#### AUTO 


```{c}
auto manager = res->knsBackend()->downloadManager();
```

#### RANGE FOR STATEMENT 


```{c}
for (Application* app : m_appList)
        app->setParent(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &pkgid : pkgids) {
        const auto pkgname = PackageKit::Daemon::packageName(pkgid);
        if (pkgname == shadowPackage)
            ret += PackageKit::Daemon::packageVersion(pkgid);
        else
            ret += i18nc("package-name (version)", "%1 (%2)", pkgname, PackageKit::Daemon::packageVersion(pkgid));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto source : qAsConst(m_flatpakLoadingSources)) {
        if (source->url() == flatpak_remote_get_url(remote) && source->installation() == flatpakInstallation) {
            metadataRefreshed();
            return source;
        }
    }
```

#### AUTO 


```{c}
const auto insts = backend->installations();
```

#### LAMBDA EXPRESSION 


```{c}
[this](const KNSCore::EntryInternal& entry){ return resourceForEntry(entry); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &source : m_flatpakSources) {
        if (source->installation() == installation && source->name() == origin) {
            return source;
        }
    }
```

#### AUTO 


```{c}
auto res = m_backend->resourceForFile(fileUrl);
```

#### AUTO 


```{c}
auto req = backend->client()->getIcon(packageName());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &arg : positionalArguments) {
        const QUrl url = QUrl::fromUserInput(arg, {}, QUrl::AssumeLocalFile);
        if (url.isLocalFile())
            mainWindow->openLocalPackage(url);
        else if (url.scheme() == QLatin1String("apt"))
            Q_EMIT mainWindow->openSearch(url.host());
        else
            mainWindow->openApplication(url);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, resource, fw, runtimeUrl, stream]() {
            fw->deleteLater();
            const auto metadata = fw->result();
            // Even when we failed to fetch information about runtime we still want to show the application
            if (metadata.isEmpty()) {
                Q_EMIT onFetchMetadataFinished(resource, metadata);
            } else {
                updateAppMetadata(resource, metadata);

                auto runtime = getRuntimeForApp(resource);
                if (!runtime || (runtime && !runtime->isInstalled())) {
                    auto repoStream = new ResultsStream(QLatin1String("FlatpakStream-searchrepo-") + runtimeUrl.toString());
                    connect(repoStream, &ResultsStream::resourcesFound, this, [this, resource, stream](const QVector<AbstractResource *> &resources) {
                        for (auto res : resources) {
                            installApplication(res);
                        }
                        addResource(resource);
                        stream->resourcesFound({resource});
                        stream->finish();
                    });

                    auto fetchRemoteResource = new FlatpakFetchRemoteResourceJob(runtimeUrl, repoStream, this);
                    fetchRemoteResource->start();
                    return;
                } else {
                    addResource(resource);
                }
            }
            stream->resourcesFound({resource});
            stream->finish();
        }
```

#### AUTO 


```{c}
auto actions = ResourcesModel::global()->messageActions();
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractResourcesBackend *backend : backends) {
        resourcesModel->addResourcesBackend(backend);
        backend->integrateMainWindow(this);
    }
```

#### AUTO 


```{c}
auto req = qobject_cast<QSnapdGetIconRequest *>(sender());
```

#### AUTO 


```{c}
auto res = m_packages.packages.take(pkg);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &path: locations) {
                QDirIterator dirIt(path, {QStringLiteral("*.knsrc")}, QDir::Files);
                for(; dirIt.hasNext(); ) {
                    dirIt.next();

                    if (files.contains(dirIt.fileName()))
                        continue;
                    files << dirIt.fileName();

                    auto bk = new KNSBackend(parent, QStringLiteral("plasma"), dirIt.filePath());
                    if (bk->isValid())
                        ret += bk;
                    else
                        delete bk;
                }
            }
```

#### AUTO 


```{c}
auto action = new OneTimeAction(
        [this, localfile]() {
            auto res = ResourcesModel::global()->resourceForFile(localfile);
            qDebug() << "all initialized..." << res;
            if (res) {
                emit openApplicationInternal(res);
            } else {
                QMimeDatabase db;
                auto mime = db.mimeTypeForUrl(localfile);
                if (mime.name().startsWith(QLatin1String("application/vnd.flatpak"))) {
                    openApplication(QUrl(QLatin1String("appstream://org.kde.discover.flatpak")));
                    showPassiveNotification(i18n("Cannot interact with flatpak resources without the flatpak backend %1. Please install it first.", localfile.toDisplayString()));
                } else {
                    setRootObjectProperty("defaultStartup", true);
                    showPassiveNotification(i18n("Couldn't open %1", localfile.toDisplayString()));
                }
            }
        }
        , this);
```

#### LAMBDA EXPRESSION 


```{c}
[this, resource](const QVector<AbstractResource *> &resources) {
                        for (auto res : resources) {
                            installApplication(res);
                        }
                        addResource(resource);
                    }
```

#### AUTO 


```{c}
const auto remoteName = flatpak_remote_ref_get_remote_name(remoteRef);
```

#### AUTO 


```{c}
auto stream = new ResultsStream(QStringLiteral("KNS-search"));
```

#### AUTO 


```{c}
const auto query = uq.toString().toUtf8();
```

#### LAMBDA EXPRESSION 


```{c}
[&filter](AbstractResource* r) { return r->state()>=filter.state && (r->name().contains(filter.search, Qt::CaseInsensitive) || r->comment().contains(filter.search, Qt::CaseInsensitive)); }
```

#### RANGE FOR STATEMENT 


```{c}
for (QApt::Package *package : packages) {
        if (m_stop) {
            m_backend->setCompressEvents(false);
            QApplication::restoreOverrideCursor();
            break;
        }

        switch (action) {
        case QApt::Package::ToInstall:
            setInstall(package);
            break;
        case QApt::Package::ToRemove:
            setRemove(package);
            break;
        case QApt::Package::ToUpgrade:
            setUpgrade(package);
            break;
        case QApt::Package::ToReInstall:
            if (package->isInstalled())
                setReInstall(package);
            break;
        case QApt::Package::ToKeep:
            setKeep(package);
            break;
        case QApt::Package::ToPurge:
            setPurge(package);
            break;
        default:
            break;
        }
    }
```

#### AUTO 


```{c}
const auto id = res->appstreamId();
```

#### LAMBDA EXPRESSION 


```{c}
[menu, this]() {
        m_item->setTitle(i18n("Restart to apply installed updates"));
        m_item->setToolTipTitle(i18n("Click to restart the computer"));
        m_item->setIconByName(QStringLiteral("view-refresh"));
        auto refreshAction = menu->addAction(QIcon::fromTheme(QStringLiteral("view-refresh")), i18n("Restart..."));
        connect(refreshAction, &QAction::triggered, &m_notifier, &DiscoverNotifier::recheckSystemUpdateNeeded);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[fetchResourceJob, stream] (bool success, FlatpakResource *resource) {
            if (success) {
                Q_EMIT stream->resourcesFound({resource});
            }
            stream->finish();
            fetchResourceJob->deleteLater();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &tid: tids) {
        if (m_transactions.contains(tid))
            continue;

        auto t = new PackageKit::Transaction(QDBusObjectPath(tid));

        connect(t, &PackageKit::Transaction::roleChanged, this, [this, t]() {
            if (t->role() == PackageKit::Transaction::RoleGetUpdates) {
                setupGetUpdatesTransaction(t);
            }
        });
        connect(t, &PackageKit::Transaction::requireRestart, this, &PackageKitNotifier::onRequireRestart);
        connect(t, &PackageKit::Transaction::finished, this, [this, t](){
            auto restart = t->property("requireRestart");
            if (!restart.isNull()) {
                auto restartEvent = PackageKit::Transaction::Restart(restart.toInt());
                if (restartEvent >= PackageKit::Transaction::RestartSession) {
                    nowNeedsReboot();
                }
            }
            m_transactions.remove(t->tid().path());
            t->deleteLater();
        });
        m_transactions.insert(tid, t);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, resource] (Transaction::Status status) {
        if (status == Transaction::Status::DoneStatus) {
            FlatpakInstallation *installation = resource->installation();
            updateAppState(installation, resource);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, stream, searchText]() {
        Q_ASSERT(!isFetching());
        if (!m_isValid) {
            stream->finish();
            return;
        }
        // No need to explicitly launch a search, setting the search term already does that for us
        m_engine->setSearchTerm(searchText);
        m_onePage = false;
        m_responsePending = true;

        connect(this, &KNSBackend::receivedResources, stream, &ResultsStream::resourcesFound);
        connect(this, &KNSBackend::searchFinished, stream, &ResultsStream::finish);
        connect(this, &KNSBackend::startingSearch, stream, &ResultsStream::finish);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[resolved, toResolve, stream]() {
                    if (!resolved.isEmpty())
                        Q_EMIT stream->resourcesFound(resolved);

                    if (toResolve.isEmpty())
                        stream->finish();
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this, fw]() {
        m_fetching = true;
        emit fetchingChanged();

        auto devices = fw->result();
        for(uint i = 0; devices && i < devices->len; i++) {
            FwupdDevice *device = (FwupdDevice *) g_ptr_array_index(devices, i);

            auto res = createDevice(device);
            g_autoptr(GPtrArray) releases = fwupd_client_get_releases(client, fwupd_device_get_id(device), nullptr, nullptr);
            for (uint i=0; releases && i<releases->len; ++i) {
                FwupdRelease *release = (FwupdRelease *)g_ptr_array_index(releases, i);
                if (res->installedVersion().toUtf8() == fwupd_release_get_version(release)) {
                    res->setReleaseDetails(release);
                    break;
                }
            }
            addResourceToList(res);
        }
        g_ptr_array_unref(devices);

        addUpdates();

        m_fetching = false;
        emit fetchingChanged();
        emit initialized();
        fw->deleteLater();
    }
```

#### AUTO 


```{c}
auto ret = QAbstractItemModel::roleNames();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                    Q_EMIT startingSearch();
                    m_onePage = true;
                    m_responsePending = true;
                    m_engine->checkForUpdates();
                }
```

#### AUTO 


```{c}
auto mReportBugAction = KStandardAction::reportBug(this, SLOT(reportBug()), this);
```

#### AUTO 


```{c}
auto app = qobject_cast<LocalFilePKResource*>(m_apps.at(0));
```

#### AUTO 


```{c}
const auto metadata = fw->result();
```

#### LAMBDA EXPRESSION 


```{c}
[this, localfile]() {
            auto res = ResourcesModel::global()->resourceForFile(localfile);
            qDebug() << "all initialized..." << res;
            if (res) {
                emit openApplicationInternal(res);
            } else
                showPassiveNotification(i18n("Couldn't open %1", localfile.toDisplayString()));
        }
```

#### AUTO 


```{c}
auto req = client()->listOne(packageName());
```

#### AUTO 


```{c}
const auto pathParts = search.path().split(QLatin1Char('/'), Qt::SkipEmptyParts);
```

#### AUTO 


```{c}
auto restart = t->property("requireRestart");
```

#### AUTO 


```{c}
auto action = new OneTimeAction(
        [this, url]() {
            AbstractResourcesBackend::Filters f;
            f.resourceUrl = url;
            auto stream = new StoredResultsStream({ResourcesModel::global()->search(f)});
            connect(stream, &StoredResultsStream::finished, this, [this, url, stream]() {
                const auto res = stream->resources();
                if (res.count() == 1) {
                    emit openApplicationInternal(res.first());
                } else {
                    setRootObjectProperty("defaultStartup", true);
                    Q_EMIT openErrorPage(i18n("Couldn't open %1", url.toDisplayString()));
                }
            });
        }
        , this);
```

#### AUTO 


```{c}
auto cats = kToSet(m_filters.category ? m_filters.category->subCategories() : CategoryModel::global()->rootCategories());
```

#### AUTO 


```{c}
auto streams = kTransform<QSet<ResultsStream*>>(m_backends, [search](AbstractResourcesBackend* backend){ return backend->findResourceByPackageName(search); });
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        m_notifier.showDiscover(m_item->providedToken());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& pkgid : m_updatesPackageId) {
        if (TransactionpackageName(pkgid) == name)
            return pkgid;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, filter, stream] {
            const auto resources = kTransform<QVector<AbstractResource*>>(m_packages.extendedBy.value(filter.extends), [](AppPackageKitResource* a){ return a; });
            if (!resources.isEmpty()) {
                stream->setResources(resources);
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[servicePath, this](){
        bool b = QProcess::startDetached(QStringLiteral(CMAKE_INSTALL_FULL_LIBEXECDIR_KF5 "/discover/runservice"), {servicePath});
        if (!b)
            qWarning() << "Could not start" << servicePath;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto res : qAsConst(m_resources)) {
            if (resources.contains(res))
                res->setState(AbstractResource::Installed);
            else
                res->setState(AbstractResource::None);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QApt::Package *package : *i) {
            root->appendRow(new QStandardItem(KIcon("muon"), package->name()));
        }
```

#### LAMBDA EXPRESSION 


```{c}
[mainWindow](const QStringList &arguments, const QString &/*workingDirectory*/){
            QScopedPointer<QCommandLineParser> parser(createParser());
            parser->process(arguments);
            processArgs(parser.data(), mainWindow);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, fw, stream]() {
                if (g_cancellable_is_cancelled(m_cancellable)) {
                    stream->finish();
                    fw->deleteLater();
                    return;
                }

                const auto refs = fw->result();
                QVector<AbstractResource *> resources;
                for (auto it = refs.constBegin(), itEnd = refs.constEnd(); it != itEnd; ++it) {
                    resources.reserve(resources.size() + it->size());
                    for (auto ref : qAsConst(it.value())) {
                        auto resource = getAppForInstalledRef(it.key(), ref);
#if FLATPAK_CHECK_VERSION(1, 1, 2)
                        resource->setAvailableVersion(QString::fromUtf8(flatpak_installed_ref_get_appdata_version(ref)));
#endif
                        g_object_unref(ref);
                        resource->setState(AbstractResource::Upgradeable);
                        updateAppSize(resource);
                        if (resource->resourceType() == FlatpakResource::Runtime) {
                            resources.prepend(resource);
                        } else {
                            resources.append(resource);
                        }
                    }
                }

                if (!resources.isEmpty())
                    Q_EMIT stream->resourcesFound(resources);
                stream->finish();
                fw->deleteLater();
            }
```

#### AUTO 


```{c}
auto item = sourceById(sourceId);
```

#### AUTO 


```{c}
auto resources2 = fetchResources(m_appBackend->search({}));
```

#### RANGE FOR STATEMENT 


```{c}
for(Transaction* t: trans) {
        if (t->property("updater").value<QObject*>() == this)
            ret += t->downloadSpeed();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& instRef : qAsConst(toRemoveRefs)) {
                        const QByteArray refString = instRef.toUtf8();
                        flatpak_transaction_add_uninstall(transaction, refString.constData(), &localError);
                        if (localError)
                            return;
                    }
```

#### AUTO 


```{c}
auto resource = getAppForInstalledRef(it.key(), ref, &fresh);
```

#### AUTO 


```{c}
auto packageDependencies = QSharedPointer<QJsonArray>::create();
```

#### AUTO 


```{c}
auto item = itemFromResource(app, m_rootItem.data());
```

#### AUTO 


```{c}
auto f = [this, stream, url] () {
                QVector<AbstractResource*> resources;
                foreach(FlatpakResource* res, m_resources) {
                    if (QString::compare(res->appstreamId(), url.host(), Qt::CaseInsensitive)==0)
                        resources << res;
                }
                auto f = [this](AbstractResource* l, AbstractResource* r) { return flatpakResourceLessThan(l,r); };
                std::sort(resources.begin(), resources.end(), f);

                if (!resources.isEmpty())
                    Q_EMIT stream->resourcesFound(resources);
                stream->finish();
            };
```

#### AUTO 


```{c}
auto randomRating = qrand() % 10;
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractResource *res : resources) {
        qobject_cast<PackageKitResource *>(res)->setDetails(details);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Application *app : m_appList) {
        app->setParent(this);
        pkg = app->package();
        if (pkg->isInstalled())
            m_instOriginList << pkg->origin();
        else
            m_originList << pkg->origin();
    }
```

#### AUTO 


```{c}
auto filter = m_notFilters.constBegin();
```

#### AUTO 


```{c}
auto matchIt = envRx.globalMatch(path);
```

#### AUTO 


```{c}
const auto name = QLatin1String(flatpak_ref_get_name(FLATPAK_REF(ref)));
```

#### AUTO 


```{c}
auto res = qobject_cast<KNSResource*>(app);
```

#### AUTO 


```{c}
auto resources = getResources(m_appBackend->search(f), true);
```

#### AUTO 


```{c}
auto newValue = m_get();
```

#### LAMBDA EXPRESSION 


```{c}
[this, installation, fw](){
        auto refs = fw->result();
        if (refs)
            onFetchUpdatesFinished(installation, refs);
        fw->deleteLater();
    }
```

#### AUTO 


```{c}
auto f = [this](AbstractResource *l, AbstractResource *r) {
            return flatpakResourceLessThan(l, r);
        };
```

#### AUTO 


```{c}
const auto metadata = metadataFromBytes(appstreamGz, m_cancellable);
```

#### AUTO 


```{c}
const auto resources = resourcesByAppstreamName(name);
```

#### AUTO 


```{c}
const auto alts = res->alternativeAppstreamIds();
```

#### AUTO 


```{c}
auto mReportBugAction = KStandardAction::reportBug(this, &DiscoverMainWindow::reportBug, this);
```

#### LAMBDA EXPRESSION 


```{c}
[this, stream] () {
        setResources(stream->resources());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](AbstractResource* res) { return res->type() != AbstractResource::Technical; }
```

#### AUTO 


```{c}
auto source = integrateRemote(preferredInstallation(), remote);
```

#### AUTO 


```{c}
auto start = [this, entryid, stream, providerid]() {
        if (m_responsePending) {
            // Slot already taken, will need to wait again
            return;
        }
        setResponsePending(true);
        m_engine->fetchEntryById(entryid);
        m_onePage = true;

        connect(m_engine, &KNSCore::Engine::signalErrorCode, stream, &ResultsStream::finish);
        connect(m_engine,
                &KNSCore::Engine::signalEntryEvent,
                stream,
                [this, stream, entryid, providerid](const KNSCore::EntryInternal &entry, KNSCore::EntryInternal::EntryEvent event) {
                    switch (event) {
                    case KNSCore::EntryInternal::StatusChangedEvent:
                        if (entry.uniqueId() == entryid && providerid == QUrl(entry.providerId()).host()) {
                            Q_EMIT stream->resourcesFound({resourceForEntry(entry)});
                        } else
                            qWarning() << "found invalid" << entryid << entry.uniqueId() << providerid << QUrl(entry.providerId()).host();
                        QTimer::singleShot(0, this, [this] {
                            setResponsePending(false);
                        });
                        stream->finish();
                        break;
                    case KNSCore::EntryInternal::DetailsLoadedEvent:
                    case KNSCore::EntryInternal::AdoptedEvent:
                    case KNSCore::EntryInternal::UnknownEvent:
                    default:
                        break;
                    }
                });
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const QApt::HistoryItem &item : m_history->historyItems()) {
        QDateTime startDateTime = item.startDate();
        QString formattedTime = KGlobal::locale()->formatTime(startDateTime.time());
        QString category;

        QString date = startDateTime.date().toString();
        if (categoryHash.contains(date)) {
            category = categoryHash.value(date);
        } else {
            category = KGlobal::locale()->formatDate(startDateTime.date(), KLocale::FancyShortDate);
            categoryHash[date] = category;
        }

        QStandardItem *parentItem = 0;

        if (!m_categoryHash.contains(category)) {
            parentItem = new QStandardItem;
            parentItem->setEditable(false);
            parentItem->setText(category);
            parentItem->setData(startDateTime, HistoryProxyModel::HistoryDateRole);

            m_historyModel->appendRow(parentItem);
            m_categoryHash[category] = parentItem;
        } else {
            parentItem = m_categoryHash.value(category);
        }

        foreach (const QString &package, item.installedPackages()) {
            QStandardItem *historyItem = new QStandardItem;
            historyItem->setEditable(false);
            historyItem->setIcon(itemIcon);

            QString action = actionHash.value(InstalledAction);
            QString text = i18nc("@item example: muon installed at 16:00", "%1 %2 at %3",
                                 package, action, formattedTime);
            historyItem->setText(text);
            historyItem->setData(startDateTime, HistoryProxyModel::HistoryDateRole);
            historyItem->setData(QApt::Package::ToInstall, HistoryProxyModel::HistoryActionRole);

            parentItem->appendRow(historyItem);
        }

        foreach (const QString &package, item.upgradedPackages()) {
            QStandardItem *historyItem = new QStandardItem;
            historyItem->setEditable(false);
            historyItem->setIcon(itemIcon);

            QString action = actionHash.value(UpgradedAction);
            QString text = i18nc("@item example: muon installed at 16:00", "%1 %2 at %3",
                                 package, action, formattedTime);
            historyItem->setText(text);
            historyItem->setData(startDateTime, HistoryProxyModel::HistoryDateRole);
            historyItem->setData(QApt::Package::ToUpgrade, HistoryProxyModel::HistoryActionRole);

            parentItem->appendRow(historyItem);
        }

        foreach (const QString &package, item.downgradedPackages()) {
            QStandardItem *historyItem = new QStandardItem;
            historyItem->setEditable(false);
            historyItem->setIcon(itemIcon);

            QString action = actionHash.value(DowngradedAction);
            QString text = i18nc("@item example: muon installed at 16:00", "%1 %2 at %3",
                                 package, action, formattedTime);
            historyItem->setText(text);
            historyItem->setData(startDateTime, HistoryProxyModel::HistoryDateRole);
            historyItem->setData(QApt::Package::ToDowngrade, HistoryProxyModel::HistoryActionRole);

            parentItem->appendRow(historyItem);
        }

        foreach (const QString &package, item.removedPackages()) {
            QStandardItem *historyItem = new QStandardItem;
            historyItem->setEditable(false);
            historyItem->setIcon(itemIcon);

            QString action = actionHash.value(RemovedAction);
            QString text = i18nc("@item example: muon installed at 16:00", "%1 %2 at %3",
                                 package, action, formattedTime);
            historyItem->setText(text);
            historyItem->setData(startDateTime, HistoryProxyModel::HistoryDateRole);
            historyItem->setData(QApt::Package::ToRemove, HistoryProxyModel::HistoryActionRole);

            parentItem->appendRow(historyItem);
        }

        foreach (const QString &package, item.purgedPackages()) {
            QStandardItem *historyItem = new QStandardItem;
            historyItem->setEditable(false);
            historyItem->setIcon(itemIcon);

            QString action = actionHash.value(PurgedAction);
            QString text = i18nc("@item example: muon installed at 16:00", "%1 %2 at %3",
                                 package, action, formattedTime);
            historyItem->setText(text);
            historyItem->setData(startDateTime, HistoryProxyModel::HistoryDateRole);
            historyItem->setData(QApt::Package::ToPurge, HistoryProxyModel::HistoryActionRole);

            parentItem->appendRow(historyItem);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(Category* cat : cats) {
        Category* ret = recFindCategory(cat, name);
        if(ret)
            return ret;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[stream, this, state](SnapJob* job) {
        if (!job->isSuccessful()) {
            stream->finish();
            return;
        }

        const auto snaps = job->result().toArray();

        QVector<AbstractResource*> ret;
        QSet<SnapResource*> resources;
        for(const auto& snap: snaps) {
            const auto snapObj = snap.toObject();
            const auto snapid = snapObj.value(QLatin1String("name")).toString();
            SnapResource* res = m_resources.value(snapid);
            if (!res) {
                res = new SnapResource(snapObj, state, this);
                Q_ASSERT(res->packageName() == snapid);
                resources += res;
            }
            ret += res;
        }

        if (!resources.isEmpty()) {
            foreach(SnapResource* res, resources)
                m_resources[res->packageName()] = res;
        }
        if (!ret.isEmpty())
            stream->resourcesFound(ret);
        stream->finish();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(QApt::Package* it : pkgList) {
            AbstractResource* res = m_appBackend->resourceByPackageName(it->name());
            if(!res) //If we couldn't find it by its name, try with
                res = m_appBackend->resourceByPackageName(QString("%1:%2").arg(it->name()).arg(it->architecture()));

            if(res)
                m_toUpdate += res;
            else
                qWarning() << "Couldn't find the package:" << it->name();
            Q_ASSERT(res);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto slot : theSlots) {
                    auto item = new QStandardItem;
                    if (plug->label().isEmpty())
                        item->setText(plug->name());
                    else
                        item->setText(i18n("%1 - %2", plug->name(), plug->label()));

                    // qDebug() << "xxx" << plug->name() << plug->label() << plug->interface() << slot->snap() << "slot:" << slot->name() <<
                    // slot->snap() << slot->interface() << slot->label();
                    item->setCheckable(true);
                    item->setCheckState(plug->connectionCount() > 0 ? Qt::Checked : Qt::Unchecked);
                    item->setData(plug->name(), PlugNameRole);
                    item->setData(slot->snap(), SlotSnapRole);
                    item->setData(slot->name(), SlotNameRole);
                    appendRow(item);
                }
```

#### LAMBDA EXPRESSION 


```{c}
[](AbstractResource *res) {
    return res->state() == AbstractResource::Broken;
}
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &source : m_flatpakSources) {
        if (source->m_resources.contains(uid)) {
            return true;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[job] {
        QCoreApplication::instance()->exit(job->error());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const QString &errorMessage) { Q_EMIT passiveMessage(errorMessage); }
```

#### LAMBDA EXPRESSION 


```{c}
[this, p] (int code, QProcess::ExitStatus status) {
                p->deleteLater();
                if (code != 0) {
                    qWarning() << "login failed... code:" << code << status << p->readAll();
                    Q_EMIT passiveMessage(m_request->errorString());
                    setStatus(DoneWithErrorStatus);
                    return;
                }
                const auto doc = QJsonDocument::fromJson(p->readAllStandardOutput());
                const auto result = doc.object();

                const auto macaroon = result[QStringLiteral("macaroon")].toString();
                const auto discharges = kTransform<QStringList>(result[QStringLiteral("discharges")].toArray(), [](const QJsonValue& val) { return val.toString(); });
                static_cast<SnapBackend*>(m_app->backend())->client()->setAuthData(new QSnapdAuthData(macaroon, discharges));
                m_request->runAsync();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractBackendUpdater *upd : m_updaters) {
        ret += std::max(0., upd->updateSize());
    }
```

#### AUTO 


```{c}
const auto handle = handleEula(eulaID, licenseAgreement);
```

#### LAMBDA EXPRESSION 


```{c}
[this, stream, searchText]() {
        Q_ASSERT(!isFetching());
        if (!m_isValid) {
            stream->finish();
            return;
        }
        // No need to explicitly launch a search, setting the search term already does that for us
        m_engine->setSearchTerm(searchText);
        m_onePage = false;
        m_responsePending = true;

        QSharedPointer<int> count(new int(0));
        connect(this, &KNSBackend::receivedResources, stream, [this, count](const QVector<AbstractResource*>& resources){
            *count += resources.count();
            if (*count>2000)
                m_stopSearching = true;
        });
        connect(this, &KNSBackend::receivedResources, stream, &ResultsStream::resourcesFound);
        connect(this, &KNSBackend::searchFinished, stream, &ResultsStream::finish);
        connect(this, &KNSBackend::startingSearch, stream, &ResultsStream::finish);
    }
```

#### AUTO 


```{c}
auto service = PackageKitBackend::locateService(QStringLiteral("software-properties-qt.desktop"));
```

#### AUTO 


```{c}
auto ret = flatpak_installation_fetch_remote_ref_sync_full(app->installation(),
                                                               origin.constData(),
                                                               kind,
                                                               name.constData(),
                                                               arch.constData(),
                                                               branch.constData(),
                                                               FLATPAK_QUERY_FLAGS_ONLY_CACHED,
                                                               cancellable,
                                                               &localError);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            auto trans = PackageKit::Daemon::global()->repairSystem();
            connect(trans, &PackageKit::Transaction::errorCode, this, [](PackageKit::Transaction::Error /*error*/, const QString &details) {
                KNotification::event(QStringLiteral("OfflineUpdateRepairFailed"),
                                     i18n("Repair Failed"),
                                     i18n("Please report to your distribution: %1", details),
                                     {},
                                     KNotification::Persistent,
                                     QStringLiteral("org.kde.discovernotifier"));
            });
        }
```

#### AUTO 


```{c}
auto it = source->m_resources.constBegin(), itEnd = source->m_resources.constEnd();
```

#### LAMBDA EXPRESSION 


```{c}
[](QQmlEngine*, QJSEngine*) -> QObject* {
            auto r = new DiscoverSettings;
            connect(r, &DiscoverSettings::installedPageSortingChanged, r, &DiscoverSettings::save);
            connect(r, &DiscoverSettings::appsListPageSortingChanged, r, &DiscoverSettings::save);
            return r;
        }
```

#### AUTO 


```{c}
const auto desc = m_appdata.description();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto res : qAsConst(m_resources)) {
            PackageKitResource * app = qobject_cast<PackageKitResource*>(res);
            QString pkgid = m_backend->upgradeablePackageId(app);
            if (!donePkgs.contains(pkgid)) {
                donePkgs.insert(pkgid);
                ret += app->size();
            }
        }
```

#### AUTO 


```{c}
const auto kind = app->resourceType() == FlatpakResource::DesktopApp ? FLATPAK_REF_KIND_APP : FLATPAK_REF_KIND_RUNTIME;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &name : pkgnames) {
        const QStringList names = m_packages.packageToApp.value(name, QStringList(name));
        foreach (const QString &name, names) {
            AbstractResource *res = m_packages.packages.value(name);
            if (res)
                ret += res;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[addSource](const QVector<AbstractResource *> &res) {
            addSource(res.constFirst());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto source : qAsConst(m_flatpakLoadingSources)) {
        if (source->url() == flatpak_remote_get_url(remote)) {
            qDebug() << "do not add a source twice" << source << remote;
            metadataRefreshed();
            return source;
        }
    }
```

#### AUTO 


```{c}
auto repoStream = new ResultsStream(QLatin1String("FlatpakStream-searchrepo-") + runtimeUrl.toString());
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        m_settingUp = false;
        Q_EMIT updatesCountChanged(updatesCount());
        Q_EMIT progressingChanged(false);
    }
```

#### AUTO 


```{c}
const auto discharges = kTransform<QStringList>(result[QStringLiteral("discharges")].toArray(), [](const QJsonValue& val) { return val.toString(); });
```

#### AUTO 


```{c}
auto trans = PackageKit::Daemon::installPackages({ pkgid }, PackageKit::Transaction::TransactionFlagSimulate);
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
                    //No need to check for updates if there's no resources
                    if (m_resourcesByName.isEmpty()) {
                        return;
                    }

                    Q_EMIT startingSearch();
                    m_onePage = true;
                    m_responsePending = true;
                    m_engine->checkForUpdates();
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto b : ResourcesModel::global()->backends())
                found |= b->hasApplications();
```

#### RANGE FOR STATEMENT 


```{c}
for(auto resource: qAsConst(resources)) {
        const auto finder = [this](AbstractResource* resource, AbstractResource* res){ return lessThan(resource, res); };
        const auto it = std::upper_bound(m_displayedResources.constBegin(), m_displayedResources.constEnd(), resource, finder);
        const auto newIdx = it == m_displayedResources.constEnd() ? m_displayedResources.count() : (it - m_displayedResources.constBegin());

        if ((it-1) != m_displayedResources.constEnd() && *(it-1) == resource)
            continue;

        beginInsertRows({}, newIdx, newIdx);
        m_displayedResources.insert(newIdx, resource);
        endInsertRows();
//         Q_ASSERT(isSorted(resources));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto stream: streams) {
        connect(stream, &ResultsStream::resourcesFound, this, &AggregatedResultsStream::addResults);
        connect(stream, &QObject::destroyed, this, &AggregatedResultsStream::destruction);
        m_streams << stream;
    }
```

#### AUTO 


```{c}
const auto &source
```

#### RANGE FOR STATEMENT 


```{c}
for(auto backend: m_backends) {
                sum += backend->fetchingUpdatesProgress();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto backend: qAsConst(m_backends)) {
                sum += backend->fetchingUpdatesProgress();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (UpdateItem *item : qAsConst(m_updateItems)) {
        if (item->app() == res)
            return item;
    }
```

#### AUTO 


```{c}
auto reasonIter = failedReasons.constBegin();
```

#### AUTO 


```{c}
auto m = const_cast<AbstractSourcesBackend *>(this)->sources();
```

#### AUTO 


```{c}
auto id2 = idForInstalledRef(ref, QStringLiteral(".desktop"));
```

#### LAMBDA EXPRESSION 


```{c}
[stream, resources] () {
                stream->resourcesFound(resources);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString &name : pkgnames) {
        const QStringList names = m_packages.packageToApp.value(name, QStringList(name));
        foreach(const QString& name, names) {
            AbstractResource* res = m_packages.packages.value(name);
            if (res)
                ret += res;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &alias : alts) {
            aliases[alias] = appstreamid;
        }
```

#### AUTO 


```{c}
auto backend = qobject_cast<SnapBackend *>(parent());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &dir : libraryPaths) {
        QDirIterator it(dir + QStringLiteral("/discover"), QDir::Files);
        while (it.hasNext()) {
            it.next();
            if (QLibrary::isLibrary(it.fileName()) && (allowDummy || it.fileName() != QLatin1String("dummy-backend.so"))) {
                pluginNames += it.fileInfo().baseName();
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, stream, entryid, providerid](const KNSCore::EntryInternal &entry) {
            if (entry.uniqueId() == entryid && providerid == QUrl(entry.providerId()).host()) {
                stream->resourcesFound({resourceForEntry(entry)});
            }
            m_responsePending = false;
            QTimer::singleShot(0, this, &KNSBackend::availableForQueries);
            stream->finish();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[res, engine]() {
                const auto links = res->linkIds();
                for(auto i : links)
                    engine->install(res->entry(), i);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[](AbstractResourcesBackend *backend) {
        return backend->name() == QLatin1String("discover_ktexteditor_codesnippets_core.knsrc");
    }
```

#### AUTO 


```{c}
auto f = [this, stream, appstreamId] () {
                const auto resources = resourcesByAppstreamName(appstreamId);
                if (!resources.isEmpty())
                    Q_EMIT stream->resourcesFound(resources);
                stream->finish();
            };
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractResourcesBackend *backend : qAsConst(m_backends)) {
                      ret += backend->updatesCount();
                  }
```

#### LAMBDA EXPRESSION 


```{c}
[this](){
        int s = (m_state+1) % 4;
        setState(State(s));
    }
```

#### AUTO 


```{c}
const auto id = it.key();
```

#### AUTO 


```{c}
auto transaction = PackageKit::Daemon::global()->repoRemove(id, false);
```

#### AUTO 


```{c}
const auto pkgid = availablePackageId();
```

#### AUTO 


```{c}
auto installation
```

#### AUTO 


```{c}
auto action = new OneTimeAction(
        [this, url]() {
            AbstractResourcesBackend::Filters f;
            f.resourceUrl = url;
            auto stream = new StoredResultsStream({ResourcesModel::global()->search(f)});
            connect(stream, &StoredResultsStream::finished, this, [this, url, stream]() {
                const auto res = stream->resources();
                if (res.count() == 1) {
                    emit openApplicationInternal(res.first());
                } else {
                    rootObject()->setProperty("defaultStartup", true);
                    showPassiveNotification(i18n("Couldn't open %1", url.toDisplayString()));
                }
            });
        }
        , this);
```

#### LAMBDA EXPRESSION 


```{c}
[stream, this, state, job]() {
        QSet<SnapResource*> higher = kFilter<QSet<SnapResource*>>(m_resources, [state](AbstractResource* res){ return res->state()>=state; });

        QVector<AbstractResource*> ret;
        QSet<SnapResource*> resources;
        for (int i=0, c=job->snapCount(); i<c; ++i) {
            QSharedPointer<QSnapdSnap> snap(job->snap(i));
            const auto snapname = snap->name();
            SnapResource* res = m_resources.value(snapname);
            if (!res) {
                res = new SnapResource(snap, state, this);
                Q_ASSERT(res->packageName() == snapname);
                resources += res;
            } else {
                res->setState(state);
                higher.remove(res);
            }
            ret += res;
        }

        foreach(SnapResource* res, resources)
            m_resources[res->packageName()] = res;
        for(auto res: higher) {
            res->setState(AbstractResource::None);
        }

        if (!ret.isEmpty())
            stream->resourcesFound(ret);
        stream->finish();
    }
```

#### AUTO 


```{c}
const auto ret = kFilter<QVector<AbstractResource*>>(m_resourcesByName, filterFunction);
```

#### LAMBDA EXPRESSION 


```{c}
[this, filter, stream] {
            auto resources = kFilter<QVector<AbstractResource *>>(m_packages.packages, [](AbstractResource *res) {
                return res->type() != AbstractResource::Technical && !qobject_cast<PackageKitResource *>(res)->extendsItself();
            });
            if (!resources.isEmpty()) {
                stream->setResources(resources);
            }
            stream->finish();
        }
```

#### AUTO 


```{c}
auto f = [this, filter, stream] {
            const auto resources = kTransform<QVector<AbstractResource *>>(m_packages.extendedBy.value(filter.extends), [](AppPackageKitResource *a) {
                return a;
            });
            stream->setResources(resources);
            stream->finish();
        };
```

#### AUTO 


```{c}
auto stream = backend->search(f);
```

#### LAMBDA EXPRESSION 


```{c}
[](QQuickWindow::SceneGraphError /*error*/, const QString &message) {
        KCrash::setErrorMessage(message);
        qFatal("%s", qPrintable(message));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[resolved, toResolve, stream] () {
                    if (!resolved.isEmpty())
                        Q_EMIT stream->resourcesFound(resolved);

                    if (toResolve.isEmpty())
                        stream->finish();
                }
```

#### AUTO 


```{c}
auto ref = qobject_cast<FlatpakBackend *>(backend())->getInstalledRefForApp(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            reloadPackageList();
            acquireFetching(false);
        }
```

#### AUTO 


```{c}
auto at = storedIds.find(appstreamid);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto updater : qAsConst(m_allUpdaters)) {
            connect(updater, &AbstractBackendUpdater::progressingChanged, this, &UpdateTransaction::slotProgressingChanged);
            connect(updater, &AbstractBackendUpdater::downloadSpeedChanged, this, &UpdateTransaction::slotDownloadSpeedChanged);
            connect(updater, &AbstractBackendUpdater::progressChanged, this, &UpdateTransaction::slotUpdateProgress);
            connect(updater, &AbstractBackendUpdater::proceedRequest, this, &UpdateTransaction::processProceedRequest);
            connect(updater, &AbstractBackendUpdater::cancelableChanged, this, [this](bool) {
                setCancellable(kContains(m_allUpdaters, [](AbstractBackendUpdater *updater) {
                    return updater->isCancelable() && updater->isProgressing();
                }));
            });
            cancelable |= updater->isCancelable();
        }
```

#### AUTO 


```{c}
auto ret = source->m_resources.value(id2);
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const QString &/*pkgid*/, const QStringList & files) {
        const auto execIdx = kIndexOf(files, [](const QString& file) { return file.endsWith(QLatin1String(".desktop")) && file.contains(QLatin1String("usr/share/applications")); });
        if (execIdx >= 0)
            m_exec = files[execIdx];
        else
            qWarning() << "could not find an executable desktop file for" << m_path << "among" << files;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](AbstractResource *res) {
                return res->type() != AbstractResource::Technical && !qobject_cast<PackageKitResource *>(res)->isCritical()
                    && !qobject_cast<PackageKitResource *>(res)->extendsItself();
            }
```

#### AUTO 


```{c}
auto process = new QProcess(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &name : names) {
            AbstractResource *res = m_packages.packages.value(name);
            if (res)
                ret += res;
        }
```

#### AUTO 


```{c}
const auto cats = CategoryModel::rootCategories();
```

#### AUTO 


```{c}
auto start = [this, entryid, stream]() {
        m_responsePending = true;
        m_engine->fetchEntryById(entryid);
        connect(m_engine, &KNSCore::Engine::signalEntryDetailsLoaded, stream, [this, stream, entryid](const KNSCore::EntryInternal &entry) {
            if (entry.uniqueId() == entryid) {
                stream->resourcesFound({resourceForEntry(entry)});
            }
            m_responsePending = false;
            QTimer::singleShot(0, this, &KNSBackend::availableForQueries);
            stream->deleteLater();
        });
    };
```

#### AUTO 


```{c}
auto &r = m_resources[res->packageName()];
```

#### AUTO 


```{c}
auto stream = new StoredResultsStream({backend->search(filter)});
```

#### AUTO 


```{c}
const auto it = sourceForId(id);
```

#### LAMBDA EXPRESSION 


```{c}
[filter] (AbstractResource *res) {
                return res->state() >= AbstractResource::Installed && (res->name().contains(filter.search) || res->packageName() == filter.search);
            }
```

#### AUTO 


```{c}
auto f = [this, stream, filter] {
            const auto toResolve = kFilter<QVector<AbstractResource *>>(m_packages.packages, needsResolveFilter);

            auto installedAndNameFilter = [filter](AbstractResource *res) {
                return res->state() >= AbstractResource::Installed && (res->name().contains(filter.search) || res->packageName() == filter.search);
            };
            bool furtherSearch = false;
            if (!toResolve.isEmpty()) {
                resolvePackages(kTransform<QStringList>(toResolve, [](AbstractResource *res) {
                    return res->packageName();
                }));
                connect(m_resolveTransaction, &PKResolveTransaction::allFinished, this, [stream, toResolve, installedAndNameFilter] {
                    const auto resolved = kFilter<QVector<AbstractResource *>>(toResolve, installedAndNameFilter);
                    if (!resolved.isEmpty())
                        Q_EMIT stream->resourcesFound(resolved);
                    stream->finish();
                });
                furtherSearch = true;
            }

            const auto resolved = kFilter<QVector<AbstractResource *>>(m_packages.packages, installedAndNameFilter);
            if (!resolved.isEmpty()) {
                QTimer::singleShot(0, this, [resolved, toResolve, stream]() {
                    if (!resolved.isEmpty())
                        Q_EMIT stream->resourcesFound(resolved);

                    if (toResolve.isEmpty())
                        stream->finish();
                });
                furtherSearch = true;
            }

            if (!furtherSearch)
                stream->finish();
        };
```

#### LAMBDA EXPRESSION 


```{c}
[this, resource](Transaction::Status status) {
        if (status == Transaction::Status::DoneStatus) {
            updateAppSize(resource);
        }
    }
```

#### AUTO 


```{c}
auto ret = model->property(DisplayName);
```

#### LAMBDA EXPRESSION 


```{c}
[stream, toResolve, installedAndNameFilter] {
                    const auto resolved = kFilter<QVector<AbstractResource*>>(toResolve, installedAndNameFilter);
                    if (!resolved.isEmpty())
                        Q_EMIT stream->resourcesFound(resolved);
                    stream->finish();
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this, fw, stream]() {
                if (g_cancellable_is_cancelled(m_cancellable)) {
                    stream->finish();
                    fw->deleteLater();
                    return;
                }

                const auto refs = fw->result();
                QVector<AbstractResource *> resources;
                for (auto it = refs.constBegin(), itEnd = refs.constEnd(); it != itEnd; ++it) {
                    resources.reserve(resources.size() + it->size());
                    for (auto ref : qAsConst(it.value())) {
                        auto resource = getAppForInstalledRef(it.key(), ref);
                        g_object_unref(ref);
                        resource->setState(AbstractResource::Upgradeable);
                        updateAppSize(resource);
                        if (resource->resourceType() == FlatpakResource::Runtime) {
                            resources.prepend(resource);
                        } else {
                            resources.append(resource);
                        }
                    }
                }

                if (!resources.isEmpty())
                    Q_EMIT stream->resourcesFound(resources);
                stream->finish();
                fw->deleteLater();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for(AbstractResource* res : m_packages.values()) {
        if (res->state() == AbstractResource::Upgradeable) {
            ret++;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[regularCheck](const QStringRef &value) {
            bool ok;
            const int days = value.toInt(&ok);
            if (!ok || days == 0) {
                regularCheck->setInterval(24 * 60 * 60 * 1000); // refresh at least once every day
                regularCheck->start();
                if (!value.isEmpty())
                    qWarning() << "couldn't understand value for timer:" << value;
            }

            // if the setting is not empty, refresh will be carried out by unattended-upgrade
            // https://wiki.debian.org/UnattendedUpgrades
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : files) {
            QString fullPath = dir.absoluteFilePath(file);
            QPluginLoader loader(fullPath);
            loader.load();
            ret += qobject_cast<BackendNotifierModule *>(loader.instance());
            if (ret.last() == nullptr) {
                qWarning() << "couldn't load" << fullPath << "because" << loader.errorString();
                ret.removeLast();
            }
        }
```

#### AUTO 


```{c}
const auto &id = it.key();
```

#### AUTO 


```{c}
auto updater
```

#### RANGE FOR STATEMENT 


```{c}
for(AbstractResource* res : m_packages) {
        if(res->name().contains(searchText, Qt::CaseInsensitive))
            ret += res;
    }
```

#### AUTO 


```{c}
const auto oldState = state();
```

#### AUTO 


```{c}
auto addNativeSourcesManager = [this](const QString &file) {
        auto service = PackageKitBackend::locateService(file);
        if (!service.isEmpty())
            m_actions += QVariant::fromValue<QObject *>(createActionForService(service, this));
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            Q_EMIT startingSearch();
            m_onePage = true;
            m_responsePending = true;
            m_engine->checkForUpdates();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](QJsonValue a, QJsonValue b) {
            const auto objA = a.toObject(), objB = b.toObject();
            return objA[QLatin1String("packageInfo")].toString() < objB[QLatin1String("packageInfo")].toString()
                || (objA[QLatin1String("packageInfo")].toString() == objB[QLatin1String("packageInfo")].toString()
                    && objA[QLatin1String("packageName")].toString() < objB[QLatin1String("packageName")].toString());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(AbstractResource* res : m_packages) {
        if(res->name()==name || res->packageName()==name) {
            ret = res;
            break;
        }
    }
```

#### AUTO 


```{c}
const auto dirs = QStringView(filesystems).split(';', Qt::SkipEmptyParts);
```

#### LAMBDA EXPRESSION 


```{c}
[this, fw]() {
        m_fetching = true;
        emit fetchingChanged();

        auto devices = fw->result();
        for(uint i = 0; devices && i < devices->len; i++) {
            FwupdDevice *device = (FwupdDevice *) g_ptr_array_index(devices, i);

            if (!fwupd_device_has_flag (device, FWUPD_DEVICE_FLAG_SUPPORTED))
                continue;

            g_autoptr(GError) error = nullptr;
            g_autoptr(GPtrArray) releases = fwupd_client_get_releases(client, fwupd_device_get_id(device), nullptr, &error);

            if (error) {
                if (g_error_matches(error, FWUPD_ERROR, FWUPD_ERROR_NOT_SUPPORTED)) {
                    qWarning() << "fwupd: Device not supported:" << fwupd_device_get_name(device);
                    continue;
                }
                if (g_error_matches(error, FWUPD_ERROR, FWUPD_ERROR_INVALID_FILE)) {
                    continue;
                }

                handleError(error);
            }

            auto res = createDevice(device);
            for (uint i=0; releases && i<releases->len; ++i) {
                FwupdRelease *release = (FwupdRelease *)g_ptr_array_index(releases, i);
                if (res->installedVersion().toUtf8() == fwupd_release_get_version(release)) {
                    res->setReleaseDetails(release);
                    break;
                }
            }
            addResourceToList(res);
        }
        g_ptr_array_unref(devices);

        addUpdates();

        m_fetching = false;
        emit fetchingChanged();
        emit initialized();
        fw->deleteLater();
    }
```

#### AUTO 


```{c}
const auto start = [this, stream, filter]() {
            if (m_isValid) {
                auto filterFunction = [&filter](AbstractResource *r) {
                    return r->state() >= filter.state
                        && (r->name().contains(filter.search, Qt::CaseInsensitive) || r->comment().contains(filter.search, Qt::CaseInsensitive));
                };
                const auto ret = kFilter<QVector<AbstractResource *>>(m_resourcesByName, filterFunction);

                if (!ret.isEmpty())
                    Q_EMIT stream->resourcesFound(ret);
            }
            stream->finish();
        };
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &configFile : availableConfigFiles) {
            auto bk = new KNSBackend(parent, QStringLiteral("plasma"), configFile);
            if (bk->isValid())
                ret += bk;
            else
                delete bk;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](PackageKit::Transaction::Error err, const QString &error) {
        qWarning() << "error fetching updates:" << err << error;
        emit changelogFetched(QString());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, url, stream]() {
                const auto res = stream->resources();
                if (res.count() == 1) {
                    emit openApplicationInternal(res.first());
                } else {
                    rootObject()->setProperty("defaultStartup", true);
                    showPassiveNotification(i18n("Couldn't open %1", url.toDisplayString()));
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[](BackendNotifierModule* module) { return module->hasUpdates(); }
```

#### AUTO 


```{c}
auto pk = new PackageKitResource(packageName, summary, this);
```

#### AUTO 


```{c}
const auto pkgNames = component.packageNames();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QApt::HistoryItem &item : m_history->historyItems()) {
        QDateTime startDateTime = item.startDate();
        QString formattedTime = startDateTime.toString();
        QString category;

        QString date = startDateTime.date().toString();
        if (categoryHash.contains(date)) {
            category = categoryHash.value(date);
        } else {
            category = startDateTime.date().toString(Qt::DefaultLocaleShortDate);
            categoryHash[date] = category;
        }

        QStandardItem *parentItem = 0;

        if (!m_categoryHash.contains(category)) {
            parentItem = new QStandardItem;
            parentItem->setEditable(false);
            parentItem->setText(category);
            parentItem->setData(startDateTime, HistoryProxyModel::HistoryDateRole);

            m_historyModel->appendRow(parentItem);
            m_categoryHash[category] = parentItem;
        } else {
            parentItem = m_categoryHash.value(category);
        }

        foreach (const QString &package, item.installedPackages()) {
            QStandardItem *historyItem = new QStandardItem;
            historyItem->setEditable(false);
            historyItem->setIcon(itemIcon);

            QString action = actionHash.value(InstalledAction);
            QString text = i18nc("@item example: muon installed at 16:00", "%1 %2 at %3",
                                 package, action, formattedTime);
            historyItem->setText(text);
            historyItem->setData(startDateTime, HistoryProxyModel::HistoryDateRole);
            historyItem->setData(QApt::Package::ToInstall, HistoryProxyModel::HistoryActionRole);

            parentItem->appendRow(historyItem);
        }

        foreach (const QString &package, item.upgradedPackages()) {
            QStandardItem *historyItem = new QStandardItem;
            historyItem->setEditable(false);
            historyItem->setIcon(itemIcon);

            QString action = actionHash.value(UpgradedAction);
            QString text = i18nc("@item example: muon installed at 16:00", "%1 %2 at %3",
                                 package, action, formattedTime);
            historyItem->setText(text);
            historyItem->setData(startDateTime, HistoryProxyModel::HistoryDateRole);
            historyItem->setData(QApt::Package::ToUpgrade, HistoryProxyModel::HistoryActionRole);

            parentItem->appendRow(historyItem);
        }

        foreach (const QString &package, item.downgradedPackages()) {
            QStandardItem *historyItem = new QStandardItem;
            historyItem->setEditable(false);
            historyItem->setIcon(itemIcon);

            QString action = actionHash.value(DowngradedAction);
            QString text = i18nc("@item example: muon installed at 16:00", "%1 %2 at %3",
                                 package, action, formattedTime);
            historyItem->setText(text);
            historyItem->setData(startDateTime, HistoryProxyModel::HistoryDateRole);
            historyItem->setData(QApt::Package::ToDowngrade, HistoryProxyModel::HistoryActionRole);

            parentItem->appendRow(historyItem);
        }

        foreach (const QString &package, item.removedPackages()) {
            QStandardItem *historyItem = new QStandardItem;
            historyItem->setEditable(false);
            historyItem->setIcon(itemIcon);

            QString action = actionHash.value(RemovedAction);
            QString text = i18nc("@item example: muon installed at 16:00", "%1 %2 at %3",
                                 package, action, formattedTime);
            historyItem->setText(text);
            historyItem->setData(startDateTime, HistoryProxyModel::HistoryDateRole);
            historyItem->setData(QApt::Package::ToRemove, HistoryProxyModel::HistoryActionRole);

            parentItem->appendRow(historyItem);
        }

        foreach (const QString &package, item.purgedPackages()) {
            QStandardItem *historyItem = new QStandardItem;
            historyItem->setEditable(false);
            historyItem->setIcon(itemIcon);

            QString action = actionHash.value(PurgedAction);
            QString text = i18nc("@item example: muon installed at 16:00", "%1 %2 at %3",
                                 package, action, formattedTime);
            historyItem->setText(text);
            historyItem->setData(startDateTime, HistoryProxyModel::HistoryDateRole);
            historyItem->setData(QApt::Package::ToPurge, HistoryProxyModel::HistoryActionRole);

            parentItem->appendRow(historyItem);
        }
    }
```

#### AUTO 


```{c}
const auto f = [this, appstreamIds, stream] () {
                AbstractResource* pkg = nullptr;

                QStringList allAppStreamIds = appstreamIds;
                {
                    auto it = deprecatedAppstreamIds.constFind(appstreamIds.first());
                    if (it != deprecatedAppstreamIds.constEnd()) {
                        allAppStreamIds << *it;
                    }
                }

                for (auto it = m_packages.packages.constBegin(), itEnd = m_packages.packages.constEnd(); it != itEnd; ++it) {
                    const bool matches = kContains(allAppStreamIds, [&it] (const QString& id) {
                        return it.key().compare(id, Qt::CaseInsensitive) == 0 ||
                              (id.endsWith(QLatin1String(".desktop")) && id.compare(it.key()+QLatin1String(".desktop"), Qt::CaseInsensitive) == 0);
                    });
                    if (matches) {
                        pkg = it.value();
                        break;
                    }
                }
                if (pkg)
                    Q_EMIT stream->resourcesFound({pkg});
                stream->finish();
    //             if (!pkg)
    //                 qCDebug(LIBDISCOVER_BACKEND_LOG) << "could not find" << host << deprecatedHost;
            };
```

#### LAMBDA EXPRESSION 


```{c}
[&entry](const KNSCore::Provider::CategoryMetadata& cat){ return entry.category() == cat.id; }
```

#### AUTO 


```{c}
const auto finder = [this](AbstractResource *resource, AbstractResource *res) {
            return lessThan(resource, res);
        };
```

#### LAMBDA EXPRESSION 


```{c}
[this, fetchingChangedTimer]{
//         Q_ASSERT(isFetching() != fetchingChangedTimer->isActive());
        if (isFetching())
            fetchingChangedTimer->start();
        else
            fetchingChangedTimer->stop();
        
        Q_EMIT fetchingUpdatesProgressChanged();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const KConfigGroup &group, const QByteArrayList &names) {
        if (group.config()->name() == m_settings->config()->name() && group.name() == "Global" && names.contains("UseUnattendedUpdates")) {
            refreshUnattended();
        }
    }
```

#### AUTO 


```{c}
const auto f = [this, appstreamId, stream] () {
                AbstractResource* pkg = nullptr;
                const auto deprecatedHost = deprecatedAppstreamIds.value(appstreamId); //try this as fallback
                for (auto it = m_packages.packages.constBegin(), itEnd = m_packages.packages.constEnd(); it != itEnd; ++it) {
                    if    (it.key().compare(appstreamId, Qt::CaseInsensitive) == 0
                        || it.key().compare(deprecatedHost, Qt::CaseInsensitive) == 0
                        || (appstreamId.endsWith(QLatin1String(".desktop")) && appstreamId.compare(it.key()+QLatin1String(".desktop"), Qt::CaseInsensitive) == 0)) {
                        pkg = it.value();
                        break;
                    }
                }
                if (pkg)
                    Q_EMIT stream->resourcesFound({pkg});
                stream->finish();
    //             if (!pkg)
    //                 qCDebug(LIBDISCOVER_BACKEND_LOG) << "could not find" << host << deprecatedHost;
            };
```

#### AUTO 


```{c}
auto output = process.readAll().trimmed();
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        m_reviews->emitRatingFetched(this, kTransform<QList<AbstractResource *>>(m_resources, [](AbstractResource *r) {
                                         return r;
                                     }));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](AbstractResource* res) { return res->type() != AbstractResource::Technical && !qobject_cast<PackageKitResource*>(res)->extendsItself(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto res : qAsConst(m_resources)) {
            PackageKitResource * app = qobject_cast<PackageKitResource*>(res);
            QString pkgid = m_backend->upgradeablePackageId(app);
            if (!donePkgs.contains(pkgid)) {
                donePkgs.insert(pkgid);
                const auto versions = res->upgradeText();
                const auto idx = versions.indexOf(u'\u009C');
                changes += QStringLiteral("<li>") + res->packageName() + QStringLiteral(": ") + versions.leftRef(idx) + QStringLiteral("</li>\n");
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, stream, searchText]() {
        Q_ASSERT(!isFetching());
        if (!m_isValid) {
            stream->finish();
            return;
        }
        // No need to explicitly launch a search, setting the search term already does that for us
        m_engine->setSearchTerm(searchText);
        m_onePage = false;
        m_responsePending = true;

        connect(stream, &ResultsStream::fetchMore, this, &KNSBackend::fetchMore);
        connect(this, &KNSBackend::receivedResources, stream, &ResultsStream::resourcesFound);
        connect(this, &KNSBackend::searchFinished, stream, &ResultsStream::finish);
        connect(this, &KNSBackend::startingSearch, stream, &ResultsStream::finish);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[categories] (const QList<KNSCore::Provider::CategoryMetadata>& categoryMetadatas){
        for (const KNSCore::Provider::CategoryMetadata& category : categoryMetadatas) {
            for (Category* cat : qAsConst(categories)) {
                if (cat->orFilters().count() > 0 && cat->orFilters().constFirst().second == category.name) {
                    cat->setName(category.displayName);
                    break;
                }
            }
        }
    }
```

#### AUTO 


```{c}
auto future = QtConcurrent::run(&m_threadPool, [this, jobs] () {
        for (auto job : jobs) {
            connect(this, &SnapBackend::shuttingDown, job, &T::cancel);
            job->runSync();
        }
    });
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        m_item->setTitle(i18n("Restart to apply installed updates"));
        m_item->setToolTipTitle(i18n("Click to restart the device"));
        m_item->setIconByName(QStringLiteral("view-refresh"));
    }
```

#### AUTO 


```{c}
const auto finder = [this, resource](AbstractResource* res){ return lessThan(resource, res); };
```

#### AUTO 


```{c}
auto updatesAction = menu->addAction(QIcon::fromTheme(QStringLiteral("system-software-update")), i18n("See Updates..."));
```

#### LAMBDA EXPRESSION 


```{c}
[](const auto &source) {
                                         return kTransform<QList<AbstractResource *>>(source->m_resources.values());
                                     }
```

#### LAMBDA EXPRESSION 


```{c}
[this, url]() {
            AbstractResourcesBackend::Filters f;
            f.resourceUrl = url;
            auto stream = new StoredResultsStream({ResourcesModel::global()->search(f)});
            connect(stream, &StoredResultsStream::finished, this, [this, url, stream]() {
                const auto res = stream->resources();
                if (res.count() == 1) {
                    emit openApplicationInternal(res.first());
                } else {
                    rootObject()->setProperty("defaultStartup", true);
                    Q_EMIT openErrorPage(i18n("Couldn't open %1", url.toDisplayString()));
                }
            });
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const QVector<AbstractResource*>& resources){
        for (auto res: qAsConst(m_resources)) {
            if (resources.contains(res))
                res->setState(AbstractResource::Installed);
            else
                res->setState(AbstractResource::None);
        }
    }
```

#### AUTO 


```{c}
const auto releases = dc.releases();
```

#### LAMBDA EXPRESSION 


```{c}
[](AbstractResource* a) { return a->name(); }
```

#### AUTO 


```{c}
auto buff = g_bytes_get_data(data, &len);
```

#### AUTO 


```{c}
auto cats = kVectorToSet(m_filters.category ? m_filters.category->subCategories() : CategoryModel::global()->rootCategories());
```

#### AUTO 


```{c}
auto refreshAction = menu->addAction(QIcon::fromTheme(QStringLiteral("view-refresh")), i18n("Refresh�"));
```

#### AUTO 


```{c}
auto osrelease = AppStreamIntegration::global()->osRelease();
```

#### AUTO 


```{c}
const auto res = getResources(m_appBackend->search(f));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVariant &act : theActions) {
        DiscoverAction *action = qobject_cast<DiscoverAction *>(act.value<QObject *>());
        if (action->objectName() == id) {
            action->setEnabled(false);
            action->setVisible(false);
        }
    }
```

#### AUTO 


```{c}
const auto resources2 = fetchResources(m_appBackend->findResourceByPackageName(QUrl(QStringLiteral("dummy://Dummy.1"))));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& potentialSubCat: qAsConst(categories)) {
            if(potentialSubCat->name().startsWith(catName)) {
                cat->addSubcategory(potentialSubCat);
                topCategories.removeOne(potentialSubCat);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractBackendUpdater* upd : m_updaters) {
            if (upd->hasUpdates())
                QMetaObject::invokeMethod(upd, "start", Qt::QueuedConnection);
        }
```

#### AUTO 


```{c}
auto resource = new FlatpakResource(asComponent, this);
```

#### AUTO 


```{c}
auto res = resources.first();
```

#### LAMBDA EXPRESSION 


```{c}
[updateAction, this](){
        updateAction->setEnabled(!isFetching());
    }
```

#### AUTO 


```{c}
auto stream = new PKResultsStream(this, QStringLiteral("PackageKitStream-search"));
```

#### AUTO 


```{c}
auto refresh = [&notifier, &item](){
        item.setStatus(sniStatus(notifier.state()));
        item.setIconByName(notifier.iconName());
        item.setToolTipSubTitle(notifier.message());
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractResource *res : packages) {
        if (SystemUpgrade *upgrade = dynamic_cast<SystemUpgrade *>(res)) {
            packageIds = involvedPackages(upgrade->resources());
            continue;
        }

        PackageKitResource *app = qobject_cast<PackageKitResource *>(res);
        const QSet<QString> ids = m_backend->upgradeablePackageId(app);
        if (ids.isEmpty()) {
            qWarning() << "no upgradeablePackageId for" << app;
            continue;
        }

        packageIds.unite(ids);
    }
```

#### AUTO 


```{c}
auto args = execParser.resultingArguments();
```

#### LAMBDA EXPRESSION 


```{c}
[this, url]() {
            AbstractResourcesBackend::Filters f;
            f.resourceUrl = url;
            auto stream = new StoredResultsStream({ResourcesModel::global()->search(f)});
            connect(stream, &StoredResultsStream::finishedResources, this, [this, url](const QVector<AbstractResource*> &res) {
                if (res.count() >= 1) {
                    emit openApplicationInternal(res.first());
                } else {
                    setRootObjectProperty("defaultStartup", true);
                    Q_EMIT openErrorPage(i18n("Couldn't open %1", url.toDisplayString()));
                }
            });
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Transaction* t : m_transactions) {
        PKTransaction* pkt = qobject_cast<PKTransaction*>(t);
        if (pkt->resource() == app) {
            if (pkt->transaction()->allowCancel()) {
                pkt->transaction()->cancel();
                int count = m_transactions.removeAll(t);
                Q_ASSERT(count==1);
                Q_UNUSED(count)
                //TransactionModel::global()->cancelTransaction(t);
            } else {
                kWarning() << "trying to cancel a non-cancellable transaction: " << app->name();
            }
            break;
        }
    }
```

#### AUTO 


```{c}
auto role = m_sortRole;
```

#### LAMBDA EXPRESSION 


```{c}
[this, localfile]() {
            AbstractResourcesBackend::Filters f;
            f.resourceUrl = localfile;
            auto stream = new StoredResultsStream({ResourcesModel::global()->search(f)});
            connect(stream, &StoredResultsStream::finished, this, [this, localfile, stream]() {
                const auto res = stream->resources();
                if (res.count() == 1) {
                    emit openApplicationInternal(res.first());
                } else {
                    QMimeDatabase db;
                    auto mime = db.mimeTypeForUrl(localfile);
                    auto fIsFlatpakBackend = [](AbstractResourcesBackend* backend) { return backend->metaObject()->className() == QByteArray("FlatpakBackend"); };
                    if (mime.name().startsWith(QLatin1String("application/vnd.flatpak")) && !kContains(ResourcesModel::global()->backends(), fIsFlatpakBackend)) {
                        openApplication(QUrl(QLatin1String("appstream://org.kde.discover.flatpak")));
                        showPassiveNotification(i18n("Cannot interact with flatpak resources without the flatpak backend %1. Please install it first.", localfile.toDisplayString()));
                    } else {
                        setRootObjectProperty("defaultStartup", true);
                        showPassiveNotification(i18n("Couldn't open %1", localfile.toDisplayString()));
                    }
                }
            });
        }
```

#### AUTO 


```{c}
auto m = SourcesModel::global();
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QByteArray& arr) { return roleNames().key(arr, -1); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &pkgStr : transaction->addons().addonsToRemove()) {
        QApt::Package *addon = m_backend->package(pkgStr);

        if (addon)
            excluded.append(addon);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](){
            setApplication(nullptr);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Category *cat : m_rootCategories) {
        Category *ret = recFindCategory(cat, name);
        if (ret)
            return ret;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &role: roles) {
        if (!roles.contains(role))
            return false;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, localfile]() {
            AbstractResourcesBackend::Filters f;
            f.resourceUrl = localfile;
            auto stream = new StoredResultsStream({ResourcesModel::global()->search(f)});
            connect(stream, &StoredResultsStream::finishedResources, this, [this, localfile](const QVector<AbstractResource *> &res) {
                if (res.count() == 1) {
                    emit openApplicationInternal(res.first());
                } else {
                    QMimeDatabase db;
                    auto mime = db.mimeTypeForUrl(localfile);
                    auto fIsFlatpakBackend = [](AbstractResourcesBackend *backend) {
                        return backend->metaObject()->className() == QByteArray("FlatpakBackend");
                    };
                    if (mime.name().startsWith(QLatin1String("application/vnd.flatpak"))
                        && !kContains(ResourcesModel::global()->backends(), fIsFlatpakBackend)) {
                        openApplication(QUrl(QStringLiteral("appstream://org.kde.discover.flatpak")));
                        showPassiveNotification(i18n("Cannot interact with flatpak resources without the flatpak backend %1. Please install it first.",
                                                     localfile.toDisplayString()));
                    } else {
                        openMode(QStringLiteral("Browsing"));
                        showPassiveNotification(i18n("Could not open %1", localfile.toDisplayString()));
                    }
                }
            });
        }
```

#### AUTO 


```{c}
const auto appsToRemove = resourcesByPackageNames<QVector<AbstractResource *>>(addons.addonsToRemove());
```

#### LAMBDA EXPRESSION 


```{c}
[func, process, varname](int code) {
        if (code != 0)
            return;

        QRegularExpression rx(QLatin1Char('^') + varname + QStringLiteral(" \"(.*?)\"$"));
        QTextStream stream(process);
        QString line;
        while (stream.readLineInto(&line)) {
            const auto match = rx.match(line);
            if (match.hasMatch()) {
                func(match.capturedRef(1));
                return;
            }
        }
        func({});
    }
```

#### AUTO 


```{c}
const auto ids = group.readEntry<QStringList>("Sources", QStringList());
```

#### LAMBDA EXPRESSION 


```{c}
[this](){
        // If KNS tells us we should reset the view, what that means here is to remove
        // references to all the resources we've already told the agregator model about
        // from the model, as they will be added again...
        foreach(AbstractResource* res, m_resourcesByName.values()) {
            resourceRemoved(res);
            res->deleteLater();
        }
        m_resourcesByName.clear();
    }
```

#### AUTO 


```{c}
auto pkgList
```

#### RANGE FOR STATEMENT 


```{c}
for(Category* cat : m_categories) {
        ret.append(QVariant::fromValue<QObject*>(cat));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto installation : qAsConst(m_installations)) {
        // Load applications from appstream metadata
        if (!loadAppsFromAppstreamData(installation)) {
            qWarning() << "Failed to load packages from appstream data from installation" << installation;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, url](const QVector<AbstractResource *> &res) {
                if (res.count() >= 1) {
                    Q_EMIT openApplicationInternal(res.first());
                } else if (url.scheme() == QLatin1String("snap")) {
                    openApplication(QUrl(QStringLiteral("appstream://org.kde.discover.snap")));
                    showPassiveNotification(i18n("Please make sure Snap support is installed"));
                } else {
                    const QString errorText = i18n("Could not open %1 because it "
                    "was not found in any available software repositories.",
                    url.toDisplayString());
                    const QString errorExplanation = i18n("Please report this "
                    "issue to the packagers of your distribution.");
                    QString buttonIcon = QStringLiteral("tools-report-bug");
                    QString buttonText = i18n("Report This Issue");
                    QString buttonUrl = KOSRelease().bugReportUrl();
                    Q_EMIT openErrorPage(errorText, errorExplanation, buttonText, buttonIcon, buttonUrl);
                }
            }
```

#### AUTO 


```{c}
const auto res = stream->resources();
```

#### AUTO 


```{c}
const auto resources = kTransform<QVector<AbstractResource*>>(filtered, [this](const KNSCore::EntryInternal& entry){ return resourceForEntry(entry); });
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractResourcesBackend *b : backends) {
            addResourcesBackend(b);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[] (QProcess::ProcessError error) {
        qWarning() << "Error running plasma-discover-update" << error;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](PackageKit::Transaction::Exit status) {
        if (status != PackageKit::Transaction::Exit::ExitSuccess) {
            qWarning() << "transaction failed" << sender() << status;
            cancel();
            return;
        }

        if (!m_proceedFunctions.isEmpty()) {
            processProceedFunction();
        } else {
            start();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto res : qAsConst(m_resources)) {
            connect(res, &AbstractResource::sizeChanged, this, [this] {
                Q_EMIT m_backend->resourcesChanged(this, {"size", "homepage", "license"});
            });
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, url](const QVector<AbstractResource *> &res) {
                if (res.count() >= 1) {
                    Q_EMIT openApplicationInternal(res.first());
                } else if (url.scheme() == QLatin1String("snap")) {
                    openApplication(QUrl(QStringLiteral("appstream://org.kde.discover.snap")));
                    showPassiveNotification(i18n("Please make sure Snap support is installed"));
                } else {
                    Q_EMIT openErrorPage(i18n("Could not open %1", url.toDisplayString()));
                }
            }
```

#### AUTO 


```{c}
auto source = findSource(installation, origin);
```

#### AUTO 


```{c}
auto it = m_initial.constBegin();
```

#### AUTO 


```{c}
auto installation = preferredInstallation();
```

#### AUTO 


```{c}
auto stream = new ResultsStream(QLatin1String("FlatpakStream-searchrepo-") + runtimeUrl.toString());
```

#### AUTO 


```{c}
auto trans = PackageKit::Daemon::dependsOn(ids);
```

#### LAMBDA EXPRESSION 


```{c}
[this, resource, fw, runtimeUrl]() {
            const auto metadata = fw->result();
            // Even when we failed to fetch information about runtime we still want to show the application
            if (metadata.isEmpty()) {
                Q_EMIT onFetchMetadataFinished(resource, metadata);
            } else {
                updateAppMetadata(resource, metadata);

                auto runtime = getRuntimeForApp(resource);
                if (!runtime || (runtime && !runtime->isInstalled())) {
                    auto stream = new ResultsStream(QLatin1String("FlatpakStream-searchrepo-") + runtimeUrl.toString());
                    connect(stream, &ResultsStream::resourcesFound, this, [this, resource](const QVector<AbstractResource *> &resources) {
                        for (auto res : resources) {
                            installApplication(res);
                        }
                        addResource(resource);
                    });

                    auto fetchRemoteResource = new FlatpakFetchRemoteResourceJob(runtimeUrl, stream, this);
                    fetchRemoteResource->start();
                    return;
                } else {
                    addResource(resource);
                }
            }
            fw->deleteLater();
        }
```

#### AUTO 


```{c}
auto f = [menu, this]() {
        m_item->setTitle(i18n("Restart to apply installed updates"));
        m_item->setToolTipTitle(i18n("Click to restart the device"));
        m_item->setIconByName(QStringLiteral("view-refresh"));
        auto refreshAction = menu->addAction(QIcon::fromTheme(QStringLiteral("view-refresh")), i18n("Restart..."));
        connect(refreshAction, &QAction::triggered, &m_notifier, &DiscoverNotifier::recheckSystemUpdateNeeded);
    };
```

#### AUTO 


```{c}
const auto toResolve = kFilter<QVector<AbstractResource *>>(res, needsResolveFilter);
```

#### LAMBDA EXPRESSION 


```{c}
[this, localfile](const QVector<AbstractResource*> &res) {
                if (res.count() == 1) {
                    emit openApplicationInternal(res.first());
                } else {
                    QMimeDatabase db;
                    auto mime = db.mimeTypeForUrl(localfile);
                    auto fIsFlatpakBackend = [](AbstractResourcesBackend* backend) { return backend->metaObject()->className() == QByteArray("FlatpakBackend"); };
                    if (mime.name().startsWith(QLatin1String("application/vnd.flatpak")) && !kContains(ResourcesModel::global()->backends(), fIsFlatpakBackend)) {
                        openApplication(QUrl(QStringLiteral("appstream://org.kde.discover.flatpak")));
                        showPassiveNotification(i18n("Cannot interact with flatpak resources without the flatpak backend %1. Please install it first.", localfile.toDisplayString()));
                    } else {
                        openMode(QStringLiteral("Browsing"));
                        showPassiveNotification(i18n("Could not open %1", localfile.toDisplayString()));
                    }
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[action]() {
        action->trigger();
    }
```

#### AUTO 


```{c}
auto start = [this, stream, searchText]() {
        Q_ASSERT(!isFetching());
        if (!m_isValid) {
            stream->finish();
            return;
        }
        // No need to explicitly launch a search, setting the search term already does that for us
        m_engine->setSearchTerm(searchText);
        m_onePage = false;
        m_responsePending = true;

        connect(this, &KNSBackend::receivedResources, stream, &ResultsStream::resourcesFound);
        connect(this, &KNSBackend::searchFinished, stream, &ResultsStream::finish);
        connect(this, &KNSBackend::startingSearch, stream, &ResultsStream::finish);
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &source : m_flatpakSources) {
        if (source->m_pool) {
            const auto comps = source->m_pool->componentsById(name) + source->m_pool->componentsById(nameWithDesktop);
            resources << kTransform<QVector<AbstractResource *>>(comps, [this, source](const auto &comp) {
                return resourceForComponent(comp, source);
            });
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &tid : tids) {
        if (m_transactions.contains(tid))
            continue;

        auto t = new PackageKit::Transaction(QDBusObjectPath(tid));

        connect(t, &PackageKit::Transaction::roleChanged, this, [this, t]() {
            if (t->role() == PackageKit::Transaction::RoleGetUpdates) {
                setupGetUpdatesTransaction(t);
            }
        });
        connect(t, &PackageKit::Transaction::requireRestart, this, &PackageKitNotifier::onRequireRestart);
        connect(t, &PackageKit::Transaction::finished, this, [this, t]() {
            auto restart = t->property("requireRestart");
            if (!restart.isNull()) {
                auto restartEvent = PackageKit::Transaction::Restart(restart.toInt());
                if (restartEvent >= PackageKit::Transaction::RestartSession) {
                    nowNeedsReboot();
                }
            }
            m_transactions.remove(t->tid().path());
            t->deleteLater();
        });
        m_transactions.insert(tid, t);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[]() {
            QCoreApplication::instance()->exit(1);
        }
```

#### AUTO 


```{c}
auto it = m_sources->item(i);
```

#### AUTO 


```{c}
const auto trans = transactions();
```

#### LAMBDA EXPRESSION 


```{c}
[stream, this, job, filter]() {
        if (job->error()) {
            qDebug() << "error:" << job->error() << job->errorString();
            stream->finish();
            return;
        }

        QVector<AbstractResource*> ret;
        QVector<SnapResource*> resources;
        ret.reserve(job->snapCount());
        resources.reserve(job->snapCount());
        for (int i=0, c=job->snapCount(); i<c; ++i) {
            QSharedPointer<QSnapdSnap> snap(job->snap(i));

            if (!filter(snap))
                continue;

            const auto snapname = snap->name();
            SnapResource* res = m_resources.value(snapname);
            if (!res) {
                res = new SnapResource(snap, AbstractResource::None, this);
                Q_ASSERT(res->packageName() == snapname);
                resources += res;
            } else {
                res->setSnap(snap);
            }
            ret += res;
        }

        foreach(SnapResource* res, resources)
            m_resources[res->packageName()] = res;

        if (!ret.isEmpty())
            Q_EMIT stream->resourcesFound(ret);
        stream->finish();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QVariant& act: theActions) {
        DiscoverAction* action = qobject_cast<DiscoverAction*>(act.value<QObject*>());
        if (action->objectName() == id) {
            action->setEnabled(false);
            action->setVisible(false);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        if (m_initializingBackends == 0)
            Q_EMIT allInitialized();
    }
```

#### AUTO 


```{c}
auto actualCategory = new Category(displayName, QStringLiteral("plasma"), filters, backendName, {}, QUrl(), true);
```

#### AUTO 


```{c}
auto action = new OneTimeAction(
        [this, url]() {
            AbstractResourcesBackend::Filters f;
            f.resourceUrl = url;
            auto stream = new StoredResultsStream({ResourcesModel::global()->search(f)});
            connect(stream, &StoredResultsStream::finished, this, [this, url, stream]() {
                const auto res = stream->resources();
                if (res.count() >= 1) {
                    emit openApplicationInternal(res.first());
                } else {
                    setRootObjectProperty("defaultStartup", true);
                    showPassiveNotification(i18n("Couldn't open %1", url.toDisplayString()));
                }
            });
        }
        , this);
```

#### AUTO 


```{c}
auto refSource = QSharedPointer<FlatpakSource>::create(this, preferredInstallation());
```

#### RANGE FOR STATEMENT 


```{c}
for (auto r : res)
        connect(r, &QObject::destroyed, this, &AggregatedResultsStream::resourceDestruction);
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractResource * res : m_toUpgrade) {
        PackageKitResource * app = qobject_cast<PackageKitResource*>(res);
        QString pkgid = m_backend->upgradeablePackageId(app);
        if (!donePkgs.contains(pkgid)) {
            donePkgs.insert(pkgid);
            ret += app->size();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[packageDependencies](PackageKit::Transaction::Info info, const QString &packageID, const QString &summary) {
                (*packageDependencies)
                    .append(QJsonObject{{QStringLiteral("packageName"), PackageKit::Daemon::packageName(packageID)},
                                        {QStringLiteral("packageInfo"), PackageKitMessages::info(info)},
                                        {QStringLiteral("packageDescription"), summary}});
            }
```

#### AUTO 


```{c}
auto updateChecker = new OneTimeAction(
                [this] {
                    //No need to check for updates if there's no resources
                    if (m_resourcesByName.isEmpty()) {
                        return;
                    }

                    Q_EMIT startingSearch();
                    m_onePage = true;
                    m_responsePending = true;
                    m_engine->checkForUpdates();
                },
                this);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto stream: streams) {
        connect(stream, &ResultsStream::resourcesFound, this, &ResultsStream::resourcesFound);
        connect(stream, &QObject::destroyed, this, &AggregatedResultsStream::destruction);
        m_streams << stream;
    }
```

#### AUTO 


```{c}
const auto actions = this->actions();
```

#### LAMBDA EXPRESSION 


```{c}
[this, trans](PackageKit::Transaction::Exit status) {
        auto deps = trans->property("dependencies").toUInt();
        if (deps != m_dependenciesCount) {
            m_dependenciesCount = deps;
            Q_EMIT sizeChanged();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        if (m_responsePending) {
            setResponsePending(false);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](PackageKit::Transaction::Error err, const QString & error) {
        qWarning() << "error fetching updates:" << err << error;
        emit changelogFetched(QString());
    }
```

#### AUTO 


```{c}
const auto appsBackend = ResourcesModel::global()->currentApplicationBackend();
```

#### AUTO 


```{c}
const auto name = applicationSourceName();
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto& v : input) {
        if (op(v))
            ret += v;
    }
```

#### AUTO 


```{c}
const auto destRow = row + delta;
```

#### LAMBDA EXPRESSION 


```{c}
[]() {
            const int progress = TransactionModel::global()->progress();
            static int lastProgress = -1;
            Q_ASSERT(progress >= lastProgress || (TransactionModel::global()->rowCount() == 0 && progress == 0));
            lastProgress = progress;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            bool found = DiscoverBackendsFactory::hasRequestedBackends();
            const auto backends = ResourcesModel::global()->backends();
            for (auto b : backends)
                found |= b->hasApplications();

            if (!found)
                Q_EMIT openErrorPage(
                    i18n("Discover currently cannot be used to install any apps "
                         "because none of its app backends are available. Please "
                         "report this issue to the packagers of your distribution."));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto r : apps) {
        PackageKitResource *res = qobject_cast<PackageKitResource *>(r);
        m_pkgnames.unite(kToSet(res->allPackageNames()));
    }
```

#### AUTO 


```{c}
const auto files = dir.entryList(QDir::Files);
```

#### AUTO 


```{c}
const auto resources = fetchResources(m_appBackend->findResourceByPackageName(QUrl(QStringLiteral("dummy://Dummy.1"))));
```

#### AUTO 


```{c}
const auto mime = db.mimeTypeForUrl(file);
```

#### AUTO 


```{c}
auto f = [this, stream, filter] {
            QVector<AbstractResource *> resources;
            for (auto installation : m_installations) {
                g_autoptr(GError) localError = nullptr;
                g_autoptr(GPtrArray) refs = flatpak_installation_list_installed_refs(installation, m_cancellable, &localError);
                if (!refs) {
                    qWarning() << "Failed to get list of installed refs for listing installed:" << localError->message;
                    continue;
                }

                resources.reserve(resources.size() + refs->len);
                for (uint i = 0; i < refs->len; i++) {
                    FlatpakInstalledRef *ref = FLATPAK_INSTALLED_REF(g_ptr_array_index(refs, i));
                    QString name = QString::fromUtf8(flatpak_installed_ref_get_appdata_name(ref));
                    if (name.endsWith(QLatin1String(".Debug")) || name.endsWith(QLatin1String(".Locale")) || name.endsWith(QLatin1String(".BaseApp"))
                        || name.endsWith(QLatin1String(".Docs")))
                        continue;

                    auto resource = getAppForInstalledRef(installation, ref);
                    if (!filter.search.isEmpty() && !resource->name().contains(filter.search, Qt::CaseInsensitive))
                        continue;

                    if (resource->resourceType() == FlatpakResource::Runtime) {
                        resources.prepend(resource);
                    } else {
                        resources.append(resource);
                    }
                }
            }
            if (!resources.isEmpty())
                Q_EMIT stream->resourcesFound(resources);
            stream->finish();
        };
```

#### LAMBDA EXPRESSION 


```{c}
[](AbstractResource *res) {
        return res->url();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, replyGet] {
            QScopedPointer<QNetworkReply, QScopedPointerDeleteLater> replyPtr(replyGet);
            const QUrl originalUrl = replyGet->request().url();
            if (replyGet->error() != QNetworkReply::NoError) {
                qWarning() << "couldn't download" << originalUrl << replyGet->errorString();
                Q_EMIT jobFinished(false, nullptr);
                return;
            }

            const QUrl fileUrl =
                QUrl::fromLocalFile(QStandardPaths::writableLocation(QStandardPaths::TempLocation) + QLatin1Char('/') + originalUrl.fileName());
            auto replyPut = put(QNetworkRequest(fileUrl), replyGet->readAll());
            connect(replyPut, &QNetworkReply::finished, this, [this, originalUrl, fileUrl, replyPut]() {
                QScopedPointer<QNetworkReply, QScopedPointerDeleteLater> replyPtr(replyPut);
                if (replyPut->error() != QNetworkReply::NoError) {
                    qWarning() << "couldn't save" << originalUrl << replyPut->errorString();
                    Q_EMIT jobFinished(false, nullptr);
                    return;
                }
                if (!fileUrl.isLocalFile()) {
                    Q_EMIT jobFinished(false, nullptr);
                    return;
                }

                FlatpakResource *resource = nullptr;
                if (fileUrl.path().endsWith(QLatin1String(".flatpak"))) {
                    resource = m_backend->addAppFromFlatpakBundle(fileUrl);
                } else if (fileUrl.path().endsWith(QLatin1String(".flatpakref"))) {
                    resource = m_backend->addAppFromFlatpakRef(fileUrl);
                } else if (fileUrl.path().endsWith(QLatin1String(".flatpakrepo"))) {
                    resource = m_backend->addSourceFromFlatpakRepo(fileUrl);
                }

                if (resource) {
                    resource->setResourceFile(originalUrl);
                    Q_EMIT jobFinished(true, resource);
                } else {
                    qWarning() << "couldn't create resource from" << fileUrl.toLocalFile();
                    Q_EMIT jobFinished(false, nullptr);
                }
            });
        }
```

#### AUTO 


```{c}
auto cats = (m_filters.category ? m_filters.category->subCategories() : CategoryModel::global()->rootCategories()).toList().toSet();
```

#### AUTO 


```{c}
auto bk = qobject_cast<AbstractSourcesBackend*>(m->index(0, 0).data(SourcesModel::SourcesBackend).value<QObject*>());
```

#### AUTO 


```{c}
auto bk = new KNSBackend(parent, QStringLiteral("plasma"), configFile);
```

#### LAMBDA EXPRESSION 


```{c}
[mainWindow](const QStringList &arguments, const QString & /*workingDirectory*/) {
            if (!mainWindow->rootObject())
                QCoreApplication::instance()->quit();

            auto window = qobject_cast<QWindow *>(mainWindow->rootObject());
            if (window && QX11Info::isPlatformX11()) {
                KStartupInfo::setNewStartupId(window, QX11Info::nextStartupId());
            }
            window->raise();

            if (arguments.isEmpty())
                return;
            QScopedPointer<QCommandLineParser> parser(createParser());
            parser->parse(arguments);
            processArgs(parser.data(), mainWindow);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Appstream::Screenshot &s : comp.screenshots()) {
        for (const Appstream::Image &i : s.images()) {
            if (i.kind() == kind) {
                ret = i.url();
            }
        }
        if (s.isDefault() && !ret.isEmpty())
            break;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, t](){
            auto restart = t->property("requireRestart");
            if (!restart.isNull()) {
                auto restartEvent = PackageKit::Transaction::Restart(restart.toInt());
                if (restartEvent >= PackageKit::Transaction::RestartSession) {
                    nowNeedsReboot();
                }
            }
            m_transactions.remove(t->tid().path());
            t->deleteLater();
        }
```

#### AUTO 


```{c}
static const auto needsResolveFilter = [](AbstractResource *res) {
    return res->state() == AbstractResource::Broken;
};
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &arch : archList) {
        QStandardItem *archItem = new QStandardItem;
        archItem->setEditable(false);
        archItem->setText(arch);
        archItem->setData(arch, Qt::UserRole+1);
        appendRow(archItem);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(BackendNotifierModule* module : m_backends)
        ret += QString::fromLatin1(module->metaObject()->className());
```

#### AUTO 


```{c}
auto it = sortedResources.constBegin(), itEnd = sortedResources.constEnd();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto updater : toCancel) {
            updater->cancel();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](){ transactionChanged(StatusTextRole); }
```

#### LAMBDA EXPRESSION 


```{c}
[this, request]() {
        if (request->error()) {
            qWarning() << "error" << request->error() << ": " << request->errorString();
            return;
        }
        Q_ASSERT(request->snapCount() == 1);
        setSnap(QSharedPointer<QSnapdSnap>(request->snap(0)));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        if (!m_appToBeOpened.isEmpty())
            Q_EMIT unableToFind(m_appToBeOpened);
        disconnect(ResourcesModel::global(), &ResourcesModel::fetchingChanged, this, &DiscoverMainWindow::triggerOpenApplication);
        disconnect(ResourcesModel::global(), &ResourcesModel::allInitialized, this, &DiscoverMainWindow::triggerOpenApplication);
    }
```

#### AUTO 


```{c}
const auto objs = m_engine->rootObjects();
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractResourcesBackend *backend : qAsConst(m_backends)) {
        ret |= backend->hasSecurityUpdates();
    }
```

#### AUTO 


```{c}
auto app
```

#### AUTO 


```{c}
const auto &uri
```

#### LAMBDA EXPRESSION 


```{c}
[](AbstractResource *res) {
        return !static_cast<PackageKitResource *>(res)->extendsItself();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, replyGet] {
            const QUrl originalUrl = replyGet->request().url();
            if (replyGet->error() != QNetworkReply::NoError) {
                qWarning() << "couldn't download" << originalUrl << replyGet->errorString();
                Q_EMIT jobFinished(false, nullptr);
                return;
            }

            const QUrl fileUrl = QUrl::fromLocalFile(QStandardPaths::writableLocation(QStandardPaths::TempLocation) + QLatin1Char('/') + originalUrl.fileName());
            auto replyPut = put(QNetworkRequest(fileUrl), replyGet->readAll());
            connect(replyPut, &QNetworkReply::finished, this, [this, originalUrl, fileUrl, replyPut]() {
                if (replyPut->error() != QNetworkReply::NoError) {
                    qWarning() << "couldn't save" << originalUrl << replyPut->errorString();
                    Q_EMIT jobFinished(false, nullptr);
                    return;
                }
                if (!fileUrl.isLocalFile()) {
                    Q_EMIT jobFinished(false, nullptr);
                    return;
                }

                FlatpakResource *resource = nullptr;
                if (fileUrl.path().endsWith(QLatin1String(".flatpak"))) {
                    resource = m_backend->addAppFromFlatpakBundle(fileUrl);
                } else if (fileUrl.path().endsWith(QLatin1String(".flatpakref"))) {
                    resource = m_backend->addAppFromFlatpakRef(fileUrl);
                } else if (fileUrl.path().endsWith(QLatin1String(".flatpakrepo"))) {
                    resource = m_backend->addSourceFromFlatpakRepo(fileUrl);
                }

                if (resource) {
                    resource->setResourceFile(originalUrl);
                    Q_EMIT jobFinished(true, resource);
                } else {
                    qWarning() << "couldn't create resource from" << fileUrl.toLocalFile();
                    Q_EMIT jobFinished(false, nullptr);
                }
            }
            );
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, appstreamIds, stream]() {
                AbstractResource *pkg = nullptr;

                QStringList allAppStreamIds = appstreamIds;
                {
                    auto it = deprecatedAppstreamIds.constFind(appstreamIds.first());
                    if (it != deprecatedAppstreamIds.constEnd()) {
                        allAppStreamIds << *it;
                    }
                }

                for (auto it = m_packages.packages.constBegin(), itEnd = m_packages.packages.constEnd(); it != itEnd; ++it) {
                    const bool matches = kContains(allAppStreamIds, [&it](const QString &id) {
                        static const QLatin1String desktopPostfix(".desktop");
                        return it.key().compare(id, Qt::CaseInsensitive) == 0 ||
                            // doing (id == id.key()+".desktop") without allocating
                            (id.size() == (desktopPostfix.size() + it.key().size()) && id.endsWith(desktopPostfix)
                             && id.startsWith(it.key(), Qt::CaseInsensitive)) ||
                            (it.key().size() == (desktopPostfix.size() + id.size()) && it.key().endsWith(desktopPostfix)
                             && it.key().startsWith(id, Qt::CaseInsensitive));
                    });
                    if (matches) {
                        pkg = it.value();
                        break;
                    }
                }
                if (pkg)
                    stream->setResources({pkg});
                stream->finish();
                //         if (!pkg)
                //             qCDebug(LIBDISCOVER_BACKEND_LOG) << "could not find" << host << deprecatedHost;
            }
```

#### AUTO 


```{c}
auto futureWatcher = new QFutureWatcher<FlatpakRemoteRef*>(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QVector<AbstractResource *> &resources) {
        for (auto res : resources)
            if (res->state() == AbstractResource::Upgradeable)
                m_upgradeable.insert(res);
    }
```

#### AUTO 


```{c}
auto t = m_backend->installApplication(res);
```

#### RANGE FOR STATEMENT 


```{c}
for(QApt::Package* it : pkgList) {
            AbstractResource* res = m_appBackend->resourceByPackageName(it->name());
            if(!res) //If we couldn't find it by its name, try with
                res = m_appBackend->resourceByPackageName(QString("%1:%2").arg(it->name()).arg(it->architecture()));
            Q_ASSERT(res);
            m_toUpdate += res;
        }
```

#### AUTO 


```{c}
auto a = new OneTimeAction([this] { fetchUpdateDetails(); }, this);
```

#### AUTO 


```{c}
const auto updaters = kFilter<QVector<AbstractBackendUpdater *>>(m_updaters, [](AbstractBackendUpdater *u) {
            return u->hasUpdates();
        });
```

#### AUTO 


```{c}
auto source
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& pkgid: m_updatesPackageId) {
        if (PackageKit::Daemon::packageName(pkgid) == name)
            return pkgid;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QVector<AbstractResource*>& resources) {
        m_resources += resources;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, appstreamIds, stream] () {
                AbstractResource* pkg = nullptr;

                const QStringList allAppStreamIds = appstreamIds + deprecatedAppstreamIds.values(appstreamIds.first());
                for (auto it = m_packages.packages.constBegin(), itEnd = m_packages.packages.constEnd(); it != itEnd; ++it) {
                    const bool matches = kContains(allAppStreamIds, [&it] (const QString& id) {
                        return it.key().compare(id, Qt::CaseInsensitive) == 0 ||
                              (id.endsWith(QLatin1String(".desktop")) && id.compare(it.key()+QLatin1String(".desktop"), Qt::CaseInsensitive) == 0);
                    });
                    if (matches) {
                        pkg = it.value();
                        break;
                    }
                }
                if (pkg)
                    Q_EMIT stream->resourcesFound({pkg});
                stream->finish();
    //             if (!pkg)
    //                 qCDebug(LIBDISCOVER_BACKEND_LOG) << "could not find" << host << deprecatedHost;
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this, stream] {
            auto fw = new QFutureWatcher<QMap<FlatpakInstallation *, QVector<FlatpakInstalledRef *>>>(this);
            connect(fw, &QFutureWatcher<QByteArray>::finished, this, [this, fw, stream]() {
                if (g_cancellable_is_cancelled(m_cancellable)) {
                    stream->finish();
                    fw->deleteLater();
                    return;
                }

                const auto refs = fw->result();
                QVector<AbstractResource *> resources;
                for (auto it = refs.constBegin(), itEnd = refs.constEnd(); it != itEnd; ++it) {
                    resources.reserve(resources.size() + it->size());
                    for (auto ref : qAsConst(it.value())) {
                        auto resource = getAppForInstalledRef(it.key(), ref);
                        g_object_unref(ref);
                        resource->setState(AbstractResource::Upgradeable);
                        updateAppSize(resource);
                        if (resource->resourceType() == FlatpakResource::Runtime) {
                            resources.prepend(resource);
                        } else {
                            resources.append(resource);
                        }
                    }
                }

                if (!resources.isEmpty())
                    Q_EMIT stream->resourcesFound(resources);
                stream->finish();
                fw->deleteLater();
            });

            QVector<FlatpakInstallation *> installations = m_installations;
            auto cancellable = m_cancellable;
            fw->setFuture(QtConcurrent::run(&m_threadPool, [installations, cancellable] {
                QMap<FlatpakInstallation *, QVector<FlatpakInstalledRef *>> ret;

                for (auto installation : installations) {
                    g_autoptr(GError) localError = nullptr;
                    g_autoptr(GPtrArray) refs = flatpak_installation_list_installed_refs_for_update(installation, cancellable, &localError);
                    if (!refs) {
                        qWarning() << "Failed to get list of installed refs for listing updates:" << localError->message;
                        continue;
                    }
                    if (g_cancellable_is_cancelled(cancellable)) {
                        qWarning() << "Job cancelled";
                        return ret;
                    }

                    auto &current = ret[installation];
                    current.reserve(refs->len);
                    for (uint i = 0; i < refs->len; i++) {
                        FlatpakInstalledRef *ref = FLATPAK_INSTALLED_REF(g_ptr_array_index(refs, i));
                        g_object_ref(ref);
                        current.append(ref);
                    }
                }
                return ret;
            }));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &pkgStr : transaction->addons().addonsToInstall()) {
        QApt::Package *addon = m_backend->package(pkgStr);

        if (addon)
            excluded.append(addon);
    }
```

#### AUTO 


```{c}
auto it = pkgDeps.constBegin(), itEnd = pkgDeps.constEnd();
```

#### LAMBDA EXPRESSION 


```{c}
[this, stream, entryid, providerid](const KNSCore::EntryInternal &entry) {
            if (entry.uniqueId() == entryid && providerid == QUrl(entry.providerId()).host()) {
                Q_EMIT stream->resourcesFound({resourceForEntry(entry)});
            } else
                qWarning() << "found invalid" << entryid << entry.uniqueId() << providerid << QUrl(entry.providerId()).host();
            m_responsePending = false;
            QTimer::singleShot(0, this, &KNSBackend::availableForQueries);
            stream->finish();
        }
```

#### AUTO 


```{c}
const auto resources = kTransform<QVector<AbstractResource *>>(filtered, [this](const KNSCore::EntryInternal &entry) {
        return resourceForEntry(entry);
    });
```

#### AUTO 


```{c}
const auto resources = resourcesByPackageNames<QVector<AbstractResource*>>(ids);
```

#### AUTO 


```{c}
const auto resolved = kFilter<QVector<AbstractResource*>>(toResolve, installedFilter);
```

#### LAMBDA EXPRESSION 


```{c}
[]() {
        qDebug() << "action triggered!";
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QApt::MarkingErrorInfo &reason : failedReasons)
        dialogText += digestReason(package, reason);
```

#### AUTO 


```{c}
auto streams = kTransform<QSet<ResultsStream*>>(m_backends, [search](AbstractResourcesBackend* backend){ return backend->search(search); });
```

#### AUTO 


```{c}
const auto packageServices = kFilter<QStringList>(allServices, [filenames](const QString &file) { return filenames.contains(file); });
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &error) { qWarning() << "kns error" << this << error; }
```

#### LAMBDA EXPRESSION 


```{c}
[](AppPackageKitResource* a){ return a; }
```

#### AUTO 


```{c}
auto applicationCategory =
            new Category(i18n("Applications"), QStringLiteral("applications-internet"), filters, backendName, {actualCategory}, QUrl(), false);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &cat : qAsConst(categories)) {
        const QString catName = cat->name().append(QLatin1Char('/'));
        for (const auto &potentialSubCat : qAsConst(categories)) {
            if (potentialSubCat->name().startsWith(catName)) {
                cat->addSubcategory(potentialSubCat);
                topCategories.removeOne(potentialSubCat);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractResource *res : resources) {
        if (m_ratings.contains(res->appstreamId())) {
            Q_EMIT res->ratingFetched();
        }
    }
```

#### AUTO 


```{c}
const auto numberStr = headers.value("content-length");
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            reloadPackageList();
            acquireFetching(false);
            delete m_refresher;
        }
```

#### AUTO 


```{c}
auto args = {QStringLiteral("update"), QStringLiteral("--check")};
```

#### AUTO 


```{c}
auto remote = flatpak_installation_get_remote_by_name(preferredInstallation(), resource->flatpakName().toUtf8().constData(), cancellable, nullptr);
```

#### AUTO 


```{c}
auto f = [this, filter, stream] {
            const auto resources = kTransform<QVector<AbstractResource*>>(m_packages.extendedBy.value(filter.extends), [](AppPackageKitResource* a){ return a; });
            if (!resources.isEmpty()) {
                stream->setResources(resources);
            }
            stream->finish();
        };
```

#### AUTO 


```{c}
auto searchComponent = [this, stream, source, name] {
                auto comps = source->m_pool->componentsById(name);
                if (comps.isEmpty()) {
                    const QString nameWithDesktop = name + QLatin1String(".desktop");
                    comps = source->m_pool->componentsById(nameWithDesktop);
                }
                auto resources = kTransform<QVector<AbstractResource *>>(comps, [this, source](const auto &comp) {
                    return resourceForComponent(comp, source);
                });
                stream->resourcesFound(resources);
                stream->finish();
            };
```

#### AUTO 


```{c}
auto start = [this, stream, searchText]() {
        m_engine->setSearchTerm(searchText);
        m_engine->requestData(0, 100);
        m_responsePending = true;
        m_page = 0;
        connect(this, &KNSBackend::receivedResources, stream, &ResultsStream::resourcesFound);
        connect(this, &KNSBackend::searchFinished, stream, &ResultsStream::finish);
        connect(this, &KNSBackend::startingSearch, stream, &ResultsStream::finish);
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &_error) {
        QString error = _error;
        if(error == QLatin1Literal("All categories are missing")) {
            markInvalid(error);
            error = i18n("Invalid %1 backend, contact your distributor.", m_displayName);
        }
        m_responsePending = false;
        Q_EMIT searchFinished();
        Q_EMIT availableForQueries();
        this->setFetching(false);
        qWarning() << "kns error" << objectName() << error;
        passiveMessage(i18n("%1: %2", name(), error));
    }
```

#### AUTO 


```{c}
const auto trans = TransactionModel::global()->transactions();
```

#### AUTO 


```{c}
auto addNativeSourcesManager = [this](const QString &file){
        auto service = PackageKitBackend::locateService(file);
        if (!service.isEmpty())
            m_actions += createActionForService(service, this);
        };
```

#### LAMBDA EXPRESSION 


```{c}
[this, originalUrl, fileUrl, replyPut]() {
                if (replyPut->error() == QNetworkReply::NoError) {
                    auto res = m_backend->resourceForFile(fileUrl);
                    if (res) {
                        FlatpakResource *resource = qobject_cast<FlatpakResource*>(res);
                        resource->setResourceFile(originalUrl);
                        Q_EMIT jobFinished(true, resource);
                    } else {
                        qWarning() << "couldn't create resource from" << fileUrl.toLocalFile();
                        Q_EMIT jobFinished(false, nullptr);
                    }
                } else {
                    qWarning() << "couldn't save" << originalUrl << replyPut->errorString();
                    Q_EMIT jobFinished(false, nullptr);
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[t, &ret] { ret = t->status(); }
```

#### AUTO 


```{c}
auto p = new QProcess(parent());
```

#### AUTO 


```{c}
const auto pkgs = m_packages.packageToApp.value(res->packageName(), {res->packageName()});
```

#### AUTO 


```{c}
auto t = new PackageKit::Transaction(QDBusObjectPath(tid));
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &e : m_entry.downloadLinkInformationList()) {
        if (e.isDownloadtypeLink)
            ids << e.id;
    }
```

#### AUTO 


```{c}
const auto destRow = row + (delta > 0 ? delta : delta);
```

#### RANGE FOR STATEMENT 


```{c}
for (KAction *action : m_actions) {
        action->setEnabled(enabled);
    }
```

#### AUTO 


```{c}
auto theIcon = QVariant::fromValue<QImage>(reader.read());
```

#### AUTO 


```{c}
auto id = idForInstalledRef(installation, ref, {});
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &pkg : pkgNames) {
        m_packages.packageToApp[pkg] += component.id();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[menu, this]() {
        m_item->setTitle(i18n("Restart to apply installed updates"));
        m_item->setToolTipTitle(i18n("Click to restart the device"));
        m_item->setIconByName(QStringLiteral("view-refresh"));
    }
```

#### AUTO 


```{c}
const auto it = std::find_if(m_displayedResources.constBegin(), m_displayedResources.constEnd(), finder);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        Q_EMIT finishedResources(m_resources);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        {
            if (m_backends.isEmpty())
                return 0;

            int sum = 0;
            for(auto backend: qAsConst(m_backends)) {
                sum += backend->fetchingUpdatesProgress();
            }
            return sum / m_backends.count();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &pkg : componentExtends) {
        m_packages.extendedBy[pkg] += res;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[regularCheck](const QStringRef& value) {
            bool ok;
            int time = value.toInt(&ok);
            if (ok && time > 0)
                regularCheck->setInterval(time * 60 * 60 * 1000);
            else
                qWarning() << "couldn't understand value for timer:" << value;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &pkgStr : addons.addonsToRemove()) {
        QApt::Package *package = m_backend->package(pkgStr);
        package->setRemove();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[stream, this, state, job]() {
        QSet<SnapResource*> higher = kFilter<QSet<SnapResource*>>(m_resources, [state](AbstractResource* res){ return res->state()>=state; });

        QVector<AbstractResource*> ret;
        QSet<SnapResource*> resources;
        for (int i=0, c=job->snapCount(); i<c; ++i) {
            const auto snap = job->snap(i);
            const auto snapname = snap->name();
            SnapResource* res = m_resources.value(snapname);
            if (!res) {
                res = new SnapResource(snap, state, this);
                Q_ASSERT(res->packageName() == snapname);
                resources += res;
            } else {
                res->setState(state);
                higher.remove(res);
            }
            ret += res;
        }

        foreach(SnapResource* res, resources)
            m_resources[res->packageName()] = res;
        for(auto res: higher) {
            res->setState(AbstractResource::None);
        }

        if (!ret.isEmpty())
            stream->resourcesFound(ret);
        stream->finish();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& filter: orFilters) {
            if(shouldFilter(res, filter)) {
                orValue = true;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto backend: qAsConst(m_backends))
        backend->checkForUpdates();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &pkgid : toremove) {
                auto res = kFilter<QVector<AbstractResource *>>(m_backend->resourcesByPackageName(pkgid), [](AbstractResource *res) {
                    return static_cast<PackageKitResource *>(res)->isCritical();
                });
                criticals << kTransform<QStringList>(res, [](AbstractResource *a) {
                    return a->name();
                });
                if (!criticals.isEmpty()) {
                    break;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (Application *app : tempList) {
        bool added = false;
        QApt::Package *pkg = app->package();
        if (app->isValid() && pkg)
        {
            appList << app;
            app->moveToThread(thread);
            added = true;
        }

        if(!added)
            delete app;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const AppStream::Component &appstreamComponent : components) {
            FlatpakResource *resource = new FlatpakResource(appstreamComponent, flatpakInstallation, this);
            resource->setIconPath(appstreamIconsPath);
            resource->setOrigin(sourceName);
            if (resource->resourceType() == FlatpakResource::Runtime) {
                resources.prepend(resource);
            } else {
                resources.append(resource);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QApt::Transaction *t : list) {
        if (t->transactionId() == active) {
            trans = t;
            break;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, fw]() {
        const auto data = fw->result();
        fw->deleteLater();

        if (!data.correct && m_packages.packages.isEmpty()) {
            QTimer::singleShot(0, this, [this]() {
                Q_EMIT passiveMessage(i18n("Please make sure that Appstream is properly set up on your system"));
            });
        }
        QStringList neededPackages;
        neededPackages.reserve(data.components.size());
        for (const auto &component: data.components) {
            const auto pkgNames = component.packageNames();
            addComponent(component, pkgNames);
            neededPackages << pkgNames;
        }
        for (auto it = data.missingComponents.constBegin(), itEnd = data.missingComponents.constEnd(); it != itEnd; ++it) {
            acquireFetching(true);
            const auto file = it.key();
            const auto component = it.value();
            auto trans = PackageKit::Daemon::searchFiles(file);
            connect(trans, &PackageKit::Transaction::package, this, [trans](PackageKit::Transaction::Info info, const QString &packageID){
                if (info == PackageKit::Transaction::InfoInstalled)
                    trans->setProperty("installedPackage", packageID);
            });
            connect(trans, &PackageKit::Transaction::finished, this, [this, trans, component](PackageKit::Transaction::Exit status) {
                const auto pkgidVal = trans->property("installedPackage");
                if (status == PackageKit::Transaction::ExitSuccess && !pkgidVal.isNull()) {
                    const auto pkgid = pkgidVal.toString();
                    auto res = addComponent(component, {PackageKit::Daemon::packageName(pkgid)});
                    res->clearPackageIds();
                    res->addPackageId(PackageKit::Transaction::InfoInstalled, pkgid, true);
                }
                acquireFetching(false);
            });
        }

        if (!neededPackages.isEmpty()) {
            neededPackages.removeDuplicates();
            resolvePackages(neededPackages);
        } else {
            qCDebug(LIBDISCOVER_BACKEND_LOG) << "empty appstream db";
            if (PackageKit::Daemon::backendName() == QLatin1String("aptcc") || PackageKit::Daemon::backendName().isEmpty()) {
                checkForUpdates();
            }
        }
        acquireFetching(false);
        if (!m_appstreamInitialized) {
            m_appstreamInitialized = true;
            Q_EMIT loadedAppStream();
        }
    }
```

#### AUTO 


```{c}
const auto snaps = jobResult(socket.find(QStringLiteral("editor"))).toArray();
```

#### AUTO 


```{c}
auto randomRating = qrand()%10;
```

#### AUTO 


```{c}
auto it = m_categories.begin();
```

#### LAMBDA EXPRESSION 


```{c}
[](const Appstream::Component& comp) { return comp.id(); }
```

#### AUTO 


```{c}
auto backend = qobject_cast<PackageKitBackend*>(resource()->backend());
```

#### AUTO 


```{c}
const auto notFilters = cat->notFilters();
```

#### AUTO 


```{c}
auto *job = new KIO::CommandLauncherJob(QStringLiteral("plasma-discover"), {QStringLiteral("--mode"), QStringLiteral("update")});
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &source : qAsConst(m_flatpakSources)) {
            QVector<FlatpakResource *> resources;
            if (source->m_pool) {
                resources = kTransform<QVector<FlatpakResource *>>(source->m_pool->search(filter.search), [this, &source](const auto &comp) {
                    return resourceForComponent(comp, source);
                });
            } else {
                resources = source->m_resources.values().toVector();
            }

            for (auto r : resources) {
                const bool matchById = r->appstreamId().compare(filter.search, Qt::CaseInsensitive) == 0;
                if (r->type() == AbstractResource::Technical && filter.state != AbstractResource::Upgradeable && !matchById) {
                    continue;
                }
                if (r->state() < filter.state)
                    continue;

                if (!filter.extends.isEmpty() && !r->extends().contains(filter.extends))
                    continue;

                if (!filter.mimetype.isEmpty() && !r->mimetypes().contains(filter.mimetype))
                    continue;

                if (filter.search.isEmpty() || matchById) {
                    rest += r;
                } else if (r->name().contains(filter.search, Qt::CaseInsensitive)) {
                    prioritary += r;
                } else if (r->comment().contains(filter.search, Qt::CaseInsensitive)) {
                    rest += r;
                }
            }
        }
```

#### AUTO 


```{c}
const auto res = new AppPackageKitResource(component, pkgNames.at(0), this);
```

#### LAMBDA EXPRESSION 


```{c}
[eulaID](){
        return PackageKit::Daemon::acceptEula(eulaID);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, toRemoveRefs, installation, id] {
                    g_autoptr(GError) localError = nullptr;
                    g_autoptr(GCancellable) cancellable = g_cancellable_new();
                    g_autoptr(FlatpakTransaction) transaction = flatpak_transaction_new_for_installation(installation, cancellable, &localError);
                    for (const QString& instRef : qAsConst(toRemoveRefs)) {
                        const QByteArray refString = instRef.toUtf8();
                        flatpak_transaction_add_uninstall(transaction, refString.constData(), &localError);
                        if (localError)
                            return;
                    }

                    if (flatpak_transaction_run(transaction, cancellable, &localError)) {
                        removeSource(id);
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for(QApt::Package* it : pkgList) {
            AbstractResource* res = m_appBackend->resourceByPackageName(it->name());
            if(!res) //If we couldn't find it by its name, try with 
                res = m_appBackend->resourceByPackageName(QString("%1:%2").arg(it->name()).arg(it->architecture()));
            Q_ASSERT(res);
            ret += res;
        }
```

#### AUTO 


```{c}
auto it = jsonObject.begin();
```

#### LAMBDA EXPRESSION 


```{c}
[this](AbstractResource* res, AbstractResource* res2){ return lessThan(res, res2); }
```

#### CONST EXPRESSION 


```{c}
constexpr int requested_sort_magic = (QApt::Package::ToInstall
                                         | QApt::Package::ToRemove
                                         | QApt::Package::ToKeep);
```

#### AUTO 


```{c}
auto action = new OneTimeAction(
        [this, localfile]() {
            auto res = ResourcesModel::global()->resourceForFile(localfile);
            qDebug() << "all initialized..." << res;
            if (res) {
                emit openApplicationInternal(res);
            } else {
                rootObject()->setProperty("defaultStartup", true);
                showPassiveNotification(i18n("Couldn't open %1", localfile.toDisplayString()));
            }
        }
        , this);
```

#### AUTO 


```{c}
const auto packageId = stream->property("packageId");
```

#### AUTO 


```{c}
auto proceedFunction = [this, item, value, role]() {
                        if(fwupd_client_modify_remote(m_backend->backend->client, fwupd_remote_get_id(remote), "Enabled", "true", nullptr, nullptr))
                            item->setData(value, role);
                    };
```

#### LAMBDA EXPRESSION 


```{c}
[res, engine]() {
                engine->install(res->entry(), -1);
            }
```

#### AUTO 


```{c}
auto transaction = m_resourcesUpdatesModel->transaction();
```

#### AUTO 


```{c}
auto roles = QStandardItemModel::roleNames();
```

#### RANGE FOR STATEMENT 


```{c}
for(AbstractResource* res : m_packages.values()) {
        if (res->state() == AbstractResource::Upgradeable && !res->isTechnical()) {
            ret++;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &name : qAsConst(*it)) {
            auto remote = flatpak_installation_get_remote_by_name(installation, name.toUtf8(), m_cancellable, &localError);
            if (!remote) {
                qWarning() << "Could not find remote" << name << "in" << it.key();
                continue;
            }
            loadRemote(installation, remote);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
              {
                  int ret = 0;
                  foreach (AbstractResourcesBackend *backend, m_backends) {
                      ret += backend->updatesCount();
                  }
                  return ret;
              }
          }
```

#### LAMBDA EXPRESSION 


```{c}
[installation]() -> GPtrArray * {
        g_autoptr(GCancellable) cancellable = g_cancellable_new();
        g_autoptr(GError) localError = nullptr;
        GPtrArray *refs = flatpak_installation_list_installed_refs_for_update(installation->m_installation, cancellable, &localError);
        if (!refs) {
            qWarning() << "Failed to get list of installed refs for listing updates: " << localError->message;
        }
        return refs;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[filenames](const QString &file) { return filenames.contains(file); }
```

#### AUTO 


```{c}
auto action = new OneTimeAction(
        [this, localfile]() {
            AbstractResourcesBackend::Filters f;
            f.resourceUrl = localfile;
            auto stream = new StoredResultsStream({ResourcesModel::global()->search(f)});
            connect(stream, &StoredResultsStream::finished, this, [this, localfile, stream]() {
                const auto res = stream->resources();
                if (res.count() == 1) {
                    emit openApplicationInternal(res.first());
                } else {
                    QMimeDatabase db;
                    auto mime = db.mimeTypeForUrl(localfile);
                    auto fIsFlatpakBackend = [](AbstractResourcesBackend* backend) { return backend->metaObject()->className() == QByteArray("FlatpakBackend"); };
                    if (mime.name().startsWith(QLatin1String("application/vnd.flatpak")) && !kContains(ResourcesModel::global()->backends(), fIsFlatpakBackend)) {
                        openApplication(QUrl(QStringLiteral("appstream://org.kde.discover.flatpak")));
                        showPassiveNotification(i18n("Cannot interact with flatpak resources without the flatpak backend %1. Please install it first.", localfile.toDisplayString()));
                    } else {
                        setRootObjectProperty("defaultStartup", true);
                        showPassiveNotification(i18n("Couldn't open %1", localfile.toDisplayString()));
                    }
                }
            });
        }
        , this);
```

#### AUTO 


```{c}
auto item = m_sources->sourceByUrl(refurl);
```

#### AUTO 


```{c}
const auto packageName = item->resource()->packageName();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto res : qAsConst(m_resources)) {
            PackageKitResource * app = qobject_cast<PackageKitResource*>(res);
            QString pkgid = m_backend->upgradeablePackageId(app);
            if (!donePkgs.contains(pkgid)) {
                donePkgs.insert(pkgid);
                ret += app;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &name) {
        return backend(name);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto backend : qAsConst(m_backends))
        backend->checkForUpdates();
```

#### RANGE FOR STATEMENT 


```{c}
for (Application *app : m_appList) {
        app->setParent(this);
        QApt::Package* pkg = app->package();
        if (pkg->isInstalled())
            m_instOriginList << pkg->origin();
        else
            m_originList << pkg->origin();
    }
```

#### AUTO 


```{c}
auto changes = m_aptBackend->stateChanges(m_updatesCache, QApt::PackageList());
```

#### LAMBDA EXPRESSION 


```{c}
[&it] (const QString& id) {
                        static const QLatin1String desktopPostfix(".desktop");
                        return it.key().compare(id, Qt::CaseInsensitive) == 0 ||
                              //doing (id == id.key()+".desktop") without allocating
                              (id.size() == (desktopPostfix.size() + it.key().size()) && id.endsWith(desktopPostfix) && id.startsWith(it.key(), Qt::CaseInsensitive));
                    }
```

#### AUTO 


```{c}
auto pkgs = involvedPackages(m_toUpgrade).values();
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        m_reviews->emitRatingFetched(this, kTransform<QList<AbstractResource*>>(m_packages.packages, [] (AbstractResource* r) { return r; }));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, res]() {
            for(auto i : res->linkIds()) {
                auto engine = res->knsBackend()->engine();
                if (this->role() == InstallRole)
                    engine->install(res->entry(), i);
                else if(this->role() == RemoveRole)
                    engine->uninstall(res->entry());
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[stream, this, job, filter]() {
            const int remaining = stream->property("remaining").toInt() - 1;
            stream->setProperty("remaining", remaining);

            if (job->error()) {
                qDebug() << "error:" << job->error() << job->errorString();
                if (remaining == 0)
                    stream->finish();
                return;
            }

            QVector<AbstractResource*> ret;
            QVector<SnapResource*> resources;
            ret.reserve(job->snapCount());
            resources.reserve(job->snapCount());
            for (int i=0, c=job->snapCount(); i<c; ++i) {
                QSharedPointer<QSnapdSnap> snap(job->snap(i));

                if (!filter(snap))
                    continue;

                const auto snapname = snap->name();
                SnapResource* res = m_resources.value(snapname);
                if (!res) {
                    res = new SnapResource(snap, AbstractResource::None, this);
                    Q_ASSERT(res->packageName() == snapname);
                    resources += res;
                } else {
                    res->setSnap(snap);
                }
                ret += res;
            }

            foreach(SnapResource* res, resources)
                m_resources[res->packageName()] = res;

            if (!ret.isEmpty())
                Q_EMIT stream->resourcesFound(ret);

            if (remaining == 0)
                stream->finish();
        }
```

#### AUTO 


```{c}
const auto resources = backend->resourcesByPackageName(PackageKit::Daemon::packageName(pkgid));
```

#### AUTO 


```{c}
auto searchComponent = [this, stream, source, name] {
                auto comps = source->m_pool->componentsById(name);
                if (comps.isEmpty()) {
                    comps = source->m_pool->componentsByProvided(AppStream::Provided::KindId, name);
                }
                auto resources = kTransform<QVector<AbstractResource *>>(comps, [this, source](const auto &comp) {
                    return resourceForComponent(comp, source);
                });
                stream->resourcesFound(resources);
                stream->finish();
            };
```

#### AUTO 


```{c}
const auto backends = ResourcesModel::global()->backends();
```

#### RANGE FOR STATEMENT 


```{c}
for (Category *c : subs) {
            Category *ret = recFindCategory(c, name);
            if (ret)
                return ret;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, resource] (Transaction::Status status) {
        if (status == Transaction::Status::DoneStatus) {
            updateAppState(resource);
        }
    }
```

#### AUTO 


```{c}
const auto orFilters = cat->orFilters();
```

#### AUTO 


```{c}
const auto components = m_appdata.allComponents();
```

#### AUTO 


```{c}
auto mReportBugAction = KStandardAction::reportBug(this, &DiscoverObject::reportBug, this);
```

#### LAMBDA EXPRESSION 


```{c}
[stream, this, job]() {
        if (job->error()) {
            qDebug() << "error:" << job->error() << job->errorString();
            stream->finish();
            return;
        }

        QVector<AbstractResource*> ret;
        QSet<SnapResource*> resources;
        resources.reserve(job->snapCount());
        for (int i=0, c=job->snapCount(); i<c; ++i) {
            QSharedPointer<QSnapdSnap> snap(job->snap(i));
            const auto snapname = snap->name();
            SnapResource* res = m_resources.value(snapname);
            if (!res) {
                res = new SnapResource(snap, AbstractResource::None, this);
                Q_ASSERT(res->packageName() == snapname);
                resources += res;
            } else {
                res->setSnap(snap);
            }
            ret += res;
        }

        foreach(SnapResource* res, resources)
            m_resources[res->packageName()] = res;

        if (!ret.isEmpty())
            Q_EMIT stream->resourcesFound(ret);
        stream->finish();
    }
```

#### AUTO 


```{c}
auto it = data.constBegin(), itEnd=data.constEnd();
```

#### RANGE FOR STATEMENT 


```{c}
for(auto pkgList : changes.values()) {
        for(QApt::Package* it : pkgList) {
            AbstractResource* res = m_appBackend->resourceByPackageName(it->name());
            if(!res) //If we couldn't find it by its name, try with
                res = m_appBackend->resourceByPackageName(QString("%1:%2").arg(it->name()).arg(it->architecture()));
            Q_ASSERT(res);
            ret += res;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto res : resources)
            if (res->state() == AbstractResource::Upgradeable)
                m_upgradeable.insert(res);
```

#### AUTO 


```{c}
auto it = std::lower_bound(list.begin(), list.end(), newcat, &categoryLessThan);
```

#### LAMBDA EXPRESSION 


```{c}
[this, fw, pool, source]() {
        source->m_pool = pool;
        m_flatpakLoadingSources.removeAll(source);
        if (fw->result()) {
            m_flatpakSources += source;
        } else {
            qWarning() << "Could not open the AppStream metadata pool" << pool->lastError();
        }
        metadataRefreshed();
        acquireFetching(false);
        fw->deleteLater();
    }
```

#### AUTO 


```{c}
auto action = new OneTimeAction(
        [this, url]() {
            AbstractResourcesBackend::Filters f;
            f.resourceUrl = url;
            auto stream = new StoredResultsStream({ResourcesModel::global()->search(f)});
            connect(stream, &StoredResultsStream::finishedResources, this, [this, url](const QVector<AbstractResource *> &res) {
                if (res.count() >= 1) {
                    emit openApplicationInternal(res.first());
                } else if (url.scheme() == QLatin1String("snap")) {
                    openApplication(QUrl(QStringLiteral("appstream://org.kde.discover.snap")));
                    showPassiveNotification(i18n("Please make sure Snap support is installed"));
                } else {
                    Q_EMIT openErrorPage(i18n("Could not open %1", url.toDisplayString()));
                }
            });
        },
        this);
```

#### AUTO 


```{c}
const auto pkgids = m_newPackageStates.value(PackageKit::Transaction::InfoFinished);
```

#### AUTO 


```{c}
auto resource = new FlatpakResource(c, this);
```

#### AUTO 


```{c}
auto randomRating = qrand()%15;
```

#### AUTO 


```{c}
auto resource = resources.constFirst();
```

#### AUTO 


```{c}
const auto resources2 = fetchResources(m_appBackend->search(filter));
```

#### LAMBDA EXPRESSION 


```{c}
[this, ret](){
        for (auto res: qAsConst(m_resources)) {
            if (ret->resources().contains(res))
                res->setState(AbstractResource::Installed);
            else
                res->setState(AbstractResource::None);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[res, engine]() {
                engine->install(res->entry());
            }
```

#### AUTO 


```{c}
auto future = QtConcurrent::run(&m_threadPool, [this, jobs]() {
        for (auto job : jobs) {
            connect(this, &SnapBackend::shuttingDown, job, &T::cancel);
            job->runSync();
        }
    });
```

#### LAMBDA EXPRESSION 


```{c}
[](Category* cat){ return QVariant::fromValue<QObject*>(cat); }
```

#### RANGE FOR STATEMENT 


```{c}
for (Transaction *trans : m_transactions) {
        if (trans->resource() == resource) {
            ret = trans;
            break;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[type, keyId, packageID](){
        return PackageKit::Daemon::installSignature(type, keyId, packageID);
    }
```

#### AUTO 


```{c}
const auto conf = KSharedConfig::openConfig();
```

#### AUTO 


```{c}
const auto topLevelName = knsrcPlasma.contains(fileName)? i18n("Plasma Addons") : i18n("Application Addons");
```

#### AUTO 


```{c}
const auto networkError = reply->networkError();
```

#### LAMBDA EXPRESSION 


```{c}
[this, stream, url] () {
                const auto resources = resourcesByAppstreamName(url.host());
                if (!resources.isEmpty())
                    Q_EMIT stream->resourcesFound(resources);
                stream->finish();
            }
```

#### AUTO 


```{c}
auto actualCategory = new Category(m_displayName, iconName, filters, backendName, categories, QUrl(), true);
```

#### AUTO 


```{c}
const auto ret = QIcon::fromTheme(icon.name());
```

#### AUTO 


```{c}
const auto &role
```

#### AUTO 


```{c}
const auto components = fw->result();
```

#### LAMBDA EXPRESSION 


```{c}
[](AppPackageKitResource *r) {
        return PackageState(r->appstreamId(), r->name(), r->comment(), r->isInstalled());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Attica::Comment &comment : comments) {
        // TODO: language lookup?
        ReviewPtr r(new Review(app->name(),
                               app->packageName(),
                               QStringLiteral("en"),
                               comment.subject(),
                               comment.text(),
                               comment.user(),
                               comment.date(),
                               true,
                               comment.id().toInt(),
                               comment.score() / 10,
                               0,
                               0,
                               QString()));
        r->addMetadata(QStringLiteral("NumberOfParents"), depth);
        reviews += r;
        if (comment.childCount() > 0) {
            reviews += createReviewList(app, comment.children(), depth + 1);
        }
    }
```

#### AUTO 


```{c}
auto start = [this, stream, searchText]() {
        Q_ASSERT(!isFetching());
        if (!m_isValid) {
            qWarning() << "querying an invalid backend";
            stream->finish();
            return;
        }

        if (m_responsePending || stream->property("alreadyStarted").toBool()) {
            return;
        }
        stream->setProperty("alreadyStarted", true);
        setResponsePending(true);

        // No need to explicitly launch a search, setting the search term already does that for us
        m_engine->setSearchTerm(searchText);
        m_onePage = false;

        connect(stream, &ResultsStream::fetchMore, this, &KNSBackend::fetchMore);
        connect(this, &KNSBackend::receivedResources, stream, &ResultsStream::resourcesFound);
        connect(this, &KNSBackend::searchFinished, stream, &ResultsStream::finish);
        connect(this, &KNSBackend::startingSearch, stream, &ResultsStream::finish);
    };
```

#### AUTO 


```{c}
const auto backend = qobject_cast<PackageKitBackend*>(resource()->backend());
```

#### LAMBDA EXPRESSION 


```{c}
[](PackageKit::Transaction::Error /*error*/, const QString &details) {
                KNotification::event(QStringLiteral("OfflineUpdateRepairFailed"),
                                     i18n("Repair Failed"),
                                     i18n("Please report to your distribution: %1", details),
                                     {},
                                     KNotification::Persistent,
                                     QStringLiteral("org.kde.discovernotifier"));
            }
```

#### LAMBDA EXPRESSION 


```{c}
[regularCheck](const QStringView &value) {
            bool ok;
            const int days = value.toInt(&ok);
            if (!ok || days == 0) {
                regularCheck->setInterval(24h); // refresh at least once every day
                regularCheck->start();
                if (!value.isEmpty())
                    qWarning() << "couldn't understand value for timer:" << value;
            }

            // if the setting is not empty, refresh will be carried out by unattended-upgrade
            // https://wiki.debian.org/UnattendedUpgrades
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, category]() {
            Category* cat = CategoryModel::global()->findCategoryByName(category);
            if (cat) {
                emit listCategoryInternal(cat);
            } else {
                showPassiveNotification(i18n("Could not find category '%1'", category));
                rootObject()->setProperty("defaultStartup", false);
            }
        }
```

#### AUTO 


```{c}
auto *fetchJob = KIO::storedGet(featuredUrl, KIO::NoReload, KIO::HideProgressInfo);
```

#### AUTO 


```{c}
const auto resources = withoutDuplicates();
```

#### AUTO 


```{c}
const auto backendNames = f.allBackendNames(false, true);
```

#### AUTO 


```{c}
const auto sourceItem = qobject_cast<FlatpakBackend*>(backend())->sources()->sourceById(origin());
```

#### RANGE FOR STATEMENT 


```{c}
for(AbstractResource* res : m_packages) {
        if(res->state() == AbstractResource::Upgradeable) {
            ret+=res;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &pkgid) {
        return PackageKit::Daemon::packageName(pkgid);
    }
```

#### AUTO 


```{c}
auto trans = PackageKit::Daemon::installPackages(ids, PackageKit::Transaction::TransactionFlagSimulate);
```

#### LAMBDA EXPRESSION 


```{c}
[this, url](const QVector<AbstractResource*> &res) {
                if (res.count() >= 1) {
                    emit openApplicationInternal(res.first());
                } else if (url.scheme() == QLatin1String("snap")) {
                    openApplication(QUrl(QStringLiteral("appstream://org.kde.discover.snap")));
                    showPassiveNotification(i18n("Please make sure Snap support is installed"));
                } else {
                    Q_EMIT openErrorPage(i18n("Could not open %1", url.toDisplayString()));
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this, resource, fw, runtimeUrl]() {
            const auto metadata = fw->result();
            // Even when we failed to fetch information about runtime we still want to show the application
            if (metadata.isEmpty()) {
                Q_EMIT onFetchMetadataFinished(resource, metadata);
            } else {
                updateAppMetadata(resource, metadata);

                auto runtime = getRuntimeForApp(resource);
                if (!runtime || (runtime && !runtime->isInstalled())) {
                    FlatpakFetchRemoteResourceJob *fetchRemoteResource = new FlatpakFetchRemoteResourceJob(runtimeUrl, this);
                    connect(fetchRemoteResource, &FlatpakFetchRemoteResourceJob::jobFinished, this, [this, resource] (bool success, FlatpakResource *repoResource) {
                        if (success) {
                            installApplication(repoResource);
                        }
                        addResource(resource);
                    });
                    fetchRemoteResource->start();
                    return;
                } else {
                    addResource(resource);
                }
            }
            fw->deleteLater();
        }
```

#### AUTO 


```{c}
auto r = new ResultsStream(QStringLiteral("KNS-search-")+name());
```

#### LAMBDA EXPRESSION 


```{c}
[](QStandardItem *item) {
        qDebug() << "DummySource changed" << item << item->checkState();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString& pkgid : m_updatesPackageId) {
        ret += m_packages[PackageKit::Daemon::packageName(pkgid)];
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(AbstractResource* res : m_packages) {
        if(res->state() == AbstractResource::Upgradeable) {
            ret++;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        m_fetchingUpdatesProgress.reevaluate();
    }
```

#### AUTO 


```{c}
const auto it = std::upper_bound(m_displayedResources.constBegin(), m_displayedResources.constEnd(), resource, finder);
```

#### AUTO 


```{c}
auto b = new SourceBackendModel(backend);
```

#### AUTO 


```{c}
auto actualCategory = new Category(m_displayName, QStringLiteral("plasma"), filters, backendName, categories, QUrl(), true);
```

#### AUTO 


```{c}
const auto deprecatedHost = deprecatedAppstreamIds.value(url.host());
```

#### AUTO 


```{c}
auto stream = new ResultsStream(QLatin1String("FlatpakStream-http-") + fileName);
```

#### LAMBDA EXPRESSION 


```{c}
[this, installation, fw]() {
        onFetchUpdatesFinished(installation, fw->result());
        fw->deleteLater();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &path) -> FlatpakInstallation * {
        for (auto inst : m_installations) {
            if (FlatpakResource::installationPath(inst) == path)
                return inst;
        }
        return nullptr;
    }
```

#### AUTO 


```{c}
const auto resources = resourcesByAppstreamName(url.host());
```

#### LAMBDA EXPRESSION 


```{c}
[=]()
                            {
                                item->setCheckState(Qt::Unchecked);
                                Q_EMIT dataChanged(index,index,{});
                                return false;
                            }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto ref : qAsConst(it.value())) {
                        bool fresh;
                        auto resource = getAppForInstalledRef(it.key(), ref, &fresh);
#if FLATPAK_CHECK_VERSION(1, 1, 2)
                        resource->setAvailableVersion(QString::fromUtf8(flatpak_installed_ref_get_appdata_version(ref)));
#endif
                        g_object_unref(ref);
                        resource->setState(AbstractResource::Upgradeable, !fresh);
                        updateAppSize(resource);
                        if (resource->resourceType() == FlatpakResource::Runtime) {
                            resources.prepend(resource);
                        } else {
                            resources.append(resource);
                        }
                    }
```

#### AUTO 


```{c}
auto pkg = m_resourcesByName.value(search);
```

#### RANGE FOR STATEMENT 


```{c}
for(auto o: objs)
            delete o;
```

#### AUTO 


```{c}
auto pkr = qobject_cast<PackageKitResource*>(it.value());
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const PackageKit::Details &details){ setDetails(details); }
```

#### AUTO 


```{c}
auto f = [this, stream, url] () {
                QVector<AbstractResource*> resources;
                foreach(FlatpakResource* res, m_resources) {
                    if (QString::compare(res->appstreamId(), url.host(), Qt::CaseInsensitive)==0)
                        resources << res;
                }
                auto f = [this](AbstractResource* l, AbstractResource* r) { return flatpakResourceLessThan(l,r); };
                std::sort(resources.begin(), resources.end(), f);

                QTimer::singleShot(0, stream, [resources, stream] () {
                    if (!resources.isEmpty())
                        Q_EMIT stream->resourcesFound(resources);
                    stream->finish();
                });
            };
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            qInfo() << "Repairing system";
            auto trans = PackageKit::Daemon::global()->repairSystem();
            KNotification::event(QStringLiteral("OfflineUpdateRepairStarted"),
                                 i18n("Repairing failed offline update"),
                                 {},
                                 {},
                                 KNotification::CloseOnTimeout,
                                 QStringLiteral("org.kde.discovernotifier"));

            connect(trans, &PackageKit::Transaction::errorCode, this, [](PackageKit::Transaction::Error /*error*/, const QString &details) {
                KNotification::event(QStringLiteral("OfflineUpdateRepairFailed"),
                                     i18n("Repair Failed"),
                                     xi18nc("@info", "%1<nl/>Please report this error to your distribution.", details),
                                     {},
                                     KNotification::Persistent,
                                     QStringLiteral("org.kde.discovernotifier"));
            });
            connect(trans, &PackageKit::Transaction::finished, this, [] (PackageKit::Transaction::Exit status, uint runtime) {
                qInfo() << "repair finished!" << status << runtime;
                if (status == PackageKit::Transaction::ExitSuccess) {
                    PackageKit::Daemon::global()->offline()->clearResults();

                    KNotification::event(QStringLiteral("OfflineUpdateRepairSuccessful"),
                                         i18n("Repaired Successfully"),
                                         {},
                                         {},
                                         KNotification::CloseOnTimeout,
                                         QStringLiteral("org.kde.discovernotifier"));
                }
            });
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(BackendNotifierModule* module : m_backends) {
        if(!module->isSystemUpToDate())
            return false;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[stream, this, job]() {
        if (job->error()) {
            qDebug() << "error:" << job->error() << job->errorString();
            stream->finish();
            return;
        }

        QVector<AbstractResource*> ret;
        QVector<SnapResource*> resources;
        ret.reserve(job->snapCount());
        resources.reserve(job->snapCount());
        for (int i=0, c=job->snapCount(); i<c; ++i) {
            QSharedPointer<QSnapdSnap> snap(job->snap(i));
            const auto snapname = snap->name();
            SnapResource* res = m_resources.value(snapname);
            if (!res) {
                res = new SnapResource(snap, AbstractResource::None, this);
                Q_ASSERT(res->packageName() == snapname);
                resources += res;
            } else {
                res->setSnap(snap);
            }
            ret += res;
        }

        foreach(SnapResource* res, resources)
            m_resources[res->packageName()] = res;

        if (!ret.isEmpty())
            Q_EMIT stream->resourcesFound(ret);
        stream->finish();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(Application* a : m_appList) {
            a->setHasScreenshot(packages.contains(a->packageName()));
        }
```

#### AUTO 


```{c}
auto it = refs.constBegin(), itEnd = refs.constEnd();
```

#### AUTO 


```{c}
const auto resources =
                    kFilter<QVector<AbstractResource *>>(resourcesByPackageNames<QVector<AbstractResource *>>(ids), [](AbstractResource *res) {
                        return !qobject_cast<PackageKitResource *>(res)->extendsItself();
                    });
```

#### AUTO 


```{c}
auto res = backend->addSourceFromFlatpakRepo(flatpakrepoUrl);
```

#### RANGE FOR STATEMENT 


```{c}
for (PackageState state : m_availableAddons) {
        if (state.name() == addonName) {
            addon = &state;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto res : resources) {
                auto r = qobject_cast<PackageKitResource *>(res);
                r->clearPackageIds();
                Q_EMIT r->stateChanged();
                needResolving << r->allPackageNames();
            }
```

#### AUTO 


```{c}
auto f = [this, filter, stream] {
            auto resources = kFilter<QVector<AbstractResource *>>(m_packages.packages, [](AbstractResource *res) {
                return res->type() != AbstractResource::Technical && !qobject_cast<PackageKitResource *>(res)->extendsItself();
            });
            stream->setResources(resources);
            stream->finish();
        };
```

#### AUTO 


```{c}
auto remote = new QStandardItem(QString(remotes[r]));
```

#### RANGE FOR STATEMENT 


```{c}
for (Application *app : tempList) {
        bool added = false;
        QApt::Package *pkg = app->package();
        if (app->isValid()) {
            if ((pkg) && !pkgBlacklist.contains(pkg->name())
                    && !(pkg->state() & uninstallable)) {
                appList << app;
                added = true;
            }
        }

        if(added)
            app->moveToThread(thread);
        else
            delete app;
    }
```

#### AUTO 


```{c}
auto res = kFilter<QVector<AbstractResource *>>(m_backend->resourcesByPackageName(pkgid), [](AbstractResource *res) {
                    return static_cast<PackageKitResource *>(res)->isCritical();
                });
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString& file : files) {
        QList<Category*> cats = loadCategoriesFile(file);
        if(ret.isEmpty())
            ret += cats;
        else {
            for(Category* c : cats)
                Category::addSubcategory(ret, c);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](AbstractResource* resource){
        m_upgradeable.remove(resource);
        m_toUpgrade.remove(resource);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, packageDependencies](PackageKit::Transaction::Exit status) {
        Q_EMIT dependenciesFound(*packageDependencies);
    }
```

#### AUTO 


```{c}
auto f = [this, stream, filter] () {
        QVector<AbstractResource*> prioritary, rest;
        for (auto r : qAsConst(m_resources)) {
            const bool matchById = r->appstreamId().compare(filter.search, Qt::CaseInsensitive) == 0;
            if (r->type() == AbstractResource::Technical && filter.state != AbstractResource::Upgradeable && !matchById) {
                continue;
            }
            if (r->state() < filter.state)
                continue;

            if (!filter.extends.isEmpty() && !r->extends().contains(filter.extends))
                continue;

            if (!filter.mimetype.isEmpty() && !r->mimetypes().contains(filter.mimetype))
                continue;

            if (filter.search.isEmpty() || matchById) {
                rest += r;
            } else if (r->name().contains(filter.search, Qt::CaseInsensitive)) {
                prioritary += r;
            } else if (r->comment().contains(filter.search, Qt::CaseInsensitive)) {
                rest += r;
            }
        }
        auto f = [this](AbstractResource* l, AbstractResource* r) { return flatpakResourceLessThan(l,r); };
        std::sort(rest.begin(), rest.end(), f);
        std::sort(prioritary.begin(), prioritary.end(), f);
        rest = prioritary + rest;
        if (!rest.isEmpty())
            Q_EMIT stream->resourcesFound(rest);
        stream->finish();
    };
```

#### AUTO 


```{c}
auto release = appdata.releases().constFirst();
```

#### AUTO 


```{c}
auto it = resources.constBegin() + 1, itEnd = resources.constEnd();
```

#### AUTO 


```{c}
auto refs = fw->result();
```

#### AUTO 


```{c}
const auto filtered = kFilter<KNSCore::EntryInternal::List>(entries, [](const KNSCore::EntryInternal& entry){ return entry.isValid(); });
```

#### AUTO 


```{c}
const auto resources = kFilter<QVector<AbstractResource*>>(resourcesByPackageNames<QVector<AbstractResource*>>(ids), [](AbstractResource* res){ return !qobject_cast<PackageKitResource*>(res)->extendsItself(); });
```

#### AUTO 


```{c}
auto resource = new FlatpakResource(asComponent, preferredInstallation(), this);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const KNSCore::EntryInternal &entry) {
        return resourceForEntry(entry);
    }
```

#### AUTO 


```{c}
auto it = resources.begin();
```

#### LAMBDA EXPRESSION 


```{c}
[] {qCDebug(LIBDISCOVER_BACKEND_LOG) << "."; }
```

#### AUTO 


```{c}
auto *notification = new KNotification(QStringLiteral("OfflineUpdateFailed"), KNotification::Persistent);
```

#### AUTO 


```{c}
const auto ourPackageNames = allPackageNames();
```

#### RANGE FOR STATEMENT 


```{c}
for(auto res: higher) {
            res->setState(AbstractResource::None);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, localfile](const QVector<AbstractResource *> &res) {
                if (res.count() == 1) {
                    emit openApplicationInternal(res.first());
                } else {
                    QMimeDatabase db;
                    auto mime = db.mimeTypeForUrl(localfile);
                    auto fIsFlatpakBackend = [](AbstractResourcesBackend *backend) {
                        return backend->metaObject()->className() == QByteArray("FlatpakBackend");
                    };
                    if (mime.name().startsWith(QLatin1String("application/vnd.flatpak"))
                        && !kContains(ResourcesModel::global()->backends(), fIsFlatpakBackend)) {
                        openApplication(QUrl(QStringLiteral("appstream://org.kde.discover.flatpak")));
                        showPassiveNotification(i18n("Cannot interact with flatpak resources without the flatpak backend %1. Please install it first.",
                                                     localfile.toDisplayString()));
                    } else {
                        openMode(QStringLiteral("Browsing"));
                        showPassiveNotification(i18n("Could not open %1", localfile.toDisplayString()));
                    }
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto installation : qAsConst(m_installations)) {
            // Load local updates, comparing current and latest commit
            loadLocalUpdates(installation);

            if (g_cancellable_is_cancelled(m_cancellable))
                break;
        }
```

#### AUTO 


```{c}
auto it = new QStandardItem(i18n("Snap"));
```

#### AUTO 


```{c}
auto job = m_socket.snapAction(app->packageName(), SnapSocket::Remove);
```

#### AUTO 


```{c}
auto it = reviews.begin();
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto& snap: snaps) {
            const auto snapObj = snap.toObject();
            const auto snapid = snapObj.value(QLatin1String("name")).toString();
            SnapResource* res = m_resources.value(snapid);
            if (!res) {
                res = new SnapResource(snapObj, state, this);
                Q_ASSERT(res->packageName() == snapid);
                resources += res;
            }
            ret += res;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[resolved, toResolve, stream] () {
                    if (!resolved.isEmpty())
                        Q_EMIT stream->resourcesFound(resolved);

                    if (toResolve.isEmpty())
                        stream->finish();
            }
```

#### AUTO 


```{c}
auto res = new FwupdResource(device, this);
```

#### LAMBDA EXPRESSION 


```{c}
[this, p] (int exitCode, QProcess::ExitStatus exitStatus) {
            if (exitCode != 0) {
                backend()->passiveMessage(i18n("Failed to start '%1'", KShell::joinArgs(p->arguments())));
            }
	    p->deleteLater();
        }
```

#### AUTO 


```{c}
const auto resources = getAllResources(m_backend);
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &pkgid) { return PackageKit::Daemon::packageName(pkgid); }
```

#### AUTO 


```{c}
auto &elem
```

#### LAMBDA EXPRESSION 


```{c}
[this, entryid, stream, providerid]() {
        m_responsePending = true;
        m_engine->fetchEntryById(entryid);
        m_onePage = false;
        connect(m_engine, &KNSCore::Engine::signalError, stream, &ResultsStream::finish);
        connect(m_engine, &KNSCore::Engine::signalEntryDetailsLoaded, stream, [this, stream, entryid, providerid](const KNSCore::EntryInternal &entry) {
            if (entry.uniqueId() == entryid && providerid == QUrl(entry.providerId()).host()) {
                Q_EMIT stream->resourcesFound({resourceForEntry(entry)});
            } else
                qWarning() << "found invalid" << entryid << entry.uniqueId() << providerid << QUrl(entry.providerId()).host();
            m_responsePending = false;
            QTimer::singleShot(0, this, &KNSBackend::availableForQueries);
            stream->finish();
        });
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Category* cat: m_rootCategories) {
        Category* ret = recFindCategory(cat, name);
        if(ret)
            return ret;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](){
            m_transaction->setStatus(Transaction::CommittingStatus);
            m_transaction->slotProgressingChanged();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        setResponsePending(false);
    }
```

#### AUTO 


```{c}
auto action = new OneTimeAction(
        [this, url]() {
            AbstractResourcesBackend::Filters f;
            f.resourceUrl = url;
            auto stream = new StoredResultsStream({ResourcesModel::global()->search(f)});
            connect(stream, &StoredResultsStream::finished, this, [this, url, stream]() {
                const auto res = stream->resources();
                if (res.count() == 1) {
                    emit openApplicationInternal(res.first());
                } else {
                    setRootObjectProperty("defaultStartup", true);
                    showPassiveNotification(i18n("Couldn't open %1", url.toDisplayString()));
                }
            });
        }
        , this);
```

#### LAMBDA EXPRESSION 


```{c}
[menu](UpgradeAction* a) {
        QAction* action = new QAction(a->description(), menu);
        QObject::connect(action, &QAction::triggered, a, &UpgradeAction::trigger);
        menu->addAction(action);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[resources, this]() {
        if (!resources.isEmpty())
            Q_EMIT resourcesFound(resources);
        finish();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto t: transactions()) {
        allProgresses += t->progress();
    }
```

#### AUTO 


```{c}
auto& resPos = m_packages.packages[component.id()];
```

#### AUTO 


```{c}
auto item = itemFromIndex(index);
```

#### LAMBDA EXPRESSION 


```{c}
[this, installation, fw](){
        g_autoptr(GPtrArray) refs = fw->result();
        if (refs)
            onFetchUpdatesFinished(installation, refs);
        fw->deleteLater();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, p] (int code) {
                p->deleteLater();
                if (code != 0) {
                    qWarning() << "login failed... code:" << code << p->readAll();
                    Q_EMIT passiveMessage(m_request->errorString());
                    setStatus(DoneWithErrorStatus);
                    return;
                }
                const auto doc = QJsonDocument::fromJson(p->readAllStandardOutput());
                const auto result = doc.object();

                const auto macaroon = result[QStringLiteral("macaroon")].toString();
                const auto discharges = kTransform<QStringList>(result[QStringLiteral("discharges")].toArray(), [](const QJsonValue& val) { return val.toString(); });
                static_cast<SnapBackend*>(m_app->backend())->client()->setAuthData(new QSnapdAuthData(macaroon, discharges));
                m_request->runAsync();
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &/*packageID*/, const QStringList &filenames) {
        const auto allServices = QStandardPaths::locateAll(QStandardPaths::ApplicationsLocation, m_appdata.id());
        if (!allServices.isEmpty()) {
            const auto packageServices = kFilter<QStringList>(allServices, [filenames](const QString &file) { return filenames.contains(file); });
            QProcess::startDetached(QStringLiteral(CMAKE_INSTALL_FULL_LIBEXECDIR_KF5 "/discover/runservice"), {packageServices});
        } else {
            const QStringList exes = m_appdata.provided(AppStream::Provided::KindBinary).items();
            const auto packageExecutables = kFilter<QStringList>(allServices, [filenames](const QString &exe) { return filenames.contains(QLatin1Char('/') + exe); });
            if (packageExecutables.isEmpty()) {
                qWarning() << "Could not find any executables" << exes << filenames;
                return;
            }
            QProcess::startDetached(exes.constFirst());
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[file, reply](){
            file->write(reply->readAll());
        }
```

#### AUTO 


```{c}
const auto snaps = jobResult(socket.snaps()).toArray();
```

#### AUTO 


```{c}
auto pkgDeps = (*packageDependencies);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &error) { this->setFetching(false); qWarning() << "kns error" << objectName() << error; }
```

#### AUTO 


```{c}
const auto destRow = row + (delta>0? delta : delta);
```

#### AUTO 


```{c}
auto action = new OneTimeAction(
        [this]() {
            bool found = DiscoverBackendsFactory::hasRequestedBackends();
            const auto backends = ResourcesModel::global()->backends();
            for (auto b : backends)
                found |= b->hasApplications();

            if (!found)
                Q_EMIT openErrorPage(i18n("No application back-ends found, please report to your distribution."));
        },
        this);
```

#### AUTO 


```{c}
const auto backends = f.allBackends();
```

#### LAMBDA EXPRESSION 


```{c}
[this, localfile]() {
            auto res = ResourcesModel::global()->resourceForFile(localfile);
            qDebug() << "all initialized..." << res;
            if (res) {
                emit openApplicationInternal(res);
            } else {
                QMimeDatabase db;
                auto mime = db.mimeTypeForUrl(localfile);
                if (mime.name().startsWith(QLatin1String("application/vnd.flatpak"))) {
                    openApplication(QUrl(QLatin1String("appstream://org.kde.discover.flatpak")));
                    showPassiveNotification(i18n("Cannot interact with flatpak resources without the flatpak backend %1. Please install it first.", localfile.toDisplayString()));
                } else {
                    setRootObjectProperty("defaultStartup", true);
                    showPassiveNotification(i18n("Couldn't open %1", localfile.toDisplayString()));
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const AppStream::Component &dc : distroComponents) {
            const auto releases = dc.releases();
            for (auto r : releases) {
                int cmp = AppStream::Utils::vercmpSimple(r.version(), AppStreamIntegration::global()->osRelease()->versionId());
                if (cmp == 0) {
                    // Ignore (likely) empty date_eol entries that are parsed as the UNIX Epoch
                    if (r.timestampEol().isNull() || r.timestampEol().toSecsSinceEpoch() == 0) {
                        continue;
                    }
                    if (r.timestampEol() < QDateTime::currentDateTime()) {
                        const QString releaseDate = QLocale().toString(r.timestampEol());
                        Q_EMIT inlineMessage(InlineMessageType::Warning,
                                             QStringLiteral("dialog-warning"),
                                             i18nc("%1 is the date as formatted by the locale",
                                                   "Your operating system ended support on %1. Consider upgrading to a supported version.",
                                                   releaseDate));
                    }
                }
            }
        }
```

#### AUTO 


```{c}
auto ref
```

#### LAMBDA EXPRESSION 


```{c}
[backend, stream, flatpakrepoUrl]() {
            const auto res = stream->resources();
            if (!res.isEmpty()) {
                Q_ASSERT(res.count() == 1);
                backend->installApplication(res.first());
            } else {
                backend->passiveMessage(i18n("Could not add the source %1", flatpakrepoUrl.toDisplayString()));
            }
        }
```

#### AUTO 


```{c}
auto res
```

#### LAMBDA EXPRESSION 


```{c}
[this, trans](){ removeTransaction(trans); }
```

#### RANGE FOR STATEMENT 


```{c}
for(Category* nc : newcat->subCategories())
                    addSubcategory(c->m_subCategories, nc);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &errorMessage) {
        Q_EMIT passiveMessage(errorMessage);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&notifier]() {
        notifier.showDiscoverUpdates();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](){ qDebug() << "action triggered!"; }
```

#### AUTO 


```{c}
const auto pkgs = resourcesByPackageName(pkgname);
```

#### LAMBDA EXPRESSION 


```{c}
[this, category]() {
            Category* cat = CategoryModel::global()->findCategoryByName(category);
            if (cat) {
                emit listCategoryInternal(cat);
            } else {
                openMode(QStringLiteral("Browsing"));
                showPassiveNotification(i18n("Could not find category '%1'", category));
            }
        }
```

#### AUTO 


```{c}
const auto runtimeInfo = resource->runtime().split(QLatin1Char('/'));
```

#### RANGE FOR STATEMENT 


```{c}
for(auto &backend: backends) {
        if (!backend.endsWith(QLatin1String("-backend")))
            backend.append(QLatin1String("-backend"));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &alt : alts) {
                if (QString::compare(alt, name, Qt::CaseInsensitive)==0 || QString::compare(alt, nameWithDesktop, Qt::CaseInsensitive)==0) {
                    resources << res;
                    break;
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this, obj](const QList<QQmlError> &warnings) {
        foreach(const QQmlError &warning, warnings) {
            if (warning.url().path().endsWith(QLatin1String("DiscoverTest.qml"))) {
                qWarning() << "Test failed!" << warnings;
                qGuiApp->exit(1);
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, fw]() {
        const auto data = fw->result();
        fw->deleteLater();

        if (!data.correct && m_packages.packages.isEmpty()) {
            QTimer::singleShot(0, this, [this]() {
                Q_EMIT passiveMessage(i18n("Please make sure that Appstream is properly set up on your system"));
            });
        }
        for (const auto &component : data.components) {
            addComponent(component);
        }

        if (data.components.isEmpty()) {
            qCDebug(LIBDISCOVER_BACKEND_LOG) << "empty appstream db";
            if (PackageKit::Daemon::backendName() == QLatin1String("aptcc") || PackageKit::Daemon::backendName().isEmpty()) {
                checkForUpdates();
            }
        }
        if (!m_appstreamInitialized) {
            m_appstreamInitialized = true;
            Q_EMIT loadedAppStream();
        }
        acquireFetching(false);

        const QList<AppStream::Component> distroComponents = m_appdata->componentsById(AppStream::Utils::currentDistroComponentId());
        if (distroComponents.isEmpty()) {
            qWarning() << "no component found for" << AppStream::Utils::currentDistroComponentId();
        }
        for (const AppStream::Component &dc : distroComponents) {
            const auto releases = dc.releases();
            for (auto r : releases) {
                int cmp = AppStream::Utils::vercmpSimple(r.version(), AppStreamIntegration::global()->osRelease()->versionId());
                if (cmp == 0) {
                    // Ignore (likely) empty date_eol entries that are parsed as the UNIX Epoch
                    if (r.timestampEol().isNull() || r.timestampEol().toSecsSinceEpoch() == 0) {
                        continue;
                    }
                    if (r.timestampEol() < QDateTime::currentDateTime()) {
                        const QString releaseDate = QLocale().toString(r.timestampEol());
                        Q_EMIT inlineMessage(InlineMessageType::Warning,
                                             QStringLiteral("dialog-warning"),
                                             i18nc("%1 is the date as formatted by the locale",
                                                   "Your operating system ended support on %1. Consider upgrading to a supported version.",
                                                   releaseDate));
                    }
                }
            }
        }
    }
```

#### AUTO 


```{c}
auto roles = roleNames();
```

#### RANGE FOR STATEMENT 


```{c}
for (TransactionListener *listener : m_transactions) {
        if(listener->application() == app) {
            toRemove = listener;
            break;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const QString &/*pkgid*/, const QStringList & files) {
        const auto execIdx = kIndexOf(files, [](const QString& file) { return file.endsWith(QLatin1String(".desktop")) && file.contains(QLatin1String("usr/share/applications")); });
        if (execIdx >= 0) {
            m_exec = files[execIdx];

            // sometimes aptcc provides paths like usr/share/applications/steam.desktop
            if (!m_exec.startsWith(QLatin1Char('/'))) {
                m_exec.prepend(QLatin1Char('/'));
            }
        } else {
            qWarning() << "could not find an executable desktop file for" << m_path << "among" << files;
        }
    }
```

#### AUTO 


```{c}
auto &current = ret[installation];
```

#### AUTO 


```{c}
const auto inSourcesModel = "InSourcesModel";
```

#### RANGE FOR STATEMENT 


```{c}
for(const QVariant& act: theActions) {
        QAction* action = qobject_cast<QAction*>(act.value<QObject*>());
        if (action->toolTip() == id) {
            action->setEnabled(false);
            action->setVisible(false);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[res, engine]() {
                engine->uninstall(res->entry());
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this, error](uint timeSince) {
        if (timeSince > 3600)
            checkForUpdates();
    }
```

#### AUTO 


```{c}
const auto model = sidx.model();
```

#### AUTO 


```{c}
auto remotes = flatpak_installation_list_remotes(installation, m_cancellable, nullptr);
```

#### LAMBDA EXPRESSION 


```{c}
[this, stream](const QVector<AbstractResource*>& resources) {
                stream->setProperty("resources", QVariant::fromValue<QVector<AbstractResource*>>(resources));
            }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto a : container) {
        ret.push_back(a);
    }
```

#### AUTO 


```{c}
const auto compIt = m_sources->item(idx);
```

#### LAMBDA EXPRESSION 


```{c}
[this, stream, searchText]() {
        m_engine->setSearchTerm(searchText);
        m_engine->requestData(0, 100);
        m_responsePending = true;
        m_page = 0;
        connect(this, &KNSBackend::receivedResources, stream, &ResultsStream::resourcesFound);
        connect(this, &KNSBackend::searchFinished, stream, &ResultsStream::deleteLater);
        connect(this, &KNSBackend::startingSearch, stream, &ResultsStream::deleteLater);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Category* cat: qAsConst(done))
        ret += QVariant::fromValue<QObject*>(cat);
```

#### AUTO 


```{c}
auto applicationCategory = new Category(i18n("Applications"), QStringLiteral("applications-internet"), filters, backendName, { actualCategory }, QUrl(), false);
```

#### AUTO 


```{c}
auto action = new OneTimeAction(
        [this, localfile]() {
            auto res = ResourcesModel::global()->resourceForFile(localfile);
            qCDebug(DISCOVER_LOG) << "all initialized..." << res;
            if (res) {
                emit openApplicationInternal(res);
            } else {
                QMimeDatabase db;
                auto mime = db.mimeTypeForUrl(localfile);
                auto fIsFlatpakBackend = [](AbstractResourcesBackend* backend) { return backend->metaObject()->className() == QByteArray("FlatpakBackend"); };
                if (mime.name().startsWith(QLatin1String("application/vnd.flatpak")) && !kContains(ResourcesModel::global()->backends(), fIsFlatpakBackend)) {
                    openApplication(QUrl(QLatin1String("appstream://org.kde.discover.flatpak")));
                    showPassiveNotification(i18n("Cannot interact with flatpak resources without the flatpak backend %1. Please install it first.", localfile.toDisplayString()));
                } else {
                    setRootObjectProperty("defaultStartup", true);
                    showPassiveNotification(i18n("Couldn't open %1", localfile.toDisplayString()));
                }
            }
        }
        , this);
```

#### LAMBDA EXPRESSION 


```{c}
[this](AbstractResource *l, AbstractResource *r) {
        return flatpakResourceLessThan(l, r);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, stream, url] () {
                QVector<AbstractResource*> resources;
                foreach(FlatpakResource* res, m_resources) {
                    if (QString::compare(res->appstreamId(), url.host(), Qt::CaseInsensitive)==0)
                        resources << res;
                }
                auto f = [this](AbstractResource* l, AbstractResource* r) { return flatpakResourceLessThan(l,r); };
                std::sort(resources.begin(), resources.end(), f);

                if (!resources.isEmpty())
                    Q_EMIT stream->resourcesFound(resources);
                stream->finish();
            }
```

#### LAMBDA EXPRESSION 


```{c}
[filenames](const QString &exe) {
                return filenames.contains(QLatin1Char('/') + exe);
            }
```

#### AUTO 


```{c}
auto r = new ResultsStream(QLatin1String("KNS-search-") + name());
```

#### RANGE FOR STATEMENT 


```{c}
for(auto item : m_updateItems) {
                item->setProgress(0);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QPair<FilterType, QString>& filter : m_orFilters) {
            if(shouldFilter(res, filter)) {
                orValue = true;
                break;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &error) {
        if(error == QLatin1Literal("All categories are missing")) {
            markInvalid(error);
        }
        m_responsePending = false;
        Q_EMIT searchFinished();
        Q_EMIT availableForQueries();
        this->setFetching(false);
        qWarning() << "kns error" << objectName() << error;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, t](){
            auto restart = t->property("requireRestart");
            if (!restart.isNull())
                requireRestartNotification(PackageKit::Transaction::Restart(restart.toInt()));
            m_transactions.remove(t->tid().path());
            t->deleteLater();
        }
```

#### AUTO 


```{c}
auto transaction = PackageKit::Daemon::global()->repoEnable(item->text(), value.toInt() == Qt::Checked);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &token : licenses) {
        QString license = token;
        license.remove(0, 1); // tokenize prefixes with an @ for some reason
        if (!AppStream::SPDX::isLicenseId(license))
            continue;
        ret.append(QJsonObject{{QStringLiteral("name"), license}, {QStringLiteral("url"), {AppStream::SPDX::licenseUrl(license)}}});
    }
```

#### AUTO 


```{c}
auto it = m_resources.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto backend : backends) {
        streams << backend->search({});
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractResource * res : m_packages.values()) {
        if (!res->isTechnical() && res->canUpgrade())
            resources << res;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &file){
        auto service = PackageKitBackend::locateService(file);
        if (!service.isEmpty())
            m_actions += createActionForService(service, this);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, url, stream]() {
                const auto res = stream->resources();
                if (res.count() >= 1) {
                    emit openApplicationInternal(res.first());
                } else {
                    setRootObjectProperty("defaultStartup", true);
                    showPassiveNotification(i18n("Couldn't open %1", url.toDisplayString()));
                }
            }
```

#### AUTO 


```{c}
const auto components = m_appdata->components();
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractResource *res : m_toUpgrade) {
        if (auto upgrade = dynamic_cast<SystemUpgrade *>(res)) {
            ret += upgrade->size();
            continue;
        }

        PackageKitResource *app = qobject_cast<PackageKitResource *>(res);
        QString pkgname = app->packageName();
        if (!donePkgs.contains(pkgname)) {
            donePkgs.insert(pkgname);
            ret += app->size();
        }
    }
```

#### AUTO 


```{c}
auto iter = changes.constBegin();
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
                if (m_responsePending) {
                    // Slot already taken, will need to wait again
                    return false;
                }

                m_onePage = true;
                setResponsePending(true);
                m_engine->checkForUpdates();
                return true;
            }
```

#### CONST EXPRESSION 


```{c}
constexpr int status_sort_magic = (QApt::Package::Installed |
                                   QApt::Package::New);
```

#### AUTO 


```{c}
auto prop = Rating::staticMetaObject.property(idx);
```

#### AUTO 


```{c}
auto futureWatcher = new QFutureWatcher<FlatpakRemoteRef *>(this);
```

#### AUTO 


```{c}
auto comps = source->componentsByName(name);
```

#### AUTO 


```{c}
auto engine = res->knsBackend()->engine();
```

#### AUTO 


```{c}
const auto otpMode = reply->data()[QLatin1String("otpMode")].toBool();
```

#### AUTO 


```{c}
auto remote = flatpak_installation_get_remote_by_name(m_systemInstallation, resource->flatpakName().toStdString().c_str(), cancellable, nullptr);
```

#### RANGE FOR STATEMENT 


```{c}
for(AbstractSourcesBackend* b: m_sources) {
        if (b->name() == status) {
            ret = b;
            break;
        }
    }
```

#### AUTO 


```{c}
auto f = [this, stream, filter] {
            const auto toResolve = kFilter<QVector<AbstractResource*>>(m_packages.packages, needsResolveFilter);

            auto installedAndNameFilter = [filter] (AbstractResource *res) {
                return res->state() >= AbstractResource::Installed && (res->name().contains(filter.search) || res->packageName() == filter.search);
            };
            if (!toResolve.isEmpty()) {
                resolvePackages(kTransform<QStringList>(toResolve, [] (AbstractResource* res) { return res->packageName(); }));
                connect(m_resolveTransaction, &PKResolveTransaction::allFinished, this, [stream, toResolve, installedAndNameFilter] {
                    const auto resolved = kFilter<QVector<AbstractResource*>>(toResolve, installedAndNameFilter);
                    if (!resolved.isEmpty())
                        Q_EMIT stream->resourcesFound(resolved);
                    stream->finish();
                });
            }

            const auto resolved = kFilter<QVector<AbstractResource*>>(m_packages.packages, installedAndNameFilter);
            if (!resolved.isEmpty()) {
                QTimer::singleShot(0, this, [resolved, toResolve, stream] () {
                    if (!resolved.isEmpty())
                        Q_EMIT stream->resourcesFound(resolved);

                    if (toResolve.isEmpty())
                        stream->finish();
            });
            }
        };
```

#### AUTO 


```{c}
const auto result = doc.object();
```

#### AUTO 


```{c}
const auto release = m_appdata.releases().constFirst();
```

#### LAMBDA EXPRESSION 


```{c}
[this](){
        const auto objs = m_engine->rootObjects();
        for(auto o: objs)
            delete o;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&it] (const QString& id) {
                        return it.key().compare(id, Qt::CaseInsensitive) == 0 ||
                              (id.endsWith(QLatin1String(".desktop")) && id.compare(it.key()+QLatin1String(".desktop"), Qt::CaseInsensitive) == 0);
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &path : locations) {
            QDirIterator dirIt(path, {QStringLiteral("*.knsrc")}, QDir::Files);
            for (; dirIt.hasNext();) {
                dirIt.next();

                if (files.contains(dirIt.fileName()))
                    continue;
                files << dirIt.fileName();

                auto bk = new KNSBackend(parent, QStringLiteral("plasma"), dirIt.filePath());
                if (bk->isValid())
                    ret += bk;
                else
                    delete bk;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto backend : qAsConst(m_backends)) {
                      sum += backend->fetchingUpdatesProgress();
                  }
```

#### AUTO 


```{c}
auto resource = getAppForInstalledRef(installation, ref);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            Q_EMIT downloadSpeedChanged(downloadSpeed());
        }
```

#### AUTO 


```{c}
const auto match = it.next();
```

#### AUTO 


```{c}
auto f = [menu, &notifier]() {
        auto refreshAction = menu->addAction(QIcon::fromTheme(QStringLiteral("view-refresh")), i18n("Restart..."));
        QObject::connect(refreshAction, &QAction::triggered, &notifier, &DiscoverNotifier::recheckSystemUpdateNeeded);
    };
```

#### AUTO 


```{c}
auto packageIter = failReason.constBegin();
```

#### LAMBDA EXPRESSION 


```{c}
[this](AbstractResource* l, AbstractResource* r) { return flatpakResourceLessThan(l, r); }
```

#### AUTO 


```{c}
const auto mime = db.mimeTypeForUrl(url);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &name : categoryFiles) {
            const QVector<Category *> cats = reader.loadCategoriesPath(name);

            if (ret.isEmpty()) {
                ret = cats;
            } else {
                for (Category *c : cats)
                    Category::addSubcategory(ret, c);
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[objectName]() { qDebug() << "stream took really long" << objectName; }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() -> QVariant {
            const auto iconPath = m_snap->icon();
            if (iconPath.isEmpty())
                return QStringLiteral("package-x-generic");

            if (!iconPath.startsWith(QLatin1Char('/')))
                return QUrl(iconPath);

            auto req = client()->getIcon(packageName());
            connect(req, &QSnapdGetIconRequest::complete, this, &SnapResource::gotIcon);
            req->runAsync();
            return {};
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](AbstractResource *r) {
                                         return r;
                                     }
```

#### AUTO 


```{c}
auto pkr = qobject_cast<PackageKitResource*>(resource());
```

#### LAMBDA EXPRESSION 


```{c}
[](Category* cat) {return QVariant::fromValue<QObject*>(cat); }
```

#### LAMBDA EXPRESSION 


```{c}
[](const AbstractResource *a, const AbstractResource *b) {
        return a->name() < b->name();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractResourcesBackend *backend : backends) {
        if(!m_appBackend &&
            backend->metaObject()->className()==QLatin1String("ApplicationBackend"))
        {
            m_appBackend = backend;
            connect(m_appBackend, SIGNAL(fetchingChanged()), SLOT(aptFetchingChanged()));
            connect(m_appBackend, SIGNAL(sourcesEditorFinished()), SLOT(sourcesEditorFinished()));
            populateViews();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](QAction* action){ return action->isVisible(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this, localfile]() {
            auto res = ResourcesModel::global()->resourceForFile(localfile);
            qDebug() << "all initialized..." << res;
            if (res) {
                emit openApplicationInternal(res);
            } else {
                setRootObjectProperty("defaultStartup", true);
                showPassiveNotification(i18n("Couldn't open %1", localfile.toDisplayString()));
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, url]() {
            AbstractResourcesBackend::Filters f;
            f.resourceUrl = url;
            auto stream = new StoredResultsStream({ResourcesModel::global()->search(f)});
            connect(stream, &StoredResultsStream::finished, this, [this, url, stream]() {
                const auto res = stream->resources();
                if (res.count() >= 1) {
                    emit openApplicationInternal(res.first());
                } else {
                    setRootObjectProperty("defaultStartup", true);
                    showPassiveNotification(i18n("Couldn't open %1", url.toDisplayString()));
                }
            });
        }
```

#### AUTO 


```{c}
auto res = createDevice(device);
```

#### AUTO 


```{c}
auto installation = FLATPAK_INSTALLATION(g_ptr_array_index(installations, i));
```

#### LAMBDA EXPRESSION 


```{c}
[=]()
                            {
                                if(fwupd_client_modify_remote(m_backend->backend->client,fwupd_remote_get_id(remote),QString(QLatin1String("Enabled")).toUtf8().constData(),(QString(QLatin1String("true")).toUtf8().constData()),nullptr,nullptr))
                                    item->setData(value, role);
                            }
```

#### LAMBDA EXPRESSION 


```{c}
[resources, this]() {
            if (!resources.isEmpty())
                setResources(resources);
            finish();
        }
```

#### AUTO 


```{c}
const auto& potentialSubCat
```

#### AUTO 


```{c}
auto idx = kIndexOf(m_backends, [name](AbstractResourcesBackend *b) {
        return b->hasApplications() && b->name() == name;
    });
```

#### LAMBDA EXPRESSION 


```{c}
[](QQmlEngine*, QJSEngine*) -> QObject* {return TransactionModel::global();}
```

#### LAMBDA EXPRESSION 


```{c}
[](const AppStream::Component &comp) {
                return comp.id();
            }
```

#### LAMBDA EXPRESSION 


```{c}
[](UpdateItem *a, UpdateItem *b) {
        return a->name() < b->name();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](){ transactionChanged(ProgressRole); Q_EMIT progressChanged(); }
```

#### AUTO 


```{c}
auto discoverAction = menu->addAction(QIcon::fromTheme(QStringLiteral("plasmadiscover")), i18n("Open Discover�"));
```

#### LAMBDA EXPRESSION 


```{c}
[this, stream, filter] () {
            const QList<AppStream::Component> components = m_appdata->search(filter.search);
            const QStringList ids = kTransform<QStringList>(components, [](const AppStream::Component& comp) { return comp.id(); });
            if (!ids.isEmpty()) {
                const auto resources = kFilter<QVector<AbstractResource*>>(resourcesByPackageNames<QVector<AbstractResource*>>(ids), [](AbstractResource* res){ return !qobject_cast<PackageKitResource*>(res)->extendsItself(); });
                Q_EMIT stream->resourcesFound(resources);
            }

            PackageKit::Transaction * tArch = PackageKit::Daemon::resolve(filter.search, PackageKit::Transaction::FilterArch);
            connect(tArch, &PackageKit::Transaction::package, this, &PackageKitBackend::addPackageArch);
            connect(tArch, &PackageKit::Transaction::package, stream, [stream](PackageKit::Transaction::Info /*info*/, const QString &packageId){
                stream->setProperty("packageId", packageId);
            });
            connect(tArch, &PackageKit::Transaction::finished, stream, [stream, ids, this](PackageKit::Transaction::Exit status) {
                getPackagesFinished();
                if (status == PackageKit::Transaction::Exit::ExitSuccess) {
                    const auto packageId = stream->property("packageId");
                    if (!packageId.isNull()) {
                        const auto res = resourcesByPackageNames<QVector<AbstractResource*>>({PackageKit::Daemon::packageName(packageId.toString())});
                        Q_EMIT stream->resourcesFound(kFilter<QVector<AbstractResource*>>(res, [ids](AbstractResource* res){ return !ids.contains(res->appstreamId()); }));
                    }
                }
                stream->finish();
            }, Qt::QueuedConnection);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, msg](){
            Q_EMIT passiveMessage(msg);
        }
```

#### AUTO 


```{c}
auto f = [this, stream, filter] () {
        QVector<AbstractResource*> ret;
        foreach(auto r, m_resources) {
            const bool matchById = filter.search.compare(r->appstreamId(), Qt::CaseInsensitive) == 0;
            if (r->type() == AbstractResource::Technical && filter.state != AbstractResource::Upgradeable && !matchById) {
                continue;
            }
            if (r->state() < filter.state)
                continue;

            if (!filter.extends.isEmpty() && !r->extends().contains(filter.extends))
                continue;

            if (filter.search.isEmpty() || r->name().contains(filter.search, Qt::CaseInsensitive) || r->comment().contains(filter.search, Qt::CaseInsensitive) || matchById)
            {
                ret += r;
            }
        }
        auto f = [this](AbstractResource* l, AbstractResource* r) { return flatpakResourceLessThan(l,r); };
        std::sort(ret.begin(), ret.end(), f);
        if (!ret.isEmpty())
            Q_EMIT stream->resourcesFound(ret);
        stream->finish();
    };
```

#### AUTO 


```{c}
const auto modes = mainWindow->modes();
```

#### AUTO 


```{c}
auto bk = qobject_cast<AbstractSourcesBackend *>(m->index(0, 0).data(SourcesModel::SourcesBackend).value<QObject *>());
```

#### LAMBDA EXPRESSION 


```{c}
[this](const KNSCore::EntryInternal &entry, KNSCore::EntryInternal::EntryEvent event) {
            switch (event) {
            case KNSCore::EntryInternal::StatusChangedEvent:
                anEntryChanged(entry);
                break;
            case KNSCore::EntryInternal::DetailsLoadedEvent:
            case KNSCore::EntryInternal::AdoptedEvent:
            case KNSCore::EntryInternal::UnknownEvent:
            default:
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Transaction *trans : qAsConst(m_transactions)) {
        if (trans->resource() == resource) {
            ret = trans;
            break;
        }
    }
```

#### AUTO 


```{c}
auto licenseGroup = group.group(eulaID);
```

#### AUTO 


```{c}
const auto linkInfo = m_entry.downloadLinkInformationList();
```

#### LAMBDA EXPRESSION 


```{c}
[this, fetchingChangedTimer] {
        // Q_ASSERT(isFetching() != fetchingChangedTimer->isActive());
        if (isFetching())
            fetchingChangedTimer->start();
        else
            fetchingChangedTimer->stop();

        Q_EMIT fetchingUpdatesProgressChanged();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](AbstractResourcesBackend* b) {return QVariant::fromValue<QObject*>(b);}
```

#### RANGE FOR STATEMENT 


```{c}
for (const KNSCore::Provider::CategoryMetadata &category : categoryMetadatas) {
            for (Category *cat : qAsConst(categories)) {
                if (cat->orFilters().count() > 0 && cat->orFilters().constFirst().second == category.name) {
                    cat->setName(category.displayName);
                    break;
                }
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool) {
                setCancellable(kContains(m_allUpdaters, [](AbstractBackendUpdater *updater) {
                    return updater->isCancelable() && updater->isProgressing();
                }));
            }
```

#### AUTO 


```{c}
auto transaction = PackageKit::Daemon::global()->getRepoList();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QStringView &dir : dirs) {
        if (dir == QLatin1String("xdg-config/kdeglobals:ro")) {
            // Ignore notifying about the global file being visible, since it's intended by design
            continue;
        }

        int separator = dir.lastIndexOf(':');
        const QStringView postfix = separator > 0 ? dir.mid(separator) : QStringView();
        const QStringView symbolicName = dir.left(separator);
        const QString id = translateSymbolicName(symbolicName);
        if ((dir.contains(QLatin1String("home")) || dir.contains(QChar('~')))) {
            if (postfix == QLatin1String(":ro")) {
                homeList << i18n("%1 (read-only)", id);
                home_ro = true;
            } else if (postfix == QLatin1String(":create")) {
                homeList << i18n("%1 (can create files)", id);
                home_cr = true;
            } else {
                homeList << i18n("%1 (read & write) ", id);
                home_rw = true;
            }
            homeAccess = true;
        } else if (!hasHostRW) {
            if (postfix == QLatin1String(":ro")) {
                systemList << i18n("%1 (read-only)", id);
                system_ro = true;
            } else if (postfix == QLatin1String(":create")) {
                systemList << i18n("%1 (can create files)", id);
                system_cr = true;
            } else {
                // Once we have host in rw, no need to list the rest
                if (symbolicName == QLatin1String("host")) {
                    hasHostRW = true;
                    systemList.clear();
                }

                systemList << i18n("%1 (read & write) ", id);
                system_rw = true;
            }
            systemAccess = true;
        }
    }
```

#### AUTO 


```{c}
auto firstTransaction = TransactionModel::global()->transactions().constFirst();
```

#### LAMBDA EXPRESSION 


```{c}
[&filter](const QString &cat) {
                       return filter.category->matchesCategoryName(cat);
                   }
```

#### LAMBDA EXPRESSION 


```{c}
[this, url]() {
            AbstractResourcesBackend::Filters f;
            f.resourceUrl = url;
            auto stream = new StoredResultsStream({ResourcesModel::global()->search(f)});
            connect(stream, &StoredResultsStream::finishedResources, this, [this, url](const QVector<AbstractResource *> &res) {
                if (res.count() >= 1) {
                    emit openApplicationInternal(res.first());
                } else if (url.scheme() == QLatin1String("snap")) {
                    openApplication(QUrl(QStringLiteral("appstream://org.kde.discover.snap")));
                    showPassiveNotification(i18n("Please make sure Snap support is installed"));
                } else {
                    Q_EMIT openErrorPage(i18n("Could not open %1", url.toDisplayString()));
                }
            });
        }
```

#### LAMBDA EXPRESSION 


```{c}
[stream, this, state](SnapJob* job) {
        const auto snaps = job->result().toArray();

        QVector<AbstractResource*> ret;
        QSet<SnapResource*> resources;
        for(const auto& snap: snaps) {
            const auto snapObj = snap.toObject();
            const auto snapid = snapObj.value(QLatin1String("name")).toString();
            SnapResource* res = m_resources.value(snapid);
            if (!res) {
                res = new SnapResource(snapObj, state, this);
                Q_ASSERT(res->packageName() == snapid);
                resources += res;
            }
            ret += res;
        }

        if (!resources.isEmpty()) {
            foreach(SnapResource* res, resources)
                m_resources[res->packageName()] = res;
        }
        if (!ret.isEmpty())
            stream->resourcesFound(ret);
    }
```

#### AUTO 


```{c}
auto sourceIt = sourceById(id);
```

#### LAMBDA EXPRESSION 


```{c}
[this, filter, stream] {
            const auto resources = kTransform<QVector<AbstractResource*>>(m_packages.extendedBy.value(filter.extends), [](AppPackageKitResource* a){ return a; });
            if (!resources.isEmpty()) {
                Q_EMIT stream->setResources(resources);
            }
        }
```

#### AUTO 


```{c}
auto resourceName = [](AbstractResource *a) {
            return a->name();
        };
```

#### AUTO 


```{c}
const auto oldDescription = m_details.description();
```

#### RANGE FOR STATEMENT 


```{c}
for (FilterModel *filterModel : m_filterModels) {
        filterModel->populate();
    }
```

#### AUTO 


```{c}
const auto id = availablePackageId();
```

#### LAMBDA EXPRESSION 


```{c}
[](){
            QCoreApplication::instance()->exit(1);
        }
```

#### AUTO 


```{c}
const auto extendsResources = backend()->resourcesByPackageNames<QVector<AbstractResource*>>(extends());
```

#### LAMBDA EXPRESSION 


```{c}
[](const QSharedPointer<QSnapdSnap> &) {
        return true;
    }
```

#### AUTO 


```{c}
auto f = [this, stream, appstreamIds]() {
                const auto resources = kAppend<QVector<AbstractResource *>>(appstreamIds, [this](const QString &appstreamId) {
                    return resourcesByAppstreamName(appstreamId);
                });
                if (!resources.isEmpty())
                    Q_EMIT stream->resourcesFound(resources);
                stream->finish();
            };
```

#### LAMBDA EXPRESSION 


```{c}
[this, t]() {
            if (t->role() == PackageKit::Transaction::RoleGetUpdates) {
                setupGetUpdatesTransaction(t);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto res : qAsConst(m_resources)) {
            PackageKitResource *app = qobject_cast<PackageKitResource *>(res);
            QString pkgname = app->packageName();
            if (!donePkgs.contains(pkgname)) {
                donePkgs.insert(pkgname);
                ret += app;
            }
        }
```

#### AUTO 


```{c}
const auto locations = QStandardPaths::standardLocations(QStandardPaths::ApplicationsLocation);
```

#### AUTO 


```{c}
const auto backend
```

#### LAMBDA EXPRESSION 


```{c}
[installation, this]() -> GPtrArray * {
        g_autoptr(GError) localError = nullptr;
        if (g_cancellable_is_cancelled(m_cancellable)) {
            qWarning() << "don't issue commands after cancelling";
            return {};
        }
        GPtrArray *refs = flatpak_installation_list_installed_refs_for_update(installation, m_cancellable, &localError);
        if (!refs) {
            qWarning() << "Failed to get list of installed refs for listing updates: " << localError->message;
        }
        return refs;
    }
```

#### AUTO 


```{c}
const auto component = it.value();
```

#### AUTO 


```{c}
auto a = new OneTimeAction(
            [this] {
                fetchUpdateDetails();
            },
            this);
```

#### AUTO 


```{c}
auto discoverAction = menu->addAction(QIcon::fromTheme(QStringLiteral("plasmadiscover")), i18n("Open Discover..."));
```

#### LAMBDA EXPRESSION 


```{c}
[t, &ret] {
            ret = t->status();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            m_refresher = nullptr;
            fetchUpdates();
            acquireFetching(false);
        }
```

#### AUTO 


```{c}
auto res = resourceForEntry(entry);
```

#### LAMBDA EXPRESSION 


```{c}
[backend, stream, flatpakrepoUrl]() {
            const auto res = stream->resources();
            if (!res.isEmpty()) {
                Q_ASSERT(res.count() == 1);
                backend->installApplication(res.first());
            } else {
                Q_EMIT backend->passiveMessage(i18n("Could not add the source %1", flatpakrepoUrl.toDisplayString()));
            }
        }
```

#### AUTO 


```{c}
auto res = qobject_cast<KNSResource *>(app);
```

#### LAMBDA EXPRESSION 


```{c}
[this, r]() {
                m_resources.removeAll(r);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[](PackageKitResource *r) {
                                                                        return r->installedPackageId();
                                                                    }
```

#### LAMBDA EXPRESSION 


```{c}
[&resources](const QVector<AbstractResource *> &res) {
            resources += res;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(Category* c : cats)
                addSubcategory(ret, c);
```

#### RANGE FOR STATEMENT 


```{c}
for (Category *cat : cats) {
        if (res->categoryMatches(cat)) {
            const auto subcats = walkCategories(res, cat->subCategories());
            if (subcats.isEmpty()) {
                ret += cat;
            } else {
                ret += subcats;
            }
        }
    }
```

#### AUTO 


```{c}
auto mKeyBindignsAction = KStandardAction::keyBindings(this, SLOT(configureShortcuts()), this);
```

#### AUTO 


```{c}
auto resources = kFilter<QVector<AbstractResource *>>(m_packages.packages, [](AbstractResource *res) {
                return res->type() != AbstractResource::Technical && !qobject_cast<PackageKitResource *>(res)->isCritical()
                    && !qobject_cast<PackageKitResource *>(res)->extendsItself();
            });
```

#### AUTO 


```{c}
const auto change = m_request->change();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &archive : package->archives()) {
            if (archive.contains(QLatin1String("security"))) {
                securityFound = true;
                break;
            }
        }
```

#### AUTO 


```{c}
auto m_window = new KXmlGuiWindow();
```

#### LAMBDA EXPRESSION 


```{c}
[this, filter, stream] {
            auto resources = kFilter<QVector<AbstractResource *>>(m_packages.packages, [](AbstractResource *res) {
                return res->type() != AbstractResource::Technical && !qobject_cast<PackageKitResource *>(res)->extendsItself();
            });
            stream->setResources(resources);
            stream->finish();
        }
```

#### AUTO 


```{c}
auto a = new OneTimeAction(
            [this] {
                Q_EMIT updatesCountChanged();
            },
            this);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        const auto objs = m_engine->rootObjects();
        for (auto o : objs)
            delete o;
    }
```

#### AUTO 


```{c}
const auto icons = m_appdata.icons();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &e : linkInfo) {
        if (e.isDownloadtypeLink)
            ids << e.id;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto installation : qAsConst(m_installations)) {
        // Load installed applications and update existing resources with info from installed application
        if (!loadInstalledApps(installation)) {
            qWarning() << "Failed to load installed packages from installation" << installation;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, packageDependencies](PackageKit::Transaction::Exit /*status*/) {
        auto pkgDeps = (*packageDependencies);

        for (auto it = pkgDeps.constBegin(), itEnd = pkgDeps.constEnd(); it != itEnd; ++it) {
            const auto resources = resourcesByPackageName(PackageKit::Daemon::packageName(it.key()));
            for(auto resource : resources) {
                auto pkres = qobject_cast<PackageKitResource*>(resource);
                pkres->setDependenciesCount(it.value());
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, resource] (bool success, FlatpakResource *repoResource) {
                    if (success) {
                        installApplication(repoResource);
                    }
                    addResource(resource);
                }
```

#### LAMBDA EXPRESSION 


```{c}
[](AbstractResource* res){ return res->url(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (Application* app : m_appList) {
        ret += app;
    }
```

#### AUTO 


```{c}
const auto resources = resourcesByPackageNames<QVector<AbstractResource*>>(packageNames);
```

#### AUTO 


```{c}
const auto &cat
```

#### AUTO 


```{c}
const auto installation = sourceItem->flatpakInstallation();
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractBackendUpdater *upd : m_updaters) {
        ret += upd->updateSize();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[installation]() -> bool {
        g_autoptr(GCancellable) cancellable = g_cancellable_new();
        g_autoptr(GError) localError = nullptr;
        g_autoptr(GPtrArray) fetchedUpdates = flatpak_installation_list_installed_refs_for_update(installation->m_installation, cancellable, &localError);
        bool hasUpdates = false;

        if (!fetchedUpdates) {
            qWarning() << "Failed to get list of installed refs for listing updates: " << localError->message;
            return false;
        }
        for (uint i = 0; !hasUpdates && i < fetchedUpdates->len; i++) {
            FlatpakInstalledRef *ref = FLATPAK_INSTALLED_REF(g_ptr_array_index(fetchedUpdates, i));
            const QString refName = QString::fromUtf8(flatpak_ref_get_name(FLATPAK_REF(ref)));
            // FIXME right now I can't think of any other filter than this, in FlatpakBackend updates are matched
            // with apps so .Locale/.Debug subrefs are not shown and updated automatically. Also this will show
            // updates for refs we don't show in Discover if appstream metadata or desktop file for them is not found
            if (refName.endsWith(QLatin1String(".Locale")) || refName.endsWith(QLatin1String(".Debug"))) {
                continue;
            }
            hasUpdates = true;
        }
        return hasUpdates;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QVector<AbstractResource*>& resources) {
        addResources(resources);
    }
```

#### AUTO 


```{c}
const auto backends = f.backend(name);
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        showDiscoverUpdates({});
    }
```

#### AUTO 


```{c}
const auto idx = statuses.indexOf(status);
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool fetching) {
        m_updateAction->setEnabled(!fetching);
        fetchingUpdatesProgressChanged();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const AppStream::Component &dc : distroComponents) {
            const auto releases = dc.releases();
            for (auto r : releases) {
                if (AppStream::Utils::vercmpSimple(r.version(), AppStreamIntegration::global()->osRelease()->version()) == 0) {
                    if (r.timestampEol() < QDateTime::currentDateTime()) {
                        const QString releaseDate = QLocale().toString(r.timestampEol());
                        Q_EMIT inlineMessage(InlineMessageType::Warning,
                                             QStringLiteral("dialog-warning"),
                                             i18nc("%1 is the date as formatted by the locale",
                                                   "Your operating system ended support on %1. Consider upgrading to a supported version.",
                                                   releaseDate));
                    }
                }
            }
        }
```

#### AUTO 


```{c}
auto tracker = new KUiServerV2JobTracker(m_sni);
```

#### RANGE FOR STATEMENT 


```{c}
for (BackendNotifierModule* module: m_backends)
        securityCount += module->securityUpdatesCount();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto res: qAsConst(m_resources)) {
            if (resources.contains(res))
                res->setState(AbstractResource::Installed);
            else
                res->setState(AbstractResource::None);
        }
```

#### AUTO 


```{c}
auto cb = [](const char *status, guint progress, gboolean /*estimating*/, gpointer /*user_data*/) {
        qDebug() << "Progress..." << status << progress;
    };
```

#### RANGE FOR STATEMENT 


```{c}
for(auto pkgList : changes.values()) {
        for(QApt::Package* it : pkgList) {
            AbstractResource* res = m_appBackend->resourceByPackageName(it->name());
            if(!res) //If we couldn't find it by its name, try with 
                res = m_appBackend->resourceByPackageName(QString("%1:%2").arg(it->name()).arg(it->architecture()));
            Q_ASSERT(res);
            ret += res;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction* action: highActions) {
        if(!containsAction(action, qobject_cast<QBoxLayout*>(centralWidget()->layout()))) {
            KActionMessageWidget* w = new KActionMessageWidget(action, centralWidget());
            qobject_cast<QBoxLayout*>(centralWidget()->layout())->insertWidget(1, w);
        }
    }
```

#### AUTO 


```{c}
auto pkg = m_packages.packages.value(search);
```

#### LAMBDA EXPRESSION 


```{c}
[t](PackageKit::Transaction::Info info, const QString& packageId) { QMap<PackageKit::Transaction::Info, QStringList> packages = t->property("packages").value<QMap<PackageKit::Transaction::Info, QStringList>>(); packages[info].append(packageId); t->setProperty("packages", qVariantFromValue(packages)); }
```

#### AUTO 


```{c}
auto it=changes.begin();
```

#### LAMBDA EXPRESSION 


```{c}
[state](AbstractResource* res){ return res->state()>=state; }
```

#### LAMBDA EXPRESSION 


```{c}
[](PackageKitResource *r) {
                return r->availablePackageId();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractResource *resource : m_resource->backend()->allResources()) {
            if (!resource)
                continue;

            if (resource->packageName() == addon.name()) {
                addonResource = resource;
                break;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, localfile, stream]() {
                const auto res = stream->resources();
                if (res.count() == 1) {
                    emit openApplicationInternal(res.first());
                } else {
                    QMimeDatabase db;
                    auto mime = db.mimeTypeForUrl(localfile);
                    auto fIsFlatpakBackend = [](AbstractResourcesBackend* backend) { return backend->metaObject()->className() == QByteArray("FlatpakBackend"); };
                    if (mime.name().startsWith(QLatin1String("application/vnd.flatpak")) && !kContains(ResourcesModel::global()->backends(), fIsFlatpakBackend)) {
                        openApplication(QUrl(QLatin1String("appstream://org.kde.discover.flatpak")));
                        showPassiveNotification(i18n("Cannot interact with flatpak resources without the flatpak backend %1. Please install it first.", localfile.toDisplayString()));
                    } else {
                        setRootObjectProperty("defaultStartup", true);
                        showPassiveNotification(i18n("Couldn't open %1", localfile.toDisplayString()));
                    }
                }
            }
```

#### AUTO 


```{c}
auto findTestBackend = [](AbstractResourcesBackend* backend) {
        return backend->name() == QLatin1String("discover_ktexteditor_codesnippets_core.knsrc");
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (auto stream: streams) {
        connect(stream, &ResultsStream::resourcesFound, this, &AggregatedResultsStream::addResults);
        connect(stream, &QObject::destroyed, this, &AggregatedResultsStream::streamDestruction);
        connect(this, &ResultsStream::fetchMore, stream, &ResultsStream::fetchMore);
        m_streams << stream;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Category *subCat : qAsConst(m_subCategories)) {
        if (!categoryLessThan(subCat, cat)) {
            break;
        }
        ++i;
    }
```

#### AUTO 


```{c}
const auto resources = kTransform<QVector<AbstractResource*>>(m_packages.extendedBy.value(filter.extends), [](AppPackageKitResource* a){ return a; });
```

#### LAMBDA EXPRESSION 


```{c}
[categories](const QList< KNSCore::Provider::CategoryMetadata>& categoryMetadatas){
        for (const KNSCore::Provider::CategoryMetadata& category : categoryMetadatas) {
            for (Category* cat : categories) {
                if (cat->orFilters().count() > 0 && cat->orFilters().first().second == category.name) {
                    cat->setName(category.displayName);
                    break;
                }
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto app : m_apps) {
                    qCDebug(LIBDISCOVER_BACKEND_LOG) << "app" << app << app->state() << static_cast<PackageKitResource*>(app)->packages();
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this, stream, source, name] {
                auto comps = source->m_pool->componentsById(name);
                if (comps.isEmpty()) {
                    comps = source->m_pool->componentsByProvided(AppStream::Provided::KindId, name);
                }
                auto resources = kTransform<QVector<AbstractResource *>>(comps, [this, source](const auto &comp) {
                    return resourceForComponent(comp, source);
                });
                stream->resourcesFound(resources);
                stream->finish();
            }
```

#### AUTO 


```{c}
auto sj = new SnapJob();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto installation : m_installations) {
        auto instref = flatpak_installation_get_installed_ref(installation,
                                                              FLATPAK_REF_KIND_RUNTIME,
                                                              runtimeInfo.at(0).toUtf8().constData(),
                                                              runtimeInfo.at(1).toUtf8().constData(),
                                                              runtimeInfo.at(2).toUtf8().constData(),
                                                              m_cancellable,
                                                              nullptr);
        if (instref) {
            return getAppForInstalledRef(installation, instref);
        }
    }
```

#### AUTO 


```{c}
auto sharedConfig = KSharedConfig::openConfig();
```

#### AUTO 


```{c}
const auto refString = QString::fromUtf8(flatpak_ref_format_ref(ref));
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
                            setResponsePending(false);
                        }
```

#### AUTO 


```{c}
auto start = [this, stream, searchText]() {
        // No need to explicitly launch a search, setting the search term already does that for us
        m_engine->setSearchTerm(searchText);
        m_onePage = false;
        m_responsePending = true;

        QSharedPointer<int> count(new int(0));
        connect(this, &KNSBackend::receivedResources, stream, [this, count](const QVector<AbstractResource*>& resources){
            *count += resources.count();
            if (*count>2000)
                m_stopSearching = true;
        });
        connect(this, &KNSBackend::receivedResources, stream, &ResultsStream::resourcesFound);
        connect(this, &KNSBackend::searchFinished, stream, &ResultsStream::finish);
        connect(this, &KNSBackend::startingSearch, stream, &ResultsStream::finish);
    };
```

#### AUTO 


```{c}
auto start = [this, entryid, stream, providerid]() {
        m_responsePending = true;
        m_engine->fetchEntryById(entryid);
        m_onePage = false;
        connect(m_engine, &KNSCore::Engine::signalError, stream, &ResultsStream::finish);
        connect(m_engine, &KNSCore::Engine::signalEntryDetailsLoaded, stream, [this, stream, entryid, providerid](const KNSCore::EntryInternal &entry) {
            if (entry.uniqueId() == entryid && providerid == QUrl(entry.providerId()).host()) {
                stream->resourcesFound({resourceForEntry(entry)});
            }
            m_responsePending = false;
            QTimer::singleShot(0, this, &KNSBackend::availableForQueries);
            stream->finish();
        });
    };
```

#### AUTO 


```{c}
auto ret = m_appdata.packageNames();
```

#### RANGE FOR STATEMENT 


```{c}
for (QStandardItem *item : items) {
        item->setEditable(false);
        appendRow(item);
    }
```

#### AUTO 


```{c}
const auto args = parser.positionalArguments();
```

#### LAMBDA EXPRESSION 


```{c}
[this, url, stream]() {
                const auto res = stream->resources();
                if (res.count() == 1) {
                    emit openApplicationInternal(res.first());
                } else {
                    rootObject()->setProperty("defaultStartup", true);
                    Q_EMIT openErrorPage(i18n("Couldn't open %1", url.toDisplayString()));
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &component: data.components) {
            const auto pkgNames = component.packageNames();
            addComponent(component, pkgNames);
        }
```

#### AUTO 


```{c}
auto watcher = new QFutureWatcher<void>(this);
```

#### LAMBDA EXPRESSION 


```{c}
[ids](AbstractResource* res){ return !ids.contains(res->appstreamId()); }
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractResource *res : qAsConst(upgradeList)) {
        m_pendingResources += res;
        auto t = m_backend->installApplication(res);
        t->setVisible(false);
        t->setProperty("updater", QVariant::fromValue<QObject *>(this));
        connect(t, &Transaction::downloadSpeedChanged, this, [this]() {
            Q_EMIT downloadSpeedChanged(downloadSpeed());
        });
        connect(this, &StandardBackendUpdater::cancelTransaction, t, &Transaction::cancel);
        TransactionModel::global()->addTransaction(t);
        m_canCancel |= t->isCancellable();
    }
```

#### AUTO 


```{c}
const auto execIdx = kIndexOf(files, [](const QString &file) {
                return file.endsWith(QLatin1String(".desktop")) && file.contains(QLatin1String("usr/share/applications"));
            });
```

#### RANGE FOR STATEMENT 


```{c}
for(BackendNotifierModule* module : m_backends)
        ret += module->updatesCount();
```

#### RANGE FOR STATEMENT 


```{c}
for(Category* c : list) {
        if(c->name() == newcat->name()) {
            if(c->icon() != newcat->icon()
                || c->shouldShowTechnical() != newcat->shouldShowTechnical()
                || c->m_andFilters != newcat->andFilters())
            {
                qWarning() << "the following categories seem to be the same but they're not entirely"
                    << c->name() << newcat->name();
                break;
            } else {
                c->m_orFilters += newcat->orFilters();
                c->m_notFilters += newcat->notFilters();
                for(Category* nc : newcat->subCategories())
                    addSubcategory(c->m_subCategories, nc);
                delete newcat;
                return;
            }
        }
    }
```

#### AUTO 


```{c}
auto stream = new ResultsStream(QStringLiteral("PackageKitStream-search"));
```

#### AUTO 


```{c}
const auto row = sourceById(sourceId)->row();
```

#### AUTO 


```{c}
const auto uris = kTransform<QVector<QUrl>>(array, [](const QJsonValue& uri) { return QUrl(uri.toString()); });
```

#### LAMBDA EXPRESSION 


```{c}
[regularCheck](const QStringRef& value) {
            bool ok;
            const int days = value.toInt(&ok);
            if (!ok || days == 0) {
                regularCheck->setInterval(24 * 60 * 60 * 1000); //refresh at least once every day
                regularCheck->start();
                qWarning() << "couldn't understand value for timer:" << value;
            }

            //if the setting is not empty, refresh will be carried out by unattended-upgrade
            //https://wiki.debian.org/UnattendedUpgrades
        }
```

#### AUTO 


```{c}
const auto icons = comp.icons();
```

#### AUTO 


```{c}
auto ref = FLATPAK_REF(remoteRef);
```

#### AUTO 


```{c}
auto resources = kFilter<QVector<AbstractResource*>>(m_packages.packages, [](AbstractResource* res) { return res->type() != AbstractResource::Technical && !qobject_cast<PackageKitResource*>(res)->extendsItself(); });
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &file) {
                return file.endsWith(QLatin1String(".desktop")) && file.contains(QLatin1String("usr/share/applications"));
            }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto itCat : cats) {
        if (contains(qobject_cast<Category*>(itCat.value<QObject*>()))) {
            ret = true;
            break;
        }
    }
```

#### AUTO 


```{c}
auto action = new OneTimeAction(
        [this, localfile]() {
            AbstractResourcesBackend::Filters f;
            f.resourceUrl = localfile;
            auto stream = new StoredResultsStream({ResourcesModel::global()->search(f)});
            connect(stream, &StoredResultsStream::finishedResources, this, [this, localfile](const QVector<AbstractResource *> &res) {
                if (res.count() == 1) {
                    Q_EMIT openApplicationInternal(res.first());
                } else {
                    QMimeDatabase db;
                    auto mime = db.mimeTypeForUrl(localfile);
                    auto fIsFlatpakBackend = [](AbstractResourcesBackend *backend) {
                        return backend->metaObject()->className() == QByteArray("FlatpakBackend");
                    };
                    if (mime.name().startsWith(QLatin1String("application/vnd.flatpak"))
                        && !kContains(ResourcesModel::global()->backends(), fIsFlatpakBackend)) {
                        openApplication(QUrl(QStringLiteral("appstream://org.kde.discover.flatpak")));
                        showPassiveNotification(i18n("Cannot interact with flatpak resources without the flatpak backend %1. Please install it first.",
                                                     localfile.toDisplayString()));
                    } else {
                        openMode(QStringLiteral("Browsing"));
                        showPassiveNotification(i18n("Could not open %1", localfile.toDisplayString()));
                    }
                }
            });
        },
        this);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &elem : m_addons) {
        if (elem.name() == addon) {
            elem.setInstalled(installed);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& exec : execs) {
        KService::Ptr service = KService::serviceByStorageId(exec);

        QString name = service->property("Name").toString();
        if (!service->genericName().isEmpty())
            name += QLatin1String(" - ") % service->genericName();

        QStandardItem *item = new QStandardItem(name);
        item->setIcon(QIcon::fromTheme(service->icon()));
        item->setData(service->desktopEntryPath(), Qt::UserRole);
        items += item;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const QString &appstreamId) { return resourcesByAppstreamName(appstreamId); }
```

#### AUTO 


```{c}
const auto updaters = kFilter<QVector<AbstractBackendUpdater*>>(m_updaters, [](AbstractBackendUpdater* u) {return u->hasUpdates(); });
```

#### AUTO 


```{c}
const auto pathParts = search.path().split(QLatin1Char('/'), QString::SkipEmptyParts);
```

#### RANGE FOR STATEMENT 


```{c}
for (DetailsTab *tab : m_detailsTabs) {
        tab->refresh();
    }
```

#### AUTO 


```{c}
const auto host = url.host();
```

#### AUTO 


```{c}
auto findTestBackend = [](AbstractResourcesBackend *backend) {
        return backend->name() == QLatin1String("discover_ktexteditor_codesnippets_core.knsrc");
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (PackageKitResource *res : qAsConst(m_packagesToAdd)) {
        m_packages.packages[res->packageName()] = res;
    }
```

#### AUTO 


```{c}
const auto execIdx = kIndexOf(files, [](const QString &file) {
            return file.endsWith(QLatin1String(".desktop")) && file.contains(QLatin1String("usr/share/applications"));
        });
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &pkgStr : addons.addonsToInstall()) {
        QApt::Package *package = m_backend->package(pkgStr);
        package->setInstall();
    }
```

#### AUTO 


```{c}
const auto entryid = pathParts.at(1);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto job : jobs) {
            connect(this, &SnapBackend::shuttingDown, job, &T::cancel);
            job->runSync();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, entryid, stream, providerid]() {
        m_responsePending = true;
        m_engine->fetchEntryById(entryid);
        m_onePage = false;

        connect(m_engine, &KNSCore::Engine::signalErrorCode, stream, &ResultsStream::finish);
        connect(m_engine,
                &KNSCore::Engine::signalEntryEvent,
                stream,
                [this, stream, entryid, providerid](const KNSCore::EntryInternal &entry, KNSCore::EntryInternal::EntryEvent event) {
                    switch (event) {
                    case KNSCore::EntryInternal::StatusChangedEvent:
                        if (entry.uniqueId() == entryid && providerid == QUrl(entry.providerId()).host()) {
                            Q_EMIT stream->resourcesFound({resourceForEntry(entry)});
                        } else
                            qWarning() << "found invalid" << entryid << entry.uniqueId() << providerid << QUrl(entry.providerId()).host();
                        m_responsePending = false;
                        QTimer::singleShot(0, this, &KNSBackend::availableForQueries);
                        stream->finish();
                        break;
                    case KNSCore::EntryInternal::DetailsLoadedEvent:
                    case KNSCore::EntryInternal::AdoptedEvent:
                    case KNSCore::EntryInternal::UnknownEvent:
                    default:
                        break;
                    }
                });
    }
```

#### AUTO 


```{c}
auto &backend
```

#### AUTO 


```{c}
auto job
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &tid: tids) {
        if (m_transactions.contains(tid))
            continue;

        auto t = new PackageKit::Transaction(QDBusObjectPath(tid));

        connect(t, &PackageKit::Transaction::roleChanged, this, [this, t]() {
            if (t->role() == PackageKit::Transaction::RoleGetUpdates) {
                setupGetUpdatesTransaction(t);
            }
        });
        connect(t, &PackageKit::Transaction::requireRestart, this, &PackageKitNotifier::onRequireRestart);
        connect(t, &PackageKit::Transaction::finished, this, [this, t](){
            auto restart = t->property("requireRestart");
            if (!restart.isNull())
                requireRestartNotification(PackageKit::Transaction::Restart(restart.toInt()));
            m_transactions.remove(t->tid().path());
            t->deleteLater();
        });
        m_transactions.insert(tid, t);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &snapValue : snaps) {
            QVERIFY(snapValue.isObject());
            const auto snap = snapValue.toObject();
            QVERIFY(snap.contains(QLatin1String("name") ));
            QVERIFY(snap.contains(QLatin1String("developer")));
        }
```

#### AUTO 


```{c}
const auto newIdx = it == m_displayedResources.constEnd() ? m_displayedResources.count() : (it - m_displayedResources.constBegin());
```

#### AUTO 


```{c}
auto actualCategory = new Category(m_displayName, QStringLiteral("plasma"), filters, backendName, topCategories, QUrl(), false);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto r : qAsConst(m_resources)) {
            const bool matchById = r->appstreamId().compare(filter.search, Qt::CaseInsensitive) == 0;
            if (r->type() == AbstractResource::Technical && filter.state != AbstractResource::Upgradeable && !matchById) {
                continue;
            }
            if (r->state() < filter.state)
                continue;

            if (!filter.extends.isEmpty() && !r->extends().contains(filter.extends))
                continue;

            if (!filter.mimetype.isEmpty() && !r->mimetypes().contains(filter.mimetype))
                continue;

            if (filter.search.isEmpty() || matchById) {
                rest += r;
            } else if (r->name().contains(filter.search, Qt::CaseInsensitive)) {
                prioritary += r;
            } else if (r->comment().contains(filter.search, Qt::CaseInsensitive)) {
                rest += r;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Application *app : tempList) {
        bool added = false;
        QApt::Package *pkg = app->package();
        if (app->isValid()) {
            if ((pkg) && !pkgBlacklist.contains(pkg->name())) {
                appList << app;
                app->moveToThread(thread);
                added = true;
            }
        }

        if(!added)
            delete app;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto res : qAsConst(m_resources)) {
            ret += res->licenses();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](PackageKit::Transaction::Error, const QString &message) {
        qWarning() << "Transaction error: " << message << sender();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto installation : insts) {
            g_autoptr(GError) error = nullptr;
            auto remote = flatpak_installation_get_remote_by_name(installation, name, nullptr, &error);
            if (remote) {
                addRemote(remote, installation);
            }
        }
```

#### AUTO 


```{c}
const auto uris = kTransform<QVector<QUrl>>(array, [](const QJsonValue &uri) {
        return QUrl(uri.toString());
    });
```

#### LAMBDA EXPRESSION 


```{c}
[updateAction](bool fetching) {
        updateAction->setEnabled(!fetching);
    }
```

#### AUTO 


```{c}
auto f = [this, stream, filter] () {
        QVector<AbstractResource*> ret;
        foreach(auto r, m_resources) {
            if (r->type() == AbstractResource::Technical && filter.state != AbstractResource::Upgradeable) {
                continue;
            }

            if (r->state() < filter.state)
                continue;

            if (!filter.extends.isEmpty() && !r->extends().contains(filter.extends))
                continue;

            if (filter.search.isEmpty() || r->name().contains(filter.search, Qt::CaseInsensitive) || r->comment().contains(filter.search, Qt::CaseInsensitive)) {
                ret += r;
            }
        }
        auto f = [this](AbstractResource* l, AbstractResource* r) { return flatpakResourceLessThan(l,r); };
        std::sort(ret.begin(), ret.end(), f);
        if (!ret.isEmpty())
            Q_EMIT stream->resourcesFound(ret);
        stream->finish();
    };
```

#### AUTO 


```{c}
auto it = new QStandardItem(QStringLiteral("rpm-ostree"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &source : m_flatpakSources) {
        if (source->m_pool) {
            auto comps = source->componentsByName(name);
            resources << kTransform<QVector<AbstractResource *>>(comps, [this, source](const auto &comp) {
                return resourceForComponent(comp, source);
            });
        }
    }
```

#### AUTO 


```{c}
auto comps = pool.componentsById(name);
```

#### LAMBDA EXPRESSION 


```{c}
[this, stream] {
            auto fw = new QFutureWatcher<QMap<FlatpakInstallation *, QVector<FlatpakInstalledRef *>>>(this);
            connect(fw, &QFutureWatcher<QByteArray>::finished, this, [this, fw, stream]() {
                if (g_cancellable_is_cancelled(m_cancellable)) {
                    stream->finish();
                    fw->deleteLater();
                    return;
                }

                const auto refs = fw->result();
                QVector<AbstractResource *> resources;
                for (auto it = refs.constBegin(), itEnd = refs.constEnd(); it != itEnd; ++it) {
                    resources.reserve(resources.size() + it->size());
                    for (auto ref : qAsConst(it.value())) {
                        auto resource = getAppForInstalledRef(it.key(), ref);
#if FLATPAK_CHECK_VERSION(1, 1, 2)
                        resource->setAvailableVersion(QString::fromUtf8(flatpak_installed_ref_get_appdata_version(ref)));
#endif
                        g_object_unref(ref);
                        resource->setState(AbstractResource::Upgradeable);
                        updateAppSize(resource);
                        if (resource->resourceType() == FlatpakResource::Runtime) {
                            resources.prepend(resource);
                        } else {
                            resources.append(resource);
                        }
                    }
                }

                if (!resources.isEmpty())
                    Q_EMIT stream->resourcesFound(resources);
                stream->finish();
                fw->deleteLater();
            });

            QVector<FlatpakInstallation *> installations = m_installations;
            auto cancellable = m_cancellable;
            fw->setFuture(QtConcurrent::run(&m_threadPool, [installations, cancellable] {
                QMap<FlatpakInstallation *, QVector<FlatpakInstalledRef *>> ret;

                for (auto installation : installations) {
                    g_autoptr(GError) localError = nullptr;
                    g_autoptr(GPtrArray) refs = flatpak_installation_list_installed_refs_for_update(installation, cancellable, &localError);
                    if (!refs) {
                        qWarning() << "Failed to get list of installed refs for listing updates:" << localError->message;
                        continue;
                    }
                    if (g_cancellable_is_cancelled(cancellable)) {
                        qWarning() << "Job cancelled";
                        return ret;
                    }

                    auto &current = ret[installation];
                    current.reserve(refs->len);
                    for (uint i = 0; i < refs->len; i++) {
                        FlatpakInstalledRef *ref = FLATPAK_INSTALLED_REF(g_ptr_array_index(refs, i));
                        g_object_ref(ref);
                        current.append(ref);
                    }
                }
                return ret;
            }));
        }
```

#### AUTO 


```{c}
const auto appstreamIds = AppStreamUtils::appstreamIds(url);
```

#### AUTO 


```{c}
auto f = [this, stream, filter] {
            const auto toResolve = kFilter<QVector<AbstractResource *>>(m_packages.packages, needsResolveFilter);

            auto installedAndNameFilter = [filter](AbstractResource *res) {
                return res->state() >= AbstractResource::Installed && !qobject_cast<PackageKitResource *>(res)->isCritical()
                    && (res->name().contains(filter.search, Qt::CaseInsensitive) || res->packageName().compare(filter.search, Qt::CaseInsensitive) == 0);
            };
            bool furtherSearch = false;
            if (!toResolve.isEmpty()) {
                resolvePackages(kTransform<QStringList>(toResolve, [](AbstractResource *res) {
                    return res->packageName();
                }));
                connect(m_resolveTransaction, &PKResolveTransaction::allFinished, this, [stream, toResolve, installedAndNameFilter] {
                    const auto resolved = kFilter<QVector<AbstractResource *>>(toResolve, installedAndNameFilter);
                    if (!resolved.isEmpty())
                        Q_EMIT stream->resourcesFound(resolved);
                    stream->finish();
                });
                furtherSearch = true;
            }

            const auto resolved = kFilter<QVector<AbstractResource *>>(m_packages.packages, installedAndNameFilter);
            if (!resolved.isEmpty()) {
                QTimer::singleShot(0, this, [resolved, toResolve, stream]() {
                    if (!resolved.isEmpty())
                        Q_EMIT stream->resourcesFound(resolved);

                    if (toResolve.isEmpty())
                        stream->finish();
                });
                furtherSearch = true;
            }

            if (!furtherSearch)
                stream->finish();
        };
```

#### AUTO 


```{c}
const auto components = m_appdata.components();
```

#### LAMBDA EXPRESSION 


```{c}
[this, stream, filter] () {
        QVector<AbstractResource*> ret;
        foreach(AbstractResource* r, m_resources) {
            if (r->isTechnical() && filter.state != AbstractResource::Upgradeable) {
                continue;
            }

            if (r->state() < filter.state)
                continue;

            if (filter.search.isEmpty() || r->name().contains(filter.search, Qt::CaseInsensitive) || r->comment().contains(filter.search, Qt::CaseInsensitive)) {
                ret += r;
            }
        }
        auto f = [this](AbstractResource* l, AbstractResource* r) { return flatpakResourceLessThan(l,r); };
        std::sort(ret.begin(), ret.end(), f);
        if (!ret.isEmpty())
            Q_EMIT stream->resourcesFound(ret);
        stream->finish();
    }
```

#### AUTO 


```{c}
auto res = packagesForPackageId({itemID});
```

#### AUTO 


```{c}
auto flatpakInstallationByPath = [this](const QString &path) -> FlatpakInstallation * {
        for (auto inst : m_installations) {
            if (FlatpakResource::installationPath(inst) == path)
                return inst;
        }
        return nullptr;
    };
```

#### AUTO 


```{c}
auto it = m_rootCategories.begin(), itEnd = m_rootCategories.end();
```

#### LAMBDA EXPRESSION 


```{c}
[this](){
        KProtocolManager::reparseConfiguration();
        updateProxy();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () -> GPtrArray*
        {
            const uint cacheAge = (24*60*60); // Check for updates every day
            g_autoptr(GError) error = nullptr;

            /* get devices */
            GPtrArray* devices = fwupd_client_get_devices(client, nullptr, nullptr);


            g_autoptr(GPtrArray) remotes = fwupd_client_get_remotes(client, nullptr, &error);
            for(uint i = 0; remotes && i < remotes->len; i++)
            {
                FwupdRemote *remote = (FwupdRemote *)g_ptr_array_index(remotes, i);
                if (!fwupd_remote_get_enabled(remote))
                    continue;

                if (fwupd_remote_get_kind(remote) == FWUPD_REMOTE_KIND_LOCAL)
                    continue;

                refreshRemote(this, remote, cacheAge);
            }
            return devices;
        }
```

#### AUTO 


```{c}
const auto config = KSharedConfig::openConfig();
```

#### AUTO 


```{c}
auto updateChecker = new OneTimeAction(
            [this]() {
                Q_EMIT startingSearch();
                m_onePage = true;
                m_responsePending = true;
                m_engine->checkForUpdates();
            },
            this);
```

#### LAMBDA EXPRESSION 


```{c}
[this, stream, source, name] {
                auto comps = source->m_pool->componentsById(name);
                if (comps.isEmpty()) {
                    const QString nameWithDesktop = name + QLatin1String(".desktop");
                    comps = source->m_pool->componentsById(nameWithDesktop);
                }
                auto resources = kTransform<QVector<AbstractResource *>>(comps, [this, source](const auto &comp) {
                    return resourceForComponent(comp, source);
                });
                stream->resourcesFound(resources);
                stream->finish();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &pkgid : m_updatesPackageId) {
        if (TransactionpackageName(pkgid) == name)
            ids.insert(pkgid);
    }
```

#### AUTO 


```{c}
const auto icons = m_appdata->icons();
```

#### AUTO 


```{c}
auto res = backend->getAppForInstalledRef(installation, installedRef);
```

#### LAMBDA EXPRESSION 


```{c}
[this, filter, stream] {
            const auto resources = kTransform<QVector<AbstractResource *>>(m_packages.extendedBy.value(filter.extends), [](AppPackageKitResource *a) {
                return a;
            });
            if (!resources.isEmpty()) {
                stream->setResources(resources);
            }
            stream->finish();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] { m_updatesCount.reevaluate(); }
```

#### AUTO 


```{c}
auto manager = res->knsBackend()->engine();
```

#### LAMBDA EXPRESSION 


```{c}
[](QQmlEngine*, QJSEngine*) -> QObject* {return ResourcesModel::global();}
```

#### LAMBDA EXPRESSION 


```{c}
[this, appstreamIds, stream] () {
                AbstractResource* pkg = nullptr;

                QStringList allAppStreamIds = appstreamIds;
                {
                    auto it = deprecatedAppstreamIds.constFind(appstreamIds.first());
                    if (it != deprecatedAppstreamIds.constEnd()) {
                        allAppStreamIds << *it;
                    }
                }

                for (auto it = m_packages.packages.constBegin(), itEnd = m_packages.packages.constEnd(); it != itEnd; ++it) {
                    const bool matches = kContains(allAppStreamIds, [&it] (const QString& id) {
                        return it.key().compare(id, Qt::CaseInsensitive) == 0 ||
                              (id.endsWith(QLatin1String(".desktop")) && id.compare(it.key()+QLatin1String(".desktop"), Qt::CaseInsensitive) == 0);
                    });
                    if (matches) {
                        pkg = it.value();
                        break;
                    }
                }
                if (pkg)
                    stream->setResources({pkg});
                stream->finish();
    //             if (!pkg)
    //                 qCDebug(LIBDISCOVER_BACKEND_LOG) << "could not find" << host << deprecatedHost;
            }
```

#### AUTO 


```{c}
const auto f = [this, appstreamIds, stream]() {
                AbstractResource *pkg = nullptr;

                QStringList allAppStreamIds = appstreamIds;
                {
                    auto it = deprecatedAppstreamIds.constFind(appstreamIds.first());
                    if (it != deprecatedAppstreamIds.constEnd()) {
                        allAppStreamIds << *it;
                    }
                }

                for (auto it = m_packages.packages.constBegin(), itEnd = m_packages.packages.constEnd(); it != itEnd; ++it) {
                    const bool matches = kContains(allAppStreamIds, [&it](const QString &id) {
                        static const QLatin1String desktopPostfix(".desktop");
                        return it.key().compare(id, Qt::CaseInsensitive) == 0 ||
                            // doing (id == id.key()+".desktop") without allocating
                            (id.size() == (desktopPostfix.size() + it.key().size()) && id.endsWith(desktopPostfix)
                             && id.startsWith(it.key(), Qt::CaseInsensitive)) ||
                            (it.key().size() == (desktopPostfix.size() + id.size()) && it.key().endsWith(desktopPostfix)
                             && it.key().startsWith(id, Qt::CaseInsensitive));
                    });
                    if (matches) {
                        pkg = it.value();
                        break;
                    }
                }
                if (pkg)
                    stream->setResources({pkg});
                stream->finish();
                //         if (!pkg)
                //             qCDebug(LIBDISCOVER_BACKEND_LOG) << "could not find" << host << deprecatedHost;
            };
```

#### AUTO 


```{c}
const auto resolved = kFilter<QVector<AbstractResource*>>(m_packages.packages, installedAndNameFilter);
```

#### RANGE FOR STATEMENT 


```{c}
for (TransactionListener *listener : m_transactions) {
        if(listener->resource() == app) {
            toRemove = listener;
            break;
        }
    }
```

#### AUTO 


```{c}
const auto &tid
```

#### AUTO 


```{c}
const auto resources = resourcesByAppstreamName(appstreamId);
```

#### LAMBDA EXPRESSION 


```{c}
[](const AbstractResource* a, const AbstractResource* b){ return a->name() < b->name(); }
```

#### AUTO 


```{c}
auto it = m_resources.constBegin(), itEnd = m_resources.constEnd();
```

#### AUTO 


```{c}
auto f = [this, stream, filter]() {
        QVector<AbstractResource *> prioritary, rest;
        for (auto r : qAsConst(m_resources)) {
            const bool matchById = r->appstreamId().compare(filter.search, Qt::CaseInsensitive) == 0;
            if (r->type() == AbstractResource::Technical && filter.state != AbstractResource::Upgradeable && !matchById) {
                continue;
            }
            if (r->state() < filter.state)
                continue;

            if (!filter.extends.isEmpty() && !r->extends().contains(filter.extends))
                continue;

            if (!filter.mimetype.isEmpty() && !r->mimetypes().contains(filter.mimetype))
                continue;

            if (filter.search.isEmpty() || matchById) {
                rest += r;
            } else if (r->name().contains(filter.search, Qt::CaseInsensitive)) {
                prioritary += r;
            } else if (r->comment().contains(filter.search, Qt::CaseInsensitive)) {
                rest += r;
            }
        }
        auto f = [this](AbstractResource *l, AbstractResource *r) {
            return flatpakResourceLessThan(l, r);
        };
        std::sort(rest.begin(), rest.end(), f);
        std::sort(prioritary.begin(), prioritary.end(), f);
        rest = prioritary + rest;
        if (!rest.isEmpty())
            Q_EMIT stream->resourcesFound(rest);
        stream->finish();
    };
```

#### AUTO 


```{c}
auto it = names.begin(), itEnd = names.end();
```

#### LAMBDA EXPRESSION 


```{c}
[](AppPackageKitResource *a) {
                return a;
            }
```

#### AUTO 


```{c}
auto s = state();
```

#### RANGE FOR STATEMENT 


```{c}
for (const KNSCore::Provider::CategoryMetadata& category : categoryMetadatas) {
            for (Category* cat : categories) {
                if (cat->orFilters().count() > 0 && cat->orFilters().first().second == category.name) {
                    cat->setName(category.displayName);
                    break;
                }
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        {
            if (m_backends.isEmpty())
                return 0;

            int sum = 0;
            for(auto backend: m_backends) {
                sum += backend->fetchingUpdatesProgress();
            }
            return sum / m_backends.count();
        }
    }
```

#### AUTO 


```{c}
auto ref = qobject_cast<FlatpakBackend *>(backend())->getInstalledRefForApp(this)
```

#### RANGE FOR STATEMENT 


```{c}
for (Transaction *trans : resource->backend()->transactions()) {
                if (trans->resource() == resource) {
                    t = trans;
                    break;
                }
            }
```

#### AUTO 


```{c}
auto action = new OneTimeAction(
        [this, localfile]() {
            auto res = ResourcesModel::global()->resourceForFile(localfile);
            qDebug() << "all initialized..." << res;
            if (res) {
                emit openApplicationInternal(res);
            } else {
                setRootObjectProperty("defaultStartup", true);
                showPassiveNotification(i18n("Couldn't open %1", localfile.toDisplayString()));
            }
        }
        , this);
```

#### LAMBDA EXPRESSION 


```{c}
[mainWindow](const QStringList &arguments, const QString &/*workingDirectory*/){


            if (!mainWindow->rootObject())
                QCoreApplication::instance()->quit();


            auto window = qobject_cast<QWindow*>(mainWindow->rootObject());
            if (window && QX11Info::isPlatformX11()) {
                KStartupInfo::setNewStartupId(window, QX11Info::nextStartupId());
            }
            window->raise();

            if (arguments.isEmpty())
                return;
            QScopedPointer<QCommandLineParser> parser(createParser());
            parser->parse(arguments);
            processArgs(parser.data(), mainWindow);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractBackendUpdater *upd : qAsConst(m_updaters)) {
        ret += upd->toUpdate();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Appstream::Image &i : s.images()) {
            if (i.kind() == kind) {
                ret = i.url();
            }
        }
```

#### AUTO 


```{c}
auto toinstall = QStringList() << m_packagesModified.value(PackageKit::Transaction::InfoInstalling)
                                       << m_packagesModified.value(PackageKit::Transaction::InfoUpdating);
```

#### AUTO 


```{c}
const auto id = line.left(idx).toLower();
```

#### LAMBDA EXPRESSION 


```{c}
[](PackageKit::Transaction::Error /*error*/, const QString &details) {
                KNotification::event(QStringLiteral("OfflineUpdateRepairFailed"),
                                     i18n("Repair Failed"),
                                     xi18nc("@info", "%1<nl/>Please report this error to your distribution.", details),
                                     {},
                                     KNotification::Persistent,
                                     QStringLiteral("org.kde.discovernotifier"));
            }
```

#### LAMBDA EXPRESSION 


```{c}
[filter](AbstractResource *res) {
                return res->state() >= AbstractResource::Installed && !qobject_cast<PackageKitResource *>(res)->isCritical()
                    && (res->name().contains(filter.search, Qt::CaseInsensitive) || res->packageName().compare(filter.search, Qt::CaseInsensitive) == 0);
            }
```

#### AUTO 


```{c}
const auto subs = root->subCategories();
```

#### LAMBDA EXPRESSION 


```{c}
[](AbstractResourcesBackend* backend) { return backend->metaObject()->className() == QByteArray("FlatpakBackend"); }
```

#### LAMBDA EXPRESSION 


```{c}
[]() {
            qApp->exit(1);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        Q_EMIT downloadSpeedChanged(downloadSpeed());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto cat : cats) {
        sortCategories(cat->m_subCategories);
    }
```

#### AUTO 


```{c}
const auto subCategories = newcat->subCategories();
```

#### AUTO 


```{c}
auto stream = new ResultsStream(QStringLiteral("FlatpakStream-installed"));
```

#### RANGE FOR STATEMENT 


```{c}
for(auto app : m_apps) {
                    qDebug() << "app" << app << app->state() << static_cast<PackageKitResource*>(app)->packages();
                }
```

#### AUTO 


```{c}
const auto basename = QString::fromUtf8(g_path_get_basename(fwupd_remote_get_filename_cache(remote)));
```

#### AUTO 


```{c}
auto m = const_cast<AbstractSourcesBackend*>(this)->sources();
```

#### AUTO 


```{c}
auto toremove = toremoveOrig;
```

#### AUTO 


```{c}
auto disableSessionManagement = [](QSessionManager &sm) {
        sm.setRestartHint(QSessionManager::RestartNever);
    };
```

#### LAMBDA EXPRESSION 


```{c}
[objectName]() { qCDebug(LIBDISCOVER_LOG) << "stream took really long" << objectName; }
```

#### AUTO 


```{c}
auto action = new OneTimeAction(
        [this, url]() {
            AbstractResourcesBackend::Filters f;
            f.resourceUrl = url;
            auto stream = new StoredResultsStream({ResourcesModel::global()->search(f)});
            connect(stream, &StoredResultsStream::finishedResources, this, [this, url](const QVector<AbstractResource *> &res) {
                if (res.count() >= 1) {
                    Q_EMIT openApplicationInternal(res.first());
                } else if (url.scheme() == QLatin1String("snap")) {
                    openApplication(QUrl(QStringLiteral("appstream://org.kde.discover.snap")));
                    showPassiveNotification(i18n("Please make sure Snap support is installed"));
                } else {
                    const QString errorText = i18n("Could not open %1 because it "
                    "was not found in any available software repositories.",
                    url.toDisplayString());
                    const QString errorExplanation = i18n("Please report this "
                    "issue to the packagers of your distribution.");
                    QString buttonIcon = QStringLiteral("tools-report-bug");
                    QString buttonText = i18n("Report This Issue");
                    QString buttonUrl = KOSRelease().bugReportUrl();
                    Q_EMIT openErrorPage(errorText, errorExplanation, buttonText, buttonIcon, buttonUrl);
                }
            });
        },
        this);
```

#### LAMBDA EXPRESSION 


```{c}
[this, error] {
                return flatpak_installation_new_user(m_cancellable, error);
            }
```

#### AUTO 


```{c}
auto variant = split_branch[3];
```

#### LAMBDA EXPRESSION 


```{c}
[this, stream, filter] () {
        QVector<AbstractResource*> prioritary, rest;
        for (auto r : qAsConst(m_resources)) {
            const bool matchById = r->appstreamId().compare(filter.search, Qt::CaseInsensitive) == 0;
            if (r->type() == AbstractResource::Technical && filter.state != AbstractResource::Upgradeable && !matchById) {
                continue;
            }
            if (r->state() < filter.state)
                continue;

            if (!filter.extends.isEmpty() && !r->extends().contains(filter.extends))
                continue;

            if (!filter.mimetype.isEmpty() && !r->mimetypes().contains(filter.mimetype))
                continue;

            if (filter.search.isEmpty() || matchById) {
                rest += r;
            } else if (r->name().contains(filter.search, Qt::CaseInsensitive)) {
                prioritary += r;
            } else if (r->comment().contains(filter.search, Qt::CaseInsensitive)) {
                rest += r;
            }
        }
        auto f = [this](AbstractResource* l, AbstractResource* r) { return flatpakResourceLessThan(l,r); };
        std::sort(rest.begin(), rest.end(), f);
        std::sort(prioritary.begin(), prioritary.end(), f);
        rest = prioritary + rest;
        if (!rest.isEmpty())
            Q_EMIT stream->resourcesFound(rest);
        stream->finish();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, stream, entryid, providerid](const KNSCore::EntryInternal &entry, KNSCore::EntryInternal::EntryEvent event) {
                    switch (event) {
                    case KNSCore::EntryInternal::StatusChangedEvent:
                        if (entry.uniqueId() == entryid && providerid == QUrl(entry.providerId()).host()) {
                            Q_EMIT stream->resourcesFound({resourceForEntry(entry)});
                        } else
                            qWarning() << "found invalid" << entryid << entry.uniqueId() << providerid << QUrl(entry.providerId()).host();
                        QTimer::singleShot(0, this, [this] {
                            setResponsePending(false);
                        });
                        stream->finish();
                        break;
                    case KNSCore::EntryInternal::DetailsLoadedEvent:
                    case KNSCore::EntryInternal::AdoptedEvent:
                    case KNSCore::EntryInternal::UnknownEvent:
                    default:
                        break;
                    }
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this](uint timeSince) {
        if (timeSince > 3600)
            checkForUpdates();
        else
            fetchUpdates();
    }
```

#### AUTO 


```{c}
const auto &updateText = _updateText;
```

#### LAMBDA EXPRESSION 


```{c}
[this, process](int exitCode, QProcess::ExitStatus exitStatus) {
        if (exitStatus != QProcess::NormalExit) {
            qWarning() << "rpm-ostree-backend: Error while calling rpm-ostree:" << process->readAllStandardError();
            return;
        }
        if (exitCode != 0) {
            qInfo() << "rpm-ostree-backend: No update available";
            return;
        }
        QString newVersionFound;
        QTextStream stream(process);
        for (QString line = stream.readLine(); stream.readLineInto(&line);) {
            if (line.contains(QLatin1String("Version"))) {
                newVersionFound = line;
            }
        }
        if (!newVersionFound.isEmpty()) {
            newVersionFound.remove(0, QStringLiteral("        Version: ").length() - 1);
            newVersionFound.remove(newVersionFound.size() - QStringLiteral(" (XXXX-XX-XXTXX:XX:XXZ)").length(), newVersionFound.size() - 1);
            currentlyBootedDeployment()->setNewVersion(newVersionFound);
            currentlyBootedDeployment()->setState(AbstractResource::Upgradeable);
        }
        process->deleteLater();
    }
```

#### AUTO 


```{c}
const auto it = std::find_if(m_displayedResources.constBegin() + newIdx, m_displayedResources.constEnd(), finder);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        transactionChanged(ProgressRole);
        Q_EMIT progressChanged();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto pkgList : changes.values()) {
        for(QApt::Package* it : pkgList) {
            AbstractResource* res = m_appBackend->resourceByPackageName(it->name());
            if(!res) //If we couldn't find it by its name, try with
                res = m_appBackend->resourceByPackageName(QString("%1:%2").arg(it->name()).arg(it->architecture()));
            if(!res)
                qWarning() << "Couldn't find the package:" << it->name();
            Q_ASSERT(res);
            m_toUpdate += res;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[type, keyId, packageID]() {
        return PackageKit::Daemon::installSignature(type, keyId, packageID);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractResourcesBackend *backend : backends) {
        if (QString::fromLatin1(backend->metaObject()->className()) == name) {
            return backend;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (DetailsTab *tab : m_detailsTabs) {
        tab->clear();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto stream : streams) {
        connect(stream, &ResultsStream::resourcesFound, this, &AggregatedResultsStream::addResults);
        connect(stream, &QObject::destroyed, this, &AggregatedResultsStream::streamDestruction);
        connect(this, &ResultsStream::fetchMore, stream, &ResultsStream::fetchMore);
        m_streams << stream;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &name : backendNames)
                QTextStream(stdout) << " * " << name << '\n';
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractResource *res : qAsConst(m_allUpgradeable)) {
        if (auto upgrade = dynamic_cast<SystemUpgrade *>(res)) {
            if (packages.contains(upgrade->allPackageNames())) {
                ret += upgrade;
            }
            continue;
        }

        PackageKitResource *pres = qobject_cast<PackageKitResource *>(res);
        if (packages.contains(kToSet(pres->allPackageNames()))) {
            ret.insert(res);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &/*packageID*/, const QStringList &_filenames) {
        //This workarounds bug in zypper's backend (suse) https://github.com/hughsie/PackageKit/issues/351
        QStringList filenames = _filenames;
        if (filenames.count() == 1 && !QFile::exists(filenames.constFirst())) {
            filenames = filenames.constFirst().split(QLatin1Char(';'));
        }
        const auto allServices = QStandardPaths::locateAll(QStandardPaths::ApplicationsLocation, m_appdata.id());
        if (!allServices.isEmpty()) {
            const auto packageServices = kFilter<QStringList>(allServices, [filenames](const QString &file) { return filenames.contains(file); });
            runService(packageServices);
            return;
        } else {
            const QStringList exes = m_appdata.provided(AppStream::Provided::KindBinary).items();
            const auto packageExecutables = kFilter<QStringList>(exes, [filenames](const QString &exe) { return filenames.contains(QLatin1Char('/') + exe); });
            if (!packageExecutables.isEmpty()) {
                QProcess::startDetached(exes.constFirst(), QStringList());
                return;
            } else {
                const auto locations = QStandardPaths::standardLocations(QStandardPaths::ApplicationsLocation);
                const auto desktopFiles = kFilter<QStringList>(filenames, [locations](const QString &exe) {
                    for (const auto &location: locations) {
                        if (exe.startsWith(location))
                            return exe.contains(QLatin1String(".desktop"));
                    }
                    return false;
                });
                if (!desktopFiles.isEmpty()) {
                    runService(desktopFiles);
                    return;
                }
            }
            Q_EMIT backend()->passiveMessage(i18n("Cannot launch %1", name()));
        }
    }
```

#### AUTO 


```{c}
const auto snap = m_res->snap();
```

#### LAMBDA EXPRESSION 


```{c}
[this, stream, searchText]() {
        m_manager->setSearchTerm(searchText);
        m_manager->search(0);
        m_responsePending = true;
        m_page = 0;
        connect(this, &KNSBackend::receivedResources, stream, &ResultsStream::resourcesFound);
        connect(this, &KNSBackend::searchFinished, stream, &ResultsStream::deleteLater);
        connect(this, &KNSBackend::startingSearch, stream, &ResultsStream::deleteLater);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QJsonValue& uri) { return QUrl(uri.toString()); }
```

#### AUTO 


```{c}
const auto filtered = kFilter<KNSCore::EntryInternal::List>(entries, [](const KNSCore::EntryInternal &entry) {
        return entry.isValid();
    });
```

#### AUTO 


```{c}
auto it = input.begin();
```

#### LAMBDA EXPRESSION 


```{c}
[=](AbstractResource *res) {
        if (res)
            backend->installApplication(res);
        else
            Q_EMIT backend->passiveMessage(i18n("Could not add the source %1", flatpakrepoUrl.toDisplayString()));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto e : m_entry.downloadLinkInformationList()) {
        if (e.isDownloadtypeLink)
            ids << e.id;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &_error) {
        QString error = _error;
        bool invalidFile = false;
        if(error == QLatin1Literal("All categories are missing")) {
            markInvalid(error);
            error = i18n("Invalid %1 backend, contact your distributor.", m_displayName);
            invalidFile = true;
        }
        m_responsePending = false;
        Q_EMIT searchFinished();
        Q_EMIT availableForQueries();
        this->setFetching(false);
        qWarning() << "kns error" << objectName() << error;
        if (!invalidFile)
            passiveMessage(i18n("%1: %2", name(), error));
    }
```

#### AUTO 


```{c}
auto action = new OneTimeAction(
        [this, category]() {
            Category* cat = CategoryModel::global()->findCategoryByName(category);
            if (cat) {
                emit listCategoryInternal(cat);
            } else {
                showPassiveNotification(i18n("Could not find category '%1'", category));
                rootObject()->setProperty("defaultStartup", false);
            }
        }
        , this);
```

#### LAMBDA EXPRESSION 


```{c}
[this, fw, flatpakInstallation, appstreamIconsPath, sourceName]() {
        const auto components = fw->result();
        foreach (const AppStream::Component& appstreamComponent, components) {
            FlatpakResource *resource = new FlatpakResource(appstreamComponent, flatpakInstallation, this);
            resource->setIconPath(appstreamIconsPath);
            resource->setOrigin(sourceName);
            addResource(resource);
        }

        metadataRefreshed();
        acquireFetching(false);
        fw->deleteLater();
    }
```

#### AUTO 


```{c}
auto changes = m_backend->stateChanges(m_oldCacheState, upgradeable);
```

#### LAMBDA EXPRESSION 


```{c}
[](QStandardItem* item) { qDebug() << "DummySource changed" << item << item->checkState(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this, stream, filter]() {
            const QList<AppStream::Component> components = m_appdata->search(filter.search);
            const QStringList ids = kTransform<QStringList>(components, [](const AppStream::Component &comp) {
                return comp.id();
            });
            if (!ids.isEmpty()) {
                const auto resources =
                    kFilter<QVector<AbstractResource *>>(resourcesByPackageNames<QVector<AbstractResource *>>(ids), [](AbstractResource *res) {
                        return !qobject_cast<PackageKitResource *>(res)->extendsItself();
                    });
                stream->setResources(resources);
            }
            stream->finish();
        }
```

#### AUTO 


```{c}
auto res = m_resources.value(index.row());
```

#### AUTO 


```{c}
const auto error = m_appdata->lastError();
```

#### LAMBDA EXPRESSION 


```{c}
[](AbstractResource* res) { return res->packageName(); }
```

#### AUTO 


```{c}
auto backend
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &potentialSubCat : qAsConst(categories)) {
            if (potentialSubCat->name().startsWith(catName)) {
                cat->addSubcategory(potentialSubCat);
                topCategories.removeOne(potentialSubCat);
            }
        }
```

#### AUTO 


```{c}
auto f = [this, stream, filter] () {
        QVector<AbstractResource*> ret;
        foreach(AbstractResource* r, m_resources) {
            if (r->state() < filter.state)
                continue;

            if (filter.search.isEmpty() || r->name().contains(filter.search, Qt::CaseInsensitive) || r->comment().contains(filter.search, Qt::CaseInsensitive)) {
                ret += r;
            }
        }
        if (!ret.isEmpty())
            Q_EMIT stream->resourcesFound(ret);
        stream->finish();
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this](int count) {
              Q_EMIT updatesCountChanged(count);
          }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
            acquireFetching(false);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractResource *res : resources) {
        Rating *r = rev->ratingForApplication(res);
        QVERIFY(r);
        QCOMPARE(r->packageName(), res->packageName());
        QVERIFY(r->rating() > 0 && r->rating() <= 10);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto resource: resources) {
        int newIdx = 0;
        const auto finder = [this, resource](AbstractResource* res){ return lessThan(resource, res); };
        const auto it = std::find_if(m_displayedResources.constBegin() + newIdx, m_displayedResources.constEnd(), finder);
        newIdx = it == m_displayedResources.constEnd() ? m_displayedResources.count() : (it - m_displayedResources.constBegin());

        beginInsertRows({}, newIdx, newIdx);
        m_displayedResources.insert(newIdx, resource);
        endInsertRows();
    }
```

#### AUTO 


```{c}
const auto toResolve = kFilter<QVector<AbstractResource*>>(res, needsResolveFilter);
```

#### LAMBDA EXPRESSION 


```{c}
[msg](){ msg->setVisible(false); }
```

#### LAMBDA EXPRESSION 


```{c}
[] {
        qCDebug(LIBDISCOVER_BACKEND_LOG) << ".";
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, installation, fw](){
        g_autoptr(GPtrArray) refs = fw->result();
        onFetchUpdatesFinished(installation, refs);
        fw->deleteLater();
        acquireFetching(false);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &refs : m_remoteRefsList) {
        if (refs == m_currentRefs)
            continue;
        QString refssV = refs;
        QStringList refsNumber = refssV.split(QStringLiteral("/"));
        int refsNumberV = refsNumber[1].toInt();
        if (refsNumberV <= currentVersion)
            continue;
        m_recentRefs = refs;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
            acquireFetching(false);
            refresh();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, r](){
                m_resources.removeAll(r);
            }
```

#### AUTO 


```{c}
const auto appsToRemove = resourcesByPackageNames<QVector<AbstractResource*>>(addons.addonsToRemove());
```

#### RANGE FOR STATEMENT 


```{c}
for (auto res : toUpgrade) {
        const auto packageName = res->packageName();
        if (packages.contains(packageName)) {
            continue;
        }
        packages.insert(packageName);
        ret += 1;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &source : m_flatpakSources) {
        if (!source->m_pool->lastError().isEmpty()) {
            return new HelpfulError(QStringLiteral("emblem-error"), i18n("Failed to load \"%1\" source", source->name()));
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, filter, stream] {
            auto resources = kFilter<QVector<AbstractResource*>>(m_packages.packages, [](AbstractResource* res) { return res->type() != AbstractResource::Technical && !qobject_cast<PackageKitResource*>(res)->extendsItself(); });
            if (!resources.isEmpty()) {
                stream->setResources(resources);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (UpdateItem *item : qAsConst(m_updateItems)) {
        const auto packageName = item->resource()->packageName();
        if (packages.contains(packageName)) {
            continue;
        }
        packages.insert(packageName);
        ret += item->checked() != Qt::Unchecked ? 1 : 0;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[]() {
            QProcess::startDetached(QStringLiteral("plasma-discover"), QStringList());
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, resource](bool success, FlatpakResource *repoResource) {
                                if (success) {
                                    installApplication(repoResource);
                                }
                                addResource(resource);
                            }
```

#### AUTO 


```{c}
const auto dest = qScopeGuard([this] { acquireFetching(false); });
```

#### LAMBDA EXPRESSION 


```{c}
[appDirFileName]() -> QList<AppStream::Component> {
        AppStream::Metadata metadata;
        metadata.setFormatStyle(AppStream::Metadata::FormatStyleCollection);
        AppStream::Metadata::MetadataError error = metadata.parseFile(appDirFileName, AppStream::Metadata::FormatKindXml);
        if (error != AppStream::Metadata::MetadataErrorNoError) {
            qWarning() << "Failed to parse appstream metadata: " << error;
            return {};
        }

        return metadata.components();
    }
```

#### AUTO 


```{c}
auto data = job->data();
```

#### LAMBDA EXPRESSION 


```{c}
[&notifier, &item](){
        item.setStatus(sniStatus(notifier.state()));
        item.setIconByName(notifier.iconName());
        item.setToolTipSubTitle(notifier.message());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](Category *cat) {
        return QVariant::fromValue<QObject *>(cat);
    }
```

#### AUTO 


```{c}
const auto name = snap.value(QLatin1String("name")).toString();
```

#### AUTO 


```{c}
const auto path = fileUrl.toLocalFile();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &ext : extends)
                        m_packages.extendedBy[ext].removeAll(ares);
```

#### AUTO 


```{c}
const auto numberStr = line.mid(prefix.size()).trimmed();
```

#### AUTO 


```{c}
auto f = [this, stream] {
            auto fw = new QFutureWatcher<QMap<FlatpakInstallation *, QVector<FlatpakInstalledRef *>>>(this);
            connect(fw, &QFutureWatcher<QByteArray>::finished, this, [this, fw, stream]() {
                if (g_cancellable_is_cancelled(m_cancellable)) {
                    stream->finish();
                    fw->deleteLater();
                    return;
                }

                const auto refs = fw->result();
                QVector<AbstractResource *> resources;
                for (auto it = refs.constBegin(), itEnd = refs.constEnd(); it != itEnd; ++it) {
                    resources.reserve(resources.size() + it->size());
                    for (auto ref : qAsConst(it.value())) {
                        bool fresh;
                        auto resource = getAppForInstalledRef(it.key(), ref, &fresh);
#if FLATPAK_CHECK_VERSION(1, 1, 2)
                        resource->setAvailableVersion(QString::fromUtf8(flatpak_installed_ref_get_appdata_version(ref)));
#endif
                        g_object_unref(ref);
                        resource->setState(AbstractResource::Upgradeable, !fresh);
                        updateAppSize(resource);
                        if (resource->resourceType() == FlatpakResource::Runtime) {
                            resources.prepend(resource);
                        } else {
                            resources.append(resource);
                        }
                    }
                }

                if (!resources.isEmpty())
                    Q_EMIT stream->resourcesFound(resources);
                stream->finish();
                fw->deleteLater();
            });

            QVector<FlatpakInstallation *> installations = m_installations;
            auto cancellable = m_cancellable;
            fw->setFuture(QtConcurrent::run(&m_threadPool, [installations, cancellable] {
                QMap<FlatpakInstallation *, QVector<FlatpakInstalledRef *>> ret;

                for (auto installation : installations) {
                    g_autoptr(GError) localError = nullptr;
                    g_autoptr(GPtrArray) refs = flatpak_installation_list_installed_refs_for_update(installation, cancellable, &localError);
                    if (!refs) {
                        qWarning() << "Failed to get list of installed refs for listing updates:" << localError->message;
                        continue;
                    }
                    if (g_cancellable_is_cancelled(cancellable)) {
                        qWarning() << "Job cancelled";
                        return ret;
                    }

                    auto &current = ret[installation];
                    current.reserve(refs->len);
                    for (uint i = 0; i < refs->len; i++) {
                        FlatpakInstalledRef *ref = FLATPAK_INSTALLED_REF(g_ptr_array_index(refs, i));
                        g_object_ref(ref);
                        current.append(ref);
                    }
                }
                return ret;
            }));
        };
```

#### LAMBDA EXPRESSION 


```{c}
[] (AbstractResource* r) { return r; }
```

#### AUTO 


```{c}
auto transaction = PackageKit::Daemon::global()->repoEnable(id, true);
```

#### RANGE FOR STATEMENT 


```{c}
for(auto job : m_jobs) {
        if (!job->isFinished()) {
            connect(job, &QThread::finished, job, &QObject::deleteLater);
        } else
            delete job;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, stream, url] () {
                QVector<AbstractResource*> resources;
                foreach(FlatpakResource* res, m_resources) {
                    if (QString::compare(res->appstreamId(), url.host(), Qt::CaseInsensitive)==0)
                        resources << res;
                }
                auto f = [this](AbstractResource* l, AbstractResource* r) { return flatpakResourceLessThan(l,r); };
                std::sort(resources.begin(), resources.end(), f);

                QTimer::singleShot(0, stream, [resources, stream] () {
                    if (!resources.isEmpty())
                        Q_EMIT stream->resourcesFound(resources);
                    stream->finish();
                });
            }
```

#### AUTO 


```{c}
auto fw = new QFutureWatcher<GPtrArray*>(this);
```

#### RANGE FOR STATEMENT 


```{c}
for(AbstractBackendUpdater* upd: m_updaters) {
        ret += upd->updateSize();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[menu](UpgradeAction* a) {
        QAction* action = new QAction(a->description(), menu);
        connect(action, &QAction::triggered, a, &UpgradeAction::trigger);
        menu->addAction(action);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                Q_EMIT passiveMessage(i18n("Please make sure that Appstream is properly set up on your system"));
            }
```

#### AUTO 


```{c}
auto filterFunction = [&filter](AbstractResource *r) {
                    return r->state() >= filter.state
                        && (r->name().contains(filter.search, Qt::CaseInsensitive) || r->comment().contains(filter.search, Qt::CaseInsensitive));
                };
```

#### AUTO 


```{c}
auto resources = kTransform<QVector<AbstractResource *>>(comps, [this, source](const auto &comp) {
                    return resourceForComponent(comp, source);
                });
```

#### LAMBDA EXPRESSION 


```{c}
[this, stream, entryid](const KNSCore::EntryInternal &entry) {
            if (entry.uniqueId() == entryid) {
                stream->resourcesFound({resourceForEntry(entry)});
            }
            m_responsePending = false;
            QTimer::singleShot(0, this, &KNSBackend::availableForQueries);
            stream->deleteLater();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[t](PackageKit::Transaction::Info info, const QString& packageId) {
        QMap<PackageKit::Transaction::Info, QStringList> packages = t->property("packages").value<QMap<PackageKit::Transaction::Info, QStringList>>();
        packages[info].append(packageId);
        t->setProperty("packages", qVariantFromValue(packages));
    }
```

#### AUTO 


```{c}
auto mAboutAppAction = KStandardAction::aboutApp(this, &DiscoverObject::aboutApplication, this);
```

#### LAMBDA EXPRESSION 


```{c}
[this, filter, stream] {
            auto resources = kFilter<QVector<AbstractResource*>>(m_packages.packages, [](AbstractResource* res) { return res->type() != AbstractResource::Technical && !qobject_cast<PackageKitResource*>(res)->extendsItself(); });
            if (!resources.isEmpty()) {
                Q_EMIT stream->setResources(resources);
            }
        }
```

#### AUTO 


```{c}
auto itCat
```

#### LAMBDA EXPRESSION 


```{c}
[this, stream, filter] () {
        QVector<AbstractResource*> ret;
        foreach(auto r, m_resources) {
            const bool matchById = filter.search.compare(r->appstreamId(), Qt::CaseInsensitive) == 0;
            if (r->type() == AbstractResource::Technical && filter.state != AbstractResource::Upgradeable && !matchById) {
                continue;
            }
            if (r->state() < filter.state)
                continue;

            if (!filter.extends.isEmpty() && !r->extends().contains(filter.extends))
                continue;

            if (filter.search.isEmpty() || r->name().contains(filter.search, Qt::CaseInsensitive) || r->comment().contains(filter.search, Qt::CaseInsensitive) || matchById)
            {
                ret += r;
            }
        }
        auto f = [this](AbstractResource* l, AbstractResource* r) { return flatpakResourceLessThan(l,r); };
        std::sort(ret.begin(), ret.end(), f);
        if (!ret.isEmpty())
            Q_EMIT stream->resourcesFound(ret);
        stream->finish();
    }
```

#### AUTO 


```{c}
auto proceedFunction = [=]()
                    {
                        if(fwupd_client_modify_remote(m_backend->backend->client, fwupd_remote_get_id(remote), "Enabled", "true", nullptr, nullptr))
                            item->setData(value, role);
                    };
```

#### AUTO 


```{c}
const auto idx = m.index(i, 0);
```

#### AUTO 


```{c}
auto oldState = state();
```

#### AUTO 


```{c}
auto args = KShell::splitArgs(exe);
```

#### RANGE FOR STATEMENT 


```{c}
for(Transaction* t: TransactionModel::global()->transactions()) {
        if (t->property("updater").value<QObject*>() == this)
            ret += t->downloadSpeed();
    }
```

#### AUTO 


```{c}
auto upgrade = dynamic_cast<SystemUpgrade *>(res)
```

#### AUTO 


```{c}
auto requestedSnap = jobResult(socket.snapByName(name)).toObject();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &v : input) {
        if (op(v))
            ret += v;
    }
```

#### AUTO 


```{c}
auto match = rx.match(buff);
```

#### AUTO 


```{c}
auto icon = req->icon();
```

#### AUTO 


```{c}
auto components = backend()->componentsById(m_appdata.extends().constFirst());
```

#### AUTO 


```{c}
auto actions = m_filteredActions;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &alt : alts) {
                at = storedIds.find(alt);
                if (at != storedIds.end())
                    break;
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &file){
        auto service = PackageKitBackend::locateService(file);
        if (!service.isEmpty())
            m_actions += QVariant::fromValue<QObject*>(createActionForService(service, this));
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&bundleId](const AppStream::Component &comp) -> bool {
                return comp.bundle(AppStream::Bundle::Kind::KindFlatpak).id() == bundleId;
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (PackageKit::Transaction *t : qAsConst(m_transactions)) {
        connect(t, &PackageKit::Transaction::finished, this, &PKResolveTransaction::transactionFinished);
    }
```

#### AUTO 


```{c}
auto last = resources.constFirst();
```

#### RANGE FOR STATEMENT 


```{c}
for (QListView *view : m_listViews) {
        selectFirstRow(view);
    }
```

#### AUTO 


```{c}
auto inst
```

#### AUTO 


```{c}
auto uri = "org.kde.discover";
```

#### RANGE FOR STATEMENT 


```{c}
for (auto o : objs)
            delete o;
```

#### AUTO 


```{c}
auto futureWatcher = new QFutureWatcher<FlatpakRunnables::SizeInformation>(this);
```

#### AUTO 


```{c}
const auto basenameSig = QString::fromUtf8(g_path_get_basename(fwupd_remote_get_filename_cache_sig(remote)));
```

#### LAMBDA EXPRESSION 


```{c}
[this, stream, entryid, providerid](const KNSCore::EntryInternal &entry) {
            if (entry.uniqueId() == entryid && providerid == QUrl(entry.providerId()).host()) {
                stream->resourcesFound({resourceForEntry(entry)});
            } else
                qWarning() << "found invalid" << entryid << entry.uniqueId() << providerid << QUrl(entry.providerId()).host();
            m_responsePending = false;
            QTimer::singleShot(0, this, &KNSBackend::availableForQueries);
            stream->finish();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& potentialSubCat: categories) {
            if(potentialSubCat->name().startsWith(catName)) {
                cat->addSubcategory(potentialSubCat);
                topCategories.removeOne(potentialSubCat);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto resource : qAsConst(resources))
        addResource(resource);
```

#### AUTO 


```{c}
auto action = new OneTimeAction(
        [this, url]() {
            AbstractResourcesBackend::Filters f;
            f.resourceUrl = url;
            auto stream = new StoredResultsStream({ResourcesModel::global()->search(f)});
            connect(stream, &StoredResultsStream::finished, this, [this, url, stream]() {
                const auto res = stream->resources();
                qDebug() << "results..." << res;
                if (res.count() == 1) {
                    emit openApplicationInternal(res.first());
                } else {
                    rootObject()->setProperty("defaultStartup", true);
                    showPassiveNotification(i18n("Couldn't open %1", url.toDisplayString()));
                }
            });
        }
        , this);
```

#### LAMBDA EXPRESSION 


```{c}
[] {qDebug() << "."; }
```

#### LAMBDA EXPRESSION 


```{c}
[](AbstractResourcesBackend *b) {
            return b->hasApplications();
        }
```

#### AUTO 


```{c}
const auto file = it.key();
```

#### AUTO 


```{c}
const auto SourcesBackendId = "SourcesBackend";
```

#### AUTO 


```{c}
auto ret = source->m_resources.value(idForInstalledRef(ref, {}));
```

#### LAMBDA EXPRESSION 


```{c}
[this, url, stream]() {
                const auto res = stream->resources();
                qDebug() << "results..." << res;
                if (res.count() == 1) {
                    emit openApplicationInternal(res.first());
                } else {
                    rootObject()->setProperty("defaultStartup", true);
                    showPassiveNotification(i18n("Couldn't open %1", url.toDisplayString()));
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[res]() {
                qWarning() << "No installable candidates in the KNewStuff entry" << res->entry().name() << "with id" << res->entry().uniqueId() << "on the backend" << res->backend()->name() << "There should always be at least one downloadable item in an OCS entry, and if there isn't, we should consider it broken. OCS can technically show them, but if there is nothing to install, it cannot be installed.";
            }
```

#### LAMBDA EXPRESSION 


```{c}
[](){ qDebug() << "disconnected :("; }
```

#### AUTO 


```{c}
const auto res2 = getResources(m_backend->search(f));
```

#### LAMBDA EXPRESSION 


```{c}
[this, stream, filter] {
            const auto toResolve = kFilter<QVector<AbstractResource *>>(m_packages.packages, needsResolveFilter);

            auto installedAndNameFilter = [filter](AbstractResource *res) {
                return res->state() >= AbstractResource::Installed && !qobject_cast<PackageKitResource *>(res)->isCritical()
                    && (res->name().contains(filter.search, Qt::CaseInsensitive) || res->packageName().compare(filter.search, Qt::CaseInsensitive) == 0);
            };
            bool furtherSearch = false;
            if (!toResolve.isEmpty()) {
                resolvePackages(kTransform<QStringList>(toResolve, [](AbstractResource *res) {
                    return res->packageName();
                }));
                connect(m_resolveTransaction, &PKResolveTransaction::allFinished, this, [stream, toResolve, installedAndNameFilter] {
                    const auto resolved = kFilter<QVector<AbstractResource *>>(toResolve, installedAndNameFilter);
                    if (!resolved.isEmpty())
                        Q_EMIT stream->resourcesFound(resolved);
                    stream->finish();
                });
                furtherSearch = true;
            }

            const auto resolved = kFilter<QVector<AbstractResource *>>(m_packages.packages, installedAndNameFilter);
            if (!resolved.isEmpty()) {
                QTimer::singleShot(0, this, [resolved, toResolve, stream]() {
                    if (!resolved.isEmpty())
                        Q_EMIT stream->resourcesFound(resolved);

                    if (toResolve.isEmpty())
                        stream->finish();
                });
                furtherSearch = true;
            }

            if (!furtherSearch)
                stream->finish();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, stream, filter]() {
            if (m_isValid) {
                auto filterFunction = [&filter](AbstractResource* r) { return r->state()>=filter.state && (r->name().contains(filter.search, Qt::CaseInsensitive) || r->comment().contains(filter.search, Qt::CaseInsensitive)); };
                const auto ret = kFilter<QVector<AbstractResource*>>(m_resourcesByName, filterFunction);

                if (!ret.isEmpty())
                    Q_EMIT stream->resourcesFound(ret);
            }
            stream->finish();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[importantAction](){
        importantAction->setEnabled(false);
        qDebug() << "important action triggered";
    }
```

#### LAMBDA EXPRESSION 


```{c}
[stream, this, state, job]() {
        static_assert(std::is_base_of<QSnapdRequest, T>::value, "we can only populate QSnapdRequest");
        QSet<SnapResource*> higher = kFilter<QSet<SnapResource*>>(m_resources, [state](AbstractResource* res){ return res->state()>=state; });

        QVector<AbstractResource*> ret;
        QSet<SnapResource*> resources;
        for (int i=0, c=job->snapCount(); i<c; ++i) {
            QSharedPointer<QSnapdSnap> snap(job->snap(i));
            const auto snapname = snap->name();
            SnapResource* res = m_resources.value(snapname);
            if (!res) {
                res = new SnapResource(snap, state, this);
                Q_ASSERT(res->packageName() == snapname);
                resources += res;
            } else {
                res->setState(state);
                higher.remove(res);
            }
            ret += res;
        }

        foreach(SnapResource* res, resources)
            m_resources[res->packageName()] = res;
        for(auto res: higher) {
            res->setState(AbstractResource::None);
        }

        if (!ret.isEmpty())
            stream->resourcesFound(ret);
        stream->finish();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QLocalSocket::LocalSocketError socketError){
            qDebug() << "error!" << socketError;
            Q_EMIT finished(this);
        }
```

#### AUTO 


```{c}
const auto sortUpdateItems = [](UpdateItem *a, UpdateItem *b) {
        return a->name() < b->name();
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &toRemove : addonsToRemove) {
        setAddonInstalled(toRemove, false);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractResource * app : apps) {
        m_toUpgrade.removeAll(app);
    }
```

#### AUTO 


```{c}
const auto pkgid = pkgidVal.toString();
```

#### AUTO 


```{c}
auto it = m_newPackageStates.constBegin(), itEnd = m_newPackageStates.constEnd();
```

#### AUTO 


```{c}
auto t = m_appBackend->installApplication(resRssguard);
```

#### LAMBDA EXPRESSION 


```{c}
[this, stream, filter] {
            const auto toResolve = kFilter<QVector<AbstractResource*>>(m_packages.packages, needsResolveFilter);

            auto installedAndNameFilter = [filter] (AbstractResource *res) {
                return res->state() >= AbstractResource::Installed && (res->name().contains(filter.search) || res->packageName() == filter.search);
            };
            if (!toResolve.isEmpty()) {
                resolvePackages(kTransform<QStringList>(toResolve, [] (AbstractResource* res) { return res->packageName(); }));
                connect(m_resolveTransaction, &PKResolveTransaction::allFinished, this, [stream, toResolve, installedAndNameFilter] {
                    const auto resolved = kFilter<QVector<AbstractResource*>>(toResolve, installedAndNameFilter);
                    if (!resolved.isEmpty())
                        Q_EMIT stream->resourcesFound(resolved);
                    stream->finish();
                });
            }

            const auto resolved = kFilter<QVector<AbstractResource*>>(m_packages.packages, installedAndNameFilter);
            if (!resolved.isEmpty()) {
                QTimer::singleShot(0, this, [resolved, toResolve, stream] () {
                    if (!resolved.isEmpty())
                        Q_EMIT stream->resourcesFound(resolved);

                    if (toResolve.isEmpty())
                        stream->finish();
            });
            }
        }
```

#### AUTO 


```{c}
auto f = [this, stream, appstreamIds] () {
                const auto resources = kAppend<QVector<AbstractResource*>>(appstreamIds, [this] (const QString appstreamId) { return resourcesByAppstreamName(appstreamId); });
                if (!resources.isEmpty())
                    Q_EMIT stream->resourcesFound(resources);
                stream->finish();
            };
```

#### RANGE FOR STATEMENT 


```{c}
for (auto t: allTransactions) {
        allProgresses += t->progress();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](AbstractResource* resource, AbstractResource* res){ return lessThan(resource, res); }
```

#### AUTO 


```{c}
const auto &e
```

#### RANGE FOR STATEMENT 


```{c}
for (BackendNotifierModule *module : m_backends)
        ret += QString::fromLatin1(module->metaObject()->className());
```

#### AUTO 


```{c}
const auto candidates = m_backend->upgradeablePackages();
```

#### LAMBDA EXPRESSION 


```{c}
[this, jobs, filter, stream] {
        QVector<AbstractResource*> ret;
        for (auto job : jobs) {
            job->deleteLater();
            if (job->error()) {
                qDebug() << "error:" << job->error() << job->errorString();
                continue;
            }

            for (int i=0, c=job->snapCount(); i<c; ++i) {
                QSharedPointer<QSnapdSnap> snap(job->snap(i));

                if (!filter(snap))
                    continue;

                const auto snapname = snap->name();
                SnapResource*& res = m_resources[snapname];
                if (!res) {
                    res = new SnapResource(snap, AbstractResource::None, this);
                    Q_ASSERT(res->packageName() == snapname);
                } else {
                    res->setSnap(snap);
                }
                ret += res;
            }
        }

        if (!ret.isEmpty())
            Q_EMIT stream->resourcesFound(ret);
        stream->finish();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, localfile](const QVector<AbstractResource*> &res) {
                if (res.count() == 1) {
                    emit openApplicationInternal(res.first());
                } else {
                    QMimeDatabase db;
                    auto mime = db.mimeTypeForUrl(localfile);
                    auto fIsFlatpakBackend = [](AbstractResourcesBackend* backend) { return backend->metaObject()->className() == QByteArray("FlatpakBackend"); };
                    if (mime.name().startsWith(QLatin1String("application/vnd.flatpak")) && !kContains(ResourcesModel::global()->backends(), fIsFlatpakBackend)) {
                        openApplication(QUrl(QStringLiteral("appstream://org.kde.discover.flatpak")));
                        showPassiveNotification(i18n("Cannot interact with flatpak resources without the flatpak backend %1. Please install it first.", localfile.toDisplayString()));
                    } else {
                        openMode(QStringLiteral("Browsing"));
                        showPassiveNotification(i18n("Couldn't open %1", localfile.toDisplayString()));
                    }
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[] (PackageKit::Transaction::Exit status, uint runtime) {
                qInfo() << "repair finished!" << status << runtime;
                if (status == PackageKit::Transaction::ExitSuccess) {
                    PackageKit::Daemon::global()->offline()->clearResults();

                    KNotification::event(QStringLiteral("OfflineUpdateRepairSuccessful"),
                                         i18n("Repaired Successfully"),
                                         {},
                                         {},
                                         KNotification::CloseOnTimeout,
                                         QStringLiteral("org.kde.discovernotifier"));
                }
            }
```

#### AUTO 


```{c}
const auto res = resourcesByPackageNames<QVector<AbstractResource*>>({PackageKit::Daemon::packageName(packageId.toString())});
```

#### AUTO 


```{c}
auto resource = getAppForInstalledRef(it.key(), ref);
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
            m_resolveTransaction = nullptr;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[resources, this]() {
            setResources(resources);
            finish();
        }
```

#### AUTO 


```{c}
const auto providerid = pathParts.at(0);
```

#### LAMBDA EXPRESSION 


```{c}
[installations, cancellable] {
                QMap<FlatpakInstallation *, QVector<FlatpakInstalledRef *>> ret;

                for (auto installation : installations) {
                    g_autoptr(GError) localError = nullptr;
                    g_autoptr(GPtrArray) refs = flatpak_installation_list_installed_refs_for_update(installation, cancellable, &localError);
                    if (!refs) {
                        qWarning() << "Failed to get list of installed refs for listing updates:" << localError->message;
                        continue;
                    }
                    if (g_cancellable_is_cancelled(cancellable)) {
                        qWarning() << "Job cancelled";
                        return ret;
                    }

                    auto &current = ret[installation];
                    current.reserve(refs->len);
                    for (uint i = 0; i < refs->len; i++) {
                        FlatpakInstalledRef *ref = FLATPAK_INSTALLED_REF(g_ptr_array_index(refs, i));
                        g_object_ref(ref);
                        current.append(ref);
                    }
                }
                return ret;
            }
```

#### LAMBDA EXPRESSION 


```{c}
[](AbstractResourcesBackend* backend) {
        return backend->name() == QLatin1String("discover_ktexteditor_codesnippets_core.knsrc");
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, originalUrl, fileUrl, replyPut]() {
                if (replyPut->error() == QNetworkReply::NoError) {
                    auto res = m_backend->resourceForFile(fileUrl);
                    if (res) {
                        FlatpakResource *resource = qobject_cast<FlatpakResource*>(res);
                        resource->setResourceFile(originalUrl);
                        Q_EMIT jobFinished(true, resource);
                    } else {
                        qWarning() << "couldn't download" << originalUrl << "into" << fileUrl << replyPut->errorString();
                        Q_EMIT jobFinished(false, nullptr);
                    }
                }
            }
```

#### AUTO 


```{c}
auto it = m_updatingPackages.begin();
```

#### AUTO 


```{c}
auto start = [this, entryid, stream, providerid]() {
        m_responsePending = true;
        m_engine->fetchEntryById(entryid);
        m_onePage = false;

        connect(m_engine, &KNSCore::Engine::signalErrorCode, stream, &ResultsStream::finish);
        connect(m_engine,
                &KNSCore::Engine::signalEntryEvent,
                stream,
                [this, stream, entryid, providerid](const KNSCore::EntryInternal &entry, KNSCore::EntryInternal::EntryEvent event) {
                    switch (event) {
                    case KNSCore::EntryInternal::StatusChangedEvent:
                        if (entry.uniqueId() == entryid && providerid == QUrl(entry.providerId()).host()) {
                            Q_EMIT stream->resourcesFound({resourceForEntry(entry)});
                        } else
                            qWarning() << "found invalid" << entryid << entry.uniqueId() << providerid << QUrl(entry.providerId()).host();
                        m_responsePending = false;
                        QTimer::singleShot(0, this, &KNSBackend::availableForQueries);
                        stream->finish();
                        break;
                    case KNSCore::EntryInternal::DetailsLoadedEvent:
                    case KNSCore::EntryInternal::AdoptedEvent:
                    case KNSCore::EntryInternal::UnknownEvent:
                    default:
                        break;
                    }
                });
    };
```

#### AUTO 


```{c}
auto item = itemFromResource(app);
```

#### LAMBDA EXPRESSION 


```{c}
[this, installation, resource] (Transaction::Status status) {
        if (status == Transaction::Status::DoneStatus) {
            updateAppState(installation, resource);
        }
    }
```

#### AUTO 


```{c}
const auto res = getResources(m_backend->findResourceByPackageName(url));
```

#### LAMBDA EXPRESSION 


```{c}
[this] () -> GPtrArray*
        {
            const uint cacheAge = (24*60*60); // Check for updates every day
            g_autoptr(GError) error = nullptr;

            /* get devices */
            GPtrArray* devices = fwupd_client_get_devices(client, m_cancellable, nullptr);


            g_autoptr(GPtrArray) remotes = fwupd_client_get_remotes(client, m_cancellable, &error);
            for(uint i = 0; remotes && i < remotes->len; i++)
            {
                FwupdRemote *remote = (FwupdRemote *)g_ptr_array_index(remotes, i);
                if (!fwupd_remote_get_enabled(remote))
                    continue;

                if (fwupd_remote_get_kind(remote) == FWUPD_REMOTE_KIND_LOCAL)
                    continue;

                refreshRemote(this, remote, cacheAge, m_cancellable);
            }
            return devices;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto t : transactions) {
        auto updateTransaction = qobject_cast<UpdateTransaction *>(t);
        if (updateTransaction) {
            setTransaction(updateTransaction);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, stream, filter] {
            QVector<AbstractResource *> resources;
            for (auto installation : m_installations) {
                g_autoptr(GError) localError = nullptr;
                g_autoptr(GPtrArray) refs = flatpak_installation_list_installed_refs(installation, m_cancellable, &localError);
                if (!refs) {
                    qWarning() << "Failed to get list of installed refs for listing installed:" << localError->message;
                    continue;
                }

                resources.reserve(resources.size() + refs->len);
                for (uint i = 0; i < refs->len; i++) {
                    FlatpakInstalledRef *ref = FLATPAK_INSTALLED_REF(g_ptr_array_index(refs, i));
                    QString name = QString::fromUtf8(flatpak_installed_ref_get_appdata_name(ref));
                    if (name.endsWith(QLatin1String(".Debug")) || name.endsWith(QLatin1String(".Locale")) || name.endsWith(QLatin1String(".BaseApp"))
                        || name.endsWith(QLatin1String(".Docs")))
                        continue;

                    auto resource = getAppForInstalledRef(installation, ref);
                    if (!filter.search.isEmpty() && !resource->name().contains(filter.search, Qt::CaseInsensitive))
                        continue;

                    if (resource->resourceType() == FlatpakResource::Runtime) {
                        resources.prepend(resource);
                    } else {
                        resources.append(resource);
                    }
                }
            }
            if (!resources.isEmpty())
                Q_EMIT stream->resourcesFound(resources);
            stream->finish();
        }
```

#### AUTO 


```{c}
const auto extends = res->extends();
```

#### LAMBDA EXPRESSION 


```{c}
[this](AppPackageKitResource *r) {
        return r->allPackageNames() != allPackageNames();
    }
```

#### AUTO 


```{c}
const auto &v
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractBackendUpdater *upd : qAsConst(m_updaters)) {
        QDateTime current = upd->lastUpdate();
        if (!ret.isValid() || (current.isValid() && current > ret)) {
            ret = current;
        }
    }
```

#### AUTO 


```{c}
const auto packages = packagesJoined.splitRef(QLatin1Char(','));
```

#### AUTO 


```{c}
auto prog = QStringLiteral("rpm-ostree");
```

#### AUTO 


```{c}
const auto res = resourcesByPackageNames<QVector<AbstractResource*>, QVector<QString>>({PackageKit::Daemon::packageName(packageId.toString())});
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractResourcesBackend *backend : backends) {
        resourcesModel->addResourcesBackend(backend);
        backend->integrateMainWindow(this);
        
        if(backend->metaObject()->className()==QLatin1String("ApplicationBackend")) {
            m_appBackend = backend;
            connect(m_appBackend, SIGNAL(backendReady()),
                    this, SLOT(populateViews()));
            connect(m_appBackend, SIGNAL(reloadStarted()), //TODO: use ResourcesModel signals
                    this, SLOT(removeProgressItem()));
            connect(m_appBackend, SIGNAL(reloadFinished()),
                    this, SLOT(showLauncherMessage()));
            connect(m_appBackend, SIGNAL(startingFirstTransaction()),
                    this, SLOT(addProgressItem()));
            connect(m_appBackend, SIGNAL(sourcesEditorFinished()),
                    this, SLOT(sourcesEditorFinished()));
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, stream, filter] () {
            const QList<AppStream::Component> components = m_appdata->search(filter.search);
            const QStringList ids = kTransform<QStringList>(components, [](const AppStream::Component& comp) { return comp.id(); });
            if (!ids.isEmpty()) {
                const auto resources = kFilter<QVector<AbstractResource*>>(resourcesByPackageNames<QVector<AbstractResource*>>(ids), [](AbstractResource* res){ return !qobject_cast<PackageKitResource*>(res)->extendsItself(); });
                stream->setResources(resources);
            }

            PackageKit::Transaction * tArch = PackageKit::Daemon::resolve(filter.search, PackageKit::Transaction::FilterArch);
            connect(tArch, &PackageKit::Transaction::package, this, &PackageKitBackend::addPackageArch);
            connect(tArch, &PackageKit::Transaction::package, stream, [stream](PackageKit::Transaction::Info /*info*/, const QString &packageId){
                stream->setProperty("packageId", packageId);
            });
            connect(tArch, &PackageKit::Transaction::finished, stream, [stream, ids, this](PackageKit::Transaction::Exit status) {
                getPackagesFinished();
                if (status == PackageKit::Transaction::Exit::ExitSuccess) {
                    const auto packageId = stream->property("packageId");
                    if (!packageId.isNull()) {
                        const auto res = resourcesByPackageNames<QVector<AbstractResource*>>({PackageKit::Daemon::packageName(packageId.toString())});
                        stream->setResources(kFilter<QVector<AbstractResource*>>(res, [ids](AbstractResource* res){ return !ids.contains(res->appstreamId()); }));
                    }
                }
                stream->finish();
            }, Qt::QueuedConnection);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        if (QFile::exists(QStringLiteral(PK_OFFLINE_ACTION_FILENAME)))
            nowNeedsReboot();
    }
```

#### AUTO 


```{c}
auto res = createApp(device);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &source : m_flatpakSources) {
        auto ret = source->m_resources.value(id2);
        if (ret) {
            return ret;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[cancel, t, this](PackageKit::Transaction::Exit /*status*/, uint /*runtime*/){ QMap<PackageKit::Transaction::Info, QStringList> packages = t->property("packages").value<QMap<PackageKit::Transaction::Info, QStringList>>(); qobject_cast<PackageKitResource*>(resource())->setPackages(packages); setStatus(Transaction::DoneStatus); if (cancel) qobject_cast<PackageKitBackend*>(resource()->backend())->transactionCanceled(this); else qobject_cast<PackageKitBackend*>(resource()->backend())->removeTransaction(this); }
```

#### AUTO 


```{c}
auto keys = ratings.keys().toSet();
```

#### AUTO 


```{c}
auto idx = kIndexOf(backends, [name](AbstractResourcesBackend* b) { return b->name() == name; });
```

#### AUTO 


```{c}
auto installedAndNameFilter = [filter](AbstractResource *res) {
                return res->state() >= AbstractResource::Installed
                    && (res->name().contains(filter.search, Qt::CaseInsensitive) || res->packageName().compare(filter.search, Qt::CaseInsensitive) == 0);
            };
```

#### AUTO 


```{c}
auto curr = resById.value(id);
```

#### AUTO 


```{c}
auto backend = qobject_cast<SnapBackend*>(parent());
```

#### RANGE FOR STATEMENT 


```{c}
for (auto res : (m_resources - candidates)) {
            disconnect(res, &AbstractResource::sizeChanged, this, &SystemUpgrade::refreshResource);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto resource : resources) {
                auto pkres = qobject_cast<PackageKitResource*>(resource);
                pkres->setDependenciesCount(it.value());
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        m_reviews->emitRatingFetched(this, kTransform<QList<AbstractResource *>>(m_resources.values(), [](AbstractResource *r) {
                                         return r;
                                     }));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](AbstractResource *res) {
                return res->type() != AbstractResource::Technical && !qobject_cast<PackageKitResource *>(res)->extendsItself();
            }
```

#### AUTO 


```{c}
const auto subcats = walkCategories(res, cat->subCategories());
```

#### AUTO 


```{c}
auto fw = new QFutureWatcher<QList<AppStream::Component>>(this);
```

#### AUTO 


```{c}
auto transaction = PackageKit::Daemon::global()->repoEnable(item->data(AbstractSourcesBackend::IdRole).toString(), value.toInt() == Qt::Checked);
```

#### AUTO 


```{c}
auto res = job->result().toObject();
```

#### AUTO 


```{c}
const auto dest = qScopeGuard([this] {
            acquireFetching(false);
            refresh();
        });
```

#### LAMBDA EXPRESSION 


```{c}
[this, filter, stream] {
            const auto resources = kTransform<QVector<AbstractResource*>>(m_packages.extendedBy.value(filter.extends), [](AppPackageKitResource* a){ return a; });
            if (!resources.isEmpty()) {
                stream->setResources(resources);
            }
            stream->finish();
        }
```

#### AUTO 


```{c}
auto instref = flatpak_installation_get_installed_ref(installation,
                                                              FLATPAK_REF_KIND_RUNTIME,
                                                              runtimeInfo.at(0).toUtf8().constData(),
                                                              runtimeInfo.at(1).toUtf8().constData(),
                                                              runtimeInfo.at(2).toUtf8().constData(),
                                                              m_cancellable,
                                                              nullptr);
```

#### RANGE FOR STATEMENT 


```{c}
for(BackendNotifierModule* module : m_backends)
        module->recheckSystemUpdateNeeded();
```

#### AUTO 


```{c}
auto md = flatpak_installed_ref_load_metadata(ref, m_cancellable, &gerror);
```

#### AUTO 


```{c}
auto f = [this, stream] {
            auto fw = new QFutureWatcher<QMap<FlatpakInstallation *, QVector<FlatpakInstalledRef *>>>(this);
            connect(fw, &QFutureWatcher<QByteArray>::finished, this, [this, fw, stream]() {
                if (g_cancellable_is_cancelled(m_cancellable)) {
                    stream->finish();
                    fw->deleteLater();
                    return;
                }

                const auto refs = fw->result();
                QVector<AbstractResource *> resources;
                for (auto it = refs.constBegin(), itEnd = refs.constEnd(); it != itEnd; ++it) {
                    resources.reserve(resources.size() + it->size());
                    for (auto ref : qAsConst(it.value())) {
                        auto resource = getAppForInstalledRef(it.key(), ref);
#if FLATPAK_CHECK_VERSION(1, 1, 2)
                        resource->setAvailableVersion(QString::fromUtf8(flatpak_installed_ref_get_appdata_version(ref)));
#endif
                        g_object_unref(ref);
                        resource->setState(AbstractResource::Upgradeable);
                        updateAppSize(resource);
                        if (resource->resourceType() == FlatpakResource::Runtime) {
                            resources.prepend(resource);
                        } else {
                            resources.append(resource);
                        }
                    }
                }

                if (!resources.isEmpty())
                    Q_EMIT stream->resourcesFound(resources);
                stream->finish();
                fw->deleteLater();
            });

            QVector<FlatpakInstallation *> installations = m_installations;
            auto cancellable = m_cancellable;
            fw->setFuture(QtConcurrent::run(&m_threadPool, [installations, cancellable] {
                QMap<FlatpakInstallation *, QVector<FlatpakInstalledRef *>> ret;

                for (auto installation : installations) {
                    g_autoptr(GError) localError = nullptr;
                    g_autoptr(GPtrArray) refs = flatpak_installation_list_installed_refs_for_update(installation, cancellable, &localError);
                    if (!refs) {
                        qWarning() << "Failed to get list of installed refs for listing updates:" << localError->message;
                        continue;
                    }
                    if (g_cancellable_is_cancelled(cancellable)) {
                        qWarning() << "Job cancelled";
                        return ret;
                    }

                    auto &current = ret[installation];
                    current.reserve(refs->len);
                    for (uint i = 0; i < refs->len; i++) {
                        FlatpakInstalledRef *ref = FLATPAK_INSTALLED_REF(g_ptr_array_index(refs, i));
                        g_object_ref(ref);
                        current.append(ref);
                    }
                }
                return ret;
            }));
        };
```

#### AUTO 


```{c}
auto fetchRemoteResource = new FlatpakFetchRemoteResourceJob(runtimeUrl, repoStream, this);
```

#### LAMBDA EXPRESSION 


```{c}
[this](){
    if (QFile::exists(QStringLiteral(PK_OFFLINE_ACTION_FILENAME)))
        nowNeedsReboot();
    }
```

#### AUTO 


```{c}
auto upgradeList = m_toUpgrade.values();
```

#### AUTO 


```{c}
const auto toUpgrade = upgradeablePackages();
```

#### AUTO 


```{c}
const auto found = res->categoryObjects(kSetToVector(cats));
```

#### AUTO 


```{c}
const auto res = getResources(ResourcesModel::global()->findResourceByPackageName(QUrl(QStringLiteral("kns://plasma-themes.knsrc/api.kde-look.org/1136471"))));
```

#### RANGE FOR STATEMENT 


```{c}
for (Transaction *t : qAsConst(m_transactions)) {
        if (t->isActive() && t->isVisible()) {
            sum += t->progress();
            ++count;
        }
    }
```

#### AUTO 


```{c}
auto res = m_resources.value(search);
```

#### AUTO 


```{c}
const auto cats = m_filters.category ? m_filters.category->subCategories() : CategoryModel::global()->rootCategories();
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        m_reviews->emitRatingFetched(this, kTransform<QList<AbstractResource*>>(m_packages.packages.values(), [] (AbstractResource* r) { return r; }));
    }
```

#### AUTO 


```{c}
auto trans = PackageKit::Daemon::installPackage(id, PackageKit::Transaction::TransactionFlagSimulate);
```

#### LAMBDA EXPRESSION 


```{c}
[this](AbstractResource *res, AbstractResource *res2) {
            return lessThan(res, res2);
        }
```

#### AUTO 


```{c}
const auto resources = fetchResources(m_appBackend->findResourceByPackageName(QStringLiteral("Dummy 1")));
```

#### AUTO 


```{c}
const auto ids = m_packageNamesToFetchDetails.values();
```

#### LAMBDA EXPRESSION 


```{c}
[this](){ m_initialized = true; }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto res : qAsConst(m_resources)) {
            const auto versions = res->upgradeText();
            const auto idx = versions.indexOf(u'\u009C');
            changes += QStringLiteral("<li>") + res->packageName() + QStringLiteral(": ") + versions.leftRef(idx) + QStringLiteral("</li>\n");
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        if (m_initializingBackends == 0)
            emit allInitialized();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](Transaction *t) {
        return t->property("updater").value<QObject *>() == this;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, resource, futureWatcher]() {
            auto value = futureWatcher->result();
            if (value.valid) {
                onFetchSizeFinished(resource, value.downloadSize, value.installedSize);
            } else {
                resource->setPropertyState(FlatpakResource::DownloadSize, FlatpakResource::UnknownOrFailed);
                resource->setPropertyState(FlatpakResource::InstalledSize, FlatpakResource::UnknownOrFailed);
            }
            futureWatcher->deleteLater();
        }
```

#### AUTO 


```{c}
const auto resources = b->resources();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto r : res) {
        ret += func(qobject_cast<PackageKitResource *>(r));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(KService::Ptr exe : exes) {
        ret += exe->exec();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, replyGet] {
            QScopedPointer<QNetworkReply, QScopedPointerDeleteLater> replyPtr(replyGet);
            const QUrl originalUrl = replyGet->request().url();
            if (replyGet->error() != QNetworkReply::NoError) {
                qWarning() << "couldn't download" << originalUrl << replyGet->errorString();
                Q_EMIT jobFinished(false, nullptr);
                return;
            }

            const QUrl fileUrl = QUrl::fromLocalFile(QStandardPaths::writableLocation(QStandardPaths::TempLocation) //
                                                     + QLatin1Char('/') + originalUrl.fileName());
            auto replyPut = put(QNetworkRequest(fileUrl), replyGet->readAll());
            connect(replyPut, &QNetworkReply::finished, this, [this, originalUrl, fileUrl, replyPut]() {
                QScopedPointer<QNetworkReply, QScopedPointerDeleteLater> replyPtr(replyPut);
                if (replyPut->error() != QNetworkReply::NoError) {
                    qWarning() << "couldn't save" << originalUrl << replyPut->errorString();
                    Q_EMIT jobFinished(false, nullptr);
                    return;
                }
                if (!fileUrl.isLocalFile()) {
                    Q_EMIT jobFinished(false, nullptr);
                    return;
                }

                FlatpakResource *resource = nullptr;
                if (fileUrl.path().endsWith(QLatin1String(".flatpak"))) {
                    resource = m_backend->addAppFromFlatpakBundle(fileUrl);
                } else if (fileUrl.path().endsWith(QLatin1String(".flatpakref"))) {
                    resource = m_backend->addAppFromFlatpakRef(fileUrl);
                } else if (fileUrl.path().endsWith(QLatin1String(".flatpakrepo"))) {
                    resource = m_backend->addSourceFromFlatpakRepo(fileUrl);
                }

                if (resource) {
                    resource->setResourceFile(originalUrl);
                    Q_EMIT jobFinished(true, resource);
                } else {
                    qWarning() << "couldn't create resource from" << fileUrl.toLocalFile();
                    Q_EMIT jobFinished(false, nullptr);
                }
            });
        }
```

#### AUTO 


```{c}
auto number = numberString.toInt(&ok, 16);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto r : res) {
        static_cast<PackageKitResource *>(r)
            ->updateDetail(packageID, updates, obsoletes, vendorUrls, bugzillaUrls, cveUrls, restart, updateText, changelog, state, issued, updated);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, localfile]() {
            AbstractResourcesBackend::Filters f;
            f.resourceUrl = localfile;
            auto stream = new StoredResultsStream({ResourcesModel::global()->search(f)});
            connect(stream, &StoredResultsStream::finishedResources, this, [this, localfile](const QVector<AbstractResource*> &res) {
                if (res.count() == 1) {
                    emit openApplicationInternal(res.first());
                } else {
                    QMimeDatabase db;
                    auto mime = db.mimeTypeForUrl(localfile);
                    auto fIsFlatpakBackend = [](AbstractResourcesBackend* backend) { return backend->metaObject()->className() == QByteArray("FlatpakBackend"); };
                    if (mime.name().startsWith(QLatin1String("application/vnd.flatpak")) && !kContains(ResourcesModel::global()->backends(), fIsFlatpakBackend)) {
                        openApplication(QUrl(QStringLiteral("appstream://org.kde.discover.flatpak")));
                        showPassiveNotification(i18n("Cannot interact with flatpak resources without the flatpak backend %1. Please install it first.", localfile.toDisplayString()));
                    } else {
                        setRootObjectProperty("defaultStartup", true);
                        showPassiveNotification(i18n("Couldn't open %1", localfile.toDisplayString()));
                    }
                }
            });
        }
```

#### AUTO 


```{c}
const auto processedPercentage = percentageWithStatus(m_trans->status(), qBound<int>(0, percent, 100));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &pkgid : itValue) {
            const auto resources = backend->resourcesByPackageName(PackageKit::Daemon::packageName(pkgid));
            for (auto res : resources) {
                auto r = qobject_cast<PackageKitResource *>(res);
                r->clearPackageIds();
                r->addPackageId(state, pkgid, true);
            }
        }
```

#### AUTO 


```{c}
auto app = qobject_cast<AbstractResource *>(sender());
```

#### AUTO 


```{c}
auto reply = m_nam->post(request, document.toJson());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &filter : orFilters) {
            if (shouldFilter(this, filter)) {
                orValue = true;
                break;
            }
        }
```

#### AUTO 


```{c}
auto installedAndNameFilter = [filter](AbstractResource *res) {
                return res->state() >= AbstractResource::Installed && !qobject_cast<PackageKitResource *>(res)->isCritical()
                    && (res->name().contains(filter.search, Qt::CaseInsensitive) || res->packageName().compare(filter.search, Qt::CaseInsensitive) == 0);
            };
```

#### AUTO 


```{c}
const auto start = [this, stream, filter]() {
            if (m_isValid) {
                auto filterFunction = [&filter](AbstractResource* r) { return r->state()>=filter.state && (r->name().contains(filter.search, Qt::CaseInsensitive) || r->comment().contains(filter.search, Qt::CaseInsensitive)); };
                const auto ret = kFilter<QVector<AbstractResource*>>(m_resourcesByName, filterFunction);

                if (!ret.isEmpty())
                    Q_EMIT stream->resourcesFound(ret);
            }
            stream->finish();
        };
```

#### AUTO 


```{c}
auto req = qobject_cast<QSnapdGetIconRequest*>(sender());
```

#### AUTO 


```{c}
auto app = qobject_cast<SnapResource*>(_app);
```

#### AUTO 


```{c}
auto reply = nam()->post(request, json);
```

#### LAMBDA EXPRESSION 


```{c}
[this, fw, flatpakInstallation, appstreamIconsPath, sourceName]() {
        const auto components = fw->result();
        QVector<FlatpakResource*> resources;
        for (const AppStream::Component& appstreamComponent : components) {
            FlatpakResource *resource = new FlatpakResource(appstreamComponent, flatpakInstallation, this);
            resource->setIconPath(appstreamIconsPath);
            resource->setOrigin(sourceName);
            if (resource->resourceType() == FlatpakResource::Runtime) {
                resources.prepend(resource);
            } else {
                resources.append(resource);
            }
        }
        for (auto resource : qAsConst(resources)) {
            addResource(resource);
        }

        metadataRefreshed();
        acquireFetching(false);
        fw->deleteLater();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, fw]() {
        const auto data = fw->result();
        fw->deleteLater();

        if (!data.correct && m_packages.packages.isEmpty()) {
            QTimer::singleShot(0, this, [this]() {
                Q_EMIT passiveMessage(i18n("Please make sure that Appstream is properly set up on your system"));
            });
        }
        for (const auto &component : data.components) {
            const auto pkgNames = component.packageNames();
            addComponent(component, pkgNames);
        }

        if (data.components.isEmpty()) {
            qCDebug(LIBDISCOVER_BACKEND_LOG) << "empty appstream db";
            if (PackageKit::Daemon::backendName() == QLatin1String("aptcc") || PackageKit::Daemon::backendName().isEmpty()) {
                checkForUpdates();
            }
        }
        if (!m_appstreamInitialized) {
            m_appstreamInitialized = true;
            Q_EMIT loadedAppStream();
        }
        acquireFetching(false);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &source : m_flatpakSources) {
        for (auto it = source->m_resources.constBegin(), itEnd = source->m_resources.constEnd(); it != itEnd; ++it) {
            const auto &id = it.key();
            if ((*it)->resourceType() == FlatpakResource::Runtime && id.id == runtimeInfo.at(0) && id.branch == runtimeInfo.at(2)) {
                runtime = *it;
                break;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto& v : input) {
        ret.append(op(v));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, fw]() {
        m_fetching = true;
        emit fetchingChanged();

        auto devices = fw->result();
        for(uint i = 0; devices && i < devices->len; i++) {
            FwupdDevice *device = (FwupdDevice *) g_ptr_array_index(devices, i);

            if (!fwupd_device_has_flag (device, FWUPD_DEVICE_FLAG_SUPPORTED))
                continue;

            g_autoptr(GError) error = nullptr;
            g_autoptr(GPtrArray) releases = fwupd_client_get_releases(client, fwupd_device_get_id(device), m_cancellable, &error);

            if (error) {
                if (g_error_matches(error, FWUPD_ERROR, FWUPD_ERROR_NOT_SUPPORTED)) {
                    qWarning() << "fwupd: Device not supported:" << fwupd_device_get_name(device) << error->message;
                    continue;
                }
                if (g_error_matches(error, FWUPD_ERROR, FWUPD_ERROR_INVALID_FILE)) {
                    continue;
                }

                handleError(error);
            }

            auto res = new FwupdResource(device, this);
            for (uint i=0; releases && i<releases->len; ++i) {
                FwupdRelease *release = (FwupdRelease *)g_ptr_array_index(releases, i);
                if (res->installedVersion().toUtf8() == fwupd_release_get_version(release)) {
                    res->setReleaseDetails(release);
                    break;
                }
            }
            addResourceToList(res);
        }
        g_ptr_array_unref(devices);

        addUpdates();

        m_fetching = false;
        emit fetchingChanged();
        emit initialized();
        fw->deleteLater();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractResource * res : m_toUpgrade) {
        PackageKitResource * app = qobject_cast<PackageKitResource*>(res);
        m_packageIds.insert(app->availablePackageId());
        qDebug() << "Upgrade" << app->availablePackageId() << app->installedPackageId();
    }
```

#### AUTO 


```{c}
const auto addonsToInstall = addons.addonsToInstall();
```

#### LAMBDA EXPRESSION 


```{c}
[](UpdateItem *a, UpdateItem *b) { return a->name() < b->name(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &error) { qWarning() << "kns error" << objectName() << error; }
```

#### LAMBDA EXPRESSION 


```{c}
[this, replyGet] {
            const QUrl originalUrl = replyGet->request().url();
            if (replyGet->error() != QNetworkReply::NoError) {
                qWarning() << "couldn't download" << originalUrl << replyGet->errorString();
                Q_EMIT jobFinished(false, nullptr);
                return;
            }

            const QUrl fileUrl = QUrl::fromLocalFile(QStandardPaths::writableLocation(QStandardPaths::TempLocation) + QLatin1Char('/') + originalUrl.fileName());
            auto replyPut = put(QNetworkRequest(fileUrl), replyGet->readAll());
            connect(replyPut, &QNetworkReply::finished, this, [this, originalUrl, fileUrl, replyPut]() {
                if (replyPut->error() == QNetworkReply::NoError) {
                    auto res = m_backend->resourceForFile(fileUrl);
                    if (res) {
                        FlatpakResource *resource = qobject_cast<FlatpakResource*>(res);
                        resource->setResourceFile(originalUrl);
                        Q_EMIT jobFinished(true, resource);
                    } else {
                        qWarning() << "couldn't create resource from" << fileUrl.toLocalFile();
                        Q_EMIT jobFinished(false, nullptr);
                    }
                } else {
                    qWarning() << "couldn't save" << originalUrl << replyPut->errorString();
                    Q_EMIT jobFinished(false, nullptr);
                }
            });
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QJsonValueRef &val) -> QString {
            return val.toObject()[QLatin1String("name")].toString();
        }
```

#### AUTO 


```{c}
const auto &pkg
```

#### LAMBDA EXPRESSION 


```{c}
[](AbstractBackendUpdater *updater) {
                    return updater->isCancelable() && updater->isProgressing();
                }
```

#### AUTO 


```{c}
auto replyGet = get(QNetworkRequest(m_url));
```

#### AUTO 


```{c}
auto method = QDBusMessage::createMethodCall(QStringLiteral("org.freedesktop.login1"),
                                                 QStringLiteral("/org/freedesktop/login1"),
                                                 QStringLiteral("org.freedesktop.login1.Manager"),
                                                 QStringLiteral("Reboot"));
```

#### AUTO 


```{c}
auto ro = rootObject();
```

#### RANGE FOR STATEMENT 


```{c}
for (QVariantMap d : deployments) {
        RpmOstreeResource *deployment = new RpmOstreeResource(d, this);
        m_resources << deployment;
        if (deployment->isBooted()) {
            connect(deployment, &RpmOstreeResource::stateChanged, this, &RpmOstreeBackend::updatesCountChanged);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, category]() {
            Category* cat = CategoryModel::global()->findCategoryByName(category);
            if (!cat) {
                showPassiveNotification(i18n("Could not find category '%1'", category));
                return;
            }

            emit listCategoryInternal(cat);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        setRemainingTime(m_trans->remainingTime());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &/*packageID*/, const QStringList &filenames) {
        const auto allServices = QStandardPaths::locateAll(QStandardPaths::ApplicationsLocation, m_appdata.id());
        if (!allServices.isEmpty()) {
            const auto packageServices = kFilter<QStringList>(allServices, [filenames](const QString &file) { return filenames.contains(file); });
            QProcess::startDetached(QStringLiteral(CMAKE_INSTALL_FULL_LIBEXECDIR_KF5 "/discover/runservice"), {packageServices});
        } else {
            const QStringList exes = m_appdata.provided(AppStream::Provided::KindBinary).items();
            const auto packageExecutables = kFilter<QStringList>(allServices, [filenames](const QString &exe) { return filenames.contains(QLatin1Char('/') + exe); });
            if (!packageExecutables.isEmpty()) {
                QProcess::startDetached(exes.constFirst());
            } else {
                const auto locations = QStandardPaths::standardLocations(QStandardPaths::ApplicationsLocation);
                const auto desktopFiles = kFilter<QStringList>(filenames, [locations](const QString &exe) {
                    for (const auto &location: locations) {
                        if (exe.startsWith(location))
                            return exe.contains(QLatin1String(".desktop"));
                    }
                    return false;
                });
                if (!desktopFiles.isEmpty()) {
                    QProcess::startDetached(QStringLiteral(CMAKE_INSTALL_FULL_LIBEXECDIR_KF5 "/discover/runservice"), { desktopFiles });
                }
            }
            qWarning() << "Could not find any executables" << exes << filenames;
        }
    }
```

#### AUTO 


```{c}
const auto desktops = m_appdata.compulsoryForDesktops();
```

#### AUTO 


```{c}
const auto &pkgid
```

#### LAMBDA EXPRESSION 


```{c}
[this, stream, entryid](const KNSCore::EntryInternal &entry) {
            if (entry.uniqueId() == entryid) {
                stream->resourcesFound({resourceForEntry(entry)});
            }
            m_responsePending = false;
            QTimer::singleShot(0, this, &KNSBackend::availableForQueries);
            stream->finish();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, stream, filter] {
            const auto toResolve = kFilter<QVector<AbstractResource *>>(m_packages.packages, needsResolveFilter);

            auto installedAndNameFilter = [filter](AbstractResource *res) {
                return res->state() >= AbstractResource::Installed
                    && (res->name().contains(filter.search, Qt::CaseInsensitive) || res->packageName().compare(filter.search, Qt::CaseInsensitive) == 0);
            };
            bool furtherSearch = false;
            if (!toResolve.isEmpty()) {
                resolvePackages(kTransform<QStringList>(toResolve, [](AbstractResource *res) {
                    return res->packageName();
                }));
                connect(m_resolveTransaction, &PKResolveTransaction::allFinished, this, [stream, toResolve, installedAndNameFilter] {
                    const auto resolved = kFilter<QVector<AbstractResource *>>(toResolve, installedAndNameFilter);
                    if (!resolved.isEmpty())
                        Q_EMIT stream->resourcesFound(resolved);
                    stream->finish();
                });
                furtherSearch = true;
            }

            const auto resolved = kFilter<QVector<AbstractResource *>>(m_packages.packages, installedAndNameFilter);
            if (!resolved.isEmpty()) {
                QTimer::singleShot(0, this, [resolved, toResolve, stream]() {
                    if (!resolved.isEmpty())
                        Q_EMIT stream->resourcesFound(resolved);

                    if (toResolve.isEmpty())
                        stream->finish();
                });
                furtherSearch = true;
            }

            if (!furtherSearch)
                stream->finish();
        }
```

#### AUTO 


```{c}
auto cats = m_appdata.categories();
```

#### AUTO 


```{c}
const auto sidx = mapToSource(index);
```

#### RANGE FOR STATEMENT 


```{c}
for(Appstream::Provides p : m_appdata.provides())
        if (p.kind() == kind)
            ret += p.value();
```

#### RANGE FOR STATEMENT 


```{c}
for(auto res: toUpgrade) {
        const auto packageName = res->packageName();
        if (packages.contains(packageName)) {
            continue;
        }
        packages.insert(packageName);
        ret += 1;
    }
```

#### AUTO 


```{c}
const auto toResolve = kFilter<QVector<AbstractResource *>>(m_packages.packages, needsResolveFilter);
```

#### RANGE FOR STATEMENT 


```{c}
for(auto b : backends)
        addResourcesBackend(b);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &cat : cats) {
            if (m_hasApplications)
                categories << new Category(cat, QStringLiteral("applications-other"), {{CategoryFilter, cat}}, backendName, {}, {}, true);
            else
                categories << new Category(cat, QStringLiteral("plasma"), {{CategoryFilter, cat}}, backendName, {}, {}, true);
        }
```

#### AUTO 


```{c}
auto it = data.missingComponents.constBegin(), itEnd = data.missingComponents.constEnd();
```

#### AUTO 


```{c}
auto job = socket.snapByName(snap);
```

#### LAMBDA EXPRESSION 


```{c}
[this](PackageKit::Transaction::Error, const QString& message) { qWarning() << "Transaction error: " << message << sender(); }
```

#### AUTO 


```{c}
const auto id = resource->ref();
```

#### AUTO 


```{c}
const auto histo = histogram.midRef(1,histogram.size()-2).split(QStringLiteral(", "));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &tid: tids) {
        if (m_transactions.contains(tid))
            continue;

        auto t = new PackageKit::Transaction(QDBusObjectPath(tid));
        connect(t, &PackageKit::Transaction::requireRestart, this, &PackageKitNotifier::onRequireRestart);
        connect(t, &PackageKit::Transaction::finished, this, [this, t](){
            auto restart = t->property("requireRestart");
            if (!restart.isNull())
                requireRestartNotification(PackageKit::Transaction::Restart(restart.toInt()));
            m_transactions.remove(t->tid().path());
            t->deleteLater();
        });
        m_transactions.insert(tid, t);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractResource *r : qAsConst(m_resources)) {
            if (r->state() < filter.state)
                continue;

            if (filter.search.isEmpty() || r->name().contains(filter.search, Qt::CaseInsensitive)
                || r->comment().contains(filter.search, Qt::CaseInsensitive)) {
                ret += r;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, category]() {
            Category* cat = CategoryModel::global()->findCategoryByName(category);
            if (cat) {
                emit listCategoryInternal(cat);
            } else {
                showPassiveNotification(i18n("Could not find category '%1'", category));
                setRootObjectProperty("defaultStartup", false);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto res : qAsConst(r))
        static_cast<PackageKitResource *>(res)->addPackageId(info, packageId, arch);
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractResource * res : m_packages.values()) {
        if (res->name().contains(searchText, Qt::CaseInsensitive) || res->comment().contains(searchText, Qt::CaseInsensitive))
            result << res;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[resource, transaction, this] (FlatpakResource::PropertyKind kind, FlatpakResource::PropertyState state) {
            if (kind != FlatpakResource::RequiredRuntime) {
                return;
            }

            if (state == FlatpakResource::AlreadyKnown) {
                FlatpakResource *runtime = getRuntimeForApp(resource);
                if (runtime && !runtime->isInstalled()) {
                    transaction->setRuntime(runtime);
                }
            }
            transaction->start();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[trans](PackageKit::Transaction::Info /*info*/, const QString &/*packageID*/, const QString &/*summary*/) {
        trans->setProperty("dependencies", trans->property("dependencies").toUInt() + 1);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[installation, this]() -> GPtrArray * {
        g_autoptr(GError) localError = nullptr;
        GPtrArray *refs = flatpak_installation_list_installed_refs_for_update(installation, m_cancellable, &localError);
        if (!refs) {
            qWarning() << "Failed to get list of installed refs for listing updates: " << localError->message;
        }
        return refs;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &/*packageID*/, const QStringList &_filenames) {
        //This workarounds bug in zypper's backend (suse) https://github.com/hughsie/PackageKit/issues/351
        QStringList filenames = _filenames;
        if (filenames.count() == 1 && !QFile::exists(filenames.constFirst())) {
            filenames = filenames.constFirst().split(QLatin1Char(';'));
        }
        const auto allServices = QStandardPaths::locateAll(QStandardPaths::ApplicationsLocation, m_appdata.id());
        if (!allServices.isEmpty()) {
            const auto packageServices = kFilter<QStringList>(allServices, [filenames](const QString &file) { return filenames.contains(file); });
            QProcess::startDetached(QStringLiteral(CMAKE_INSTALL_FULL_LIBEXECDIR_KF5 "/discover/runservice"), {packageServices});
            return;
        } else {
            const QStringList exes = m_appdata.provided(AppStream::Provided::KindBinary).items();
            const auto packageExecutables = kFilter<QStringList>(exes, [filenames](const QString &exe) { return filenames.contains(QLatin1Char('/') + exe); });
            if (!packageExecutables.isEmpty()) {
                QProcess::startDetached(exes.constFirst(), QStringList());
                return;
            } else {
                const auto locations = QStandardPaths::standardLocations(QStandardPaths::ApplicationsLocation);
                const auto desktopFiles = kFilter<QStringList>(filenames, [locations](const QString &exe) {
                    for (const auto &location: locations) {
                        if (exe.startsWith(location))
                            return exe.contains(QLatin1String(".desktop"));
                    }
                    return false;
                });
                if (!desktopFiles.isEmpty()) {
                    QProcess::startDetached(QStringLiteral(CMAKE_INSTALL_FULL_LIBEXECDIR_KF5 "/discover/runservice"), { desktopFiles });
                    return;
                }
            }
            Q_EMIT backend()->passiveMessage(i18n("Cannot launch %1", name()));
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QVector<AbstractResource *> &resources) {
        for (auto r : resources)
            connect(r, &QObject::destroyed, this, [this, r]() {
                m_resources.removeAll(r);
            });
        m_resources += resources;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, stream, searchText]() {
        // No need to explicitly launch a search, setting the search term already does that for us
        m_engine->setSearchTerm(searchText);
        m_onePage = false;
        m_responsePending = true;

        QSharedPointer<int> count(new int(0));
        connect(this, &KNSBackend::receivedResources, stream, [this, count](const QVector<AbstractResource*>& resources){
            *count += resources.count();
            if (*count>2000)
                m_stopSearching = true;
        });
        connect(this, &KNSBackend::receivedResources, stream, &ResultsStream::resourcesFound);
        connect(this, &KNSBackend::searchFinished, stream, &ResultsStream::finish);
        connect(this, &KNSBackend::startingSearch, stream, &ResultsStream::finish);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(Category* cat : m_subCategories) {
        ret.append(QVariant::fromValue<QObject*>(cat));
    }
```

#### AUTO 


```{c}
auto percent = m_trans->percentage();
```

#### AUTO 


```{c}
auto roles = propertiesToRoles(properties);
```

#### LAMBDA EXPRESSION 


```{c}
[=]()
                    {
                        if(fwupd_client_modify_remote(m_backend->backend->client, fwupd_remote_get_id(remote), "Enabled", "true", nullptr, nullptr))
                            item->setData(value, role);
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for(Category* c : list) {
        if(c->name() == newcat->name()) {
            if(c->icon() != newcat->icon()
                || c->shouldShowTechnical() != newcat->shouldShowTechnical()
                || c->m_andFilters != newcat->andFilters())
            {
                qWarning() << "the following categories seem to be the same but they're not entirely"
                    << c->name() << newcat->name();
                break;
            } else {
                c->m_orFilters += newcat->orFilters();
                c->m_notFilters += newcat->notFilters();
                c->m_plugins.unite(newcat->m_plugins);
                for(Category* nc : newcat->subCategories())
                    addSubcategory(c->m_subCategories, nc);
                delete newcat;
                return;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto slot: slotsForInterface[plug->interface()]) {
                    auto item = new QStandardItem;
                    if (plug->label().isEmpty())
                        item->setText(plug->name());
                    else
                        item->setText(i18n("%1 - %2", plug->name(), plug->label()));

                    item->setCheckable(true);
                    item->setCheckState(plug->connectionCount()>0 ? Qt::Checked : Qt::Unchecked);
                    item->setData(plug->name(), PlugNameRole);
                    item->setData(slot->snap(), SlotSnapRole);
                    item->setData(slot->name(), SlotNameRole);
                    appendRow(item);
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (Category *c : cats)
                Category::addSubcategory(ret, c);
```

#### AUTO 


```{c}
const auto& filter
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        for (int i = 0; i < m_sources->rowCount();) {
            if (!m_sources->item(i, 0)->isEnabled()) {
                m_sources->removeRow(i);
            } else {
                ++i;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto pkgList : changes.values()) {
        for(QApt::Package* it : pkgList) {
            AbstractResource* res = m_appBackend->resourceByPackageName(it->name());
            if(!res) //If we couldn't find it by its name, try with
                res = m_appBackend->resourceByPackageName(QString("%1:%2").arg(it->name()).arg(it->architecture()));

            if(res)
                m_toUpdate += res;
            else
                qWarning() << "Couldn't find the package:" << it->name();
            Q_ASSERT(res);
        }
    }
```

#### AUTO 


```{c}
const auto name = QString::fromUtf8(flatpak_ref_get_name(ref));
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractResourcesBackend *backend : backends) {
        backend->integrateMainWindow(this);
        
        if(backend->metaObject()->className()==QLatin1String("ApplicationBackend")) {
            m_appBackend = backend;
            connect(m_appBackend, SIGNAL(backendReady()),
                    this, SLOT(populateViews()));
            connect(m_appBackend, SIGNAL(reloadStarted()), //TODO: use ResourcesModel signals
                    this, SLOT(removeProgressItem()));
            connect(m_appBackend, SIGNAL(reloadFinished()),
                    this, SLOT(showLauncherMessage()));
            connect(m_appBackend, SIGNAL(startingFirstTransaction()),
                    this, SLOT(addProgressItem()));
            connect(m_appBackend, SIGNAL(sourcesEditorFinished()),
                    this, SLOT(sourcesEditorFinished()));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &path: QStandardPaths::standardLocations(QStandardPaths::GenericConfigLocation)) {
                QDirIterator dirIt(path, {QStringLiteral("*.knsrc")}, QDir::Files);
                for(; dirIt.hasNext(); ) {
                    dirIt.next();

                    auto bk = new KNSBackend(parent, QStringLiteral("plasma"), dirIt.filePath());
                    ret += bk;
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                m_transaction->setStatus(Transaction::CommittingStatus);
                m_transaction->slotProgressingChanged();
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this](int count){ Q_EMIT updatesCountChanged(count); }
```

#### LAMBDA EXPRESSION 


```{c}
[] (AbstractResource* res) { return res->packageName(); }
```

#### AUTO 


```{c}
const auto doc = QJsonDocument::fromJson(rest, &error);
```

#### LAMBDA EXPRESSION 


```{c}
[this, msg](){
        QMetaObject::invokeMethod(rootObject(), "showPassiveNotification", Qt::QueuedConnection, Q_ARG(QVariant, msg), Q_ARG(QVariant, {}), Q_ARG(QVariant, {}), Q_ARG(QVariant, {}));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto r : res)
        connect(r, &QObject::destroyed, this, [this, r](){
            m_results.removeAll(r);
        });
```

#### RANGE FOR STATEMENT 


```{c}
for (auto job : jobs) {
            job->deleteLater();
            if (job->error()) {
                qDebug() << "error:" << job->error() << job->errorString();
                continue;
            }

            for (int i=0, c=job->snapCount(); i<c; ++i) {
                QSharedPointer<QSnapdSnap> snap(job->snap(i));

                if (!filter(snap))
                    continue;

                const auto snapname = snap->name();
                SnapResource*& res = m_resources[snapname];
                if (!res) {
                    res = new SnapResource(snap, AbstractResource::None, this);
                    Q_ASSERT(res->packageName() == snapname);
                } else {
                    res->setSnap(snap);
                }
                ret += res;
            }
        }
```

#### AUTO 


```{c}
auto onActivateRequested = [mainWindow](const QStringList &arguments, const QString & /*workingDirectory*/) {
                auto window = qobject_cast<QWindow *>(mainWindow->rootObject());
                if (!window) {
                    // Should never happen anyway
                    QCoreApplication::instance()->quit();
                    return;
                }

                raiseWindow(window);

                if (arguments.isEmpty())
                    return;
                QScopedPointer<QCommandLineParser> parser(createParser());
                parser->parse(arguments);
                processArgs(parser.data(), mainWindow);
            };
```

#### AUTO 


```{c}
const auto backend = m_model->backends().first();
```

#### LAMBDA EXPRESSION 


```{c}
[this, resource, stream](const QVector<AbstractResource *> &resources) {
                        for (auto res : resources) {
                            installApplication(res);
                        }
                        addResource(resource);
                        stream->resourcesFound({resource});
                        stream->finish();
                    }
```

#### LAMBDA EXPRESSION 


```{c}
[stream, tArch, ids, this]() {
            getPackagesFinished();
            const auto packageId = tArch->property("packageId");
            if (!packageId.isNull()) {
                const auto res = resourcesByPackageNames<QVector<AbstractResource*>>({PackageKit::Daemon::packageName(packageId.toString())});
                stream->resourcesFound(kFilter<QVector<AbstractResource*>>(res, [ids](AbstractResource* res){ return !ids.contains(res->appstreamId()); }));
            }
            stream->deleteLater();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QSessionManager &sessionManager) {
        if (ResourcesModel::global()->isBusy()) {
            Q_EMIT preventedClose();
            sessionManager.cancel();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, category]() {
            Category *cat = CategoryModel::global()->findCategoryByName(category);
            if (cat) {
                Q_EMIT listCategoryInternal(cat);
            } else {
                openMode(QStringLiteral("Browsing"));
                showPassiveNotification(i18n("Could not find category '%1'", category));
            }
        }
```

#### AUTO 


```{c}
const auto oldSize= size();
```

#### LAMBDA EXPRESSION 


```{c}
[filenames](const QString &file) {
                return filenames.contains(file);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (DetailsTab *tab : m_detailsTabs) {
        tab->setBackend(backend);
    }
```

#### AUTO 


```{c}
const auto resources = resourcesByAppstreamName(settings.value(QStringLiteral("Flatpak Ref/Name")).toString());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &token : licenses) {
        QString license = token;
        license.remove(0, 1); // tokenize prefixes with an @ for some reason

        bool publicLicense = false;
        QString name = license;
        if (license.startsWith(QLatin1String("LicenseRef-proprietary"))) {
            name = i18n("Proprietary");
        } else if (license == QLatin1String("LicenseRef-public-domain")) {
            name = i18n("Public Domain");
            publicLicense = true;
        }

        if (!AppStream::SPDX::isLicenseId(license))
            continue;
        ret.append(QJsonObject{
            {QStringLiteral("name"), name},
            {QStringLiteral("url"), {AppStream::SPDX::licenseUrl(license)}},
            {QStringLiteral("hasFreedom"), AppStream::SPDX::isFreeLicense(license) || publicLicense},
        });
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto i : links)
                    engine->install(res->entry(), i);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        transactionChanged(CancellableRole);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, app]() {
            StoredResultsStream* stream = new StoredResultsStream({ResourcesModel::global()->findResourceByPackageName(app)});
            connect(stream, &StoredResultsStream::finishedResources, stream, [this, stream, app](const QVector<AbstractResource*> &resources) {
                if (!resources.isEmpty()) {
                    if (resources.size() > 1)
                        qWarning() << "many resources found for" << app;
                    emit openApplicationInternal(resources.first());
                } else {
                    rootObject()->setProperty("defaultStartup", true);
                    showPassiveNotification(i18n("Couldn't open %1", app.toDisplayString()));
                }
            });
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractBackendUpdater *updater : qAsConst(m_allUpdaters)) {
            total += updater->downloadSpeed();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[func](QDBusPendingCallWatcher *watcher) {
        watcher->deleteLater();
        QDBusPendingReply<T> reply = *watcher;
        func(reply.value());
    }
```

#### AUTO 


```{c}
auto updateChecker = new OneTimeAction([this]() {
            Q_EMIT startingSearch();
            m_onePage = true;
            m_responsePending = true;
            m_engine->checkForUpdates();
        }, this);
```

#### LAMBDA EXPRESSION 


```{c}
[stream] {
        stream->finish();
    }
```

#### AUTO 


```{c}
const auto comps = source->m_pool->componentsById(name) + source->m_pool->componentsById(nameWithDesktop);
```

#### LAMBDA EXPRESSION 


```{c}
[cancel, t, this](PackageKit::Transaction::Exit /*status*/, uint /*runtime*/){
        QMap<PackageKit::Transaction::Info, QStringList> packages = t->property("packages").value<QMap<PackageKit::Transaction::Info, QStringList>>();
        qobject_cast<PackageKitResource*>(resource())->setPackages(packages);
        setStatus(Transaction::DoneStatus);
        if (cancel)
            qobject_cast<PackageKitBackend*>(resource()->backend())->transactionCanceled(this);
        else
            qobject_cast<PackageKitBackend*>(resource()->backend())->removeTransaction(this);
    }
```

#### AUTO 


```{c}
auto f = [menu, this]() {
        m_item->setTitle(i18n("Restart to apply installed updates"));
        m_item->setToolTipTitle(i18n("Click to restart the device"));
        m_item->setIconByName(QStringLiteral("view-refresh"));
    };
```

#### AUTO 


```{c}
const auto uid = resource->uniqueId();
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &error) {
        if(error == QLatin1Literal("All categories are missing")) {
            markInvalid(error);
        }
        m_responsePending = false;
        Q_EMIT searchFinished();
        Q_EMIT availableForQueries();
        this->setFetching(false);
        qWarning() << "kns error" << objectName() << error;
        passiveMessage(i18n("%1: %2", name(), error));
    }
```

#### AUTO 


```{c}
auto action = new OneTimeAction(
        [this, url]() {
            AbstractResourcesBackend::Filters f;
            f.resourceUrl = url;
            auto stream = new StoredResultsStream({ResourcesModel::global()->search(f)});
            connect(stream, &StoredResultsStream::finishedResources, this, [this, url](const QVector<AbstractResource*> &res) {
                if (res.count() >= 1) {
                    emit openApplicationInternal(res.first());
                } else {
                    Q_EMIT openErrorPage(i18n("Couldn't open %1", url.toDisplayString()));
                }
            });
        }
        , this);
```

#### AUTO 


```{c}
auto stream = new ResultsStream(QLatin1String("KNS-byname-")+entryid);
```

#### AUTO 


```{c}
auto array = fwupd_client_get_remotes_finish(helper->client, res, &error);
```

#### LAMBDA EXPRESSION 


```{c}
[name](AbstractResourcesBackend* b) { return b->name() == name; }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto installation : qAsConst(m_installations)) {
        // Load applications from appstream metadata
        if (!loadAppsFromAppstreamData(installation)) {
            qWarning() << "Failed to load packages from appstream data from installation" << installation;
        }

        // Load installed applications and update existing resources with info from installed application
        if (!loadInstalledApps(installation)) {
            qWarning() << "Failed to load installed packages from installation" << installation;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const AppStream::Icon &icon : icons) {
            switch (icon.kind()) {
            case AppStream::Icon::KindLocal:
            case AppStream::Icon::KindCached: {
                const QString path = m_iconPath + icon.url().path();
                if (QFileInfo::exists(path)) {
                    ret.addFile(path, icon.size());
                } else {
                    const QString altPath = m_iconPath + QStringLiteral("%1x%2/").arg(icon.size().width()).arg(icon.size().height()) + icon.url().path();
                    if (QFileInfo::exists(altPath)) {
                        ret.addFile(altPath, icon.size());
                    }
                }
            } break;
            case AppStream::Icon::KindStock: {
                const auto ret = QIcon::fromTheme(icon.name());
                if (!ret.isNull())
                    return ret;
                break;
            }
            case AppStream::Icon::KindRemote: {
                const QString fileName = iconCachePath(icon);
                if (QFileInfo::exists(fileName)) {
                    ret.addFile(fileName, icon.size());
                }
                break;
            }
            case AppStream::Icon::KindUnknown:
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : selected) {
        packages << m_proxyModel->packageAt(index);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](QQmlEngine *, QJSEngine *) -> QObject * {
        auto r = new DiscoverSettings;
        connect(r, &DiscoverSettings::installedPageSortingChanged, r, &DiscoverSettings::save);
        connect(r, &DiscoverSettings::appsListPageSortingChanged, r, &DiscoverSettings::save);
        return r;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        m_updatesCount.reevaluate();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[filters](const QSharedPointer<QSnapdSnap>& s) { return filters.search.isEmpty() || s->name().contains(filters.search, Qt::CaseInsensitive) || s->description().contains(filters.search, Qt::CaseInsensitive); }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto res : toUpd) {
        res->fetchChangelog();
    }
```

#### AUTO 


```{c}
auto resources = getResources(ResourcesModel::global()->findResourceByPackageName(url), true);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &uri : uris) {
        AbstractResourcesBackend::Filters filter;
        filter.resourceUrl = uri;
        streams << m_backend->search(filter);
    }
```

#### AUTO 


```{c}
const auto res = packagesForPackageId({itemID});
```

#### AUTO 


```{c}
auto at = ids.find(appstreamid);
```

#### AUTO 


```{c}
const auto iconUrl = sourceItem->data(FlatpakSourcesBackend::IconUrlRole).toString();
```

#### LAMBDA EXPRESSION 


```{c}
[](AbstractResourcesBackend *backend) {
                        return backend->metaObject()->className() == QByteArray("FlatpakBackend");
                    }
```

#### AUTO 


```{c}
auto instance = rating();
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        m_reviews->emitRatingFetched(this, kTransform<QList<AbstractResource *>>(m_packages.packages, [](AbstractResource *r) {
                                         return r;
                                     }));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (UpdateItem *item : m_rootItem->children()) {
        for (UpdateItem *subItem : item->children()) {
            QApt::Package *pkg = subItem->retrievePackage();
            if (!pkg)
                continue;

            subItem->setChecked(pkg->state() & QApt::Package::ToInstall);
        }
    }
```

#### AUTO 


```{c}
auto conf = KSharedConfig::openConfig();
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString& toRemove){ return m_packages.packages.value(toRemove); }
```

#### AUTO 


```{c}
auto ret = new StoredResultsStream({populate(m_client.getSnaps())});
```

#### AUTO 


```{c}
auto f = [menu, this]() {
        auto refreshAction = menu->addAction(QIcon::fromTheme(QStringLiteral("view-refresh")), i18n("Restart..."));
        connect(refreshAction, &QAction::triggered, &m_notifier, &DiscoverNotifier::recheckSystemUpdateNeeded);
    };
```

#### LAMBDA EXPRESSION 


```{c}
[] (const QJsonValueRef &val) -> QString { return val.toObject()[QLatin1String("name")].toString(); }
```

#### RANGE FOR STATEMENT 


```{c}
for(Category* c : list) {
        if(c->name() == newcat->name()) {
            if(c->icon() != newcat->icon()
                || c->shouldShowTechnical() != newcat->shouldShowTechnical()
                || c->m_andFilters != newcat->andFilters())
            {
                kWarning() << "the following categories seem to be the same but they're not entirely"
                    << c->name() << newcat->name();
                break;
            } else {
                c->m_orFilters += newcat->orFilters();
                c->m_notFilters += newcat->notFilters();
                for(Category* nc : newcat->subCategories())
                    addSubcategory(c->m_subCategories, nc);
                delete newcat;
                return;
            }
        }
    }
```

#### AUTO 


```{c}
const auto start = [this, stream, filter]() {
            if (m_isValid) {
                auto filterFunction = [&filter](AbstractResource* r) { return r->state()>=filter.state && (r->name().contains(filter.search, Qt::CaseInsensitive) || r->comment().contains(filter.search, Qt::CaseInsensitive)); };
                const auto ret = kFilter<QVector<AbstractResource*>>(m_resourcesByName, filterFunction);

                if (!ret.isEmpty())
                    stream->resourcesFound(ret);
            }
            stream->finish();
        };
```

#### LAMBDA EXPRESSION 


```{c}
[](QQmlEngine*, QJSEngine*) -> QObject* { return new DiscoverNotifier; }
```

#### AUTO 


```{c}
const auto sc = AppStreamUtils::fetchScreenshots(m_appdata);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto source : qAsConst(m_flatpakSources)) {
        if (source->url() == flatpak_remote_get_url(remote) && source->installation() == flatpakInstallation) {
            metadataRefreshed();
            return source;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[mainWindow](const QStringList &arguments, const QString &/*workingDirectory*/){
            mainWindow->rootObject()->raise();
            if (arguments.isEmpty())
                return;
            QScopedPointer<QCommandLineParser> parser(createParser());
            parser->process(arguments);
            processArgs(parser.data(), mainWindow);
        }
```

#### AUTO 


```{c}
auto status = SetupStatus;
```

#### AUTO 


```{c}
auto window = qobject_cast<QWindow*>(mainWindow->rootObject());
```

#### LAMBDA EXPRESSION 


```{c}
[mainWindow](const QStringList &arguments, const QString & /*workingDirectory*/) {
            auto window = qobject_cast<QWindow *>(mainWindow->rootObject());
            if (!window) {
                // Should never happen anyway
                QCoreApplication::instance()->quit();
                return;
            }

            raiseWindow(window);

            if (arguments.isEmpty())
                return;
            QScopedPointer<QCommandLineParser> parser(createParser());
            parser->parse(arguments);
            processArgs(parser.data(), mainWindow);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const AppStream::Icon &icon : icons) {
        QStringList stock;
        switch (icon.kind()) {
        case AppStream::Icon::KindLocal:
            ret.addFile(icon.url().toLocalFile(), icon.size());
            break;
        case AppStream::Icon::KindCached:
            ret.addFile(icon.url().toLocalFile(), icon.size());
            break;
        case AppStream::Icon::KindStock: {
            const auto ret = QIcon::fromTheme(icon.name());
            if (!ret.isNull())
                return ret;
            break;
        }
        default:
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(Category* c : cats)
                Category::addSubcategory(ret, c);
```

#### LAMBDA EXPRESSION 


```{c}
[this, p](int exitCode, QProcess::ExitStatus /*exitStatus*/) {
            if (exitCode != 0) {
                backend()->passiveMessage(i18n("Failed to start '%1'", KShell::joinArgs(p->arguments())));
            }
            p->deleteLater();
        }
```

#### AUTO 


```{c}
auto it = m_jobHash.constBegin();
```

#### AUTO 


```{c}
auto job = new LocalSnapJob(createRequest("POST", "/v2/login", obj), this);
```

#### LAMBDA EXPRESSION 


```{c}
[](PackageKitResource* r){return r->installedPackageId(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
                Q_EMIT updatesCountChanged();
            }
```

#### LAMBDA EXPRESSION 


```{c}
[] {
        QFile ratingsDocument(QStandardPaths::writableLocation(QStandardPaths::CacheLocation) + QStringLiteral("/ratings/ratings"));
        if (!ratingsDocument.open(QIODevice::ReadOnly)) {
            return QJsonDocument::fromJson({});
        }
        return QJsonDocument::fromJson(ratingsDocument.readAll());
    }
```

#### AUTO 


```{c}
const auto installed = m_packages[PackageKit::Transaction::InfoInstalled];
```

#### AUTO 


```{c}
auto repo = flatpak_installation_get_remote_by_name(m_flatpakInstallationSystem, resource->flatpakName().toStdString().c_str(), m_cancellable, nullptr);
```

#### AUTO 


```{c}
const auto snapname = snap->name();
```

#### LAMBDA EXPRESSION 


```{c}
[fetchResourceJob, stream](bool success, FlatpakResource *resource) {
            if (success) {
                Q_EMIT stream->resourcesFound({resource});
            }
            stream->finish();
            fetchResourceJob->deleteLater();
        }
```

#### AUTO 


```{c}
const auto residx = m_displayedResources.indexOf(resource);
```

#### LAMBDA EXPRESSION 


```{c}
[stream, toResolve] {
                    const auto resolved = kFilter<QVector<AbstractResource*>>(toResolve, installedFilter);
                    if (!resolved.isEmpty())
                        Q_EMIT stream->resourcesFound(resolved);
                    stream->finish();
                }
```

#### AUTO 


```{c}
auto mSwitchApplicationLanguageAction = KStandardAction::create(KStandardAction::SwitchApplicationLanguage, this, &DiscoverMainWindow::switchApplicationLanguage, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &source : m_flatpakSources) {
        auto ret = source->m_resources.value(id);
        if (ret) {
            return ret;
        }
    }
```

#### AUTO 


```{c}
const auto value = mi.data(pm.sortRole());
```

#### AUTO 


```{c}
auto f = [this, stream] {
            QVector<AbstractResource *> resources;
            for (auto installation : m_installations) {
                g_autoptr(GError) localError = nullptr;
                g_autoptr(GPtrArray) refs = flatpak_installation_list_installed_refs(installation, m_cancellable, &localError);
                if (!refs) {
                    qWarning() << "Failed to get list of installed refs for listing installed:" << localError->message;
                    continue;
                }

                resources.reserve(resources.size() + refs->len);
                for (uint i = 0; i < refs->len; i++) {
                    FlatpakInstalledRef *ref = FLATPAK_INSTALLED_REF(g_ptr_array_index(refs, i));
                    QString name = QString::fromUtf8(flatpak_installed_ref_get_appdata_name(ref));
                    if (name.endsWith(QLatin1String(".Debug")) || name.endsWith(QLatin1String(".Locale")) || name.endsWith(QLatin1String(".BaseApp"))
                        || name.endsWith(QLatin1String(".Docs")))
                        continue;

                    auto resource = getAppForInstalledRef(installation, ref);
                    if (resource->resourceType() == FlatpakResource::Runtime) {
                        resources.prepend(resource);
                    } else {
                        resources.append(resource);
                    }
                }
            }
            if (!resources.isEmpty())
                Q_EMIT stream->resourcesFound(resources);
            stream->finish();
        };
```

#### LAMBDA EXPRESSION 


```{c}
[this, url]() {
            AbstractResourcesBackend::Filters f;
            f.resourceUrl = url;
            auto stream = new StoredResultsStream({ResourcesModel::global()->search(f)});
            connect(stream, &StoredResultsStream::finished, this, [this, url, stream]() {
                const auto res = stream->resources();
                if (res.count() >= 1) {
                    emit openApplicationInternal(res.first());
                } else {
                    setRootObjectProperty("defaultStartup", true);
                    Q_EMIT openErrorPage(i18n("Couldn't open %1", url.toDisplayString()));
                }
            });
        }
```

#### AUTO 


```{c}
auto request = client()->find(QSnapdClient::FindFlag::MatchName, m_snap->name());
```

#### AUTO 


```{c}
auto start = [this, entryid, stream, providerid]() {
        m_responsePending = true;
        m_engine->fetchEntryById(entryid);
        m_onePage = false;

        connect(m_engine, &KNSCore::Engine::signalErrorCode, stream, &ResultsStream::finish);
        connect(m_engine, &KNSCore::Engine::signalEntryDetailsLoaded, stream, [this, stream, entryid, providerid](const KNSCore::EntryInternal &entry) {
            if (entry.uniqueId() == entryid && providerid == QUrl(entry.providerId()).host()) {
                Q_EMIT stream->resourcesFound({resourceForEntry(entry)});
            } else
                qWarning() << "found invalid" << entryid << entry.uniqueId() << providerid << QUrl(entry.providerId()).host();
            m_responsePending = false;
            QTimer::singleShot(0, this, &KNSBackend::availableForQueries);
            stream->finish();
        });
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this, entryid, stream, providerid]() {
        m_responsePending = true;
        m_engine->fetchEntryById(entryid);
        connect(m_engine, &KNSCore::Engine::signalError, stream, &ResultsStream::finish);
        connect(m_engine, &KNSCore::Engine::signalEntryDetailsLoaded, stream, [this, stream, entryid, providerid](const KNSCore::EntryInternal &entry) {
            if (entry.uniqueId() == entryid && providerid == QUrl(entry.providerId()).host()) {
                stream->resourcesFound({resourceForEntry(entry)});
            }
            m_responsePending = false;
            QTimer::singleShot(0, this, &KNSBackend::availableForQueries);
            stream->finish();
        });
    }
```

#### AUTO 


```{c}
const auto f = [this, stream, filter] () {
            const QList<AppStream::Component> components = m_appdata->search(filter.search);
            const QStringList ids = kTransform<QStringList>(components, [](const AppStream::Component& comp) { return comp.id(); });
            if (!ids.isEmpty()) {
                const auto resources = kFilter<QVector<AbstractResource*>>(resourcesByPackageNames<QVector<AbstractResource*>>(ids), [](AbstractResource* res){ return !qobject_cast<PackageKitResource*>(res)->extendsItself(); });
                Q_EMIT stream->setResources(resources);
            }

            PackageKit::Transaction * tArch = PackageKit::Daemon::resolve(filter.search, PackageKit::Transaction::FilterArch);
            connect(tArch, &PackageKit::Transaction::package, this, &PackageKitBackend::addPackageArch);
            connect(tArch, &PackageKit::Transaction::package, stream, [stream](PackageKit::Transaction::Info /*info*/, const QString &packageId){
                stream->setProperty("packageId", packageId);
            });
            connect(tArch, &PackageKit::Transaction::finished, stream, [stream, ids, this](PackageKit::Transaction::Exit status) {
                getPackagesFinished();
                if (status == PackageKit::Transaction::Exit::ExitSuccess) {
                    const auto packageId = stream->property("packageId");
                    if (!packageId.isNull()) {
                        const auto res = resourcesByPackageNames<QVector<AbstractResource*>>({PackageKit::Daemon::packageName(packageId.toString())});
                        Q_EMIT stream->setResources(kFilter<QVector<AbstractResource*>>(res, [ids](AbstractResource* res){ return !ids.contains(res->appstreamId()); }));
                    }
                }
                stream->finish();
            }, Qt::QueuedConnection);
        };
```

#### AUTO 


```{c}
const auto matchedCategories = categoryObjects();
```

#### AUTO 


```{c}
const auto versions = res->upgradeText();
```

#### AUTO 


```{c}
auto fw = new QFutureWatcher<bool>(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this, stream, filter]() {
            if (m_isValid) {
                auto filterFunction = [&filter](AbstractResource* r) { return r->state()>=filter.state && (r->name().contains(filter.search, Qt::CaseInsensitive) || r->comment().contains(filter.search, Qt::CaseInsensitive)); };
                const auto ret = kFilter<QVector<AbstractResource*>>(m_resourcesByName, filterFunction);

                if (!ret.isEmpty())
                    stream->resourcesFound(ret);
            }
            stream->finish();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &component : data.components) {
            addComponent(component);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QDeclarativeError &error : m_view->errors()) {
            errors.append(error.toString() + QLatin1String("\n"));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Category *c : cats)
                    Category::addSubcategory(ret, c);
```

#### AUTO 


```{c}
auto stream = new ResultsStream(QLatin1String("FlatpakStream-http-") + filter.resourceUrl.fileName());
```

#### AUTO 


```{c}
auto ret = source->m_resources.value(id);
```

#### LAMBDA EXPRESSION 


```{c}
[process]() {
        qWarning() << "rpm-ostree-backend: Error while calling rpm-ostree:" << process->readAllStandardError();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, appstreamIds, stream]() {
                AbstractResource *pkg = nullptr;

                QStringList allAppStreamIds = appstreamIds;
                {
                    auto it = deprecatedAppstreamIds.constFind(appstreamIds.first());
                    if (it != deprecatedAppstreamIds.constEnd()) {
                        allAppStreamIds << *it;
                    }
                }

                for (auto it = m_packages.packages.constBegin(), itEnd = m_packages.packages.constEnd(); it != itEnd; ++it) {
                    const bool matches = kContains(allAppStreamIds, [&it](const QString &id) {
                        static const QLatin1String desktopPostfix(".desktop");
                        return it.key().compare(id, Qt::CaseInsensitive) == 0 ||
                            // doing (id == id.key()+".desktop") without allocating
                            (id.size() == (desktopPostfix.size() + it.key().size()) && id.endsWith(desktopPostfix)
                             && id.startsWith(it.key(), Qt::CaseInsensitive));
                    });
                    if (matches) {
                        pkg = it.value();
                        break;
                    }
                }
                if (pkg)
                    stream->setResources({pkg});
                stream->finish();
                //             if (!pkg)
                //                 qCDebug(LIBDISCOVER_BACKEND_LOG) << "could not find" << host << deprecatedHost;
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractResource *r : qAsConst(m_resources)) {
            if (r->type() == AbstractResource::Technical && filter.state != AbstractResource::Upgradeable) {
                continue;
            }

            if (r->state() < filter.state)
                continue;

            if (r->name().contains(filter.search, Qt::CaseInsensitive) || r->comment().contains(filter.search, Qt::CaseInsensitive))
                ret += r;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](AbstractResource *resource, const QVector<QByteArray> &properties) {
        if (!properties.contains("state"))
            return;

        const QString appstreamId = resource->appstreamId();
        if (kContains(m_initial, [&appstreamId](const PackageState &state) {
                return appstreamId == state.packageName();
            })) {
            resetState();
        }
    }
```

#### AUTO 


```{c}
const auto deprecatedHost = deprecatedAppstreamIds.value(appstreamId);
```

#### AUTO 


```{c}
auto it = toRemoveHash.constBegin(), itEnd = toRemoveHash.constEnd();
```

#### AUTO 


```{c}
auto it = names.constBegin();
```

#### LAMBDA EXPRESSION 


```{c}
[this, stream, filter] {
            const auto toResolve = kFilter<QVector<AbstractResource *>>(m_packages.packages, needsResolveFilter);

            auto installedAndNameFilter = [filter](AbstractResource *res) {
                return res->state() >= AbstractResource::Installed && (res->name().contains(filter.search) || res->packageName() == filter.search);
            };
            bool furtherSearch = false;
            if (!toResolve.isEmpty()) {
                resolvePackages(kTransform<QStringList>(toResolve, [](AbstractResource *res) {
                    return res->packageName();
                }));
                connect(m_resolveTransaction, &PKResolveTransaction::allFinished, this, [stream, toResolve, installedAndNameFilter] {
                    const auto resolved = kFilter<QVector<AbstractResource *>>(toResolve, installedAndNameFilter);
                    if (!resolved.isEmpty())
                        Q_EMIT stream->resourcesFound(resolved);
                    stream->finish();
                });
                furtherSearch = true;
            }

            const auto resolved = kFilter<QVector<AbstractResource *>>(m_packages.packages, installedAndNameFilter);
            if (!resolved.isEmpty()) {
                QTimer::singleShot(0, this, [resolved, toResolve, stream]() {
                    if (!resolved.isEmpty())
                        Q_EMIT stream->resourcesFound(resolved);

                    if (toResolve.isEmpty())
                        stream->finish();
                });
                furtherSearch = true;
            }

            if (!furtherSearch)
                stream->finish();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(Category* subCat : m_subCategories) {
        if(!categoryLessThan(subCat, cat)) {
            break;
        }
        ++i;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString& pkgid : m_updatesPackageId) {
        ret += m_packages[PackageKit::Daemon::packageName(pkgid)];
        if (!ret.last()) {
            qWarning() << "couldn't find resource for" << pkgid;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto& v : input) {
        ret += v;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto slot : theSlots) {
                    auto item = new QStandardItem;
                    if (plug->label().isEmpty())
                        item->setText(plug->name());
                    else
                        item->setText(i18n("%1 - %2", plug->name(), plug->label()));

                    //                     qDebug() << "xxx" << plug->name() << plug->label() << plug->interface() << slot->snap() << "slot:" << slot->name() <<
                    //                     slot->snap() << slot->interface() << slot->label();
                    item->setCheckable(true);
                    item->setCheckState(plug->connectionCount() > 0 ? Qt::Checked : Qt::Unchecked);
                    item->setData(plug->name(), PlugNameRole);
                    item->setData(slot->snap(), SlotSnapRole);
                    item->setData(slot->name(), SlotNameRole);
                    appendRow(item);
                }
```

#### AUTO 


```{c}
auto pkres = qobject_cast<PackageKitResource*>(resource);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &filter : m_orFilters) {
        if (filter.first == CategoryFilter && filter.second == name)
            return true;
    }
```

#### AUTO 


```{c}
auto f = [this](AbstractResource* l, AbstractResource* r) { return flatpakResourceLessThan(l,r); };
```

#### AUTO 


```{c}
auto stream = new ResultsStream(QLatin1String("KNS-byname-") + entryid);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &v : input) {
        ret += op(v);
    }
```

#### AUTO 


```{c}
auto applicationCategory = new Category(i18n("Applications"), //
                                                QStringLiteral("applications-internet"),
                                                filters,
                                                backendName,
                                                {actualCategory},
                                                QUrl(),
                                                false);
```

#### LAMBDA EXPRESSION 


```{c}
[](){ qDebug() << "connected"; }
```

#### LAMBDA EXPRESSION 


```{c}
[mainWindow](const QStringList &arguments, const QString & /*workingDirectory*/) {
                             if (!mainWindow->rootObject())
                                 QCoreApplication::instance()->quit();

                             auto window = qobject_cast<QWindow *>(mainWindow->rootObject());
                             if (window && QX11Info::isPlatformX11()) {
                                 KStartupInfo::setNewStartupId(window, QX11Info::nextStartupId());
                             }
                             window->raise();

                             if (arguments.isEmpty())
                                 return;
                             QScopedPointer<QCommandLineParser> parser(createParser());
                             parser->parse(arguments);
                             processArgs(parser.data(), mainWindow);
                         }
```

#### AUTO 


```{c}
const auto& updateText = _updateText;
```

#### AUTO 


```{c}
const auto cats = m_engine->categoriesMetadata();
```

#### AUTO 


```{c}
auto split_branch = ref.split('/');
```

#### AUTO 


```{c}
auto action = new OneTimeAction(
        [this]() {
            bool found = DiscoverBackendsFactory::hasRequestedBackends();
            const auto backends = ResourcesModel::global()->backends();
            for (auto b : backends)
                found |= b->hasApplications();

            if (!found)
                Q_EMIT openErrorPage(
                    i18n("Discover currently cannot be used to install any apps "
                         "because none of its app backends are available. Please "
                         "report this issue to the packagers of your distribution."));
        },
        this);
```

#### AUTO 


```{c}
auto &r = m_resources[res->packageName().toLower()];
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            // If we are using offline updates, there is no need to badger the user to
            // reboot since it is safe to continue using the system in its current state
            if (!m_needsReboot && !m_settings->useUnattendedUpdates()) {
                m_needsReboot = true;
                showRebootNotification();
                Q_EMIT stateChanged();
                Q_EMIT needsRebootChanged(true);
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, stream] {
            auto fw = new QFutureWatcher<QMap<FlatpakInstallation *, QVector<FlatpakInstalledRef *>>>(this);
            connect(fw, &QFutureWatcher<QByteArray>::finished, this, [this, fw, stream]() {
                if (g_cancellable_is_cancelled(m_cancellable)) {
                    stream->finish();
                    fw->deleteLater();
                    return;
                }

                const auto refs = fw->result();
                QVector<AbstractResource *> resources;
                for (auto it = refs.constBegin(), itEnd = refs.constEnd(); it != itEnd; ++it) {
                    resources.reserve(resources.size() + it->size());
                    for (auto ref : qAsConst(it.value())) {
                        bool fresh;
                        auto resource = getAppForInstalledRef(it.key(), ref, &fresh);
#if FLATPAK_CHECK_VERSION(1, 1, 2)
                        resource->setAvailableVersion(QString::fromUtf8(flatpak_installed_ref_get_appdata_version(ref)));
#endif
                        g_object_unref(ref);
                        resource->setState(AbstractResource::Upgradeable, !fresh);
                        updateAppSize(resource);
                        if (resource->resourceType() == FlatpakResource::Runtime) {
                            resources.prepend(resource);
                        } else {
                            resources.append(resource);
                        }
                    }
                }

                if (!resources.isEmpty())
                    Q_EMIT stream->resourcesFound(resources);
                stream->finish();
                fw->deleteLater();
            });

            QVector<FlatpakInstallation *> installations = m_installations;
            auto cancellable = m_cancellable;
            fw->setFuture(QtConcurrent::run(&m_threadPool, [installations, cancellable] {
                QMap<FlatpakInstallation *, QVector<FlatpakInstalledRef *>> ret;

                for (auto installation : installations) {
                    g_autoptr(GError) localError = nullptr;
                    g_autoptr(GPtrArray) refs = flatpak_installation_list_installed_refs_for_update(installation, cancellable, &localError);
                    if (!refs) {
                        qWarning() << "Failed to get list of installed refs for listing updates:" << localError->message;
                        continue;
                    }
                    if (g_cancellable_is_cancelled(cancellable)) {
                        qWarning() << "Job cancelled";
                        return ret;
                    }

                    auto &current = ret[installation];
                    current.reserve(refs->len);
                    for (uint i = 0; i < refs->len; i++) {
                        FlatpakInstalledRef *ref = FLATPAK_INSTALLED_REF(g_ptr_array_index(refs, i));
                        g_object_ref(ref);
                        current.append(ref);
                    }
                }
                return ret;
            }));
        }
```

#### AUTO 


```{c}
auto action = new OneTimeAction(
        [this, category]() {
            Category *cat = CategoryModel::global()->findCategoryByName(category);
            if (cat) {
                Q_EMIT listCategoryInternal(cat);
            } else {
                openMode(QStringLiteral("Browsing"));
                showPassiveNotification(i18n("Could not find category '%1'", category));
            }
        },
        this);
```

#### AUTO 


```{c}
auto id = m_appdata.bundle(AppStream::Bundle::KindFlatpak).id();
```

#### LAMBDA EXPRESSION 


```{c}
[](AbstractResource *res) {
                    return res->packageName();
                }
```

#### AUTO 


```{c}
auto f = [this, filter, stream] {
            auto resources = kFilter<QVector<AbstractResource*>>(m_packages.packages, [](AbstractResource* res) { return res->type() != AbstractResource::Technical && !qobject_cast<PackageKitResource*>(res)->extendsItself(); });
            if (!resources.isEmpty()) {
                Q_EMIT stream->setResources(resources);
            }
        };
```

#### AUTO 


```{c}
const auto allTransactions = transactions();
```

#### AUTO 


```{c}
const auto& v
```

#### AUTO 


```{c}
const auto service = locateService(QStringLiteral("software-properties-kde.desktop"));
```

#### RANGE FOR STATEMENT 


```{c}
for(auto & elem : m_addons)
    {
        if(elem.name() == addon)
        {
            elem.setInstalled(installed);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[] (PackageKit::Transaction::Exit status, uint runtime) {
                qInfo() << "repair finished!" << status << runtime;
                if (status == PackageKit::Transaction::ExitSuccess) {
                    PackageKit::Daemon::global()->offline()->clearResults();
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this, fw] {
        const QJsonDocument jsonDocument = fw->result();
        fw->deleteLater();
        const QJsonObject jsonObject = jsonDocument.object();
        m_ratings.reserve(jsonObject.size());
        for (auto it = jsonObject.begin(); it != jsonObject.end(); it++) {
            QJsonObject appJsonObject = it.value().toObject();

            const int ratingCount =  appJsonObject.value(QLatin1String("total")).toInt();
            int ratingMap[] = { appJsonObject.value(QLatin1String("star0")).toInt(),
                                appJsonObject.value(QLatin1String("star1")).toInt(),
                                appJsonObject.value(QLatin1String("star2")).toInt(),
                                appJsonObject.value(QLatin1String("star3")).toInt(),
                                appJsonObject.value(QLatin1String("star4")).toInt(),
                                appJsonObject.value(QLatin1String("star5")).toInt(), };

            Rating *rating = new Rating(it.key(), ratingCount, ratingMap);
            m_ratings.insert(it.key(), rating);
        }
        Q_EMIT ratingsReady();
    }
```

#### AUTO 


```{c}
auto i = m_jobFilenames.constBegin();
```

#### LAMBDA EXPRESSION 


```{c}
[](QProcess::ProcessError error) {
        qWarning() << "Error running plasma-discover-update" << error;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto job : jobs) {
            job->deleteLater();
            if (job->error()) {
                qDebug() << "error:" << job->error() << job->errorString();
                continue;
            }

            for (int i = 0, c = job->snapCount(); i < c; ++i) {
                QSharedPointer<QSnapdSnap> snap(job->snap(i));

                if (!filter(snap))
                    continue;

                const auto snapname = snap->name();
                SnapResource *&res = m_resources[snapname];
                if (!res) {
                    res = new SnapResource(snap, AbstractResource::None, this);
                    Q_ASSERT(res->packageName() == snapname);
                } else {
                    res->setSnap(snap);
                }
                ret += res;
            }
        }
```

#### AUTO 


```{c}
auto updateTransaction = qobject_cast<UpdateTransaction *>(t);
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
            emit updatesCountChanged();
        }
```

#### AUTO 


```{c}
const auto components = backend()->componentsById(m_appdata.extends().constFirst());
```

#### RANGE FOR STATEMENT 


```{c}
for(auto resource: resources) {
        const auto finder = [this, resource](AbstractResource* res){ return lessThan(resource, res); };
        const auto it = std::find_if(m_displayedResources.constBegin() + newIdx, m_displayedResources.constEnd(), finder);
        newIdx = it == m_displayedResources.constEnd() ? m_displayedResources.count() : (it - m_displayedResources.constBegin());

        beginInsertRows({}, newIdx, newIdx);
        m_displayedResources.insert(newIdx, resource);
        endInsertRows();
    }
```

#### AUTO 


```{c}
auto tm = TransactionModel::global();
```

#### AUTO 


```{c}
auto match = matchIt.next();
```

#### AUTO 


```{c}
const auto ret = m_appdata.provided(AppStream_Provided_KindId).items();
```

#### LAMBDA EXPRESSION 


```{c}
[this, entryid, stream]() {
        m_responsePending = true;
        m_engine->fetchEntryById(entryid);
        connect(m_engine, &KNSCore::Engine::signalEntryDetailsLoaded, stream, [this, stream, entryid](const KNSCore::EntryInternal &entry) {
            if (entry.uniqueId() == entryid) {
                stream->resourcesFound({resourceForEntry(entry)});
            }
            m_responsePending = false;
            QTimer::singleShot(0, this, &KNSBackend::availableForQueries);
            stream->deleteLater();
        });
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto source : qAsConst(m_flatpakSources)) {
        if (source->remote()) {
            Q_ASSERT(!m_refreshAppstreamMetadataJobs.contains(source->remote()));
            m_refreshAppstreamMetadataJobs.insert(source->remote());
            checkForUpdates(source->installation(), source->remote());
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](AbstractResourcesBackend* b) { return b->hasApplications(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](AbstractResource *resource, AbstractResource *res) {
            return lessThan(resource, res);
        }
```

#### AUTO 


```{c}
auto fw = new QFutureWatcher<GPtrArray *>(this);
```

#### AUTO 


```{c}
auto stream = new ResultsStream(QStringLiteral("KNS-installed"));
```

#### LAMBDA EXPRESSION 


```{c}
[this, fetchingChangedTimer]{
//         Q_ASSERT(isFetching() != fetchingChangedTimer->isActive());
        if (isFetching())
            fetchingChangedTimer->start();
        else
            fetchingChangedTimer->stop();
    }
```

#### AUTO 


```{c}
const auto pkgidVal = trans->property("installedPackage");
```

#### RANGE FOR STATEMENT 


```{c}
for (auto resource : qAsConst(resources)) {
            addResource(resource);
        }
```

#### AUTO 


```{c}
const auto job = socket.snapAction(snap, SnapSocket::Install);
```

#### AUTO 


```{c}
auto devices = fw->result();
```

#### AUTO 


```{c}
auto stream = new PKResultsStream(this, QStringLiteral("PackageKitStream-all"));
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractResource *res : packages) {
        if (SystemUpgrade *upgrade = dynamic_cast<SystemUpgrade *>(res)) {
            packageIds = involvedPackages(upgrade->resources());
            continue;
        }

        PackageKitResource *app = qobject_cast<PackageKitResource *>(res);
        const QString pkgid = m_backend->upgradeablePackageId(app);
        if (pkgid.isEmpty()) {
            qWarning() << "no upgradeablePackageId for" << app;
            continue;
        }

        packageIds.insert(pkgid);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
              {
                  if (m_backends.isEmpty())
                      return 0;

                  int sum = 0;
                  for (auto backend : qAsConst(m_backends)) {
                      sum += backend->fetchingUpdatesProgress();
                  }
                  return sum / (int)m_backends.count();
              }
          }
```

#### AUTO 


```{c}
const auto val = line.mid(idx+2).trimmed();
```

#### LAMBDA EXPRESSION 


```{c}
[this, icon, fileName, manager](QNetworkReply *reply) {
                        if (reply->error() == QNetworkReply::NoError) {
                            QByteArray iconData = reply->readAll();
                            QFile file(fileName);
                            if (file.open(QIODevice::WriteOnly)) {
                                file.write(iconData);
                            }
                            file.close();
                            Q_EMIT iconChanged();
                        }
                        manager->deleteLater();
                    }
```

#### AUTO 


```{c}
static const auto needsResolveFilter = [] (AbstractResource* res) { return res->state() == AbstractResource::Broken; };
```

#### AUTO 


```{c}
const auto snapObj = snap.toObject();
```

#### LAMBDA EXPRESSION 


```{c}
[packageDependencies](PackageKit::Transaction::Info info, const QString &packageID, const QString &summary) {
        (*packageDependencies)[PackageKit::Daemon::packageName(packageID)] = summary ;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto res : resources)
            if (res->state() == AbstractResource::Upgradeable)
                m_upgradeable.insert(res);
```

#### AUTO 


```{c}
const auto servicePath = QStandardPaths::locate(QStandardPaths::ApplicationsLocation, m_appdata.id());
```

#### AUTO 


```{c}
auto idx = kIndexOf(m_backends, [name](AbstractResourcesBackend* b) { return b->hasApplications() && b->name() == name; });
```

#### LAMBDA EXPRESSION 


```{c}
[menu](UpgradeAction *a) {
        QAction *action = new QAction(a->description(), menu);
        connect(action, &QAction::triggered, a, &UpgradeAction::trigger);
        menu->addAction(action);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractResource *res : resources) {
        sortedResources[res->backend()] += res;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &error) { qWarning() << "kns error" << error; }
```

#### LAMBDA EXPRESSION 


```{c}
[](AbstractResource *res) {
                        return !qobject_cast<PackageKitResource *>(res)->extendsItself();
                    }
```

#### LAMBDA EXPRESSION 


```{c}
[action] () {
        action->trigger();
    }
```

#### AUTO 


```{c}
static const auto installedFilter = [] (AbstractResource* res) { return res->state() >= AbstractResource::Installed; };
```

#### AUTO 


```{c}
auto stream = new StoredResultsStream ({backend->search(filter)});
```

#### LAMBDA EXPRESSION 


```{c}
[this, toRemoveRefs, installation, id] {
                    g_autoptr(GError) localError = nullptr;
                    g_autoptr(GCancellable) cancellable = g_cancellable_new();
                    g_autoptr(FlatpakTransaction) transaction = flatpak_transaction_new_for_installation(installation, cancellable, &localError);
                    for (const QString &instRef : qAsConst(toRemoveRefs)) {
                        const QByteArray refString = instRef.toUtf8();
                        flatpak_transaction_add_uninstall(transaction, refString.constData(), &localError);
                        if (localError)
                            return;
                    }

                    if (flatpak_transaction_run(transaction, cancellable, &localError)) {
                        removeSource(id);
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &in : urls)
        ret += QStringLiteral("<a href='%1'>%1</a>").arg(in);
```

#### AUTO 


```{c}
const auto res = packagesForPackageId({packageID});
```

#### AUTO 


```{c}
auto resourceExtends = [id](AbstractResource* res) {return res->extends().contains(id); };
```

#### RANGE FOR STATEMENT 


```{c}
for (auto res : resources) {
                                    installApplication(res);
                                }
```

#### LAMBDA EXPRESSION 


```{c}
[resource] () {
            resource->setPropertyState(FlatpakResource::DownloadSize, FlatpakResource::UnknownOrFailed);
            resource->setPropertyState(FlatpakResource::InstalledSize, FlatpakResource::UnknownOrFailed);
        }
```

#### AUTO 


```{c}
auto action = new OneTimeAction(
        [this, category]() {
            Category* cat = CategoryModel::global()->findCategoryByName(category);
            if (!cat) {
                showPassiveNotification(i18n("Could not find category '%1'", category));
                return;
            }

            emit listCategoryInternal(cat);
        }
        , this);
```

#### AUTO 


```{c}
auto res = ResourcesModel::global()->resourceForFile(localfile);
```

#### LAMBDA EXPRESSION 


```{c}
[](AbstractResourcesBackend* b){ return b->hasApplications(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (RpmOstreeResource *r : m_resources) {
        if (r->state() >= filter.state) {
            // Let's only include the booted deployment until we have better support for multiple deployments
            if (r->isBooted()) {
                res.push_back(r);
            }
        }
    }
```

#### AUTO 


```{c}
const auto keys = snap.keys();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto res: qAsConst(m_resources)) {
            if (ret->resources().contains(res))
                res->setState(AbstractResource::Installed);
            else
                res->setState(AbstractResource::None);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Category* cat : qAsConst(categories)) {
                if (cat->orFilters().count() > 0 && cat->orFilters().constFirst().second == category.name) {
                    cat->setName(category.displayName);
                    break;
                }
            }
```

#### AUTO 


```{c}
auto a = new OneTimeAction(
            [this] {
                emit updatesCountChanged();
            },
            this);
```

#### AUTO 


```{c}
auto id = idForInstalledRef(ref, {});
```

#### AUTO 


```{c}
auto options = parser->optionNames();
```

#### AUTO 


```{c}
const auto transport = QNetworkInformation::instance()->transportMedium();
```

#### AUTO 


```{c}
auto &resPos = m_packages.packages[component.id()];
```

#### LAMBDA EXPRESSION 


```{c}
[](QQmlEngine*, QJSEngine*) -> QObject* { return new SystemFonts; }
```

#### LAMBDA EXPRESSION 


```{c}
[this, localfile]() {
            AbstractResourcesBackend::Filters f;
            f.resourceUrl = localfile;
            auto stream = new StoredResultsStream({ResourcesModel::global()->search(f)});
            connect(stream, &StoredResultsStream::finished, this, [this, localfile, stream]() {
                const auto res = stream->resources();
                if (res.count() == 1) {
                    emit openApplicationInternal(res.first());
                } else {
                    QMimeDatabase db;
                    auto mime = db.mimeTypeForUrl(localfile);
                    auto fIsFlatpakBackend = [](AbstractResourcesBackend* backend) { return backend->metaObject()->className() == QByteArray("FlatpakBackend"); };
                    if (mime.name().startsWith(QLatin1String("application/vnd.flatpak")) && !kContains(ResourcesModel::global()->backends(), fIsFlatpakBackend)) {
                        openApplication(QUrl(QStringLiteral("appstream://org.kde.discover.flatpak")));
                        showPassiveNotification(i18n("Cannot interact with flatpak resources without the flatpak backend %1. Please install it first.", localfile.toDisplayString()));
                    } else {
                        setRootObjectProperty("defaultStartup", true);
                        showPassiveNotification(i18n("Couldn't open %1", localfile.toDisplayString()));
                    }
                }
            });
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        if (m_offlineUpdates == group.readEntry<bool>("UseOfflineUpdates", false)) {
            return;
        }
        Q_EMIT useUnattendedUpdatesChanged();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[func, process, varname](int code) {
        if (code != 0)
            return;

        QRegularExpression rx(QLatin1Char('^') + varname + QStringLiteral(" \"(.*?)\";?$"), QRegularExpression::CaseInsensitiveOption);
        QTextStream stream(process);
        QString line;
        while (stream.readLineInto(&line)) {
            const auto match = rx.match(line);
            if (match.hasMatch()) {
                func(match.capturedRef(1));
                return;
            }
        }
        func({});
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& instRef : qAsConst(toRemoveRefs)) {
                    const QByteArray refString = instRef.toUtf8();
                    flatpak_transaction_add_uninstall(transaction, refString.constData(), &localError);
                    if (localError)
                        return;
                }
```

#### LAMBDA EXPRESSION 


```{c}
[mainWindow](const QStringList &arguments, const QString &/*workingDirectory*/){
            if (!mainWindow->rootObject())
                QCoreApplication::instance()->quit();

            mainWindow->rootObject()->raise();
            if (arguments.isEmpty())
                return;
            QScopedPointer<QCommandLineParser> parser(createParser());
            parser->parse(arguments);
            processArgs(parser.data(), mainWindow);
        }
```

#### AUTO 


```{c}
auto discoverAction = menu->addAction(QIcon::fromTheme(QStringLiteral("plasma-discover")), i18n("Open Discover..."));
```

#### LAMBDA EXPRESSION 


```{c}
[name](AbstractResourcesBackend *b) {
        return b->hasApplications() && b->name() == name;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, resource] {
            // Even when we failed to fetch information about runtime we still want to show the application
            addResource(resource);
        }
```

#### AUTO 


```{c}
auto c = new AppStream::Component();
```

#### AUTO 


```{c}
const auto sourceName = source.name();
```

#### LAMBDA EXPRESSION 


```{c}
[this, entryid, stream, providerid]() {
        m_responsePending = true;
        m_engine->fetchEntryById(entryid);
        m_onePage = false;
        connect(m_engine, &KNSCore::Engine::signalError, stream, &ResultsStream::finish);
        connect(m_engine, &KNSCore::Engine::signalEntryDetailsLoaded, stream, [this, stream, entryid, providerid](const KNSCore::EntryInternal &entry) {
            if (entry.uniqueId() == entryid && providerid == QUrl(entry.providerId()).host()) {
                stream->resourcesFound({resourceForEntry(entry)});
            } else
                qWarning() << "found invalid" << entryid << entry.uniqueId() << providerid << QUrl(entry.providerId()).host();
            m_responsePending = false;
            QTimer::singleShot(0, this, &KNSBackend::availableForQueries);
            stream->finish();
        });
    }
```

#### AUTO 


```{c}
auto it = m_packages.packages.cbegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractResource *res : qAsConst(m_allUpgradeable)) {
        if (auto upgrade = dynamic_cast<SystemUpgrade *>(res)) {
            upgrade->fetchChangelog();
        } else {
            pkgids += static_cast<PackageKitResource *>(res)->availablePackageId();
        }
    }
```

#### AUTO 


```{c}
auto addSource = [=](AbstractResource *res) {
        if (res)
            backend->installApplication(res);
        else
            Q_EMIT backend->passiveMessage(i18n("Could not add the source %1", flatpakrepoUrl.toDisplayString()));
    };
```

#### AUTO 


```{c}
auto start = [this, entryid, stream, providerid]() {
        m_responsePending = true;
        m_engine->fetchEntryById(entryid);
        m_onePage = false;
        connect(m_engine, &KNSCore::Engine::signalError, stream, &ResultsStream::finish);
        connect(m_engine, &KNSCore::Engine::signalEntryDetailsLoaded, stream, [this, stream, entryid, providerid](const KNSCore::EntryInternal &entry) {
            if (entry.uniqueId() == entryid && providerid == QUrl(entry.providerId()).host()) {
                Q_EMIT stream->resourcesFound({resourceForEntry(entry)});
            } else
                qWarning() << "found invalid" << entryid << entry.uniqueId() << providerid << QUrl(entry.providerId()).host();
            m_responsePending = false;
            QTimer::singleShot(0, this, &KNSBackend::availableForQueries);
            stream->finish();
        });
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this, appstreamIds, stream] () {
                AbstractResource* pkg = nullptr;

                QStringList allAppStreamIds = appstreamIds;
                {
                    auto it = deprecatedAppstreamIds.constFind(appstreamIds.first());
                    if (it != deprecatedAppstreamIds.constEnd()) {
                        allAppStreamIds << *it;
                    }
                }

                for (auto it = m_packages.packages.constBegin(), itEnd = m_packages.packages.constEnd(); it != itEnd; ++it) {
                    const bool matches = kContains(allAppStreamIds, [&it] (const QString& id) {
                        return it.key().compare(id, Qt::CaseInsensitive) == 0 ||
                              (id.endsWith(QLatin1String(".desktop")) && id.compare(it.key()+QLatin1String(".desktop"), Qt::CaseInsensitive) == 0);
                    });
                    if (matches) {
                        pkg = it.value();
                        break;
                    }
                }
                if (pkg)
                    Q_EMIT stream->resourcesFound({pkg});
                stream->finish();
    //             if (!pkg)
    //                 qCDebug(LIBDISCOVER_BACKEND_LOG) << "could not find" << host << deprecatedHost;
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto a : vector) {
        if (last && !Category::categoryLessThan(last, a))
            return false;
        last = a;
    }
```

#### AUTO 


```{c}
const auto match = rx.match(line);
```

#### RANGE FOR STATEMENT 


```{c}
for(AbstractSourcesBackend* b: m_sources) {
        for(QAction* action: b->actions())
            ret.append(action);
    }
```

#### AUTO 


```{c}
auto array = fwupd_client_get_devices_finish(helper->client, res, &error);
```

#### AUTO 


```{c}
auto search = new OneTimeAction(
        666,
        [this]() {
            // First we ensure we've got data loaded on what we've got installed already
            if (m_responsePending) {
                // Slot already taken, will need to wait again
                return false;
            }
            m_onePage = true;
            setResponsePending(true);
            m_engine->checkForInstalled();
            // And then we check for updates - we could do only one, if all we cared about was updates,
            // but to have both a useful initial list, /and/ information on updates, we want to get both.
            // The reason we are not doing a checkUpdates() overload for this is that the caching for this
            // information is done by KNSEngine, and we want to actually load it every time we initialize.
            auto updateChecker = new OneTimeAction(
                666,
                [this] {
                    //No need to check for updates if there's no resources
                    if (m_resourcesByName.isEmpty()) {
                        return true;
                    }

                    if (m_responsePending) {
                        // Slot already taken, will need to wait again
                        return false;
                    }

                    m_onePage = true;
                    setResponsePending(true);
                    m_engine->checkForUpdates();
                    return true;
                },
                this);
            connect(this, &KNSBackend::availableForQueries, updateChecker, &OneTimeAction::trigger, Qt::QueuedConnection);
            return true;
        },
        this);
```

#### AUTO 


```{c}
const auto job = socket.snapAction(snap, SnapSocket::Remove);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QByteArray &arr) {
        return roleNames().key(arr, -1);
    }
```

#### AUTO 


```{c}
auto f = [this, stream, filter]() {
        QVector<AbstractResource *> ret;
        foreach (AbstractResource *r, m_resources) {
            if (r->state() < filter.state)
                continue;

            if (filter.search.isEmpty() || r->name().contains(filter.search, Qt::CaseInsensitive)
                || r->comment().contains(filter.search, Qt::CaseInsensitive)) {
                ret += r;
            }
        }
        if (!ret.isEmpty())
            Q_EMIT stream->resourcesFound(ret);
        stream->finish();
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this](SnapJob* job){
        m_state = job->isSuccessful() ? AbstractResource::Installed : AbstractResource::None;
        Q_EMIT stateChanged();
        qDebug() << "refreshed!!" << job->result() << job->statusCode() << m_state;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {
            auto trans = PackageKit::Daemon::global()->repairSystem();
            connect(trans, &PackageKit::Transaction::errorCode, this, [](PackageKit::Transaction::Error /*error*/, const QString &details){
                KNotification::event(QStringLiteral("offlineupdate-repair-failed"), i18n("Repair Failed"), i18n("Please report to your distribution: %1", details), {}, KNotification::Persistent, QStringLiteral("org.kde.discovernotifier"));
            });
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &pkg : pkgs) {
            auto res = m_packages.packages.take(pkg);
            if (res) {
                if (AppPackageKitResource *ares = qobject_cast<AppPackageKitResource *>(res)) {
                    const auto extends = res->extends();
                    for (const auto &ext : extends)
                        m_packages.extendedBy[ext].removeAll(ares);
                }

                Q_EMIT resourceRemoved(res);
                res->deleteLater();
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[objectName]() {
        qCDebug(LIBDISCOVER_LOG) << "stream took really long" << objectName;
    }
```

#### AUTO 


```{c}
auto iter = m_subViewHash.begin();
```

#### AUTO 


```{c}
const auto extendsResources = backend()->resourcesByPackageNames<QVector<AbstractResource *>>(extends());
```

#### AUTO 


```{c}
auto cat
```

#### AUTO 


```{c}
auto ret = kTransform<QVector<AbstractResourcesBackend *>>(names, [this](const QString &name) {
        return backend(name);
    });
```

#### AUTO 


```{c}
auto job = socket->snapByName(packageName());
```

#### LAMBDA EXPRESSION 


```{c}
[this, fetchingChangedTimer] {
        //         Q_ASSERT(isFetching() != fetchingChangedTimer->isActive());
        if (isFetching())
            fetchingChangedTimer->start();
        else
            fetchingChangedTimer->stop();

        Q_EMIT fetchingUpdatesProgressChanged();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[stream, tArch, ids, this](PackageKit::Transaction::Exit status) {
            getPackagesFinished();
            if (status == PackageKit::Transaction::Exit::ExitSuccess) {
                const auto packageId = tArch->property("packageId");
                if (!packageId.isNull()) {
                    const auto res = resourcesByPackageNames<QVector<AbstractResource*>>({PackageKit::Daemon::packageName(packageId.toString())});
                    stream->resourcesFound(kFilter<QVector<AbstractResource*>>(res, [ids](AbstractResource* res){ return !ids.contains(res->appstreamId()); }));
                }
            }
            stream->finish();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, stream, appstreamId] () {
                const auto resources = resourcesByAppstreamName(appstreamId);
                if (!resources.isEmpty())
                    Q_EMIT stream->resourcesFound(resources);
                stream->finish();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &cat: cats) {
            if (m_hasApplications)
                categories << new Category(cat, QStringLiteral("applications-other"), { {CategoryFilter, cat } }, backendName, {}, {}, true);
            else
                categories << new Category(cat, QStringLiteral("plasma"), { {CategoryFilter, cat } }, backendName, {}, {}, true);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, stream, filter]() {
        QVector<AbstractResource *> ret;
        foreach (AbstractResource *r, m_resources) {
            if (r->state() < filter.state)
                continue;

            if (filter.search.isEmpty() || r->name().contains(filter.search, Qt::CaseInsensitive)
                || r->comment().contains(filter.search, Qt::CaseInsensitive)) {
                ret += r;
            }
        }
        if (!ret.isEmpty())
            Q_EMIT stream->resourcesFound(ret);
        stream->finish();
    }
```

#### AUTO 


```{c}
auto repo = flatpak_installation_get_remote_by_name(preferredInstallation(), flatpak_remote_get_name(remote), nullptr, nullptr);
```

#### LAMBDA EXPRESSION 


```{c}
[this, filter, stream] {
            auto resources = kFilter<QVector<AbstractResource*>>(m_packages.packages, [](AbstractResource* res) { return res->type() != AbstractResource::Technical && !qobject_cast<PackageKitResource*>(res)->extendsItself(); });
            if (!resources.isEmpty()) {
                stream->setResources(resources);
            }
            stream->finish();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, fw, flatpakInstallation, appstreamIconsPath, sourceName]() {
        const auto components = fw->result();
        foreach (const AppStream::Component& appstreamComponent, components) {
            FlatpakResource *resource = new FlatpakResource(appstreamComponent, flatpakInstallation, this);
            resource->setIconPath(appstreamIconsPath);
            resource->setOrigin(sourceName);
            addResource(resource);
        }

        m_refreshAppstreamMetadataJobs--;
        if (m_refreshAppstreamMetadataJobs == 0) {
            loadInstalledApps();
            checkForUpdates();

        }
        acquireFetching(false);
        fw->deleteLater();
    }
```

#### AUTO 


```{c}
auto f = [this, filter, stream] {
            auto resources = kFilter<QVector<AbstractResource *>>(m_packages.packages, [](AbstractResource *res) {
                return res->type() != AbstractResource::Technical && !qobject_cast<PackageKitResource *>(res)->isCritical()
                    && !qobject_cast<PackageKitResource *>(res)->extendsItself();
            });
            stream->setResources(resources);
            stream->finish();
        };
```

#### RANGE FOR STATEMENT 


```{c}
for (auto t : allTransactions) {
        allProgresses += t->progress();
    }
```

#### AUTO 


```{c}
auto user = flatpak_installation_new_user(m_cancellable, error);
```

#### LAMBDA EXPRESSION 


```{c}
[this, fetchJob]() {
        const auto dest = qScopeGuard([this] {
            acquireFetching(false);
            refresh();
        });
        if (fetchJob->error() != 0)
            return;

        QFile f(*featuredCache);
        if (!f.open(QIODevice::WriteOnly))
            qCWarning(DISCOVER_LOG) << "could not open" << *featuredCache << f.errorString();
        f.write(fetchJob->data());
        f.close();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](){
        if (m_initializingBackends == 0)
            emit allInitialized();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, url]() {
            AbstractResourcesBackend::Filters f;
            f.resourceUrl = url;
            auto stream = new StoredResultsStream({ResourcesModel::global()->search(f)});
            connect(stream, &StoredResultsStream::finishedResources, this, [this, url](const QVector<AbstractResource*> &res) {
                if (res.count() >= 1) {
                    emit openApplicationInternal(res.first());
                } else if (url.scheme() == QLatin1String("snap")) {
                    openApplication(QUrl(QStringLiteral("appstream://org.kde.discover.snap")));
                    showPassiveNotification(i18n("Please make sure Snap support is installed"));
                } else {
                    Q_EMIT openErrorPage(i18n("Could not open %1", url.toDisplayString()));
                }
            });
        }
```

#### AUTO 


```{c}
auto e = KNotification::event(QStringLiteral("Update"), message(), {}, iconName(), nullptr, KNotification::CloseOnTimeout, QStringLiteral("discoverabstractnotifier"));
```

#### LAMBDA EXPRESSION 


```{c}
[this, stream, filter] () {
        QVector<AbstractResource*> ret;
        foreach(AbstractResource* r, m_resources) {
            if (r->state() < filter.state)
                continue;

            if (filter.search.isEmpty() || r->name().contains(filter.search, Qt::CaseInsensitive) || r->comment().contains(filter.search, Qt::CaseInsensitive)) {
                ret += r;
            }
        }
        if (!ret.isEmpty())
            Q_EMIT stream->resourcesFound(ret);
        stream->finish();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto res : resources) {
                auto r = qobject_cast<PackageKitResource *>(res);
                r->clearPackageIds();
                r->addPackageId(state, pkgid, true);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {
            auto trans = PackageKit::Daemon::global()->repairSystem();
            connect(trans, &PackageKit::Transaction::errorCode, this, [](PackageKit::Transaction::Error /*error*/, const QString &details){
                KNotification::event(QStringLiteral("OfflineUpdateRepairFailed"), i18n("Repair Failed"), i18n("Please report to your distribution: %1", details), {}, KNotification::Persistent, QStringLiteral("org.kde.discovernotifier"));
            });
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractBackendUpdater *updater : qAsConst(m_allUpdaters)) {
            total += updater->progress();
        }
```

#### AUTO 


```{c}
auto m = idx.model();
```

#### AUTO 


```{c}
auto mKeyBindignsAction = KStandardAction::keyBindings(this, &DiscoverMainWindow::configureShortcuts, this);
```

#### LAMBDA EXPRESSION 


```{c}
[type] () {
        QDBusInterface interface(QStringLiteral("org.kde.ksmserver"), QStringLiteral("/KSMServer"), QStringLiteral("org.kde.KSMServerInterface"), QDBusConnection::sessionBus());
        if (type == PackageKit::Transaction::RestartSystem) {
            interface.asyncCall(QStringLiteral("logout"), 0, 1, 2); // Options: do not ask again | reboot | force
        } else {
            interface.asyncCall(QStringLiteral("logout"), 0, 0, 2); // Options: do not ask again | logout | force
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[filter](AbstractResource *res) {
                return res->state() >= AbstractResource::Installed && (res->name().contains(filter.search) || res->packageName() == filter.search);
            }
```

#### AUTO 


```{c}
auto upgrade = dynamic_cast<SystemUpgrade*>(res)
```

#### RANGE FOR STATEMENT 


```{c}
for (QListView *view : m_listViews) {
        view->setAlternatingRowColors(true);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(Solid::Device device_ac : acAdapters) {
        Solid::AcAdapter* acAdapter = device_ac.as<Solid::AcAdapter>();
        isPlugged |= acAdapter->isPlugged();
        connect(acAdapter, SIGNAL(plugStateChanged(bool,QString)),
                this, SLOT(updatePlugState(bool)), Qt::UniqueConnection);
    }
```

#### AUTO 


```{c}
const auto it = m_categories.constFind(provider.baseUrl());
```

#### AUTO 


```{c}
const auto& rel
```

#### AUTO 


```{c}
auto service = PackageKitBackend::locateService(file);
```

#### AUTO 


```{c}
auto resource = source->m_resources.value(idForRefString(component.bundle(AppStream::Bundle::KindFlatpak).id()));
```

#### LAMBDA EXPRESSION 


```{c}
[this](){
        addSource(QStringLiteral("https://flathub.org/repo/flathub.flatpakrepo"));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&resources, stream](const QVector<AbstractResource*>& res) {
        resources += res;
        Q_EMIT stream->fetchMore();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractResource *r : m_resources) {
        if (r->state() >= filter.state)
            res.push_back(r);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](int progress){ Q_EMIT fetchingUpdatesProgressChanged(progress); }
```

#### AUTO 


```{c}
auto remote = flatpak_installation_get_remote_by_name(m_preferredInstallation, resource->flatpakName().toStdString().c_str(), cancellable, nullptr);
```

#### LAMBDA EXPRESSION 


```{c}
[this, resource] (Transaction::Status status) {
        if (status == Transaction::Status::DoneStatus) {
            updateAppSize(resource);
        }
    }
```

#### AUTO 


```{c}
auto remote = flatpak_installation_get_remote_by_name(m_preferredInstallation, resource->flatpakName().toUtf8().constData(), cancellable, nullptr);
```

#### AUTO 


```{c}
auto trans = PackageKit::Daemon::global()->repairSystem();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &v : input) {
        ret += v;
    }
```

#### AUTO 


```{c}
auto aliased = aliases.constFind(alt);
```

#### AUTO 


```{c}
auto action = new OneTimeAction(
        [this, url]() {
            AbstractResourcesBackend::Filters f;
            f.resourceUrl = url;
            auto stream = new StoredResultsStream({ResourcesModel::global()->search(f)});
            connect(stream, &StoredResultsStream::finishedResources, this, [this, url](const QVector<AbstractResource *> &res) {
                if (res.count() >= 1) {
                    Q_EMIT openApplicationInternal(res.first());
                } else if (url.scheme() == QLatin1String("snap")) {
                    openApplication(QUrl(QStringLiteral("appstream://org.kde.discover.snap")));
                    showPassiveNotification(i18n("Please make sure Snap support is installed"));
                } else {
                    Q_EMIT openErrorPage(
                        i18n("Could not open %1 because it was not found in any "
                             "available software repositories. Please report this "
                             "issue to the packagers of your distribution.",
                             url.toDisplayString()));
                }
            });
        },
        this);
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractResourcesBackend *b : backends) {
        AbstractBackendUpdater *updater = b->backendUpdater();
        if (updater && !m_updaters.contains(updater)) {
            connect(updater, &AbstractBackendUpdater::statusMessageChanged, this, &ResourcesUpdatesModel::message);
            connect(updater, &AbstractBackendUpdater::statusDetailChanged, this, &ResourcesUpdatesModel::message);
            connect(updater, &AbstractBackendUpdater::downloadSpeedChanged, this, &ResourcesUpdatesModel::downloadSpeedChanged);
            connect(updater, &AbstractBackendUpdater::resourceProgressed, this, &ResourcesUpdatesModel::resourceProgressed);
            connect(updater, &AbstractBackendUpdater::passiveMessage, this, &ResourcesUpdatesModel::passiveMessage);
            connect(updater, &AbstractBackendUpdater::needsRebootChanged, this, &ResourcesUpdatesModel::needsRebootChanged);
            connect(updater, &AbstractBackendUpdater::destroyed, this, &ResourcesUpdatesModel::updaterDestroyed);
            m_updaters += updater;

            m_lastIsProgressing |= updater->isProgressing();
        }
    }
```

#### AUTO 


```{c}
auto app = qobject_cast<AbstractResource*>(sender());
```

#### LAMBDA EXPRESSION 


```{c}
[this, localfile]() {
            AbstractResourcesBackend::Filters f;
            f.resourceUrl = localfile;
            auto stream = new StoredResultsStream({ResourcesModel::global()->search(f)});
            connect(stream, &StoredResultsStream::finishedResources, this, [this, localfile](const QVector<AbstractResource *> &res) {
                if (res.count() == 1) {
                    Q_EMIT openApplicationInternal(res.first());
                } else {
                    QMimeDatabase db;
                    auto mime = db.mimeTypeForUrl(localfile);
                    auto fIsFlatpakBackend = [](AbstractResourcesBackend *backend) {
                        return backend->metaObject()->className() == QByteArray("FlatpakBackend");
                    };
                    if (mime.name().startsWith(QLatin1String("application/vnd.flatpak"))
                        && !kContains(ResourcesModel::global()->backends(), fIsFlatpakBackend)) {
                        openApplication(QUrl(QStringLiteral("appstream://org.kde.discover.flatpak")));
                        showPassiveNotification(i18n("Cannot interact with flatpak resources without the flatpak backend %1. Please install it first.",
                                                     localfile.toDisplayString()));
                    } else {
                        openMode(QStringLiteral("Browsing"));
                        showPassiveNotification(i18n("Could not open %1", localfile.toDisplayString()));
                    }
                }
            });
        }
```

#### AUTO 


```{c}
auto r = qobject_cast<PackageKitResource *>(res);
```

#### AUTO 


```{c}
auto it = m_displayedResources.begin();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            bool found = DiscoverBackendsFactory::hasRequestedBackends();
            const auto backends = ResourcesModel::global()->backends();
            for (auto b : backends)
                found |= b->hasApplications();

            if (!found) {
                QString errorText = i18n(
                    "Discover currently cannot be used to install any apps or "
                    "perform system updates because none of its app backends are "
                    "available.");
                QString errorExplanation = xi18nc("@info",
                    "You can install some on the Settings page, under the "
                    "<interface>Missing Backends</interface> section.<nl/><nl/>"
                    "Also please consider reporting this as a packaging issue to "
                    "your distribution.");
                QString buttonIcon = QStringLiteral("tools-report-bug");
                QString buttonText = i18n("Report This Issue");
                QString buttonUrl = KOSRelease().bugReportUrl();

                if (KOSRelease().name().contains(QStringLiteral("Arch Linux"))) {
                    errorExplanation = xi18nc("@info",
                        "You can use <command>pacman</command> to "
                        "install the optional dependencies that are needed to "
                        "enable the application backends.<nl/><nl/>Please note "
                        "that Arch Linux developers recommend using "
                        "<command>pacman</command> for managing software because "
                        "the PackageKit backend is not well-integrated on Arch "
                        "Linux.");
                    buttonIcon = QStringLiteral("help-about");
                    buttonText = i18n("Learn More");
                    buttonUrl = KOSRelease().supportUrl();
                }

                Q_EMIT openErrorPage(errorText, errorExplanation, buttonText, buttonIcon, buttonUrl);
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[] () {
            QProcess::startDetached(QStringLiteral("plasma-discover"));
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QNetworkReply* reply){fwupdInstall(reply);}
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString & /*pkgid*/, const QStringList &files) {
        const auto execIdx = kIndexOf(files, [](const QString &file) {
            return file.endsWith(QLatin1String(".desktop")) && file.contains(QLatin1String("usr/share/applications"));
        });
        if (execIdx >= 0) {
            m_exec = files[execIdx];

            // sometimes aptcc provides paths like usr/share/applications/steam.desktop
            if (!m_exec.startsWith(QLatin1Char('/'))) {
                m_exec.prepend(QLatin1Char('/'));
            }
        } else {
            qWarning() << "could not find an executable desktop file for" << m_path << "among" << files;
        }
    }
```

#### AUTO 


```{c}
const auto resources2 = fetchResources(m_appBackend->findResourceByPackageName(QStringLiteral("Dummy 1")));
```

#### AUTO 


```{c}
auto factory = m_engine->networkAccessManagerFactory();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto source : qAsConst(m_flatpakSources)) {
        checkForUpdates(source->installation(), source->remote());
    }
```

#### AUTO 


```{c}
const auto &token
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString& path : QCoreApplication::instance()->libraryPaths()) {
        QDir dir(path+"/muon-notifier/");
        for(const QString& file : dir.entryList(QDir::Files)) {
            QString fullPath = dir.absoluteFilePath(file);
            QPluginLoader loader(fullPath);
            ret += qobject_cast<BackendNotifierModule*>(loader.instance());
            if (ret.last() == nullptr) {
                qWarning() << "couldn't load" << fullPath << "because" << loader.errorString();
                ret.removeLast();
            }
        }
    }
```

#### AUTO 


```{c}
const auto idx = line.indexOf(": ");
```

#### AUTO 


```{c}
auto action = new OneTimeAction(
        [this]() {
            bool found = DiscoverBackendsFactory::hasRequestedBackends();
            for (auto b : ResourcesModel::global()->backends())
                found |= b->hasApplications();

            if (!found)
                Q_EMIT openErrorPage(i18n("No application back-ends found, please report to your distribution."));
        }
        , this);
```

#### LAMBDA EXPRESSION 


```{c}
[](){
        qGuiApp->quit();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&resources, stream](const QVector<AbstractResource*>& res) {
        resources += res;
        stream->fetchMore();
    }
```

#### AUTO 


```{c}
auto onActivateRequested = [mainWindow](const QStringList &arguments, const QString & /*workingDirectory*/) {
            auto window = qobject_cast<QWindow *>(mainWindow->rootObject());
            if (!window) {
                // Should never happen anyway
                QCoreApplication::instance()->quit();
                return;
            }

            raiseWindow(window);

            if (arguments.isEmpty())
                return;
            QScopedPointer<QCommandLineParser> parser(createParser());
            parser->parse(arguments);
            processArgs(parser.data(), mainWindow);
        };
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        m_notifier.showDiscoverUpdates(m_item->providedToken());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, installation, resource] (Transaction::Status status) {
        if (status == Transaction::Status::DoneStatus) {
            updateAppSize(installation, resource);
        }
    }
```

#### AUTO 


```{c}
auto res = search.scheme() == QLatin1String("fwupd") ? m_resources.value(search.host().replace(QLatin1Char('.'), QLatin1Char(' '))) : nullptr;
```

#### LAMBDA EXPRESSION 


```{c}
[this, category]() {
            Category *cat = CategoryModel::global()->findCategoryByName(category);
            if (cat) {
                emit listCategoryInternal(cat);
            } else {
                openMode(QStringLiteral("Browsing"));
                showPassiveNotification(i18n("Could not find category '%1'", category));
            }
        }
```

#### AUTO 


```{c}
auto mHandBookAction = KStandardAction::helpContents(this, &DiscoverObject::appHelpActivated, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto resource : resources) {
            if (resource->origin() == item->data(AbstractSourcesBackend::IdRole)) {
                return static_cast<FlatpakResource*>(resource);
            }
        }
```

#### AUTO 


```{c}
const auto execIdx = kIndexOf(files, [](const QString& file) { return file.endsWith(QLatin1String(".desktop")) && file.contains(QLatin1String("usr/share/applications")); });
```

#### AUTO 


```{c}
auto action = new OneTimeAction(
        [this, category]() {
            Category *cat = CategoryModel::global()->findCategoryByName(category);
            if (cat) {
                emit listCategoryInternal(cat);
            } else {
                openMode(QStringLiteral("Browsing"));
                showPassiveNotification(i18n("Could not find category '%1'", category));
            }
        },
        this);
```

#### LAMBDA EXPRESSION 


```{c}
[installations, cancellable] {
                QHash<FlatpakInstallation *, QVector<FlatpakInstalledRef *>> ret;

                for (auto installation : installations) {
                    g_autoptr(GError) localError = nullptr;
                    g_autoptr(GPtrArray) refs = flatpak_installation_list_installed_refs_for_update(installation, cancellable, &localError);
                    if (!refs) {
                        qWarning() << "Failed to get list of installed refs for listing updates:" << localError->message;
                        continue;
                    }
                    if (g_cancellable_is_cancelled(cancellable)) {
                        qWarning() << "Job cancelled";
                        return ret;
                    }

                    auto &current = ret[installation];
                    current.reserve(refs->len);
                    for (uint i = 0; i < refs->len; i++) {
                        FlatpakInstalledRef *ref = FLATPAK_INSTALLED_REF(g_ptr_array_index(refs, i));
                        g_object_ref(ref);
                        current.append(ref);
                    }
                }
                return ret;
            }
```

#### AUTO 


```{c}
const auto appBackend = ResourcesModel::global()->currentApplicationBackend();
```

#### LAMBDA EXPRESSION 


```{c}
[](Category* cat) { return QVariant::fromValue<QObject*>(cat); }
```

#### AUTO 


```{c}
auto iter = addons.constBegin();
```

#### LAMBDA EXPRESSION 


```{c}
[this, entryid, stream]() {
        m_responsePending = true;
        m_engine->fetchEntryById(entryid);
        connect(m_engine, &KNSCore::Engine::signalError, stream, &ResultsStream::finish);
        connect(m_engine, &KNSCore::Engine::signalEntryDetailsLoaded, stream, [this, stream, entryid](const KNSCore::EntryInternal &entry) {
            if (entry.uniqueId() == entryid) {
                stream->resourcesFound({resourceForEntry(entry)});
            }
            m_responsePending = false;
            QTimer::singleShot(0, this, &KNSBackend::availableForQueries);
            stream->finish();
        });
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](AbstractResource *resource) {
        m_upgradeable.remove(resource);
        m_toUpgrade.remove(resource);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] { fetchUpdateDetails(); }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &pkgid) {
                return !PackageKit::Transaction::packageName(pkgid).startsWith(QLatin1String("kmod"));
            }
```

#### AUTO 


```{c}
auto resources = _resources;
```

#### AUTO 


```{c}
auto addNativeSourcesManager = [this](const QString &file){
        auto service = PackageKitBackend::locateService(file);
        if (!service.isEmpty())
            m_actions += QVariant::fromValue<QObject*>(createActionForService(service, this));
        };
```

#### LAMBDA EXPRESSION 


```{c}
[this, localfile](const QVector<AbstractResource *> &res) {
                if (res.count() == 1) {
                    Q_EMIT openApplicationInternal(res.first());
                } else {
                    QMimeDatabase db;
                    auto mime = db.mimeTypeForUrl(localfile);
                    auto fIsFlatpakBackend = [](AbstractResourcesBackend *backend) {
                        return backend->metaObject()->className() == QByteArray("FlatpakBackend");
                    };
                    if (mime.name().startsWith(QLatin1String("application/vnd.flatpak"))
                        && !kContains(ResourcesModel::global()->backends(), fIsFlatpakBackend)) {
                        openApplication(QUrl(QStringLiteral("appstream://org.kde.discover.flatpak")));
                        showPassiveNotification(i18n("Cannot interact with flatpak resources without the flatpak backend %1. Please install it first.",
                                                     localfile.toDisplayString()));
                    } else {
                        openMode(QStringLiteral("Browsing"));
                        showPassiveNotification(i18n("Could not open %1", localfile.toDisplayString()));
                    }
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this, stream, appstreamIds]() {
                const auto resources = kAppend<QVector<AbstractResource *>>(appstreamIds, [this](const QString &appstreamId) {
                    return resourcesByAppstreamName(appstreamId);
                });
                if (!resources.isEmpty())
                    Q_EMIT stream->resourcesFound(resources);
                stream->finish();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto r : res) {
        Q_EMIT resourceProgressed(r, percentage, toUpdateState(status));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractBackendUpdater *upd : qAsConst(m_allUpdaters)) {
            progressing |= upd->isProgressing();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](PackageKit::Transaction::Error /*error*/, const QString &details){
                KNotification::event(QStringLiteral("OfflineUpdateRepairFailed"), i18n("Repair Failed"), i18n("Please report to your distribution: %1", details), {}, KNotification::Persistent, QStringLiteral("org.kde.discovernotifier"));
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto updater : qAsConst(m_allUpdaters)) {
            connect(updater, &AbstractBackendUpdater::progressingChanged, this, &UpdateTransaction::slotProgressingChanged);
            connect(updater, &AbstractBackendUpdater::downloadSpeedChanged, this, &UpdateTransaction::slotDownloadSpeedChanged);
            connect(updater, &AbstractBackendUpdater::progressChanged, this, &UpdateTransaction::slotUpdateProgress);
            connect(updater, &AbstractBackendUpdater::proceedRequest, this, &UpdateTransaction::processProceedRequest);
            connect(updater, &AbstractBackendUpdater::distroErrorMessage, this, &UpdateTransaction::distroErrorMessage);
            connect(updater, &AbstractBackendUpdater::cancelableChanged, this, [this](bool) {
                setCancellable(kContains(m_allUpdaters, [](AbstractBackendUpdater *updater) {
                    return updater->isCancelable() && updater->isProgressing();
                }));
            });
            cancelable |= updater->isCancelable();
        }
```

#### AUTO 


```{c}
auto prevRow = m_sources->takeRow(row);
```

#### RANGE FOR STATEMENT 


```{c}
for (BackendNotifierModule *module : qAsConst(m_backends)) {
        connect(module, &BackendNotifierModule::foundUpdates, this, &DiscoverNotifier::updateStatusNotifier);
        connect(module, &BackendNotifierModule::needsRebootChanged, this, [this]() {
            if (!m_needsReboot) {
                m_needsReboot = true;
                showRebootNotification();
                Q_EMIT stateChanged();
                Q_EMIT needsRebootChanged(true);
            }
        });

        connect(module, &BackendNotifierModule::foundUpgradeAction, this, &DiscoverNotifier::foundUpgradeAction);
    }
```

#### AUTO 


```{c}
auto prev = iter;
```

#### AUTO 


```{c}
auto ret = app.exec();
```

#### LAMBDA EXPRESSION 


```{c}
[this](){
        if(!m_initialized) {
            markInvalid(i18n("Backend %1 took too long to initialize", m_displayName));
            m_responsePending = false;
            Q_EMIT searchFinished();
            Q_EMIT availableForQueries();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[res]() {
                qWarning() << "No installable candidates in the KNewStuff entry" << res->entry().name() << "with id" << res->entry().uniqueId()
                           << "on the backend" << res->backend()->name()
                           << "There should always be at least one downloadable item in an OCS entry, and if there isn't, we should consider it broken. OCS "
                              "can technically show them, but if there is nothing to install, it cannot be installed.";
            }
```

#### AUTO 


```{c}
const auto result = job->result().toObject();
```

#### LAMBDA EXPRESSION 


```{c}
[servicePath]() {
        bool b = QProcess::startDetached(QStringLiteral(CMAKE_INSTALL_FULL_LIBEXECDIR_KF5 "/discover/runservice"), {servicePath});
        if (!b)
            qWarning() << "Could not start" << servicePath;
    }
```

#### AUTO 


```{c}
const auto objA = a.toObject(), objB = b.toObject();
```

#### LAMBDA EXPRESSION 


```{c}
[this, url]() {
            AbstractResourcesBackend::Filters f;
            f.resourceUrl = url;
            auto stream = new StoredResultsStream({ResourcesModel::global()->search(f)});
            connect(stream, &StoredResultsStream::finished, this, [this, url, stream]() {
                const auto res = stream->resources();
                qDebug() << "results..." << res;
                if (res.count() == 1) {
                    emit openApplicationInternal(res.first());
                } else {
                    rootObject()->setProperty("defaultStartup", true);
                    showPassiveNotification(i18n("Couldn't open %1", url.toDisplayString()));
                }
            });
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &cat: cats)
            categories << new Category(cat, {}, { {CategoryFilter, cat } }, backendName, {}, {}, true);
```

#### AUTO 


```{c}
auto stream = new PKResultsStream(this, QStringLiteral("PackageKitStream-appstream-url"));
```

#### LAMBDA EXPRESSION 


```{c}
[] (const QString &message) {
        qWarning() << "message" << message;
    }
```

#### AUTO 


```{c}
auto res = packagesForPackageId({packageID});
```

#### AUTO 


```{c}
const auto resources = resourcesByPackageName(PackageKit::Daemon::packageName(it.key()));
```

#### LAMBDA EXPRESSION 


```{c}
[](const AppStream::Component& comp) { return comp.id(); }
```

#### AUTO 


```{c}
auto source = QSharedPointer<FlatpakSource>::create(this, flatpakInstallation, remote);
```

#### LAMBDA EXPRESSION 


```{c}
[&entry](const KNSCore::Provider::CategoryMetadata &cat) {
            return entry.category() == cat.id;
        }
```

#### AUTO 


```{c}
auto e = KNotification::event(QStringLiteral("Update"), message(), extendedMessage(), iconName(), nullptr, KNotification::CloseOnTimeout, QStringLiteral("discoverabstractnotifier"));
```

#### AUTO 


```{c}
const auto &component
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &/*packageID*/, const QStringList &_filenames) {
        //This workarounds bug in zypper's backend (suse) https://github.com/hughsie/PackageKit/issues/351
        QStringList filenames = _filenames;
        if (filenames.count() == 1 && !QFile::exists(filenames.constFirst())) {
            filenames = filenames.constFirst().split(QLatin1Char(';'));
        }
        const auto allServices = QStandardPaths::locateAll(QStandardPaths::ApplicationsLocation, m_appdata.id());
        if (!allServices.isEmpty()) {
            const auto packageServices = kFilter<QStringList>(allServices, [filenames](const QString &file) { return filenames.contains(file); });
            QProcess::startDetached(QStringLiteral(CMAKE_INSTALL_FULL_LIBEXECDIR_KF5 "/discover/runservice"), {packageServices});
            return;
        } else {
            const QStringList exes = m_appdata.provided(AppStream::Provided::KindBinary).items();
            const auto packageExecutables = kFilter<QStringList>(exes, [filenames](const QString &exe) { return filenames.contains(QLatin1Char('/') + exe); });
            if (!packageExecutables.isEmpty()) {
                QProcess::startDetached(exes.constFirst());
                return;
            } else {
                const auto locations = QStandardPaths::standardLocations(QStandardPaths::ApplicationsLocation);
                const auto desktopFiles = kFilter<QStringList>(filenames, [locations](const QString &exe) {
                    for (const auto &location: locations) {
                        if (exe.startsWith(location))
                            return exe.contains(QLatin1String(".desktop"));
                    }
                    return false;
                });
                if (!desktopFiles.isEmpty()) {
                    QProcess::startDetached(QStringLiteral(CMAKE_INSTALL_FULL_LIBEXECDIR_KF5 "/discover/runservice"), { desktopFiles });
                    return;
                }
            }
            Q_EMIT backend()->passiveMessage(i18n("Cannot launch %1", name()));
        }
    }
```

#### AUTO 


```{c}
const auto entries = component.launchable(AppStream::Launchable::KindDesktopId).entries();
```

#### AUTO 


```{c}
auto bk = new KNSBackend(parent, QStringLiteral("plasma"), dirIt.filePath());
```

#### AUTO 


```{c}
const auto license = m_appdata.projectLicense();
```

#### LAMBDA EXPRESSION 


```{c}
[this, error] { return flatpak_installation_new_system(m_cancellable, error); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const AppStream::Component& appstreamComponent : components) {
            FlatpakResource *resource = new FlatpakResource(appstreamComponent, flatpakInstallation, this);
            resource->setIconPath(appstreamIconsPath);
            resource->setOrigin(sourceName);
            if (resource->resourceType() == FlatpakResource::Runtime) {
                resources.prepend(resource);
            } else {
                resources.append(resource);
            }
        }
```

#### AUTO 


```{c}
auto f = [this, filter, stream] {
            const auto resources = kTransform<QVector<AbstractResource*>>(m_packages.extendedBy.value(filter.extends), [](AppPackageKitResource* a){ return a; });
            if (!resources.isEmpty()) {
                Q_EMIT stream->setResources(resources);
            }
        };
```

#### AUTO 


```{c}
const auto transferEncoding = headers.value("transfer-encoding");
```

#### RANGE FOR STATEMENT 


```{c}
for (auto installation : qAsConst(m_installations)) {
        // Load local updates, comparing current and latest commit
        loadLocalUpdates(installation);

        // Load updates from remote repositories
        loadRemoteUpdates(installation);
    }
```

#### AUTO 


```{c}
auto pkgid = availablePackageId();
```

#### AUTO 


```{c}
auto stream = new ResultsStream(QStringLiteral("FlatpakStream"));
```

#### RANGE FOR STATEMENT 


```{c}
for(auto backend: m_backends) {
        sum += backend->fetchingUpdatesProgress();
    }
```

#### AUTO 


```{c}
const auto libraryPaths = QCoreApplication::instance()->libraryPaths();
```

#### AUTO 


```{c}
auto stream = new PKResultsStream(this, QStringLiteral("PackageKitStream-installed"));
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        qDebug() << "took really long to fetch" << this;
    }
```

#### AUTO 


```{c}
const auto res = kFilter<QVector<AppPackageKitResource*>>(backend()->extendedBy(m_appdata.id()), [this](AppPackageKitResource* r){ return r->allPackageNames() != allPackageNames(); });
```

#### LAMBDA EXPRESSION 


```{c}
[this, fw, pool, source]() {
        if (fw->result()) {
            m_flatpakSources += source;
        } else {
            qWarning() << "Could not open the AppStream metadata pool" << pool->lastError();
        }
        metadataRefreshed();
        acquireFetching(false);
        fw->deleteLater();
    }
```

#### AUTO 


```{c}
const auto toinstall = QStringList() << m_packagesModified.value(PackageKit::Transaction::InfoInstalling) << m_packagesModified.value(PackageKit::Transaction::InfoUpdating);
```

#### LAMBDA EXPRESSION 


```{c}
[this, stream] {
            QVector<AbstractResource *> resources;
            for (auto installation : m_installations) {
                g_autoptr(GError) localError = nullptr;
                g_autoptr(GPtrArray) refs = flatpak_installation_list_installed_refs(installation, m_cancellable, &localError);
                if (!refs) {
                    qWarning() << "Failed to get list of installed refs for listing installed:" << localError->message;
                    continue;
                }

                resources.reserve(resources.size() + refs->len);
                for (uint i = 0; i < refs->len; i++) {
                    FlatpakInstalledRef *ref = FLATPAK_INSTALLED_REF(g_ptr_array_index(refs, i));
                    QString name = QString::fromUtf8(flatpak_installed_ref_get_appdata_name(ref));
                    if (name.endsWith(QLatin1String(".Debug")) || name.endsWith(QLatin1String(".Locale")) || name.endsWith(QLatin1String(".BaseApp"))
                        || name.endsWith(QLatin1String(".Docs")))
                        continue;

                    auto resource = getAppForInstalledRef(installation, ref);
                    if (resource->resourceType() == FlatpakResource::Runtime) {
                        resources.prepend(resource);
                    } else {
                        resources.append(resource);
                    }
                }
            }
            if (!resources.isEmpty())
                Q_EMIT stream->resourcesFound(resources);
            stream->finish();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto deployment : m_resources) {
        if (deployment->isBooted()) {
            deployment->fetchRemoteRefs();
        }
    }
```

#### AUTO 


```{c}
auto component = metadata.component();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &pkgid : m_updatesPackageId) {
        if (TransactionpackageName(pkgid) == name)
            return pkgid;
    }
```

#### AUTO 


```{c}
const auto f = [this, appstreamIds, stream]() {
                AbstractResource *pkg = nullptr;

                QStringList allAppStreamIds = appstreamIds;
                {
                    auto it = deprecatedAppstreamIds.constFind(appstreamIds.first());
                    if (it != deprecatedAppstreamIds.constEnd()) {
                        allAppStreamIds << *it;
                    }
                }

                for (auto it = m_packages.packages.constBegin(), itEnd = m_packages.packages.constEnd(); it != itEnd; ++it) {
                    const bool matches = kContains(allAppStreamIds, [&it](const QString &id) {
                        static const QLatin1String desktopPostfix(".desktop");
                        return it.key().compare(id, Qt::CaseInsensitive) == 0 ||
                            // doing (id == id.key()+".desktop") without allocating
                            (id.size() == (desktopPostfix.size() + it.key().size()) && id.endsWith(desktopPostfix)
                             && id.startsWith(it.key(), Qt::CaseInsensitive));
                    });
                    if (matches) {
                        pkg = it.value();
                        break;
                    }
                }
                if (pkg)
                    stream->setResources({pkg});
                stream->finish();
                //         if (!pkg)
                //             qCDebug(LIBDISCOVER_BACKEND_LOG) << "could not find" << host << deprecatedHost;
            };
```

#### RANGE FOR STATEMENT 


```{c}
for (auto res : resources) {
            const auto versions = res->upgradeText();
            const auto idx = versions.indexOf(u'\u009C');
            changes += QStringLiteral("<li>") + res->packageName() + QStringLiteral(": ") + versions.leftRef(idx) + QStringLiteral("</li>\n");

        }
```

#### AUTO 


```{c}
auto updateChecker = new OneTimeAction(
            666,
            [this] {
                if (m_responsePending) {
                    // Slot already taken, will need to wait again
                    return false;
                }

                m_onePage = true;
                setResponsePending(true);
                m_engine->checkForUpdates();
                return true;
            },
            this);
```

#### AUTO 


```{c}
const auto doc = QJsonDocument::fromJson(p->readAllStandardOutput());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &component : data.components) {
            const auto pkgNames = component.packageNames();
            addComponent(component, pkgNames);
        }
```

#### AUTO 


```{c}
auto it=m_resources.constBegin();
```

#### AUTO 


```{c}
auto stream = new StoredResultsStream(streams);
```

#### AUTO 


```{c}
const auto f = [this, appstreamIds, stream] () {
                AbstractResource* pkg = nullptr;

                QStringList allAppStreamIds = appstreamIds;
                {
                    auto it = deprecatedAppstreamIds.constFind(appstreamIds.first());
                    if (it != deprecatedAppstreamIds.constEnd()) {
                        allAppStreamIds << *it;
                    }
                }

                for (auto it = m_packages.packages.constBegin(), itEnd = m_packages.packages.constEnd(); it != itEnd; ++it) {
                    const bool matches = kContains(allAppStreamIds, [&it] (const QString& id) {
                        static const QLatin1String desktopPostfix(".desktop");
                        return it.key().compare(id, Qt::CaseInsensitive) == 0 ||
                              //doing (id == id.key()+".desktop") without allocating
                              (id.size() == (desktopPostfix.size() + it.key().size()) && id.endsWith(desktopPostfix) && id.startsWith(it.key(), Qt::CaseInsensitive));
                    });
                    if (matches) {
                        pkg = it.value();
                        break;
                    }
                }
                if (pkg)
                    stream->setResources({pkg});
                stream->finish();
    //             if (!pkg)
    //                 qCDebug(LIBDISCOVER_BACKEND_LOG) << "could not find" << host << deprecatedHost;
            };
```

#### LAMBDA EXPRESSION 


```{c}
[](const QJsonValue& val) { return val.toString(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (Transaction *t : trans) {
        ret += t->downloadSpeed();
    }
```

#### AUTO 


```{c}
auto a
```

#### AUTO 


```{c}
const auto f = [this, stream, filter] () {
            const QList<AppStream::Component> components = m_appdata->search(filter.search);
            const QStringList ids = kTransform<QStringList>(components, [](const AppStream::Component& comp) { return comp.id(); });
            if (!ids.isEmpty()) {
                const auto resources = kFilter<QVector<AbstractResource*>>(resourcesByPackageNames<QVector<AbstractResource*>>(ids), [](AbstractResource* res){ return !qobject_cast<PackageKitResource*>(res)->extendsItself(); });
                Q_EMIT stream->resourcesFound(resources);
            }

            PackageKit::Transaction * tArch = PackageKit::Daemon::resolve(filter.search, PackageKit::Transaction::FilterArch);
            connect(tArch, &PackageKit::Transaction::package, this, &PackageKitBackend::addPackageArch);
            connect(tArch, &PackageKit::Transaction::package, stream, [stream](PackageKit::Transaction::Info /*info*/, const QString &packageId){
                stream->setProperty("packageId", packageId);
            });
            connect(tArch, &PackageKit::Transaction::finished, stream, [stream, ids, this](PackageKit::Transaction::Exit status) {
                getPackagesFinished();
                if (status == PackageKit::Transaction::Exit::ExitSuccess) {
                    const auto packageId = stream->property("packageId");
                    if (!packageId.isNull()) {
                        const auto res = resourcesByPackageNames<QVector<AbstractResource*>>({PackageKit::Daemon::packageName(packageId.toString())});
                        Q_EMIT stream->resourcesFound(kFilter<QVector<AbstractResource*>>(res, [ids](AbstractResource* res){ return !ids.contains(res->appstreamId()); }));
                    }
                }
                stream->finish();
            }, Qt::QueuedConnection);
        };
```

#### AUTO 


```{c}
auto b
```

#### AUTO 


```{c}
auto t = new KNSTransaction(this, res, Transaction::RemoveRole);
```

#### LAMBDA EXPRESSION 


```{c}
[this, localfile]() {
            auto res = ResourcesModel::global()->resourceForFile(localfile);
            qCDebug(DISCOVER_LOG) << "all initialized..." << res;
            if (res) {
                emit openApplicationInternal(res);
            } else {
                QMimeDatabase db;
                auto mime = db.mimeTypeForUrl(localfile);
                auto fIsFlatpakBackend = [](AbstractResourcesBackend* backend) { return backend->metaObject()->className() == QByteArray("FlatpakBackend"); };
                if (mime.name().startsWith(QLatin1String("application/vnd.flatpak")) && !kContains(ResourcesModel::global()->backends(), fIsFlatpakBackend)) {
                    openApplication(QUrl(QLatin1String("appstream://org.kde.discover.flatpak")));
                    showPassiveNotification(i18n("Cannot interact with flatpak resources without the flatpak backend %1. Please install it first.", localfile.toDisplayString()));
                } else {
                    setRootObjectProperty("defaultStartup", true);
                    showPassiveNotification(i18n("Couldn't open %1", localfile.toDisplayString()));
                }
            }
        }
```

#### AUTO 


```{c}
auto task = change->task(i);
```

#### AUTO 


```{c}
auto match = rx.match(line);
```

#### LAMBDA EXPRESSION 


```{c}
[mainWindow](const QStringList &arguments, const QString & /*workingDirectory*/) {
                auto window = qobject_cast<QWindow *>(mainWindow->rootObject());
                if (!window) {
                    // Should never happen anyway
                    QCoreApplication::instance()->quit();
                    return;
                }

                raiseWindow(window);

                if (arguments.isEmpty())
                    return;
                QScopedPointer<QCommandLineParser> parser(createParser());
                parser->parse(arguments);
                processArgs(parser.data(), mainWindow);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this, resource] {
            if (!m_backend->isFetching())
                Q_EMIT m_backend->resourcesChanged(resource, {"size", "sizeDescription"});
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &source : m_flatpakSources) {
        auto comps = source->m_pool->componentsById(name) + source->m_pool->componentsById(nameWithDesktop);
        resources << kTransform<QVector<AbstractResource *>>(comps, [this, source](const auto &comp) {
            return resourceForComponent(comp, source);
        });
    }
```

#### AUTO 


```{c}
const auto id = isInstalled() ? installedPackageId() : availablePackageId();
```

#### AUTO 


```{c}
auto o
```

#### AUTO 


```{c}
auto installedAndNameFilter = [filter] (AbstractResource *res) {
                return res->state() >= AbstractResource::Installed && (res->name().contains(filter.search) || res->packageName() == filter.search);
            };
```

#### AUTO 


```{c}
auto c = *it;
```

#### AUTO 


```{c}
auto r
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &message) {
        qWarning() << "message" << message;
    }
```

#### AUTO 


```{c}
auto e
```

#### AUTO 


```{c}
auto app = qobject_cast<LocalFilePKResource *>(m_apps.at(0));
```

#### AUTO 


```{c}
const auto& id = it.key();
```

#### RANGE FOR STATEMENT 


```{c}
for (QApt::Package *package : packages) {
        bool locked = setLocked(package, lock);
        if (!locked) {
            // TODO: report error
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, entryid, stream, providerid]() {
        m_responsePending = true;
        m_engine->fetchEntryById(entryid);
        m_onePage = false;
        connect(m_engine, &KNSCore::Engine::signalError, stream, &ResultsStream::finish);
        connect(m_engine, &KNSCore::Engine::signalEntryDetailsLoaded, stream, [this, stream, entryid, providerid](const KNSCore::EntryInternal &entry) {
            if (entry.uniqueId() == entryid && providerid == QUrl(entry.providerId()).host()) {
                stream->resourcesFound({resourceForEntry(entry)});
            }
            m_responsePending = false;
            QTimer::singleShot(0, this, &KNSBackend::availableForQueries);
            stream->finish();
        });
    }
```

#### AUTO 


```{c}
auto i
```

#### RANGE FOR STATEMENT 


```{c}
for(const QPair<FilterType, QString> &filter : m_notFilters) {
        if(shouldFilter(res, filter))
            return false;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, fileUrl, replyPut]() {
                QScopedPointer<QNetworkReply, QScopedPointerDeleteLater> replyPtr(replyPut);
                if (replyPut->error() != QNetworkReply::NoError) {
                    qWarning() << "couldn't save" << m_url << replyPut->errorString();
                    m_stream->finish();
                    return;
                }
                if (!fileUrl.isLocalFile()) {
                    m_stream->finish();
                    return;
                }

                processFile(fileUrl);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const AppStream::Icon &icon : icons) {
            if (icon.kind() == AppStream::Icon::KindRemote) {
                const QString fileName = iconCachePath(icon);
                if (!QFileInfo::exists(fileName)) {
                    const QDir cacheDir(QStandardPaths::writableLocation(QStandardPaths::CacheLocation));
                    // Create $HOME/.cache/discover/icons folder
                    cacheDir.mkdir(QStringLiteral("icons"));
                    QNetworkAccessManager *manager = new QNetworkAccessManager(this);
                    connect(manager, &QNetworkAccessManager::finished, this, [this, icon, fileName, manager](QNetworkReply *reply) {
                        if (reply->error() == QNetworkReply::NoError) {
                            QByteArray iconData = reply->readAll();
                            QFile file(fileName);
                            if (file.open(QIODevice::WriteOnly)) {
                                file.write(iconData);
                            }
                            file.close();
                            Q_EMIT iconChanged();
                        }
                        manager->deleteLater();
                    });
                    manager->get(QNetworkRequest(icon.url()));
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto &x: set)
        ret.insert(x);
```

#### AUTO 


```{c}
auto actualCategory = new Category(m_displayName, QStringLiteral("applications-other"), filters, backendName, topCategories, QUrl(), false);
```

#### AUTO 


```{c}
auto &state = m_propertyStates[kind];
```

#### LAMBDA EXPRESSION 


```{c}
[](AbstractResource* res){ return !qobject_cast<PackageKitResource*>(res)->extendsItself(); }
```

#### RANGE FOR STATEMENT 


```{c}
for(BackendNotifierModule* module : m_backends) {
        connect(module, &BackendNotifierModule::foundUpdates, this, &DiscoverNotifier::updateStatusNotifier);
    }
```

#### AUTO 


```{c}
auto state = it.key();
```

#### AUTO 


```{c}
auto request = m_client.connect();
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QJsonObject& obj) { setDependenciesCount(obj.size()); }
```

#### AUTO 


```{c}
auto window = qobject_cast<QWindow *>(mainWindow->rootObject());
```

#### LAMBDA EXPRESSION 


```{c}
[id](AbstractResource* res) {return res->extends().contains(id); }
```

#### AUTO 


```{c}
auto it = resources.constBegin()+1, itEnd = resources.constEnd();
```

#### AUTO 


```{c}
auto action = new OneTimeAction(
        [this, localfile]() {
            AbstractResourcesBackend::Filters f;
            f.resourceUrl = localfile;
            auto stream = new StoredResultsStream({ResourcesModel::global()->search(f)});
            connect(stream, &StoredResultsStream::finishedResources, this, [this, localfile](const QVector<AbstractResource *> &res) {
                if (res.count() == 1) {
                    emit openApplicationInternal(res.first());
                } else {
                    QMimeDatabase db;
                    auto mime = db.mimeTypeForUrl(localfile);
                    auto fIsFlatpakBackend = [](AbstractResourcesBackend *backend) {
                        return backend->metaObject()->className() == QByteArray("FlatpakBackend");
                    };
                    if (mime.name().startsWith(QLatin1String("application/vnd.flatpak"))
                        && !kContains(ResourcesModel::global()->backends(), fIsFlatpakBackend)) {
                        openApplication(QUrl(QStringLiteral("appstream://org.kde.discover.flatpak")));
                        showPassiveNotification(i18n("Cannot interact with flatpak resources without the flatpak backend %1. Please install it first.",
                                                     localfile.toDisplayString()));
                    } else {
                        openMode(QStringLiteral("Browsing"));
                        showPassiveNotification(i18n("Could not open %1", localfile.toDisplayString()));
                    }
                }
            });
        },
        this);
```

#### RANGE FOR STATEMENT 


```{c}
for(AbstractResource* res: m_toUpgrade) {
        ret += res->size();
    }
```

#### AUTO 


```{c}
const auto links = res->linkIds();
```

#### LAMBDA EXPRESSION 


```{c}
[search](AbstractResourcesBackend* backend){ return backend->findResourceByPackageName(search); }
```

#### AUTO 


```{c}
const auto f = [this, appstreamIds, stream]() {
                AbstractResource *pkg = nullptr;

                QStringList allAppStreamIds = appstreamIds;
                {
                    auto it = deprecatedAppstreamIds.constFind(appstreamIds.first());
                    if (it != deprecatedAppstreamIds.constEnd()) {
                        allAppStreamIds << *it;
                    }
                }

                for (auto it = m_packages.packages.constBegin(), itEnd = m_packages.packages.constEnd(); it != itEnd; ++it) {
                    const bool matches = kContains(allAppStreamIds, [&it](const QString &id) {
                        static const QLatin1String desktopPostfix(".desktop");
                        return it.key().compare(id, Qt::CaseInsensitive) == 0 ||
                            // doing (id == id.key()+".desktop") without allocating
                            (id.size() == (desktopPostfix.size() + it.key().size()) && id.endsWith(desktopPostfix)
                             && id.startsWith(it.key(), Qt::CaseInsensitive));
                    });
                    if (matches) {
                        pkg = it.value();
                        break;
                    }
                }
                if (pkg)
                    stream->setResources({pkg});
                stream->finish();
                //             if (!pkg)
                //                 qCDebug(LIBDISCOVER_BACKEND_LOG) << "could not find" << host << deprecatedHost;
            };
```

#### RANGE FOR STATEMENT 


```{c}
for(AbstractResource* res : m_packages.values()) {
        if (res->state() == AbstractResource::Upgradeable) {
            ret+=res;
        }
    }
```

#### AUTO 


```{c}
const auto backends = applicationBackends();
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        if (PackageKit::Daemon::global()->offline()->updateTriggered())
            nowNeedsReboot();
    }
```

#### AUTO 


```{c}
auto installation = m_flatpakInstallationSystem;
```

#### AUTO 


```{c}
const auto ret = kFilter<QVector<AbstractResource *>>(m_resourcesByName, filterFunction);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QDeclarativeError &error : m_view->errors()) {
            errors.append(error.toString() + QLatin1String("\n\n"));
        }
```

#### AUTO 


```{c}
auto start = [this, stream, searchText]() {
        m_engine->setSearchTerm(searchText);
        m_engine->requestData(0, 100);
        m_responsePending = true;
        m_page = 0;
        connect(this, &KNSBackend::receivedResources, stream, &ResultsStream::resourcesFound);
        connect(this, &KNSBackend::searchFinished, stream, &ResultsStream::deleteLater);
        connect(this, &KNSBackend::startingSearch, stream, &ResultsStream::deleteLater);
    };
```

#### LAMBDA EXPRESSION 


```{c}
[locations](const QString &exe) {
                    for (const auto &location: locations) {
                        if (exe.startsWith(location))
                            return exe.contains(QLatin1String(".desktop"));
                    }
                    return false;
                }
```

#### AUTO 


```{c}
auto release = m_appdata.releases().constFirst();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &pkgid : qAsConst(m_updatesPackageId)) {
        const QString pkgname = PackageKit::Daemon::packageName(pkgid);
        const auto pkgs = resourcesByPackageName(pkgname);
        if (pkgs.isEmpty()) {
            qWarning() << "couldn't find resource for" << pkgid;
        }
        ret.unite(pkgs);
    }
```

#### AUTO 


```{c}
const auto packageName = res->packageName();
```

#### AUTO 


```{c}
auto &x
```

#### LAMBDA EXPRESSION 


```{c}
[this, request](){
//             qDebug() << "connected" << request;
            m_socket->write(request);
        }
```

#### AUTO 


```{c}
auto f = [this, stream, url] () {
                const auto resources = resourcesByAppstreamName(url.host());
                if (!resources.isEmpty())
                    Q_EMIT stream->resourcesFound(resources);
                stream->finish();
            };
```

#### LAMBDA EXPRESSION 


```{c}
[stream, this, job]() {
        if (job->error()) {
            qDebug() << "error:" << job->error() << job->errorString();
            stream->finish();
            return;
        }

        QVector<AbstractResource*> ret;
        QSet<SnapResource*> resources;
        for (int i=0, c=job->snapCount(); i<c; ++i) {
            QSharedPointer<QSnapdSnap> snap(job->snap(i));
            const auto snapname = snap->name();
            SnapResource* res = m_resources.value(snapname);
            if (!res) {
                res = new SnapResource(snap, AbstractResource::None, this);
                Q_ASSERT(res->packageName() == snapname);
                resources += res;
            } else {
                res->setSnap(snap);
            }
            ret += res;
        }

        foreach(SnapResource* res, resources)
            m_resources[res->packageName()] = res;

        if (!ret.isEmpty())
            stream->resourcesFound(ret);
        stream->finish();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[resources, stream] () {
                    if (!resources.isEmpty())
                        Q_EMIT stream->resourcesFound(resources);
                    stream->finish();
                }
```

#### AUTO 


```{c}
auto stream = new ResultsStream(QStringLiteral("PackageKitStream-appstream-url"));
```

#### LAMBDA EXPRESSION 


```{c}
[=](AbstractResource* res) {
        if (res)
            backend->installApplication(res);
        else
            Q_EMIT backend->passiveMessage(i18n("Could not add the source %1", flatpakrepoUrl.toDisplayString()));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[menu, this]() {
        auto refreshAction = menu->addAction(QIcon::fromTheme(QStringLiteral("view-refresh")), i18n("Restart..."));
        connect(refreshAction, &QAction::triggered, &m_notifier, &DiscoverNotifier::recheckSystemUpdateNeeded);
    }
```

#### AUTO 


```{c}
const auto positionalArguments = parser->positionalArguments();
```

#### LAMBDA EXPRESSION 


```{c}
[this, resource, futureWatcher]() {
            g_autoptr(FlatpakRemoteRef) remoteRef = futureWatcher->result();
            if (remoteRef) {
                onFetchSizeFinished(resource, flatpak_remote_ref_get_download_size(remoteRef), flatpak_remote_ref_get_installed_size(remoteRef));
            } else {
                resource->setPropertyState(FlatpakResource::DownloadSize, FlatpakResource::UnknownOrFailed);
                resource->setPropertyState(FlatpakResource::InstalledSize, FlatpakResource::UnknownOrFailed);
            }
            futureWatcher->deleteLater();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, fw]() {
        const auto data = fw->result();
        fw->deleteLater();

        if (!data.correct && m_packages.packages.isEmpty()) {
            QTimer::singleShot(0, this, [this]() {
                Q_EMIT passiveMessage(i18n("Please make sure that Appstream is properly set up on your system"));
            });
        }
        for (const auto &component : data.components) {
            addComponent(component);
        }

        if (data.components.isEmpty()) {
            qCDebug(LIBDISCOVER_BACKEND_LOG) << "empty appstream db";
            if (PackageKit::Daemon::backendName() == QLatin1String("aptcc") || PackageKit::Daemon::backendName().isEmpty()) {
                checkForUpdates();
            }
        }
        if (!m_appstreamInitialized) {
            m_appstreamInitialized = true;
            Q_EMIT loadedAppStream();
        }
        acquireFetching(false);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[filenames](const QString &exe) { return filenames.contains(QLatin1Char('/') + exe); }
```

#### AUTO 


```{c}
auto item
```

#### AUTO 


```{c}
const auto resolved = kFilter<QVector<AbstractResource*>>(toResolve, installedAndNameFilter);
```

#### AUTO 


```{c}
auto t
```

#### AUTO 


```{c}
auto action = new OneTimeAction(
        [this, url]() {
            AbstractResourcesBackend::Filters f;
            f.resourceUrl = url;
            auto stream = new StoredResultsStream({ResourcesModel::global()->search(f)});
            connect(stream, &StoredResultsStream::finishedResources, this, [this, url](const QVector<AbstractResource*> &res) {
                if (res.count() >= 1) {
                    emit openApplicationInternal(res.first());
                } else {
                    setRootObjectProperty("defaultStartup", true);
                    Q_EMIT openErrorPage(i18n("Couldn't open %1", url.toDisplayString()));
                }
            });
        }
        , this);
```

#### AUTO 


```{c}
const auto packages = kTransform<QSet<QString>>(pkgids,
                                                    [] (const QString& pkgid) { return PackageKit::Daemon::packageName(pkgid); }
                                                   );
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        m_initialized = true;
    }
```

#### AUTO 


```{c}
auto f = [this](AbstractResource* l, AbstractResource* r) { return flatpakResourceLessThan(l, r); };
```

#### RANGE FOR STATEMENT 


```{c}
for (auto r : extendsResources) {
        PackageKitResource *pkres = qobject_cast<PackageKitResource *>(r);
        if (pkres->allPackageNames() != ourPackageNames)
            return false;
    }
```

#### AUTO 


```{c}
auto action = new OneTimeAction(
        [this, localfile]() {
            AbstractResourcesBackend::Filters f;
            f.resourceUrl = localfile;
            auto stream = new StoredResultsStream({ResourcesModel::global()->search(f)});
            connect(stream, &StoredResultsStream::finishedResources, this, [this, localfile](const QVector<AbstractResource*> &res) {
                if (res.count() == 1) {
                    emit openApplicationInternal(res.first());
                } else {
                    QMimeDatabase db;
                    auto mime = db.mimeTypeForUrl(localfile);
                    auto fIsFlatpakBackend = [](AbstractResourcesBackend* backend) { return backend->metaObject()->className() == QByteArray("FlatpakBackend"); };
                    if (mime.name().startsWith(QLatin1String("application/vnd.flatpak")) && !kContains(ResourcesModel::global()->backends(), fIsFlatpakBackend)) {
                        openApplication(QUrl(QStringLiteral("appstream://org.kde.discover.flatpak")));
                        showPassiveNotification(i18n("Cannot interact with flatpak resources without the flatpak backend %1. Please install it first.", localfile.toDisplayString()));
                    } else {
                        openMode(QStringLiteral("Browsing"));
                        showPassiveNotification(i18n("Couldn't open %1", localfile.toDisplayString()));
                    }
                }
            });
        }
        , this);
```

#### LAMBDA EXPRESSION 


```{c}
[]() {
                QProcess::startDetached(QStringLiteral("plasma-discover"), QStringList());
            }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString& file : dir.entryList(QDir::Files)) {
            QString fullPath = dir.absoluteFilePath(file);
            QPluginLoader loader(fullPath);
            loader.load();
            ret += qobject_cast<BackendNotifierModule*>(loader.instance());
            if (ret.last() == nullptr) {
                qWarning() << "couldn't load" << fullPath << "because" << loader.errorString();
                ret.removeLast();
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, resource](AbstractResource* res){ return lessThan(resource, res); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](uint timeSince) {
        if (timeSince > 3600)
            checkForUpdates();
    }
```

#### AUTO 


```{c}
const auto &itCat
```

#### AUTO 


```{c}
auto installedAndNameFilter = [filter](AbstractResource *res) {
                return res->state() >= AbstractResource::Installed && (res->name().contains(filter.search) || res->packageName() == filter.search);
            };
```

#### AUTO 


```{c}
auto curr = currentlyBootedDeployment();
```

#### AUTO 


```{c}
const auto key = fetchKey(*it);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto installation : m_installations) {
                g_autoptr(GError) localError = nullptr;
                g_autoptr(GPtrArray) refs = flatpak_installation_list_installed_refs(installation, m_cancellable, &localError);
                if (!refs) {
                    qWarning() << "Failed to get list of installed refs for listing installed:" << localError->message;
                    continue;
                }

                resources.reserve(resources.size() + refs->len);
                for (uint i = 0; i < refs->len; i++) {
                    FlatpakInstalledRef *ref = FLATPAK_INSTALLED_REF(g_ptr_array_index(refs, i));
                    QString name = QString::fromUtf8(flatpak_installed_ref_get_appdata_name(ref));
                    if (name.endsWith(QLatin1String(".Debug")) || name.endsWith(QLatin1String(".Locale")) || name.endsWith(QLatin1String(".BaseApp"))
                        || name.endsWith(QLatin1String(".Docs")))
                        continue;

                    auto resource = getAppForInstalledRef(installation, ref);
                    if (!filter.search.isEmpty() && !resource->name().contains(filter.search, Qt::CaseInsensitive))
                        continue;

                    if (resource->resourceType() == FlatpakResource::Runtime) {
                        resources.prepend(resource);
                    } else {
                        resources.append(resource);
                    }
                }
            }
```

#### AUTO 


```{c}
const auto f = [this, stream, filter] () {
            const QList<AppStream::Component> components = m_appdata->search(filter.search);
            const QStringList ids = kTransform<QStringList>(components, [](const AppStream::Component& comp) { return comp.id(); });
            if (!ids.isEmpty()) {
                const auto resources = kFilter<QVector<AbstractResource*>>(resourcesByPackageNames<QVector<AbstractResource*>>(ids), [](AbstractResource* res){ return !qobject_cast<PackageKitResource*>(res)->extendsItself(); });
                stream->setResources(resources);
            }
            stream->finish();
        };
```

#### LAMBDA EXPRESSION 


```{c}
[this](){
        m_settingUp = false;
        Q_EMIT updatesCountChanged(updatesCount());
        Q_EMIT progressingChanged(false);
    }
```

#### AUTO 


```{c}
auto start = [this, searchText]() {
        // No need to explicitly launch a search, setting the search term already does that for us
        m_engine->setSearchTerm(searchText);
        m_responsePending = true;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[] () {
            QProcess::startDetached(QStringLiteral("plasma-discover"), QStringList());
        }
```

#### AUTO 


```{c}
auto action = new OneTimeAction(
        [this, url]() {
            AbstractResourcesBackend::Filters f;
            f.resourceUrl = url;
            auto stream = new StoredResultsStream({ResourcesModel::global()->search(f)});
            connect(stream, &StoredResultsStream::finishedResources, this, [this, url](const QVector<AbstractResource*> &res) {
                if (res.count() >= 1) {
                    emit openApplicationInternal(res.first());
                } else if (url.scheme() == QLatin1String("snap")) {
                    openApplication(QUrl(QStringLiteral("appstream://org.kde.discover.snap")));
                    showPassiveNotification(i18n("Please make sure Snap support is installed"));
                } else {
                    Q_EMIT openErrorPage(i18n("Could not open %1", url.toDisplayString()));
                }
            });
        }
        , this);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QVector<AbstractResource *> &resources) {
        for (auto res : qAsConst(m_resources)) {
            if (resources.contains(res))
                res->setState(AbstractResource::Installed);
            else
                res->setState(AbstractResource::None);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, process](int exitCode, QProcess::ExitStatus exitStatus) {
        qDebug() << "Finished running plasma-discover-update" << exitCode << exitStatus;
        DiscoverNotifier *notifier = static_cast<DiscoverNotifier *>(parent());
        process->deleteLater();
        notifier->settings()->setLastUnattendedTrigger(QDateTime::currentDateTimeUtc());
        notifier->settings()->save();
        notifier->setBusy(false);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &itCat : cats) {
        if (contains(qobject_cast<Category*>(itCat.value<QObject*>()))) {
            ret = true;
            break;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[stream](PackageKit::Transaction::Info /*info*/, const QString &packageId){
                stream->setProperty("packageId", packageId);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[stream, ids, this](PackageKit::Transaction::Exit status) {
                getPackagesFinished();
                if (status == PackageKit::Transaction::Exit::ExitSuccess) {
                    const auto packageId = stream->property("packageId");
                    if (!packageId.isNull()) {
                        const auto res = resourcesByPackageNames<QVector<AbstractResource*>>({PackageKit::Daemon::packageName(packageId.toString())});
                        Q_EMIT stream->resourcesFound(kFilter<QVector<AbstractResource*>>(res, [ids](AbstractResource* res){ return !ids.contains(res->appstreamId()); }));
                    }
                }
                stream->finish();
            }
```

#### LAMBDA EXPRESSION 


```{c}
[] (QQuickWindow::SceneGraphError /*error*/, const QString &message) {
        KCrash::setErrorMessage(message);
        qFatal("%s", qPrintable(message));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            if (!m_needsReboot) {
                m_needsReboot = true;
                showRebootNotification();
                Q_EMIT updatesChanged();
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Transaction *trans : transList) {
        addTransaction(trans);
    }
```

#### AUTO 


```{c}
auto fw = new QFutureWatcher<QHash<FlatpakInstallation *, QVector<FlatpakInstalledRef *>>>(this);
```

#### RANGE FOR STATEMENT 


```{c}
for(auto resource: resources) {
        const auto finder = [this](AbstractResource* resource, AbstractResource* res){ return lessThan(resource, res); };
        const auto it = std::upper_bound(m_displayedResources.constBegin(), m_displayedResources.constEnd(), resource, finder);
        const auto newIdx = it == m_displayedResources.constEnd() ? m_displayedResources.count() : (it - m_displayedResources.constBegin());

        if (it != m_displayedResources.constEnd() && *it == resource)
            continue;

        beginInsertRows({}, newIdx, newIdx);
        m_displayedResources.insert(newIdx, resource);
        endInsertRows();
    }
```

#### AUTO 


```{c}
auto mHandBookAction = KStandardAction::helpContents(this, &DiscoverMainWindow::appHelpActivated, this);
```

#### AUTO 


```{c}
const auto actions = ResourcesModel::global()->messageActions();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QJsonValue &val : m_discharges)
            request += ",discharge=\"" + val.toString().toLatin1() + '\"';
```

#### LAMBDA EXPRESSION 


```{c}
[this, p] (int code) {
                p->deleteLater();
                if (code != 0) {
                    qWarning() << "login failed..." << p->readAll();
                    Q_EMIT passiveMessage(m_request->errorString());
                    return;
                }
                const auto doc = QJsonDocument::fromJson(p->readAllStandardOutput());
                const auto result = doc.object();

                const auto macaroon = result[QStringLiteral("macaroon")].toString();
                const auto discharges = kTransform<QStringList>(result[QStringLiteral("discharges")].toArray(), [](const QJsonValue& val) { return val.toString(); });
                static_cast<SnapBackend*>(m_app->backend())->client()->setAuthData(new QSnapdAuthData(macaroon, discharges));
                m_request->runAsync();
            }
```

#### AUTO 


```{c}
auto & state = m_propertyStates[kind];
```

#### RANGE FOR STATEMENT 


```{c}
for(auto upd: m_updaters) {
        if (upd->needsReboot())
            return true;
    }
```

#### AUTO 


```{c}
auto meta = metadataFromBytes(metadata, m_cancellable);
```

#### AUTO 


```{c}
auto i = changes.constBegin();
```

#### AUTO 


```{c}
const auto componentExtends = component.extends();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            // First we ensure we've got data loaded on what we've got installed already
            Q_EMIT startingSearch();
            m_onePage = true;
            m_responsePending = true;
            m_engine->checkForInstalled();
            // And then we check for updates - we could do only one, if all we cared about was updates,
            // but to have both a useful initial list, /and/ information on updates, we want to get both.
            // The reason we are not doing a checkUpdates() overload for this is that the caching for this
            // information is done by KNSEngine, and we want to actually load it every time we initialize.
            auto updateChecker = new OneTimeAction(
                [this] {
                    //No need to check for updates if there's no resources
                    if (m_resourcesByName.isEmpty()) {
                        return;
                    }

                    Q_EMIT startingSearch();
                    m_onePage = true;
                    m_responsePending = true;
                    m_engine->checkForUpdates();
                },
                this);
            connect(this, &KNSBackend::availableForQueries, updateChecker, &OneTimeAction::trigger, Qt::QueuedConnection);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[stream, tArch, ids, this]() {
            getPackagesFinished();
            const auto packageId = tArch->property("packageId");
            if (!packageId.isNull()) {
                const auto res = resourcesByPackageNames<QVector<AbstractResource*>>({PackageKit::Daemon::packageName(packageId.toString())});
                stream->resourcesFound(kFilter<QVector<AbstractResource*>>(res, [ids](AbstractResource* res){ return !ids.contains(res->appstreamId()); }));
            }
            stream->finish();
        }
```

#### AUTO 


```{c}
auto repo = flatpak_installation_get_remote_by_name(preferredInstallation(), resource->flatpakName().toStdString().c_str(), m_cancellable, nullptr);
```

#### AUTO 


```{c}
const auto componentsProvided = meta->components();
```

#### LAMBDA EXPRESSION 


```{c}
[this, ret](){
        for (auto res: m_resources) {
            if (ret->resources().contains(res))
                res->setState(AbstractResource::Installed);
            else
                res->setState(AbstractResource::None);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const KNSCore::EntryInternal &entry) {
        return entry.isValid();
    }
```

#### AUTO 


```{c}
auto addonsCategory = new Category(topLevelName, QStringLiteral("plasma"), filters, backendName, {actualCategory}, QUrl(), true);
```

#### LAMBDA EXPRESSION 


```{c}
[this](PackageKit::Transaction::Error err, const QString &error) {
        qWarning() << "error fetching updates:" << err << error;
        Q_EMIT changelogFetched(QString());
    }
```

#### AUTO 


```{c}
auto actualCategory = new Category(m_displayName, QStringLiteral("plasma"), filters, backendName, {}, QUrl(), true);
```

#### RANGE FOR STATEMENT 


```{c}
for (FilterModel *filterModel : m_filterModels) {
        filterModel->clear();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](int exitCode, QProcess::ExitStatus exitStatus) {
        qDebug() << "process exited with code " << exitCode << exitStatus;
        if (exitCode == 0) {
            readRefsOutput(process);
        }
        process->deleteLater();
    }
```

#### AUTO 


```{c}
auto service = PackageKitBackend::locateService(QStringLiteral("software-properties-kde.desktop"));
```

#### AUTO 


```{c}
const auto filtered = kFilter<KNSCore::EntryInternal::List>(entries, [this](const KNSCore::EntryInternal& entry){ return entry.isValid(); });
```

#### LAMBDA EXPRESSION 


```{c}
[stream, this, state, job]() {
        if (job->error()) {
            qDebug() << "error:" << job->error() << job->errorString();
            stream->finish();
            return;
        }

        QVector<AbstractResource*> ret;
        QSet<SnapResource*> resources;
        for (int i=0, c=job->snapCount(); i<c; ++i) {
            QSharedPointer<QSnapdSnap> snap(job->snap(i));
            const auto snapname = snap->name();
            SnapResource* res = m_resources.value(snapname);
            if (!res) {
                res = new SnapResource(snap, state, this);
                Q_ASSERT(res->packageName() == snapname);
                resources += res;
            } else if (res->state() < state) {
                res->setState(state);
                res->setSnap(snap);
            }
            ret += res;
        }

        foreach(SnapResource* res, resources)
            m_resources[res->packageName()] = res;

        if (!ret.isEmpty())
            stream->resourcesFound(ret);
        stream->finish();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[] (QQuickWindow::SceneGraphError /*error*/, const QString &message) {
#if KCrash_VERSION >= QT_VERSION_CHECK(5, 69, 0)
        KCrash::setErrorMessage(message);
#endif
        qFatal("%s", qPrintable(message));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &alt : alts) {
                    at = ids.find(alt);
                    if (at != ids.end())
                        break;
                }
```

#### LAMBDA EXPRESSION 


```{c}
[stream, ids, this](PackageKit::Transaction::Exit status) {
                getPackagesFinished();
                if (status == PackageKit::Transaction::Exit::ExitSuccess) {
                    const auto packageId = stream->property("packageId");
                    if (!packageId.isNull()) {
                        const auto res = resourcesByPackageNames<QVector<AbstractResource*>>({PackageKit::Daemon::packageName(packageId.toString())});
                        stream->setResources(kFilter<QVector<AbstractResource*>>(res, [ids](AbstractResource* res){ return !ids.contains(res->appstreamId()); }));
                    }
                }
                stream->finish();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for(QAction *action: theActions) {
        if (action->toolTip() == id) {
            action->setEnabled(false);
            action->setVisible(false);
        }
    }
```

#### AUTO 


```{c}
auto stream = new ResultsStream(QStringLiteral("FlatpakSource-") + flatpakrepoUrl.toDisplayString());
```

#### AUTO 


```{c}
auto proxyWatch = new QFileSystemWatcher(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this, trans](PackageKit::Transaction::Exit /*status*/) {
        auto deps = trans->property("dependencies").toUInt();
        if (deps != m_dependenciesCount) {
            m_dependenciesCount = deps;
            Q_EMIT sizeChanged();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, msg]() {
        QMetaObject::invokeMethod(rootObject(),
                                  "showPassiveNotification",
                                  Qt::QueuedConnection,
                                  Q_ARG(QVariant, msg),
                                  Q_ARG(QVariant, {}),
                                  Q_ARG(QVariant, {}),
                                  Q_ARG(QVariant, {}));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const AppStream::Image &i : images) {
        if (i.kind() == kind) {
            ret = i.url();
            break;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[mainWindow](const QStringList &arguments, const QString &/*workingDirectory*/){
            mainWindow->rootObject()->raise();
            if (arguments.isEmpty())
                return;
            QScopedPointer<QCommandLineParser> parser(createParser());
            parser->parse(arguments);
            processArgs(parser.data(), mainWindow);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto b : backends)
                found |= b->hasApplications();
```

#### LAMBDA EXPRESSION 


```{c}
[this, stream, filter] () {
        QVector<AbstractResource*> ret;
        for (auto r : qAsConst(m_resources)) {
            const bool matchById = r->appstreamId().compare(filter.search, Qt::CaseInsensitive) == 0;
            if (r->type() == AbstractResource::Technical && filter.state != AbstractResource::Upgradeable && !matchById) {
                continue;
            }
            if (r->state() < filter.state)
                continue;

            if (!filter.extends.isEmpty() && !r->extends().contains(filter.extends))
                continue;

            if (filter.search.isEmpty() || r->name().contains(filter.search, Qt::CaseInsensitive) || r->comment().contains(filter.search, Qt::CaseInsensitive) || matchById)
            {
                ret += r;
            }
        }
        auto f = [this](AbstractResource* l, AbstractResource* r) { return flatpakResourceLessThan(l,r); };
        std::sort(ret.begin(), ret.end(), f);
        if (!ret.isEmpty())
            Q_EMIT stream->resourcesFound(ret);
        stream->finish();
    }
```

#### AUTO 


```{c}
auto streamKnown = search(filter);
```

#### LAMBDA EXPRESSION 


```{c}
[this, t]() {
            auto restart = t->property("requireRestart");
            if (!restart.isNull()) {
                auto restartEvent = PackageKit::Transaction::Restart(restart.toInt());
                if (restartEvent >= PackageKit::Transaction::RestartSession) {
                    nowNeedsReboot();
                }
            }
            m_transactions.remove(t->tid().path());
            t->deleteLater();
        }
```

#### AUTO 


```{c}
auto r = new ResultsStream(QLatin1String("KNS-search-")+name());
```

#### AUTO 


```{c}
auto search = new OneTimeAction(
        [this]() {
            // First we ensure we've got data loaded on what we've got installed already
            Q_EMIT startingSearch();
            m_onePage = true;
            m_responsePending = true;
            m_engine->checkForInstalled();
            // And then we check for updates - we could do only one, if all we cared about was updates,
            // but to have both a useful initial list, /and/ information on updates, we want to get both.
            // The reason we are not doing a checkUpdates() overload for this is that the caching for this
            // information is done by KNSEngine, and we want to actually load it every time we initialize.
            auto updateChecker = new OneTimeAction(
                [this]() {
                    Q_EMIT startingSearch();
                    m_onePage = true;
                    m_responsePending = true;
                    m_engine->checkForUpdates();
                },
                this);
            connect(this, &KNSBackend::availableForQueries, updateChecker, &OneTimeAction::trigger, Qt::QueuedConnection);
        },
        this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &mode : modes)
                QTextStream(stdout) << " * " << mode << '\n';
```

#### AUTO 


```{c}
auto filter = m_andFilters.constBegin();
```

#### AUTO 


```{c}
const auto json = document.toJson(QJsonDocument::Compact);
```

#### LAMBDA EXPRESSION 


```{c}
[this, m] {
                addSourceModel(m);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this, replyGet] {
            QScopedPointer<QNetworkReply, QScopedPointerDeleteLater> replyPtr(replyGet);
            if (replyGet->error() != QNetworkReply::NoError) {
                qWarning() << "couldn't download" << m_url << replyGet->errorString();
                m_stream->finish();
                return;
            }
            const QUrl fileUrl = QUrl::fromLocalFile(QStandardPaths::writableLocation(QStandardPaths::TempLocation) //
                                                     + QLatin1Char('/') + m_url.fileName());
            auto replyPut = put(QNetworkRequest(fileUrl), replyGet->readAll());
            connect(replyPut, &QNetworkReply::finished, this, [this, fileUrl, replyPut]() {
                QScopedPointer<QNetworkReply, QScopedPointerDeleteLater> replyPtr(replyPut);
                if (replyPut->error() != QNetworkReply::NoError) {
                    qWarning() << "couldn't save" << m_url << replyPut->errorString();
                    m_stream->finish();
                    return;
                }
                if (!fileUrl.isLocalFile()) {
                    m_stream->finish();
                    return;
                }

                processFile(fileUrl);
            });
        }
```

#### AUTO 


```{c}
const auto icons = m_appdata.iconUrls();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            auto trans = PackageKit::Daemon::global()->repairSystem();
            connect(trans, &PackageKit::Transaction::errorCode, this, [](PackageKit::Transaction::Error /*error*/, const QString &details) {
                KNotification::event(QStringLiteral("OfflineUpdateRepairFailed"),
                                     i18n("Repair Failed"),
                                     xi18nc("@info", "%1<nl/>Please report this error to your distribution.", details),
                                     {},
                                     KNotification::Persistent,
                                     QStringLiteral("org.kde.discovernotifier"));
            });
            connect(trans, &PackageKit::Transaction::finished, this, [] (PackageKit::Transaction::Exit status, uint runtime) {
                qInfo() << "repair finished!" << status << runtime;
                if (status == PackageKit::Transaction::ExitSuccess) {
                    PackageKit::Daemon::global()->offline()->clearResults();
                }
            });
        }
```

#### AUTO 


```{c}
const auto components = appdata->components();
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &name) {
        PackageKit::Daemon::upgradeSystem(name, PackageKit::Transaction::UpgradeKindDefault);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const PackageState &addon : m_availableAddons) {
        // Check if we have an application for the addon
        AbstractResource *addonResource = 0;

        for (AbstractResource *resource : m_resource->backend()->allResources()) {
            if (!resource)
                continue;

            if (resource->packageName() == addon.name()) {
                addonResource = resource;
                break;
            }
        }

        QStandardItem *addonItem = new QStandardItem;
        addonItem->setData(addon.name());
        QString resourceName = QLatin1String(" (") % addon.name() % ')';
        if (addonResource) {
            addonItem->setText(addonResource->name() % resourceName);
            addonItem->setIcon(KIcon(addonResource->icon()));
        } else {
            addonItem->setText(addon.description() % resourceName);
            addonItem->setIcon(KIcon("applications-other"));
        }

        addonItem->setEditable(false);
        addonItem->setCheckable(true);

        if (addon.isInstalled()) {
            addonItem->setCheckState(Qt::Checked);
        } else {
            addonItem->setCheckState(Qt::Unchecked);
        }

        m_addonsModel->appendRow(addonItem);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &source : m_flatpakSources) {
        if (source->m_pool && !source->m_pool->lastError().isEmpty()) {
            return new HelpfulError(QStringLiteral("emblem-error"), i18n("Failed to load \"%1\" source", source->name()));
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        addSource(QStringLiteral("https://flathub.org/repo/flathub.flatpakrepo"));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, toRemoveRefs, installation, id] {
                g_autoptr(GError) localError = nullptr;
                g_autoptr(GCancellable) cancellable = g_cancellable_new();
                g_autoptr(FlatpakTransaction) transaction = flatpak_transaction_new_for_installation(installation, cancellable, &localError);
                for (const QString& instRef : qAsConst(toRemoveRefs)) {
                    const QByteArray refString = instRef.toUtf8();
                    flatpak_transaction_add_uninstall(transaction, refString.constData(), &localError);
                    if (localError)
                        return;
                }

                if (flatpak_transaction_run(transaction, cancellable, &localError)) {
                    removeSource(id);
                }
            }
```

#### AUTO 


```{c}
auto stream = new ResultsStream(QStringLiteral("FwupdStream"));
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &pkgid) {
            return PackageKit::Daemon::packageName(pkgid);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, app](PackageKit::Transaction::Exit status) {
            const bool simulate = m_trans->transactionFlags() & PackageKit::Transaction::TransactionFlagSimulate;
            if (!simulate && status == PackageKit::Transaction::ExitSuccess) {
                app->setState(AbstractResource::Installed);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto resource: resources) {
        const auto finder = [this](AbstractResource* resource, AbstractResource* res){ return lessThan(resource, res); };
        const auto it = std::upper_bound(m_displayedResources.constBegin(), m_displayedResources.constEnd(), resource, finder);
        const auto newIdx = it == m_displayedResources.constEnd() ? m_displayedResources.count() : (it - m_displayedResources.constBegin());

        if ((it-1) != m_displayedResources.constEnd() && *(it-1) == resource)
            continue;

        beginInsertRows({}, newIdx, newIdx);
        m_displayedResources.insert(newIdx, resource);
        endInsertRows();
//         Q_ASSERT(isSorted(resources));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const AppStream::Component &component : components) {
        if (component.kind() == AppStream::Component::KindFirmware)
            continue;

        const auto pkgNames = component.packageNames();
        if (pkgNames.isEmpty()) {
            const auto entries = component.launchable(AppStream::Launchable::KindDesktopId).entries();
            if (component.kind() == AppStream::Component::KindDesktopApp && !entries.isEmpty()) {
                const QString file = PackageKitBackend::locateService(entries.first());
                if (!file.isEmpty()) {
                    ret.missingComponents[file] = component;
                }
            }
        } else {
            ret.components << component;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &name : pkgnames) {
        const QStringList names = m_packages.packageToApp.value(name, QStringList(name));
        for (const QString &name : names) {
            AbstractResource *res = m_packages.packages.value(name);
            if (res)
                ret += res;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (PackageKitResource *res : qAsConst(m_packagesToDelete)) {
        const auto pkgs = m_packages.packageToApp.value(res->packageName(), {res->packageName()});
        for (const auto &pkg : pkgs) {
            auto res = m_packages.packages.take(pkg);
            if (res) {
                if (AppPackageKitResource *ares = qobject_cast<AppPackageKitResource *>(res)) {
                    const auto extends = res->extends();
                    for (const auto &ext : extends)
                        m_packages.extendedBy[ext].removeAll(ares);
                }

                Q_EMIT resourceRemoved(res);
                res->deleteLater();
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](AbstractResourcesBackend *b) {
        return QVariant::fromValue<QObject *>(b);
    }
```

#### AUTO 


```{c}
const auto runtimeInfo = runtimeName.splitRef(QLatin1Char('/'));
```

#### AUTO 


```{c}
const auto snap = job->snap(i);
```

#### AUTO 


```{c}
auto b = resource->backend();
```

#### AUTO 


```{c}
const auto resRssguard = res.constFirst();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &source : m_flatpakLoadingSources) {
        if (source->installation() == installation && source->name() == origin) {
            return source;
        }
    }
```

#### AUTO 


```{c}
auto action = new OneTimeAction(
        [this, localfile]() {
            AbstractResourcesBackend::Filters f;
            f.resourceUrl = localfile;
            auto stream = new StoredResultsStream({ResourcesModel::global()->search(f)});
            connect(stream, &StoredResultsStream::finishedResources, this, [this, localfile](const QVector<AbstractResource*> &res) {
                if (res.count() == 1) {
                    emit openApplicationInternal(res.first());
                } else {
                    QMimeDatabase db;
                    auto mime = db.mimeTypeForUrl(localfile);
                    auto fIsFlatpakBackend = [](AbstractResourcesBackend* backend) { return backend->metaObject()->className() == QByteArray("FlatpakBackend"); };
                    if (mime.name().startsWith(QLatin1String("application/vnd.flatpak")) && !kContains(ResourcesModel::global()->backends(), fIsFlatpakBackend)) {
                        openApplication(QUrl(QStringLiteral("appstream://org.kde.discover.flatpak")));
                        showPassiveNotification(i18n("Cannot interact with flatpak resources without the flatpak backend %1. Please install it first.", localfile.toDisplayString()));
                    } else {
                        openMode(QStringLiteral("Browsing"));
                        showPassiveNotification(i18n("Could not open %1", localfile.toDisplayString()));
                    }
                }
            });
        }
        , this);
```

#### AUTO 


```{c}
const auto it = m_packages.constFind(PackageKit::Transaction::InfoAvailable);
```

#### LAMBDA EXPRESSION 


```{c}
[](const KNSCore::EntryInternal& entry){ return entry.isValid(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this, p](int code, QProcess::ExitStatus status) {
            p->deleteLater();
            if (code != 0) {
                qWarning() << "login failed... code:" << code << status << p->readAll();
                Q_EMIT passiveMessage(m_request->errorString());
                setStatus(DoneWithErrorStatus);
                return;
            }
            const auto doc = QJsonDocument::fromJson(p->readAllStandardOutput());
            const auto result = doc.object();

            const auto macaroon = result[QStringLiteral("macaroon")].toString();
            const auto discharges = kTransform<QStringList>(result[QStringLiteral("discharges")].toArray(), [](const QJsonValue &val) {
                return val.toString();
            });
            static_cast<SnapBackend *>(m_app->backend())->client()->setAuthData(new QSnapdAuthData(macaroon, discharges));
            m_request->runAsync();
        }
```

#### AUTO 


```{c}
static constexpr auto s_addonKinds = {AppStream::Component::KindAddon, AppStream::Component::KindCodec};
```

#### RANGE FOR STATEMENT 


```{c}
for (auto ref : qAsConst(it.value())) {
                        auto resource = getAppForInstalledRef(it.key(), ref);
#if FLATPAK_CHECK_VERSION(1, 1, 2)
                        resource->setAvailableVersion(QString::fromUtf8(flatpak_installed_ref_get_appdata_version(ref)));
#endif
                        g_object_unref(ref);
                        resource->setState(AbstractResource::Upgradeable);
                        updateAppSize(resource);
                        if (resource->resourceType() == FlatpakResource::Runtime) {
                            resources.prepend(resource);
                        } else {
                            resources.append(resource);
                        }
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &desktopFilePath : desktopFilePaths) {
        auto p = new QProcess(parent());
        connect(p, QOverload<int, QProcess::ExitStatus>::of(&QProcess::finished), this, [this, p](int exitCode, QProcess::ExitStatus /*exitStatus*/) {
            if (exitCode != 0) {
                backend()->passiveMessage(i18n("Failed to start '%1'", KShell::joinArgs(p->arguments())));
            }
            p->deleteLater();
        });
        p->start(QStringLiteral(CMAKE_INSTALL_FULL_LIBEXECDIR_KF5 "/discover/runservice"), {desktopFilePath});
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto backend: qAsConst(m_backends))
        if (!backend->isFetching())
            backend->checkForUpdates();
```

#### AUTO 


```{c}
auto stream = ResourcesModel::global()->findResourceByPackageName(m_appToBeOpened);
```

#### LAMBDA EXPRESSION 


```{c}
[this](){
            Q_EMIT downloadSpeedChanged(downloadSpeed());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Category* cat : categories) {
                if (cat->orFilters().count() > 0 && cat->orFilters().first().second == category.name) {
                    cat->setName(category.displayName);
                    break;
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this](AbstractResource *res) {
            m_resources.remove(res);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, p](int exitCode, QProcess::ExitStatus exitStatus) {
            if (exitCode != 0) {
                backend()->passiveMessage(i18n("Failed to start '%1'", KShell::joinArgs(p->arguments())));
            }
            p->deleteLater();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[process]() {
        qDebug() << "rpm-ostree errors" << process->readAllStandardError().constData();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](AbstractResource *resource) {
        if (m_upgradeable.remove(resource)) {
            Q_EMIT updatesCountChanged(updatesCount());
        }
        m_toUpgrade.remove(resource);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto app : m_apps) {
                    qCDebug(LIBDISCOVER_BACKEND_LOG) << "app" << app << app->state();
                }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto &x: set)
        ret.append(x);
```

#### AUTO 


```{c}
const auto resources = stream->property("resources").value<QVector<AbstractResource*>>();
```

#### AUTO 


```{c}
auto snap = snapValue.toObject();
```

#### RANGE FOR STATEMENT 


```{c}
for(auto job : jobs) {
        connect(job, &T::complete, stream, [stream, this, job, filter]() {
            const int remaining = stream->property("remaining").toInt() - 1;
            stream->setProperty("remaining", remaining);

            if (job->error()) {
                qDebug() << "error:" << job->error() << job->errorString();
                if (remaining == 0)
                    stream->finish();
                return;
            }

            QVector<AbstractResource*> ret;
            QVector<SnapResource*> resources;
            ret.reserve(job->snapCount());
            resources.reserve(job->snapCount());
            for (int i=0, c=job->snapCount(); i<c; ++i) {
                QSharedPointer<QSnapdSnap> snap(job->snap(i));

                if (!filter(snap))
                    continue;

                const auto snapname = snap->name();
                SnapResource* res = m_resources.value(snapname);
                if (!res) {
                    res = new SnapResource(snap, AbstractResource::None, this);
                    Q_ASSERT(res->packageName() == snapname);
                    resources += res;
                } else {
                    res->setSnap(snap);
                }
                ret += res;
            }

            foreach(SnapResource* res, resources)
                m_resources[res->packageName()] = res;

            if (!ret.isEmpty())
                Q_EMIT stream->resourcesFound(ret);

            if (remaining == 0)
                stream->finish();
        });
        job->runAsync();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(AbstractSourcesBackend* b: m_sources) {
        foreach(QAction* action, b->actions())
            ret.append(action);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        KProtocolManager::reparseConfiguration();
        updateProxy();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &component: data.components) {
            const auto pkgNames = component.packageNames();
            addComponent(component, pkgNames);
            neededPackages << pkgNames;
        }
```

#### AUTO 


```{c}
const auto slot = req->slot(i);
```

#### AUTO 


```{c}
auto it = list.begin(), itEnd = list.end();
```

#### RANGE FOR STATEMENT 


```{c}
for(BackendNotifierModule* module : m_backends) {
        security |= module->securityUpdatesCount()>0;
        normal |= security || module->updatesCount()>0;
        if (security)
            break;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&ret](const QVector<AbstractResource*>& res) { ret += res; }
```

#### AUTO 


```{c}
const auto &location
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &path: QStandardPaths::standardLocations(QStandardPaths::GenericConfigLocation)) {
                QDirIterator dirIt(path, {QStringLiteral("*.knsrc")}, QDir::Files);
                for(; dirIt.hasNext(); ) {
                    dirIt.next();

                    auto bk = new KNSBackend(parent, QStringLiteral("plasma"), dirIt.filePath());
                    if (bk->isValid())
                        ret += bk;
                    else
                        delete bk;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &archive : package->archives()) {
                if (archive.contains(QLatin1String("security"))) {
                    securityFound = true;
                    break;
                }
            }
```

#### AUTO 


```{c}
const auto iconPath = m_snap->icon();
```

#### AUTO 


```{c}
const auto sortUpdateItems = [](UpdateItem *a, UpdateItem *b) { return a->name() < b->name(); };
```

#### AUTO 


```{c}
auto findTestBackend = [](AbstractResourcesBackend *backend) {
        return backend->name() == QLatin1String("ksplash.knsrc");
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (DetailsTab *tab : m_detailsTabs) {
        tab->setPackage(package);

        if (tab->shouldShow()) {
            addTab(tab, tab->name());
        } else {
            if (currentIndex() == indexOf(tab)) {
                setCurrentIndex(0);
            }
            removeTab(indexOf(tab));
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        Q_EMIT startingSearch();
        m_onePage = true;
        m_responsePending = true;
        m_engine->checkForInstalled();
    }
```

#### AUTO 


```{c}
const auto libraryPaths = QCoreApplication::libraryPaths();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            qCDebug(LIBDISCOVER_LOG) << "destroyed transaction before finishing";
            setTransaction(nullptr);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, stream, filter]() {
            if (m_isValid) {
                auto filterFunction = [&filter](AbstractResource *r) {
                    return r->state() >= filter.state
                        && (r->name().contains(filter.search, Qt::CaseInsensitive) || r->comment().contains(filter.search, Qt::CaseInsensitive));
                };
                const auto ret = kFilter<QVector<AbstractResource *>>(m_resourcesByName, filterFunction);

                if (!ret.isEmpty())
                    Q_EMIT stream->resourcesFound(ret);
            }
            stream->finish();
        }
```

#### AUTO 


```{c}
const auto appstreamId = AppStreamUtils::appstreamId(url);
```

#### RANGE FOR STATEMENT 


```{c}
for (FlatpakResource *res : m_resources) {
        if (QString::compare(res->appstreamId(), name, Qt::CaseInsensitive) == 0
            || QString::compare(res->appstreamId(), nameWithDesktop, Qt::CaseInsensitive) == 0)
            resources << res;
        else {
            const auto alts = res->alternativeAppstreamIds();
            for (const auto &alt : alts) {
                if (QString::compare(alt, name, Qt::CaseInsensitive) == 0 || QString::compare(alt, nameWithDesktop, Qt::CaseInsensitive) == 0) {
                    resources << res;
                    break;
                }
            }
        }
    }
```

#### AUTO 


```{c}
auto backend = qobject_cast<AbstractResourcesBackend*>(sources->parent());
```

#### RANGE FOR STATEMENT 


```{c}
for (auto source : qAsConst(m_flatpakLoadingSources)) {
        if (source->url() == flatpak_remote_get_url(remote) && source->installation() == flatpakInstallation) {
            qDebug() << "do not add a source twice2" << source << remote;
            metadataRefreshed();
            return source;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &e : linkInfo) {
        if (e.isDownloadtypeLink)
            ids << e.id;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        if (m_notifier.needsReboot()) {
            m_notifier.reboot();
        } else {
            m_notifier.showDiscoverUpdates();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractResourcesBackend *backend : backends) {
        if(backend->metaObject()->className()==QLatin1String("ApplicationBackend")) {
            m_appBackend = backend;
            connect(m_appBackend, SIGNAL(backendReady()),
                    this, SLOT(populateViews()));
            connect(m_appBackend, SIGNAL(reloadFinished()),
                    this, SLOT(showLauncherMessage()));
            connect(m_appBackend, SIGNAL(sourcesEditorFinished()),
                    this, SLOT(sourcesEditorFinished()));
        }
    }
```

#### AUTO 


```{c}
const auto& snap
```

#### AUTO 


```{c}
const auto addonsToRemove = addons.addonsToRemove();
```

#### AUTO 


```{c}
auto f = [this, stream, filter] {
            const auto toResolve = kFilter<QVector<AbstractResource *>>(m_packages.packages, needsResolveFilter);

            auto installedAndNameFilter = [filter](AbstractResource *res) {
                return res->state() >= AbstractResource::Installed
                    && (res->name().contains(filter.search, Qt::CaseInsensitive) || res->packageName().compare(filter.search, Qt::CaseInsensitive) == 0);
            };
            bool furtherSearch = false;
            if (!toResolve.isEmpty()) {
                resolvePackages(kTransform<QStringList>(toResolve, [](AbstractResource *res) {
                    return res->packageName();
                }));
                connect(m_resolveTransaction, &PKResolveTransaction::allFinished, this, [stream, toResolve, installedAndNameFilter] {
                    const auto resolved = kFilter<QVector<AbstractResource *>>(toResolve, installedAndNameFilter);
                    if (!resolved.isEmpty())
                        Q_EMIT stream->resourcesFound(resolved);
                    stream->finish();
                });
                furtherSearch = true;
            }

            const auto resolved = kFilter<QVector<AbstractResource *>>(m_packages.packages, installedAndNameFilter);
            if (!resolved.isEmpty()) {
                QTimer::singleShot(0, this, [resolved, toResolve, stream]() {
                    if (!resolved.isEmpty())
                        Q_EMIT stream->resourcesFound(resolved);

                    if (toResolve.isEmpty())
                        stream->finish();
                });
                furtherSearch = true;
            }

            if (!furtherSearch)
                stream->finish();
        };
```

#### AUTO 


```{c}
auto slot
```

#### LAMBDA EXPRESSION 


```{c}
[categories](const QList<KNSCore::Provider::CategoryMetadata> &categoryMetadatas) {
        for (const KNSCore::Provider::CategoryMetadata &category : categoryMetadatas) {
            for (Category *cat : qAsConst(categories)) {
                if (cat->orFilters().count() > 0 && cat->orFilters().constFirst().second == category.name) {
                    cat->setName(category.displayName);
                    break;
                }
            }
        }
    }
```

#### AUTO 


```{c}
const auto deprecatedHost = deprecatedAppstreamIds.value(host);
```

#### AUTO 


```{c}
const auto actualPercentage = percentageWithStatus(m_transaction->status(), m_transaction->percentage());
```

#### AUTO 


```{c}
const auto res = getAppForInstalledRef(flatpakInstallation, ref);
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto& v : input) {
        ret += op(v);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractResource * res : m_toUpgrade) {
        if (auto upgrade = dynamic_cast<SystemUpgrade*>(res)) {
            ret += upgrade->size();
            continue;
        }

        PackageKitResource * app = qobject_cast<PackageKitResource*>(res);
        QString pkgid = m_backend->upgradeablePackageId(app);
        if (!donePkgs.contains(pkgid)) {
            donePkgs.insert(pkgid);
            ret += app->size();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString& pkgid : m_updatesPackageId) {
        const QString pkgname = PackageKit::Daemon::packageName(pkgid);
        ret += resourcesByPackageName(pkgname, false);
        if (ret.isEmpty()) {
            qWarning() << "couldn't find resource for" << pkgid;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](uint timeSince) {
        if (timeSince > 3600)
            checkForUpdates();
        else
            fetchUpdates();
        acquireFetching(false);
    }
```

#### AUTO 


```{c}
auto f = [this, stream] {
            const auto toResolve = kFilter<QVector<AbstractResource*>>(m_packages.packages, needsResolveFilter);

            if (!toResolve.isEmpty()) {
                resolvePackages(kTransform<QStringList>(toResolve, [] (AbstractResource* res) { return res->packageName(); }));
                connect(m_resolveTransaction, &PKResolveTransaction::allFinished, this, [stream, toResolve] {
                    const auto resolved = kFilter<QVector<AbstractResource*>>(toResolve, installedFilter);
                    if (!resolved.isEmpty())
                        Q_EMIT stream->resourcesFound(resolved);
                    stream->finish();
                });
            }

            const auto resolved = kFilter<QVector<AbstractResource*>>(m_packages.packages, installedFilter);
            if (!resolved.isEmpty()) {
                QTimer::singleShot(0, this, [resolved, toResolve, stream] () {
                    if (!resolved.isEmpty())
                        Q_EMIT stream->resourcesFound(resolved);

                    if (toResolve.isEmpty())
                        stream->finish();
            });
            }
        };
```

#### AUTO 


```{c}
const auto sourceName = source->name();
```

#### LAMBDA EXPRESSION 


```{c}
[this, localfile]() {
            AbstractResourcesBackend::Filters f;
            f.resourceUrl = localfile;
            auto stream = new StoredResultsStream({ResourcesModel::global()->search(f)});
            connect(stream, &StoredResultsStream::finishedResources, this, [this, localfile](const QVector<AbstractResource*> &res) {
                if (res.count() == 1) {
                    emit openApplicationInternal(res.first());
                } else {
                    QMimeDatabase db;
                    auto mime = db.mimeTypeForUrl(localfile);
                    auto fIsFlatpakBackend = [](AbstractResourcesBackend* backend) { return backend->metaObject()->className() == QByteArray("FlatpakBackend"); };
                    if (mime.name().startsWith(QLatin1String("application/vnd.flatpak")) && !kContains(ResourcesModel::global()->backends(), fIsFlatpakBackend)) {
                        openApplication(QUrl(QStringLiteral("appstream://org.kde.discover.flatpak")));
                        showPassiveNotification(i18n("Cannot interact with flatpak resources without the flatpak backend %1. Please install it first.", localfile.toDisplayString()));
                    } else {
                        openMode(QStringLiteral("Browsing"));
                        showPassiveNotification(i18n("Could not open %1", localfile.toDisplayString()));
                    }
                }
            });
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QQmlError &warning : warnings) {
            if (warning.url().path().endsWith(QLatin1String("DiscoverTest.qml"))) {
                qCWarning(DISCOVER_LOG) << "Test failed!" << warnings;
                qGuiApp->exit(1);
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, fw]() {
        m_fetching = true;
        emit fetchingChanged();

        auto devices = fw->result();
        for(uint i = 0; devices && i < devices->len; i++) {
            FwupdDevice *device = (FwupdDevice *) g_ptr_array_index(devices, i);
            g_autoptr(GError) error = nullptr;
            g_autoptr(GPtrArray) releases = fwupd_client_get_releases(client, fwupd_device_get_id(device), nullptr, &error);

            if (error) {
                if (g_error_matches(error, FWUPD_ERROR, FWUPD_ERROR_INVALID_FILE) || g_error_matches(error, FWUPD_ERROR, FWUPD_ERROR_NOT_SUPPORTED))
                    continue;

                handleError(error);
            }

            auto res = createDevice(device);
            for (uint i=0; releases && i<releases->len; ++i) {
                FwupdRelease *release = (FwupdRelease *)g_ptr_array_index(releases, i);
                if (res->installedVersion().toUtf8() == fwupd_release_get_version(release)) {
                    res->setReleaseDetails(release);
                    break;
                }
            }
            addResourceToList(res);
        }
        g_ptr_array_unref(devices);

        addUpdates();

        m_fetching = false;
        emit fetchingChanged();
        emit initialized();
        fw->deleteLater();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, fw]() {
        const auto data = fw->result();
        fw->deleteLater();

        if (!data.correct && m_packages.packages.isEmpty()) {
            QTimer::singleShot(0, this, [this]() {
                Q_EMIT passiveMessage(i18n("Please make sure that Appstream is properly set up on your system"));
            });
        }
        for (const auto &component: data.components) {
            const auto pkgNames = component.packageNames();
            addComponent(component, pkgNames);
        }

        if (data.components.isEmpty()) {
            qCDebug(LIBDISCOVER_BACKEND_LOG) << "empty appstream db";
            if (PackageKit::Daemon::backendName() == QLatin1String("aptcc") || PackageKit::Daemon::backendName().isEmpty()) {
                checkForUpdates();
            }
        }
        if (!m_appstreamInitialized) {
            m_appstreamInitialized = true;
            Q_EMIT loadedAppStream();
        }
        acquireFetching(false);
    }
```

#### AUTO 


```{c}
const auto toUpd = toUpdate();
```

#### LAMBDA EXPRESSION 


```{c}
[this, stream, filter] () {
            const QList<AppStream::Component> components = m_appdata->search(filter.search);
            const QStringList ids = kTransform<QStringList>(components, [](const AppStream::Component& comp) { return comp.id(); });
            if (!ids.isEmpty()) {
                const auto resources = kFilter<QVector<AbstractResource*>>(resourcesByPackageNames<QVector<AbstractResource*>>(ids), [](AbstractResource* res){ return !qobject_cast<PackageKitResource*>(res)->extendsItself(); });
                stream->setResources(resources);
            }
            stream->finish();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QStringList &list : m_list) {
        list.removeAll(addon);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(AbstractResource* res : m_packages.values()) {
        if (res->name().contains(searchText, Qt::CaseInsensitive)) {
            ret += res;
        }
    }
```

#### AUTO 


```{c}
auto app = qobject_cast<SnapResource *>(_app);
```

#### LAMBDA EXPRESSION 


```{c}
[](){ qDebug() << "random action triggered"; }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &errorMessage) {
            Q_EMIT passiveMessage(errorMessage);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](Category* cat) {return qVariantFromValue<QObject*>(cat); }
```

#### AUTO 


```{c}
auto it = deprecatedAppstreamIds.constFind(appstreamIds.first());
```

#### LAMBDA EXPRESSION 


```{c}
[this, r](){
            m_results.removeAll(r);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](){ transactionChanged(CancellableRole); }
```

#### LAMBDA EXPRESSION 


```{c}
[addSource, stream]() {
            const auto res = stream->resources();
            addSource(res.value(0));
        }
```

#### AUTO 


```{c}
auto comps = source->m_pool->componentsById(name);
```

#### AUTO 


```{c}
const auto appstreamid = (*it)->appstreamId();
```

#### LAMBDA EXPRESSION 


```{c}
[this, stream, filter] () {
            const QList<AppStream::Component> components = m_appdata->search(filter.search);
            const QStringList ids = kTransform<QStringList>(components, [](const AppStream::Component& comp) { return comp.id(); });
            if (!ids.isEmpty()) {
                const auto resources = kFilter<QVector<AbstractResource*>>(resourcesByPackageNames<QVector<AbstractResource*>>(ids), [](AbstractResource* res){ return !qobject_cast<PackageKitResource*>(res)->extendsItself(); });
                Q_EMIT stream->setResources(resources);
            }

            PackageKit::Transaction * tArch = PackageKit::Daemon::resolve(filter.search, PackageKit::Transaction::FilterArch);
            connect(tArch, &PackageKit::Transaction::package, this, &PackageKitBackend::addPackageArch);
            connect(tArch, &PackageKit::Transaction::package, stream, [stream](PackageKit::Transaction::Info /*info*/, const QString &packageId){
                stream->setProperty("packageId", packageId);
            });
            connect(tArch, &PackageKit::Transaction::finished, stream, [stream, ids, this](PackageKit::Transaction::Exit status) {
                getPackagesFinished();
                if (status == PackageKit::Transaction::Exit::ExitSuccess) {
                    const auto packageId = stream->property("packageId");
                    if (!packageId.isNull()) {
                        const auto res = resourcesByPackageNames<QVector<AbstractResource*>>({PackageKit::Daemon::packageName(packageId.toString())});
                        Q_EMIT stream->setResources(kFilter<QVector<AbstractResource*>>(res, [ids](AbstractResource* res){ return !ids.contains(res->appstreamId()); }));
                    }
                }
                stream->finish();
            }, Qt::QueuedConnection);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](AbstractBackendUpdater *updater) {
        return !updater->needsReboot() || updater->isReadyToReboot();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString& toRemove : addons.addonsToRemove()) {
        setAddonInstalled(toRemove, false);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, appstreamId, stream] () {
                AbstractResource* pkg = nullptr;
                const auto deprecatedHost = deprecatedAppstreamIds.value(appstreamId); //try this as fallback
                for (auto it = m_packages.packages.constBegin(), itEnd = m_packages.packages.constEnd(); it != itEnd; ++it) {
                    if    (it.key().compare(appstreamId, Qt::CaseInsensitive) == 0
                        || it.key().compare(deprecatedHost, Qt::CaseInsensitive) == 0
                        || (appstreamId.endsWith(QLatin1String(".desktop")) && appstreamId.compare(it.key()+QLatin1String(".desktop"), Qt::CaseInsensitive) == 0)) {
                        pkg = it.value();
                        break;
                    }
                }
                if (pkg)
                    Q_EMIT stream->resourcesFound({pkg});
                stream->finish();
    //             if (!pkg)
    //                 qCDebug(LIBDISCOVER_BACKEND_LOG) << "could not find" << host << deprecatedHost;
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            recheckSystemUpdateNeeded();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto installation : qAsConst(m_installations)) {
        // Load local updates, comparing current and latest commit
        loadLocalUpdates(installation);

        if (g_cancellable_is_cancelled(m_cancellable))
            break;

        // Load updates from remote repositories
        loadRemoteUpdates(installation);

        if (g_cancellable_is_cancelled(m_cancellable))
            break;
    }
```

#### AUTO 


```{c}
auto fIsFlatpakBackend = [](AbstractResourcesBackend* backend) { return backend->metaObject()->className() == QByteArray("FlatpakBackend"); };
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &/*packageID*/, const QStringList &filenames) {
        const auto allServices = QStandardPaths::locateAll(QStandardPaths::ApplicationsLocation, m_appdata.id());
        if (!allServices.isEmpty()) {
            const auto packageServices = kFilter<QStringList>(allServices, [filenames](const QString &file) { return filenames.contains(file); });
            QProcess::startDetached(QStringLiteral(CMAKE_INSTALL_FULL_LIBEXECDIR_KF5 "/discover/runservice"), {packageServices});
            return;
        } else {
            const QStringList exes = m_appdata.provided(AppStream::Provided::KindBinary).items();
            const auto packageExecutables = kFilter<QStringList>(allServices, [filenames](const QString &exe) { return filenames.contains(QLatin1Char('/') + exe); });
            if (!packageExecutables.isEmpty()) {
                QProcess::startDetached(exes.constFirst());
                return;
            } else {
                const auto locations = QStandardPaths::standardLocations(QStandardPaths::ApplicationsLocation);
                const auto desktopFiles = kFilter<QStringList>(filenames, [locations](const QString &exe) {
                    for (const auto &location: locations) {
                        if (exe.startsWith(location))
                            return exe.contains(QLatin1String(".desktop"));
                    }
                    return false;
                });
                if (!desktopFiles.isEmpty()) {
                    QProcess::startDetached(QStringLiteral(CMAKE_INSTALL_FULL_LIBEXECDIR_KF5 "/discover/runservice"), { desktopFiles });
                    return;
                }
            }
            Q_EMIT backend()->passiveMessage(i18n("Cannot launch %1", name()));
        }
    }
```

#### AUTO 


```{c}
const auto sourceItem = qobject_cast<FlatpakBackend *>(backend())->sources()->sourceById(origin());
```

#### LAMBDA EXPRESSION 


```{c}
[this, localfile](const QVector<AbstractResource*> &res) {
                if (res.count() == 1) {
                    emit openApplicationInternal(res.first());
                } else {
                    QMimeDatabase db;
                    auto mime = db.mimeTypeForUrl(localfile);
                    auto fIsFlatpakBackend = [](AbstractResourcesBackend* backend) { return backend->metaObject()->className() == QByteArray("FlatpakBackend"); };
                    if (mime.name().startsWith(QLatin1String("application/vnd.flatpak")) && !kContains(ResourcesModel::global()->backends(), fIsFlatpakBackend)) {
                        openApplication(QUrl(QStringLiteral("appstream://org.kde.discover.flatpak")));
                        showPassiveNotification(i18n("Cannot interact with flatpak resources without the flatpak backend %1. Please install it first.", localfile.toDisplayString()));
                    } else {
                        setRootObjectProperty("defaultStartup", true);
                        showPassiveNotification(i18n("Couldn't open %1", localfile.toDisplayString()));
                    }
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        acquireFetching(false);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[func](QDBusPendingCallWatcher* watcher) {
                        watcher->deleteLater();
                        QDBusPendingReply<T> reply = *watcher;
                        func(reply.value());
                    }
```

#### AUTO 


```{c}
const auto match = rx.match(QString::fromUtf8(data));
```

#### LAMBDA EXPRESSION 


```{c}
[](const QQmlError& err) -> bool {
            return err.description().contains(QLatin1String("QML Image: Failed to get image from provider: image://icon/"));
        }
```

#### AUTO 


```{c}
auto resources = _res;
```

#### AUTO 


```{c}
const auto filename_cache = FwupdBackend::cacheFile(QStringLiteral("fwupd"), QFileInfo(QUrl(m_updateURI).path()).fileName());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &path: locations) {
                QDirIterator dirIt(path, {QStringLiteral("*.knsrc")}, QDir::Files);
                for(; dirIt.hasNext(); ) {
                    dirIt.next();

                    auto bk = new KNSBackend(parent, QStringLiteral("plasma"), dirIt.filePath());
                    if (bk->isValid())
                        ret += bk;
                    else
                        delete bk;
                }
            }
```

#### AUTO 


```{c}
auto tempSource = resource->temporarySource()
```

#### RANGE FOR STATEMENT 


```{c}
for (auto resource : resources) {
            if (resource->origin() == item->data(AbstractSourcesBackend::IdRole)) {
                stream->resourcesFound({resource});
                stream->finish();
                return;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, process](int exitCode, QProcess::ExitStatus exitStatus) {
        qDebug() << "Finished running plasma-discover-update" << exitCode << exitStatus;
        DiscoverNotifier *notifier = static_cast<DiscoverNotifier *>(parent());
        notifier->setBusy(false);
        process->deleteLater();
    }
```

#### AUTO 


```{c}
auto f = [this, filter, stream] {
            const auto resources = kTransform<QVector<AbstractResource*>>(m_packages.extendedBy.value(filter.extends), [](AppPackageKitResource* a){ return a; });
            if (!resources.isEmpty()) {
                stream->setResources(resources);
            }
        };
```

#### AUTO 


```{c}
auto action = new OneTimeAction(
        [this, localfile]() {
            auto res = ResourcesModel::global()->resourceForFile(localfile);
            qDebug() << "all initialized..." << res;
            if (res) {
                emit openApplicationInternal(res);
            } else
                showPassiveNotification(i18n("Couldn't open %1", localfile.toDisplayString()));
        }
        , this);
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractResource *res : m_toUpgrade) {
        if (auto upgrade = dynamic_cast<SystemUpgrade *>(res)) {
            ret += upgrade->size();
            continue;
        }

        PackageKitResource *app = qobject_cast<PackageKitResource *>(res);
        QString pkgid = m_backend->upgradeablePackageId(app);
        if (!donePkgs.contains(pkgid)) {
            donePkgs.insert(pkgid);
            ret += app->size();
        }
    }
```

#### AUTO 


```{c}
const auto open = m_file.open(QIODevice::ReadOnly | QIODevice::Text);
```

#### AUTO 


```{c}
const auto ourIdx = ids.indexOf(id);
```

#### LAMBDA EXPRESSION 


```{c}
[](const QQmlError &err) -> bool {
            return err.description().contains(QLatin1String("QML Image: Failed to get image from provider: image://icon/"));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &alias : alts) {
                    aliases[alias] = appstreamid;
                }
```

#### AUTO 


```{c}
const auto type = resource->resourceType() == FlatpakResource::DesktopApp ? FLATPAK_REF_KIND_APP : FLATPAK_REF_KIND_RUNTIME;
```

#### RANGE FOR STATEMENT 


```{c}
for (BackendNotifierModule *module : qAsConst(m_backends))
        module->recheckSystemUpdateNeeded();
```

#### AUTO 


```{c}
const auto snap = snapValue.toObject();
```

#### LAMBDA EXPRESSION 


```{c}
[this](AbstractResource *l, AbstractResource *r) {
            return flatpakResourceLessThan(l, r);
        }
```

#### AUTO 


```{c}
auto f = [this, stream, appstreamIds] () {
                const auto resources = kAppend<QVector<AbstractResource*>>(appstreamIds, [this] (const QString &appstreamId) { return resourcesByAppstreamName(appstreamId); });
                if (!resources.isEmpty())
                    Q_EMIT stream->resourcesFound(resources);
                stream->finish();
            };
```

#### LAMBDA EXPRESSION 


```{c}
[stream, ids, this](PackageKit::Transaction::Exit status) {
                getPackagesFinished();
                if (status == PackageKit::Transaction::Exit::ExitSuccess) {
                    const auto packageId = stream->property("packageId");
                    if (!packageId.isNull()) {
                        const auto res = resourcesByPackageNames<QVector<AbstractResource*>>({PackageKit::Daemon::packageName(packageId.toString())});
                        Q_EMIT stream->setResources(kFilter<QVector<AbstractResource*>>(res, [ids](AbstractResource* res){ return !ids.contains(res->appstreamId()); }));
                    }
                }
                stream->finish();
            }
```

#### AUTO 


```{c}
const auto res = QMessageBox::question(nullptr, i18n("Add Remote"),
                                            i18n("Would you like to add remote '%1'?\n\nFrom: %2\nWith GPG key=%3...",
                                                    settings.value(QStringLiteral("Flatpak Ref/Title")).toString(),
                                                    refurl,
                                                    settings.value(QStringLiteral("Flatpak Ref/GPGKey")).toString().left(23)),
                                            QMessageBox::StandardButtons(QMessageBox::Yes | QMessageBox::No));
```

#### LAMBDA EXPRESSION 


```{c}
[this, item, index]() {
                        item->setCheckState(Qt::Unchecked);
                        Q_EMIT dataChanged(index,index,{});
                        return false;
                    }
```

#### AUTO 


```{c}
const auto release = appdata.releases().constFirst();
```

#### RANGE FOR STATEMENT 


```{c}
for (TransactionListener *listener : m_transactions) {
        if(listener->resource() == trans->resource()) {
            toRemove = listener;
            break;
        }
    }
```

#### AUTO 


```{c}
auto stream = new ResultsStream(QStringLiteral("PackageKitStream"));
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractResourcesBackend *backend : backends) {
            if (QLatin1String(backend->metaObject()->className()) == name) {
                return backend;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString &pkgid) {
                return name == PackageKit::Transaction::packageName(pkgid);
            }
```

#### AUTO 


```{c}
auto stream = new ResultsStream(QStringLiteral("FlatpakStream-upgradeable"));
```

#### RANGE FOR STATEMENT 


```{c}
for (auto installation : installations) {
                    g_autoptr(GError) localError = nullptr;
                    g_autoptr(GPtrArray) refs = flatpak_installation_list_installed_refs_for_update(installation, cancellable, &localError);
                    if (!refs) {
                        qWarning() << "Failed to get list of installed refs for listing updates:" << localError->message;
                        continue;
                    }
                    if (g_cancellable_is_cancelled(cancellable)) {
                        qWarning() << "Job cancelled";
                        return ret;
                    }

                    auto &current = ret[installation];
                    current.reserve(refs->len);
                    for (uint i = 0; i < refs->len; i++) {
                        FlatpakInstalledRef *ref = FLATPAK_INSTALLED_REF(g_ptr_array_index(refs, i));
                        g_object_ref(ref);
                        current.append(ref);
                    }
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this, jobs, filter, stream] {
        QVector<AbstractResource*> ret;
        for (auto job : jobs) {
            if (job->error()) {
                qDebug() << "error:" << job->error() << job->errorString();
                continue;
            }

            for (int i=0, c=job->snapCount(); i<c; ++i) {
                QSharedPointer<QSnapdSnap> snap(job->snap(i));

                if (!filter(snap))
                    continue;

                const auto snapname = snap->name();
                SnapResource*& res = m_resources[snapname];
                if (!res) {
                    res = new SnapResource(snap, AbstractResource::None, this);
                    Q_ASSERT(res->packageName() == snapname);
                } else {
                    res->setSnap(snap);
                }
                ret += res;
            }
        }

        if (!ret.isEmpty())
            Q_EMIT stream->resourcesFound(ret);
        stream->finish();
    }
```

#### AUTO 


```{c}
const auto cats = m_filteredCategory ? m_filteredCategory->subCategories().toList() : CategoryModel::rootCategories();
```

#### AUTO 


```{c}
auto r = m_resources.value(idForInstalledRef(flatpakInstallation, ref, {}));
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            bool found = DiscoverBackendsFactory::hasRequestedBackends();
            const auto backends = ResourcesModel::global()->backends();
            for (auto b : backends)
                found |= b->hasApplications();

            if (!found)
                Q_EMIT openErrorPage(i18n("No application back-ends found, please report to your distribution."));
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, installation, fw]() {
        g_autoptr(GPtrArray) refs = fw->result();
        if (refs)
            onFetchUpdatesFinished(installation, refs);
        fw->deleteLater();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto res : resources) {
        data += itemDataToMap(res, m_exculdedProperties);
    }
```

#### AUTO 


```{c}
auto process = checkAptVariable(aptconfig, QLatin1String("Apt::Periodic::Update-Package-Lists"), [regularCheck](const QStringRef& value) {
            bool ok;
            int time = value.toInt(&ok);
            if (ok && time > 0)
                regularCheck->setInterval(time * 60 * 60 * 1000);
            else
                qWarning() << "couldn't understand value for timer:" << value;
        });
```

#### AUTO 


```{c}
const auto it = m_sources->item(i, 0);
```

#### AUTO 


```{c}
auto parts = ref.split('/');
```

#### AUTO 


```{c}
auto histo = histogram.midRef(1,histogram.size()-2).split(QStringLiteral(", "));
```

#### AUTO 


```{c}
auto iter = transaction->addons().constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for(QApt::Package* it : pkgList) {
            AbstractResource* res = m_appBackend->resourceByPackageName(it->name());
            if(!res) //If we couldn't find it by its name, try with
                res = m_appBackend->resourceByPackageName(QString("%1:%2").arg(it->name()).arg(it->architecture()));
            Q_ASSERT(res);
            ret += res;
        }
```

#### AUTO 


```{c}
auto mAboutAppAction = KStandardAction::aboutApp(this, SLOT(aboutApplication()), this);
```

#### LAMBDA EXPRESSION 


```{c}
[](BackendNotifierModule* module) { return module->hasSecurityUpdates(); }
```

#### AUTO 


```{c}
auto x = qScopeGuard([path] {
        QDir(path).removeRecursively();
    });
```

#### AUTO 


```{c}
auto runtime = getRuntimeForApp(resource);
```

#### AUTO 


```{c}
auto id2 = idForInstalledRef(installation, ref, QStringLiteral(".desktop"));
```

#### AUTO 


```{c}
auto changes = m_aptBackend->stateChanges(cache, QApt::PackageList());
```

#### LAMBDA EXPRESSION 


```{c}
[stream, this, state](SnapJob* job) {
        if (!job->isSuccessful()) {
            stream->finish();
            return;
        }

        const auto snaps = job->result().toArray();

        QVector<AbstractResource*> ret;
        QSet<SnapResource*> resources;
        for(const auto& snap: snaps) {
            const auto snapObj = snap.toObject();
            const auto snapid = snapObj.value(QLatin1String("name")).toString();
            SnapResource* res = m_resources.value(snapid);
            if (!res) {
                res = new SnapResource(snapObj, state, this);
                Q_ASSERT(res->packageName() == snapid);
                resources += res;
            }
            ret += res;
        }

        if (!resources.isEmpty()) {
            foreach(SnapResource* res, resources)
                m_resources[res->packageName()] = res;
        }
        if (!ret.isEmpty())
            stream->resourcesFound(ret);
        stream->finis();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, appstreamIds, stream]() {
                AbstractResource *pkg = nullptr;

                QStringList allAppStreamIds = appstreamIds;
                {
                    auto it = deprecatedAppstreamIds.constFind(appstreamIds.first());
                    if (it != deprecatedAppstreamIds.constEnd()) {
                        allAppStreamIds << *it;
                    }
                }

                for (auto it = m_packages.packages.constBegin(), itEnd = m_packages.packages.constEnd(); it != itEnd; ++it) {
                    const bool matches = kContains(allAppStreamIds, [&it](const QString &id) {
                        static const QLatin1String desktopPostfix(".desktop");
                        return it.key().compare(id, Qt::CaseInsensitive) == 0 ||
                            // doing (id == id.key()+".desktop") without allocating
                            (id.size() == (desktopPostfix.size() + it.key().size()) && id.endsWith(desktopPostfix)
                             && id.startsWith(it.key(), Qt::CaseInsensitive));
                    });
                    if (matches) {
                        pkg = it.value();
                        break;
                    }
                }
                if (pkg)
                    stream->setResources({pkg});
                stream->finish();
                //         if (!pkg)
                //             qCDebug(LIBDISCOVER_BACKEND_LOG) << "could not find" << host << deprecatedHost;
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            setApplication(nullptr);
        }
```

#### AUTO 


```{c}
auto iter = m_transQueue.constBegin();
```

#### AUTO 


```{c}
auto it = content.constBegin(), itEnd = content.constEnd();
```

#### LAMBDA EXPRESSION 


```{c}
[stream, resources] () {
                Q_EMIT stream->resourcesFound(resources);
            }
```

#### AUTO 


```{c}
const auto cats = *s_categories;
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
                Q_EMIT m_backend->resourcesChanged(this, {"size", "homepage", "license"});
            }
```

#### AUTO 


```{c}
auto resources = getResources(m_backend->findResourceByPackageName(url));
```

#### RANGE FOR STATEMENT 


```{c}
for (auto res : newCandidates) {
            connect(res, &AbstractResource::sizeChanged, this, &SystemUpgrade::refreshResource);
        }
```

#### AUTO 


```{c}
auto updatesAction = menu->addAction(QIcon::fromTheme(QStringLiteral("system-software-update")), i18n("See Updates�"));
```

#### AUTO 


```{c}
auto search = new OneTimeAction([this]() {
        // First we ensure we've got data loaded on what we've got installed already
        Q_EMIT startingSearch();
        m_onePage = true;
        m_responsePending = true;
        m_engine->checkForInstalled();
        // And then we check for updates - we could do only one, if all we cared about was updates,
        // but to have both a useful initial list, /and/ information on updates, we want to get both.
        // The reason we are not doing a checkUpdates() overload for this is that the caching for this
        // information is done by KNSEngine, and we want to actually load it every time we initialize.
        auto updateChecker = new OneTimeAction([this]() {
            Q_EMIT startingSearch();
            m_onePage = true;
            m_responsePending = true;
            m_engine->checkForUpdates();
        }, this);
        connect(this, &KNSBackend::availableForQueries, updateChecker, &OneTimeAction::trigger, Qt::QueuedConnection);
    }, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractResourcesBackend *backend : backends) {
        if(!m_appBackend &&
            backend->metaObject()->className()==QLatin1String("ApplicationBackend"))
        {
            m_appBackend = backend;
            connect(m_appBackend, SIGNAL(backendReady()), SLOT(populateViews()));
            connect(m_appBackend, SIGNAL(reloadFinished()), SLOT(showLauncherMessage()));
            connect(m_appBackend, SIGNAL(sourcesEditorFinished()), SLOT(sourcesEditorFinished()));
            populateViews();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto& rel: m_appdata.releases()) {
        changelog += QStringLiteral("<h3>") + rel.version() + QStringLiteral("</h3>");
        changelog += QStringLiteral("<p>") + rel.description() + QStringLiteral("</p>");
    }
```

#### AUTO 


```{c}
const auto iconName = knsrcPlasma.contains(fileName)? QStringLiteral("plasma") : QStringLiteral("applications-other");
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        // First we ensure we've got data loaded on what we've got installed already
        Q_EMIT startingSearch();
        m_onePage = true;
        m_responsePending = true;
        m_engine->checkForInstalled();
        // And then we check for updates - we could do only one, if all we cared about was updates,
        // but to have both a useful initial list, /and/ information on updates, we want to get both.
        // The reason we are not doing a checkUpdates() overload for this is that the caching for this
        // information is done by KNSEngine, and we want to actually load it every time we initialize.
        auto updateChecker = new OneTimeAction([this]() {
            Q_EMIT startingSearch();
            m_onePage = true;
            m_responsePending = true;
            m_engine->checkForUpdates();
        }, this);
        connect(this, &KNSBackend::availableForQueries, updateChecker, &OneTimeAction::trigger, Qt::QueuedConnection);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const int rating : ratings)
            tot_ratings = rating + tot_ratings;
```

#### LAMBDA EXPRESSION 


```{c}
[this](PackageKit::Transaction::Error err, const QString & error) { qWarning() << "error fetching updates:" << err << error; emit changelogFetched(QString()); }
```

#### AUTO 


```{c}
const auto &filter
```

#### AUTO 


```{c}
auto action = new OneTimeAction(
        [this]() {
            bool found = DiscoverBackendsFactory::hasRequestedBackends();
            const auto backends = ResourcesModel::global()->backends();
            for (auto b : backends)
                found |= b->hasApplications();

            if (!found)
                Q_EMIT openErrorPage(i18n("No application back-ends found, please report to your distribution."));
        }
        , this);
```

#### LAMBDA EXPRESSION 


```{c}
[servicePath](){
        bool b = QProcess::startDetached(QStringLiteral(CMAKE_INSTALL_FULL_LIBEXECDIR_KF5 "/discover/runservice"), {servicePath});
        if (!b)
            qWarning() << "Could not start" << servicePath;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        m_currentStream = nullptr;
        Q_EMIT busyChanged(false);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, url]() {
            AbstractResourcesBackend::Filters f;
            f.resourceUrl = url;
            auto stream = new StoredResultsStream({ResourcesModel::global()->search(f)});
            connect(stream, &StoredResultsStream::finishedResources, this, [this, url](const QVector<AbstractResource *> &res) {
                if (res.count() >= 1) {
                    Q_EMIT openApplicationInternal(res.first());
                } else if (url.scheme() == QLatin1String("snap")) {
                    openApplication(QUrl(QStringLiteral("appstream://org.kde.discover.snap")));
                    showPassiveNotification(i18n("Please make sure Snap support is installed"));
                } else {
                    Q_EMIT openErrorPage(
                        i18n("Could not open %1 because it was not found in any "
                             "available software repositories. Please report this "
                             "issue to the packagers of your distribution.",
                             url.toDisplayString()));
                }
            });
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &appstreamId) {
                    return resourcesByAppstreamName(appstreamId);
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this, stream] {
            auto fw = new QFutureWatcher<QHash<FlatpakInstallation *, QVector<FlatpakInstalledRef *>>>(this);
            connect(fw, &QFutureWatcher<QByteArray>::finished, this, [this, fw, stream]() {
                if (g_cancellable_is_cancelled(m_cancellable)) {
                    stream->finish();
                    fw->deleteLater();
                    return;
                }

                const auto refs = fw->result();
                QVector<AbstractResource *> resources;
                for (auto it = refs.constBegin(), itEnd = refs.constEnd(); it != itEnd; ++it) {
                    resources.reserve(resources.size() + it->size());
                    for (auto ref : qAsConst(it.value())) {
                        bool fresh;
                        auto resource = getAppForInstalledRef(it.key(), ref, &fresh);
#if FLATPAK_CHECK_VERSION(1, 1, 2)
                        resource->setAvailableVersion(QString::fromUtf8(flatpak_installed_ref_get_appdata_version(ref)));
#endif
                        g_object_unref(ref);
                        resource->setState(AbstractResource::Upgradeable, !fresh);
                        updateAppSize(resource);
                        if (resource->resourceType() == FlatpakResource::Runtime) {
                            resources.prepend(resource);
                        } else {
                            resources.append(resource);
                        }
                    }
                }

                if (!resources.isEmpty())
                    Q_EMIT stream->resourcesFound(resources);
                stream->finish();
                fw->deleteLater();
            });

            QVector<FlatpakInstallation *> installations = m_installations;
            auto cancellable = m_cancellable;
            fw->setFuture(QtConcurrent::run(&m_threadPool, [installations, cancellable] {
                QHash<FlatpakInstallation *, QVector<FlatpakInstalledRef *>> ret;

                for (auto installation : installations) {
                    g_autoptr(GError) localError = nullptr;
                    g_autoptr(GPtrArray) refs = flatpak_installation_list_installed_refs_for_update(installation, cancellable, &localError);
                    if (!refs) {
                        qWarning() << "Failed to get list of installed refs for listing updates:" << localError->message;
                        continue;
                    }
                    if (g_cancellable_is_cancelled(cancellable)) {
                        qWarning() << "Job cancelled";
                        return ret;
                    }

                    auto &current = ret[installation];
                    current.reserve(refs->len);
                    for (uint i = 0; i < refs->len; i++) {
                        FlatpakInstalledRef *ref = FLATPAK_INSTALLED_REF(g_ptr_array_index(refs, i));
                        g_object_ref(ref);
                        current.append(ref);
                    }
                }
                return ret;
            }));
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, fw, flatpakInstallation, appstreamIconsPath, sourceName]() {
        const auto components = fw->result();
        QVector<FlatpakResource *> resources;
        for (const AppStream::Component &appstreamComponent : components) {
            FlatpakResource *resource = new FlatpakResource(appstreamComponent, flatpakInstallation, this);
            resource->setIconPath(appstreamIconsPath);
            resource->setOrigin(sourceName);
            if (resource->resourceType() == FlatpakResource::Runtime) {
                resources.prepend(resource);
            } else {
                resources.append(resource);
            }
        }
        for (auto resource : qAsConst(resources)) {
            addResource(resource);
        }

        metadataRefreshed();
        acquireFetching(false);
        fw->deleteLater();
    }
```

#### AUTO 


```{c}
auto f = [this, stream] {
            auto fw = new QFutureWatcher<QHash<FlatpakInstallation *, QVector<FlatpakInstalledRef *>>>(this);
            connect(fw, &QFutureWatcher<QByteArray>::finished, this, [this, fw, stream]() {
                if (g_cancellable_is_cancelled(m_cancellable)) {
                    stream->finish();
                    fw->deleteLater();
                    return;
                }

                const auto refs = fw->result();
                QVector<AbstractResource *> resources;
                for (auto it = refs.constBegin(), itEnd = refs.constEnd(); it != itEnd; ++it) {
                    resources.reserve(resources.size() + it->size());
                    for (auto ref : qAsConst(it.value())) {
                        bool fresh;
                        auto resource = getAppForInstalledRef(it.key(), ref, &fresh);
#if FLATPAK_CHECK_VERSION(1, 1, 2)
                        resource->setAvailableVersion(QString::fromUtf8(flatpak_installed_ref_get_appdata_version(ref)));
#endif
                        g_object_unref(ref);
                        resource->setState(AbstractResource::Upgradeable, !fresh);
                        updateAppSize(resource);
                        if (resource->resourceType() == FlatpakResource::Runtime) {
                            resources.prepend(resource);
                        } else {
                            resources.append(resource);
                        }
                    }
                }

                if (!resources.isEmpty())
                    Q_EMIT stream->resourcesFound(resources);
                stream->finish();
                fw->deleteLater();
            });

            QVector<FlatpakInstallation *> installations = m_installations;
            auto cancellable = m_cancellable;
            fw->setFuture(QtConcurrent::run(&m_threadPool, [installations, cancellable] {
                QHash<FlatpakInstallation *, QVector<FlatpakInstalledRef *>> ret;

                for (auto installation : installations) {
                    g_autoptr(GError) localError = nullptr;
                    g_autoptr(GPtrArray) refs = flatpak_installation_list_installed_refs_for_update(installation, cancellable, &localError);
                    if (!refs) {
                        qWarning() << "Failed to get list of installed refs for listing updates:" << localError->message;
                        continue;
                    }
                    if (g_cancellable_is_cancelled(cancellable)) {
                        qWarning() << "Job cancelled";
                        return ret;
                    }

                    auto &current = ret[installation];
                    current.reserve(refs->len);
                    for (uint i = 0; i < refs->len; i++) {
                        FlatpakInstalledRef *ref = FLATPAK_INSTALLED_REF(g_ptr_array_index(refs, i));
                        g_object_ref(ref);
                        current.append(ref);
                    }
                }
                return ret;
            }));
        };
```

#### AUTO 


```{c}
auto addonsCategory = new Category(topLevelName, QStringLiteral("plasma"), filters, backendName, {actualCategory}, decoration, true);
```

#### LAMBDA EXPRESSION 


```{c}
[path] {
        QDir(path).removeRecursively();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, stream, app](const QVector<AbstractResource*> &resources) {
                if (!resources.isEmpty()) {
                    if (resources.size() > 1)
                        qWarning() << "many resources found for" << app;
                    emit openApplicationInternal(resources.first());
                } else {
                    rootObject()->setProperty("defaultStartup", true);
                    showPassiveNotification(i18n("Couldn't open %1", app.toDisplayString()));
                }
            }
```

#### AUTO 


```{c}
auto x = qobject_cast<AggregatedResultsStream *>(stream)
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &cat: categories) {
        const QString catName = cat->name().append(QLatin1Char('/'));
        for (const auto& potentialSubCat: categories) {
            if(potentialSubCat->name().startsWith(catName)) {
                cat->addSubcategory(potentialSubCat);
                topCategories.removeOne(potentialSubCat);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto res: upgradeablePackages()) {
        const auto packageName = res->packageName();
        if (packages.contains(packageName)) {
            continue;
        }
        packages.insert(packageName);
        ret += 1;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto upd : m_updaters) {
        if (upd->needsReboot())
            return true;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() { updatePlugState(job->isPlugged()); }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QJsonValue &val) {
                return val.toString();
            }
```

#### LAMBDA EXPRESSION 


```{c}
[&resources](const QVector<AbstractResource*>& res) { resources += res; }
```

#### AUTO 


```{c}
const auto desktopFiles = kFilter<QStringList>(filenames, [locations](const QString &exe) {
                    for (const auto &location : locations) {
                        if (exe.startsWith(location))
                            return exe.contains(QLatin1String(".desktop"));
                    }
                    return false;
                });
```

#### RANGE FOR STATEMENT 


```{c}
for(const QVariant& act: theActions) {
        QAction* action = qobject_cast<QAction*>(act.value<QObject*>());
        if (action->objectName() == id) {
            action->setEnabled(false);
            action->setVisible(false);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Category *nc : subCategories) {
                addSubcategory(c->m_subCategories, nc);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QAction* action){ return action->priority() == m_priority; }
```

#### AUTO 


```{c}
auto refreshAction = menu->addAction(QIcon::fromTheme(QStringLiteral("view-refresh")), i18n("Restart..."));
```

#### AUTO 


```{c}
const auto cab = ResourcesModel::global()->currentApplicationBackend();
```

#### RANGE FOR STATEMENT 


```{c}
for (QApt::Package *package : packages) {
            item = new QStandardItem;
            item->setText(package->name());
            item->setEditable(false);
            item->setIcon(KIcon("muon"));

            root->appendRow(item);
        }
```

#### AUTO 


```{c}
auto service = locateService(QStringLiteral("software-properties-kde.desktop"));
```

#### AUTO 


```{c}
auto ret = flatpak_installation_fetch_remote_ref_sync_full(app->installation(), origin.constData(), kind, name.constData(), arch.constData(), branch.constData(), FLATPAK_QUERY_FLAGS_ONLY_CACHED, cancellable, &localError);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto source : qAsConst(m_flatpakLoadingSources)) {
        if (source->url() == flatpak_remote_get_url(remote) && source->installation() == flatpakInstallation
            && source->name() == flatpak_remote_get_name(remote)) {
            createPool(source);
            return source;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto item : qAsConst(m_updateItems)) {
                item->setProgress(0);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this, url]() {
            AbstractResourcesBackend::Filters f;
            f.resourceUrl = url;
            auto stream = new StoredResultsStream({ResourcesModel::global()->search(f)});
            connect(stream, &StoredResultsStream::finishedResources, this, [this, url](const QVector<AbstractResource *> &res) {
                if (res.count() >= 1) {
                    Q_EMIT openApplicationInternal(res.first());
                } else if (url.scheme() == QLatin1String("snap")) {
                    openApplication(QUrl(QStringLiteral("appstream://org.kde.discover.snap")));
                    showPassiveNotification(i18n("Please make sure Snap support is installed"));
                } else {
                    Q_EMIT openErrorPage(i18n("Could not open %1", url.toDisplayString()));
                }
            });
        }
```

#### AUTO 


```{c}
auto mHandBookAction = KStandardAction::helpContents(this, SLOT(appHelpActivated()), this);
```

#### LAMBDA EXPRESSION 


```{c}
[this, stream] {
            const auto toResolve = kFilter<QVector<AbstractResource*>>(m_packages.packages, needsResolveFilter);

            if (!toResolve.isEmpty()) {
                resolvePackages(kTransform<QStringList>(toResolve, [] (AbstractResource* res) { return res->packageName(); }));
                connect(m_resolveTransaction, &PKResolveTransaction::allFinished, this, [stream, toResolve] {
                    const auto resolved = kFilter<QVector<AbstractResource*>>(toResolve, installedFilter);
                    if (!resolved.isEmpty())
                        Q_EMIT stream->resourcesFound(resolved);
                    stream->finish();
                });
            }

            const auto resolved = kFilter<QVector<AbstractResource*>>(m_packages.packages, installedFilter);
            if (!resolved.isEmpty()) {
                QTimer::singleShot(0, this, [resolved, toResolve, stream] () {
                    if (!resolved.isEmpty())
                        Q_EMIT stream->resourcesFound(resolved);

                    if (toResolve.isEmpty())
                        stream->finish();
            });
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[func] {
            func();
            return true;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, localfile, stream]() {
                const auto res = stream->resources();
                if (res.count() == 1) {
                    emit openApplicationInternal(res.first());
                } else {
                    QMimeDatabase db;
                    auto mime = db.mimeTypeForUrl(localfile);
                    auto fIsFlatpakBackend = [](AbstractResourcesBackend* backend) { return backend->metaObject()->className() == QByteArray("FlatpakBackend"); };
                    if (mime.name().startsWith(QLatin1String("application/vnd.flatpak")) && !kContains(ResourcesModel::global()->backends(), fIsFlatpakBackend)) {
                        openApplication(QUrl(QStringLiteral("appstream://org.kde.discover.flatpak")));
                        showPassiveNotification(i18n("Cannot interact with flatpak resources without the flatpak backend %1. Please install it first.", localfile.toDisplayString()));
                    } else {
                        setRootObjectProperty("defaultStartup", true);
                        showPassiveNotification(i18n("Couldn't open %1", localfile.toDisplayString()));
                    }
                }
            }
```

#### AUTO 


```{c}
auto fw = new QFutureWatcher<QJsonDocument>(this);
```

#### RANGE FOR STATEMENT 


```{c}
for(auto pkgList : changes.values()) {
        for(QApt::Package* it : pkgList) {
            AbstractResource* res = m_appBackend->resourceByPackageName(it->name());
            if(!res) //If we couldn't find it by its name, try with
                res = m_appBackend->resourceByPackageName(QString("%1:%2").arg(it->name()).arg(it->architecture()));
            Q_ASSERT(res);
            m_toUpdate += res;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, url, stream]() {
                const auto res = stream->resources();
                if (res.count() == 1) {
                    emit openApplicationInternal(res.first());
                } else {
                    setRootObjectProperty("defaultStartup", true);
                    showPassiveNotification(i18n("Couldn't open %1", url.toDisplayString()));
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this, url](const QVector<AbstractResource *> &res) {
                if (res.count() >= 1) {
                    Q_EMIT openApplicationInternal(res.first());
                } else if (url.scheme() == QLatin1String("snap")) {
                    openApplication(QUrl(QStringLiteral("appstream://org.kde.discover.snap")));
                    showPassiveNotification(i18n("Please make sure Snap support is installed"));
                } else {
                    Q_EMIT openErrorPage(
                        i18n("Could not open %1 because it was not found in any "
                             "available software repositories. Please report this "
                             "issue to the packagers of your distribution.",
                             url.toDisplayString()));
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this] { acquireFetching(false); }
```

#### AUTO 


```{c}
const auto res = kFilter<QVector<AppPackageKitResource *>>(backend()->extendedBy(m_appdata.id()), [this](AppPackageKitResource *r) {
        return r->allPackageNames() != allPackageNames();
    });
```

#### AUTO 


```{c}
const auto packageServices = kFilter<QStringList>(allServices, [filenames](const QString &file) {
                return filenames.contains(file);
            });
```

#### AUTO 


```{c}
auto toremoveOrig = m_packagesModified.value(PackageKit::Transaction::InfoRemoving);
```

#### AUTO 


```{c}
auto iter = m_transQueue.begin();
```

#### AUTO 


```{c}
const auto resources = fetchResources(m_appBackend->search({}));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& name : backendNames) {
        QString file = KGlobal::dirs()->findResource("data", "libmuon/categories/"+name+"-categories.xml");
        if (file.isEmpty()) {
            qWarning() << "Couldn't find a category for " << name;
            continue;
        }
        QList<Category*> cats = loadCategoriesFile(file);

        if(ret.isEmpty()) {
            ret += cats;
        } else {
            for(Category* c : cats)
                Category::addSubcategory(ret, c);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (FlatpakResource* res : m_resources) {
        if (QString::compare(res->appstreamId(), name, Qt::CaseInsensitive)==0 || QString::compare(res->appstreamId(), nameWithDesktop, Qt::CaseInsensitive)==0)
            resources << res;
        else {
            const auto alts = res->alternativeAppstreamIds();
            for (const auto &alt : alts) {
                if (QString::compare(alt, name, Qt::CaseInsensitive)==0 || QString::compare(alt, nameWithDesktop, Qt::CaseInsensitive)==0) {
                    resources << res;
                    break;
                }
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](AbstractResource *res) {
                    return static_cast<PackageKitResource *>(res)->isCritical();
                }
```

#### AUTO 


```{c}
auto value = futureWatcher->result();
```

#### AUTO 


```{c}
auto instances = f->newInstance(ResourcesModel::global(), name);
```

#### LAMBDA EXPRESSION 


```{c}
[](const QSharedPointer<QSnapdSnap>&){ return true; }
```

#### AUTO 


```{c}
const auto ids = m_reviews->appstreamIds().toSet();
```

#### RANGE FOR STATEMENT 


```{c}
for(QApt::Package* it : pkgList) {
            AbstractResource* res = m_appBackend->resourceByPackageName(it->name());
            if(!res) //If we couldn't find it by its name, try with
                res = m_appBackend->resourceByPackageName(QString("%1:%2").arg(it->name()).arg(it->architecture()));
            if(!res)
                qWarning() << "Couldn't find the package:" << it->name();
            Q_ASSERT(res);
            m_toUpdate += res;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, category]() {
            Category* cat = CategoryModel::global()->findCategoryByName(category);
            if (cat) {
                emit listCategoryInternal(cat);
            } else {
                showPassiveNotification(i18n("Could not find category '%1'", category));
                setRootObjectProperty("defaultStartup", true);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &toInstall : addonsToInstall) {
        setAddonInstalled(toInstall, true);
    }
```

#### AUTO 


```{c}
auto appk = qobject_cast<AppPackageKitResource*>(app);
```

#### AUTO 


```{c}
const auto resources = kAppend<QVector<AbstractResource*>>(appstreamIds, [this] (const QString &appstreamId) { return resourcesByAppstreamName(appstreamId); });
```

#### LAMBDA EXPRESSION 


```{c}
[packageDependencies](PackageKit::Transaction::Info /*info*/, const QString &packageID, const QString &/*summary*/) {
        (*packageDependencies)[packageID] += 1;
    }
```

#### AUTO 


```{c}
const auto name = (*it)->backend()->metaObject()->className();
```

#### LAMBDA EXPRESSION 


```{c}
[this, res]() {
            auto engine = res->knsBackend()->engine();
            if (this->role() == InstallRole)
                engine->install(res->entry());
            else if(this->role() == RemoveRole)
                engine->uninstall(res->entry());
        }
```

#### AUTO 


```{c}
auto action = new OneTimeAction(
        [this, url]() {
            AbstractResourcesBackend::Filters f;
            f.resourceUrl = url;
            auto stream = new StoredResultsStream({ResourcesModel::global()->search(f)});
            connect(stream, &StoredResultsStream::finished, this, [this, url, stream]() {
                const auto res = stream->resources();
                if (res.count() == 1) {
                    emit openApplicationInternal(res.first());
                } else {
                    rootObject()->setProperty("defaultStartup", true);
                    Q_EMIT openErrorPage(i18n("Couldn't open %1", url.toDisplayString()));
                }
            });
        }
        , this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &v : input) {
        ret.append(op(v));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString& file : files) {
        QList<Category*> cats = loadCategoriesFile(file);
        if(ret.isEmpty())
            ret += cats;
        else {
            for(Category* c : cats)
                addSubcategory(ret, c);
        }
    }
```

#### AUTO 


```{c}
auto stream
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractBackendUpdater *upd : updaters) {
            QMetaObject::invokeMethod(upd, &AbstractBackendUpdater::start, Qt::QueuedConnection);
        }
```

#### AUTO 


```{c}
auto fu = device->read(number);
```

#### AUTO 


```{c}
const auto resolved = kFilter<QVector<AbstractResource *>>(m_packages.packages, installedAndNameFilter);
```

#### AUTO 


```{c}
auto f = [this, stream] {
            auto fw = new QFutureWatcher<QMap<FlatpakInstallation *, QVector<FlatpakInstalledRef *>>>(this);
            connect(fw, &QFutureWatcher<QByteArray>::finished, this, [this, fw, stream]() {
                if (g_cancellable_is_cancelled(m_cancellable)) {
                    stream->finish();
                    fw->deleteLater();
                    return;
                }

                const auto refs = fw->result();
                QVector<AbstractResource *> resources;
                for (auto it = refs.constBegin(), itEnd = refs.constEnd(); it != itEnd; ++it) {
                    resources.reserve(resources.size() + it->size());
                    for (auto ref : qAsConst(it.value())) {
                        auto resource = getAppForInstalledRef(it.key(), ref);
                        g_object_unref(ref);
                        resource->setState(AbstractResource::Upgradeable);
                        updateAppSize(resource);
                        if (resource->resourceType() == FlatpakResource::Runtime) {
                            resources.prepend(resource);
                        } else {
                            resources.append(resource);
                        }
                    }
                }

                if (!resources.isEmpty())
                    Q_EMIT stream->resourcesFound(resources);
                stream->finish();
                fw->deleteLater();
            });

            QVector<FlatpakInstallation *> installations = m_installations;
            auto cancellable = m_cancellable;
            fw->setFuture(QtConcurrent::run(&m_threadPool, [installations, cancellable] {
                QMap<FlatpakInstallation *, QVector<FlatpakInstalledRef *>> ret;

                for (auto installation : installations) {
                    g_autoptr(GError) localError = nullptr;
                    g_autoptr(GPtrArray) refs = flatpak_installation_list_installed_refs_for_update(installation, cancellable, &localError);
                    if (!refs) {
                        qWarning() << "Failed to get list of installed refs for listing updates:" << localError->message;
                        continue;
                    }
                    if (g_cancellable_is_cancelled(cancellable)) {
                        qWarning() << "Job cancelled";
                        return ret;
                    }

                    auto &current = ret[installation];
                    current.reserve(refs->len);
                    for (uint i = 0; i < refs->len; i++) {
                        FlatpakInstalledRef *ref = FLATPAK_INSTALLED_REF(g_ptr_array_index(refs, i));
                        g_object_ref(ref);
                        current.append(ref);
                    }
                }
                return ret;
            }));
        };
```

#### RANGE FOR STATEMENT 


```{c}
for(const Appstream::Component& component: m_appdata.allComponents()) {
        m_updatingPackages[component.id()] = new AppPackageKitResource(component, this);
        foreach (const QString& pkg, component.packageNames()) {
            m_updatingTranslationPackageToApp[pkg] += component.id();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, resource] {
        if (!isFetching())
            Q_EMIT resourcesChanged(resource, {"size", "sizeDescription"});
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString &name) {
            comps = m_pool->componentsById(name);
            if (!comps.isEmpty())
                return;

            comps = m_pool->componentsByProvided(AppStream::Provided::KindId, name);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const PackageState &addon : m_availableAddons) {
        // Check if we have an application for the addon
        AbstractResource *addonResource = 0;

        for (AbstractResource *resource : m_resource->backend()->allResources()) {
            if (!resource)
                continue;

            if (resource->packageName() == addon.name()) {
                addonResource = resource;
                break;
            }
        }

        QStandardItem *addonItem = new QStandardItem;
        addonItem->setData(addon.name());
        QString resourceName = QLatin1String(" (") % addon.name() % ')';
        if (addonResource) {
            addonItem->setText(addonResource->name() % resourceName);
            addonItem->setIcon(QIcon::fromTheme(addonResource->icon()));
        } else {
            addonItem->setText(addon.description() % resourceName);
            addonItem->setIcon(QIcon::fromTheme("applications-other"));
        }

        addonItem->setEditable(false);
        addonItem->setCheckable(true);

        if (addon.isInstalled()) {
            addonItem->setCheckState(Qt::Checked);
        } else {
            addonItem->setCheckState(Qt::Unchecked);
        }

        m_addonsModel->appendRow(addonItem);
    }
```

#### AUTO 


```{c}
auto actualCategory = new Category(m_displayName, QStringLiteral("plasma"), filters, backendName, categories, QUrl(), false);
```

#### AUTO 


```{c}
auto refreshAction = menu->addAction(QIcon::fromTheme(QStringLiteral("view-refresh")), i18n("Refresh..."));
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        m_reviews->emitRatingFetched(this, kTransform<QList<AbstractResource*>>(m_resources, [] (AbstractResource* r) { return r; }));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        m_reviews->emitRatingFetched(this, kTransform<QList<AbstractResource*>>(m_resources.values(), [] (AbstractResource* r) { return r; }));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto res : resources) {
            const auto versions = res->upgradeText();
            const auto idx = versions.indexOf(u'\u009C');
            changes += QStringLiteral("<li>") + res->packageName() + QStringLiteral(": ") + versions.leftRef(idx) + QStringLiteral("</li>\n");
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](bool b){ if(!b) QCoreApplication::instance()->quit(); }
```

#### AUTO 


```{c}
auto name = QString::fromUtf8(suggested_remote_name);
```

#### AUTO 


```{c}
const auto numberString = device->readLine().trimmed();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            recheckSystemUpdateNeeded();
            delete m_refresher;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[] () {
        QDBusInterface interface(QStringLiteral("org.kde.ksmserver"), QStringLiteral("/KSMServer"), QStringLiteral("org.kde.KSMServerInterface"), QDBusConnection::sessionBus());
        interface.asyncCall(QStringLiteral("logout"), 0, 1, 2); // Options: do not ask again | reboot | force
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &archive : m_package->archives()) {
        if (archive.contains(QLatin1String("security"))) {
            return true;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, fw]() {
        m_fetching = true;
        emit fetchingChanged();

        auto devices = fw->result();
        for(uint i = 0; devices && i < devices->len; i++) {
            FwupdDevice *device = (FwupdDevice *) g_ptr_array_index(devices, i);

            if (!fwupd_device_has_flag (device, FWUPD_DEVICE_FLAG_SUPPORTED))
                continue;

            g_autoptr(GError) error = nullptr;
            g_autoptr(GPtrArray) releases = fwupd_client_get_releases(client, fwupd_device_get_id(device), nullptr, &error);

            if (error) {
                if (g_error_matches(error, FWUPD_ERROR, FWUPD_ERROR_INVALID_FILE)) {
                    continue;
                }

                handleError(error);
            }

            auto res = createDevice(device);
            for (uint i=0; releases && i<releases->len; ++i) {
                FwupdRelease *release = (FwupdRelease *)g_ptr_array_index(releases, i);
                if (res->installedVersion().toUtf8() == fwupd_release_get_version(release)) {
                    res->setReleaseDetails(release);
                    break;
                }
            }
            addResourceToList(res);
        }
        g_ptr_array_unref(devices);

        addUpdates();

        m_fetching = false;
        emit fetchingChanged();
        emit initialized();
        fw->deleteLater();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString& file : dir.entryList(QDir::Files)) {
            QString fullPath = dir.absoluteFilePath(file);
            QPluginLoader loader(fullPath);
            ret += qobject_cast<BackendNotifierModule*>(loader.instance());
            if (ret.last() == nullptr) {
                qWarning() << "couldn't load" << fullPath << "because" << loader.errorString();
                ret.removeLast();
            }
        }
```

#### AUTO 


```{c}
auto repo = flatpak_installation_get_remote_by_name(resource->installation(), flatpak_remote_get_name(remote), m_cancellable, nullptr);
```

#### AUTO 


```{c}
auto res = search.scheme() == QLatin1String("dummy") ? m_resources.value(search.host().replace(QLatin1Char('.'), QLatin1Char(' '))) : nullptr;
```

#### RANGE FOR STATEMENT 


```{c}
for (auto app : m_apps) {
                    qCDebug(LIBDISCOVER_BACKEND_LOG) << "app" << app << app->state();
                }
```

#### RANGE FOR STATEMENT 


```{c}
for(QAction *action: actions()) {
        if (action->toolTip() == id) {
            action->setEnabled(false);
            action->setVisible(false);
        }
    }
```

#### AUTO 


```{c}
const auto summary = m_appdata->summary();
```

#### LAMBDA EXPRESSION 


```{c}
[this, stream, filter] () {
        QVector<AbstractResource*> ret;
        foreach(auto r, m_resources) {
            if (r->type() == AbstractResource::Technical && filter.state != AbstractResource::Upgradeable) {
                continue;
            }

            if (r->state() < filter.state)
                continue;

            if (!filter.extends.isEmpty() && !r->extends().contains(filter.extends))
                continue;

            if (filter.search.isEmpty() || r->name().contains(filter.search, Qt::CaseInsensitive) || r->comment().contains(filter.search, Qt::CaseInsensitive)) {
                ret += r;
            }
        }
        auto f = [this](AbstractResource* l, AbstractResource* r) { return flatpakResourceLessThan(l,r); };
        std::sort(ret.begin(), ret.end(), f);
        if (!ret.isEmpty())
            Q_EMIT stream->resourcesFound(ret);
        stream->finish();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[cancel, t, this](PackageKit::Transaction::Exit /*status*/, uint /*runtime*/){
        QMap<PackageKit::Transaction::Info, QStringList> packages = t->property("packages").value<QMap<PackageKit::Transaction::Info, QStringList>>();
        auto pkr = qobject_cast<PackageKitResource*>(resource());
        pkr->setPackages(packages);
        setStatus(Transaction::DoneStatus);
        if (cancel)
            pkr->backend()->transactionCanceled(this);
        else
            pkr->backend()->removeTransaction(this);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto r : releases) {
                int cmp = AppStream::Utils::vercmpSimple(r.version(), AppStreamIntegration::global()->osRelease()->versionId());
                if (cmp == 0) {
                    // Ignore (likely) empty date_eol entries that are parsed as the UNIX Epoch
                    if (r.timestampEol().isNull() || r.timestampEol().toSecsSinceEpoch() == 0) {
                        continue;
                    }
                    if (r.timestampEol() < QDateTime::currentDateTime()) {
                        const QString releaseDate = QLocale().toString(r.timestampEol());
                        Q_EMIT inlineMessage(InlineMessageType::Warning,
                                             QStringLiteral("dialog-warning"),
                                             i18nc("%1 is the date as formatted by the locale",
                                                   "Your operating system ended support on %1. Consider upgrading to a supported version.",
                                                   releaseDate));
                    }
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { Q_EMIT finishedResources(m_resources); }
```

#### LAMBDA EXPRESSION 


```{c}
[this, resource, fw]() {
            const auto metadata = fw->result();
            if (!metadata.isEmpty())
                onFetchMetadataFinished(resource, metadata);
            fw->deleteLater();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](bool b){
        if(!b)
            QCoreApplication::instance()->quit();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[] (const QString &name) {
        PackageKit::Daemon::upgradeSystem(name, PackageKit::Transaction::UpgradeKindDefault);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto cat : matchedCategories) {
        ret.append(cat->name());
    }
```

#### AUTO 


```{c}
auto f = [this](AbstractResource *l, AbstractResource *r) {
        return flatpakResourceLessThan(l, r);
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString & /*pkgid*/, const QStringList &files) {
            const auto isFileInstalled = [](const QString &file) {
                return QFileInfo::exists(QLatin1Char('/') + file);
            };
            const bool allFilesInstalled = std::all_of(files.constBegin(), files.constEnd(), isFileInstalled);

            // PackageKit can't tell us if a package coming from the a file is installed or not,
            // so we inspect the files it wants to install and check if they're available on our running system
            setState(allFilesInstalled ? Installed : None);
            const auto execIdx = kIndexOf(files, [](const QString &file) {
                return file.endsWith(QLatin1String(".desktop")) && file.contains(QLatin1String("usr/share/applications"));
            });
            if (execIdx >= 0) {
                m_exec = files[execIdx];

                // sometimes aptcc provides paths like usr/share/applications/steam.desktop
                if (!m_exec.startsWith(QLatin1Char('/'))) {
                    m_exec.prepend(QLatin1Char('/'));
                }
            } else {
                qWarning() << "could not find an executable desktop file for" << m_path << "among" << files;
            }
        }
```

#### AUTO 


```{c}
auto packagesToRemove = m_newPackageStates.value(PackageKit::Transaction::InfoRemoving);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() -> QVariant {
            const auto iconPath = m_snap->icon();
            if (iconPath.isEmpty())
                return QStringLiteral("package-x-generic");

            if (!iconPath.startsWith(QLatin1Char('/')))
                return QUrl(iconPath);

            auto backend = qobject_cast<SnapBackend*>(parent());
            auto req = backend->client()->getIcon(packageName());
            connect(req, &QSnapdGetIconRequest::complete, this, &SnapResource::gotIcon);
            req->runAsync();
            return {};
        }
```

#### LAMBDA EXPRESSION 


```{c}
[resources, this] () {
        if (!resources.isEmpty())
            Q_EMIT resourcesFound(resources);
        finish();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, msg]() {
            Q_EMIT passiveMessage(msg);
        }
```

#### AUTO 


```{c}
auto itInstall = std::find_if(toinstall.begin(), toinstall.end(), [&](const QString &pkgid) {
                return name == PackageKit::Transaction::packageName(pkgid);
            });
```

#### AUTO 


```{c}
auto cat = backend->category();
```

#### LAMBDA EXPRESSION 


```{c}
[this](const KNSCore::EntryInternal& entry){ return entry.isValid(); }
```

#### AUTO 


```{c}
auto action = new OneTimeAction(
        [this, url]() {
            AbstractResourcesBackend::Filters f;
            f.resourceUrl = url;
            auto stream = new StoredResultsStream({ResourcesModel::global()->search(f)});
            connect(stream, &StoredResultsStream::finished, this, [this, url, stream]() {
                const auto res = stream->resources();
                if (res.count() >= 1) {
                    emit openApplicationInternal(res.first());
                } else {
                    setRootObjectProperty("defaultStartup", true);
                    Q_EMIT openErrorPage(i18n("Couldn't open %1", url.toDisplayString()));
                }
            });
        }
        , this);
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        m_responsePending = false;
        Q_EMIT availableForQueries();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, item, value, role]() {
                        if(fwupd_client_modify_remote(m_backend->backend->client, fwupd_remote_get_id(remote), "Enabled", "true", nullptr, nullptr))
                            item->setData(value, role);
                    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, resource, stream, refSource](const QVector<AbstractResource *> &resources) {
                                for (auto res : resources) {
                                    installApplication(res);
                                }
                                refSource->addResource(resource);
                                stream->resourcesFound({resource});
                                stream->finish();
                            }
```

#### LAMBDA EXPRESSION 


```{c}
[stream, resources, this] () {
                stream->resourcesFound(resources);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this]{ qDebug() << "took really long to fetch" << this; }
```

#### LAMBDA EXPRESSION 


```{c}
[this, app](PackageKit::Transaction::Exit status) {
			const bool simulate = m_trans->transactionFlags() & PackageKit::Transaction::TransactionFlagSimulate;
            if (!simulate && status == PackageKit::Transaction::ExitSuccess) {
                app->markInstalled();
            }
        }
```

#### AUTO 


```{c}
auto action = new OneTimeAction(
        [this, category]() {
            Category* cat = CategoryModel::global()->findCategoryByName(category);
            if (cat) {
                emit listCategoryInternal(cat);
            } else {
                showPassiveNotification(i18n("Could not find category '%1'", category));
                setRootObjectProperty("defaultStartup", false);
            }
        }
        , this);
```

#### AUTO 


```{c}
const auto toinstall = QStringList() << m_packagesModified.value(PackageKit::Transaction::InfoInstalling)
                                                 << m_packagesModified.value(PackageKit::Transaction::InfoUpdating);
```

#### LAMBDA EXPRESSION 


```{c}
[regularCheck](const QStringRef& value) {
            bool ok;
            const int days = value.toInt(&ok);
            if (!ok || days == 0) {
                regularCheck->setInterval(24 * 60 * 60 * 1000); //refresh at least once every day
                regularCheck->start();
                if (!value.isEmpty())
                    qWarning() << "couldn't understand value for timer:" << value;
            }

            //if the setting is not empty, refresh will be carried out by unattended-upgrade
            //https://wiki.debian.org/UnattendedUpgrades
        }
```

#### AUTO 


```{c}
const auto alts = (*it)->alternativeAppstreamIds();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& name : backendNames) {
        QString file = QStandardPaths::locate(QStandardPaths::GenericDataLocation, "libmuon/categories/"+name+"-categories.xml");
        if (file.isEmpty()) {
            qWarning() << "Couldn't find a category for " << name;
            continue;
        }
        QList<Category*> cats = loadCategoriesFile(file);

        if(ret.isEmpty()) {
            ret += cats;
        } else {
            for(Category* c : cats)
                Category::addSubcategory(ret, c);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        showDiscoverUpdates(m_updatesAvailableNotification->xdgActivationToken());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto r : extendsResources) {
        PackageKitResource* pkres = qobject_cast<PackageKitResource*>(r);
        if (pkres->allPackageNames() != ourPackageNames)
            return false;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &filter: m_orFilters) {
        if (filter.first == CategoryFilter && filter.second == name)
            return true;
    }
```

#### AUTO 


```{c}
const auto index = indexFromItem(item);
```

#### LAMBDA EXPRESSION 


```{c}
[this] (AbstractResource *res) {
            m_resources.remove(res);
        }
```

#### AUTO 


```{c}
auto f = [this, stream, filter]() {
        QVector<AbstractResource *> ret;
        for (AbstractResource *r : qAsConst(m_resources)) {
            if (r->state() < filter.state)
                continue;

            if (filter.search.isEmpty() || r->name().contains(filter.search, Qt::CaseInsensitive)
                || r->comment().contains(filter.search, Qt::CaseInsensitive)) {
                ret += r;
            }
        }
        if (!ret.isEmpty())
            Q_EMIT stream->resourcesFound(ret);
        stream->finish();
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &/*packageID*/, const QStringList &filenames) {
        const auto allServices = QStandardPaths::locateAll(QStandardPaths::ApplicationsLocation, m_appdata.id());
        if (!allServices.isEmpty()) {
            const auto packageServices = kFilter<QStringList>(allServices, [filenames](const QString &file) { return filenames.contains(file); });
            QProcess::startDetached(QStringLiteral(CMAKE_INSTALL_FULL_LIBEXECDIR_KF5 "/discover/runservice"), {packageServices});
            return;
        } else {
            const QStringList exes = m_appdata.provided(AppStream::Provided::KindBinary).items();
            const auto packageExecutables = kFilter<QStringList>(allServices, [filenames](const QString &exe) { return filenames.contains(QLatin1Char('/') + exe); });
            if (!packageExecutables.isEmpty()) {
                QProcess::startDetached(exes.constFirst());
                return;
            } else {
                const auto locations = QStandardPaths::standardLocations(QStandardPaths::ApplicationsLocation);
                const auto desktopFiles = kFilter<QStringList>(filenames, [locations](const QString &exe) {
                    for (const auto &location: locations) {
                        if (exe.startsWith(location))
                            return exe.contains(QLatin1String(".desktop"));
                    }
                    return false;
                });
                if (!desktopFiles.isEmpty()) {
                    QProcess::startDetached(QStringLiteral(CMAKE_INSTALL_FULL_LIBEXECDIR_KF5 "/discover/runservice"), { desktopFiles });
                    return;
                }
            }
            backend()->passiveMessage(i18n("Cannot launch %1", name()));
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, process](int exitCode, QProcess::ExitStatus exitStatus) {
        qDebug() << "process exited with code " << exitCode << exitStatus;
        if (exitCode == 0) {
            readUpdateOutput(process);
        }
        toggleFetching();
        process->deleteLater();
    }
```

#### AUTO 


```{c}
const auto &snapValue
```

#### AUTO 


```{c}
auto m = sources->sources();
```

#### LAMBDA EXPRESSION 


```{c}
[this, originalUrl, fileUrl, replyPut]() {
                if (replyPut->error() != QNetworkReply::NoError) {
                    qWarning() << "couldn't save" << originalUrl << replyPut->errorString();
                    Q_EMIT jobFinished(false, nullptr);
                    return;
                }
                if (!fileUrl.isLocalFile()) {
                    Q_EMIT jobFinished(false, nullptr);
                    return;
                }

                FlatpakResource *resource = nullptr;
                if (fileUrl.path().endsWith(QLatin1String(".flatpak"))) {
                    resource = m_backend->addAppFromFlatpakBundle(fileUrl);
                } else if (fileUrl.path().endsWith(QLatin1String(".flatpakref"))) {
                    resource = m_backend->addAppFromFlatpakRef(fileUrl);
                } else if (fileUrl.path().endsWith(QLatin1String(".flatpakrepo"))) {
                    resource = m_backend->addSourceFromFlatpakRepo(fileUrl);
                }

                if (resource) {
                    resource->setResourceFile(originalUrl);
                    Q_EMIT jobFinished(true, resource);
                } else {
                    qWarning() << "couldn't create resource from" << fileUrl.toLocalFile();
                    Q_EMIT jobFinished(false, nullptr);
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this, stream, filter]() {
        QVector<AbstractResource *> prioritary, rest;
        for (const auto &source : qAsConst(m_flatpakSources)) {
            QVector<FlatpakResource *> resources;
            if (source->m_pool) {
                resources = kTransform<QVector<FlatpakResource *>>(source->m_pool->search(filter.search), [this, &source](const auto &comp) {
                    return resourceForComponent(comp, source);
                });
            } else {
                resources = source->m_resources.values().toVector();
            }

            for (auto r : resources) {
                const bool matchById = r->appstreamId().compare(filter.search, Qt::CaseInsensitive) == 0;
                if (r->type() == AbstractResource::Technical && filter.state != AbstractResource::Upgradeable && !matchById) {
                    continue;
                }
                if (r->state() < filter.state)
                    continue;

                if (!filter.extends.isEmpty() && !r->extends().contains(filter.extends))
                    continue;

                if (!filter.mimetype.isEmpty() && !r->mimetypes().contains(filter.mimetype))
                    continue;

                if (filter.search.isEmpty() || matchById) {
                    rest += r;
                } else if (r->name().contains(filter.search, Qt::CaseInsensitive)) {
                    prioritary += r;
                } else if (r->comment().contains(filter.search, Qt::CaseInsensitive)) {
                    rest += r;
                }
            }
        }
        auto f = [this](AbstractResource *l, AbstractResource *r) {
            return flatpakResourceLessThan(l, r);
        };
        std::sort(rest.begin(), rest.end(), f);
        std::sort(prioritary.begin(), prioritary.end(), f);
        rest = prioritary + rest;
        if (!rest.isEmpty())
            Q_EMIT stream->resourcesFound(rest);
        stream->finish();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, stream, filter]() {
        QVector<AbstractResource *> ret;
        for (AbstractResource *r : qAsConst(m_resources)) {
            if (r->state() < filter.state)
                continue;

            if (filter.search.isEmpty() || r->name().contains(filter.search, Qt::CaseInsensitive)
                || r->comment().contains(filter.search, Qt::CaseInsensitive)) {
                ret += r;
            }
        }
        if (!ret.isEmpty())
            Q_EMIT stream->resourcesFound(ret);
        stream->finish();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&] {
        app.exit(job->error());
    }
```

#### AUTO 


```{c}
auto start = [this, entryid, stream]() {
        m_responsePending = true;
        m_engine->fetchEntryById(entryid);
        connect(m_engine, &KNSCore::Engine::signalError, stream, &ResultsStream::finish);
        connect(m_engine, &KNSCore::Engine::signalEntryDetailsLoaded, stream, [this, stream, entryid](const KNSCore::EntryInternal &entry) {
            if (entry.uniqueId() == entryid) {
                stream->resourcesFound({resourceForEntry(entry)});
            }
            m_responsePending = false;
            QTimer::singleShot(0, this, &KNSBackend::availableForQueries);
            stream->finish();
        });
    };
```

#### AUTO 


```{c}
auto it = list.constBegin(), itEnd = list.constEnd();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto resource : resources) {
            if (resource->origin() == item->data(AbstractSourcesBackend::IdRole)) {
                return static_cast<FlatpakResource *>(resource);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto r : releases) {
                if (AppStream::Utils::vercmpSimple(r.version(), AppStreamIntegration::global()->osRelease()->version()) == 0) {
                    if (r.timestampEol() < QDateTime::currentDateTime()) {
                        const QString releaseDate = QLocale().toString(r.timestampEol());
                        Q_EMIT inlineMessage(InlineMessageType::Warning,
                                             QStringLiteral("dialog-warning"),
                                             i18nc("%1 is the date as formatted by the locale",
                                                   "Your operating system ended support on %1. Consider upgrading to a supported version.",
                                                   releaseDate));
                    }
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[](AbstractBackendUpdater *u) {
            return u->hasUpdates();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[locations](const QString &exe) {
                    for (const auto &location : locations) {
                        if (exe.startsWith(location))
                            return exe.contains(QLatin1String(".desktop"));
                    }
                    return false;
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this, source](const auto &comp) {
                return resourceForComponent(comp, source);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this, jobs]() {
        for (auto job : jobs) {
            connect(this, &SnapBackend::shuttingDown, job, &T::cancel);
            job->runSync();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[name](AbstractResourcesBackend* b) { return b->hasApplications() && b->name() == name; }
```

#### LAMBDA EXPRESSION 


```{c}
[this, jobs, filter, stream] {
        QVector<AbstractResource *> ret;
        for (auto job : jobs) {
            job->deleteLater();
            if (job->error()) {
                qDebug() << "error:" << job->error() << job->errorString();
                continue;
            }

            for (int i = 0, c = job->snapCount(); i < c; ++i) {
                QSharedPointer<QSnapdSnap> snap(job->snap(i));

                if (!filter(snap))
                    continue;

                const auto snapname = snap->name();
                SnapResource *&res = m_resources[snapname];
                if (!res) {
                    res = new SnapResource(snap, AbstractResource::None, this);
                    Q_ASSERT(res->packageName() == snapname);
                } else {
                    res->setSnap(snap);
                }
                ret += res;
            }
        }

        if (!ret.isEmpty())
            Q_EMIT stream->resourcesFound(ret);
        stream->finish();
    }
```

#### AUTO 


```{c}
auto name = flatpak_remote_get_name(remote);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &token : licenses) {
        QString license = token;
        license.remove(0, 1); // tokenize prefixes with an @ for some reason

        QString name = license;
        if (license == QLatin1String("LicenseRef-proprietary")) {
            name = i18n("Proprietary");
        }

        if (!AppStream::SPDX::isLicenseId(license))
            continue;
        ret.append(QJsonObject{
            {QStringLiteral("name"), name},
            {QStringLiteral("url"), {AppStream::SPDX::licenseUrl(license)}},
            {QStringLiteral("free"), AppStream::SPDX::isFreeLicense(license)},
        });
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, fw, flatpakInstallation, appstreamIconsPath, sourceName]() {
        const auto components = fw->result();
        foreach (const AppStream::Component& appstreamComponent, components) {
            FlatpakResource *resource = new FlatpakResource(appstreamComponent, flatpakInstallation, this);
            resource->setIconPath(appstreamIconsPath);
            resource->setOrigin(sourceName);
            addResource(resource);
        }
        if (!m_refreshAppstreamMetadataJobs) {
            loadInstalledApps();
            checkForUpdates();

        }
        acquireFetching(false);
        fw->deleteLater();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () -> GPtrArray*
        {
            const uint cacheAge = (24*60*60); // Check for updates every day
            g_autoptr(GError) error = nullptr;

            /* get devices */
            GPtrArray* devices = fwupd_client_get_devices(client, m_cancellable, &error);
            handleError(error);

            g_autoptr(GPtrArray) remotes = fwupd_client_get_remotes(client, m_cancellable, &error);
            handleError(error);
            for(uint i = 0; remotes && i < remotes->len; i++)
            {
                FwupdRemote *remote = (FwupdRemote *)g_ptr_array_index(remotes, i);
                if (!fwupd_remote_get_enabled(remote))
                    continue;

                if (fwupd_remote_get_kind(remote) == FWUPD_REMOTE_KIND_LOCAL)
                    continue;

                refreshRemote(this, remote, cacheAge, m_cancellable);
            }
            return devices;
        }
```

#### AUTO 


```{c}
auto action = new OneTimeAction(
        [this, category]() {
            Category* cat = CategoryModel::global()->findCategoryByName(category);
            if (cat) {
                emit listCategoryInternal(cat);
            } else {
                showPassiveNotification(i18n("Could not find category '%1'", category));
                setRootObjectProperty("defaultStartup", true);
            }
        }
        , this);
```

#### LAMBDA EXPRESSION 


```{c}
[this, fw, flatpakInstallation, appstreamIconsPath, sourceName]() {
        const auto components = fw->result();
        foreach (const AppStream::Component& appstreamComponent, components) {
            FlatpakResource *resource = new FlatpakResource(appstreamComponent, flatpakInstallation, this);
            resource->setIconPath(appstreamIconsPath);
            resource->setOrigin(sourceName);
            addResource(resource);
        }
        if (!m_refreshAppstreamMetadataJobs) {
            finishInitialization();
        }
        fw->deleteLater();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, p] (int code) {
                p->deleteLater();
                if (code != 0) {
                    qWarning() << "login failed... code:" << code << p->readAll();
                    Q_EMIT passiveMessage(m_request->errorString());
                    setStatus(DoneStatus);
                    return;
                }
                const auto doc = QJsonDocument::fromJson(p->readAllStandardOutput());
                const auto result = doc.object();

                const auto macaroon = result[QStringLiteral("macaroon")].toString();
                const auto discharges = kTransform<QStringList>(result[QStringLiteral("discharges")].toArray(), [](const QJsonValue& val) { return val.toString(); });
                static_cast<SnapBackend*>(m_app->backend())->client()->setAuthData(new QSnapdAuthData(macaroon, discharges));
                m_request->runAsync();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto res: resources) {
        qobject_cast<PackageKitResource*>(res)->clearPackageIds();
    }
```

#### AUTO 


```{c}
const auto backend = (*it)->backend();
```

#### AUTO 


```{c}
auto f = [this, stream] {
            QVector<AbstractResource *> resources;
            for (auto installation : m_installations) {
                g_autoptr(GError) localError = nullptr;
                g_autoptr(GPtrArray) refs = flatpak_installation_list_installed_refs_for_update(installation, m_cancellable, &localError);
                if (!refs) {
                    qWarning() << "Failed to get list of installed refs for listing updates:" << localError->message;
                    continue;
                }

                resources.reserve(resources.size() + refs->len);
                for (uint i = 0; i < refs->len; i++) {
                    FlatpakInstalledRef *ref = FLATPAK_INSTALLED_REF(g_ptr_array_index(refs, i));
                    auto resource = getAppForInstalledRef(installation, ref);
                    resource->setState(AbstractResource::Upgradeable);
                    updateAppSize(resource);
                    if (resource->resourceType() == FlatpakResource::Runtime) {
                        resources.prepend(resource);
                    } else {
                        resources.append(resource);
                    }
                }
            }
            if (!resources.isEmpty())
                Q_EMIT stream->resourcesFound(resources);
            stream->finish();
        };
```

#### LAMBDA EXPRESSION 


```{c}
[](PackageKitResource* r){return r->availablePackageId(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString& name) { return backend(name); }
```

#### AUTO 


```{c}
const auto oldSize = m_details.size();
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractResource *resource : m_backend->allResources()) {
            if (!resource)
                continue;

            if (resource->packageName() == addon.name()) {
                addonResource = resource;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractResourcesBackend *backend : backends) {
        resourcesModel->addResourcesBackend(backend);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &_error) {
        QString error = _error;
        bool invalidFile = false;
        if(error == QLatin1Literal("All categories are missing")) {
            markInvalid(error);
            error = i18n("Invalid %1 backend, contact your distributor.", m_displayName);
            invalidFile = true;
        }
        m_responsePending = false;
        Q_EMIT searchFinished();
        Q_EMIT availableForQueries();
        this->setFetching(false);
        qWarning() << "kns error" << objectName() << error;
        if (!invalidFile)
            Q_EMIT passiveMessage(i18n("%1: %2", name(), error));
    }
```

#### AUTO 


```{c}
auto a = new OneTimeAction([this] {
            emit updatesCountChanged();
        }, this);
```

#### AUTO 


```{c}
const auto networkError = reply->error();
```

#### LAMBDA EXPRESSION 


```{c}
[packageDependencies](PackageKit::Transaction::Info /*info*/, const QString &packageID, const QString &summary) {
                (*packageDependencies)[PackageKit::Daemon::packageName(packageID)] = summary;
            }
```

#### AUTO 


```{c}
auto job = new TransactionsJob;
```

#### LAMBDA EXPRESSION 


```{c}
[this, url]() {
            AbstractResourcesBackend::Filters f;
            f.resourceUrl = url;
            auto stream = new StoredResultsStream({ResourcesModel::global()->search(f)});
            connect(stream, &StoredResultsStream::finished, this, [this, url, stream]() {
                const auto res = stream->resources();
                if (res.count() == 1) {
                    emit openApplicationInternal(res.first());
                } else {
                    setRootObjectProperty("defaultStartup", true);
                    Q_EMIT openErrorPage(i18n("Couldn't open %1", url.toDisplayString()));
                }
            });
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QVector<AbstractResource*> &resources){
        for(auto res : resources)
            if (res->state() == AbstractResource::Upgradeable)
                m_upgradeable.insert(res);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](AbstractResource *res) {
                return res->packageName();
            }
```

#### AUTO 


```{c}
const auto iconUrl = qobject_cast<FlatpakBackend*>(backend())->sources()->sourceById(origin())->data(FlatpakSourcesBackend::IconUrlRole).toString();
```

#### AUTO 


```{c}
const auto refs = fw->result();
```

#### LAMBDA EXPRESSION 


```{c}
[filter](AbstractResource *res) {
                return res->state() >= AbstractResource::Installed
                    && (res->name().contains(filter.search, Qt::CaseInsensitive) || res->packageName().compare(filter.search, Qt::CaseInsensitive) == 0);
            }
```

#### AUTO 


```{c}
auto f = [this, stream, filter] () {
        QVector<AbstractResource*> ret;
        for (auto r : qAsConst(m_resources)) {
            const bool matchById = r->appstreamId().compare(filter.search, Qt::CaseInsensitive) == 0;
            if (r->type() == AbstractResource::Technical && filter.state != AbstractResource::Upgradeable && !matchById) {
                continue;
            }
            if (r->state() < filter.state)
                continue;

            if (!filter.extends.isEmpty() && !r->extends().contains(filter.extends))
                continue;

            if (filter.search.isEmpty() || r->name().contains(filter.search, Qt::CaseInsensitive) || r->comment().contains(filter.search, Qt::CaseInsensitive) || matchById)
            {
                ret += r;
            }
        }
        auto f = [this](AbstractResource* l, AbstractResource* r) { return flatpakResourceLessThan(l,r); };
        std::sort(ret.begin(), ret.end(), f);
        if (!ret.isEmpty())
            Q_EMIT stream->resourcesFound(ret);
        stream->finish();
    };
```

#### LAMBDA EXPRESSION 


```{c}
[eulaID, hashHex] {
            KConfigGroup group(KSharedConfig::openConfig(), "EULA");
            KConfigGroup licenseGroup = group.group(eulaID);
            licenseGroup.writeEntry<QByteArray>("Hash", hashHex);
            return PackageKit::Daemon::acceptEula(eulaID);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QJsonObject &obj) {
        setDependenciesCount(obj.size());
    }
```

#### AUTO 


```{c}
auto matchIt = exp.globalMatch(id);
```

#### AUTO 


```{c}
auto action = new OneTimeAction(
        [this, localfile]() {
            AbstractResourcesBackend::Filters f;
            f.resourceUrl = localfile;
            auto stream = new StoredResultsStream({ResourcesModel::global()->search(f)});
            connect(stream, &StoredResultsStream::finished, this, [this, localfile, stream]() {
                const auto res = stream->resources();
                if (res.count() == 1) {
                    emit openApplicationInternal(res.first());
                } else {
                    QMimeDatabase db;
                    auto mime = db.mimeTypeForUrl(localfile);
                    auto fIsFlatpakBackend = [](AbstractResourcesBackend* backend) { return backend->metaObject()->className() == QByteArray("FlatpakBackend"); };
                    if (mime.name().startsWith(QLatin1String("application/vnd.flatpak")) && !kContains(ResourcesModel::global()->backends(), fIsFlatpakBackend)) {
                        openApplication(QUrl(QLatin1String("appstream://org.kde.discover.flatpak")));
                        showPassiveNotification(i18n("Cannot interact with flatpak resources without the flatpak backend %1. Please install it first.", localfile.toDisplayString()));
                    } else {
                        setRootObjectProperty("defaultStartup", true);
                        showPassiveNotification(i18n("Couldn't open %1", localfile.toDisplayString()));
                    }
                }
            });
        }
        , this);
```

#### AUTO 


```{c}
auto backend = ResourcesModel::global()->currentApplicationBackend();
```

#### LAMBDA EXPRESSION 


```{c}
[this, url](const QVector<AbstractResource*> &res) {
                if (res.count() >= 1) {
                    emit openApplicationInternal(res.first());
                } else {
                    setRootObjectProperty("defaultStartup", true);
                    Q_EMIT openErrorPage(i18n("Couldn't open %1", url.toDisplayString()));
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[resources, this] () {
            if (!resources.isEmpty())
                setResources(resources);
            finish();
        }
```

#### AUTO 


```{c}
auto fetchRemoteResource = new FlatpakFetchRemoteResourceJob(runtimeUrl, stream, this);
```

#### AUTO 


```{c}
auto item = new QStandardItem;
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
              {
                  if (m_backends.isEmpty())
                      return 0;

                  int sum = 0;
                  for (auto backend : qAsConst(m_backends)) {
                      sum += backend->fetchingUpdatesProgress();
                  }
                  return sum / m_backends.count();
              }
          }
```

#### AUTO 


```{c}
auto cats = m_appdata->categories();
```

#### AUTO 


```{c}
auto item = itemFromResource(res);
```

#### AUTO 


```{c}
auto action = new OneTimeAction(
        [this]() {
            bool found = DiscoverBackendsFactory::hasRequestedBackends();
            const auto backends = ResourcesModel::global()->backends();
            for (auto b : backends)
                found |= b->hasApplications();

            if (!found)
                Q_EMIT openErrorPage(
                    i18n("Discover currently cannot be used to install any apps "
                         "because none of its app backends are available. Please "
                         "report this error to your distribution."));
        },
        this);
```

#### LAMBDA EXPRESSION 


```{c}
[this, source](const auto &comp) {
            return resourceForComponent(comp, source);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[stream](PackageKit::Transaction::Info /*info*/, const QString &packageId){
            stream->setProperty("packageId", packageId);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, trans, component](PackageKit::Transaction::Exit status) {
                const auto pkgidVal = trans->property("installedPackage");
                if (status == PackageKit::Transaction::ExitSuccess && !pkgidVal.isNull()) {
                    const auto pkgid = pkgidVal.toString();
                    auto res = addComponent(component, {PackageKit::Daemon::packageName(pkgid)});
                    res->clearPackageIds();
                    res->addPackageId(PackageKit::Transaction::InfoInstalled, pkgid, true);
                }
                acquireFetching(false);
            }
```

#### AUTO 


```{c}
auto refVariant = split_branch[3];
```

#### AUTO 


```{c}
auto mime = db.mimeTypeForUrl(localfile);
```

#### AUTO 


```{c}
const auto roles = propertiesToRoles(properties);
```

#### LAMBDA EXPRESSION 


```{c}
[tArch](PackageKit::Transaction::Info /*info*/, const QString &packageId){
            tArch->setProperty("packageId", packageId);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, fw]() {
        const auto data = fw->result();
        fw->deleteLater();

        if (!data.correct && m_packages.packages.isEmpty()) {
            QTimer::singleShot(0, this, [this]() {
                Q_EMIT passiveMessage(i18n("Please make sure that Appstream is properly set up on your system"));
            });
        }
        for (const auto &component : data.components) {
            addComponent(component);
        }

        if (data.components.isEmpty()) {
            qCDebug(LIBDISCOVER_BACKEND_LOG) << "empty appstream db";
            if (PackageKit::Daemon::backendName() == QLatin1String("aptcc") || PackageKit::Daemon::backendName().isEmpty()) {
                checkForUpdates();
            }
        }
        if (!m_appstreamInitialized) {
            m_appstreamInitialized = true;
            Q_EMIT loadedAppStream();
        }
        acquireFetching(false);

        const QList<AppStream::Component> distroComponents = m_appdata->componentsById(AppStream::Utils::currentDistroComponentId());
        for (const AppStream::Component &dc : distroComponents) {
            const auto releases = dc.releases();
            for (auto r : releases) {
                if (AppStream::Utils::vercmpSimple(r.version(), AppStreamIntegration::global()->osRelease()->version()) == 0) {
                    if (r.timestampEol() < QDateTime::currentDateTime()) {
                        const QString releaseDate = QLocale().toString(r.timestampEol());
                        Q_EMIT inlineMessage(InlineMessageType::Warning,
                                             QStringLiteral("dialog-warning"),
                                             i18nc("%1 is the date as formatted by the locale",
                                                   "Your operating system ended support on %1. Consider upgrading to a supported version.",
                                                   releaseDate));
                    }
                }
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractBackendUpdater *upd : qAsConst(m_updaters)) {
        upd->setOfflineUpdates(m_offlineUpdates);
        upd->prepare();
    }
```

#### AUTO 


```{c}
const auto array = QJsonDocument::fromJson(f.readAll(), &error).array();
```

#### AUTO 


```{c}
auto req = backend->client()->getIcon(iconPath);
```

#### RANGE FOR STATEMENT 


```{c}
for(auto a : qAsConst(m_filteredActions)) {
        connect(a, &QAction::changed, this, &ActionsModel::reload, Qt::UniqueConnection);
    }
```

#### AUTO 


```{c}
auto addonsCategory = new Category(topLevelName, iconName, filters, backendName, {actualCategory}, QUrl(), true);
```

#### AUTO 


```{c}
const auto images = s.images();
```

#### RANGE FOR STATEMENT 


```{c}
for(BackendNotifierModule* module : m_backends) {
        connect(module, &BackendNotifierModule::foundUpdates, this, &MuonNotifier::updatesChanged);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[trans](PackageKit::Transaction::Info info, const QString &packageID, const QString &summary) {
        trans->setProperty("dependencies", trans->property("dependencies").toUInt() + 1);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[func, process, varname](int code) {
        if (code != 0)
            return;

        QRegularExpression rx(QLatin1Char('^') + varname + QStringLiteral(" \"(.*?)\";?$"), QRegularExpression::CaseInsensitiveOption);
        QTextStream stream(process);
        QString line;
        while (stream.readLineInto(&line)) {
            const auto match = rx.match(line);
            if (match.hasMatch()) {
                func(match.capturedView(1));
                return;
            }
        }
        func({});
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Application *app : m_appsTemp)
    {
        app->clearPackage();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, fw]() {
        m_fetching = true;
        emit fetchingChanged();

        auto devices = fw->result();
        for(uint i = 0; devices && i < devices->len; i++) {
            FwupdDevice *device = (FwupdDevice *) g_ptr_array_index(devices, i);

            if (!fwupd_device_has_flag (device, FWUPD_DEVICE_FLAG_SUPPORTED))
                continue;

            g_autoptr(GError) error = nullptr;
            g_autoptr(GPtrArray) releases = fwupd_client_get_releases(client, fwupd_device_get_id(device), m_cancellable, &error);

            if (error) {
                if (g_error_matches(error, FWUPD_ERROR, FWUPD_ERROR_NOT_SUPPORTED)) {
                    qWarning() << "fwupd: Device not supported:" << fwupd_device_get_name(device) << error->message;
                    continue;
                }
                if (g_error_matches(error, FWUPD_ERROR, FWUPD_ERROR_INVALID_FILE)) {
                    continue;
                }

                handleError(error);
            }

            auto res = createDevice(device);
            for (uint i=0; releases && i<releases->len; ++i) {
                FwupdRelease *release = (FwupdRelease *)g_ptr_array_index(releases, i);
                if (res->installedVersion().toUtf8() == fwupd_release_get_version(release)) {
                    res->setReleaseDetails(release);
                    break;
                }
            }
            addResourceToList(res);
        }
        g_ptr_array_unref(devices);

        addUpdates();

        m_fetching = false;
        emit fetchingChanged();
        emit initialized();
        fw->deleteLater();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto b : f.backend(name))
        addResourcesBackend(b);
```

#### AUTO 


```{c}
const auto resources = kAppend<QVector<AbstractResource *>>(appstreamIds, [this](const QString &appstreamId) {
                    return resourcesByAppstreamName(appstreamId);
                });
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString& e : vals.keys()) {
                if(vals[e]>1)
                    ret.append(e);
                else
                    ret.append(i18n("%1 (Binary)", e));
            }
```

#### AUTO 


```{c}
auto job = m_socket.snapAction(app->packageName(), SnapSocket::Install);
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractResource * res : m_toUpgrade) {
        PackageKitResource * app = qobject_cast<PackageKitResource*>(res);
        QString pkgid = m_backend->upgradeablePackageId(app);
        m_packageIds.insert(pkgid);
    }
```

#### AUTO 


```{c}
const auto matchedCategories = categoryObjects(CategoryModel::global()->rootCategories());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &location: locations) {
                        if (exe.startsWith(location))
                            return exe.contains(QLatin1String(".desktop"));
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto backend : backends) {
        if (!backend->isValid())
            continue;

        const QVector<Category *> cats = cr.loadCategoriesFile(backend);

        if (ret.isEmpty()) {
            ret = cats;
        } else {
            for (Category *c : cats)
                Category::addSubcategory(ret, c);
        }
    }
```

#### AUTO 


```{c}
auto start = [this, entryid, stream]() {
        m_responsePending = true;
        m_engine->fetchEntryById(entryid);
        connect(m_engine, &KNSCore::Engine::signalError, stream, &QObject::deleteLater);
        connect(m_engine, &KNSCore::Engine::signalEntryDetailsLoaded, stream, [this, stream, entryid](const KNSCore::EntryInternal &entry) {
            if (entry.uniqueId() == entryid) {
                stream->resourcesFound({resourceForEntry(entry)});
            }
            m_responsePending = false;
            QTimer::singleShot(0, this, &KNSBackend::availableForQueries);
            stream->deleteLater();
        });
    };
```

#### AUTO 


```{c}
auto iter = m_jobHash.constBegin();
```

#### AUTO 


```{c}
auto *job = new KIO::CommandLauncherJob(QStringLiteral("plasma-discover"), {
        QStringLiteral("--mode"),
        QStringLiteral("update")
    });
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &file) {
                return QFileInfo::exists(QLatin1Char('/') + file);
            }
```

#### AUTO 


```{c}
const auto checksum = fwupd_remote_get_checksum(remote);
```

#### LAMBDA EXPRESSION 


```{c}
[search](SnapResource* res){ return res->appstreamId() == search.host(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto res : resources) {
                            installApplication(res);
                        }
```

#### AUTO 


```{c}
auto split_ref = m_origin.split(':');
```

#### LAMBDA EXPRESSION 


```{c}
[this] { m_fetchingUpdatesProgress.reevaluate(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this, originalUrl, fileUrl, replyPut]() {
                QScopedPointer<QNetworkReply, QScopedPointerDeleteLater> replyPtr(replyPut);
                if (replyPut->error() != QNetworkReply::NoError) {
                    qWarning() << "couldn't save" << originalUrl << replyPut->errorString();
                    Q_EMIT jobFinished(false, nullptr);
                    return;
                }
                if (!fileUrl.isLocalFile()) {
                    Q_EMIT jobFinished(false, nullptr);
                    return;
                }

                FlatpakResource *resource = nullptr;
                if (fileUrl.path().endsWith(QLatin1String(".flatpak"))) {
                    resource = m_backend->addAppFromFlatpakBundle(fileUrl);
                } else if (fileUrl.path().endsWith(QLatin1String(".flatpakref"))) {
                    resource = m_backend->addAppFromFlatpakRef(fileUrl);
                } else if (fileUrl.path().endsWith(QLatin1String(".flatpakrepo"))) {
                    resource = m_backend->addSourceFromFlatpakRepo(fileUrl);
                }

                if (resource) {
                    resource->setResourceFile(originalUrl);
                    Q_EMIT jobFinished(true, resource);
                } else {
                    qWarning() << "couldn't create resource from" << fileUrl.toLocalFile();
                    Q_EMIT jobFinished(false, nullptr);
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this](AppPackageKitResource* r){ return r->allPackageNames() != allPackageNames(); }
```

#### AUTO 


```{c}
const auto fileName = filter.resourceUrl.fileName();
```

#### RANGE FOR STATEMENT 


```{c}
for(auto i : res->linkIds()) {
                auto engine = res->knsBackend()->engine();
                if (this->role() == InstallRole)
                    engine->install(res->entry(), i);
                else if(this->role() == RemoveRole)
                    engine->uninstall(res->entry());
            }
```

#### AUTO 


```{c}
const auto theActions = actions();
```

#### AUTO 


```{c}
auto *job = new KIO::ApplicationLauncherJob(KService::serviceByDesktopName(QStringLiteral("org.kde.discover")));
```

#### AUTO 


```{c}
auto r = m_backend->search(f);
```

#### AUTO 


```{c}
const auto resources = kTransform<QVector<AbstractResource*>>(entries, [this](const KNSCore::EntryInternal& entry){ return resourceForEntry(entry); });
```

#### AUTO 


```{c}
const auto toResolve = kFilter<QVector<AbstractResource*>>(m_packages.packages, needsResolveFilter);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &desktopFilePath : desktopFilePaths) {
        auto p = new QProcess(parent());
        connect(p, QOverload<int, QProcess::ExitStatus>::of(&QProcess::finished), this, [this, p](int exitCode, QProcess::ExitStatus exitStatus) {
            if (exitCode != 0) {
                backend()->passiveMessage(i18n("Failed to start '%1'", KShell::joinArgs(p->arguments())));
            }
            p->deleteLater();
        });
        p->start(QStringLiteral(CMAKE_INSTALL_FULL_LIBEXECDIR_KF5 "/discover/runservice"), {desktopFilePath});
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto r : resources)
            connect(r, &QObject::destroyed, this, [this, r]() {
                m_resources.removeAll(r);
            });
```

#### AUTO 


```{c}
auto message = QDBusMessage::createMethodCall(QStringLiteral("org.kde.DiscoverNotifier"),
                                                        QStringLiteral("/MainApplication"),
                                                        QStringLiteral("org.qtproject.Qt.QCoreApplication"),
                                                        QStringLiteral("quit"));
```

#### AUTO 


```{c}
auto changes = m_backend->stateChanges(m_oldCacheState, selectedPackages());
```

#### LAMBDA EXPRESSION 


```{c}
[this, stream, appstreamIds] () {
                const auto resources = kAppend<QVector<AbstractResource*>>(appstreamIds, [this] (const QString appstreamId) { return resourcesByAppstreamName(appstreamId); });
                if (!resources.isEmpty())
                    Q_EMIT stream->resourcesFound(resources);
                stream->finish();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &instRef : qAsConst(toRemoveRefs)) {
                        const QByteArray refString = instRef.toUtf8();
                        flatpak_transaction_add_uninstall(transaction, refString.constData(), &localError);
                        if (localError)
                            return;
                    }
```

#### AUTO 


```{c}
auto deps = trans->property("dependencies").toUInt();
```

#### LAMBDA EXPRESSION 


```{c}
[eulaID] {
            return PackageKit::Daemon::acceptEula(eulaID);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto installation : m_installations) {
                g_autoptr(GError) localError = nullptr;
                g_autoptr(GPtrArray) refs = flatpak_installation_list_installed_refs(installation, m_cancellable, &localError);
                if (!refs) {
                    qWarning() << "Failed to get list of installed refs for listing installed:" << localError->message;
                    continue;
                }

                resources.reserve(resources.size() + refs->len);
                for (uint i = 0; i < refs->len; i++) {
                    FlatpakInstalledRef *ref = FLATPAK_INSTALLED_REF(g_ptr_array_index(refs, i));
                    QString name = QString::fromUtf8(flatpak_installed_ref_get_appdata_name(ref));
                    if (name.endsWith(QLatin1String(".Debug")) || name.endsWith(QLatin1String(".Locale")) || name.endsWith(QLatin1String(".BaseApp"))
                        || name.endsWith(QLatin1String(".Docs")))
                        continue;

                    auto resource = getAppForInstalledRef(installation, ref);
                    if (resource->resourceType() == FlatpakResource::Runtime) {
                        resources.prepend(resource);
                    } else {
                        resources.append(resource);
                    }
                }
            }
```

#### AUTO 


```{c}
auto stream = ResourcesModel::global()->findResourceByPackageName(app);
```

#### LAMBDA EXPRESSION 


```{c}
[](QSessionManager &sm) {
        sm.setRestartHint(QSessionManager::RestartNever);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool fetching) {
        m_updateAction->setEnabled(!fetching);
        m_fetchingUpdatesProgress.reevaluate();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QApt::Package *package : packages) {
        if (m_stop) {
            m_backend->setCompressEvents(false);
            QApplication::restoreOverrideCursor();
            break;
        }

        switch (action) {
        case QApt::Package::ToInstall:
            setInstall(package);
            break;
        case QApt::Package::ToRemove:
            setRemove(package);
            break;
        case QApt::Package::ToUpgrade:
            setUpgrade(package);
            break;
        case QApt::Package::ToReInstall:
            setReInstall(package);
            break;
        case QApt::Package::ToKeep:
            setKeep(package);
            break;
        case QApt::Package::ToPurge:
            setPurge(package);
            break;
        default:
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto source : qAsConst(m_flatpakSources)) {
        if (source->url() == flatpak_remote_get_url(remote) && source->installation() == flatpakInstallation
            && source->name() == flatpak_remote_get_name(remote)) {
            createPool(source);
            return source;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, url]() {
            AbstractResourcesBackend::Filters f;
            f.resourceUrl = url;
            auto stream = new StoredResultsStream({ResourcesModel::global()->search(f)});
            connect(stream, &StoredResultsStream::finished, this, [this, url, stream]() {
                const auto res = stream->resources();
                if (res.count() == 1) {
                    emit openApplicationInternal(res.first());
                } else {
                    setRootObjectProperty("defaultStartup", true);
                    showPassiveNotification(i18n("Couldn't open %1", url.toDisplayString()));
                }
            });
        }
```

#### AUTO 


```{c}
auto action = new OneTimeAction(
        [this, category]() {
            Category* cat = CategoryModel::global()->findCategoryByName(category);
            if (cat) {
                emit listCategoryInternal(cat);
            } else {
                openMode(QStringLiteral("Browsing"));
                showPassiveNotification(i18n("Could not find category '%1'", category));
            }
        }
        , this);
```

#### AUTO 


```{c}
auto it = toremove.begin(), itEnd = toremove.end();
```

#### AUTO 


```{c}
auto stream = new ResultsStream(QStringLiteral("FlatpakStream-http-")+filter.resourceUrl.fileName());
```

#### RANGE FOR STATEMENT 


```{c}
for(auto inst : qAsConst(m_installations))
        g_object_unref(inst);
```

#### LAMBDA EXPRESSION 


```{c}
[] (const QString& pkgid) { return PackageKit::Daemon::packageName(pkgid); }
```

#### LAMBDA EXPRESSION 


```{c}
[&ret](const QVector<AbstractResource *> &res) {
        ret += res;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (BackendNotifierModule *module : qAsConst(m_backends)) {
        connect(module, &BackendNotifierModule::foundUpdates, this, &DiscoverNotifier::updateStatusNotifier);
        connect(module, &BackendNotifierModule::needsRebootChanged, this, [this]() {
            // If we are using offline updates, there is no need to badger the user to
            // reboot since it is safe to continue using the system in its current state
            if (!m_needsReboot && !m_settings->useUnattendedUpdates()) {
                m_needsReboot = true;
                showRebootNotification();
                Q_EMIT stateChanged();
                Q_EMIT needsRebootChanged(true);
            }
        });

        connect(module, &BackendNotifierModule::foundUpgradeAction, this, &DiscoverNotifier::foundUpgradeAction);
    }
```

#### AUTO 


```{c}
const auto packages = kTransform<QSet<QString>>(pkgids, [](const QString &pkgid) {
        return PackageKit::Daemon::packageName(pkgid);
    });
```

#### LAMBDA EXPRESSION 


```{c}
[](BackendNotifierModule *module) {
                                return module->hasUpdates();
                            }
```

#### LAMBDA EXPRESSION 


```{c}
[this, &source](const auto &comp) {
                    return resourceForComponent(comp, source);
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
              {
                  int ret = 0;
                  for (AbstractResourcesBackend *backend : qAsConst(m_backends)) {
                      ret += backend->updatesCount();
                  }
                  return ret;
              }
          }
```

#### AUTO 


```{c}
const auto transactions = tm->transactions();
```

#### LAMBDA EXPRESSION 


```{c}
[stream, ids, this](PackageKit::Transaction::Exit status) {
            getPackagesFinished();
            if (status == PackageKit::Transaction::Exit::ExitSuccess) {
                const auto packageId = stream->property("packageId");
                if (!packageId.isNull()) {
                    const auto res = resourcesByPackageNames<QVector<AbstractResource*>, QVector<QString>>({PackageKit::Daemon::packageName(packageId.toString())});
                    stream->resourcesFound(kFilter<QVector<AbstractResource*>>(res, [ids](AbstractResource* res){ return !ids.contains(res->appstreamId()); }));
                }
            }
            stream->finish();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[] (AbstractResource* res) { return res->state() >= AbstractResource::Installed; }
```

#### LAMBDA EXPRESSION 


```{c}
[this, url]() {
            AbstractResourcesBackend::Filters f;
            f.resourceUrl = url;
            auto stream = new StoredResultsStream({ResourcesModel::global()->search(f)});
            connect(stream, &StoredResultsStream::finishedResources, this, [this, url](const QVector<AbstractResource *> &res) {
                if (res.count() >= 1) {
                    Q_EMIT openApplicationInternal(res.first());
                } else if (url.scheme() == QLatin1String("snap")) {
                    openApplication(QUrl(QStringLiteral("appstream://org.kde.discover.snap")));
                    showPassiveNotification(i18n("Please make sure Snap support is installed"));
                } else {
                    const QString errorText = i18n("Could not open %1 because it "
                    "was not found in any available software repositories.",
                    url.toDisplayString());
                    const QString errorExplanation = i18n("Please report this "
                    "issue to the packagers of your distribution.");
                    QString buttonIcon = QStringLiteral("tools-report-bug");
                    QString buttonText = i18n("Report This Issue");
                    QString buttonUrl = KOSRelease().bugReportUrl();
                    Q_EMIT openErrorPage(errorText, errorExplanation, buttonText, buttonIcon, buttonUrl);
                }
            });
        }
```

#### AUTO 


```{c}
const auto execName = args.takeFirst();
```

#### LAMBDA EXPRESSION 


```{c}
[this, stream, source, name] {
                auto comps = source->componentsByName(name);
                auto resources = kTransform<QVector<AbstractResource *>>(comps, [this, source](const auto &comp) {
                    return resourceForComponent(comp, source);
                });
                stream->resourcesFound(resources);
                stream->finish();
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this, fw]() {
        m_fetching = true;
        emit fetchingChanged();

        auto devices = fw->result();
        for(uint i = 0; devices && i < devices->len; i++) {
            FwupdDevice *device = (FwupdDevice *) g_ptr_array_index(devices, i);

            addResourceToList(createDevice(device));
        }
        g_ptr_array_unref(devices);


        addUpdates();
        addHistoricalUpdates();

        m_fetching = false;
        emit fetchingChanged();
        fw->deleteLater();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](int exitCode, QProcess::ExitStatus exitStatus) {
        qWarning() << "process exited with code " << exitCode << exitStatus;
        if (exitCode == 0) {
            readUpdateOutput(process);
        }
        process->deleteLater();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(AbstractResource* res : m_packages.values()) {
        if (res->name().contains(searchText, Qt::CaseInsensitive)) {
            kDebug() << "Got one" << res->name();
            ret += res;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto a: vector) {
        if (last && !Category::categoryLessThan(last, a))
            return false;
        last = a;
    }
```

#### AUTO 


```{c}
const auto f = [this, stream, filter]() {
            const QList<AppStream::Component> components = m_appdata->search(filter.search);
            const QStringList ids = kTransform<QStringList>(components, [](const AppStream::Component &comp) {
                return comp.id();
            });
            if (!ids.isEmpty()) {
                const auto resources =
                    kFilter<QVector<AbstractResource *>>(resourcesByPackageNames<QVector<AbstractResource *>>(ids), [](AbstractResource *res) {
                        return !qobject_cast<PackageKitResource *>(res)->extendsItself();
                    });
                stream->setResources(resources);
            }
            stream->finish();
        };
```

#### RANGE FOR STATEMENT 


```{c}
for (auto resource : qAsConst(resources)) {
        const auto finder = [this](AbstractResource *resource, AbstractResource *res) {
            return lessThan(resource, res);
        };
        const auto it = std::upper_bound(m_displayedResources.constBegin(), m_displayedResources.constEnd(), resource, finder);
        const auto newIdx = it == m_displayedResources.constEnd() ? m_displayedResources.count() : (it - m_displayedResources.constBegin());

        if ((it - 1) != m_displayedResources.constEnd() && *(it - 1) == resource)
            continue;

        beginInsertRows({}, newIdx, newIdx);
        m_displayedResources.insert(newIdx, resource);
        endInsertRows();
        //         Q_ASSERT(isSorted(resources));
    }
```

#### AUTO 


```{c}
auto deployment
```

#### AUTO 


```{c}
auto replyGet = get(req);
```

#### AUTO 


```{c}
auto filterFunction = [&filter](AbstractResource* r) { return r->state()>=filter.state && (r->name().contains(filter.search, Qt::CaseInsensitive) || r->comment().contains(filter.search, Qt::CaseInsensitive)); };
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const QString &/*pkgid*/, const QStringList & files){
        const auto execs = kFilter<QVector<QString>>(files, [](const QString& file) { return file.endsWith(QLatin1String(".desktop")) && file.contains(QLatin1String("usr/share/applications")); });
        if (!execs.isEmpty())
            m_exec = execs.constFirst();
        else
            qWarning() << "could not find an executable desktop file for" << m_path << "among" << files;
    }
```

#### AUTO 


```{c}
auto ret = s_shared->atticaManager.providerFor(m_providerUrl);
```

#### AUTO 


```{c}
auto installation = resource->scope() == FlatpakResource::System ? m_flatpakInstallationSystem : m_flatpakInstallationUser;
```

#### LAMBDA EXPRESSION 


```{c}
[](AbstractResource *r) { return static_cast<PackageKitResource *>(r)->isCritical(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this, resource] (bool success, FlatpakResource *repoResource) {
                        if (success) {
                            installApplication(repoResource);
                        }
                        addResource(resource);
                    }
```

#### LAMBDA EXPRESSION 


```{c}
[search](AbstractResourcesBackend* backend){ return backend->search(search); }
```

#### LAMBDA EXPRESSION 


```{c}
[this, packageDependencies](PackageKit::Transaction::Exit /*status*/) {
        Q_EMIT dependenciesFound(*packageDependencies);
    }
```

#### AUTO 


```{c}
auto t = m_proceedFunctions.takeFirst()();
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString & /*packageID*/, const QStringList &_filenames) {
        // This workarounds bug in zypper's backend (suse) https://github.com/hughsie/PackageKit/issues/351
        QStringList filenames = _filenames;
        if (filenames.count() == 1 && !QFile::exists(filenames.constFirst())) {
            filenames = filenames.constFirst().split(QLatin1Char(';'));
        }
        const auto allServices = QStandardPaths::locateAll(QStandardPaths::ApplicationsLocation, m_appdata.id());
        if (!allServices.isEmpty()) {
            const auto packageServices = kFilter<QStringList>(allServices, [filenames](const QString &file) {
                return filenames.contains(file);
            });
            runService(packageServices);
            return;
        } else {
            const QStringList exes = m_appdata.provided(AppStream::Provided::KindBinary).items();
            const auto packageExecutables = kFilter<QStringList>(exes, [filenames](const QString &exe) {
                return filenames.contains(QLatin1Char('/') + exe);
            });
            if (!packageExecutables.isEmpty()) {
                QProcess::startDetached(exes.constFirst(), QStringList());
                return;
            } else {
                const auto locations = QStandardPaths::standardLocations(QStandardPaths::ApplicationsLocation);
                const auto desktopFiles = kFilter<QStringList>(filenames, [locations](const QString &exe) {
                    for (const auto &location : locations) {
                        if (exe.startsWith(location))
                            return exe.contains(QLatin1String(".desktop"));
                    }
                    return false;
                });
                if (!desktopFiles.isEmpty()) {
                    runService(desktopFiles);
                    return;
                }
            }
            Q_EMIT backend()->passiveMessage(i18n("Cannot launch %1", name()));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto res : source->m_resources) {
        if (res->appstreamId() == component.id()) {
            return res;
        }
    }
```

#### AUTO 


```{c}
auto resource
```

#### AUTO 


```{c}
auto iter = m_jobFilenames.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString& path : QCoreApplication::instance()->libraryPaths()) {
        QDir dir(path + QStringLiteral("/discover-notifier/"));
        for(const QString& file : dir.entryList(QDir::Files)) {
            QString fullPath = dir.absoluteFilePath(file);
            QPluginLoader loader(fullPath);
            loader.load();
            ret += qobject_cast<BackendNotifierModule*>(loader.instance());
            if (ret.last() == nullptr) {
                qWarning() << "couldn't load" << fullPath << "because" << loader.errorString();
                ret.removeLast();
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, stream, appstreamIds] () {
                const auto resources = kAppend<QVector<AbstractResource*>>(appstreamIds, [this] (const QString &appstreamId) { return resourcesByAppstreamName(appstreamId); });
                if (!resources.isEmpty())
                    Q_EMIT stream->resourcesFound(resources);
                stream->finish();
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this, request](){
        if (request->error()) {
            qWarning() << "error" << request->error() << ": " << request->errorString();
            return;
        }
        Q_ASSERT(request->snapCount() == 1);
        setSnap(QSharedPointer<QSnapdSnap>(request->snap(0)));
    }
```

#### AUTO 


```{c}
const auto isFileInstalled = [](const QString &file) {
                return QFileInfo::exists(QLatin1Char('/') + file);
            };
```

#### LAMBDA EXPRESSION 


```{c}
[this, searchText]() {
        // No need to explicitly launch a search, setting the search term already does that for us
        m_engine->setSearchTerm(searchText);
        m_responsePending = true;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[filters](const QSharedPointer<QSnapdSnap> &s) {
            return filters.search.isEmpty() || s->name().contains(filters.search, Qt::CaseInsensitive)
                || s->description().contains(filters.search, Qt::CaseInsensitive);
        }
```

#### AUTO 


```{c}
auto it = m_packages.packages.constBegin(), itEnd = m_packages.packages.constEnd();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& name : backendNames) {
        QList<Category*> cats = loadCategoriesFile(name);

        if(ret.isEmpty()) {
            ret += cats;
        } else {
            for(Category* c : cats)
                Category::addSubcategory(ret, c);
        }
    }
```

#### AUTO 


```{c}
const auto resources = kTransform<QVector<AbstractResource *>>(m_packages.extendedBy.value(filter.extends), [](AppPackageKitResource *a) {
                return a;
            });
```

#### AUTO 


```{c}
auto changed = PopConParser::parsePopcon(this, dev.data(), m_ratings);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto res : qAsConst(m_resources)) {
            ret += kToSet(qobject_cast<PackageKitResource *>(res)->allPackageNames());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &desktopFilePath : desktopFilePaths) {
        auto p = new QProcess(parent());
        connect(p, QOverload<int, QProcess::ExitStatus>::of(&QProcess::finished), this, [this, p] (int exitCode, QProcess::ExitStatus exitStatus) {
            if (exitCode != 0) {
                backend()->passiveMessage(i18n("Failed to start '%1'", KShell::joinArgs(p->arguments())));
            }
	    p->deleteLater();
        });
        p->start(QStringLiteral(CMAKE_INSTALL_FULL_LIBEXECDIR_KF5 "/discover/runservice"), {desktopFilePath});
    }
```

#### LAMBDA EXPRESSION 


```{c}
[search](AbstractResourcesBackend *backend) {
        return backend->search(search);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QVector<AbstractResource*>& resources) {
        for(auto r : resources)
            connect(r, &QObject::destroyed, this, [this, r](){
                m_resources.removeAll(r);
            });
        m_resources += resources;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, installation, fw](){
        auto refs = fw->result();
        onFetchUpdatesFinished(installation, refs);
        fw->deleteLater();
    }
```

#### AUTO 


```{c}
auto discoverAction = menu->addAction(QIcon::fromTheme(QStringLiteral("plasma-discover")), i18n("Open Software Center..."));
```

#### AUTO 


```{c}
const auto packageExecutables = kFilter<QStringList>(exes, [filenames](const QString &exe) { return filenames.contains(QLatin1Char('/') + exe); });
```

#### AUTO 


```{c}
auto f = [this, stream, filter] {
            const auto toResolve = kFilter<QVector<AbstractResource*>>(m_packages.packages, needsResolveFilter);

            auto installedAndNameFilter = [filter] (AbstractResource *res) {
                return res->state() >= AbstractResource::Installed && (res->name().contains(filter.search) || res->packageName() == filter.search);
            };
            bool furtherSearch = false;
            if (!toResolve.isEmpty()) {
                resolvePackages(kTransform<QStringList>(toResolve, [] (AbstractResource* res) { return res->packageName(); }));
                connect(m_resolveTransaction, &PKResolveTransaction::allFinished, this, [stream, toResolve, installedAndNameFilter] {
                    const auto resolved = kFilter<QVector<AbstractResource*>>(toResolve, installedAndNameFilter);
                    if (!resolved.isEmpty())
                        Q_EMIT stream->resourcesFound(resolved);
                    stream->finish();
                });
                furtherSearch = true;
            }

            const auto resolved = kFilter<QVector<AbstractResource*>>(m_packages.packages, installedAndNameFilter);
            if (!resolved.isEmpty()) {
                QTimer::singleShot(0, this, [resolved, toResolve, stream] () {
                    if (!resolved.isEmpty())
                        Q_EMIT stream->resourcesFound(resolved);

                    if (toResolve.isEmpty())
                        stream->finish();
                });
                furtherSearch = true;
            }

            if (!furtherSearch)
                stream->finish();
        };
```

#### AUTO 


```{c}
auto iter = m_transQueue.find(m_currentTransaction);
```

#### LAMBDA EXPRESSION 


```{c}
[this](AbstractResource* l, AbstractResource* r) { return flatpakResourceLessThan(l,r); }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &file) {
            return file.endsWith(QLatin1String(".desktop")) && file.contains(QLatin1String("usr/share/applications"));
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](BackendNotifierModule *module) {
        return module->hasSecurityUpdates();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&appstreamId](const PackageState &state) {
                return appstreamId == state.packageName();
            }
```

#### LAMBDA EXPRESSION 


```{c}
[menu, &notifier]() {
        auto refreshAction = menu->addAction(QIcon::fromTheme(QStringLiteral("view-refresh")), i18n("Restart..."));
        QObject::connect(refreshAction, &QAction::triggered, &notifier, &DiscoverNotifier::recheckSystemUpdateNeeded);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &snapValue : snaps) {
            QVERIFY(snapValue.isObject());
            auto snap = snapValue.toObject();
            QVERIFY(snap.contains(QLatin1String("name") ));
            QVERIFY(snap.contains(QLatin1String("developer")));

            const auto name = snap.value(QLatin1String("name")).toString();
            auto requestedSnap = jobResult(socket.snapByName(name)).toObject();

            //should treat these separately becauase they're randomly delivered in different order
            //just make sure they're the same number, for now
            const auto apps = snap.take(QLatin1String("apps")).toArray(), reqApps = requestedSnap.take(QLatin1String("apps")).toArray();
            QCOMPARE(apps.count(), reqApps.count());

            if (requestedSnap != snap) {
                const auto keys = snap.keys();
                QCOMPARE(requestedSnap.keys(), keys);
                foreach(const auto &key, keys) {
                    QCOMPARE(requestedSnap.value(key), snap.value(key));
                }
            }
            QCOMPARE(requestedSnap, snap);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, url]() {
            AbstractResourcesBackend::Filters f;
            f.resourceUrl = url;
            auto stream = new StoredResultsStream({ResourcesModel::global()->search(f)});
            connect(stream, &StoredResultsStream::finished, this, [this, url, stream]() {
                const auto res = stream->resources();
                if (res.count() == 1) {
                    emit openApplicationInternal(res.first());
                } else {
                    rootObject()->setProperty("defaultStartup", true);
                    showPassiveNotification(i18n("Couldn't open %1", url.toDisplayString()));
                }
            });
        }
```

#### AUTO 


```{c}
auto fw = new QFutureWatcher<QMap<FlatpakInstallation *, QVector<FlatpakInstalledRef *>>>(this);
```

#### RANGE FOR STATEMENT 


```{c}
for(auto cat: cats) {
        proxy->setFiltersFromCategory(cat);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
                processFile(m_url);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[trans](PackageKit::Transaction::Info info, const QString &packageID){
                if (info == PackageKit::Transaction::InfoInstalled)
                    trans->setProperty("installedPackage", packageID);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractResource * res : m_packages.values()) {
        if (!res->isTechnical() && res->canUpgrade())
            count++;
    }
```

#### AUTO 


```{c}
auto resources = getResources(ResourcesModel::global()->search(filter), true);
```

#### AUTO 


```{c}
const auto discharges = kTransform<QStringList>(result[QStringLiteral("discharges")].toArray(), [](const QJsonValue &val) {
                return val.toString();
            });
```

#### CONST EXPRESSION 


```{c}
static constexpr auto s_addonKinds = {AppStream::Component::KindAddon, AppStream::Component::KindCodec};
```

#### AUTO 


```{c}
auto f = [this, filter, stream] {
            auto resources = kFilter<QVector<AbstractResource*>>(m_packages.packages, [](AbstractResource* res) { return res->type() != AbstractResource::Technical && !qobject_cast<PackageKitResource*>(res)->extendsItself(); });
            if (!resources.isEmpty()) {
                stream->setResources(resources);
            }
        };
```

#### LAMBDA EXPRESSION 


```{c}
[this](){
        m_settingUp = false;
        Q_EMIT progressingChanged(false);
        Q_EMIT updatesCountChanged(updatesCount());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, process] (int exitCode, QProcess::ExitStatus exitStatus) {
        qDebug() << "Finished running plasma-discover-update" << exitCode << exitStatus;
        DiscoverNotifier* notifier = static_cast<DiscoverNotifier*>(parent());
        notifier->setBusy(false);
        process->deleteLater();
    }
```

#### AUTO 


```{c}
auto f = [this, stream, filter]() {
        QVector<AbstractResource *> prioritary, rest;
        for (const auto &source : qAsConst(m_flatpakSources)) {
            QVector<FlatpakResource *> resources;
            if (source->m_pool) {
                resources = kTransform<QVector<FlatpakResource *>>(source->m_pool->search(filter.search), [this, &source](const auto &comp) {
                    return resourceForComponent(comp, source);
                });
            } else {
                resources = source->m_resources.values().toVector();
            }

            for (auto r : resources) {
                const bool matchById = r->appstreamId().compare(filter.search, Qt::CaseInsensitive) == 0;
                if (r->type() == AbstractResource::Technical && filter.state != AbstractResource::Upgradeable && !matchById) {
                    continue;
                }
                if (r->state() < filter.state)
                    continue;

                if (!filter.extends.isEmpty() && !r->extends().contains(filter.extends))
                    continue;

                if (!filter.mimetype.isEmpty() && !r->mimetypes().contains(filter.mimetype))
                    continue;

                if (filter.search.isEmpty() || matchById) {
                    rest += r;
                } else if (r->name().contains(filter.search, Qt::CaseInsensitive)) {
                    prioritary += r;
                } else if (r->comment().contains(filter.search, Qt::CaseInsensitive)) {
                    rest += r;
                }
            }
        }
        auto f = [this](AbstractResource *l, AbstractResource *r) {
            return flatpakResourceLessThan(l, r);
        };
        std::sort(rest.begin(), rest.end(), f);
        std::sort(prioritary.begin(), prioritary.end(), f);
        rest = prioritary + rest;
        if (!rest.isEmpty())
            Q_EMIT stream->resourcesFound(rest);
        stream->finish();
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (QApt::Package *package : *it) {
                pkgList << package->name();
	}
```

#### AUTO 


```{c}
auto fw = new QFutureWatcher<DelayedAppStreamLoad>(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this, fw] {
        const QJsonDocument jsonDocument = fw->result();
        fw->deleteLater();
        const QJsonObject jsonObject = jsonDocument.object();
        m_ratings.reserve(jsonObject.size());
        for (auto it = jsonObject.begin(); it != jsonObject.end(); it++) {
            QJsonObject appJsonObject = it.value().toObject();

            const int ratingCount =  appJsonObject.value(QLatin1String("total")).toInt();
            int ratingMap[] = { appJsonObject.value(QLatin1String("star0")).toInt(),
                                appJsonObject.value(QLatin1String("star1")).toInt(),
                                appJsonObject.value(QLatin1String("star2")).toInt(),
                                appJsonObject.value(QLatin1String("star3")).toInt(),
                                appJsonObject.value(QLatin1String("star4")).toInt(),
                                appJsonObject.value(QLatin1String("star5")).toInt() };

            Rating *rating = new Rating(it.key(), ratingCount, ratingMap);
            m_ratings.insert(it.key(), rating);
        }
        Q_EMIT ratingsReady();
    }
```

#### AUTO 


```{c}
const auto macaroon = result[QStringLiteral("macaroon")].toString();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &source : m_flatpakSources) {
        if (source->m_pool) {
            auto comps = source->m_pool->componentsById(name);
            if (comps.isEmpty()) {
                comps = source->m_pool->componentsByProvided(AppStream::Provided::KindId, name);
            }
            resources << kTransform<QVector<AbstractResource *>>(comps, [this, source](const auto &comp) {
                return resourceForComponent(comp, source);
            });
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(Appstream::Provides p : m_appdata.provides())
        if (p.kind() == Appstream::Provides::KindBinary)
            ret += p.value();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVector<AbstractResource*>& resources : m_resources)
        ret += resources.size();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            if (!m_needsReboot) {
                m_needsReboot = true;
                showRebootNotification();
                Q_EMIT updatesChanged();
                Q_EMIT needsRebootChanged(true);
            }
        }
```

#### AUTO 


```{c}
auto req = client()->getIcon(packageName());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &repoName : repoNames) {
        const QByteArray name = repoName.toUtf8();
        for (auto installation : insts) {
            g_autoptr(GError) error = nullptr;
            auto remote = flatpak_installation_get_remote_by_name(installation, name, nullptr, &error);
            if (remote) {
                addRemote(remote, installation);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Application *app : tempList) {
        bool added = false;
        QApt::Package *pkg = app->package();
        if (app->isValid() && pkg) {
            appList << app;
            app->moveToThread(thread);
            added = true;
        }

        if(!added)
            delete app;
    }
```

#### AUTO 


```{c}
auto it = m_updatingPackages.packages.begin();
```

#### AUTO 


```{c}
const auto resources = kAppend<QVector<AbstractResource*>>(appstreamIds, [this] (const QString appstreamId) { return resourcesByAppstreamName(appstreamId); });
```

#### LAMBDA EXPRESSION 


```{c}
[installation]() -> bool {
        g_autoptr(GCancellable) cancellable = g_cancellable_new();
        g_autoptr(GError) localError = nullptr;
        g_autoptr(GPtrArray) fetchedUpdates = flatpak_installation_list_installed_refs_for_update(installation->m_installation, cancellable, &localError);
        bool hasUpdates = false;

        for (uint i = 0; !hasUpdates && i < fetchedUpdates->len; i++) {
            FlatpakInstalledRef *ref = FLATPAK_INSTALLED_REF(g_ptr_array_index(fetchedUpdates, i));
            const QString refName = QString::fromUtf8(flatpak_ref_get_name(FLATPAK_REF(ref)));
            // FIXME right now I can't think of any other filter than this, in FlatpakBackend updates are matched
            // with apps so .Locale/.Debug subrefs are not shown and updated automatically. Also this will show
            // updates for refs we don't show in Discover if appstream metadata or desktop file for them is not found
            if (refName.endsWith(QLatin1String(".Locale")) || refName.endsWith(QLatin1String(".Debug"))) {
                continue;
            }
            hasUpdates = true;
        }
        if (!fetchedUpdates) {
            qWarning() << "Failed to get list of installed refs for listing updates: " << localError->message;
        }
        return hasUpdates;
    }
```

#### AUTO 


```{c}
auto refSource = QSharedPointer<FlatpakSource>::create(this, preferredInstallation(), nullptr);
```

#### RANGE FOR STATEMENT 


```{c}
for (RpmOstreeResource *deployment : m_resources) {
        if (deployment->isBooted()) {
            return deployment;
        }
    }
```

#### AUTO 


```{c}
const auto apps = snap.take(QLatin1String("apps")).toArray(), reqApps = requestedSnap.take(QLatin1String("apps")).toArray();
```

#### LAMBDA EXPRESSION 


```{c}
[this](Transaction* t) { return t->property("updater").value<QObject*>() == this; }
```

#### LAMBDA EXPRESSION 


```{c}
[this, stream, searchText]() {
        // No need to explicitly launch a search, setting the search term already does that for us
        m_engine->setSearchTerm(searchText);
        m_onePage = false;
        m_responsePending = true;

        connect(this, &KNSBackend::receivedResources, stream, &ResultsStream::resourcesFound);
        connect(this, &KNSBackend::searchFinished, stream, &ResultsStream::finish);
        connect(this, &KNSBackend::startingSearch, stream, &ResultsStream::finish);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, localfile]() {
            auto res = ResourcesModel::global()->resourceForFile(localfile);
            qDebug() << "all initialized..." << res;
            if (res) {
                emit openApplicationInternal(res);
            } else {
                rootObject()->setProperty("defaultStartup", true);
                showPassiveNotification(i18n("Couldn't open %1", localfile.toDisplayString()));
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto res: qAsConst(resources)) {
        const auto id = res->appstreamId();
        if (uri.contains(id))
            dupeUri += id;
        else
            uri += id;
    }
```

#### AUTO 


```{c}
const auto packageId = tArch->property("packageId");
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            qDebug() << "destroyed transaction before finishing";
            setTransaction(nullptr);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto stream: streams) {
        connect(stream, &ResultsStream::resourcesFound, this, &AggregatedResultsStream::addResults);
        connect(stream, &QObject::destroyed, this, &AggregatedResultsStream::destruction);
        connect(this, &ResultsStream::fetchMore, stream, &ResultsStream::fetchMore);
        m_streams << stream;
    }
```

#### AUTO 


```{c}
auto streams = kTransform<QSet<ResultsStream *>>(m_backends, [search](AbstractResourcesBackend *backend) {
        return backend->search(search);
    });
```

#### AUTO 


```{c}
auto stream = new ResultsStream(QStringLiteral("Snap-populate"));
```

#### RANGE FOR STATEMENT 


```{c}
for (DummyResource *app : resources) {
        if (m_ratings.contains(app))
            continue;
        auto randomRating = qrand() % 10;

        int ratings[] = {0, 0, 0, 0, 0, randomRating};
        Rating *rating = new Rating(app->packageName(), ++i, ratings);
        m_ratings.insert(app, rating);
        Q_EMIT app->ratingFetched();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](AbstractResourcesBackend *backend) {
        return backend->name() == QLatin1String("ksplash.knsrc");
    }
```

#### LAMBDA EXPRESSION 


```{c}
[menu, this]() {
        m_item->setTitle(i18n("Restart to apply installed updates"));
        m_item->setToolTipTitle(i18n("Click to restart the device"));
        m_item->setIconByName(QStringLiteral("view-refresh"));
        auto refreshAction = menu->addAction(QIcon::fromTheme(QStringLiteral("view-refresh")), i18n("Restart..."));
        connect(refreshAction, &QAction::triggered, &m_notifier, &DiscoverNotifier::recheckSystemUpdateNeeded);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(BackendNotifierModule* module : m_backends) {
        connect(module, &BackendNotifierModule::foundUpdates, this, &MuonNotifier::updateStatusNotifier);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (UpdateItem *item : qAsConst(m_updateItems)) {
        const auto packageName = item->resource()->packageName();
        if (packages.contains(packageName)) {
            continue;
        }
        packages.insert(packageName);
        ret += 1;
    }
```

#### AUTO 


```{c}
auto a = new UpgradeAction(name, description, this);
```

#### AUTO 


```{c}
const auto execs = kFilter<QVector<QString>>(files, [](const QString& file) { return file.endsWith(QLatin1String(".desktop")) && file.contains(QLatin1String("usr/share/applications")); });
```

#### AUTO 


```{c}
auto method = QDBusMessage::createMethodCall(QStringLiteral("org.kde.LogoutPrompt"),
                                                 QStringLiteral("/LogoutPrompt"),
                                                 QStringLiteral("org.kde.LogoutPrompt"),
                                                 QStringLiteral("promptReboot"));
```

#### LAMBDA EXPRESSION 


```{c}
[this, resource](Transaction::Status status) {
        if (status == Transaction::Status::DoneStatus) {
            updateAppState(resource);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto i : res->linkIds())
                    engine->install(res->entry(), i);
```

#### AUTO 


```{c}
auto addSource = [=](AbstractResource* res) {
        if (res)
            backend->installApplication(res);
        else
            Q_EMIT backend->passiveMessage(i18n("Could not add the source %1", flatpakrepoUrl.toDisplayString()));
    };
```

#### AUTO 


```{c}
auto connection = QDBusConnection::connectToPeer(m_path, TransactionConnection);
```

#### RANGE FOR STATEMENT 


```{c}
for(Transaction* t: trans) {
        ret += t->downloadSpeed();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &backend : backends) {
        if (!backend.endsWith(QLatin1String("-backend")))
            backend.append(QLatin1String("-backend"));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[func, process, varname](int code) {
        if (code != 0)
            return;

        QRegularExpression rx(QLatin1Char('^') + varname + QStringLiteral(" \"(.*?)\"$"));
        QTextStream stream(process);
        QString line;
        while (stream.readLineInto(&line)) {
            const auto match = rx.match(line);
            if (match.hasMatch()) {
                func(match.capturedRef(1));
            }
        }
    }
```

#### AUTO 


```{c}
const auto res = getResources(m_backend->findResourceByPackageName(QUrl(QStringLiteral("kns://") + m_backend->name() + QStringLiteral("/api.kde-look.org/1136471"))));
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {
        m_refreshAppstreamMetadataJobs--;
    }
```

#### AUTO 


```{c}
auto res = getAllResources(m_appBackend);
```

#### RANGE FOR STATEMENT 


```{c}
for (Application *app : tempList) {
        bool added = false;
        QApt::Package *pkg = app->package();
        if (app->isValid()) {
            if ((pkg) && !pkgBlacklist.contains(pkg->name())) {
                appList << app;
                added = true;
            }
        }

        if(added)
            app->moveToThread(thread);
        else
            delete app;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &arch : archList) {
        QStandardItem *archItem = new QStandardItem;
        archItem->setEditable(false);
        archItem->setText(MuonStrings::global()->archString(arch));
        archItem->setData(arch, Qt::UserRole+1);
        appendRow(archItem);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, stream, app]() {
                const auto resources = stream->property("resources").value<QVector<AbstractResource*>>();
                if (!resources.isEmpty()) {
                    if (resources.size() > 1)
                        qWarning() << "many resources found for" << app;
                    emit openApplicationInternal(resources.first());
                } else {
                    rootObject()->setProperty("defaultStartup", true);
                    showPassiveNotification(i18n("Couldn't open %1", app.toDisplayString()));
                }
            }
```

#### AUTO 


```{c}
auto source = findSource(resource->installation(), resource->origin());
```

#### AUTO 


```{c}
auto ref = QString((char *)key);
```

#### RANGE FOR STATEMENT 


```{c}
for (QApt::Package *package : *i) {
            root->appendRow(new QStandardItem(QIcon::fromTheme("muon"), package->name()));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto inst : m_installations) {
            if (FlatpakResource::installationPath(inst) == path)
                return inst;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](AbstractResource *a) {
            return a->name();
        }
```

#### AUTO 


```{c}
auto source = integrateRemote(installation, remote);
```

#### LAMBDA EXPRESSION 


```{c}
[this, flatpakInstallation, resource, fw]() {
            const auto metadata = fw->result();
            if (!metadata.isEmpty())
                onFetchMetadataFinished(flatpakInstallation, resource, metadata);
            fw->deleteLater();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto pkgList : changes.values()) {
        for(QApt::Package* it : pkgList) {
            AbstractResource* res = m_appBackend->resourceByPackageName(it->name());
            if(!res) //If we couldn't find it by its name, try with
                res = m_appBackend->resourceByPackageName(QStringLiteral("%1:%2").arg(it->name()).arg(it->architecture()));

            if(res) {
                if (res->state() == Application::Upgradeable)
                    m_toUpdate += res;
            } else {
                qWarning() << "Couldn't find the package:" << it->name();
            }
            Q_ASSERT(res);
        }
    }
```

#### AUTO 


```{c}
auto stream = new ResultsStream(QStringLiteral("KNS-byname-")+entryid);
```

#### AUTO 


```{c}
auto pkgs = involvedPackages(m_toUpgrade).toList();
```

#### RANGE FOR STATEMENT 


```{c}
for(Category* subCat : qAsConst(m_subCategories)) {
        if(!categoryLessThan(subCat, cat)) {
            break;
        }
        ++i;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, stream] {
            QVector<AbstractResource *> resources;
            for (auto installation : m_installations) {
                g_autoptr(GError) localError = nullptr;
                g_autoptr(GPtrArray) refs = flatpak_installation_list_installed_refs_for_update(installation, m_cancellable, &localError);
                if (!refs) {
                    qWarning() << "Failed to get list of installed refs for listing updates:" << localError->message;
                    continue;
                }

                resources.reserve(resources.size() + refs->len);
                for (uint i = 0; i < refs->len; i++) {
                    FlatpakInstalledRef *ref = FLATPAK_INSTALLED_REF(g_ptr_array_index(refs, i));
                    auto resource = getAppForInstalledRef(installation, ref);
                    resource->setState(AbstractResource::Upgradeable);
                    updateAppSize(resource);
                    if (resource->resourceType() == FlatpakResource::Runtime) {
                        resources.prepend(resource);
                    } else {
                        resources.append(resource);
                    }
                }
            }
            if (!resources.isEmpty())
                Q_EMIT stream->resourcesFound(resources);
            stream->finish();
        }
```

#### AUTO 


```{c}
const auto iconName = knsrcPlasma.contains(fileName) ? QStringLiteral("plasma") : QStringLiteral("applications-other");
```

#### AUTO 


```{c}
const auto name = PackageKit::Daemon::packageName(packageID);
```

#### LAMBDA EXPRESSION 


```{c}
[this, file, reply](){
            file->close();
            file->deleteLater();

            if(reply->error() != QNetworkReply::NoError) {
                qWarning() << "Fwupd Error: Could not download" << reply->url() << reply->errorString();
                file->remove();
                setStatus(DoneWithErrorStatus);
            } else {
                fwupdInstall(file->fileName());
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](const char *status, guint progress, gboolean /*estimating*/, gpointer /*user_data*/) {
        qDebug() << "Progress..." << status << progress;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]{
        if (PackageKit::Daemon::global()->offline()->updateTriggered())
            nowNeedsReboot();
    }
```

#### AUTO 


```{c}
auto it = icons.constBegin(), itEnd = icons.constEnd();
```

#### RANGE FOR STATEMENT 


```{c}
for(QAction *action: actions) {
            if (action->toolTip() == id) {
                action->setEnabled(false);
                action->setVisible(false);
            }
        }
```

#### AUTO 


```{c}
auto backend = qobject_cast<AbstractResourcesBackend *>(sources->parent());
```

#### RANGE FOR STATEMENT 


```{c}
for(BackendNotifierModule* module : m_backends)
        ret += module->metaObject()->className();
```

#### AUTO 


```{c}
auto updateChecker = new OneTimeAction(
                666,
                [this] {
                    //No need to check for updates if there's no resources
                    if (m_resourcesByName.isEmpty()) {
                        return true;
                    }

                    if (m_responsePending) {
                        // Slot already taken, will need to wait again
                        return false;
                    }

                    m_onePage = true;
                    setResponsePending(true);
                    m_engine->checkForUpdates();
                    return true;
                },
                this);
```

#### LAMBDA EXPRESSION 


```{c}
[packageDependencies](PackageKit::Transaction::Info /*info*/, const QString &packageID, const QString &summary) {
        (*packageDependencies)[PackageKit::Daemon::packageName(packageID)] = summary ;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &filter : notFilters) {
        if (shouldFilter(this, filter))
            return false;
    }
```

#### AUTO 


```{c}
auto action = new OneTimeAction(
        [this]() {
            bool found = DiscoverBackendsFactory::hasRequestedBackends();
            const auto backends = ResourcesModel::global()->backends();
            for (auto b : backends)
                found |= b->hasApplications();

            if (!found) {
                QString errorText = i18n(
                    "Discover currently cannot be used to install any apps or "
                    "perform system updates because none of its app backends are "
                    "available.");
                QString errorExplanation = xi18nc("@info",
                    "You can install some on the Settings page, under the "
                    "<interface>Missing Backends</interface> section.<nl/><nl/>"
                    "Also please consider reporting this as a packaging issue to "
                    "your distribution.");
                QString buttonIcon = QStringLiteral("tools-report-bug");
                QString buttonText = i18n("Report This Issue");
                QString buttonUrl = KOSRelease().bugReportUrl();

                if (KOSRelease().name().contains(QStringLiteral("Arch Linux"))) {
                    errorExplanation = xi18nc("@info",
                        "You can use <command>pacman</command> to "
                        "install the optional dependencies that are needed to "
                        "enable the application backends.<nl/><nl/>Please note "
                        "that Arch Linux developers recommend using "
                        "<command>pacman</command> for managing software because "
                        "the PackageKit backend is not well-integrated on Arch "
                        "Linux.");
                    buttonIcon = QStringLiteral("help-about");
                    buttonText = i18n("Learn More");
                    buttonUrl = KOSRelease().supportUrl();
                }

                Q_EMIT openErrorPage(errorText, errorExplanation, buttonText, buttonIcon, buttonUrl);
            }
        },
        this);
```

#### AUTO 


```{c}
auto ret = new StoredResultsStream({populate(m_client.list())});
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
                emit updatesCountChanged();
            }
```

#### LAMBDA EXPRESSION 


```{c}
[&filter](AbstractResource *r) {
                    return r->state() >= filter.state
                        && (r->name().contains(filter.search, Qt::CaseInsensitive) || r->comment().contains(filter.search, Qt::CaseInsensitive));
                }
```

#### AUTO 


```{c}
const auto resolved = kFilter<QVector<AbstractResource*>>(m_packages.packages, installedFilter);
```

#### AUTO 


```{c}
auto onActivateRequested = [mainWindow](const QStringList &arguments, const QString & /*workingDirectory*/) {
            if (!mainWindow->rootObject())
                QCoreApplication::instance()->quit();

            auto window = qobject_cast<QWindow *>(mainWindow->rootObject());
            if (window && QX11Info::isPlatformX11()) {
                KStartupInfo::setNewStartupId(window, QX11Info::nextStartupId());
            }
            window->raise();

            if (arguments.isEmpty())
                return;
            QScopedPointer<QCommandLineParser> parser(createParser());
            parser->parse(arguments);
            processArgs(parser.data(), mainWindow);
        };
```

#### LAMBDA EXPRESSION 


```{c}
[this, stream, entryid, providerid](const KNSCore::EntryInternal &entry, KNSCore::EntryInternal::EntryEvent event) {
                    switch (event) {
                    case KNSCore::EntryInternal::StatusChangedEvent:
                        if (entry.uniqueId() == entryid && providerid == QUrl(entry.providerId()).host()) {
                            Q_EMIT stream->resourcesFound({resourceForEntry(entry)});
                        } else
                            qWarning() << "found invalid" << entryid << entry.uniqueId() << providerid << QUrl(entry.providerId()).host();
                        m_responsePending = false;
                        QTimer::singleShot(0, this, &KNSBackend::availableForQueries);
                        stream->finish();
                        break;
                    case KNSCore::EntryInternal::DetailsLoadedEvent:
                    case KNSCore::EntryInternal::AdoptedEvent:
                    case KNSCore::EntryInternal::UnknownEvent:
                    default:
                        break;
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &cat: qAsConst(categories)) {
        const QString catName = cat->name().append(QLatin1Char('/'));
        for (const auto& potentialSubCat: qAsConst(categories)) {
            if(potentialSubCat->name().startsWith(catName)) {
                cat->addSubcategory(potentialSubCat);
                topCategories.removeOne(potentialSubCat);
            }
        }
    }
```

#### AUTO 


```{c}
auto reply = nam()->post(request, document.toJson());
```

#### AUTO 


```{c}
auto x = qScopeGuard([stream] {
        stream->finish();
    });
```

#### AUTO 


```{c}
auto isCritical = [](AbstractResource *r) { return static_cast<PackageKitResource *>(r)->isCritical(); };
```

#### RANGE FOR STATEMENT 


```{c}
for (auto resource : qAsConst(resources)) {
        const auto finder = [this](AbstractResource *resource, AbstractResource *res) {
            return lessThan(resource, res);
        };
        const auto it = std::upper_bound(m_displayedResources.constBegin(), m_displayedResources.constEnd(), resource, finder);
        const auto newIdx = it == m_displayedResources.constEnd() ? m_displayedResources.count() : (it - m_displayedResources.constBegin());

        if ((it - 1) != m_displayedResources.constEnd() && *(it - 1) == resource)
            continue;

        beginInsertRows({}, newIdx, newIdx);
        m_displayedResources.insert(newIdx, resource);
        endInsertRows();
        // Q_ASSERT(isSorted(resources));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[resources, this] () {
        if (!resources.isEmpty())
            Q_EMIT resourcesFound(resources);
        deleteLater();
    }
```

#### AUTO 


```{c}
const auto licenses = AppStream::SPDX::tokenizeLicense(appdata.projectLicense());
```

#### LAMBDA EXPRESSION 


```{c}
[this, trans](const QString & title, const QString &desc){ Q_EMIT proceedRequest(trans, title, desc); }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto res : qAsConst(m_resources)) {
            PackageKitResource *app = qobject_cast<PackageKitResource *>(res);
            QString pkgid = m_backend->upgradeablePackageId(app);
            if (!donePkgs.contains(pkgid)) {
                donePkgs.insert(pkgid);
                ret += app;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &itCat : cats) {
        if (contains(qobject_cast<Category *>(itCat.value<QObject *>()))) {
            ret = true;
            break;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, file, reply](){
            file->close();
            file->deleteLater();

            if(reply->error() != QNetworkReply::NoError) {
                qWarning() << "Fwupd Error: Could not download" << reply->url() << reply->errorString();
                file->remove();
                setStatus(DoneWithErrorStatus);
            } else {
                fwupdInstall();
            }
        }
```

#### AUTO 


```{c}
const auto dest = qScopeGuard([this] {
        acquireFetching(false);
    });
```

#### AUTO 


```{c}
auto b = addBackend(backend);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &location : locations) {
                        if (exe.startsWith(location))
                            return exe.contains(QLatin1String(".desktop"));
                    }
```

#### AUTO 


```{c}
auto action = new OneTimeAction(
            [this, m] {
                addSourceModel(m);
            },
            this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QApt::SourceEntry &sEntry : m_sourcesList.entries()) {
        if (!sEntry.isValid())
            continue;

        SourceItem* newSource = sourceForUri(sEntry.uri());
        EntryItem* entry = new EntryItem(sEntry);
        newSource->appendRow(entry);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](){
            m_transaction->setStatus(Transaction::QueuedStatus);
            m_transaction->slotProgressingChanged();
        }
```

#### AUTO 


```{c}
auto restartEvent = PackageKit::Transaction::Restart(restart.toInt());
```

#### RANGE FOR STATEMENT 


```{c}
for(const Appstream::Component& component: m_appdata.allComponents()) {
        const QString name = component.packageNames().first();
        m_updatingPackages[name] = new AppPackageKitResource(component, this);
    }
```

#### AUTO 


```{c}
const auto newCandidates = (candidates - m_resources);
```

#### AUTO 


```{c}
auto it = s_categories->begin(), itEnd = s_categories->end();
```

#### RANGE FOR STATEMENT 


```{c}
for (const AppStream::Screenshot &s : appdataScreenshots) {
        const auto images = s.images();
        const QUrl thumbnail = AppStreamUtils::imageOfKind(images, AppStream::Image::KindThumbnail);
        const QUrl plain = AppStreamUtils::imageOfKind(images, AppStream::Image::KindSource);
        if (plain.isEmpty())
            qWarning() << "invalid screenshot for" << appdata.name();

        screenshots << plain;
        thumbnails << (thumbnail.isEmpty() ? plain : thumbnail);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, resource](Transaction::Status status) {
        if (status == Transaction::Status::DoneStatus) {
            if (auto tempSource = resource->temporarySource()) {
                auto source = findSource(resource->installation(), resource->origin());
                resource->setTemporarySource({});
                const auto id = resource->uniqueId();
                source->m_resources.insert(id, resource);

                tempSource->m_resources.remove(id);
                if (tempSource->m_resources.isEmpty()) {
                    const bool removed = m_flatpakSources.removeAll(tempSource) || m_flatpakLoadingSources.removeAll(tempSource);
                    Q_ASSERT(removed);
                }
            }
            updateAppState(resource);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QQmlError &error : m_view->errors()) {
            errors.append(error.toString() + QLatin1String("\n"));
        }
```

#### AUTO 


```{c}
const auto topLevelName = knsrcPlasma.contains(fileName) ? i18n("Plasma Addons") : i18n("Application Addons");
```

#### AUTO 


```{c}
auto resFlathub = getAllResources(m_appBackend);
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractResource *res : resources) {
        QVERIFY(!res->name().isEmpty());
        QVERIFY(!res->categories().isEmpty());
        QVERIFY(!res->origin().isEmpty());
        QVERIFY(!res->icon().isNull());
        //     QVERIFY(!res->comment().isEmpty());
        //     QVERIFY(!res->longDescription().isEmpty());
        //     QVERIFY(!res->license().isEmpty());
        QVERIFY(res->homepage().isValid() && !res->homepage().isEmpty());
        QVERIFY(res->state() > AbstractResource::Broken);
        QVERIFY(res->addonsInformation().isEmpty());

        QSignalSpy spy(res, &AbstractResource::screenshotsFetched);
        res->fetchScreenshots();
        QVERIFY(spy.count() || spy.wait());

        QSignalSpy spy1(res, &AbstractResource::changelogFetched);
        res->fetchChangelog();
        QVERIFY(spy1.count() || spy1.wait());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, url, stream]() {
                const auto res = stream->resources();
                if (res.count() == 1) {
                    emit openApplicationInternal(res.first());
                } else {
                    setRootObjectProperty("defaultStartup", true);
                    Q_EMIT openErrorPage(i18n("Couldn't open %1", url.toDisplayString()));
                }
            }
```

#### AUTO 


```{c}
auto stream = new ResultsStream(QLatin1String("FlatpakStream-http-")+filter.resourceUrl.fileName());
```

#### AUTO 


```{c}
const auto finder = [this, resource](AbstractResource* res){ return lessThan(res, resource); };
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString& file) { return file.endsWith(QLatin1String(".desktop")) && file.contains(QLatin1String("usr/share/applications")); }
```

#### AUTO 


```{c}
const auto &potentialSubCat
```

#### RANGE FOR STATEMENT 


```{c}
for (auto source : qAsConst(m_flatpakSources)) {
        if (source->url() == flatpak_remote_get_url(remote) && source->installation() == flatpakInstallation) {
            qDebug() << "do not add a source twice1" << source << remote;
            metadataRefreshed();
            return source;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QApt::Package *package : packages) {
        if (!m_backend->setPackagePinned(package, lock)) {
            QString title = i18nc("@title:window", "Failed to Lock Package");
            QString text = i18nc("@info Error text", "The package %1 could not "
                                 "be locked. Failed to write lock file.",
                                 package->name());
            KMessageBox::error(this, text, title);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto res : qAsConst(m_resources)) {
            ret += kToSet(qobject_cast<PackageKitResource*>(res)->allPackageNames());
        }
```

#### AUTO 


```{c}
auto res = _res;
```

#### RANGE FOR STATEMENT 


```{c}
for (Application *app : m_appList) {
        pkg = app->package();
        if (pkg->isInstalled()) {
            m_instOriginList << pkg->origin();
        }

        m_originList << pkg->origin();
    }
```

#### AUTO 


```{c}
const auto toremove = m_packagesModified.value(PackageKit::Transaction::InfoRemoving);
```

#### AUTO 


```{c}
auto f = [this, filter, stream] {
            auto resources = kFilter<QVector<AbstractResource *>>(m_packages.packages, [](AbstractResource *res) {
                return res->type() != AbstractResource::Technical && !qobject_cast<PackageKitResource *>(res)->extendsItself();
            });
            if (!resources.isEmpty()) {
                stream->setResources(resources);
            }
            stream->finish();
        };
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            if (!m_needsReboot) {
                m_needsReboot = true;
                showRebootNotification();
                Q_EMIT stateChanged();
                Q_EMIT needsRebootChanged(true);
            }
        }
```

#### AUTO 


```{c}
auto action = new OneTimeAction(
        [this, localfile]() {
            AbstractResourcesBackend::Filters f;
            f.resourceUrl = localfile;
            auto stream = new StoredResultsStream({ResourcesModel::global()->search(f)});
            connect(stream, &StoredResultsStream::finishedResources, this, [this, localfile](const QVector<AbstractResource*> &res) {
                if (res.count() == 1) {
                    emit openApplicationInternal(res.first());
                } else {
                    QMimeDatabase db;
                    auto mime = db.mimeTypeForUrl(localfile);
                    auto fIsFlatpakBackend = [](AbstractResourcesBackend* backend) { return backend->metaObject()->className() == QByteArray("FlatpakBackend"); };
                    if (mime.name().startsWith(QLatin1String("application/vnd.flatpak")) && !kContains(ResourcesModel::global()->backends(), fIsFlatpakBackend)) {
                        openApplication(QUrl(QStringLiteral("appstream://org.kde.discover.flatpak")));
                        showPassiveNotification(i18n("Cannot interact with flatpak resources without the flatpak backend %1. Please install it first.", localfile.toDisplayString()));
                    } else {
                        setRootObjectProperty("defaultStartup", true);
                        showPassiveNotification(i18n("Couldn't open %1", localfile.toDisplayString()));
                    }
                }
            });
        }
        , this);
```

#### AUTO 


```{c}
auto replyPut = put(QNetworkRequest(fileUrl), replyGet->readAll());
```

#### AUTO 


```{c}
auto fIsFlatpakBackend = [](AbstractResourcesBackend *backend) {
                        return backend->metaObject()->className() == QByteArray("FlatpakBackend");
                    };
```

#### RANGE FOR STATEMENT 


```{c}
for (auto b : backends)
        addResourcesBackend(b);
```

#### AUTO 


```{c}
const auto enabled = m_settings->useUnattendedUpdates() && m_manager->isOnline() && isConnectionAdequate(m_manager->defaultConfiguration());
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractResource *res : m_toUpgrade) {
        ret += res->size();
    }
```

#### AUTO 


```{c}
auto it = m_flatpakSources.begin();
```

#### AUTO 


```{c}
const auto reply = m_reply->data()[QStringLiteral("reply")].toByteArray();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto installation : installations) {
        if (!listRepositories(installation)) {
            qWarning() << "Failed to list repositories from installation" << installation;
        }
    }
```

#### AUTO 


```{c}
const auto enabled = m_settings->useUnattendedUpdates()
#if QT_VERSION < QT_VERSION_CHECK(6, 0, 0)
        && m_manager->isOnline() && isConnectionAdequate(m_manager->defaultConfiguration());
#elif QT_VERSION >= QT_VERSION_CHECK(6, 3, 0)
        && QNetworkInformation::instance()->reachability() == QNetworkInformation::Reachability::Online && isConnectionAdequate();
```

#### AUTO 


```{c}
auto ret = provider.requestCategories();
```

#### AUTO 


```{c}
auto f = [this, stream, filter] () {
        QVector<AbstractResource*> ret;
        foreach(AbstractResource* r, m_resources) {
            if (r->isTechnical() && filter.state != AbstractResource::Upgradeable) {
                continue;
            }

            if (r->state() < filter.state)
                continue;

            if (filter.search.isEmpty() || r->name().contains(filter.search, Qt::CaseInsensitive) || r->comment().contains(filter.search, Qt::CaseInsensitive)) {
                ret += r;
            }
        }
        auto f = [this](AbstractResource* l, AbstractResource* r) { return flatpakResourceLessThan(l,r); };
        std::sort(ret.begin(), ret.end(), f);
        if (!ret.isEmpty())
            Q_EMIT stream->resourcesFound(ret);
        stream->finish();
    };
```

#### AUTO 


```{c}
auto action = new OneTimeAction(
        [this, app]() {
            auto stream = ResourcesModel::global()->findResourceByPackageName(app);
            connect(stream, &AggregatedResultsStream::resourcesFound, stream, [this, stream](const QVector<AbstractResource*>& resources) {
                stream->setProperty("resources", QVariant::fromValue<QVector<AbstractResource*>>(resources));
            });
            connect(stream, &AggregatedResultsStream::finished, stream, [this, stream, app]() {
                const auto resources = stream->property("resources").value<QVector<AbstractResource*>>();
                if (!resources.isEmpty()) {
                    if (resources.size() > 1)
                        qWarning() << "many resources found for" << app;
                    emit openApplicationInternal(resources.first());
                } else {
                    rootObject()->setProperty("defaultStartup", true);
                    showPassiveNotification(i18n("Couldn't open %1", app.toDisplayString()));
                }
            });
        }
        , this);
```

#### AUTO 


```{c}
auto action = new OneTimeAction(
        [this, url]() {
            AbstractResourcesBackend::Filters f;
            f.resourceUrl = url;
            auto stream = new StoredResultsStream({ResourcesModel::global()->search(f)});
            connect(stream, &StoredResultsStream::finishedResources, this, [this, url](const QVector<AbstractResource *> &res) {
                if (res.count() >= 1) {
                    Q_EMIT openApplicationInternal(res.first());
                } else if (url.scheme() == QLatin1String("snap")) {
                    openApplication(QUrl(QStringLiteral("appstream://org.kde.discover.snap")));
                    showPassiveNotification(i18n("Please make sure Snap support is installed"));
                } else {
                    Q_EMIT openErrorPage(i18n("Could not open %1", url.toDisplayString()));
                }
            });
        },
        this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &path : libraryPaths) {
        QDir dir(path + QStringLiteral("/discover-notifier/"));
        const auto files = dir.entryList(QDir::Files);
        for (const QString &file : files) {
            QString fullPath = dir.absoluteFilePath(file);
            QPluginLoader loader(fullPath);
            loader.load();
            ret += qobject_cast<BackendNotifierModule *>(loader.instance());
            if (ret.last() == nullptr) {
                qWarning() << "couldn't load" << fullPath << "because" << loader.errorString();
                ret.removeLast();
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, resource, fw, runtimeUrl, stream, refSource]() {
            fw->deleteLater();
            const auto metadata = fw->result();
            // Even when we failed to fetch information about runtime we still want to show the application
            if (metadata.isEmpty()) {
                Q_EMIT onFetchMetadataFinished(resource, metadata);
            } else {
                updateAppMetadata(resource, metadata);

                auto runtime = getRuntimeForApp(resource);
                if (!runtime || (runtime && !runtime->isInstalled())) {
                    auto repoStream = new ResultsStream(QLatin1String("FlatpakStream-searchrepo-") + runtimeUrl.toString());
                    connect(repoStream,
                            &ResultsStream::resourcesFound,
                            this,
                            [this, resource, stream, refSource](const QVector<AbstractResource *> &resources) {
                                for (auto res : resources) {
                                    installApplication(res);
                                }
                                refSource->addResource(resource);
                                stream->resourcesFound({resource});
                                stream->finish();
                            });

                    auto fetchRemoteResource = new FlatpakFetchRemoteResourceJob(runtimeUrl, repoStream, this);
                    fetchRemoteResource->start();
                    return;
                } else {
                    refSource->addResource(resource);
                }
            }
            stream->resourcesFound({resource});
            stream->finish();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[stream, ids, this](PackageKit::Transaction::Exit status) {
            getPackagesFinished();
            if (status == PackageKit::Transaction::Exit::ExitSuccess) {
                const auto packageId = stream->property("packageId");
                if (!packageId.isNull()) {
                    const auto res = resourcesByPackageNames<QVector<AbstractResource*>>({PackageKit::Daemon::packageName(packageId.toString())});
                    Q_EMIT stream->resourcesFound(kFilter<QVector<AbstractResource*>>(res, [ids](AbstractResource* res){ return !ids.contains(res->appstreamId()); }));
                }
            }
            stream->finish();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, resource](AbstractResource* res){ return lessThan(res, resource); }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        if (!m_initialized) {
            markInvalid(i18n("Backend %1 took too long to initialize", m_displayName));
            setResponsePending(false);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(QApt::Package* it : pkgList) {
            AbstractResource* res = m_appBackend->resourceByPackageName(it->name());
            if(!res) //If we couldn't find it by its name, try with
                res = m_appBackend->resourceByPackageName(QStringLiteral("%1:%2").arg(it->name()).arg(it->architecture()));

            if(res) {
                if (res->state() == Application::Upgradeable)
                    m_toUpdate += res;
            } else {
                qWarning() << "Couldn't find the package:" << it->name();
            }
            Q_ASSERT(res);
        }
```

#### AUTO 


```{c}
auto req = backend->client()->getInterfaces();
```

#### LAMBDA EXPRESSION 


```{c}
[regularCheck](const QStringRef& value) {
            bool ok;
            int time = value.toInt(&ok);
            if (ok && time > 0) {
                regularCheck->setInterval(time * 60 * 60 * 1000);
            } else {
                regularCheck->setInterval(24 * 60 * 60 * 1000); //refresh at least once every day
                qWarning() << "couldn't understand value for timer:" << value;
            }
            regularCheck->start();
        }
```

#### AUTO 


```{c}
auto repo = flatpak_installation_get_remote_by_name(preferredInstallation(), resource->flatpakName().toUtf8().constData(), m_cancellable, nullptr);
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractResourcesBackend *b : qAsConst(m_backends)) {
        // isFetching should sort of be enough. However, sometimes the backend itself
        // will still be operating on things, which from a model point of view would
        // still mean something going on. So, interpret that as fetching as well, for
        // the purposes of this property.
        if (b->isFetching() || (b->backendUpdater() && b->backendUpdater()->isProgressing())) {
            newFetching = true;
            break;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, fw, stream]() {
                if (g_cancellable_is_cancelled(m_cancellable)) {
                    stream->finish();
                    fw->deleteLater();
                    return;
                }

                const auto refs = fw->result();
                QVector<AbstractResource *> resources;
                for (auto it = refs.constBegin(), itEnd = refs.constEnd(); it != itEnd; ++it) {
                    resources.reserve(resources.size() + it->size());
                    for (auto ref : qAsConst(it.value())) {
                        bool fresh;
                        auto resource = getAppForInstalledRef(it.key(), ref, &fresh);
#if FLATPAK_CHECK_VERSION(1, 1, 2)
                        resource->setAvailableVersion(QString::fromUtf8(flatpak_installed_ref_get_appdata_version(ref)));
#endif
                        g_object_unref(ref);
                        resource->setState(AbstractResource::Upgradeable, !fresh);
                        updateAppSize(resource);
                        if (resource->resourceType() == FlatpakResource::Runtime) {
                            resources.prepend(resource);
                        } else {
                            resources.append(resource);
                        }
                    }
                }

                if (!resources.isEmpty())
                    Q_EMIT stream->resourcesFound(resources);
                stream->finish();
                fw->deleteLater();
            }
```

#### LAMBDA EXPRESSION 


```{c}
[stream, this, state](SnapJob* job) {
        if (!job->isSuccessful()) {
            stream->deleteLater();
            return;
        }

        const auto snaps = job->result().toArray();

        QVector<AbstractResource*> ret;
        QSet<SnapResource*> resources;
        for(const auto& snap: snaps) {
            const auto snapObj = snap.toObject();
            const auto snapid = snapObj.value(QLatin1String("name")).toString();
            SnapResource* res = m_resources.value(snapid);
            if (!res) {
                res = new SnapResource(snapObj, state, this);
                Q_ASSERT(res->packageName() == snapid);
                resources += res;
            }
            ret += res;
        }

        if (!resources.isEmpty()) {
            foreach(SnapResource* res, resources)
                m_resources[res->packageName()] = res;
        }
        if (!ret.isEmpty())
            stream->resourcesFound(ret);
        stream->deleteLater();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto inst : m_installations)
        g_object_unref(inst);
```

#### AUTO 


```{c}
const auto snapid = snapObj.value(QLatin1String("name")).toString();
```

#### LAMBDA EXPRESSION 


```{c}
[this, replyGet] {
            QScopedPointer<QNetworkReply, QScopedPointerDeleteLater> replyPtr(replyGet);
            const QUrl originalUrl = replyGet->request().url();
            if (replyGet->error() != QNetworkReply::NoError) {
                qWarning() << "couldn't download" << originalUrl << replyGet->errorString();
                Q_EMIT jobFinished(false, nullptr);
                return;
            }

            const QUrl fileUrl = QUrl::fromLocalFile(QStandardPaths::writableLocation(QStandardPaths::TempLocation) + QLatin1Char('/') + originalUrl.fileName());
            auto replyPut = put(QNetworkRequest(fileUrl), replyGet->readAll());
            connect(replyPut, &QNetworkReply::finished, this, [this, originalUrl, fileUrl, replyPut]() {
                QScopedPointer<QNetworkReply, QScopedPointerDeleteLater> replyPtr(replyPut);
                if (replyPut->error() != QNetworkReply::NoError) {
                    qWarning() << "couldn't save" << originalUrl << replyPut->errorString();
                    Q_EMIT jobFinished(false, nullptr);
                    return;
                }
                if (!fileUrl.isLocalFile()) {
                    Q_EMIT jobFinished(false, nullptr);
                    return;
                }

                FlatpakResource *resource = nullptr;
                if (fileUrl.path().endsWith(QLatin1String(".flatpak"))) {
                    resource = m_backend->addAppFromFlatpakBundle(fileUrl);
                } else if (fileUrl.path().endsWith(QLatin1String(".flatpakref"))) {
                    resource = m_backend->addAppFromFlatpakRef(fileUrl);
                } else if (fileUrl.path().endsWith(QLatin1String(".flatpakrepo"))) {
                    resource = m_backend->addSourceFromFlatpakRepo(fileUrl);
                }

                if (resource) {
                    resource->setResourceFile(originalUrl);
                    Q_EMIT jobFinished(true, resource);
                } else {
                    qWarning() << "couldn't create resource from" << fileUrl.toLocalFile();
                    Q_EMIT jobFinished(false, nullptr);
                }
            }
            );
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(AbstractResource* res : m_searchResults) {
            if(res == leftPackage)
                return true;
            else if(res == rightPackage)
                return false;
        }
```

#### AUTO 


```{c}
auto start = [this, stream, searchText]() {
        // No need to explicitly launch a search, setting the search term already does that for us
        m_engine->setSearchTerm(searchText);
        m_onePage = false;
        m_responsePending = true;

        connect(this, &KNSBackend::receivedResources, stream, &ResultsStream::resourcesFound);
        connect(this, &KNSBackend::searchFinished, stream, &ResultsStream::finish);
        connect(this, &KNSBackend::startingSearch, stream, &ResultsStream::finish);
    };
```

#### AUTO 


```{c}
auto f = [this, filter, stream] {
            auto resources = kFilter<QVector<AbstractResource*>>(m_packages.packages, [](AbstractResource* res) { return res->type() != AbstractResource::Technical && !qobject_cast<PackageKitResource*>(res)->extendsItself(); });
            if (!resources.isEmpty()) {
                stream->setResources(resources);
            }
            stream->finish();
        };
```

#### RANGE FOR STATEMENT 


```{c}
for (const QApt::SourceEntry &sEntry : m_sourcesList.entries()) {
        if (!sEntry.isValid())
            continue;

        Source* newSource = sourceForUri(sEntry.uri());
        Entry* entry = new Entry(this, sEntry);
        newSource->addEntry(entry);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KNSCore::Provider::CategoryMetadata& category : categoryMetadatas) {
            for (Category* cat : qAsConst(categories)) {
                if (cat->orFilters().count() > 0 && cat->orFilters().constFirst().second == category.name) {
                    cat->setName(category.displayName);
                    break;
                }
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, resource, fw, runtimeUrl]() {
            const auto metadata = fw->result();
            // Even when we failed to fetch information about runtime we still want to show the application
            if (metadata.isEmpty()) {
                Q_EMIT onFetchMetadataFinished(resource, metadata);
            } else {
                updateAppMetadata(resource, metadata);

                auto runtime = getRuntimeForApp(resource);
                if (!runtime || (runtime && !runtime->isInstalled())) {
                    FlatpakFetchRemoteResourceJob *fetchRemoteResource = new FlatpakFetchRemoteResourceJob(runtimeUrl, this);
                    connect(fetchRemoteResource,
                            &FlatpakFetchRemoteResourceJob::jobFinished,
                            this,
                            [this, resource](bool success, FlatpakResource *repoResource) {
                                if (success) {
                                    installApplication(repoResource);
                                }
                                addResource(resource);
                            });
                    fetchRemoteResource->start();
                    return;
                } else {
                    addResource(resource);
                }
            }
            fw->deleteLater();
        }
```

#### AUTO 


```{c}
const auto actualPercentage = percentageWithStatus(status, percentage);
```

#### LAMBDA EXPRESSION 


```{c}
[this, jobs] () {
        for (auto job : jobs) {
            connect(this, &SnapBackend::shuttingDown, job, &T::cancel);
            job->runSync();
        }
    }
```

#### AUTO 


```{c}
auto r = new DiscoverSettings;
```

#### LAMBDA EXPRESSION 


```{c}
[] (AbstractResource* res) { return res->state() == AbstractResource::Broken; }
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractResource *res : resources) {
        connect(res, &AbstractResource::changelogFetched, this, &UpdateModel::integrateChangelog, Qt::UniqueConnection);

        UpdateItem *updateItem = new UpdateItem(res);

        switch (res->type()) {
        case AbstractResource::Technical:
            systemItems += updateItem;
            break;
        case AbstractResource::Application:
            appItems += updateItem;
            break;
        case AbstractResource::Addon:
            addonItems += updateItem;
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(BackendNotifierModule* module : m_backends)
        ret += module->securityUpdatesCount();
```

#### AUTO 


```{c}
const auto idx = index(i, 0);
```

#### AUTO 


```{c}
auto trans = PackageKit::Daemon::getFiles({installedPackageId()});
```

#### AUTO 


```{c}
const auto backends = m->backends();
```

#### RANGE FOR STATEMENT 


```{c}
for(auto r : resources)
            connect(r, &QObject::destroyed, this, [this, r](){
                m_resources.removeAll(r);
            });
```

#### RANGE FOR STATEMENT 


```{c}
for (auto job : jobs) {
            if (job->error()) {
                qDebug() << "error:" << job->error() << job->errorString();
                continue;
            }

            for (int i=0, c=job->snapCount(); i<c; ++i) {
                QSharedPointer<QSnapdSnap> snap(job->snap(i));

                if (!filter(snap))
                    continue;

                const auto snapname = snap->name();
                SnapResource*& res = m_resources[snapname];
                if (!res) {
                    res = new SnapResource(snap, AbstractResource::None, this);
                    Q_ASSERT(res->packageName() == snapname);
                } else {
                    res->setSnap(snap);
                }
                ret += res;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Category *cat : qAsConst(categories)) {
                if (cat->orFilters().count() > 0 && cat->orFilters().constFirst().second == category.name) {
                    cat->setName(category.displayName);
                    break;
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[&filter](const QString& cat) { return filter.category->matchesCategoryName(cat); }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                Q_EMIT startingSearch();
                m_onePage = true;
                m_responsePending = true;
                m_engine->checkForUpdates();
            }
```

#### AUTO 


```{c}
auto start = [this, entryid, stream, providerid]() {
        m_responsePending = true;
        m_engine->fetchEntryById(entryid);
        m_onePage = false;
        connect(m_engine, &KNSCore::Engine::signalError, stream, &ResultsStream::finish);
        connect(m_engine, &KNSCore::Engine::signalEntryDetailsLoaded, stream, [this, stream, entryid, providerid](const KNSCore::EntryInternal &entry) {
            if (entry.uniqueId() == entryid && providerid == QUrl(entry.providerId()).host()) {
                stream->resourcesFound({resourceForEntry(entry)});
            } else
                qWarning() << "found invalid" << entryid << entry.uniqueId() << providerid << QUrl(entry.providerId()).host();
            m_responsePending = false;
            QTimer::singleShot(0, this, &KNSBackend::availableForQueries);
            stream->finish();
        });
    };
```

#### AUTO 


```{c}
auto resources = kFilter<QVector<AbstractResource *>>(m_packages.packages, [](AbstractResource *res) {
                return res->type() != AbstractResource::Technical && !qobject_cast<PackageKitResource *>(res)->extendsItself();
            });
```

#### AUTO 


```{c}
const auto data = fw->result();
```

#### AUTO 


```{c}
const auto runtimeInfo = resource->runtime().splitRef(QLatin1Char('/'));
```

#### LAMBDA EXPRESSION 


```{c}
[chunk]() { return PackageKit::Daemon::getDetails(chunk); }
```

#### AUTO 


```{c}
auto action = new OneTimeAction(
        [this, localfile]() {
            auto res = ResourcesModel::global()->resourceForFile(localfile);
            qCDebug(DISCOVER_LOG) << "all initialized..." << res;
            if (res) {
                emit openApplicationInternal(res);
            } else {
                QMimeDatabase db;
                auto mime = db.mimeTypeForUrl(localfile);
                if (mime.name().startsWith(QLatin1String("application/vnd.flatpak"))) {
                    openApplication(QUrl(QLatin1String("appstream://org.kde.discover.flatpak")));
                    showPassiveNotification(i18n("Cannot interact with flatpak resources without the flatpak backend %1. Please install it first.", localfile.toDisplayString()));
                } else {
                    setRootObjectProperty("defaultStartup", true);
                    showPassiveNotification(i18n("Couldn't open %1", localfile.toDisplayString()));
                }
            }
        }
        , this);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const KConfigGroup &group, const QByteArrayList &names) {
        // Ensure it is for the right file
        if (!names.contains("UseOfflineUpdates") || group.name() != "Software") {
            return;
        }

        if (m_offlineUpdates == group.readEntry<bool>("UseOfflineUpdates", false)) {
            return;
        }
        Q_EMIT useUnattendedUpdatesChanged();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        {
            int ret = 0;
            foreach(AbstractResourcesBackend* backend, m_backends) {
                ret += backend->updatesCount();
            }
            return ret;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto ref : qAsConst(it.value())) {
                        auto resource = getAppForInstalledRef(it.key(), ref);
                        g_object_unref(ref);
                        resource->setState(AbstractResource::Upgradeable);
                        updateAppSize(resource);
                        if (resource->resourceType() == FlatpakResource::Runtime) {
                            resources.prepend(resource);
                        } else {
                            resources.append(resource);
                        }
                    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, runtimeUrl] (FlatpakInstallation *installation, FlatpakResource *resource, const QByteArray &metadata) {
            Q_UNUSED(installation);

            updateAppMetadata(resource, metadata);

            auto runtime = getRuntimeForApp(resource);
            if (!runtime || (runtime && !runtime->isInstalled())) {
                FlatpakFetchRemoteResourceJob *fetchRemoteResource = new FlatpakFetchRemoteResourceJob(runtimeUrl, this);
                connect(fetchRemoteResource, &FlatpakFetchRemoteResourceJob::jobFinished, this, [this, resource] (bool success, FlatpakResource *repoResource) {
                    if (success) {
                        installApplication(repoResource);
                    }
                    addResource(resource);
                });
                fetchRemoteResource->start();
                return;
            } else {
                addResource(resource);
            }
        }
```

#### AUTO 


```{c}
auto start = [this, stream, searchText]() {
        Q_ASSERT(!isFetching());
        if (!m_isValid) {
            stream->finish();
            return;
        }
        // No need to explicitly launch a search, setting the search term already does that for us
        m_engine->setSearchTerm(searchText);
        m_onePage = false;
        m_responsePending = true;

        QSharedPointer<int> count(new int(0));
        connect(this, &KNSBackend::receivedResources, stream, [this, count](const QVector<AbstractResource*>& resources){
            *count += resources.count();
            if (*count>2000)
                m_stopSearching = true;
        });
        connect(this, &KNSBackend::receivedResources, stream, &ResultsStream::resourcesFound);
        connect(this, &KNSBackend::searchFinished, stream, &ResultsStream::finish);
        connect(this, &KNSBackend::startingSearch, stream, &ResultsStream::finish);
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this, filter, stream] {
            auto resources = kFilter<QVector<AbstractResource *>>(m_packages.packages, [](AbstractResource *res) {
                return res->type() != AbstractResource::Technical && !qobject_cast<PackageKitResource *>(res)->isCritical()
                    && !qobject_cast<PackageKitResource *>(res)->extendsItself();
            });
            stream->setResources(resources);
            stream->finish();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, count](const QVector<AbstractResource*>& resources){
            *count += resources.count();
            if (*count>2000)
                m_stopSearching = true;
        }
```

#### AUTO 


```{c}
const auto &alt
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            bool found = DiscoverBackendsFactory::hasRequestedBackends();
            const auto backends = ResourcesModel::global()->backends();
            for (auto b : backends)
                found |= b->hasApplications();

            if (!found)
                Q_EMIT openErrorPage(
                    i18n("Discover currently cannot be used to install any apps "
                         "because none of its app backends are available. Please "
                         "report this error to your distribution."));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &pkgid : itValue) {
            const auto resources = backend->resourcesByPackageName(PackageKit::Daemon::packageName(pkgid));
            for (auto res : resources) {
                auto r = qobject_cast<PackageKitResource *>(res);
                r->clearPackageIds();
                Q_EMIT r->stateChanged();
                needResolving << r->allPackageNames();
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto installation : qAsConst(m_installations)) {
        // Load local updates, comparing current and latest commit
        loadLocalUpdates(installation);

        if (g_cancellable_is_cancelled(m_cancellable))
            break;
    }
```

#### AUTO 


```{c}
auto search = new OneTimeAction(
        [this]() {
            // First we ensure we've got data loaded on what we've got installed already
            Q_EMIT startingSearch();
            m_onePage = true;
            m_responsePending = true;
            m_engine->checkForInstalled();
            // And then we check for updates - we could do only one, if all we cared about was updates,
            // but to have both a useful initial list, /and/ information on updates, we want to get both.
            // The reason we are not doing a checkUpdates() overload for this is that the caching for this
            // information is done by KNSEngine, and we want to actually load it every time we initialize.
            auto updateChecker = new OneTimeAction(
                [this] {
                    //No need to check for updates if there's no resources
                    if (m_resourcesByName.isEmpty()) {
                        return;
                    }

                    Q_EMIT startingSearch();
                    m_onePage = true;
                    m_responsePending = true;
                    m_engine->checkForUpdates();
                },
                this);
            connect(this, &KNSBackend::availableForQueries, updateChecker, &OneTimeAction::trigger, Qt::QueuedConnection);
        },
        this);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        if (m_notifier.needsReboot()) {
            m_notifier.reboot();
        } else {
            m_notifier.showDiscoverUpdates(m_item->providedToken());
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, source](const auto &comp) {
                    return resourceForComponent(comp, source);
                }
```

#### LAMBDA EXPRESSION 


```{c}
[&it](const QString &id) {
                        static const QLatin1String desktopPostfix(".desktop");
                        return it.key().compare(id, Qt::CaseInsensitive) == 0 ||
                            // doing (id == id.key()+".desktop") without allocating
                            (id.size() == (desktopPostfix.size() + it.key().size()) && id.endsWith(desktopPostfix)
                             && id.startsWith(it.key(), Qt::CaseInsensitive)) ||
                            (it.key().size() == (desktopPostfix.size() + id.size()) && it.key().endsWith(desktopPostfix)
                             && it.key().startsWith(id, Qt::CaseInsensitive));
                    }
```

#### LAMBDA EXPRESSION 


```{c}
[stream, ids, this](PackageKit::Transaction::Exit status) {
            getPackagesFinished();
            if (status == PackageKit::Transaction::Exit::ExitSuccess) {
                const auto packageId = stream->property("packageId");
                if (!packageId.isNull()) {
                    const auto res = resourcesByPackageNames<QVector<AbstractResource*>>({PackageKit::Daemon::packageName(packageId.toString())});
                    stream->resourcesFound(kFilter<QVector<AbstractResource*>>(res, [ids](AbstractResource* res){ return !ids.contains(res->appstreamId()); }));
                }
            }
            stream->finish();
        }
```

#### AUTO 


```{c}
auto f = [this, filter, stream] {
            const auto resources = kTransform<QVector<AbstractResource *>>(m_packages.extendedBy.value(filter.extends), [](AppPackageKitResource *a) {
                return a;
            });
            if (!resources.isEmpty()) {
                stream->setResources(resources);
            }
            stream->finish();
        };
```

#### RANGE FOR STATEMENT 


```{c}
for (auto installation : m_installations) {
                g_autoptr(GError) localError = nullptr;
                g_autoptr(GPtrArray) refs = flatpak_installation_list_installed_refs_for_update(installation, m_cancellable, &localError);
                if (!refs) {
                    qWarning() << "Failed to get list of installed refs for listing updates:" << localError->message;
                    continue;
                }

                resources.reserve(resources.size() + refs->len);
                for (uint i = 0; i < refs->len; i++) {
                    FlatpakInstalledRef *ref = FLATPAK_INSTALLED_REF(g_ptr_array_index(refs, i));
                    auto resource = getAppForInstalledRef(installation, ref);
                    resource->setState(AbstractResource::Upgradeable);
                    updateAppSize(resource);
                    if (resource->resourceType() == FlatpakResource::Runtime) {
                        resources.prepend(resource);
                    } else {
                        resources.append(resource);
                    }
                }
            }
```

#### AUTO 


```{c}
auto findComponents = [&](const QString &name) {
            comps = m_pool->componentsById(name);
            if (!comps.isEmpty())
                return;

            comps = m_pool->componentsByProvided(AppStream::Provided::KindId, name);
        };
```

#### AUTO 


```{c}
auto start = [this, stream, searchText]() {
        m_manager->setSearchTerm(searchText);
        m_manager->search(0);
        m_responsePending = true;
        m_page = 0;
        connect(this, &KNSBackend::receivedResources, stream, &ResultsStream::resourcesFound);
        connect(this, &KNSBackend::searchFinished, stream, &ResultsStream::deleteLater);
        connect(this, &KNSBackend::startingSearch, stream, &ResultsStream::deleteLater);
    };
```

#### AUTO 


```{c}
const auto &alias
```

#### LAMBDA EXPRESSION 


```{c}
[this](QSessionManager &sessionManager) {
        if (!quitWhenIdle()) {
            sessionManager.cancel();
        }
    }
```

#### AUTO 


```{c}
auto searchComponent = [this, stream, source, name] {
                auto comps = source->componentsByName(name);
                auto resources = kTransform<QVector<AbstractResource *>>(comps, [this, source](const auto &comp) {
                    return resourceForComponent(comp, source);
                });
                stream->resourcesFound(resources);
                stream->finish();
            };
```

#### AUTO 


```{c}
auto resources= getResources(m_appBackend->search(f), true);
```

#### LAMBDA EXPRESSION 


```{c}
[](const QJsonValue &uri) {
        return QUrl(uri.toString());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString& path : QCoreApplication::instance()->libraryPaths()) {
        QDir dir(path+"/muon-notifier/");
        for(const QString& file : dir.entryList(QDir::Files)) {
            QString fullPath = dir.absoluteFilePath(file);
            QPluginLoader loader(fullPath);
            loader.load();
            ret += qobject_cast<BackendNotifierModule*>(loader.instance());
            if (ret.last() == nullptr) {
                qWarning() << "couldn't load" << fullPath << "because" << loader.errorString();
                ret.removeLast();
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](AppPackageKitResource* r) { return PackageState(r->appstreamId(), r->name(), r->comment(), r->isInstalled()); }
```

#### LAMBDA EXPRESSION 


```{c}
[&resources, stream](const QVector<AbstractResource *> &res) {
        resources += res;
        Q_EMIT stream->fetchMore();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto r : resources) {
                const bool matchById = r->appstreamId().compare(filter.search, Qt::CaseInsensitive) == 0;
                if (r->type() == AbstractResource::Technical && filter.state != AbstractResource::Upgradeable && !matchById) {
                    continue;
                }
                if (r->state() < filter.state)
                    continue;

                if (!filter.extends.isEmpty() && !r->extends().contains(filter.extends))
                    continue;

                if (!filter.mimetype.isEmpty() && !r->mimetypes().contains(filter.mimetype))
                    continue;

                if (filter.search.isEmpty() || matchById) {
                    rest += r;
                } else if (r->name().contains(filter.search, Qt::CaseInsensitive)) {
                    prioritary += r;
                } else if (r->comment().contains(filter.search, Qt::CaseInsensitive)) {
                    rest += r;
                }
            }
```

#### AUTO 


```{c}
const auto pkgname = PackageKit::Daemon::packageName(pkgid);
```

#### LAMBDA EXPRESSION 


```{c}
[this, app]() {
            auto stream = ResourcesModel::global()->findResourceByPackageName(app);
            connect(stream, &AggregatedResultsStream::resourcesFound, stream, [this, stream](const QVector<AbstractResource*>& resources) {
                stream->setProperty("resources", QVariant::fromValue<QVector<AbstractResource*>>(resources));
            });
            connect(stream, &AggregatedResultsStream::finished, stream, [this, stream, app]() {
                const auto resources = stream->property("resources").value<QVector<AbstractResource*>>();
                if (!resources.isEmpty()) {
                    if (resources.size() > 1)
                        qWarning() << "many resources found for" << app;
                    emit openApplicationInternal(resources.first());
                } else {
                    rootObject()->setProperty("defaultStartup", true);
                    showPassiveNotification(i18n("Couldn't open %1", app.toDisplayString()));
                }
            });
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, app](PackageKit::Transaction::Exit status) {
            const bool simulate = m_trans->transactionFlags() & PackageKit::Transaction::TransactionFlagSimulate;
            if (!simulate && status == PackageKit::Transaction::ExitSuccess) {
                app->markInstalled();
            }
        }
```

#### AUTO 


```{c}
auto filter = m_orFilters.constBegin();
```

#### LAMBDA EXPRESSION 


```{c}
[&suffix](const AppStream::Component &component) {
            return component.bundle(AppStream::Bundle::KindFlatpak).id().endsWith(suffix);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto slot: theSlots) {
                    auto item = new QStandardItem;
                    if (plug->label().isEmpty())
                        item->setText(plug->name());
                    else
                        item->setText(i18n("%1 - %2", plug->name(), plug->label()));

//                     qDebug() << "xxx" << plug->name() << plug->label() << plug->interface() << slot->snap() << "slot:" << slot->name() << slot->snap() << slot->interface() << slot->label();
                    item->setCheckable(true);
                    item->setCheckState(plug->connectionCount()>0 ? Qt::Checked : Qt::Unchecked);
                    item->setData(plug->name(), PlugNameRole);
                    item->setData(slot->snap(), SlotSnapRole);
                    item->setData(slot->name(), SlotNameRole);
                    appendRow(item);
                }
```

#### AUTO 


```{c}
auto id = (*it)->appstreamId();
```

#### LAMBDA EXPRESSION 


```{c}
[this](int progress) {
              Q_EMIT fetchingUpdatesProgressChanged(progress);
          }
```

#### AUTO 


```{c}
const auto finder = [this](AbstractResource* resource, AbstractResource* res){ return lessThan(resource, res); };
```

#### LAMBDA EXPRESSION 


```{c}
[res, engine]() {
                for(auto i : res->linkIds())
                    engine->install(res->entry(), i);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this, appstreamIds, stream] () {
                AbstractResource* pkg = nullptr;

                QStringList allAppStreamIds = appstreamIds;
                {
                    auto it = deprecatedAppstreamIds.constFind(appstreamIds.first());
                    if (it != deprecatedAppstreamIds.constEnd()) {
                        allAppStreamIds << *it;
                    }
                }

                for (auto it = m_packages.packages.constBegin(), itEnd = m_packages.packages.constEnd(); it != itEnd; ++it) {
                    const bool matches = kContains(allAppStreamIds, [&it] (const QString& id) {
                        static const QLatin1String desktopPostfix(".desktop");
                        return it.key().compare(id, Qt::CaseInsensitive) == 0 ||
                              //doing (id == id.key()+".desktop") without allocating
                              (id.size() == (desktopPostfix.size() + it.key().size()) && id.endsWith(desktopPostfix) && id.startsWith(it.key(), Qt::CaseInsensitive));
                    });
                    if (matches) {
                        pkg = it.value();
                        break;
                    }
                }
                if (pkg)
                    stream->setResources({pkg});
                stream->finish();
    //             if (!pkg)
    //                 qCDebug(LIBDISCOVER_BACKEND_LOG) << "could not find" << host << deprecatedHost;
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            m_refresher = nullptr;
            reloadPackageList();
            acquireFetching(false);
        }
```

#### AUTO 


```{c}
const auto oldLicense = m_details.license();
```

#### AUTO 


```{c}
auto it=m_actions.begin();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto res : resources) {
            ret += res->size();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[stream, toResolve, installedAndNameFilter] {
                    const auto resolved = kFilter<QVector<AbstractResource *>>(toResolve, installedAndNameFilter);
                    if (!resolved.isEmpty())
                        Q_EMIT stream->resourcesFound(resolved);
                    stream->finish();
                }
```

#### AUTO 


```{c}
const auto f = [this, appstreamIds, stream] () {
                AbstractResource* pkg = nullptr;

                const QStringList allAppStreamIds = appstreamIds + deprecatedAppstreamIds.values(appstreamIds.first());
                for (auto it = m_packages.packages.constBegin(), itEnd = m_packages.packages.constEnd(); it != itEnd; ++it) {
                    const bool matches = kContains(allAppStreamIds, [&it] (const QString& id) {
                        return it.key().compare(id, Qt::CaseInsensitive) == 0 ||
                              (id.endsWith(QLatin1String(".desktop")) && id.compare(it.key()+QLatin1String(".desktop"), Qt::CaseInsensitive) == 0);
                    });
                    if (matches) {
                        pkg = it.value();
                        break;
                    }
                }
                if (pkg)
                    Q_EMIT stream->resourcesFound({pkg});
                stream->finish();
    //             if (!pkg)
    //                 qCDebug(LIBDISCOVER_BACKEND_LOG) << "could not find" << host << deprecatedHost;
            };
```

#### LAMBDA EXPRESSION 


```{c}
[this, url](const QVector<AbstractResource *> &res) {
                if (res.count() >= 1) {
                    emit openApplicationInternal(res.first());
                } else if (url.scheme() == QLatin1String("snap")) {
                    openApplication(QUrl(QStringLiteral("appstream://org.kde.discover.snap")));
                    showPassiveNotification(i18n("Please make sure Snap support is installed"));
                } else {
                    Q_EMIT openErrorPage(i18n("Could not open %1", url.toDisplayString()));
                }
            }
```

#### AUTO 


```{c}
auto reply = QDBusConnection::sessionBus().call(message);
```

#### AUTO 


```{c}
auto start = [this, stream, searchText]() {
        Q_ASSERT(!isFetching());
        if (!m_isValid) {
            stream->finish();
            return;
        }
        // No need to explicitly launch a search, setting the search term already does that for us
        m_engine->setSearchTerm(searchText);
        m_onePage = false;
        m_responsePending = true;

        connect(stream, &ResultsStream::fetchMore, this, &KNSBackend::fetchMore);
        connect(this, &KNSBackend::receivedResources, stream, &ResultsStream::resourcesFound);
        connect(this, &KNSBackend::searchFinished, stream, &ResultsStream::finish);
        connect(this, &KNSBackend::startingSearch, stream, &ResultsStream::finish);
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QVector<AbstractResource*> & res){
        Q_ASSERT(!res.isEmpty());

        emit openApplicationInternal(res.first());
        m_appToBeOpened.clear();
    }
```

#### AUTO 


```{c}
auto stream = new StoredResultsStream({ResourcesModel::global()->search(f)});
```

#### RANGE FOR STATEMENT 


```{c}
for (auto res: m_resources) {
            if (ret->resources().contains(res))
                res->setState(AbstractResource::Installed);
            else
                res->setState(AbstractResource::None);
        }
```

#### AUTO 


```{c}
const auto f = [this, stream, filter] () {
            const QList<AppStream::Component> components = m_appdata->search(filter.search);
            const QStringList ids = kTransform<QStringList>(components, [](const AppStream::Component& comp) { return comp.id(); });
            if (!ids.isEmpty()) {
                const auto resources = kFilter<QVector<AbstractResource*>>(resourcesByPackageNames<QVector<AbstractResource*>>(ids), [](AbstractResource* res){ return !qobject_cast<PackageKitResource*>(res)->extendsItself(); });
                stream->setResources(resources);
            }

            PackageKit::Transaction * tArch = PackageKit::Daemon::resolve(filter.search, PackageKit::Transaction::FilterArch);
            connect(tArch, &PackageKit::Transaction::package, this, &PackageKitBackend::addPackageArch);
            connect(tArch, &PackageKit::Transaction::package, stream, [stream](PackageKit::Transaction::Info /*info*/, const QString &packageId){
                stream->setProperty("packageId", packageId);
            });
            connect(tArch, &PackageKit::Transaction::finished, stream, [stream, ids, this](PackageKit::Transaction::Exit status) {
                getPackagesFinished();
                if (status == PackageKit::Transaction::Exit::ExitSuccess) {
                    const auto packageId = stream->property("packageId");
                    if (!packageId.isNull()) {
                        const auto res = resourcesByPackageNames<QVector<AbstractResource*>>({PackageKit::Daemon::packageName(packageId.toString())});
                        stream->setResources(kFilter<QVector<AbstractResource*>>(res, [ids](AbstractResource* res){ return !ids.contains(res->appstreamId()); }));
                    }
                }
                stream->finish();
            }, Qt::QueuedConnection);
        };
```

#### LAMBDA EXPRESSION 


```{c}
[](AbstractBackendUpdater* u) {return u->hasUpdates(); }
```

#### LAMBDA EXPRESSION 


```{c}
[](AbstractResource *a) {
                    return a->name();
                }
```

#### LAMBDA EXPRESSION 


```{c}
[t, this](PackageKit::Transaction::Exit status, uint runtime){
        QMap<PackageKit::Transaction::Info, QStringList> packages = t->property("packages").value<QMap<PackageKit::Transaction::Info, QStringList>>();
        qobject_cast<PackageKitResource*>(resource())->setPackages(packages);
        setStatus(Transaction::DoneStatus);
        qobject_cast<PackageKitBackend*>(resource()->backend())->removeTransaction(this);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[app](PackageKit::Transaction::Exit status) {
            if (status == PackageKit::Transaction::ExitSuccess) {
                app->markInstalled();
            }
        }
```

#### AUTO 


```{c}
const auto ext = kTransform<QVector<AbstractResource*>>(m_packages.extendedBy[filter.extends], [](AppPackageKitResource* a){ return a; });
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            auto trans = PackageKit::Daemon::global()->repairSystem();
            connect(trans, &PackageKit::Transaction::errorCode, this, [](PackageKit::Transaction::Error /*error*/, const QString &details) {
                KNotification::event(QStringLiteral("OfflineUpdateRepairFailed"),
                                     i18n("Repair Failed"),
                                     xi18nc("@info", "%1<nl/>Please report this error to your distribution.", details),
                                     {},
                                     KNotification::Persistent,
                                     QStringLiteral("org.kde.discovernotifier"));
            });
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](AbstractResource* res) { return !res->isTechnical(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const QString appstreamId) { return resourcesByAppstreamName(appstreamId); }
```

#### LAMBDA EXPRESSION 


```{c}
[this, installation, fw]() {
        g_autoptr(GPtrArray) refs = fw->result();
        onFetchUpdatesFinished(installation, refs);
        fw->deleteLater();
        acquireFetching(false);
    }
```

#### AUTO 


```{c}
auto trans = PackageKit::Daemon::dependsOn(id);
```

#### AUTO 


```{c}
auto x = qobject_cast<AggregatedResultsStream*>(stream)
```

#### LAMBDA EXPRESSION 


```{c}
[this](){ processReply(m_socket); }
```

#### LAMBDA EXPRESSION 


```{c}
[file, reply]() {
            file->write(reply->readAll());
        }
```

#### AUTO 


```{c}
auto id = QVariant(QStringLiteral("id"));
```

#### RANGE FOR STATEMENT 


```{c}
for (Transaction* t : m_transactions) {
        PKTransaction* pkt = qobject_cast<PKTransaction*>(t);
        if (pkt->resource() == app) {
            if (pkt->transaction()->allowCancel()) {
                pkt->transaction()->cancel();
                int count = m_transactions.removeAll(t);
                Q_ASSERT(count==1);
                Q_UNUSED(count)
                //TransactionModel::global()->cancelTransaction(t);
            } else {
                qWarning() << "trying to cancel a non-cancellable transaction: " << app->name();
            }
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(AbstractResource* res : m_packages.values()) {
        if (res->name().contains(searchText, Qt::CaseInsensitive)) {
//             kDebug() << "Got one" << res->name();
            ret += res;
        }
    }
```

#### AUTO 


```{c}
auto upd
```

#### AUTO 


```{c}
auto aliased = aliases.constFind(appstreamid);
```

#### RANGE FOR STATEMENT 


```{c}
for(auto r : res)
        connect(r, &QObject::destroyed, this, &AggregatedResultsStream::resourceDestruction);
```

#### AUTO 


```{c}
const auto packageExecutables = kFilter<QStringList>(allServices, [filenames](const QString &exe) { return filenames.contains(QLatin1Char('/') + exe); });
```

#### AUTO 


```{c}
const auto idx = versions.indexOf(u'\u009C');
```

#### AUTO 


```{c}
auto stream = new ResultsStream(QStringLiteral("KNS-search-")+name());
```

#### AUTO 


```{c}
auto reply = manager->get(QNetworkRequest(uri));
```

#### AUTO 


```{c}
auto stream = new PKResultsStream(this, QStringLiteral("PackageKitStream-extends"));
```

#### LAMBDA EXPRESSION 


```{c}
[this, file, reply]() {
            file->close();
            file->deleteLater();

            if (reply->error() != QNetworkReply::NoError) {
                qWarning() << "Fwupd Error: Could not download" << reply->url() << reply->errorString();
                file->remove();
                setStatus(DoneWithErrorStatus);
            } else {
                fwupdInstall(file->fileName());
            }
        }
```

#### AUTO 


```{c}
const auto theSlots = slotsForInterface.value(plug->interface());
```

#### RANGE FOR STATEMENT 


```{c}
for(QAction* action: b->actions())
            ret.append(action);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto installation : qAsConst(m_installations)) {
        // Load applications from appstream metadata
        if (g_cancellable_is_cancelled(m_cancellable))
            break;

        if (!loadAppsFromAppstreamData(installation)) {
            qWarning() << "Failed to load packages from appstream data from installation" << installation;
        }
    }
```

#### AUTO 


```{c}
auto idx = m_categories.indexOf(static_cast<Category*>(cat));
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        transactionChanged(StatusTextRole);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto source : qAsConst(m_flatpakSources)) {
        if (source->url() == flatpak_remote_get_url(remote)) {
            qDebug() << "do not add a source twice" << source << remote;
            metadataRefreshed();
            return source;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            // First we ensure we've got data loaded on what we've got installed already
            Q_EMIT startingSearch();
            m_onePage = true;
            m_responsePending = true;
            m_engine->checkForInstalled();
            // And then we check for updates - we could do only one, if all we cared about was updates,
            // but to have both a useful initial list, /and/ information on updates, we want to get both.
            // The reason we are not doing a checkUpdates() overload for this is that the caching for this
            // information is done by KNSEngine, and we want to actually load it every time we initialize.
            auto updateChecker = new OneTimeAction(
                [this]() {
                    Q_EMIT startingSearch();
                    m_onePage = true;
                    m_responsePending = true;
                    m_engine->checkForUpdates();
                },
                this);
            connect(this, &KNSBackend::availableForQueries, updateChecker, &OneTimeAction::trigger, Qt::QueuedConnection);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &x : set)
        ret.append(x);
```

#### AUTO 


```{c}
auto ret = kTransform<QVector<AbstractResourcesBackend*>>(names, [this](const QString& name) { return backend(name); });
```

#### AUTO 


```{c}
const auto downloadInfo = m_entry.downloadLinkInformationList();
```

#### LAMBDA EXPRESSION 


```{c}
[] (AbstractResource* res) { return !static_cast<PackageKitResource*>(res)->extendsItself(); }
```

#### AUTO 


```{c}
auto b = qobject_cast<SnapBackend*>(backend());
```

#### RANGE FOR STATEMENT 


```{c}
for(auto cat: cats) {
        sortCategories(cat->m_subCategories);
    }
```

#### AUTO 


```{c}
auto & elem
```

#### AUTO 


```{c}
const auto snaps = job->result().toArray();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        m_notifier.showDiscoverUpdates();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QPair<FilterType, QString> &filter : m_andFilters) {
        if(!shouldFilter(res, filter))
            return false;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, installation, resource, fw, runtimeUrl]() {
            const auto metadata = fw->result();
            // Even when we failed to fetch information about runtime we still want to show the application
            if (metadata.isEmpty()) {
                onFetchMetadataFinished(installation, resource, metadata);
            } else {
                updateAppMetadata(resource, metadata);

                auto runtime = getRuntimeForApp(resource);
                if (!runtime || (runtime && !runtime->isInstalled())) {
                    FlatpakFetchRemoteResourceJob *fetchRemoteResource = new FlatpakFetchRemoteResourceJob(runtimeUrl, this);
                    connect(fetchRemoteResource, &FlatpakFetchRemoteResourceJob::jobFinished, this, [this, resource] (bool success, FlatpakResource *repoResource) {
                        if (success) {
                            installApplication(repoResource);
                        }
                        addResource(resource);
                    });
                    fetchRemoteResource->start();
                    return;
                } else {
                    addResource(resource);
                }
            }
            fw->deleteLater();
        }
```

#### AUTO 


```{c}
const auto idx = statuses.value(status, -1);
```

#### AUTO 


```{c}
auto mAboutAppAction = KStandardAction::aboutApp(this, &DiscoverMainWindow::aboutApplication, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto inst : qAsConst(m_installations))
        g_object_unref(inst);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &source : m_flatpakSources) {
        for (auto it = source->m_resources.constBegin(), itEnd = source->m_resources.constEnd(); it != itEnd; ++it) {
            const auto &id = it.key();
            if (id.type == FlatpakResource::Runtime && id.id == runtimeInfo.at(0) && id.branch == runtimeInfo.at(2)) {
                runtime = *it;
                break;
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[stream, this, job]() {
        if (job->error()) {
            qDebug() << "error:" << job->error() << job->errorString();
            stream->finish();
            return;
        }

        QVector<AbstractResource*> ret;
        QSet<SnapResource*> resources;
        resources.reserve(job->snapCount());
        for (int i=0, c=job->snapCount(); i<c; ++i) {
            QSharedPointer<QSnapdSnap> snap(job->snap(i));
            const auto snapname = snap->name();
            SnapResource* res = m_resources.value(snapname);
            if (!res) {
                res = new SnapResource(snap, AbstractResource::None, this);
                Q_ASSERT(res->packageName() == snapname);
                resources += res;
            } else {
                res->setSnap(snap);
            }
            ret += res;
        }

        foreach(SnapResource* res, resources)
            m_resources[res->packageName()] = res;

        if (!ret.isEmpty())
            stream->resourcesFound(ret);
        stream->finish();
    }
```

#### AUTO 


```{c}
const auto order = QVariant::compare(leftValue, rightValue);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& exec : execs) {
        KService::Ptr service = KService::serviceByStorageId(exec);

        QString name = service->property("Name").toString();
        if (!service->genericName().isEmpty())
            name += QLatin1String(" - ") % service->genericName();

        QStandardItem *item = new QStandardItem(name);
        item->setIcon(KIcon(service->icon()));
        item->setData(service->desktopEntryPath(), Qt::UserRole);
        items += item;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](PackageKit::Transaction::Error /*error*/, const QString &details){
                KNotification::event(QStringLiteral("offlineupdate-repair-failed"), i18n("Repair Failed"), i18n("Please report to your distribution: %1", details), {}, KNotification::Persistent, QStringLiteral("org.kde.discovernotifier"));
            }
```

#### AUTO 


```{c}
auto it=sortedResources.constBegin(), itEnd=sortedResources.constEnd();
```

#### LAMBDA EXPRESSION 


```{c}
[cancel, this](PackageKit::Transaction::Exit /*status*/, uint /*runtime*/) {
        this->submitResolve();
        auto backend = qobject_cast<PackageKitBackend*>(resource()->backend());
        if (cancel) backend->transactionCanceled(this);
        else backend->removeTransaction(this);
        backend->fetchUpdates();
    }
```

#### AUTO 


```{c}
const auto desktopFiles = kFilter<QStringList>(filenames, [locations](const QString &exe) {
                    for (const auto &location: locations) {
                        if (exe.startsWith(location))
                            return exe.contains(QLatin1String(".desktop"));
                    }
                    return false;
                });
```

#### AUTO 


```{c}
auto fw = new QFutureWatcher<QByteArray>(this);
```

#### LAMBDA EXPRESSION 


```{c}
[](PackageKit::Transaction::Error, const QString& msg){ qWarning() << "error fetching details" << msg; }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &alt : alts) {
                    at = ids.find(alt);
                    if (at != ids.end())
                        break;

                    auto aliased = aliases.constFind(appstreamid);
                    if (aliased != aliases.constEnd()) {
                        at = ids.find(aliased.value());
                        if (at != ids.end())
                            break;
                    }
                }
```

#### AUTO 


```{c}
const auto cats = m_filters.category ? m_filters.category->subCategories().toList() : CategoryModel::rootCategories();
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool fetching) {
        m_updateAction->setEnabled(!fetching);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&it](const QString &id) {
                        static const QLatin1String desktopPostfix(".desktop");
                        return it.key().compare(id, Qt::CaseInsensitive) == 0 ||
                            // doing (id == id.key()+".desktop") without allocating
                            (id.size() == (desktopPostfix.size() + it.key().size()) && id.endsWith(desktopPostfix)
                             && id.startsWith(it.key(), Qt::CaseInsensitive));
                    }
```

#### AUTO 


```{c}
const auto ids = m_packageNamesToFetchDetails.toList();
```

#### AUTO 


```{c}
auto list = m_transQueue.values();
```

#### AUTO 


```{c}
auto mSwitchApplicationLanguageAction = KStandardAction::create(KStandardAction::SwitchApplicationLanguage, this, SLOT(switchApplicationLanguage()), this);
```

#### AUTO 


```{c}
auto job = m_socket->changes(m_changeId);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &alt : alts) {
                at = storedIds.find(alt);
                if (at == storedIds.end())
                    break;

                auto aliased = aliases.constFind(alt);
                if (aliased != aliases.constEnd()) {
                    at = storedIds.find(aliased.value());
                    if (at != storedIds.end())
                        break;
                }
            }
```

#### AUTO 


```{c}
auto f = [menu, this]() {
        m_item->setTitle(i18n("Restart to apply installed updates"));
        m_item->setToolTipTitle(i18n("Click to restart the computer"));
        m_item->setIconByName(QStringLiteral("view-refresh"));
        auto refreshAction = menu->addAction(QIcon::fromTheme(QStringLiteral("view-refresh")), i18n("Restart..."));
        connect(refreshAction, &QAction::triggered, &m_notifier, &DiscoverNotifier::recheckSystemUpdateNeeded);
    };
```

#### LAMBDA EXPRESSION 


```{c}
[=] {
        acquireFetching(false);
    }
```

#### AUTO 


```{c}
const auto &ext
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        m_reviews->emitRatingFetched(this, kAppend<QList<AbstractResource *>>(m_flatpakSources, [](const auto &source) {
                                         return kTransform<QList<AbstractResource *>>(source->m_resources.values());
                                     }));
    }
```

#### AUTO 


```{c}
const auto allServices = QStandardPaths::locateAll(QStandardPaths::ApplicationsLocation, m_appdata.id());
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
                fetchUpdateDetails();
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this, stream, filter]() {
        QVector<AbstractResource *> prioritary, rest;
        for (auto r : qAsConst(m_resources)) {
            const bool matchById = r->appstreamId().compare(filter.search, Qt::CaseInsensitive) == 0;
            if (r->type() == AbstractResource::Technical && filter.state != AbstractResource::Upgradeable && !matchById) {
                continue;
            }
            if (r->state() < filter.state)
                continue;

            if (!filter.extends.isEmpty() && !r->extends().contains(filter.extends))
                continue;

            if (!filter.mimetype.isEmpty() && !r->mimetypes().contains(filter.mimetype))
                continue;

            if (filter.search.isEmpty() || matchById) {
                rest += r;
            } else if (r->name().contains(filter.search, Qt::CaseInsensitive)) {
                prioritary += r;
            } else if (r->comment().contains(filter.search, Qt::CaseInsensitive)) {
                rest += r;
            }
        }
        auto f = [this](AbstractResource *l, AbstractResource *r) {
            return flatpakResourceLessThan(l, r);
        };
        std::sort(rest.begin(), rest.end(), f);
        std::sort(prioritary.begin(), prioritary.end(), f);
        rest = prioritary + rest;
        if (!rest.isEmpty())
            Q_EMIT stream->resourcesFound(rest);
        stream->finish();
    }
```

#### AUTO 


```{c}
const auto matchedCategories = walkCategories(const_cast<AbstractResource*>(this), CategoryModel::rootCategories().toVector());
```

#### AUTO 


```{c}
const auto pkgname = PackageKit::Daemon::packageName(i.next());
```

#### LAMBDA EXPRESSION 


```{c}
[this, fw, pool, source]() {
        source->m_pool = pool;
        m_flatpakLoadingSources.removeAll(source);
        if (fw->result()) {
            m_flatpakSources += source;
        } else {
            qWarning() << "Could not open the AppStream metadata pool" << pool->lastError();
        }
        metadataRefreshed(source->remote());
        acquireFetching(false);
        fw->deleteLater();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, stream, searchText]() {
        Q_ASSERT(!isFetching());
        if (!m_isValid) {
            qWarning() << "querying an invalid backend";
            stream->finish();
            return;
        }

        if (m_responsePending || stream->property("alreadyStarted").toBool()) {
            return;
        }
        stream->setProperty("alreadyStarted", true);
        setResponsePending(true);

        // No need to explicitly launch a search, setting the search term already does that for us
        m_engine->setSearchTerm(searchText);
        m_onePage = false;

        connect(stream, &ResultsStream::fetchMore, this, &KNSBackend::fetchMore);
        connect(this, &KNSBackend::receivedResources, stream, &ResultsStream::resourcesFound);
        connect(this, &KNSBackend::searchFinished, stream, &ResultsStream::finish);
        connect(this, &KNSBackend::startingSearch, stream, &ResultsStream::finish);
    }
```

#### AUTO 


```{c}
const auto type = resource->type() == FlatpakResource::DesktopApp ? FLATPAK_REF_KIND_APP : FLATPAK_REF_KIND_RUNTIME;
```

#### LAMBDA EXPRESSION 


```{c}
[this, localfile]() {
            auto res = ResourcesModel::global()->resourceForFile(localfile);
            qCDebug(DISCOVER_LOG) << "all initialized..." << res;
            if (res) {
                emit openApplicationInternal(res);
            } else {
                QMimeDatabase db;
                auto mime = db.mimeTypeForUrl(localfile);
                if (mime.name().startsWith(QLatin1String("application/vnd.flatpak"))) {
                    openApplication(QUrl(QLatin1String("appstream://org.kde.discover.flatpak")));
                    showPassiveNotification(i18n("Cannot interact with flatpak resources without the flatpak backend %1. Please install it first.", localfile.toDisplayString()));
                } else {
                    setRootObjectProperty("defaultStartup", true);
                    showPassiveNotification(i18n("Couldn't open %1", localfile.toDisplayString()));
                }
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        if (!m_initialized) {
            markInvalid(i18n("Backend %1 took too long to initialize", m_displayName));
            m_responsePending = false;
            Q_EMIT searchFinished();
            Q_EMIT availableForQueries();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &file) {
        auto service = PackageKitBackend::locateService(file);
        if (!service.isEmpty())
            m_actions += QVariant::fromValue<QObject *>(createActionForService(service, this));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, url]() {
            AbstractResourcesBackend::Filters f;
            f.resourceUrl = url;
            auto stream = new StoredResultsStream({ResourcesModel::global()->search(f)});
            connect(stream, &StoredResultsStream::finishedResources, this, [this, url](const QVector<AbstractResource*> &res) {
                if (res.count() >= 1) {
                    emit openApplicationInternal(res.first());
                } else {
                    Q_EMIT openErrorPage(i18n("Couldn't open %1", url.toDisplayString()));
                }
            });
        }
```

#### AUTO 


```{c}
auto remote = flatpak_installation_get_remote_by_name(installation, name.toUtf8(), m_cancellable, &localError);
```

#### AUTO 


```{c}
const auto summary = m_appdata.summary();
```

#### LAMBDA EXPRESSION 


```{c}
[this, entryid, stream, providerid]() {
        m_responsePending = true;
        m_engine->fetchEntryById(entryid);
        m_onePage = false;

        connect(m_engine, &KNSCore::Engine::signalErrorCode, stream, &ResultsStream::finish);
        connect(m_engine, &KNSCore::Engine::signalEntryDetailsLoaded, stream, [this, stream, entryid, providerid](const KNSCore::EntryInternal &entry) {
            if (entry.uniqueId() == entryid && providerid == QUrl(entry.providerId()).host()) {
                Q_EMIT stream->resourcesFound({resourceForEntry(entry)});
            } else
                qWarning() << "found invalid" << entryid << entry.uniqueId() << providerid << QUrl(entry.providerId()).host();
            m_responsePending = false;
            QTimer::singleShot(0, this, &KNSBackend::availableForQueries);
            stream->finish();
        });
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractResourcesBackend *backend : qAsConst(m_backends)) {
        ret = backend->extends().contains(id);
        if (ret)
            break;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            setCancellable(m_updater->isCancelable());
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](){
        auto job = m_socket->changes(m_changeId);
        connect(job, &SnapJob::finished, this, &SnapTransaction::iterateTransaction);
    }
```

#### AUTO 


```{c}
auto comps = source->m_pool->componentsById(name) + source->m_pool->componentsById(nameWithDesktop);
```

#### AUTO 


```{c}
const auto backend = qobject_cast<PackageKitBackend *>(resource()->backend());
```

#### LAMBDA EXPRESSION 


```{c}
[this, url, stream]() {
                const auto res = stream->resources();
                if (res.count() >= 1) {
                    emit openApplicationInternal(res.first());
                } else {
                    setRootObjectProperty("defaultStartup", true);
                    Q_EMIT openErrorPage(i18n("Couldn't open %1", url.toDisplayString()));
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this, stream, filter] {
            const auto toResolve = kFilter<QVector<AbstractResource*>>(m_packages.packages, needsResolveFilter);

            auto installedAndNameFilter = [filter] (AbstractResource *res) {
                return res->state() >= AbstractResource::Installed && (res->name().contains(filter.search) || res->packageName() == filter.search);
            };
            bool furtherSearch = false;
            if (!toResolve.isEmpty()) {
                resolvePackages(kTransform<QStringList>(toResolve, [] (AbstractResource* res) { return res->packageName(); }));
                connect(m_resolveTransaction, &PKResolveTransaction::allFinished, this, [stream, toResolve, installedAndNameFilter] {
                    const auto resolved = kFilter<QVector<AbstractResource*>>(toResolve, installedAndNameFilter);
                    if (!resolved.isEmpty())
                        Q_EMIT stream->resourcesFound(resolved);
                    stream->finish();
                });
                furtherSearch = true;
            }

            const auto resolved = kFilter<QVector<AbstractResource*>>(m_packages.packages, installedAndNameFilter);
            if (!resolved.isEmpty()) {
                QTimer::singleShot(0, this, [resolved, toResolve, stream] () {
                    if (!resolved.isEmpty())
                        Q_EMIT stream->resourcesFound(resolved);

                    if (toResolve.isEmpty())
                        stream->finish();
                });
                furtherSearch = true;
            }

            if (!furtherSearch)
                stream->finish();
        }
```

#### AUTO 


```{c}
const auto row = item->row();
```

#### LAMBDA EXPRESSION 


```{c}
[this, packageDependencies](PackageKit::Transaction::Exit /*status*/) {
        std::sort(packageDependencies->begin(), packageDependencies->end(), [](QJsonValue a, QJsonValue b) {
            const auto objA = a.toObject(), objB = b.toObject();
            return objA[QLatin1String("packageInfo")].toString() < objB[QLatin1String("packageInfo")].toString()
                || (objA[QLatin1String("packageInfo")].toString() == objB[QLatin1String("packageInfo")].toString()
                    && objA[QLatin1String("packageName")].toString() < objB[QLatin1String("packageName")].toString());
        });

        Q_EMIT dependenciesFound(*packageDependencies);
        setDependenciesCount(packageDependencies->size());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, replyGet] {
            const QUrl originalUrl = replyGet->request().url();
            if (replyGet->error() != QNetworkReply::NoError) {
                qWarning() << "couldn't download" << originalUrl << replyGet->errorString();
                Q_EMIT jobFinished(false, nullptr);
                return;
            }

            const QUrl fileUrl = QUrl::fromLocalFile(QStandardPaths::writableLocation(QStandardPaths::TempLocation) + QLatin1Char('/') + originalUrl.fileName());
            auto replyPut = put(QNetworkRequest(fileUrl), replyGet->readAll());
            connect(replyPut, &QNetworkReply::finished, this, [this, originalUrl, fileUrl, replyPut]() {
                if (replyPut->error() == QNetworkReply::NoError) {
                    auto res = m_backend->resourceForFile(fileUrl);
                    if (res) {
                        FlatpakResource *resource = qobject_cast<FlatpakResource*>(res);
                        resource->setResourceFile(originalUrl);
                        Q_EMIT jobFinished(true, resource);
                    } else {
                        qWarning() << "couldn't download" << originalUrl << "into" << fileUrl << replyPut->errorString();
                        Q_EMIT jobFinished(false, nullptr);
                    }
                }
            });
        }
```

#### AUTO 


```{c}
const auto packageExecutables = kFilter<QStringList>(exes, [filenames](const QString &exe) {
                return filenames.contains(QLatin1Char('/') + exe);
            });
```

#### AUTO 


```{c}
auto msg = new QAction(i18n("Got it"), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto r : qAsConst(m_resources)) {
            const bool matchById = r->appstreamId().compare(filter.search, Qt::CaseInsensitive) == 0;
            if (r->type() == AbstractResource::Technical && filter.state != AbstractResource::Upgradeable && !matchById) {
                continue;
            }
            if (r->state() < filter.state)
                continue;

            if (!filter.extends.isEmpty() && !r->extends().contains(filter.extends))
                continue;

            if (filter.search.isEmpty() || r->name().contains(filter.search, Qt::CaseInsensitive) || r->comment().contains(filter.search, Qt::CaseInsensitive) || matchById)
            {
                ret += r;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](QLocalSocket::LocalSocketError socketError){ qDebug() << "error!" << socketError; }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto item : qAsConst(m_updateItems)) {
                item->setProgress(0);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for(Category* c : subs) {
            Category* ret = recFindCategory(c, name);
            if(ret)
                return ret;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& filter: orFilters) {
            if(shouldFilter(this, filter)) {
                orValue = true;
                break;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, fw]() {
        const auto data = fw->result();
        fw->deleteLater();

        if (!data.correct && m_packages.packages.isEmpty()) {
            QTimer::singleShot(0, this, [this]() {
                Q_EMIT passiveMessage(i18n("Please make sure that Appstream is properly set up on your system"));
            });
        }
        QStringList neededPackages;
        neededPackages.reserve(data.components.size());
        for (const auto &component: data.components) {
            const auto pkgNames = component.packageNames();
            addComponent(component, pkgNames);
            neededPackages << pkgNames;
        }
        for (auto it = data.missingComponents.constBegin(), itEnd = data.missingComponents.constEnd(); it != itEnd; ++it) {
            acquireFetching(true);
            const auto file = it.key();
            const auto component = it.value();
            auto trans = PackageKit::Daemon::searchFiles(file);
            connect(trans, &PackageKit::Transaction::package, this, [trans](PackageKit::Transaction::Info info, const QString &packageID){
                if (info == PackageKit::Transaction::InfoInstalled)
                    trans->setProperty("installedPackage", packageID);
            });
            connect(trans, &PackageKit::Transaction::finished, this, [this, trans, component](PackageKit::Transaction::Exit status) {
                const auto pkgidVal = trans->property("installedPackage");
                if (status == PackageKit::Transaction::ExitSuccess && !pkgidVal.isNull()) {
                    const auto pkgid = pkgidVal.toString();
                    auto res = addComponent(component, {PackageKit::Daemon::packageName(pkgid)});
                    res->clearPackageIds();
                    res->addPackageId(PackageKit::Transaction::InfoInstalled, pkgid, true);
                }
                acquireFetching(false);
            });
        }

        if (!neededPackages.isEmpty()) {
            neededPackages.removeDuplicates();
            resolvePackages(neededPackages);
        } else {
            qCDebug(LIBDISCOVER_BACKEND_LOG) << "empty appstream db";
            if (PackageKit::Daemon::backendName() == QLatin1String("aptcc") || PackageKit::Daemon::backendName().isEmpty()) {
                checkForUpdates();
            }
        }
        if (!m_appstreamInitialized) {
            m_appstreamInitialized = true;
            Q_EMIT loadedAppStream();
        }
        acquireFetching(false);
    }
```

#### AUTO 


```{c}
auto split_branch = m_branch.split('/');
```

#### RANGE FOR STATEMENT 


```{c}
for(auto & elem : m_addons) {
        if(elem.name() == addon) {
            elem.setInstalled(installed);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            // First we ensure we've got data loaded on what we've got installed already
            if (m_responsePending) {
                // Slot already taken, will need to wait again
                return false;
            }
            m_onePage = true;
            setResponsePending(true);
            m_engine->checkForInstalled();
            // And then we check for updates - we could do only one, if all we cared about was updates,
            // but to have both a useful initial list, /and/ information on updates, we want to get both.
            // The reason we are not doing a checkUpdates() overload for this is that the caching for this
            // information is done by KNSEngine, and we want to actually load it every time we initialize.
            auto updateChecker = new OneTimeAction(
                666,
                [this] {
                    //No need to check for updates if there's no resources
                    if (m_resourcesByName.isEmpty()) {
                        return true;
                    }

                    if (m_responsePending) {
                        // Slot already taken, will need to wait again
                        return false;
                    }

                    m_onePage = true;
                    setResponsePending(true);
                    m_engine->checkForUpdates();
                    return true;
                },
                this);
            connect(this, &KNSBackend::availableForQueries, updateChecker, &OneTimeAction::trigger, Qt::QueuedConnection);
            return true;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, url](const QVector<AbstractResource*> &res) {
                if (res.count() >= 1) {
                    emit openApplicationInternal(res.first());
                } else {
                    Q_EMIT openErrorPage(i18n("Couldn't open %1", url.toDisplayString()));
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
            if (m_transaction->status() == PackageKit::Transaction::StatusDownload) {
                Q_EMIT resourceProgressed(m_upgrade, m_transaction->percentage(), Downloading);
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](){ int s = (m_state+1) % 4; setState(State(s)); }
```

#### AUTO 


```{c}
const auto andFilters = cat->andFilters();
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
                    //No need to check for updates if there's no resources
                    if (m_resourcesByName.isEmpty()) {
                        return true;
                    }

                    if (m_responsePending) {
                        // Slot already taken, will need to wait again
                        return false;
                    }

                    m_onePage = true;
                    setResponsePending(true);
                    m_engine->checkForUpdates();
                    return true;
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const PackageState &addon : m_availableAddons) {
        // Check if we have an application for the addon
        AbstractResource *addonResource = 0;

        for (AbstractResource *resource : m_backend->allResources()) {
            if (!resource)
                continue;

            if (resource->packageName() == addon.name()) {
                addonResource = resource;
                break;
            }
        }

        QStandardItem *addonItem = new QStandardItem;
        addonItem->setData(addon.name());
        QString resourceName = QLatin1String(" (") % addon.name() % ')';
        if (addonResource) {
            addonItem->setText(addonResource->name() % resourceName);
            addonItem->setIcon(KIcon(addonResource->icon()));
        } else {
            addonItem->setText(addon.description() % resourceName);
            addonItem->setIcon(KIcon("applications-other"));
        }

        addonItem->setEditable(false);
        addonItem->setCheckable(true);

        if (addon.isInstalled()) {
            addonItem->setCheckState(Qt::Checked);
        } else {
            addonItem->setCheckState(Qt::Unchecked);
        }

        m_addonsModel->appendRow(addonItem);
    }
```

#### AUTO 


```{c}
auto action = new OneTimeAction(
        [this, app]() {
            StoredResultsStream* stream = new StoredResultsStream({ResourcesModel::global()->findResourceByPackageName(app)});
            connect(stream, &StoredResultsStream::finishedResources, stream, [this, stream, app](const QVector<AbstractResource*> &resources) {
                if (!resources.isEmpty()) {
                    if (resources.size() > 1)
                        qWarning() << "many resources found for" << app;
                    emit openApplicationInternal(resources.first());
                } else {
                    rootObject()->setProperty("defaultStartup", true);
                    showPassiveNotification(i18n("Couldn't open %1", app.toDisplayString()));
                }
            });
        }
        , this);
```

#### AUTO 


```{c}
const auto was = percentage;
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
            setPercent(TransactionModel::global()->progress());
        }
```

#### AUTO 


```{c}
auto upgradeList = m_toUpgrade.toList();
```

#### AUTO 


```{c}
auto search = new OneTimeAction([this]() {
        Q_EMIT startingSearch();
        m_onePage = true;
        m_responsePending = true;
        m_engine->checkForInstalled();
    }, this);
```

#### LAMBDA EXPRESSION 


```{c}
[this, installation, fw](){
        auto refs = fw->result();
        onFetchUpdatesFinished(installation, refs);
        fw->deleteLater();
        acquireFetching(false);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, localfile]() {
            AbstractResourcesBackend::Filters f;
            f.resourceUrl = localfile;
            auto stream = new StoredResultsStream({ResourcesModel::global()->search(f)});
            connect(stream, &StoredResultsStream::finishedResources, this, [this, localfile](const QVector<AbstractResource*> &res) {
                if (res.count() == 1) {
                    emit openApplicationInternal(res.first());
                } else {
                    QMimeDatabase db;
                    auto mime = db.mimeTypeForUrl(localfile);
                    auto fIsFlatpakBackend = [](AbstractResourcesBackend* backend) { return backend->metaObject()->className() == QByteArray("FlatpakBackend"); };
                    if (mime.name().startsWith(QLatin1String("application/vnd.flatpak")) && !kContains(ResourcesModel::global()->backends(), fIsFlatpakBackend)) {
                        openApplication(QUrl(QStringLiteral("appstream://org.kde.discover.flatpak")));
                        showPassiveNotification(i18n("Cannot interact with flatpak resources without the flatpak backend %1. Please install it first.", localfile.toDisplayString()));
                    } else {
                        openMode(QStringLiteral("Browsing"));
                        showPassiveNotification(i18n("Couldn't open %1", localfile.toDisplayString()));
                    }
                }
            });
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : m_actions) {
        action->setEnabled(enabled);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, error] {
                return flatpak_installation_new_system(m_cancellable, error);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[fetchResourceJob, stream] (bool success, FlatpakResource *resource) {
            if (success) {
                stream->resourcesFound({resource});
            }
            stream->finish();
            fetchResourceJob->deleteLater();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            bool found = DiscoverBackendsFactory::hasRequestedBackends();
            for (auto b : ResourcesModel::global()->backends())
                found |= b->hasApplications();

            if (!found)
                Q_EMIT openErrorPage(i18n("No application back-ends found, please report to your distribution."));
        }
```

#### AUTO 


```{c}
const auto &itValue = it.value();
```

#### AUTO 


```{c}
const auto resources = fetchResources(m_appBackend->search(filter));
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        setDownloadSpeed(m_trans->speed());
    }
```

#### AUTO 


```{c}
const auto resolved = kFilter<QVector<AbstractResource *>>(toResolve, installedAndNameFilter);
```

#### AUTO 


```{c}
auto pos = index(*at - m_displayedResources.begin(), 0);
```

#### AUTO 


```{c}
const auto f = [this, appstreamIds, stream] () {
                AbstractResource* pkg = nullptr;

                QStringList allAppStreamIds = appstreamIds;
                {
                    auto it = deprecatedAppstreamIds.constFind(appstreamIds.first());
                    if (it != deprecatedAppstreamIds.constEnd()) {
                        allAppStreamIds << *it;
                    }
                }

                for (auto it = m_packages.packages.constBegin(), itEnd = m_packages.packages.constEnd(); it != itEnd; ++it) {
                    const bool matches = kContains(allAppStreamIds, [&it] (const QString& id) {
                        return it.key().compare(id, Qt::CaseInsensitive) == 0 ||
                              (id.endsWith(QLatin1String(".desktop")) && id.compare(it.key()+QLatin1String(".desktop"), Qt::CaseInsensitive) == 0);
                    });
                    if (matches) {
                        pkg = it.value();
                        break;
                    }
                }
                if (pkg)
                    stream->setResources({pkg});
                stream->finish();
    //             if (!pkg)
    //                 qCDebug(LIBDISCOVER_BACKEND_LOG) << "could not find" << host << deprecatedHost;
            };
```

#### RANGE FOR STATEMENT 


```{c}
for (UpdateItem *subItem : item->children()) {
            QApt::Package *pkg = subItem->retrievePackage();
            if (!pkg)
                continue;

            subItem->setChecked(pkg->state() & QApt::Package::ToInstall);
        }
```

#### AUTO 


```{c}
auto res = addComponent(component, {PackageKit::Daemon::packageName(pkgid)});
```

#### LAMBDA EXPRESSION 


```{c}
[this, entryid, stream, providerid]() {
        if (m_responsePending) {
            // Slot already taken, will need to wait again
            return;
        }
        setResponsePending(true);
        m_engine->fetchEntryById(entryid);
        m_onePage = true;

        connect(m_engine, &KNSCore::Engine::signalErrorCode, stream, &ResultsStream::finish);
        connect(m_engine,
                &KNSCore::Engine::signalEntryEvent,
                stream,
                [this, stream, entryid, providerid](const KNSCore::EntryInternal &entry, KNSCore::EntryInternal::EntryEvent event) {
                    switch (event) {
                    case KNSCore::EntryInternal::StatusChangedEvent:
                        if (entry.uniqueId() == entryid && providerid == QUrl(entry.providerId()).host()) {
                            Q_EMIT stream->resourcesFound({resourceForEntry(entry)});
                        } else
                            qWarning() << "found invalid" << entryid << entry.uniqueId() << providerid << QUrl(entry.providerId()).host();
                        QTimer::singleShot(0, this, [this] {
                            setResponsePending(false);
                        });
                        stream->finish();
                        break;
                    case KNSCore::EntryInternal::DetailsLoadedEvent:
                    case KNSCore::EntryInternal::AdoptedEvent:
                    case KNSCore::EntryInternal::UnknownEvent:
                    default:
                        break;
                    }
                });
    }
```

#### AUTO 


```{c}
auto cancellable = m_cancellable;
```

#### LAMBDA EXPRESSION 


```{c}
[this](uint timeSince) {
            if (timeSince > 3600)
                checkForUpdates();
            else
                fetchUpdates();
            acquireFetching(false);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &filter : andFilters) {
        if (!shouldFilter(this, filter))
            return false;
    }
```

#### AUTO 


```{c}
auto installation = resource->installation();
```

#### RANGE FOR STATEMENT 


```{c}
for (const AppStream::Icon &icon : icons) {
            switch (icon.kind()) {
            case AppStream::Icon::KindLocal:
            case AppStream::Icon::KindCached:
                ret.addFile(icon.url().toLocalFile(), icon.size());
                break;
            case AppStream::Icon::KindStock: {
                const auto ret = QIcon::fromTheme(icon.name());
                if (!ret.isNull())
                    return ret;
                break;
            }
            case AppStream::Icon::KindRemote: {
                const QString fileName = iconCachePath(icon);
                if (QFileInfo::exists(fileName)) {
                    ret.addFile(fileName, icon.size());
                }
                break;
            }
            case AppStream::Icon::KindUnknown:
                break;
            }
        }
```

#### AUTO 


```{c}
auto start = [this, entryid, stream, providerid]() {
        m_responsePending = true;
        m_engine->fetchEntryById(entryid);
        connect(m_engine, &KNSCore::Engine::signalError, stream, &ResultsStream::finish);
        connect(m_engine, &KNSCore::Engine::signalEntryDetailsLoaded, stream, [this, stream, entryid, providerid](const KNSCore::EntryInternal &entry) {
            if (entry.uniqueId() == entryid && providerid == QUrl(entry.providerId()).host()) {
                stream->resourcesFound({resourceForEntry(entry)});
            }
            m_responsePending = false;
            QTimer::singleShot(0, this, &KNSBackend::availableForQueries);
            stream->finish();
        });
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this, entryid, stream]() {
        m_responsePending = true;
        m_engine->fetchEntryById(entryid);
        connect(m_engine, &KNSCore::Engine::signalError, stream, &QObject::deleteLater);
        connect(m_engine, &KNSCore::Engine::signalEntryDetailsLoaded, stream, [this, stream, entryid](const KNSCore::EntryInternal &entry) {
            if (entry.uniqueId() == entryid) {
                stream->resourcesFound({resourceForEntry(entry)});
            }
            m_responsePending = false;
            QTimer::singleShot(0, this, &KNSBackend::availableForQueries);
            stream->deleteLater();
        });
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](QQmlEngine*, QJSEngine*) -> QObject* { return new MuonNotifier; }
```

#### LAMBDA EXPRESSION 


```{c}
[this, fw] {
        const QJsonDocument jsonDocument = fw->result();
        fw->deleteLater();
        const QJsonObject jsonObject = jsonDocument.object();
        m_ratings.reserve(jsonObject.size());
        for (auto it = jsonObject.begin(); it != jsonObject.end(); it++) {
            QJsonObject appJsonObject = it.value().toObject();

            const int ratingCount = appJsonObject.value(QLatin1String("total")).toInt();
            int ratingMap[] = {
                appJsonObject.value(QLatin1String("star0")).toInt(),
                appJsonObject.value(QLatin1String("star1")).toInt(),
                appJsonObject.value(QLatin1String("star2")).toInt(),
                appJsonObject.value(QLatin1String("star3")).toInt(),
                appJsonObject.value(QLatin1String("star4")).toInt(),
                appJsonObject.value(QLatin1String("star5")).toInt(),
            };

            Rating *rating = new Rating(it.key(), ratingCount, ratingMap);
            m_ratings.insert(it.key(), rating);
        }
        Q_EMIT ratingsReady();
    }
```

#### AUTO 


```{c}
auto changes = m_backend->stateChanges(m_oldCacheState, list);
```

#### AUTO 


```{c}
const auto ext = kTransform<QVector<AbstractResource*>>(m_packages.extendedBy.value(filter.extends), [](AppPackageKitResource* a){ return a; });
```

#### AUTO 


```{c}
auto it = m_filter.globalMatch(read);
```

#### AUTO 


```{c}
auto criticals = kFilter<QSet<AbstractResource *>>(removedResources, isCritical);
```

#### AUTO 


```{c}
auto updateChecker = new OneTimeAction(
                [this]() {
                    Q_EMIT startingSearch();
                    m_onePage = true;
                    m_responsePending = true;
                    m_engine->checkForUpdates();
                },
                this);
```

#### AUTO 


```{c}
const auto appdataScreenshots = appdata.screenshots();
```

#### LAMBDA EXPRESSION 


```{c}
[this, stream, searchText]() {
        m_engine->setSearchTerm(searchText);
        m_engine->requestData(0, 100);
        m_responsePending = true;
        m_page = 0;
        connect(this, &KNSBackend::receivedResources, stream, &ResultsStream::resourcesFound);
        connect(this, &KNSBackend::searchFinished, stream, &ResultsStream::finish);
        connect(this, &KNSBackend::startingSearch, stream, &ResultsStream::finish);
    }
```

#### AUTO 


```{c}
auto f = [this]() {
        m_item->setTitle(i18n("Restart to apply installed updates"));
        m_item->setToolTipTitle(i18n("Click to restart the device"));
        m_item->setIconByName(QStringLiteral("view-refresh"));
    };
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString& toInstall : addons.addonsToInstall()) {
        setAddonInstalled(toInstall, true);
    }
```

#### AUTO 


```{c}
auto trans = PackageKit::Daemon::searchFiles(file);
```

#### AUTO 


```{c}
auto remote = flatpak_installation_get_remote_by_name(installation, name, nullptr, &error);
```

#### LAMBDA EXPRESSION 


```{c}
[installation]() -> GPtrArray * {
        g_autoptr(GCancellable) cancellable = g_cancellable_new();
        g_autoptr(GError) localError = nullptr;
        GPtrArray *refs = flatpak_installation_list_installed_refs_for_update(installation, cancellable, &localError);
        if (!refs) {
            qWarning() << "Failed to get list of installed refs for listing updates: " << localError->message;
        }
        return refs;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, filter, stream] {
            const auto resources = kTransform<QVector<AbstractResource *>>(m_packages.extendedBy.value(filter.extends), [](AppPackageKitResource *a) {
                return a;
            });
            stream->setResources(resources);
            stream->finish();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            Q_EMIT passiveMessage(i18n("Please make sure that Appstream is properly set up on your system"));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto slot: slotsForInterface[plug->interface()]) {
                    auto item = new QStandardItem;
                    if (plug->label().isEmpty())
                        item->setText(plug->name());
                    else
                        item->setText(i18n("%1 - %2", plug->name(), plug->label()));

//                     qDebug() << "xxx" << plug->name() << plug->label() << plug->interface() << slot->snap() << "slot:" << slot->name() << slot->snap() << slot->interface() << slot->label();
                    item->setCheckable(true);
                    item->setCheckState(plug->connectionCount()>0 ? Qt::Checked : Qt::Unchecked);
                    item->setData(plug->name(), PlugNameRole);
                    item->setData(slot->snap(), SlotSnapRole);
                    item->setData(slot->name(), SlotNameRole);
                    appendRow(item);
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &alt : alts) {
                if (QString::compare(alt, name, Qt::CaseInsensitive) == 0 || QString::compare(alt, nameWithDesktop, Qt::CaseInsensitive) == 0) {
                    resources << res;
                    break;
                }
            }
```

#### AUTO 


```{c}
const auto id = resource->uniqueId();
```

#### AUTO 


```{c}
const auto found = res->categoryObjects(cats.toList().toVector());
```

