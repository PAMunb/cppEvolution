#### AUTO 


```{c}
auto headers = new KMime::Message();
```

#### RANGE FOR STATEMENT 


```{c}
for (const MBoxEntry &entry : std::as_const(d->mEntries)) {
        if (!deletedEntries.contains(entry)) {
            result << entry;
        }
    }
```

#### AUTO 


```{c}
auto mail = new KMime::Message();
```

#### RANGE FOR STATEMENT 


```{c}
for (const MBoxEntry &entry : qAsConst(d->mEntries)) {
        if (!deletedEntries.contains(entry)) {
            result << entry;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const MBoxEntry &msgInfo : list) {
        const QByteArray header = mbox.readMessageHeaders(msgInfo);
        QVERIFY(!header.isEmpty());

        KMime::Message *message = mbox.readMessage(msgInfo);
        QVERIFY(message != nullptr);

        KMime::Message *headers = new KMime::Message();
        headers->setHead(KMime::CRLFtoLF(header));
        headers->parse();

        QCOMPARE(message->messageID()->identifier(), headers->messageID()->identifier());
        QCOMPARE(message->subject()->as7BitString(), headers->subject()->as7BitString());
        QCOMPARE(message->to()->as7BitString(), headers->to()->as7BitString());
        QCOMPARE(message->from()->as7BitString(), headers->from()->as7BitString());

        if (msgInfo.messageOffset() == 0) {
            QCOMPARE(message->messageID()->identifier(), mMail1->messageID()->identifier());
            QCOMPARE(message->subject()->as7BitString(), mMail1->subject()->as7BitString());
            QCOMPARE(message->to()->as7BitString(), mMail1->to()->as7BitString());
            QCOMPARE(message->from()->as7BitString(), mMail1->from()->as7BitString());
        } else if (msgInfo.messageOffset() == offsetMail2.messageOffset()) {
            QCOMPARE(message->messageID()->identifier(), mMail2->messageID()->identifier());
            QCOMPARE(message->subject()->as7BitString(), mMail2->subject()->as7BitString());
            QCOMPARE(message->to()->as7BitString(), mMail2->to()->as7BitString());
            QCOMPARE(message->from()->as7BitString(), mMail2->from()->as7BitString());
        }

        delete message;
        delete headers;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const MBoxEntry &msgInfo : list) {
        const QByteArray header = mbox.readMessageHeaders(msgInfo);
        QVERIFY(!header.isEmpty());

        KMime::Message *message = mbox.readMessage(msgInfo);
        QVERIFY(message != nullptr);

        auto headers = new KMime::Message();
        headers->setHead(KMime::CRLFtoLF(header));
        headers->parse();

        QCOMPARE(message->messageID()->identifier(), headers->messageID()->identifier());
        QCOMPARE(message->subject()->as7BitString(), headers->subject()->as7BitString());
        QCOMPARE(message->to()->as7BitString(), headers->to()->as7BitString());
        QCOMPARE(message->from()->as7BitString(), headers->from()->as7BitString());

        delete message;
        delete headers;
    }
```

#### AUTO 


```{c}
auto *mail = new KMime::Message();
```

#### RANGE FOR STATEMENT 


```{c}
for (const MBoxEntry &msgInfo : list) {
        const QByteArray header = mbox.readMessageHeaders(msgInfo);
        QVERIFY(!header.isEmpty());

        KMime::Message *message = mbox.readMessage(msgInfo);
        QVERIFY(message != nullptr);

        auto *headers = new KMime::Message();
        headers->setHead(KMime::CRLFtoLF(header));
        headers->parse();

        QCOMPARE(message->messageID()->identifier(), headers->messageID()->identifier());
        QCOMPARE(message->subject()->as7BitString(), headers->subject()->as7BitString());
        QCOMPARE(message->to()->as7BitString(), headers->to()->as7BitString());
        QCOMPARE(message->from()->as7BitString(), headers->from()->as7BitString());

        delete message;
        delete headers;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const MBoxEntry &entry : qAsConst(deletedEntries)) {
        d->mMboxFile.seek(entry.messageOffset());
        const QByteArray line = d->mMboxFile.readLine();

        if (!d->isMBoxSeparator(line)) {
            qCDebug(KMBOX_LOG) << "Found invalid separator at:" << entry.messageOffset();
            unlock();
            return false; // The file is messed up or the index is incorrect.
        }
    }
```

#### AUTO 


```{c}
auto *headers = new KMime::Message();
```

#### RANGE FOR STATEMENT 


```{c}
for (const MBoxEntry &msgInfo : list) {
        const QByteArray header = mbox.readMessageHeaders(msgInfo);
        QVERIFY(!header.isEmpty());

        KMime::Message *message = mbox.readMessage(msgInfo);
        QVERIFY(message != nullptr);

        KMime::Message *headers = new KMime::Message();
        headers->setHead(KMime::CRLFtoLF(header));
        headers->parse();

        QCOMPARE(message->messageID()->identifier(), headers->messageID()->identifier());
        QCOMPARE(message->subject()->as7BitString(), headers->subject()->as7BitString());
        QCOMPARE(message->to()->as7BitString(), headers->to()->as7BitString());
        QCOMPARE(message->from()->as7BitString(), headers->from()->as7BitString());

        delete message;
        delete headers;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const MBoxEntry &msgInfo : list) {
        const QByteArray header = mbox.readMessageHeaders(msgInfo);
        QVERIFY(!header.isEmpty());

        KMime::Message *message = mbox.readMessage(msgInfo);
        QVERIFY(message != nullptr);

        auto *headers = new KMime::Message();
        headers->setHead(KMime::CRLFtoLF(header));
        headers->parse();

        QCOMPARE(message->messageID()->identifier(), headers->messageID()->identifier());
        QCOMPARE(message->subject()->as7BitString(), headers->subject()->as7BitString());
        QCOMPARE(message->to()->as7BitString(), headers->to()->as7BitString());
        QCOMPARE(message->from()->as7BitString(), headers->from()->as7BitString());

        if (msgInfo.messageOffset() == 0) {
            QCOMPARE(message->messageID()->identifier(), mMail1->messageID()->identifier());
            QCOMPARE(message->subject()->as7BitString(), mMail1->subject()->as7BitString());
            QCOMPARE(message->to()->as7BitString(), mMail1->to()->as7BitString());
            QCOMPARE(message->from()->as7BitString(), mMail1->from()->as7BitString());
        } else if (msgInfo.messageOffset() == offsetMail2.messageOffset()) {
            QCOMPARE(message->messageID()->identifier(), mMail2->messageID()->identifier());
            QCOMPARE(message->subject()->as7BitString(), mMail2->subject()->as7BitString());
            QCOMPARE(message->to()->as7BitString(), mMail2->to()->as7BitString());
            QCOMPARE(message->from()->as7BitString(), mMail2->from()->as7BitString());
        }

        delete message;
        delete headers;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const MBoxEntry &entry : std::as_const(deletedEntries)) {
        d->mMboxFile.seek(entry.messageOffset());
        const QByteArray line = d->mMboxFile.readLine();

        if (!d->isMBoxSeparator(line)) {
            qCDebug(KMBOX_LOG) << "Found invalid separator at:" << entry.messageOffset();
            unlock();
            return false; // The file is messed up or the index is incorrect.
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const MBoxEntry &msgInfo : list) {
        const QByteArray header = mbox.readMessageHeaders(msgInfo);
        QVERIFY(!header.isEmpty());

        KMime::Message *message = mbox.readMessage(msgInfo);
        QVERIFY(message != nullptr);

        auto headers = new KMime::Message();
        headers->setHead(KMime::CRLFtoLF(header));
        headers->parse();

        QCOMPARE(message->messageID()->identifier(), headers->messageID()->identifier());
        QCOMPARE(message->subject()->as7BitString(), headers->subject()->as7BitString());
        QCOMPARE(message->to()->as7BitString(), headers->to()->as7BitString());
        QCOMPARE(message->from()->as7BitString(), headers->from()->as7BitString());

        if (msgInfo.messageOffset() == 0) {
            QCOMPARE(message->messageID()->identifier(), mMail1->messageID()->identifier());
            QCOMPARE(message->subject()->as7BitString(), mMail1->subject()->as7BitString());
            QCOMPARE(message->to()->as7BitString(), mMail1->to()->as7BitString());
            QCOMPARE(message->from()->as7BitString(), mMail1->from()->as7BitString());
        } else if (msgInfo.messageOffset() == offsetMail2.messageOffset()) {
            QCOMPARE(message->messageID()->identifier(), mMail2->messageID()->identifier());
            QCOMPARE(message->subject()->as7BitString(), mMail2->subject()->as7BitString());
            QCOMPARE(message->to()->as7BitString(), mMail2->to()->as7BitString());
            QCOMPARE(message->from()->as7BitString(), mMail2->from()->as7BitString());
        }

        delete message;
        delete headers;
    }
```

