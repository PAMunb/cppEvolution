#### LAMBDA EXPRESSION 


```{c}
[=](float volume) {
            m_volume = volume;
            emit volumeChanged(volume);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=](bool mute) {
            mute ? emit volumeChanged(0.0) : emit volumeChanged(volume());
        }
```

#### AUTO 


```{c}
const auto plane = picture->p[i];
```

#### AUTO 


```{c}
auto i = 0;
```

#### AUTO 


```{c}
auto ret = P_THIS->formatCallback(chroma, width, height, pitches, lines);
```

#### AUTO 


```{c}
const auto picture = picture_New(fourcc, width, height, 0, 1);
```

