#### AUTO 


```{c}
auto& test
```

#### CONST EXPRESSION 


```{c}
static constexpr int TEST_RUNS = 5;
```

#### CONST EXPRESSION 


```{c}
static constexpr int TEST_DELAY = 15*60;
```

#### RANGE FOR STATEMENT 


```{c}
for ( auto& test : tests ) {
        status |= QTest::qExec( test.get(), argc, argv );
    }
```

#### AUTO 


```{c}
auto timer = new QTimer(this);
```

#### AUTO 


```{c}
auto timer = new QTimer( this );
```

#### AUTO 


```{c}
auto disableSessionManagement = [](QSessionManager &sm) {
        sm.setRestartHint(QSessionManager::RestartNever);
    };
```

#### CONST EXPRESSION 


```{c}
static constexpr int TEST_DELAY = 15 * 60;
```

#### AUTO 


```{c}
auto &test
```

#### CONST EXPRESSION 


```{c}
static constexpr int RELAX_ENDED_MAGIC_VALUE = -1;
```

#### RANGE FOR STATEMENT 


```{c}
for ( WId win : KWindowSystem::windows() ) {
        KWindowInfo info( win, NET::WMDesktop | NET::WMState | NET::XAWMState );
        if ( (info.state() & NET::FullScreen) && !info.isMinimized() && info.isOnCurrentDesktop() ) {
            return true;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &test : tests) {
        status |= QTest::qExec(test.get(), argc, argv);
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr int TEST_THRESHOLD = 40;
```

#### RANGE FOR STATEMENT 


```{c}
for ( QScreen *screen : QGuiApplication::screens() ) {
        GrayWidget* grayWidget = new GrayWidget( 0 );
        m_widgets.insert( screen, grayWidget );

        const QRect rect = screen->geometry();
        grayWidget->move( rect.topLeft() );
        grayWidget->setGeometry( rect );

        KWindowSystem::forceActiveWindow( grayWidget->winId() );
        KWindowSystem::setState( grayWidget->winId(), NET::KeepAbove );
        KWindowSystem::setOnAllDesktops( grayWidget->winId(), true );
        KWindowSystem::setState( grayWidget->winId(), NET::FullScreen );

        qDebug() << "Created widget for screen" << screen << "Position:" << rect.topLeft();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QScreen *screen : QGuiApplication::screens()) {
        GrayWidget *grayWidget = new GrayWidget(nullptr);
        m_widgets.insert(screen, grayWidget);

        const QRect rect = screen->geometry();
        grayWidget->move(rect.topLeft());
        grayWidget->setGeometry(rect);

        KWindowSystem::forceActiveWindow(grayWidget->winId());
        KWindowSystem::setState(grayWidget->winId(), NET::KeepAbove);
        KWindowSystem::setOnAllDesktops(grayWidget->winId(), true);
        KWindowSystem::setState(grayWidget->winId(), NET::FullScreen);

        qDebug() << "Created widget for screen" << screen << "Position:" << rect.topLeft();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QScreen *screen : QGuiApplication::screens()) {
        GrayWidget *grayWidget = new GrayWidget(0);
        m_widgets.insert(screen, grayWidget);

        const QRect rect = screen->geometry();
        grayWidget->move(rect.topLeft());
        grayWidget->setGeometry(rect);

        KWindowSystem::forceActiveWindow(grayWidget->winId());
        KWindowSystem::setState(grayWidget->winId(), NET::KeepAbove);
        KWindowSystem::setOnAllDesktops(grayWidget->winId(), true);
        KWindowSystem::setState(grayWidget->winId(), NET::FullScreen);

        qDebug() << "Created widget for screen" << screen << "Position:" << rect.topLeft();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](QSessionManager &sm) {
        sm.setRestartHint(QSessionManager::RestartNever);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (WId win : KWindowSystem::windows()) {
        KWindowInfo info(win, NET::WMDesktop | NET::WMState | NET::XAWMState);
        if ((info.state() & NET::FullScreen) && !info.isMinimized() && info.isOnCurrentDesktop()) {
            return true;
        }
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr int TEST_BREAK = 30;
```

