#### LAMBDA EXPRESSION 


```{c}
[this, process] () {
        appendErrorText( process->readAllStandardError() );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &i : qAsConst(list)) {
        for ( auto it = hashTable->cbegin(); it != hashTable->cend(); ++it ) {
            if (it.key().startsWith(i)) {
                ret.append(i);
                break;
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {
        const QString filePath = m_actAddFile->data().value<svnCommitEntryInfo_t>().localPath;
        emit addFiles(QStringList() << filePath);
    }
```

#### AUTO 


```{c}
auto storageAccess = dev.as<Solid::StorageAccess>();
```

#### AUTO 


```{c}
auto *job = new KIO::CommandLauncherJob(command);
```

#### AUTO 


```{c}
auto dev
```

#### AUTO 


```{c}
auto file = fileItemInfos.urlList().at(0).toLocalFile();
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &item : items) {
            const ItemVersion state = itemVersion(item);
            if (state != UnversionedVersion && state != RemovedVersion) {
                ++versionedCount;
            }
            if (state == UnversionedVersion ||
                    state == LocallyModifiedUnstagedVersion) {
                ++addableCount;
            }
            if (state == LocallyModifiedVersion ||
                    state == AddedVersion ||
                    state == RemovedVersion) {
                ++revertableCount;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {
        const QString dir = QFileDialog::getExistingDirectory(this, i18nc("@title:window", "Choose a directory to checkout"),
                                                              QString(), QFileDialog::ShowDirsOnly | QFileDialog::DontResolveSymlinks);

        if (!dir.isEmpty()) {
            m_ui.leCheckoutDir->setText(dir);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &msg : messages) {
        QAction *action = m_copyMessageMenu->addAction(msg.left(40)); // max 40 characters
        action->setData(msg); // entire description into action data
        actionGroup->addAction(action);
    }
```

#### AUTO 


```{c}
auto notifier = Solid::DeviceNotifier::instance();
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {
        const QString filePath = m_actRevertFile->data().value<svnInfo_t>().filePath;
        emit revertFiles(QStringList() << filePath);
    }
```

#### AUTO 


```{c}
auto view = new QTextBrowser();
```

#### AUTO 


```{c}
auto genericDevice = device.as<Solid::GenericInterface>();
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {
        // Form a new context list from an existing one and a possibly modified m_versionInfoHash (some
        // files from original context might no longer be in m_versionInfoHash).
        QStringList context = makeContext(m_context, m_versionInfoHash);
        emit commit(context, m_editor->toPlainText());
        QDialog::accept();
    }
```

#### AUTO 


```{c}
auto it = hashTable->cbegin();
```

#### LAMBDA EXPRESSION 


```{c}
[device]() { unmount(device); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& b : branches) {
        if (!b.startsWith(QLatin1String("remotes/"))) {
            //you CAN create local branches called "remotes/...", but since no sane person
            //would do that, we save the effort of another call to "git branch"
            m_branchNames.insert(b);
        }
    }
```

#### AUTO 


```{c}
auto genericInterface = device.as<Solid::GenericInterface>();
```

#### RANGE FOR STATEMENT 


```{c}
for (QListWidgetItem *item : selectedItems) {
        m_ignoreTable->addItem(item->text());
        m_untrackedList->takeItem(m_untrackedList->row(item));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {
        const QString filePath = m_actDiffFile->data().value<svnInfo_t>().filePath;
        emit diffFile(filePath);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, process] () {
        appendInfoText( process->readAllStandardOutput() );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem& item : items){
            const ItemVersion state = itemVersion(item);
            if (state != UnversionedVersion && state != RemovedVersion &&
                state != IgnoredVersion) {
                ++versionedCount;
            }
            if (state == UnversionedVersion || state == LocallyModifiedUnstagedVersion ||
                state == IgnoredVersion || state == ConflictingVersion) {
                ++addableCount;
            }
            if (state == LocallyModifiedVersion || state == LocallyModifiedUnstagedVersion ||
                state == ConflictingVersion) {
                ++revertCount;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &item : fileList) {
        arguments << item.localPath();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QCheckBox *cb : qAsConst(m_options)) {
        layout->addWidget(cb);
    }
```

#### AUTO 


```{c}
auto connection = QDBusConnection::sessionBus();
```

#### RANGE FOR STATEMENT 


```{c}
for (Solid::Device storageAccessDevice : devices) {
        auto storageAccess = storageAccessDevice.as<Solid::StorageAccess>();
        if (storageAccess->isAccessible()) {
            storageAccess->teardown();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem& item : items) {
            const ItemVersion version = itemVersion(item);
            if (version != UnversionedVersion) {
                ++versionedCount;
            }

            switch (version) {
                case LocallyModifiedVersion:
                case ConflictingVersion:
                case AddedVersion:
                case RemovedVersion:
                    ++editingCount;
                    break;
                default:
                    break;
            }
        }
```

#### AUTO 


```{c}
auto log = QSharedPointer< QVector<logEntry> >::create();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Solid::Device &device : blockDevices) {
        QMap<QString, QVariant> properties = device.as<Solid::GenericInterface>()->allProperties();
        if (properties.contains("BackingFile")
            && backingFile == properties["BackingFile"].value<QString>()) {
            return device;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {
        svnLogEntryInfo_t info = m_diffFilePrev->data().value<svnLogEntryInfo_t>();
        emit diffBetweenRevs(info.remotePath, info.revision, info.revision - 1);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &fileName : filesInside) {
            const QUrl tempUrl(dir.absoluteFilePath(fileName));
            KFileItem tempFileItem(tempUrl);
            if (itemVersion(tempFileItem) == NormalVersion) {
               return NormalVersion;
          }
        }
```

#### AUTO 


```{c}
auto okButton = buttonBox->button(QDialogButtonBox::Ok);
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {
        const QString filePath = m_actDiffFile->data().value<svnCommitEntryInfo_t>().localPath;
        Q_EMIT diffFile(filePath);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : result) {
        m_untrackedList->addItem(file.mid(2));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {
        const QString filePath = m_actRevertFile->data().value<svnCommitEntryInfo_t>().localPath;
        Q_EMIT revertFiles(QStringList() << filePath);
    }
```

#### AUTO 


```{c}
auto query = QString("[ StorageVolume.uuid == '%1' AND IS StorageAccess ]").arg(uuid);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &fileName : filesInside) {
            if (fileName == "." || fileName == ".." ) {
                continue;
            }
            QUrl tempUrl(dir.absoluteFilePath(fileName));
            KFileItem tempFileItem(tempUrl);
            if (itemVersion(tempFileItem) == NormalVersion) {
               return NormalVersion;
          }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {
        svnLogEntryInfo_t info = m_diffFileCurrent->data().value<svnLogEntryInfo_t>();
        emit diffAgainstWorkingCopy(info.localPath, info.revision);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem& item : items){
            m_contextItems.append(item);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &instance : instanceDirs) {
        aggregationDB = dropboxDir + '/' + instance + '/' + "aggregation.dbx";
        if (QFile::exists(aggregationDB)) {
            d->databaseFileWatcher->addPath(aggregationDB);
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &i : m_contextItems) {
            context << i.localPath();
        }
```

#### AUTO 


```{c}
const auto &i
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &fileName : patches) {
        getPatchInfo(fileName);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[file]() { mount(file); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &item : items) {
            m_contextItems.append(item);
        }
```

#### AUTO 


```{c}
auto qtFd = QDBusUnixFileDescriptor(fd);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &i : qAsConst(list)) {
        if (str.startsWith(i)) {
            return true;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, process] (QProcess::ProcessError) {
        const QString commandLine = process->program() + process->arguments().join(' ');
        appendErrorText(i18nc("@info:status", "Error starting: %1", commandLine));
        operationCompeleted();
    }
```

#### AUTO 


```{c}
auto &item
```

#### AUTO 


```{c}
auto buttonBox = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel, this);
```

#### AUTO 


```{c}
auto refreshButton = buttonBox->addButton(i18nc("@action:button", "Refresh"), QDialogButtonBox::ResetRole);
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {
        m_logLength += 100;
        refreshLog();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {
        // Form a new context list from an existing one and a possibly modified m_versionInfoHash (some
        // files from original context might no longer be in m_versionInfoHash).
        QStringList context = makeContext(m_context, m_versionInfoHash);
        Q_EMIT commit(context, m_editor->toPlainText());
        QDialog::accept();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto dev : devices) {
        auto storageAccess = dev.as<Solid::StorageAccess>();
        storageAccess->setup();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Solid::Device &device : blockDevices) {
        auto genericDevice = device.as<Solid::GenericInterface>();
        if (backingFile == genericDevice->property(QStringLiteral("BackingFile")).toString()) {
            return device;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {
        const QString filePath = m_actAddFile->data().value<svnInfo_t>().filePath;
        emit addFiles(QStringList() << filePath);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QListWidgetItem *item : selectedItems) {
        m_ignoreTable->takeItem(m_ignoreTable->row(item));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem& item : items) {
        m_contextItems.append(item);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &alias : qAsConst(m_removeList)) {
        hgc.deleteRepoRemotePath(alias);
    }
```

#### AUTO 


```{c}
auto it = m_versionInfoHash->cbegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& replyLine : reply) {
        const QStringList options = replyLine.split('~');

        if (options.count() > 2) {
            QAction* action = d->contextActions->addAction(options.at(2));
            action->setText(options.at(0));
            action->setToolTip(options.at(1));
            action->setIcon(QIcon::fromTheme("dropbox"));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &item : fileList) {
        args << item.localPath();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {
        svnLogEntryInfo_t info = m_diffFilePrev->data().value<svnLogEntryInfo_t>();
        Q_EMIT diffBetweenRevs(info.remotePath, info.revision, info.revision - 1);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {
        svnLogEntryInfo_t info = m_diffFileCurrent->data().value<svnLogEntryInfo_t>();
        Q_EMIT diffAgainstWorkingCopy(info.localPath, info.revision);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem& item : items) {
            const ItemVersion state = itemVersion(item);
            if (state != UnversionedVersion) {
                ++versionedCount;
            }

            switch (state) {
                case LocallyModifiedVersion:
                case ConflictingVersion:
                    ++editingCount;
                    break;
                default:
                    break;
            }
        }
```

#### AUTO 


```{c}
auto storageAccess = storageAccessDevice.as<Solid::StorageAccess>();
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {
        const QString filePath = m_actAddFile->data().value<svnCommitEntryInfo_t>().localPath;
        Q_EMIT addFiles(QStringList() << filePath);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& branch : branches) {
        if (branch.startsWith(QLatin1String("remotes/"))) {
            const QString remote = branch.section('/', 1, 1);
            const QString name = branch.section('/', 2);
            m_remoteBranches[remote] << name;
        } else {
            m_localBranchComboBox->addItem(branch);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &i : qAsConst(filesPath)) {
        m_contextItems.append( QUrl::fromLocalFile(i) );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &item : qAsConst(m_contextItems)) {
            items << item.url().fileName();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, process] () {
        process->terminate();
        m_svnTerminated = true;
    }
```

#### AUTO 


```{c}
auto view = new QTextBrowser(dlg);
```

#### AUTO 


```{c}
auto buttonBox = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel);
```

#### RANGE FOR STATEMENT 


```{c}
for (QListWidgetItem *item : items) {
            args << item->data(Qt::DisplayRole).toString();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {
        const QString filePath = m_actRevertFile->data().value<svnCommitEntryInfo_t>().localPath;
        emit revertFiles(QStringList() << filePath);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {
        const QString dir = QFileDialog::getExistingDirectory(this, i18nc("@title:window", "Choose a directory to clean up"),
                                                              m_ui.lineEditDirectory->text(), QFileDialog::ShowDirsOnly | QFileDialog::DontResolveSymlinks);

        if (!dir.isEmpty()) {
            m_ui.lineEditDirectory->setText(dir);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &i : qAsConst(m_log->at(currentRow).affectedPaths)) {
        svnLogEntryInfo_t info;
        info.remotePath = rootUrl + i.path;
        info.localPath = m_contextDir + i.path;
        info.revision = m_log->at(currentRow).revision;

        // For user: let's show relative path from 'svn log'.
        QListWidgetItem *item = new QListWidgetItem(i.path, m_ui.lPaths);
        item->setData(Qt::UserRole, QVariant::fromValue(info));
        m_ui.lPaths->addItem(item);
    }
```

#### AUTO 


```{c}
auto it = m_versionInfoHash.cbegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem& item : items) {
        d->contextFilePaths << QDir(item.localPath()).canonicalPath();
    }
```

#### AUTO 


```{c}
auto buttonBox = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel, &dialog);
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {
        const QString filePath = m_actDiffFile->data().value<svnCommitEntryInfo_t>().localPath;
        emit diffFile(filePath);
    }
```

#### AUTO 


```{c}
auto storageVolume = device.as<Solid::StorageVolume>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &instance : instanceDirs) {
        aggregationDB = dropboxDir + "/" + instance + "/" + "aggregation.dbx";
        if (QFile::exists(aggregationDB)) {
            d->databaseFileWatcher->addPath(aggregationDB);
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Solid::Device &device : blockDevices) {
        QMap<QString, QVariant> properties = device.as<Solid::GenericInterface>()->allProperties();
        if (properties.contains("BackingFile")
            && backingFile == properties["BackingFile"].value<QString>()) {
            return device.udi();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& branch : branches) {
        if (branch.startsWith(QLatin1String("remotes/"))) {
            const QString remote = branch.section('/', 1, 1);
            const QString name = branch.section('/', 2);
            m_remoteBranches[remote] << name;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &i : items) {
        if (isInUnversionedDir(i)) {
            return {};
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &i : qAsConst(m_contextItems)) {
            context << i.localPath();
        }
```

