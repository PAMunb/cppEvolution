#### RANGE FOR STATEMENT 


```{c}
for (ConnectorLine *line : m_connectorLineList)
        delete line;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray& s : entries)
        list << s.toInt();
```

#### RANGE FOR STATEMENT 


```{c}
for ( QString category: categories)
	{
		QDir dir( KStandardDirs::locate( "appdata", "examples/" + category + "/" ) );

		//K3PopupMenu * m = static_cast<K3PopupMenu*>(factory()->container( "examples_" + category, this ));
        QMenu * m = static_cast<QMenu*>(factory()->container( "examples_" + category, this ));
		if ( !m ) {
            qWarning() << "failed to cast to popup menu: " << "examples_" + category;
			continue;
        }
		connect( m, SIGNAL(triggered(QAction*)), this, SLOT(openExample(QAction*)) );

		QStringList files = dir.entryList();
		files.removeAll(".");
		files.removeAll("..");

		for ( QString fileName: files )
		{
			QString name = filesToNames[ fileName ];
			if ( name.isEmpty() )
			{
				name = fileName;
				name.remove(".circuit");
				name.replace("-"," ");
				name.replace("_"," ");

				// Capitalize the start of each word
				bool prevWasSpace = true;
				for ( unsigned i = 0; i < name.length(); ++i )
				{
					if ( prevWasSpace )
						name[i] = name[i].toUpper();
					prevWasSpace = name[i].isSpace();
				}
			}

			//m->insertItem( name, at, at ); // 2018.12.02
            m->addAction( name )->setData(at);
			m_exampleFiles[ at ] = dir.path() + "/" + fileName;
			at++;
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *a : actions) {
        switch (a->data().toInt()) {
        case TextDocument::AssemblyOutput:
            actAsmOut = a;
            break;
        case TextDocument::HexOutput:
            actHexOut = a;
            break;
        case TextDocument::PICOutput:
            actPicOut = a;
            break;
        default:
            qDebug() << Q_FUNC_INFO << " skip action: " << a;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QString category : categories) {
        QDir dir(QStandardPaths::locate(QStandardPaths::AppDataLocation, "examples/" + category + "/", QStandardPaths::LocateDirectory));

        // K3PopupMenu * m = static_cast<K3PopupMenu*>(factory()->container( "examples_" + category, this ));
        QMenu *m = static_cast<QMenu *>(factory()->container("examples_" + category, this));
        if (!m) {
            qWarning() << "failed to cast to popup menu: "
                       << "examples_" + category;
            continue;
        }
        connect(m, SIGNAL(triggered(QAction *)), this, SLOT(openExample(QAction *)));

        QStringList files = dir.entryList();
        files.removeAll(".");
        files.removeAll("..");

        for (QString fileName : files) {
            QString name = filesToNames[fileName];
            if (name.isEmpty()) {
                name = fileName;
                name.remove(".circuit");
                name.replace("-", " ");
                name.replace("_", " ");

                // Capitalize the start of each word
                bool prevWasSpace = true;
                for (unsigned i = 0; i < name.length(); ++i) {
                    if (prevWasSpace)
                        name[i] = name[i].toUpper();
                    prevWasSpace = name[i].isSpace();
                }
            }

            // m->insertItem( name, at, at ); // 2018.12.02
            m->addAction(name)->setData(at);
            m_exampleFiles[at] = dir.path() + "/" + fileName;
            at++;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QString format: mimeData->formats()) {
        if (format.startsWith("ktechlab/")) {
            matchingFormat = format;
            break;
        }
    }
```

#### AUTO 


```{c}
auto descIt = itemDescriptions.begin(), end = itemDescriptions.end();
```

#### RANGE FOR STATEMENT 


```{c}
for (QString fileName : files) {
            QString name = filesToNames[fileName];
            if (name.isEmpty()) {
                name = fileName;
                name.remove(".circuit");
                name.replace("-", " ");
                name.replace("_", " ");

                // Capitalize the start of each word
                bool prevWasSpace = true;
                for (int i = 0; i < name.length(); ++i) {
                    if (prevWasSpace)
                        name[i] = name[i].toUpper();
                    prevWasSpace = name[i].isSpace();
                }
            }

            // m->insertItem( name, at, at ); // 2018.12.02
            m->addAction(name)->setData(at);
            m_exampleFiles[at] = dir.path() + "/" + fileName;
            at++;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *a : actions) {
        switch (a->data().toInt()) {
        case TextDocument::AssemblyOutput:
        case TextDocument::HexOutput:
        case TextDocument::PICOutput:
            a->setEnabled(false);
            break;
        default:
            qCDebug(KTL_LOG) << " skip action: " << a;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KtlQCanvasPolygonalItem *item: m_connectorLineList) {
		bool changed = (item->z() != z)
			    || (item->pen() != pen)
			    || (item->isVisible() != isVisible());

		if (!changed) {
			if (forceRedraw)
				canvas()->setChanged(item->boundingRect());
			continue;
		}

		item->setZ(z);
		item->setPen(pen);
		item->setVisible(isVisible());
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *a : actions) {
        switch (a->data().toInt()) {
            case TextDocument::AssemblyOutput:  actAsmOut = a; break;
            case TextDocument::HexOutput:       actHexOut = a; break;
            case TextDocument::PICOutput:       actPicOut = a; break;
            default:
                qDebug() << Q_FUNC_INFO << " skip action: " << a;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &str) { m_combo->setCurrentItem(str); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : urls)
			fileList << url.toLocalFile();
```

#### RANGE FOR STATEMENT 


```{c}
for (QPoint p: *m_conRouter->cellPointList()) {
		const int x = p.x();
		const int y = p.y();

		const int numCon = cells->haveCell(x, y) ? cells->cell(x, y).numCon : 0;

		const int y_canvas = toCanvas(y);
		const int x_canvas = toCanvas(x);

		const bool bumpNext = (prevX == x
		                       && numCon > 1
		                       && std::abs(y_canvas - startNode()->y()) > 8
		                       && std::abs(y_canvas - endNode()->y())   > 8);

		int x0 = prevX_canvas;
		int x2 = x_canvas;
		int x1 = (x0 + x2) / 2;

		int y0 = prevY_canvas;
		int y3 = y_canvas;
		int y1 = (y0 == y3) ? y0 : ((y0 < y3) ? y0 + 3 : y0 - 3);
		int y2 = (y0 == y3) ? y3 : ((y0 < y3) ? y3 - 3 : y3 + 3);

		if (bumpNow)  x0 += 3;
		if (bumpNext) x2 += 3;

		if (!bumpNow && !bumpNext) {
			drawLineList += QPoint(x0, y0);
			drawLineList += QPoint(x2, y3);
		} else if (bumpNow) {
			drawLineList += QPoint(x0, y0);
			drawLineList += QPoint(x1, y1);
			drawLineList += QPoint(x2, y3);
		} else if (bumpNext) {
			drawLineList += QPoint(x0, y0);
			drawLineList += QPoint(x1, y2);
			drawLineList += QPoint(x2, y3);
		} else {
			drawLineList += QPoint(x0, y0);
			drawLineList += QPoint(x1, y1);
			drawLineList += QPoint(x1, y2);
			drawLineList += QPoint(x2, y3);
		}

		prevX = x;
		prevY = y;

		prevY_canvas = y_canvas;
		prevX_canvas = x_canvas;
		bumpNow = bumpNext;
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &internalUrl : availableInternal) {
        QString relativeURL;
        if (projectUrl.scheme() == internalUrl.scheme() && projectUrl.host() == internalUrl.host() && projectUrl.port() == internalUrl.port() && projectUrl.userInfo() == internalUrl.userInfo()) {
            relativeURL = projectDir.relativeFilePath(internalUrl.path());
        } else {
            relativeURL = internalUrl.toDisplayString(QUrl::PreferLocalFile);
        }
        // 2017.12.1 - convert to QListWidgetItem
        // Q3CheckListItem * item = new Q3CheckListItem( m_pWidget->m_pInternalLibraries, relativeURL, Q3CheckListItem::CheckBox );
        QListWidgetItem *item = new QListWidgetItem(relativeURL, m_pWidget->m_pInternalLibraries);
        item->setCheckState((linkedInternal.contains(relativeURL)) ? Qt::Checked : Qt::Unchecked);
        // item->setOn( linkedInternal.contains(relativeURL) ); // 2017.12.1 - convert to QListWidgetItem
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QPoint p : *m_conRouter->cellPointList()) {
        int x = p.x();
        int y = p.y();

        // Add the points of this connector to the cell array in the ICNDocument,
        // so that other connectors still to calculate their points know to try
        // and avoid this connector

        p_icnDocument->addCPenalty(x, y - 1, mult * ICNDocument::hs_connector / 2);
        p_icnDocument->addCPenalty(x - 1, y, mult * ICNDocument::hs_connector / 2);
        p_icnDocument->addCPenalty(x, y, mult * ICNDocument::hs_connector);
        p_icnDocument->addCPenalty(x + 1, y, mult * ICNDocument::hs_connector / 2);
        p_icnDocument->addCPenalty(x, y + 1, mult * ICNDocument::hs_connector / 2);

        if (cells->haveCell(x, y))
            cells->cell(x, y).numCon += mult;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : urls)
        addFile(url);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QSerialPortInfo &serialPortInfo : serialPortInfos) {
        list << serialPortInfo.systemLocation();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QString category : categories) {
        QDir dir(QStandardPaths::locate(QStandardPaths::AppDataLocation, "examples/" + category + "/", QStandardPaths::LocateDirectory));

        // K3PopupMenu * m = static_cast<K3PopupMenu*>(factory()->container( "examples_" + category, this ));
        QMenu *m = static_cast<QMenu *>(factory()->container("examples_" + category, this));
        if (!m) {
            qCWarning(KTL_LOG) << "failed to cast to popup menu: "
                       << "examples_" + category;
            continue;
        }
        connect(m, SIGNAL(triggered(QAction *)), this, SLOT(openExample(QAction *)));

        QStringList files = dir.entryList();
        files.removeAll(".");
        files.removeAll("..");

        for (QString fileName : files) {
            QString name = filesToNames[fileName];
            if (name.isEmpty()) {
                name = fileName;
                name.remove(".circuit");
                name.replace("-", " ");
                name.replace("_", " ");

                // Capitalize the start of each word
                bool prevWasSpace = true;
                for (int i = 0; i < name.length(); ++i) {
                    if (prevWasSpace)
                        name[i] = name[i].toUpper();
                    prevWasSpace = name[i].isSpace();
                }
            }

            // m->insertItem( name, at, at ); // 2018.12.02
            m->addAction(name)->setData(at);
            m_exampleFiles[at] = dir.path() + "/" + fileName;
            at++;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (ConnectorLine* line: m_connectorLineList)
		delete line;
```

#### RANGE FOR STATEMENT 


```{c}
for (QPoint next : drawLineList) {
            ConnectorLine *line = new ConnectorLine(this, pixelOffset);
            m_connectorLineList.append(line);

            line->setPoints(prev.x(), prev.y(), next.x(), next.y());

            // (note that only one of the following QABS will be non-zero)
            pixelOffset += abs(prev.x() - next.x()) + abs(prev.y() - next.y());

            prev = next;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&connector]() { connector->removeConnector(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& mimeTypeName : qAsConst(m_mimeTypeNames)) {
        m_formatSelect->addItem(mimeDb.mimeTypeForName(mimeTypeName).comment());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &languageCode : descriptionLanguages) {
        QString text = languageCode;
        QLocale locale(languageCode);
        if (locale != QLocale::c()) {
            text = locale.nativeLanguageName();
            // For some languages the native name might be empty.
            // In this case use the non native language name as fallback.
            // See: QTBUG-51323
            if (text.isEmpty()) {
                text = QLocale::languageToString(locale.language());
            }
        }
        m_pLanguageSelect->addItem(text, languageCode);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *act: actionCollection()->actions()) {
        qDebug() << Q_FUNC_INFO << "act: " << act->text() << " shortcut " << act->shortcut() << ":" << act ;

        if ( ((act->objectName()) == QLatin1String("file_save"))
            || ((act->objectName()) == QLatin1String("file_save_as"))
            || ((act->objectName()) == QLatin1String("file_print"))
            || ((act->objectName()) == QLatin1String("edit_undo"))
            || ((act->objectName()) == QLatin1String("edit_redo"))
            || ((act->objectName()) == QLatin1String("edit_cut"))
            || ((act->objectName()) == QLatin1String("edit_copy"))
            || ((act->objectName()) == QLatin1String("edit_paste"))
        ) {
            act->setShortcutContext(Qt::WidgetWithChildrenShortcut);
            //act->setShortcutConfigurable(true);
            act->setShortcut(Qt::Key_unknown);
            qDebug() << Q_FUNC_INFO << "action " << act << " disabled";
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QString fileName : files) {
            QString name = filesToNames[fileName];
            if (name.isEmpty()) {
                name = fileName;
                name.remove(".circuit");
                name.replace("-", " ");
                name.replace("_", " ");

                // Capitalize the start of each word
                bool prevWasSpace = true;
                for (unsigned i = 0; i < name.length(); ++i) {
                    if (prevWasSpace)
                        name[i] = name[i].toUpper();
                    prevWasSpace = name[i].isSpace();
                }
            }

            // m->insertItem( name, at, at ); // 2018.12.02
            m->addAction(name)->setData(at);
            m_exampleFiles[at] = dir.path() + "/" + fileName;
            at++;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &internalUrl : availableInternal) {
        QString relativeURL;
        if (projectUrl.scheme() == internalUrl.scheme() && projectUrl.host() == internalUrl.host() &&
            projectUrl.port() == internalUrl.port() && projectUrl.userInfo() == internalUrl.userInfo())
        {
            relativeURL = projectDir.relativeFilePath(internalUrl.path());
        } else {
            relativeURL = internalUrl.toDisplayString(QUrl::PreferLocalFile);
        }
        // 2017.12.1 - convert to QListWidgetItem
		//Q3CheckListItem * item = new Q3CheckListItem( m_pWidget->m_pInternalLibraries, relativeURL, Q3CheckListItem::CheckBox );
        QListWidgetItem * item = new QListWidgetItem( relativeURL, m_pWidget->m_pInternalLibraries );
        item->setCheckState( (linkedInternal.contains(relativeURL)) ? Qt::Checked : Qt::Unchecked );
		//item->setOn( linkedInternal.contains(relativeURL) ); // 2017.12.1 - convert to QListWidgetItem
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &u : urls) {
			DocManager::self()->openURL(u);
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *act : actionCollection()->actions()) {
        qDebug() << Q_FUNC_INFO << "act: " << act->text() << " shortcut " << act->shortcut() << ":" << act;

        if (((act->objectName()) == QLatin1String("file_save")) || ((act->objectName()) == QLatin1String("file_save_as")) || ((act->objectName()) == QLatin1String("file_print")) || ((act->objectName()) == QLatin1String("edit_undo")) ||
            ((act->objectName()) == QLatin1String("edit_redo")) || ((act->objectName()) == QLatin1String("edit_cut")) || ((act->objectName()) == QLatin1String("edit_copy")) || ((act->objectName()) == QLatin1String("edit_paste"))) {
            act->setShortcutContext(Qt::WidgetWithChildrenShortcut);
            // act->setShortcutConfigurable(true);
            act->setShortcut(Qt::Key_unknown);
            qDebug() << Q_FUNC_INFO << "action " << act << " disabled";
        }
    }
```

#### AUTO 


```{c}
auto &mimeTypeName
```

#### AUTO 


```{c}
auto grOscill = KGlobal::config()->group("Oscilloscope");
```

#### RANGE FOR STATEMENT 


```{c}
for(QAction *a : actions) {
        switch (a->data().toInt()) {
            case TextDocument::AssemblyOutput:
            case TextDocument::HexOutput:
            case TextDocument::PICOutput:
                a->setEnabled( false );
                break;
            default:
                qDebug() << Q_FUNC_INFO << " skip action: " << a;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KtlQCanvasPolygonalItem *item : m_connectorLineList) {
        bool changed = (item->z() != z) || (item->pen() != pen) || (item->isVisible() != isVisible());

        if (!changed) {
            if (forceRedraw)
                canvas()->setChanged(item->boundingRect());
            continue;
        }

        item->setZ(z);
        item->setPen(pen);
        item->setVisible(isVisible());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *a : actions) {
        switch (a->data().toInt()) {
        case TextDocument::AssemblyOutput:
            actAsmOut = a;
            break;
        case TextDocument::HexOutput:
            actHexOut = a;
            break;
        case TextDocument::PICOutput:
            actPicOut = a;
            break;
        default:
            qCDebug(KTL_LOG) << " skip action: " << a;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &s : entries)
        list << s.toInt();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QPoint p : drawLineList) {
            if (p.x() < x1 || x1 == invalid)
                x1 = p.x();
            if (p.x() > x2 || x2 == invalid)
                x2 = p.x();

            if (p.y() < y1 || y1 == invalid)
                y1 = p.y();
            if (p.y() > y2 || y2 == invalid)
                y2 = p.y();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : urls)
        load(url);
```

#### RANGE FOR STATEMENT 


```{c}
for (QString category : categories) {
        QDir dir(QStandardPaths::locate(QStandardPaths::AppDataLocation, "examples/" + category + "/", QStandardPaths::LocateDirectory));

        // K3PopupMenu * m = static_cast<K3PopupMenu*>(factory()->container( "examples_" + category, this ));
        QMenu *m = static_cast<QMenu *>(factory()->container("examples_" + category, this));
        if (!m) {
            qCWarning(KTL_LOG) << "failed to cast to popup menu: "
                       << "examples_" + category;
            continue;
        }
        connect(m, &QMenu::triggered, this, &KTechlab::openExample);

        QStringList files = dir.entryList();
        files.removeAll(".");
        files.removeAll("..");

        for (QString fileName : files) {
            QString name = filesToNames[fileName];
            if (name.isEmpty()) {
                name = fileName;
                name.remove(".circuit");
                name.replace("-", " ");
                name.replace("_", " ");

                // Capitalize the start of each word
                bool prevWasSpace = true;
                for (int i = 0; i < name.length(); ++i) {
                    if (prevWasSpace)
                        name[i] = name[i].toUpper();
                    prevWasSpace = name[i].isSpace();
                }
            }

            // m->insertItem( name, at, at ); // 2018.12.02
            m->addAction(name)->setData(at);
            m_exampleFiles[at] = dir.path() + "/" + fileName;
            at++;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& languageCode : descriptionLanguages) {
        QString text = languageCode;
        QLocale locale(languageCode);
        if (locale != QLocale::c()) {
            text = locale.nativeLanguageName();
            // For some languages the native name might be empty.
            // In this case use the non native language name as fallback.
            // See: QTBUG-51323
            if (text.isEmpty()) {
                text = QLocale::languageToString(locale.language());
            }
        }
	m_pLanguageSelect->addItem(text, languageCode);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : urls)
		load(url);
```

#### AUTO 


```{c}
const auto serialPortInfos = QSerialPortInfo::availablePorts();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &u : urls) {
            DocManager::self()->openURL(u);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &mimeTypeName : qAsConst(m_mimeTypeNames)) {
        m_formatSelect->addItem(mimeDb.mimeTypeForName(mimeTypeName).comment());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *a : actions) {
        switch (a->data().toInt()) {
        case TextDocument::AssemblyOutput:
        case TextDocument::HexOutput:
        case TextDocument::PICOutput:
            a->setEnabled(false);
            break;
        default:
            qDebug() << Q_FUNC_INFO << " skip action: " << a;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QObject *child : children) {
        if (0 == strcmp(child->metaObject()->className(), className)) {
            return child;
        }
        QObject *ret = ktlFindQObjectChild(child, className);
        if (ret) {
            return ret;
        }
    }
```

#### AUTO 


```{c}
auto& mimeTypeName
```

#### RANGE FOR STATEMENT 


```{c}
for (QObject *child : children) {
        if (0 == strcmp( child->metaObject()->className(), className )) {
            return child;
        }
        QObject *ret = ktlFindQObjectChild(child, className);
        if (ret) {
            return ret;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QPoint next: drawLineList) {
			ConnectorLine *line = new ConnectorLine(this, pixelOffset);
			m_connectorLineList.append(line);

			line->setPoints(prev.x(), prev.y(), next.x(), next.y());

			// (note that only one of the following QABS will be non-zero)
			pixelOffset += abs(prev.x() - next.x()) + abs(prev.y() - next.y());

			prev = next;
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (QPoint p: *m_conRouter->cellPointList()) {
		int x = p.x();
		int y = p.y();

		// Add the points of this connector to the cell array in the ICNDocument,
		// so that other connectors still to calculate their points know to try
		// and avoid this connector

		p_icnDocument->addCPenalty(x    , y - 1, mult*ICNDocument::hs_connector / 2);
		p_icnDocument->addCPenalty(x - 1, y    , mult*ICNDocument::hs_connector / 2);
		p_icnDocument->addCPenalty(x    , y    , mult*ICNDocument::hs_connector    );
		p_icnDocument->addCPenalty(x + 1, y    , mult*ICNDocument::hs_connector / 2);
		p_icnDocument->addCPenalty(x    , y + 1, mult*ICNDocument::hs_connector / 2);

		if (cells->haveCell(x , y))
			cells->cell(x, y).numCon += mult;
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : urls)
            fileList << url.toLocalFile();
```

#### RANGE FOR STATEMENT 


```{c}
for (QString format : mimeData->formats()) {
        if (format.startsWith("ktechlab/")) {
            matchingFormat = format;
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( QString category: categories)
	{
		QDir dir( QStandardPaths::locate(QStandardPaths::AppDataLocation, "examples/" + category + "/", QStandardPaths::LocateDirectory ) );

		//K3PopupMenu * m = static_cast<K3PopupMenu*>(factory()->container( "examples_" + category, this ));
        QMenu * m = static_cast<QMenu*>(factory()->container( "examples_" + category, this ));
		if ( !m ) {
            qWarning() << "failed to cast to popup menu: " << "examples_" + category;
			continue;
        }
		connect( m, SIGNAL(triggered(QAction*)), this, SLOT(openExample(QAction*)) );

		QStringList files = dir.entryList();
		files.removeAll(".");
		files.removeAll("..");

		for ( QString fileName: files )
		{
			QString name = filesToNames[ fileName ];
			if ( name.isEmpty() )
			{
				name = fileName;
				name.remove(".circuit");
				name.replace("-"," ");
				name.replace("_"," ");

				// Capitalize the start of each word
				bool prevWasSpace = true;
				for ( unsigned i = 0; i < name.length(); ++i )
				{
					if ( prevWasSpace )
						name[i] = name[i].toUpper();
					prevWasSpace = name[i].isSpace();
				}
			}

			//m->insertItem( name, at, at ); // 2018.12.02
            m->addAction( name )->setData(at);
			m_exampleFiles[ at ] = dir.path() + "/" + fileName;
			at++;
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : urls)
		addFile(url);
```

#### RANGE FOR STATEMENT 


```{c}
for (QPoint p : *m_conRouter->cellPointList()) {
        const int x = p.x();
        const int y = p.y();

        const int numCon = cells->haveCell(x, y) ? cells->cell(x, y).numCon : 0;

        const int y_canvas = toCanvas(y);
        const int x_canvas = toCanvas(x);

        const bool bumpNext = (prevX == x && numCon > 1 && std::abs(y_canvas - startNode()->y()) > 8 && std::abs(y_canvas - endNode()->y()) > 8);

        int x0 = prevX_canvas;
        int x2 = x_canvas;
        int x1 = (x0 + x2) / 2;

        int y0 = prevY_canvas;
        int y3 = y_canvas;
        int y1 = (y0 == y3) ? y0 : ((y0 < y3) ? y0 + 3 : y0 - 3);
        int y2 = (y0 == y3) ? y3 : ((y0 < y3) ? y3 - 3 : y3 + 3);

        if (bumpNow)
            x0 += 3;
        if (bumpNext)
            x2 += 3;

        if (!bumpNow && !bumpNext) {
            drawLineList += QPoint(x0, y0);
            drawLineList += QPoint(x2, y3);
        } else if (bumpNow) {
            drawLineList += QPoint(x0, y0);
            drawLineList += QPoint(x1, y1);
            drawLineList += QPoint(x2, y3);
        } else if (bumpNext) {
            drawLineList += QPoint(x0, y0);
            drawLineList += QPoint(x1, y2);
            drawLineList += QPoint(x2, y3);
        } else {
            drawLineList += QPoint(x0, y0);
            drawLineList += QPoint(x1, y1);
            drawLineList += QPoint(x1, y2);
            drawLineList += QPoint(x2, y3);
        }

        prevX = x;
        prevY = y;

        prevY_canvas = y_canvas;
        prevX_canvas = x_canvas;
        bumpNow = bumpNext;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QString category : categories) {
        QDir dir(QStandardPaths::locate(QStandardPaths::AppDataLocation, "examples/" + category + "/", QStandardPaths::LocateDirectory));

        // K3PopupMenu * m = static_cast<K3PopupMenu*>(factory()->container( "examples_" + category, this ));
        QMenu *m = static_cast<QMenu *>(factory()->container("examples_" + category, this));
        if (!m) {
            qCWarning(KTL_LOG) << "failed to cast to popup menu: "
                       << "examples_" + category;
            continue;
        }
        connect(m, SIGNAL(triggered(QAction *)), this, SLOT(openExample(QAction *)));

        QStringList files = dir.entryList();
        files.removeAll(".");
        files.removeAll("..");

        for (QString fileName : files) {
            QString name = filesToNames[fileName];
            if (name.isEmpty()) {
                name = fileName;
                name.remove(".circuit");
                name.replace("-", " ");
                name.replace("_", " ");

                // Capitalize the start of each word
                bool prevWasSpace = true;
                for (unsigned i = 0; i < name.length(); ++i) {
                    if (prevWasSpace)
                        name[i] = name[i].toUpper();
                    prevWasSpace = name[i].isSpace();
                }
            }

            // m->insertItem( name, at, at ); // 2018.12.02
            m->addAction(name)->setData(at);
            m_exampleFiles[at] = dir.path() + "/" + fileName;
            at++;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( QString fileName: files )
		{
			QString name = filesToNames[ fileName ];
			if ( name.isEmpty() )
			{
				name = fileName;
				name.remove(".circuit");
				name.replace("-"," ");
				name.replace("_"," ");

				// Capitalize the start of each word
				bool prevWasSpace = true;
				for ( unsigned i = 0; i < name.length(); ++i )
				{
					if ( prevWasSpace )
						name[i] = name[i].toUpper();
					prevWasSpace = name[i].isSpace();
				}
			}

			//m->insertItem( name, at, at ); // 2018.12.02
            m->addAction( name )->setData(at);
			m_exampleFiles[ at ] = dir.path() + "/" + fileName;
			at++;
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *act : actionCollection()->actions()) {
        qCDebug(KTL_LOG) << "act: " << act->text() << " shortcut " << act->shortcut() << ":" << act;

        if (((act->objectName()) == QLatin1String("file_save")) || ((act->objectName()) == QLatin1String("file_save_as")) || ((act->objectName()) == QLatin1String("file_print")) || ((act->objectName()) == QLatin1String("edit_undo")) ||
            ((act->objectName()) == QLatin1String("edit_redo")) || ((act->objectName()) == QLatin1String("edit_cut")) || ((act->objectName()) == QLatin1String("edit_copy")) || ((act->objectName()) == QLatin1String("edit_paste"))) {
            act->setShortcutContext(Qt::WidgetWithChildrenShortcut);
            // act->setShortcutConfigurable(true);
            act->setShortcut(Qt::Key_unknown);
            qCDebug(KTL_LOG) << "action " << act << " disabled";
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QPoint p: drawLineList) {
			if (p.x() < x1 || x1 == invalid) x1 = p.x();
			if (p.x() > x2 || x2 == invalid) x2 = p.x();

			if (p.y() < y1 || y1 == invalid) y1 = p.y();
			if (p.y() > y2 || y2 == invalid) y2 = p.y();
		}
```

