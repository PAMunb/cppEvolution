#### AUTO 


```{c}
auto i = gen.mToGenerate.begin();
```

#### AUTO 


```{c}
auto jt = set2.begin();
```

#### AUTO 


```{c}
auto firstPairs = NFA<SeqCharSet<Ucs2> >(SeqCharSet<Ucs2>::range(startHighSurrogate, startHighSurrogate + 1));
```

#### AUTO 


```{c}
auto jt = FLD.begin();
```

#### AUTO 


```{c}
LEXER_EXTRA_CODE_GEN(constructorCode)
```

#### AUTO 


```{c}
auto i = node->mPre.begin();
```

#### AUTO 


```{c}
LEXER_EXTRA_CODE_GEN(declarations)
```

#### DECLTYPE 


```{c}
__typeof__(it) jt = FLD.begin();
```

#### AUTO 


```{c}
auto midPairs = NFA<SeqCharSet<Ucs2> >(SeqCharSet<Ucs2>::range(startHighSurrogate, endHighSurrogate));
```

#### DECLTYPE 


```{c}
__typeof__(node->mParen.begin()) i = node->mParen.begin();
```

#### AUTO 


```{c}
auto flags = o.flags();
```

#### DECLTYPE 


```{c}
__typeof__(gen.mToGenerate.begin()) i = gen.mToGenerate.begin();
```

#### DECLTYPE 


```{c}
__typeof__(data.begin()) i = data.begin();
```

#### AUTO 


```{c}
auto toInsert = GNFA::range(start, end+1);
```

#### AUTO 


```{c}
auto mbegin = max(begin, (quint32)0xe000);
```

#### DECLTYPE 


```{c}
__typeof__(it) jt = FD.begin();
```

#### AUTO 


```{c}
auto i = globalSystem.terminals.begin();
```

#### DECLTYPE 


```{c}
__typeof__(node->mPre.begin()) i = node->mPre.begin();
```

#### AUTO 


```{c}
const auto str = qString2Codec<codec>(s);
```

#### AUTO 


```{c}
auto fill = o.fill();
```

#### AUTO 


```{c}
UTF16_IMPL(SeqCharSet, s2)
```

#### AUTO 


```{c}
auto i = dfaForNfa.begin();
```

#### AUTO 


```{c}
auto i = rules.begin();
```

#### DECLTYPE 


```{c}
__typeof__(st.begin()) i = st.begin();
```

#### AUTO 


```{c}
LEXER_EXTRA_CODE_GEN(destructorCode)
```

#### AUTO 


```{c}
auto i = tmp.rules.begin();
```

#### AUTO 


```{c}
auto i = node->mParen.begin();
```

#### AUTO 


```{c}
auto lastPairs = NFA<SeqCharSet<Ucs2> >(SeqCharSet<Ucs2>::range(endHighSurrogate, endHighSurrogate + 1));
```

#### AUTO 


```{c}
const auto &p = *i;
```

#### DECLTYPE 


```{c}
__typeof__(rules[i].begin()) j = rules[i].begin();
```

#### DECLTYPE 


```{c}
__typeof__(rules.begin()) i = rules.begin();
```

#### AUTO 


```{c}
auto pad = o.padChar();
```

#### AUTO 


```{c}
auto i = node->mTern.begin();
```

#### AUTO 


```{c}
auto i = lexerEnvResults.begin();
```

#### DECLTYPE 


```{c}
__typeof__(set2.begin()) jt = set2.begin();
```

#### AUTO 


```{c}
auto j = orules.begin();
```

#### AUTO 


```{c}
auto tmp = dfa();
```

#### AUTO 


```{c}
auto width = o.width();
```

#### DECLTYPE 


```{c}
typeof(GDFA::type) GDFA::type = GDFA::SUcs2;
```

#### AUTO 


```{c}
auto next = i;
```

#### AUTO 


```{c}
UTF16_IMPL(TableCharSet, t2)
```

#### DECLTYPE 


```{c}
__typeof__(globalSystem.terminals.begin()) i = globalSystem.terminals.begin();
```

#### DECLTYPE 


```{c}
__typeof__(FLD.begin()) it = FLD.begin();
```

#### DECLTYPE 


```{c}
__typeof__(globalSystem.rules.begin()) i = globalSystem.rules.begin();
```

#### DECLTYPE 


```{c}
__typeof__(o.data.begin()) i = o.data.begin();
```

#### AUTO 


```{c}
auto midTuples = NFA<CharSet<Latin1> >(CharSet<Latin1>::range(from0 + 1, to0));
```

#### DECLTYPE 


```{c}
__typeof__(i) next = i;
```

#### DECLTYPE 


```{c}
__typeof__(rules.begin()) i = std::lower_bound(rules.begin(), rules.end(), sym, &ruleComp);
```

#### AUTO 


```{c}
auto i = node->mPost.begin();
```

#### AUTO 


```{c}
auto i = node->mBin.begin();
```

#### AUTO 


```{c}
auto i = std::lower_bound(rules.begin(), rules.end(), sym, &ruleComp);
```

#### DECLTYPE 


```{c}
__typeof__(node->mTern.begin()) i = node->mTern.begin();
```

#### AUTO 


```{c}
auto surrPairs = NFA<SeqCharSet<Ucs2> >(SeqCharSet<Ucs2>::range(startHighSurrogate + 1, endHighSurrogate + 1));
```

#### AUTO 


```{c}
auto any = anyChar();
```

#### DECLTYPE 


```{c}
__typeof__(node->mPost.begin()) i = node->mPost.begin();
```

#### AUTO 


```{c}
auto surrPairs = NFA<SeqCharSet<Ucs2> >(SeqCharSet<Ucs2>::range(startHighSurrogate, endHighSurrogate));
```

#### AUTO 


```{c}
auto i = qLowerBound(rules.begin(), rules.end(), sym, &ruleComp);
```

#### AUTO 


```{c}
auto base = o.integerBase();
```

#### AUTO 


```{c}
auto width = o.fieldWidth();
```

#### AUTO 


```{c}
auto i = st.begin();
```

#### AUTO 


```{c}
auto i = regexpById.begin();
```

#### AUTO 


```{c}
auto i = cs.data.begin();
```

#### AUTO 


```{c}
auto i = str.begin();
```

#### DECLTYPE 


```{c}
EACH_TYPE(macro)
```

#### AUTO 


```{c}
auto j = i->begin();
```

#### DECLTYPE 


```{c}
__typeof__(node->mBin.begin()) i = node->mBin.begin();
```

#### AUTO 


```{c}
auto midPairs = NFA<SeqCharSet<Ucs2> >(SeqCharSet<Ucs2>::range(startHighSurrogate + 1, endHighSurrogate));
```

#### AUTO 


```{c}
auto i = tmp.accept.begin();
```

#### AUTO 


```{c}
auto firstTuples = NFA<CharSet<Latin1> >(CharSet<Latin1>(from0));
```

#### AUTO 


```{c}
auto i = o.data.begin();
```

#### AUTO 


```{c}
auto i = globalSystem.rules.begin();
```

#### AUTO 


```{c}
auto j = rules[i].begin();
```

#### AUTO 


```{c}
auto tuples = NFA<CharSet<Latin1> >(CharSet<Latin1>(from0));
```

#### AUTO 


```{c}
auto jt = FD.begin();
```

#### AUTO 


```{c}
auto line = file.readLine();
```

#### AUTO 


```{c}
auto lastTuples = NFA<CharSet<Latin1> >(CharSet<Latin1>(to0));
```

#### DECLTYPE 


```{c}
__typeof__(FD.begin()) it = FD.begin();
```

#### AUTO 


```{c}
auto str = qString2Codec<codec>(s);
```

#### AUTO 


```{c}
auto orules = rules[i];
```

#### AUTO 


```{c}
auto toInsert = GNFA::character(single);
```

