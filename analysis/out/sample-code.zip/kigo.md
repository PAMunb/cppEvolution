#### AUTO 


```{c}
auto mainWin = new Kigo::MainWindow(game, nullptr);
```

#### RANGE FOR STATEMENT 


```{c}
for(QGraphicsPixmapItem *item : std::as_const(m_territoryItems)) {  // Old territory is invalid, remove it first
        removeItem(item);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Move &move : qAsConst(m_movesList)) {
            if (move.player()->color() == player.color()) {
                list.append(move);
            }
        }
```

#### AUTO 


```{c}
const auto moves = m_game->moves();
```

#### RANGE FOR STATEMENT 


```{c}
for (QGraphicsPixmapItem *item : qAsConst(m_hintItems)) {   // Old hint is invalid, remove it first
        removeItem(item);
    }
```

#### AUTO 


```{c}
const auto blackStones = m_game->finalStates(Game::FinalState::FinalBlackTerritory);
```

#### AUTO 


```{c}
auto* theme
```

#### RANGE FOR STATEMENT 


```{c}
for (const Stone &stone : blackStones) {
            item = addPixmap(stonePixmap);
            item->setZValue(8);
            const int xOff = stone.x() >= 'I' ? stone.x() - 'A' - 1 : stone.x() - 'A';
            item->setPos(QPointF(m_gridRect.x() + xOff * m_cellSize - halfCellSize + 2,
                                 m_gridRect.y() + (m_boardSize - stone.y()) * m_cellSize - halfCellSize + 2));
            m_territoryItems.append(item);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] { m_gameScene->showMessage(i18n("Set up a new game...")); }
```

#### AUTO 


```{c}
const auto moves = m_game->bestMoves(m_game->currentPlayer());
```

#### AUTO 


```{c}
const auto whiteStones = m_game->stones(m_game->whitePlayer());
```

#### RANGE FOR STATEMENT 


```{c}
for (const Stone &stone : whiteStones) {
            item = addPixmap(stonePixmap);
            item->setZValue(8);
            const int xOff = stone.x() >= 'I' ? stone.x() - 'A' - 1 : stone.x() - 'A';
            item->setPos(QPointF(m_gridRect.x() + xOff * m_cellSize - halfCellSize + 2,
                                 m_gridRect.y() + (m_boardSize - stone.y()) * m_cellSize - halfCellSize + 2));
            m_territoryItems.append(item);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Stone &stone : blackStones) {
        ThemeRenderer::Element element = (stone == lastStone) ? ThemeRenderer::Element::BlackStoneLast : ThemeRenderer::Element::BlackStone;
        stoneItem = addPixmap(ThemeRenderer::self()->renderElement(element, m_stonePixmapSize));
        stoneItem->setZValue(2);
        const int xOff = stone.x() >= 'I' ? stone.x() - 'A' - 1 : stone.x() - 'A';
        stoneItem->setPos(QPointF(m_gridRect.x() + xOff * m_cellSize - halfStoneSize + 1,
                             m_gridRect.y() + (m_boardSize - stone.y()) * m_cellSize - halfStoneSize + 1));
        m_stoneItems.append(stoneItem);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QGraphicsPixmapItem *stoneItem : std::as_const(m_stoneItems)) {  // Clear all stone items
        removeItem(stoneItem);
    }
```

#### AUTO 


```{c}
auto errorWidget = new ErrorWidget(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Stone &stone : whiteStones) {
        ThemeRenderer::Element element = (stone == lastStone) ? ThemeRenderer::Element::WhiteStoneLast : ThemeRenderer::Element::WhiteStone;
        stoneItem = addPixmap(ThemeRenderer::self()->renderElement(element, m_stonePixmapSize));
        stoneItem->setZValue(2);
        const int xOff = stone.x() >= 'I' ? stone.x() - 'A' - 1 : stone.x() - 'A';
        stoneItem->setPos(QPointF(m_gridRect.x() + xOff * m_cellSize - halfStoneSize + 1,
                             m_gridRect.y() + (m_boardSize - stone.y()) * m_cellSize - halfStoneSize + 1));
        m_stoneItems.append(stoneItem);
    }
```

#### AUTO 


```{c}
auto gameWidget = new GameWidget(m_game, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &entry : entries) {
            list.append(Stone(entry));
        }
```

#### AUTO 


```{c}
const auto entries = m_response.split(QLatin1Char(' '));
```

#### RANGE FOR STATEMENT 


```{c}
for (const Move &move : moves) {
            int xOff = move.stone().x() >= 'I' ? move.stone().x() - 'A' - 1 : move.stone().x() - 'A';
            QPointF pos = QPointF(m_gridRect.x() + xOff * m_cellSize,
                                  m_gridRect.y() + (m_boardSize - move.stone().y()) * m_cellSize);

            if (QGraphicsPixmapItem *item = static_cast<QGraphicsPixmapItem *>(itemAt(pos, QTransform()))) {
                // We found an item in the scene that is in our move numbers, so we paint it's move number
                // on top of the item and that's all.
                //TODO: Check for existing move number to do special treatment
                QPixmap pixmap = item->pixmap();
                QPainter painter(&pixmap);
                if (move.player()->isWhite()) {
                    painter.setPen(Qt::black);
                } else if (move.player()->isBlack()) {
                    painter.setPen(Qt::white);
                }
                QFont f = painter.font();
                f.setPointSizeF(halfStoneSize / 2);
                painter.setFont(f);
                painter.drawText(pixmap.rect(), Qt::AlignCenter, QString::number(i++));
                item->setPixmap(pixmap);
            }
        }
```

#### AUTO 


```{c}
const auto whiteStones = m_game->finalStates(Game::FinalState::FinalWhiteTerritory);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto* theme : themes) {
        if (theme->identifier() == themeIdentifier) {
            provider->setCurrentTheme(theme);
            loadTheme(theme);
            break;
        }
    }
```

#### AUTO 


```{c}
const auto positions = m_response.split(QLatin1Char(' '));
```

#### AUTO 


```{c}
const auto blackStones = m_game->stones(m_game->blackPlayer());
```

#### RANGE FOR STATEMENT 


```{c}
for (QGraphicsPixmapItem *item : std::as_const(m_hintItems)) {   // Old hint is invalid, remove it first
        removeItem(item);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(QGraphicsPixmapItem *item : qAsConst(m_territoryItems)) {  // Old territory is invalid, remove it first
        removeItem(item);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Move &move : std::as_const(m_movesList)) {
            if (move.player()->color() == player.color()) {
                list.append(move);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QGraphicsPixmapItem *stoneItem : qAsConst(m_stoneItems)) {  // Clear all stone items
        removeItem(stoneItem);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &pos : positions) {
                list.append(Stone(pos));
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Stone &move : moves) {
            QPixmap stonePixmap;
            if (m_game->currentPlayer().isWhite()) {
                stonePixmap = ThemeRenderer::self()->renderElement(ThemeRenderer::Element::WhiteStoneTransparent, m_stonePixmapSize);
            } else if (m_game->currentPlayer().isBlack()) {
                stonePixmap = ThemeRenderer::self()->renderElement(ThemeRenderer::Element::BlackStoneTransparent, m_stonePixmapSize);
            }

            QPainter painter(&stonePixmap);
            if (m_game->currentPlayer().isWhite()) {
                painter.setPen(Qt::black);
            } else if (m_game->currentPlayer().isBlack()) {
                painter.setPen(Qt::white);
            }
            QFont f = painter.font();
            f.setPointSizeF(m_cellSize / 4);
            painter.setFont(f);
            painter.drawText(stonePixmap.rect(), Qt::AlignCenter, QString::number(move.value()));
            painter.end();

            item = addPixmap(stonePixmap);
            item->setZValue(4);
            const int xOff = move.x() >= 'I' ? move.x() - 'A' - 1 : move.x() - 'A';
            item->setPos(QPointF(m_gridRect.x() + xOff * m_cellSize - halfStoneSize + 2,
                                 m_gridRect.y() + (m_boardSize - move.y()) * m_cellSize - halfStoneSize + 2));
            m_hintItems.append(item);
        }
```

