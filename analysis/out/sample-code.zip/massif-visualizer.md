#### AUTO 


```{c}
const auto saveFilename = QFileDialog::getSaveFileName(this, i18n("Save Current Visualization"), QString(),
                                                           i18n("Images (*.png *.jpg *.tiff *.svg)"));
```

#### AUTO 


```{c}
const auto url = QUrl::fromLocalFile(m_dotGenerator->outputFile());
```

