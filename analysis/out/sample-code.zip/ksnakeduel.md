#### AUTO 


```{c}
auto *prov = new KgThemeProvider(QByteArray());
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &label : m_statusBarLabel) {
		label = new QLabel(this);
		label->setAlignment(Qt::AlignCenter);
		statusBar()->addWidget(label, 1);
	}
```

#### AUTO 


```{c}
auto &label
```

#### RANGE FOR STATEMENT 


```{c}
for (auto* theme : themes) {
	    if (theme->identifier() == identifier) {
		provider->setCurrentTheme(theme);
		return true;
	    }
	}
```

#### LAMBDA EXPRESSION 


```{c}
[this](const KgTheme *theme) {
		Settings::setTheme(QString::fromUtf8(theme->identifier()));
	    }
```

#### AUTO 


```{c}
auto* theme
```

