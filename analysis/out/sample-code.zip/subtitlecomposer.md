#### LAMBDA EXPRESSION 


```{c}
[this](){ m_player->increaseVolume(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](){ m_control->selectAll(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](int val){
		QSignalBlocker b(alt_MinDurationPerCharacter);
		alt_MinDurationPerCharacter->setValue(1000 / val);
		kcfg_IdealDurationPerCharacter->setMinimum(val);
		alt_IdealDurationPerCharacter->setMaximum(1000 / val);
	}
```

#### RANGE FOR STATEMENT 


```{c}
for(const QItemSelectionRange &r : selection) {
		if(r.bottom() > row)
			row = r.bottom();
	}
```

#### AUTO 


```{c}
auto i = audioTracks.cbegin();
```

#### LAMBDA EXPRESSION 


```{c}
[&](RichDocument *doc)->bool{
		if(doc->isEmpty())
			return false;
		const QString &text = doc->toPlainText();
		QTextCursor *c = doc->undoableCursor();
		int len = text.length();
		int i = len / 2;
		int j = i + len % 2;
		for(; ; i--, j++) {
			if(text.at(i) == QChar::Space) {
				c->movePosition(QTextCursor::Start);
				c->movePosition(QTextCursor::NextCharacter, QTextCursor::MoveAnchor, i);
				c->movePosition(QTextCursor::NextCharacter, QTextCursor::KeepAnchor);
				c->insertText(QString(QChar::LineFeed));
				return true;
			}
			if(text.at(j) == QChar::Space) {
				c->movePosition(QTextCursor::Start);
				c->movePosition(QTextCursor::NextCharacter, QTextCursor::MoveAnchor, j);
				c->movePosition(QTextCursor::NextCharacter, QTextCursor::KeepAnchor);
				c->insertText(QString(QChar::LineFeed));
				return true;
			}
			if(i == 0) {
				c->movePosition(QTextCursor::End, QTextCursor::MoveAnchor);
				c->insertText(QString(QChar::LineFeed));
				return true;
			}
		}
		return false;
	}
```

#### LAMBDA EXPRESSION 


```{c}
[this](){ reloadScripts(); }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString &knownExtension : m_extensions) {
			if(knownExtension != QChar('*') && knownExtension.compare(extension, Qt::CaseInsensitive) == 0) {
				return true;
			}
		}
```

#### LAMBDA EXPRESSION 


```{c}
[&](const char *actionName, bool checkable=false, bool checked=false) -> QAction * {
		static const Application *app = Application::instance();
		QAction *action = app->action(actionName);
		if(checkable) {
			checkableActions.append(action);
			action->setCheckable(true);
			action->setChecked(checked);
		}
		return action;
	}
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString &subdir: subdirs) {
			const QDir path(buildPluginPath.filePath(subdir));
			const QStringList libs = path.entryList(QDir::Files);
			for(const QString &lib: libs) {
				if(QLibrary::isLibrary(lib))
					pluginLoad(path.filePath(lib));
			}
		}
```

#### LAMBDA EXPRESSION 


```{c}
[&](){
				m_subtitle->removeLines(RangeList(Range(currentLine->index())), Subtitle::Both);
				if(selectedLine != currentLine)
					app->linesWidget()->setCurrentLine(selectedLine, true);
			}
```

#### AUTO 


```{c}
auto it = m_scripts.begin();
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString &ext : format->extensions())
				extensions += QStringLiteral(" *.") % ext % QStringLiteral(" *.") % ext.toUpper();
```

#### RANGE FOR STATEMENT 


```{c}
for(QStringList &encList : m_encodings) {
		bool first = true;
		for(QString &enc: encList) {
			if(first)
				first = false;
			else
				enc = enc.toUpper();
		}
	}
```

#### LAMBDA EXPRESSION 


```{c}
[this](){ openSubtitle(); }
```

#### RANGE FOR STATEMENT 


```{c}
for(int n: lines) {
		SubtitleLine *l = new SubtitleLine(n * 1000, n * 1000 + 500);
		l->primaryDoc()->setPlainText(QString::number(n));
		sub->insertLine(l);
	}
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool muted){
		if(m_muted != muted) emit muteChanged(m_muted = muted);
	}
```

#### LAMBDA EXPRESSION 


```{c}
[this, ed](){
			if(linesWidget()->m_inlineEditor == ed)
				linesWidget()->m_inlineEditor = nullptr;
		}
```

#### LAMBDA EXPRESSION 


```{c}
[&](){
				m_subtitle->removeLines(RangeList(Range(currentLine->index())), SubtitleTarget::Both);
				if(selectedLine != currentLine)
					app->linesWidget()->setCurrentLine(selectedLine, true);
			}
```

#### LAMBDA EXPRESSION 


```{c}
[this](){ addScript(); }
```

#### LAMBDA EXPRESSION 


```{c}
[&](int x, int y){
		if(piece->top > y)
			piece->top = y;
		if(piece->bottom < y)
			piece->bottom = y;

		if(piece->left > x)
			piece->left = x;
		if(piece->right < x)
			piece->right = x;

		piece->pixels.append(QPoint(x, y));
		pieceBitmap.setPixel(x, y, ignoredColors.at(0));

		if(x < width - 1 && !ignoredColors.contains(pieceBitmap.pixelIndex(x + 1, y)))
			cutPiece(x + 1, y);
		if(x > 0 && !ignoredColors.contains(pieceBitmap.pixelIndex(x - 1, y)))
			cutPiece(x - 1, y);
		if(y < height - 1 && !ignoredColors.contains(pieceBitmap.pixelIndex(x, y + 1)))
			cutPiece(x, y + 1);
		if(y > 0 && !ignoredColors.contains(pieceBitmap.pixelIndex(x, y - 1)))
			cutPiece(x, y - 1);
	}
```

#### LAMBDA EXPRESSION 


```{c}
[this](){ m_control->cut(); }
```

#### AUTO 


```{c}
auto *fullScreenLayout = new QHBoxLayout;
```

#### LAMBDA EXPRESSION 


```{c}
[this](){ emit positionChanged(position()); }
```

#### AUTO 


```{c}
auto splitOnSpace = [&](RichDocument *doc)->bool{
		if(doc->isEmpty())
			return false;
		const QString &text = doc->toPlainText();
		QTextCursor *c = doc->undoableCursor();
		int len = text.length();
		int i = len / 2;
		int j = i + len % 2;
		for(; ; i--, j++) {
			if(text.at(i) == QChar::Space) {
				c->movePosition(QTextCursor::Start);
				c->movePosition(QTextCursor::NextCharacter, QTextCursor::MoveAnchor, i);
				c->movePosition(QTextCursor::NextCharacter, QTextCursor::KeepAnchor);
				c->insertText(QString(QChar::LineFeed));
				return true;
			}
			if(text.at(j) == QChar::Space) {
				c->movePosition(QTextCursor::Start);
				c->movePosition(QTextCursor::NextCharacter, QTextCursor::MoveAnchor, j);
				c->movePosition(QTextCursor::NextCharacter, QTextCursor::KeepAnchor);
				c->insertText(QString(QChar::LineFeed));
				return true;
			}
			if(i == 0) {
				c->movePosition(QTextCursor::End, QTextCursor::MoveAnchor);
				c->insertText(QString(QChar::LineFeed));
				return true;
			}
		}
		return false;
	};
```

#### AUTO 


```{c}
auto i = subTracks.cbegin();
```

#### LAMBDA EXPRESSION 


```{c}
[&](){ m_videoOutput = nullptr; }
```

#### LAMBDA EXPRESSION 


```{c}
[&](int){ if(m_subtitle) m_subtitle->updateState(); }
```

#### LAMBDA EXPRESSION 


```{c}
[&](const int index){
		m_secondaryState = index;
		if(m_secondaryState == m_secondaryCleanState)
			emit secondaryDirtyStateChanged(false);
		else
			emit secondaryDirtyStateChanged(true);
		emit secondaryChanged();
	}
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QUrl &url){ openSubtitle(url); }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QItemSelectionRange &r : is) {
		preSelection.push_back(std::pair<int, int>(r.top(), r.bottom()));
		postSelection.push_back(std::pair<int, int>(r.top(), r.bottom()));
	}
```

#### LAMBDA EXPRESSION 


```{c}
[this](int val){
		QSignalBlocker b(kcfg_IdealDurationPerCharacter);
		kcfg_IdealDurationPerCharacter->setValue(1000 / val);
		alt_MinDurationPerCharacter->setMinimum(val);
		alt_MaxDurationPerCharacter->setMaximum(val);
		kcfg_MinDurationPerCharacter->setMaximum(1000 / val);
		kcfg_MaxDurationPerCharacter->setMinimum(1000 / val);
	}
```

#### LAMBDA EXPRESSION 


```{c}
[this](){
		m_player->renderer()->reset();
		emit fileOpened(m_filePath);
		m_fps = m_player->videoFPS();
		emit fpsChanged(m_fps);
		m_videoWidget->videoLayer()->show();
	}
```

#### LAMBDA EXPRESSION 


```{c}
[&](){ addScript(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](int val){
		QSignalBlocker b(alt_IdealDurationPerCharacter);
		alt_IdealDurationPerCharacter->setValue(1000 / val);
		kcfg_MinDurationPerCharacter->setMaximum(val);
		kcfg_MaxDurationPerCharacter->setMinimum(val);
		alt_MinDurationPerCharacter->setMinimum(1000 / val);
		alt_MaxDurationPerCharacter->setMaximum(1000 / val);
	}
```

#### LAMBDA EXPRESSION 


```{c}
[this](){
		const double pf = position();
		const qint32 p = pf * 1000.;
		if(m_postitionLast != p) {
			m_postitionLast = p;
			emit positionChanged(pf);
		}
	}
```

#### AUTO 


```{c}
auto updatePrimary = [&](int index){
		m_primaryState = index;
		if(m_primaryState == m_primaryCleanState)
			emit primaryDirtyStateChanged(false);
		else
			emit primaryDirtyStateChanged(true);
		emit primaryChanged();
	};
```

#### RANGE FOR STATEMENT 


```{c}
for(const QItemSelectionRange &r : is)
		selection->push_back(std::pair<int, int>(r.top(), r.bottom()));
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString &arg: args) {
		const QMimeType mime = QMimeDatabase().mimeTypeForFile(arg);
		if(mimeIsSubtitle(mime)) {
			// try to open primary subtitle if not already opened
			if(fileSub.isEmpty()) {
				fileSub = arg;
				continue;
			}
			// try to open translation if not already opened
			if(fileTrans.isEmpty()) {
				fileTrans = arg;
				continue;
			}
		} else if(mimeIsMedia(mime)) {
			// try to open video if not already opened
			if(fileVideo.isEmpty()) {
				fileVideo = arg;
				continue;
			}
		}
	}
```

#### AUTO 


```{c}
auto appAction = [&](const char *actionName, bool checkable=false, bool checked=false) -> QAction * {
		static const Application *app = Application::instance();
		QAction *action = app->action(actionName);
		if(checkable) {
			checkableActions.append(action);
			action->setCheckable(true);
			action->setChecked(checked);
		}
		return action;
	};
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool checked){
		QFont font = ui->lineEdit->font();
		font.setBold(checked);
		ui->lineEdit->setFont(font);
	}
```

#### LAMBDA EXPRESSION 


```{c}
[this](int val){
		QSignalBlocker b(kcfg_MinDurationPerCharacter);
		kcfg_MinDurationPerCharacter->setValue(1000 / val);
		alt_IdealDurationPerCharacter->setMaximum(val);
		kcfg_IdealDurationPerCharacter->setMinimum(1000 / val);
	}
```

#### CONST EXPRESSION 


```{c}
static constexpr int MaxMseconds = 86399999;
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString &fmt : formats) {
			const InputFormat *format = FormatManager::instance().input(fmt);
			QString extensions;
			for(const QString &ext : format->extensions())
				extensions += QStringLiteral(" *.") % ext % QStringLiteral(" *.") % ext.toUpper();
			allSupported += extensions;
			QString name = format->name();
			name.replace(QChar('/'), QStringLiteral("\\/"));
			filter += QChar('\n') % extensions.midRef(1) % QChar('|') % name;
		}
```

#### AUTO 


```{c}
auto updateZoomDataRange = [&](const quint32 iMin, const quint32 iMax){
		Q_ASSERT(iMax <= (m_waveformZoomedSize - 1) * m_samplesPerPixel);

		qint32 xMax = -65535, xSum = 0;

		for(quint32 ch = 0; ch < m_waveformChannels; ch++) {
			for(quint32 i = iMin; i < iMax; i++) {
				qint32 val = qAbs(qint32(m_waveform[ch][i]) - SAMPLE_MIN - (SAMPLE_MAX - SAMPLE_MIN) / 2);
				if(xMax < val)
					xMax = val;
				xSum += val;

				if(i % m_samplesPerPixel == m_samplesPerPixel - 1) {
					const int zi = i / m_samplesPerPixel;
					m_waveformZoomed[ch][zi].min = xSum / m_samplesPerPixel;
					m_waveformZoomed[ch][zi].max = xMax;

					xMax = -65535;
					xSum = 0;
				}
			}
		}
	};
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &){
		VideoPlayer::instance()->setVolume(VideoPlayer::instance()->volume());
	}
```

#### LAMBDA EXPRESSION 


```{c}
[&](int x, int y){
		if(piece->top > y)
			piece->top = y;
		if(piece->bottom < y)
			piece->bottom = y;

		if(piece->left > x)
			piece->left = x;
		if(piece->right < x)
			piece->right = x;

		piece->pixels.append(QPoint(x, y));
		pieceBitmap.setPixel(x, y, bgColor);

		if(x < width - 1 && qGray(pieceBitmap.pixel(x + 1, y)) > 127)
			cutPiece(x + 1, y);
		if(x > 0 && qGray(pieceBitmap.pixel(x - 1, y)) > 127)
			cutPiece(x - 1, y);
		if(y < height - 1 && qGray(pieceBitmap.pixel(x, y + 1)) > 127)
			cutPiece(x, y + 1);
		if(y > 0 && qGray(pieceBitmap.pixel(x, y - 1)) > 127)
			cutPiece(x, y - 1);
	}
```

#### LAMBDA EXPRESSION 


```{c}
[line](){
		if(line->subtitle()) emit line->subtitle()->linePrimaryTextChanged(line);
	}
```

#### LAMBDA EXPRESSION 


```{c}
[teAction1, teAction2, appAction](){
		teAction1->setShortcut(appAction->shortcut());
		teAction2->setShortcut(appAction->shortcut());
	}
```

#### LAMBDA EXPRESSION 


```{c}
[&](SString &text){
		int len = text.length();
		int i = len / 2;
		int j = i + len % 2;
		for(; ; i--, j++) {
			if(text[i] == QChar::Space) {
				text[i] = QChar::LineFeed;
				break;
			}
			Q_ASSERT(j <= len);
			if(text[j] == QChar::Space) {
				text[j] = QChar::LineFeed;
				break;
			}
			if(i == 0) {
				text.append(QChar::LineFeed);
				break;
			}
		}
	}
```

#### LAMBDA EXPRESSION 


```{c}
[this](){
		m_videoWidget->setVideoResolution(m_player->videoWidth(), m_player->videoHeight(), m_player->videoSAR());
		m_videoWidget->videoLayer()->show();
	}
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString &word : auxText.split(sep)) {
			if(!word.isEmpty())
				auxWordsList << (word.at(0).toUpper() + word.mid(1));
			else
				auxWordsList << QString();
		}
```

#### LAMBDA EXPRESSION 


```{c}
[&](){ removeScript(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](){
		emit fileOpened(m_filePath);
		m_fps = m_player->videoFPS();
		m_minPositionDelta = m_fps > 0. ? 1. / m_fps : .02;
		emit fpsChanged(m_fps);
	}
```

#### LAMBDA EXPRESSION 


```{c}
[this](){ createScript(); }
```

#### LAMBDA EXPRESSION 


```{c}
[&](){
		// when the player backend is initialized the video widget is created in front
		// of the text overlay, so we have to raise it to make it visible again
		m_textOverlay->raise();
	}
```

#### LAMBDA EXPRESSION 


```{c}
[&](int index){
		m_primaryState = index;
		if(m_primaryState == m_primaryCleanState)
			emit primaryDirtyStateChanged(false);
		else
			emit primaryDirtyStateChanged(true);
		emit primaryChanged();
	}
```

#### LAMBDA EXPRESSION 


```{c}
[this](){ m_control->clear(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](){ m_control->copy(); }
```

#### LAMBDA EXPRESSION 


```{c}
[line](){
		if(line->subtitle()) emit line->subtitle()->lineSecondaryTextChanged(line);
	}
```

#### LAMBDA EXPRESSION 


```{c}
[&](bool){
			emit triggered(KCharsets::charsets()->codecForName(SCConfig::defaultSubtitlesEncoding()));
		}
```

#### LAMBDA EXPRESSION 


```{c}
[this](double volume){
		if(m_volume != (volume = volume * 100. / VOLUME_MULTIPLIER)) {
			m_volume = volume;
			if(!m_muted) emit volumeChanged(m_volume);
		}
	}
```

#### AUTO 


```{c}
auto piece = m_pieceCurrent;
```

#### LAMBDA EXPRESSION 


```{c}
[this](){
		if(subtitle()) emit subtitle()->lineSecondaryTextChanged(this);
	}
```

#### AUTO 


```{c}
auto changeList = reinterpret_cast<const QVector<EditChange> *>(data);
```

#### AUTO 


```{c}
auto ctfit = _ctfi.constFind(frame->color_trc);
```

#### AUTO 


```{c}
auto it = categoryMenus.cbegin();
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QStringList &streams){
		if(m_activeAudioStream >= 0)
			m_player->activeAudioStream(m_activeAudioStream);
		emit audioStreamsChanged(m_audioStreams = streams);
		emit activeAudioStreamChanged(m_activeAudioStream = m_player->activeAudioStream());
	}
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
		onWaveformResize(m_waveformGraphics->span());
	}
```

#### LAMBDA EXPRESSION 


```{c}
[&](){
		Q_ASSERT(m_state == VideoPlayer::Uninitialized);
		m_videoWidget = nullptr;
		cleanup();
	}
```

#### AUTO 


```{c}
auto updateSecondary = [&](const int index){
		m_secondaryState = index;
		if(m_secondaryState == m_secondaryCleanState)
			emit secondaryDirtyStateChanged(false);
		else
			emit secondaryDirtyStateChanged(true);
		emit secondaryChanged();
	};
```

#### AUTO 


```{c}
auto itChar = Frame::spaceStats.begin();
```

#### LAMBDA EXPRESSION 


```{c}
[this](){ m_control->toggleBold(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](SubtitleLine *l){ onHighlightLine(l); }
```

#### AUTO 


```{c}
auto updateZoomDataRange = [&](const quint32 iMin, const quint32 iMax){
		Q_ASSERT(iMax <= (m_waveformZoomedSize - 1) * m_samplesPerPixel);

		qint32 xMin = 65535, xMax = -65535;

		for(quint32 ch = 0; ch < m_waveformChannels; ch++) {
			for(quint32 i = iMin; i < iMax; i++) {
				qint32 val = (qint32)m_waveform[ch][i] + SIGNED_PAD;
				if(xMin > val)
					xMin = val;
				if(xMax < val)
					xMax = val;

				if(i % m_samplesPerPixel == m_samplesPerPixel - 1) {
					const int zi = i / m_samplesPerPixel;
					m_waveformZoomed[ch][zi].min = xMin;
					m_waveformZoomed[ch][zi].max = xMax;

					xMin = 65535;
					xMax = -65535;
				}
			}
		}
	};
```

#### AUTO 


```{c}
auto i = pixels.begin();
```

#### LAMBDA EXPRESSION 


```{c}
[this](double dur){
		if(m_duration != dur) emit durationChanged(m_duration = dur);
	}
```

#### LAMBDA EXPRESSION 


```{c}
[this](){ editScript(); }
```

#### RANGE FOR STATEMENT 


```{c}
for(SubtitleLine *nl: newLines) {
			++duri;
			const Time st = pl->hideTime() + 1.;
			nl->setTimes(st, qMax(st, pl->hideTime() + lineDur * *duri / totalDuration));
			insertLine(nl, pl->index() + 1);
			pl = nl;
		}
```

#### AUTO 


```{c}
auto sm = qobject_cast<LinesSelectionModel *>(selectionModel());
```

#### AUTO 


```{c}
auto it = changeList->crbegin();
```

#### AUTO 


```{c}
auto *fullScreenWidget = new QWidget();
```

#### AUTO 


```{c}
auto it = m_selection.cbegin();
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool checked){
		QFont font = ui->lineEdit->font();
		font.setUnderline(checked);
		ui->lineEdit->setFont(font);
	}
```

#### LAMBDA EXPRESSION 


```{c}
CONNECT_SUB(PlayerWidget, m_playerWidget)
```

#### LAMBDA EXPRESSION 


```{c}
[&](){
				int startIndex = -1, endIndex = -1;
				const Time startTime = rightMouseSoonerTime();
				const Time endTime = rightMouseLaterTime();
				for(int idx = 0, n = m_subtitle->count(); idx < n; idx++) {
					const SubtitleLine *sub = m_subtitle->at(idx);
					if(sub->showTime() <= endTime && startTime <= sub->hideTime()) {
						if(startIndex == -1 || startIndex > idx)
							startIndex = idx;
						if(endIndex == -1 || endIndex < idx)
							endIndex = idx;
					}
				}
				if(endIndex >= 0 && startIndex != endIndex)
					m_subtitle->joinLines(RangeList(Range(startIndex, endIndex)));
			}
```

#### LAMBDA EXPRESSION 


```{c}
[&](){
			int startIndex = -1, endIndex = -1;
			const Time startTime = rightMouseSoonerTime();
			const Time endTime = rightMouseLaterTime();
			for(int idx = 0, n = m_subtitle->count(); idx < n; idx++) {
				const SubtitleLine *sub = m_subtitle->at(idx);
				if(sub->showTime() <= endTime && startTime <= sub->hideTime()) {
					if(startIndex == -1 || startIndex > idx)
						startIndex = idx;
					if(endIndex == -1 || endIndex < idx)
						endIndex = idx;
				}
			}
			if(endIndex >= 0 && startIndex != endIndex)
				m_subtitle->joinLines(RangeList(Range(startIndex, endIndex)));
		}
```

#### LAMBDA EXPRESSION 


```{c}
[this](){
		if(subtitle()) emit subtitle()->linePrimaryTextChanged(this);
	}
```

#### LAMBDA EXPRESSION 


```{c}
[this](){ openSubtitleTr(); }
```

#### LAMBDA EXPRESSION 


```{c}
CONNECT_SUB(SpeechProcessor, m_speechProcessor)
```

#### RANGE FOR STATEMENT 


```{c}
for(const QStringList &encodingsForScript: encodings) {
		KSelectAction *group = new KSelectAction(encodingsForScript.at(0), this);
		for(int i = 1; i < encodingsForScript.size(); ++i)
			group->addAction(encodingsForScript.at(i).toUpper())->setCheckable(m_mode == Open);
		connect(group, QOverload<QAction *>::of(&KSelectAction::triggered), this, [=](QAction *a){
			emit triggered(KCharsets::charsets()->codecForName(a->text()));
		});
		group->setCheckable(m_mode == Open);
		addAction(group);
	}
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QUrl &url){ openSubtitleTr(url); }
```

#### AUTO 


```{c}
auto updatePrimary = [&](const int index){
		m_primaryState = index;
		if(m_primaryState == m_primaryCleanState)
			emit primaryDirtyStateChanged(false);
		else
			emit primaryDirtyStateChanged(true);
		emit primaryChanged();
	};
```

#### RANGE FOR STATEMENT 


```{c}
for(const QChar sep : QStringLiteral(" -_([:,;./\\\t\n\"")) {
		QStringList auxWordsList;
		for(const QString &word : auxText.split(sep)) {
			if(!word.isEmpty())
				auxWordsList << (word.at(0).toUpper() + word.mid(1));
			else
				auxWordsList << QString();
		}
		auxText = auxWordsList.join(sep);
	}
```

#### RANGE FOR STATEMENT 


```{c}
for(QString row: getHelpResponse()) {
			int pos = row.indexOf(QChar(' '));
			if(pos == -1)
				continue;
			const QString name = row.left(pos);
			if(bad.contains(name))
				continue;
			row.insert(pos, "\t-");
			kcfg_audioOutput->addItem(row, name);
			if(MPVConfig::audioOutput() == name)
				kcfg_audioOutput->setCurrentIndex(kcfg_audioOutput->count() - 1);
		}
```

#### LAMBDA EXPRESSION 


```{c}
CONNECT_SUB(MainWindow, m_mainWindow)
```

#### LAMBDA EXPRESSION 


```{c}
[this](double pos){
		if(m_position != (pos = qBound(0., pos, m_duration)))
			emit positionChanged(m_position = pos);
	}
```

#### LAMBDA EXPRESSION 


```{c}
CONNECT_SUB(UserActionManager, UserActionManager::instance())
```

#### LAMBDA EXPRESSION 


```{c}
[&](){ saveSubtitleTrAs(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](){
		m_renderer->reset();
		emit fileOpened(m_filePath);
		m_fps = m_player->videoFPS();
		emit fpsChanged(m_fps);
		m_videoWidget->videoLayer()->show();
	}
```

#### RANGE FOR STATEMENT 


```{c}
for(QString &enc: encList) {
			if(first)
				first = false;
			else
				enc = enc.toUpper();
		}
```

#### LAMBDA EXPRESSION 


```{c}
[=](QAction *a){
			emit triggered(KCharsets::charsets()->codecForName(a->text()));
		}
```

#### RANGE FOR STATEMENT 


```{c}
for(const std::pair<int, int> r : selection)
		itemSel.push_back(QItemSelectionRange(lm->index(r.first), lm->index(r.second, lastCol)));
```

#### RANGE FOR STATEMENT 


```{c}
for(const QItemSelectionRange &r : selection) {
		if(row == -1 || r.top() < row)
			row = r.top();
	}
```

#### LAMBDA EXPRESSION 


```{c}
[&](const quint32 iMin, const quint32 iMax){
		Q_ASSERT(iMax <= (m_waveformZoomedSize - 1) * m_samplesPerPixel);

		qint32 xMax = -65535, xSum = 0;

		for(quint32 ch = 0; ch < m_waveformChannels; ch++) {
			for(quint32 i = iMin; i < iMax; i++) {
				qint32 val = qAbs(qint32(m_waveform[ch][i]) - SAMPLE_MIN - (SAMPLE_MAX - SAMPLE_MIN) / 2);
				if(xMax < val)
					xMax = val;
				xSum += val;

				if(i % m_samplesPerPixel == m_samplesPerPixel - 1) {
					const int zi = i / m_samplesPerPixel;
					m_waveformZoomed[ch][zi].min = xSum / m_samplesPerPixel;
					m_waveformZoomed[ch][zi].max = xMax;

					xMax = -65535;
					xSum = 0;
				}
			}
		}
	}
```

#### LAMBDA EXPRESSION 


```{c}
[&](){ reloadScripts(); }
```

#### LAMBDA EXPRESSION 


```{c}
[&](){
				const Time timeShow = rightMouseSoonerTime();
				const Time timeHide = rightMouseLaterTime();

				int insertIndex = 0;
				for(int i = 0, n = m_subtitle->count(); i < n; i++) {
					const SubtitleLine *sub = m_subtitle->at(i);
					insertIndex++;

					if(sub->showTime() > timeShow) {
						insertIndex = i;
						break;
					}
				}

				SubtitleLine *newLine = new SubtitleLine(SString(), timeShow,
					timeHide.toMillis() - timeShow.toMillis() > SCConfig::minDuration() ? timeHide : timeShow + SCConfig::minDuration());
				m_subtitle->insertLine(newLine, insertIndex);
				app->linesWidget()->setCurrentLine(newLine, true);
			}
```

#### RANGE FOR STATEMENT 


```{c}
for(auto obj: subListeners) {
		connect(this, SIGNAL(subtitleOpened(Subtitle *)), obj, SLOT(setSubtitle(Subtitle *)));
		connect(this, SIGNAL(subtitleClosed()), obj, SLOT(setSubtitle()));
	}
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString backendName : VideoPlayer::instance()->backendNames()) {
		if(QWidget *configWidget = VideoPlayer::instance()->backend(backendName)->newConfigWidget(nullptr)) {
			item = addPage(configWidget, backendName);
			item->setHeader(i18nc("@title Video player backend settings", "%1 backend settings", backendName));
			item->setIcon(QIcon::fromTheme(backendName.toLower()));
		}
	}
```

#### AUTO 


```{c}
auto appAction = [&](const char *actionName, bool checkable=false, bool checked=false) -> QAction * {
		QAction *action = app()->action(actionName);
		if(checkable) {
			checkableActions.append(action);
			action->setCheckable(true);
			action->setChecked(checked);
		}
		return action;
	};
```

#### LAMBDA EXPRESSION 


```{c}
[this](){
		if(subtitle()) emit subtitle()->lineShowTimeChanged(this);
	}
```

#### LAMBDA EXPRESSION 


```{c}
[&](const quint32 iMin, const quint32 iMax){
		Q_ASSERT(iMax <= (m_waveformZoomedSize - 1) * m_samplesPerPixel);

		qint32 xMin = 65535, xMax = -65535;

		for(quint32 ch = 0; ch < m_waveformChannels; ch++) {
			for(quint32 i = iMin; i < iMax; i++) {
				qint32 val = (qint32)m_waveform[ch][i] + SIGNED_PAD;
				if(xMin > val)
					xMin = val;
				if(xMax < val)
					xMax = val;

				if(i % m_samplesPerPixel == m_samplesPerPixel - 1) {
					const int zi = i / m_samplesPerPixel;
					m_waveformZoomed[ch][zi].min = xMin;
					m_waveformZoomed[ch][zi].max = xMax;

					xMin = 65535;
					xMax = -65535;
				}
			}
		}
	}
```

#### LAMBDA EXPRESSION 


```{c}
[=](){
		btnBold->setChecked(textEdit->fontBold());
		btnItalic->setChecked(textEdit->fontItalic());
		btnUnderline->setChecked(textEdit->fontUnderline());
		btnStrike->setChecked(textEdit->fontStrikeOut());
	}
```

#### AUTO 


```{c}
auto splitOnSpace = [&](SString &text){
		int len = text.length();
		int i = len / 2;
		int j = i + len % 2;
		for(; ; i--, j++) {
			if(text[i] == QChar::Space) {
				text[i] = QChar::LineFeed;
				break;
			}
			Q_ASSERT(j <= len);
			if(text[j] == QChar::Space) {
				text[j] = QChar::LineFeed;
				break;
			}
			if(i == 0) {
				text.append(QChar::LineFeed);
				break;
			}
		}
	};
```

#### LAMBDA EXPRESSION 


```{c}
[act, appAction](){ act->setShortcut(appAction->shortcut()); }
```

#### LAMBDA EXPRESSION 


```{c}
[&](){
				selectedLine->setShowTime(m_timeRMBRelease, true);
			}
```

#### LAMBDA EXPRESSION 


```{c}
[this](){ m_control->paste(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](){
		toolButton(this, ACT_STOP)->setDefaultAction(app()->action(ACT_STOP));
		toolButton(this, ACT_PLAY_PAUSE)->setDefaultAction(app()->action(ACT_PLAY_PAUSE));
		toolButton(this, ACT_SEEK_BACKWARD)->setDefaultAction(app()->action(ACT_SEEK_BACKWARD));
		toolButton(this, ACT_SEEK_FORWARD)->setDefaultAction(app()->action(ACT_SEEK_FORWARD));
		toolButton(this, ACT_SEEK_TO_PREVIOUS_LINE)->setDefaultAction(app()->action(ACT_SEEK_TO_PREVIOUS_LINE));
		toolButton(this, ACT_SEEK_TO_NEXT_LINE)->setDefaultAction(app()->action(ACT_SEEK_TO_NEXT_LINE));
		toolButton(this, ACT_SET_CURRENT_LINE_SHOW_TIME)->setDefaultAction(app()->action(ACT_SET_CURRENT_LINE_SHOW_TIME));
		toolButton(this, ACT_SET_CURRENT_LINE_HIDE_TIME)->setDefaultAction(app()->action(ACT_SET_CURRENT_LINE_HIDE_TIME));
		toolButton(this, ACT_CURRENT_LINE_FOLLOWS_VIDEO)->setDefaultAction(app()->action(ACT_CURRENT_LINE_FOLLOWS_VIDEO));
		toolButton(this, ACT_TOGGLE_MUTED)->setDefaultAction(app()->action(ACT_TOGGLE_MUTED));
		toolButton(this, ACT_TOGGLE_FULL_SCREEN)->setDefaultAction(app()->action(ACT_TOGGLE_FULL_SCREEN));
		toolButton(this, ACT_PLAY_RATE_DECREASE)->setDefaultAction(app()->action(ACT_PLAY_RATE_DECREASE));
		toolButton(this, ACT_PLAY_RATE_INCREASE)->setDefaultAction(app()->action(ACT_PLAY_RATE_INCREASE));

		toolButton(m_fullScreenControls, ACT_STOP)->setDefaultAction(app()->action(ACT_STOP));
		toolButton(m_fullScreenControls, ACT_PLAY_PAUSE)->setDefaultAction(app()->action(ACT_PLAY_PAUSE));
		toolButton(m_fullScreenControls, ACT_SEEK_BACKWARD)->setDefaultAction(app()->action(ACT_SEEK_BACKWARD));
		toolButton(m_fullScreenControls, ACT_SEEK_FORWARD)->setDefaultAction(app()->action(ACT_SEEK_FORWARD));
		toolButton(m_fullScreenControls, ACT_SEEK_TO_PREVIOUS_LINE)->setDefaultAction(app()->action(ACT_SEEK_TO_PREVIOUS_LINE));
		toolButton(m_fullScreenControls, ACT_SEEK_TO_NEXT_LINE)->setDefaultAction(app()->action(ACT_SEEK_TO_NEXT_LINE));
		toolButton(m_fullScreenControls, ACT_TOGGLE_MUTED)->setDefaultAction(app()->action(ACT_TOGGLE_MUTED));
		toolButton(m_fullScreenControls, ACT_TOGGLE_FULL_SCREEN)->setDefaultAction(app()->action(ACT_TOGGLE_FULL_SCREEN));
		toolButton(m_fullScreenControls, ACT_PLAY_RATE_DECREASE)->setDefaultAction(app()->action(ACT_PLAY_RATE_DECREASE));
		toolButton(m_fullScreenControls, ACT_PLAY_RATE_INCREASE)->setDefaultAction(app()->action(ACT_PLAY_RATE_INCREASE));
	}
```

#### LAMBDA EXPRESSION 


```{c}
CONNECT_SUB(Finder, m_finder)
```

#### LAMBDA EXPRESSION 


```{c}
[this](QAction *action){ speechImportAudioStream(action->data().value<int>()); }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString &fmt : formats) {
			const InputFormat *format = FormatManager::instance().input(fmt);
			QString extensions;
			for(const QString &ext : format->extensions())
				extensions += $(" *.") % ext;
			const QString formatLine = format->dialogFilter() % QChar::LineFeed;
			filterOpen += formatLine;
			if(format->isBinary()) {
				imageExtensions += extensions;
			} else {
				textExtensions += extensions;
				filterSave += formatLine;
			}
		}
```

#### LAMBDA EXPRESSION 


```{c}
[&](){
				selectedLine->setHideTime(m_timeRMBRelease, true);
			}
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString &message){ KMessageBox::sorry(m_mainWindow, message); }
```

#### LAMBDA EXPRESSION 


```{c}
[](void *ctx){
		QMetaObject::invokeMethod(
					reinterpret_cast<MPVBackend *>(ctx),
					"processEvents", Qt::QueuedConnection);
	}
```

#### LAMBDA EXPRESSION 


```{c}
[this](){ saveSubtitle(KCharsets::charsets()->codecForName(m_subtitleEncoding)); }
```

#### AUTO 


```{c}
auto it = plugins.cbegin();
```

#### LAMBDA EXPRESSION 


```{c}
[&](){
		close();
		m_renderer = nullptr;
	}
```

#### RANGE FOR STATEMENT 


```{c}
for(const QFileInfo &file: files) {
		if(file.isDir()) {
			if(file.fileName().at(0) != '.')
				findAllFiles(file.absoluteFilePath(), fileList);
		} else {
			fileList.append(file.absoluteFilePath());
		}
	}
```

#### LAMBDA EXPRESSION 


```{c}
[&](bool){ if(m_subtitle) m_subtitle->updateState(); }
```

#### RANGE FOR STATEMENT 


```{c}
for(const REStringCapture &backRef: qAsConst(backRefs)) {
			// part of the replacement string before the backreference
			if(!repFrags.at(repFrag)->isEmpty())
				cl.push_back(EditChange(ReplaceFragment, matchStart, 0, repFrags.at(repFrag)));
			repFrag++;

			// backreference inside the replacement string
			if((len = match.capturedLength(backRef.no))) {
				REBackrefFragment *brF = &backRefFrags[backRef.no - 1];
				const int pos = match.capturedStart(backRef.no);
				if(brF->frag.isNull() || pos != brF->pos || len != brF->len) {
					cursor.movePosition(QTextCursor::Start);
					cursor.movePosition(QTextCursor::Right, QTextCursor::MoveAnchor, pos);
					cursor.movePosition(QTextCursor::Right, QTextCursor::KeepAnchor, len);
					brF->frag.reset(new QTextDocumentFragment(cursor));
				}
				cl.push_back(EditChange(ReplaceFragment, matchStart, 0, brF->frag));
			}
		}
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString &ext : m_extensions)
			extensions += QStringLiteral(" *.") % ext;
```

#### LAMBDA EXPRESSION 


```{c}
[this](int val){
		QSignalBlocker b(kcfg_MaxDurationPerCharacter);
		kcfg_MaxDurationPerCharacter->setValue(1000 / val);
		alt_IdealDurationPerCharacter->setMinimum(val);
		kcfg_IdealDurationPerCharacter->setMaximum(1000 / val);
	}
```

#### LAMBDA EXPRESSION 


```{c}
[&](int index){
		m_secondaryState = index;
		if(m_secondaryState == m_secondaryCleanState)
			emit secondaryDirtyStateChanged(false);
		else
			emit secondaryDirtyStateChanged(true);
		emit secondaryChanged();
	}
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString &ext : format->extensions())
				extensions += $(" *.") % ext;
```

#### LAMBDA EXPRESSION 


```{c}
[&](){ m_mainWindow = nullptr; }
```

#### LAMBDA EXPRESSION 


```{c}
[this](){
		if(subtitle()) emit subtitle()->lineHideTimeChanged(this);
	}
```

#### LAMBDA EXPRESSION 


```{c}
[this](){ openVideo(); }
```

#### LAMBDA EXPRESSION 


```{c}
[w](){ if(!w->isEditing()) w->editCurrentLineInPlace(); }
```

#### LAMBDA EXPRESSION 


```{c}
[&](){
				app->linesWidget()->setCurrentLine(currentLine, true);
			}
```

#### LAMBDA EXPRESSION 


```{c}
CONNECT_SUB(Replacer, m_replacer)
```

#### AUTO 


```{c}
auto updateSecondary = [&](int index){
		m_secondaryState = index;
		if(m_secondaryState == m_secondaryCleanState)
			emit secondaryDirtyStateChanged(false);
		else
			emit secondaryDirtyStateChanged(true);
		emit secondaryChanged();
	};
```

#### LAMBDA EXPRESSION 


```{c}
[&](){
			int startIndex = -1, endIndex = -1;
			const Time startTime = rightMouseSoonerTime();
			const Time endTime = rightMouseLaterTime();
			foreach(SubtitleLine *sub, m_subtitle->allLines()) {
				if(sub->showTime() <= endTime && startTime <= sub->hideTime()) {
					if(startIndex == -1 || startIndex > sub->index())
						startIndex = sub->index();
					if(endIndex == -1 || endIndex < sub->index())
						endIndex = sub->index();
				}
			}
			if(endIndex >= 0 && startIndex != endIndex)
				m_subtitle->joinLines(RangeList(Range(startIndex, endIndex)));
		}
```

#### LAMBDA EXPRESSION 


```{c}
[this](int code, const QString &message) { onStreamError(code, message, QString()); }
```

#### LAMBDA EXPRESSION 


```{c}
[&](){ saveSubtitleAs(); }
```

#### LAMBDA EXPRESSION 


```{c}
[&](){ runScript(); }
```

#### RANGE FOR STATEMENT 


```{c}
for(QString row : getHelpResponse()) {
			int pos = row.indexOf(QChar(' '));
			if(pos == -1)
				continue;
			const QString name = row.left(pos);
			const QString lastName = kcfg_hwDecode->itemData(kcfg_hwDecode->count() - 1).toString();
			if(lastName == name || bad.contains(name))
				continue;
			kcfg_hwDecode->addItem(name, name);
			if(MPVConfig::hwDecode() == name)
				kcfg_hwDecode->setCurrentIndex(kcfg_hwDecode->count() - 1);
		}
```

#### LAMBDA EXPRESSION 


```{c}
[&](){
		const SCScript *s = currentScript();
		const bool isScriptSelected = s && s->isScript();
		const bool isFileWritable = s && QFileInfo(s->path()).isWritable();
		btnRemove->setEnabled(isFileWritable);
		if(isFileWritable) {
			btnEdit->setText(i18n("Edit"));
			btnEdit->setIcon(QIcon::fromTheme($("document-edit")));
		} else {
			btnEdit->setText(i18n("View"));
			btnEdit->setIcon(QIcon::fromTheme($("document-open")));
		}
		btnEdit->setEnabled(isScriptSelected);
		btnRun->setEnabled(isScriptSelected);
	}
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString backendName : VideoPlayer::instance()->backendNames()) {
		if(QWidget *configWidget = VideoPlayer::instance()->backend(backendName)->newConfigWidget(nullptr)) {
			item = addPage(configWidget, backendName);
			item->setHeader(i18nc("@title Video player backend settings", "%1 backend settings", backendName));
			item->setIcon(QIcon(QStringLiteral(CUSTOM_ICON_INSTALL_PATH) + backendName.toLower() + QStringLiteral("-logo")));
		}
	}
```

#### LAMBDA EXPRESSION 


```{c}
[this](){ m_control->toggleItalic(); }
```

#### LAMBDA EXPRESSION 


```{c}
[&](){
				const Time timeShow = rightMouseSoonerTime();
				const Time timeHide = rightMouseLaterTime();

				int insertIndex = 0;
				foreach(SubtitleLine *sub, m_subtitle->allLines()) {
					if(sub->showTime() <= timeShow)
						insertIndex++;

					if(sub->showTime() > timeShow) {
						insertIndex = sub->index();
						break;
					}
				}

				SubtitleLine *newLine = new SubtitleLine(SString(), timeShow,
					timeHide.toMillis() - timeShow.toMillis() > SCConfig::minDuration() ? timeHide : timeShow + SCConfig::minDuration());
				m_subtitle->insertLine(newLine, insertIndex);
				app->linesWidget()->setCurrentLine(newLine, true);
			}
```

#### LAMBDA EXPRESSION 


```{c}
[&](){
				m_subtitle->removeLines(RangeList(Range(currentLine->index())), Both);
				if(selectedLine != currentLine)
					app->linesWidget()->setCurrentLine(selectedLine, true);
			}
```

#### AUTO 


```{c}
auto *fullScreenWidget = new QWidget;
```

#### RANGE FOR STATEMENT 


```{c}
for(QString row : getHelpResponse()) {
			int pos = row.indexOf(QChar(' '));
			if(pos == -1)
				continue;
			const QString name = row.left(pos);
			const QString lastName = kcfg_mpvHwDecode->itemData(kcfg_mpvHwDecode->count() - 1).toString();
			if(lastName == name || bad.contains(name))
				continue;
			if(SCConfig::mpvHwDecode() == name)
				kcfg_mpvHwDecode->setCurrentIndex(kcfg_mpvHwDecode->count());
			kcfg_mpvHwDecode->addItem(name, name);
		}
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QStringList &streams){
		emit textStreamsChanged(m_textStreams = streams);
	}
```

#### RANGE FOR STATEMENT 


```{c}
for(QString row: getHelpResponse()) {
			int pos = row.indexOf(QChar(' '));
			if(pos == -1)
				continue;
			const QString name = row.left(pos);
			if(bad.contains(name))
				continue;
			row.insert(pos, "\t-");
			if(MPVConfig::audioOutput() == name)
				kcfg_audioOutput->setCurrentIndex(kcfg_audioOutput->count());
			kcfg_audioOutput->addItem(row, name);
		}
```

#### AUTO 


```{c}
auto *fullScreenLayout = new QHBoxLayout();
```

#### CONST EXPRESSION 


```{c}
static constexpr double MaxSeconds = MaxMseconds / 1000.0;
```

#### LAMBDA EXPRESSION 


```{c}
CONNECT_SUB(WaveformWidget, m_mainWindow->m_waveformWidget)
```

#### LAMBDA EXPRESSION 


```{c}
[&](){
		saveSubtitle(KCharsets::charsets()->codecForName(m_subtitleEncoding));
	}
```

#### LAMBDA EXPRESSION 


```{c}
[&](){ editScript(); }
```

#### LAMBDA EXPRESSION 


```{c}
[&](bool){
			emit triggered(nullptr);
		}
```

#### LAMBDA EXPRESSION 


```{c}
CONNECT_SUB(ErrorTracker, m_errorTracker)
```

#### LAMBDA EXPRESSION 


```{c}
[line](){
		if(line->subtitle()) emit line->subtitle()->lineHideTimeChanged(line);
	}
```

#### LAMBDA EXPRESSION 


```{c}
[&](){
				selectedLine->setHideTime(m_timeRMBRelease);
			}
```

#### LAMBDA EXPRESSION 


```{c}
[this](FFPlayer::State ffs){
		static const QMap<FFPlayer::State, State> stateMap
			{{ FFPlayer::Stopped, Stopped }, { FFPlayer::Playing, Playing }, { FFPlayer::Paused, Paused }};
		const State state = stateMap[ffs];
		if(m_state != state) switch(m_state = state) {
		case Stopped: emit stopped(); break;
		case Playing: emit playing(); break;
		case Paused: emit paused(); break;
		default: break; // not possible
		}
	}
```

#### LAMBDA EXPRESSION 


```{c}
[&](){
				const Time timeShow = rightMouseSoonerTime();
				const Time timeHide = rightMouseLaterTime();
				SubtitleLine *newLine = new SubtitleLine(timeShow,
					timeHide.toMillis() - timeShow.toMillis() > SCConfig::minDuration() ? timeHide : timeShow + SCConfig::minDuration());
				m_subtitle->insertLine(newLine);
				app->linesWidget()->setCurrentLine(newLine, true);
			}
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString &text){ static QAction *a = action(ACT_REDO); a->setToolTip(text); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QUrl &url){ openVideo(url); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QStringList &streams){
		emit audioStreamsChanged(m_audioStreams = streams);
		emit activeAudioStreamChanged(m_activeAudioStream = m_player->activeAudioStream());
	}
```

#### AUTO 


```{c}
auto ehint = LinesItemDelegate::ExtendedEditHint(hint);
```

#### LAMBDA EXPRESSION 


```{c}
[](){ if(Subtitle *s = app()->subtitle()) s->updateState(); }
```

#### LAMBDA EXPRESSION 


```{c}
[&](){ m_subtitle->toggleLineAnchor(currentLine); }
```

#### LAMBDA EXPRESSION 


```{c}
[&](){
		saveSubtitleTr(KCharsets::charsets()->codecForName(m_subtitleTrEncoding));
	}
```

#### LAMBDA EXPRESSION 


```{c}
[&](){
				const Time timeShow = rightMouseSoonerTime();
				const Time timeHide = rightMouseLaterTime();

				int insertIndex = 0;
				for(int i = 0, n = m_subtitle->count(); i < n; i++) {
					const SubtitleLine *sub = m_subtitle->at(i);
					insertIndex++;

					if(sub->showTime() > timeShow) {
						insertIndex = i;
						break;
					}
				}

				SubtitleLine *newLine = new SubtitleLine(timeShow,
					timeHide.toMillis() - timeShow.toMillis() > SCConfig::minDuration() ? timeHide : timeShow + SCConfig::minDuration());
				m_subtitle->insertLine(newLine, insertIndex);
				app->linesWidget()->setCurrentLine(newLine, true);
			}
```

#### LAMBDA EXPRESSION 


```{c}
[&](){
				const Time timeShow = rightMouseSoonerTime();
				const Time timeHide = rightMouseLaterTime();

				int insertIndex = 0;
				foreach(SubtitleLine *sub, m_subtitle->allLines()) {
					if(sub->showTime() > timeShow) {
						insertIndex = sub->index();
						if(sub->showTime() <= timeShow)
							insertIndex++;
						break;
					}
				}

				SubtitleLine *newLine = new SubtitleLine(SString(), timeShow,
					timeHide.toMillis() - timeShow.toMillis() > SCConfig::minDuration() ? timeHide : timeShow + SCConfig::minDuration());
				m_subtitle->insertLine(newLine, insertIndex);
				app->linesWidget()->setCurrentLine(newLine, true);
			}
```

#### RANGE FOR STATEMENT 


```{c}
for(const QItemSelectionRange &r : selection) {
		ranges << Range(r.top(), r.bottom());
	}
```

#### RANGE FOR STATEMENT 


```{c}
for(QString row : getHelpResponse()) {
			int pos = row.indexOf(QChar(' '));
			if(pos == -1)
				continue;
			const QString name = row.left(pos);
			const QString lastName = kcfg_hwDecode->itemData(kcfg_hwDecode->count() - 1).toString();
			if(lastName == name || bad.contains(name))
				continue;
			if(MPVConfig::hwDecode() == name)
				kcfg_hwDecode->setCurrentIndex(kcfg_hwDecode->count());
			kcfg_hwDecode->addItem(name, name);
		}
```

#### AUTO 


```{c}
auto it = m_visibleLines.begin();
```

#### RANGE FOR STATEMENT 


```{c}
for(QString row : getHelpResponse()) {
			int pos = row.indexOf(QChar(' '));
			if(pos == -1)
				continue;
			const QString name = row.left(pos);
			if(bad.contains(name))
				continue;
			row.insert(pos, "\t-");
			if(MPVConfig::videoOutput() == name)
				kcfg_videoOutput->setCurrentIndex(kcfg_hwDecode->count());
			kcfg_videoOutput->addItem(row, name);
		}
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool checked){
		QFont font = ui->lineEdit->font();
		font.setItalic(checked);
		ui->lineEdit->setFont(font);
	}
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString &text){ static QAction *a = action(ACT_UNDO); a->setToolTip(text); }
```

#### RANGE FOR STATEMENT 


```{c}
for(int n: lines) {
		SubtitleLine *l = new SubtitleLine(n * 1000, n * 1000 + 500);
		l->primaryDoc()->setPlainText(QString::number(n));
		sub.insertLine(l);
	}
```

#### LAMBDA EXPRESSION 


```{c}
[line](){
		if(line->subtitle()) emit line->subtitle()->lineShowTimeChanged(line);
	}
```

#### LAMBDA EXPRESSION 


```{c}
[this](){
		emit fileOpened(m_filePath);
		m_fps = m_player->videoFPS();
		emit fpsChanged(m_fps);
		m_videoWidget->videoLayer()->show();
	}
```

#### LAMBDA EXPRESSION 


```{c}
CONNECT_SUB(CurrentLineWidget, m_curLineWidget)
```

#### LAMBDA EXPRESSION 


```{c}
[this](FFPlayer::State ffs){
		if(m_state == Initialized) // video file is closed don't notify play/pause/stop
			return;
		static const QMap<FFPlayer::State, State> stateMap
			{{ FFPlayer::Stopped, Stopped }, { FFPlayer::Playing, Playing }, { FFPlayer::Paused, Paused }};
		const State state = stateMap[ffs];
		if(m_state != state) switch(m_state = state) {
		case Stopped: emit stopped(); break;
		case Playing: emit playing(); break;
		case Paused: emit paused(); break;
		default: break; // not possible
		}
	}
```

#### AUTO 


```{c}
auto itWord = Frame::spaceStats.end() - 1;
```

#### LAMBDA EXPRESSION 


```{c}
[&](){
				const Time timeShow = rightMouseSoonerTime();
				const Time timeHide = rightMouseLaterTime();

				int insertIndex = m_subtitle->indexForTime(timeShow);

				SubtitleLine *newLine = new SubtitleLine(SString(), timeShow,
					timeHide.toMillis() - timeShow.toMillis() > SCConfig::minDuration() ? timeHide : timeShow + SCConfig::minDuration());
				m_subtitle->insertLine(newLine, insertIndex);
				app->linesWidget()->setCurrentLine(newLine, true);
			}
```

#### LAMBDA EXPRESSION 


```{c}
CONNECT_SUB(LinesWidget, m_linesWidget)
```

#### LAMBDA EXPRESSION 


```{c}
[this](){ m_control->toggleStrikeOut(); }
```

#### AUTO 


```{c}
const auto encodings = KCharsets::charsets()->encodingsByScript();
```

#### RANGE FOR STATEMENT 


```{c}
for(const std::pair<int, int> &r : selection)
		itemSel.push_back(QItemSelectionRange(lm->index(r.first), lm->index(r.second, lastCol)));
```

#### LAMBDA EXPRESSION 


```{c}
CONNECT_SUB(Speller, m_speller)
```

#### LAMBDA EXPRESSION 


```{c}
[this](){ m_player->decreaseVolume(); }
```

#### LAMBDA EXPRESSION 


```{c}
[&](){
				// TODO: split the line at exact waveform mouse position
				m_subtitle->splitLines(RangeList(Range(currentLine->index())));
			}
```

#### LAMBDA EXPRESSION 


```{c}
[&](const char *actionName, bool checkable=false, bool checked=false) -> QAction * {
		QAction *action = app()->action(actionName);
		if(checkable) {
			checkableActions.append(action);
			action->setCheckable(true);
			action->setChecked(checked);
		}
		return action;
	}
```

#### LAMBDA EXPRESSION 


```{c}
[&](){ createScript(); }
```

#### LAMBDA EXPRESSION 


```{c}
CONNECT_SUB(ErrorFinder, m_errorFinder)
```

#### LAMBDA EXPRESSION 


```{c}
[&, model](const QItemSelection &sel, const QItemSelection &){
		const bool hasSelection = !sel.isEmpty() && !sel.first().isEmpty();
		ui->buttonBox->button(QDialogButtonBox::Ok)->setEnabled(hasSelection);

		if(hasSelection) {
			const QModelIndex first = sel.first().indexes().first();
			m_selectedEncoding = model->encoding(first);
			QTextCodec *codec = KCharsets::charsets()->codecForName(m_selectedEncoding);
			QTextStream textStream(m_text);
			textStream.setCodec(codec);
			const int val = ui->preview->verticalScrollBar()->value();
			ui->preview->setPlainText(textStream.readAll());
			ui->preview->verticalScrollBar()->setValue(val);
		} else {
			ui->preview->clear();
			m_selectedEncoding.clear();
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for(QString row : getHelpResponse()) {
			int pos = row.indexOf(QChar(' '));
			if(pos == -1)
				continue;
			const QString name = row.left(pos);
			if(bad.contains(name))
				continue;
			row.insert(pos, "\t-");
			if(SCConfig::mpvVideoOutput() == name)
				kcfg_mpvVideoOutput->setCurrentIndex(kcfg_mpvHwDecode->count());
			kcfg_mpvVideoOutput->addItem(row, name);
		}
```

#### LAMBDA EXPRESSION 


```{c}
[this](QRect r){ r.setBottom(rect().bottom()); update(r); }
```

#### AUTO 


```{c}
auto i = m_recognizedPieces.cbegin();
```

#### AUTO 


```{c}
auto obj
```

#### LAMBDA EXPRESSION 


```{c}
CONNECT_SUB(ScriptsManager, m_scriptsManager)
```

#### AUTO 


```{c}
auto it = Frame::spaceStats.end() - 1;
```

#### RANGE FOR STATEMENT 


```{c}
for(const REStringCapture &backRef: qAsConst(backRefs)) {
			// part of the replacement string before the backreference
			if(!repFrags.at(repFrag)->isEmpty())
				cl.push_back(EditChange(ReplaceFragment, matchStart, 0, repFrags.at(repFrag)));
			repFrag++;

			// backreference inside the replacement string
			if((len = match.capturedLength(backRef.no))) {
				REBackrefFragment *brF = &backRefFrags[backRef.no - 1];
				const int pos = match.capturedStart(backRef.no);
				if(brF->frag.isNull() || pos != brF->pos || len != brF->len) {
					readCur.movePosition(QTextCursor::Start);
					readCur.movePosition(QTextCursor::Right, QTextCursor::MoveAnchor, pos);
					readCur.movePosition(QTextCursor::Right, QTextCursor::KeepAnchor, len);
					brF->frag.reset(new QTextDocumentFragment(readCur));
				}
				cl.push_back(EditChange(ReplaceFragment, matchStart, 0, brF->frag));
			}
		}
```

#### RANGE FOR STATEMENT 


```{c}
for(const QAction *act: m_actions) {
			if(act->shortcuts().contains(key)) {
				e->accept();
				return true;
			}
		}
```

#### AUTO 


```{c}
auto duri = dur.begin();
```

#### LAMBDA EXPRESSION 


```{c}
[](const PiecePtr &a, const PiecePtr &b)->bool{
		return *a < *b;
	}
```

#### LAMBDA EXPRESSION 


```{c}
[this](double pos){
		if(m_position != (pos = qBound(0., pos, m_duration))
		&& (m_position <= 0. || m_minPositionDelta <= 0. || qAbs(m_position - pos) >= m_minPositionDelta))
			emit positionChanged(m_position = pos);
	}
```

#### LAMBDA EXPRESSION 


```{c}
[&](){
				selectedLine->setShowTime(m_timeRMBRelease);
			}
```

#### RANGE FOR STATEMENT 


```{c}
for(const QStringList &encodingsForScript: encodings) {
		KSelectAction *group = new KSelectAction(encodingsForScript.at(0), this);
		for(int i = 1; i < encodingsForScript.size(); ++i)
			group->addAction(encodingsForScript.at(i))->setCheckable(m_mode == Open);
		connect(group, QOverload<QAction *>::of(&KSelectAction::triggered), this, [=](QAction *a){
			emit triggered(KCharsets::charsets()->codecForName(a->text()));
		});
		group->setCheckable(m_mode == Open);
		addAction(group);
	}
```

#### LAMBDA EXPRESSION 


```{c}
[](void *ctx)->int {
		VideoState *is = (VideoState *)ctx;
		return is->abortRequested;
	}
```

#### LAMBDA EXPRESSION 


```{c}
[&](int x, int y){
		if(piece->top > y)
			piece->top = y;
		if(piece->bottom < y)
			piece->bottom = y;

		if(piece->left > x)
			piece->left = x;
		if(piece->right < x)
			piece->right = x;

		piece->pixels.append(QPoint(x, y));
		pieceBitmap.setPixel(x, y, bgColor);

		if(x < width - 1 && qGray(pieceBitmap.pixel(x + 1, y)) > colorOffset)
			cutPiece(x + 1, y);
		if(x > 0 && qGray(pieceBitmap.pixel(x - 1, y)) > colorOffset)
			cutPiece(x - 1, y);
		if(y < height - 1 && qGray(pieceBitmap.pixel(x, y + 1)) > colorOffset)
			cutPiece(x, y + 1);
		if(y > 0 && qGray(pieceBitmap.pixel(x, y - 1)) > colorOffset)
			cutPiece(x, y - 1);
	}
```

#### LAMBDA EXPRESSION 


```{c}
[this](){ runScript(); }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString &lib: libs) {
				if(QLibrary::isLibrary(lib))
					pluginLoad(path.filePath(lib));
			}
```

#### RANGE FOR STATEMENT 


```{c}
for(QString row : getHelpResponse()) {
			int pos = row.indexOf(QChar(' '));
			if(pos == -1)
				continue;
			const QString name = row.left(pos);
			if(bad.contains(name))
				continue;
			row.insert(pos, "\t-");
			if(SCConfig::mpvAudioOutput() == name)
				kcfg_mpvAudioOutput->setCurrentIndex(kcfg_mpvHwDecode->count());
			kcfg_mpvAudioOutput->addItem(row, name);
		}
```

#### RANGE FOR STATEMENT 


```{c}
for(QAction *act: m_actions) {
		if(act->shortcuts().contains(key)) {
			act->trigger();
			m_control->updateDisplayText();
			return;
		}
	}
```

#### LAMBDA EXPRESSION 


```{c}
[this](int val){
		QSignalBlocker b(alt_MaxDurationPerCharacter);
		alt_MaxDurationPerCharacter->setValue(1000 / val);
		kcfg_IdealDurationPerCharacter->setMaximum(val);
		alt_IdealDurationPerCharacter->setMinimum(1000 / val);
	}
```

#### LAMBDA EXPRESSION 


```{c}
[&](const int index){
		m_primaryState = index;
		if(m_primaryState == m_primaryCleanState)
			emit primaryDirtyStateChanged(false);
		else
			emit primaryDirtyStateChanged(true);
		emit primaryChanged();
	}
```

#### LAMBDA EXPRESSION 


```{c}
[&](){
				int startIndex = -1, endIndex = -1;
				const Time startTime = rightMouseSoonerTime();
				const Time endTime = rightMouseLaterTime();
				for(int idx = 0, n = m_subtitle->count(); idx < n; idx++) {
					const SubtitleLine *sub = m_subtitle->at(idx);
					if(sub->intersectsTimespan(startTime, endTime)) {
						if(startIndex == -1 || startIndex > idx)
							startIndex = idx;
						if(endIndex == -1 || endIndex < idx)
							endIndex = idx;
					}
				}
				if(endIndex >= 0 && startIndex != endIndex)
					m_subtitle->joinLines(RangeList(Range(startIndex, endIndex)));
			}
```

#### RANGE FOR STATEMENT 


```{c}
for(const SStringCapture &backRef: qAsConst(backReferences)) {
			// part of 'replacement' before the backreference
			len = backRef.pos - lastEnd;
			Q_ASSERT(len >= 0);
			chunks << lastEnd << len;
			newLength += len;

			// add the 'copy' string that backreference points to
			len = match.capturedLength(backRef.no);
			Q_ASSERT(len >= 0);
			chunks << match.capturedStart(backRef.no) << len;
			newLength += len;

			lastEnd = backRef.pos + backRef.len;
		}
```

#### LAMBDA EXPRESSION 


```{c}
[this](){ m_control->toggleUnderline(); }
```

#### CONST EXPRESSION 


```{c}
static constexpr double MaxMseconds = 86399999.0;
```

#### LAMBDA EXPRESSION 


```{c}
[&](){
				const Time timeShow = rightMouseSoonerTime();
				const Time timeHide = rightMouseLaterTime();

				int insertIndex = 0;
				foreach(SubtitleLine *sub, m_subtitle->allLines()) {
					insertIndex++;

					if(sub->showTime() > timeShow) {
						insertIndex = sub->index();
						break;
					}
				}

				SubtitleLine *newLine = new SubtitleLine(SString(), timeShow,
					timeHide.toMillis() - timeShow.toMillis() > SCConfig::minDuration() ? timeHide : timeShow + SCConfig::minDuration());
				m_subtitle->insertLine(newLine, insertIndex);
				app->linesWidget()->setCurrentLine(newLine, true);
			}
```

#### LAMBDA EXPRESSION 


```{c}
[this](){ removeScript(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QAction *action){ demuxTextStream(action->data().value<int>()); }
```

#### LAMBDA EXPRESSION 


```{c}
[](void *ctx){
		QMetaObject::invokeMethod(
					reinterpret_cast<MPVBackend *>(ctx),
					&MPVBackend::processEvents, Qt::QueuedConnection);
	}
```

#### LAMBDA EXPRESSION 


```{c}
[this](double speed){
		if(m_playSpeed != speed) emit playSpeedChanged(m_playSpeed = speed);
	}
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString &m: mimeList) {
		if(mime.inherits(m))
			return true;
	}
```

#### LAMBDA EXPRESSION 


```{c}
[&](){ m_nativeWindow = nullptr; }
```

