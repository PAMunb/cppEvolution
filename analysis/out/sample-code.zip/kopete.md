#### RANGE FOR STATEMENT 


```{c}
for(const QString &str : list)
    {
        QVERIFY(expected.overlayIcons().contains(str));
    }
```

