#### AUTO 


```{c}
auto monitor = new Monitor;
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *widget : widgetList) {
        auto w = qobject_cast<MailWidget *>(widget);
        w->updateAddRemoveButton(addButtonEnabled);
    }
```

#### AUTO 


```{c}
auto button = new QPushButton(QStringLiteral("Show Selection"));
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *widget : widgetList) {
        auto w = qobject_cast<WebWidget *>(widget);
        KContacts::ResourceLocatorUrl newUrl = w->url();
        if (newUrl.isValid()) {
            resourceLocatorList << newUrl;
        }
    }
```

#### AUTO 


```{c}
auto *protocolCombo = w.findChild<QComboBox *>(QStringLiteral("protocol"));
```

#### AUTO 


```{c}
auto *lineEdit = qobject_cast<QLineEdit *>(editor);
```

#### AUTO 


```{c}
auto *job = new KIO::CommandLauncherJob(command);
```

#### AUTO 


```{c}
auto addbuttonaddress = w.findChild<QPushButton *>(QStringLiteral("addbuttonaddress"));
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *widget : widgetList) {
        auto w = qobject_cast<PhoneWidget *>(widget);
        w->updateAddRemoveButton(addButtonEnabled);
    }
```

#### AUTO 


```{c}
auto *logoLayout = new QVBoxLayout;
```

#### AUTO 


```{c}
auto interface = new QDBusInterface(service, path, QString(), QDBusConnection::sessionBus());
```

#### AUTO 


```{c}
auto rightLayout = new QVBoxLayout;
```

#### AUTO 


```{c}
auto generalLayout = new QGridLayout;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &custom : customs) {
        QString app;
        QString name;
        QString value;
        ContactEditor::Utils::splitCustomField(custom, app, name, value);

        // skip all well-known fields that have separated editor widgets
        if (custom.startsWith(QLatin1String("messaging/"))) { // IM addresses
            continue;
        }

        if (app == QLatin1String("KADDRESSBOOK")) {
            static QSet<QString> blacklist;
            if (blacklist.isEmpty()) {
                blacklist << QStringLiteral("BlogFeed") << QStringLiteral("X-IMAddress") << QStringLiteral("X-Profession") << QStringLiteral("X-Office")
                          << QStringLiteral("X-ManagersName") << QStringLiteral("X-AssistantsName") << QStringLiteral("X-Anniversary")
                          << QStringLiteral("X-SpousesName") << QStringLiteral("MailPreferedFormatting") << QStringLiteral("MailAllowToRemoteContent")
                          << QStringLiteral("CRYPTOPROTOPREF") << QStringLiteral("OPENPGPFP") << QStringLiteral("SMIMEFP") << QStringLiteral("CRYPTOSIGNPREF")
                          << QStringLiteral("CRYPTOENCRYPTPREF");
            }
            QSet<QString> upperCaseBlacklist;
            for (const QString &blacklistEntry : std::as_const(blacklist)) {
                upperCaseBlacklist << blacklistEntry.toUpper();
            }
            blacklist.unite(upperCaseBlacklist);
            if (blacklist.contains(name)) { // several KAddressBook specific fields
                continue;
            }
        }

        // check whether it correspond to a local custom field
        bool isLocalCustomField = false;
        const int localCustomFieldsCount(mLocalCustomFields.count());
        for (int i = 0; i < localCustomFieldsCount; ++i) {
            if (mLocalCustomFields[i].key() == name) {
                mLocalCustomFields[i].setValue(value);
                isLocalCustomField = true;
                break;
            }
        }

        // check whether it correspond to a global custom field
        bool isGlobalCustomField = false;
        const int globalCustomFieldsCount(globalCustomFields.count());
        for (int i = 0; i < globalCustomFieldsCount; ++i) {
            if (globalCustomFields[i].key() == name) {
                globalCustomFields[i].setValue(value);
                isGlobalCustomField = true;
                break;
            }
        }

        // if not local and not global it must be external
        if (!isLocalCustomField && !isGlobalCustomField) {
            if (app == QLatin1String("KADDRESSBOOK")) {
                // however if it starts with our prefix it might be that this is an outdated
                // global custom field, in this case treat it as local field of type text
                CustomField customField(name, name, CustomField::TextType, CustomField::LocalScope);
                customField.setValue(value);

                mLocalCustomFields << customField;
            } else {
                // it is really an external custom field
                const QString key = app + QLatin1Char('-') + name;
                CustomField customField(key, key, CustomField::TextType, CustomField::ExternalScope);
                customField.setValue(value);

                externalCustomFields << customField;
            }
        }
    }
```

#### AUTO 


```{c}
auto mButtonBoxHBoxLayout = new QHBoxLayout(d->mButtonBox);
```

#### RANGE FOR STATEMENT 


```{c}
for (ContactEditor::ContactEditorPagePlugin *plugin : qAsConst(d->mCustomPages)) {
            plugin->setReadOnly(readOnly);
        }
```

#### AUTO 


```{c}
auto label = new QLabel(i18n("Web"), this);
```

#### AUTO 


```{c}
auto *job = new KIO::CommandLauncherJob(commandTemplate);
```

#### AUTO 


```{c}
auto proxyModel = new GroupFilterModel(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KContacts::Address &address : rawContact.addresses()) {
        QString formattedAddress;

        if (address.label().isEmpty()) {
            formattedAddress = address.formattedAddress().trimmed().toHtmlEscaped();
        } else {
            formattedAddress = address.label().toHtmlEscaped();
        }

        formattedAddress = formattedAddress.replace(QRegExp(QStringLiteral("\n+")), QStringLiteral("<br>"));

        const QString url = QStringLiteral("<a href=\"address:?index=%1\" title=\"%2\"><img src=\"map_icon\" alt=\"%2\"/></a>")
                            .arg(counter)
                            .arg(i18nc("@info:tooltip", "Show address on map"));
        counter++;

        dynamicPart += rowFmtStr2
                       .arg(KContacts::Address::typeLabel(address.type()))
                       .arg(formattedAddress)
                       .arg(url);
    }
```

#### AUTO 


```{c}
auto *job = new ContactGroupExpandJob(group);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &email : rawContact.emails()) {
        const QString type = i18nc("a contact's email address", "Email");

        const QString fullEmail = QString::fromLatin1(QUrl::toPercentEncoding(rawContact.fullEmail(email)));

        dynamicPart += rowFmtStr1.arg(type).arg(QStringLiteral("<a href=\"mailto:%1\">%2</a>").arg(fullEmail, email));
    }
```

#### AUTO 


```{c}
auto *blogFeedLabel = editor.findChild<QLabel *>(QStringLiteral("blogFeedLabel"));
```

#### AUTO 


```{c}
auto postofficeboxlabel = w.findChild<QLabel *>(QStringLiteral("postofficeboxlabel"));
```

#### AUTO 


```{c}
auto *layout = new QVBoxLayout(mainWidget);
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *widget : std::as_const(d->mWidgetList)) {
        clearWidget(widget);
    }
```

#### AUTO 


```{c}
auto *comboBox = new KComboBox(parent);
```

#### AUTO 


```{c}
auto *completer = new QCompleter(filter, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &category : categories) {
        if (category.startsWith(QLatin1String("akonadi:"))) {
            tags.append(Akonadi::Tag::fromUrl(QUrl(category)));
        } else {
            Akonadi::Tag missingTag = Akonadi::Tag(category);
            auto createJob = new Akonadi::TagCreateJob(missingTag, this);
            createJob->setMergeIfExisting(true);
            connect(createJob, &Akonadi::TagCreateJob::result, this, &CategoriesEditWidget::onMissingTagCreated);
        }
    }
```

#### AUTO 


```{c}
auto *typeAddress = w.findChild<SelectAddressTypeComboBox *>(QStringLiteral("typeaddress"));
```

#### AUTO 


```{c}
auto *mAllowRemoteContent = w.findChild<QCheckBox *>(QStringLiteral("mAllowRemoteContent"));
```

#### AUTO 


```{c}
auto *postalcodelineedit = w.findChild<KLineEdit *>(QStringLiteral("postalcodelineedit"));
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) {
        d->_k_expandResult(job);
    }
```

#### AUTO 


```{c}
const auto leftContactGroup = leftItem.payload<KContacts::ContactGroup>();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { slotNextMonth(); }
```

#### AUTO 


```{c}
auto *addfield = w.findChild<QPushButton *>(QStringLiteral("addfield"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const KContacts::Addressee &contact : std::as_const(mCurrentContacts)) {
            group.append(KContacts::ContactGroup::Data(contact.realName(), contact.preferredEmail()));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVariantMap &map : additionalFields()) {
        strGroup.append(QStringLiteral("<tr><td colspan=\"2\">&nbsp;</td></tr><tr><td align=\"right\" width=\"30%\"><b><font color=\"grey\">%1</font></b></td>"
                                       "<td valign=\"bottom\" align=\"left\" width=\"50%\"><font>%2</font></td></tr>")
                        .arg(map.value(QStringLiteral("title")).toString())
                        .arg(map.value(QStringLiteral("value")).toString()));
    }
```

#### AUTO 


```{c}
auto widget = qobject_cast<QDateEdit *>(editor);
```

#### AUTO 


```{c}
auto editor = new QSpinBox(parent);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            slotCancelClicked();
        }
```

#### AUTO 


```{c}
auto *editor = new QTimeEdit(parent);
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *widget : widgetList) {
        auto *w = qobject_cast<WebWidget *>(widget);
        KContacts::ResourceLocatorUrl newUrl = w->url();
        if (newUrl.isValid()) {
            resourceLocatorList << newUrl;
        }
    }
```

#### AUTO 


```{c}
auto label = new QLabel(i18n("Custom Field Title"), this);
```

#### LAMBDA EXPRESSION 


```{c}
[&imageData](KIO::Job *, const QByteArray &data) {
                            imageData.append(data);
                         }
```

#### AUTO 


```{c}
auto *modifyButtonWidgetLayout = new QHBoxLayout(modifyButtonWidget);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { adaptHeaderSizes(); }
```

#### AUTO 


```{c}
auto *edit = new KLineEdit(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *widget : widgetList) {
        WebWidget *w = qobject_cast<WebWidget *>(widget);
        KContacts::ResourceLocatorUrl newUrl = w->url();
        if (newUrl.isValid()) {
            resourceLocatorList << newUrl;
        }
    }
```

#### AUTO 


```{c}
auto job = new Akonadi::ItemFetchJob(item);
```

#### AUTO 


```{c}
auto *remove = w.findChild<QToolButton *>(QStringLiteral("removebutton"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::EmailAddressSelection &selection : selectedAddresses) {
        addressList << selection.quotedEmail();
    }
```

#### AUTO 


```{c}
auto *attribute = contact.attribute<ContactMetaDataAttribute>(Item::AddIfMissing);
```

#### AUTO 


```{c}
auto regionlabel = w.findChild<QLabel *>(QStringLiteral("regionlabel"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item &item : lstItems) {
        if (item.hasPayload<KContacts::Addressee>()) {
            contacts.append(item.payload<KContacts::Addressee>());
        }
    }
```

#### AUTO 


```{c}
auto mainLayout = new QGridLayout(this);
```

#### AUTO 


```{c}
auto nickNameLabel = editor.findChild<QLabel *>(QStringLiteral("nicknamelabel"));
```

#### RANGE FOR STATEMENT 


```{c}
for (ContactEditor::ContactEditorPagePlugin *plugin : std::as_const(mCustomPages)) {
        mTabWidget->addTab(plugin, plugin->title());
    }
```

#### AUTO 


```{c}
auto layout = new QVBoxLayout(mainWidget);
```

#### AUTO 


```{c}
const auto parentCollection = index.data(EntityTreeModel::ParentCollectionRole).value<Collection>();
```

#### AUTO 


```{c}
const auto customs = rawContact.customs();
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *widget : widgetList) {
        MessagingWidget *w = qobject_cast<MessagingWidget *>(widget);
        w->setReadOnly(readOnly);
    }
```

#### AUTO 


```{c}
auto buttonBox = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel, q);
```

#### RANGE FOR STATEMENT 


```{c}
for (const CustomField &newCustomField : qAsConst(customFields)) {
                if (newCustomField.scope() != CustomField::ExternalScope) {
                    if (newCustomField.key() == oldCustomField.key()) {
                        fieldStillExists = true;
                        break;
                    }
                }
            }
```

#### AUTO 


```{c}
auto *layout = new QHBoxLayout(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *widget : widgetList) {
        auto *w = qobject_cast<MailWidget *>(widget);
        KContacts::Email newEmail = w->email();
        if (newEmail.isValid()) {
            emailList << newEmail;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &category : categories) {
        tags.append(Akonadi::Tag::fromUrl(QUrl(category)));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob*job) { d->_k_expandResult(job);}
```

#### AUTO 


```{c}
auto *line = w.findChild<QLineEdit *>(QStringLiteral("phonenumber"));
```

#### AUTO 


```{c}
auto countrycombobox = w.findChild<KComboBox *>(QStringLiteral("countrycombobox"));
```

#### AUTO 


```{c}
const auto collectionMimeTypesSet  = collection.contentMimeTypes();
```

#### AUTO 


```{c}
auto box = new QGroupBox(i18nc("street/postal", "Address Types"), page);
```

#### AUTO 


```{c}
auto *button = new QPushButton(this);
```

#### AUTO 


```{c}
auto attribute = contact.attribute<ContactMetaDataAttribute>(Item::AddIfMissing);
```

#### AUTO 


```{c}
auto *editor = new QDateTimeEdit(parent);
```

#### AUTO 


```{c}
auto modifyButtonWidget = new QWidget(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *widget : widgetList) {
        auto *w = qobject_cast<WebWidget *>(widget);
        w->setReadOnly(readOnly);
    }
```

#### AUTO 


```{c}
auto mainLayout = new QVBoxLayout(q);
```

#### AUTO 


```{c}
auto blogFeedLabel = editor.findChild<QLabel *>(QStringLiteral("blogFeedLabel"));
```

#### AUTO 


```{c}
auto *delegate = new DisplayNameDelegate(mView->view(), this);
```

#### AUTO 


```{c}
auto rightJob = new Akonadi::ContactGroupExpandJob(rightContactGroup);
```

#### AUTO 


```{c}
auto label = new QLabel(i18n("Please insert SMS text for an SMS to the following number: %1", mNumber), this);
```

#### LAMBDA EXPRESSION 


```{c}
[this, idx]() {
            const auto result = KMessageBox::questionYesNo(this, i18n("Do you really want to delete this address?"));
            if (result == KMessageBox::Yes) {
                mAddressModel->removeAddress(idx.row());
            }
        }
```

#### AUTO 


```{c}
auto *regionlineedit = w.findChild<KLineEdit *>(QStringLiteral("regionlineedit"));
```

#### AUTO 


```{c}
auto edit = new ContactLineEdit(isReference, ContactCompletionModel::NameAndEmailColumn, parent);
```

#### AUTO 


```{c}
auto *line = w.findChild<KLineEdit *>(QStringLiteral("messaginglineedit"));
```

#### AUTO 


```{c}
auto cb = new QCheckBox(KContacts::PhoneNumber::typeLabel(*it), this);
```

#### AUTO 


```{c}
auto wIt = widgetList.constBegin();
```

#### AUTO 


```{c}
auto *w = qobject_cast<PhoneWidget *>(*wIt);
```

#### AUTO 


```{c}
auto layout = new QVBoxLayout(mParent);
```

#### AUTO 


```{c}
auto customFieldEditorWidget = w.findChild<ContactEditor::CustomFieldEditorWidget *>(QStringLiteral("customfieldeditorwidget"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &custom : customs) {

        QString app, name, value;
        Akonadi::Utils::splitCustomField(custom, app, name, value);

        // skip all well-known fields that have separated editor widgets
        if (custom.startsWith(QStringLiteral("messaging/"))) {       // IM addresses
            continue;
        }

        if (app == QLatin1String("KADDRESSBOOK")) {
            static QSet<QString> blacklist;
            if (blacklist.isEmpty()) {
                blacklist << QStringLiteral("BlogFeed")
                          << QStringLiteral("X-IMAddress")
                          << QStringLiteral("X-Profession")
                          << QStringLiteral("X-Office")
                          << QStringLiteral("X-ManagersName")
                          << QStringLiteral("X-AssistantsName")
                          << QStringLiteral("X-Anniversary")
                          << QStringLiteral("X-SpousesName")
                          << QStringLiteral("MailPreferedFormatting")
                          << QStringLiteral("MailAllowToRemoteContent")
                          << QStringLiteral("CRYPTOPROTOPREF")
                          << QStringLiteral("OPENPGPFP")
                          << QStringLiteral("SMIMEFP")
                          << QStringLiteral("CRYPTOSIGNPREF")
                          << QStringLiteral("CRYPTOENCRYPTPREF");
            }
            QSet<QString> upperCaseBlacklist;
            for (const QString &blacklistEntry : qAsConst(blacklist)) {
                upperCaseBlacklist << blacklistEntry.toUpper();
            }
            blacklist.unite(upperCaseBlacklist);
            if (blacklist.contains(name)) {     // several KAddressBook specific fields
                continue;
            }
        }

        // check whether it correspond to a local custom field
        bool isLocalCustomField = false;
        const int localCustomFieldsCount(mLocalCustomFields.count());
        for (int i = 0; i < localCustomFieldsCount; ++i) {
            if (mLocalCustomFields[i].key() == name) {
                mLocalCustomFields[i].setValue(value);
                isLocalCustomField = true;
                break;
            }
        }

        // check whether it correspond to a global custom field
        bool isGlobalCustomField = false;
        const int globalCustomFieldsCount(globalCustomFields.count());
        for (int i = 0; i < globalCustomFieldsCount; ++i) {
            if (globalCustomFields[i].key() == name) {
                globalCustomFields[i].setValue(value);
                isGlobalCustomField = true;
                break;
            }
        }

        // if not local and not global it must be external
        if (!isLocalCustomField && !isGlobalCustomField) {
            if (app == QLatin1String("KADDRESSBOOK")) {
                // however if it starts with our prefix it might be that this is an outdated
                // global custom field, in this case treat it as local field of type text
                CustomField customField(name, name, CustomField::TextType, CustomField::LocalScope);
                customField.setValue(value);

                mLocalCustomFields << customField;
            } else {
                // it is really an external custom field
                const QString key = app + QLatin1Char('-') + name;
                CustomField customField(key, key, CustomField::TextType, CustomField::ExternalScope);
                customField.setValue(value);

                externalCustomFields << customField;
            }
        }
    }
```

#### AUTO 


```{c}
auto *layout = new QGridLayout(this);
```

#### AUTO 


```{c}
auto *monitor = new Monitor;
```

#### AUTO 


```{c}
auto *e = static_cast<QKeyEvent *>(event);
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *widget : widgetList) {
        auto *w = qobject_cast<PhoneWidget *>(widget);
        KContacts::PhoneNumber number = w->storePhone();
        if (!number.isEmpty()) {
            phoneNumbers << number;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&imageData](KIO::Job *, const QByteArray &data) {
            imageData.append(data);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Akonadi::Item &item, const QSet<QByteArray> &set) {
        itemChanged(item, set);
    }
```

#### AUTO 


```{c}
auto attribute2 = static_cast<Akonadi::ContactMetaDataAttribute *>(attribute1.clone());
```

#### AUTO 


```{c}
auto mainWidget = new QWidget(q);
```

#### RANGE FOR STATEMENT 


```{c}
for (const IMAddress &address : qAsConst(imaddresses)) {
        protocolMap[address.protocol()].append(address.name());
    }
```

#### AUTO 


```{c}
auto w = qobject_cast<WebWidget *>(widget);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &protocol : lstProtocols) {
        protocolMap.insert(protocol, QStringList());
    }
```

#### AUTO 


```{c}
auto wEnd = widgetList.constEnd();
```

#### AUTO 


```{c}
auto logoLayout = new QVBoxLayout;
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            d->adaptHeaderSizes();
        }
```

#### AUTO 


```{c}
auto *w = new WebWidget(parent);
```

#### RANGE FOR STATEMENT 


```{c}
for (Akonadi::ContactEditorPagePlugin *plugin : qAsConst(d->mCustomPages)) {
            plugin->storeContact(contact);
        }
```

#### AUTO 


```{c}
auto *layout = new QVBoxLayout(mParent);
```

#### AUTO 


```{c}
auto topLayout = new QHBoxLayout(this);
```

#### AUTO 


```{c}
auto layout = new QFormLayout;
```

#### AUTO 


```{c}
auto *job = new Akonadi::ItemCreateJob(item, d->mDefaultCollection);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QUrl &url) {
        d->slotUrlClicked(url);
    }
```

#### AUTO 


```{c}
auto postalcodelineedit = w.findChild<KLineEdit *>(QStringLiteral("postalcodelineedit"));
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) {
            slotSearchDone(job);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QPoint pos) {
        const auto idx = mAddressesLocationView->indexAt(pos);
        if (!idx.isValid()) {
            return;
        }
        QMenu menu;
        auto action = menu.addAction(QIcon::fromTheme(QStringLiteral("edit-delete")), i18n("Remove Address"));
        action->setEnabled(!mReadOnly);
        connect(action, &QAction::triggered, this, [this, idx]() {
            const auto result = KMessageBox::questionYesNo(this,
                                                           i18n("Do you really want to delete this address?"),
                                                           QString(),
                                                           KStandardGuiItem::del(),
                                                           KStandardGuiItem::cancel());
            if (result == KMessageBox::Yes) {
                mAddressModel->removeAddress(idx.row());
            }
        });
        menu.exec(mAddressesLocationView->viewport()->mapToGlobal(pos));
    }
```

#### AUTO 


```{c}
auto *countrylabel = w.findChild<QLabel *>(QStringLiteral("countrylabel"));
```

#### AUTO 


```{c}
auto *combotype = w.findChild<ContactEditor::PhoneComboBoxType *>(QStringLiteral("phonetype"));
```

#### AUTO 


```{c}
const auto protocols = KContacts::Impp::serviceTypes();
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) {
            parentCollectionFetchDone(job);
        }
```

#### AUTO 


```{c}
const auto additionalFieldsLst = additionalFields();
```

#### AUTO 


```{c}
const auto attribute = contact.attribute<ContactMetaDataAttribute>();
```

#### AUTO 


```{c}
auto enumValueSms = static_cast<ContactActionsSettings::EnumSendSmsAction>(ContactActionsSettings::self()->sendSmsAction());
```

#### AUTO 


```{c}
auto *mStreetEdit = w.findChild<KLineEdit *>(QStringLiteral("streetlineedit"));
```

#### AUTO 


```{c}
auto description = new QLabel(this);
```

#### AUTO 


```{c}
auto label = new QLabel(i18nc("@label The organization of a contact", "Organization:"), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KContacts::Addressee &contact : contacts) {
        contactsList.push_back(QVariant::fromValue(ContactGrantleeWrapper(contact)));
    }
```

#### AUTO 


```{c}
auto combotype = w.findChild<ContactEditor::PhoneComboBoxType *>(QStringLiteral("phonetype"));
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            slotNextMonth();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &protocol : protocols) {
        mProtocolCombo->addItem(QIcon::fromTheme(KContacts::Impp::serviceIcon(protocol)), KContacts::Impp::serviceLabel(protocol), protocol);
    }
```

#### AUTO 


```{c}
auto box = new KComboBox;
```

#### AUTO 


```{c}
auto expandJob = qobject_cast<ContactGroupExpandJob *>(job);
```

#### AUTO 


```{c}
auto e = static_cast<QKeyEvent *>(event);
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *itemModifyJob) {
                auto modifiedJob = static_cast<Akonadi::ItemModifyJob *>(itemModifyJob);
                if (!modifiedJob->error()) {
                    Q_EMIT q->contactUpdated(modifiedJob->item(), messageId, mShowAsHTML, mRemoteContent);
                }
                slotAddModifyContactDone(itemModifyJob);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const CustomField &field : customFields) {
        if (field.scope() == CustomField::LocalScope) {
            descriptions.append(field.toVariantMap());
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { slotNoDate(); }
```

#### LAMBDA EXPRESSION 


```{c}
[&imageData](KIO::Job *, const QByteArray &data) {
                imageData.append(data);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *widget : widgetList) {
        if (widget != w) {
            (static_cast<WebWidget *>(widget))->setPreferred(false);
        }
    }
```

#### AUTO 


```{c}
auto *combobox = w.findChild<QComboBox *>(QStringLiteral("fieldtype"));
```

#### AUTO 


```{c}
auto widget = new QWidget;
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Akonadi::Item &item) {
                    contactStored(item);
                }
```

#### AUTO 


```{c}
auto label = new QLabel(i18n("Name"));
```

#### RANGE FOR STATEMENT 


```{c}
for (QString custom : customs) {
            if (custom.startsWith(QLatin1String("KADDRESSBOOK-"))) {
                custom.remove(QStringLiteral("KADDRESSBOOK-X-"));
                custom.remove(QStringLiteral("KADDRESSBOOK-"));

                int pos = custom.indexOf(QLatin1Char(':'));
                QString key = custom.left(pos);
                QString value = custom.mid(pos + 1);

                // convert anniversary correctly
                if (key == QLatin1String("Anniversary") || key == QLatin1String("ANNIVERSARY")) {
                    const QDateTime dateTime = QDateTime::fromString(value, Qt::ISODate);
                    value = QLocale().toString(dateTime.date());
                } else if (key == QLatin1String("BlogFeed") || key == QLatin1String("BLOGFEED")) { // blog is handled separated
                    continue;
                } else if (blacklistedKeys.contains(key)) {
                    continue;
                }

                // check whether we have a mapping for the title
                const QMap<QString, QString>::ConstIterator keyIt = titleMap.constFind(key);
                bool needToEscape = true;
                if (keyIt != titleMap.constEnd()) {
                    key = keyIt.value();
                } else {
                    // check whether it is a custom local field
                    for (const QVariantMap &description : customFieldDescriptions()) {
                        if (description.value(QStringLiteral("key")).toString() == key) {
                            key = description.value(QStringLiteral("title")).toString();
                            const QString descriptionType = description.value(QStringLiteral("type")).toString();
                            if (descriptionType == QLatin1String("boolean")) {
                                if (value == QLatin1String("true")) {
                                    value = i18nc("Boolean value", "yes");
                                } else {
                                    value = i18nc("Boolean value", "no");
                                }
                            } else if (descriptionType == QLatin1String("date")) {
                                const QDate date = QDate::fromString(value, Qt::ISODate);
                                value = QLocale().toString(date, QLocale::ShortFormat);
                            } else if (descriptionType == QLatin1String("time")) {
                                const QTime time = QTime::fromString(value, Qt::ISODate);
                                value = QLocale().toString(time);
                            } else if (descriptionType == QLatin1String("datetime")) {
                                const QDateTime dateTime = QDateTime::fromString(value, Qt::ISODate);
                                value = QLocale().toString(dateTime, QLocale::ShortFormat);
                            } else if (descriptionType == QLatin1String("url")) {
                                value = KStringHandler::tagUrls(value.toHtmlEscaped());
                                needToEscape = false;
                            }

                            break;
                        }
                    }
                }
                if (needToEscape) {
                    value = value.toHtmlEscaped();
                }
                customData += rowFmtStr1.arg(key, value);
            }
        }
```

#### AUTO 


```{c}
const auto idx = selection.at(0).topLeft();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            d->slotCreateContactGroup();
        }
```

#### AUTO 


```{c}
const auto result = KMessageBox::questionYesNo(this, i18n("Do you really want to delete this address?"));
```

#### AUTO 


```{c}
auto createJob = new Akonadi::TagCreateJob(missingTag, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QLocale &locale : localeList) {
        const QString localeStr = QLocale::countryToString(locale.country());
        if (countries.contains(localeStr)) {
            continue;
        }
        countries.append(localeStr);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *widget : widgetList) {
        MessagingWidget *w = qobject_cast<MessagingWidget *>(widget);
        imaddresses << w->imAddress();
    }
```

#### AUTO 


```{c}
auto *edit = new ContactLineEdit(isReference, ContactCompletionModel::EmailColumn, parent);
```

#### AUTO 


```{c}
auto job = KIO::storedGet(url);
```

#### AUTO 


```{c}
auto mBlogFeed = editor.findChild<KLineEdit *>(QStringLiteral("blogfeed"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const CustomField &oldCustomField : qAsConst(mLocalCustomFields)) {
        if (oldCustomField.scope() != CustomField::ExternalScope) {
            bool fieldStillExists = false;
            for (const CustomField &newCustomField : qAsConst(customFields)) {
                if (newCustomField.scope() != CustomField::ExternalScope) {
                    if (newCustomField.key() == oldCustomField.key()) {
                        fieldStillExists = true;
                        break;
                    }
                }
            }

            if (!fieldStillExists) {
                contact.removeCustom(QStringLiteral("KADDRESSBOOK"), oldCustomField.key());
            }
        }
    }
```

#### AUTO 


```{c}
auto customFieldsListWidget = w.findChild<ContactEditor::CustomFieldsListWidget *>(QStringLiteral("customfieldslistwidget"));
```

#### AUTO 


```{c}
auto combobox = w.findChild<QComboBox *>(QStringLiteral("fieldtype"));
```

#### AUTO 


```{c}
auto line = w.findChild<QLineEdit *>(QStringLiteral("mailedit"));
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &str) { d->slotGroupNameChanged(str); }
```

#### AUTO 


```{c}
auto box = qobject_cast<QCheckBox *>(mGroup->buttons().at(i));
```

#### AUTO 


```{c}
auto copy = new ContactMetaDataAttribute;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &type : lst) {
        if (value.contains(type)) {
            mOldType = type;
            mWebType->setCurrentIndex(mWebType->findData(type));
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QString custom : customs) {
            if (custom.startsWith(QLatin1String("KADDRESSBOOK-"))) {
                custom.remove(QStringLiteral("KADDRESSBOOK-X-"));
                custom.remove(QStringLiteral("KADDRESSBOOK-"));

                int pos = custom.indexOf(QLatin1Char(':'));
                QString key = custom.left(pos);
                QString value = custom.mid(pos + 1);

                // convert anniversary correctly
                if (key == QLatin1String("Anniversary") || key == QLatin1String("ANNIVERSARY")) {
                    const QDateTime dateTime = QDateTime::fromString(value, Qt::ISODate);
                    value = QLocale().toString(dateTime.date());
                } else if (key == QLatin1String("BlogFeed") || key == QLatin1String("BLOGFEED")) {      // blog is handled separated
                    continue;
                } else if (blacklistedKeys.contains(key)) {
                    continue;
                }

                // check whether we have a mapping for the title
                const QMap<QString, QString>::ConstIterator keyIt = titleMap.constFind(key);
                bool needToEscape = true;
                if (keyIt != titleMap.constEnd()) {
                    key = keyIt.value();
                } else {
                    // check whether it is a custom local field
                    for (const QVariantMap &description : customFieldDescriptions()) {
                        if (description.value(QStringLiteral("key")).toString() == key) {
                            key = description.value(QStringLiteral("title")).toString();
                            const QString descriptionType = description.value(QStringLiteral("type")).toString();
                            if (descriptionType == QLatin1String("boolean")) {
                                if (value == QLatin1String("true")) {
                                    value = i18nc("Boolean value", "yes");
                                } else {
                                    value = i18nc("Boolean value", "no");
                                }
                            } else if (descriptionType == QLatin1String("date")) {
                                const QDate date = QDate::fromString(value, Qt::ISODate);
                                value = QLocale().toString(date, QLocale::ShortFormat);
                            } else if (descriptionType == QLatin1String("time")) {
                                const QTime time = QTime::fromString(value, Qt::ISODate);
                                value = QLocale().toString(time);
                            } else if (descriptionType == QLatin1String("datetime")) {
                                const QDateTime dateTime = QDateTime::fromString(value, Qt::ISODate);
                                value = QLocale().toString(dateTime, QLocale::ShortFormat);
                            } else if (descriptionType == QLatin1String("url")) {
                                value = KStringHandler::tagUrls(value.toHtmlEscaped());
                                needToEscape = false;
                            }

                            break;
                        }
                    }
                }
                if (needToEscape) {
                    value = value.toHtmlEscaped();
                }
                customData += rowFmtStr1.arg(key, value);
            }
        }
```

#### AUTO 


```{c}
auto *w = qobject_cast<MessagingWidget *>(widget);
```

#### AUTO 


```{c}
auto searchJob = qobject_cast<ContactGroupSearchJob *>(job);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            slotToday();
        }
```

#### AUTO 


```{c}
auto *removeButton = w.findChild<QToolButton *>(QStringLiteral("removebutton"));
```

#### AUTO 


```{c}
auto mNickName = editor.findChild<KLineEdit *>(QStringLiteral("nickname"));
```

#### AUTO 


```{c}
auto *mainLayout = new QVBoxLayout(this);
```

#### AUTO 


```{c}
auto *job = new ItemModifyJob(d->mItem);
```

#### AUTO 


```{c}
auto *w = new PhoneWidget(parent);
```

#### AUTO 


```{c}
auto cb = new QCheckBox(KContacts::Address::typeLabel(*it), box);
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *createJob) {
            auto modifiedJob = static_cast<Akonadi::ItemCreateJob *>(createJob);
            if (!modifiedJob->error()) {
                Q_EMIT q->contactUpdated(modifiedJob->item(), messageId, mShowAsHTML, mRemoteContent);
            }
            slotAddModifyContactDone(createJob);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *widget : widgetList) {
        auto *w = qobject_cast<MessagingWidget *>(widget);
        imaddresses << w->imAddress();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *widget : widgetList) {
        auto *w = qobject_cast<PhoneWidget *>(widget);
        w->updateAddRemoveButton(addButtonEnabled);
    }
```

#### AUTO 


```{c}
auto *copy = new ContactMetaDataAttribute;
```

#### AUTO 


```{c}
GRANTLEE_MAKE_GADGET(KContacts::Email)
```

#### AUTO 


```{c}
auto searchJob = new ContactGroupSearchJob(this);
```

#### AUTO 


```{c}
auto *localitylineedit = w.findChild<KLineEdit *>(QStringLiteral("localitylineedit"));
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) {
            d->searchResult(job);
        }
```

#### AUTO 


```{c}
auto job = new Akonadi::ItemCreateJob(item, mCollection);
```

#### AUTO 


```{c}
const auto contact = item.payload<KContacts::Addressee>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVariantMap &map : additionalFields()) {
        strGroup.append(QStringLiteral("<tr><td colspan=\"2\">&nbsp;</td></tr><tr><td align=\"right\" width=\"30%\"><b><font color=\"grey\">%1</font></b></td>"
                                       "<td valign=\"bottom\" align=\"left\" width=\"50%\"><font>%2</font></td></tr>")
                            .arg(map.value(QStringLiteral("title")).toString())
                            .arg(map.value(QStringLiteral("value")).toString()));
    }
```

#### AUTO 


```{c}
auto *cancelbuttonaddress = w.findChild<QPushButton *>(QStringLiteral("cancelbuttonaddress"));
```

#### AUTO 


```{c}
auto *w = qobject_cast<PhoneWidget *>(widget);
```

#### AUTO 


```{c}
auto *editor = new QDateEdit(parent);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &name : names) {
                    //TODO preferred support ?
                    imaddresses << IMAddress(protocol, name, false);
                }
```

#### AUTO 


```{c}
const auto result = KMessageBox::questionYesNo(this,
                                                       i18n("Do you really want to delete this address?"),
                                                       QString(),
                                                       KStandardGuiItem::del(),
                                                       KStandardGuiItem::cancel());
```

#### AUTO 


```{c}
auto leftLayout = new QVBoxLayout;
```

#### AUTO 


```{c}
auto categoryWidget = new QWidget(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *widget : widgetList) {
        auto w = qobject_cast<WebWidget *>(widget);
        w->setReadOnly(readOnly);
    }
```

#### AUTO 


```{c}
auto add = w.findChild<QToolButton *>(QStringLiteral("addbutton"));
```

#### AUTO 


```{c}
auto *w = qobject_cast<WebWidget *>(widget);
```

#### AUTO 


```{c}
auto etm = qobject_cast<Akonadi::EntityTreeModel *>(mModel)
```

#### AUTO 


```{c}
auto job = new ItemModifyJob(d->mItem);
```

#### AUTO 


```{c}
auto *layout = new QGridLayout(mainWidget);
```

#### AUTO 


```{c}
const auto addr = mAddresses.at(index.row());
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            adaptHeaderSizes();
        }
```

#### AUTO 


```{c}
auto *leftJob = new Akonadi::ContactGroupExpandJob(leftContactGroup);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            d->slotCreateContact();
        }
```

#### AUTO 


```{c}
auto actions = new ContactDefaultActions(this);
```

#### AUTO 


```{c}
const auto rightContact = rightItem.payload<KContacts::Addressee>();
```

#### AUTO 


```{c}
auto *w = qobject_cast<MessagingWidget *>(*wIt);
```

#### AUTO 


```{c}
auto filter = new ContactsWithEmailFilterModel(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *widget : widgetList) {
        WebWidget *w = qobject_cast<WebWidget *>(widget);
        w->setReadOnly(readOnly);
    }
```

#### AUTO 


```{c}
auto group = d->mItem.payload<KContacts::ContactGroup>();
```

#### AUTO 


```{c}
const auto selectedAddress = mAddressesWidget->selectedAddresses();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { slotNextWeek(); }
```

#### AUTO 


```{c}
auto *addbuttonaddress = w.findChild<QPushButton *>(QStringLiteral("addbuttonaddress"));
```

#### AUTO 


```{c}
auto label = new QLabel(i18n("Messaging"), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const CustomField &newCustomField : std::as_const(customFields)) {
                if (newCustomField.scope() != CustomField::ExternalScope) {
                    if (newCustomField.key() == oldCustomField.key()) {
                        fieldStillExists = true;
                        break;
                    }
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KContacts::Address &address : rawContact.addresses()) {
        QString formattedAddress;

        if (address.label().isEmpty()) {
            formattedAddress = address.formattedAddress().trimmed().toHtmlEscaped();
        } else {
            formattedAddress = address.label().toHtmlEscaped();
        }

        formattedAddress.replace(QRegExp(QStringLiteral("\n+")), QStringLiteral("<br>"));

        const QString url = QStringLiteral("<a href=\"address:?index=%1\" title=\"%2\"><img src=\"map_icon\" alt=\"%2\"/></a>")
                            .arg(counter)
                            .arg(i18nc("@info:tooltip", "Show address on map"));
        counter++;

        dynamicPart += rowFmtStr2
                       .arg(KContacts::Address::typeLabel(address.type()))
                       .arg(formattedAddress)
                       .arg(url);
    }
```

#### AUTO 


```{c}
const auto group = item.payload<KContacts::ContactGroup>();
```

#### AUTO 


```{c}
GRANTLEE_MAKE_GADGET(KContacts::Geo)
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QUrl &url) { d->slotMailClicked(url); }
```

#### AUTO 


```{c}
auto *proxyModel = new QSortFilterProxyModel(this);
```

#### AUTO 


```{c}
auto *w = qobject_cast<MailWidget *>(widget);
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) {
        d->slotParentCollectionFetched(job);
    }
```

#### AUTO 


```{c}
auto customFieldDelegate = new ContactEditor::CustomFieldsListDelegate(mCustomFieldList, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &key : keys) {
        CustomField field;
        field.setKey(key);
        field.setScope(CustomField::GlobalScope);

        const QString value = group.readEntry(key, QString());
        const int pos = value.indexOf(QLatin1Char(':'));
        if (pos != -1) {
            field.setType(CustomField::stringToType(value.left(pos - 1)));
            field.setTitle(value.mid(pos + 1));
        }

        customFields << field;
    }
```

#### AUTO 


```{c}
auto lineLayout = new QHBoxLayout;
```

#### AUTO 


```{c}
auto *generalLayout = new QGridLayout;
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::EmailAddressSelection &selection : mAddressesWidget->selectedAddresses()) {
        mInfo->append(QStringLiteral("%1: %2\n").arg(selection.name(), selection.email()));
    }
```

#### AUTO 


```{c}
auto addr = d->mItem.payload<KContacts::Addressee>();
```

#### AUTO 


```{c}
auto leftJob = new Akonadi::ContactGroupExpandJob(leftContactGroup);
```

#### AUTO 


```{c}
const auto item = index.data(Akonadi::EntityTreeModel::ItemRole).value<Akonadi::Item>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &email : rawContact.emails()) {
        const QString type = i18nc("a contact's email address", "Email");

        const QString fullEmail = QString::fromLatin1(QUrl::toPercentEncoding(rawContact.fullEmail(email)));

        dynamicPart += rowFmtStr1.arg(type)
                       .arg(QStringLiteral("<a href=\"mailto:%1\">%2</a>")
                            .arg(fullEmail, email));
    }
```

#### AUTO 


```{c}
GRANTLEE_MAKE_GADGET(KContacts::Address)
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *widget : widgetList) {
        auto *w = qobject_cast<MailWidget *>(widget);
        w->updateAddRemoveButton(addButtonEnabled);
    }
```

#### AUTO 


```{c}
auto *label = w.findChild<QLabel *>(QStringLiteral("labeltitle"));
```

#### AUTO 


```{c}
auto *postofficeboxlineedit = w.findChild<KLineEdit *>(QStringLiteral("postofficeboxlineedit"));
```

#### AUTO 


```{c}
const auto n = c.toCaseFolded();
```

#### RANGE FOR STATEMENT 


```{c}
for (QString custom : customs) {
            if (custom.startsWith(QStringLiteral("KADDRESSBOOK-"))) {
                custom.remove(QStringLiteral("KADDRESSBOOK-X-"));
                custom.remove(QStringLiteral("KADDRESSBOOK-"));

                int pos = custom.indexOf(QLatin1Char(':'));
                QString key = custom.left(pos);
                QString value = custom.mid(pos + 1);

                // convert anniversary correctly
                if (key == QLatin1String("Anniversary") || key == QLatin1String("ANNIVERSARY")) {
                    const QDateTime dateTime = QDateTime::fromString(value, Qt::ISODate);
                    value = QLocale().toString(dateTime.date());
                } else if (key == QLatin1String("BlogFeed")) {      // blog is handled separated
                    continue;
                } else if (blacklistedKeys.contains(key)) {
                    continue;
                }

                // check whether we have a mapping for the title
                const QMap<QString, QString>::ConstIterator keyIt = titleMap.constFind(key);
                bool needToEscape = true;
                if (keyIt != titleMap.constEnd()) {
                    key = keyIt.value();
                } else {
                    // check whether it is a custom local field
                    foreach (const QVariantMap &description, customFieldDescriptions()) {
                        if (description.value(QStringLiteral("key")).toString() == key) {
                            key = description.value(QStringLiteral("title")).toString();
                            const QString descriptionType = description.value(QStringLiteral("type")).toString();
                            if (descriptionType == QLatin1String("boolean")) {
                                if (value == QLatin1String("true")) {
                                    value = i18nc("Boolean value", "yes");
                                } else {
                                    value = i18nc("Boolean value", "no");
                                }
                            } else if (descriptionType == QLatin1String("date")) {
                                const QDate date = QDate::fromString(value, Qt::ISODate);
                                value = QLocale().toString(date, QLocale::ShortFormat);
                            } else if (descriptionType == QLatin1String("time")) {
                                const QTime time = QTime::fromString(value, Qt::ISODate);
                                value = QLocale().toString(time);
                            } else if (descriptionType == QLatin1String("datetime")) {
                                const QDateTime dateTime = QDateTime::fromString(value, Qt::ISODate);
                                value = QLocale().toString(dateTime, QLocale::ShortFormat);
                            } else if (descriptionType == QLatin1String("url")) {
                                value = KStringHandler::tagUrls(value.toHtmlEscaped());
                                needToEscape = false;
                            }

                            break;
                        }
                    }
                }
                if (needToEscape) {
                    value = value.toHtmlEscaped();
                }
                customData += rowFmtStr1.arg(key).arg(value);
            }
        }
```

#### AUTO 


```{c}
auto *editor = new QCheckBox(parent);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            d->slotEditItem();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &custom : customs) {
        QString app, name, value;
        ContactEditor::Utils::splitCustomField(custom, app, name, value);

        // skip all well-known fields that have separated editor widgets
        if (custom.startsWith(QLatin1String("messaging/"))) {       // IM addresses
            continue;
        }

        if (app == QLatin1String("KADDRESSBOOK")) {
            static QSet<QString> blacklist;
            if (blacklist.isEmpty()) {
                blacklist << QStringLiteral("BlogFeed")
                          << QStringLiteral("X-IMAddress")
                          << QStringLiteral("X-Profession")
                          << QStringLiteral("X-Office")
                          << QStringLiteral("X-ManagersName")
                          << QStringLiteral("X-AssistantsName")
                          << QStringLiteral("X-Anniversary")
                          << QStringLiteral("X-SpousesName")
                          << QStringLiteral("MailPreferedFormatting")
                          << QStringLiteral("MailAllowToRemoteContent")
                          << QStringLiteral("CRYPTOPROTOPREF")
                          << QStringLiteral("OPENPGPFP")
                          << QStringLiteral("SMIMEFP")
                          << QStringLiteral("CRYPTOSIGNPREF")
                          << QStringLiteral("CRYPTOENCRYPTPREF");
            }
            QSet<QString> upperCaseBlacklist;
            for (const QString &blacklistEntry : qAsConst(blacklist)) {
                upperCaseBlacklist << blacklistEntry.toUpper();
            }
            blacklist.unite(upperCaseBlacklist);
            if (blacklist.contains(name)) {     // several KAddressBook specific fields
                continue;
            }
        }

        // check whether it correspond to a local custom field
        bool isLocalCustomField = false;
        const int localCustomFieldsCount(mLocalCustomFields.count());
        for (int i = 0; i < localCustomFieldsCount; ++i) {
            if (mLocalCustomFields[i].key() == name) {
                mLocalCustomFields[i].setValue(value);
                isLocalCustomField = true;
                break;
            }
        }

        // check whether it correspond to a global custom field
        bool isGlobalCustomField = false;
        const int globalCustomFieldsCount(globalCustomFields.count());
        for (int i = 0; i < globalCustomFieldsCount; ++i) {
            if (globalCustomFields[i].key() == name) {
                globalCustomFields[i].setValue(value);
                isGlobalCustomField = true;
                break;
            }
        }

        // if not local and not global it must be external
        if (!isLocalCustomField && !isGlobalCustomField) {
            if (app == QLatin1String("KADDRESSBOOK")) {
                // however if it starts with our prefix it might be that this is an outdated
                // global custom field, in this case treat it as local field of type text
                CustomField customField(name, name, CustomField::TextType, CustomField::LocalScope);
                customField.setValue(value);

                mLocalCustomFields << customField;
            } else {
                // it is really an external custom field
                const QString key = app + QLatin1Char('-') + name;
                CustomField customField(key, key, CustomField::TextType, CustomField::ExternalScope);
                customField.setValue(value);

                externalCustomFields << customField;
            }
        }
    }
```

#### AUTO 


```{c}
auto *gridLayout = new QGridLayout;
```

#### AUTO 


```{c}
auto modifiedJob = static_cast<Akonadi::ItemCreateJob *>(createJob);
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *widget : widgetList) {
        MailWidget *w = qobject_cast<MailWidget *>(widget);
        w->updateAddRemoveButton(addButtonEnabled);
    }
```

#### AUTO 


```{c}
auto layout = new QVBoxLayout(page);
```

#### AUTO 


```{c}
auto typeAddress = w.findChild<SelectAddressTypeComboBox *>(QStringLiteral("typeaddress"));
```

#### AUTO 


```{c}
auto cancelbuttonaddress = w.findChild<QPushButton *>(QStringLiteral("cancelbuttonaddress"));
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) {
            itemFetchDone(job);
        }
```

#### AUTO 


```{c}
auto *w = new MailWidget(parent);
```

#### AUTO 


```{c}
auto label = new QLabel(KContacts::Address::streetLabel(), this);
```

#### AUTO 


```{c}
auto line = w.findChild<KLineEdit *>(QStringLiteral("messaginglineedit"));
```

#### AUTO 


```{c}
auto w = qobject_cast<MessagingWidget *>(widget);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KContacts::PhoneNumber &number : numbers) {
                    values += number.number();
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (QString custom : customs) {
            if (custom.startsWith(QStringLiteral("KADDRESSBOOK-"))) {
                custom.remove(QStringLiteral("KADDRESSBOOK-X-"));
                custom.remove(QStringLiteral("KADDRESSBOOK-"));

                int pos = custom.indexOf(QLatin1Char(':'));
                QString key = custom.left(pos);
                QString value = custom.mid(pos + 1);

                // convert anniversary correctly
                if (key == QLatin1String("Anniversary") || key == QLatin1String("ANNIVERSARY")) {
                    const QDateTime dateTime = QDateTime::fromString(value, Qt::ISODate);
                    value = QLocale().toString(dateTime.date());
                } else if (key == QLatin1String("BlogFeed")) {      // blog is handled separated
                    continue;
                } else if (blacklistedKeys.contains(key)) {
                    continue;
                }

                // check whether we have a mapping for the title
                const QMap<QString, QString>::ConstIterator keyIt = titleMap.constFind(key);
                bool needToEscape = true;
                if (keyIt != titleMap.constEnd()) {
                    key = keyIt.value();
                } else {
                    // check whether it is a custom local field
                    for (const QVariantMap &description : customFieldDescriptions()) {
                        if (description.value(QStringLiteral("key")).toString() == key) {
                            key = description.value(QStringLiteral("title")).toString();
                            const QString descriptionType = description.value(QStringLiteral("type")).toString();
                            if (descriptionType == QLatin1String("boolean")) {
                                if (value == QLatin1String("true")) {
                                    value = i18nc("Boolean value", "yes");
                                } else {
                                    value = i18nc("Boolean value", "no");
                                }
                            } else if (descriptionType == QLatin1String("date")) {
                                const QDate date = QDate::fromString(value, Qt::ISODate);
                                value = QLocale().toString(date, QLocale::ShortFormat);
                            } else if (descriptionType == QLatin1String("time")) {
                                const QTime time = QTime::fromString(value, Qt::ISODate);
                                value = QLocale().toString(time);
                            } else if (descriptionType == QLatin1String("datetime")) {
                                const QDateTime dateTime = QDateTime::fromString(value, Qt::ISODate);
                                value = QLocale().toString(dateTime, QLocale::ShortFormat);
                            } else if (descriptionType == QLatin1String("url")) {
                                value = KStringHandler::tagUrls(value.toHtmlEscaped());
                                needToEscape = false;
                            }

                            break;
                        }
                    }
                }
                if (needToEscape) {
                    value = value.toHtmlEscaped();
                }
                customData += rowFmtStr1.arg(key).arg(value);
            }
        }
```

#### AUTO 


```{c}
auto addButtonWidget = new QWidget(this);
```

#### AUTO 


```{c}
auto delegate = new DisplayNameDelegate(mView->view(), this);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            setComboBoxEditable(mDisplayType == CustomName);
        }
```

#### AUTO 


```{c}
const auto rightContactGroup = rightItem.payload<KContacts::ContactGroup>();
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *widget : widgetList) {
        auto w = qobject_cast<PhoneWidget *>(widget);
        KContacts::PhoneNumber number = w->storePhone();
        if (!number.isEmpty()) {
            phoneNumbers << number;
        }
    }
```

#### AUTO 


```{c}
auto *drag = new QDrag(this);
```

#### AUTO 


```{c}
auto selectedTags{mTagWidget->selection()};
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            slotFinish();
        }
```

#### AUTO 


```{c}
auto categoryWidgetLayout = new QVBoxLayout(categoryWidget);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item &item : lstItems) {
        if (item.hasPayload<KContacts::ContactGroup>()) {
            contactGroups.append(item.payload<KContacts::ContactGroup>());
        }
    }
```

#### AUTO 


```{c}
const auto idx = mAddressesLocationView->indexAt(pos);
```

#### AUTO 


```{c}
auto *topLayout = new QHBoxLayout(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KContacts::Address &address : addresses) {
        QString formattedAddress;

        if (address.label().isEmpty()) {
            formattedAddress = address.formattedAddress().trimmed().toHtmlEscaped();
        } else {
            formattedAddress = address.label().toHtmlEscaped();
        }

        formattedAddress.replace(QRegularExpression(QStringLiteral("\n+")), QStringLiteral("<br>"));

        const QString url = QStringLiteral("<a href=\"address:?index=%1\" title=\"%2\"><img src=\"map_icon\" alt=\"%2\"/></a>")
                                .arg(counter)
                                .arg(i18nc("@info:tooltip", "Show address on map"));
        counter++;

        dynamicPart += rowFmtStr2.arg(KContacts::Address::typeLabel(address.type()), formattedAddress, url);
    }
```

#### AUTO 


```{c}
auto const addressBookJob = new Akonadi::CollectionFetchJob(Akonadi::Collection::root(), Akonadi::CollectionFetchJob::Recursive);
```

#### AUTO 


```{c}
auto button = new QPushButton(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { slotToday(); }
```

#### AUTO 


```{c}
auto *postalcodelabel = w.findChild<QLabel *>(QStringLiteral("postalcodelabel"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &custom : customs) {
        QString app, name, value;
        ContactEditor::Utils::splitCustomField(custom, app, name, value);

        // skip all well-known fields that have separated editor widgets
        if (custom.startsWith(QLatin1String("messaging/"))) { // IM addresses
            continue;
        }

        if (app == QLatin1String("KADDRESSBOOK")) {
            static QSet<QString> blacklist;
            if (blacklist.isEmpty()) {
                blacklist << QStringLiteral("BlogFeed") << QStringLiteral("X-IMAddress") << QStringLiteral("X-Profession") << QStringLiteral("X-Office")
                          << QStringLiteral("X-ManagersName") << QStringLiteral("X-AssistantsName") << QStringLiteral("X-Anniversary")
                          << QStringLiteral("X-SpousesName") << QStringLiteral("MailPreferedFormatting") << QStringLiteral("MailAllowToRemoteContent")
                          << QStringLiteral("CRYPTOPROTOPREF") << QStringLiteral("OPENPGPFP") << QStringLiteral("SMIMEFP") << QStringLiteral("CRYPTOSIGNPREF")
                          << QStringLiteral("CRYPTOENCRYPTPREF");
            }
            QSet<QString> upperCaseBlacklist;
            for (const QString &blacklistEntry : std::as_const(blacklist)) {
                upperCaseBlacklist << blacklistEntry.toUpper();
            }
            blacklist.unite(upperCaseBlacklist);
            if (blacklist.contains(name)) { // several KAddressBook specific fields
                continue;
            }
        }

        // check whether it correspond to a local custom field
        bool isLocalCustomField = false;
        const int localCustomFieldsCount(mLocalCustomFields.count());
        for (int i = 0; i < localCustomFieldsCount; ++i) {
            if (mLocalCustomFields[i].key() == name) {
                mLocalCustomFields[i].setValue(value);
                isLocalCustomField = true;
                break;
            }
        }

        // check whether it correspond to a global custom field
        bool isGlobalCustomField = false;
        const int globalCustomFieldsCount(globalCustomFields.count());
        for (int i = 0; i < globalCustomFieldsCount; ++i) {
            if (globalCustomFields[i].key() == name) {
                globalCustomFields[i].setValue(value);
                isGlobalCustomField = true;
                break;
            }
        }

        // if not local and not global it must be external
        if (!isLocalCustomField && !isGlobalCustomField) {
            if (app == QLatin1String("KADDRESSBOOK")) {
                // however if it starts with our prefix it might be that this is an outdated
                // global custom field, in this case treat it as local field of type text
                CustomField customField(name, name, CustomField::TextType, CustomField::LocalScope);
                customField.setValue(value);

                mLocalCustomFields << customField;
            } else {
                // it is really an external custom field
                const QString key = app + QLatin1Char('-') + name;
                CustomField customField(key, key, CustomField::TextType, CustomField::ExternalScope);
                customField.setValue(value);

                externalCustomFields << customField;
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->updateActions(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) {
            d->storeDone(job);
        }
```

#### AUTO 


```{c}
auto enumValueAddress = static_cast<ContactActionsSettings::EnumShowAddressAction>(ContactActionsSettings::self()->showAddressAction());
```

#### AUTO 


```{c}
auto fetchJob = qobject_cast<CollectionFetchJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (ContactEditor::ContactEditorPagePlugin *plugin : qAsConst(d->mCustomPages)) {
            plugin->storeContact(contact);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *widget : widgetList) {
        if (widget != w) {
            (static_cast<PhoneWidget *>(widget))->setPreferred(false);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const CustomField &field : customFields) {
        const QString key = field.key();
        const QString value = CustomField::typeToString(field.type()) + QLatin1Char(':') + field.title();

        group.writeEntry(key, value);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) {
                fetchResult(job);
            }
```

#### AUTO 


```{c}
auto *fetchJob = qobject_cast<ItemFetchJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *widget : widgetList) {
        MailWidget *w = qobject_cast<MailWidget *>(widget);
        KContacts::Email newEmail = w->email();
        if (newEmail.isValid()) {
            emailList << newEmail;
        }
    }
```

#### AUTO 


```{c}
const auto item = index.data(ContactsTreeModel::ItemRole).value<Akonadi::Item>();
```

#### AUTO 


```{c}
auto createJob = new Akonadi::ItemCreateJob(item, addressBook, q);
```

#### AUTO 


```{c}
auto filter = new Akonadi::EntityMimeTypeFilterModel(model);
```

#### RANGE FOR STATEMENT 


```{c}
for (ContactEditor::ContactEditorPagePlugin *plugin : std::as_const(d->mCustomPages)) {
            plugin->loadContact(contact);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *widget : qAsConst(d->mWidgetList)) {
        clearWidget(widget);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *widget : widgetList) {
        if (widget != w) {
            (static_cast<MessagingWidget *>(widget))->setPreferred(false);
        }
    }
```

#### AUTO 


```{c}
auto mainWidget = new QWidget(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &custom : customs) {
        QString app, name, value;
        Akonadi::Utils::splitCustomField(custom, app, name, value);

        if (app.startsWith(QStringLiteral("messaging/"))) {
            if (name == QLatin1String("All")) {
                const QString protocol = app;
                const QStringList names = value.split(QChar(0xE000), QString::SkipEmptyParts);

                for (const QString &name : names) {
                    //TODO preferred support ?
                    imaddresses << IMAddress(protocol, name, false);
                }
            }
        }
    }
```

#### AUTO 


```{c}
const auto result = KPluginFactory::instantiatePlugin<ContactEditor::CategoriesEditAbstractWidget>(editWidgetPlugin, parent);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &blacklistEntry : std::as_const(blacklist)) {
                upperCaseBlacklist << blacklistEntry.toUpper();
            }
```

#### AUTO 


```{c}
auto job = new Akonadi::ItemModifyJob(d->mItem);
```

#### AUTO 


```{c}
auto comboBox = qobject_cast<KComboBox *>(editor);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { setComboBoxEditable(mDisplayType == CustomName); }
```

#### AUTO 


```{c}
auto fetchJob = qobject_cast<Akonadi::ItemFetchJob *>(job);
```

#### AUTO 


```{c}
auto *job = new ItemFetchJob(item);
```

#### AUTO 


```{c}
auto *localitylabel = w.findChild<QLabel *>(QStringLiteral("localitylabel"));
```

#### AUTO 


```{c}
const auto *attribute = contact.attribute<ContactMetaDataAttribute>();
```

#### AUTO 


```{c}
auto drag = new QDrag(this);
```

#### AUTO 


```{c}
auto countrylabel = w.findChild<QLabel *>(QStringLiteral("countrylabel"));
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) {
            slotParentCollectionFetched(job);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->slotAddressBook(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QItemSelection &selection) {
        mAddressLocationWidget->clear();
        if (selection.size() != 1) {
            return;
        }
        const auto idx = selection.at(0).topLeft();
        if (!idx.isValid()) {
            return;
        }
        mAddressLocationWidget->slotModifyAddress(idx.data(Qt::UserRole).value<KContacts::Address>(), idx.row());
    }
```

#### AUTO 


```{c}
auto *act = w.findChild<QAction *>(QStringLiteral("preferredaction"));
```

#### AUTO 


```{c}
auto *nickNameLabel = editor.findChild<QLabel *>(QStringLiteral("nicknamelabel"));
```

#### AUTO 


```{c}
auto label = new QLabel(i18nc("@label Search in a list of contacts", "Search:"));
```

#### AUTO 


```{c}
auto label = new QLabel(i18n("Tags"), this);
```

#### AUTO 


```{c}
auto *w = new MessagingWidget(parent);
```

#### AUTO 


```{c}
auto *model = new ContactCompletionModel(monitor);
```

#### AUTO 


```{c}
auto *layout = new QVBoxLayout(widget);
```

#### AUTO 


```{c}
const auto result = KMessageBox::questionYesNo(this,
                                                           i18n("Do you really want to delete this address?"),
                                                           QString(),
                                                           KStandardGuiItem::del(),
                                                           KStandardGuiItem::cancel());
```

#### RANGE FOR STATEMENT 


```{c}
for (const KContacts::Address &address : addresses) {
        QString formattedAddress;

        if (address.label().isEmpty()) {
            formattedAddress = address.formatted(KContacts::AddressFormatStyle::Postal).trimmed().toHtmlEscaped();
        } else {
            formattedAddress = address.label().toHtmlEscaped();
        }

        formattedAddress.replace(QRegularExpression(QStringLiteral("\n+")), QStringLiteral("<br>"));

        const QString url = QStringLiteral("<a href=\"address:?index=%1\" title=\"%2\"><img src=\"map_icon\" alt=\"%2\"/></a>")
                                .arg(counter)
                                .arg(i18nc("@info:tooltip", "Show address on map"));
        counter++;

        dynamicPart += rowFmtStr2.arg(KContacts::Address::typeLabel(address.type()), formattedAddress, url);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {d->slotCreateContact();}
```

#### AUTO 


```{c}
auto layout = new QVBoxLayout(this);
```

#### AUTO 


```{c}
auto *job = new Akonadi::ContactGroupExpandJob(group);
```

#### AUTO 


```{c}
auto editor = new QDateEdit(parent);
```

#### AUTO 


```{c}
auto widget = qobject_cast<QSpinBox *>(editor);
```

#### AUTO 


```{c}
auto fieldLayout = new QHBoxLayout;
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) {
            slotAddContactDone(job);
        }
```

#### AUTO 


```{c}
auto label = new QLabel(i18n("Phone"), this);
```

#### AUTO 


```{c}
auto widget = qobject_cast<QCheckBox *>(editor);
```

#### AUTO 


```{c}
auto localitylabel = w.findChild<QLabel *>(QStringLiteral("localitylabel"));
```

#### LAMBDA EXPRESSION 


```{c}
[&imageData](KIO::Job *, const QByteArray & data) {
            imageData.append(data);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const CustomField &customField : customFields) {
        // write back values for local and global scope, leave external untouched
        if (customField.scope() != CustomField::ExternalScope) {
            if (!customField.value().isEmpty()) {
                contact.insertCustom(QStringLiteral("KADDRESSBOOK"), customField.key(), customField.value());
            } else {
                contact.removeCustom(QStringLiteral("KADDRESSBOOK"), customField.key());
            }
        }
    }
```

#### AUTO 


```{c}
auto *addButton = w.findChild<QToolButton *>(QStringLiteral("addbutton"));
```

#### AUTO 


```{c}
auto mailtype = w.findChild<QComboBox *>(QStringLiteral("mailtype"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVariantMap &map : additionalFieldsLst) {
        strGroup.append(QStringLiteral("<tr><td colspan=\"2\">&nbsp;</td></tr><tr><td align=\"right\" width=\"30%\"><b><font color=\"grey\">%1</font></b></td>"
                                       "<td valign=\"bottom\" align=\"left\" width=\"50%\"><font>%2</font></td></tr>")
                            .arg(map.value(QStringLiteral("title")).toString(), map.value(QStringLiteral("value")).toString()));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *widget : widgetList) {
        PhoneWidget *w = qobject_cast<PhoneWidget *>(widget);
        w->updateAddRemoveButton(addButtonEnabled);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const auto &s1, const auto &s2) {
        return QString::localeAwareCompare(s1, s2) < 0;
    }
```

#### AUTO 


```{c}
auto editor = new QDateTimeEdit(parent);
```

#### AUTO 


```{c}
auto searchJob = new Akonadi::ContactSearchJob(q);
```

#### AUTO 


```{c}
auto *lineLayout = new QHBoxLayout;
```

#### RANGE FOR STATEMENT 


```{c}
for (Akonadi::ContactEditorPagePlugin *plugin : qAsConst(d->mCustomPages)) {
            plugin->loadContact(contact);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[proxyModel](const QString &text) {
        proxyModel->setFilterRegularExpression(text);
    }
```

#### AUTO 


```{c}
auto *job = new Akonadi::ItemFetchJob(mItem);
```

#### AUTO 


```{c}
auto *job = new Akonadi::ItemFetchJob(item);
```

#### AUTO 


```{c}
auto w = qobject_cast<MailWidget *>(*wIt);
```

#### AUTO 


```{c}
auto label = new QLabel(i18n("Email"), this);
```

#### AUTO 


```{c}
auto *w = qobject_cast<MailWidget *>(*wIt);
```

#### AUTO 


```{c}
auto enumValue = static_cast<ContactActionsSettings::EnumDialPhoneNumberAction>(ContactActionsSettings::self()->dialPhoneNumberAction());
```

#### AUTO 


```{c}
auto *addButtonWidgetLayout = new QHBoxLayout(addButtonWidget);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : selectedRows) {
        EmailAddressSelection selection;
        selection.d->mName = index.data(EmailAddressSelectionProxyModel::NameRole).toString();
        selection.d->mEmailAddress = index.data(EmailAddressSelectionProxyModel::EmailAddressRole).toString();
        selection.d->mItem = index.data(ContactsTreeModel::ItemRole).value<Akonadi::Item>();

        if (d->mShowOnlyContactWithEmail) {
            if (!selection.d->mEmailAddress.isEmpty()) {
                selections << selection;
            }
        } else {
            selections << selection;
        }
    }
```

#### AUTO 


```{c}
auto *categoryWidgetLayout = new QVBoxLayout(categoryWidget);
```

#### AUTO 


```{c}
auto modifyButtonWidgetLayout = new QHBoxLayout(modifyButtonWidget);
```

#### AUTO 


```{c}
const auto imaddresses = contact.imppList();
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *widget : widgetList) {
        MailWidget *w = qobject_cast<MailWidget *>(widget);
        w->setReadOnly(readOnly);
    }
```

#### AUTO 


```{c}
auto w = qobject_cast<PhoneWidget *>(*wIt);
```

#### AUTO 


```{c}
GRANTLEE_MAKE_GADGET(KContacts::Impp)
```

#### LAMBDA EXPRESSION 


```{c}
[this] () { d->adaptHeaderSizes(); }
```

#### AUTO 


```{c}
auto layout = new QVBoxLayout(q);
```

#### AUTO 


```{c}
auto label = w.findChild<QLabel *>(QStringLiteral("labeltitle"));
```

#### AUTO 


```{c}
auto widget = qobject_cast<QTimeEdit *>(editor);
```

#### AUTO 


```{c}
auto layout = new QHBoxLayout(this);
```

#### AUTO 


```{c}
auto *box = new KComboBox;
```

#### AUTO 


```{c}
auto *postofficeboxlabel = w.findChild<QLabel *>(QStringLiteral("postofficeboxlabel"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const KContacts::Address &address : rawContact.addresses()) {
        QString formattedAddress;

        if (address.label().isEmpty()) {
            formattedAddress = address.formattedAddress().trimmed().toHtmlEscaped();
        } else {
            formattedAddress = address.label().toHtmlEscaped();
        }

        formattedAddress.replace(QRegularExpression(QStringLiteral("\n+")), QStringLiteral("<br>"));

        const QString url = QStringLiteral("<a href=\"address:?index=%1\" title=\"%2\"><img src=\"map_icon\" alt=\"%2\"/></a>")
                            .arg(counter)
                            .arg(i18nc("@info:tooltip", "Show address on map"));
        counter++;

        dynamicPart += rowFmtStr2
                       .arg(KContacts::Address::typeLabel(address.type()))
                       .arg(formattedAddress)
                       .arg(url);
    }
```

#### AUTO 


```{c}
auto label = new QLabel(i18nc("@label The birthdate of a contact", "Birthdate:"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &custom : customs) {
        QString app, name, value;
        ContactEditor::Utils::splitCustomField(custom, app, name, value);

        if (app.startsWith(QStringLiteral("messaging/"))) {
            if (name == QLatin1String("All")) {
                const QString protocol = app;
                const QStringList names = value.split(QChar(0xE000), QString::SkipEmptyParts);

                for (const QString &name : names) {
                    //TODO preferred support ?
                    imaddresses << IMAddress(protocol, name, false);
                }
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Collection &collection : colsList) {
            if (Akonadi::Collection::CanCreateItem & collection.rights()) {
                canCreateItemCollections.append(collection);
            }
        }
```

#### AUTO 


```{c}
auto w = new WebWidget(parent);
```

#### AUTO 


```{c}
auto addButton = w.findChild<QToolButton *>(QStringLiteral("addbutton"));
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Akonadi::Item &item , const QSet<QByteArray> &arrays) { itemChanged(item,arrays); }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->slotAddressBook();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) { d->storeDone(job); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) { d->itemFetchDone(job); }
```

#### AUTO 


```{c}
auto *topLayout = editor.findChild<QVBoxLayout *>(QStringLiteral("mainlayout"));
```

#### AUTO 


```{c}
auto addfield = w.findChild<QPushButton *>(QStringLiteral("addfield"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const CustomField &field : std::as_const(globalCustomFields)) {
            QVariantMap description;
            description.insert(QStringLiteral("key"), field.key());
            description.insert(QStringLiteral("title"), field.title());

            customFieldDescriptions << description;
        }
```

#### AUTO 


```{c}
auto *fieldLayout = new QHBoxLayout;
```

#### AUTO 


```{c}
auto protocolCombo = w.findChild<QComboBox *>(QStringLiteral("protocol"));
```

#### AUTO 


```{c}
auto photoLayout = new QVBoxLayout;
```

#### AUTO 


```{c}
auto *filter = new Akonadi::EntityMimeTypeFilterModel(model);
```

#### AUTO 


```{c}
auto *attribute2 = static_cast<Akonadi::ContactMetaDataAttribute *>(attribute1.clone());
```

#### AUTO 


```{c}
auto *searchJob = new Akonadi::ContactSearchJob(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &custom : customs) {
        QString app, name, value;
        ContactEditor::Utils::splitCustomField(custom, app, name, value);

        if (app.startsWith(QLatin1String("messaging/"))) {
            if (name == QLatin1String("All")) {
                const QString protocol = app;
                const QStringList names = value.split(QChar(0xE000), QString::SkipEmptyParts);

                for (const QString &name : names) {
                    //TODO preferred support ?
                    imaddresses << IMAddress(protocol, name, false);
                }
            }
        }
    }
```

#### AUTO 


```{c}
auto mMailPreferFormatting = w.findChild<QComboBox *>(QStringLiteral("mMailPreferFormatting"));
```

#### AUTO 


```{c}
auto buttonBox = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel, this);
```

#### AUTO 


```{c}
auto *job = new ItemFetchJob(mItem);
```

#### RANGE FOR STATEMENT 


```{c}
for (const CustomField &customField : qAsConst(customFields)) {
        if (customField.scope() == CustomField::GlobalScope) {
            globalCustomFields << customField;
        }
    }
```

#### AUTO 


```{c}
auto *job = new Akonadi::ItemModifyJob(d->mItem);
```

#### AUTO 


```{c}
auto line = w.findChild<QLineEdit *>(QStringLiteral("phonenumber"));
```

#### AUTO 


```{c}
auto remove = w.findChild<QToolButton *>(QStringLiteral("removebutton"));
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *widget : widgetList) {
        auto *w = qobject_cast<PhoneWidget *>(widget);
        w->setReadOnly(readOnly);
    }
```

#### AUTO 


```{c}
auto *fetchJob = qobject_cast<Akonadi::CollectionFetchJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const CustomField &oldCustomField : std::as_const(mLocalCustomFields)) {
        if (oldCustomField.scope() != CustomField::ExternalScope) {
            bool fieldStillExists = false;
            for (const CustomField &newCustomField : std::as_const(customFields)) {
                if (newCustomField.scope() != CustomField::ExternalScope) {
                    if (newCustomField.key() == oldCustomField.key()) {
                        fieldStillExists = true;
                        break;
                    }
                }
            }

            if (!fieldStillExists) {
                contact.removeCustom(QStringLiteral("KADDRESSBOOK"), oldCustomField.key());
            }
        }
    }
```

#### AUTO 


```{c}
auto *buttonLayout = new QGridLayout(box);
```

#### AUTO 


```{c}
auto w = new MailWidget(parent);
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) {
        d->slotSearchDone(job);
    }
```

#### AUTO 


```{c}
auto *filter = new Akonadi::ContactsFilterProxyModel(q);
```

#### AUTO 


```{c}
auto *mMailPreferFormatting = w.findChild<QComboBox *>(QStringLiteral("mMailPreferFormatting"));
```

#### AUTO 


```{c}
auto w = qobject_cast<WebWidget *>(*wIt);
```

#### AUTO 


```{c}
auto itemModifyJob = new Akonadi::ItemModifyJob(item);
```

#### AUTO 


```{c}
auto job = new Akonadi::ItemFetchJob(mItem);
```

#### AUTO 


```{c}
auto comboBox = new KComboBox(parent);
```

#### AUTO 


```{c}
auto editor = new QTimeEdit(parent);
```

#### AUTO 


```{c}
GRANTLEE_MAKE_GADGET(KContacts::PhoneNumber)
```

#### AUTO 


```{c}
const auto group = mItem.payload<KContacts::ContactGroup>();
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) { d->searchResult(job); }
```

#### AUTO 


```{c}
auto mStreetEdit = w.findChild<KLineEdit *>(QStringLiteral("streetlineedit"));
```

#### AUTO 


```{c}
GRANTLEE_MAKE_GADGET(KContacts::ResourceLocatorUrl)
```

#### AUTO 


```{c}
auto *customFieldDelegate = new ContactEditor::CustomFieldsListDelegate(mCustomFieldList, this);
```

#### AUTO 


```{c}
auto act = w.findChild<QAction *>(QStringLiteral("preferredaction"));
```

#### AUTO 


```{c}
auto *layout = new QVBoxLayout(page);
```

#### AUTO 


```{c}
auto job = new KIO::CommandLauncherJob(commandTemplate);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &str) {
        d->slotGroupNameChanged(str);
    }
```

#### AUTO 


```{c}
auto layout = new QGridLayout(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *widget : widgetList) {
        auto w = qobject_cast<MailWidget *>(widget);
        w->setReadOnly(readOnly);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &str) {
                    slotContactEditorError(str);
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &custom : customs) {
        QString app, name, value;
        ContactEditor::Utils::splitCustomField(custom, app, name, value);

        // skip all well-known fields that have separated editor widgets
        if (custom.startsWith(QLatin1String("messaging/"))) { // IM addresses
            continue;
        }

        if (app == QLatin1String("KADDRESSBOOK")) {
            static QSet<QString> blacklist;
            if (blacklist.isEmpty()) {
                blacklist << QStringLiteral("BlogFeed") << QStringLiteral("X-IMAddress") << QStringLiteral("X-Profession") << QStringLiteral("X-Office")
                          << QStringLiteral("X-ManagersName") << QStringLiteral("X-AssistantsName") << QStringLiteral("X-Anniversary")
                          << QStringLiteral("X-SpousesName") << QStringLiteral("MailPreferedFormatting") << QStringLiteral("MailAllowToRemoteContent")
                          << QStringLiteral("CRYPTOPROTOPREF") << QStringLiteral("OPENPGPFP") << QStringLiteral("SMIMEFP") << QStringLiteral("CRYPTOSIGNPREF")
                          << QStringLiteral("CRYPTOENCRYPTPREF");
            }
            QSet<QString> upperCaseBlacklist;
            for (const QString &blacklistEntry : qAsConst(blacklist)) {
                upperCaseBlacklist << blacklistEntry.toUpper();
            }
            blacklist.unite(upperCaseBlacklist);
            if (blacklist.contains(name)) { // several KAddressBook specific fields
                continue;
            }
        }

        // check whether it correspond to a local custom field
        bool isLocalCustomField = false;
        const int localCustomFieldsCount(mLocalCustomFields.count());
        for (int i = 0; i < localCustomFieldsCount; ++i) {
            if (mLocalCustomFields[i].key() == name) {
                mLocalCustomFields[i].setValue(value);
                isLocalCustomField = true;
                break;
            }
        }

        // check whether it correspond to a global custom field
        bool isGlobalCustomField = false;
        const int globalCustomFieldsCount(globalCustomFields.count());
        for (int i = 0; i < globalCustomFieldsCount; ++i) {
            if (globalCustomFields[i].key() == name) {
                globalCustomFields[i].setValue(value);
                isGlobalCustomField = true;
                break;
            }
        }

        // if not local and not global it must be external
        if (!isLocalCustomField && !isGlobalCustomField) {
            if (app == QLatin1String("KADDRESSBOOK")) {
                // however if it starts with our prefix it might be that this is an outdated
                // global custom field, in this case treat it as local field of type text
                CustomField customField(name, name, CustomField::TextType, CustomField::LocalScope);
                customField.setValue(value);

                mLocalCustomFields << customField;
            } else {
                // it is really an external custom field
                const QString key = app + QLatin1Char('-') + name;
                CustomField customField(key, key, CustomField::TextType, CustomField::ExternalScope);
                customField.setValue(value);

                externalCustomFields << customField;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *widget : widgetList) {
        PhoneWidget *w = qobject_cast<PhoneWidget *>(widget);
        w->setReadOnly(readOnly);
    }
```

#### AUTO 


```{c}
auto fieldname = w.findChild<QLineEdit *>(QStringLiteral("fieldname"));
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) {
                slotAddContactDone(job);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::EmailAddressSelection &selection : selectedAddress) {
            qDebug("%s: %s", qPrintable(selection.name()), qPrintable(selection.email()));
        }
```

#### AUTO 


```{c}
auto nickNameLabel = new QLabel(i18n("Nickname"), this);
```

#### AUTO 


```{c}
auto *actions = new ContactDefaultActions(this);
```

#### AUTO 


```{c}
auto modifiedJob = static_cast<Akonadi::ItemModifyJob *>(itemModifyJob);
```

#### AUTO 


```{c}
auto *lineEdit = static_cast<ContactLineEdit *>(editor);
```

#### AUTO 


```{c}
auto *box = qobject_cast<QCheckBox *>(mGroup->buttons().at(i));
```

#### AUTO 


```{c}
auto *mailtype = w.findChild<QComboBox *>(QStringLiteral("mailtype"));
```

#### AUTO 


```{c}
const auto c = KCountry::fromName(address.country());
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *widget : widgetList) {
        auto w = qobject_cast<MessagingWidget *>(widget);
        imaddresses << w->imAddress();
    }
```

#### AUTO 


```{c}
auto addButtonWidgetLayout = new QHBoxLayout(addButtonWidget);
```

#### AUTO 


```{c}
auto localitylineedit = w.findChild<KLineEdit *>(QStringLiteral("localitylineedit"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &description : qAsConst(mDescriptions)) {
            mMaxDescriptionWidth = qMax(mMaxDescriptionWidth, metrics.width(description));
        }
```

#### AUTO 


```{c}
auto *buttonLayout = new QGridLayout;
```

#### AUTO 


```{c}
auto preferredcheckbox = w.findChild<QCheckBox *>(QStringLiteral("preferredcheckbox"));
```

#### AUTO 


```{c}
auto editor = new QCheckBox(parent);
```

#### AUTO 


```{c}
auto *layout = new QVBoxLayout(this);
```

#### AUTO 


```{c}
auto label = w.findChild<QLabel *>(QStringLiteral("label"));
```

#### LAMBDA EXPRESSION 


```{c}
[&imageData](KIO::Job *, const QByteArray &data) {
                                imageData.append(data);
                             }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            slotOkClicked();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVariantMap &description : customFieldDescriptions()) {
                        if (description.value(QStringLiteral("key")).toString() == key) {
                            key = description.value(QStringLiteral("title")).toString();
                            const QString descriptionType = description.value(QStringLiteral("type")).toString();
                            if (descriptionType == QLatin1String("boolean")) {
                                if (value == QLatin1String("true")) {
                                    value = i18nc("Boolean value", "yes");
                                } else {
                                    value = i18nc("Boolean value", "no");
                                }
                            } else if (descriptionType == QLatin1String("date")) {
                                const QDate date = QDate::fromString(value, Qt::ISODate);
                                value = QLocale().toString(date, QLocale::ShortFormat);
                            } else if (descriptionType == QLatin1String("time")) {
                                const QTime time = QTime::fromString(value, Qt::ISODate);
                                value = QLocale().toString(time);
                            } else if (descriptionType == QLatin1String("datetime")) {
                                const QDateTime dateTime = QDateTime::fromString(value, Qt::ISODate);
                                value = QLocale().toString(dateTime, QLocale::ShortFormat);
                            } else if (descriptionType == QLatin1String("url")) {
                                value = KStringHandler::tagUrls(value.toHtmlEscaped());
                                needToEscape = false;
                            }

                            break;
                        }
                    }
```

#### AUTO 


```{c}
auto completer = new QCompleter(filter, this);
```

#### AUTO 


```{c}
auto *line = w.findChild<QLineEdit *>(QStringLiteral("mailedit"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &custom : customs) {

        QString app, name, value;
        Akonadi::Utils::splitCustomField(custom, app, name, value);

        // skip all well-known fields that have separated editor widgets
        if (custom.startsWith(QStringLiteral("messaging/"))) {       // IM addresses
            continue;
        }

        if (app == QLatin1String("KADDRESSBOOK")) {
            static QSet<QString> blacklist;
            if (blacklist.isEmpty()) {
                blacklist << QStringLiteral("BlogFeed")
                          << QStringLiteral("X-IMAddress")
                          << QStringLiteral("X-Profession")
                          << QStringLiteral("X-Office")
                          << QStringLiteral("X-ManagersName")
                          << QStringLiteral("X-AssistantsName")
                          << QStringLiteral("X-Anniversary")
                          << QStringLiteral("X-ANNIVERSARY")
                          << QStringLiteral("X-SpousesName")
                          << QStringLiteral("X-Profession")
                          << QStringLiteral("MailPreferedFormatting")
                          << QStringLiteral("MailAllowToRemoteContent")
                          << QStringLiteral("CRYPTOPROTOPREF")
                          << QStringLiteral("OPENPGPFP")
                          << QStringLiteral("SMIMEFP")
                          << QStringLiteral("CRYPTOSIGNPREF")
                          << QStringLiteral("CRYPTOENCRYPTPREF");
            }

            if (blacklist.contains(name)) {     // several KAddressBook specific fields
                continue;
            }
        }

        // check whether it correspond to a local custom field
        bool isLocalCustomField = false;
        const int localCustomFieldsCount(mLocalCustomFields.count());
        for (int i = 0; i < localCustomFieldsCount; ++i) {
            if (mLocalCustomFields[i].key() == name) {
                mLocalCustomFields[i].setValue(value);
                isLocalCustomField = true;
                break;
            }
        }

        // check whether it correspond to a global custom field
        bool isGlobalCustomField = false;
        const int globalCustomFieldsCount(globalCustomFields.count());
        for (int i = 0; i < globalCustomFieldsCount; ++i) {
            if (globalCustomFields[i].key() == name) {
                globalCustomFields[i].setValue(value);
                isGlobalCustomField = true;
                break;
            }
        }

        // if not local and not global it must be external
        if (!isLocalCustomField && !isGlobalCustomField) {
            if (app == QLatin1String("KADDRESSBOOK")) {
                // however if it starts with our prefix it might be that this is an outdated
                // global custom field, in this case treat it as local field of type text
                CustomField customField(name, name, CustomField::TextType, CustomField::LocalScope);
                customField.setValue(value);

                mLocalCustomFields << customField;
            } else {
                // it is really an external custom field
                const QString key = app + QLatin1Char('-') + name;
                CustomField customField(key, key, CustomField::TextType, CustomField::ExternalScope);
                customField.setValue(value);

                externalCustomFields << customField;
            }
        }
    }
```

#### AUTO 


```{c}
auto label = new QLabel(i18n("Show messages received from this contact as:"), this);
```

#### AUTO 


```{c}
auto *searchJob = new ContactGroupSearchJob(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) {
            itemFetched(job);
        }
```

#### AUTO 


```{c}
auto layout = new QVBoxLayout(widget);
```

#### AUTO 


```{c}
auto proxyModel = new QSortFilterProxyModel(this);
```

#### AUTO 


```{c}
auto streetlabel = w.findChild<QLabel *>(QStringLiteral("streetlabel"));
```

#### AUTO 


```{c}
auto postalcodelabel = w.findChild<QLabel *>(QStringLiteral("postalcodelabel"));
```

#### AUTO 


```{c}
auto model = new ContactCompletionModel(monitor);
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *widget : widgetList) {
        if (widget != w) {
            (static_cast<MailWidget *>(widget))->setPreferred(false);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        adaptHeaderSizes();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {d->slotCreateContactGroup(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KContacts::PhoneNumber &number : phoneNumbers) {
        QString dispLabel = number.typeLabel().replace(QLatin1Char(' '), QStringLiteral("&nbsp;"));
        QString dispValue = QStringLiteral("<a href=\"phone:?index=%1\">%2</a>").arg(counter).arg(number.number().toHtmlEscaped());
        if (number.type() & KContacts::PhoneNumber::Cell) {
            QString dispIcon = QStringLiteral("<a href=\"sms:?index=%1\" title=\"%2\"><img src=\"sms_icon\" align=\"top\"/>")
                                   .arg(counter)
                                   .arg(i18nc("@info:tooltip", "Send SMS"));
            dynamicPart += rowFmtStr2.arg(dispLabel, dispValue, dispIcon);
        } else {
            dynamicPart += rowFmtStr1.arg(dispLabel, dispValue);
        }

        ++counter;
    }
```

#### AUTO 


```{c}
auto *mButtonBoxHBoxLayout = new QHBoxLayout(d->mButtonBox);
```

#### AUTO 


```{c}
auto topLayout = editor.findChild<QVBoxLayout *>(QStringLiteral("mainlayout"));
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *widget : widgetList) {
        auto *w = qobject_cast<MessagingWidget *>(widget);
        w->setReadOnly(readOnly);
    }
```

#### AUTO 


```{c}
auto buttonLayout = new QGridLayout(box);
```

#### AUTO 


```{c}
auto createJob = new AddEmailAddressJob(mCompleteAddress, mParentWidget, q);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->resolveGroup(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            slotTomorrow();
        }
```

#### AUTO 


```{c}
auto collectionFetchJob = new Akonadi::CollectionFetchJob(mItem.parentCollection(), Akonadi::CollectionFetchJob::Base);
```

#### AUTO 


```{c}
auto layout = new QGridLayout(mainWidget);
```

#### AUTO 


```{c}
const auto country = KCountry::fromName(address.country());
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &error) {
                slotContactEditorError(error);
            }
```

#### AUTO 


```{c}
auto mainLayout = new QVBoxLayout(this);
```

#### AUTO 


```{c}
auto job = new Akonadi::ContactGroupExpandJob(group);
```

#### AUTO 


```{c}
auto *searchLayout = new QHBoxLayout;
```

#### AUTO 


```{c}
auto *widget = qobject_cast<QDateEdit *>(editor);
```

#### AUTO 


```{c}
auto job = new Akonadi::AgentInstanceCreateJob(agentType, q);
```

#### AUTO 


```{c}
const auto selectedAddresses = dlg.selectedAddresses();
```

#### AUTO 


```{c}
auto w = qobject_cast<PhoneWidget *>(widget);
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) {
                            slotResourceCreationDone(job);
                        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &protocol : protocols) {
        mProtocolCombo->addItem(QIcon::fromTheme(KContacts::Impp::serviceIcon(protocol)),
                                KContacts::Impp::serviceLabel(protocol),
                                protocol);
    }
```

#### AUTO 


```{c}
auto label = new QLabel(i18n("Add to:"), mainWidget);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::EmailAddressSelection &selection : dlg.selectedAddresses()) {
            qDebug("%s: %s", qPrintable(selection.name()), qPrintable(selection.email()));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KContacts::Address &address : addresses) {
        QString formattedAddress;

        if (address.label().isEmpty()) {
            formattedAddress = address.formattedAddress().trimmed().toHtmlEscaped();
        } else {
            formattedAddress = address.label().toHtmlEscaped();
        }

        formattedAddress.replace(QRegularExpression(QStringLiteral("\n+")), QStringLiteral("<br>"));

        const QString url = QStringLiteral("<a href=\"address:?index=%1\" title=\"%2\"><img src=\"map_icon\" alt=\"%2\"/></a>")
                            .arg(counter)
                            .arg(i18nc("@info:tooltip", "Show address on map"));
        counter++;

        dynamicPart += rowFmtStr2
                       .arg(KContacts::Address::typeLabel(address.type()), formattedAddress, url);
    }
```

#### AUTO 


```{c}
const auto selectedAddresses = dlg->selectedAddresses();
```

#### AUTO 


```{c}
auto *widget = qobject_cast<QCheckBox *>(editor);
```

#### RANGE FOR STATEMENT 


```{c}
for (Akonadi::ContactEditorPagePlugin *plugin : qAsConst(d->mCustomPages)) {
            plugin->setReadOnly(readOnly);
        }
```

#### AUTO 


```{c}
auto edit = new ContactLineEdit(isReference, ContactCompletionModel::EmailColumn, parent);
```

#### RANGE FOR STATEMENT 


```{c}
for (ContactEditor::ContactEditorPagePlugin *plugin : qAsConst(mCustomPages)) {
        mTabWidget->addTab(plugin, plugin->title());
    }
```

#### AUTO 


```{c}
const auto addr = mItem.payload<KContacts::Addressee>();
```

#### RANGE FOR STATEMENT 


```{c}
for (QString custom : customs) {
        if (custom.startsWith(QLatin1String("KADDRESSBOOK-"))) {
            custom.remove(QStringLiteral("KADDRESSBOOK-X-"));
            custom.remove(QStringLiteral("KADDRESSBOOK-"));

            int pos = custom.indexOf(QLatin1Char(':'));
            QString key = custom.left(pos);
            QString value = custom.mid(pos + 1);

            if (blacklistedKeys.contains(key)) {
                continue;
            }

            bool addUrl = false;
            // check whether it is a custom local field
            for (int i = 0; i < customFieldDescriptions().size(); ++i) {
                const QVariantMap description = customFieldDescriptions().at(i);
                if (description.value(QStringLiteral("key")).toString() == key) {
                    key = description.value(QStringLiteral("title")).toString();
                    const QString descriptionType = description.value(QStringLiteral("type")).toString();
                    if (descriptionType == QLatin1String("boolean")) {
                        if (value == QLatin1String("true")) {
                            value = i18nc("Boolean value", "yes");
                        } else {
                            value = i18nc("Boolean value", "no");
                        }
                    } else if (descriptionType == QLatin1String("date")) {
                        const QDate date = QDate::fromString(value, Qt::ISODate);
                        value = QLocale().toString(date, QLocale::ShortFormat);
                    } else if (descriptionType == QLatin1String("time")) {
                        const QTime time = QTime::fromString(value, Qt::ISODate);
                        value = QLocale::system().toString(time, QLocale::ShortFormat);
                    } else if (descriptionType == QLatin1String("datetime")) {
                        const QDateTime dateTime = QDateTime::fromString(value, Qt::ISODate);
                        value = QLocale().toString(dateTime, QLocale::ShortFormat);
                    } else if (descriptionType == QLatin1String("url")) {
                        value = KStringHandler::tagUrls(value.toHtmlEscaped());
                        addUrl = true;
                    }
                    break;
                }
            }
            QVariantHash customFieldObject;
            customFieldObject.insert(QStringLiteral("title"), key);
            customFieldObject.insert(QStringLiteral("value"), value);

            if (addUrl) {
                customFieldsUrl.append(customFieldObject);
            } else {
                customFields.append(customFieldObject);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QString custom : customs) {
            if (custom.startsWith(QLatin1String("KADDRESSBOOK-"))) {
                custom.remove(QStringLiteral("KADDRESSBOOK-X-"));
                custom.remove(QStringLiteral("KADDRESSBOOK-"));

                int pos = custom.indexOf(QLatin1Char(':'));
                QString key = custom.left(pos);
                QString value = custom.mid(pos + 1);

                // convert anniversary correctly
                if (key == QLatin1String("Anniversary") || key == QLatin1String("ANNIVERSARY")) {
                    const QDateTime dateTime = QDateTime::fromString(value, Qt::ISODate);
                    value = QLocale().toString(dateTime.date());
                } else if (key == QLatin1String("BlogFeed") || key == QLatin1String("BLOGFEED")) {      // blog is handled separated
                    continue;
                } else if (blacklistedKeys.contains(key)) {
                    continue;
                }

                // check whether we have a mapping for the title
                const QMap<QString, QString>::ConstIterator keyIt = titleMap.constFind(key);
                bool needToEscape = true;
                if (keyIt != titleMap.constEnd()) {
                    key = keyIt.value();
                } else {
                    // check whether it is a custom local field
                    for (const QVariantMap &description : customFieldDescriptions()) {
                        if (description.value(QStringLiteral("key")).toString() == key) {
                            key = description.value(QStringLiteral("title")).toString();
                            const QString descriptionType = description.value(QStringLiteral("type")).toString();
                            if (descriptionType == QLatin1String("boolean")) {
                                if (value == QLatin1String("true")) {
                                    value = i18nc("Boolean value", "yes");
                                } else {
                                    value = i18nc("Boolean value", "no");
                                }
                            } else if (descriptionType == QLatin1String("date")) {
                                const QDate date = QDate::fromString(value, Qt::ISODate);
                                value = QLocale().toString(date, QLocale::ShortFormat);
                            } else if (descriptionType == QLatin1String("time")) {
                                const QTime time = QTime::fromString(value, Qt::ISODate);
                                value = QLocale().toString(time);
                            } else if (descriptionType == QLatin1String("datetime")) {
                                const QDateTime dateTime = QDateTime::fromString(value, Qt::ISODate);
                                value = QLocale().toString(dateTime, QLocale::ShortFormat);
                            } else if (descriptionType == QLatin1String("url")) {
                                value = KStringHandler::tagUrls(value.toHtmlEscaped());
                                needToEscape = false;
                            }

                            break;
                        }
                    }
                }
                if (needToEscape) {
                    value = value.toHtmlEscaped();
                }
                customData += rowFmtStr1.arg(key).arg(value);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *widget : widgetList) {
        auto w = qobject_cast<PhoneWidget *>(widget);
        w->setReadOnly(readOnly);
    }
```

#### AUTO 


```{c}
auto address = item.payload<KContacts::Addressee>();
```

#### LAMBDA EXPRESSION 


```{c}
[this](QPoint pos) {
        const auto idx = mAddressesLocationView->indexAt(pos);
        if (!idx.isValid()) {
            return;
        }
        QMenu menu;
        auto action = menu.addAction(QIcon::fromTheme(QStringLiteral("edit-delete")), i18n("Remove Address"));
        action->setEnabled(!mReadOnly);
        connect(action, &QAction::triggered, this, [this, idx]() {
            const auto result = KMessageBox::questionYesNo(this, i18n("Do you really want to delete this address?"));
            if (result == KMessageBox::Yes) {
                mAddressModel->removeAddress(idx.row());
            }
        });
        menu.exec(mAddressesLocationView->viewport()->mapToGlobal(pos));
    }
```

#### AUTO 


```{c}
auto session = new Akonadi::Session("InternalEmailAddressSelectionWidgetModel", this);
```

#### AUTO 


```{c}
auto job = new ItemFetchJob(item, mParent);
```

#### AUTO 


```{c}
auto *filter = new ContactsWithEmailFilterModel(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Tag &tag : tags) {
        categories.append(tag.name());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &type : lst) {
        if (value.contains(type)) {
            mOldType = type;
            mMailType->setCurrentIndex(mMailType->findData(type));
            break;
        }
    }
```

#### AUTO 


```{c}
auto *rightJob = new Akonadi::ContactGroupExpandJob(rightContactGroup);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::EmailAddressSelection &selection : selectedAddress) {
        mInfo->append(QStringLiteral("%1: %2\n").arg(selection.name(), selection.email()));
    }
```

#### AUTO 


```{c}
auto *fetchJob = qobject_cast<Akonadi::ItemFetchJob *>(job);
```

#### AUTO 


```{c}
auto model = new Akonadi::EmailAddressSelectionModel(q);
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) {
            slotCollectionsFetched(job);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Tag &tag : tags) {
        categories.append(tag.url().url());
    }
```

#### AUTO 


```{c}
auto *editor = new QSpinBox(parent);
```

#### AUTO 


```{c}
auto *job = new ItemCreateJob(item, d->mDefaultCollection);
```

#### AUTO 


```{c}
auto *label = w.findChild<QLabel *>(QStringLiteral("label"));
```

#### AUTO 


```{c}
auto blogFeedLabel = new QLabel(i18n("Blog Feed"), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *widget : widgetList) {
        PhoneWidget *w = qobject_cast<PhoneWidget *>(widget);
        KContacts::PhoneNumber number = w->storePhone();
        if (!number.isEmpty()) {
            phoneNumbers << number;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QUrl &url) {
        d->slotMailClicked(url);
    }
```

#### AUTO 


```{c}
auto lineEdit = qobject_cast<QLineEdit *>(editor);
```

#### AUTO 


```{c}
auto contact = item.payload<KContacts::Addressee>();
```

#### AUTO 


```{c}
auto *photoLayout = new QVBoxLayout;
```

#### AUTO 


```{c}
const auto collection = index.data(Akonadi::EntityTreeModel::CollectionRole).value<Akonadi::Collection>();
```

#### AUTO 


```{c}
auto *widget = qobject_cast<QDateTimeEdit *>(editor);
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *widget : widgetList) {
        auto w = qobject_cast<MailWidget *>(widget);
        KContacts::Email newEmail = w->email();
        if (newEmail.isValid()) {
            emailList << newEmail;
        }
    }
```

#### AUTO 


```{c}
auto *regionlabel = w.findChild<QLabel *>(QStringLiteral("regionlabel"));
```

#### AUTO 


```{c}
const auto c
```

#### RANGE FOR STATEMENT 


```{c}
for (Akonadi::ContactEditorPagePlugin *plugin : qAsConst(mCustomPages)) {
        mTabWidget->addTab(plugin, plugin->title());
    }
```

#### AUTO 


```{c}
auto *layout = new QFormLayout;
```

#### AUTO 


```{c}
auto buttonBox = new QDialogButtonBox(QDialogButtonBox::Ok, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (ContactEditor::ContactEditorPagePlugin *plugin : qAsConst(d->mCustomPages)) {
            plugin->loadContact(contact);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QUrl &url) { d->slotUrlClicked(url);}
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { Q_EMIT q->doubleClicked(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &description : std::as_const(mDescriptions)) {
            mMaxDescriptionWidth = qMax(mMaxDescriptionWidth, metrics.boundingRect(description).width());
        }
```

#### AUTO 


```{c}
auto *preferredcheckbox = w.findChild<QCheckBox *>(QStringLiteral("preferredcheckbox"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVariant &description : descriptions) {
        mLocalCustomFields.append(CustomField::fromVariantMap(description.toMap(), CustomField::LocalScope));
    }
```

#### AUTO 


```{c}
const auto selectedAddress = dlg.selectedAddresses();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVariant &entry : std::as_const(localCustomFieldDescriptions)) {
            customFieldDescriptions << entry.toMap();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            slotNoDate();
        }
```

#### AUTO 


```{c}
auto edit = new KLineEdit(this);
```

#### AUTO 


```{c}
auto *collectionFetchJob = new Akonadi::CollectionFetchJob(mItem.parentCollection(), Akonadi::CollectionFetchJob::Base);
```

#### LAMBDA EXPRESSION 


```{c}
[this, idx]() {
            const auto result = KMessageBox::questionYesNo(this,
                                                           i18n("Do you really want to delete this address?"),
                                                           QString(),
                                                           KStandardGuiItem::del(),
                                                           KStandardGuiItem::cancel());
            if (result == KMessageBox::Yes) {
                mAddressModel->removeAddress(idx.row());
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KContacts::PhoneNumber &number : rawContact.phoneNumbers()) {

        QString dispLabel = number.typeLabel().replace(QLatin1Char(' '), QStringLiteral("&nbsp;"));
        QString dispValue = QStringLiteral("<a href=\"phone:?index=%1\">%2</a>").arg(counter).arg(number.number().toHtmlEscaped());
        if (number.type() & KContacts::PhoneNumber::Cell) {
            QString dispIcon = QStringLiteral("<a href=\"sms:?index=%1\" title=\"%2\"><img src=\"sms_icon\" align=\"top\"/>")
                               .arg(counter)
                               .arg(i18nc("@info:tooltip", "Send SMS"));
            dynamicPart += rowFmtStr2
                           .arg(dispLabel)
                           .arg(dispValue)
                           .arg(dispIcon);
        } else {
            dynamicPart += rowFmtStr1
                           .arg(dispLabel)
                           .arg(dispValue);
        }

        ++counter;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                d->resolveGroup();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KContacts::PhoneNumber &number : phoneNumbers) {
        QString dispLabel = number.typeLabel().replace(QLatin1Char(' '), QStringLiteral("&nbsp;"));
        QString dispValue = QStringLiteral("<a href=\"phone:?index=%1\">%2</a>").arg(counter).arg(number.number().toHtmlEscaped());
        if (number.type() & KContacts::PhoneNumber::Cell) {
            QString dispIcon = QStringLiteral("<a href=\"sms:?index=%1\" title=\"%2\"><img src=\"sms_icon\" align=\"top\"/>")
                               .arg(counter)
                               .arg(i18nc("@info:tooltip", "Send SMS"));
            dynamicPart += rowFmtStr2
                           .arg(dispLabel, dispValue, dispIcon);
        } else {
            dynamicPart += rowFmtStr1
                           .arg(dispLabel, dispValue);
        }

        ++counter;
    }
```

#### AUTO 


```{c}
auto *layout = new QVBoxLayout(q);
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) { parentCollectionFetchDone(job); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Akonadi::Item &item, const QSet<QByteArray> &arrays) {
        itemChanged(item, arrays);
    }
```

#### AUTO 


```{c}
auto *streetlabel = w.findChild<QLabel *>(QStringLiteral("streetlabel"));
```

#### AUTO 


```{c}
auto *mNickName = editor.findChild<KLineEdit *>(QStringLiteral("nickname"));
```

#### AUTO 


```{c}
const auto leftContact = leftItem.payload<KContacts::Addressee>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &ba : supportedImage) {
        if (!filter.isEmpty()) {
            filter += QLatin1Char(' ');
        }
        filter += QLatin1String("*.") + QString::fromLatin1(ba);
    }
```

#### AUTO 


```{c}
auto *comboBox = qobject_cast<KComboBox *>(editor);
```

#### AUTO 


```{c}
auto *rightLayout = new QVBoxLayout;
```

#### AUTO 


```{c}
auto postofficeboxlineedit = w.findChild<KLineEdit *>(QStringLiteral("postofficeboxlineedit"));
```

#### AUTO 


```{c}
GRANTLEE_MAKE_GADGET(KAddressBookGrantlee::ContactGrantleeWrapper)
```

#### AUTO 


```{c}
auto fetchJob = qobject_cast<Akonadi::CollectionFetchJob *>(job);
```

#### AUTO 


```{c}
const auto addresses = rawContact.addresses();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &protocol : protocols) {
        mProtocolCombo->addItem(QIcon::fromTheme(IMProtocols::self()->icon(protocol)),
                                IMProtocols::self()->name(protocol),
                                protocol);
    }
```

#### AUTO 


```{c}
const auto phoneNumbers = rawContact.phoneNumbers();
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) {
        d->itemFetchDone(job);
    }
```

#### AUTO 


```{c}
auto *widget = qobject_cast<QTimeEdit *>(editor);
```

#### AUTO 


```{c}
auto *topLayout = new QVBoxLayout(this);
```

#### AUTO 


```{c}
auto fetchJob = qobject_cast<ItemFetchJob *>(job);
```

#### AUTO 


```{c}
auto job = new ContactGroupExpandJob(group);
```

#### AUTO 


```{c}
const auto pix = imageResource.value<QPixmap>();
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *widget : widgetList) {
        auto w = qobject_cast<MessagingWidget *>(widget);
        w->setReadOnly(readOnly);
    }
```

#### AUTO 


```{c}
auto job = new ItemCreateJob(item, d->mDefaultCollection);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {d->slotEditItem(); }
```

#### AUTO 


```{c}
auto *model = new Akonadi::EmailAddressSelectionModel(q);
```

#### RANGE FOR STATEMENT 


```{c}
for (ContactEditor::ContactEditorPagePlugin *plugin : std::as_const(d->mCustomPages)) {
            plugin->storeContact(contact);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KContacts::Address &address : rawContact.addresses()) {
        QString formattedAddress;

        if (address.label().isEmpty()) {
            formattedAddress = address.formattedAddress().trimmed().toHtmlEscaped();
        } else {
            formattedAddress = address.label().toHtmlEscaped();
        }

        formattedAddress.replace(QRegularExpression(QStringLiteral("\n+")), QStringLiteral("<br>"));

        const QString url = QStringLiteral("<a href=\"address:?index=%1\" title=\"%2\"><img src=\"map_icon\" alt=\"%2\"/></a>")
                            .arg(counter)
                            .arg(i18nc("@info:tooltip", "Show address on map"));
        counter++;

        dynamicPart += rowFmtStr2
                       .arg(KContacts::Address::typeLabel(address.type()), formattedAddress, url);
    }
```

#### AUTO 


```{c}
auto regionlineedit = w.findChild<KLineEdit *>(QStringLiteral("regionlineedit"));
```

#### AUTO 


```{c}
auto filter = new Akonadi::ContactsFilterProxyModel(q);
```

#### RANGE FOR STATEMENT 


```{c}
for (const CustomField &customField : std::as_const(customFields)) {
        if (customField.scope() == CustomField::GlobalScope) {
            globalCustomFields << customField;
        }
    }
```

#### AUTO 


```{c}
auto *widget = qobject_cast<QSpinBox *>(editor);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::EmailAddressSelection &selection : mAddressesWidget->selectedAddresses()) {
        mInfo->append(QStringLiteral("%1: %2\n").arg(selection.name()).arg(selection.email()));
    }
```

#### AUTO 


```{c}
auto *changeRecorder = new Akonadi::ChangeRecorder(this);
```

#### AUTO 


```{c}
auto *leftLayout = new QVBoxLayout;
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) {d->slotParentCollectionFetched(job);}
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *widget : widgetList) {
        auto *w = qobject_cast<MailWidget *>(widget);
        w->setReadOnly(readOnly);
    }
```

#### AUTO 


```{c}
auto job = new Akonadi::ItemCreateJob(item, d->mDefaultCollection);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            slotNextWeek();
        }
```

#### AUTO 


```{c}
auto job = new ItemFetchJob(item);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &email : rawContact.emails()) {
        const QString type = i18nc("a contact's email address", "Email");

        const QString fullEmail = QString::fromLatin1(QUrl::toPercentEncoding(rawContact.fullEmail(email)));

        dynamicPart += rowFmtStr1.arg(type, QStringLiteral("<a href=\"mailto:%1\">%2</a>").arg(fullEmail, email));
    }
```

#### AUTO 


```{c}
auto createJob = static_cast<Akonadi::TagCreateJob *>(job);
```

#### AUTO 


```{c}
auto searchJob = new Akonadi::ContactSearchJob(this);
```

#### AUTO 


```{c}
auto *collectionFetchJob = new Akonadi::CollectionFetchJob(mItem.parentCollection(),
                                                                                          Akonadi::CollectionFetchJob::Base);
```

#### AUTO 


```{c}
auto *customFieldsListWidget = w.findChild<ContactEditor::CustomFieldsListWidget *>(QStringLiteral("customfieldslistwidget"));
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        Q_EMIT q->doubleClicked();
    }
```

#### AUTO 


```{c}
const auto collectionMimeTypesSet = collection.contentMimeTypes();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { slotTomorrow(); }
```

#### AUTO 


```{c}
auto *etm = qobject_cast<Akonadi::EntityTreeModel *>(mModel)
```

#### AUTO 


```{c}
auto *modifybuttonaddress = w.findChild<QPushButton *>(QStringLiteral("modifybuttonaddress"));
```

#### AUTO 


```{c}
auto w = qobject_cast<MessagingWidget *>(*wIt);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &description : qAsConst(mDescriptions)) {
            mMaxDescriptionWidth = qMax(mMaxDescriptionWidth, metrics.boundingRect(description).width());
        }
```

#### AUTO 


```{c}
auto job = new KIO::CommandLauncherJob(command);
```

#### AUTO 


```{c}
auto removeButton = w.findChild<QToolButton *>(QStringLiteral("removebutton"));
```

#### AUTO 


```{c}
const auto selectedAddress =  dlg.selectedAddresses();
```

#### AUTO 


```{c}
auto action = menu.addAction(QIcon::fromTheme(QStringLiteral("edit-delete")), i18n("Remove Address"));
```

#### AUTO 


```{c}
auto widget = qobject_cast<QDateTimeEdit *>(editor);
```

#### RANGE FOR STATEMENT 


```{c}
for (const CustomField &oldCustomField : qAsConst(mLocalCustomFields)) {
        if (oldCustomField.scope() != CustomField::ExternalScope) {

            bool fieldStillExists = false;
            for (const CustomField &newCustomField : qAsConst(customFields)) {
                if (newCustomField.scope() != CustomField::ExternalScope) {
                    if (newCustomField.key() == oldCustomField.key()) {
                        fieldStillExists = true;
                        break;
                    }
                }
            }

            if (!fieldStillExists) {
                contact.removeCustom(QStringLiteral("KADDRESSBOOK"), oldCustomField.key());
            }
        }
    }
```

#### AUTO 


```{c}
auto w = new MessagingWidget(parent);
```

#### AUTO 


```{c}
auto *customFieldEditorWidget = w.findChild<ContactEditor::CustomFieldEditorWidget *>(QStringLiteral("customfieldeditorwidget"));
```

#### AUTO 


```{c}
auto page = new QWidget(this);
```

#### AUTO 


```{c}
auto *add = w.findChild<QToolButton *>(QStringLiteral("addbutton"));
```

#### AUTO 


```{c}
auto *fieldname = w.findChild<QLineEdit *>(QStringLiteral("fieldname"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &blacklistEntry : qAsConst(blacklist)) {
                upperCaseBlacklist << blacklistEntry.toUpper();
            }
```

#### AUTO 


```{c}
auto searchLayout = new QHBoxLayout;
```

#### AUTO 


```{c}
auto mAllowRemoteContent = w.findChild<QCheckBox *>(QStringLiteral("mAllowRemoteContent"));
```

#### AUTO 


```{c}
auto *countrycombobox = w.findChild<KComboBox *>(QStringLiteral("countrycombobox"));
```

#### AUTO 


```{c}
auto w = qobject_cast<MailWidget *>(widget);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto c : str) {
        // case folding
        const auto n = c.toCaseFolded();

        // if the character has a canonical decomposition use that and skip the
        // combining diacritic markers following it
        // see https://en.wikipedia.org/wiki/Unicode_equivalence
        // see https://en.wikipedia.org/wiki/Combining_character
        if (n.decompositionTag() == QChar::Canonical) {
            out.push_back(n.decomposition().at(0));
        }
        // handle compatibility compositions such as ligatures
        // see https://en.wikipedia.org/wiki/Unicode_compatibility_characters
        else if (n.decompositionTag() == QChar::Compat && n.isLetter() && n.script() == QChar::Script_Latin) {
            out.append(n.decomposition());
        } else {
            out.push_back(n);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KContacts::Addressee &contact : listContact) {
                group.append(KContacts::ContactGroup::Data(contact.realName(), contact.preferredEmail()));
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KContacts::PhoneNumber &number : rawContact.phoneNumbers()) {
        QString dispLabel = number.typeLabel().replace(QLatin1Char(' '), QStringLiteral("&nbsp;"));
        QString dispValue = QStringLiteral("<a href=\"phone:?index=%1\">%2</a>").arg(counter).arg(number.number().toHtmlEscaped());
        if (number.type() & KContacts::PhoneNumber::Cell) {
            QString dispIcon = QStringLiteral("<a href=\"sms:?index=%1\" title=\"%2\"><img src=\"sms_icon\" align=\"top\"/>")
                               .arg(counter)
                               .arg(i18nc("@info:tooltip", "Send SMS"));
            dynamicPart += rowFmtStr2
                           .arg(dispLabel)
                           .arg(dispValue)
                           .arg(dispIcon);
        } else {
            dynamicPart += rowFmtStr1
                           .arg(dispLabel)
                           .arg(dispValue);
        }

        ++counter;
    }
```

#### AUTO 


```{c}
auto lineEdit = static_cast<ContactLineEdit *>(editor);
```

#### AUTO 


```{c}
auto topLayout = new QVBoxLayout(this);
```

#### AUTO 


```{c}
auto buttonLayout = new QGridLayout;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &custom : customs) {
        QString app, name, value;
        ContactEditor::Utils::splitCustomField(custom, app, name, value);

        // skip all well-known fields that have separated editor widgets
        if (custom.startsWith(QStringLiteral("messaging/"))) {       // IM addresses
            continue;
        }

        if (app == QLatin1String("KADDRESSBOOK")) {
            static QSet<QString> blacklist;
            if (blacklist.isEmpty()) {
                blacklist << QStringLiteral("BlogFeed")
                          << QStringLiteral("X-IMAddress")
                          << QStringLiteral("X-Profession")
                          << QStringLiteral("X-Office")
                          << QStringLiteral("X-ManagersName")
                          << QStringLiteral("X-AssistantsName")
                          << QStringLiteral("X-Anniversary")
                          << QStringLiteral("X-SpousesName")
                          << QStringLiteral("MailPreferedFormatting")
                          << QStringLiteral("MailAllowToRemoteContent")
                          << QStringLiteral("CRYPTOPROTOPREF")
                          << QStringLiteral("OPENPGPFP")
                          << QStringLiteral("SMIMEFP")
                          << QStringLiteral("CRYPTOSIGNPREF")
                          << QStringLiteral("CRYPTOENCRYPTPREF");
            }
            QSet<QString> upperCaseBlacklist;
            for (const QString &blacklistEntry : qAsConst(blacklist)) {
                upperCaseBlacklist << blacklistEntry.toUpper();
            }
            blacklist.unite(upperCaseBlacklist);
            if (blacklist.contains(name)) {     // several KAddressBook specific fields
                continue;
            }
        }

        // check whether it correspond to a local custom field
        bool isLocalCustomField = false;
        const int localCustomFieldsCount(mLocalCustomFields.count());
        for (int i = 0; i < localCustomFieldsCount; ++i) {
            if (mLocalCustomFields[i].key() == name) {
                mLocalCustomFields[i].setValue(value);
                isLocalCustomField = true;
                break;
            }
        }

        // check whether it correspond to a global custom field
        bool isGlobalCustomField = false;
        const int globalCustomFieldsCount(globalCustomFields.count());
        for (int i = 0; i < globalCustomFieldsCount; ++i) {
            if (globalCustomFields[i].key() == name) {
                globalCustomFields[i].setValue(value);
                isGlobalCustomField = true;
                break;
            }
        }

        // if not local and not global it must be external
        if (!isLocalCustomField && !isGlobalCustomField) {
            if (app == QLatin1String("KADDRESSBOOK")) {
                // however if it starts with our prefix it might be that this is an outdated
                // global custom field, in this case treat it as local field of type text
                CustomField customField(name, name, CustomField::TextType, CustomField::LocalScope);
                customField.setValue(value);

                mLocalCustomFields << customField;
            } else {
                // it is really an external custom field
                const QString key = app + QLatin1Char('-') + name;
                CustomField customField(key, key, CustomField::TextType, CustomField::ExternalScope);
                customField.setValue(value);

                externalCustomFields << customField;
            }
        }
    }
```

#### AUTO 


```{c}
auto changeRecorder = new Akonadi::ChangeRecorder(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (QString custom : customs) {
            if (custom.startsWith(QStringLiteral("KADDRESSBOOK-"))) {
                custom.remove(QStringLiteral("KADDRESSBOOK-X-"));
                custom.remove(QStringLiteral("KADDRESSBOOK-"));

                int pos = custom.indexOf(QLatin1Char(':'));
                QString key = custom.left(pos);
                QString value = custom.mid(pos + 1);

                // convert anniversary correctly
                if (key == QLatin1String("Anniversary") || key == QLatin1String("ANNIVERSARY")) {
                    const QDateTime dateTime = QDateTime::fromString(value, Qt::ISODate);
                    value = QLocale().toString(dateTime.date());
                } else if (key == QLatin1String("BlogFeed") || key == QLatin1String("BLOGFEED")) {      // blog is handled separated
                    continue;
                } else if (blacklistedKeys.contains(key)) {
                    continue;
                }

                // check whether we have a mapping for the title
                const QMap<QString, QString>::ConstIterator keyIt = titleMap.constFind(key);
                bool needToEscape = true;
                if (keyIt != titleMap.constEnd()) {
                    key = keyIt.value();
                } else {
                    // check whether it is a custom local field
                    for (const QVariantMap &description : customFieldDescriptions()) {
                        if (description.value(QStringLiteral("key")).toString() == key) {
                            key = description.value(QStringLiteral("title")).toString();
                            const QString descriptionType = description.value(QStringLiteral("type")).toString();
                            if (descriptionType == QLatin1String("boolean")) {
                                if (value == QLatin1String("true")) {
                                    value = i18nc("Boolean value", "yes");
                                } else {
                                    value = i18nc("Boolean value", "no");
                                }
                            } else if (descriptionType == QLatin1String("date")) {
                                const QDate date = QDate::fromString(value, Qt::ISODate);
                                value = QLocale().toString(date, QLocale::ShortFormat);
                            } else if (descriptionType == QLatin1String("time")) {
                                const QTime time = QTime::fromString(value, Qt::ISODate);
                                value = QLocale().toString(time);
                            } else if (descriptionType == QLatin1String("datetime")) {
                                const QDateTime dateTime = QDateTime::fromString(value, Qt::ISODate);
                                value = QLocale().toString(dateTime, QLocale::ShortFormat);
                            } else if (descriptionType == QLatin1String("url")) {
                                value = KStringHandler::tagUrls(value.toHtmlEscaped());
                                needToEscape = false;
                            }

                            break;
                        }
                    }
                }
                if (needToEscape) {
                    value = value.toHtmlEscaped();
                }
                customData += rowFmtStr1.arg(key).arg(value);
            }
        }
```

#### AUTO 


```{c}
auto *w = qobject_cast<WebWidget *>(*wIt);
```

#### AUTO 


```{c}
auto modifybuttonaddress = w.findChild<QPushButton *>(QStringLiteral("modifybuttonaddress"));
```

#### AUTO 


```{c}
auto w = new PhoneWidget(parent);
```

#### AUTO 


```{c}
auto gridLayout = new QGridLayout;
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->updateActions();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Collection &collection : lstColls) {
            if (Akonadi::Collection::CanCreateItem & collection.rights()) {
                canCreateItemCollections.append(collection);
            }
        }
```

#### AUTO 


```{c}
auto *mainLayout = new QGridLayout(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KContacts::Addressee &contact : lstContacts) {
                group.append(KContacts::ContactGroup::Data(contact.realName(), contact.preferredEmail()));
            }
```

#### AUTO 


```{c}
auto job = new ItemFetchJob(mItem);
```

#### RANGE FOR STATEMENT 


```{c}
for (ContactEditor::ContactEditorPagePlugin *plugin : std::as_const(d->mCustomPages)) {
            plugin->setReadOnly(readOnly);
        }
```

#### AUTO 


```{c}
auto *mBlogFeed = editor.findChild<KLineEdit *>(QStringLiteral("blogfeed"));
```

