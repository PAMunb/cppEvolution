#### RANGE FOR STATEMENT 


```{c}
for (auto& e : values.keys()) {
                map.insert(e, values.value(e).toString());
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (KWallet::Entry* entry : lst) {
            rc.insert(entry->key(), entry->value());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &e : map.keys()) {
        json.insert(e, QJsonValue::fromVariant(QVariant(map.value(e))));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &key: entries) {

                    int entryType = invokeAndCheck<int>(
                        [this, handle4, folder, key, appId] { return _kde4_daemon->entryType(handle4, folder, key, appId); },
                        i18n("Cannot retrieve key %1 info. Aborting.", key));
                    
                    // handle the case where the entries are already there
                    if (_kf5_daemon->hasEntry(handle5, folder, key, appId)) {
                        emit progressMessage(i18n("* SKIPPING entry %1 in folder %2 as it seems already migrated", key, folder));
                    } else {
                        QByteArray entry = invokeAndCheck<QByteArray>(
                            [this, handle4, folder, key, appId] { return _kde4_daemon->readEntry(handle4, folder, key, appId); },
                                                                      i18n("Cannot retrieve key %1 data. Aborting.", key));
                        if ( _kf5_daemon->writeEntry(handle5, folder, key, entry, entryType, appId) != 0 ) {
                            auto msg = i18n("Cannot write entry %1 in the new wallet. Aborting.", key);
                            emit progressMessage(msg);
                            throw MigrationException(msg);
                        }
                    }
                }
```

#### AUTO 


```{c}
auto el = theWallet->entryList();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto e: el) {
          std::cout << e.toUtf8().constData() << std::endl;
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &folder : folders) {
                emit progressMessage(i18n("* Migrating folder %1", folder));

                const QStringList entries = invokeAndCheck<QStringList>(
                    this, [this, handle4, folder, appId] { return _kde4_daemon->entryList(handle4, folder, appId); },
                    i18n("Cannot retrieve folder %1 entries. Aborting.", folder));

                for (const QString &key : entries) {

                    int entryType = invokeAndCheck<int>(
                        this, [this, handle4, folder, key, appId] { return _kde4_daemon->entryType(handle4, folder, key, appId); },
                        i18n("Cannot retrieve key %1 info. Aborting.", key));

                    // handle the case where the entries are already there
                    if (_kf5_daemon->hasEntry(handle5, folder, key, appId)) {
                        emit progressMessage(i18n("* SKIPPING entry %1 in folder %2 as it seems already migrated", key, folder));
                    } else {
                        QByteArray entry = invokeAndCheck<QByteArray>(
                            this, [this, handle4, folder, key, appId] { return _kde4_daemon->readEntry(handle4, folder, key, appId); },
                            i18n("Cannot retrieve key %1 data. Aborting.", key));
                        if ( _kf5_daemon->writeEntry(handle5, folder, key, entry, entryType, appId) != 0 ) {
                            auto msg = i18n("Cannot write entry %1 in the new wallet. Aborting.", key);
                            emit progressMessage(msg);
                            throw MigrationException(msg);
                        }
                    }
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KWalletAppHandlePair &s : sessremove) {
        b = getWallet(s.first, s.second);
        if (b) {
            b->deref();
            internalClose(b, s.second, false);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool t) {
                emit this->completeChanged();
            }
```

#### AUTO 


```{c}
auto written = sf.write(wholeFile);
```

#### AUTO 


```{c}
const auto errorStr = KWallet::Backend::openRCToString(rc);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            d->walletServiceUnregistered();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &f : fl) {
            std::cout << f.toUtf8().constData() << std::endl;
            Q_ASSERT(theWallet->setFolder(f));
            const auto el = theWallet->entryList();
            for (auto &e : el) {
                std::cout << "\t" << e.toUtf8().constData() << std::endl;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KWalletAppHandlePair &s : sessremove) {
        _sessions.removeSession(s.first, service, s.second);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto e : map.keys()) {
        json.insert(e, QJsonValue::fromVariant(QVariant(map.value(e))));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &appid : sessionKeys) {
        const auto lst = m_sessions[appid];
        for (const Session *sess : lst) {
            Q_ASSERT(sess);
            if (sess->m_service == service) {
                rc.append(qMakePair(appid, sess->m_handle));
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto e: el) {
              std::cout << "\t" << e.toUtf8().constData() << std::endl;
          }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& e: el) {
              std::cout << "\t" << e.toUtf8().constData() << std::endl;
          }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QList<Session *> &l : std::as_const(m_sessions)) {
        qDeleteAll(l);
    }
```

#### AUTO 


```{c}
auto fl = theWallet->folderList();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto e : el) {
        std::cout << e.toUtf8().constData() << std::endl;
    }
```

#### AUTO 


```{c}
auto qreply = _kde_kwalletd4.call(QStringLiteral("quit"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const KWalletAppHandlePair& s : sessremove) {
        _sessions.removeSession(s.first, service, s.second);
    }
```

#### AUTO 


```{c}
const auto lst = b->readEntryList(key);
```

#### AUTO 


```{c}
auto e
```

#### AUTO 


```{c}
auto f
```

#### LAMBDA EXPRESSION 


```{c}
[this, handle4, folder, key, appId] { return _kde4_daemon->readEntry(handle4, folder, key, appId); }
```

#### LAMBDA EXPRESSION 


```{c}
[](QSessionManager &sm) {
        sm.setRestartHint(QSessionManager::RestartNever);
    }
```

#### AUTO 


```{c}
auto i
```

#### RANGE FOR STATEMENT 


```{c}
for (auto f: fl) {
          std::cout << f.toUtf8().constData() << std::endl;
          Q_ASSERT(theWallet->setFolder(f));
          auto el = theWallet->entryList();
          for (auto e: el) {
              std::cout << "\t" << e.toUtf8().constData() << std::endl;
          }
      }
```

#### AUTO 


```{c}
auto bus = QDBusConnection::sessionBus().interface();
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool t) {
                emit completeChanged();
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this] { return _kde4_daemon->wallets(); }
```

#### AUTO 


```{c}
auto wl = Wallet::walletList();
```

#### RANGE FOR STATEMENT 


```{c}
for (int timerId : std::as_const(_timers)) {
        killTimer(timerId);
    }
```

#### AUTO 


```{c}
auto& e
```

#### AUTO 


```{c}
auto& f
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& e: el) {
          std::cout << e.toUtf8().constData() << std::endl;
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &e : values.keys()) {
                map.insert(e, values.value(e).toString());
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KWalletAppHandlePair& s : sessremove) {
        b = getWallet(s.first, s.second);
        if (b) {
            b->deref();
            internalClose(b, s.second, false);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KWallet::Entry* entry : lst) {
            if (entry->type() == KWallet::Wallet::Map) {
                rc.insert(entry->key(), entry->map());
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (KWallet::Entry* entry : lst) {
            if (entry->type() == KWallet::Wallet::Password) {
                rc.insert(entry->key(), entry->password());
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto i : lst) {
        if (!walletsInDisk.contains(i->walletName())) {
            internalClose(i, _wallets.key(i), true, false);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &e : el) {
        std::cout << e.toUtf8().constData() << std::endl;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (int timerId : qAsConst(_timers)) {
        killTimer(timerId);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Session *sess : lst) {
            Q_ASSERT(sess);
            if (sess->m_service == service) {
                rc.append(qMakePair(appid, sess->m_handle));
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, wallet, wid, appId] { return _kde4_daemon->open(wallet, wid, appId); }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& f: fl) {
          std::cout << f.toUtf8().constData() << std::endl;
          Q_ASSERT(theWallet->setFolder(f));
          const auto el = theWallet->entryList();
          for (auto& e: el) {
              std::cout << "\t" << e.toUtf8().constData() << std::endl;
          }
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &appid : std::as_const(appremove)) {
        m_sessions.remove(appid);
    }
```

#### AUTO 


```{c}
const auto fl = theWallet->folderList();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QFileInfo& fi : list) {
        QString fn = fi.fileName();
        if (fn.endsWith(QLatin1String(".kwl"))) {
            fn.truncate(fn.length() - 4);
        }
        rc += fn;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KWallet::Entry *entry : lst) {
            rc.insert(entry->key(), entry->value());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &appid : qAsConst(appremove)) {
        m_sessions.remove(appid);
    }
```

#### AUTO 


```{c}
auto appId = i18n("KDE Wallet Migration Agent");
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &e : el) {
                std::cout << "\t" << e.toUtf8().constData() << std::endl;
            }
```

#### AUTO 


```{c}
auto reply = bus->registerService(QStringLiteral("org.kde.kwalletd"), QDBusConnectionInterface::QueueService);
```

#### RANGE FOR STATEMENT 


```{c}
for (KWallet::Entry *entry : lst) {
            if (entry->type() == KWallet::Wallet::Map) {
                rc.insert(entry->key(), entry->map());
            }
        }
```

#### AUTO 


```{c}
auto &fi
```

#### AUTO 


```{c}
const auto lst = m_sessions[appid];
```

#### AUTO 


```{c}
auto disableSessionManagement = [](QSessionManager &sm) {
        sm.setRestartHint(QSessionManager::RestartNever);
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const QList<Session *> &l : qAsConst(m_sessions)) {
        qDeleteAll(l);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QFileInfo &fi : list) {
        QString fn = fi.fileName();
        if (fn.endsWith(QLatin1String(".kwl"))) {
            fn.truncate(fn.length() - 4);
        }
        rc += fn;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &appid : lst) {
        if (hasSession(appid, handle)) {
            rc.append(appid);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KWallet::Entry *entry : lst) {
            if (entry->type() == KWallet::Wallet::Password) {
                rc.insert(entry->key(), entry->password());
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& e : el) {
        std::cout << e.toUtf8().constData() << std::endl;
    }
```

#### AUTO 


```{c}
const auto lst = m_sessions.keys();
```

#### AUTO 


```{c}
const auto el = theWallet->entryList();
```

#### AUTO 


```{c}
const auto list = dir.entryInfoList();
```

#### AUTO 


```{c}
const auto lst = m_sessions.uniqueKeys();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &appid : sessionKeys) {
        QList<Session *>::iterator it;
        QList<Session *>::iterator end = m_sessions[appid].end();
        for (it = m_sessions[appid].begin(); it != end; ++it) {
            Q_ASSERT(*it);
            if ((*it)->m_handle == handle) {
                delete *it;
                *it = nullptr;
                numrem++;
            }
        }
        // remove all zeroed sessions
        m_sessions[appid].removeAll(nullptr);
        if (m_sessions[appid].isEmpty()) {
            appremove.append(appid);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &wallet : qAsConst(wallets)) {
            emit progressMessage(i18n("Migrating wallet: %1", wallet));
            emit progressMessage(i18n("* Creating KF5 wallet: %1", wallet));

            int handle5 = -1;
            if (withoutWizard && (_pam_hash != nullptr)) {
                // see BUG 351056 for why this hacky code
                // If the user has several wallets, all the values will be
                // merged into the single LocalWallet
                handle5 = _kf5_daemon->pamOpen(KWallet::Wallet::LocalWallet(), _pam_hash, 0);
            } else {
                handle5 = _kf5_daemon->internalOpen(appId, wallet, false, 0, true, QString());
            }
            if (handle5 <0) {
                emit progressMessage(i18n("ERROR when attempting new wallet creation. Aborting."));
                return false;
            }

            int handle4 = invokeAndCheck<int>(
                this, [this, wallet, wid, appId] { return _kde4_daemon->open(wallet, wid, appId); },
                i18n("Cannot open KDE4 wallet named: %1", wallet));
            emit progressMessage(i18n("* Opened KDE4 wallet: %1", wallet));

            const QStringList folders = invokeAndCheck<QStringList>(
                this, [this, handle4, appId] { return _kde4_daemon->folderList(handle4, appId); },
                i18n("Cannot retrieve folder list. Aborting."));

            for (const QString &folder : folders) {
                emit progressMessage(i18n("* Migrating folder %1", folder));

                const QStringList entries = invokeAndCheck<QStringList>(
                    this, [this, handle4, folder, appId] { return _kde4_daemon->entryList(handle4, folder, appId); },
                    i18n("Cannot retrieve folder %1 entries. Aborting.", folder));

                for (const QString &key : entries) {

                    int entryType = invokeAndCheck<int>(
                        this, [this, handle4, folder, key, appId] { return _kde4_daemon->entryType(handle4, folder, key, appId); },
                        i18n("Cannot retrieve key %1 info. Aborting.", key));

                    // handle the case where the entries are already there
                    if (_kf5_daemon->hasEntry(handle5, folder, key, appId)) {
                        emit progressMessage(i18n("* SKIPPING entry %1 in folder %2 as it seems already migrated", key, folder));
                    } else {
                        QByteArray entry = invokeAndCheck<QByteArray>(
                            this, [this, handle4, folder, key, appId] { return _kde4_daemon->readEntry(handle4, folder, key, appId); },
                            i18n("Cannot retrieve key %1 data. Aborting.", key));
                        if ( _kf5_daemon->writeEntry(handle5, folder, key, entry, entryType, appId) != 0 ) {
                            auto msg = i18n("Cannot write entry %1 in the new wallet. Aborting.", key);
                            emit progressMessage(msg);
                            throw MigrationException(msg);
                        }
                    }
                }
            }

            //_kde4_daemon->close(handle4, false, appId);
            //_kf5_daemon->close(handle5, true, appId);
            _kf5_daemon->sync(handle5, appId);
            emit progressMessage(i18n("DONE migrating wallet\n"));
        }
```

#### AUTO 


```{c}
auto msg = i18n("Cannot write entry %1 in the new wallet. Aborting.", key);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &wallet : wallets) {
            emit progressMessage(i18n("Migrating wallet: %1</p>", wallet));
            emit progressMessage(i18n("* Creating KF5 wallet: %1", wallet));
            
            int handle5 = _kf5_daemon->internalOpen(appId, wallet, false, 0, true, QString());
            if (handle5 <0) {
                emit progressMessage(i18n("ERROR when attempting new wallet creation. Aborting."));
                return false;
            }
            
            int handle4 = invokeAndCheck<int>(
                [this, wallet, wid, appId] { return _kde4_daemon->open(wallet, wid, appId); },
                i18n("Cannot open KDE4 wallet named: %1", wallet));
            emit progressMessage(i18n("* Opened KDE4 wallet: %1", wallet));
            
            const QStringList folders = invokeAndCheck<QStringList>(
                [this, handle4, appId] { return _kde4_daemon->folderList(handle4, appId); },
                i18n("Cannot retrieve folder list. Aborting."));
            
            for (const QString &folder: folders) {
                emit progressMessage(i18n("* Migrating folder %1", folder));

                QStringList entries = invokeAndCheck<QStringList>(
                    [this, handle4, folder, appId] { return _kde4_daemon->entryList(handle4, folder, appId); },
                    i18n("Cannot retrieve folder %1 entries. Aborting.", folder));
                
                for (const QString &key: entries) {

                    int entryType = invokeAndCheck<int>(
                        [this, handle4, folder, key, appId] { return _kde4_daemon->entryType(handle4, folder, key, appId); },
                        i18n("Cannot retrieve key %1 info. Aborting.", key));
                    
                    // handle the case where the entries are already there
                    if (_kf5_daemon->hasEntry(handle5, folder, key, appId)) {
                        emit progressMessage(i18n("* SKIPPING entry %1 in folder %2 as it seems already migrated", key, folder));
                    } else {
                        QByteArray entry = invokeAndCheck<QByteArray>(
                            [this, handle4, folder, key, appId] { return _kde4_daemon->readEntry(handle4, folder, key, appId); },
                                                                      i18n("Cannot retrieve key %1 data. Aborting.", key));
                        if ( _kf5_daemon->writeEntry(handle5, folder, key, entry, entryType, appId) != 0 ) {
                            auto msg = i18n("Cannot write entry %1 in the new wallet. Aborting.", key);
                            emit progressMessage(msg);
                            throw MigrationException(msg);
                        }
                    }
                }
            }
            
            //_kde4_daemon->close(handle4, false, appId);
            //_kf5_daemon->close(handle5, true, appId);
            _kf5_daemon->sync(handle5, appId);
            emit progressMessage(i18n("DONE migrating wallet\n"));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &key : entries) {

                    int entryType = invokeAndCheck<int>(
                        this, [this, handle4, folder, key, appId] { return _kde4_daemon->entryType(handle4, folder, key, appId); },
                        i18n("Cannot retrieve key %1 info. Aborting.", key));

                    // handle the case where the entries are already there
                    if (_kf5_daemon->hasEntry(handle5, folder, key, appId)) {
                        emit progressMessage(i18n("* SKIPPING entry %1 in folder %2 as it seems already migrated", key, folder));
                    } else {
                        QByteArray entry = invokeAndCheck<QByteArray>(
                            this, [this, handle4, folder, key, appId] { return _kde4_daemon->readEntry(handle4, folder, key, appId); },
                            i18n("Cannot retrieve key %1 data. Aborting.", key));
                        if ( _kf5_daemon->writeEntry(handle5, folder, key, entry, entryType, appId) != 0 ) {
                            auto msg = i18n("Cannot write entry %1 in the new wallet. Aborting.", key);
                            emit progressMessage(msg);
                            throw MigrationException(msg);
                        }
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto e : values.keys()) {
                map.insert(e, values.value(e).toString());
            }
```

#### AUTO 


```{c}
const auto lst = _wallets.values();
```

#### LAMBDA EXPRESSION 


```{c}
[this, handle4, folder, appId] { return _kde4_daemon->entryList(handle4, folder, appId); }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &fi : dir.entryInfoList()) {
		QString fn = fi.fileName();
		if (fn.endsWith(QLatin1String(".kwl"))) {
			fn.truncate(fn.length()-4);
		}
		rc += fn;
	}
```

#### AUTO 


```{c}
auto reply = bus->registerService(QLatin1String("org.kde.kwalletd"), QDBusConnectionInterface::QueueService);
```

#### LAMBDA EXPRESSION 


```{c}
[this, handle4, folder, key, appId] { return _kde4_daemon->entryType(handle4, folder, key, appId); }
```

#### AUTO 


```{c}
auto qreply = _kde_kwalletd4.call("quit");
```

#### AUTO 


```{c}
auto &e
```

#### AUTO 


```{c}
auto &f
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &e : el) {
            std::cout << e.toUtf8().constData() << std::endl;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &folder: folders) {
                emit progressMessage(i18n("* Migrating folder %1", folder));

                QStringList entries = invokeAndCheck<QStringList>(
                    [this, handle4, folder, appId] { return _kde4_daemon->entryList(handle4, folder, appId); },
                    i18n("Cannot retrieve folder %1 entries. Aborting.", folder));
                
                for (const QString &key: entries) {

                    int entryType = invokeAndCheck<int>(
                        [this, handle4, folder, key, appId] { return _kde4_daemon->entryType(handle4, folder, key, appId); },
                        i18n("Cannot retrieve key %1 info. Aborting.", key));
                    
                    // handle the case where the entries are already there
                    if (_kf5_daemon->hasEntry(handle5, folder, key, appId)) {
                        emit progressMessage(i18n("* SKIPPING entry %1 in folder %2 as it seems already migrated", key, folder));
                    } else {
                        QByteArray entry = invokeAndCheck<QByteArray>(
                            [this, handle4, folder, key, appId] { return _kde4_daemon->readEntry(handle4, folder, key, appId); },
                                                                      i18n("Cannot retrieve key %1 data. Aborting.", key));
                        if ( _kf5_daemon->writeEntry(handle5, folder, key, entry, entryType, appId) != 0 ) {
                            auto msg = i18n("Cannot write entry %1 in the new wallet. Aborting.", key);
                            emit progressMessage(msg);
                            throw MigrationException(msg);
                        }
                    }
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& e : map.keys()) {
        json.insert(e, QJsonValue::fromVariant(QVariant(map.value(e))));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, handle4, appId] { return _kde4_daemon->folderList(handle4, appId); }
```

