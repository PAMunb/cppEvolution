#### LAMBDA EXPRESSION 


```{c}
[this](){ m_view->slotOcrSpellCheck(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const KFileItem &item, const QPixmap &preview)
    {
        qCDebug(DESTINATION_LOG) << "got preview for" << item.url();
        emit gotThumbnail(item.url(), preview);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KService::Ptr service : qAsConst(mOpenWithOffers))
    {
        //qCDebug(KOOKA_LOG) << "> offer:" << service->name();
        QString actionName(service->name().replace("&", "&&"));
        QAction *act = new QAction(QIcon::fromTheme(service->icon()), actionName, this);
        connect(act, &QAction::triggered, this, [=]() { slotOpenWith(i); });
        menu->addAction(act);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](){ m_view->slotSelectDevice(); }
```

#### AUTO 


```{c}
const auto &pluginInfo
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : qAsConst(fileUrls))
        {
            kipiInterface->addUrl(url);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &mimeName : {"image/png",
                                    "image/jpeg",
                                    "image/tiff",
                                    "image/x-eps",
                                    "image/bmp"})
    {
        const QMimeType mimeType = db.mimeTypeForName(mimeName);
        const ImageFormat fmt = ImageFormat::formatForMime(mimeType);
        if (!fmt.isValid()) continue;			// this format not supported

        if (mimeName==configuredMime) configuredIndex = mFormatCombo->count();
        mFormatCombo->addItem(QIcon::fromTheme(mimeType.iconName()), mimeType.comment(), mimeType.name());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() { m_view->imageViewerAction(ImageCanvas::UserActionFitHeight); }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() { m_view->imageViewerAction(ImageCanvas::UserActionFitWidth); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &msg){ changeStatus(msg); }
```

#### LAMBDA EXPRESSION 


```{c}
[=](int index)
                {
                    ScanImage::ImageType fmt = static_cast<ScanImage::ImageType>(fitCombo->currentData().toInt());
                    mSaneDevice->setTestFormat(fmt);
                }
```

#### LAMBDA EXPRESSION 


```{c}
[job]()
    {
        if (job->error()) qCDebug(DESTINATION_LOG) << "PreviewJob error" << job->error();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &mimeName : mimeTypes)
    {
        const QMimeType mimeType = db.mimeTypeForName(mimeName);
        const ImageFormat fmt = ImageFormat::formatForMime(mimeType);
        if (!fmt.isValid()) continue;			// this format not supported

        if (mimeName==configuredMime) configuredIndex = combo->count();
        combo->addItem(QIcon::fromTheme(mimeType.iconName()), mimeType.comment(), mimeType.name());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : qAsConst(exportActions))
        {
            QString text = KLocalizedString::removeAcceleratorMarker(action->text());
            if (text.endsWith(dots)) text.chop(dots.length());

            std::cout << qPrintable(action->objectName().leftJustified(maxnamelen+3));
            std::cout << qPrintable(action->icon().name().leftJustified(maxiconlen+3));
            std::cout << qPrintable(text);
            std::cout << std::endl;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : qAsConst(exportActions))
        {
            if (sharetype!=action->objectName()) continue;
            qCDebug(DESTINATION_LOG) << "sharing with action" << action->text();

            action->trigger();				// do the export action
            return (app.exec());			// let that do its work
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() { slotSetSize(size); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &savedFile : mSavedFiles)
    {
        delayedDelete(savedFile);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &pluginInfo : pluginList)
    {
        if (!pluginInfo->shouldLoad()) continue;

        KIPI::Plugin *plugin = pluginInfo->plugin();
        if (plugin==nullptr)
        {
            qCWarning(DESTINATION_LOG) << "Failed to load KIPI plugin from library" << pluginInfo->library();
            continue;
        }

        plugin->setup(dummyWidget);
        const QList<QAction *> actions = plugin->actions();
        for (QAction *action : actions)
        {
            KIPI::Category category = plugin->category(action);
            if (category==KIPI::ExportPlugin)
            {
                exportActions += action;
            }
            else if (category==KIPI::ImagesPlugin && pluginInfo->library().contains(QLatin1String("kipiplugin_sendimages")))
            {
                exportActions += action;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &scanMode : scanModes)
        {
            cb->setIcon(ScanIcons::self()->icon(scanMode), scanMode.constData());
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() { m_view->imageViewerAction(ImageCanvas::UserActionZoom); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &line : lines)
        {
            const QString lineStr = QString::fromLocal8Bit(line);
            qDebug() << "line:" << lineStr;

            QRegExp rx;
            if (opt=="list-langs") rx.setPattern("^\\s*(\\w+)()$");
            else rx.setPattern("^\\s*(\\d+)\\s+(\\w.+)?$");
            if (rx.indexIn(lineStr)>-1)
            {
                const QString value = rx.cap(1);
                QString desc = rx.cap(2).simplified();
                if (desc.endsWith(QLatin1Char('.')) || desc.endsWith(QLatin1Char(','))) desc.chop(1);
                result.insert(value, desc);
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this,dirToShow]()
        {
            setUrl(dirToShow, true);			// change path and reload
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QMimeType &mimeType : *mimeTypes)
    {
        filters << mimeType.name();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : urls)
    {
        items.append(KFileItem(url, KFileItem::SkipMimeTypeFromContent));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() { m_view->imageViewerAction(ImageCanvas::UserActionOrigSize); }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() { slotOpenWith(i); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KService::Ptr service : allServices)
    {
        // Okular is an odd case.  For whatever reason, the application does
        // not have just one desktop file listing all of the MIME types that
        // it supports, but a number of such files each listing one or a
        // closely related set of MIME types.  I suspect that this is so that
        // there can be one desktop file for each generator with the MIME
        // types that the generator supports.  There was a similar hack for
        // Ark (https://git.reviewboard.kde.org/r/129617 from 2011) that
        // collected a list of MIME types supported by each plugin and passed
        // them up to the top level CMakeLists.txt, then using the collected
        // list to generate the desktop files, but it was remarked at the time
        // that it would be more complicated to do this for Okular.
        //
        // Since the criteria used to select an application for including in
        // the "preferrred applications" list is that it supports at least one
        // image MIME type that we also support, this would result in multiple
        // entries for Okular.  Because the command used to start Okular is the
        // same in every case, we special case detect the main Okular application
        // here and ignore all of the others (along with any other NoDisplay
        // services).
        if (service->desktopEntryName()=="org.kde.okular")
        {
            qCDebug(DESTINATION_LOG) << "accept" << service->desktopEntryName() << "by name, pref" << service->initialPreference();
            validServices.append(service);
            continue;
        }

        if (service->noDisplay()) continue;		// ignore hidden services
        if (service->mimeTypes().isEmpty()) continue;	// ignore those with no MIME types
        //qCDebug(DESTINATION_LOG) << "  " << service->mimeTypes();

        for (const QString &mimeType : service->mimeTypes())
        {
            if (!mimeType.startsWith("image/")) continue;
            for (const QMimeType &imt : *imageMimeTypes)
            {						// supports a MIME type that we also do
                if (imt.inherits(mimeType)) goto found;
            }
        }
        continue;					// service not accepted

found:  qCDebug(DESTINATION_LOG) << "accept" << service->desktopEntryName() << "by MIME, pref" << service->initialPreference();
        validServices.append(service);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KService::Ptr service : validServices)
    {
        const QString key = service->desktopEntryName();
        if (key==configuredApp) configuredIndex = mAppsCombo->count();
        mAppsCombo->addItem(QIcon::fromTheme(service->icon()), service->name(), key);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { slotItemHighlighted(); }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &link){ QDesktopServices::openUrl(QUrl(link)); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &line : lines)
    {
        //qCDebug(DESTINATION_LOG) << "read line" << line;

        // QString::split() is more versatile than QByteArray::split(),
        // which can only split on a single character.
        const QStringList splits = QString::fromLocal8Bit(line).split(rx, Qt::SkipEmptyParts);
        if (splits.count()<3) continue;			// not enough fields

        QStringList::const_iterator it = splits.begin();
        const QString actionName = (*it++);
        const QString actionIcon = (*it++);
        const QString actionText = QStringList(it, splits.constEnd()).join(' ');

        // The check on the KIPI::Category will already have been done by the
        // helper, so always accept the action.
        if (actionName==configuredExport) configuredIndex = mExportCombo->count();
        mExportCombo->addItem(QIcon::fromTheme(actionIcon), actionText, actionName);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](){ slotSelectDevice(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &mimetype : mimetypes)
        {
            if (mime.inherits(mimetype)) return (fi);	// matching that MIME type
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : qAsConst(exportActions))
        {
            maxnamelen = qMax(maxnamelen, action->objectName().length());
            maxiconlen = qMax(maxiconlen, action->icon().name().length());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &line : lines)
        {
            const QString lineStr = QString::fromLocal8Bit(line);
            qCDebug(OCR_LOG) << "line:" << lineStr;

            QRegExp rx;
            if (opt=="list-langs") rx.setPattern("^\\s*(\\w+)()$");
            else rx.setPattern("^\\s*(\\d+)\\s+(\\w.+)?$");
            if (rx.indexIn(lineStr)>-1)
            {
                const QString value = rx.cap(1);
                QString desc = rx.cap(2).simplified();
                if (desc.endsWith(QLatin1Char('.')) || desc.endsWith(QLatin1Char(','))) desc.chop(1);
                result.insert(value, desc);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : actions)
        {
            KIPI::Category category = plugin->category(action);
            if (category==KIPI::ExportPlugin)
            {
                exportActions += action;
            }
            else if (category==KIPI::ImagesPlugin && pluginInfo->library().contains(QLatin1String("kipiplugin_sendimages")))
            {
                exportActions += action;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QMimeType &imt : *imageMimeTypes)
            {						// supports a MIME type that we also do
                if (imt.inherits(mimeType)) goto found;
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &mimeType : service->mimeTypes())
        {
            if (!mimeType.startsWith("image/")) continue;
            for (const QMimeType &imt : *imageMimeTypes)
            {						// supports a MIME type that we also do
                if (imt.inherits(mimeType)) goto found;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() { slotOpenWith(-1); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &arg : args)
        {
            QUrl u = QUrl::fromUserInput(arg, QDir::currentPath(), QUrl::AssumeLocalFile);
            if (!u.isLocalFile())
            {
                report(false, i18n("Argument '%1' is not a local file, ignored", u.toDisplayString()));
                continue;
            }

            QFileInfo fi(u.toLocalFile());
            if (!fi.exists() || !fi.isReadable())
            {
                report(false, i18n("File '%1' not found or is unreadable, ignored", fi.canonicalFilePath()));
                continue;
            }

            fileUrls.append(u);				// this file is usable
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QMimeType &mimeType : *mimeTypes)
    {
        ImageFormat fmt = ImageFormat::formatForMime(mimeType);
        if (!fmt.isValid()) continue;			// format for that MIME type
							// see if it should be used
        if (!FormatDialog::isCompatible(mimeType, type, recOnly)) continue;
        filters << mimeType.name();			// yes, add to filter list
    }
```

