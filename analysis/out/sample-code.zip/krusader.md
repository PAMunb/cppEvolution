#### AUTO 


```{c}
auto *layout = new QGridLayout;
```

#### RANGE FOR STATEMENT 


```{c}
for (QExplicitlySharedDataPointer<KMountPoint> possibleMountPoint : KMountPoint::possibleMountPoints()) {
        // skip nonmountable file systems
        if (nonmountFilesystem(possibleMountPoint->mountType(), possibleMountPoint->mountPoint())
            || invalidFilesystem(possibleMountPoint->mountType())) {
            continue;
        }
        // does the mountpoint exist in current list?
        // if so, it can only be umounted, otherwise, it can be mounted
        bool needUmount = false;
        for (QExplicitlySharedDataPointer<KMountPoint> currentMountPoint : currentMountPoints) {
            if (currentMountPoint->mountPoint() == possibleMountPoint->mountPoint()) {
                // found -> needs umount
                needUmount = true;
                break;
            }
        }
        // add the item to the menu
        const QString text = QString("%1 %2 (%3)").arg(needUmount ? i18n("Unmount") : i18n("Mount"),
                                                 possibleMountPoint->mountPoint(), possibleMountPoint->mountedFrom());

        QAction *act = _action->menu()->addAction(text);
        act->setData(QList<QVariant>({
            QVariant(needUmount ? KMountMan::ActionType::Unmount : KMountMan::ActionType::Mount),
            QVariant(possibleMountPoint->mountPoint())
        }));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &fileItem : _items) {
                // do not open dirs if multiple files are selected
                if (_items.size() == 1 || !fileItem.isDir()) {
                    panel->func->execute(fileItem.name());
                }
            }
```

#### AUTO 


```{c}
auto* item = dynamic_cast<UserActionListViewItem*>(currentItem())
```

#### AUTO 


```{c}
auto *loaderLayout = new QGridLayout(widget);
```

#### AUTO 


```{c}
auto* spacer = new QSpacerItem(20, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {setModified(true); }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() { reject(); }
```

#### AUTO 


```{c}
auto percent = (int)(((double)p / (double)(sum)) * 10000. + 0.5);
```

#### RANGE FOR STATEMENT 


```{c}
for (QListWidgetItem *item : selectedItems)
        delete item;
```

#### AUTO 


```{c}
auto *drive = d.as<Solid::StorageDrive>();
```

#### AUTO 


```{c}
auto action = KrBookmark::jumpBackAction(_privateCollection, true, actions);
```

#### AUTO 


```{c}
auto *ke = dynamic_cast<QKeyEvent *>(event);
```

#### AUTO 


```{c}
auto *kioJob = qobject_cast<KIO::TransferJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto & _tableHeader : _tableHeaders) {
        _label = new QLabel(_tableHeader, this);
        _label->setContentsMargins(5, 5, 5, 5);
        _grid->addWidget(_label, 0, column);

        // Set font
        QFont defFont = QFontDatabase::systemFont(QFontDatabase::GeneralFont);
        defFont.setPointSize(defFont.pointSize() - 1);
        defFont.setBold(true);
        _label->setFont(defFont);

        ++column;
    }
```

#### AUTO 


```{c}
auto minSize = headerView->minimumSectionSize();
```

#### AUTO 


```{c}
auto *layout = new QGridLayout(container);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString fileName : fileNames) {
        if (!getUrl(fileName).isLocalFile()) {
            return false;
        }
    }
```

#### AUTO 


```{c}
auto * errorEvent = new UserEvent(CMD_SUCCESS, args);
```

#### AUTO 


```{c}
auto *duHBox = new QHBoxLayout(duTools);
```

#### AUTO 


```{c}
auto *layout = new QVBoxLayout;
```

#### AUTO 


```{c}
auto *synchGrid = new QGridLayout(loaderBox);
```

#### AUTO 


```{c}
auto * downloadEvent = new UserEvent(CMD_DOWNLOAD_FILES, args);
```

#### AUTO 


```{c}
auto* arch = dynamic_cast<Archiver*>(search);
```

#### AUTO 


```{c}
auto *fontLayout = new QHBoxLayout();
```

#### AUTO 


```{c}
auto quickSearchMenu = _quickSearchMenu;
```

#### AUTO 


```{c}
auto repr = QString("%1 [%2] %3x%4 %5 %6").arg(name).arg(overlays.join(';'))
                                                  .arg(size.width()).arg(size.height())
                                                  .arg((int)mode).arg((int)state);
```

#### AUTO 


```{c}
auto *kgGeneralLayout = new QGridLayout(tab);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString source : sourceList) {
        sourceURLs.append(QUrl::fromUserInput(source, QString(), QUrl::AssumeLocalFile));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto part : parts) {
        // if the part is not the first one, we need to add one character to account for the dot
        selectionLength += part.length() + !isFirstPart;
        isFirstPart = false;
        // if we reached the full length, don't add the selection, since it's a full selection
        if (selectionLength == length)
            break;

        // don't add empty selections (could happen if the full name ends with a dot)
        if (selectionLength > 0)
            selections.append(EditorSelection(length - selectionLength, selectionLength));
    }
```

#### AUTO 


```{c}
auto *KgProtocolsLayout = new QGridLayout(this);
```

#### AUTO 


```{c}
auto *ownerGroup = new QGroupBox(ownershipGroup);
```

#### AUTO 


```{c}
auto * toolbarLayout = new QHBoxLayout(toolbar);
```

#### AUTO 


```{c}
auto *event = dynamic_cast<UserEvent*>( e);
```

#### AUTO 


```{c}
auto *gridLayout = new QGridLayout();
```

#### AUTO 


```{c}
auto *rightUrlReq = new KUrlRequester(rightLocation, compareDirs);
```

#### AUTO 


```{c}
auto *tabLayout = new QGridLayout(tab);
```

#### AUTO 


```{c}
auto* pvb = dynamic_cast<PanelViewerBase*>(tabWidget.widget(i));
```

#### AUTO 


```{c}
auto & name
```

#### AUTO 


```{c}
auto *tempFile = new QTemporaryFile;
```

#### AUTO 


```{c}
auto a_max = int(acos((double)width / double((width + 5) * scaleFactor)) * (180 * 16 / M_PI));
```

#### RANGE FOR STATEMENT 


```{c}
for (KrJob *job: m_jobs)
        connect(job, &KrJob::terminated, this, &JobMan::slotUpdateMessageBox);
```

#### LAMBDA EXPRESSION 


```{c}
[=]() { emit filesystemChanged(QUrl("trash:/")); }
```

#### RANGE FOR STATEMENT 


```{c}
for (KrJob *job: qAsConst(m_jobs)) {
            job->cancel();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &fileUrl : urls) {
        if (!urlList->contains(fileUrl)) {
            urlList->push_back(fileUrl);
        }
    }
```

#### AUTO 


```{c}
auto *layout = new QGridLayout(groupWidget);
```

#### RANGE FOR STATEMENT 


```{c}
for (KrJob *job : _jobs) {
            if (anyRunning)
                job->pause();
            else
                job->start();
        }
```

#### AUTO 


```{c}
auto *excludeCheckBox = new QCheckBox(this);
```

#### AUTO 


```{c}
auto mode = KrSelectionMode::getSelectionHandler();
```

#### AUTO 


```{c}
auto headerView = header();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& name : fileNames) {
            if (_virtFilesystemDict.find(parentDir) != _virtFilesystemDict.end()) {
                QList<QUrl> *urlList = _virtFilesystemDict[parentDir];
                urlList->removeAll(getUrl(name));
            }
        }
```

#### AUTO 


```{c}
auto* ke = (QKeyEvent*) event;
```

#### RANGE FOR STATEMENT 


```{c}
for (auto & mountPoint : mountPoints) {
            md5.addData(mountPoint->mountedFrom().toUtf8());
            md5.addData(mountPoint->realDeviceName().toUtf8());
            md5.addData(mountPoint->mountPoint().toUtf8());
            md5.addData(mountPoint->mountType().toUtf8());
        }
```

#### AUTO 


```{c}
auto it = root->children().begin();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto fallbackThemeName : themeFallbackList) {
            QIcon::setThemeName(fallbackThemeName);
            if (QIcon::hasThemeIcon(iconName)) {
                return IconSearchResult(QIcon::fromTheme(iconName), currentTheme);
            }
        }
```

#### AUTO 


```{c}
auto *btnGroup = new QButtonGroup(dateGroup);
```

#### AUTO 


```{c}
auto *hbox = new QHBoxLayout();
```

#### AUTO 


```{c}
auto *mapper = new QSignalMapper(this);
```

#### AUTO 


```{c}
auto *compareDirs = new QGroupBox(synchronizerTab);
```

#### AUTO 


```{c}
auto percent = static_cast<int>(((static_cast<long double>(receivedSize) / expectedSize) * 100.) + 0.5);
```

#### AUTO 


```{c}
auto a_len = (unsigned int)(5760 * ((double)(*it)->size() / (double)m_root->size()));
```

#### AUTO 


```{c}
auto  *sizes = new int [ m_map.m_visibleDepth + 1 ];
```

#### RANGE FOR STATEMENT 


```{c}
for (auto & fileSystem : fileSystems)
        addItemToMountList(mountList, fileSystem);
```

#### AUTO 


```{c}
auto *layout = new QHBoxLayout(this);
```

#### LAMBDA EXPRESSION 


```{c}
[=](KJob *job) {
            connect(job, &KJob::description, this, &JobMenuAction::slotDescription);
            connect(job, SIGNAL(percent(KJob*,ulong)), this,
                    SLOT(slotPercent(KJob*,ulong)));
            connect(job, &KJob::suspended, this, &JobMenuAction::updatePauseResumeButton);
            connect(job, &KJob::resumed, this, &JobMenuAction::updatePauseResumeButton);
            connect(job, &KJob::result, this, &JobMenuAction::slotResult);
            connect(job, &KJob::warning, this, [](KJob *, const QString &plain, const QString &) {
                krOut << "unexpected job warning: " << plain;
            });

            updatePauseResumeButton();
        }
```

#### AUTO 


```{c}
auto *panelTypes = new KONFIGURATOR_NAME_VALUE_PAIR[ viewsSize ];
```

#### AUTO 


```{c}
auto *he = dynamic_cast<QHelpEvent*>(event);
```

#### RANGE FOR STATEMENT 


```{c}
for (FileItem *file : files)
        uniqueMimeTypes.insert(file->getMime());
```

#### AUTO 


```{c}
auto *option = new QCheckBox(this);
```

#### AUTO 


```{c}
auto *ownershipLayout = new QGridLayout(ownershipGroup);
```

#### AUTO 


```{c}
auto *result = new bool(!searchResult.icon.isNull());
```

#### AUTO 


```{c}
auto *optionsLayout = new QGridLayout(optionsGroup);
```

#### AUTO 


```{c}
auto *button = new QPushButton(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this](){ _view->customSelection(true); }
```

#### LAMBDA EXPRESSION 


```{c}
[=](KIO::Job *job) { connectJobToDestination(job, destDir); }
```

#### AUTO 


```{c}
auto *me = (QContextMenuEvent *)event;
```

#### AUTO 


```{c}
auto *addButton = new QToolButton(hboxWidget3);
```

#### AUTO 


```{c}
auto *ke = dynamic_cast<QKeyEvent *>(e);
```

#### AUTO 


```{c}
auto* general_scroll = new QScrollArea(tabWidget);
```

#### AUTO 


```{c}
auto *currentPg = qobject_cast<KonfiguratorPage *>(before->widget());
```

#### RANGE FOR STATEMENT 


```{c}
for (QUrl &item : whereNotToSearch)
        if (item.isParentOf(url) || url.matches(item, QUrl::StripTrailingSlash))
            return true;
```

#### RANGE FOR STATEMENT 


```{c}
for (auto i : evilstuff)
        s.replace(i, ('\\' + i));
```

#### LAMBDA EXPRESSION 


```{c}
[=](const KPluginMetaData& metaData) {
        return metaData.pluginId() == "compressfileitemaction" || metaData.pluginId() == "extractfileitemaction";
    }
```

#### AUTO 


```{c}
auto *gridLayout = new QGridLayout(parent);
```

#### AUTO 


```{c}
auto iconLoader = KIconLoader::global();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto & item : itemList)
        restartNeeded = item->apply() || restartNeeded;
```

#### AUTO 


```{c}
auto* actionItem = dynamic_cast<UserActionListViewItem*>(item)
```

#### AUTO 


```{c}
auto *openWithMenu = new QMenu(this);
```

#### AUTO 


```{c}
auto *syncItem = dynamic_cast<SyncViewItem *>(itemIn);
```

#### AUTO 


```{c}
auto *item = new QTreeWidgetItem(tree);
```

#### AUTO 


```{c}
auto *vbox1 = new QVBoxLayout(vbox1Widget);
```

#### AUTO 


```{c}
auto *item = new SynchronizerFileItem(leftFile, rightFile, leftDir, rightDir, marked,
            existsLeft, existsRight, leftSize, rightSize, leftDate, rightDate, leftLink, rightLink,
            leftOwner, rightOwner, leftGroup, rightGroup, leftMode, rightMode, leftACL, rightACL, tsk, isDir,
            isTemp, parent);
```

#### AUTO 


```{c}
auto delegate = dynamic_cast<KrViewItemDelegate *>(itemDelegate(nameIndex));
```

#### AUTO 


```{c}
auto *layout = new QGridLayout(this);
```

#### AUTO 


```{c}
auto progress = event->args()[ 0 ].value<qulonglong>();
```

#### AUTO 


```{c}
auto *allGroup = new QGroupBox(ownershipGroup);
```

#### AUTO 


```{c}
auto *kgAdvancedLayout = new QGridLayout(innerWidget);
```

#### AUTO 


```{c}
auto *urlReq = qobject_cast<KonfiguratorURLRequester *>(obj);
```

#### AUTO 


```{c}
auto selections = generateFileNameSelections(text);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto selection : selections) {
        if (selection == currentSelection)
            break;
        currentIndex++;
    }
```

#### AUTO 


```{c}
auto *btnCloseSync = new QPushButton(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (vfile *vf : vfs_->vfiles()) {
        QUrl fileURL = vf->vfile_getUrl();

        if (query->isRecursive() && ((vf->vfile_isSymLink() && query->followLinks()) || vf->vfile_isDir()))
            unScannedUrls.push(fileURL);

        if (query->match(vf)) {
            // if we got here - we got a winner
            results.append(fileURL.toDisplayString(QUrl::PreferLocalFile));

            emit found(*vf, query->foundText()); // emitting copy of vfile
        }

        if (timer.elapsed() >= EVENT_PROCESS_DELAY) {
            qApp->processEvents();
            timer.start();
            if (stopSearch) return;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
            deleteFile(fileItem, true);
        }
```

#### AUTO 


```{c}
auto* foundTextLayout = new QHBoxLayout();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString name: names) {
        FileItem *file = ACTIVE_FUNC->files()->getFileItem(name);
        if (!file)
            continue;
        const QUrl url = file->getUrl();
        // KRename only supports the recursive option combined with a local directory path
        if (file->isDir() && url.scheme() == "file") {
            proc << "-r" << url.path();
        } else {
            proc << url.toString();
        }
    }
```

#### AUTO 


```{c}
auto searchResult = searchIcon(iconName, getThemeFallbackList());
```

#### AUTO 


```{c}
auto *filterLayout = new QGridLayout(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (vfile *file : files) {
        _items.append(KFileItem(file->vfile_getUrl(), file->vfile_getMime(),
                                file->vfile_getMode()));
    }
```

#### AUTO 


```{c}
auto* spacer_5 = new QSpacerItem(20, 26, QSizePolicy::Fixed, QSizePolicy::Fixed);
```

#### AUTO 


```{c}
auto *panelManager = new PanelManager(horiz_splitter, krApp, left);
```

#### AUTO 


```{c}
auto* spacer_cons = new QSpacerItem(48, 20, QSizePolicy::Expanding, QSizePolicy::Fixed);
```

#### AUTO 


```{c}
auto sourceAction = isSetter ? sourceActions->actSetJumpBack : sourceActions->actJumpBack;
```

#### AUTO 


```{c}
auto * getPasswdEvent = new UserEvent(CMD_MESSAGE, args);
```

#### RANGE FOR STATEMENT 


```{c}
for(QPointer<vfs> vfsPointer: _vfs_list) {
        // always refresh virtual vfs showing a virtual directory; it can contain files from various
        // places, we don't know if they were (re)moved, refreshing is also fast enough
        vfs *vfs = vfsPointer.data();
        const QUrl vfsDir = vfs->currentDirectory();
        if (vfsDir == vfs::cleanUrl(directory) || (vfsDir.scheme() == "virt" && !vfs->isRoot())) {
            vfs->mayRefresh();
        }
    }
```

#### AUTO 


```{c}
auto *gd = new KrGetDate(d, this);
```

#### AUTO 


```{c}
auto *archGrid1 = new QGridLayout(packers_tab);
```

#### AUTO 


```{c}
auto *stderrBox = new QVBoxLayout(stderrWidget);
```

#### AUTO 


```{c}
auto* item = dynamic_cast<UserActionListViewItem*>(*it)
```

#### AUTO 


```{c}
auto* layout = new QHBoxLayout(this);
```

#### AUTO 


```{c}
auto *split = new QSplitter(this);
```

#### AUTO 


```{c}
auto *vol = device.as<Solid::StorageVolume> ();
```

#### RANGE FOR STATEMENT 


```{c}
for (KrJob *job: qAsConst(m_jobs))
        connect(job, &KrJob::terminated, this, &JobMan::slotUpdateMessageBox);
```

#### AUTO 


```{c}
auto *dialog = new KrCalcSpaceDialog(parent, calculator);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString name : names) {
        urls.append(getUrl(name));
    }
```

#### AUTO 


```{c}
auto currentTheme = QIcon::themeName();
```

#### AUTO 


```{c}
auto *compressLayout = new QVBoxLayout;
```

#### RANGE FOR STATEMENT 


```{c}
for (auto & item : itemList)
        item->loadInitialValue();
```

#### AUTO 


```{c}
auto keyEvent = dynamic_cast<QKeyEvent *>(event);
```

#### AUTO 


```{c}
auto *grid = new QGridLayout(this);
```

#### AUTO 


```{c}
auto *fileItem = const_cast<FileItem *>(current->getFileItem());
```

#### LAMBDA EXPRESSION 


```{c}
[=](KIO::Job *, const QUrl &url) { slotRedirection(url); }
```

#### AUTO 


```{c}
auto *hLayout = new QHBoxLayout;
```

#### AUTO 


```{c}
auto *_topLayout = new QVBoxLayout();
```

#### AUTO 


```{c}
auto & item
```

#### AUTO 


```{c}
auto charCode = (int)c;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString line : data)
            stream << line << "\n";
```

#### AUTO 


```{c}
auto * infoEvent = new UserEvent(CMD_INFO, args);
```

#### AUTO 


```{c}
auto* cbSpacer = new QSpacerItem(20, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
            KPropertiesDialog* dialog = new KPropertiesDialog(fileItem.url(), this);
            dialog->setAttribute(Qt::WA_DeleteOnClose);
            dialog->show();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() { FileSystemProvider::instance().refreshFilesystem(url); }
```

#### AUTO 


```{c}
auto * vbox = new QVBoxLayout(vboxWidget);
```

#### AUTO 


```{c}
auto *kgStartupLayout = new QGridLayout(innerWidget);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KIO::UDSEntry& entry : entries) {
        FileItem *item = FileSystem::createFileItemFromKIO(entry, listJob->url());
        if (item) {
            insert(item->getName(), item);
        }
    }
```

#### AUTO 


```{c}
auto *duItem = dynamic_cast< DULinesItem *>(lvitem);
```

#### AUTO 


```{c}
auto *modifiedInTheLastLayout = new QHBoxLayout();
```

#### AUTO 


```{c}
auto * re = dynamic_cast<QResizeEvent *>(event);
```

#### AUTO 


```{c}
auto *createNewMenu = new QMenu(this);
```

#### LAMBDA EXPRESSION 


```{c}
[=]() { emit filesystemChanged(url); }
```

#### AUTO 


```{c}
auto addJumpBackAction = [=](bool isSetter) {
                    auto action = KrBookmark::jumpBackAction(_privateCollection, isSetter, actions);
                    if (action) {
                        menu->addAction(action);
                        _specialBookmarks.append(action);

                        // disconnecting from this as a receiver is important:
                        // we don't want to break connections established by KrBookmark::jumpBackAction
                        disconnect(action, &QAction::triggered, this, nullptr);
                        connect(action, &QAction::triggered, this, slotTriggered);
                    }
                };
```

#### AUTO 


```{c}
auto *krstyle = new KrStyleProxy();
```

#### AUTO 


```{c}
auto* appGroup = dynamic_cast<ApplicationGroup*>(search);
```

#### LAMBDA EXPRESSION 


```{c}
[=](KIO::Job *job) {
            // Note: the "trash" protocol should always have only one "/" after the "scheme:" part
            connect(job, &KIO::Job::result, this, [=]() { emit fileSystemChanged(QUrl("trash:/"), false); });
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (KrJob *job : m_jobs) {
            if (anyRunning)
                job->pause();
            else
                job->start();
        }
```

#### AUTO 


```{c}
auto *hbox = new QHBoxLayout;
```

#### AUTO 


```{c}
auto comboBox = qobject_cast<KHistoryComboBox *>(obj);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto & atomicExtension : _viewProperties->atomicExtensions) {
                if (fileitemName.endsWith(atomicExtension)) {
                    loc = fileitemName.length() - atomicExtension.length();
                    break;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (QUrl fileUrl : urls) {
        files.append(showPath ? fileUrl.toDisplayString(QUrl::PreferLocalFile) : fileUrl.fileName());
    }
```

#### AUTO 


```{c}
auto *layout = new QVBoxLayout(tab);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& name : names) {
        FileItem *fileitem = files()->getFileItem(name);
        if (!fileitem) {
            continue;
        }

        fileItems.push_back(KFileItem(fileitem->getEntry(), files()->getUrl(name)));
    }
```

#### AUTO 


```{c}
auto part
```

#### RANGE FOR STATEMENT 


```{c}
for (auto part : parts) {
        // if the part is not the first one, we need to add one character to account for the dot
        selectionLength += part.length() + !isFirstPart;
        isFirstPart = false;
        // if we reached the full length, don't add the selection, since it's a full selection
        if (selectionLength == length)
            break;

        // don't add empty selections (could happen if the full name starts with a dot)
        if (selectionLength > 0)
            selections.append(EditorSelection(0, selectionLength));
    }
```

#### AUTO 


```{c}
auto *categoryMenu = new KActionMenu(category, menu);
```

#### LAMBDA EXPRESSION 


```{c}
[=](KIO::Job *job) {
            // Note: the "trash" protocal should always have only one "/" after the "scheme:" part
            connect(job, &KIO::Job::result, this, [=]() { emit fileSystemChanged(QUrl("trash:/"), false); });
        }
```

#### AUTO 


```{c}
auto * layout = new QGridLayout(this);
```

#### AUTO 


```{c}
auto *drive = dev.as<Solid::OpticalDrive>();
```

#### LAMBDA EXPRESSION 


```{c}
[=](KJob* job) { slotJobResult(job, false); }
```

#### AUTO 


```{c}
auto *menuAction = new JobMenuAction(job, m_controlAction, kJob);
```

#### AUTO 


```{c}
auto * uploadEvent = new UserEvent(CMD_UPLOAD_FILES, args);
```

#### AUTO 


```{c}
auto *item = new QTreeWidgetItem(_createIn);
```

#### RANGE FOR STATEMENT 


```{c}
for (FileItem *fileItem : fileSystem->fileItems()) {
        const QUrl fileUrl = fileItem->getUrl();

        if (m_query->isRecursive() &&
            ((!fileItem->isSymLink() && fileItem->isDir()) || (fileItem->isSymLink() && m_query->followLinks()))) {
            // query search in subdirectory
            m_unScannedUrls.push(fileUrl);
        }

        if (m_query->searchInArchives() && fileUrl.isLocalFile() &&
            KrArcHandler::arcSupported(fileItem->getMime())) {
            // query search in archive; NOTE: only supported for local files
            QUrl archiveURL = fileUrl;
            bool encrypted;
            const QString type = krArcMan.getType(encrypted, fileUrl.path(), fileItem->getMime());

            if (!encrypted) {
                archiveURL.setScheme(TAR_TYPES.contains(type) ? "tar" : "krarc");
                m_unScannedUrls.push(archiveURL);
            }
        }

        if (m_query->match(fileItem)) {
            // found!
            emit found(*fileItem, m_query->foundText()); // emitting copy of file item
        }

        if (m_timer.elapsed() >= EVENT_PROCESS_DELAY) {
            qApp->processEvents();
            m_timer.start();
            if (m_stopSearch)
                return;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto & it : possibleMountList) {
        if (krMtMan.networkFilesystem(it->mountType())) {
            bool mounted = false;

            for (auto & it2 : currentMountList) {
                if (krMtMan.networkFilesystem(it2->mountType()) &&
                        it->mountPoint() == it2->mountPoint()) {
                    mounted = true;
                    break;
                }
            }

            QString name = i18nc("%1 is the mount point of the remote share", "Remote Share [%1]", it->mountPoint());
            QStringList overlays;
            if (mounted)
                overlays << "emblem-mounted";
            QAction * act = popupMenu->addAction(Icon("network-wired", overlays), name);
            QString udi = remotePrefix + it->mountPoint();
            act->setData(QVariant(udi));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KrJob *job: m_jobs)
        if (job->isRunning())
            return true;
```

#### AUTO 


```{c}
auto nBytesRead = readlink(path, buffer.get(), bufferSize);
```

#### LAMBDA EXPRESSION 


```{c}
[=](const QUrl &url) { ListPanel::newTab(url); }
```

#### AUTO 


```{c}
auto *item = (SynchronizerGUI::SyncViewItem *) * it;
```

#### AUTO 


```{c}
auto selectionCount = selections.length();
```

#### AUTO 


```{c}
auto *hboxlayout = new QHBoxLayout(widget);
```

#### AUTO 


```{c}
auto *clientLayout = new QVBoxLayout(clientArea);
```

#### AUTO 


```{c}
auto *v = dynamic_cast<KrInterBriefView*>(other);
```

#### AUTO 


```{c}
auto *hbox3 = new QHBoxLayout(hboxWidget3);
```

#### AUTO 


```{c}
auto *file1 = const_cast<FileItem *>(i1->getFileItem());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl& url : urlList) {
        urlListBox->addItem(url.toDisplayString(QUrl::PreferLocalFile));
    }
```

#### AUTO 


```{c}
auto* fileitem = (FileItem *)item->getFileItem();
```

#### AUTO 


```{c}
auto it = widgets.constBegin(), end = widgets.constEnd();
```

#### AUTO 


```{c}
auto node = new UrlNode;
```

#### AUTO 


```{c}
auto *ui = dynamic_cast<KIO::JobUiDelegate*>(uiDelegate());
```

#### AUTO 


```{c}
auto *sizeCalculator = new SizeCalculator(urls);
```

#### LAMBDA EXPRESSION 


```{c}
[=]() { FileSystemProvider::instance().refreshFilesystems(url, false); }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() { Q_EMIT pathChanged(p); }
```

#### AUTO 


```{c}
auto *nameGroupLayout = new QGridLayout(nameGroup);
```

#### AUTO 


```{c}
auto* spacer_psw = new QSpacerItem(20, 20, QSizePolicy::Fixed, QSizePolicy::Expanding);
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        if (_dragTabIndex != -1 && _dragTabIndex != currentIndex()) {
            setCurrentIndex(_dragTabIndex);
        }
        _dragTabIndex = -1;
    }
```

#### AUTO 


```{c}
auto *buttons = new QHBoxLayout;
```

#### RANGE FOR STATEMENT 


```{c}
for (vfile *file : files) {
        if (file->vfile_getMime() != mime) {
            mime.clear();
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto & name : names) {
        m_impl->m_colorTextValues[name] = src.m_impl->m_colorTextValues[name];
        m_impl->m_colorValues[name] = src.m_impl->m_colorValues[name];
    }
```

#### AUTO 


```{c}
auto *leftUrlReq = new KUrlRequester(leftLocation, compareDirs);
```

#### LAMBDA EXPRESSION 


```{c}
[=]() { _tabbar->updateTab(p); }
```

#### AUTO 


```{c}
auto* spacer = new QSpacerItem(0, 0, QSizePolicy::Expanding, QSizePolicy::Fixed);
```

#### AUTO 


```{c}
auto *e = qobject_cast<QLineEdit*>(editor)
```

#### LAMBDA EXPRESSION 


```{c}
[=]() { emit fileSystemChanged(currentDirectory(), false); }
```

#### AUTO 


```{c}
auto *userActionMenu = (KActionMenu *) KrActions::actUserMenu;
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : _action->menu()->actions()) {
        if (action == _manageAction || action->isSeparator()) {
            continue;
        }
        _action->menu()->removeAction(action);
    }
```

#### AUTO 


```{c}
auto *grid = new QGridLayout();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& name : names) {
        if (_exited)
            return;

        const QString path = calcSpaceFileSystem->getUrl(name).toLocalFile();
        if (!QFileInfo(path).exists())
            return;

        countFiles(path, totalFiles, _exited);
    }
```

#### AUTO 


```{c}
auto * hbox4 = new QHBoxLayout(hboxWidget4);
```

#### AUTO 


```{c}
auto *kgColorsLayout = new QGridLayout(innerWidget);
```

#### AUTO 


```{c}
auto comboBox = qobject_cast<KHistoryComboBox *>(itemView->parent()->parent());
```

#### RANGE FOR STATEMENT 


```{c}
for (auto & it : possibleMountList) {
                if (krMtMan.networkFilesystem(it->mountType()) &&
                        it->mountPoint() == mountPoint) {
                    available = true;
                    break;
                }
            }
```

#### AUTO 


```{c}
auto *saveAsButton = new QPushButton;
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
            qDebug() << "openFile canceled: '" << curl << "'";
        }
```

#### AUTO 


```{c}
auto *splitt = new QSplitter(Qt::Horizontal, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString name : names) {
        FileItem *fileitem = files()->getFileItem(name);
        if (!fileitem) {
            continue;
        }

        fileItems.push_back(KFileItem(fileitem->getEntry(), files()->getUrl(name)));
    }
```

#### AUTO 


```{c}
auto *job = new KIO::OpenUrlJob(url, this);
```

#### AUTO 


```{c}
auto * errorEvent = new UserEvent(CMD_ERROR, args);
```

#### AUTO 


```{c}
auto* resultLayout = new QGridLayout(resultTab);
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : actions) {
        if (m_controlAction->menu()->actions().count() <= MAX_OLD_MENU_ACTIONS)
            break;
        JobMenuAction *jobAction = static_cast<JobMenuAction *>(action);
        if (jobAction->isDone()) {
            m_controlAction->menu()->removeAction(action);
            action->deleteLater();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](KIO::CopyJob *kJob) {
        connectJobToDestination(job, dest); // now we have to refresh the destination

        KrJob *krJob = KrJob::createDropJob(job, kJob);
        krJobMan->manageStartedJob(krJob, kJob);
        if (kJob->operationMode() == KIO::CopyJob::Move) { // notify source about removed files
            connectJobToSources(kJob, kJob->srcUrls());
        }
    }
```

#### AUTO 


```{c}
auto *horizontalLayout = new QHBoxLayout();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& fallbackThemeName : themeFallbackList) {
            QIcon::setThemeName(fallbackThemeName);
            if (QIcon::hasThemeIcon(iconName)) {
                return IconSearchResult(QIcon::fromTheme(iconName), currentTheme);
            }
        }
```

#### AUTO 


```{c}
auto action = collection->action(actionName);
```

#### AUTO 


```{c}
auto font = action->font();
```

#### AUTO 


```{c}
auto * hbox3 = new QHBoxLayout(hboxWidget3);
```

#### RANGE FOR STATEMENT 


```{c}
for (KrJob *job : qAsConst(m_jobs)) {
            if (anyRunning)
                job->pause();
            else
                job->start();
        }
```

#### AUTO 


```{c}
auto* file2 = (FileItem *)i2->getFileItem();
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        emit terminated(this);
        deleteLater();
    }
```

#### AUTO 


```{c}
auto actionName = isSetter ? QString("setJumpBack") : QString("jumpBack");
```

#### RANGE FOR STATEMENT 


```{c}
for (FileItem *item : _fileItems.values()) {
        if (!item->isDir() && item->getName() != "." && item->getName() != "..") {
            temp += item->getSize();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto & it : currentMountList) {
            if (krMtMan.networkFilesystem(it->mountType()) &&
                    it->mountPoint() == mountPoint) {
                mounted = true;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl url : urlList) {
        urlListBox->addItem(url.toDisplayString(QUrl::PreferLocalFile));
    }
```

#### AUTO 


```{c}
auto* toolbarLayout = new QHBoxLayout;
```

#### AUTO 


```{c}
auto *grid = new QGridLayout(compareDirs);
```

#### RANGE FOR STATEMENT 


```{c}
for (Solid::Device &device : Solid::Device::allDevices()) {
        if (device.isValid()) {
            QPointer<Solid::StorageAccess> access = device.as<Solid::StorageAccess>();
            if (access) {
                connect(access, &Solid::StorageAccess::teardownRequested,
                        this, &KMountMan::slotTeardownRequested, Qt::UniqueConnection);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto act : acts) {
            if (act->isSeparator() || act->text() == "") {
                continue;
            }

            if (!searchInSpecialItems && _specialBookmarks.contains(act)) {
                continue;
            }

            if (quickSearchStarted) {
                // if the first key press is an accelerator key, let the accelerator handler process this event
                if (act->text().contains('&' + kev->text(), Qt::CaseInsensitive)) {
                    qDebug() << "Bookmark search: hit accelerator key of" << act;
                    _setQuickSearchText("");
                    return QObject::eventFilter(obj, ev);
                }

                // strip accelerator keys from actions so they don't interfere with the search key press events
                auto text = act->text();
                _quickSearchOriginalActionTitles.insert(act, text);
                act->setText(KLocalizedString::removeAcceleratorMarker(text));
            }

            // match prefix of the action text to the query
            if (act->text().left(_quickSearchText().length()).compare(_quickSearchText(), matchCase) == 0) {
                _highlightAction(act);
                if (!matchedAction || matchedAction->menu()) {
                    // Can't highlight menus (see comment below), hopefully pick something we can
                    matchedAction = act;
                }
                nMatches++;
            } else {
                _highlightAction(act, false);
            }
        }
```

#### AUTO 


```{c}
auto menu = PanelContextMenu::run(loc, this);
```

#### AUTO 


```{c}
auto *mainLayout = new QVBoxLayout;
```

#### AUTO 


```{c}
auto error = event->args()[ 0 ].value<int>();
```

#### AUTO 


```{c}
auto * minmaxHbox = new QHBoxLayout(minmaxWidget);
```

#### AUTO 


```{c}
auto *tooltipLayout = new QHBoxLayout();
```

#### LAMBDA EXPRESSION 


```{c}
[=](int index) {
        bool resultTabShown = index == searcherTabs->indexOf(resultTab);
        viewAction->setEnabled(resultTabShown);
        editAction->setEnabled(resultTabShown);
        compareAction->setEnabled(resultTabShown);
        copyAction->setEnabled(resultTabShown);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](KIO::Job *job) { connectJob(job, currentDirectory()); }
```

#### AUTO 


```{c}
auto * vbox2 = new QVBoxLayout(vboxWidget2);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto & it : possible) {
        // make sure we don't add things we've already added
        if (KMountMan::findInListByMntPoint(mounted, it->mountPoint())) {
            continue;
        } else {
            fsData data;
            data.setMntPoint(it->mountPoint());
            data.setMounted(false);
            data.setType(it->mountType());
            data.setName(it->mountedFrom());

            if (mountMan->invalidFilesystem(data.type()))
                continue;

            fileSystems.append(data);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=] (const QUrl &url) { slotNewTab(url); }
```

#### RANGE FOR STATEMENT 


```{c}
for(QPointer<vfs> vfsPointer: _vfs_list) {
        // always refresh virtual vfs showing a virtual directory; it can contain files from various
        // places, we don't know if they were (re)moved, refreshing is also fast enough
        vfs *vfs = vfsPointer.data();
        const QUrl vfsDir = vfs->currentDirectory();
        if ((vfsDir == vfs::cleanUrl(directory) || (vfsDir.scheme() == "virt" && !vfs->isRoot()))
            && !vfs->hasAutoUpdate()) {
            // refresh all vfs currently showing this directory...
            vfs->refresh();
        } else if (!mountPoint.isEmpty() && mountPoint == vfs->mountPoint()) {
            // ..or refresh filesystem info if mount point is the same (for free space update)
            vfs->updateFilesystemInfo();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& name : dir.entryList(QDir::NoDotAndDotDot)) {
        if (stop)
            return;

        countFiles(dir.absoluteFilePath(name), totalFiles, stop);
    }
```

#### AUTO 


```{c}
const auto dialogResult = dialog.exec();
```

#### AUTO 


```{c}
const auto *p = dynamic_cast<const Directory *>(m_focus->file());
```

#### LAMBDA EXPRESSION 


```{c}
[=] {
        panel->view->setSelectionUrls(selectedUrls);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](bool checked) mutable {
        _queueMode = checked;
        cfg.writeEntry("Queue Mode", _queueMode);
    }
```

#### AUTO 


```{c}
auto * sb = device.as<Solid::Block>();
```

#### AUTO 


```{c}
auto* hSpacer1 = new QSpacerItem(0, 5);
```

#### AUTO 


```{c}
auto *iconThemeLayout = new QHBoxLayout();
```

#### AUTO 


```{c}
auto *filterWidget = new QTabWidget;
```

#### RANGE FOR STATEMENT 


```{c}
for (auto & domain : domains) {
            //qDebug() << "Domain to remove: " << *it;
            if (config.hasGroup(domain))
                config.deleteGroup(domain);
            else if (config.group("").hasKey(domain))
                config.group("").deleteEntry(domain);       //don't know what group name is supposed to be XXX
        }
```

#### AUTO 


```{c}
auto *mouseLayout = new QGridLayout(tab_mouse);
```

#### AUTO 


```{c}
auto *menu = new QMenu(krMainWindow);
```

#### AUTO 


```{c}
auto *button = new QPushButton(parent);
```

#### AUTO 


```{c}
const auto& fallbackThemeName
```

#### AUTO 


```{c}
auto & _app
```

#### AUTO 


```{c}
auto* pvb = dynamic_cast<PanelViewerBase*>(tabBar.currentWidget());
```

#### RANGE FOR STATEMENT 


```{c}
for (KrJob *job: _jobs) {
            job->cancel();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto & it : _showonlyPath) {
            if (it.right(1) == "*") {
                if (currentURL.path().indexOf(it.left(it.length() - 1)) == 0) {
                    available = true;
                    break;
                }
            } else
                if (currentURL.adjusted(QUrl::RemoveFilename|QUrl::StripTrailingSlash).path() == it) {    // FIXME remove trailing slashes at the xml-parsing (faster because done only once)
                    available = true;
                    break;
                }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (vfile *file : files)
        uniqueMimeTypes.insert(file->vfile_getMime());
```

#### LAMBDA EXPRESSION 


```{c}
[=]() { emit fileSystemChanged(destination); }
```

#### AUTO 


```{c}
auto maxValue = event->args()[ 0 ].value<qulonglong>();
```

#### AUTO 


```{c}
auto *nameGroup = new QGroupBox(this);
```

#### AUTO 


```{c}
auto* l = new KUrlLabel(_app->getWebsite(), _app->getAppName(), toolBoxWidget);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& source : sourceList) {
        sourceURLs.append(QUrl::fromUserInput(source, QString(), QUrl::AssumeLocalFile));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& line : m_process->stdOutput()) {
        const QString filename = line.mid(line.indexOf(' ') + 2) + type;
        if (!saveChecksumFile(QStringList() << line, filename)) {
            KMessageBox::error(this, i18n("Errors occurred while saving multiple checksums. Stopping"));
            krApp->stopWait();
            return false;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto & it2 : currentMountList) {
                if (krMtMan.networkFilesystem(it2->mountType()) &&
                        path == it2->mountPoint()) {
                    mounted = true;
                    break;
                }
            }
```

#### AUTO 


```{c}
auto *status = new KrusaderStatus(this);
```

#### LAMBDA EXPRESSION 


```{c}
[=](KIO::Job*, QByteArray array) {
            if (array.size() != 0) {
                _tempFile->write(array);
            } }
```

#### AUTO 


```{c}
auto* ke = (QKeyEvent*) e;
```

#### AUTO 


```{c}
const auto performNewline = [&] (qint64 nextRowStartOffset) {
        list << row;
        effLength = 0;
        row = "";
        if (locs) {
            (*locs) << (filePos + nextRowStartOffset);
        }
    };
```

#### AUTO 


```{c}
auto *item = new QTreeWidgetItem(urls, lastItem);
```

#### RANGE FOR STATEMENT 


```{c}
for(ButtonEntry entry : buttonList) {
        entry.first->setText(entry.second.first->shortcut().toString() + ' ' + entry.second.second);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (FileItem *file : files) {
        protocols.insert(file->getUrl().scheme());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=] {
                    if (_mainBookmarkPopup && !_mainBookmarkPopup->isHidden()) {
                        _mainBookmarkPopup->close();
                    }
                }
```

#### AUTO 


```{c}
auto *style = new KrStyleProxy();
```

#### LAMBDA EXPRESSION 


```{c}
[=](KIO::Job *, const QUrl &, const QUrl &url) { slotRedirection(url); }
```

#### AUTO 


```{c}
auto *listViewItem = new QTreeWidgetItem(currentListItem);
```

#### AUTO 


```{c}
auto itemView = qobject_cast<QAbstractItemView *>(obj);
```

#### AUTO 


```{c}
auto *urlRequester = dynamic_cast<KonfiguratorURLRequester *>( obj);
```

#### AUTO 


```{c}
auto *containsLayout = new QGridLayout(containsGroup);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto & name : names) {
        m_colorTextValues[name] = group.readEntry(name, QString());
        if (m_colorTextValues[name].count(',') == 2)
            m_colorValues[name] = group.readEntry(name, QColor());
        else
            m_colorValues[name] = QColor();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](const QUrl &url) { newTab(url); }
```

#### AUTO 


```{c}
auto *saveSearchBtn = new QToolButton(this);
```

#### AUTO 


```{c}
auto k = strlen(chksum);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& name : names) {
        if (_exited)
            return;

        const QString path = calcSpaceFileSystem->getUrl(name).toLocalFile();
        if (!QFileInfo::exists(path))
            return;

        countFiles(path, totalFiles, _exited);
    }
```

#### AUTO 


```{c}
auto* ce = (QContextMenuEvent*) event;
```

#### LAMBDA EXPRESSION 


```{c}
[=]() { pathChanged(p); }
```

#### AUTO 


```{c}
auto *menu = dynamic_cast<QMenu *>(obj);
```

#### AUTO 


```{c}
auto *synchGrid = new QGridLayout(this);
```

#### AUTO 


```{c}
auto *syncItem = (SyncViewItem *)itemIn;
```

#### RANGE FOR STATEMENT 


```{c}
for(QPointer<FileSystem> fileSystemPointer: _fileSystems) {
        FileSystem *fs = fileSystemPointer.data();
        // refresh all filesystems currently showing this directory
        // and always refresh filesystems showing a virtual directory; it can contain files from
        // various places, we don't know if they were (re)moved. Refreshing is also fast enough.
        const QUrl fileSystemDir = fs->currentDirectory();
        if ((!fs->hasAutoUpdate() && (fileSystemDir == FileSystem::cleanUrl(directory) ||
                                      (fileSystemDir.scheme() == "virt" && !fs->isRoot())))
            // also refresh if a parent directory was (re)moved (not detected by file watcher)
            || (removed && directory.isParentOf(fileSystemDir))) {
            fs->refresh();
            // ..or refresh filesystem info if mount point is the same (for free space update)
        } else if (!mountPoint.isEmpty() && mountPoint == fs->mountPoint()) {
            fs->updateFilesystemInfo();
        }
    }
```

#### AUTO 


```{c}
auto *containsGroup = new QGroupBox(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto & name : names) {
            KonfiguratorColorChooser * chooser = getColorSelector(name);
            if (!chooser)
                continue;
            colorSettings.setColorTextValue(name, chooser->getValue());
            if (chooser->isValueRGB())
                colorSettings.setColorValue(name, chooser->getColor());
            else
                colorSettings.setColorValue(name, QColor());
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        quickSizeCalcProgress->reset();
        quickSizeCalcProgress->show();
        cancelQuickSizeCalcButton->show();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto i : evilstuff)
        name.replace(i, ('\\' + i));
```

#### AUTO 


```{c}
auto *item = new QTreeWidgetItem(parent);
```

#### AUTO 


```{c}
auto* popup = new AddPlaceholderPopup(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (KrViewItem *item : selectedItems) {
            if (isItemVisible(item)) {
                anyVisible = true;
                break;
            }
        }
```

#### AUTO 


```{c}
auto activeAction = _quickSearchMenu->activeAction();
```

#### AUTO 


```{c}
auto* progress = new QProgressBar(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (FileItem *file : files) {
        _items.append(KFileItem(file->getUrl(), file->getMime(), file->getMode()));
        allFilesAreDirs &= file->isDir();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : actions) {
        if (m_controlAction->menu()->actions().count() <= MAX_OLD_MENU_ACTIONS)
            break;
        auto *jobAction = dynamic_cast<JobMenuAction *>(action);
        if (jobAction->isDone()) {
            m_controlAction->menu()->removeAction(action);
            action->deleteLater();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&] (const int cursorX, const int cursorY, const QTextCursor::MoveMode mode) -> bool {
        if (cursorY > realSizeY) {
            return false;
        }

        _skipCursorChangedListener = true;

        moveCursor(QTextCursor::Start, mode);
        for (int i = 0; i < cursorY; i++) {
            moveCursor(QTextCursor::Down, mode);
        }

        int finalCursorX = cursorX;
        if (_rowContent.count() > cursorY && finalCursorX > _rowContent[ cursorY ].length()) {
            finalCursorX = _rowContent[ cursorY ].length();
        }

        for (int i = 0; i < finalCursorX; i++) {
            moveCursor(QTextCursor::Right, mode);
        }

        _skipCursorChangedListener = false;

        return true;
    }
```

#### AUTO 


```{c}
auto *drag = new QDrag(this);
```

#### AUTO 


```{c}
auto *panelLayout = new QGridLayout(tab_panel);
```

#### AUTO 


```{c}
auto *pvb = dynamic_cast<PanelViewerBase *>(tabBar.widget(index));
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        deleteFile(fileItem, false);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString name : dir.entryList()) {
        if (stop)
            return;

        if (name == QStringLiteral(".") || name == QStringLiteral(".."))
            continue;

        countFiles(dir.absoluteFilePath(name), totalFiles, stop);
    }
```

#### AUTO 


```{c}
auto *mergedBuffer = new char[len + receivedBufferLen];
```

#### RANGE FOR STATEMENT 


```{c}
for (auto item : list) {
        if (auto* actionItem = dynamic_cast<UserActionListViewItem*>(item))
            root.appendChild(actionItem->action()->xmlDump(doc));
    }
```

#### AUTO 


```{c}
auto i
```

#### RANGE FOR STATEMENT 


```{c}
for (KrViewItem *item : selectedItems) {
        urls.append(item->getFileItem()->getUrl());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](KIO::Job *job) { connectSourceVFS(job, urls); }
```

#### AUTO 


```{c}
auto *viewItem = (SyncViewItem *)currentItem->userData();
```

#### AUTO 


```{c}
auto comboBox = dynamic_cast<KHistoryComboBox *>(itemView->parent()->parent());
```

#### RANGE FOR STATEMENT 


```{c}
for (auto & it : _showonlyFile) {
            QRegExp regex = QRegExp(it, Qt::CaseInsensitive, QRegExp::Wildcard);   // case-sensitive = false; wildcards = true
            if (regex.exactMatch(currentURL.fileName())) {
                available = true;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto & _app : _apps) {
        auto* l = new KUrlLabel(_app->getWebsite(), _app->getAppName(), toolBoxWidget);
        toolBox->addWidget(l);

        l->setAlignment(Qt::AlignLeft | Qt::AlignTop);
        l->setContentsMargins(5, 5, 5, 5);
#if KIO_VERSION >= QT_VERSION_CHECK(5, 65, 0)
        connect(l, QOverload<>::of(&KUrlLabel::leftClickedUrl),
                this, [this, l]() { KrToolResultTable::website(l->url()); } );
#else
        connect(l, QOverload<const QString &>::of(&KUrlLabel::leftClickedUrl), this, &KrToolResultTable::website);
#endif
    }
```

#### AUTO 


```{c}
auto menu = new QMenu(mainWindow->widget());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& fileName : fileNames) {
        if (stopListFiles)
            return QStringList();

        QDir subDir = QDir(baseDir.filePath(fileName));
        if (subDir.exists()) {
            subDir.setFilter(QDir::Files);
            QDirIterator it(subDir, QDirIterator::Subdirectories | QDirIterator::FollowSymlinks);
            while (it.hasNext()) {
                if (stopListFiles)
                    return QStringList();

                allFiles << baseDir.relativeFilePath(it.next());
            }
        } else {
            // assume this is a file
            allFiles << fileName;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (vfile *vf : _vfiles.values()) {
        if (filter.match(vf)) {
            result.append(vf);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](KJob* job) { slotJobResult(job, refresh); }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto act : acts) {
            if (act->isSeparator() || act->text() == "") {
                continue;
            }

            if (quickSearchStarted) {
                // if the first key press is an accelerator key, let the accelerator handler process this event
                if (act->text().contains('&' + kev->text(), Qt::CaseInsensitive)) {
                    qDebug() << "Bookmark search: hit accelerator key of" << act;
                    _setQuickSearchText("");
                    break;
                }

                // strip accelerator keys from actions so they don't interfere with the search key press events
                auto text = act->text();
                _quickSearchOriginalActionTitles.insert(act, text);
                act->setText(KLocalizedString::removeAcceleratorMarker(text));
            }

            // match prefix of the action text to the query
            if (act->text().left(_quickSearchText().length()).compare(_quickSearchText(), Qt::CaseInsensitive) == 0) {
                _highlightAction(act);
                if (!firstMatch) {
                    firstMatch = act;
                }
                nMatches++;
            } else {
                _highlightAction(act, false);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString fileName : fileNames) {
        files.append(panel->func->files()->getFileItem(fileName));
    }
```

#### AUTO 


```{c}
auto *linkMenu = new QMenu(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto & mime : mimes)
            addMime(mime, it);
```

#### AUTO 


```{c}
auto *job = new KIO::CommandLauncherJob(cmd, this);
```

#### AUTO 


```{c}
auto *scrollArea = new QScrollArea(tabWidget);
```

#### AUTO 


```{c}
auto *mimeData = new QMimeData;
```

#### AUTO 


```{c}
auto editor = qobject_cast<QLineEdit *>(_editor);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto act : acts) {
            if (act->isSeparator() || act->text() == "") {
                continue;
            }

            if (!searchInSpecialItems && _specialBookmarks.contains(act)) {
                continue;
            }

            if (quickSearchStarted) {
                // if the first key press is an accelerator key, let the accelerator handler process this event
                if (act->text().contains('&' + kev->text(), Qt::CaseInsensitive)) {
                    qDebug() << "Bookmark search: hit accelerator key of" << act;
                    _setQuickSearchText("");
                    return QObject::eventFilter(obj, ev);
                }

                // strip accelerator keys from actions so they don't interfere with the search key press events
                auto text = act->text();
                _quickSearchOriginalActionTitles.insert(act, text);
                act->setText(KLocalizedString::removeAcceleratorMarker(text));
            }

            // match prefix of the action text to the query
            if (act->text().left(_quickSearchText().length()).compare(_quickSearchText(), Qt::CaseInsensitive) == 0) {
                _highlightAction(act);
                if (!matchedAction || matchedAction->menu()) {
                    // Can't highlight menus (see comment below), hopefully pick something we can
                    matchedAction = act;
                }
                nMatches++;
            } else {
                _highlightAction(act, false);
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() { updateTab(panel); }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {receivedOutput(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto & it : protList) {
        addProtocol(it);

        QStringList mimes = group.readEntry(QString("Mimes For %1").arg(it), QStringList());

        for (auto & mime : mimes)
            addMime(mime, it);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString name : fileNames) {
            if (_virtVfsDict.find(parentDir) != _virtVfsDict.end()) {
                QList<QUrl> *urlList = _virtVfsDict[parentDir];
                urlList->removeAll(getUrl(name));
            }
        }
```

#### AUTO 


```{c}
auto* popup = new QMenu(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl& fileUrl : urls) {
            if (!fileUrl.isLocalFile()) {
                continue; // TODO only local fs supported
            }

            const QString filePath = fileUrl.toLocalFile();
            QFileInfo fileInfo(filePath);
            if (fileInfo.isDir() && !fileInfo.isSymLink()) {
                // read local dir...
                const QDir dir(filePath);
                if (!dir.entryList(QDir::AllEntries | QDir::System | QDir::Hidden |
                                   QDir::NoDotAndDotDot).isEmpty()) {

                    // ...is not empty, ask user
                    const QString fileString = showPath ? filePath : fileUrl.fileName();
                    const KMessageBox::ButtonCode result = KMessageBox::warningYesNoCancel(
                        krMainWindow,
                        i18n("<qt><p>Folder <b>%1</b> is not empty.</p>", fileString) +
                            (moveToTrash ? i18n("<p>Skip this one or trash all?</p></qt>") :
                                           i18n("<p>Skip this one or delete all?</p></qt>")),
                        QString(), KGuiItem(i18n("&Skip")),
                        KGuiItem(moveToTrash ? i18n("&Trash All") : i18n("&Delete All")));
                    if (result == KMessageBox::Yes) {
                        confirmedFiles.remove(fileUrl); // skip this dir
                    } else if (result == KMessageBox::No) {
                        break; // accept all remaining
                    } else {
                        return QList<QUrl>(); // cancel
                    }
                }
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
                qDebug() << "Bookmark search: active action =" << quickSearchMenu->activeAction();
                if (!quickSearchMenu->activeAction() && activeAction) {
                    quickSearchMenu->setActiveAction(activeAction);
                    qDebug() << "Bookmark search: restored active action =" << quickSearchMenu->activeAction();
                }
            }
```

#### AUTO 


```{c}
auto *duItem = dynamic_cast<DULinesItem *>(lvitem);
```

#### RANGE FOR STATEMENT 


```{c}
for (FileItem *fileItem : fileSystem->fileItems()) {
        const QUrl fileUrl = fileItem->getUrl();

        if (m_query->isRecursive() &&
            ((!fileItem->isSymLink() && fileItem->isDir()) || (fileItem->isSymLink() && m_query->followLinks()))) {
            // query search in subdirectory
            m_unScannedUrls.push(fileUrl);
        }

        if (m_query->searchInArchives() && fileUrl.isLocalFile() &&
            KRarcHandler::arcSupported(fileItem->getMime())) {
            // query search in archive; NOTE: only supported for local files
            QUrl archiveURL = fileUrl;
            bool encrypted;
            const QString type = krArcMan.getType(encrypted, fileUrl.path(), fileItem->getMime());

            if (!encrypted) {
                archiveURL.setScheme(TAR_TYPES.contains(type) ? "tar" : "krarc");
                m_unScannedUrls.push(archiveURL);
            }
        }

        if (m_query->match(fileItem)) {
            // found!
            emit found(*fileItem, m_query->foundText()); // emitting copy of file item
        }

        if (m_timer.elapsed() >= EVENT_PROCESS_DELAY) {
            qApp->processEvents();
            m_timer.start();
            if (m_stopSearch)
                return;
        }
    }
```

#### AUTO 


```{c}
auto* pvb = dynamic_cast<PanelViewerBase*>(tabBar.widget(i));
```

#### AUTO 


```{c}
auto & domain
```

#### LAMBDA EXPRESSION 


```{c}
[=] {setView(inst->id());}
```

#### AUTO 


```{c}
auto * volumeHbox = new QHBoxLayout;
```

#### AUTO 


```{c}
auto & it
```

#### AUTO 


```{c}
auto action = KrBookmark::jumpBackAction(_privateCollection, isSetter, actions);
```

#### LAMBDA EXPRESSION 


```{c}
[=]() { zoomOut(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (KrJob *job: _jobs)
        if (job->isRunning())
            return true;
```

#### LAMBDA EXPRESSION 


```{c}
[=](bool checked) mutable {
        m_queueMode = checked;
        cfg.writeEntry("Queue Mode", m_queueMode);
    }
```

#### AUTO 


```{c}
auto *consistencyHbox = new QHBoxLayout;
```

#### AUTO 


```{c}
auto *groupWidget = new KonfiguratorCheckBoxGroup(parent);
```

#### AUTO 


```{c}
auto keyEvent = static_cast<QKeyEvent *>(event);
```

#### AUTO 


```{c}
auto cPartCompleted = [=]() {
            connect(cpart.data(), &KParts::ReadOnlyPart::destroyed, this, &PanelViewer::slotCPartDestroyed);
            emit openUrlFinished(this, true);
            qDebug() << "openFile completed: '" << curl << "'";
        };
```

#### AUTO 


```{c}
auto* pvb = dynamic_cast<PanelViewerBase*>(tabWidget.currentWidget());
```

#### AUTO 


```{c}
auto *fileitem = const_cast<FileItem *>(item->getFileItem());
```

#### AUTO 


```{c}
auto* spacer_2 = new QSpacerItem(140, 20, QSizePolicy::Expanding, QSizePolicy::Fixed);
```

#### LAMBDA EXPRESSION 


```{c}
[=](const QUrl &url) { ListPanel::duplicateTab(url); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& name : dir.entryList()) {
        if (stop)
            return;

        if (name == QStringLiteral(".") || name == QStringLiteral(".."))
            continue;

        countFiles(dir.absoluteFilePath(name), totalFiles, stop);
    }
```

#### AUTO 


```{c}
auto *page = new QWizardPage;
```

#### LAMBDA EXPRESSION 


```{c}
[=]() { KrVfsHandler::instance().refreshVfs(url); }
```

#### AUTO 


```{c}
auto *actionGroup = new QActionGroup(krusaderApp);
```

#### AUTO 


```{c}
auto *vboxl = new QVBoxLayout(box);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto & fileSystem : fileSystems) {
        // the only thing which is unique is the mount point
        if (fileSystem.mntPoint() == getMntPoint(item)) {
            return & fileSystem;
        }
    }
```

#### AUTO 


```{c}
auto item
```

#### LAMBDA EXPRESSION 


```{c}
[=](KJob *job) {
            _tempFile->flush();
            if (job->error()) {   /* any error occurred? */
                auto *kioJob = dynamic_cast<KIO::TransferJob *>(job);
                KMessageBox::error(_textArea, i18n("Error reading file %1.", kioJob->url().toDisplayString(QUrl::PreferLocalFile)));
            }
            _downloading = false;
            _downloadUpdateTimer.stop();
            slotUpdate();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() { stopListFiles = true; }
```

#### RANGE FOR STATEMENT 


```{c}
for (KrViewItem *item : items) {
        FileItem *file = panel->func->getFileItem(item);
        fileNames.append(file->getUrl().fileName());
    }
```

#### AUTO 


```{c}
auto *grid = new QGridLayout(widget);
```

#### AUTO 


```{c}
auto *btnClose = new QPushButton(hboxWidget);
```

#### AUTO 


```{c}
auto selection = selections[currentIndex];
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString ext: m_checksumTools.keys())
        typesFilter += ("*." + ext + ' ');
```

#### AUTO 


```{c}
auto *konfigurator = new Konfigurator(firstTime);
```

#### AUTO 


```{c}
auto *lister = qobject_cast<Lister *>((KParts::ReadOnlyPart *)part);
```

#### AUTO 


```{c}
auto* GroupBox1 = new QGroupBox(this);
```

#### AUTO 


```{c}
auto *kioJob = dynamic_cast<KIO::TransferJob *>(job);
```

#### LAMBDA EXPRESSION 


```{c}
[=]() { emit fileSystemChanged(destination, false); }
```

#### AUTO 


```{c}
auto a  = (uint)(acos((double)e.x() / length) * 916.736);
```

#### LAMBDA EXPRESSION 


```{c}
[=]() { emit fileSystemChanged(url); }
```

#### AUTO 


```{c}
auto *krusader = new Krusader(parser);
```

#### LAMBDA EXPRESSION 


```{c}
[=](KIO::Job *job) {
        connectJobToSources(job, urls);
    }
```

#### AUTO 


```{c}
auto *widgetLayout = new QGridLayout();
```

#### AUTO 


```{c}
auto *jobAction = dynamic_cast<JobMenuAction *>(action);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto & name : names) {
        if (!group.readEntry(name, QString()).isEmpty()) {
            m_numValues[name] = group.readEntry(name, 0);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KrJob *job: m_jobs) {
        totalPercent += job->percent();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& fileName : fileNames) {
        files.append(panel->func->files()->getFileItem(fileName));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](bool checked) {
        syncBrowseButton->setIcon(
            Icon(checked ? "kr_syncbrowse_on" : "kr_syncbrowse_off"));
    }
```

#### AUTO 


```{c}
auto * infoEvent = new UserEvent(CMD_MAXPROGRESSVALUE, args);
```

#### AUTO 


```{c}
auto *listJob = dynamic_cast<KIO::ListJob *>(job);
```

#### AUTO 


```{c}
auto *showOptionsLayout = new QGridLayout(showOptions);
```

#### AUTO 


```{c}
const auto* isoFileEntry = dynamic_cast<const KIsoFile *>(isoEntry);
```

#### AUTO 


```{c}
auto* packers_scroll = new QScrollArea(tabWidget);
```

#### AUTO 


```{c}
auto *listViewItem = new QTreeWidgetItem(linkList);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto & atomicExtension : props->atomicExtensions) {
                    if (fileitemName.endsWith(atomicExtension) && fileitemName != atomicExtension) {
                        loc = fileitemName.length() - atomicExtension.length();
                        break;
                    }
                }
```

#### AUTO 


```{c}
const auto *compWith = dynamic_cast< const DULinesItem * >(&other);
```

#### AUTO 


```{c}
auto *upDir = (Directory *)diskUsage->getCurrentDir()->parent();
```

#### AUTO 


```{c}
auto *v = new QVBoxLayout;
```

#### LAMBDA EXPRESSION 


```{c}
[=](int index) { tabCloseRequest(index, false); }
```

#### AUTO 


```{c}
auto *layout = new QGridLayout(radioWidget);
```

#### AUTO 


```{c}
auto * toolBox = new QVBoxLayout(toolBoxWidget);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto & it : parameter)
        if (it.isSimple())
            lst.push_back(it.string());
        else {
            setError(exp, Error(Error::exp_S_FATAL, Error::exp_C_SYNTAX, i18n("%Each% is not allowed in parameter to %1", description())));
            return QString();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() { emit fileSystemChanged(currentDirectory()); }
```

#### AUTO 


```{c}
auto *resultResp = new QList<QVariant> ();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto & it : commandList) {
            bool exec = true;
            it = QInputDialog::getText(krMainWindow, i18n("Confirm Execution"), i18n("Command being executed:"),
                      QLineEdit::Normal, it, &exec);
            if (exec) {
                proc = actionProcFactoryMethod();
                proc->start(it);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString type: m_checksumTools.keys())
        m_methodBox->addItem(type);
```

#### AUTO 


```{c}
auto* buttonsLayout = new QHBoxLayout();
```

#### LAMBDA EXPRESSION 


```{c}
[=](KIO::Job *job) { connectJob(job, destDir); }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
            slotUpdate();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KIO::UDSEntry entry : entries) {
        FileItem *fileItem = FileSystem::createFileItemFromKIO(entry, _currentDirectory);
        if (fileItem) {
            addFileItem(fileItem);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](bool checked) {
        syncBrowseButton->setIcon(
            QIcon::fromTheme(checked ? "kr_syncbrowse_on" : "kr_syncbrowse_off"));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](const QUrl & _t1) { func->openUrl(_t1); }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto act : acts) {
            if (act->isSeparator() || act->text().isEmpty()) {
                continue;
            }

            if (!searchInSpecialItems && _specialBookmarks.contains(act)) {
                continue;
            }

            if (quickSearchStarted) {
                // if the first key press is an accelerator key, let the accelerator handler process this event
                if (act->text().contains('&' + kev->text(), Qt::CaseInsensitive)) {
                    qDebug() << "Bookmark search: hit accelerator key of" << act;
                    _setQuickSearchText("");
                    return QObject::eventFilter(obj, ev);
                }

                // strip accelerator keys from actions so they don't interfere with the search key press events
                auto text = act->text();
                _quickSearchOriginalActionTitles.insert(act, text);
                act->setText(KLocalizedString::removeAcceleratorMarker(text));
            }

            // match prefix of the action text to the query
            if (act->text().left(_quickSearchText().length()).compare(_quickSearchText(), matchCase) == 0) {
                _highlightAction(act);
                if (!matchedAction || matchedAction->menu()) {
                    // Can't highlight menus (see comment below), hopefully pick something we can
                    matchedAction = act;
                }
                nMatches++;
            } else {
                _highlightAction(act, false);
            }
        }
```

#### AUTO 


```{c}
auto * _iconBox = new QHBoxLayout(_iconWidget);
```

#### LAMBDA EXPRESSION 


```{c}
[=]() { emit filesystemChanged(currentDirectory()); }
```

#### AUTO 


```{c}
auto *excludeComboBox = new KHistoryComboBox(false, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto & it : possibleMountList) {
        if (krMtMan.networkFilesystem(it->mountType())) {
            QString path = it->mountPoint();
            bool mounted = false;
            QString udi = remotePrefix + path;

            QAction * correspondingAct = nullptr;
            foreach(QAction * act, actionList) {
                if (act && act->data().canConvert<QString>() && act->data().toString() == udi) {
                    correspondingAct = act;
                    break;
                }
            }
            for (auto & it2 : currentMountList) {
                if (krMtMan.networkFilesystem(it2->mountType()) &&
                        path == it2->mountPoint()) {
                    mounted = true;
                    break;
                }
            }

            QString name = i18nc("%1 is the mount point of the remote share", "Remote Share [%1]", it->mountPoint());
            QStringList overlays;
            if (mounted)
                overlays << "emblem-mounted";
            QIcon kdeIcon = Icon("network-wired", overlays);

            if (!correspondingAct) {
                QAction * act = popupMenu->addAction(kdeIcon, name);
                act->setData(QVariant(udi));
            } else {
                correspondingAct->setText(name);
                correspondingAct->setIcon(kdeIcon);
            }
        }
    }
```

#### AUTO 


```{c}
auto *sizeGroup = new QGroupBox(this);
```

#### AUTO 


```{c}
auto errorCode = (*result)[ 0 ].value<int>();
```

#### AUTO 


```{c}
auto * re = (QResizeEvent *)event;
```

#### RANGE FOR STATEMENT 


```{c}
for (FileItem *file : files) {
        _items.append(KFileItem(file->getUrl(), file->getMime(),
                                file->getMode()));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QUrl & _t1) { func->openUrl(_t1); }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto item : list) {
        if (auto* actionItem = dynamic_cast<UserActionListViewItem*>(item)) {
            delete actionItem->action(); // remove the action itself
            delete actionItem; // remove the action from the list
        } // if
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QDropEvent *event) {handleDrop(event, true); }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() { slotFocusOnMe(); }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() { zoomIn(); }
```

#### AUTO 


```{c}
auto *duGrid = new QGridLayout();
```

#### AUTO 


```{c}
auto *comboItems = new KONFIGURATOR_NAME_VALUE_PAIR[ profileListSize ];
```

#### AUTO 


```{c}
auto *viewItem = (SynchronizerGUI::SyncViewItem *)currentItem->userData();
```

#### AUTO 


```{c}
auto *ctentry = (CompareTask *) entry;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& type: m_checksumTools.keys())
        m_methodBox->addItem(type);
```

#### AUTO 


```{c}
auto *gd = new KRGetDate(d, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto act : acts) {
            if (act->isSeparator() || act->text() == "") {
                continue;
            }

            if (quickSearchStarted) {
                // if the first key press is an accelerator key, let the accelerator handler process this event
                if (act->text().contains('&' + kev->text(), Qt::CaseInsensitive)) {
                    qDebug() << "Bookmark search: hit accelerator key of" << act;
                    _setQuickSearchText("");
                    return QObject::eventFilter(obj, ev);
                }

                // strip accelerator keys from actions so they don't interfere with the search key press events
                auto text = act->text();
                _quickSearchOriginalActionTitles.insert(act, text);
                act->setText(KLocalizedString::removeAcceleratorMarker(text));
            }

            // match prefix of the action text to the query
            if (act->text().left(_quickSearchText().length()).compare(_quickSearchText(), Qt::CaseInsensitive) == 0) {
                _highlightAction(act);
                if (!matchedAction || matchedAction->menu()) {
                    // Can't highlight menus (see comment below), hopefully pick something we can
                    matchedAction = act;
                }
                nMatches++;
            } else {
                _highlightAction(act, false);
            }
        }
```

#### AUTO 


```{c}
auto *hboxLayout = new QHBoxLayout();
```

#### AUTO 


```{c}
auto* spacer = new QSpacerItem(0, 0, QSizePolicy::Minimum, QSizePolicy::Expanding);
```

#### AUTO 


```{c}
auto* ke = dynamic_cast<QKeyEvent*>( event);
```

#### LAMBDA EXPRESSION 


```{c}
[=](KJob *job) {
            connect(job, &KJob::description, this, &JobMenuAction::slotDescription);
            connect(job, SIGNAL(percent(KJob *, unsigned long)), this,
                    SLOT(slotPercent(KJob *, unsigned long)));
            connect(job, &KJob::suspended, this, &JobMenuAction::updatePauseResumeButton);
            connect(job, &KJob::resumed, this, &JobMenuAction::updatePauseResumeButton);
            connect(job, &KJob::result, this, &JobMenuAction::slotResult);
            connect(job, &KJob::warning, this, [](KJob *, const QString &plain, const QString &) {
                krOut << "unexpected job warning: " << plain;
            });

            updatePauseResumeButton();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto & it : possibleMountList) {
        if (krMtMan.networkFilesystem(it->mountType())) {
            QString path = it->mountPoint();
            bool mounted = false;

            for (auto & it2 : currentMountList) {
                if (krMtMan.networkFilesystem(it2->mountType()) &&
                        it->mountPoint() == it2->mountPoint()) {
                    mounted = true;
                    break;
                }
            }

            QString name = i18nc("%1 is the mount point of the remote share", "Remote Share [%1]", it->mountPoint());
            QStringList overlays;
            if (mounted)
                overlays << "emblem-mounted";
            QAction * act = popupMenu->addAction(Icon("network-wired", overlays), name);
            QString udi = remotePrefix + it->mountPoint();
            act->setData(QVariant(udi));
        }
    }
```

#### AUTO 


```{c}
auto *removeButton = new QToolButton(hboxWidget3);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto & item : itemList)
        isChanged = isChanged || item->isChanged();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString name : fileNames) {
            if (_virtFilesystemDict.find(parentDir) != _virtFilesystemDict.end()) {
                QList<QUrl> *urlList = _virtFilesystemDict[parentDir];
                urlList->removeAll(getUrl(name));
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() { emit fileSystemChanged(QUrl("trash:/"), false); }
```

#### AUTO 


```{c}
auto selections = QList<EditorSelection>();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto & it : _showonlyProtocol) {
            //qDebug() << "KrAction::isAvailable currentProtocol: " << currentURL.scheme() << " =?= " << *it;
            if (currentURL.scheme() == it) {    // FIXME remove trailing slashes at the xml-parsing (faster because done only once)
                available = true;
                break;
            }
        }
```

#### AUTO 


```{c}
const auto& overlay
```

#### LAMBDA EXPRESSION 


```{c}
[this, l]() { KrToolResultTable::website(l->url()); }
```

#### LAMBDA EXPRESSION 


```{c}
[=](bool isSetter) {
                    auto action = KrBookmark::jumpBackAction(_privateCollection, isSetter, actions);
                    if (action) {
                        menu->addAction(action);
                        _specialBookmarks.append(action);

                        // disconnecting from this as a receiver is important:
                        // we don't want to break connections established by KrBookmark::jumpBackAction
                        disconnect(action, &QAction::triggered, this, nullptr);
                        connect(action, &QAction::triggered, this, slotTriggered);
                    }
                }
```

#### AUTO 


```{c}
auto *stdoutBox = new QVBoxLayout(stdoutWidget);
```

#### AUTO 


```{c}
auto *urlReq = dynamic_cast<KonfiguratorURLRequester *>(obj);
```

#### AUTO 


```{c}
auto *optionGrid = new QGridLayout(optionGridWidget);
```

#### AUTO 


```{c}
auto *kev = dynamic_cast<QKeyEvent *>(ev);
```

#### AUTO 


```{c}
auto *profileHandler = new QGroupBox(this);
```

#### AUTO 


```{c}
auto eventType = ev->type();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& name : names) {
        urls.append(getUrl(name));
    }
```

#### AUTO 


```{c}
auto* spacer_3 = new QSpacerItem(20, 26, QSizePolicy::Fixed, QSizePolicy::Expanding);
```

#### AUTO 


```{c}
auto *ctentry = dynamic_cast<CompareTask *>( entry);
```

#### AUTO 


```{c}
const auto & it
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& ext: m_checksumTools.keys())
        typesFilter += ("*." + ext + ' ');
```

#### RANGE FOR STATEMENT 


```{c}
for (FileItem *file : fs->fileItems())
            m_nextSubUrls << file->getUrl();
```

#### AUTO 


```{c}
auto *hbox = new QHBoxLayout(hboxWidget);
```

#### AUTO 


```{c}
auto text = editor->text();
```

#### AUTO 


```{c}
auto *profileLayout = new QGridLayout(profileHandler);
```

#### AUTO 


```{c}
auto* spacer = new QSpacerItem(48, 20, QSizePolicy::Fixed, QSizePolicy::Fixed);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& line : outputLines)
            addChecksumLine(m_hashesTreeWidget, line);
```

#### AUTO 


```{c}
auto *access = device.as<Solid::StorageAccess>();
```

#### RANGE FOR STATEMENT 


```{c}
for(const QPointer<FileSystem>& fileSystemPointer: _fileSystems) {
        FileSystem *fs = fileSystemPointer.data();
        // refresh all filesystems currently showing this directory
        // and always refresh filesystems showing a virtual directory; it can contain files from
        // various places, we don't know if they were (re)moved. Refreshing is also fast enough.
        const QUrl fileSystemDir = fs->currentDirectory();
        if ((!fs->hasAutoUpdate() && (fileSystemDir == FileSystem::cleanUrl(directory) ||
                                      (fs->type() == FileSystem::FS_VIRTUAL && !fs->isRoot())))
            // also refresh if a parent directory was (re)moved (not detected by file watcher)
            || (removed && directory.isParentOf(fileSystemDir))) {
            fs->refresh();
            // ..or refresh filesystem info if mount point is the same (for free space update)
        } else if (!mountPoint.isEmpty() && mountPoint == fs->mountPoint()) {
            fs->updateFilesystemInfo();
        }
    }
```

#### AUTO 


```{c}
auto *advancedFilter = new AdvancedFilter(this, tabWidget);
```

#### AUTO 


```{c}
auto *selectGroup = new QActionGroup(krusaderApp);
```

#### RANGE FOR STATEMENT 


```{c}
for (FileItem *item : _fileItems.values()) {
        if (filter.match(item)) {
            result.append(item);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl& fileUrl : urls) {
        files.append(showPath ? fileUrl.toDisplayString(QUrl::PreferLocalFile) : fileUrl.fileName());
    }
```

#### AUTO 


```{c}
auto file_item = (FileItem *)item->getFileItem();
```

#### AUTO 


```{c}
auto view
```

#### AUTO 


```{c}
auto  *optdisc = device.as<Solid::OpticalDisc>();
```

#### AUTO 


```{c}
auto comboBox = dynamic_cast<KHistoryComboBox *>(obj);
```

#### LAMBDA EXPRESSION 


```{c}
[=]() { receivedOutput(); }
```

#### AUTO 


```{c}
auto *tabbarLayout = new QHBoxLayout;
```

#### AUTO 


```{c}
auto overlay
```

#### LAMBDA EXPRESSION 


```{c}
[=](QDropEvent *event) { dynamic_cast<ListPanel*>(panel)->handleDrop(event); }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto & it : protList) {
            QStringList mimes = group.readEntry(QString("Mimes For %1").arg(it), QStringList());
            for (auto & mime : mimes)
                (*slaveMap)[mime] = it;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
            connect(cpart.data(), &KParts::ReadOnlyPart::destroyed, this, &PanelViewer::slotCPartDestroyed);
            emit openUrlFinished(this, true);
            qDebug() << "openFile completed: '" << curl << "'";
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl& fileUrl : urls) {
            confirmedFiles.insert(fileUrl);

            if (!fileUrl.isLocalFile()) {
                continue; // TODO only local fs supported
            }

            const QString filePath = fileUrl.toLocalFile();
            QFileInfo fileInfo(filePath);
            if (fileInfo.isDir() && !fileInfo.isSymLink()) {
                // read local dir...
                const QDir dir(filePath);
                if (!dir.entryList(QDir::AllEntries | QDir::System | QDir::Hidden |
                                   QDir::NoDotAndDotDot).isEmpty()) {

                    // ...is not empty, ask user
                    const QString fileString = showPath ? filePath : fileUrl.fileName();
                    const KMessageBox::ButtonCode result = KMessageBox::warningYesNoCancel(
                        krMainWindow,
                        i18n("<qt><p>Folder <b>%1</b> is not empty.</p>", fileString) +
                            (moveToTrash ? i18n("<p>Skip this one or trash all?</p></qt>") :
                                           i18n("<p>Skip this one or delete all?</p></qt>")),
                        QString(), KGuiItem(i18n("&Skip")),
                        KGuiItem(moveToTrash ? i18n("&Trash All") : i18n("&Delete All")));
                    if (result == KMessageBox::Yes) {
                        confirmedFiles.remove(fileUrl); // skip this dir
                    } else if (result == KMessageBox::No) {
                        break; // accept all remaining
                    } else {
                        return QList<QUrl>(); // cancel
                    }
                }
            }
        }
```

#### AUTO 


```{c}
auto & it2
```

#### AUTO 


```{c}
auto percent = (int)(perc * 10000. + 0.5);
```

#### AUTO 


```{c}
auto *pathsGrid = new QGridLayout(general_tab);
```

#### AUTO 


```{c}
auto *optionsGroup = new QGroupBox(generalFilter);
```

#### AUTO 


```{c}
auto *layout = new QGridLayout();
```

#### AUTO 


```{c}
auto *file2 = const_cast<FileItem *>(i2->getFileItem());
```

#### RANGE FOR STATEMENT 


```{c}
for (QString &item : excludedFolderNames)
        if (filename == item)
            return true;
```

#### LAMBDA EXPRESSION 


```{c}
[=](const QUrl &url) { duplicateTab(url); }
```

#### LAMBDA EXPRESSION 


```{c}
[=] {

        if (actionType == KMountMan::ActionType::Mount) {
            mount(mountPoint);
        } else {
            unmount(mountPoint);
        }
    }
```

#### AUTO 


```{c}
auto *m = dynamic_cast<QMouseEvent*>(e);
```

#### LAMBDA EXPRESSION 


```{c}
[=](KIO::CopyJob *kJob) {
        connectJob(job, dest); // now we now we have to refresh the destination

        KrJob *krJob = KrJob::createDropJob(job, kJob);
        krJobMan->manageStartedJob(krJob, kJob);
        if (kJob->operationMode() == KIO::CopyJob::Move) { // notify source about removed files
            connectSourceFileSystem(kJob, kJob->srcUrls());
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() { copyToClipBoard(fileItem, false); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &fileItem : _items) {
            panel->manager()->duplicateTab(fileItem.url(), panel);
        }
```

#### AUTO 


```{c}
const auto *p = (const Directory *)m_focus->file();
```

#### AUTO 


```{c}
auto *ctentry = qobject_cast<CompareTask *>( entry);
```

#### AUTO 


```{c}
auto *urlReq = (KonfiguratorURLRequester *)obj;
```

#### AUTO 


```{c}
auto key = IconCacheKey(_iconName, _overlays, size, mode, state);
```

#### AUTO 


```{c}
auto * sliderHbox = new QHBoxLayout;
```

#### AUTO 


```{c}
auto *pvb = dynamic_cast<PanelViewerBase *>(tabWidget.widget(index));
```

#### LAMBDA EXPRESSION 


```{c}
[=](KJob *job) {
            _tempFile->flush();
            if (job->error()) {   /* any error occurred? */
                auto *kioJob = (KIO::TransferJob *)job;
                KMessageBox::error(_textArea, i18n("Error reading file %1.", kioJob->url().toDisplayString(QUrl::PreferLocalFile)));
            }
            _downloading = false;
            _downloadUpdateTimer.stop();
            slotUpdate();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() { emit fileSystemChanged(QUrl("trash:/")); }
```

#### AUTO 


```{c}
auto *ke = static_cast<QKeyEvent *>(event);
```

#### AUTO 


```{c}
auto *layout = new QVBoxLayout(this);
```

#### AUTO 


```{c}
auto *fileItemActions = new KFileItemActions(this);
```

#### AUTO 


```{c}
auto selection
```

#### AUTO 


```{c}
auto* fileItem = (FileItem *)current->getFileItem();
```

#### AUTO 


```{c}
auto *fileSystem = dynamic_cast<VirtualFileSystem*>(files());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString fileName: fileNames) {
            vfile *vfile = files()->getVfile(fileName);
            if (vfile && !vfile->vfile_isSymLink() && vfile->vfile_isDir()) {
                // read local dir...
                const QDir dir(vfile->vfile_getUrl().path());
                if (dir.entryList(QDir::TypeMask | QDir::System | QDir::Hidden).count() > 2) {
                    // ...is not empty, ask user
                    const KMessageBox::ButtonCode result = KMessageBox::warningYesNoCancel(
                        krMainWindow,
                        i18n("<qt><p>Folder <b>%1</b> is not empty.</p><p>Skip this one "
                             "or delete all?</p></qt>",
                             fileName),
                        QString(), KGuiItem(i18n("&Skip")), KGuiItem(i18n("&Delete All")));
                    if (result == KMessageBox::Yes) {
                        fileNames.removeAll(fileName); // skip
                    } else if (result == KMessageBox::No) {
                        break; // accept all remaining
                    } else {
                        return; // cancel
                    }
                }
            }
        }
```

#### AUTO 


```{c}
auto *urlRequester = (KonfiguratorURLRequester *) obj;
```

#### AUTO 


```{c}
auto *h = new QHBoxLayout;
```

#### LAMBDA EXPRESSION 


```{c}
[=](const QPoint &pos) {
        QListWidgetItem *item = itemAt(pos);
        emit itemRightClicked(item, viewport()->mapToGlobal(pos));
    }
```

#### AUTO 


```{c}
auto *bm = act->data().value<KrBookmark *>();
```

#### AUTO 


```{c}
auto *ke = (QKeyEvent *)e;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto & it : list) {
        QUrl url = ACTIVE_FUNC->files()->getUrl(it);
        if (url.isEmpty())
            return;

        if (ACTIVE_FUNC->files()->getFileItem(it)->isDir()) {
            KMessageBox::sorry(krApp, i18n("You cannot combine a folder."));
            return;
        }

        if (!unixStyle) {
            QString name = url.fileName();
            int extPos = name.lastIndexOf('.');
            QString ext = name.mid(extPos + 1);
            name.truncate(extPos);
            url = url.adjusted(QUrl::RemoveFilename);
            url.setPath(url.path() + name);

            bool isExtInt;
            ext.toInt(&isExtInt, 10);

            if (extPos < 1 || ext.isEmpty() || (ext != "crc" && !isExtInt)) {
                if (windowsStyle) {
                    KMessageBox::error(nullptr, i18n("Not a split file: %1.", url.toDisplayString(QUrl::PreferLocalFile)));
                    return;
                }
                unixStyle = true;
            } else {

                if (ext != "crc")
                    windowsStyle = true;

                if (baseURL.isEmpty())
                    baseURL = url;
                else if (baseURL != url) {
                    KMessageBox::error(nullptr, i18n("Select only one split file."));
                    return;
                }
            }
        }

        if (unixStyle) {
            bool error = true;

            do {
                const QString& shortName   = it;
                QChar   lastChar  = shortName.at(shortName.length() - 1);

                if (lastChar.isLetter()) {
                    char fillLetter = (lastChar.toUpper() == lastChar) ? 'A' : 'a';

                    if (commonName.isNull()) {
                        commonLength = shortName.length();
                        commonName = shortName;

                        while (commonName.length()) {
                            QString shorter  = commonName.left(commonName.length() - 1);
                            QString testFile = shorter.leftJustified(commonLength, fillLetter);

                            if (ACTIVE_FUNC->files()->getFileItem(testFile) == nullptr)
                                break;
                            else {
                                commonName = shorter;
                                baseURL = ACTIVE_PANEL->virtualPath().adjusted(QUrl::StripTrailingSlash);
                                baseURL.setPath(baseURL.path() + '/' + (testFile));
                            }
                        }

                        error = (commonName == shortName);
                    } else if (commonLength == shortName.length() && shortName.startsWith(commonName))
                        error = false;
                }
            } while (false);

            if (error) {
                KMessageBox::error(nullptr, i18n("Not a split file: %1.", url.toDisplayString(QUrl::PreferLocalFile)));
                return;
            }
        }
    }
```

#### AUTO 


```{c}
auto *listItem = (SyncViewItem *)item->userData();
```

#### AUTO 


```{c}
auto* file1 = (FileItem *)i1->getFileItem();
```

#### AUTO 


```{c}
auto* searchBaseLayout = new QGridLayout(this);
```

#### AUTO 


```{c}
auto pixmap = new QPixmap;
```

#### AUTO 


```{c}
auto* ce = dynamic_cast<QContextMenuEvent*>( event);
```

#### RANGE FOR STATEMENT 


```{c}
for (KrJob *job: _jobs)
        connect(job, &KrJob::terminated, this, &JobMan::slotUpdateMessageBox);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto & it2 : currentMountList) {
                if (krMtMan.networkFilesystem(it2->mountType()) &&
                        it->mountPoint() == it2->mountPoint()) {
                    mounted = true;
                    break;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (vfile *vf : _vfiles.values()) {
        if (!vf->vfile_isDir() && vf->vfile_getName() != "." && vf->vfile_getName() != "..") {
            temp += vf->vfile_getSize();
        }
    }
```

#### AUTO 


```{c}
auto* layout = new QVBoxLayout(page);
```

#### AUTO 


```{c}
auto & fileSystem
```

#### RANGE FOR STATEMENT 


```{c}
for (auto & it : list) {
        if (--items == 0 && !remaining.endsWith('\n'))
            remaining = it;
        else {
            if (dontSearchPath) {
                QRegExp regExp(pattern, isCs ? Qt::CaseSensitive : Qt::CaseInsensitive, QRegExp::Wildcard);
                QString fileName = it.trimmed();
                if (fileName.endsWith(QLatin1String("/")) && fileName != "/") {
                    fileName.truncate(fileName.length() - 1);
                }
                fileName = fileName.mid(fileName.lastIndexOf('/') + 1);

                if (!regExp.exactMatch(fileName))
                    continue;
            }
            if (onlyExist) {
                KFileItem file(QUrl::fromLocalFile(it.trimmed()));
                if (!file.isReadable())
                    continue;
            }

            if (lastItem)
                lastItem = new QTreeWidgetItem(resultList, lastItem);
            else
                lastItem = new QTreeWidgetItem(resultList);

            lastItem->setText(0, it);
        }
    }
```

#### AUTO 


```{c}
auto itemView = dynamic_cast<QAbstractItemView *>(obj);
```

#### RANGE FOR STATEMENT 


```{c}
for (FileItem *fileitem : fileSystem_->fileItems()) {
        QUrl fileURL = fileitem->getUrl();

        if (query->isRecursive() && ((fileitem->isSymLink() && query->followLinks()) || fileitem->isDir()))
            unScannedUrls.push(fileURL);

        if (query->match(fileitem)) {
            // if we got here - we got a winner
            results.append(fileURL.toDisplayString(QUrl::PreferLocalFile));

            emit found(*fileitem, query->foundText()); // emitting copy of file item
        }

        if (timer.elapsed() >= EVENT_PROCESS_DELAY) {
            qApp->processEvents();
            timer.start();
            if (stopSearch) return;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto & fileName : fileNames) {
        proc << fileName;
    }
```

#### AUTO 


```{c}
auto *currentPg = dynamic_cast<KonfiguratorPage *>(before->widget());
```

#### AUTO 


```{c}
auto *groupBox = new QGroupBox(parent);
```

#### RANGE FOR STATEMENT 


```{c}
for (QUrl fileUrl : urls) {
            if (!fileUrl.isLocalFile()) {
                continue; // TODO only local fs supported
            }

            const QString filePath = fileUrl.toLocalFile();
            QFileInfo fileInfo(filePath);
            if (fileInfo.isDir() && !fileInfo.isSymLink()) {
                // read local dir...
                const QDir dir(filePath);
                if (!dir.entryList(QDir::AllEntries | QDir::System | QDir::Hidden |
                                   QDir::NoDotAndDotDot).isEmpty()) {

                    // ...is not empty, ask user
                    const QString fileString = showPath ? filePath : fileUrl.fileName();
                    const KMessageBox::ButtonCode result = KMessageBox::warningYesNoCancel(
                        krMainWindow,
                        i18n("<qt><p>Folder <b>%1</b> is not empty.</p>", fileString) +
                            (moveToTrash ? i18n("<p>Skip this one or trash all?</p></qt>") :
                                           i18n("<p>Skip this one or delete all?</p></qt>")),
                        QString(), KGuiItem(i18n("&Skip")),
                        KGuiItem(moveToTrash ? i18n("&Trash All") : i18n("&Delete All")));
                    if (result == KMessageBox::Yes) {
                        confirmedFiles.remove(fileUrl); // skip this dir
                    } else if (result == KMessageBox::No) {
                        break; // accept all remaining
                    } else {
                        return QList<QUrl>(); // cancel
                    }
                }
            }
        }
```

#### AUTO 


```{c}
const auto pc = uint((100 * files) / (double)root->fileCount());
```

#### AUTO 


```{c}
auto *regAct = dynamic_cast<RegExpAction *>(act);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &fileItem : _items) {
            panel->manager()->newTab(fileItem.url(), panel);
        }
```

#### AUTO 


```{c}
auto parts = text.split('.');
```

#### AUTO 


```{c}
auto *sd = new SynchronizeDialog(this, &synchronizer,
            copyToLeftNr, copyToLeftSize, copyToRightNr,
            copyToRightSize, deleteNr, deleteSize,
            parallelThreadsSpinBox->value());
```

#### AUTO 


```{c}
auto *s = new Segment(*it, a_start, a_len);
```

#### AUTO 


```{c}
auto *layouts = new KONFIGURATOR_NAME_VALUE_PAIR[numLayouts];
```

#### AUTO 


```{c}
auto *hboxlayout = new QHBoxLayout(spacerWidget);
```

#### LAMBDA EXPRESSION 


```{c}
[](KJob *, const QString &plain, const QString &) {
                krOut << "unexpected job warning: " << plain;
            }
```

#### LAMBDA EXPRESSION 


```{c}
[=](KIO::Job *job) { connectSourceFileSystem(job, urls); }
```

#### AUTO 


```{c}
auto *dir = dynamic_cast<Directory *>(file);
```

#### AUTO 


```{c}
auto *iso = static_cast<KIso*>(udata);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : urls) {
            // NOTE: we only support verifying local files for this safeguard option
            if (!url.isLocalFile() || deleteAllIsChosen) {
                urlsMarkedForDeletion.append(url);
                continue;
            }

            bool markForDeletion = true;
            const QString filePath = url.toLocalFile();
            QFileInfo fileInfo(filePath);
            if (fileInfo.isDir() && !fileInfo.isSymLink()) {
                // read local dir
                const QDir dir(filePath);
                if (!dir.entryList(QDir::AllEntries | QDir::System | QDir::Hidden |
                                   QDir::NoDotAndDotDot).isEmpty()) {

                    // if the dir is not empty, show a confirmation dialog with buttons:
                    // * Skip (-> KMessageBox::Yes)
                    // * Delete All (-> KMessageBox::No)
                    // * Cancel (-> KMessageBox::Cancel)
                    const QString fileString = showPath ? filePath : url.fileName();
                    const KMessageBox::ButtonCode result = KMessageBox::warningYesNoCancel(
                        krMainWindow,
                        i18n("<qt><p>Folder <b>%1</b> is not empty.</p>", fileString) +
                            (moveToTrash ? i18n("<p>Skip this one or trash all?</p></qt>") :
                                           i18n("<p>Skip this one or delete all?</p></qt>")),
                        QString(), KGuiItem(i18n("&Skip")),
                        KGuiItem(moveToTrash ? i18n("&Trash All") : i18n("&Delete All")));

                    // process user response
                    if (result == KMessageBox::Yes) {
                        // skip this dir
                        markForDeletion = false;
                    } else if (result == KMessageBox::No) {
                        // delete all
                        deleteAllIsChosen = true;
                    } else {
                        // cancel
                        return QList<QUrl>();
                    }
                }
            }

            if (markForDeletion)
                urlsMarkedForDeletion.append(url);
        }
```

#### AUTO 


```{c}
auto * infoEvent = new UserEvent(CMD_RESET, args);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto & item : itemList) {
        if (item->subPage() == activePage)
            item->setDefaults();
    }
```

#### AUTO 


```{c}
auto *userActionMenu = dynamic_cast<KActionMenu *>( KrActions::actUserMenu);
```

#### AUTO 


```{c}
auto length = text.length();
```

#### AUTO 


```{c}
auto *containsCbsLayout = new QHBoxLayout();
```

#### LAMBDA EXPRESSION 


```{c}
[=](int state) {
        KConfigGroup group(krConfig, "Search");
        group.writeEntry("QueryToClipboard", state);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& protocol : sProtocols) {
        if (availableProtocols.contains(protocol))
            prefix->addItem(protocol + QStringLiteral("://"));
    }
```

#### AUTO 


```{c}
auto* spacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);
```

#### RANGE FOR STATEMENT 


```{c}
for(QPointer<FileSystem> fileSystemPointer: _fileSystems) {
        // always refresh filesystems showing a virtual directory; it can contain files from various
        // places, we don't know if they were (re)moved, refreshing is also fast enough
        FileSystem *fs = fileSystemPointer.data();
        const QUrl fileSystemDir = fs->currentDirectory();
        if ((fileSystemDir == FileSystem::cleanUrl(directory) ||
             (fileSystemDir.scheme() == "virt" && !fs->isRoot())) &&
            !fs->hasAutoUpdate()) {
            // refresh all filesystems currently showing this directory...
            fs->refresh();
        } else if (!mountPoint.isEmpty() && mountPoint == fs->mountPoint()) {
            // ..or refresh filesystem info if mount point is the same (for free space update)
            fs->updateFilesystemInfo();
        }
    }
```

#### AUTO 


```{c}
auto *newMenu = new QMenu(menu);
```

#### AUTO 


```{c}
auto *listWidget = new KrListWidget;
```

#### AUTO 


```{c}
auto *recurseLayout = new QHBoxLayout();
```

#### LAMBDA EXPRESSION 


```{c}
[=](KJob *job) {
            _tempFile->flush();
            if (job->error()) {   /* any error occurred? */
                KIO::TransferJob *kioJob = (KIO::TransferJob *)job;
                KMessageBox::error(_textArea, i18n("Error reading file %1.", kioJob->url().toDisplayString(QUrl::PreferLocalFile)));
            }
            _downloading = false;
            _downloadUpdateTimer.stop();
            slotUpdate();
        }
```

#### AUTO 


```{c}
auto * passwordGrid = new QGridLayout;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& overlay : overlays) {
        if (overlay.isEmpty() || iconLoader->hasIcon(overlay)) {
            fixedOverlays << overlay;
        } else {
            fixedOverlays << "emblem-unreadable";
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](KIO::Job *job) { connectJob(job, dest); }
```

#### AUTO 


```{c}
auto metaDataList = KParts::PartLoader::partsForMimeType(mimetype);
```

#### AUTO 


```{c}
auto *sliderVBox = new QVBoxLayout(sliderVBoxWidget);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto & _app : _apps) {
        auto* l = new KUrlLabel(_app->getWebsite(), _app->getAppName(), toolBoxWidget);
        toolBox->addWidget(l);

        l->setAlignment(Qt::AlignLeft | Qt::AlignTop);
        l->setContentsMargins(5, 5, 5, 5);
        connect(l, QOverload<const QString &>::of(&KUrlLabel::leftClickedUrl), this, &KrToolResultTable::website);
    }
```

#### AUTO 


```{c}
auto pcnt = (int)(100. * (double)receivedBytes / (double)totalBytes + .5);
```

#### AUTO 


```{c}
const auto pctInt = (int) pcnt;
```

#### RANGE FOR STATEMENT 


```{c}
for (QExplicitlySharedDataPointer<KMountPoint> currentMountPoint : currentMountPoints) {
            if (currentMountPoint->mountPoint() == possibleMountPoint->mountPoint()) {
                // found -> needs umount
                needUmount = true;
                break;
            }
        }
```

#### AUTO 


```{c}
auto * infoEvent = new UserEvent(CMD_ADD_PROGRESS, args);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto overlay : overlays) {
        if (overlay.isEmpty() || iconLoader->hasIcon(overlay)) {
            fixedOverlays << overlay;
        } else {
            fixedOverlays << "emblem-unreadable";
        }
    }
```

#### AUTO 


```{c}
auto *ui = dynamic_cast<KIO::JobUiDelegate*>(job->uiDelegate());
```

#### AUTO 


```{c}
auto *kgArchivesLayout = new QGridLayout(innerWidget);
```

#### AUTO 


```{c}
auto *iconSizes = new KONFIGURATOR_NAME_VALUE_PAIR[KrView::iconSizes.count()];
```

#### AUTO 


```{c}
auto *ownershipGroup = new QGroupBox(this);
```

#### AUTO 


```{c}
const auto *compWith = dynamic_cast< const DUListViewItem * >(&other);
```

#### AUTO 


```{c}
auto file_item = const_cast<FileItem *>(item->getFileItem());
```

#### RANGE FOR STATEMENT 


```{c}
for (FileItem *fileItem : fileSystem->fileItems()) {
        const QUrl fileUrl = fileItem->getUrl();

        if (m_query->isRecursive() &&
            (fileItem->isDir() || (fileItem->isSymLink() && m_query->followLinks()))) {
            // query search in subdirectory
            m_unScannedUrls.push(fileUrl);
        }

        if (m_query->searchInArchives() && fileUrl.isLocalFile() &&
            KRarcHandler::arcSupported(fileItem->getMime())) {
            // query search in archive; NOTE: only supported for local files
            QUrl archiveURL = fileUrl;
            bool encrypted;
            const QString type = arcHandler.getType(encrypted, fileUrl.path(), fileItem->getMime());

            if (!encrypted) {
                archiveURL.setScheme(TAR_TYPES.contains(type) ? "tar" : "krarc");
                m_unScannedUrls.push(archiveURL);
            }
        }

        if (m_query->match(fileItem)) {
            // found!
            emit found(*fileItem, m_query->foundText()); // emitting copy of file item
        }

        if (m_timer.elapsed() >= EVENT_PROCESS_DELAY) {
            qApp->processEvents();
            m_timer.start();
            if (m_stopSearch)
                return;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(QPointer<FileSystem> fileSystemPointer: _fileSystems) {
        FileSystem *fs = fileSystemPointer.data();
        // refresh all filesystems currently showing this directory
        // and always refresh filesystems showing a virtual directory; it can contain files from
        // various places, we don't know if they were (re)moved. Refreshing is also fast enough.
        const QUrl fileSystemDir = fs->currentDirectory();
        if ((!fs->hasAutoUpdate() && (fileSystemDir == FileSystem::cleanUrl(directory) ||
                                      (fs->type() == FileSystem::FS_VIRTUAL && !fs->isRoot())))
            // also refresh if a parent directory was (re)moved (not detected by file watcher)
            || (removed && directory.isParentOf(fileSystemDir))) {
            fs->refresh();
            // ..or refresh filesystem info if mount point is the same (for free space update)
        } else if (!mountPoint.isEmpty() && mountPoint == fs->mountPoint()) {
            fs->updateFilesystemInfo();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        // moving position clockwise
        setSidebarPosition((sidebarPosition() + 1) % 4); }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto view : _instance.m_objects) {
        if(this != view) {
            view->_ignoreSettingsChange = true;
            view->copySettingsFrom(this);
            view->_ignoreSettingsChange = false;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KrJob *job: qAsConst(m_jobs)) {
        totalPercent += job->percent();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        KIO::PasteJob *job = KIO::paste(QApplication::clipboard()->mimeData(), fileItem.url());
        KJobWidgets::setWindow(job, this);
    }
```

#### AUTO 


```{c}
const auto setUpCursor = [&] (const int cursorX, const int cursorY, const QTextCursor::MoveMode mode) -> bool {
        if (cursorY > realSizeY) {
            return false;
        }

        _skipCursorChangedListener = true;

        moveCursor(QTextCursor::Start, mode);
        for (int i = 0; i < cursorY; i++) {
            moveCursor(QTextCursor::Down, mode);
        }

        int finalCursorX = cursorX;
        if (_rowContent.count() > cursorY && finalCursorX > _rowContent[ cursorY ].length()) {
            finalCursorX = _rowContent[ cursorY ].length();
        }

        for (int i = 0; i < finalCursorX; i++) {
            moveCursor(QTextCursor::Right, mode);
        }

        _skipCursorChangedListener = false;

        return true;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[](KrJob *job) {return job->isRunning();}
```

#### AUTO 


```{c}
auto * menu = new QMenu();
```

#### AUTO 


```{c}
auto* mimeData = new QMimeData();
```

#### AUTO 


```{c}
auto & _tableHeader
```

#### AUTO 


```{c}
auto *ke = dynamic_cast<QKeyEvent*>(e);
```

#### AUTO 


```{c}
auto *item = new QTreeWidgetItem(lst);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString name : files) {
        if (_exited)
            return;

        const QString path = calcSpaceFileSystem->getUrl(name).toLocalFile();
        if (!QFileInfo(path).exists())
            return;

        countFiles(path, totalFiles, _exited);
    }
```

#### AUTO 


```{c}
auto *tabs_view = new QTabWidget(panelGrp);
```

#### AUTO 


```{c}
auto *hbox = new QHBoxLayout(statusWidget);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto & _app : _apps) {
        _label = new QLabel(_app->getPath(), vboxWidget);
        _label->setContentsMargins(5, 5, 5, 5);
        _label->setAlignment(Qt::AlignTop);
        vbox->addWidget(_label);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KIO::UDSEntry entry : entries) {
        vfile *vfile = vfs::createVFileFromKIO(entry, _currentDirectory);
        if (vfile) {
            addVfile(vfile);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KrJob *job: _jobs) {
        totalPercent += job->percent();
    }
```

#### AUTO 


```{c}
const auto *menuItem =
                    qstyleoption_cast<const QStyleOptionMenuItem*>(option);
```

#### LAMBDA EXPRESSION 


```{c}
[=] {
        if (!_cursorBlinkMutex.tryLock()) {
            return;
        }
        setCursorWidth(cursorWidth() == 0 ? 2 : 0);
        _cursorBlinkMutex.unlock();
    }
```

#### AUTO 


```{c}
auto *synchronizerGrid = new QGridLayout(synchronizerTab);
```

#### RANGE FOR STATEMENT 


```{c}
for (vfile *file : files) {
        protocols.insert(file->vfile_getUrl().scheme());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto & atomicExtension : properties()->atomicExtensions) {
            if (fileItemName.endsWith(atomicExtension) && fileItemName != atomicExtension) {
                loc = fileItemName.length() - atomicExtension.length();
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (FileItem *fileItem : fileSystem->fileItems()) {
        const QUrl fileUrl = fileItem->getUrl();

        if (m_query->isRecursive() &&
            ((!fileItem->isSymLink() && fileItem->isDir()) || (fileItem->isSymLink() && m_query->followLinks()))) {
            // query search in subdirectory
            m_unScannedUrls.push(fileUrl);
        }

        if (m_query->searchInArchives() && fileUrl.isLocalFile() &&
            KRarcHandler::arcSupported(fileItem->getMime())) {
            // query search in archive; NOTE: only supported for local files
            QUrl archiveURL = fileUrl;
            bool encrypted;
            const QString type = arcHandler.getType(encrypted, fileUrl.path(), fileItem->getMime());

            if (!encrypted) {
                archiveURL.setScheme(TAR_TYPES.contains(type) ? "tar" : "krarc");
                m_unScannedUrls.push(archiveURL);
            }
        }

        if (m_query->match(fileItem)) {
            // found!
            emit found(*fileItem, m_query->foundText()); // emitting copy of file item
        }

        if (m_timer.elapsed() >= EVENT_PROCESS_DELAY) {
            qApp->processEvents();
            m_timer.start();
            if (m_stopSearch)
                return;
        }
    }
```

#### AUTO 


```{c}
auto *rootActionGroup = new QActionGroup(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (vfile *vf : vfs_->vfiles()) {
        QUrl fileURL = vf->vfile_getUrl();

        if (query->isRecursive() && ((vf->vfile_isSymLink() && query->followLinks()) || vf->vfile_isDir()))
            unScannedUrls.push(fileURL);

        if (query->match(vf)) {
            // if we got here - we got a winner
            results.append(fileURL.toDisplayString(QUrl::PreferLocalFile));

            emit found(fileURL.fileName(), KIO::upUrl(fileURL).toDisplayString(QUrl::PreferLocalFile | QUrl::StripTrailingSlash),
                       vf->vfile_getSize(), vf->vfile_getTime_t(), vf->vfile_getPerm(), vf->vfile_getUid(),
                       vf->vfile_getGid(), query->foundText());
        }

        if (timer.elapsed() >= EVENT_PROCESS_DELAY) {
            qApp->processEvents();
            timer.start();
            if (stopSearch) return;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](KIO::Job *job) {
            // Note: the "trash" protocal should always have only one "/" after the "scheme:" part
            connect(job, &KIO::Job::result, [=]() { emit filesystemChanged(QUrl("trash:/")); });
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (FileItem *file : fileItems)
            m_nextSubUrls << file->getUrl();
```

#### AUTO 


```{c}
auto* parameterDialog = new ParameterDialog(currentPlaceholder, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto & name : names) {
        if (!group.readEntry(name, QString()).isEmpty()) {
            m_boolValues[name] = group.readEntry(name, false);
        }
    }
```

#### AUTO 


```{c}
auto *dateLayout = new QGridLayout(dateGroup);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& line : data)
            stream << line << "\n";
```

#### RANGE FOR STATEMENT 


```{c}
for (auto & it : nonmount_fs_mntpoint) {
            it = it.simplified();
        }
```

#### AUTO 


```{c}
auto * splitSizeLineLayout = new QHBoxLayout;
```

#### LAMBDA EXPRESSION 


```{c}
[=]() { startSynchronization(); }
```

#### AUTO 


```{c}
auto *upDir = const_cast<Directory *>(diskUsage->getCurrentDir()->parent());
```

#### RANGE FOR STATEMENT 


```{c}
for (QString text : lines) {
        QString error;
        emit checkValidity(text, error);
        if (error.isNull())
            urls.append(QUrl::fromUserInput(text, QString(), QUrl::AssumeLocalFile));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() { emit fileSystemChanged(url, true); }
```

#### AUTO 


```{c}
auto *showOptions  = new QGroupBox(optionWidget);
```

#### AUTO 


```{c}
auto fallbackThemeName
```

#### AUTO 


```{c}
auto text = act->text();
```

#### AUTO 


```{c}
auto *dialog = new KPropertiesDialog(fileItems, krMainWindow);
```

#### RANGE FOR STATEMENT 


```{c}
for(QPointer<FileSystem> fileSystemPointer: _fileSystems) {
        // always refresh filesystems showing a virtual directory; it can contain files from various
        // places, we don't know if they were (re)moved, refreshing is also fast enough
        FileSystem *fs = fileSystemPointer.data();
        const QUrl fileSystemDir = fs->currentDirectory();
        if ((fileSystemDir == FileSystem::cleanUrl(directory) || (fileSystemDir.scheme() == "virt" && !fs->isRoot()))
            && !fs->hasAutoUpdate()) {
            // refresh all filesystem currently showing this directory...
            fs->refresh();
        } else if (!mountPoint.isEmpty() && mountPoint == fs->mountPoint()) {
            // ..or refresh filesystem info if mount point is the same (for free space update)
            fs->updateFilesystemInfo();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto & it : parameter1) {
            it = it.trimmed();
            if (it.left(1) == "\"")
                it = it.mid(1, it.length() - 2);
            parameter.push_back(expandCurrent(it, useUrl));
            if (error())
                return TagStringList();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=](KJob *job) {
            _tempFile->flush();
            if (job->error()) {   /* any error occurred? */
                auto *kioJob = qobject_cast<KIO::TransferJob *>(job);
                KMessageBox::error(_textArea, i18n("Error reading file %1.", kioJob->url().toDisplayString(QUrl::PreferLocalFile)));
            }
            _downloading = false;
            _downloadUpdateTimer.stop();
            slotUpdate();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto & it : _showonlyMime) {
                if (it.contains("/")) {
                    if (mime.inherits(it)) {      // don't use ==; use 'inherits()' instead, which is aware of inheritance (ie: text/x-makefile is also text/plain)
                        available = true;
                        break;
                    }
                } else {
                    if (mime.name().indexOf(it) == 0) {      // 0 is the beginning, -1 is not found
                        available = true;
                        break;
                    }
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[=](KIO::Job *job) { connectJobToSources(job, urls); }
```

#### AUTO 


```{c}
auto *showSizeHBox = new QHBoxLayout();
```

#### AUTO 


```{c}
auto * newItem =  new KrViewItem(fileItem, this);
```

#### AUTO 


```{c}
auto *item = new QTreeWidgetItem(items[ 0 ]);
```

#### AUTO 


```{c}
auto & fileName
```

#### AUTO 


```{c}
auto *vbox2 = new QVBoxLayout(vbox2Widget);
```

#### AUTO 


```{c}
auto sortOptions = static_cast<KrViewProperties::SortOptions>(sortOps);
```

#### AUTO 


```{c}
auto* layout = new QVBoxLayout(this);
```

#### AUTO 


```{c}
auto *lineEdit = qobject_cast<QLineEdit *> (editor);
```

#### AUTO 


```{c}
auto *progressAction = new QWidgetAction(krMainWindow);
```

#### AUTO 


```{c}
auto* vbox = new QVBoxLayout();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto & it : lst) {
        m = it.data();
        QString mntPnt = m->mountPoint();
        if (mntPnt.length() > 1 && mntPnt.endsWith('/'))
            mntPnt = mntPnt.left(mntPnt.length() - 1);
        if (mntPnt == value)
            return m;
    }
```

#### AUTO 


```{c}
auto *duItem = (DULinesItem *)(lvitem);
```

#### AUTO 


```{c}
auto* spacer_6 = new QSpacerItem(20, 26, QSizePolicy::Fixed, QSizePolicy::Fixed);
```

#### LAMBDA EXPRESSION 


```{c}
[=]() { slotUpdateStatus(); }
```

#### AUTO 


```{c}
auto newOwnerID = (uid_t) - 1;
```

#### LAMBDA EXPRESSION 


```{c}
[=]() { setModified(true); }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() { emit filesystemChanged(destination); }
```

#### AUTO 


```{c}
auto *startupInfo = new KStartupInfo(0, this);
```

#### RANGE FOR STATEMENT 


```{c}
for(QPair<QPushButton *, QPair<QAction *, const QString&>> entry : qAsConst(buttonList)) {
        layout->addWidget(entry.first, 0, pos++);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString fileName : fileNames) {
        if (stopListFiles)
            return QStringList();

        QDir subDir = QDir(baseDir.filePath(fileName));
        if (subDir.exists()) {
            subDir.setFilter(QDir::Files);
            QDirIterator it(subDir, QDirIterator::Subdirectories | QDirIterator::FollowSymlinks);
            while (it.hasNext()) {
                if (stopListFiles)
                    return QStringList();

                allFiles << baseDir.relativeFilePath(it.next());
            }
        } else {
            // assume this is a file
            allFiles << fileName;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        cancelQuickSizeCalcButton->hide();
        quickSizeCalcProgress->hide();
    }
```

#### AUTO 


```{c}
auto* MainLayout = new QVBoxLayout(this);
```

#### AUTO 


```{c}
auto * hbox2 = new QHBoxLayout(hboxWidget2);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KIO::UDSEntry entry : entries) {
        vfile *item = vfs::createVFileFromKIO(entry, listJob->url());
        if (item) {
            insert(item->vfile_getName(), item);
        }
    }
```

#### AUTO 


```{c}
auto *closeButton = new QToolButton(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto & it : mounted) {
        // don't bother with invalid file systems
        if (mountMan->invalidFilesystem(it->mountType())) {
            continue;
        }
        KDiskFreeSpaceInfo info = KDiskFreeSpaceInfo::freeSpaceInfo(it ->mountPoint());
        if(!info.isValid()) {
            continue;
        }
        fsData data;
        data.setMntPoint(it ->mountPoint());
        data.setMounted(true);
        data.setTotalBlks(info.size() / 1024);
        data.setFreeBlks(info.available() / 1024);
        data.setName(it->mountedFrom());
        data.setType(it->mountType());
        fileSystems.append(data);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KIO::UDSEntry entry : entries) {
        FileItem *item = FileSystem::createFileItemFromKIO(entry, listJob->url());
        if (item) {
            insert(item->getName(), item);
        }
    }
```

#### AUTO 


```{c}
auto action = KrBookmark::jumpBackAction(_collection, false, actions);
```

#### AUTO 


```{c}
auto* ke = dynamic_cast<QKeyEvent*>( e);
```

#### AUTO 


```{c}
auto *newViewer = new KrViewer();
```

#### RANGE FOR STATEMENT 


```{c}
for (KrJob *job: m_jobs) {
            job->cancel();
        }
```

#### AUTO 


```{c}
auto searchResult = searchIcon(_iconName, _themeFallbackList);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString fileName : fileNames) {
        files.append(panel->func->files()->getVfile(fileName));
    }
```

#### AUTO 


```{c}
auto percent = (int)((((double)receivedSize / expectedSize) * 100.) + 0.5);
```

#### AUTO 


```{c}
auto *allHBox = new QHBoxLayout(allGroup);
```

#### AUTO 


```{c}
auto menu = PanelContextMenu::run(QPoint(loc.x() + 5, loc.y() + j), this);
```

#### AUTO 


```{c}
auto *menu = qobject_cast<QMenu *>(obj);
```

#### AUTO 


```{c}
auto *dateGroup = new QGroupBox(this);
```

#### AUTO 


```{c}
auto * hbox = new QHBoxLayout(hboxWidget);
```

#### AUTO 


```{c}
auto *kioJob = (KIO::TransferJob *)job;
```

#### RANGE FOR STATEMENT 


```{c}
for(QPair<QPushButton *, QPair<QAction *, const QString&>> entry : buttonList) {
        layout->addWidget(entry.first, 0, pos++);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString line : m_process->stdOutput()) {
        const QString filename = line.mid(line.indexOf(' ') + 2) + type;
        if (!saveChecksumFile(QStringList() << line, filename)) {
            KMessageBox::error(this, i18n("Errors occurred while saving multiple checksums. Stopping"));
            krApp->stopWait();
            return false;
        }
    }
```

#### AUTO 


```{c}
auto *ownerHBox = new QHBoxLayout(ownerGroup);
```

#### AUTO 


```{c}
auto * vol = device.as<Solid::StorageVolume> ();
```

#### AUTO 


```{c}
auto & mime
```

#### AUTO 


```{c}
auto *excludeComboBox = new KrHistoryComboBox(false, this);
```

#### AUTO 


```{c}
auto *cancelButton = new QPushButton(hboxWidget);
```

#### AUTO 


```{c}
auto *item = new KPageWidgetItem(page, name);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString name : names) {
        if (_exited)
            return;

        const QString path = calcSpaceFileSystem->getUrl(name).toLocalFile();
        if (!QFileInfo(path).exists())
            return;

        countFiles(path, totalFiles, _exited);
    }
```

#### AUTO 


```{c}
auto *duItem = (DUListViewItem *)itemPtr;
```

#### LAMBDA EXPRESSION 


```{c}
[this, urlLabel]() { KrArchiverResultTable::website(urlLabel->url()); }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        // moving position clockwise
        setPopupPosition((popupPosition() + 1) % 4); }
```

#### AUTO 


```{c}
auto *sizeLayout = new QGridLayout(sizeGroup);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& name: names) {
        FileItem *file = ACTIVE_FUNC->files()->getFileItem(name);
        if (!file)
            continue;
        const QUrl url = file->getUrl();
        // KRename only supports the recursive option combined with a local directory path
        if (file->isDir() && url.scheme() == "file") {
            proc << "-r" << url.path();
        } else {
            proc << url.toString();
        }
    }
```

#### AUTO 


```{c}
const auto & atomicExtension
```

#### RANGE FOR STATEMENT 


```{c}
for (auto & name : names) {
        if (!group.readEntry(name, QString()).isEmpty()) {
            m_numValues[name] = group.readEntry(name, (long long)0);
        }
    }
```

#### AUTO 


```{c}
auto * getPasswdEvent = new UserEvent(CMD_GET_PASSWORD, args);
```

#### AUTO 


```{c}
auto *me = dynamic_cast<QContextMenuEvent *>(event);
```

#### LAMBDA EXPRESSION 


```{c}
[=](QDropEvent *event) { qobject_cast<ListPanel*>(panel)->handleDrop(event); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString name: names) {
        vfile *file = ACTIVE_FUNC->files()->getVfile(name);
        if (!file)
            continue;
        const QUrl url = file->vfile_getUrl();
        // KRename only supports the recursive option combined with a local directory path
        if (file->vfile_isDir() && url.scheme() == "file") {
            proc << "-r" << url.path();
        } else {
            proc << url.toString();
        }
    }
```

#### AUTO 


```{c}
auto *access = Solid::Device(udi).as<Solid::StorageAccess>();
```

#### LAMBDA EXPRESSION 


```{c}
[&] (qint64 nextRowStartOffset) {
        list << row;
        effLength = 0;
        row = "";
        if (locs) {
            (*locs) << (filePos + nextRowStartOffset);
        }
    }
```

#### AUTO 


```{c}
auto *bm = qobject_cast<KrBookmark *>(act);
```

#### LAMBDA EXPRESSION 


```{c}
[=](KJob *job) { slotFileCreated(job, url); }
```

#### AUTO 


```{c}
auto* recurseSpacer = new QSpacerItem(20, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);
```

#### AUTO 


```{c}
auto newSearchText = _quickSearchText();
```

#### AUTO 


```{c}
auto* HeaderLayout = new QHBoxLayout();
```

#### AUTO 


```{c}
auto *radBtn = new QRadioButton(params[i].text, radioWidget);
```

#### RANGE FOR STATEMENT 


```{c}
for (QUrl fileUrl : confirmedUrls) {
        confirmedFileNames.append(fileUrl.fileName());
    }
```

#### AUTO 


```{c}
auto act
```

#### LAMBDA EXPRESSION 


```{c}
[=](KJob *job) { slotFileCreated(job, filePath); }
```

#### LAMBDA EXPRESSION 


```{c}
[=](KJob* job) { slotJobResult(job, isLocal()); }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() { emit fileSystemChanged(destDir); }
```

#### AUTO 


```{c}
auto *checksumFileReq = new KUrlRequester;
```

#### AUTO 


```{c}
auto* gbLayout = new QHBoxLayout(GroupBox1);
```

#### AUTO 


```{c}
auto * hbox = new QHBoxLayout;
```

#### AUTO 


```{c}
auto *fs = new VirtualFileSystem();
```

#### AUTO 


```{c}
auto *archGrid2 = new QGridLayout(checksum_tab);
```

#### AUTO 


```{c}
auto *v = dynamic_cast<KrInterDetailedView*>(other);
```

#### AUTO 


```{c}
auto *item = dynamic_cast<SynchronizerGUI::SyncViewItem *>( * it);
```

#### AUTO 


```{c}
auto* checksum_scroll = new QScrollArea(tabWidget);
```

#### AUTO 


```{c}
auto *kgDependenciesLayout = new QGridLayout(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool checked) {
        syncBrowseButton->setIcon(
            Icon(checked ? "kr_syncbrowse_on" : "kr_syncbrowse_off"));
    }
```

#### AUTO 


```{c}
auto & mountPoint
```

#### AUTO 


```{c}
auto *urlRequester = qobject_cast<KonfiguratorURLRequester *>( obj);
```

#### AUTO 


```{c}
auto *patterns = new QMenu(containsRegExp);
```

#### AUTO 


```{c}
auto modifiers = ke->modifiers();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString fileName: fileNames) {
            FileItem *fileItem = files()->getFileItem(fileName);
            if (fileItem && !fileItem->isSymLink() && fileItem->isDir()) {
                // read local dir...
                const QDir dir(fileItem->getUrl().path());
                if (dir.entryList(QDir::TypeMask | QDir::System | QDir::Hidden).count() > 2) {
                    // ...is not empty, ask user
                    const KMessageBox::ButtonCode result = KMessageBox::warningYesNoCancel(
                        krMainWindow,
                        i18n("<qt><p>Folder <b>%1</b> is not empty.</p><p>Skip this one "
                             "or delete all?</p></qt>",
                             fileName),
                        QString(), KGuiItem(i18n("&Skip")), KGuiItem(i18n("&Delete All")));
                    if (result == KMessageBox::Yes) {
                        fileNames.removeAll(fileName); // skip
                    } else if (result == KMessageBox::No) {
                        break; // accept all remaining
                    } else {
                        return; // cancel
                    }
                }
            }
        }
```

#### AUTO 


```{c}
auto *bar = new QProgressBar();
```

#### AUTO 


```{c}
auto menu = new PanelContextMenu(panel);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &filename : fileNames) {
            _virtFilesystemDict["/"]->removeAll(QUrl(QStringLiteral("virt:/") + filename));
            delete _virtFilesystemDict[filename];
            _virtFilesystemDict.remove(filename);
            _metaInfoDict.remove(filename);
        }
```

#### AUTO 


```{c}
const auto selections = generateFileNameSelections(text);
```

#### LAMBDA EXPRESSION 


```{c}
[=](KIO::Job *job) {
            // Note: the "trash" protocal should always have only one "/" after the "scheme:" part
            connect(job, &KIO::Job::result, [=]() { emit fileSystemChanged(QUrl("trash:/")); });
        }
```

#### AUTO 


```{c}
auto *kgUserActionLayout = new QGridLayout(innerWidget);
```

#### AUTO 


```{c}
auto *group = new QActionGroup(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KIO::UDSEntry& entry : entries) {
        FileItem *fileItem = FileSystem::createFileItemFromKIO(entry, _currentDirectory);
        if (fileItem) {
            addFileItem(fileItem);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString line : outputLines)
            addChecksumLine(m_hashesTreeWidget, line);
```

#### AUTO 


```{c}
auto slotTriggered = [=] {
                    if (_mainBookmarkPopup && !_mainBookmarkPopup->isHidden()) {
                        _mainBookmarkPopup->close();
                    }
                };
```

#### LAMBDA EXPRESSION 


```{c}
[=]() { copyToClipBoard(fileItem, true); }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() { emit pathChanged(p); }
```

#### AUTO 


```{c}
auto *userActionMenu = qobject_cast<KActionMenu *>( KrActions::actUserMenu);
```

#### AUTO 


```{c}
auto *groupGroup = new QGroupBox(ownershipGroup);
```

#### AUTO 


```{c}
auto newGroupID = (gid_t) - 1;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString protocol : sProtocols) {
        if (availableProtocols.contains(protocol))
            prefix->addItem(protocol + QStringLiteral("://"));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() { pauseOrResume(); }
```

#### AUTO 


```{c}
auto *vbox2 = new QVBoxLayout(vboxWidget2);
```

#### AUTO 


```{c}
auto* resultLabelLayout = new QHBoxLayout();
```

#### LAMBDA EXPRESSION 


```{c}
[=](KIO::Job *job) {
            // Note: the "trash" protocal should always have only one "/" after the "scheme:" part
            connect(job, &KIO::Job::result, this, [=]() { emit fileSystemChanged(QUrl("trash:/")); });
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &filename : fileNames) {
            _virtVfsDict["/"]->removeAll(QUrl(QStringLiteral("virt:/") + filename));
            delete _virtVfsDict[filename];
            _virtVfsDict.remove(filename);
            _metaInfoDict.remove(filename);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=](KJob *) { _menuAction->menu()->removeAction(menuAction); }
```

#### AUTO 


```{c}
auto *currentPg = (KonfiguratorPage *)(before->widget());
```

#### AUTO 


```{c}
auto *searchLayout = new QGridLayout(searchGroupBox);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto & mime : mimes)
                (*slaveMap)[mime] = it;
```

#### AUTO 


```{c}
auto *optionBox = new QHBoxLayout(optionWidget);
```

#### AUTO 


```{c}
auto *groupHBox = new QHBoxLayout(groupGroup);
```

#### AUTO 


```{c}
const auto *fropt = qstyleoption_cast<const QStyleOptionFocusRect *>(option)
```

#### AUTO 


```{c}
auto *containsTextLayout = new QHBoxLayout();
```

#### AUTO 


```{c}
auto *event = (UserEvent*) e;
```

#### AUTO 


```{c}
auto *urlListRequesterGrid = new QGridLayout(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& fileName : fileNames) {
        if (!getUrl(fileName).isLocalFile()) {
            return false;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : qAsConst(setViewActions))
        actions << action;
```

