#### AUTO 


```{c}
auto *layout = new QGridLayout;
```

#### AUTO 


```{c}
auto *m = qobject_cast<QStandardItemModel *>(checkCombo->model());
```

#### AUTO 


```{c}
auto addressBookLayout = new QVBoxLayout;
```

#### RANGE FOR STATEMENT 


```{c}
for (const ContactCacheData &cacheContact : mGroupsCache[groupItemId]) {
        const QString name = cacheContact.name().trimmed();
        if (!name.isEmpty()) {
            initials.append(name.front());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (int column : columns) {
        settingsColumns.append(static_cast<int>(column));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&groupContacts](const ContactCacheData &cacheContact) -> bool {
        for (int idx = 0; idx < groupContacts.contactReferenceCount(); ++idx)
        {
            const KContacts::ContactGroup::ContactReference &reference = groupContacts.contactReference(idx);

            if (cacheContact == reference) {
                return false;
            }
        }
        return true;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KAddressBookImportExport::PluginInterface *interface : qAsConst(mImportExportPluginInterfaceList)) {
                if (interface->canImportFileType(url)) {
                    interface->importFile(url);
                    break;
                }
            }
```

#### AUTO 


```{c}
auto fetch = qobject_cast<Akonadi::CollectionFetchJob *>(job);
```

#### AUTO 


```{c}
auto menu = new QMenu(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &name : contactListNames) {
        if (!name.isEmpty()) {
            initials.append(name.front());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KAddressBookImportExport::KAddressBookImportExportContactFields::Field &field : qAsConst(fields)) {
            // we need only values with content
            const QString value = KAddressBookImportExport::KAddressBookImportExportContactFields::value(field, contact).trimmed();
            if (!value.isEmpty()) {
                values << value;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &email : emails) {
                rightBlock.append(email);
            }
```

#### AUTO 


```{c}
auto *job = new Akonadi::ItemFetchJob(collection);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &cacheContact : mGroupsCache[index]) {
        contactCacheIds += cacheContact.gid.isEmpty() ? cacheContact.uid : cacheContact.gid;
    }
```

#### AUTO 


```{c}
auto categoryFilter = new QWidgetAction(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *wdg : std::as_const(mPageList)) {
        mWizard->setAppropriate(mPageItems[wdg], false);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KContacts::Addressee &contact : contacts) {
        // get the values
        QStringList values;
        for (const KAddressBookImportExport::KAddressBookImportExportContactFields::Field &field : qAsConst(fields)) {
            // we need only values with content
            const QString value = KAddressBookImportExport::KAddressBookImportExportContactFields::value(field, contact).trimmed();
            if (!value.isEmpty()) {
                values << value;
            }
        }

        content += QLatin1String("   <tr>\n");
        QString style = QStringLiteral("background-color:");
        if (this->withAlternating) {
            style += (odd) ? this->firstColor.name() : this->secondColor.name();
        } else {
            style += QLatin1String("#ffffff");
        }
        content += QLatin1String("    <td style=\"") + style + QLatin1String(";\">") + values.join(QStringLiteral("; ")) + QLatin1String("</td>\n");
        content += QLatin1String("   </tr>\n");
        odd = !odd;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&imageData](KIO::Job *, const QByteArray &data) {
                        imageData.append(data);
                     }
```

#### AUTO 


```{c}
auto layout = new QHBoxLayout(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KContacts::Addressee &contact : contacts) {
        // get the values
        QStringList values;
        foreach (const KAddressBookImportExport::KAddressBookImportExportContactFields::Field &field, fields) {
            // we need only values with content
            const QString value = KAddressBookImportExport::KAddressBookImportExportContactFields::value(field, contact).trimmed();
            if (!value.isEmpty()) {
                values << value;
            }
        }

        content += QLatin1String("   <tr>\n");
        QString style = QStringLiteral("background-color:");
        if (this->withAlternating) {
            style += (odd) ? this->firstColor.name() : this->secondColor.name();
        } else {
            style += QLatin1String("#ffffff");
        }
        content += QLatin1String("    <td style=\"") + style + QLatin1String(";\">") + values.join(QStringLiteral("; ")) + QLatin1String("</td>\n");
        content += QLatin1String("   </tr>\n");
        odd = !odd;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : fetchJob->items()) {
            if (item.isValid()) {
                if ((!item.gid().isEmpty() && refId[QStringLiteral("gid")].toString() == item.gid())
                    || QString::number(item.id()) == refId[QStringLiteral("uid")].toString()) {
                    if (item.hasPayload<KContacts::Addressee>()) {
                        mMonitor->setItemMonitored(item);
                        const KContacts::Addressee contact = item.payload<KContacts::Addressee>();
                        cacheContact.name = contact.realName();
                        cacheContact.email = contact.preferredEmail();
                    }
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KContacts::Addressee &contact : contacts) {
        QString name = contact.realName();
        if (!contact.title().isEmpty() || !contact.role().isEmpty()) {
            QStringList content;
            if (!contact.title().isEmpty()) {
                content << contact.title();
            }
            if (!contact.role().isEmpty()) {
                content << contact.role();
            }
            name += QStringLiteral(" (%1)").arg(content.join(QStringLiteral(", ")));
        }

        const QString birthday = QLocale().toString(contact.birthday().date(), QLocale::ShortFormat);

        ContactBlock::List blocks;

        if (!contact.organization().isEmpty()) {
            ContactBlock block;
            block.header = i18n("Organization:");
            block.entries.append(contact.organization());

            blocks.append(block);
        }

        if (!contact.emails().isEmpty()) {
            ContactBlock block;
            block.header = (contact.emails().count() == 1
                            ? i18n("Email address:")
                            : i18n("Email addresses:"));
            block.entries = contact.emails();

            blocks.append(block);
        }

        if (!contact.phoneNumbers().isEmpty()) {
            const KContacts::PhoneNumber::List numbers = contact.phoneNumbers();

            ContactBlock block;
            block.header = (numbers.count() == 1
                            ? i18n("Telephone:")
                            : i18n("Telephones:"));

            for (const KContacts::PhoneNumber &number : numbers) {
                const QString line = number.typeLabel() + QLatin1String(": ") + number.number();
                block.entries.append(line);
            }

            blocks.append(block);
        }

        if (contact.url().isValid()) {
            ContactBlock block;
            block.header = i18n("Web page:");
            block.entries.append(contact.url().url().toDisplayString());

            blocks.append(block);
        }

        if (!contact.addresses().isEmpty()) {
            const KContacts::Address::List addresses = contact.addresses();

            for (const KContacts::Address &address : addresses) {
                ContactBlock block;

                switch (address.type()) {
                case KContacts::Address::Dom:
                    block.header = i18n("Domestic Address");
                    break;
                case KContacts::Address::Intl:
                    block.header = i18n("International Address");
                    break;
                case KContacts::Address::Postal:
                    block.header = i18n("Postal Address");
                    break;
                case KContacts::Address::Parcel:
                    block.header = i18n("Parcel Address");
                    break;
                case KContacts::Address::Home:
                    block.header = i18n("Home Address");
                    break;
                case KContacts::Address::Work:
                    block.header = i18n("Work Address");
                    break;
                case KContacts::Address::Pref:
                default:
                    block.header = i18n("Preferred Address");
                }
                block.header += QLatin1Char(':');

#if QT_VERSION < QT_VERSION_CHECK(5, 15, 0)
                block.entries = address.formattedAddress().split(QLatin1Char('\n'), QString::KeepEmptyParts);
#else
                block.entries = address.formattedAddress().split(QLatin1Char('\n'), Qt::KeepEmptyParts);
#endif
                blocks.append(block);
            }
        }

        if (!contact.note().isEmpty()) {
            ContactBlock block;
            block.header = i18n("Notes:");
#if QT_VERSION < QT_VERSION_CHECK(5, 15, 0)
            block.entries = contact.note().split(QLatin1Char('\n'), QString::KeepEmptyParts);
#else
            block.entries = contact.note().split(QLatin1Char('\n'), Qt::KeepEmptyParts);
#endif

            blocks.append(block);
        }

        // add header
        content += QLatin1String("  <table style=\"border-width: 0px; border-spacing: 0px; "
                                 "page-break-inside: avoid\" cellspacing=\"0\" cellpadding=\"0\" width=\"100%\">\n");
        content += QLatin1String("   <tr>\n");
        content += QLatin1String("    <td style=\"color: ") + settings.headerTextColor
                   +QLatin1String(";\" bgcolor=\"") + settings.headerBackgroundColor
                   +QLatin1String("\" style=\"padding-left: 20px\">")
                   +name +  QLatin1String("</td>\n");
        content += QLatin1String("    <td style=\"color: ") + settings.headerTextColor
                   +QLatin1String(";\" align=\"right\" bgcolor=\"") + settings.headerBackgroundColor
                   +QLatin1String("\" style=\"padding-right: 20px\">")
                   +birthday + QLatin1String("</td>\n");
        content += QLatin1String("   </tr>\n");

        for (int i = 0; i < blocks.count(); i += 2) {
            // add empty line for spacing
            content += QLatin1String("   <tr>\n");
            content += QLatin1String("    <td>&nbsp;</td>\n");
            content += QLatin1String("    <td>&nbsp;</td>\n");
            content += QLatin1String("   </tr>\n");

            // add real block data
            const ContactBlock leftBlock = blocks.at(i);
            const ContactBlock rightBlock = ((i + 1 < blocks.count())
                                             ? blocks.at(i + 1)
                                             : ContactBlock());

            content += QLatin1String("   <tr>\n");
            content += QLatin1String("    <td>") + leftBlock.header + QLatin1String("</td>\n");
            content += QLatin1String("    <td>") + rightBlock.header + QLatin1String("</td>\n");
            content += QLatin1String("   </tr>\n");

            const int maxLines = qMax(leftBlock.entries.count(), rightBlock.entries.count());
            for (int j = 0; j < maxLines; ++j) {
                QString leftLine, rightLine;

                if (j < leftBlock.entries.count()) {
                    leftLine = leftBlock.entries.at(j);
                }

                if (j < rightBlock.entries.count()) {
                    rightLine = rightBlock.entries.at(j);
                }

                content += QLatin1String("   <tr>\n");
                content += QLatin1String("    <td class=\"indented\">") + leftLine + QLatin1String("</td>\n");
                content += QLatin1String("    <td class=\"indented\">") + rightLine + QLatin1String("</td>\n");
                content += QLatin1String("   </tr>\n");
            }
        }

        // add empty line for spacing
        content += QLatin1String("   <tr>\n");
        content += QLatin1String("    <td>&nbsp;</td>\n");
        content += QLatin1String("    <td>&nbsp;</td>\n");
        content += QLatin1String("   </tr>\n");
        content += QLatin1String("  </table>\n");
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : items) {
        ContactCacheData::List::iterator it_contact = findCacheItem(groupItemId, item);
        if (it_contact != mGroupsCache[groupItemId].end()) {
            if (it_contact->setData(item)) {
                mMonitor->setItemMonitored(item);
            } else {
                qCWarning(KADDRESSBOOK_LOG) << QStringLiteral("item with id %1 cannot be saved into cache").arg(item.id());
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (int column : settingsColumns) {
        columns.append(static_cast<Akonadi::ContactsTreeModel::Column>(column));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *interface : qAsConst(mImportExportPluginInterfaceList)) {
        interface->setDefaultCollection(col);
    }
```

#### AUTO 


```{c}
auto detailsPaneLayout = new QVBoxLayout(mDetailsPane);
```

#### RANGE FOR STATEMENT 


```{c}
for (const ContactCacheData &cacheContact : mGroupsCache[index]) {
        if (!cacheContact.name.isEmpty()) {
            initials.append(cacheContact.name.front());
        }
    }
```

#### AUTO 


```{c}
auto *topLayout = new QGridLayout(this);
```

#### AUTO 


```{c}
auto interface
```

#### RANGE FOR STATEMENT 


```{c}
for (const KContacts::Addressee &contact : contacts) {
        blocks.clear();
        QString name = contact.realName();
        if (!contact.title().isEmpty() || !contact.role().isEmpty()) {
            QStringList contentAddress;
            if (!contact.title().isEmpty()) {
                contentAddress << contact.title();
            }
            if (!contact.role().isEmpty()) {
                contentAddress << contact.role();
            }
            name += QStringLiteral(" (%1)").arg(contentAddress.join(QStringLiteral(", ")));
        }

        const QString birthday = QLocale().toString(contact.birthday().date(), QLocale::ShortFormat);

        if (!contact.organization().isEmpty()) {
            ContactBlock block;
            block.header = i18n("Organization:");
            block.entries.append(contact.organization());

            blocks.append(block);
        }

        if (!contact.emails().isEmpty()) {
            ContactBlock block;
            block.header = (contact.emails().count() == 1 ? i18n("Email address:") : i18n("Email addresses:"));
            block.entries = contact.emails();

            blocks.append(block);
        }

        if (!contact.phoneNumbers().isEmpty()) {
            const KContacts::PhoneNumber::List numbers = contact.phoneNumbers();

            ContactBlock block;
            block.header = (numbers.count() == 1 ? i18n("Telephone:") : i18n("Telephones:"));

            for (const KContacts::PhoneNumber &number : numbers) {
                const QString line = number.typeLabel() + QLatin1String(": ") + number.number();
                block.entries.append(line);
            }

            blocks.append(block);
        }

        if (contact.url().isValid()) {
            ContactBlock block;
            block.header = i18n("Web page:");
            block.entries.append(contact.url().url().toDisplayString());

            blocks.append(block);
        }

        if (!contact.addresses().isEmpty()) {
            const KContacts::Address::List addresses = contact.addresses();

            for (const KContacts::Address &address : addresses) {
                ContactBlock block;

                switch (address.type()) {
                case KContacts::Address::Dom:
                    block.header = i18n("Domestic Address");
                    break;
                case KContacts::Address::Intl:
                    block.header = i18n("International Address");
                    break;
                case KContacts::Address::Postal:
                    block.header = i18n("Postal Address");
                    break;
                case KContacts::Address::Parcel:
                    block.header = i18n("Parcel Address");
                    break;
                case KContacts::Address::Home:
                    block.header = i18n("Home Address");
                    break;
                case KContacts::Address::Work:
                    block.header = i18n("Work Address");
                    break;
                case KContacts::Address::Pref:
                default:
                    block.header = i18n("Preferred Address");
                }
                block.header += QLatin1Char(':');

                block.entries = address.formatted(KContacts::AddressFormatStyle::Postal).split(QLatin1Char('\n'), Qt::KeepEmptyParts);
                blocks.append(block);
            }
        }

        if (!contact.note().isEmpty()) {
            ContactBlock block;
            block.header = i18n("Notes:");
            block.entries = contact.note().split(QLatin1Char('\n'), Qt::KeepEmptyParts);

            blocks.append(block);
        }

        // add header
        content += QLatin1String(
            "  <table style=\"border-width: 0px; border-spacing: 0px; "
            "page-break-inside: avoid\" cellspacing=\"0\" cellpadding=\"0\" width=\"100%\">\n");
        content += QLatin1String("   <tr>\n");
        content += QLatin1String("    <td style=\"color: ") + settings.headerTextColor + QLatin1String(";\" bgcolor=\"") + settings.headerBackgroundColor
            + QLatin1String(R"(" style="padding-left: 20px">)") + name + QLatin1String("</td>\n");
        content += QLatin1String("    <td style=\"color: ") + settings.headerTextColor + QLatin1String(R"(;" align="right" bgcolor=")")
            + settings.headerBackgroundColor + QLatin1String(R"(" style="padding-right: 20px">)") + birthday + QLatin1String("</td>\n");
        content += QLatin1String("   </tr>\n");

        for (int i = 0; i < blocks.count(); i += 2) {
            // add empty line for spacing
            content += QLatin1String("   <tr>\n");
            content += QLatin1String("    <td>&nbsp;</td>\n");
            content += QLatin1String("    <td>&nbsp;</td>\n");
            content += QLatin1String("   </tr>\n");

            // add real block data
            const ContactBlock leftBlock = blocks.at(i);
            const ContactBlock rightBlock = ((i + 1 < blocks.count()) ? blocks.at(i + 1) : ContactBlock());

            content += QLatin1String("   <tr>\n");
            content += QLatin1String("    <td>") + leftBlock.header + QLatin1String("</td>\n");
            content += QLatin1String("    <td>") + rightBlock.header + QLatin1String("</td>\n");
            content += QLatin1String("   </tr>\n");

            const int maxLines = qMax(leftBlock.entries.count(), rightBlock.entries.count());
            for (int j = 0; j < maxLines; ++j) {
                QString leftLine;
                QString rightLine;

                if (j < leftBlock.entries.count()) {
                    leftLine = leftBlock.entries.at(j);
                }

                if (j < rightBlock.entries.count()) {
                    rightLine = rightBlock.entries.at(j);
                }

                content += QLatin1String("   <tr>\n");
                content += QLatin1String("    <td class=\"indented\">") + leftLine + QLatin1String("</td>\n");
                content += QLatin1String("    <td class=\"indented\">") + rightLine + QLatin1String("</td>\n");
                content += QLatin1String("   </tr>\n");
            }
        }

        // add empty line for spacing
        content += QLatin1String("   <tr>\n");
        content += QLatin1String("    <td>&nbsp;</td>\n");
        content += QLatin1String("    <td>&nbsp;</td>\n");
        content += QLatin1String("   </tr>\n");
        content += QLatin1String("  </table>\n");
    }
```

#### AUTO 


```{c}
auto descendantsModel = new KDescendantsProxyModel(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *act : std::as_const(exportActions)) {
            exportMenu->addAction(act);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &lhs, const QString &rhs) -> bool {
        return lhs.toLongLong() < rhs.toLongLong();
    }
```

#### AUTO 


```{c}
auto *plugin = KAddressBookImportExport::PluginManager::self()->pluginFromIdentifier(identifier);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KContacts::Addressee &contact : contacts) {
        const int max = qMax(leftFields.count(), rightFields.count());

        const QString name = contact.realName();

        if (counter % 2) {
            content += QLatin1String("  <br/><br/>\n");
        }

        // start a new page after every second table
        const QString pageBreak = ((counter % 2) ? QStringLiteral("page-break-after: always;") : QString());

        content += QLatin1String("  <table style=\"border-width: 0px; ") + pageBreak + QLatin1String("\" width=\"100%\">\n");
        content += QLatin1String("   <tr>\n");
        content += QLatin1String("    <th align=\"left\" style=\"color: black;\" bgcolor=\"gray\" "
                                 "style=\"padding-left: 20px\" colspan=\"4\">") + name + QLatin1String("</th>\n");
        content += QLatin1String("   </tr>\n");

        for (int i = 0; i < max; ++i) {
            QString leftTitle, leftValue, rightTitle, rightValue;

            if (i < leftFields.count()) {
                leftTitle = KAddressBookImportExport::KAddressBookImportExportContactFields::label(leftFields.at(i)) + QLatin1Char(':');
                leftTitle.replace(QLatin1Char(' '), QStringLiteral("&nbsp;"));
                leftValue = KAddressBookImportExport::KAddressBookImportExportContactFields::value(leftFields.at(i), contact);
            }

            if (i < rightFields.count()) {
                rightTitle = KAddressBookImportExport::KAddressBookImportExportContactFields::label(rightFields.at(i)) + QLatin1Char(':');
                rightTitle.replace(QLatin1Char(' '), QStringLiteral("&nbsp;"));
                rightValue = KAddressBookImportExport::KAddressBookImportExportContactFields::value(rightFields.at(i), contact);
            }

            content += QLatin1String("   <tr>\n");
            content += QLatin1String("    <td>") + leftTitle + QLatin1String("</td>\n");
            content += QLatin1String("    <td>") + leftValue + QLatin1String("</td>\n");
            content += QLatin1String("    <td>") + rightTitle + QLatin1String("</td>\n");
            content += QLatin1String("    <td>") + rightValue + QLatin1String("</td>\n");
            content += QLatin1String("   </tr>\n");
        }
        content += QLatin1String("  </table>\n");

        counter++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KAddressBookImportExport::Plugin *plugin : listPlugins) {
        if (plugin->isEnabled()) {
            auto *interface
                = static_cast<KAddressBookImportExport::PluginInterface *>(plugin->createInterface(this));
            interface->setItemSelectionModel(mItemView->selectionModel());
            interface->setParentWidget(this);
            interface->createAction(collection);
            importActions.append(interface->importActions());
            exportActions.append(interface->exportActions());
            mImportExportPluginInterfaceList.append(interface);
            connect(interface, &PimCommon::AbstractGenericPluginInterface::emitPluginActivated, this, &MainWidget::slotImportExportActivated);
        }
    }
```

#### AUTO 


```{c}
auto job = KIO::file_copy(QUrl::fromLocalFile(tmpFile.fileName()), newUrl, -1, KIO::Overwrite);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto interface : qAsConst(mImportExportPluginInterfaceList)) {
        interface->setDefaultCollection(col);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (int column : columns) {
        settingsColumns.append((int)column);
    }
```

#### AUTO 


```{c}
auto boxLayout = new QGridLayout;
```

#### AUTO 


```{c}
auto interface = static_cast<PimCommon::GenericPluginInterface *>(abstractInterface);
```

#### LAMBDA EXPRESSION 


```{c}
[&imageData](KIO::Job *, const QByteArray & data) {
        imageData.append(data);
    }
```

#### AUTO 


```{c}
auto job = new Akonadi::RecursiveItemFetchJob(collection, QStringList() << KContacts::Addressee::mimeType());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &url : parser.positionalArguments()) {
          importManager()->importFile(QUrl::fromUserInput(url));
        }
```

#### AUTO 


```{c}
auto *quicksearch = new QWidgetAction(this);
```

#### AUTO 


```{c}
auto monitor = new Monitor(this);
```

#### AUTO 


```{c}
auto buttonBox = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel, this);
```

#### AUTO 


```{c}
auto action = new QAction(QIcon::fromTheme(QStringLiteral("configure")), i18n("&Configure KAddressBook..."), this);
```

#### AUTO 


```{c}
auto actions = new Akonadi::ContactDefaultActions(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &urlStr : parser.positionalArguments()) {
            const QUrl url(QUrl::fromUserInput(urlStr));
            for (KAddressBookImportExport::KAddressBookImportExportPluginInterface *interface : qAsConst(mImportExportPluginInterfaceList)) {
                if (interface->canImportFileType(url)) {
                    interface->importFile(url);
                    break;
                }
            }
        }
```

#### AUTO 


```{c}
auto *addressBookLayout = new QVBoxLayout;
```

#### AUTO 


```{c}
auto *interface
                = static_cast<KAddressBookImportExport::PluginInterface *>(plugin->createInterface(this));
```

#### AUTO 


```{c}
auto job = new PimCommon::ManageServerSideSubscriptionJob(this);
```

#### AUTO 


```{c}
auto *but = new QToolButton(q);
```

#### AUTO 


```{c}
auto *layout = new QHBoxLayout(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &metaData : availablePlugins) {
#if KCMUTILS_VERSION >= QT_VERSION_CHECK(5, 84, 0)
        dlg->addModule(metaData);
#else
        dlg->addModule(metaData.pluginId());
#endif
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KContacts::Address &address : addresses) {
                ContactBlock block;

                switch (address.type()) {
                case KContacts::Address::Dom:
                    block.header = i18n("Domestic Address");
                    break;
                case KContacts::Address::Intl:
                    block.header = i18n("International Address");
                    break;
                case KContacts::Address::Postal:
                    block.header = i18n("Postal Address");
                    break;
                case KContacts::Address::Parcel:
                    block.header = i18n("Parcel Address");
                    break;
                case KContacts::Address::Home:
                    block.header = i18n("Home Address");
                    break;
                case KContacts::Address::Work:
                    block.header = i18n("Work Address");
                    break;
                case KContacts::Address::Pref:
                default:
                    block.header = i18n("Preferred Address");
                }
                block.header += QLatin1Char(':');

                block.entries = address.formattedAddress().split(QLatin1Char('\n'), QString::KeepEmptyParts);
                blocks.append(block);
            }
```

#### AUTO 


```{c}
auto hbox = new QHBoxLayout(q);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &directory : std::as_const(themesDirectories)) {
        QDirIterator dirIt(directory, QStringList(), QDir::AllDirs | QDir::NoDotAndDotDot);
        QStringList alreadyLoadedThemeName;
        while (dirIt.hasNext()) {
            dirIt.next();
            const QString themeInfoFile = dirIt.filePath() + QStringLiteral("/theme.desktop");
            KConfig config(themeInfoFile);
            KConfigGroup group(&config, QStringLiteral("Desktop Entry"));
            QString name = group.readEntry("Name", QString());
            if (name.isEmpty()) {
                continue;
            }
            if (alreadyLoadedThemeName.contains(name)) {
                int i = 2;
                const QString originalName(name);
                while (alreadyLoadedThemeName.contains(name)) {
                    name = originalName + QStringLiteral(" (%1)").arg(i);
                    ++i;
                }
            }
            const QString printThemePath(dirIt.filePath() + QLatin1Char('/'));
            if (!printThemePath.isEmpty()) {
                alreadyLoadedThemeName << name;
                mPrintStyleDefinition.append(new PrintStyleDefinition(new GrantleeStyleFactory(name, printThemePath, this)));
            }
        }
    }
```

#### AUTO 


```{c}
const auto item = this->index(idx, 0, parent).data(Akonadi::EntityTreeModel::ItemRole).value<Akonadi::Item>();
```

#### AUTO 


```{c}
auto *saver = new Akonadi::ETMViewStateSaver;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QPersistentModelIndex &index : mGroupsCache.keys()) {
            ContactCacheData::List::iterator it = findCacheItem(index, item);

            if (it != mGroupsCache[index].end()) {
                mGroupsCache[index].erase(it);
                Q_EMIT dataChanged(index, index, mKrole);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &url : parser.positionalArguments()) {
            importManager()->importFile(QUrl::fromUserInput(url));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KContacts::Address &address : addresses) {
                const QString data
                    = address.formattedAddress().replace(QLatin1String("\n\n"), QStringLiteral("\n")).replace(QLatin1Char('\n'), QStringLiteral("<br/>"));
                const QString subBlock = QLatin1String("<p style=\"margin-top: 0px; margin-left: 20px\">") + data + QLatin1String("</p>");

                leftBlock.append(subBlock);
            }
```

#### AUTO 


```{c}
auto interface = static_cast<KAddressBookImportExport::PluginInterface *>(plugin->createInterface(this));
```

#### RANGE FOR STATEMENT 


```{c}
for (KAddressBookImportExport::Plugin *plugin : listPlugins) {
        if (plugin->isEnabled()) {
            auto interface = static_cast<KAddressBookImportExport::PluginInterface *>(plugin->createInterface(this));
            interface->setItemSelectionModel(mItemView->selectionModel());
            interface->setParentWidget(this);
            interface->createAction(collection);
            importActions.append(interface->importActions());
            exportActions.append(interface->exportActions());
            mImportExportPluginInterfaceList.append(interface);
            connect(interface, &PimCommon::AbstractGenericPluginInterface::emitPluginActivated, this, &MainWidget::slotImportExportActivated);
        }
    }
```

#### AUTO 


```{c}
const auto parentId = tagModel->data(idx, TagModel::IdRole).value<Tag::Id>();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        mMainWidget->updateQuickSearchText();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KAddressBookImportExport::KAddressBookImportExportPluginInterface *interface : qAsConst(mImportExportPluginInterfaceList)) {
        interface->setDefaultCollection(col);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QPersistentModelIndex &index : mGroupsCache.keys()) {
        ContactCacheData::ListIterator it = findCacheItem(index, item);
        if (it != mGroupsCache[index].end()) {
            if (item.isValid()) {
                if (item.hasPayload<KContacts::Addressee>()) {
                    const KContacts::Addressee contact = item.payload<KContacts::Addressee>();
                    it->uid = QString::number(item.id());
                    it->gid = item.gid();
                    it->name = contact.realName();
                    it->email = contact.preferredEmail();
                    Q_EMIT dataChanged(index, index, mKrole);
                }
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&wizard]() {
        wizard.print();
    }
```

#### AUTO 


```{c}
auto *actions = new Akonadi::ContactDefaultActions(this);
```

#### LAMBDA EXPRESSION 


```{c}
[&cacheContact](const ContactCacheData &contact) -> bool {
            return contact == cacheContact;
        }
```

#### AUTO 


```{c}
auto item = new QStandardItem(i18n("(Untagged)"));
```

#### AUTO 


```{c}
auto manager = new KColorSchemeManager(this);
```

#### LAMBDA EXPRESSION 


```{c}
[&cacheContact](const ContactCacheData &contact) -> bool
    {
        return contact == cacheContact;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KContacts::Addressee &contact : contacts) {
        QString nameString = contact.familyName() + QLatin1String(", ") + contact.givenName();

        if (fields & Organization) {
            if (!contact.organization().isEmpty()) {
                nameString += QLatin1String(" (") + contact.organization() + QLatin1Char(')');
            }
        }

        if (fields & Birthday) {
            if (contact.birthday().isValid()) {
                nameString += QLatin1String(" *") + QLocale().toString(contact.birthday().date(), QLocale::ShortFormat);
            }
        }

        QStringList leftBlock, rightBlock;
        if (fields & PhoneNumbers) {
            const KContacts::PhoneNumber::List numbers = contact.phoneNumbers();
            for (const KContacts::PhoneNumber &number : numbers) {
                rightBlock.append(number.typeLabel() + QLatin1String(": ") + number.number());
            }
        }
        if (fields & Emails) {
            const QStringList emails = contact.emails();
            for (const QString &email : emails) {
                rightBlock.append(email);
            }
        }
        if (fields & Note) {
            if (!contact.note().isEmpty()) {
                const QString note = i18n("Note: ") + contact.note().replace(QLatin1Char('\n'), QStringLiteral("<br/>"));

                rightBlock.append(note);
            }
        }
        if (fields & Addresses) {
            const KContacts::Address::List addresses = contact.addresses();
            for (const KContacts::Address &address : addresses) {
                const QString data =
                    address.formattedAddress().replace(QLatin1String("\n\n"), QStringLiteral("\n")).replace(QLatin1Char('\n'), QStringLiteral("<br/>"));
                const QString subBlock = QLatin1String("<p style=\"margin-top: 0px; margin-left: 20px\">") + data + QLatin1String("</p>");

                leftBlock.append(subBlock);
            }
        }

        content += QLatin1String("   <tr>\n");
        content += QLatin1String("    <td style=\"padding-left: 3px; padding-top: 3px; padding-right: 3px; "
                                 "padding-bottom: 3px;\">") +
                   nameString + leftBlock.join(QString()) + QLatin1String("</td>\n");
        content += QLatin1String("    <td style=\"padding-left: 3px; padding-top: 3px; padding-right: 3px; "
                                 "padding-bottom: 3px;\">") +
                   rightBlock.join(QStringLiteral("<br/>")) + QLatin1String("</td>\n");
        content += QLatin1String("   </tr>\n");
    }
```

#### AUTO 


```{c}
auto dlg = new KShortcutsDialog(this);
```

#### AUTO 


```{c}
auto qrtoggleAction = collection->add<KToggleAction>(QStringLiteral("options_show_qrcodes"));
```

#### AUTO 


```{c}
auto etm = qobject_cast<Akonadi::EntityTreeModel *>(proxy->sourceModel());
```

#### AUTO 


```{c}
auto exportMenu = new KActionMenu(i18n("Export"), this);
```

#### AUTO 


```{c}
auto *proxy = qobject_cast<QAbstractProxyModel *>(mCollectionView->model());
```

#### AUTO 


```{c}
auto m = qobject_cast<QStandardItemModel *>(checkCombo->model());
```

#### AUTO 


```{c}
auto quicksearch = new QWidgetAction(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KContacts::Addressee &contact : contacts) {
        QString nameString = contact.familyName() + QLatin1String(", ") + contact.givenName();

        if (fields & Organization) {
            if (!contact.organization().isEmpty()) {
                nameString += QLatin1String(" (") + contact.organization() + QLatin1Char(')');
            }
        }

        if (fields & Birthday) {
            if (contact.birthday().isValid()) {
                nameString += QLatin1String(" *") + QLocale().toString(contact.birthday().date(), QLocale::ShortFormat);
            }
        }

        QStringList leftBlock, rightBlock;
        if (fields & PhoneNumbers) {
            const KContacts::PhoneNumber::List numbers = contact.phoneNumbers();
            for (const KContacts::PhoneNumber &number : numbers) {
                rightBlock.append(number.typeLabel() + QLatin1String(": ") + number.number());
            }
        }
        if (fields & Emails) {
            const QStringList emails = contact.emails();
            for (const QString &email : emails) {
                rightBlock.append(email);
            }
        }
        if (fields & Note) {
            if (!contact.note().isEmpty()) {
                const QString note = i18n("Note: ") + contact.note().replace(QLatin1Char('\n'), QStringLiteral("<br/>"));

                rightBlock.append(note);
            }
        }
        if (fields & Addresses) {
            const KContacts::Address::List addresses = contact.addresses();
            for (const KContacts::Address &address : addresses) {
                const QString data
                    = address.formattedAddress().replace(QLatin1String("\n\n"), QStringLiteral("\n")).replace(QLatin1Char('\n'), QStringLiteral("<br/>"));
                const QString subBlock = QLatin1String("<p style=\"margin-top: 0px; margin-left: 20px\">") + data + QLatin1String("</p>");

                leftBlock.append(subBlock);
            }
        }

        content += QLatin1String("   <tr>\n");
        content += QLatin1String("    <td style=\"padding-left: 3px; padding-top: 3px; padding-right: 3px; "
                                 "padding-bottom: 3px;\">")
                   +nameString + leftBlock.join(QString()) + QLatin1String("</td>\n");
        content += QLatin1String("    <td style=\"padding-left: 3px; padding-top: 3px; padding-right: 3px; "
                                 "padding-bottom: 3px;\">")
                   +rightBlock.join(QLatin1String("<br/>")) + QLatin1String("</td>\n");
        content += QLatin1String("   </tr>\n");
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (int column : settingsColumns) {
        columns.append((Akonadi::ContactsTreeModel::Column)column);
    }
```

#### AUTO 


```{c}
auto *checkableProxyModel
        = new StructuralCollectionsNotCheckableProxy(this);
```

#### AUTO 


```{c}
auto layout = new QGridLayout;
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *w : qAsConst(widgets)) {
        if (w->objectName().isEmpty()) {
            continue;
        }
        PROCESS_TYPE(QSplitter);
        PROCESS_TYPE(QTabWidget);
        PROCESS_TYPE(QTreeView);
        PROCESS_TYPE(QComboBox);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &directory : qAsConst(themesDirectories)) {
        QDirIterator dirIt(directory, QStringList(), QDir::AllDirs | QDir::NoDotAndDotDot);
        QStringList alreadyLoadedThemeName;
        while (dirIt.hasNext()) {
            dirIt.next();
            const QString themeInfoFile = dirIt.filePath() + QDir::separator() + QStringLiteral("theme.desktop");
            KConfig config(themeInfoFile);
            KConfigGroup group(&config, QStringLiteral("Desktop Entry"));
            QString name = group.readEntry("Name", QString());
            if (name.isEmpty()) {
                continue;
            }
            if (alreadyLoadedThemeName.contains(name)) {
                int i = 2;
                const QString originalName(name);
                while (alreadyLoadedThemeName.contains(name)) {
                    name = originalName + QStringLiteral(" (%1)").arg(i);
                    ++i;
                }
            }
            const QString printThemePath(dirIt.filePath() + QDir::separator());
            if (!printThemePath.isEmpty()) {
                alreadyLoadedThemeName << name;
                mPrintStyleDefinition.append(new PrintStyleDefinition(new GrantleeStyleFactory(name, printThemePath, this)));
            }
        }
    }
```

#### AUTO 


```{c}
auto selectionProxyModel = new KSelectionProxyModel(mCollectionSelectionModel, this);
```

#### LAMBDA EXPRESSION 


```{c}
[&cacheContact](const ContactCacheData &contact) -> bool
    { return contact == cacheContact; }
```

#### RANGE FOR STATEMENT 


```{c}
for (Akonadi::StandardContactActionManager::Type contactAction : std::as_const(contactActions)) {
        mActionManager->createAction(contactAction);
    }
```

#### AUTO 


```{c}
auto *interface
```

#### AUTO 


```{c}
auto *layout = new QVBoxLayout(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (KAddressBookImportExport::KAddressBookImportExportPlugin *plugin : listPlugins) {
        if (plugin->isEnabled()) {
            KAddressBookImportExport::KAddressBookImportExportPluginInterface *interface = static_cast<KAddressBookImportExport::KAddressBookImportExportPluginInterface *>(plugin->createInterface(collection, this));
            interface->setItemSelectionModel(mItemView->selectionModel());
            interface->createAction(collection);
            importActions.append(interface->importActions());
            exportActions.append(interface->exportActions());
            mImportExportPluginInterfaceList.append(interface);
            connect(interface, &PimCommon::AbstractGenericPluginInterface::emitPluginActivated, this, &MainWidget::slotImportExportActivated);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KContacts::Addressee &contact : contacts) {
        QString nameString = contact.familyName() + QLatin1String(", ") + contact.givenName();

        if (fields & Organization) {
            if (!contact.organization().isEmpty()) {
                nameString += QLatin1String(" (") + contact.organization() + QLatin1Char(')');
            }
        }

        if (fields & Birthday) {
            if (contact.birthday().isValid()) {
                nameString += QLatin1String(" *") + QLocale().toString(contact.birthday().date(), QLocale::ShortFormat);
            }
        }

        QStringList leftBlock, rightBlock;
        if (fields & PhoneNumbers) {
            const KContacts::PhoneNumber::List numbers = contact.phoneNumbers();
            for (const KContacts::PhoneNumber &number : numbers) {
                rightBlock.append(number.typeLabel() + QLatin1String(": ") + number.number());
            }
        }
        if (fields & Emails) {
            const QStringList emails = contact.emails();
            for (const QString &email : emails) {
                rightBlock.append(email);
            }
        }
        if (fields & Note) {
            if (!contact.note().isEmpty()) {
                const QString note = i18n("Note: ") + contact.note().replace(QLatin1Char('\n'), QStringLiteral("<br/>"));

                rightBlock.append(note);
            }
        }
        if (fields & Addresses) {
            const KContacts::Address::List addresses = contact.addresses();
            for (const KContacts::Address &address : addresses) {
                const QString data
                    = address.formattedAddress().replace(QLatin1String("\n\n"), QStringLiteral("\n")).replace(QLatin1Char('\n'), QStringLiteral("<br/>"));
                const QString subBlock = QLatin1String("<p style=\"margin-top: 0px; margin-left: 20px\">") + data + QLatin1String("</p>");

                leftBlock.append(subBlock);
            }
        }

        content += QLatin1String("   <tr>\n");
        content += QLatin1String("    <td style=\"padding-left: 3px; padding-top: 3px; padding-right: 3px; "
                                 "padding-bottom: 3px;\">")
                   +nameString + leftBlock.join(QString()) + QLatin1String("</td>\n");
        content += QLatin1String("    <td style=\"padding-left: 3px; padding-top: 3px; padding-right: 3px; "
                                 "padding-bottom: 3px;\">")
                   +rightBlock.join(QStringLiteral("<br/>")) + QLatin1String("</td>\n");
        content += QLatin1String("   </tr>\n");
    }
```

#### AUTO 


```{c}
auto *sync
        = new Akonadi::CollectionAttributesSynchronizationJob(col);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : items) {
        ContactCacheData::List::iterator it_contact = findCacheItem(groupItemId, item);
        if (it_contact != mGroupsCache[groupItemId].end()) {
            if (it_contact->setData(item)) {
                mMonitor->setItemMonitored(item);
            }
            else {
                qCWarning(KADDRESSBOOK_LOG) << QStringLiteral("item with id %1 cannot be saved into cache").arg(item.id());
            }
        }
    }
```

#### AUTO 


```{c}
auto *job = new Akonadi::ItemFetchJob(items);
```

#### AUTO 


```{c}
auto *descendantsModel = new KDescendantsProxyModel(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *wdg : qAsConst(mPageList)) {
        mWizard->setAppropriate(mPageItems[ wdg ], false);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KContacts::Addressee &contact : contacts) {
        const int max = qMax(leftFields.count(), rightFields.count());

        const QString name = contact.realName();

        if (counter % 2) {
            content += QLatin1String("  <br/><br/>\n");
        }

        // start a new page after every second table
        const QString pageBreak = ((counter % 2) ? QStringLiteral("page-break-after: always;") : QString());

        content += QLatin1String("  <table style=\"border-width: 0px; ") + pageBreak + QLatin1String("\" width=\"100%\">\n");
        content += QLatin1String("   <tr>\n");
        content += QLatin1String("    <th align=\"left\" style=\"color: black;\" bgcolor=\"gray\" "
                                 "style=\"padding-left: 20px\" colspan=\"4\">") + name + QLatin1String("</th>\n");
        content += QLatin1String("   </tr>\n");

        for (int i = 0; i < max; ++i) {
            QString leftTitle, leftValue, rightTitle, rightValue;

            if (i < leftFields.count()) {
                leftTitle = ContactFields::label(leftFields.at(i)) + QLatin1Char(':');
                leftTitle.replace(QLatin1Char(' '), QStringLiteral("&nbsp;"));
                leftValue = ContactFields::value(leftFields.at(i), contact);
            }

            if (i < rightFields.count()) {
                rightTitle = ContactFields::label(rightFields.at(i)) + QLatin1Char(':');
                rightTitle.replace(QLatin1Char(' '), QStringLiteral("&nbsp;"));
                rightValue = ContactFields::value(rightFields.at(i), contact);
            }

            content += QLatin1String("   <tr>\n");
            content += QLatin1String("    <td>") + leftTitle + QLatin1String("</td>\n");
            content += QLatin1String("    <td>") + leftValue + QLatin1String("</td>\n");
            content += QLatin1String("    <td>") + rightTitle + QLatin1String("</td>\n");
            content += QLatin1String("    <td>") + rightValue + QLatin1String("</td>\n");
            content += QLatin1String("   </tr>\n");
        }
        content += QLatin1String("  </table>\n");

        counter++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KContacts::Address &address : addresses) {
                ContactBlock block;

                switch (address.type()) {
                case KContacts::Address::Dom:
                    block.header = i18n("Domestic Address");
                    break;
                case KContacts::Address::Intl:
                    block.header = i18n("International Address");
                    break;
                case KContacts::Address::Postal:
                    block.header = i18n("Postal Address");
                    break;
                case KContacts::Address::Parcel:
                    block.header = i18n("Parcel Address");
                    break;
                case KContacts::Address::Home:
                    block.header = i18n("Home Address");
                    break;
                case KContacts::Address::Work:
                    block.header = i18n("Work Address");
                    break;
                case KContacts::Address::Pref:
                default:
                    block.header = i18n("Preferred Address");
                }
                block.header += QLatin1Char(':');

                block.entries = address.formatted(KContacts::AddressFormatStyle::Postal).split(QLatin1Char('\n'), Qt::KeepEmptyParts);
                blocks.append(block);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &lhs, const QString &rhs) -> bool {
                        return lhs.toLongLong() < rhs.toLongLong();
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KContacts::Addressee &contact : contacts) {
        const int max = qMax(leftFields.count(), rightFields.count());

        const QString name = contact.realName();

        if (counter % 2) {
            content += QLatin1String("  <br/><br/>\n");
        }

        // start a new page after every second table
        const QString pageBreak = ((counter % 2) ? QStringLiteral("page-break-after: always;") : QString());

        content += QLatin1String("  <table style=\"border-width: 0px; ") + pageBreak + QLatin1String("\" width=\"100%\">\n");
        content += QLatin1String("   <tr>\n");
        content += QLatin1String(
                       "    <th align=\"left\" style=\"color: black;\" bgcolor=\"gray\" "
                       "style=\"padding-left: 20px\" colspan=\"4\">")
            + name + QLatin1String("</th>\n");
        content += QLatin1String("   </tr>\n");

        for (int i = 0; i < max; ++i) {
            QString leftTitle;
            QString leftValue;
            QString rightTitle;
            QString rightValue;

            if (i < leftFields.count()) {
                leftTitle = ContactFields::label(leftFields.at(i)) + QLatin1Char(':');
                leftTitle.replace(QLatin1Char(' '), QStringLiteral("&nbsp;"));
                leftValue = ContactFields::value(leftFields.at(i), contact);
            }

            if (i < rightFields.count()) {
                rightTitle = ContactFields::label(rightFields.at(i)) + QLatin1Char(':');
                rightTitle.replace(QLatin1Char(' '), QStringLiteral("&nbsp;"));
                rightValue = ContactFields::value(rightFields.at(i), contact);
            }

            content += QLatin1String("   <tr>\n");
            content += QLatin1String("    <td>") + leftTitle + QLatin1String("</td>\n");
            content += QLatin1String("    <td>") + leftValue + QLatin1String("</td>\n");
            content += QLatin1String("    <td>") + rightTitle + QLatin1String("</td>\n");
            content += QLatin1String("    <td>") + rightValue + QLatin1String("</td>\n");
            content += QLatin1String("   </tr>\n");
        }
        content += QLatin1String("  </table>\n");

        counter++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KAddressBookImportExport::KAddressBookImportExportPluginInterface *interface : qAsConst(mImportExportPluginInterfaceList)) {
                if (interface->canImportFileType(url)) {
                    interface->importFile(url);
                    break;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (KAddressBookImportExport::KAddressBookImportExportPlugin *plugin : listPlugins) {
        if (plugin->isEnabled()) {
            KAddressBookImportExport::KAddressBookImportExportPluginInterface *interface
                = static_cast<KAddressBookImportExport::KAddressBookImportExportPluginInterface *>(plugin->createInterface(collection, this));
            interface->setItemSelectionModel(mItemView->selectionModel());
            interface->createAction(collection);
            importActions.append(interface->importActions());
            exportActions.append(interface->exportActions());
            mImportExportPluginInterfaceList.append(interface);
            connect(interface, &PimCommon::AbstractGenericPluginInterface::emitPluginActivated, this, &MainWidget::slotImportExportActivated);
        }
    }
```

#### AUTO 


```{c}
auto group = new QButtonGroup(this);
```

#### AUTO 


```{c}
const auto groupCacheId = mGroupsCache[groupItemId];
```

#### AUTO 


```{c}
auto checkableProxyModel = new StructuralCollectionsNotCheckableProxy(this);
```

#### AUTO 


```{c}
auto topLayout = new QGridLayout(this);
```

#### AUTO 


```{c}
auto *view = qobject_cast<QHeaderView *>(mWidget);
```

#### AUTO 


```{c}
auto job = new Akonadi::ItemFetchJob(items);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Tag &tag : filterTagList) {
            if (tag.id() == id) {
                return true; // a category matches filter
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &metaData : availablePlugins) {
        dlg->addModule(metaData);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QJsonObject &refId : groupRefIdsList) {
        ContactCacheData cacheContact;
        cacheContact.gid = refId[QStringLiteral("gid")].toString();
        cacheContact.uid = refId[QStringLiteral("uid")].toString();

        for (const Akonadi::Item &item : fetchJob->items()) {
            if (item.isValid()) {
                if ((!item.gid().isEmpty() && refId[QStringLiteral("gid")].toString() == item.gid())
                    || QString::number(item.id()) == refId[QStringLiteral("uid")].toString()) {
                    if (item.hasPayload<KContacts::Addressee>()) {
                        mMonitor->setItemMonitored(item);
                        const KContacts::Addressee contact = item.payload<KContacts::Addressee>();
                        cacheContact.name = contact.realName();
                        cacheContact.email = contact.preferredEmail();
                    }
                }
            }
        }
        if (mGroupsCache.contains(index)) {
            mGroupsCache[index].append(cacheContact);
        }
    }
```

#### AUTO 


```{c}
const auto groupContacts = item.payload<KContacts::ContactGroup>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const KContacts::Addressee &contact : contacts) {
        blocks.clear();
        QString name = contact.realName();
        if (!contact.title().isEmpty() || !contact.role().isEmpty()) {
            QStringList contentAddress;
            if (!contact.title().isEmpty()) {
                contentAddress << contact.title();
            }
            if (!contact.role().isEmpty()) {
                contentAddress << contact.role();
            }
            name += QStringLiteral(" (%1)").arg(contentAddress.join(QStringLiteral(", ")));
        }

        const QString birthday = QLocale().toString(contact.birthday().date(), QLocale::ShortFormat);

        if (!contact.organization().isEmpty()) {
            ContactBlock block;
            block.header = i18n("Organization:");
            block.entries.append(contact.organization());

            blocks.append(block);
        }

        if (!contact.emails().isEmpty()) {
            ContactBlock block;
            block.header = (contact.emails().count() == 1 ? i18n("Email address:") : i18n("Email addresses:"));
            block.entries = contact.emails();

            blocks.append(block);
        }

        if (!contact.phoneNumbers().isEmpty()) {
            const KContacts::PhoneNumber::List numbers = contact.phoneNumbers();

            ContactBlock block;
            block.header = (numbers.count() == 1 ? i18n("Telephone:") : i18n("Telephones:"));

            for (const KContacts::PhoneNumber &number : numbers) {
                const QString line = number.typeLabel() + QLatin1String(": ") + number.number();
                block.entries.append(line);
            }

            blocks.append(block);
        }

        if (contact.url().isValid()) {
            ContactBlock block;
            block.header = i18n("Web page:");
            block.entries.append(contact.url().url().toDisplayString());

            blocks.append(block);
        }

        if (!contact.addresses().isEmpty()) {
            const KContacts::Address::List addresses = contact.addresses();

            for (const KContacts::Address &address : addresses) {
                ContactBlock block;

                switch (address.type()) {
                case KContacts::Address::Dom:
                    block.header = i18n("Domestic Address");
                    break;
                case KContacts::Address::Intl:
                    block.header = i18n("International Address");
                    break;
                case KContacts::Address::Postal:
                    block.header = i18n("Postal Address");
                    break;
                case KContacts::Address::Parcel:
                    block.header = i18n("Parcel Address");
                    break;
                case KContacts::Address::Home:
                    block.header = i18n("Home Address");
                    break;
                case KContacts::Address::Work:
                    block.header = i18n("Work Address");
                    break;
                case KContacts::Address::Pref:
                default:
                    block.header = i18n("Preferred Address");
                }
                block.header += QLatin1Char(':');

                block.entries = address.formattedAddress().split(QLatin1Char('\n'), Qt::KeepEmptyParts);
                blocks.append(block);
            }
        }

        if (!contact.note().isEmpty()) {
            ContactBlock block;
            block.header = i18n("Notes:");
            block.entries = contact.note().split(QLatin1Char('\n'), Qt::KeepEmptyParts);

            blocks.append(block);
        }

        // add header
        content += QLatin1String(
            "  <table style=\"border-width: 0px; border-spacing: 0px; "
            "page-break-inside: avoid\" cellspacing=\"0\" cellpadding=\"0\" width=\"100%\">\n");
        content += QLatin1String("   <tr>\n");
        content += QLatin1String("    <td style=\"color: ") + settings.headerTextColor + QLatin1String(";\" bgcolor=\"") + settings.headerBackgroundColor
            + QLatin1String(R"(" style="padding-left: 20px">)") + name + QLatin1String("</td>\n");
        content += QLatin1String("    <td style=\"color: ") + settings.headerTextColor + QLatin1String(R"(;" align="right" bgcolor=")")
            + settings.headerBackgroundColor + QLatin1String(R"(" style="padding-right: 20px">)") + birthday + QLatin1String("</td>\n");
        content += QLatin1String("   </tr>\n");

        for (int i = 0; i < blocks.count(); i += 2) {
            // add empty line for spacing
            content += QLatin1String("   <tr>\n");
            content += QLatin1String("    <td>&nbsp;</td>\n");
            content += QLatin1String("    <td>&nbsp;</td>\n");
            content += QLatin1String("   </tr>\n");

            // add real block data
            const ContactBlock leftBlock = blocks.at(i);
            const ContactBlock rightBlock = ((i + 1 < blocks.count()) ? blocks.at(i + 1) : ContactBlock());

            content += QLatin1String("   <tr>\n");
            content += QLatin1String("    <td>") + leftBlock.header + QLatin1String("</td>\n");
            content += QLatin1String("    <td>") + rightBlock.header + QLatin1String("</td>\n");
            content += QLatin1String("   </tr>\n");

            const int maxLines = qMax(leftBlock.entries.count(), rightBlock.entries.count());
            for (int j = 0; j < maxLines; ++j) {
                QString leftLine;
                QString rightLine;

                if (j < leftBlock.entries.count()) {
                    leftLine = leftBlock.entries.at(j);
                }

                if (j < rightBlock.entries.count()) {
                    rightLine = rightBlock.entries.at(j);
                }

                content += QLatin1String("   <tr>\n");
                content += QLatin1String("    <td class=\"indented\">") + leftLine + QLatin1String("</td>\n");
                content += QLatin1String("    <td class=\"indented\">") + rightLine + QLatin1String("</td>\n");
                content += QLatin1String("   </tr>\n");
            }
        }

        // add empty line for spacing
        content += QLatin1String("   <tr>\n");
        content += QLatin1String("    <td>&nbsp;</td>\n");
        content += QLatin1String("    <td>&nbsp;</td>\n");
        content += QLatin1String("   </tr>\n");
        content += QLatin1String("  </table>\n");
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : lstItems) {
        if (item.isValid()) {
            if (item.hasPayload<KContacts::Addressee>()) {
                contacts.append(item.payload<KContacts::Addressee>());
            }
        }
    }
```

#### AUTO 


```{c}
auto *interface = static_cast<PimCommon::GenericPluginInterface *>(abstractInterface);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KContacts::Addressee &contact : contacts) {
        QString name = contact.realName();
        if (!contact.title().isEmpty() || !contact.role().isEmpty()) {
            QStringList contentAddress;
            if (!contact.title().isEmpty()) {
                contentAddress << contact.title();
            }
            if (!contact.role().isEmpty()) {
                contentAddress << contact.role();
            }
            name += QStringLiteral(" (%1)").arg(contentAddress.join(QStringLiteral(", ")));
        }

        const QString birthday = QLocale().toString(contact.birthday().date(), QLocale::ShortFormat);

        ContactBlock::List blocks;

        if (!contact.organization().isEmpty()) {
            ContactBlock block;
            block.header = i18n("Organization:");
            block.entries.append(contact.organization());

            blocks.append(block);
        }

        if (!contact.emails().isEmpty()) {
            ContactBlock block;
            block.header = (contact.emails().count() == 1
                            ? i18n("Email address:")
                            : i18n("Email addresses:"));
            block.entries = contact.emails();

            blocks.append(block);
        }

        if (!contact.phoneNumbers().isEmpty()) {
            const KContacts::PhoneNumber::List numbers = contact.phoneNumbers();

            ContactBlock block;
            block.header = (numbers.count() == 1
                            ? i18n("Telephone:")
                            : i18n("Telephones:"));

            for (const KContacts::PhoneNumber &number : numbers) {
                const QString line = number.typeLabel() + QLatin1String(": ") + number.number();
                block.entries.append(line);
            }

            blocks.append(block);
        }

        if (contact.url().isValid()) {
            ContactBlock block;
            block.header = i18n("Web page:");
            block.entries.append(contact.url().url().toDisplayString());

            blocks.append(block);
        }

        if (!contact.addresses().isEmpty()) {
            const KContacts::Address::List addresses = contact.addresses();

            for (const KContacts::Address &address : addresses) {
                ContactBlock block;

                switch (address.type()) {
                case KContacts::Address::Dom:
                    block.header = i18n("Domestic Address");
                    break;
                case KContacts::Address::Intl:
                    block.header = i18n("International Address");
                    break;
                case KContacts::Address::Postal:
                    block.header = i18n("Postal Address");
                    break;
                case KContacts::Address::Parcel:
                    block.header = i18n("Parcel Address");
                    break;
                case KContacts::Address::Home:
                    block.header = i18n("Home Address");
                    break;
                case KContacts::Address::Work:
                    block.header = i18n("Work Address");
                    break;
                case KContacts::Address::Pref:
                default:
                    block.header = i18n("Preferred Address");
                }
                block.header += QLatin1Char(':');

#if QT_VERSION < QT_VERSION_CHECK(5, 15, 0)
                block.entries = address.formattedAddress().split(QLatin1Char('\n'), QString::KeepEmptyParts);
#else
                block.entries = address.formattedAddress().split(QLatin1Char('\n'), Qt::KeepEmptyParts);
#endif
                blocks.append(block);
            }
        }

        if (!contact.note().isEmpty()) {
            ContactBlock block;
            block.header = i18n("Notes:");
#if QT_VERSION < QT_VERSION_CHECK(5, 15, 0)
            block.entries = contact.note().split(QLatin1Char('\n'), QString::KeepEmptyParts);
#else
            block.entries = contact.note().split(QLatin1Char('\n'), Qt::KeepEmptyParts);
#endif

            blocks.append(block);
        }

        // add header
        content += QLatin1String("  <table style=\"border-width: 0px; border-spacing: 0px; "
                                 "page-break-inside: avoid\" cellspacing=\"0\" cellpadding=\"0\" width=\"100%\">\n");
        content += QLatin1String("   <tr>\n");
        content += QLatin1String("    <td style=\"color: ") + settings.headerTextColor
                   +QLatin1String(";\" bgcolor=\"") + settings.headerBackgroundColor
                   +QLatin1String("\" style=\"padding-left: 20px\">")
                   +name +  QLatin1String("</td>\n");
        content += QLatin1String("    <td style=\"color: ") + settings.headerTextColor
                   +QLatin1String(";\" align=\"right\" bgcolor=\"") + settings.headerBackgroundColor
                   +QLatin1String("\" style=\"padding-right: 20px\">")
                   +birthday + QLatin1String("</td>\n");
        content += QLatin1String("   </tr>\n");

        for (int i = 0; i < blocks.count(); i += 2) {
            // add empty line for spacing
            content += QLatin1String("   <tr>\n");
            content += QLatin1String("    <td>&nbsp;</td>\n");
            content += QLatin1String("    <td>&nbsp;</td>\n");
            content += QLatin1String("   </tr>\n");

            // add real block data
            const ContactBlock leftBlock = blocks.at(i);
            const ContactBlock rightBlock = ((i + 1 < blocks.count())
                                             ? blocks.at(i + 1)
                                             : ContactBlock());

            content += QLatin1String("   <tr>\n");
            content += QLatin1String("    <td>") + leftBlock.header + QLatin1String("</td>\n");
            content += QLatin1String("    <td>") + rightBlock.header + QLatin1String("</td>\n");
            content += QLatin1String("   </tr>\n");

            const int maxLines = qMax(leftBlock.entries.count(), rightBlock.entries.count());
            for (int j = 0; j < maxLines; ++j) {
                QString leftLine, rightLine;

                if (j < leftBlock.entries.count()) {
                    leftLine = leftBlock.entries.at(j);
                }

                if (j < rightBlock.entries.count()) {
                    rightLine = rightBlock.entries.at(j);
                }

                content += QLatin1String("   <tr>\n");
                content += QLatin1String("    <td class=\"indented\">") + leftLine + QLatin1String("</td>\n");
                content += QLatin1String("    <td class=\"indented\">") + rightLine + QLatin1String("</td>\n");
                content += QLatin1String("   </tr>\n");
            }
        }

        // add empty line for spacing
        content += QLatin1String("   <tr>\n");
        content += QLatin1String("    <td>&nbsp;</td>\n");
        content += QLatin1String("    <td>&nbsp;</td>\n");
        content += QLatin1String("   </tr>\n");
        content += QLatin1String("  </table>\n");
    }
```

#### AUTO 


```{c}
auto mainLayout = new QVBoxLayout(this);
```

#### AUTO 


```{c}
auto group = new QActionGroup(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KContacts::Addressee &contact : contacts) {
        blocks.clear();
        QString name = contact.realName();
        if (!contact.title().isEmpty() || !contact.role().isEmpty()) {
            QStringList contentAddress;
            if (!contact.title().isEmpty()) {
                contentAddress << contact.title();
            }
            if (!contact.role().isEmpty()) {
                contentAddress << contact.role();
            }
            name += QStringLiteral(" (%1)").arg(contentAddress.join(QStringLiteral(", ")));
        }

        const QString birthday = QLocale().toString(contact.birthday().date(), QLocale::ShortFormat);

        if (!contact.organization().isEmpty()) {
            ContactBlock block;
            block.header = i18n("Organization:");
            block.entries.append(contact.organization());

            blocks.append(block);
        }

        if (!contact.emails().isEmpty()) {
            ContactBlock block;
            block.header = (contact.emails().count() == 1 ? i18n("Email address:") : i18n("Email addresses:"));
            block.entries = contact.emails();

            blocks.append(block);
        }

        if (!contact.phoneNumbers().isEmpty()) {
            const KContacts::PhoneNumber::List numbers = contact.phoneNumbers();

            ContactBlock block;
            block.header = (numbers.count() == 1 ? i18n("Telephone:") : i18n("Telephones:"));

            for (const KContacts::PhoneNumber &number : numbers) {
                const QString line = number.typeLabel() + QLatin1String(": ") + number.number();
                block.entries.append(line);
            }

            blocks.append(block);
        }

        if (contact.url().isValid()) {
            ContactBlock block;
            block.header = i18n("Web page:");
            block.entries.append(contact.url().url().toDisplayString());

            blocks.append(block);
        }

        if (!contact.addresses().isEmpty()) {
            const KContacts::Address::List addresses = contact.addresses();

            for (const KContacts::Address &address : addresses) {
                ContactBlock block;

                switch (address.type()) {
                case KContacts::Address::Dom:
                    block.header = i18n("Domestic Address");
                    break;
                case KContacts::Address::Intl:
                    block.header = i18n("International Address");
                    break;
                case KContacts::Address::Postal:
                    block.header = i18n("Postal Address");
                    break;
                case KContacts::Address::Parcel:
                    block.header = i18n("Parcel Address");
                    break;
                case KContacts::Address::Home:
                    block.header = i18n("Home Address");
                    break;
                case KContacts::Address::Work:
                    block.header = i18n("Work Address");
                    break;
                case KContacts::Address::Pref:
                default:
                    block.header = i18n("Preferred Address");
                }
                block.header += QLatin1Char(':');

#if QT_VERSION < QT_VERSION_CHECK(5, 15, 0)
                block.entries = address.formattedAddress().split(QLatin1Char('\n'), QString::KeepEmptyParts);
#else
                block.entries = address.formattedAddress().split(QLatin1Char('\n'), Qt::KeepEmptyParts);
#endif
                blocks.append(block);
            }
        }

        if (!contact.note().isEmpty()) {
            ContactBlock block;
            block.header = i18n("Notes:");
#if QT_VERSION < QT_VERSION_CHECK(5, 15, 0)
            block.entries = contact.note().split(QLatin1Char('\n'), QString::KeepEmptyParts);
#else
            block.entries = contact.note().split(QLatin1Char('\n'), Qt::KeepEmptyParts);
#endif

            blocks.append(block);
        }

        // add header
        content += QLatin1String(
            "  <table style=\"border-width: 0px; border-spacing: 0px; "
            "page-break-inside: avoid\" cellspacing=\"0\" cellpadding=\"0\" width=\"100%\">\n");
        content += QLatin1String("   <tr>\n");
        content += QLatin1String("    <td style=\"color: ") + settings.headerTextColor + QLatin1String(";\" bgcolor=\"") + settings.headerBackgroundColor
            + QLatin1String(R"(" style="padding-left: 20px">)") + name + QLatin1String("</td>\n");
        content += QLatin1String("    <td style=\"color: ") + settings.headerTextColor + QLatin1String(R"(;" align="right" bgcolor=")")
            + settings.headerBackgroundColor + QLatin1String(R"(" style="padding-right: 20px">)") + birthday + QLatin1String("</td>\n");
        content += QLatin1String("   </tr>\n");

        for (int i = 0; i < blocks.count(); i += 2) {
            // add empty line for spacing
            content += QLatin1String("   <tr>\n");
            content += QLatin1String("    <td>&nbsp;</td>\n");
            content += QLatin1String("    <td>&nbsp;</td>\n");
            content += QLatin1String("   </tr>\n");

            // add real block data
            const ContactBlock leftBlock = blocks.at(i);
            const ContactBlock rightBlock = ((i + 1 < blocks.count()) ? blocks.at(i + 1) : ContactBlock());

            content += QLatin1String("   <tr>\n");
            content += QLatin1String("    <td>") + leftBlock.header + QLatin1String("</td>\n");
            content += QLatin1String("    <td>") + rightBlock.header + QLatin1String("</td>\n");
            content += QLatin1String("   </tr>\n");

            const int maxLines = qMax(leftBlock.entries.count(), rightBlock.entries.count());
            for (int j = 0; j < maxLines; ++j) {
                QString leftLine, rightLine;

                if (j < leftBlock.entries.count()) {
                    leftLine = leftBlock.entries.at(j);
                }

                if (j < rightBlock.entries.count()) {
                    rightLine = rightBlock.entries.at(j);
                }

                content += QLatin1String("   <tr>\n");
                content += QLatin1String("    <td class=\"indented\">") + leftLine + QLatin1String("</td>\n");
                content += QLatin1String("    <td class=\"indented\">") + rightLine + QLatin1String("</td>\n");
                content += QLatin1String("   </tr>\n");
            }
        }

        // add empty line for spacing
        content += QLatin1String("   <tr>\n");
        content += QLatin1String("    <td>&nbsp;</td>\n");
        content += QLatin1String("    <td>&nbsp;</td>\n");
        content += QLatin1String("   </tr>\n");
        content += QLatin1String("  </table>\n");
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const ContactCacheData &cacheContact : groupCacheId) {
        const QString name = cacheContact.name().trimmed();
        if (!name.isEmpty()) {
            initials.append(name.front());
        }
    }
```

#### AUTO 


```{c}
auto sortFunc = [](const QString &lhs, const QString &rhs) -> bool {
                        return lhs.toLongLong() < rhs.toLongLong();
                    };
```

#### RANGE FOR STATEMENT 


```{c}
for (Akonadi::StandardActionManager::Type standardAction : qAsConst(standardActions)) {
        mActionManager->createAction(standardAction);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const ContactFields::Field &field : std::as_const(fields)) {
            // we need only values with content
            const QString value = ContactFields::value(field, contact).trimmed();
            if (!value.isEmpty()) {
                values << value;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KContacts::Address &address : addresses) {
                const QString data =
                    address.formattedAddress().replace(QLatin1String("\n\n"), QStringLiteral("\n")).replace(QLatin1Char('\n'), QStringLiteral("<br/>"));
                const QString subBlock = QLatin1String("<p style=\"margin-top: 0px; margin-left: 20px\">") + data + QLatin1String("</p>");

                leftBlock.append(subBlock);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (Akonadi::StandardContactActionManager::Type contactAction : qAsConst(contactActions)) {
        mActionManager->createAction(contactAction);
    }
```

#### AUTO 


```{c}
auto item = new KPageWidgetItem(page, title);
```

#### AUTO 


```{c}
auto *groupBox = new QGroupBox;
```

#### RANGE FOR STATEMENT 


```{c}
for (const KContacts::Addressee &contact : contacts) {
        blocks.clear();
        QString name = contact.realName();
        if (!contact.title().isEmpty() || !contact.role().isEmpty()) {
            QStringList contentAddress;
            if (!contact.title().isEmpty()) {
                contentAddress << contact.title();
            }
            if (!contact.role().isEmpty()) {
                contentAddress << contact.role();
            }
            name += QStringLiteral(" (%1)").arg(contentAddress.join(QStringLiteral(", ")));
        }

        const QString birthday = QLocale().toString(contact.birthday().date(), QLocale::ShortFormat);

        if (!contact.organization().isEmpty()) {
            ContactBlock block;
            block.header = i18n("Organization:");
            block.entries.append(contact.organization());

            blocks.append(block);
        }

        if (!contact.emails().isEmpty()) {
            ContactBlock block;
            block.header = (contact.emails().count() == 1
                            ? i18n("Email address:")
                            : i18n("Email addresses:"));
            block.entries = contact.emails();

            blocks.append(block);
        }

        if (!contact.phoneNumbers().isEmpty()) {
            const KContacts::PhoneNumber::List numbers = contact.phoneNumbers();

            ContactBlock block;
            block.header = (numbers.count() == 1
                            ? i18n("Telephone:")
                            : i18n("Telephones:"));

            for (const KContacts::PhoneNumber &number : numbers) {
                const QString line = number.typeLabel() + QLatin1String(": ") + number.number();
                block.entries.append(line);
            }

            blocks.append(block);
        }

        if (contact.url().isValid()) {
            ContactBlock block;
            block.header = i18n("Web page:");
            block.entries.append(contact.url().url().toDisplayString());

            blocks.append(block);
        }

        if (!contact.addresses().isEmpty()) {
            const KContacts::Address::List addresses = contact.addresses();

            for (const KContacts::Address &address : addresses) {
                ContactBlock block;

                switch (address.type()) {
                case KContacts::Address::Dom:
                    block.header = i18n("Domestic Address");
                    break;
                case KContacts::Address::Intl:
                    block.header = i18n("International Address");
                    break;
                case KContacts::Address::Postal:
                    block.header = i18n("Postal Address");
                    break;
                case KContacts::Address::Parcel:
                    block.header = i18n("Parcel Address");
                    break;
                case KContacts::Address::Home:
                    block.header = i18n("Home Address");
                    break;
                case KContacts::Address::Work:
                    block.header = i18n("Work Address");
                    break;
                case KContacts::Address::Pref:
                default:
                    block.header = i18n("Preferred Address");
                }
                block.header += QLatin1Char(':');

#if QT_VERSION < QT_VERSION_CHECK(5, 15, 0)
                block.entries = address.formattedAddress().split(QLatin1Char('\n'), QString::KeepEmptyParts);
#else
                block.entries = address.formattedAddress().split(QLatin1Char('\n'), Qt::KeepEmptyParts);
#endif
                blocks.append(block);
            }
        }

        if (!contact.note().isEmpty()) {
            ContactBlock block;
            block.header = i18n("Notes:");
#if QT_VERSION < QT_VERSION_CHECK(5, 15, 0)
            block.entries = contact.note().split(QLatin1Char('\n'), QString::KeepEmptyParts);
#else
            block.entries = contact.note().split(QLatin1Char('\n'), Qt::KeepEmptyParts);
#endif

            blocks.append(block);
        }

        // add header
        content += QLatin1String("  <table style=\"border-width: 0px; border-spacing: 0px; "
                                 "page-break-inside: avoid\" cellspacing=\"0\" cellpadding=\"0\" width=\"100%\">\n");
        content += QLatin1String("   <tr>\n");
        content += QLatin1String("    <td style=\"color: ") + settings.headerTextColor
                   +QLatin1String(";\" bgcolor=\"") + settings.headerBackgroundColor
                   +QLatin1String(R"(" style="padding-left: 20px">)")
                   +name +  QLatin1String("</td>\n");
        content += QLatin1String("    <td style=\"color: ") + settings.headerTextColor
                   +QLatin1String(R"(;" align="right" bgcolor=")") + settings.headerBackgroundColor
                   +QLatin1String(R"(" style="padding-right: 20px">)")
                   +birthday + QLatin1String("</td>\n");
        content += QLatin1String("   </tr>\n");

        for (int i = 0; i < blocks.count(); i += 2) {
            // add empty line for spacing
            content += QLatin1String("   <tr>\n");
            content += QLatin1String("    <td>&nbsp;</td>\n");
            content += QLatin1String("    <td>&nbsp;</td>\n");
            content += QLatin1String("   </tr>\n");

            // add real block data
            const ContactBlock leftBlock = blocks.at(i);
            const ContactBlock rightBlock = ((i + 1 < blocks.count())
                                             ? blocks.at(i + 1)
                                             : ContactBlock());

            content += QLatin1String("   <tr>\n");
            content += QLatin1String("    <td>") + leftBlock.header + QLatin1String("</td>\n");
            content += QLatin1String("    <td>") + rightBlock.header + QLatin1String("</td>\n");
            content += QLatin1String("   </tr>\n");

            const int maxLines = qMax(leftBlock.entries.count(), rightBlock.entries.count());
            for (int j = 0; j < maxLines; ++j) {
                QString leftLine, rightLine;

                if (j < leftBlock.entries.count()) {
                    leftLine = leftBlock.entries.at(j);
                }

                if (j < rightBlock.entries.count()) {
                    rightLine = rightBlock.entries.at(j);
                }

                content += QLatin1String("   <tr>\n");
                content += QLatin1String("    <td class=\"indented\">") + leftLine + QLatin1String("</td>\n");
                content += QLatin1String("    <td class=\"indented\">") + rightLine + QLatin1String("</td>\n");
                content += QLatin1String("   </tr>\n");
            }
        }

        // add empty line for spacing
        content += QLatin1String("   <tr>\n");
        content += QLatin1String("    <td>&nbsp;</td>\n");
        content += QLatin1String("    <td>&nbsp;</td>\n");
        content += QLatin1String("   </tr>\n");
        content += QLatin1String("  </table>\n");
    }
```

#### AUTO 


```{c}
auto plugin = KAddressBookImportExport::PluginManager::self()->pluginFromIdentifier(identifier);
```

#### RANGE FOR STATEMENT 


```{c}
for (KAddressBookImportExport::PluginInterface *interface : std::as_const(mImportExportPluginInterfaceList)) {
                if (interface->canImportFileType(url)) {
                    interface->importFile(url);
                    break;
                }
            }
```

#### AUTO 


```{c}
auto groupBox = new QGroupBox;
```

#### AUTO 


```{c}
auto job = KIO::storedGet(url);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : fetchJob->items()) {
            if (item.isValid()) {
                if ((!item.gid().isEmpty() && refId[QStringLiteral("gid")].toString() == item.gid()) ||
                    QString::number(item.id()) == refId[QStringLiteral("uid")].toString()) {
                    if (item.hasPayload<KContacts::Addressee>()) {
                        mMonitor->setItemMonitored(item);
                        const KContacts::Addressee contact = item.payload<KContacts::Addressee>();
                        cacheContact.name = contact.realName();
                        cacheContact.email = contact.preferredEmail();
                    }
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &urlStr : parser.positionalArguments()) {
            const QUrl url(QUrl::fromUserInput(urlStr));
            Q_FOREACH(KAddressBookImportExport::KAddressBookImportExportPluginInterface *interface, mImportExportPluginInterfaceList) {
                if (interface->canImportFileType(url)) {
                    interface->importFile(url);
                    break;
                }
            }
        }
```

#### AUTO 


```{c}
const auto description = index.data(ContactInfoProxyModel::Roles::DescriptionRole).value<QString>();
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *act : qAsConst(importActions)) {
            importMenu->addAction(act);
        }
```

#### AUTO 


```{c}
auto sync = qobject_cast<Akonadi::CollectionAttributesSynchronizationJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : lstItems) {
            if (item.hasPayload<KContacts::Addressee>()) {
                contacts.append(item.payload<KContacts::Addressee>());
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KContacts::Addressee &contact : contacts) {
        QString name = contact.realName();
        if (!contact.title().isEmpty() || !contact.role().isEmpty()) {
            QStringList content;
            if (!contact.title().isEmpty()) {
                content << contact.title();
            }
            if (!contact.role().isEmpty()) {
                content << contact.role();
            }
            name += QStringLiteral(" (%1)").arg(content.join(QStringLiteral(", ")));
        }

        const QString birthday = QLocale().toString(contact.birthday().date(), QLocale::ShortFormat);

        ContactBlock::List blocks;

        if (!contact.organization().isEmpty()) {
            ContactBlock block;
            block.header = i18n("Organization:");
            block.entries.append(contact.organization());

            blocks.append(block);
        }

        if (!contact.emails().isEmpty()) {
            ContactBlock block;
            block.header = (contact.emails().count() == 1 ?
                            i18n("Email address:") :
                            i18n("Email addresses:"));
            block.entries = contact.emails();

            blocks.append(block);
        }

        if (!contact.phoneNumbers().isEmpty()) {
            const KContacts::PhoneNumber::List numbers = contact.phoneNumbers();

            ContactBlock block;
            block.header = (numbers.count() == 1 ?
                            i18n("Telephone:") :
                            i18n("Telephones:"));

            for (const KContacts::PhoneNumber &number : numbers) {
                const QString line = number.typeLabel() + QLatin1String(": ") + number.number();
                block.entries.append(line);
            }

            blocks.append(block);
        }

        if (contact.url().isValid()) {
            ContactBlock block;
            block.header = i18n("Web page:");
            block.entries.append(contact.url().url().toDisplayString());

            blocks.append(block);
        }

        if (!contact.addresses().isEmpty()) {
            const KContacts::Address::List addresses = contact.addresses();

            for (const KContacts::Address &address : addresses) {
                ContactBlock block;

                switch (address.type()) {
                case KContacts::Address::Dom:
                    block.header = i18n("Domestic Address");
                    break;
                case KContacts::Address::Intl:
                    block.header = i18n("International Address");
                    break;
                case KContacts::Address::Postal:
                    block.header = i18n("Postal Address");
                    break;
                case KContacts::Address::Parcel:
                    block.header = i18n("Parcel Address");
                    break;
                case KContacts::Address::Home:
                    block.header = i18n("Home Address");
                    break;
                case KContacts::Address::Work:
                    block.header = i18n("Work Address");
                    break;
                case KContacts::Address::Pref:
                default:
                    block.header = i18n("Preferred Address");
                }
                block.header += QLatin1Char(':');

                block.entries = address.formattedAddress().split(QLatin1Char('\n'), QString::KeepEmptyParts);
                blocks.append(block);
            }
        }

        if (!contact.note().isEmpty()) {
            ContactBlock block;
            block.header = i18n("Notes:");
            block.entries = contact.note().split(QLatin1Char('\n'), QString::KeepEmptyParts);

            blocks.append(block);
        }

        // add header
        content += QLatin1String("  <table style=\"border-width: 0px; border-spacing: 0px; "
                                 "page-break-inside: avoid\" cellspacing=\"0\" cellpadding=\"0\" width=\"100%\">\n");
        content += QLatin1String("   <tr>\n");
        content += QLatin1String("    <td style=\"color: ") + settings.headerTextColor +
                   QLatin1String(";\" bgcolor=\"") + settings.headerBackgroundColor +
                   QLatin1String("\" style=\"padding-left: 20px\">") +
                   name +  QLatin1String("</td>\n");
        content += QLatin1String("    <td style=\"color: ") + settings.headerTextColor +
                   QLatin1String(";\" align=\"right\" bgcolor=\"") + settings.headerBackgroundColor +
                   QLatin1String("\" style=\"padding-right: 20px\">") +
                   birthday + QLatin1String("</td>\n");
        content += QLatin1String("   </tr>\n");

        for (int i = 0; i < blocks.count(); i += 2) {
            // add empty line for spacing
            content += QLatin1String("   <tr>\n");
            content += QLatin1String("    <td>&nbsp;</td>\n");
            content += QLatin1String("    <td>&nbsp;</td>\n");
            content += QLatin1String("   </tr>\n");

            // add real block data
            const ContactBlock leftBlock = blocks.at(i);
            const ContactBlock rightBlock = ((i + 1 < blocks.count()) ?
                                             blocks.at(i + 1) :
                                             ContactBlock());

            content += QLatin1String("   <tr>\n");
            content += QLatin1String("    <td>") + leftBlock.header + QLatin1String("</td>\n");
            content += QLatin1String("    <td>") + rightBlock.header + QLatin1String("</td>\n");
            content += QLatin1String("   </tr>\n");

            const int maxLines = qMax(leftBlock.entries.count(), rightBlock.entries.count());
            for (int j = 0; j < maxLines; ++j) {
                QString leftLine, rightLine;

                if (j < leftBlock.entries.count()) {
                    leftLine = leftBlock.entries.at(j);
                }

                if (j < rightBlock.entries.count()) {
                    rightLine = rightBlock.entries.at(j);
                }

                content += QLatin1String("   <tr>\n");
                content += QLatin1String("    <td class=\"indented\">") + leftLine + QLatin1String("</td>\n");
                content += QLatin1String("    <td class=\"indented\">") + rightLine + QLatin1String("</td>\n");
                content += QLatin1String("   </tr>\n");
            }
        }

        // add empty line for spacing
        content += QLatin1String("   <tr>\n");
        content += QLatin1String("    <td>&nbsp;</td>\n");
        content += QLatin1String("    <td>&nbsp;</td>\n");
        content += QLatin1String("   </tr>\n");
        content += QLatin1String("  </table>\n");
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *act : qAsConst(exportActions)) {
            exportMenu->addAction(act);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (KAddressBookImportExport::KAddressBookImportExportPlugin *plugin : listPlugins) {
        if (plugin->isEnabled()) {
            KAddressBookImportExport::KAddressBookImportExportPluginInterface *interface
                = static_cast<KAddressBookImportExport::KAddressBookImportExportPluginInterface *>(plugin->createInterface(this));
            interface->setItemSelectionModel(mItemView->selectionModel());
            interface->setParentWidget(this);
            interface->createAction(collection);
            importActions.append(interface->importActions());
            exportActions.append(interface->exportActions());
            mImportExportPluginInterfaceList.append(interface);
            connect(interface, &PimCommon::AbstractGenericPluginInterface::emitPluginActivated, this, &MainWidget::slotImportExportActivated);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *wdg2 : std::as_const(mPageList)) {
        mWizard->setAppropriate(mPageItems[wdg2], true);
        wdg = wdg2;
    }
```

#### AUTO 


```{c}
const auto item = index.data(EntityTreeModel::ItemRole).value<Akonadi::Item>();
```

#### AUTO 


```{c}
const auto &property
```

#### AUTO 


```{c}
auto *fetchJob = qobject_cast<Akonadi::ItemFetchJob *>(job);
```

#### AUTO 


```{c}
auto act = new QAction(i18nc("@action:inmenu", "Simple (one column)"), mViewModeGroup);
```

#### AUTO 


```{c}
auto *mainLayout = new QVBoxLayout(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &directory : qAsConst(themesDirectories)) {
        QDirIterator dirIt(directory, QStringList(), QDir::AllDirs | QDir::NoDotAndDotDot);
        QStringList alreadyLoadedThemeName;
        while (dirIt.hasNext()) {
            dirIt.next();
            const QString themeInfoFile = dirIt.filePath() + QStringLiteral("/theme.desktop");
            KConfig config(themeInfoFile);
            KConfigGroup group(&config, QStringLiteral("Desktop Entry"));
            QString name = group.readEntry("Name", QString());
            if (name.isEmpty()) {
                continue;
            }
            if (alreadyLoadedThemeName.contains(name)) {
                int i = 2;
                const QString originalName(name);
                while (alreadyLoadedThemeName.contains(name)) {
                    name = originalName + QStringLiteral(" (%1)").arg(i);
                    ++i;
                }
            }
            const QString printThemePath(dirIt.filePath() + QLatin1Char('/'));
            if (!printThemePath.isEmpty()) {
                alreadyLoadedThemeName << name;
                mPrintStyleDefinition.append(new PrintStyleDefinition(new GrantleeStyleFactory(name, printThemePath, this)));
            }
        }
    }
```

#### AUTO 


```{c}
auto job = KIO::file_copy(QUrl::fromLocalFile(tmpFile.fileName()), url, -1, KIO::Overwrite);
```

#### AUTO 


```{c}
auto job = new Akonadi::RecursiveItemFetchJob(Akonadi::Collection::root(), QStringList() << KContacts::Addressee::mimeType());
```

#### AUTO 


```{c}
auto *sortLayout = new QGridLayout();
```

#### RANGE FOR STATEMENT 


```{c}
for (const KContacts::Addressee &contact : contacts) {
        QString nameString = contact.familyName() + QLatin1String(", ") + contact.givenName();

        if (fields & Organization) {
            if (!contact.organization().isEmpty()) {
                nameString += QLatin1String(" (") + contact.organization() + QLatin1Char(')');
            }
        }

        if (fields & Birthday) {
            if (contact.birthday().isValid()) {
                nameString += QLatin1String(" *") + QLocale().toString(contact.birthday().date(), QLocale::ShortFormat);
            }
        }

        QStringList leftBlock;
        QStringList rightBlock;
        if (fields & PhoneNumbers) {
            const KContacts::PhoneNumber::List numbers = contact.phoneNumbers();
            for (const KContacts::PhoneNumber &number : numbers) {
                rightBlock.append(number.typeLabel() + QLatin1String(": ") + number.number());
            }
        }
        if (fields & Emails) {
            const QStringList emails = contact.emails();
            for (const QString &email : emails) {
                rightBlock.append(email);
            }
        }
        if (fields & Note) {
            if (!contact.note().isEmpty()) {
                const QString note = i18n("Note: ") + contact.note().replace(QLatin1Char('\n'), QStringLiteral("<br/>"));

                rightBlock.append(note);
            }
        }
        if (fields & Addresses) {
            const KContacts::Address::List addresses = contact.addresses();
            for (const KContacts::Address &address : addresses) {
                const QString data = address.formatted(KContacts::AddressFormatStyle::Postal)
                                         .replace(QLatin1String("\n\n"), QStringLiteral("\n"))
                                         .replace(QLatin1Char('\n'), QStringLiteral("<br/>"));
                const QString subBlock = QLatin1String("<p style=\"margin-top: 0px; margin-left: 20px\">") + data + QLatin1String("</p>");

                leftBlock.append(subBlock);
            }
        }

        content += QLatin1String("   <tr>\n");
        content += QLatin1String(
                       "    <td style=\"padding-left: 3px; padding-top: 3px; padding-right: 3px; "
                       "padding-bottom: 3px;\">")
            + nameString + leftBlock.join(QString()) + QLatin1String("</td>\n");
        content += QLatin1String(
                       "    <td style=\"padding-left: 3px; padding-top: 3px; padding-right: 3px; "
                       "padding-bottom: 3px;\">")
            + rightBlock.join(QLatin1String("<br/>")) + QLatin1String("</td>\n");
        content += QLatin1String("   </tr>\n");
    }
```

#### AUTO 


```{c}
auto progressItem = new KPageWidgetItem(mProgress, i18n("Print Progress"));
```

#### AUTO 


```{c}
auto job = KIO::file_copy(QUrl::fromLocalFile(tmpFile.fileName()), newUrl);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &property : properties.toStdMap()) {
        job->setProperty(property.first, property.second);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&wizard]() { wizard.print(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *wdg : qAsConst(mPageList)) {
        mWizard->setAppropriate(mPageItems[wdg], false);
    }
```

#### AUTO 


```{c}
auto sync = new Akonadi::CollectionAttributesSynchronizationJob(col);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KContacts::Address &address : addresses) {
                const QString data = address.formatted(KContacts::AddressFormatStyle::Postal)
                                         .replace(QLatin1String("\n\n"), QStringLiteral("\n"))
                                         .replace(QLatin1Char('\n'), QStringLiteral("<br/>"));
                const QString subBlock = QLatin1String("<p style=\"margin-top: 0px; margin-left: 20px\">") + data + QLatin1String("</p>");

                leftBlock.append(subBlock);
            }
```

#### AUTO 


```{c}
auto importExportInterface = static_cast<KAddressBookImportExport::PluginInterface *>(interface);
```

#### AUTO 


```{c}
const auto collection = index.data(Akonadi::EntityTreeModel::CollectionRole).value<Akonadi::Collection>();
```

#### AUTO 


```{c}
const auto contact = item.payload<KContacts::Addressee>();
```

#### AUTO 


```{c}
auto importMenu = new KActionMenu(i18n("Import"), this);
```

#### AUTO 


```{c}
auto *job = new Akonadi::ItemCreateJob(item, collection);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &urlStr : lst) {
            const QUrl url(QUrl::fromUserInput(urlStr));
            for (KAddressBookImportExport::KAddressBookImportExportPluginInterface *interface : qAsConst(mImportExportPluginInterfaceList)) {
                if (interface->canImportFileType(url)) {
                    interface->importFile(url);
                    break;
                }
            }
        }
```

#### AUTO 


```{c}
auto *qrtoggleAction = collection->add<KToggleAction>(QStringLiteral("options_show_qrcodes"));
```

#### AUTO 


```{c}
auto *importExportInterface = static_cast<KAddressBookImportExport::PluginInterface *>(interface);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KContacts::Addressee &contact : contacts) {
        // get the values
        QStringList values;
        for (const ContactFields::Field &field : std::as_const(fields)) {
            // we need only values with content
            const QString value = ContactFields::value(field, contact).trimmed();
            if (!value.isEmpty()) {
                values << value;
            }
        }

        content += QLatin1String("   <tr>\n");
        QString style = QStringLiteral("background-color:");
        if (this->withAlternating) {
            style += (odd) ? this->firstColor.name() : this->secondColor.name();
        } else {
            style += QLatin1String("#ffffff");
        }
        content += QLatin1String("    <td style=\"") + style + QLatin1String(";\">") + values.join(QLatin1String("; ")) + QLatin1String("</td>\n");
        content += QLatin1String("   </tr>\n");
        odd = !odd;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *act : std::as_const(importActions)) {
            importMenu->addAction(act);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KContacts::Address &address : addresses) {
                ContactBlock block;

                switch (address.type()) {
                case KContacts::Address::Dom:
                    block.header = i18n("Domestic Address");
                    break;
                case KContacts::Address::Intl:
                    block.header = i18n("International Address");
                    break;
                case KContacts::Address::Postal:
                    block.header = i18n("Postal Address");
                    break;
                case KContacts::Address::Parcel:
                    block.header = i18n("Parcel Address");
                    break;
                case KContacts::Address::Home:
                    block.header = i18n("Home Address");
                    break;
                case KContacts::Address::Work:
                    block.header = i18n("Work Address");
                    break;
                case KContacts::Address::Pref:
                default:
                    block.header = i18n("Preferred Address");
                }
                block.header += QLatin1Char(':');

                block.entries = address.formattedAddress().split(QLatin1Char('\n'), Qt::KeepEmptyParts);
                blocks.append(block);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const ContactFields::Field &field : qAsConst(fields)) {
            // we need only values with content
            const QString value = ContactFields::value(field, contact).trimmed();
            if (!value.isEmpty()) {
                values << value;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KContacts::Addressee &contact : contacts) {
        QString nameString = contact.familyName() + QLatin1String(", ") + contact.givenName();

        if (fields & Organization) {
            if (!contact.organization().isEmpty()) {
                nameString += QLatin1String(" (") + contact.organization() + QLatin1Char(')');
            }
        }

        if (fields & Birthday) {
            if (contact.birthday().isValid()) {
                nameString += QLatin1String(" *") + QLocale().toString(contact.birthday().date(), QLocale::ShortFormat);
            }
        }

        QStringList leftBlock, rightBlock;
        if (fields & PhoneNumbers) {
            const KContacts::PhoneNumber::List numbers = contact.phoneNumbers();
            for (const KContacts::PhoneNumber &number : numbers) {
                rightBlock.append(number.typeLabel() + QLatin1String(": ") + number.number());
            }
        }
        if (fields & Emails) {
            const QStringList emails = contact.emails();
            for (const QString &email : emails) {
                rightBlock.append(email);
            }
        }
        if (fields & Note) {
            if (!contact.note().isEmpty()) {
                const QString note = QLatin1String("Note: ") + contact.note().replace(QLatin1Char('\n'), QStringLiteral("<br/>"));

                rightBlock.append(note);
            }
        }
        if (fields & Addresses) {
            const KContacts::Address::List addresses = contact.addresses();
            for (const KContacts::Address &address : addresses) {
                const QString data =
                    address.formattedAddress().replace(QLatin1String("\n\n"), QStringLiteral("\n")).replace(QLatin1Char('\n'), QStringLiteral("<br/>"));
                const QString subBlock = QLatin1String("<p style=\"margin-top: 0px; margin-left: 20px\">") + data + QLatin1String("</p>");

                leftBlock.append(subBlock);
            }
        }

        content += QLatin1String("   <tr>\n");
        content += QLatin1String("    <td style=\"padding-left: 3px; padding-top: 3px; padding-right: 3px; "
                                 "padding-bottom: 3px;\">") +
                   nameString + leftBlock.join(QString()) + QLatin1String("</td>\n");
        content += QLatin1String("    <td style=\"padding-left: 3px; padding-top: 3px; padding-right: 3px; "
                                 "padding-bottom: 3px;\">") +
                   rightBlock.join(QStringLiteral("<br/>")) + QLatin1String("</td>\n");
        content += QLatin1String("   </tr>\n");
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KContacts::Addressee &contact : contacts) {
        blocks.clear();
        QString name = contact.realName();
        if (!contact.title().isEmpty() || !contact.role().isEmpty()) {
            QStringList contentAddress;
            if (!contact.title().isEmpty()) {
                contentAddress << contact.title();
            }
            if (!contact.role().isEmpty()) {
                contentAddress << contact.role();
            }
            name += QStringLiteral(" (%1)").arg(contentAddress.join(QStringLiteral(", ")));
        }

        const QString birthday = QLocale().toString(contact.birthday().date(), QLocale::ShortFormat);

        if (!contact.organization().isEmpty()) {
            ContactBlock block;
            block.header = i18n("Organization:");
            block.entries.append(contact.organization());

            blocks.append(block);
        }

        if (!contact.emails().isEmpty()) {
            ContactBlock block;
            block.header = (contact.emails().count() == 1 ? i18n("Email address:") : i18n("Email addresses:"));
            block.entries = contact.emails();

            blocks.append(block);
        }

        if (!contact.phoneNumbers().isEmpty()) {
            const KContacts::PhoneNumber::List numbers = contact.phoneNumbers();

            ContactBlock block;
            block.header = (numbers.count() == 1 ? i18n("Telephone:") : i18n("Telephones:"));

            for (const KContacts::PhoneNumber &number : numbers) {
                const QString line = number.typeLabel() + QLatin1String(": ") + number.number();
                block.entries.append(line);
            }

            blocks.append(block);
        }

        if (contact.url().isValid()) {
            ContactBlock block;
            block.header = i18n("Web page:");
            block.entries.append(contact.url().url().toDisplayString());

            blocks.append(block);
        }

        if (!contact.addresses().isEmpty()) {
            const KContacts::Address::List addresses = contact.addresses();

            for (const KContacts::Address &address : addresses) {
                ContactBlock block;

                switch (address.type()) {
                case KContacts::Address::Dom:
                    block.header = i18n("Domestic Address");
                    break;
                case KContacts::Address::Intl:
                    block.header = i18n("International Address");
                    break;
                case KContacts::Address::Postal:
                    block.header = i18n("Postal Address");
                    break;
                case KContacts::Address::Parcel:
                    block.header = i18n("Parcel Address");
                    break;
                case KContacts::Address::Home:
                    block.header = i18n("Home Address");
                    break;
                case KContacts::Address::Work:
                    block.header = i18n("Work Address");
                    break;
                case KContacts::Address::Pref:
                default:
                    block.header = i18n("Preferred Address");
                }
                block.header += QLatin1Char(':');

                block.entries = address.formattedAddress().split(QLatin1Char('\n'), Qt::KeepEmptyParts);
                blocks.append(block);
            }
        }

        if (!contact.note().isEmpty()) {
            ContactBlock block;
            block.header = i18n("Notes:");
            block.entries = contact.note().split(QLatin1Char('\n'), Qt::KeepEmptyParts);

            blocks.append(block);
        }

        // add header
        content += QLatin1String(
            "  <table style=\"border-width: 0px; border-spacing: 0px; "
            "page-break-inside: avoid\" cellspacing=\"0\" cellpadding=\"0\" width=\"100%\">\n");
        content += QLatin1String("   <tr>\n");
        content += QLatin1String("    <td style=\"color: ") + settings.headerTextColor + QLatin1String(";\" bgcolor=\"") + settings.headerBackgroundColor
            + QLatin1String(R"(" style="padding-left: 20px">)") + name + QLatin1String("</td>\n");
        content += QLatin1String("    <td style=\"color: ") + settings.headerTextColor + QLatin1String(R"(;" align="right" bgcolor=")")
            + settings.headerBackgroundColor + QLatin1String(R"(" style="padding-right: 20px">)") + birthday + QLatin1String("</td>\n");
        content += QLatin1String("   </tr>\n");

        for (int i = 0; i < blocks.count(); i += 2) {
            // add empty line for spacing
            content += QLatin1String("   <tr>\n");
            content += QLatin1String("    <td>&nbsp;</td>\n");
            content += QLatin1String("    <td>&nbsp;</td>\n");
            content += QLatin1String("   </tr>\n");

            // add real block data
            const ContactBlock leftBlock = blocks.at(i);
            const ContactBlock rightBlock = ((i + 1 < blocks.count()) ? blocks.at(i + 1) : ContactBlock());

            content += QLatin1String("   <tr>\n");
            content += QLatin1String("    <td>") + leftBlock.header + QLatin1String("</td>\n");
            content += QLatin1String("    <td>") + rightBlock.header + QLatin1String("</td>\n");
            content += QLatin1String("   </tr>\n");

            const int maxLines = qMax(leftBlock.entries.count(), rightBlock.entries.count());
            for (int j = 0; j < maxLines; ++j) {
                QString leftLine, rightLine;

                if (j < leftBlock.entries.count()) {
                    leftLine = leftBlock.entries.at(j);
                }

                if (j < rightBlock.entries.count()) {
                    rightLine = rightBlock.entries.at(j);
                }

                content += QLatin1String("   <tr>\n");
                content += QLatin1String("    <td class=\"indented\">") + leftLine + QLatin1String("</td>\n");
                content += QLatin1String("    <td class=\"indented\">") + rightLine + QLatin1String("</td>\n");
                content += QLatin1String("   </tr>\n");
            }
        }

        // add empty line for spacing
        content += QLatin1String("   <tr>\n");
        content += QLatin1String("    <td>&nbsp;</td>\n");
        content += QLatin1String("    <td>&nbsp;</td>\n");
        content += QLatin1String("   </tr>\n");
        content += QLatin1String("  </table>\n");
    }
```

#### AUTO 


```{c}
auto gbox = new QGroupBox(i18nc("@title:group", "Fields to be exported"), this);
```

#### AUTO 


```{c}
auto plugin = KPluginFactory::instantiatePlugin<Plugin>(item->data, q, QVariantList() << item->metaDataFileNameBaseName).plugin
```

#### RANGE FOR STATEMENT 


```{c}
for (const Tag &tag : filterTagList) {
            if (tag.name() == cat) {
                return true; // a category matches filter
            }
        }
```

#### AUTO 


```{c}
const auto groupItemId = job->property("groupItemId").value<Akonadi::Item::Id>();
```

#### AUTO 


```{c}
auto label = new QLabel(i18nc("@label:textbox",
                                  "What should the print look like?\n"
                                  "KAddressBook has several printing styles, designed "
                                  "for different purposes.\n"
                                  "Choose the style that suits your needs below."),
                            this);
```

#### AUTO 


```{c}
auto *categoryFilter = new QWidgetAction(this);
```

#### AUTO 


```{c}
const auto url = QUrl{parser.value(QStringLiteral("view"))};
```

#### RANGE FOR STATEMENT 


```{c}
for (const KContacts::Addressee &contact : contacts) {
        QString name = contact.realName();
        if (!contact.title().isEmpty() || !contact.role().isEmpty()) {
            QStringList content;
            if (!contact.title().isEmpty()) {
                content << contact.title();
            }
            if (!contact.role().isEmpty()) {
                content << contact.role();
            }
            name += QStringLiteral(" (%1)").arg(content.join(QStringLiteral(", ")));
        }

        const QString birthday = QLocale().toString(contact.birthday().date(), QLocale::ShortFormat);

        ContactBlock::List blocks;

        if (!contact.organization().isEmpty()) {
            ContactBlock block;
            block.header = i18n("Organization:");
            block.entries.append(contact.organization());

            blocks.append(block);
        }

        if (!contact.emails().isEmpty()) {
            ContactBlock block;
            block.header = (contact.emails().count() == 1
                            ? i18n("Email address:")
                            : i18n("Email addresses:"));
            block.entries = contact.emails();

            blocks.append(block);
        }

        if (!contact.phoneNumbers().isEmpty()) {
            const KContacts::PhoneNumber::List numbers = contact.phoneNumbers();

            ContactBlock block;
            block.header = (numbers.count() == 1
                            ? i18n("Telephone:")
                            : i18n("Telephones:"));

            for (const KContacts::PhoneNumber &number : numbers) {
                const QString line = number.typeLabel() + QLatin1String(": ") + number.number();
                block.entries.append(line);
            }

            blocks.append(block);
        }

        if (contact.url().isValid()) {
            ContactBlock block;
            block.header = i18n("Web page:");
            block.entries.append(contact.url().url().toDisplayString());

            blocks.append(block);
        }

        if (!contact.addresses().isEmpty()) {
            const KContacts::Address::List addresses = contact.addresses();

            for (const KContacts::Address &address : addresses) {
                ContactBlock block;

                switch (address.type()) {
                case KContacts::Address::Dom:
                    block.header = i18n("Domestic Address");
                    break;
                case KContacts::Address::Intl:
                    block.header = i18n("International Address");
                    break;
                case KContacts::Address::Postal:
                    block.header = i18n("Postal Address");
                    break;
                case KContacts::Address::Parcel:
                    block.header = i18n("Parcel Address");
                    break;
                case KContacts::Address::Home:
                    block.header = i18n("Home Address");
                    break;
                case KContacts::Address::Work:
                    block.header = i18n("Work Address");
                    break;
                case KContacts::Address::Pref:
                default:
                    block.header = i18n("Preferred Address");
                }
                block.header += QLatin1Char(':');

                block.entries = address.formattedAddress().split(QLatin1Char('\n'), QString::KeepEmptyParts);
                blocks.append(block);
            }
        }

        if (!contact.note().isEmpty()) {
            ContactBlock block;
            block.header = i18n("Notes:");
            block.entries = contact.note().split(QLatin1Char('\n'), QString::KeepEmptyParts);

            blocks.append(block);
        }

        // add header
        content += QLatin1String("  <table style=\"border-width: 0px; border-spacing: 0px; "
                                 "page-break-inside: avoid\" cellspacing=\"0\" cellpadding=\"0\" width=\"100%\">\n");
        content += QLatin1String("   <tr>\n");
        content += QLatin1String("    <td style=\"color: ") + settings.headerTextColor
                   +QLatin1String(";\" bgcolor=\"") + settings.headerBackgroundColor
                   +QLatin1String("\" style=\"padding-left: 20px\">")
                   +name +  QLatin1String("</td>\n");
        content += QLatin1String("    <td style=\"color: ") + settings.headerTextColor
                   +QLatin1String(";\" align=\"right\" bgcolor=\"") + settings.headerBackgroundColor
                   +QLatin1String("\" style=\"padding-right: 20px\">")
                   +birthday + QLatin1String("</td>\n");
        content += QLatin1String("   </tr>\n");

        for (int i = 0; i < blocks.count(); i += 2) {
            // add empty line for spacing
            content += QLatin1String("   <tr>\n");
            content += QLatin1String("    <td>&nbsp;</td>\n");
            content += QLatin1String("    <td>&nbsp;</td>\n");
            content += QLatin1String("   </tr>\n");

            // add real block data
            const ContactBlock leftBlock = blocks.at(i);
            const ContactBlock rightBlock = ((i + 1 < blocks.count())
                                             ? blocks.at(i + 1)
                                             : ContactBlock());

            content += QLatin1String("   <tr>\n");
            content += QLatin1String("    <td>") + leftBlock.header + QLatin1String("</td>\n");
            content += QLatin1String("    <td>") + rightBlock.header + QLatin1String("</td>\n");
            content += QLatin1String("   </tr>\n");

            const int maxLines = qMax(leftBlock.entries.count(), rightBlock.entries.count());
            for (int j = 0; j < maxLines; ++j) {
                QString leftLine, rightLine;

                if (j < leftBlock.entries.count()) {
                    leftLine = leftBlock.entries.at(j);
                }

                if (j < rightBlock.entries.count()) {
                    rightLine = rightBlock.entries.at(j);
                }

                content += QLatin1String("   <tr>\n");
                content += QLatin1String("    <td class=\"indented\">") + leftLine + QLatin1String("</td>\n");
                content += QLatin1String("    <td class=\"indented\">") + rightLine + QLatin1String("</td>\n");
                content += QLatin1String("   </tr>\n");
            }
        }

        // add empty line for spacing
        content += QLatin1String("   <tr>\n");
        content += QLatin1String("    <td>&nbsp;</td>\n");
        content += QLatin1String("    <td>&nbsp;</td>\n");
        content += QLatin1String("   </tr>\n");
        content += QLatin1String("  </table>\n");
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KContacts::Addressee &contact : contacts) {
        QString nameString = contact.familyName() + QLatin1String(", ") + contact.givenName();

        if (fields & Organization) {
            if (!contact.organization().isEmpty()) {
                nameString += QLatin1String(" (") + contact.organization() + QLatin1Char(')');
            }
        }

        if (fields & Birthday) {
            if (contact.birthday().isValid()) {
                nameString += QLatin1String(" *") + QLocale().toString(contact.birthday().date(), QLocale::ShortFormat);
            }
        }

        QStringList leftBlock, rightBlock;
        if (fields & PhoneNumbers) {
            const KContacts::PhoneNumber::List numbers = contact.phoneNumbers();
            for (const KContacts::PhoneNumber &number : numbers) {
                rightBlock.append(number.typeLabel() + QLatin1String(": ") + number.number());
            }
        }
        if (fields & Emails) {
            const QStringList emails = contact.emails();
            for (const QString &email : emails) {
                rightBlock.append(email);
            }
        }
        if (fields & Note) {
            if (!contact.note().isEmpty()) {
                const QString note = i18n("Note: ") + contact.note().replace(QLatin1Char('\n'), QStringLiteral("<br/>"));

                rightBlock.append(note);
            }
        }
        if (fields & Addresses) {
            const KContacts::Address::List addresses = contact.addresses();
            for (const KContacts::Address &address : addresses) {
                const QString data =
                    address.formattedAddress().replace(QLatin1String("\n\n"), QStringLiteral("\n")).replace(QLatin1Char('\n'), QStringLiteral("<br/>"));
                const QString subBlock = QLatin1String("<p style=\"margin-top: 0px; margin-left: 20px\">") + data + QLatin1String("</p>");

                leftBlock.append(subBlock);
            }
        }

        content += QLatin1String("   <tr>\n");
        content += QLatin1String(
                       "    <td style=\"padding-left: 3px; padding-top: 3px; padding-right: 3px; "
                       "padding-bottom: 3px;\">")
            + nameString + leftBlock.join(QString()) + QLatin1String("</td>\n");
        content += QLatin1String(
                       "    <td style=\"padding-left: 3px; padding-top: 3px; padding-right: 3px; "
                       "padding-bottom: 3px;\">")
            + rightBlock.join(QLatin1String("<br/>")) + QLatin1String("</td>\n");
        content += QLatin1String("   </tr>\n");
    }
```

#### AUTO 


```{c}
const auto item = index.data(Akonadi::EntityTreeModel::ItemRole).value<Akonadi::Item>();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        updateHamburgerMenu();
        // Immediately disconnect. We only need to run this once, but on demand.
        // NOTE: The nullptr at the end disconnects all connections between
        // q and mHamburgerMenu's aboutToShowMenu signal.
        disconnect(mHamburgerMenu, &KHamburgerMenu::aboutToShowMenu, this, nullptr);
    }
```

#### AUTO 


```{c}
auto job = KIO::file_copy(QUrl::fromLocalFile(tmpFile.fileName()), url);
```

#### RANGE FOR STATEMENT 


```{c}
for (Akonadi::StandardActionManager::Type standardAction : std::as_const(standardActions)) {
        mActionManager->createAction(standardAction);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KContacts::Addressee &contact : contacts) {
        QString nameString = contact.familyName() + QLatin1String(", ") + contact.givenName();

        if (fields & Organization) {
            if (!contact.organization().isEmpty()) {
                nameString += QLatin1String(" (") + contact.organization() + QLatin1Char(')');
            }
        }

        if (fields & Birthday) {
            if (contact.birthday().isValid()) {
                nameString += QLatin1String(" *") + QLocale().toString(contact.birthday().date(), QLocale::ShortFormat);
            }
        }

        QStringList leftBlock;
        QStringList rightBlock;
        if (fields & PhoneNumbers) {
            const KContacts::PhoneNumber::List numbers = contact.phoneNumbers();
            for (const KContacts::PhoneNumber &number : numbers) {
                rightBlock.append(number.typeLabel() + QLatin1String(": ") + number.number());
            }
        }
        if (fields & Emails) {
            const QStringList emails = contact.emails();
            for (const QString &email : emails) {
                rightBlock.append(email);
            }
        }
        if (fields & Note) {
            if (!contact.note().isEmpty()) {
                const QString note = i18n("Note: ") + contact.note().replace(QLatin1Char('\n'), QStringLiteral("<br/>"));

                rightBlock.append(note);
            }
        }
        if (fields & Addresses) {
            const KContacts::Address::List addresses = contact.addresses();
            for (const KContacts::Address &address : addresses) {
                const QString data =
                    address.formattedAddress().replace(QLatin1String("\n\n"), QStringLiteral("\n")).replace(QLatin1Char('\n'), QStringLiteral("<br/>"));
                const QString subBlock = QLatin1String("<p style=\"margin-top: 0px; margin-left: 20px\">") + data + QLatin1String("</p>");

                leftBlock.append(subBlock);
            }
        }

        content += QLatin1String("   <tr>\n");
        content += QLatin1String(
                       "    <td style=\"padding-left: 3px; padding-top: 3px; padding-right: 3px; "
                       "padding-bottom: 3px;\">")
            + nameString + leftBlock.join(QString()) + QLatin1String("</td>\n");
        content += QLatin1String(
                       "    <td style=\"padding-left: 3px; padding-top: 3px; padding-right: 3px; "
                       "padding-bottom: 3px;\">")
            + rightBlock.join(QLatin1String("<br/>")) + QLatin1String("</td>\n");
        content += QLatin1String("   </tr>\n");
    }
```

#### AUTO 


```{c}
auto contactInfoProxyModel = new ContactInfoProxyModel(this);
```

#### AUTO 


```{c}
auto but = new QToolButton(q);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &urlStr : parser.positionalArguments()) {
            const QUrl url(QUrl::fromUserInput(urlStr));
            Q_FOREACH (KAddressBookImportExport::KAddressBookImportExportPluginInterface *interface, mImportExportPluginInterfaceList) {
                if (interface->canImportFileType(url)) {
                    interface->importFile(url);
                    break;
                }
            }
        }
```

#### AUTO 


```{c}
auto *job = new PimCommon::ManageServerSideSubscriptionJob(this);
```

#### AUTO 


```{c}
auto job = new Akonadi::ItemFetchJob(collection);
```

#### AUTO 


```{c}
const auto &cacheContact
```

#### AUTO 


```{c}
auto mSelectionPageItem = new KPageWidgetItem(mSelectionPage, i18n("Choose Contacts to Print"));
```

#### AUTO 


```{c}
auto fetch = new Akonadi::CollectionFetchJob(mMainWidget->currentAddressBook(), Akonadi::CollectionFetchJob::Base);
```

#### AUTO 


```{c}
const auto initials = index.data(ContactInfoProxyModel::Roles::InitialsRole).value<QString>();
```

#### AUTO 


```{c}
auto styleLayout = new QVBoxLayout();
```

#### RANGE FOR STATEMENT 


```{c}
for (const KContacts::Addressee &contact : contacts) {
        blocks.clear();
        QString name = contact.realName();
        if (!contact.title().isEmpty() || !contact.role().isEmpty()) {
            QStringList contentAddress;
            if (!contact.title().isEmpty()) {
                contentAddress << contact.title();
            }
            if (!contact.role().isEmpty()) {
                contentAddress << contact.role();
            }
            name += QStringLiteral(" (%1)").arg(contentAddress.join(QStringLiteral(", ")));
        }

        const QString birthday = QLocale().toString(contact.birthday().date(), QLocale::ShortFormat);


        if (!contact.organization().isEmpty()) {
            ContactBlock block;
            block.header = i18n("Organization:");
            block.entries.append(contact.organization());

            blocks.append(block);
        }

        if (!contact.emails().isEmpty()) {
            ContactBlock block;
            block.header = (contact.emails().count() == 1
                            ? i18n("Email address:")
                            : i18n("Email addresses:"));
            block.entries = contact.emails();

            blocks.append(block);
        }

        if (!contact.phoneNumbers().isEmpty()) {
            const KContacts::PhoneNumber::List numbers = contact.phoneNumbers();

            ContactBlock block;
            block.header = (numbers.count() == 1
                            ? i18n("Telephone:")
                            : i18n("Telephones:"));

            for (const KContacts::PhoneNumber &number : numbers) {
                const QString line = number.typeLabel() + QLatin1String(": ") + number.number();
                block.entries.append(line);
            }

            blocks.append(block);
        }

        if (contact.url().isValid()) {
            ContactBlock block;
            block.header = i18n("Web page:");
            block.entries.append(contact.url().url().toDisplayString());

            blocks.append(block);
        }

        if (!contact.addresses().isEmpty()) {
            const KContacts::Address::List addresses = contact.addresses();

            for (const KContacts::Address &address : addresses) {
                ContactBlock block;

                switch (address.type()) {
                case KContacts::Address::Dom:
                    block.header = i18n("Domestic Address");
                    break;
                case KContacts::Address::Intl:
                    block.header = i18n("International Address");
                    break;
                case KContacts::Address::Postal:
                    block.header = i18n("Postal Address");
                    break;
                case KContacts::Address::Parcel:
                    block.header = i18n("Parcel Address");
                    break;
                case KContacts::Address::Home:
                    block.header = i18n("Home Address");
                    break;
                case KContacts::Address::Work:
                    block.header = i18n("Work Address");
                    break;
                case KContacts::Address::Pref:
                default:
                    block.header = i18n("Preferred Address");
                }
                block.header += QLatin1Char(':');

#if QT_VERSION < QT_VERSION_CHECK(5, 15, 0)
                block.entries = address.formattedAddress().split(QLatin1Char('\n'), QString::KeepEmptyParts);
#else
                block.entries = address.formattedAddress().split(QLatin1Char('\n'), Qt::KeepEmptyParts);
#endif
                blocks.append(block);
            }
        }

        if (!contact.note().isEmpty()) {
            ContactBlock block;
            block.header = i18n("Notes:");
#if QT_VERSION < QT_VERSION_CHECK(5, 15, 0)
            block.entries = contact.note().split(QLatin1Char('\n'), QString::KeepEmptyParts);
#else
            block.entries = contact.note().split(QLatin1Char('\n'), Qt::KeepEmptyParts);
#endif

            blocks.append(block);
        }

        // add header
        content += QLatin1String("  <table style=\"border-width: 0px; border-spacing: 0px; "
                                 "page-break-inside: avoid\" cellspacing=\"0\" cellpadding=\"0\" width=\"100%\">\n");
        content += QLatin1String("   <tr>\n");
        content += QLatin1String("    <td style=\"color: ") + settings.headerTextColor
                   +QLatin1String(";\" bgcolor=\"") + settings.headerBackgroundColor
                   +QLatin1String("\" style=\"padding-left: 20px\">")
                   +name +  QLatin1String("</td>\n");
        content += QLatin1String("    <td style=\"color: ") + settings.headerTextColor
                   +QLatin1String(";\" align=\"right\" bgcolor=\"") + settings.headerBackgroundColor
                   +QLatin1String("\" style=\"padding-right: 20px\">")
                   +birthday + QLatin1String("</td>\n");
        content += QLatin1String("   </tr>\n");

        for (int i = 0; i < blocks.count(); i += 2) {
            // add empty line for spacing
            content += QLatin1String("   <tr>\n");
            content += QLatin1String("    <td>&nbsp;</td>\n");
            content += QLatin1String("    <td>&nbsp;</td>\n");
            content += QLatin1String("   </tr>\n");

            // add real block data
            const ContactBlock leftBlock = blocks.at(i);
            const ContactBlock rightBlock = ((i + 1 < blocks.count())
                                             ? blocks.at(i + 1)
                                             : ContactBlock());

            content += QLatin1String("   <tr>\n");
            content += QLatin1String("    <td>") + leftBlock.header + QLatin1String("</td>\n");
            content += QLatin1String("    <td>") + rightBlock.header + QLatin1String("</td>\n");
            content += QLatin1String("   </tr>\n");

            const int maxLines = qMax(leftBlock.entries.count(), rightBlock.entries.count());
            for (int j = 0; j < maxLines; ++j) {
                QString leftLine, rightLine;

                if (j < leftBlock.entries.count()) {
                    leftLine = leftBlock.entries.at(j);
                }

                if (j < rightBlock.entries.count()) {
                    rightLine = rightBlock.entries.at(j);
                }

                content += QLatin1String("   <tr>\n");
                content += QLatin1String("    <td class=\"indented\">") + leftLine + QLatin1String("</td>\n");
                content += QLatin1String("    <td class=\"indented\">") + rightLine + QLatin1String("</td>\n");
                content += QLatin1String("   </tr>\n");
            }
        }

        // add empty line for spacing
        content += QLatin1String("   <tr>\n");
        content += QLatin1String("    <td>&nbsp;</td>\n");
        content += QLatin1String("    <td>&nbsp;</td>\n");
        content += QLatin1String("   </tr>\n");
        content += QLatin1String("  </table>\n");
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KContacts::Address &address : addresses) {
                ContactBlock block;

                switch (address.type()) {
                case KContacts::Address::Dom:
                    block.header = i18n("Domestic Address");
                    break;
                case KContacts::Address::Intl:
                    block.header = i18n("International Address");
                    break;
                case KContacts::Address::Postal:
                    block.header = i18n("Postal Address");
                    break;
                case KContacts::Address::Parcel:
                    block.header = i18n("Parcel Address");
                    break;
                case KContacts::Address::Home:
                    block.header = i18n("Home Address");
                    break;
                case KContacts::Address::Work:
                    block.header = i18n("Work Address");
                    break;
                case KContacts::Address::Pref:
                default:
                    block.header = i18n("Preferred Address");
                }
                block.header += QLatin1Char(':');

#if QT_VERSION < QT_VERSION_CHECK(5, 15, 0)
                block.entries = address.formattedAddress().split(QLatin1Char('\n'), QString::KeepEmptyParts);
#else
                block.entries = address.formattedAddress().split(QLatin1Char('\n'), Qt::KeepEmptyParts);
#endif
                blocks.append(block);
            }
```

#### AUTO 


```{c}
auto plugin = (*it).plugin
```

#### LAMBDA EXPRESSION 


```{c}
[&groupContacts](const ContactCacheData &cacheContact) -> bool {
        for (int idx = 0; idx < groupContacts.contactReferenceCount(); ++idx) {
            const KContacts::ContactGroup::ContactReference &reference = groupContacts.contactReference(idx);

            if (cacheContact == reference) {
                return false;
            }
        }
        return true;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&phoneList](const KContacts::PhoneNumber &phone) {
            return phone.isPreferred() || phoneList.at(0) == phone;
        }
```

#### AUTO 


```{c}
auto themeMenu = new KActionMenu(i18n("&Themes"), this);
```

#### AUTO 


```{c}
const auto items = fetchJob->items();
```

#### AUTO 


```{c}
auto it = new QStandardItem(tagModel->data(idx, TagModel::NameRole).toString());
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *wdg2 : qAsConst(mPageList)) {
        mWizard->setAppropriate(mPageItems[ wdg2 ], true);
        wdg = wdg2;
    }
```

#### AUTO 


```{c}
auto *item = new KPageWidgetItem(page, title);
```

#### AUTO 


```{c}
auto *fetch = qobject_cast<Akonadi::CollectionFetchJob *>(job);
```

#### AUTO 


```{c}
auto *selectionProxyModel
        = new KSelectionProxyModel(mCollectionSelectionModel, this);
```

#### AUTO 


```{c}
auto gbLayout = new QHBoxLayout;
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *wdg2 : qAsConst(mPageList)) {
        mWizard->setAppropriate(mPageItems[wdg2], true);
        wdg = wdg2;
    }
```

#### AUTO 


```{c}
auto sortFunc = [](const QString &lhs, const QString &rhs) -> bool {
        return lhs.toLongLong() < rhs.toLongLong();
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const KContacts::PhoneNumber &number : numbers) {
                rightBlock.append(number.typeLabel() + QLatin1String(": ") + number.number());
            }
```

#### AUTO 


```{c}
auto saver = new Akonadi::ETMViewStateSaver;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QJsonObject &refId : groupRefIdsList) {
        ContactCacheData cacheContact;
        cacheContact.gid = refId[QStringLiteral("gid")].toString();
        cacheContact.uid = refId[QStringLiteral("uid")].toString();

        for (const Akonadi::Item &item : fetchJob->items()) {
            if (item.isValid()) {
                if ((!item.gid().isEmpty() && refId[QStringLiteral("gid")].toString() == item.gid()) ||
                    QString::number(item.id()) == refId[QStringLiteral("uid")].toString()) {
                    if (item.hasPayload<KContacts::Addressee>()) {
                        mMonitor->setItemMonitored(item);
                        const KContacts::Addressee contact = item.payload<KContacts::Addressee>();
                        cacheContact.name = contact.realName();
                        cacheContact.email = contact.preferredEmail();
                    }
                }
            }
        }
        if (mGroupsCache.contains(index)) {
            mGroupsCache[index].append(cacheContact);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&phoneList](const KContacts::PhoneNumber &phone) {
        return phone.isPreferred() || phoneList.at(0) == phone;
    }
```

#### AUTO 


```{c}
auto *styleLayout = new QVBoxLayout();
```

#### AUTO 


```{c}
auto b = new QToolButton(mb);
```

#### AUTO 


```{c}
auto *group = new QButtonGroup(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &urlStr : lst) {
            const QUrl url(QUrl::fromUserInput(urlStr));
            for (KAddressBookImportExport::PluginInterface *interface : std::as_const(mImportExportPluginInterfaceList)) {
                if (interface->canImportFileType(url)) {
                    interface->importFile(url);
                    break;
                }
            }
        }
```

#### AUTO 


```{c}
auto group = new QGroupBox(i18nc("@title:group", "Sorting"), this);
```

#### AUTO 


```{c}
auto *gbLayout = new QHBoxLayout;
```

#### AUTO 


```{c}
auto *sync
            = qobject_cast<Akonadi::CollectionAttributesSynchronizationJob *>(job);
```

#### AUTO 


```{c}
auto fetchJob = qobject_cast<Akonadi::ItemFetchJob *>(job);
```

#### AUTO 


```{c}
auto proxy = qobject_cast<QAbstractProxyModel *>(mCollectionView->model());
```

#### AUTO 


```{c}
auto image(index.data(ContactInfoProxyModel::Roles::PictureRole).value<QImage>());
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            updateHamburgerMenu();
            // Immediately disconnect. We only need to run this once, but on demand.
            // NOTE: The nullptr at the end disconnects all connections between
            // q and mHamburgerMenu's aboutToShowMenu signal.
            disconnect(mHamburgerMenu, &KHamburgerMenu::aboutToShowMenu, this, nullptr);
        }
```

#### AUTO 


```{c}
auto *contactInfoProxyModel = new ContactInfoProxyModel(this);
```

#### AUTO 


```{c}
auto *group = new QActionGroup(this);
```

#### AUTO 


```{c}
auto *detailsPaneLayout = new QVBoxLayout(mDetailsPane);
```

#### AUTO 


```{c}
auto *etm = qobject_cast<Akonadi::EntityTreeModel *>(proxy->sourceModel());
```

#### AUTO 


```{c}
const auto name = index.data(Qt::DisplayRole).value<QString>();
```

#### AUTO 


```{c}
auto job = new Akonadi::ItemCreateJob(item, collection);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KContacts::Addressee &contact : contacts) {
        const int max = qMax(leftFields.count(), rightFields.count());

        const QString name = contact.realName();

        if (counter % 2) {
            content += QLatin1String("  <br/><br/>\n");
        }

        // start a new page after every second table
        const QString pageBreak = ((counter % 2) ? QStringLiteral("page-break-after: always;") : QString());

        content += QLatin1String("  <table style=\"border-width: 0px; ") + pageBreak + QLatin1String("\" width=\"100%\">\n");
        content += QLatin1String("   <tr>\n");
        content += QLatin1String(
                       "    <th align=\"left\" style=\"color: black;\" bgcolor=\"gray\" "
                       "style=\"padding-left: 20px\" colspan=\"4\">")
            + name + QLatin1String("</th>\n");
        content += QLatin1String("   </tr>\n");

        for (int i = 0; i < max; ++i) {
            QString leftTitle, leftValue, rightTitle, rightValue;

            if (i < leftFields.count()) {
                leftTitle = ContactFields::label(leftFields.at(i)) + QLatin1Char(':');
                leftTitle.replace(QLatin1Char(' '), QStringLiteral("&nbsp;"));
                leftValue = ContactFields::value(leftFields.at(i), contact);
            }

            if (i < rightFields.count()) {
                rightTitle = ContactFields::label(rightFields.at(i)) + QLatin1Char(':');
                rightTitle.replace(QLatin1Char(' '), QStringLiteral("&nbsp;"));
                rightValue = ContactFields::value(rightFields.at(i), contact);
            }

            content += QLatin1String("   <tr>\n");
            content += QLatin1String("    <td>") + leftTitle + QLatin1String("</td>\n");
            content += QLatin1String("    <td>") + leftValue + QLatin1String("</td>\n");
            content += QLatin1String("    <td>") + rightTitle + QLatin1String("</td>\n");
            content += QLatin1String("    <td>") + rightValue + QLatin1String("</td>\n");
            content += QLatin1String("   </tr>\n");
        }
        content += QLatin1String("  </table>\n");

        counter++;
    }
```

#### AUTO 


```{c}
auto *hbox = new QHBoxLayout(q);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KContacts::Addressee &contact : contacts) {
        blocks.clear();
        QString name = contact.realName();
        if (!contact.title().isEmpty() || !contact.role().isEmpty()) {
            QStringList contentAddress;
            if (!contact.title().isEmpty()) {
                contentAddress << contact.title();
            }
            if (!contact.role().isEmpty()) {
                contentAddress << contact.role();
            }
            name += QStringLiteral(" (%1)").arg(contentAddress.join(QStringLiteral(", ")));
        }

        const QString birthday = QLocale().toString(contact.birthday().date(), QLocale::ShortFormat);

        if (!contact.organization().isEmpty()) {
            ContactBlock block;
            block.header = i18n("Organization:");
            block.entries.append(contact.organization());

            blocks.append(block);
        }

        if (!contact.emails().isEmpty()) {
            ContactBlock block;
            block.header = (contact.emails().count() == 1
                            ? i18n("Email address:")
                            : i18n("Email addresses:"));
            block.entries = contact.emails();

            blocks.append(block);
        }

        if (!contact.phoneNumbers().isEmpty()) {
            const KContacts::PhoneNumber::List numbers = contact.phoneNumbers();

            ContactBlock block;
            block.header = (numbers.count() == 1
                            ? i18n("Telephone:")
                            : i18n("Telephones:"));

            for (const KContacts::PhoneNumber &number : numbers) {
                const QString line = number.typeLabel() + QLatin1String(": ") + number.number();
                block.entries.append(line);
            }

            blocks.append(block);
        }

        if (contact.url().isValid()) {
            ContactBlock block;
            block.header = i18n("Web page:");
            block.entries.append(contact.url().url().toDisplayString());

            blocks.append(block);
        }

        if (!contact.addresses().isEmpty()) {
            const KContacts::Address::List addresses = contact.addresses();

            for (const KContacts::Address &address : addresses) {
                ContactBlock block;

                switch (address.type()) {
                case KContacts::Address::Dom:
                    block.header = i18n("Domestic Address");
                    break;
                case KContacts::Address::Intl:
                    block.header = i18n("International Address");
                    break;
                case KContacts::Address::Postal:
                    block.header = i18n("Postal Address");
                    break;
                case KContacts::Address::Parcel:
                    block.header = i18n("Parcel Address");
                    break;
                case KContacts::Address::Home:
                    block.header = i18n("Home Address");
                    break;
                case KContacts::Address::Work:
                    block.header = i18n("Work Address");
                    break;
                case KContacts::Address::Pref:
                default:
                    block.header = i18n("Preferred Address");
                }
                block.header += QLatin1Char(':');

#if QT_VERSION < QT_VERSION_CHECK(5, 15, 0)
                block.entries = address.formattedAddress().split(QLatin1Char('\n'), QString::KeepEmptyParts);
#else
                block.entries = address.formattedAddress().split(QLatin1Char('\n'), Qt::KeepEmptyParts);
#endif
                blocks.append(block);
            }
        }

        if (!contact.note().isEmpty()) {
            ContactBlock block;
            block.header = i18n("Notes:");
#if QT_VERSION < QT_VERSION_CHECK(5, 15, 0)
            block.entries = contact.note().split(QLatin1Char('\n'), QString::KeepEmptyParts);
#else
            block.entries = contact.note().split(QLatin1Char('\n'), Qt::KeepEmptyParts);
#endif

            blocks.append(block);
        }

        // add header
        content += QLatin1String("  <table style=\"border-width: 0px; border-spacing: 0px; "
                                 "page-break-inside: avoid\" cellspacing=\"0\" cellpadding=\"0\" width=\"100%\">\n");
        content += QLatin1String("   <tr>\n");
        content += QLatin1String("    <td style=\"color: ") + settings.headerTextColor
                   +QLatin1String(";\" bgcolor=\"") + settings.headerBackgroundColor
                   +QLatin1String("\" style=\"padding-left: 20px\">")
                   +name +  QLatin1String("</td>\n");
        content += QLatin1String("    <td style=\"color: ") + settings.headerTextColor
                   +QLatin1String(";\" align=\"right\" bgcolor=\"") + settings.headerBackgroundColor
                   +QLatin1String("\" style=\"padding-right: 20px\">")
                   +birthday + QLatin1String("</td>\n");
        content += QLatin1String("   </tr>\n");

        for (int i = 0; i < blocks.count(); i += 2) {
            // add empty line for spacing
            content += QLatin1String("   <tr>\n");
            content += QLatin1String("    <td>&nbsp;</td>\n");
            content += QLatin1String("    <td>&nbsp;</td>\n");
            content += QLatin1String("   </tr>\n");

            // add real block data
            const ContactBlock leftBlock = blocks.at(i);
            const ContactBlock rightBlock = ((i + 1 < blocks.count())
                                             ? blocks.at(i + 1)
                                             : ContactBlock());

            content += QLatin1String("   <tr>\n");
            content += QLatin1String("    <td>") + leftBlock.header + QLatin1String("</td>\n");
            content += QLatin1String("    <td>") + rightBlock.header + QLatin1String("</td>\n");
            content += QLatin1String("   </tr>\n");

            const int maxLines = qMax(leftBlock.entries.count(), rightBlock.entries.count());
            for (int j = 0; j < maxLines; ++j) {
                QString leftLine, rightLine;

                if (j < leftBlock.entries.count()) {
                    leftLine = leftBlock.entries.at(j);
                }

                if (j < rightBlock.entries.count()) {
                    rightLine = rightBlock.entries.at(j);
                }

                content += QLatin1String("   <tr>\n");
                content += QLatin1String("    <td class=\"indented\">") + leftLine + QLatin1String("</td>\n");
                content += QLatin1String("    <td class=\"indented\">") + rightLine + QLatin1String("</td>\n");
                content += QLatin1String("   </tr>\n");
            }
        }

        // add empty line for spacing
        content += QLatin1String("   <tr>\n");
        content += QLatin1String("    <td>&nbsp;</td>\n");
        content += QLatin1String("    <td>&nbsp;</td>\n");
        content += QLatin1String("   </tr>\n");
        content += QLatin1String("  </table>\n");
    }
```

#### AUTO 


```{c}
auto layout = new QVBoxLayout(this);
```

#### AUTO 


```{c}
auto *boxLayout = new QGridLayout;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &cacheContact : mGroupsCache[groupItemId]) {
        groupCacheRefIds += cacheContact.gid().isEmpty() ? cacheContact.uid() : cacheContact.gid();
    }
```

#### AUTO 


```{c}
auto *monitor = new Monitor(this);
```

#### AUTO 


```{c}
auto sortLayout = new QGridLayout();
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *w : std::as_const(widgets)) {
        if (w->objectName().isEmpty()) {
            continue;
        }
        PROCESS_TYPE(QSplitter);
        PROCESS_TYPE(QTabWidget);
        PROCESS_TYPE(QTreeView);
        PROCESS_TYPE(QComboBox);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &urlStr : lst) {
            const QUrl url(QUrl::fromUserInput(urlStr));
            for (KAddressBookImportExport::PluginInterface *interface : qAsConst(mImportExportPluginInterfaceList)) {
                if (interface->canImportFileType(url)) {
                    interface->importFile(url);
                    break;
                }
            }
        }
```

#### AUTO 


```{c}
auto view = qobject_cast<QHeaderView *>(mWidget);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto interface : std::as_const(mImportExportPluginInterfaceList)) {
        interface->setDefaultCollection(col);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KContacts::Addressee &contact : contacts) {
        // get the values
        QStringList values;
        for (const ContactFields::Field &field : qAsConst(fields)) {
            // we need only values with content
            const QString value = ContactFields::value(field, contact).trimmed();
            if (!value.isEmpty()) {
                values << value;
            }
        }

        content += QLatin1String("   <tr>\n");
        QString style = QStringLiteral("background-color:");
        if (this->withAlternating) {
            style += (odd) ? this->firstColor.name() : this->secondColor.name();
        } else {
            style += QLatin1String("#ffffff");
        }
        content += QLatin1String("    <td style=\"") + style + QLatin1String(";\">") + values.join(QLatin1String("; ")) + QLatin1String("</td>\n");
        content += QLatin1String("   </tr>\n");
        odd = !odd;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KContacts::PhoneNumber &number : numbers) {
                const QString line = number.typeLabel() + QLatin1String(": ") + number.number();
                block.entries.append(line);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &mimeType : mimeTypes) {
        if (collectionMimeTypes.contains(mimeType)) {
            return false;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KContacts::Addressee &contact : contacts) {
        // get the values
        QStringList values;
        for (const KAddressBookImportExport::KAddressBookImportExportContactFields::Field &field : qAsConst(fields)) {
            // we need only values with content
            const QString value = KAddressBookImportExport::KAddressBookImportExportContactFields::value(field, contact).trimmed();
            if (!value.isEmpty()) {
                values << value;
            }
        }

        content += QLatin1String("   <tr>\n");
        QString style = QStringLiteral("background-color:");
        if (this->withAlternating) {
            style += (odd) ? this->firstColor.name() : this->secondColor.name();
        } else {
            style += QLatin1String("#ffffff");
        }
        content += QLatin1String("    <td style=\"") + style + QLatin1String(";\">") + values.join(QLatin1String("; ")) + QLatin1String("</td>\n");
        content += QLatin1String("   </tr>\n");
        odd = !odd;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KAddressBookImportExport::Plugin *plugin : listPlugins) {
        if (plugin->isEnabled()) {
            KAddressBookImportExport::PluginInterface *interface
                = static_cast<KAddressBookImportExport::PluginInterface *>(plugin->createInterface(this));
            interface->setItemSelectionModel(mItemView->selectionModel());
            interface->setParentWidget(this);
            interface->createAction(collection);
            importActions.append(interface->importActions());
            exportActions.append(interface->exportActions());
            mImportExportPluginInterfaceList.append(interface);
            connect(interface, &PimCommon::AbstractGenericPluginInterface::emitPluginActivated, this, &MainWidget::slotImportExportActivated);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KContacts::Addressee &contact : contacts) {
        const int max = qMax(leftFields.count(), rightFields.count());

        const QString name = contact.realName();

        if (counter % 2) {
            content += QLatin1String("  <br/><br/>\n");
        }

        // start a new page after every second table
        const QString pageBreak = ((counter % 2) ? QStringLiteral("page-break-after: always;") : QString());

        content += QLatin1String("  <table style=\"border-width: 0px; ") + pageBreak + QLatin1String("\" width=\"100%\">\n");
        content += QLatin1String("   <tr>\n");
        content += QLatin1String("    <th align=\"left\" style=\"color: black;\" bgcolor=\"gray\" "
                                 "style=\"padding-left: 20px\" colspan=\"4\">") + name + QLatin1String("</th>\n");
        content += QLatin1String("   </tr>\n");

        for (int i = 0; i < max; ++i) {
            QString leftTitle, leftValue, rightTitle, rightValue;

            if (i < leftFields.count()) {
                leftTitle = KAddressBookImportExport::KAddressBookImportExportContactFields::label(leftFields.at(i)) + QLatin1Char(':');
                leftTitle = leftTitle.replace(QLatin1Char(' '), QStringLiteral("&nbsp;"));
                leftValue = KAddressBookImportExport::KAddressBookImportExportContactFields::value(leftFields.at(i), contact);
            }

            if (i < rightFields.count()) {
                rightTitle = KAddressBookImportExport::KAddressBookImportExportContactFields::label(rightFields.at(i)) + QLatin1Char(':');
                rightTitle = rightTitle.replace(QLatin1Char(' '), QStringLiteral("&nbsp;"));
                rightValue = KAddressBookImportExport::KAddressBookImportExportContactFields::value(rightFields.at(i), contact);
            }

            content += QLatin1String("   <tr>\n");
            content += QLatin1String("    <td>") + leftTitle + QLatin1String("</td>\n");
            content += QLatin1String("    <td>") + leftValue + QLatin1String("</td>\n");
            content += QLatin1String("    <td>") + rightTitle + QLatin1String("</td>\n");
            content += QLatin1String("    <td>") + rightValue + QLatin1String("</td>\n");
            content += QLatin1String("   </tr>\n");
        }
        content += QLatin1String("  </table>\n");

        counter++;
    }
```

