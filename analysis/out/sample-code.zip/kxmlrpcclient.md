#### AUTO 


```{c}
auto it = args.constBegin(), end = args.constEnd();
```

#### AUTO 


```{c}
auto it = d->mPendingQueries.begin(), end = d->mPendingQueries.end();
```

#### AUTO 


```{c}
auto it = jobMetaData.begin(), end = jobMetaData.end();
```

#### AUTO 


```{c}
auto it = map.constBegin(), end = map.constEnd();
```

#### AUTO 


```{c}
auto it = d->mPendingJobs.begin(), end = d->mPendingJobs.end();
```

