#### AUTO 


```{c}
auto mode = m_support->core()->runController()->launchModeForId("execute");
```

#### LAMBDA EXPRESSION 


```{c}
[langSupport] {
            rDebug() << "Initializing internal function file" << builtinsFile();
            ParseJob internalJob(builtinsFile(), langSupport);
            internalJob.setMinimumFeatures(TopDUContext::AllDeclarationsAndContexts);
            internalJob.run({}, nullptr);
            Q_ASSERT(internalJob.success());
        }
```

#### AUTO 


```{c}
const auto &type = getBuiltinsType(QStringLiteral("Class"), ctx);
```

#### AUTO 


```{c}
auto decl = getDeclaration(id, range, DUContextPointer(currentContext()));
```

#### LAMBDA EXPRESSION 


```{c}
[this](QVector<QuickOpenItem> &items) {
        const auto * const doc = ICore::self()->documentController()->activeDocument();

        QVector<Path> urlsToSwitch;
        if (m_kind == Kind::Views) {
            urlsToSwitch = Switchers::viewsToSwitch();
        } else if (m_kind == Kind::Tests) {
            urlsToSwitch = Switchers::testsToSwitch();
        }

        items.resize(urlsToSwitch.size());
        std::transform(urlsToSwitch.cbegin(), urlsToSwitch.cend(), items.begin(),
                       [doc](const Path &url) {
                           QuickOpenItem item;
                           item.url = url.toUrl();
                           if (doc) {
                               item.originUrl = Path(doc->url()).toUrl();
                           }
                           return item;
                       });
    }
```

#### AUTO 


```{c}
const auto top = DUChainUtils::standardContextForUrl(doc->url());
```

#### AUTO 


```{c}
auto config
```

#### RANGE FOR STATEMENT 


```{c}
for (const Declaration *d : ctx->findLocalDeclarations(md->identifier())) {
        if (d->type<FunctionType>()) {
            encounter(d->type<FunctionType>()->returnType());
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const ProblemPointer p : parser.problems) {
            rDebug() << "Added problem to context";
            m_duContext->addProblem(p);
        }
```

#### AUTO 


```{c}
const auto &builtins = builtinsFile();
```

#### AUTO 


```{c}
auto l
```

#### AUTO 


```{c}
auto document = view->document();
```

#### RANGE FOR STATEMENT 


```{c}
for (const KDevelop::Path &path : s_gemPath) {
        QDir dir(path.path());
        QStringList list = dir.entryList(filter, QDir::Dirs);
        int i = 0;
        for (const QString &inside : list) {
            KDevelop::Path url(path, inside + "/lib/" + real);
            QFile script(url.path());
            QFileInfo info(url.path());
            if (script.exists() && !info.isDir()) {
                // Sort the cache to break this loop sooner next time.
                if (i > 1) {
                    s_gemPath.prepend(s_gemPath.at(i - 1));
                    s_gemPath.removeAt(i);
                }
                return url;
            }
            i++;
        }
    }
```

#### AUTO 


```{c}
auto executePlugin = m_support->core()->pluginController()->
        pluginForExtension("org.kdevelop.IExecutePlugin")->extension<IExecutePlugin>();
```

#### LAMBDA EXPRESSION 


```{c}
[doc](const Path &url) {
                           QuickOpenItem item;
                           item.url = url.toUrl();
                           if (doc) {
                               item.originUrl = Path(doc->url()).toUrl();
                           }
                           return item;
                       }
```

#### AUTO 


```{c}
auto top = ContextBuilderBase::build(url, node, updateContext);
```

#### AUTO 


```{c}
auto context = NavigationContextPointer(new DeclarationNavigationContext(decl, topContext));
```

#### RANGE FOR STATEMENT 


```{c}
for (const IndexedString &url : unresolvedImports) {
                dependencyInQueue = KDevelop::ICore::self()->
                    languageController()->backgroundParser()->isQueued(url);
                if (dependencyInQueue) {
                    break;
                }
            }
```

#### AUTO 


```{c}
const auto &data = type.cast<IntegralType>()->dataType();
```

#### AUTO 


```{c}
auto config = m_support->core()->runController()->createLaunchConfiguration(
        type, qMakePair(mode->id(), launcher->id()), nullptr, name);
```

#### RANGE FOR STATEMENT 


```{c}
for (const ProblemPointer p : parser.problems) {
            m_duContext->addProblem(p);
        }
```

#### AUTO 


```{c}
auto type = mergeTypes(contentType().abstractType(), typeToAdd);
```

#### AUTO 


```{c}
auto name = editor->tokenToString(node);
```

#### AUTO 


```{c}
const auto &rb = QStringLiteral("kdevrubysupport/documentation/builtins.rb");
```

#### AUTO 


```{c}
auto decls = ctx->topContext()->findDeclarations(QualifiedIdentifier(desc));
```

#### AUTO 


```{c}
auto context = top->findContextAt(CursorInRevision(
        cursor.line(), cursor.column()
    ));
```

#### RANGE FOR STATEMENT 


```{c}
for (const KDevelop::Path &path : searchPaths) {
        KDevelop::Path url(path, name);
        QFile script(url.path());
        QFileInfo info(url.path());
        if (script.exists() && !info.isDir()) {
            // Sort the cache to break this loop sooner next time.
            if (i > 1) {
                s_rubyPath.prepend(s_rubyPath.at(i - 1));
                s_rubyPath.removeAt(i);
            }
            return url;
        }
        i++;
    }
```

#### AUTO 


```{c}
const auto &cursor = doc->cursorPosition();
```

#### AUTO 


```{c}
const auto * const doc = ICore::self()->documentController()->activeDocument();
```

#### AUTO 


```{c}
auto type = m_support->core()->runController()->launchConfigurationTypeForId(
        executePlugin->nativeAppConfigTypeId());
```

#### AUTO 


```{c}
auto context = previousContext()
```

#### RANGE FOR STATEMENT 


```{c}
for (auto l : type->launchers()) {
        if (l->supportedModes().contains(QStringLiteral("execute"))) {
            launcher = l;
            break;
        }
    }
```

#### AUTO 


```{c}
auto context = NavigationContextPointer(new IncludeNavigationContext(item, topContext));
```

#### AUTO 


```{c}
auto name = QStringList(i18n("Rails Views"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const ProblemPointer p : m_parser->problems) {
            rDebug() << "Added problem to context";
            m_duContext->addProblem(p);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const ProblemPointer p : m_parser->problems) {
            m_duContext->addProblem(p);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &inside : list) {
            KDevelop::Path url(path, inside + "/lib/" + real);
            QFile script(url.path());
            QFileInfo info(url.path());
            if (script.exists() && !info.isDir()) {
                // Sort the cache to break this loop sooner next time.
                if (i > 1) {
                    s_gemPath.prepend(s_gemPath.at(i - 1));
                    s_gemPath.removeAt(i);
                }
                return url;
            }
            i++;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto config : m_support->core()->runController()->launchConfigurations()) {
        if (config->name() == name) {
            return config;
        }
    }
```

#### AUTO 


```{c}
auto doc = KDevelop::ICore::self()->documentController()->activeDocument();
```

#### RANGE FOR STATEMENT 


```{c}
for (const KDevelop::Path &path : paths) {
        KDevelop::Path aux(path, url);
        QDirIterator it(aux.path());

        while (it.hasNext()) {
            it.next();
            KDevelop::IncludeItem item;
            item.name = it.fileInfo().fileName();
            if (item.name.startsWith(QStringLiteral(".")) ||
                item.name.endsWith(QStringLiteral("~")) ||
                item.name.endsWith(QStringLiteral(".so"))) {

                continue;
            }
            item.pathNumber = number;
            item.isDirectory = it.fileInfo().isDir();
            item.basePath = aux.toUrl();
            res << item;
        }
        number++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const ProblemPointer p : m_parser->problems) {
            qCDebug(KDEV_RUBY) << "Added problem to context";
            m_duContext->addProblem(p);
        }
```

#### AUTO 


```{c}
const auto &langSupport = languageSupport();
```

#### LAMBDA EXPRESSION 


```{c}
[langSupport] {
            qCDebug(KDEV_RUBY) << "Initializing internal function file" << builtinsFile();
            ParseJob internalJob(builtinsFile(), langSupport);
            internalJob.setMinimumFeatures(TopDUContext::AllDeclarationsAndContexts);
            internalJob.run({}, nullptr);
            Q_ASSERT(internalJob.success());
        }
```

#### AUTO 


```{c}
auto qo = m_support->core()->pluginController()->
        extensionForPlugin<KDevelop::IQuickOpen>("org.kdevelop.IQuickOpen");
```

#### AUTO 


```{c}
auto quickOpen = ICore::self()->pluginController()->
        extensionForPlugin<IQuickOpen>("org.kdevelop.IQuickOpen");
```

#### AUTO 


```{c}
const auto &unresolvedImports = builder.unresolvedImports();
```

#### AUTO 


```{c}
auto doc = ICore::self()->documentController()->activeDocument();
```

#### AUTO 


```{c}
auto mods = top->parsingEnvironmentFile()->allModificationRevisions();
```

#### AUTO 


```{c}
auto parser = ICore::self()->languageController()->backgroundParser();
```

