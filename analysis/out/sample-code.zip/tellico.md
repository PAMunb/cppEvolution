#### AUTO 


```{c}
auto countLabel = new QLabel(i18n("Total number of entries: %1").arg(count_), widget);
```

#### AUTO 


```{c}
auto i = m_platforms.constBegin();
```

#### AUTO 


```{c}
auto dw = dynamic_cast<Tellico::GUI::DateWidget*>(w.widget());
```

#### AUTO 


```{c}
auto c = data_.at(i);
```

#### AUTO 


```{c}
auto titleMatch = titleRx.match(str_);
```

#### AUTO 


```{c}
auto i = m_addedMacros.constBegin();
```

#### AUTO 


```{c}
auto series = new QLineSeries;
```

#### AUTO 


```{c}
auto listAfterInstall = Tellico::NewStuff::Manager::self()->userTemplates();
```

#### AUTO 


```{c}
auto p = Merge::mergeFields(c, fields, entries_);
```

#### AUTO 


```{c}
auto barSet = new QBarSet(names_.at(i));
```

#### AUTO 


```{c}
auto requester = dynamic_cast<KUrlRequester*>(w.widget());
```

#### AUTO 


```{c}
auto genres = Tellico::FieldFormat::splitValue(entry->field(QStringLiteral("genre")));
```

#### AUTO 


```{c}
auto mechs = Tellico::FieldFormat::splitValue(entry->field(QStringLiteral("mechanism")));
```

#### AUTO 


```{c}
const auto xslt = QByteArray( \
    "<xsl:stylesheet xmlns:xsl=\"http://www.w3.org/1999/XSL/Transform\" version=\"1.0\">" \
    "  <xsl:output method=\"xml\" version=\"1.0\" encoding=\"windows-1251\"/>" \
    "  <xsl:template match=\"/\"/>" \
    "</xsl:stylesheet>" \
  );
```

#### AUTO 


```{c}
auto fetcher = m_fetchers[m_fetchIndex];
```

#### AUTO 


```{c}
auto infoMatch = infoRx.match(info);
```

#### AUTO 


```{c}
const auto mergeResult = mergeCollection(m_coll, coll_);
```

#### AUTO 


```{c}
auto list = map.value(QStringLiteral("screenshots")).toList();
```

#### AUTO 


```{c}
auto new_field = new_coll->fieldByName(QStringLiteral("publisher"));
```

#### AUTO 


```{c}
auto bibtexColl1 = new Tellico::Data::BibtexCollection(true);
```

#### AUTO 


```{c}
auto const paintRect = printer.pageLayout().paintRectPixels(printer.resolution());
```

#### AUTO 


```{c}
auto sb = dynamic_cast<Tellico::GUI::SpinBox*>(w.widget());
```

#### AUTO 


```{c}
auto locationMatch = locationRx.match(s);
```

#### AUTO 


```{c}
const auto imageList = resultMap_.value(QLatin1String("images")).toList();
```

#### AUTO 


```{c}
auto list = Tellico::NewStuff::Manager::self()->userTemplates();
```

#### AUTO 


```{c}
auto grad = chart->backgroundBrush().gradient();
```

#### AUTO 


```{c}
auto interface = QDBusConnection::sessionBus().interface();
```

#### AUTO 


```{c}
auto idxName = m_colnectFields.value(name, -1);
```

#### AUTO 


```{c}
auto cb = dynamic_cast<QComboBox*>(w.widget());
```

#### AUTO 


```{c}
auto axisY = new QBarCategoryAxis();
```

#### AUTO 


```{c}
auto saveAs = KStandardAction::saveAs(this, &ImageWidget::saveImageAs, &menu);
```

#### AUTO 


```{c}
auto reply = conn.call(msg);
```

#### AUTO 


```{c}
auto ii = m_platforms.constBegin();
```

#### AUTO 


```{c}
auto langName = KLanguageName::nameForCode(lang);
```

#### AUTO 


```{c}
auto bibtexColl2 = new Tellico::Data::BibtexCollection(true);
```

#### AUTO 


```{c}
auto filter2 = coll->filters().front();
```

#### AUTO 


```{c}
auto item = formatModel->itemFromIndex(matchList.front());
```

#### AUTO 


```{c}
auto origColl = static_cast<Data::BibtexCollection*>(m_origColl.data());
```

#### AUTO 


```{c}
auto it = templates.constBegin();
```

#### AUTO 


```{c}
auto anchorMatch = anchorRx.match(dataValue);
```

#### AUTO 


```{c}
auto config = KSharedConfig::openConfig(QString(), KConfig::SimpleConfig)->group(QStringLiteral("vndb"));
```

#### AUTO 


```{c}
const auto stops = grad->stops();
```

#### AUTO 


```{c}
auto res = new FetchResult(this, title, year);
```

#### AUTO 


```{c}
auto starsMatch = starsPathRx.match(output2);
```

#### AUTO 


```{c}
auto titleMatch = titleRx.match(s);
```

#### AUTO 


```{c}
auto match = yearRx.match(inParentheses);
```

#### AUTO 


```{c}
auto page = static_cast<QWebEnginePage*>(sender());
```

#### AUTO 


```{c}
auto docUrl = doc->URL();
```

#### AUTO 


```{c}
auto request = fetcher.updateRequest(entry);
```

#### AUTO 


```{c}
auto itemMatch = matchIterator.next();
```

#### AUTO 


```{c}
auto screenshotList = resultMap_.value(QStringLiteral("screenshots")).toList();
```

#### AUTO 


```{c}
auto newEntry = m_matches.at(bestIndex);
```

#### AUTO 


```{c}
auto loan1 = borr1->loans().front();
```

#### AUTO 


```{c}
auto coll = doc->collection();
```

#### AUTO 


```{c}
auto fetchManager = Tellico::Fetch::Manager::self();
```

#### AUTO 


```{c}
auto axisY = new QValueAxis;
```

#### AUTO 


```{c}
auto newBookCollection = new Tellico::Data::BookCollection(true);
```

#### AUTO 


```{c}
auto job = getJob(refreshUrl, false /* check token */);
```

#### AUTO 


```{c}
auto macroList = bColl->macroList();
```

#### AUTO 


```{c}
auto spec = KSharedConfig::openConfig(specFile, KConfig::SimpleConfig)->group(QString());
```

#### AUTO 


```{c}
auto rating = dynamic_cast<Tellico::GUI::RatingWidget*>(w.widget());
```

#### AUTO 


```{c}
auto allEntries = m_origColl->entryIdList();
```

#### AUTO 


```{c}
auto barSet = new QBarSet(yearField);
```

#### AUTO 


```{c}
auto tw = dynamic_cast<QTableWidget*>(w.widget());
```

#### AUTO 


```{c}
auto field = coll->fieldByName(QStringLiteral("publisher"));
```

#### AUTO 


```{c}
auto borr2 = coll2->borrowers().front();
```

#### AUTO 


```{c}
auto remoteList = resultMap_.value(QLatin1String("remoteIds")).toList();
```

#### AUTO 


```{c}
auto match = m_matches.at(idx);
```

#### AUTO 


```{c}
auto f = registry.value(i.key()).create(this);
```

#### AUTO 


```{c}
auto listAfterDelete = Tellico::NewStuff::Manager::self()->userTemplates();
```

#### AUTO 


```{c}
auto chart = new QChart;
```

#### AUTO 


```{c}
auto const paperRect = printer.pageLayout().fullRectPixels(printer.resolution());
```

#### AUTO 


```{c}
auto borrowerList = coll->borrowers();
```

#### AUTO 


```{c}
auto msg = QDBusMessage::createMethodCall(QStringLiteral("org.kde.tellico"),          // Service
                                            QStringLiteral("/NewStuff"),                // Path
                                            QStringLiteral("org.kde.tellico.newstuff"), // Interface
                                            QStringLiteral("installTemplate")           // Method
                                           );
```

#### AUTO 


```{c}
auto widget = new GroupSummaryWidget(coll->title(), coll->entryCount());
```

#### AUTO 


```{c}
auto axisX = new QDateTimeAxis;
```

#### LAMBDA EXPRESSION 


```{c}
[&](bool) { loop.quit(); }
```

#### AUTO 


```{c}
auto docUrl = Tellico::Data::Document::self()->URL();
```

#### AUTO 


```{c}
auto coverMatch = coverRx.match(str_);
```

#### AUTO 


```{c}
const auto episodeList = resultMap_.value(seasonString).toMap()
                                         .value(QStringLiteral("episodes")).toList();
```

#### AUTO 


```{c}
auto axisX = new QValueAxis();
```

#### AUTO 


```{c}
auto series = new QHorizontalStackedBarSeries();
```

#### AUTO 


```{c}
auto publishers = FieldFormat::splitValue(pub);
```

#### AUTO 


```{c}
auto borr1 = borrowerList.front();
```

#### AUTO 


```{c}
const auto obj = staffArray.at(i).toObject().toVariantMap();
```

#### AUTO 


```{c}
auto textWidth = parent_->fontMetrics().horizontalAdvance(charSets.last());
```

#### AUTO 


```{c}
auto series = new QBarSeries;
```

#### AUTO 


```{c}
auto existingEntries = m_origColl->entryIdList();
```

#### AUTO 


```{c}
auto multiConfig = KSharedConfig::openConfig(QString(), KConfig::SimpleConfig)->group(QStringLiteral("multi"));
```

#### AUTO 


```{c}
auto p = Tellico::Merge::mergeFields(m_coll,
                                         m_newEntry->collection()->fields(),
                                         Data::EntryList() << m_newEntry);
```

#### AUTO 


```{c}
auto obj = conn.objectRegisteredAt(QStringLiteral("/NewStuff"));
```

#### AUTO 


```{c}
const auto tokenType = m_xml.readNext();
```

#### AUTO 


```{c}
auto filterList = coll->filters();
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QUrl& u) {
    openExternalLink(u);
    auto page = static_cast<QWebEnginePage*>(sender());
    page->action(QWebEnginePage::Stop)->trigger(); // stop the loading, further is unneccesary
    page->deleteLater();
  }
```

#### AUTO 


```{c}
auto res = new FetchResult(this, request().value(), QString());
```

#### AUTO 


```{c}
auto conn = QDBusConnection::sessionBus();
```

#### LAMBDA EXPRESSION 


```{c}
[action]() {
    const QString ymd = QStandardPaths::findExecutable(QStringLiteral("yaz-marcdump"));
    action->setEnabled(!ymd.isEmpty());
  }
```

#### AUTO 


```{c}
auto startList = Tellico::NewStuff::Manager::self()->userTemplates();
```

#### AUTO 


```{c}
auto cb = dynamic_cast<QCheckBox*>(w.widget());
```

#### AUTO 


```{c}
auto layout = new QVBoxLayout(widget);
```

#### AUTO 


```{c}
auto new_coll = doc->collection();
```

#### AUTO 


```{c}
auto i = registry.constBegin();
```

#### AUTO 


```{c}
auto job = KIO::file_copy(QUrl::fromLocalFile(file_), QUrl::fromLocalFile(scriptFolder + exeFile));
```

#### AUTO 


```{c}
auto ttMatch = ttRx.match(imdb);
```

#### AUTO 


```{c}
auto chartView = new View(chart, widget);
```

#### AUTO 


```{c}
auto formatModel = qobject_cast<const QStandardItemModel*>(m_formatCombo->model());
```

#### AUTO 


```{c}
auto divMatch = divRx.match(str_);
```

#### AUTO 


```{c}
auto le = dynamic_cast<QLineEdit*>(w.widget());
```

#### AUTO 


```{c}
auto job = KIO::file_copy(QUrl::fromLocalFile(file_), QUrl::fromLocalFile(name));
```

#### AUTO 


```{c}
auto chartView = new QChartView(chart, widget());
```

#### AUTO 


```{c}
auto filter1 = filterList.front();
```

#### AUTO 


```{c}
auto chart = new BarChart(groupNames, groupCounts);
```

#### AUTO 


```{c}
auto request = f->updateRequest(oldEntry);
```

#### AUTO 


```{c}
const auto code = mapValue(resultMap, "code");
```

#### AUTO 


```{c}
auto le = dynamic_cast<Tellico::GUI::LineEdit*>(w.widget());
```

#### LAMBDA EXPRESSION 


```{c}
[](bool) {}
```

#### AUTO 


```{c}
auto titleLabel = new QLabel(i18n("Group Summary: %1").arg(title_), widget);
```

#### AUTO 


```{c}
auto list = Tellico::Fetch::Manager::self()->fetchers();
```

#### AUTO 


```{c}
const auto staffArray = QJsonDocument::fromJson(data).array();
```

#### AUTO 


```{c}
auto axisX = new QValueAxis;
```

#### AUTO 


```{c}
const auto c = it.next();
```

#### AUTO 


```{c}
auto yearMatch = yearRx.match(s);
```

#### AUTO 


```{c}
auto widget = new QWidget;
```

#### AUTO 


```{c}
auto handler = xsltHandler();
```

#### AUTO 


```{c}
auto info = QPrinterInfo::defaultPrinter();
```

#### AUTO 


```{c}
auto tempDirName = m_tempDir.path();
```

#### AUTO 


```{c}
auto matchIterator = itemRx.globalMatch(s);
```

#### AUTO 


```{c}
auto it2 = templates.constBegin();
```

#### AUTO 


```{c}
auto slugMatch = slugRx.match(thetvdb);
```

#### AUTO 


```{c}
auto loan2 = borr2->loans().front();
```

#### AUTO 


```{c}
auto f = static_cast<Tellico::Fetch::OpenLibraryFetcher*>(fetcher.data());
```

#### AUTO 


```{c}
auto registry = Tellico::Fetch::Manager::self()->functionRegistry;
```

#### LAMBDA EXPRESSION 


```{c}
[&set, &returnList](const Data::FieldPtr& f) {
          if(set.contains(f)) {
            returnList.append(f);
            set.remove(f);
          }
        }
```

#### AUTO 


```{c}
auto year = objectMap.value(QLatin1String("minYear"));
```

#### AUTO 


```{c}
auto p = Tellico::Merge::mergeFields(coll1,
                                       Tellico::Data::FieldList() << coll2->fieldByName(QStringLiteral("platform")),
                                       Tellico::Data::EntryList() << entry2);
```

#### AUTO 


```{c}
auto oldColl = doc->collection();
```

#### AUTO 


```{c}
auto standardCopy = KStandardAction::copy(this, &ImageWidget::copyImage, &menu);
```

#### AUTO 


```{c}
auto matchList = formatModel->match(formatModel->index(0, 0), Qt::UserRole, Import::Bibtex);
```

#### AUTO 


```{c}
auto countLabel = new QLabel(i18n("Total number of entries: %1", count_), widget);
```

#### AUTO 


```{c}
auto page = new QWebEnginePage(this);
```

#### AUTO 


```{c}
auto i = newMacros.constBegin();
```

#### AUTO 


```{c}
auto job = getJob(url);
```

#### AUTO 


```{c}
auto test = QStringLiteral("test");
```

#### AUTO 


```{c}
const auto inParentheses = cap1.midRef(pPos+1, pPos2-pPos-1);
```

#### AUTO 


```{c}
auto certField = coll->fieldByName(cert);
```

#### AUTO 


```{c}
auto chartView = new QChartView(chart, widget);
```

#### AUTO 


```{c}
auto end = registry.constEnd();
```

#### AUTO 


```{c}
auto edit = dynamic_cast<KTextEdit*>(w.widget());
```

#### AUTO 


```{c}
const auto mergeResult = mergeCollection(m_coll, coll_, &structuralChange);
```

#### AUTO 


```{c}
auto doc = Tellico::Data::Document::self();
```

#### AUTO 


```{c}
auto origTitleMatch = origTitleRx.match(str_);
```

#### AUTO 


```{c}
auto config = KSharedConfig::openConfig(QString(), KConfig::SimpleConfig)->group(QStringLiteral("multi"));
```

#### AUTO 


```{c}
auto f = static_cast<Tellico::Fetch::TheTVDBFetcher*>(fetcher.data());
```

#### AUTO 


```{c}
auto offers = KApplicationTrader::queryByMimeType(QStringLiteral("image/png"));
```

#### AUTO 


```{c}
auto chart = m_charts.at(idx);
```

#### AUTO 


```{c}
auto titleLabel = new QLabel(i18n("Group Summary: %1", title_), widget);
```

