#### AUTO 


```{c}
const auto mode = static_cast<ChecksumSearch::UrlChangeMode>(ui.mode->currentIndex());
```

#### AUTO 


```{c}
auto *download = new Download(m_source, QUrl::fromLocalFile(path));
```

#### AUTO 


```{c}
auto *queue = new TestQueue(&scheduler);
```

#### AUTO 


```{c}
auto *link_view = new KGetLinkView(m_mainWindow);
```

#### AUTO 


```{c}
auto *job = new KIO::CommandLauncherJob(command);
```

#### AUTO 


```{c}
auto *proxy = new QSortFilterProxyModel(this);
```

#### AUTO 


```{c}
const auto *model = static_cast <const QAbstractItemModel *> (index.model());
```

#### AUTO 


```{c}
auto *job = static_cast<MostLocalUrlJob*>(j);
```

#### AUTO 


```{c}
auto *pattern = new KLineEdit(parent);
```

#### AUTO 


```{c}
auto* transfer = static_cast<Transfer*>(*it);
```

#### AUTO 


```{c}
auto prio = (bt::Priority)value.toInt();
```

#### AUTO 


```{c}
auto* eTagCher = new KGetMetalink::MetalinkHttpParser(url) ;
```

#### AUTO 


```{c}
auto *data = new QWidget(this);
```

#### AUTO 


```{c}
auto *modesBox = new KComboBox(parent);
```

#### AUTO 


```{c}
auto *renameDlg = new RenameFile(m_model, index, this);
```

#### AUTO 


```{c}
auto *t = (Transfer *) *it;
```

#### AUTO 


```{c}
auto *stopActionMenu = new KActionMenu(QIcon::fromTheme("media-playback-pause"), i18n("Pause"),
                                                    actionCollection());
```

#### AUTO 


```{c}
auto * notification = static_cast<KNotification*>(QObject::sender());
```

#### LAMBDA EXPRESSION 


```{c}
[](const KPluginMetaData& md) {
        return md.serviceTypes().contains(QStringLiteral("KGet/Plugin")) &&
            md.value(QStringLiteral("X-KDE-KGet-framework-version")) == QString::number(FrameworkVersion) &&
            md.value(QStringLiteral("X-KDE-KGet-rank")).toInt() > 0 &&
            md.value(QStringLiteral("X-KDE-KGet-plugintype")) == QStringLiteral("TransferFactory");
    }
```

#### AUTO 


```{c}
auto *syntaxBox = static_cast<KComboBox*>(editor);
```

#### AUTO 


```{c}
auto *numConnections = static_cast<QSpinBox*>(editor);
```

#### AUTO 


```{c}
auto *transfer = qobject_cast<TransferHandler*>(handler);
```

#### AUTO 


```{c}
auto * pluginSelector = new PluginSelector(this);
```

#### AUTO 


```{c}
auto *actionGroup = new QActionGroup(this);
```

#### AUTO 


```{c}
const auto mode = static_cast<ChecksumSearch::UrlChangeMode>(modes.at(i));
```

#### AUTO 


```{c}
auto *dataFactory = new DataSourceFactory(this,dest);
```

#### LAMBDA EXPRESSION 


```{c}
[](QSessionManager &sm) {
        sm.setRestartHint(QSessionManager::RestartNever);
    }
```

#### AUTO 


```{c}
const auto lang = static_cast<QLocale::Language>(l);
```

#### AUTO 


```{c}
auto *dataFactory = new DataSourceFactory(this, dest, fileSize, segSize);
```

#### AUTO 


```{c}
auto *contextMenu = new QMenu(this);
```

#### AUTO 


```{c}
auto *types = new KComboBox(parent);
```

#### AUTO 


```{c}
auto *layout = new QVBoxLayout;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &s : srcSplit)
        urls.append(QUrl(s));
```

#### AUTO 


```{c}
auto *line = static_cast<KLineEdit*>(editor);
```

#### AUTO 


```{c}
auto *layout = new QVBoxLayout(groupBox);
```

#### AUTO 


```{c}
auto * statJob = qobject_cast<KIO::StatJob *>(kioJob);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData& md : qAsConst(sortedOffers))
    {
        m_pluginList.prepend(md);
        if (!plugins.readEntry(md.pluginId() + QLatin1String("Enabled"), md.isEnabledByDefault()))
        {
            qCDebug(KGET_DEBUG) << "TransferFactory plugin (" << md.fileName()
                             << ") found, but not enabled";
            continue;
        }

        KGetPlugin* plugin = loadPlugin(md);
        if (plugin != nullptr)
        {
            const QString pluginName = md.name();

            pluginList.prepend(plugin);
            qCDebug(KGET_DEBUG) << "TransferFactory plugin (" << md.fileName()
                         << ") found and added to the list of available plugins";
        }
        else
        {
            qCDebug(KGET_DEBUG) << "Error loading TransferFactory plugin ("
                         << md.fileName() << ")";
        }
    }
```

#### AUTO 


```{c}
auto *item = new QStandardItem(file.name);
```

#### AUTO 


```{c}
auto *typesBox = new KComboBox(parent);
```

#### AUTO 


```{c}
auto *contextMenu = new QMenu();
```

#### AUTO 


```{c}
auto *countrySort = new QComboBox(parent);
```

#### AUTO 


```{c}
auto *transfer = static_cast<Transfer*>(job);
```

#### AUTO 


```{c}
auto *mainLayout = new QVBoxLayout;
```

#### AUTO 


```{c}
auto *searcher = new mirror();
```

#### AUTO 


```{c}
auto *childItem = static_cast<FileItem*>(index.internalPointer());
```

#### AUTO 


```{c}
auto *wrapper = new DBusVerifierWrapper(this);
```

#### AUTO 


```{c}
auto *layout = new QVBoxLayout();
```

#### AUTO 


```{c}
const auto *itemData = qobject_cast<const ItemMimeData*>(mdata);
```

#### AUTO 


```{c}
auto *action = new QAction(this);
```

#### AUTO 


```{c}
auto *webinterface = new DlgWebinterface(this);
```

#### AUTO 


```{c}
auto * mouseEvent = static_cast<QMouseEvent *>(event);
```

#### AUTO 


```{c}
const auto *model = static_cast <const QSortFilterProxyModel *>(index.model());
```

#### AUTO 


```{c}
auto *categorized_view = qobject_cast <TransferHistoryCategorizedView *> (m_view);
```

#### AUTO 


```{c}
auto *typeBox = static_cast<KComboBox*>(editor);
```

#### AUTO 


```{c}
auto * newGroup = new TransferGroup(m_transferTreeModel, m_scheduler);
```

#### AUTO 


```{c}
auto *bottomLayout = new QHBoxLayout;
```

#### AUTO 


```{c}
auto *dialog = new VerificationAddDlg(m_model, this);
```

#### AUTO 


```{c}
auto *advanced = new QWidget(this);
```

#### AUTO 


```{c}
auto *itemsModel  = qobject_cast<QStandardItemModel *>(m_proxyModel->sourceModel());
```

#### AUTO 


```{c}
auto *mimeData = new ItemMimeData();
```

#### AUTO 


```{c}
auto *hashTypes = static_cast<KComboBox*>(editor);
```

#### AUTO 


```{c}
auto *line = new KLineEdit(parent);
```

#### AUTO 


```{c}
auto *buttonBox = new QDialogButtonBox(this);
```

#### AUTO 


```{c}
auto *signat_download = new Download(m_signatureUrl, QUrl::fromLocalFile(path));
```

#### AUTO 


```{c}
auto disableSessionManagement = [](QSessionManager &sm) {
        sm.setRestartHint(QSessionManager::RestartNever);
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData& md : offers)
    {
        sortedOffers[md.value("X-KDE-KGet-rank").toInt()] = md;
        qCDebug(KGET_DEBUG) << " TransferFactory plugin found:" << endl <<
         "  rank = " << md.value("X-KDE-KGet-rank").toInt() << endl <<
         "  plugintype = " << md.value("X-KDE-KGet-plugintype") << endl;
    }
```

#### AUTO 


```{c}
auto *view_delegate = static_cast <TransfersViewDelegate *> (itemDelegate());
```

#### AUTO 


```{c}
auto *delegate = new ChecksumDelegate(m_modesModel, m_typesModel, this);
```

#### AUTO 


```{c}
const auto *model = static_cast <const QAbstractItemModel *> (m_selectedIndex.model());
```

#### AUTO 


```{c}
auto *hashTypes = new KComboBox(parent);
```

#### AUTO 


```{c}
auto *widget = new FileWidget(this);
```

#### AUTO 


```{c}
auto *mainWidget = new QWidget(this);
```

#### AUTO 


```{c}
auto *regExpAction = new QAction(i18n("Regular Expression"), this);
```

#### AUTO 


```{c}
auto *segment = new Segment(m_sourceUrl, segmentSize, segmentRange, this);
```

#### AUTO 


```{c}
auto * dialog = new PreferencesDialog( this, Settings::self() );
```

#### AUTO 


```{c}
auto *modesBox = static_cast<KComboBox*>(editor);
```

#### AUTO 


```{c}
auto *groupEditor = static_cast<GroupStatusEditor*>(editor);
```

#### AUTO 


```{c}
auto *delegate = new MirrorDelegate(m_countrySort, this);
```

#### AUTO 


```{c}
auto *item_delegate = new TransferHistoryItemDelegate(this);
```

#### AUTO 


```{c}
auto *wildcardAction = new QAction(i18n("Escape Sequences"), this);
```

#### AUTO 


```{c}
auto *countryModel = new CountryModel(this);
```

#### LAMBDA EXPRESSION 


```{c}
[](const KGetMetalink::Url &a, const KGetMetalink::Url &b) { return b < a; }
```

#### AUTO 


```{c}
auto *deleteJob = static_cast<KIO::DeleteJob*>(job);
```

#### AUTO 


```{c}
auto *startActionMenu = new KActionMenu(QIcon::fromTheme("media-playback-start"), i18n("Start"),
                                                     actionCollection());
```

#### LAMBDA EXPRESSION 


```{c}
[](const KPluginMetaData& md) {
        return md.value(QStringLiteral("X-KDE-KGet-framework-version")) == QString::number(FrameworkVersion) &&
            md.value(QStringLiteral("X-KDE-KGet-rank")).toInt() > 0 &&
            md.value(QStringLiteral("X-KDE-KGet-plugintype")) == QStringLiteral("TransferFactory");
    }
```

#### AUTO 


```{c}
auto *network = new QWidget(this);
```

#### AUTO 


```{c}
auto * buttonBox = new QDialogButtonBox(mainWidget);
```

#### AUTO 


```{c}
auto *search = new ChecksumSearch(urls, m_sourceUrl.fileName(), types);
```

#### AUTO 


```{c}
auto *range_view = qobject_cast <RangeTreeWidget *> (m_view);
```

#### AUTO 


```{c}
auto *widget = new QWidget(this);
```

#### AUTO 


```{c}
auto &listView = bt_listview;
```

#### AUTO 


```{c}
auto tempSize = static_cast<KIO::filesize_t>(m_tempData.size());
```

#### AUTO 


```{c}
auto *buttonBox = new QDialogButtonBox(QDialogButtonBox::Ok|QDialogButtonBox::Cancel);
```

#### AUTO 


```{c}
auto *item = new QStandardItem(url);
```

#### AUTO 


```{c}
const auto timeZone = QTimeZone(temp.toUtf8());
```

#### AUTO 


```{c}
auto* thread = qobject_cast<MmsThread*>(QObject::sender());
```

#### AUTO 


```{c}
auto *transfersViewDelegate = new TransfersViewDelegate(m_transfersView);
```

#### LAMBDA EXPRESSION 


```{c}
[](const QModelIndex &a, const QModelIndex &b) { return b < a; }
```

#### AUTO 


```{c}
auto *qroupStatusEditor = new GroupStatusEditor(index, parent);
```

#### AUTO 


```{c}
auto &iconView = bt_iconview;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &s : urls)
        qurls.append(QUrl(s));
```

#### AUTO 


```{c}
auto *groupEditor = static_cast<GroupStatusEditor *>(editor);
```

#### AUTO 


```{c}
auto *openAdvancedDetailsAction = new QAction(QIcon::fromTheme("document-open"), i18n("&Advanced Details"), this);
```

#### AUTO 


```{c}
auto *model = qobject_cast<QStandardItemModel *>(m_proxyModel->sourceModel());
```

#### AUTO 


```{c}
auto *type = static_cast<KComboBox*>(editor);
```

#### AUTO 


```{c}
auto *file = new DataSourceFactory(this);
```

#### AUTO 


```{c}
auto *view_delegate = static_cast<TransfersViewDelegate *>(itemDelegate());
```

#### AUTO 


```{c}
auto *dragDlg = new DragDlg(&m_tempResources, &m_tempCommonData, m_countrySort, m_languageSort, this);
```

#### AUTO 


```{c}
auto *layout = new QGridLayout(this);
```

#### AUTO 


```{c}
auto *item = static_cast<FileItem*>(file.internalPointer());
```

#### AUTO 


```{c}
auto *syntax = static_cast<KComboBox*>(editor);
```

#### AUTO 


```{c}
auto * bttransfer = qobject_cast<BTTransfer *>(transfer);
```

#### AUTO 


```{c}
auto *columnGroup = new QActionGroup(this);
```

#### AUTO 


```{c}
auto *item = new QStandardItem(m_tempFile.name);
```

#### AUTO 


```{c}
auto *layout = new QGridLayout();
```

#### AUTO 


```{c}
auto *groups = new TransfersGroupWidget(this);
```

#### AUTO 


```{c}
const auto *s_model  = static_cast <const QStandardItemModel *>(model->sourceModel());
```

#### AUTO 


```{c}
auto *quitAction = new QAction(this);
```

#### AUTO 


```{c}
auto *item = new QStandardItem(m_modes.value(mode));
```

#### AUTO 


```{c}
auto *popup = new QMenu(parent);
```

#### AUTO 


```{c}
auto *cat_view = qobject_cast <TransferHistoryCategorizedView *> (m_view);
```

#### AUTO 


```{c}
auto *typesBox = static_cast<KComboBox*>(editor);
```

#### AUTO 


```{c}
auto * transfer = static_cast<Transfer*>(job);
```

#### AUTO 


```{c}
auto* dict = dynamic_cast<BDictNode*>(n);
```

#### AUTO 


```{c}
auto *label = new QLabel(text, this);
```

#### AUTO 


```{c}
auto *integration = new IntegrationPreferences(this);
```

#### AUTO 


```{c}
auto* job = qobject_cast<KIO::Job*>(kjob);
```

#### AUTO 


```{c}
auto *menu = new KActionMenu(QIcon::fromTheme("kget"), i18n("Download Manager"), actionCollection());
```

#### AUTO 


```{c}
auto *item = static_cast<FileItem*>(index.internalPointer());
```

#### AUTO 


```{c}
auto *delegate = new RangeTreeWidgetItemDelegate(this);
```

#### AUTO 


```{c}
auto *transfer = new OrgKdeKgetTransferInterface("org.kde.kget", reply.value().first(), QDBusConnection::sessionBus(), this);
```

#### AUTO 


```{c}
auto * fac = new DataSourceFactory(this, m_dest);
```

#### AUTO 


```{c}
const auto idx = localeName.indexOf(QLatin1Char('_'));
```

#### AUTO 


```{c}
auto *factory = qobject_cast<DataSourceFactory*>(sender());
```

#### AUTO 


```{c}
auto *metalinkHttpChecker = new KGetMetalink::MetalinkHttpParser(srcUrl);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData& md : sortedOffers)
    {
        KPluginInfo info(md);
        info.load(plugins);
        m_pluginInfoList.prepend(info);

        if (!info.isPluginEnabled())
        {
            qCDebug(KGET_DEBUG) << "TransferFactory plugin (" << md.fileName()
                             << ") found, but not enabled";
            continue;
        }

        KGetPlugin* plugin = loadPlugin(md);
        if (plugin != nullptr)
        {
            const QString pluginName = info.name();

            pluginList.prepend(plugin);
            qCDebug(KGET_DEBUG) << "TransferFactory plugin (" << md.fileName()
                         << ") found and added to the list of available plugins";
        }
        else
        {
            qCDebug(KGET_DEBUG) << "Error loading TransferFactory plugin ("
                         << md.fileName() << ")";
        }
    }
```

#### AUTO 


```{c}
auto * t = (Transfer *) *it;
```

#### AUTO 


```{c}
auto *countrySort = static_cast<QComboBox*>(editor);
```

#### AUTO 


```{c}
auto *priority = new QSpinBox(parent);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData& md : sortedOffers)
    {
        KPluginInfo info(md);
        info.load(plugins);

        if (!info.isPluginEnabled())
        {
            qCDebug(KGET_DEBUG) << "TransferFactory plugin (" << md.fileName()
                             << ") found, but not enabled";
            continue;
        }

        KGetPlugin* plugin = loadPlugin(md);
        if (plugin != nullptr)
        {
            const QString pluginName = info.name();

            pluginList.prepend(plugin);
            m_pluginInfoList.prepend(info);
            qCDebug(KGET_DEBUG) << "TransferFactory plugin (" << md.fileName()
                         << ") found and added to the list of available plugins";
        }
        else
        {
            qCDebug(KGET_DEBUG) << "Error loading TransferFactory plugin ("
                         << md.fileName() << ")";
        }
    }
```

#### AUTO 


```{c}
auto *font = new QFontMetrics(QFontDatabase::systemFont(QFontDatabase::GeneralFont));
```

#### AUTO 


```{c}
auto* thread = new MmsThread(m_sourceUrl, m_fileName,
                                          iterator.value(), iterator.key());
```

#### AUTO 


```{c}
auto *dialog = new MirrorAddDlg(m_mirrorModel, m_countrySort, m_widget);
```

#### AUTO 


```{c}
auto *delegate = new AutoPasteDelegate(ui.type->model(), ui.patternSyntax->model(), this);
```

#### AUTO 


```{c}
auto *columnMapper = new QSignalMapper(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData& md : offers)
    {
        sortedOffers[md.value("X-KDE-KGet-rank").toInt()] = md;
        qCDebug(KGET_DEBUG) << " TransferFactory plugin found:\n"<<
         "  rank = " << md.value("X-KDE-KGet-rank").toInt() << '\n' <<
         "  plugintype = " << md.value("X-KDE-KGet-plugintype");
    }
```

#### AUTO 


```{c}
auto *transfer = new Commands(source, this);
```

#### AUTO 


```{c}
auto *syntaxes = new KComboBox(parent);
```

#### AUTO 


```{c}
auto *dialog = new VerificationAddDlg(m_verificationModel, this);
```

#### AUTO 


```{c}
auto * bttransfer = static_cast<BTTransferHandler *>(handler);
```

#### AUTO 


```{c}
auto *item = new MirrorItem;
```

#### AUTO 


```{c}
const auto status = static_cast<Job::Status>(data.toInt());
```

#### AUTO 


```{c}
auto *download = new Download(m_source, QUrl::fromLocalFile(m_tmpTorrentFile));
```

#### AUTO 


```{c}
auto *openScanDlg = new QAction(QIcon::fromTheme("document-open"), i18n("&Scan Files"), this);
```

#### AUTO 


```{c}
auto * wrapper = new DBusTransferWrapper(handler);
```

#### AUTO 


```{c}
auto * group = new TransferGroup(m_transferTreeModel, m_scheduler, groupName);
```

#### AUTO 


```{c}
auto * mouseEvent = dynamic_cast<QMouseEvent *>(event);
```

#### AUTO 


```{c}
auto *downloadFinishedActions = new KSelectAction(i18n("After downloads finished action"), this);
```

#### AUTO 


```{c}
auto *history = new TransferHistory();
```

#### AUTO 


```{c}
auto *appearance = new QWidget(this);
```

#### AUTO 


```{c}
auto * popup = new QMenu(parent);
```

#### AUTO 


```{c}
auto *numConnections = new QSpinBox(parent);
```

#### AUTO 


```{c}
auto *signature = new SignatureDlg(m_transfer, m_model->getUrl(index), this);
```

#### AUTO 


```{c}
auto *fileDlg = new FileDlg(file, currentNames, m_countrySort, m_languageSort, this, edit);
```

#### AUTO 


```{c}
auto *wrapper = new DBusKGetWrapper(kget);
```

#### AUTO 


```{c}
auto *link_view = new KGetLinkView(this);
```

#### AUTO 


```{c}
auto *titleWidget = new KTitleWidget(this);
```

#### AUTO 


```{c}
auto *dialog = new MirrorAddDlg(m_model, this);
```

#### AUTO 


```{c}
const auto country = static_cast<QLocale::Country>(c);
```

#### AUTO 


```{c}
auto *job = new TestJob(&scheduler, queue);
```

#### AUTO 


```{c}
auto *model = new QStandardItemModel(0, 5, this);
```

#### AUTO 


```{c}
auto * bttransfer = static_cast<BTTransferHandler *>(transfer);
```

#### AUTO 


```{c}
auto *action = static_cast<QAction*>(QObject::sender());
```

#### AUTO 


```{c}
auto *priority = static_cast<QSpinBox*>(editor);
```

#### AUTO 


```{c}
auto *groupEditor = static_cast<KLineEdit*>(editor);
```

#### AUTO 


```{c}
auto *dialog = new ChecksumSearchAddDlg(m_modesModel, m_typesModel, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData& md : qAsConst(sortedOffers))
    {
        KPluginInfo info(md);
        info.load(plugins);
        m_pluginInfoList.prepend(info);

        if (!info.isPluginEnabled())
        {
            qCDebug(KGET_DEBUG) << "TransferFactory plugin (" << md.fileName()
                             << ") found, but not enabled";
            continue;
        }

        KGetPlugin* plugin = loadPlugin(md);
        if (plugin != nullptr)
        {
            const QString pluginName = info.name();

            pluginList.prepend(plugin);
            qCDebug(KGET_DEBUG) << "TransferFactory plugin (" << md.fileName()
                         << ") found and added to the list of available plugins";
        }
        else
        {
            qCDebug(KGET_DEBUG) << "Error loading TransferFactory plugin ("
                         << md.fileName() << ")";
        }
    }
```

#### AUTO 


```{c}
auto *verification = new VerificationPreferences(this);
```

#### AUTO 


```{c}
auto *dialog = new MetalinkCreator(this);
```

#### AUTO 


```{c}
auto *groupBox = new QGroupBox(i18n("Transfer Details"));
```

#### AUTO 


```{c}
auto newState = static_cast<Qt::CheckState>(value.toInt());
```

