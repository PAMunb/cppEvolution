#### AUTO 


```{c}
const auto matchedBackends = configdialog->m_SourcePageURL->backend->findItems(backends["urlsource"], Qt::MatchFixedString);
```

