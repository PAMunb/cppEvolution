#### RANGE FOR STATEMENT 


```{c}
for (const QString &mimeStr : qAsConst(m_filterList)) {
            QMimeType mimeType = QMimeDatabase().mimeTypeForName(mimeStr);
            m_filterList.append(mimeType.name());

            QStringList fileSuffixes = mimeType.suffixes();

            if (fileSuffixes.size() > 0) {
                m_typeList << fileSuffixes.first();
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KSaneWidget::DeviceInfo &device : deviceList) {
        qCDebug(SKANLITE_LOG) << device.name;
    }
```

#### AUTO 


```{c}
const auto dpr = d->img->devicePixelRatio();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { m_ui->u_urlRequester->button()->click(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &s : settings) {
        int i = s.lastIndexOf(QLatin1Char('='));
        opts[s.left(i)] = s.right(s.length()-i-1);
    }
```

#### AUTO 


```{c}
auto *buttonsLayout = new QHBoxLayout;
```

#### AUTO 


```{c}
auto uploadJob = KIO::storedPut(&tmpFile, fileUrl, -1);
```

#### AUTO 


```{c}
static const auto selectionSettings = { QLatin1String("tl-x"), QLatin1String("tl-y"),
                                        QLatin1String("br-x"), QLatin1String("br-y") };
```

#### AUTO 


```{c}
const auto imageViewerActions = m_imageViewer->actions();
```

#### LAMBDA EXPRESSION 


```{c}
[this](){
        if (!m_pendingApplyScanOpts.isEmpty()) {
            applyScannerOptions(m_pendingApplyScanOpts);
        }
    }
```

#### AUTO 


```{c}
const auto dpr = devicePixelRatioF();
```

#### AUTO 


```{c}
auto *action
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &key : selectionSettings ) {
            if (opts.contains(key)) {
                reply.append(key + QLatin1Char('=') + opts[key]);
            }
        }
```

#### AUTO 


```{c}
auto *mainLayout = new QVBoxLayout;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &s : selectionSettings) {
        opts.remove(s);
    }
```

#### AUTO 


```{c}
const auto &key
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &mimeStr : qAsConst(m_filterList)) {
                QMimeType mimeType = QMimeDatabase().mimeTypeForName(mimeStr);
                namedMimeTypes.append(mimeType.name());

                m_settingsUi.imgFormat->addItem(mimeType.preferredSuffix(), mimeType.name());
                m_saveLocation->addImageFormat(mimeType.preferredSuffix(), mimeType.name());
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &s : selectionSettings) {
        if (opts.contains(s)) {
            return true;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *action : imageViewerActions) {
        auto *toolButton = new QToolButton;
        toolButton->setDefaultAction(action);
        buttonsLayout->addWidget(toolButton);
    }
```

#### AUTO 


```{c}
auto *toolButton = new QToolButton;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &ba : tmpList) {
            if (ba.isEmpty()) {
                continue;
            }
            m_filterList.append(QString::fromLatin1(ba));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &key : selectionSettings ) {
        if (opts.contains(key)) {
            reply.append(key + QLatin1Char('=') + opts[key]);
        }
    }
```

#### AUTO 


```{c}
auto *buttonBox = new QDialogButtonBox(QDialogButtonBox::Save | QDialogButtonBox::Discard);
```

#### AUTO 


```{c}
const auto &s
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &mimeStr : qAsConst(m_filterList)) {
                QMimeType mimeType = QMimeDatabase().mimeTypeForName(mimeStr);
                namedMimeTypes.append(mimeType.name());

                QStringList fileSuffixes = mimeType.suffixes();

                if (fileSuffixes.size() > 0) {
                    m_typeList << fileSuffixes.first();
                }
            }
```

#### AUTO 


```{c}
const auto &ba
```

