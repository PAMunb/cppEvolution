#### AUTO 


```{c}
const auto metaXml = directory->entry(QStringLiteral("meta.xml"));
```

#### AUTO 


```{c}
auto n = node.firstChildElement();
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        m_fileWidget->accept();

        // We have to do this manually for some reason
        accept();
    }
```

