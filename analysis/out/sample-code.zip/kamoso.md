#### LAMBDA EXPRESSION 


```{c}
[this](){ emitResult(); }
```

#### AUTO 


```{c}
const auto prevstate = m_pipeline->currentState();
```

#### AUTO 


```{c}
auto dev = m_deviceList.at(i);
```

#### AUTO 


```{c}
auto source = gst_element_factory_make("v4l2src", "v4l2src");
```

#### AUTO 


```{c}
auto st = gst_device_get_properties(device);
```

#### AUTO 


```{c}
auto st= gst_device_get_properties(device);
```

#### AUTO 


```{c}
auto source = gst_parse_bin_from_description(QByteArray("v4l2src device=") + device->path().toUtf8(), GST_PARSE_FLAG_FATAL_ERRORS, &error);
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString& arg: d->requiredArguments + d->optionalArguments) {
        if(!d->m_data.contains(arg))
            return false;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString& constraint: constraints) {
            static const QRegularExpression constraintRx("(\\w+):(.*)");
            Q_ASSERT(constraintRx.isValid());
            QRegularExpressionMatch match = constraintRx.match(constraint);
            if (!match.isValid() || !match.hasMatch()) {
                qWarning() << "wrong constraint" << constraint;
                continue;
            }
            QString propertyName = match.captured(1);
            QString constrainedValue = match.captured(2);
            bool acceptable = s_matchFunctions.value(propertyName, defaultMatch)(constrainedValue, m_inputData[propertyName]);
            if (!acceptable) {
//                 qDebug() << "not accepted" << meta.name() << propertyName << constrainedValue << constraint;
                return false;
            }
        }
```

#### AUTO 


```{c}
auto bin = QGst::Bin::fromDescription("videobalance name=video_balance ! gamma name=gamma ! videoflip method=4");
```

#### AUTO 


```{c}
const auto temp = m_webcamControl->stopRecording();
```

#### AUTO 


```{c}
auto sampleIcon = QIcon::fromTheme(QStringLiteral("kde"));
```

#### AUTO 


```{c}
const auto error = message.staticCast<QGst::ErrorMessage>();
```

#### LAMBDA EXPRESSION 


```{c}
[this](const KPluginMetaData& meta) {
        if(!meta.value("X-KamosoShare-PluginTypes").split(',').contains(m_pluginType)) {
//             qDebug() << "discarding" << meta.name() << meta.value("X-KamosoShare-PluginTypes");
            return false;
        }

        QStringList constraints = meta.value("X-KamosoShare-Constraints").split(',', QString::SkipEmptyParts);
        for(const QString& constraint: constraints) {
            static const QRegularExpression constraintRx("(\\w+):(.*)");
            Q_ASSERT(constraintRx.isValid());
            QRegularExpressionMatch match = constraintRx.match(constraint);
            if (!match.isValid() || !match.hasMatch()) {
                qWarning() << "wrong constraint" << constraint;
                continue;
            }
            QString propertyName = match.captured(1);
            QString constrainedValue = match.captured(2);
            bool acceptable = s_matchFunctions.value(propertyName, defaultMatch)(constrainedValue, m_inputData[propertyName]);
            if (!acceptable) {
//                 qDebug() << "not accepted" << meta.name() << propertyName << constrainedValue << constraint;
                return false;
            }
        }
        return true;
    }
```

#### AUTO 


```{c}
auto bin = QGst::Bin::fromDescription("videobalance name=video_balance ! gamma name=gamma");
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString& file: files) {
            QMimeType type = db.mimeTypeForFile(file);
            if (!common.isValid())
                common = type;
            else if(common.inherits(type.name())) {
                common = type;
            } else if(type.inherits(common.name())) {
                ;
            } else {
                common = db.mimeTypeForName("application/octet-stream");
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString& file: files) {
            const QUrl url = QUrl::fromUserInput(file);
            QMimeType type = db.mimeTypeForUrl(url);
            if (!common.isValid())
                common = type;
            else if(common.inherits(type.name())) {
                common = type;
            } else if(type.inherits(common.name())) {
                ;
            } else {
                common = db.mimeTypeForName("application/octet-stream");
            }
            urls += url.toString();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto device : qAsConst(m_deviceList)) {
        if (device->objectId() == d->objectId()) {
            delete d;
            return;
        }
    }
```

#### AUTO 


```{c}
auto objectId = objectIdFromProperties(st);
```

#### AUTO 


```{c}
auto udi = structureValue(st, "sysfs.path");
```

#### LAMBDA EXPRESSION 


```{c}
[this, job] {
            if (job->error() == 0) {
                return;
            }

            qWarning() << "Could not create" << Settings::saveVideos();
            Q_EMIT error(job->errorString());
        }
```

#### AUTO 


```{c}
auto caps = gst_caps_from_string("video/x-raw, framerate=(fraction){30/1, 15/1}, width=(int)640, height=(int)480, format=(string){YUY2}, pixel-aspect-ratio=(fraction)1/1, interlace-mode=(string)progressive");
```

#### AUTO 


```{c}
auto cameraSource = QGst::ElementFactory::make("wrappercamerabinsrc", "video_balance");
```

#### AUTO 


```{c}
auto x = gst_structure_get_value(device, key);
```

#### LAMBDA EXPRESSION 


```{c}
[this, temp, path, job] {
            if (job->error() == 0) {
                qDebug() << "video saved successfully";
                return;
            }

            qWarning() << "Could not move" << temp << "to" << path;
            Q_EMIT error(job->errorString());
        }
```

#### AUTO 


```{c}
auto dev = DeviceManager::self()->playingDevice();
```

#### AUTO 


```{c}
auto structure = gst_message_get_structure (message);
```

#### RANGE FOR STATEMENT 


```{c}
for(QJsonValue url: urls) {
                m_pendingJobs++;
                KIO::StoredTransferJob* job = KIO::storedGet(QUrl(url.toString()));
                connect(job, &KJob::finished, this, &ImgurShareJob::fileFetched);
            }
```

#### AUTO 


```{c}
auto source = QGst::Bin::fromDescription(QLatin1String("v4l2src device=") + device->path());
```

#### AUTO 


```{c}
const auto prevstate = pipelineCurrentState(m_pipeline);
```

#### RANGE FOR STATEMENT 


```{c}
for(const QMimeType& type: types) {
            QString supported = meta.value("X-KamosoShare-MimeType", "*");
            if ((supported.contains('*') && QRegExp(supported, Qt::CaseInsensitive, QRegExp::Wildcard).exactMatch(type.name())) || type.inherits(supported)) {
                return true;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString& arg: neededArguments()) {
        if(!d->m_data.contains(arg))
            return false;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString& mime: mimes) {
        types += db.mimeTypeForName(mime);
    }
```

#### AUTO 


```{c}
auto itype = G_TYPE_FROM_INSTANCE(d->surface.data()->d->videoSink);
```

#### LAMBDA EXPRESSION 


```{c}
[this](int act){ _uq_monitorReadyRead(act); }
```

#### LAMBDA EXPRESSION 


```{c}
[d](const KPluginMetaData& meta) {
        if(!meta.value("X-Purpose-PluginTypes").split(',').contains(d->m_pluginType)) {
//             qDebug() << "discarding" << meta.name() << meta.value("X-Purpose-PluginTypes");
            return false;
        }

        const QStringList constraints = meta.value("X-Purpose-Constraints").split(',', QString::SkipEmptyParts);
        for(const QString& constraint: constraints) {
            static const QRegularExpression constraintRx("(\\w+):(.*)");
            Q_ASSERT(constraintRx.isValid());
            QRegularExpressionMatch match = constraintRx.match(constraint);
            if (!match.isValid() || !match.hasMatch()) {
                qWarning() << "wrong constraint" << constraint;
                continue;
            }
            QString propertyName = match.captured(1);
            QString constrainedValue = match.captured(2);
            bool acceptable = s_matchFunctions.value(propertyName, defaultMatch)(constrainedValue, d->m_inputData[propertyName]);
            if (!acceptable) {
//                 qDebug() << "not accepted" << meta.name() << propertyName << constrainedValue << d->m_inputData[propertyName];
                return false;
            }
        }
        return true;
    }
```

#### AUTO 


```{c}
const auto ret = QString::fromUtf8(debug);
```

#### AUTO 


```{c}
auto bus = m_pipeline->bus();
```

#### AUTO 


```{c}
auto source = QGst::Bin::fromDescription(src);
```

#### AUTO 


```{c}
auto elem = gst_parse_bin_from_description(filters.toUtf8().constData(), true, &error);
```

#### AUTO 


```{c}
auto st(gst_device_get_properties(device));
```

#### LAMBDA EXPRESSION 


```{c}
[types](const KPluginMetaData& meta) {
        QRegularExpression rx();
        for(const QMimeType& type: types) {
            QString supported = meta.value("X-KamosoShare-MimeType", "*");
            if ((supported.contains('*') && QRegExp(supported, Qt::CaseInsensitive, QRegExp::Wildcard).exactMatch(type.name())) || type.inherits(supported)) {
                return true;
            }
        }
        return false;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto v : {r.x(), r.y(), r.width(), r.height()}) {
            g_value_init(&values[i], G_TYPE_QREAL);
            g_value_set_qreal(&values[i], v);
            i++;
        }
```

#### AUTO 


```{c}
auto v
```

#### AUTO 


```{c}
auto lastItem = gst_bin_get_by_name(GST_BIN(m_pipeline.data()), "last");
```

#### AUTO 


```{c}
auto d = new Device(device, this);
```

#### AUTO 


```{c}
auto udi = st.value("sysfs.path").toString();
```

#### AUTO 


```{c}
auto device
```

#### AUTO 


```{c}
const auto dirlist = dir.entryInfoList({"*.jpg"}, QDir::Files, QDir::SortFlag::Time);
```

#### LAMBDA EXPRESSION 


```{c}
[this](KIO::Job*, const QByteArray& data) { m_resultData += data; }
```

#### AUTO 


```{c}
auto lastItem = m_pipeline->getElementByName("last");
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString& constraint: constraints) {
            static const QRegularExpression constraintRx("(\\w+):(.*)");
            Q_ASSERT(constraintRx.isValid());
            QRegularExpressionMatch match = constraintRx.match(constraint);
            if (!match.isValid() || !match.hasMatch()) {
                qWarning() << "wrong constraint" << constraint;
                continue;
            }
            QString propertyName = match.captured(1);
            QString constrainedValue = match.captured(2);
            bool acceptable = s_matchFunctions.value(propertyName, defaultMatch)(constrainedValue, d->m_inputData[propertyName]);
            if (!acceptable) {
//                 qDebug() << "not accepted" << meta.name() << propertyName << constrainedValue << d->m_inputData[propertyName];
                return false;
            }
        }
```

#### AUTO 


```{c}
auto job = KIO::mkpath(Settings::saveVideos());
```

#### AUTO 


```{c}
const auto saveUrl = Settings::saveUrl();
```

#### AUTO 


```{c}
auto device = new Device(GST_DEVICE(devices->data), this);
```

#### AUTO 


```{c}
auto udi = udiFromProperties(st);
```

