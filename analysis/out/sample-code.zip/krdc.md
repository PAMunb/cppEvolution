#### RANGE FOR STATEMENT 


```{c}
for (RemoteViewFactory *factory : qAsConst(m_remoteViewFactories)) {
            m_protocolInput->addItem(factory->scheme());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &line : splittedOutput) {
        // full xfreerdp message: "transport_connect: getaddrinfo (Name or service not known)"
        if (line.contains(QLatin1String("Name or service not known"))) {
            connectionError(i18n("Name or service not known."),
                            i18n("Connection Failure"));
            return;

        // full xfreerdp message: "unable to connect to example.com:3389"
        } else if (line.contains(QLatin1String("unable to connect to"))) {
            connectionError(i18n("Connection attempt to host failed."),
                            i18n("Connection Failure"));
            return;

        } else if (line.contains(QLatin1String("Authentication failure, check credentials"))) {
            connectionError(i18n("Authentication failure, check credentials."),
                            i18n("Connection Failure"));
            return;

        // looks like some generic xfreerdp error message, handle it if nothing was handled:
        // "Error: protocol security negotiation failure"
        } else if (line.contains(QLatin1String("Error: protocol security negotiation failure")) || // xfreerdp 1.0
            line.contains(QLatin1String("Error: protocol security negotiation or connection failure"))) { // xfreerdp 1.2
            connectionError(i18n("Connection attempt to host failed. Security negotiation or connection failure."),
                            i18n("Connection Failure"));
            return;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &address : addresses) {
        KBookmark bm = manager->findByAddress(address);
        if (ignoreHistory && bm.parentGroup().metaDataItem(QLatin1String("krdc-history")) == QLatin1String("historyfolder")) {
            if (!updateTitle.isEmpty()) {
                qCDebug(KRDC) << "Update" << bm.fullText();
                bm.setFullText(updateTitle);
            }
        } else {
            if (!bm.isGroup()) { // please don't delete groups... happened in testing
                qCDebug(KRDC) << "Delete" << bm.fullText();
                bm.parentGroup().deleteBookmark(bm);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &plugin : offers) {

        KPluginInfo pluginInfo = KPluginInfo::fromMetaData(plugin);
        pluginInfo.load(conf);
        const bool enabled = pluginInfo.isPluginEnabled();

        if (enabled) {
            RemoteViewFactory *component = nullptr;

            KPluginLoader loader(plugin.fileName());
            KPluginFactory *factory = loader.factory();

            if (factory) {
                component = factory->create<RemoteViewFactory>();
            }

            if (component) {
                const int sorting = plugin.value(QStringLiteral("X-KDE-KRDC-Sorting")).toInt();
                m_remoteViewFactories.insert(sorting, component);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &address : addresses) {
        KBookmark bm = manager->findByAddress(address);
        if (ignoreHistory && bm.parentGroup().metaDataItem(QStringLiteral("krdc-history")) == QLatin1String("historyfolder")) {
            if (!updateTitle.isEmpty()) {
                qCDebug(KRDC) << "Update" << bm.fullText();
                bm.setFullText(updateTitle);
            }
        } else {
            if (!bm.isGroup()) { // please don't delete groups... happened in testing
                qCDebug(KRDC) << "Delete" << bm.fullText();
                bm.parentGroup().deleteBookmark(bm);
            }
        }
    }
```

#### AUTO 


```{c}
const auto dpr = m_frame.devicePixelRatio();
```

#### RANGE FOR STATEMENT 


```{c}
for (RemoteView *view : qAsConst(m_remoteViewMap)) {
                qCDebug(KRDC) << view->url();
                list.append(view->url().toDisplayString(QUrl::StripTrailingSlash));
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &plugin : offers) {
        const bool enabled = plugin.isEnabled(conf);

        if (enabled) {
            const auto result = KPluginFactory::instantiatePlugin<RemoteViewFactory>(plugin);

            if (result) {
                RemoteViewFactory *component = result.plugin;
                const int sorting = plugin.value(QStringLiteral("X-KDE-KRDC-Sorting")).toInt();
                m_remoteViewFactories.insert(sorting, component);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (RemoteView *view : qAsConst(m_remoteViewMap)) {
        saveHostPrefs(view);
    }
```

#### AUTO 


```{c}
auto it = m_remoteViewMap.constBegin(), end = m_remoteViewMap.constEnd();
```

#### RANGE FOR STATEMENT 


```{c}
for (RemoteViewFactory *factory : remoteViewFactories) {
            if (factory->supportsUrl(url)) {
                prefs = factory->createHostPreferences(m_hostPrefsConfig.group(urlString), this);
                if (prefs) {
                    qCDebug(KRDC) << "Found plugin to handle url (" << urlString << "): " << prefs->metaObject()->className();
                } else {
                    qCDebug(KRDC) << "Found plugin to handle url (" << urlString << "), but plugin does not provide preferences";
                }
            }
        }
```

#### AUTO 


```{c}
const auto result = KPluginFactory::instantiatePlugin<RemoteViewFactory>(plugin);
```

#### LAMBDA EXPRESSION 


```{c}
[this](QCursor cursor){ setCursor(cursor); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &address : addresses) {
        KBookmark bm = manager->findByAddress(address);
        bm.setFullText(title);
        qCDebug(KRDC) << "Update" << bm.fullText();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (RemoteView *view : currentViews) {
            view->startQuitting();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (RemoteView *currentView : qAsConst(m_remoteViewMap)) {
            currentView->enableScaling(currentView->hostPreferences()->fullscreenScale());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &plugin : offers) {
        const bool enabled = plugin.isEnabled(conf);

        if (enabled) {
            const auto result = KPluginFactory::instantiatePlugin<RemoteViewFactory>(plugin);

            if (result) {
                RemoteViewFactory *component = result.plugin;
                const int sorting = plugin.value(QStringLiteral("X-KDE-KRDC-Sorting"), 0);
                m_remoteViewFactories.insert(sorting, component);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QListWidgetItem *selectedItem : selectedItems) {
        qCDebug(KRDC) << "Remove host: " <<  selectedItem->text();

        m_hostPrefsConfig.deleteGroup(selectedItem->text());
        delete(selectedItem);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (RemoteViewFactory *factory : qAsConst(m_remoteViewFactories)) {
        if (factory->supportsUrl(url)) {
            view = factory->createView(this, url, configGroup);
            qCDebug(KRDC) << "Found plugin to handle url (" << url.url() << "): " << view->metaObject()->className();
            break;
        }
    }
```

#### AUTO 


```{c}
const auto dpr = devicePixelRatioF();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &fileName : fileNames) {
                targetFilePath = targetBasePath + fileName;
                if (!QFile::exists(targetFilePath)) {
                    QFile::copy(sourceBasePath + fileName, targetFilePath);
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (RemoteView *view : qAsConst(m_remoteViewMap)) {
        view->updateConfiguration();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QListWidgetItem *selectedItem : selectedItems) {
        const QString urlString = selectedItem->text();
        const QUrl url = QUrl(urlString);

        qCDebug(KRDC) << "Configure host: " << urlString;

        HostPreferences* prefs = nullptr;

        const QList<RemoteViewFactory *> remoteViewFactories(m_mainWindow->remoteViewFactoriesList());
        for (RemoteViewFactory *factory : remoteViewFactories) {
            if (factory->supportsUrl(url)) {
                prefs = factory->createHostPreferences(m_hostPrefsConfig.group(urlString), this);
                if (prefs) {
                    qCDebug(KRDC) << "Found plugin to handle url (" << urlString << "): " << prefs->metaObject()->className();
                } else {
                    qCDebug(KRDC) << "Found plugin to handle url (" << urlString << "), but plugin does not provide preferences";
                }
            }
        }

        if (prefs) {
            prefs->showDialog(this);
            delete prefs;
        } else {
            KMessageBox::error(this,
                               i18n("The selected host cannot be handled."),
                               i18n("Unusable URL"));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (RemoteViewFactory *factory : qAsConst(m_remoteViewFactories)) {
        if (factory->supportsUrl(QUrl(url))) {
            prefs = factory->createHostPreferences(Settings::self()->config()->group(QStringLiteral("hostpreferences")).group(url), this);
            if (prefs) {
                qCDebug(KRDC) << "Found plugin to handle url (" << url << "): " << prefs->metaObject()->className();
            } else {
                qCDebug(KRDC) << "Found plugin to handle url (" << url << "), but plugin does not provide preferences";
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (RemoteView * view : qAsConst(m_remoteViewMap)) {
            view->enableScaling(view->hostPreferences()->windowedScale());
        }
```

