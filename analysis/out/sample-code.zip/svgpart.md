#### AUTO 


```{c}
auto mime = QMimeDatabase().mimeTypeForName(mimeType);
```

#### AUTO 


```{c}
const auto success = KParts::ReadOnlyPart::openUrl(url);
```

#### AUTO 


```{c}
const auto currentUrl = url();
```

