#### RANGE FOR STATEMENT 


```{c}
for (const auto &address : std::as_const(addresses)) {
                KBookmark bk = bookmarkManager()->findByAddress(QString::fromLatin1(address));
                qCDebug(KEDITBOOKMARKS_LOG) << "Extracted bookmark:" << bk.address();
                bookmarks.prepend(bk); // reverse order, so that we don't invalidate addresses (#287038)
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &it : indexes) {
        if (it.column() == NameColumnId) {
            bookmarks.push_back(bookmarkForIndex(it));
            if (!addresses.isEmpty()) {
                addresses.append(';');
            }
            addresses.append(bookmarkForIndex(it).address().toLatin1());
            qCDebug(KEDITBOOKMARKS_LOG) << "appended" << bookmarkForIndex(it).address();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KBookmark &bk : items) {
        new CreateCommand(model, bkInsertAddr, KBookmark(bk.internalElement().cloneNode(true).toElement()), bk.text(), mcmd);
        bkInsertAddr = KBookmark::nextAddress(bkInsertAddr);
    }
```

#### AUTO 


```{c}
const auto &it
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &bm : bookmarks) {
        if (bm.isGroup() || bm.isSeparator()) {
            continue;
        }

        auto *job = new KIO::OpenUrlJob(bm.url());
        job->setUiDelegate(new KIO::JobUiDelegate(KJobUiDelegate::AutoHandlingEnabled, KEBApp::self()));
        job->start();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &groupAddress, const QString &caller) {
        d->_kd_slotBookmarksChanged(groupAddress, caller);
    }
```

#### AUTO 


```{c}
const auto &address
```

#### RANGE FOR STATEMENT 


```{c}
for (BookmarkIterator* iterator : iterList) {
        iterator->cancel();
    }
```

#### AUTO 


```{c}
auto *job = new KIO::OpenUrlJob(bm.url());
```

#### AUTO 


```{c}
const auto bookmarks = KBookmark::List::fromMimeData(data, doc);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KBookmark &bk : items) {
        new CreateCommand(model, bkInsertAddr,
                          KBookmark(bk.internalElement().cloneNode(true).toElement()),
                          bk.text(), mcmd);
        bkInsertAddr = KBookmark::nextAddress(bkInsertAddr);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KBookmark &bk : items) {
        addresses.append(bk.address());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &address : qAsConst(addresses)) {
        new DeleteCommand(model, address, false, mcmd);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &address : qAsConst(addresses)) {
                KBookmark bk = bookmarkManager()->findByAddress(QString::fromLatin1(address));
                qCDebug(KEDITBOOKMARKS_LOG) << "Extracted bookmark:" << bk.address();
                bookmarks.prepend(bk); // reverse order, so that we don't invalidate addresses (#287038)
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KBookmark &bk : bookmarks) {
        new CreateCommand(model, currentAddress, bk, QString(), mcmd);
        currentAddress = KBookmark::nextAddress(currentAddress);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (BookmarkIterator *iterator : iterList) {
        iterator->cancel();
    }
```

#### AUTO 


```{c}
auto &bm
```

#### AUTO 


```{c}
const auto iterList = m_iterators;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &address : std::as_const(addresses)) {
        new DeleteCommand(model, address, false, mcmd);
    }
```

