#### AUTO 


```{c}
auto hasIdentifier = [&](KontactInterface::Plugin *plugin) {
        return plugin->identifier() == pluginName;
    };
```

#### AUTO 


```{c}
auto progressStatusBarWidget = new KPIM::ProgressStatusBarWidget(statusBar(), this);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { Q_EMIT changed(true); }
```

#### AUTO 


```{c}
auto item = new KPageWidgetItem(page, name);
```

#### AUTO 


```{c}
auto plugin = static_cast<KontactInterface::Plugin *>(sourceIndex.internalPointer());
```

#### RANGE FOR STATEMENT 


```{c}
for (const KService::Ptr &service : offers) {
        // skip summary only plugins
        QVariant var = service->property(QStringLiteral("X-KDE-KontactPluginHasPart"));
        if (var.isValid() && var.toBool() == false) {
            continue;
        }
        mPluginCombo->addItem(service->name());
        mPluginList.append(service);

        // skip disabled plugins
        const QString pluginName = service->property(QStringLiteral("X-KDE-PluginInfo-Name")).toString();
        if (!grp.readEntry(pluginName + QStringLiteral("Enabled"), false)) {
            const QStandardItemModel *qsm = qobject_cast<QStandardItemModel *>(mPluginCombo->model());
            if (qsm) {
                qsm->item(mPluginCombo->count() - 1, 0)->setEnabled(false);
            }
        }
        if (service->property(QStringLiteral("X-KDE-PluginInfo-Name")).toString() == Prefs::self()->activePlugin()) {
            activeComponent = mPluginList.count() - 1;
        }
    }
```

#### AUTO 


```{c}
const auto &pair
```

#### AUTO 


```{c}
auto *plugin
            = static_cast<KontactInterface::Plugin *>(sourceIndex.internalPointer());
```

#### AUTO 


```{c}
auto mainWindow = new MainWindow();
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &pluginMetaData : std::as_const(mPluginMetaData)) {
        if (!configGroup.readEntry(pluginMetaData.pluginId() + QLatin1String("Enabled"), pluginMetaData.isEnabledByDefault())) {
            continue;
        }

        KontactInterface::Plugin *plugin = pluginFromName(pluginMetaData.pluginId());
        if (plugin) { // already loaded
            plugin->configUpdated();
            continue;
        }

        qCDebug(KONTACT_LOG) << "Loading Plugin:" << pluginMetaData.name();
        const auto loadResult = KPluginFactory::instantiatePlugin<KontactInterface::Plugin>(pluginMetaData, this);
        if (!loadResult) {
            qCWarning(KONTACT_LOG) << "Error loading plugin" << pluginMetaData.fileName() << loadResult.errorString;
            continue;
        } else {
            plugin = loadResult.plugin;
            if (!plugin) {
                qCWarning(KONTACT_LOG) << "Unable to create plugin for" << pluginMetaData.fileName();
                continue;
            }
        }
        plugin->setIdentifier(pluginMetaData.pluginId());
        plugin->setTitle(pluginMetaData.name());
        plugin->setIcon(pluginMetaData.iconName());

        const QString libNameProp = pluginMetaData.value(QStringLiteral("X-KDE-KontactPartLibraryName"));
        const QString exeNameProp = pluginMetaData.value(QStringLiteral("X-KDE-KontactPartExecutableName"));

        if (pluginMetaData.rawData().contains(QLatin1String("X-KDE-KontactPartLoadOnStart"))) {
            const bool loadOnStart = pluginMetaData.rawData().value(QStringLiteral("X-KDE-KontactPartLoadOnStart")).toBool();
            if (loadOnStart) {
                mDelayedPreload.append(plugin);
            }
        }
        if (pluginMetaData.rawData().contains(QLatin1String("X-KDE-KontactPluginHasPart"))) {
            const bool hasPartProp = pluginMetaData.rawData().value(QStringLiteral("X-KDE-KontactPluginHasPart")).toBool();
            plugin->setShowInSideBar(hasPartProp);
        } else {
            plugin->setShowInSideBar(true);
        }

        qCDebug(KONTACT_LOG) << "LIBNAMEPART:" << libNameProp;

        plugin->setPartLibraryName(libNameProp.toUtf8());
        plugin->setExecutableName(exeNameProp);
        plugins.append(plugin);
    }
```

#### AUTO 


```{c}
auto label = new QLabel(text, topFrame);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &pluginMetaData : std::as_const(mPluginMetaData)) {
        if (!configGroup.readEntry(pluginMetaData.pluginId() + QLatin1String("Enabled"), pluginMetaData.isEnabledByDefault())) {
            removePlugin(pluginMetaData.pluginId());
        }
    }
```

#### AUTO 


```{c}
auto iconLabel = new QLabel(page);
```

#### AUTO 


```{c}
const auto it = std::find_if(mPlugins.begin(), mPlugins.end(), hasIdentifier);
```

#### AUTO 


```{c}
auto pageItem = new KPageWidgetItem(topFrame, title);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        Q_EMIT changed(true);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const KPluginMetaData &data) {
        return data.rawData().value(QStringLiteral("X-KDE-KontactPluginVersion")).toInt() == KONTACT_PLUGIN_VERSION;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginInfo &pluginInfo : std::as_const(mPluginInfos)) {
        if (pluginInfo.isPluginEnabled()) {
            KontactInterface::Plugin *plugin = pluginFromName(pluginInfo.pluginName());
            if (plugin) {
                activePlugins.append(plugin->identifier());
                plugin->saveProperties(config);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &pluginMetaData : std::as_const(mPluginMetaData)) {
        if (!configGroup.readEntry(pluginMetaData.pluginId() + QLatin1String("Enabled"), pluginMetaData.isEnabledByDefault())) {
            continue;
        }

        KontactInterface::Plugin *plugin = pluginFromName(pluginMetaData.pluginId());
        if (plugin) { // already loaded
            plugin->configUpdated();
            continue;
        }

        qCDebug(KONTACT_LOG) << "Loading Plugin:" << pluginMetaData.name();
#if KCOREADDONS_VERSION < QT_VERSION_CHECK(5, 86, 0)
        KPluginLoader loader(pluginMetaData.fileName());
        KPluginFactory *factory = loader.factory();
        if (!factory) {
            qCWarning(KONTACT_LOG) << "Error loading plugin" << pluginMetaData.fileName() << loader.errorString();
            continue;
        } else {
            plugin = factory->create<KontactInterface::Plugin>(this);
            if (!plugin) {
                qCWarning(KONTACT_LOG) << "Unable to create plugin for" << pluginMetaData.fileName();
                continue;
            }
        }
#else
        const auto loadResult = KPluginFactory::instantiatePlugin<KontactInterface::Plugin>(pluginMetaData, this);
        if (!loadResult) {
            qCWarning(KONTACT_LOG) << "Error loading plugin" << pluginMetaData.fileName() << loadResult.errorString;
            continue;
        } else {
            plugin = loadResult.plugin;
            if (!plugin) {
                qCWarning(KONTACT_LOG) << "Unable to create plugin for" << pluginMetaData.fileName();
                continue;
            }
        }
#endif
        plugin->setIdentifier(pluginMetaData.fileName());
        plugin->setTitle(pluginMetaData.name());
        plugin->setIcon(pluginMetaData.iconName());

        const QString libNameProp = pluginMetaData.value(QStringLiteral("X-KDE-KontactPartLibraryName"));
        const QString exeNameProp = pluginMetaData.value(QStringLiteral("X-KDE-KontactPartExecutableName"));

        if (pluginMetaData.rawData().contains(QLatin1String("X-KDE-KontactPartLoadOnStart"))) {
            bool loadOnStart = pluginMetaData.rawData().value(QStringLiteral("X-KDE-KontactPartLoadOnStart")).toBool();
            if (loadOnStart) {
                mDelayedPreload.append(plugin);
            }
        }
        if (pluginMetaData.rawData().contains(QLatin1String("X-KDE-KontactPluginHasPart"))) {
            const bool hasPartProp = pluginMetaData.rawData().value(QStringLiteral("X-KDE-KontactPluginHasPart")).toBool();
            plugin->setShowInSideBar(hasPartProp);
        } else {
            plugin->setShowInSideBar(true);
        }

        qCDebug(KONTACT_LOG) << "LIBNAMEPART:" << libNameProp;

        plugin->setPartLibraryName(libNameProp.toUtf8());
        plugin->setExecutableName(exeNameProp);
        plugins.append(plugin);
    }
```

#### AUTO 


```{c}
auto *layout = new QVBoxLayout;
```

#### LAMBDA EXPRESSION 


```{c}
[](const KPluginMetaData &m1, const KPluginMetaData &m2) {
            return m1.rawData().value(QStringLiteral("X-KDE-Weight")).toInt() < m2.rawData().value(QStringLiteral("X-KDE-Weight")).toInt();
        }
```

#### AUTO 


```{c}
auto showSideBarCheckbox = new QCheckBox(Prefs::self()->sideBarOpenItem()->label(), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KAboutLicense &license : lstLicenses) {
        licenseStr += QStringLiteral("<pre>%1</pre>").arg(license.text());
    }
```

#### AUTO 


```{c}
auto *viewMode = new QActionGroup(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (KontactInterface::Plugin *plugin : plugins_) {
        if (plugin->showInSideBar()) {
            pluginsToShow << plugin;
        }
    }
```

#### AUTO 


```{c}
auto iconSize = new QActionGroup(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &plugin : pluginMetaDatas) {
        // skip summary only plugins
        if (plugin.rawData().contains(QLatin1String("X-KDE-KontactPluginHasPart"))) {
            bool var = plugin.rawData().value(QStringLiteral("X-KDE-KontactPluginHasPart")).toBool();

            if (!var) {
                continue;
            }
        }

        mPluginCombo->addItem(plugin.name());
        mPluginList.append(plugin);

        // skip disabled plugins
        const QString pluginName = plugin.pluginId();
        if (!grp.readEntry(pluginName + QStringLiteral("Enabled"), false)) {
            const QStandardItemModel *qsm = qobject_cast<QStandardItemModel *>(mPluginCombo->model());
            if (qsm) {
                qsm->item(mPluginCombo->count() - 1, 0)->setEnabled(false);
            }
        }
        if (pluginName == Prefs::self()->activePlugin()) {
            activeComponent = mPluginList.count() - 1;
        }
    }
```

#### AUTO 


```{c}
auto *job = new KIO::OpenUrlJob(url);
```

#### AUTO 


```{c}
auto *pageEngine = new IntroductionWebEnginePage(this);
```

#### AUTO 


```{c}
auto *mainWindow = new MainWindow();
```

#### RANGE FOR STATEMENT 


```{c}
for (KontactInterface::Plugin *plugin : std::as_const(mDelayedPreload)) {
        selectPlugin(plugin);
    }
```

#### AUTO 


```{c}
auto page = new QWidget(q);
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *qaction : qAsConst(mActionPlugins)) {
        QAction *action = static_cast<QAction *>(qaction);
        QString shortcut = QStringLiteral("Ctrl+%1").arg(mActionPlugins.count() - i);
        actionCollection()->setDefaultShortcut(action, QKeySequence(shortcut));
        ++i;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KontactInterface::Plugin *plugin : std::as_const(mPlugins)) {
            if (!plugin->isRunningStandalone() && activePlugins.contains(plugin->identifier())) {
                plugin->readProperties(config);
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](const KPluginMetaData &data) {
            return data.rawData().value(QStringLiteral("X-KDE-KontactPluginVersion")).toInt() == KONTACT_PLUGIN_VERSION;
            }
```

#### AUTO 


```{c}
auto *introboxHBoxLayout = new QHBoxLayout(introbox);
```

#### AUTO 


```{c}
auto textBrowser = new QTextBrowser(topFrame);
```

#### AUTO 


```{c}
auto item = new KPageWidgetItem(moduleScroll, metaData.name());
```

#### LAMBDA EXPRESSION 


```{c}
[](const QByteArray &componentName) {
        KSharedConfig::Ptr config = KSharedConfig::openConfig(QString::fromLatin1(componentName) + QLatin1String("rc"));
        config->reparseConfiguration();
    }
```

#### AUTO 


```{c}
auto leftPlugin = static_cast<KontactInterface::Plugin *>(left.internalPointer());
```

#### AUTO 


```{c}
auto *sep2 = new QAction(this);
```

#### AUTO 


```{c}
auto job = new KIO::CommandLauncherJob(QStringLiteral("accountwizard"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &metaData : std::as_const(mPluginMetaData)) {
            const QString pluginNamespace = metaData.value(QStringLiteral("X-KDE-ConfigModuleNamespace"));
            if (!pluginNamespace.isEmpty()) {
                auto plugins = KPluginMetaData::findPlugins(pluginNamespace);
                std::sort(plugins.begin(), plugins.end(), sortByWeight);
                dlg->addPluginComponent(metaData, plugins);
            }
        }
```

#### AUTO 


```{c}
auto hasIdentifier = [&](KontactInterface::Plugin * plugin) {
        return plugin->identifier() == identifier;
    };
```

#### AUTO 


```{c}
auto topFrame = new QFrame();
```

#### LAMBDA EXPRESSION 


```{c}
[&](KontactInterface::Plugin *plugin) {
        return plugin->identifier() == identifier;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const CreatedModule &module : std::as_const(modules)) {
        KCModuleProxy *proxy = module.kcm;

#if KCMUTILS_VERSION > QT_VERSION_CHECK(5, 86, 0)
        if (proxy->isChanged()) {
#else
        if (proxy->changed()) {
#endif
            proxy->save();
            /**
             * Add name of the components the kcm belongs to the list
             * of updated components.
             */
            const QStringList componentNames = module.componentNames;
            for (const QString &componentName : componentNames) {
                if (!updatedComponents.contains(componentName)) {
                    updatedComponents.append(componentName);
                }
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &name : std::as_const(updatedComponents)) {
        Q_EMIT q->configCommitted(name.toLatin1());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KPluginInfo &pluginInfo : mPluginInfos) {
        pluginInfo.setConfig(configGroup);
        pluginInfo.load();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginInfo &pluginInfo : qAsConst(mPluginInfos)) {
        if (!pluginInfo.isPluginEnabled()) {
            continue;
        }

        const QString pluginPath = pluginInfo.pluginName();
        KontactInterface::Plugin *plugin = pluginFromName(pluginPath);
        if (plugin) { // already loaded
            plugin->configUpdated();
            continue;
        }

        qCDebug(KONTACT_LOG) << "Loading Plugin:" << pluginInfo.name();
        KPluginLoader loader(pluginInfo.libraryPath());
        KPluginFactory *factory = loader.factory();
        if (!factory) {
            qWarning() << "Error loading plugin" << pluginInfo.libraryPath() << loader.errorString();
            continue;
        } else {
            plugin = factory->create<KontactInterface::Plugin>(this);
            if (!plugin) {
                qCWarning(KONTACT_LOG) << "Unable to create plugin for" << pluginInfo.libraryPath();
                continue;
            }
        }

        plugin->setIdentifier(pluginInfo.pluginName());
        plugin->setTitle(pluginInfo.name());
        plugin->setIcon(pluginInfo.icon());

        const QVariant libNameProp = pluginInfo.property(QStringLiteral("X-KDE-KontactPartLibraryName"));
        const QVariant exeNameProp = pluginInfo.property(QStringLiteral("X-KDE-KontactPartExecutableName"));
        const QVariant loadOnStart = pluginInfo.property(QStringLiteral("X-KDE-KontactPartLoadOnStart"));
        const QVariant hasPartProp = pluginInfo.property(QStringLiteral("X-KDE-KontactPluginHasPart"));

        if (!loadOnStart.isNull() && loadOnStart.toBool()) {
            mDelayedPreload.append(plugin);
        }

        qCDebug(KONTACT_LOG) << "LIBNAMEPART:" << libNameProp.toString();

        plugin->setPartLibraryName(libNameProp.toString().toUtf8());
        plugin->setExecutableName(exeNameProp.toString());
        if (hasPartProp.isValid()) {
            plugin->setShowInSideBar(hasPartProp.toBool());
        }
        plugins.append(plugin);
    }
```

#### AUTO 


```{c}
auto *sep = new QAction(this);
```

#### AUTO 


```{c}
auto *progressStatusBarWidget = new KPIM::ProgressStatusBarWidget(statusBar(), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &pluginMetaData : std::as_const(mPluginMetaData)) {
        if (!configGroup.readEntry(pluginMetaData.pluginId() + QLatin1String("Enabled"), pluginMetaData.isEnabledByDefault())) {
            continue;
        }

        KontactInterface::Plugin *plugin = pluginFromName(pluginMetaData.pluginId());
        if (plugin) { // already loaded
            plugin->configUpdated();
            continue;
        }

        qCDebug(KONTACT_LOG) << "Loading Plugin:" << pluginMetaData.name();
        const auto loadResult = KPluginFactory::instantiatePlugin<KontactInterface::Plugin>(pluginMetaData, this);
        if (!loadResult) {
            qCWarning(KONTACT_LOG) << "Error loading plugin" << pluginMetaData.fileName() << loadResult.errorString;
            continue;
        } else {
            plugin = loadResult.plugin;
            if (!plugin) {
                qCWarning(KONTACT_LOG) << "Unable to create plugin for" << pluginMetaData.fileName();
                continue;
            }
        }
        plugin->setIdentifier(pluginMetaData.fileName());
        plugin->setTitle(pluginMetaData.name());
        plugin->setIcon(pluginMetaData.iconName());

        const QString libNameProp = pluginMetaData.value(QStringLiteral("X-KDE-KontactPartLibraryName"));
        const QString exeNameProp = pluginMetaData.value(QStringLiteral("X-KDE-KontactPartExecutableName"));

        if (pluginMetaData.rawData().contains(QLatin1String("X-KDE-KontactPartLoadOnStart"))) {
            bool loadOnStart = pluginMetaData.rawData().value(QStringLiteral("X-KDE-KontactPartLoadOnStart")).toBool();
            if (loadOnStart) {
                mDelayedPreload.append(plugin);
            }
        }
        if (pluginMetaData.rawData().contains(QLatin1String("X-KDE-KontactPluginHasPart"))) {
            const bool hasPartProp = pluginMetaData.rawData().value(QStringLiteral("X-KDE-KontactPluginHasPart")).toBool();
            plugin->setShowInSideBar(hasPartProp);
        } else {
            plugin->setShowInSideBar(true);
        }

        qCDebug(KONTACT_LOG) << "LIBNAMEPART:" << libNameProp;

        plugin->setPartLibraryName(libNameProp.toUtf8());
        plugin->setExecutableName(exeNameProp);
        plugins.append(plugin);
    }
```

#### AUTO 


```{c}
auto rightPlugin = static_cast<KontactInterface::Plugin *>(right.internalPointer());
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginInfo &pluginInfo : qAsConst(mPluginInfos)) {
        if (pluginInfo.isPluginEnabled()) {
            KontactInterface::Plugin *plugin = pluginFromInfo(pluginInfo);
            if (plugin) {
                activePlugins.append(plugin->identifier());
                plugin->saveProperties(config);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginInfo &pluginInfo : qAsConst(mPluginInfos)) {
        if (!pluginInfo.isPluginEnabled()) {
            removePlugin(pluginInfo.pluginName());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginInfo &pluginInfo : qAsConst(mPluginInfos)) {
        if (!pluginInfo.isPluginEnabled()) {
            continue;
        }

        const QString pluginPath = pluginInfo.libraryPath();
        KontactInterface::Plugin *plugin = pluginFromName(pluginPath);
        if (plugin) { // already loaded
            plugin->configUpdated();
            continue;
        }

        qCDebug(KONTACT_LOG) << "Loading Plugin:" << pluginInfo.name();
        KPluginLoader loader(pluginInfo.libraryPath());
        KPluginFactory* factory = loader.factory();
        if (!factory) {
            qWarning() << "Error loading plugin" << pluginInfo.libraryPath() << loader.errorString();
            continue;
        } else {
            plugin = factory->create<KontactInterface::Plugin>(this);
            if (!plugin) {
                qCWarning(KONTACT_LOG) << "Unable to create plugin for" << pluginInfo.libraryPath();
                continue;
            }
        }

        plugin->setIdentifier(pluginInfo.pluginName());
        plugin->setTitle(pluginInfo.name());
        plugin->setIcon(pluginInfo.icon());

        QVariant libNameProp = pluginInfo.property(QStringLiteral("X-KDE-KontactPartLibraryName"));
        QVariant exeNameProp = pluginInfo.property(QStringLiteral("X-KDE-KontactPartExecutableName"));
        QVariant loadOnStart = pluginInfo.property(QStringLiteral("X-KDE-KontactPartLoadOnStart"));
        QVariant hasPartProp = pluginInfo.property(QStringLiteral("X-KDE-KontactPluginHasPart"));

        if (!loadOnStart.isNull() && loadOnStart.toBool()) {
            mDelayedPreload.append(plugin);
        }

        qCDebug(KONTACT_LOG) << "LIBNAMEPART:" << libNameProp.toString();

        plugin->setPartLibraryName(libNameProp.toString().toUtf8());
        plugin->setExecutableName(exeNameProp.toString());
        if (hasPartProp.isValid()) {
            plugin->setShowInSideBar(hasPartProp.toBool());
        }
        plugins.append(plugin);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &pluginMetaData : std::as_const(mPluginMetaData)) {
        if (!configGroup.readEntry(pluginMetaData.pluginId() + QLatin1String("Enabled"), pluginMetaData.isEnabledByDefault())) {
            KontactInterface::Plugin *plugin = pluginFromName(pluginMetaData.pluginId());
            if (plugin) {
                activePlugins.append(plugin->identifier());
                plugin->saveProperties(config);
            }
        }
    }
```

#### AUTO 


```{c}
auto *topLayout = new QFormLayout(this);
```

#### AUTO 


```{c}
auto kcm = new KCModuleProxy(metaData, moduleScroll, QStringList());
```

#### AUTO 


```{c}
auto sep2 = new QAction(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginInfo &pluginInfo : std::as_const(mPluginInfos)) {
        if (!pluginInfo.isPluginEnabled()) {
            continue;
        }

        const QString pluginPath = pluginInfo.pluginName();
        KontactInterface::Plugin *plugin = pluginFromName(pluginPath);
        if (plugin) { // already loaded
            plugin->configUpdated();
            continue;
        }

        qCDebug(KONTACT_LOG) << "Loading Plugin:" << pluginInfo.name();
        KPluginLoader loader(pluginInfo.libraryPath());
        KPluginFactory *factory = loader.factory();
        if (!factory) {
            qWarning() << "Error loading plugin" << pluginInfo.libraryPath() << loader.errorString();
            continue;
        } else {
            plugin = factory->create<KontactInterface::Plugin>(this);
            if (!plugin) {
                qCWarning(KONTACT_LOG) << "Unable to create plugin for" << pluginInfo.libraryPath();
                continue;
            }
        }

        plugin->setIdentifier(pluginInfo.pluginName());
        plugin->setTitle(pluginInfo.name());
        plugin->setIcon(pluginInfo.icon());

        const QVariant libNameProp = pluginInfo.property(QStringLiteral("X-KDE-KontactPartLibraryName"));
        const QVariant exeNameProp = pluginInfo.property(QStringLiteral("X-KDE-KontactPartExecutableName"));
        const QVariant loadOnStart = pluginInfo.property(QStringLiteral("X-KDE-KontactPartLoadOnStart"));
        const QVariant hasPartProp = pluginInfo.property(QStringLiteral("X-KDE-KontactPluginHasPart"));

        if (!loadOnStart.isNull() && loadOnStart.toBool()) {
            mDelayedPreload.append(plugin);
        }

        qCDebug(KONTACT_LOG) << "LIBNAMEPART:" << libNameProp.toString();

        plugin->setPartLibraryName(libNameProp.toString().toUtf8());
        plugin->setExecutableName(exeNameProp.toString());
        if (hasPartProp.isValid()) {
            plugin->setShowInSideBar(hasPartProp.toBool());
        }
        plugins.append(plugin);
    }
```

#### AUTO 


```{c}
const auto model = qobject_cast<const KPageWidgetModel *>(q->pageWidget()->model());
```

#### AUTO 


```{c}
auto introboxHBoxLayout = new QHBoxLayout(introbox);
```

#### LAMBDA EXPRESSION 


```{c}
[&](KontactInterface::Plugin * plugin) {
        return plugin->identifier() == identifier;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KontactInterface::Plugin *plugin : qAsConst(mPlugins)) {
            if (!plugin->newActions().isEmpty()) {
                plugin->newActions().first()->trigger();
                return;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (KontactInterface::Plugin *plugin : qAsConst(mPlugins)) {
                    if (plugin->showInSideBar()) {
                        selectPlugin(plugin);
                        return true;
                    }
                }
```

#### AUTO 


```{c}
auto sortByWeight = [](const KPluginMetaData &m1, const KPluginMetaData &m2) {
            return m1.rawData().value(QStringLiteral("X-KDE-Weight")).toInt() < m2.rawData().value(QStringLiteral("X-KDE-Weight")).toInt();
        };
```

#### AUTO 


```{c}
auto *personView = new QTextBrowser(topFrame);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QByteArray &componentName) {
            if (componentName == QByteArrayLiteral("kontact")) {
                MainWindow::updateConfig();
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (KontactInterface::Plugin *plugin : std::as_const(plugins)) {
        const QList<QAction *> actionList = plugin->newActions();
        for (QAction *action : actionList) {
            qCDebug(KONTACT_LOG) << "Plugging new action" << action->objectName();
            mNewActions->addAction(action);
        }
        addPlugin(plugin);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginInfo &pluginInfo : qAsConst(mPluginInfos)) {
        if (!pluginInfo.isPluginEnabled()) {
            continue;
        }

        KontactInterface::Plugin *plugin = pluginFromName(pluginInfo.pluginName());
        if (plugin) { // already loaded
            plugin->configUpdated();
            continue;
        }

        qCDebug(KONTACT_LOG) << "Loading Plugin:" << pluginInfo.name();
        QString error;
        plugin = pluginInfo.service()->createInstance<KontactInterface::Plugin>(this, QVariantList(), &error);

        if (!plugin) {
            qCDebug(KONTACT_LOG) << "Unable to create plugin for" << pluginInfo.name() << pluginInfo.service()->entryPath() << error;
            continue;
        }

        plugin->setIdentifier(pluginInfo.pluginName());
        plugin->setTitle(pluginInfo.name());
        plugin->setIcon(pluginInfo.icon());

        QVariant libNameProp = pluginInfo.property(QStringLiteral("X-KDE-KontactPartLibraryName"));
        QVariant exeNameProp = pluginInfo.property(QStringLiteral("X-KDE-KontactPartExecutableName"));
        QVariant loadOnStart = pluginInfo.property(QStringLiteral("X-KDE-KontactPartLoadOnStart"));
        QVariant hasPartProp = pluginInfo.property(QStringLiteral("X-KDE-KontactPluginHasPart"));

        if (!loadOnStart.isNull() && loadOnStart.toBool()) {
            mDelayedPreload.append(plugin);
        }

        qCDebug(KONTACT_LOG) << "LIBNAMEPART:" << libNameProp.toString();

        plugin->setPartLibraryName(libNameProp.toString().toUtf8());
        plugin->setExecutableName(exeNameProp.toString());
        if (hasPartProp.isValid()) {
            plugin->setShowInSideBar(hasPartProp.toBool());
        }
        plugins.append(plugin);
    }
```

#### AUTO 


```{c}
auto hasIdentifier = [&](KontactInterface::Plugin * plugin) {
        return plugin->identifier() == pluginName;
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &pluginMetaData : std::as_const(mPluginMetaData)) {
        if (!configGroup.readEntry(pluginMetaData.pluginId() + QLatin1String("Enabled"), pluginMetaData.isEnabledByDefault())) {
            continue;
        }

        KontactInterface::Plugin *plugin = pluginFromName(pluginMetaData.pluginId());
        if (plugin) { // already loaded
            plugin->configUpdated();
            continue;
        }

        qCDebug(KONTACT_LOG) << "Loading Plugin:" << pluginMetaData.name();
        const auto loadResult = KPluginFactory::instantiatePlugin<KontactInterface::Plugin>(pluginMetaData, this);
        if (!loadResult) {
            qCWarning(KONTACT_LOG) << "Error loading plugin" << pluginMetaData.fileName() << loadResult.errorString;
            continue;
        } else {
            plugin = loadResult.plugin;
            if (!plugin) {
                qCWarning(KONTACT_LOG) << "Unable to create plugin for" << pluginMetaData.fileName();
                continue;
            }
        }
        plugin->setIdentifier(pluginMetaData.fileName());
        plugin->setTitle(pluginMetaData.name());
        plugin->setIcon(pluginMetaData.iconName());

        const QString libNameProp = pluginMetaData.value(QStringLiteral("X-KDE-KontactPartLibraryName"));
        const QString exeNameProp = pluginMetaData.value(QStringLiteral("X-KDE-KontactPartExecutableName"));

        if (pluginMetaData.rawData().contains(QLatin1String("X-KDE-KontactPartLoadOnStart"))) {
            const bool loadOnStart = pluginMetaData.rawData().value(QStringLiteral("X-KDE-KontactPartLoadOnStart")).toBool();
            if (loadOnStart) {
                mDelayedPreload.append(plugin);
            }
        }
        if (pluginMetaData.rawData().contains(QLatin1String("X-KDE-KontactPluginHasPart"))) {
            const bool hasPartProp = pluginMetaData.rawData().value(QStringLiteral("X-KDE-KontactPluginHasPart")).toBool();
            plugin->setShowInSideBar(hasPartProp);
        } else {
            plugin->setShowInSideBar(true);
        }

        qCDebug(KONTACT_LOG) << "LIBNAMEPART:" << libNameProp;

        plugin->setPartLibraryName(libNameProp.toUtf8());
        plugin->setExecutableName(exeNameProp);
        plugins.append(plugin);
    }
```

#### AUTO 


```{c}
auto about = new KAboutData(QStringLiteral("kontactconfig"),
                                i18nc("@title", "KDE Kontact"),
                                QString(),
                                QString(),
                                KAboutLicense::GPL,
                                i18nc("@info:credit", "(c), 2003 Cornelius Schumacher"));
```

#### RANGE FOR STATEMENT 


```{c}
for (KontactInterface::Plugin *plugin : qAsConst(mPlugins)) {
        if (!plugin->isRunningStandalone()) {
            if (!plugin->queryClose()) {
                return false;
            }
        }
    }
```

#### AUTO 


```{c}
auto job = new KIO::OpenUrlJob(url);
```

#### RANGE FOR STATEMENT 


```{c}
for (KontactInterface::Plugin *plugin : qAsConst(mDelayedPreload)) {
        selectPlugin(plugin);
    }
```

#### AUTO 


```{c}
auto manager = new KColorSchemeManager(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KService::Ptr &service : offers) {
        // skip summary only plugins
        QVariant var = service->property(QStringLiteral("X-KDE-KontactPluginHasPart"));
        if (var.isValid() && var.toBool() == false) {
            continue;
        }
        mPluginCombo->addItem(service->name());
        mPluginList.append(service);

        // skip disabled plugins
        const QString pluginName = service->property(QStringLiteral("X-KDE-PluginInfo-Name")).toString();
        if (!grp.readEntry(pluginName + QStringLiteral("Enabled"), false)) {
            const QStandardItemModel *qsm = qobject_cast<QStandardItemModel *>(mPluginCombo->model());
            if (qsm) {
                qsm->item(mPluginCombo->count()-1, 0)->setEnabled(false);
            }
        }
        if (service->property(QStringLiteral("X-KDE-PluginInfo-Name")).toString() == Prefs::self()->activePlugin()) {

            activeComponent = mPluginList.count() - 1;
        }
    }
```

#### AUTO 


```{c}
auto layout = new QVBoxLayout(page);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginInfo &pluginInfo : qAsConst(mPluginInfos)) {
        if (!pluginInfo.isPluginEnabled()) {
            continue;
        }

        KontactInterface::Plugin *plugin = pluginFromName(pluginInfo.pluginName());
        if (plugin) { // already loaded
            plugin->configUpdated();
            continue;
        }

        qCDebug(KONTACT_LOG) << "Loading Plugin:" << pluginInfo.name();
        QString error;
        plugin = pluginInfo.service()->createInstance<KontactInterface::Plugin>(this, QVariantList(), &error);

        if (!plugin) {
            qCDebug(KONTACT_LOG) << "Unable to create plugin for" << pluginInfo.name() << pluginInfo.service()->entryPath() << error;
            continue;
        }

        plugin->setIdentifier(pluginInfo.pluginName());
        plugin->setTitle(pluginInfo.name());
        plugin->setIcon(pluginInfo.icon());

        QVariant libNameProp = pluginInfo.property(QStringLiteral("X-KDE-KontactPartLibraryName"));
        QVariant exeNameProp = pluginInfo.property(QStringLiteral("X-KDE-KontactPartExecutableName"));
        QVariant loadOnStart = pluginInfo.property(QStringLiteral("X-KDE-KontactPartLoadOnStart"));
        QVariant hasPartProp = pluginInfo.property(QStringLiteral("X-KDE-KontactPluginHasPart"));

        if (!loadOnStart.isNull() && loadOnStart.toBool()) {
            mDelayedPreload.append(plugin);
        }

        qCDebug(KONTACT_LOG) << "LIBNAMEPART:" << libNameProp.toString();

        plugin->setPartLibraryName(libNameProp.toString().toUtf8());
        plugin->setExecutableName(exeNameProp.toString());
        if (hasPartProp.isValid()) {
            plugin->setShowInSideBar(hasPartProp.toBool());
        }
        const int nbPlugins{
            plugins.count()
        };
        for (i = 0; i < nbPlugins; ++i) {
            KontactInterface::Plugin *p = plugins.at(i);
            if (plugin->weight() < p->weight()) {
                break;
            }
        }
        plugins.insert(i, plugin);
    }
```

#### AUTO 


```{c}
auto commentLabel = new QLabel(comment, page);
```

#### RANGE FOR STATEMENT 


```{c}
for (KontactInterface::Plugin *plugin : qAsConst(mPlugins)) {
            if (!plugin->newActions().isEmpty()) {
                plugin->newActions().constFirst()->trigger();
                return;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (KontactInterface::Plugin *plugin : qAsConst(mPlugins)) {
                if (!plugin->newActions().isEmpty()) {
                    newAction = plugin->newActions().first();
                }
                if (newAction) {
                    mNewActions->setIcon(newAction->icon());
                    mNewActions->setText(newAction->text());
                    mNewActions->setWhatsThis(newAction->whatsThis());
                    break;
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
            slotActionTriggered(action, plugin->identifier());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (KontactInterface::Plugin *plugin : std::as_const(mPlugins)) {
            if (plugin->showInSideBar()) {
                selectPlugin(plugin);
                return true;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const CreatedModule &module : std::as_const(modules)) {
        KCModuleProxy *proxy = module.kcm;

        if (proxy->changed()) {
            proxy->save();
            /**
             * Add name of the components the kcm belongs to the list
             * of updated components.
             */
            const QStringList componentNames = module.componentNames;
            for (const QString &componentName : componentNames) {
                if (!updatedComponents.contains(componentName)) {
                    updatedComponents.append(componentName);
                }
            }
        }
    }
```

#### AUTO 


```{c}
auto *textBrowser = new QTextBrowser(topFrame);
```

#### AUTO 


```{c}
auto layout = new QVBoxLayout;
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginInfo &pluginInfo : qAsConst(mPluginInfos)) {
        if (!pluginInfo.isPluginEnabled()) {
            continue;
        }

        const QString pluginPath = pluginInfo.libraryPath();
        KontactInterface::Plugin *plugin = pluginFromName(pluginPath);
        if (plugin) { // already loaded
            plugin->configUpdated();
            continue;
        }

        qCDebug(KONTACT_LOG) << "Loading Plugin:" << pluginInfo.name();
        KPluginLoader loader(pluginInfo.libraryPath());
        KPluginFactory *factory = loader.factory();
        if (!factory) {
            qWarning() << "Error loading plugin" << pluginInfo.libraryPath() << loader.errorString();
            continue;
        } else {
            plugin = factory->create<KontactInterface::Plugin>(this);
            if (!plugin) {
                qCWarning(KONTACT_LOG) << "Unable to create plugin for" << pluginInfo.libraryPath();
                continue;
            }
        }

        plugin->setIdentifier(pluginInfo.pluginName());
        plugin->setTitle(pluginInfo.name());
        plugin->setIcon(pluginInfo.icon());

        QVariant libNameProp = pluginInfo.property(QStringLiteral("X-KDE-KontactPartLibraryName"));
        QVariant exeNameProp = pluginInfo.property(QStringLiteral("X-KDE-KontactPartExecutableName"));
        QVariant loadOnStart = pluginInfo.property(QStringLiteral("X-KDE-KontactPartLoadOnStart"));
        QVariant hasPartProp = pluginInfo.property(QStringLiteral("X-KDE-KontactPluginHasPart"));

        if (!loadOnStart.isNull() && loadOnStart.toBool()) {
            mDelayedPreload.append(plugin);
        }

        qCDebug(KONTACT_LOG) << "LIBNAMEPART:" << libNameProp.toString();

        plugin->setPartLibraryName(libNameProp.toString().toUtf8());
        plugin->setExecutableName(exeNameProp.toString());
        if (hasPartProp.isValid()) {
            plugin->setShowInSideBar(hasPartProp.toBool());
        }
        plugins.append(plugin);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginInfo &pluginInfo : qAsConst(mPluginInfos)) {
        if (!pluginInfo.isPluginEnabled()) {
            continue;
        }

        const QString pluginName = pluginInfo.libraryPath();
        //qDebug() << pluginName;
        KontactInterface::Plugin *plugin = pluginFromName(pluginName);
        if (plugin) { // already loaded
            plugin->configUpdated();
            continue;
        }

        qCDebug(KONTACT_LOG) << "Loading Plugin:" << pluginInfo.name();
        KPluginLoader loader(pluginInfo.libraryPath());
        KPluginFactory* factory = loader.factory();
        if (!factory) {
            qWarning() << "Error loading plugin" << pluginInfo.libraryPath() << loader.errorString();
            continue;
        } else {
            plugin = factory->create<KontactInterface::Plugin>(this);
            if (!plugin) {
                qCWarning(KONTACT_LOG) << "Unable to create plugin for" << pluginInfo.libraryPath();
                continue;
            }
        }

        plugin->setIdentifier(pluginName);
        plugin->setTitle(pluginInfo.name());
        plugin->setIcon(pluginInfo.icon());

        QVariant libNameProp = pluginInfo.property(QStringLiteral("X-KDE-KontactPartLibraryName"));
        QVariant exeNameProp = pluginInfo.property(QStringLiteral("X-KDE-KontactPartExecutableName"));
        QVariant loadOnStart = pluginInfo.property(QStringLiteral("X-KDE-KontactPartLoadOnStart"));
        QVariant hasPartProp = pluginInfo.property(QStringLiteral("X-KDE-KontactPluginHasPart"));

        if (!loadOnStart.isNull() && loadOnStart.toBool()) {
            mDelayedPreload.append(plugin);
        }

        qCDebug(KONTACT_LOG) << "LIBNAMEPART:" << libNameProp.toString();

        plugin->setPartLibraryName(libNameProp.toString().toUtf8());
        plugin->setExecutableName(exeNameProp.toString());
        if (hasPartProp.isValid()) {
            plugin->setShowInSideBar(hasPartProp.toBool());
        }
        plugins.append(plugin);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &plugin : pluginMetaDatas) {
        // skip summary only plugins
        if (plugin.rawData().contains(QLatin1String("X-KDE-KontactPluginHasPart"))) {
            bool var = plugin.rawData().value(QStringLiteral("X-KDE-KontactPluginHasPart")).toBool();

            if (!var) {
                continue;
            }
        }

        cout << "lib name " << qPrintable(plugin.pluginId().remove(QStringLiteral("kontact_"))) << endl;
    }
```

#### AUTO 


```{c}
auto page = new KPageWidgetItem(topFrame, title);
```

#### RANGE FOR STATEMENT 


```{c}
for (KontactInterface::Plugin *plugin : qAsConst(mPlugins)) {
            if (!plugin->identifier().isEmpty() && plugin->identifier().contains(mInitialActiveModule)) {
                selectPlugin(plugin);
                return;
            }
        }
```

#### AUTO 


```{c}
auto *layout = new QVBoxLayout(this);
```

#### AUTO 


```{c}
const auto activePluginList = config.readEntry("ActivePlugins", QStringList());
```

#### AUTO 


```{c}
auto topLayout = new QVBoxLayout(topFrame);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &plugin : pluginMetaDatas) {
        // skip summary only plugins
        if (plugin.rawData().contains(QLatin1String("X-KDE-KontactPluginHasPart"))) {
            bool var = plugin.rawData().value(QStringLiteral("X-KDE-KontactPluginHasPart")).toBool();

            if (!var) {
                continue;
            }
        }

        mPluginCombo->addItem(plugin.name());
        mPluginList.append(plugin);

        // skip disabled plugins
        const QString pluginName = plugin.pluginId();
        if (!grp.readEntry(pluginName + QStringLiteral("Enabled"), true)) {
            const QStandardItemModel *qsm = qobject_cast<QStandardItemModel *>(mPluginCombo->model());
            if (qsm) {
                qsm->item(mPluginCombo->count() - 1, 0)->setEnabled(false);
            }
        }
        if (pluginName == Prefs::self()->activePlugin()) {
            activeComponent = mPluginList.count() - 1;
        }
    }
```

#### AUTO 


```{c}
auto topLayout = new QFormLayout(this);
```

#### AUTO 


```{c}
auto mTopWidget = new QWidget(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &metaData : std::as_const(mPluginMetaData)) {
            const QString pluginNamespace = metaData.value(QStringLiteral("X-KDE-ConfigModuleNamespace"));
            if (!pluginNamespace.isEmpty()) {
                auto plugins = KPluginLoader::findPlugins(pluginNamespace);
                std::sort(plugins.begin(), plugins.end(), sortByWeight);
                dlg->addPluginComponent(metaData, plugins);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (KontactInterface::Plugin *plugin : qAsConst(mPlugins)) {
            if (plugin->showInSideBar()) {
                selectPlugin(plugin);
                return true;
            }
        }
```

#### AUTO 


```{c}
auto label = new QLabel(i18n("No about information available."), topFrame);
```

#### AUTO 


```{c}
auto moduleScroll = new UnboundScrollArea(this);
```

#### AUTO 


```{c}
const auto loadResult = KPluginFactory::instantiatePlugin<KontactInterface::Plugin>(pluginMetaData, this);
```

#### LAMBDA EXPRESSION 


```{c}
[this](KPageWidgetItem *current, KPageWidgetItem *before) {
        _k_slotCurrentPageChanged(current, before);
    }
```

#### AUTO 


```{c}
auto buttons = activeModule ? activeModule->buttons() : KCModule::NoAdditionalButton;
```

#### AUTO 


```{c}
auto action = new QAction(QIcon::fromTheme(plugin->icon()), plugin->title(), this);
```

#### AUTO 


```{c}
auto b = new QToolButton(mb);
```

#### AUTO 


```{c}
auto hasIdentifier = [&](KontactInterface::Plugin *plugin) {
        return plugin->identifier() == identifier;
    };
```

#### AUTO 


```{c}
auto *pageItem = new KPageWidgetItem(topFrame, title);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginInfo &pluginInfo : std::as_const(mPluginInfos)) {
        if (!pluginInfo.isPluginEnabled()) {
            removePlugin(pluginInfo.pluginName());
        }
    }
```

#### AUTO 


```{c}
const auto model = qobject_cast<const KPageWidgetModel *>(pageWidget()->model());
```

#### RANGE FOR STATEMENT 


```{c}
for (KontactInterface::Plugin *plugin : qAsConst(plugins)) {
        const QList<QAction *> actionList = plugin->newActions();
        for (QAction *action : actionList) {
            qCDebug(KONTACT_LOG) << "Plugging new action" << action->objectName();
            mNewActions->addAction(action);
        }
        addPlugin(plugin);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : actionList) {
            qCDebug(KONTACT_LOG) << "Plugging new action" << action->objectName();
            mNewActions->addAction(action);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (KontactInterface::Plugin *plugin : std::as_const(mPlugins)) {
        if (!plugin->isRunningStandalone()) {
            if (!plugin->queryClose()) {
                return false;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : actionList) {
        qCDebug(KONTACT_LOG) << QStringLiteral("Unplugging New actions") << action->objectName();
        mNewActions->removeAction(action);
    }
```

#### AUTO 


```{c}
auto *page = new KPageWidgetItem(topFrame, title);
```

#### RANGE FOR STATEMENT 


```{c}
for (KontactInterface::Plugin *plugin : std::as_const(mPlugins)) {
            if (!plugin->identifier().isEmpty() && plugin->identifier().contains(mInitialActiveModule)) {
                selectPlugin(plugin);
                return;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &pair : std::as_const(componentsMetaData)) {
        const KPluginMetaData &parentComponentMetaData = pair.first;
        const QVector<KPluginMetaData> &kcmsMetaData = pair.second;
        KPageWidgetItem *parentItem =
            createPageItem(nullptr, parentComponentMetaData.name(), parentComponentMetaData.description(), parentComponentMetaData.iconName());
        for (const KPluginMetaData &metaData : kcmsMetaData) {
            q->addModule(metaData, parentItem);
        }
    }
```

#### AUTO 


```{c}
auto &proxy
```

#### LAMBDA EXPRESSION 


```{c}
[d]() {
        d->_k_clientChanged();
    }
```

#### AUTO 


```{c}
auto *iconSize = new QActionGroup(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &metaData : kcmsMetaData) {
            q->addModule(metaData, parentItem);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (KontactInterface::Plugin *plugin : qAsConst(mPlugins)) {
                if (!plugin->newActions().isEmpty()) {
                    newAction = plugin->newActions().constFirst();
                }
                if (newAction) {
                    mNewActions->setIcon(newAction->icon());
                    mNewActions->setText(newAction->text());
                    mNewActions->setWhatsThis(newAction->whatsThis());
                    break;
                }
            }
```

#### AUTO 


```{c}
auto job = new KIO::ApplicationLauncherJob(service);
```

#### RANGE FOR STATEMENT 


```{c}
for (KPluginInfo &pluginInfo : mPluginInfos) {
        pluginInfo.load();
    }
```

#### AUTO 


```{c}
auto personView = new QTextBrowser(topFrame);
```

#### AUTO 


```{c}
auto introbox = new QWidget(mPartsStack);
```

#### AUTO 


```{c}
auto viewMode = new QActionGroup(this);
```

#### AUTO 


```{c}
auto plugins = KPluginLoader::findPlugins(pluginNamespace);
```

#### AUTO 


```{c}
auto layout = new QVBoxLayout(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &pluginMetaData : std::as_const(mPluginMetaData)) {
        if (!configGroup.readEntry(pluginMetaData.pluginId() + QLatin1String("Enabled"), pluginMetaData.isEnabledByDefault())) {
            continue;
        }

        KontactInterface::Plugin *plugin = pluginFromName(pluginMetaData.pluginId());
        if (plugin) { // already loaded
            plugin->configUpdated();
            continue;
        }

        qCDebug(KONTACT_LOG) << "Loading Plugin:" << pluginMetaData.name();
        KPluginLoader loader(pluginMetaData.fileName());
        KPluginFactory *factory = loader.factory();
        if (!factory) {
            qCWarning(KONTACT_LOG) << "Error loading plugin" << pluginMetaData.fileName() << loader.errorString();
            continue;
        } else {
            plugin = factory->create<KontactInterface::Plugin>(this);
            if (!plugin) {
                qCWarning(KONTACT_LOG) << "Unable to create plugin for" << pluginMetaData.fileName();
                continue;
            }
        }

        plugin->setIdentifier(pluginMetaData.fileName());
        plugin->setTitle(pluginMetaData.name());
        plugin->setIcon(pluginMetaData.iconName());

        const QString libNameProp = pluginMetaData.value(QStringLiteral("X-KDE-KontactPartLibraryName"));
        const QString exeNameProp = pluginMetaData.value(QStringLiteral("X-KDE-KontactPartExecutableName"));
        const QString loadOnStart = pluginMetaData.value(QStringLiteral("X-KDE-KontactPartLoadOnStart"));
        const QString hasPartProp = pluginMetaData.value(QStringLiteral("X-KDE-KontactPluginHasPart"));

        if (!loadOnStart.isEmpty() && loadOnStart == QLatin1String("true")) {
            mDelayedPreload.append(plugin);
        }

        qCDebug(KONTACT_LOG) << "LIBNAMEPART:" << libNameProp;

        plugin->setPartLibraryName(libNameProp.toUtf8());
        plugin->setExecutableName(exeNameProp);
        if (!hasPartProp.isEmpty()) {
            plugin->setShowInSideBar(hasPartProp == QLatin1String("true"));
        }
        plugins.append(plugin);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&](KontactInterface::Plugin * plugin) {
        return plugin->identifier() == pluginName;
    }
```

#### AUTO 


```{c}
auto *rightPlugin
            = static_cast<KontactInterface::Plugin *>(right.internalPointer());
```

#### RANGE FOR STATEMENT 


```{c}
for (KontactInterface::Plugin *plugin : std::as_const(mPlugins)) {
                if (!plugin->newActions().isEmpty()) {
                    newAction = plugin->newActions().constFirst();
                }
                if (newAction) {
                    mNewActions->setIcon(newAction->icon());
                    mNewActions->setText(newAction->text());
                    mNewActions->setWhatsThis(newAction->whatsThis());
                    break;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (KontactInterface::Plugin *plugin : qAsConst(mPlugins)) {
            if (!plugin->identifier().isEmpty()
                && plugin->identifier().contains(mInitialActiveModule)) {
                selectPlugin(plugin);
                return;
            }
        }
```

#### AUTO 


```{c}
auto sep = new QAction(this);
```

#### AUTO 


```{c}
auto topLayout = new QVBoxLayout(this);
```

#### AUTO 


```{c}
auto action = new QAction(QIcon::fromTheme(QStringLiteral("configure")), i18nc("@action:inmenu", "Configure Kontact..."), this);
```

#### AUTO 


```{c}
auto forceStartupPluginCheckBox = new QCheckBox(Prefs::self()->forceStartupPluginItem()->label(), this);
```

#### AUTO 


```{c}
const auto it = std::find_if(mPlugins.constBegin(), mPlugins.constEnd(), hasIdentifier);
```

#### AUTO 


```{c}
auto buttonBox = new QDialogButtonBox(q);
```

#### LAMBDA EXPRESSION 


```{c}
[&](KontactInterface::Plugin *plugin) {
        return plugin->identifier() == pluginName;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &proxy : std::as_const(d->modules)) {
        proxy.kcm->deleteClient();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &metaData : std::as_const(mPluginMetaData)) {
            const QString pluginNamespace = metaData.value(QStringLiteral("X-KDE-ConfigModuleNamespace"));
            if (!pluginNamespace.isEmpty()) {
#if KCOREADDONS_VERSION < QT_VERSION_CHECK(5, 86, 0)
                auto plugins = KPluginLoader::findPlugins(pluginNamespace);
#else
                auto plugins = KPluginMetaData::findPlugins(pluginNamespace);
#endif
                std::sort(plugins.begin(), plugins.end(), sortByWeight);
                dlg->addPluginComponent(metaData, plugins);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (KontactInterface::Plugin *plugin : std::as_const(mPlugins)) {
            if (!plugin->newActions().isEmpty()) {
                plugin->newActions().constFirst()->trigger();
                return;
            }
        }
```

#### AUTO 


```{c}
auto pageEngine = new IntroductionWebEnginePage(this);
```

#### AUTO 


```{c}
const auto spacing = mNavigator->style()->pixelMetric(QStyle::PM_FocusFrameHMargin);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KService::Ptr &service : offers) {
        // skip summary only plugins
        QVariant var = service->property(QStringLiteral("X-KDE-KontactPluginHasPart"));
        if (var.isValid() && var.toBool() == false) {
            continue;
        }
        mPluginCombo->addItem(service->name());
        mPluginList.append(service);

        // skip disabled plugins
        const QString pluginName = service->property(QStringLiteral("X-KDE-PluginInfo-Name")).toString();
        if (!grp.readEntry(pluginName + QStringLiteral("Enabled"), false)) {
            const QStandardItemModel *qsm = qobject_cast<QStandardItemModel *>(mPluginCombo->model());
            if (qsm) {
                qsm->item(mPluginCombo->count()-1, 0)->setEnabled(false);
            }
        }

        if (service->property(QStringLiteral("X-KDE-PluginInfo-Name")).toString() == mItem->value()) {
            activeComponent = mPluginList.count() - 1;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginInfo &pluginInfo : qAsConst(mPluginInfos)) {
        if (pluginInfo.isPluginEnabled()) {
            KontactInterface::Plugin *plugin = pluginFromName(pluginInfo.pluginName());
            if (plugin) {
                activePlugins.append(plugin->identifier());
                plugin->saveProperties(config);
            }
        }
    }
```

#### AUTO 


```{c}
auto sortFilterProxyModel = new SortFilterProxyModel(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &componentName : componentNames) {
                if (!updatedComponents.contains(componentName)) {
                    updatedComponents.append(componentName);
                }
            }
```

#### AUTO 


```{c}
auto *sortFilterProxyModel = new SortFilterProxyModel(this);
```

#### AUTO 


```{c}
auto plugins = KPluginMetaData::findPlugins(pluginNamespace);
```

#### RANGE FOR STATEMENT 


```{c}
for (KontactInterface::Plugin *plugin : qAsConst(mPlugins)) {
            if (!plugin->isRunningStandalone() && activePlugins.contains(plugin->identifier())) {
                plugin->readProperties(config);
            }
        }
```

#### AUTO 


```{c}
auto *leftPlugin
            = static_cast<KontactInterface::Plugin *>(left.internalPointer());
```

#### RANGE FOR STATEMENT 


```{c}
for (const CreatedModule &module : std::as_const(modules)) {
        KCModuleProxy *proxy = module.kcm;

        if (proxy->isChanged()) {
            proxy->save();
            /**
             * Add name of the components the kcm belongs to the list
             * of updated components.
             */
            const QStringList componentNames = module.componentNames;
            for (const QString &componentName : componentNames) {
                if (!updatedComponents.contains(componentName)) {
                    updatedComponents.append(componentName);
                }
            }
        }
    }
```

