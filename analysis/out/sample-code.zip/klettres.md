#### RANGE FOR STATEMENT 


```{c}
for (const QString &language : languagesList) {
        if (language == QLatin1String("hi-ro")) {
            languagesNames.append(i18n("Romanized Hindi"));
        } else if (language == QLatin1String("lug_UG")) {
            languagesNames.append(i18n("Luganda"));
        } else if (language == QLatin1String("ep")) {
            languagesNames.append(i18n("English Phonics"));
        } else if (language == QLatin1String("tn")) {
            languagesNames.append(i18n("Tswana"));
        } else {
            QLocale locale(language);
            QString languageName = locale.nativeLanguageName();
            if (locale == QLocale::c())
                languageName = i18nc("@item:inlistbox no language for that locale", "None");
            languagesNames.append(languageName);
        }
    }
```

