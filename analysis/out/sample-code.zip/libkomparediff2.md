#### RANGE FOR STATEMENT 


```{c}
for (Difference* diff : differences) {
        QVERIFY(diff->applied());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& line : newLines) {
            destinationLines.append(line);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (DiffModel* model : splicedModelList) {
        model->setSourceFile(lstripSeparators(model->source(), m_info->depth));
        model->setDestinationFile(lstripSeparators(model->destination(), m_info->depth));
        model->applyAllDifferences(m_info->applied);
    }
```

#### AUTO 


```{c}
const auto differences = *model->differences();
```

#### AUTO 


```{c}
auto linesIt = lines.constBegin(), lEnd = lines.constEnd();
```

#### RANGE FOR STATEMENT 


```{c}
for (Difference* current : qAsConst(m_differences)) {
        if (current->destinationLineNumber() > diff->destinationLineNumber())
        {
            current->setTrackingDestinationLineNumber(current->trackingDestinationLineNumber() + delta);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& str : list) {
        lines.append(str);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& it : qAsConst(m_diffSettings->m_excludeFilePatternList)) {
            *this << QStringLiteral("-x") << it;
        }
```

