#### AUTO 


```{c}
auto hlay = new QHBoxLayout();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &fileName : lst) {
            if (fileName.endsWith(QLatin1String(".png"), Qt::CaseInsensitive)) {
                QImage image;
                if (image.load(dir.path() + QLatin1Char('/') + fileName)) {
                    addImage(image, fileName);
                } else {
                    qCWarning(KIDENTITYMANAGEMENT_LOG) << "Unable to load image" << dir.path() + QLatin1Char('/') + fileName;
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPIMTextEdit::ImageWithNamePtr &image : images) {
                sig.addImage(image->image, image->name);
            }
```

#### AUTO 


```{c}
auto label = new QLabel(i18n("Obtain signature &text from:"), q);
```

#### AUTO 


```{c}
const auto &pair
```

#### AUTO 


```{c}
auto page_vlay = new QVBoxLayout(page);
```

#### AUTO 


```{c}
const auto rhsIt = rhs.constFind(lhsIt.key());
```

#### RANGE FOR STATEMENT 


```{c}
for (const Signature::EmbeddedImagePtr &image : embeddedImgs) {
            textEdit->composerControler()->composerImages()->loadImage(image->image, image->name, image->name);
        }
```

#### AUTO 


```{c}
const auto vcardFile = QStringLiteral(
        "BEGIN:VCARD\n"
        "VERSION:2.1\n"
        "N:Vr�til;Daniel;;\n"
        "END:VCARD");
```

#### AUTO 


```{c}
auto it = std::remove_if(embeddedImages.begin(), embeddedImages.end(),
                                 [this](const Signature::EmbeddedImagePtr &imageInList){
            const QStringList lstImage = findImageNames(text);
            for (const QString &imageInHtml : lstImage) {
                if (imageInHtml == imageInList->name) {
                    return false;
                }
            }
            return true;
        });
```

#### AUTO 


```{c}
auto *richTextEditorwidget = new KPIMTextEdit::RichTextEditorWidget(mTextEdit, q);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &fullAddress : addressList) {
        const QString addrSpec = KEmailAddress::extractEmailAddress(fullAddress).toLower();
        for (ConstIterator it = begin(); it != end(); ++it) {
            const Identity &identity = *it;
            if (identity.matchesEmailAddress(addrSpec)) {
                return identity;
            }
        }
    }
```

#### AUTO 


```{c}
const auto embeddedImgs = sig.embeddedImages();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &imageInHtml : lstImage) {
                if (imageInHtml == imageInList->name) {
                    return false;
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        QCOMPARE(actual.uoid(), expected.uoid());
        // Don't compare isDefault - only one copy can be default, so this property
        // is not copied! It does not affect result of operator==() either.
        // QCOMPARE(actual.isDefault(), expected.isDefault());
        QCOMPARE(actual.identityName(), expected.identityName());
        QCOMPARE(actual.fullName(), expected.fullName());
        QCOMPARE(actual.organization(), expected.organization());
        QCOMPARE(actual.pgpEncryptionKey(), expected.pgpEncryptionKey());
        QCOMPARE(actual.pgpSigningKey(), expected.pgpSigningKey());
        QCOMPARE(actual.smimeEncryptionKey(), expected.smimeEncryptionKey());
        QCOMPARE(actual.smimeSigningKey(), expected.smimeSigningKey());
        QCOMPARE(actual.preferredCryptoMessageFormat(), expected.preferredCryptoMessageFormat());
        QCOMPARE(actual.emailAliases(), expected.emailAliases());
        QCOMPARE(actual.primaryEmailAddress(), expected.primaryEmailAddress());
        QCOMPARE(actual.vCardFile(), expected.vCardFile());
        QCOMPARE(actual.replyToAddr(), expected.replyToAddr());
        QCOMPARE(actual.bcc(), expected.bcc());
        QCOMPARE(actual.cc(), expected.cc());
        QCOMPARE(actual.attachVcard(), expected.attachVcard());
        QCOMPARE(actual.autocorrectionLanguage(), expected.autocorrectionLanguage());
        QCOMPARE(actual.disabledFcc(), expected.disabledFcc());
        QCOMPARE(actual.pgpAutoSign(), expected.pgpAutoSign());
        QCOMPARE(actual.pgpAutoEncrypt(), expected.pgpAutoEncrypt());
        QCOMPARE(actual.defaultDomainName(), expected.defaultDomainName());
        QCOMPARE(actual.signatureText(), expected.signatureText());
        QCOMPARE(const_cast<Identity &>(actual).signature(), const_cast<Identity &>(expected).signature());
        QCOMPARE(actual.transport(), expected.transport());
        QCOMPARE(actual.fcc(), expected.fcc());
        QCOMPARE(actual.drafts(), expected.drafts());
        QCOMPARE(actual.templates(), expected.templates());
        QCOMPARE(actual.dictionary(), expected.dictionary());
        QCOMPARE(actual.isXFaceEnabled(), expected.isXFaceEnabled());
        QCOMPARE(actual.xface(), expected.xface());
        QCOMPARE(actual.isFaceEnabled(), expected.isFaceEnabled());
        QCOMPARE(actual.face(), expected.face());
        ok = true;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &pair : {
    qMakePair(mPropertiesMap, other.mPropertiesMap),
                  qMakePair(other.mPropertiesMap, mPropertiesMap)
    }) {
        const auto lhs = pair.first;
        const auto rhs = pair.second;
        for (auto lhsIt = lhs.constBegin(), lhsEnd = lhs.constEnd(); lhsIt != lhsEnd; ++lhsIt) {
            const auto rhsIt = rhs.constFind(lhsIt.key());
            // Does the other map contain the key?
            if (rhsIt == rhs.constEnd()) {
                // It does not, so check if our value is invalid, if yes, consider it
                // equal to not present and continue
                if (lhsIt->isValid()) {
                    return false;
                }
            } else if (lhsIt.value() != rhsIt.value()) {
                // Both maps have the key, but different value -> different maps
                return false;
            }
        }
    }
```

#### AUTO 


```{c}
auto *widgetStack = new QStackedWidget(q);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &fileName : lst) {
            if (fileName.toLower().endsWith(QStringLiteral(".png"))) {
                qCDebug(KIDENTITYMANAGEMENT_LOG) << "Deleting old image" << dir.path() + fileName;
                dir.remove(fileName);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Signature::EmbeddedImagePtr &image : std::as_const(embeddedImages)) {
            textEdit->composerControler()->composerImages()->loadImage(image->image, image->name, image->name);
        }
```

#### AUTO 


```{c}
auto *hlay = new QHBoxLayout();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &line : lst) {
        text.remove(line + QLatin1Char('\n'));
    }
```

#### AUTO 


```{c}
auto block = doc.begin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Signature::EmbeddedImagePtr &image : std::as_const(embeddedImages)) {
            const QString location = saveLocation + QLatin1Char('/') + image->name;
            if (!image->image.save(location, "PNG")) {
                qCWarning(KIDENTITYMANAGEMENT_LOG) << "Failed to save image" << location;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        QCOMPARE(actual.uoid(), expected.uoid());
        // Don't compare isDefault - only one copy can be default, so this property
        // is not copied! It does not affect result of operator==() either.
        // QCOMPARE(actual.isDefault(), expected.isDefault());
        QCOMPARE(actual.identityName(), expected.identityName());
        QCOMPARE(actual.fullName(), expected.fullName());
        QCOMPARE(actual.organization(), expected.organization());
        QCOMPARE(actual.pgpEncryptionKey(), expected.pgpEncryptionKey());
        QCOMPARE(actual.pgpSigningKey(), expected.pgpSigningKey());
        QCOMPARE(actual.smimeEncryptionKey(), expected.smimeEncryptionKey());
        QCOMPARE(actual.smimeSigningKey(), expected.smimeSigningKey());
        QCOMPARE(actual.preferredCryptoMessageFormat(), expected.preferredCryptoMessageFormat());
        QCOMPARE(actual.emailAliases(), expected.emailAliases());
        QCOMPARE(actual.primaryEmailAddress(), expected.primaryEmailAddress());
        QCOMPARE(actual.vCardFile(), expected.vCardFile());
        QCOMPARE(actual.replyToAddr(), expected.replyToAddr());
        QCOMPARE(actual.bcc(), expected.bcc());
        QCOMPARE(actual.cc(), expected.cc());
        QCOMPARE(actual.attachVcard(), expected.attachVcard());
        QCOMPARE(actual.autocorrectionLanguage(), expected.autocorrectionLanguage());
        QCOMPARE(actual.disabledFcc(), expected.disabledFcc());
        QCOMPARE(actual.pgpAutoSign(), expected.pgpAutoSign());
        QCOMPARE(actual.pgpAutoEncrypt(), expected.pgpAutoEncrypt());
        QCOMPARE(actual.defaultDomainName(), expected.defaultDomainName());
        QCOMPARE(actual.signatureText(), expected.signatureText());
        QCOMPARE(const_cast<Identity &>(actual).signature(), const_cast<Identity &>(expected).signature());
        QCOMPARE(actual.transport(), expected.transport());
        QCOMPARE(actual.fcc(), expected.fcc());
        QCOMPARE(actual.drafts(), expected.drafts());
        QCOMPARE(actual.templates(), expected.templates());
        QCOMPARE(actual.dictionary(), expected.dictionary());
        QCOMPARE(actual.isXFaceEnabled(), expected.isXFaceEnabled());
        QCOMPARE(actual.xface(), expected.xface());
        ok = true;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Signature::EmbeddedImagePtr &image : qAsConst(embeddedImages)) {
            const QString location = saveLocation + QLatin1Char('/') + image->name;
            if (!image->image.save(location, "PNG")) {
                qCWarning(KIDENTITYMANAGEMENT_LOG) << "Failed to save image" << location;
            }
        }
```

#### AUTO 


```{c}
auto widgetStack = new QStackedWidget(q);
```

#### AUTO 


```{c}
const auto lhs = pair.first;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &pair : {qMakePair(mPropertiesMap, other.mPropertiesMap), qMakePair(other.mPropertiesMap, mPropertiesMap)}) {
        const auto lhs = pair.first;
        const auto rhs = pair.second;
        for (auto lhsIt = lhs.constBegin(), lhsEnd = lhs.constEnd(); lhsIt != lhsEnd; ++lhsIt) {
            const auto rhsIt = rhs.constFind(lhsIt.key());
            // Does the other map contain the key?
            if (rhsIt == rhs.constEnd()) {
                // It does not, so check if our value is invalid, if yes, consider it
                // equal to not present and continue
                if (lhsIt->isValid()) {
                    return false;
                }
            } else if (lhsIt.value() != rhsIt.value()) {
                // Both maps have the key, but different value -> different maps
                return false;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPIMTextEdit::ImageWithNamePtr &image : images) {
        ret << image->name;
    }
```

#### AUTO 


```{c}
auto it = block.begin();
```

#### AUTO 


```{c}
auto lhsIt = lhs.constBegin(), lhsEnd = lhs.constEnd();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &pair : {
        qMakePair(mPropertiesMap, other.mPropertiesMap),
        qMakePair(other.mPropertiesMap, mPropertiesMap)
    }) {
        const auto lhs = pair.first;
        const auto rhs = pair.second;
        for (auto lhsIt = lhs.constBegin(), lhsEnd = lhs.constEnd(); lhsIt != lhsEnd; ++lhsIt) {
            const auto rhsIt = rhs.constFind(lhsIt.key());
            // Does the other map contain the key?
            if (rhsIt == rhs.constEnd()) {
                // It does not, so check if our value is invalid, if yes, consider it
                // equal to not present and continue
                if (lhsIt->isValid()) {
                    return false;
                }
            } else if (lhsIt.value() != rhsIt.value()) {
                // Both maps have the key, but different value -> different maps
                return false;
            }
        }
    }
```

#### AUTO 


```{c}
const auto rhs = pair.second;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &pair : { qMakePair(mPropertiesMap, other.mPropertiesMap),
                              qMakePair(other.mPropertiesMap, mPropertiesMap) }) {
        const auto lhs = pair.first;
        const auto rhs = pair.second;
        for (auto lhsIt = lhs.constBegin(), lhsEnd = lhs.constEnd(); lhsIt != lhsEnd; ++lhsIt) {
            const auto rhsIt = rhs.constFind(lhsIt.key());
            // Does the other map contain the key?
            if (rhsIt == rhs.constEnd()) {
                // It does not, so check if our value is invalid, if yes, consider it
                // equal to not present and continue
                if (lhsIt->isValid()) {
                    return false;
                }
            } else if (lhsIt.value() != rhsIt.value()) {
                // Both maps have the key, but different value -> different maps
                return false;
            }
        }
    }
```

#### AUTO 


```{c}
const auto imageFormat = fragment.charFormat().toImageFormat();
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Signature::EmbeddedImagePtr &imageInList){
            const QStringList lstImage = findImageNames(text);
            for (const QString &imageInHtml : lstImage) {
                if (imageInHtml == imageInList->name) {
                    return false;
                }
            }
            return true;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        QCOMPARE(actual.uoid(), expected.uoid());
        // Don't compare isDefault - only one copy can be default, so this property
        // is not copied! It does not affect result of operator==() either.
        //QCOMPARE(actual.isDefault(), expected.isDefault());
        QCOMPARE(actual.identityName(), expected.identityName());
        QCOMPARE(actual.fullName(), expected.fullName());
        QCOMPARE(actual.organization(), expected.organization()); 
        QCOMPARE(actual.pgpEncryptionKey(), expected.pgpEncryptionKey());
        QCOMPARE(actual.pgpSigningKey(), expected.pgpSigningKey());
        QCOMPARE(actual.smimeEncryptionKey(), expected.smimeEncryptionKey());
        QCOMPARE(actual.smimeSigningKey(), expected.smimeSigningKey());
        QCOMPARE(actual.preferredCryptoMessageFormat(), expected.preferredCryptoMessageFormat());
        QCOMPARE(actual.emailAliases(), expected.emailAliases());
        QCOMPARE(actual.primaryEmailAddress(), expected.primaryEmailAddress());
        QCOMPARE(actual.vCardFile(), expected.vCardFile());
        QCOMPARE(actual.replyToAddr(), expected.replyToAddr());
        QCOMPARE(actual.bcc(), expected.bcc());
        QCOMPARE(actual.cc(), expected.cc());
        QCOMPARE(actual.attachVcard(), expected.attachVcard());
        QCOMPARE(actual.autocorrectionLanguage(), expected.autocorrectionLanguage());
        QCOMPARE(actual.disabledFcc(), expected.disabledFcc());
        QCOMPARE(actual.pgpAutoSign(), expected.pgpAutoSign());
        QCOMPARE(actual.pgpAutoEncrypt(), expected.pgpAutoEncrypt());
        QCOMPARE(actual.defaultDomainName(), expected.defaultDomainName());
        QCOMPARE(actual.signatureText(), expected.signatureText());
        QCOMPARE(const_cast<Identity&>(actual).signature(), const_cast<Identity&>(expected).signature());
        QCOMPARE(actual.transport(), expected.transport());
        QCOMPARE(actual.fcc(), expected.fcc());
        QCOMPARE(actual.drafts(), expected.drafts());
        QCOMPARE(actual.templates(), expected.templates());
        QCOMPARE(actual.dictionary(), expected.dictionary());
        QCOMPARE(actual.isXFaceEnabled(), expected.isXFaceEnabled());
        QCOMPARE(actual.xface(), expected.xface());
        ok = true;
    }
```

#### AUTO 


```{c}
auto it = std::remove_if(embeddedImages.begin(), embeddedImages.end(), [this](const Signature::EmbeddedImagePtr &imageInList) {
            const QStringList lstImage = findImageNames(text);
            for (const QString &imageInHtml : lstImage) {
                if (imageInHtml == imageInList->name) {
                    return false;
                }
            }
            return true;
        });
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &alias : lst) {
        if (alias.toLower() == addrSpec) {
            return true;
        }
    }
```

#### AUTO 


```{c}
const auto vcardFile = QStringLiteral("BEGIN:VCARD\n"
                                          "VERSION:2.1\n"
                                          "N:Vr�til;Daniel;;\n"
                                          "END:VCARD");
```

#### AUTO 


```{c}
auto richTextEditorwidget = new KPIMTextEdit::RichTextEditorWidget(mTextEdit, q);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Signature::EmbeddedImagePtr &imageInList) {
            const QStringList lstImage = findImageNames(text);
            for (const QString &imageInHtml : lstImage) {
                if (imageInHtml == imageInList->name) {
                    return false;
                }
            }
            return true;
        }
```

#### AUTO 


```{c}
const auto fragment = it.fragment();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &email : lst) {
            mEmails.insert(email.toLower());
        }
```

#### AUTO 


```{c}
auto vlay = new QVBoxLayout(q);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Signature::EmbeddedImagePtr &image : qAsConst(embeddedImages)) {
            QString location = saveLocation + QLatin1Char('/') + image->name;
            if (!image->image.save(location, "PNG")) {
                qCWarning(KIDENTITYMANAGEMENT_LOG) << "Failed to save image" << location;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &fileName : lst) {
            if (fileName.toLower().endsWith(QLatin1String(".png"))) {
                QImage image;
                if (image.load(dir.path() + QLatin1Char('/') + fileName)) {
                    addImage(image, fileName);
                } else {
                    qCWarning(KIDENTITYMANAGEMENT_LOG) << "Unable to load image" << dir.path() + QLatin1Char('/') + fileName;
                }
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        QCOMPARE(actual.uoid(), expected.uoid());
        // Don't compare isDefault - only one copy can be default, so this property
        // is not copied! It does not affect result of operator==() either.
        //QCOMPARE(actual.isDefault(), expected.isDefault());
        QCOMPARE(actual.identityName(), expected.identityName());
        QCOMPARE(actual.fullName(), expected.fullName());
        QCOMPARE(actual.organization(), expected.organization());
        QCOMPARE(actual.pgpEncryptionKey(), expected.pgpEncryptionKey());
        QCOMPARE(actual.pgpSigningKey(), expected.pgpSigningKey());
        QCOMPARE(actual.smimeEncryptionKey(), expected.smimeEncryptionKey());
        QCOMPARE(actual.smimeSigningKey(), expected.smimeSigningKey());
        QCOMPARE(actual.preferredCryptoMessageFormat(), expected.preferredCryptoMessageFormat());
        QCOMPARE(actual.emailAliases(), expected.emailAliases());
        QCOMPARE(actual.primaryEmailAddress(), expected.primaryEmailAddress());
        QCOMPARE(actual.vCardFile(), expected.vCardFile());
        QCOMPARE(actual.replyToAddr(), expected.replyToAddr());
        QCOMPARE(actual.bcc(), expected.bcc());
        QCOMPARE(actual.cc(), expected.cc());
        QCOMPARE(actual.attachVcard(), expected.attachVcard());
        QCOMPARE(actual.autocorrectionLanguage(), expected.autocorrectionLanguage());
        QCOMPARE(actual.disabledFcc(), expected.disabledFcc());
        QCOMPARE(actual.pgpAutoSign(), expected.pgpAutoSign());
        QCOMPARE(actual.pgpAutoEncrypt(), expected.pgpAutoEncrypt());
        QCOMPARE(actual.defaultDomainName(), expected.defaultDomainName());
        QCOMPARE(actual.signatureText(), expected.signatureText());
        QCOMPARE(const_cast<Identity &>(actual).signature(), const_cast<Identity &>(expected).signature());
        QCOMPARE(actual.transport(), expected.transport());
        QCOMPARE(actual.fcc(), expected.fcc());
        QCOMPARE(actual.drafts(), expected.drafts());
        QCOMPARE(actual.templates(), expected.templates());
        QCOMPARE(actual.dictionary(), expected.dictionary());
        QCOMPARE(actual.isXFaceEnabled(), expected.isXFaceEnabled());
        QCOMPARE(actual.xface(), expected.xface());
        ok = true;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &fileName : lst) {
            if (fileName.endsWith(QLatin1String(".png"), Qt::CaseInsensitive)) {
                qCDebug(KIDENTITYMANAGEMENT_LOG) << "Deleting old image" << dir.path() + fileName;
                dir.remove(fileName);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &fileName : lst) {
            if (fileName.toLower().endsWith(QStringLiteral(".png"))) {
                QImage image;
                if (image.load(dir.path() + QLatin1Char('/') + fileName)) {
                    addImage(image, fileName);
                } else {
                    qCWarning(KIDENTITYMANAGEMENT_LOG) << "Unable to load image" << dir.path() + QLatin1Char('/') + fileName;
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Signature::EmbeddedImagePtr &image : qAsConst(embeddedImages)) {
            textEdit->composerControler()->composerImages()->loadImage(image->image, image->name, image->name);
        }
```

#### AUTO 


```{c}
const auto var = property(QLatin1String(s_autocryptEnabled));
```

#### AUTO 


```{c}
auto actionCollection = new KActionCollection(q);
```

#### AUTO 


```{c}
auto *page_vlay = new QVBoxLayout(page);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &fileName : lst) {
            if (fileName.toLower().endsWith(QLatin1String(".png"))) {
                qCDebug(KIDENTITYMANAGEMENT_LOG) << "Deleting old image" << dir.path() + fileName;
                dir.remove(fileName);
            }
        }
```

#### AUTO 


```{c}
auto page = new QWidget(widgetStack);
```

#### AUTO 


```{c}
auto job = new KIO::OpenUrlJob(QUrl::fromLocalFile(url), QStringLiteral("text/plain"));
```

#### AUTO 


```{c}
auto *vlay = new QVBoxLayout(q);
```

