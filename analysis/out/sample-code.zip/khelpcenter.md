#### RANGE FOR STATEMENT 


```{c}
for (QAction *act : actions) {
        actionCollection()->addAction(act->objectName(), act);
    }
```

#### AUTO 


```{c}
auto iter = s_menuItemsMap.find(entry->url());
```

#### RANGE FOR STATEMENT 


```{c}
for ( const Range &range : qAsConst(docRanges) ) {
      stream << mText.mid( range.first, range.second - range.first + 1 );
    }
```

#### AUTO 


```{c}
const auto entryList = d.entryList( QStringList( QStringLiteral("*.desktop") ), QDir::Files );
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString& dir : resourceDirs) {
      QDir d(dir);
      const auto entryList = d.entryList( QStringList( QStringLiteral("*.desktop") ), QDir::Files );
      for ( const QString& entry : entryList  ) {
          resources += dir + entry;
      }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString &path : qAsConst(localDoc) ) {
    walkFiles( path, std_lang, db, xgen, &handledDocuments );
  }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString& name : qAsConst(docsToAdd) ) {
      const Xapian::Document doc = createDocument( xgen, uid, lang, std_modTime, name, cr.document( name ) );
      const Xapian::docid id = db.add_document( doc );
      handledDocuments->insert( id );
    }
```

#### AUTO 


```{c}
auto *job = new KIO::OpenUrlJob(QUrl(url));
```

#### AUTO 


```{c}
auto *bookmenu = new KBookmarkMenu( manager, owner, actmenu->menu());
```

#### RANGE FOR STATEMENT 


```{c}
for ( DocEntry *entry : entries ) {
    if ( mSearchEngine->needsIndex( entry ) ) {
      mIndexingQueue.append( entry );
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QFileInfo &fi : entryInfoList )
  {
    DocEntry *entry = nullptr;
    if ( fi.isDir() ) 
    {
      DocEntry *dirEntry = addDirEntry( QDir( fi.absoluteFilePath() ), parent );
      entry = scanMetaInfoDir( fi.absoluteFilePath(), dirEntry );
    } 
    else if ( fi.suffix() == QLatin1String("desktop") )
    {
      entry = addDocEntry( fi );
      if ( parent && entry ) parent->addChild( entry );
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString& entry : entryList  ) {
          resources += dir + entry;
      }
```

#### AUTO 


```{c}
auto iter = s_menuItemsMap.find(entry()->url());
```

#### AUTO 


```{c}
const auto entryInfoList = dir.entryInfoList(QDir::Dirs | QDir::Files | QDir::NoDotAndDotDot);
```

#### RANGE FOR STATEMENT 


```{c}
for ( const GlossaryEntryXRef &xref : entrySeeAlso )
  {
    seeAlso += QStringLiteral( "<a href=\"glossentry:%1\">%2</a>" ).arg( xref.id(), xref.term() );
  }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const Iter& it : results )
  {
    QVariantHash h;
    h.insert( QStringLiteral("title"), it.first->name() );
    h.insert( QStringLiteral("content"), it.second );
    list += h;
  }
```

#### AUTO 


```{c}
const auto actions = mDoc->actionCollection()->actions();
```

#### RANGE FOR STATEMENT 


```{c}
for ( InfoCategoryItem *item : qAsConst(alphabSections) ) {
    item->sortChildren( 0, Qt::AscendingOrder );
  }
```

#### RANGE FOR STATEMENT 


```{c}
for ( Xapian::docid id : qAsConst(docsToRemove) ) {
      db.delete_document( id );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString& word : splitlist ) {
    wordlist.append( word.toStdString() );
  }
```

#### AUTO 


```{c}
auto iter = s_menuItemsMap.find(expanded_url.toString());
```

