#### RANGE FOR STATEMENT 


```{c}
for(const QChar &c : in)
	{
		if(c == '\\')
			out += "\\\\";
		else if(c == ':')
			out += "\\c";
		else if(c == ',')
			out += "\\o";
		else if(c == '\n')
			out += "\\n";
		else
			out += c;
	}
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString &dirIt : dirs)
	{
#ifdef DEVELOPER_MODE
		logDebug(QString("Checking QCA build tree Path: %1").arg(QDir::toNativeSeparators(dirIt)));
#else
		logDebug(QString("Checking Qt Library Path: %1").arg(QDir::toNativeSeparators(dirIt)));
#endif
		QDir libpath(dirIt);
		QDir dir(libpath.filePath(PLUGIN_SUBDIR));
		if(!dir.exists())
		{
			logDebug("  (No 'crypto' subdirectory)");
			continue;
		}

		QStringList entryList = dir.entryList(QDir::Files);
		if(entryList.isEmpty())
		{
			logDebug("  (No files in 'crypto' subdirectory)");
			continue;
		}

		foreach(const QString &maybeFile, entryList)
		{
			QFileInfo fi(dir.filePath(maybeFile));

			QString filePath = fi.filePath(); // file name with path
			QString fileName = fi.fileName(); // just file name

			if(!QLibrary::isLibrary(filePath))
			{
				logDebug(QString("  %1: not a library, skipping").arg(fileName));
				continue;
			}

			// make sure we haven't loaded this file before
			bool haveFile = false;
			for(int n = 0; n < providerItemList.count(); ++n)
			{
				ProviderItem *pi = providerItemList[n];
				if(!pi->fname.isEmpty() && pi->fname == filePath)
				{
					haveFile = true;
					break;
				}
			}
			if(haveFile)
			{
				logDebug(QString("  %1: already loaded file, skipping").arg(fileName));
				continue;
			}

			QString errstr;
			ProviderItem *i = ProviderItem::load(filePath, &errstr);
			if(!i)
			{
				logDebug(QString("  %1: %2").arg(fileName, errstr));
				continue;
			}

			QString className = QString::fromLatin1(i->objectInstance()->metaObject()->className());

			QString providerName = i->p->name();
			if(haveAlready(providerName))
			{
				logDebug(QString("  %1: (class: %2, as %3) already loaded provider, skipping").arg(fileName, className, providerName));
				delete i;
				continue;
			}

			int ver = i->p->qcaVersion();
			if(!validVersion(ver))
			{
				errstr = QString::asprintf("plugin version 0x%06x is in the future", ver);
				logDebug(QString("  %1: (class: %2, as %3) %4").arg(fileName, className, providerName, errstr));
				delete i;
				continue;
			}

			if(skip_plugins(def).contains(providerName))
			{
				logDebug(QString("  %1: (class: %2, as %3) explicitly disabled, skipping").arg(fileName, className, providerName));
				delete i;
				continue;
			}

			addItem(i, get_default_priority(providerName));
			logDebug(QString("  %1: (class: %2) loaded as %3").arg(fileName, className, providerName));
		}
	}
```

#### LAMBDA EXPRESSION 


```{c}
[](BIGNUM *pointer) {
    if (pointer)
        BN_free((BIGNUM *)pointer);
}
```

#### RANGE FOR STATEMENT 


```{c}
for(const QChar &c : hex)
	{
		if(c != ' ')
			str += c;
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (auto n : desWeakKeyTable) {
        if (memcmp(workingCopy.data(), n, 8) == 0)
            return true;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Allocator *mod_alloc : mod_allocs)
        add_allocator(mod_alloc);
```

#### AUTO 


```{c}
const auto  len = OBJ_obj2txt((char *)buf.data(), buf.size(), pol->policyid, 1);
```

#### RANGE FOR STATEMENT 


```{c}
for(const QChar &c : in)
	{
		if(c == QLatin1Char('\\'))
			out += QStringLiteral("\\\\");
		else if(c == QLatin1Char('\n'))
			out += QStringLiteral("\\n");
		else
			out += c;
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const CertificateInfoPair &p : subjectInfo) {
            const CertificateInfoType type = p.type();
            if (type == IPAddress || type == DNS || type == CommonName) {
                if (cert_match_ipaddress(p.value(), ipaddr))
                    return true;
            }
        }
```

#### AUTO 


```{c}
const auto metatype = methodReturnType(obj->metaObject(), method, argTypes);
```

#### RANGE FOR STATEMENT 


```{c}
for ( AbstractLogDevice *logger : qAsConst( m_loggers ) )
		{
			logger->logTextMessage( message, severity );
		}
```

#### RANGE FOR STATEMENT 


```{c}
for(QCA::Provider *provider : providers)
		providersToTest << provider->name();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &cipher : qAsConst(list)) {
                const std::string bothanCipher = qcaCipherToBotanCipher(cipher);
                try {
                    std::unique_ptr<Botan::Keyed_Filter> enc(Botan::get_cipher(bothanCipher, Botan::ENCRYPTION));
                    std::unique_ptr<Botan::Keyed_Filter> dec(Botan::get_cipher(bothanCipher, Botan::DECRYPTION));
                    supported += cipher;
                } catch (Botan::Exception &e) {
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QCA::Provider *provider : qcaProviders) {
	// each provider has a name, which we can display
	std::cout << provider->name().toLatin1().data() << ": ";
	// ... and also a list of features
	QStringList capabilities = provider->features();
	// we turn the string list back into a single string,
	// and display it as well
	std::cout << capabilities.join(", ").toLatin1().data() << std::endl;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](DSA *pointer) {
    if (pointer)
        DSA_free((DSA *)pointer);
}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &cipher : qAsConst(list)) {
		const std::string bothanCipher = qcaCipherToBotanCipher(cipher);
		try {
		    std::unique_ptr<Botan::Keyed_Filter> enc(Botan::get_cipher(bothanCipher, Botan::ENCRYPTION));
		    std::unique_ptr<Botan::Keyed_Filter> dec(Botan::get_cipher(bothanCipher, Botan::DECRYPTION));
		    supported += cipher;
		} catch (Botan::Exception& e) {
		}
	    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QChar &c : in) {
        if (c == QLatin1Char('\\'))
            out += QStringLiteral("\\\\");
        else if (c == QLatin1Char(':'))
            out += QStringLiteral("\\c");
        else
            out += c;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const char c : hex) {
        if (c != ' ')
            str += QLatin1Char(c);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QChar &c : in)
	{
		if(!c.isDigit() && c != '.')
			return false;
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const char ac : a) {
            c = dehex(ac);
            if (c == -1) {
                _ok = false;
                break;
            }
            if (flag) {
                lo         = (uchar)c;
                uchar full = ((hi & 0x0f) << 4) + (lo & 0x0f);
                out[at++]  = full;
                flag       = false;
            } else {
                hi   = (uchar)c;
                flag = true;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QChar &c : in) {
        if (c == QLatin1Char('\\'))
            out += QLatin1String("\\\\");
        else if (c == QLatin1Char(':'))
            out += QLatin1String("\\c");
        else if (c == QLatin1Char(','))
            out += QLatin1String("\\o");
        else if (c == QLatin1Char('\n'))
            out += QLatin1String("\\n");
        else
            out += c;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto n : desWeakKeyTable)
	{
		if(memcmp(workingCopy.data(), n, 8) == 0)
			return true;
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (QCA::Provider *provider : providers)
        providersToTest << provider->name();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QChar &c : in) {
        if (c == QLatin1Char('\\'))
            out += QStringLiteral("\\\\");
        else if (c == QLatin1Char('\n'))
            out += QStringLiteral("\\n");
        else
            out += c;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const CertificateInfoPair &p : subjectInfo) {
            const CertificateInfoType type = p.type();
            if (type == DNS || type == CommonName) {
                if (cert_match_domain(p.value(), name))
                    return true;
            }
        }
```

#### AUTO 


```{c}
static const auto RsaDeleter = [](RSA *pointer) {
    if (pointer)
        RSA_free((RSA *)pointer);
};
```

#### RANGE FOR STATEMENT 


```{c}
for (char &n : buf)
                n = std::rand();
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString &s : b)
	{
		if(!a->contains(s))
			a->append(s);
	}
```

#### RANGE FOR STATEMENT 


```{c}
for(QCA::Provider *provider : providers)
        providersToTest << provider->name();
```

#### RANGE FOR STATEMENT 


```{c}
for(const char ac : a)
		{
			uchar lo = (uchar)ac & 0x0f;
			uchar hi = (uchar)ac >> 4;
			c = enhex(hi);
			if(c == -1)
			{
				_ok = false;
				break;
			}
			out[at++] = (char)c;
			c = enhex(lo);
			if(c == -1)
			{
				_ok = false;
				break;
			}
			out[at++] = (char)c;
		}
```

#### RANGE FOR STATEMENT 


```{c}
for(const QChar &c : in)
	{
		if(c == '\\')
			out += "\\\\";
		else if(c == ':')
			out += "\\c";
		else
			out += c;
	}
```

#### AUTO 


```{c}
const auto arg = QVariant::fromValue<PGPKey>(key);
```

#### RANGE FOR STATEMENT 


```{c}
for(QCA::Provider *provider : QCA::providers())
		providersToTest << provider->name();
```

#### RANGE FOR STATEMENT 


```{c}
for(const QChar &c : in)
	{
		if(!c.isDigit() && c != QLatin1Char('.'))
			return false;
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &hash : qAsConst(list)) {
		std::unique_ptr<BotanHashContext> hashContext(new BotanHashContext(nullptr, hash));
		if (hashContext->isOk()) {
		    supported << hash;
		}
	    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const char c : hex)
	{
		if(c != ' ')
			str += QLatin1Char(c);
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &cipher : qAsConst(list)) {
		std::string algoName, algoMode, algoPadding;
		qcaCipherToBotanCipher(cipher, &algoName, &algoMode, &algoPadding);
		try {
		    std::unique_ptr<Botan::Keyed_Filter> enc(Botan::get_cipher(algoName+'/'+algoMode+'/'+algoPadding, Botan::ENCRYPTION)); // NOLINT(performance-inefficient-string-concatenation)
		    std::unique_ptr<Botan::Keyed_Filter> dec(Botan::get_cipher(algoName+'/'+algoMode+'/'+algoPadding, Botan::DECRYPTION)); // NOLINT(performance-inefficient-string-concatenation)
		    supported += cipher;
		} catch (Botan::Exception& e) {
		}
	    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &s : b) {
        if (!a->contains(s))
            a->append(s);
    }
```

#### AUTO 


```{c}
static const auto DsaDeleter = [](DSA *pointer) {
    if (pointer)
        DSA_free((DSA *)pointer);
};
```

#### RANGE FOR STATEMENT 


```{c}
for (const QCA::Provider *provider : qcaProviders) {
	// each provider has a name, which we can display
	std::cout << provider->name().toLatin1().data() << ": ";
	// ... and also a list of features
	QStringList capabilities = provider->features();
	// we turn the string list back into a single string,
	// and display it as well
	std::cout << capabilities.join(QStringLiteral(", ")).toLatin1().data() << std::endl;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        // set the pipes to be inheritable
        for (int n = 0; n < pipeList.count(); ++n)
            ::fcntl(pipeList[n], F_SETFD, (::fcntl(pipeList[n], F_GETFD) & ~FD_CLOEXEC));
    }
```

#### AUTO 


```{c}
auto n
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString &dirIt : dirs)
	{
#ifdef DEVELOPER_MODE
		logDebug(QStringLiteral("Checking QCA build tree Path: %1").arg(QDir::toNativeSeparators(dirIt)));
#else
		logDebug(QStringLiteral("Checking Qt Library Path: %1").arg(QDir::toNativeSeparators(dirIt)));
#endif
		QDir libpath(dirIt);
		QDir dir(libpath.filePath(PLUGIN_SUBDIR));
		if(!dir.exists())
		{
			logDebug(QStringLiteral("  (No 'crypto' subdirectory)"));
			continue;
		}

		const QStringList entryList = dir.entryList(QDir::Files);
		if(entryList.isEmpty())
		{
			logDebug(QStringLiteral("  (No files in 'crypto' subdirectory)"));
			continue;
		}

		foreach(const QString &maybeFile, entryList)
		{
			QFileInfo fi(dir.filePath(maybeFile));

			QString filePath = fi.filePath(); // file name with path
			QString fileName = fi.fileName(); // just file name

			if(!QLibrary::isLibrary(filePath))
			{
				logDebug(QStringLiteral("  %1: not a library, skipping").arg(fileName));
				continue;
			}

			// make sure we haven't loaded this file before
			bool haveFile = false;
			for(int n = 0; n < providerItemList.count(); ++n)
			{
				ProviderItem *pi = providerItemList[n];
				if(!pi->fname.isEmpty() && pi->fname == filePath)
				{
					haveFile = true;
					break;
				}
			}
			if(haveFile)
			{
				logDebug(QStringLiteral("  %1: already loaded file, skipping").arg(fileName));
				continue;
			}

			QString errstr;
			ProviderItem *i = ProviderItem::load(filePath, &errstr);
			if(!i)
			{
				logDebug(QStringLiteral("  %1: %2").arg(fileName, errstr));
				continue;
			}

			QString className = QString::fromLatin1(i->objectInstance()->metaObject()->className());

			QString providerName = i->p->name();
			if(haveAlready(providerName))
			{
				logDebug(QStringLiteral("  %1: (class: %2, as %3) already loaded provider, skipping").arg(fileName, className, providerName));
				delete i;
				continue;
			}

			int ver = i->p->qcaVersion();
			if(!validVersion(ver))
			{
				errstr = QString::asprintf("plugin version 0x%06x is in the future", ver);
				logDebug(QStringLiteral("  %1: (class: %2, as %3) %4").arg(fileName, className, providerName, errstr));
				delete i;
				continue;
			}

			if(skip_plugins(def).contains(providerName))
			{
				logDebug(QStringLiteral("  %1: (class: %2, as %3) explicitly disabled, skipping").arg(fileName, className, providerName));
				delete i;
				continue;
			}

			addItem(i, get_default_priority(providerName));
			logDebug(QStringLiteral("  %1: (class: %2) loaded as %3").arg(fileName, className, providerName));
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for(const char ac : a)
		{
			c = dehex(ac);
			if(c == -1)
			{
				_ok = false;
				break;
			}
			if(flag)
			{
				lo = (uchar)c;
				uchar full = ((hi & 0x0f) << 4) + (lo & 0x0f);
				out[at++] = full;
				flag = false;
			}
			else
			{
				hi = (uchar)c;
				flag = true;
			}
		}
```

#### RANGE FOR STATEMENT 


```{c}
for(char &n : buf)
				n = qrand();
```

#### RANGE FOR STATEMENT 


```{c}
for (char &n : buf)
                n = qrand();
```

#### RANGE FOR STATEMENT 


```{c}
for(const QChar &c : in)
	{
		if(c == '\\')
			out += "\\\\";
		else if(c == '\n')
			out += "\\n";
		else
			out += c;
	}
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString &dirIt : dirs)
	{
#ifdef DEVELOPER_MODE
		logDebug(QStringLiteral("Checking QCA build tree Path: %1").arg(QDir::toNativeSeparators(dirIt)));
#else
		logDebug(QStringLiteral("Checking Qt Library Path: %1").arg(QDir::toNativeSeparators(dirIt)));
#endif
		QDir libpath(dirIt);
		QDir dir(libpath.filePath(PLUGIN_SUBDIR));
		if(!dir.exists())
		{
			logDebug(QStringLiteral("  (No 'crypto' subdirectory)"));
			continue;
		}

		const QStringList entryList = dir.entryList(QDir::Files);
		if(entryList.isEmpty())
		{
			logDebug(QStringLiteral("  (No files in 'crypto' subdirectory)"));
			continue;
		}

		foreach(const QString &maybeFile, entryList)
		{
			const QFileInfo fi(dir.filePath(maybeFile));

			const QString filePath = fi.filePath(); // file name with path
			const QString fileName = fi.fileName(); // just file name

			if(!QLibrary::isLibrary(filePath))
			{
				logDebug(QStringLiteral("  %1: not a library, skipping").arg(fileName));
				continue;
			}

			// make sure we haven't loaded this file before
			bool haveFile = false;
			for(int n = 0; n < providerItemList.count(); ++n)
			{
				ProviderItem *pi = providerItemList[n];
				if(!pi->fname.isEmpty() && pi->fname == filePath)
				{
					haveFile = true;
					break;
				}
			}
			if(haveFile)
			{
				logDebug(QStringLiteral("  %1: already loaded file, skipping").arg(fileName));
				continue;
			}

			QString errstr;
			ProviderItem *i = ProviderItem::load(filePath, &errstr);
			if(!i)
			{
				logDebug(QStringLiteral("  %1: %2").arg(fileName, errstr));
				continue;
			}

			const QString className = QString::fromLatin1(i->objectInstance()->metaObject()->className());

			const QString providerName = i->p->name();
			if(haveAlready(providerName))
			{
				logDebug(QStringLiteral("  %1: (class: %2, as %3) already loaded provider, skipping").arg(fileName, className, providerName));
				delete i;
				continue;
			}

			const int ver = i->p->qcaVersion();
			if(!validVersion(ver))
			{
				errstr = QString::asprintf("plugin version 0x%06x is in the future", ver);
				logDebug(QStringLiteral("  %1: (class: %2, as %3) %4").arg(fileName, className, providerName, errstr));
				delete i;
				continue;
			}

			if(skip_plugins(def).contains(providerName))
			{
				logDebug(QStringLiteral("  %1: (class: %2, as %3) explicitly disabled, skipping").arg(fileName, className, providerName));
				delete i;
				continue;
			}

			addItem(i, get_default_priority(providerName));
			logDebug(QStringLiteral("  %1: (class: %2) loaded as %3").arg(fileName, className, providerName));
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QCA::Provider *provider : qcaProviders) {
        // each provider has a name, which we can display
        std::cout << provider->name().toLatin1().data() << ": ";
        // ... and also a list of features
        QStringList capabilities = provider->features();
        // we turn the string list back into a single string,
        // and display it as well
        std::cout << capabilities.join(QStringLiteral(", ")).toLatin1().data() << std::endl;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &dirIt : dirs) {
#ifdef DEVELOPER_MODE
        logDebug(QStringLiteral("Checking QCA build tree Path: %1").arg(QDir::toNativeSeparators(dirIt)));
#else
        logDebug(QStringLiteral("Checking Qt Library Path: %1").arg(QDir::toNativeSeparators(dirIt)));
#endif
        QDir libpath(dirIt);
        QDir dir(libpath.filePath(PLUGIN_SUBDIR));
        if (!dir.exists()) {
            logDebug(QStringLiteral("  (No 'crypto' subdirectory)"));
            continue;
        }

        const QStringList entryList = dir.entryList(QDir::Files);
        if (entryList.isEmpty()) {
            logDebug(QStringLiteral("  (No files in 'crypto' subdirectory)"));
            continue;
        }

        foreach (const QString &maybeFile, entryList) {
            const QFileInfo fi(dir.filePath(maybeFile));

            const QString filePath = fi.filePath(); // file name with path
            const QString fileName = fi.fileName(); // just file name

            if (!QLibrary::isLibrary(filePath)) {
                logDebug(QStringLiteral("  %1: not a library, skipping").arg(fileName));
                continue;
            }

            // make sure we haven't loaded this file before
            bool haveFile = false;
            for (int n = 0; n < providerItemList.count(); ++n) {
                ProviderItem *pi = providerItemList[n];
                if (!pi->fname.isEmpty() && pi->fname == filePath) {
                    haveFile = true;
                    break;
                }
            }
            if (haveFile) {
                logDebug(QStringLiteral("  %1: already loaded file, skipping").arg(fileName));
                continue;
            }

            QString       errstr;
            ProviderItem *i = ProviderItem::load(filePath, &errstr);
            if (!i) {
                logDebug(QStringLiteral("  %1: %2").arg(fileName, errstr));
                continue;
            }

            const QString className = QString::fromLatin1(i->objectInstance()->metaObject()->className());

            const QString providerName = i->p->name();
            if (haveAlready(providerName)) {
                logDebug(QStringLiteral("  %1: (class: %2, as %3) already loaded provider, skipping")
                             .arg(fileName, className, providerName));
                delete i;
                continue;
            }

            const int ver = i->p->qcaVersion();
            if (!validVersion(ver)) {
                errstr = QString::asprintf("plugin version 0x%06x is in the future", ver);
                logDebug(QStringLiteral("  %1: (class: %2, as %3) %4").arg(fileName, className, providerName, errstr));
                delete i;
                continue;
            }

            if (skip_plugins(def).contains(providerName)) {
                logDebug(QStringLiteral("  %1: (class: %2, as %3) explicitly disabled, skipping")
                             .arg(fileName, className, providerName));
                delete i;
                continue;
            }

            addItem(i, get_default_priority(providerName));
            logDebug(QStringLiteral("  %1: (class: %2) loaded as %3").arg(fileName, className, providerName));
        }
    }
```

#### AUTO 


```{c}
const auto arg = QVariant::fromValue<CRL>(crl);
```

#### AUTO 


```{c}
static const auto BnDeleter = [](BIGNUM *pointer) {
    if (pointer)
        BN_free((BIGNUM *)pointer);
};
```

#### RANGE FOR STATEMENT 


```{c}
for(const QChar &c : in)
	{
		if(c == QLatin1Char('\\'))
			out += QStringLiteral("\\\\");
		else if(c == QLatin1Char(':'))
			out += QStringLiteral("\\c");
		else
			out += c;
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &hash : qAsConst(list)) {
                std::unique_ptr<BotanHashContext> hashContext(new BotanHashContext(nullptr, hash));
                if (hashContext->isOk()) {
                    supported << hash;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for(const CertificateInfoPair &p : subjectInfo)
		{
			const CertificateInfoType type = p.type();
			if (type == DNS || type == CommonName)
			{
				if(cert_match_domain(p.value(), name))
					return true;
			}
		}
```

#### RANGE FOR STATEMENT 


```{c}
for(QCA::Provider *provider : QCA::providers())
        providersToTest << provider->name();
```

#### RANGE FOR STATEMENT 


```{c}
for ( AbstractLogDevice *logger : qAsConst( m_loggers ) )
		{
			logger->logBinaryMessage( blob, severity );
		}
```

#### RANGE FOR STATEMENT 


```{c}
for(const CertificateInfoPair &p : subjectInfo)
		{
			const CertificateInfoType type = p.type();
			if (type == IPAddress || type == DNS || type == CommonName)
			{
				if(cert_match_ipaddress(p.value(), ipaddr))
					return true;
			}
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &cipher : qAsConst(list)) {
		std::string algoName, algoMode, algoPadding;
		qcaCipherToBotanCipher(cipher, &algoName, &algoMode, &algoPadding);
		try {
		    std::unique_ptr<Botan::Keyed_Filter> enc(Botan::get_cipher(algoName+'/'+algoMode+'/'+algoPadding, Botan::ENCRYPTION));
		    std::unique_ptr<Botan::Keyed_Filter> dec(Botan::get_cipher(algoName+'/'+algoMode+'/'+algoPadding, Botan::DECRYPTION));
		    supported += cipher;
		} catch (Botan::Exception& e) {
		}
	    }
```

#### AUTO 


```{c}
const auto arg = QVariant::fromValue<Certificate>(cert);
```

#### LAMBDA EXPRESSION 


```{c}
[](RSA *pointer) {
    if (pointer)
        RSA_free((RSA *)pointer);
}
```

#### RANGE FOR STATEMENT 


```{c}
for(const QChar &c : in)
	{
		if(c == QLatin1Char('\\'))
			out += QLatin1String("\\\\");
		else if(c == QLatin1Char(':'))
			out += QLatin1String("\\c");
		else if(c == QLatin1Char(','))
			out += QLatin1String("\\o");
		else if(c == QLatin1Char('\n'))
			out += QLatin1String("\\n");
		else
			out += c;
	}
```

#### AUTO 


```{c}
const auto providers = QCA::providers();
```

#### AUTO 


```{c}
const auto arg = QVariant::fromValue<KeyBundle>(kb);
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractLogDevice *logger : qAsConst(m_loggers)) {
            logger->logBinaryMessage(blob, severity);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractLogDevice *logger : qAsConst(m_loggers)) {
            logger->logTextMessage(message, severity);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QChar &c : in) {
        if (!c.isDigit() && c != QLatin1Char('.'))
            return false;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const std::pair<void *, u32bit> &p : allocated)
        dealloc_block(p.first, p.second);
```

#### RANGE FOR STATEMENT 


```{c}
for (Allocator *allocator : allocators) {
        allocator->destroy();
        delete allocator;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const char ac : a) {
            uchar lo = (uchar)ac & 0x0f;
            uchar hi = (uchar)ac >> 4;
            c        = enhex(hi);
            if (c == -1) {
                _ok = false;
                break;
            }
            out[at++] = (char)c;
            c         = enhex(lo);
            if (c == -1) {
                _ok = false;
                break;
            }
            out[at++] = (char)c;
        }
```

