#### AUTO 


```{c}
auto formatLayout = new QHBoxLayout(formatGroupBox);
```

#### AUTO 


```{c}
auto typeIdx = static_cast<unsigned>(action.m_type);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QPersistentModelIndex& index : selectedIndexes) {
    TaggedFile* taggedFile = FileProxyModel::getTaggedFileOfIndex(index);
    QString absFilename, dirName, fileName;
    if (taggedFile) {
      absFilename = taggedFile->getAbsFilename();
      dirName = taggedFile->getDirname();
      fileName = taggedFile->getFilename();
    } else {
      QFileInfo fi(model->fileInfo(index));
      absFilename = fi.filePath();
      dirName = fi.dir().path();
      fileName = fi.fileName();
    }
    bool ok;
    QString newFileName = QInputDialog::getText(
      m_w,
      tr("Rename File"),
      tr("Enter new file name:"),
      QLineEdit::Normal, fileName, &ok);
    if (ok && !newFileName.isEmpty() && newFileName != fileName) {
      if (taggedFile) {
        if (taggedFile->isChanged()) {
          taggedFile->setFilename(newFileName);
          if (selItems.size() == 1)
            m_form->setFilename(newFileName);
          continue;
        }
        // This will close the file.
        // The file must be closed before renaming on Windows.
        taggedFile->closeFileHandle();
      } else if (model->isDir(index)) {
        // The directory must be closed before renaming on Windows.
        TaggedFileIterator::closeFileHandles(index);
      }
      QString newPath = dirName + QLatin1Char('/') + newFileName;
      if (model->rename(index, newFileName)) {
        if (taggedFile) {
          taggedFile->updateCurrentFilename();
          if (selItems.size() == 1) {
            m_form->setFilename(newFileName);
          }
        }
      } else {
#ifdef Q_OS_WIN32
        if (QMessageBox::warning(
              0, tr("File Error"),
              tr("Error while renaming:\n") +
              tr("Rename %1 to %2 failed\n").arg(fileName).arg(newFileName) +
              tr("Retry after closing folders?"),
              QMessageBox::Ok, QMessageBox::Cancel) == QMessageBox::Ok) {
          m_app->tryRenameAfterReset(absFilename, newPath);
        }
#else
        QMessageBox::warning(
          nullptr, tr("File Error"),
          tr("Error while renaming:\n") +
          tr("Rename %1 to %2 failed\n").arg(fileName, newFileName),
          QMessageBox::Ok, Qt::NoButton);
#endif
      }
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (IUserCommandProcessor* userCommandProcessor : userCommandProcessors) {
    userCommandProcessor->cleanup();
  }
```

#### AUTO 


```{c}
auto fdIt = fdre.globalMatch(text);
```

#### AUTO 


```{c}
auto it = frames.cbegin();
```

#### AUTO 


```{c}
auto customFramesVBox = new QVBoxLayout;
```

#### AUTO 


```{c}
auto selected = m_quickAccessTagsModel->data(
          index, Qt::CheckStateRole).toInt() == Qt::Checked;
```

#### AUTO 


```{c}
auto name = map.value(QLatin1String("name")).toString();
```

#### AUTO 


```{c}
auto helpAboutQt = new QAction(this);
```

#### AUTO 


```{c}
auto thisIt = m_fieldList.constBegin(), otherIt = otherFieldList.constBegin();
```

#### AUTO 


```{c}
const auto dataValue = doc.object().value(QLatin1String("data"));
```

#### AUTO 


```{c}
auto writeInfoLayout = new QHBoxLayout;
```

#### AUTO 


```{c}
auto it = m_frames.findByName(name);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& index : selectedIndexes) {
    m_currentSelection.append(QPersistentModelIndex(index));
  }
```

#### AUTO 


```{c}
auto rightHalfLayout = new QVBoxLayout(m_rightHalfVBox);
```

#### AUTO 


```{c}
auto it = idTitleRe.globalMatch(str);
```

#### AUTO 


```{c}
auto it = m_currentSelection.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVariant& var : lst) {
    const QVariantMap map = var.toMap();
    QString propsStr = map.value(QLatin1String("selected")).toBool()
        ? QLatin1String(">") : QLatin1String(" ");
    propsStr +=
        (map.value(QLatin1String("changed")).toBool() ? QLatin1String("*") : QLatin1String(" "));
    if (map.contains(QLatin1String("tags"))) {
      const QVariantList tags = map.value(QLatin1String("tags")).toList();
      FOR_ALL_TAGS(tagNr) {
        propsStr += tags.contains(1 + tagNr)
            ? QLatin1Char('1' + tagNr) : QLatin1Char('-');
      }
    } else {
      propsStr += QString(Frame::Tag_NumValues, QLatin1Char(' '));
    }
    io->writeLine(propsStr + QString(indent, QLatin1Char(' ')) +
                    map.value(QLatin1String("fileName")).toString());
    if (map.contains(QLatin1String("files"))) {
      printFiles(io, map.value(QLatin1String("files")).toList(), indent + 2);
    }
  }
```

#### AUTO 


```{c}
auto it = m_taggedFiles.constFind(taggedFileIdx);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& namesPart : names) {
        if (!name.isEmpty()) {
          name += QLatin1String(", ");
        }
        name += fixUpArtist(namesPart);
      }
```

#### AUTO 


```{c}
auto srcModel = qobject_cast<QFileSystemModel*>(sourceModel());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& filePath : errorFiles) {
      QFileInfo fileInfo(filePath);
      if (!fileInfo.isWritable()) {
        errorMsgs.append(tr("%1 is not writable").arg(fileInfo.fileName()));
        notWritableFiles.append(filePath); // clazy:exclude=reserve-candidates
      } else {
        errorMsgs.append(fileInfo.fileName());
      }
    }
```

#### AUTO 


```{c}
auto it = m_matchPictureUrlMap.constBegin();
```

#### AUTO 


```{c}
auto it = frameAt(index.row());
```

#### AUTO 


```{c}
auto cb = new QComboBox(parent);
```

#### AUTO 


```{c}
const auto &nameFilter
```

#### AUTO 


```{c}
auto it = m_extraFrames.begin();
```

#### AUTO 


```{c}
auto vorbisGroupBoxLayout = new QGridLayout(vorbisGroupBox);
```

#### AUTO 


```{c}
auto it = m_matchPictureUrlMap.begin();
```

#### AUTO 


```{c}
auto apeFile =
                 dynamic_cast<TagLib::APE::File*>(file)
```

#### AUTO 


```{c}
auto it = customNames.constBegin();
```

#### AUTO 


```{c}
auto fileNameFormatLayout = new QHBoxLayout;
```

#### AUTO 


```{c}
auto otherIt = frames.cbegin();
```

#### AUTO 


```{c}
auto model = const_cast<FileProxyModel*>(getFileProxyModel());
```

#### AUTO 


```{c}
auto toolsRenameDirectory = new QAction(this);
```

#### AUTO 


```{c}
auto it = nameTypeMap.constFind(name);
```

#### AUTO 


```{c}
auto model =
            qobject_cast<FileProxyModel*>(m_form->getFileList()->model());
```

#### RANGE FOR STATEMENT 


```{c}
for (const Frame& frame : frames) {
        if (frame.getType() == Frame::FT_Other &&
            frame.getName() == QLatin1String("Chapters")) {
          uint32_t chapterCount = 0;
          MP4Chapter_t* chapterList = nullptr;
          frameToMp4Chapters(frame, chapterList, chapterCount);
          MP4SetChapters(handle, chapterList, chapterCount, MP4ChapterTypeQt);
          hasChapters = true;
          delete [] chapterList;
        } else {
          QByteArray ba;
          if (PictureFrame::getData(frame, ba)) {
#if MPEG4IP_MAJOR_MINOR_VERSION >= 0x0109
            MP4TagArtwork artwork;
            artwork.data = ba.data();
            artwork.size = static_cast<uint32_t>(ba.size());
            artwork.type = MP4_ART_JPEG;
            QString mimeType;
            if (PictureFrame::getMimeType(frame, mimeType)) {
              if (mimeType == QLatin1String("image/png")) {
                artwork.type = MP4_ART_PNG;
              } else if (mimeType == QLatin1String("image/bmp")) {
                artwork.type = MP4_ART_BMP;
              } else if (mimeType == QLatin1String("image/gif")) {
                artwork.type = MP4_ART_GIF;
              }
            }
            MP4TagsAddArtwork(tags, &artwork);
#else
            MP4SetMetadataCoverArt(handle, reinterpret_cast<uint8_t*>(ba.data()),
                                   ba.size());
#endif
          }
        }
      }
```

#### AUTO 


```{c}
const auto importers = m_importers;
```

#### AUTO 


```{c}
auto model =
      qobject_cast<FileProxyModel*>(m_form->getFileList()->model());
```

#### AUTO 


```{c}
const auto keys = oldSettings.allKeys();
```

#### AUTO 


```{c}
auto vspacer = new QSpacerItem(0, 0, QSizePolicy::Minimum, QSizePolicy::Expanding);
```

#### AUTO 


```{c}
auto ait = (*it).second.begin();
```

#### RANGE FOR STATEMENT 


```{c}
for (RenameAction& action : m_actions) {
      for (const auto& replacement : replacements) {
        action.m_src.replace(replacement.first, replacement.second);
        action.m_dest.replace(replacement.first, replacement.second);
      }
      emit actionScheduled(describeAction(action));
    }
```

#### AUTO 


```{c}
const auto factories = taggedFileFactories();
```

#### LAMBDA EXPRESSION 


```{c}
[this, tagNr]() {
      setFocusNextTag(tagNr);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& key : keys) {
        QString newKey(key);
        newKey.replace(QLatin1String("Recent Files"),
                       QLatin1String("RecentFiles"));
        config->setValue(newKey, oldSettings.value(key));
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& uiLang : uiLangs) {
    QString lang(uiLang.left(2));
    docPaths += QDir::currentPath() + QLatin1String("/kid3_") + lang + QLatin1String(".html");
    if (!docDir.isNull()) {
      docPaths += docDir + QLatin1String("/kid3_") + lang + QLatin1String(".html");
    }
  }
```

#### AUTO 


```{c}
auto cbox = new IntComboBoxControl(
                fld, Frame::Field::getTimestampFormatNames());
```

#### AUTO 


```{c}
auto findPreviousButton = new QToolButton(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (QStringList strs : constCmdStrs) {
    QString cmdStr = strs.takeFirst();
    cmdStr += QString(maxLength - cmdStr.size() + 2, QLatin1Char(' ')) %
        strs.takeFirst() % QLatin1Char('\n');
    msg += cmdStr;
    while (!strs.isEmpty()) {
      msg += QString(maxLength + 2, QLatin1Char(' ')) %
          strs.takeFirst() % QLatin1Char('\n');
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& val : subTracks) {
          TrackInfo subTrackInfo(val.toObject());
          subTrackInfo.addToFrames(frames, trackExtraArtists,
                                   standardTags, additionalTags);
          addFramesToTrackData(frames, subTrackInfo.duration());
        }
```

#### AUTO 


```{c}
auto dateTimeMatch = m_re.match(input, 0,
      QRegularExpression::PartialPreferCompleteMatch);
```

#### AUTO 


```{c}
const auto& agn
```

#### RANGE FOR STATEMENT 


```{c}
for (const TimeEvent& timeEvent : timeEvents) {
    if (!timeEvent.time.isNull()) {
      int code = timeEvent.data.toInt();

      quint32 milliseconds;
      if (timeEvent.time.type() == QVariant::Time) {
        hasMsTimeStamps = true;
        milliseconds = QTime(0, 0).msecsTo(timeEvent.time.toTime());
      } else {
        milliseconds = timeEvent.data.toUInt();
      }
      synchedData.append(milliseconds);
      synchedData.append(code);
    }
  }
```

#### AUTO 


```{c}
auto begin = frames.cbegin();
```

#### AUTO 


```{c}
auto it = frame.fieldList().begin();
```

#### AUTO 


```{c}
auto match = yearRe.match(yearStr);
```

#### AUTO 


```{c}
auto match = fdIt.next();
```

#### LAMBDA EXPRESSION 


```{c}
[proc, conn, callback, this](int exitCode) mutable {
#endif
    QObject::disconnect(*conn);
    if (!callback.isUndefined()) {
      QVariantList result{
        exitCode,
        QString::fromLocal8Bit(proc->readAllStandardOutput()),
        QString::fromLocal8Bit(proc->readAllStandardError())
      };
      callback.call({qjsEngine(this)->toScriptValue(result)});
    }
  }
```

#### AUTO 


```{c}
auto vc =
                dynamic_cast<FLAC::Metadata::VorbisComment*>(proto);
```

#### AUTO 


```{c}
auto index = mapFromSource(srcIndex);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& it : idTexts) {
    const char* text1 = it.text1;
    const char* text2 = it.text2;

    QPixmap pixmap(m_requestedSize);
    pixmap.fill(Qt::transparent);
    QPainter painter(&pixmap);
    painter.setFont(font);
    if (text1) {
      painter.setPen(Qt::white);
      painter.drawText(QPoint(2, halfHeight - 1), QLatin1String(text1));
      painter.setPen(Qt::black);
      painter.drawText(QPoint(3, halfHeight), QLatin1String(text1));
    }
    if (text2) {
      if (qstrlen(text2) > 2) {
        painter.setFont(smallFont);
      }
      painter.setPen(Qt::white);
      painter.drawText(QPoint(2, height - 2), QLatin1String(text2));
      painter.setPen(Qt::black);
      painter.drawText(QPoint(3, height - 1), QLatin1String(text2));
    }

    m_pixmapMap.insert(it.id, pixmap);
  }
```

#### AUTO 


```{c}
auto map = doc.object();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& val : trackList) {
    auto track = val.toObject();

    QString position(track.value(QLatin1String("position")).toString());
    bool ok;
    int pos = position.toInt(&ok);
    if (!ok) {
      if (discTrackPosRe.exactMatch(position)) {
        if (additionalTags) {
          frames.setValue(Frame::FT_Disc, discTrackPosRe.cap(1));
        }
        pos = discTrackPosRe.cap(2).toInt();
      } else {
        pos = trackNr;
      }
    }
    QString title(track.value(QLatin1String("title")).toString().trimmed());

    const QStringList durationHms = track.value(QLatin1String("duration"))
        .toString().split(QLatin1Char(':'));
    int duration = 0;
    for (const auto& val : durationHms) {
      duration *= 60;
      duration += val.toInt();
    }
    if (!allPositionsEmpty && position.isEmpty()) {
      if (additionalTags) {
        framesHdr.setValue(Frame::FT_Subtitle, title);
      }
    } else if (!title.isEmpty() || duration != 0) {
      if (standardTags) {
        frames.setTrack(pos);
        frames.setTitle(title);
      }
      const auto artists(track.value(QLatin1String("artists")).toArray());
      if (!artists.isEmpty()) {
        if (standardTags) {
          frames.setArtist(getArtistString(artists));
        }
        if (additionalTags) {
          frames.setValue(Frame::FT_AlbumArtist, framesHdr.getArtist());
        }
      }
      if (additionalTags) {
        const auto extraartists(track.value(QLatin1String("extraartists")).toArray());
        if (!extraartists.isEmpty()) {
          for (const auto& val : extraartists) {
            ExtraArtist extraArtist(val.toObject());
            extraArtist.addToFrames(frames);
          }
        }
      }
      for (const auto& extraArtist : trackExtraArtists) {
        extraArtist.addToFrames(frames, position);
      }

      if (atTrackDataListEnd) {
        ImportTrackData trackData;
        trackData.setFrameCollection(frames);
        trackData.setImportDuration(duration);
        trackDataVector.append(trackData);
      } else {
        while (!atTrackDataListEnd && !it->isEnabled()) {
          ++it;
          atTrackDataListEnd = (it == trackDataVector.end());
        }
        if (!atTrackDataListEnd) {
          (*it).setFrameCollection(frames);
          (*it).setImportDuration(duration);
          ++it;
          atTrackDataListEnd = (it == trackDataVector.end());
        }
      }
      ++trackNr;
    }
    frames = framesHdr;
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (QString txt : paths) {
    int lfPos = txt.indexOf(QLatin1Char('\n'));
    if (lfPos > 0 && lfPos < static_cast<int>(txt.length()) - 1) {
      txt.truncate(lfPos + 1);
    }
    QString dir = txt.trimmed();
    if (!dir.isEmpty()) {
      if (dir.endsWith(QLatin1String(".jpg"), Qt::CaseInsensitive) ||
          dir.endsWith(QLatin1String(".jpeg"), Qt::CaseInsensitive) ||
          dir.endsWith(QLatin1String(".png"), Qt::CaseInsensitive)) {
        picturePaths.append(dir);
      } else {
        filePaths.append(dir);
      }
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray& propertyName : propertyNames) {
    propertiesKv.append(QString::fromLatin1(propertyName));
    propertiesKv.append(property(propertyName).toString());
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& mapping : mappings) {
      QStringList groupKey = QString::fromLatin1(mapping.oldKey).
          split(QLatin1Char('/'));
      beginGroup(groupKey.at(0));
      if (contains(groupKey.at(1))) {
        QVariant val = value(groupKey.at(1), QVariant(mapping.type));
        remove(groupKey.at(1));
        endGroup();
        groupKey = QString::fromLatin1(mapping.newKey).
            split(QLatin1Char('/'));
        beginGroup(groupKey.at(0));
        setValue(groupKey.at(1), val);
        migrated = true;
      }
      endGroup();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& filePath : filePaths) {
      if (!QDir::match(nameFilters, filePath) &&
          !QFileInfo(filePath).isDir()) {
        setAllFilesFileFilter();
        break;
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& pluginName : disabledPlugins) {
      disabledImportPluginFileNames.insert(pluginFileName(pluginName),
                                           pluginName);
    }
```

#### AUTO 


```{c}
auto tag1Layout = new QVBoxLayout(tag1Page);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray& id : ids) {
        if (!id.isEmpty()) {
          it = searchByName(QString::fromLatin1(id));
          if (it != cend()) {
            break;
          }
        }
      }
```

#### AUTO 


```{c}
auto frameIt = frames.find(frame);
```

#### AUTO 


```{c}
auto fileOpen = new QAction(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (IUserCommandProcessor* userCommandProcessor : userCommandProcessors) {
    userCommandProcessor->initialize(m_app);
    connect(userCommandProcessor->qobject(), SIGNAL(commandOutput(QString)), // clazy:exclude=old-style-connect
            this, SLOT(showOutputLine(QString)));
  }
```

#### AUTO 


```{c}
auto it = baseNameComponents.begin();
```

#### AUTO 


```{c}
const auto ftModel =
    qobject_cast<const FrameTableModel*>(model());
```

#### AUTO 


```{c}
const auto constFileIndexes = fileIndexes;
```

#### LAMBDA EXPRESSION 


```{c}
[]() { return &TagFormatConfig::instance(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (QString filter : excludeFolders) {
    filter.replace(QLatin1Char('\\'), QLatin1Char('/'));
    m_excludeFolderFilters.append(
          QRegExp(filter, Qt::CaseInsensitive, QRegExp::Wildcard));
  }
```

#### AUTO 


```{c}
auto engine = qobject_cast<QQmlEngine*>(sender())
```

#### AUTO 


```{c}
auto images = map.value(QLatin1String("images")).toArray();
```

#### AUTO 


```{c}
auto qcarray = new QChar[numChars];
```

#### AUTO 


```{c}
const auto constCmdStrs = cmdStrs;
```

#### AUTO 


```{c}
const auto patternList = patterns.split(sep);
```

#### AUTO 


```{c}
auto name = index.data().toString();
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction* action : actions) {
      if (action) {
        QString name = action->objectName();
        if (!name.isEmpty()) {
          map.insert(name, action->shortcut());
        }
      }
    }
```

#### AUTO 


```{c}
const auto ids = getDisplayNamesOfIds().keys(name.toLatin1());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& filePath : filePaths) {
          QFile::setPermissions(filePath,
              QFile::permissions(filePath) | QFile::WriteUser);
          if (model &&
              (taggedFile = FileProxyModel::getTaggedFileOfIndex(
                 model->index(filePath))) != nullptr) {
            taggedFile->undoRevertChangedFilename();
          }
        }
```

#### AUTO 


```{c}
auto fnGroupBox = new QGroupBox(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (Frame::TagNumber tagNr : Frame::allTagNumbers()) {
      taggedFile->getAllFrames(tagNr, frames);
      result = frames.getValue(type);
      if (!result.isEmpty())
        return result;
    }
```

#### AUTO 


```{c}
auto it = normalized.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& replacement : replacements) {
        action.m_src.replace(replacement.first, replacement.second);
        action.m_dest.replace(replacement.first, replacement.second);
      }
```

#### AUTO 


```{c}
auto compoundWidget =
      qobject_cast<ShortcutsDelegateEditor*>(editor)
```

#### AUTO 


```{c}
auto id3v2Tag = dynamic_cast<TagLib::ID3v2::Tag*>(tag);
```

#### AUTO 


```{c}
auto map = namesSelected.at(row).toMap();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& index : indexes) {
        QDesktopServices::openUrl(
              QUrl::fromLocalFile(fsModel->filePath(index)));
      }
```

#### AUTO 


```{c}
auto it = m_contextMenuCommands.constBegin();
```

#### AUTO 


```{c}
auto it = filters.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QPersistentModelIndex& index : indexes) {
    if (const FileProxyModel* model =
        qobject_cast<const FileProxyModel*>(index.model())) {
      QString filePath = model->filePath(index);
      PlaylistCreator::Entry entry;
      entry.filePath = m_cfg.useFullPath()
          ? filePath
          : playlistDir.relativeFilePath(filePath);
      if (m_cfg.writeInfo()) {
        Item(index, *this).getInfo(entry.info, entry.duration);
      }
      entries.append(entry);
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (FileSystemNode *child : constChildren) {
#endif
                //On windows the root (My computer) has no path so we don't want to add a / for nothing (e.g. /C:/)
                if (!path.isEmpty()) {
                    if (path.endsWith(QLatin1Char('/')))
                        child->retranslateStrings(iconProvider, path + child->fileName);
                    else
                        child->retranslateStrings(iconProvider, path + QLatin1Char('/') + child->fileName);
                } else
                    child->retranslateStrings(iconProvider, child->fileName);
            }
```

#### AUTO 


```{c}
auto match = imgSrcRe.match(str);
```

#### AUTO 


```{c}
auto formatLayout = new QFormLayout;
```

#### AUTO 


```{c}
auto it = m_extraFrames.constBegin();
```

#### AUTO 


```{c}
auto formLayout = qobject_cast<QFormLayout*>(layout())
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& mapping : mappings) {
      QStringList groupKey = QString::fromLatin1(mapping.oldKey)
          .split(QLatin1Char('/'));
      beginGroup(groupKey.at(0));
      if (contains(groupKey.at(1))) {
        QVariant val = value(groupKey.at(1), QVariant(mapping.type));
        remove(groupKey.at(1));
        endGroup();
        groupKey = QString::fromLatin1(mapping.newKey)
            .split(QLatin1Char('/'));
        beginGroup(groupKey.at(0));
        setValue(groupKey.at(1), val);
        migrated = true;
      }
      endGroup();
    }
```

#### AUTO 


```{c}
auto kid3 = new KdeMainWindow(platformTools, kid3App);
```

#### AUTO 


```{c}
const auto indexes = m_fileSelectionModel->selectedRows();
```

#### AUTO 


```{c}
auto it = c.find(role);
```

#### AUTO 


```{c}
const auto model =
            qobject_cast<const FileProxyModel*>(index.model())
```

#### AUTO 


```{c}
auto it = re.globalMatch(text);
```

#### AUTO 


```{c}
auto it = frame.getFieldList().constBegin();
```

#### AUTO 


```{c}
const auto dirColumns = guiCfg.dirListVisibleColumns();
```

#### AUTO 


```{c}
auto privFrame =
        new TagLib::ID3v2::PrivateFrame;
```

#### AUTO 


```{c}
auto it = typeNameMap.constFind(type);
```

#### AUTO 


```{c}
auto hlayout = new QHBoxLayout(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto initFrameType : initFrameTypes) {
    newFrameTypes.append( // clazy:exclude=reserve-candidates
        Frame::ExtendedType(static_cast<Frame::Type>(initFrameType), QLatin1String("")));
  }
```

#### AUTO 


```{c}
auto pcGroupBox = new QGroupBox(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
    if (!m_terminating) {
      m_io->cleanup();
    }
  }
```

#### AUTO 


```{c}
auto match = trackNumberRe.match(trackRow);
```

#### AUTO 


```{c}
auto dialog = qobject_cast<PlaylistEditDialog*>(sender())
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& index : indexes) {
      rows.insert(index.row(), 0);
    }
```

#### AUTO 


```{c}
const auto fsModel =
        qobject_cast<const FileProxyModel*>(selModel->model())
```

#### AUTO 


```{c}
auto tdit = trackDuration.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QPersistentModelIndex& index : selectedIndexes) {
    TaggedFile* taggedFile = FileProxyModel::getTaggedFileOfIndex(index);
    QString absFilename, dirName, fileName;
    if (taggedFile) {
      absFilename = taggedFile->getAbsFilename();
      dirName = taggedFile->getDirname();
      fileName = taggedFile->getFilename();
    } else {
      QFileInfo fi(model->fileInfo(index));
      absFilename = fi.filePath();
      dirName = fi.dir().path();
      fileName = fi.fileName();
    }
    bool ok;
    QString newFileName = QInputDialog::getText(
      m_w,
      tr("Rename File"),
      tr("Enter new file name:"),
      QLineEdit::Normal, fileName, &ok);
    if (ok && !newFileName.isEmpty() && newFileName != fileName) {
      if (taggedFile) {
        if (taggedFile->isChanged()) {
          taggedFile->setFilename(newFileName);
          if (selItems.size() == 1)
            m_form->setFilename(newFileName);
          continue;
        }
        // This will close the file.
        // The file must be closed before renaming on Windows.
        taggedFile->closeFileHandle();
      } else if (model->isDir(index)) {
        // The directory must be closed before renaming on Windows.
        TaggedFileIterator::closeFileHandles(index);
      }
      QString newPath = dirName + QLatin1Char('/') + newFileName;
      bool ok = model->rename(index, newFileName);
      if (!ok && !(index.flags() & Qt::ItemIsEditable)) {
        // The file system model seems to be too restrictive, renaming without
        // write permission is possible on Linux, so try again without
        // using the model.
        ok = QFile::rename(absFilename, newPath);
      }
      if (ok) {
        if (taggedFile) {
          taggedFile->updateCurrentFilename();
          if (selItems.size() == 1) {
            m_form->setFilename(newFileName);
          }
        }
      } else {
#ifdef Q_OS_WIN32
        if (QMessageBox::warning(
              0, tr("File Error"),
              tr("Error while renaming:\n") +
              tr("Rename %1 to %2 failed\n").arg(fileName).arg(newFileName) +
              tr("Retry after closing folders?"),
              QMessageBox::Ok, QMessageBox::Cancel) == QMessageBox::Ok) {
          m_app->tryRenameAfterReset(absFilename, newPath);
        }
#else
        QMessageBox::warning(
          nullptr, tr("File Error"),
          tr("Error while renaming:\n") +
          tr("Rename %1 to %2 failed\n").arg(fileName, newFileName),
          QMessageBox::Ok, Qt::NoButton);
#endif
      }
    }
  }
```

#### AUTO 


```{c}
const auto ftModel =
    qobject_cast<const FrameTableModel*>(index.model());
```

#### RANGE FOR STATEMENT 


```{c}
for (auto ic : illegalChars) {
    QChar illegalChar = QLatin1Char(ic);
    if (fileName.contains(illegalChar)) {
      if (!changed) {
        const FormatConfig& fnCfg = FilenameFormatConfig::instance();
        if (fnCfg.strRepEnabled()) {
          replaceMap = fnCfg.strRepMap();
        }
        changed = true;
      }
      QString replacement = replaceMap.value(illegalChar);
      fileName.replace(illegalChar, replacement);
    }
  }
```

#### AUTO 


```{c}
const auto& it
```

#### AUTO 


```{c}
auto it = urls.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& twp : typeOfWmPriv) {
      strNumMap.insert(QString::fromLatin1(twp.str), twp.type);
    }
```

#### AUTO 


```{c}
auto textctl = new TextFieldControl(fld);
```

#### AUTO 


```{c}
auto chapCtl = new ChapterFieldControl(fld);
```

#### AUTO 


```{c}
const auto sectionShortcuts = SectionActions::defaultShortcuts();
```

#### AUTO 


```{c}
const auto& iw
```

#### AUTO 


```{c}
auto match = catIdTitleRe.match(*it);
```

#### AUTO 


```{c}
auto frameIt = frames.begin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& mp4NameTypeValue : mp4NameTypeValues) {
      if (mp4NameTypeValue.type == Frame::FT_Other &&
          mp4NameTypeValue.value != MVT_ByteArray &&
          !(mp4NameTypeValue.name[0] >= 'A' &&
            mp4NameTypeValue.name[0] <= 'Z')) {
        lst.append(QString::fromLatin1(mp4NameTypeValue.name));
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (int theRow : selRows) {
              int r = theRow + offset;
              if (r > mdl->rowCount(index) || r < 0) {
                r = 0;
              }
              mdl->insertRow(r, index);
            }
```

#### AUTO 


```{c}
const auto artists(track.value(QLatin1String("artists")).toArray());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& ts : typeStrOfId) {
      if (ts.type == type) {
        return ts.str;
      }
    }
```

#### AUTO 


```{c}
auto cit = credits.constBegin();
```

#### AUTO 


```{c}
auto it = m_shortcutGroups.begin();
```

#### AUTO 


```{c}
auto ntag = new TagLib::ID3v2::Tag();
```

#### AUTO 


```{c}
auto it = frameCollection.begin();
```

#### AUTO 


```{c}
auto model =
        qobject_cast<BatchImportSourcesModel*>(getItemView()->model())
```

#### AUTO 


```{c}
auto kid3 = new Kid3MainWindow(platformTools, kid3App);
```

#### AUTO 


```{c}
auto quickAccessTagsListView = new QListView;
```

#### RANGE FOR STATEMENT 


```{c}
for (int theRow : newSelRows) {
                int r = theRow + offset;
                if (r > mdl->rowCount(index) || r < 0) {
                  r = 0;
                }
                for (int j = 0; j < mdl->columnCount(index); ++j) {
                  QVariant source = mdl->index(theRow, j, index)
                      .data(m_dropRole);
                  mdl->setData(mdl->index(r, j, index), source, m_dropRole);
                }
              }
```

#### AUTO 


```{c}
auto it = trackData.findByExtendedType(type);
```

#### AUTO 


```{c}
auto leftLayout = new QVBoxLayout;
```

#### AUTO 


```{c}
auto it = roleHash.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Frame& frame : frames) {
            auto pic = new TagLib::FLAC::Picture;
            frameToFlacPicture(frame, pic);
            flacFile->addPicture(pic);
          }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& fileIndex : constFileIndexes) {
      m_fileProxyModelFileIndexes.append(
            m_fileProxyModel->mapFromSource(fileIndex));
    }
```

#### AUTO 


```{c}
const auto model =
        qobject_cast<const FileProxyModel*>(idx.model())
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& val : results) {
      auto result = val.toObject();
      QString title =
          fixUpArtist(result.value(QLatin1String("title")).toString());
      if (!title.isEmpty()) {
        QString year = result.value(QLatin1String("year")).toString().trimmed();
        if (!year.isEmpty()) {
          title += QLatin1String(" (") + year + QLatin1Char(')');
        }
        const auto fmts = result.value(QLatin1String("format")).toArray();
        if (!fmts.isEmpty()) {
          QStringList formats;
          for (const auto& fmt : fmts) {
            QString format = fmt.toString().trimmed();
            if (!format.isEmpty()) {
              formats.append(format);
            }
          }
          if (!formats.isEmpty()) {
            title += QLatin1String(" [") +
                formats.join(QLatin1String(", ")) +
                QLatin1Char(']');
          }
        }
        albumListModel()->appendItem(
          title,
          QLatin1String("releases"),
          QString::number(result.value(QLatin1String("id")).toInt()));
      }
    }
```

#### AUTO 


```{c}
auto it = m_metadata.constBegin();
```

#### AUTO 


```{c}
auto srcModel = qobject_cast<FileSystemModel*>(sourceModel());
```

#### AUTO 


```{c}
auto tokenLayout = new QHBoxLayout;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& c2t : creditToType) {
    if (role.contains(QString::fromLatin1(c2t.credit))) {
      return c2t.type;
    }
  }
```

#### AUTO 


```{c}
const auto extraartists((track.contains(QLatin1String("extraartists"))
                               ? track.value(QLatin1String("extraartists"))
                               : track.value(QLatin1String("trackCredits")))
                              .toArray());
```

#### AUTO 


```{c}
auto namesIt = m_profileNames.constBegin(),
       sourcesIt = m_profileSources.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& filePath : filePaths) {
      QFileInfo fi(filePath);
      if (!QDir::match(nameFilters, fi.fileName()) && !fi.isDir()) {
        setAllFilesFileFilter();
        break;
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QPersistentModelIndex& idx : idxs) {
    if (const auto model =
        qobject_cast<const FileProxyModel*>(idx.model())) {
      paths.append(model->filePath(idx));
    }
  }
```

#### AUTO 


```{c}
auto accuracyLayout = new QHBoxLayout;
```

#### RANGE FOR STATEMENT 


```{c}
for (ITaggedFileFactory* factory : factories) {
    const auto keys = factory->taggedFileKeys();
    for (const QString& key : keys) {
      extensions.append(factory->supportedFileExtensions(key));
    }
  }
```

#### AUTO 


```{c}
auto toolsConvertToId3v23 = new QAction(this);
```

#### AUTO 


```{c}
auto vlayout = new QVBoxLayout;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& freeFormNameType : freeFormNameTypes) {
      typeNameMap.insert(freeFormNameType.type, QString::fromLatin1(freeFormNameType.name));
    }
```

#### AUTO 


```{c}
auto fileUnload = new QAction(this);
```

#### AUTO 


```{c}
auto timeEdit = new QTimeEdit(parent);
```

#### AUTO 


```{c}
auto parentMenu = qobject_cast<QMenu*>(userMenu->parent())
```

#### AUTO 


```{c}
auto commFrame =
              new TagLib::ID3v2::CommentsFrame(enc);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QPersistentModelIndex& index : selectedIndexes) {
    TaggedFile* taggedFile = FileProxyModel::getTaggedFileOfIndex(index);
    QString absFilename, dirName, fileName;
    if (taggedFile) {
      absFilename = taggedFile->getAbsFilename();
      dirName = taggedFile->getDirname();
      fileName = taggedFile->getFilename();
    } else {
      QFileInfo fi(model->fileInfo(index));
      absFilename = fi.filePath();
      dirName = fi.dir().path();
      fileName = fi.fileName();
    }
    bool ok;
    QString newFileName = QInputDialog::getText(
      m_w,
      tr("Rename File"),
      tr("Enter new file name:"),
      QLineEdit::Normal, fileName, &ok);
    if (ok && !newFileName.isEmpty() && newFileName != fileName) {
      if (taggedFile) {
        if (taggedFile->isChanged()) {
          taggedFile->setFilename(newFileName);
          if (selItems.size() == 1)
            m_form->setFilename(newFileName);
          continue;
        }
        // This will close the file.
        // The file must be closed before renaming on Windows.
        taggedFile->closeFileHandle();
      } else if (model->isDir(index)) {
        // The directory must be closed before renaming on Windows.
        TaggedFileIterator::closeFileHandles(index);
      }
      QString newPath = dirName + QLatin1Char('/') + newFileName;
      if (!Utils::safeRename(absFilename, newPath)) {
#ifdef Q_OS_WIN32
        if (QMessageBox::warning(
              0, tr("File Error"),
              tr("Error while renaming:\n") +
              tr("Rename %1 to %2 failed\n").arg(fileName).arg(newFileName) +
              tr("Retry after closing directories?"),
              QMessageBox::Ok, QMessageBox::Cancel) == QMessageBox::Ok) {
          m_app->tryRenameAfterReset(absFilename, newPath);
        }
#else
        QMessageBox::warning(
          0, tr("File Error"),
          tr("Error while renaming:\n") +
          tr("Rename %1 to %2 failed\n").arg(fileName).arg(newFileName),
          QMessageBox::Ok, Qt::NoButton);
#endif
      }
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const ServerTrackImporter* si : stis) {
    QString serverName(QCoreApplication::translate("@default", si->name()));
    QString actionName = QString::fromLatin1(
          si->name()).toLower().remove(QLatin1Char(' '));
    int dotPos = actionName.indexOf(QLatin1Char('.'));
    if (dotPos != -1)
      actionName.truncate(dotPos);
    actionName = QLatin1String("import_") + actionName;
    auto fileImportServer = new QAction(this);
    fileImportServer->setData(importerIdx);
    fileImportServer->setStatusTip(tr("Import from %1").arg(serverName));
    fileImportServer->setText(tr("Import from %1...").arg(serverName));
    fileImportServer->setObjectName(actionName);
    m_shortcutsModel->registerAction(fileImportServer, menuTitle);
    connect(fileImportServer, &QAction::triggered,
      impl(), &BaseMainWindowImpl::slotImport);
    fileMenu->addAction(fileImportServer);
    ++importerIdx;
  }
```

#### AUTO 


```{c}
auto tag2LeftLayout = new QVBoxLayout;
```

#### AUTO 


```{c}
auto fontStyleLayout = new QGridLayout;
```

#### AUTO 


```{c}
auto sortButtonGroup = new QButtonGroup(pcGroupBox);
```

#### AUTO 


```{c}
auto pluginsLayout = new QVBoxLayout(pluginsGroupBox);
```

#### AUTO 


```{c}
auto renDirSrc = static_cast<int>(tagVersion);
```

#### AUTO 


```{c}
auto modTag = dynamic_cast<TagLib::Mod::Tag*>(m_tag[Frame::Tag_2])
```

#### AUTO 


```{c}
auto pathButtonGroup = new QButtonGroup(pcGroupBox);
```

#### AUTO 


```{c}
auto popmFrame =
        new TagLib::ID3v2::PopularimeterFrame;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& srcStr : srcStrs) {
      const QStringList propStrs = srcStr.split(QLatin1Char(':'));
      const int propStrsSize = propStrs.size();
      Source src;
      if (propStrsSize > 0)
        src.setName(propStrs.at(0));
      if (propStrsSize > 1)
        src.setRequiredAccuracy(propStrs.at(1).toInt());
      if (propStrsSize > 2) {
        const QString& enableStr = propStrs.at(2);
        src.enableStandardTags(enableStr.contains(QLatin1Char('S')));
        src.enableAdditionalTags(enableStr.contains(QLatin1Char('A')));
        src.enableCoverArt(enableStr.contains(QLatin1Char('C')));
      }
      m_sources.append(src);
    }
```

#### AUTO 


```{c}
auto owner = fieldValue.toString();
```

#### RANGE FOR STATEMENT 


```{c}
for (const ServerTrackImporter* si : stis) {
    QString serverName(QCoreApplication::translate("@default", si->name()));
    QString actionName = QString::fromLatin1(
          si->name()).toLower().remove(QLatin1Char(' '));
    int dotPos = actionName.indexOf(QLatin1Char('.'));
    if (dotPos != -1)
      actionName.truncate(dotPos);
    actionName = QLatin1String("import_") + actionName;
    QAction* fileImportServer = new QAction(this);
    fileImportServer->setData(importerIdx);
    fileImportServer->setStatusTip(tr("Import from %1").arg(serverName));
    fileImportServer->setText(tr("Import from %1...").arg(serverName));
    fileImportServer->setObjectName(actionName);
    m_shortcutsModel->registerAction(fileImportServer, menuTitle);
    connect(fileImportServer, SIGNAL(triggered()),
      impl(), SLOT(slotImport()));
    fileMenu->addAction(fileImportServer);
    ++importerIdx;
  }
```

#### AUTO 


```{c}
auto fileBrowseCoverArt = new QAction(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (int frameType : frameTypes) {
      int column = m_trackDataModel->columnForFrameType(frameType);
      if (column != -1) {
        auto action = new QAction(&menu);
        action->setText(
              m_trackDataModel->headerData(column, Qt::Horizontal).toString());
        action->setData(frameType);
        action->setCheckable(true);
        action->setChecked((m_columnVisibility & (1ULL << frameType)) != 0ULL);
        connect(action, &QAction::triggered,
                this, &ImportDialog::toggleTableColumnVisibility);
        menu.addAction(action);
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (ITaggedFileFactory* factory : factories) {
    const auto keys = factory->taggedFileKeys();
    for (const QString& key : keys) {
      if ((factory->taggedFileFeatures(key) & feature) != 0 &&
          (taggedFile = factory->createTaggedFile(key, fileName, idx,
                                                  feature))
          != 0) {
        return taggedFile;
      }
    }
  }
```

#### AUTO 


```{c}
auto it = commands.constBegin();
```

#### AUTO 


```{c}
auto formatLayout = new QHBoxLayout;
```

#### AUTO 


```{c}
const auto& c2a
```

#### AUTO 


```{c}
auto action = qobject_cast<QAction*>(sender())
```

#### AUTO 


```{c}
const auto& c2n
```

#### AUTO 


```{c}
auto it = genreList.begin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& uiLang : uiLangs) {
    QString lang(uiLang.left(2));
    docPaths += QDir::currentPath() + QLatin1String("/kid3_") + lang + QLatin1String(".html");
    if (!docDir.isNull()) {
      docPaths += docDir + QLatin1String("/kid3_") + lang + QLatin1String(".html"); // clazy:exclude=reserve-candidates
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& param : params) {
            QString arg = param.toString();
            if (arg.isEmpty()) {
              if (param.isArray()) {
                // Special handling for tags parameter of the form [1, 2]
                const auto elements = param.toArray();
                for (const auto& element : elements) {
                  int tagNr = element.toInt();
                  if (tagNr > 0 && tagNr <= Frame::Tag_NumValues) {
                    arg += QLatin1Char('0' + static_cast<char>(tagNr));
                  } else {
                    arg.clear();
                    break;
                  }
                }
              } else if (param.isDouble()) {
                // Allow integer numbers, for example for track numbers
                int argInt = param.toInt(INT_MIN);
                if (argInt != INT_MIN) {
                  arg = QString::number(argInt);
                }
              }
            }
            m_args.append(arg);
          }
```

#### AUTO 


```{c}
const auto& c2t
```

#### AUTO 


```{c}
auto fnGroupBoxLayout = new QVBoxLayout(fnGroupBox);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& localeName : localeNames) {
    if (
        (!translationsDir.isNull() &&
         kid3Tr->load(QLatin1String("kid3_") + localeName, translationsDir,
                      searchDelimiters)) ||
        kid3Tr->load(QLatin1String("kid3_") + localeName, QLatin1String("."),
                     searchDelimiters) ||
        localeName.startsWith(QLatin1String("en"))
        ) {
      break;
    }
  }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QPersistentModelIndex& lhs,
                     const QPersistentModelIndex& rhs) {
        return lhs.data().toString().compare(rhs.data().toString()) > 0;
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& efm : extensionForMimeType) {
      mimeExtMap.insert(QString::fromLatin1(efm.mime), efm.ext);
    }
```

#### AUTO 


```{c}
auto it = m_metadata.begin();
```

#### LAMBDA EXPRESSION 


```{c}
[&frameTypeSeqNr](FrameCollection::iterator lhs,
                                       FrameCollection::iterator rhs) {
      int lhsType = lhs->getType();
      int rhsType = rhs->getType();
      int lhsSeqNr = frameTypeSeqNr.at(lhsType);
      int rhsSeqNr = frameTypeSeqNr.at(rhsType);
      return lhsSeqNr < rhsSeqNr ||
             (lhsType == Frame::FT_Other && lhsType == rhsType &&
              lhs->getInternalName() < rhs->getInternalName());
    }
```

#### AUTO 


```{c}
auto it = m_disabledOtherFrames.find(name);
```

#### RANGE FOR STATEMENT 


```{c}
for (QString filter : includeFolders) {
    filter.replace(QLatin1Char('\\'), QLatin1Char('/'));
#if QT_VERSION >= 0x050f00
    filter = QRegularExpression::wildcardToRegularExpression(filter);
#else
    filter = FileSystemModel::wildcardToRegularExpression(filter);
#endif
    m_includeFolderFilters.append(
          QRegularExpression(filter, QRegularExpression::CaseInsensitiveOption));
  }
```

#### AUTO 


```{c}
auto arranger = m_trackDataModel->index(row, 10).data().toString();
```

#### AUTO 


```{c}
auto mpegFile = dynamic_cast<TagLib::MPEG::File*>(file);
```

#### AUTO 


```{c}
auto setDataModel = const_cast<QAbstractItemModel*>(
          index.model());
```

#### AUTO 


```{c}
auto it = m_metadata.find(name);
```

#### AUTO 


```{c}
auto rx = QRegularExpression(
                  FileSystemModel::wildcardToRegularExpression(nameFilter),
                  reOptions);
```

#### AUTO 


```{c}
auto dialog = new BatchImportSourceDialog(this);
```

#### AUTO 


```{c}
auto vlayout = new QVBoxLayout(pluginsPage);
```

#### RANGE FOR STATEMENT 


```{c}
for (Frame::TagNumber tagNr : Frame::allTagNumbers()) {
            if (frames.empty()) {
              firstSelectedFile->getAllFrames(tagNr, frames);
            } else {
              FrameCollection frames1;
              firstSelectedFile->getAllFrames(tagNr, frames1);
              frames.merge(frames1);
            }
          }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& uiLang : uiLangs) {
    QString lang(uiLang.left(2));
    docPaths += QDir::currentPath() + QLatin1String("/kid3_") + lang +
        QLatin1String(".html");
    if (!docDir.isNull()) {
      docPaths += docDir + QLatin1String("/kid3_") + lang + QLatin1String(".html"); // clazy:exclude=reserve-candidates
    }
  }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool checked){
    setCustomColumnWidthsEnabled(!checked);
  }
```

#### AUTO 


```{c}
auto doc = QJsonDocument::fromJson(albumStr);
```

#### AUTO 


```{c}
const auto releaseValue = it.value();
```

#### AUTO 


```{c}
const auto keys = taggedFileFactory->taggedFileKeys();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& qmlDir : constQmlDirs) {
    QString qmlPath(qmlDir);
    Utils::prependApplicationDirPathIfRelative(qmlPath);
    qmlPath += QDir::separator();
    qmlPath += QLatin1String("app");
    qmlPath += QDir::separator();
    qmlPath += QLatin1String("Main.qml");
    if (QFile::exists(qmlPath)) {
      mainQmlPath = qmlPath;
      break;
    }
  }
```

#### AUTO 


```{c}
const auto plugins = loadPlugins();
```

#### AUTO 


```{c}
auto fldIt = getFieldList().constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto fieldName : fieldNames) {
      lst.append(QString::fromLatin1(fieldName)); // clazy:exclude=reserve-candidates
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Frame::TagNumber tagNr : Frame::tagNumbersFromMask(tagMask)) {
      QString value = cli()->app()->getFrame(Frame::tagVersionFromNumber(tagNr),
                                             name);
      if (!(tagNr == Frame::Tag_1 ? value.isEmpty() : value.isNull())) {
        cli()->writeLine(value);
        break;
      }
    }
```

#### AUTO 


```{c}
auto& c = r[column];
```

#### AUTO 


```{c}
auto it = trackData.constBegin();
```

#### AUTO 


```{c}
auto moreArtistsIt = moreArtistsRe.globalMatch(
                  trackDataStr, artistEndPos, QRegularExpression::NormalMatch,
                  QRegularExpression::AnchoredMatchOption);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& index : selectedIndexes) {
    indexes.append(QPersistentModelIndex(index));
  }
```

#### AUTO 


```{c}
const auto fmts = result.value(QLatin1String("format")).toArray();
```

#### AUTO 


```{c}
auto splitter = new QSplitter(this);
```

#### LAMBDA EXPRESSION 


```{c}
[proc, conn, callback](int exitCode) mutable {
    QObject::disconnect(*conn);
    if (!callback.isUndefined()) {
      QVariantList result{
        exitCode,
        QString::fromLocal8Bit(proc->readAllStandardOutput()),
        QString::fromLocal8Bit(proc->readAllStandardError())
      };
      callback.call({callback.engine()->toScriptValue(result)});
    }
  }
```

#### AUTO 


```{c}
auto match = it.next();
```

#### AUTO 


```{c}
auto srcModel = qobject_cast<QAbstractItemModel*>(obj)
```

#### AUTO 


```{c}
auto it = freeFormNameTypeMap.constFind(name);
```

#### AUTO 


```{c}
const auto uiLangs = locale.uiLanguages();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& filePath : constFilePaths) {
      fileIndexes.append(m_fileSystemModel->index(filePath));
    }
```

#### AUTO 


```{c}
const auto constChildren = children;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& c2a : creditToArrangement) {
            if ((*cit).startsWith(
                  QString::fromLatin1(c2a.credit))) {
              addInvolvedPeople(frames, Frame::FT_Arranger,
                QString::fromLatin1(c2a.arrangement), name);
              found = true;
              break;
            }
          }
```

#### AUTO 


```{c}
auto dialog = new KdeConfigDialog(m_platformTools, this, caption,
                                                configSkeleton);
```

#### AUTO 


```{c}
auto it = m_frameOfRow.constBegin();
```

#### AUTO 


```{c}
auto it = m_keyValues.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (int frameType : constFrameTypes) {
    auto name = Frame::ExtendedType(static_cast<Frame::Type>(frameType))
        .getTranslatedName();
    if (Frame::isCustomFrameType(static_cast<Frame::Type>(frameType))) {
      int idx = frameType - Frame::FT_Custom1;
      if (idx >= 0 && idx < customFrameNames.size()) {
        name = customFrameNames.at(idx);
      } else {
        name.clear();
      }
    }
    if (!name.isEmpty()) {
      const bool selected = (frameMask & (1ULL << frameType)) != 0ULL;
      namesSelected.append(
            QVariantMap{{QLatin1String("name"), name},
                        {QLatin1String("type"), frameType},
                        {QLatin1String("selected"), selected}});
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVariant& var : frames) {
              QString name = var.toMap().value(QLatin1String("name")).toString();
              QString value = var.toMap().value(QLatin1String("value")).toString();
              bool changed =  var.toMap().value(QLatin1String("changed")).toBool();
              QString line = changed ? QLatin1String("*") : QLatin1String(" ");
              line += QLatin1Char(' ');
              line += name;
              line += QString(maxLength - name.size() + 2,
                              QLatin1Char(' '));
              line += value;
              io()->writeLine(line);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (Frame::TagNumber tagNr : Frame::tagNumbersFromMask(tagMask)) {
      QString value = cli()->app()->getFrame(Frame::tagVersionFromNumber(tagNr),
                                             name);
      if (!(tagNr == Frame::Tag_1 ? value.isEmpty() : value.isNull())) {
        cli()->writeResult(value);
        break;
      }
    }
```

#### AUTO 


```{c}
auto instrument
```

#### AUTO 


```{c}
auto editPreviousFile = new QAction(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QStorageInfo& si : QStorageInfo::mountedVolumes()) {
    QVariantMap map;
    map.insert(QLatin1String("name"), si.name());
    map.insert(QLatin1String("displayName"), si.displayName());
    map.insert(QLatin1String("isValid"), si.isValid());
    map.insert(QLatin1String("isReadOnly"), si.isReadOnly());
    map.insert(QLatin1String("isReady"), si.isReady());
    map.insert(QLatin1String("rootPath"), si.rootPath());
#if QT_VERSION >= 0x050600
    map.insert(QLatin1String("blockSize"), si.blockSize());
#endif
    map.insert(QLatin1String("mbytesAvailable"),
               static_cast<int>(si.bytesAvailable() / (1024 * 1024)));
    map.insert(QLatin1String("mbytesFree"),
               static_cast<int>(si.bytesFree() / (1024 * 1024)));
    map.insert(QLatin1String("mbytesTotal"),
               static_cast<int>(si.bytesTotal() / (1024 * 1024)));
    result.append(map);
  }
```

#### AUTO 


```{c}
auto toolsFilter = new QAction(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (int frameType : constFrameTypes) {
    QStandardItem* item = new QStandardItem(
          Frame::ExtendedType(static_cast<Frame::Type>(frameType)).getTranslatedName());
    item->setData(frameType, Qt::UserRole);
    item->setCheckable(true);
    item->setCheckState((frameMask & (1ULL << frameType))
                        ? Qt::Checked : Qt::Unchecked);
    item->setDropEnabled(false);
    m_quickAccessTagsModel->appendRow(item);
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& fileName : fileNames) {
      if (disabledImportPluginFileNames.contains(fileName)) {
        availablePlugins.append(
              disabledImportPluginFileNames.value(fileName));
        continue;
      }
      if (disabledTagPluginFileNames.contains(fileName)) {
        availableTagPlugins.append(
              disabledTagPluginFileNames.value(fileName));
        continue;
      }
      QPluginLoader loader(pluginsDir.absoluteFilePath(fileName));
      QObject* plugin = loader.instance();
      if (plugin) {
        QString name(plugin->objectName());
        if (disabledPlugins.contains(name)) {
          availablePlugins.append(name);
          loader.unload();
        } else if (disabledTagPlugins.contains(name)) {
          availableTagPlugins.append(name);
          loader.unload();
        } else {
          plugins.append(plugin);
        }
      }
    }
```

#### AUTO 


```{c}
auto textctl = new LineFieldControl(fld);
```

#### AUTO 


```{c}
auto track = val.toObject();
```

#### AUTO 


```{c}
auto ic
```

#### AUTO 


```{c}
auto dirIt = dirComponents.begin();
```

#### AUTO 


```{c}
auto layout = new QVBoxLayout(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVariant& var : frames) {
              QString name = var.toMap().value(QLatin1String("name")).toString();
              maxLength = qMax(name.size(), maxLength);
            }
```

#### AUTO 


```{c}
auto matchSpacer = new QSpacerItem(16, 0, QSizePolicy::Expanding,
                                             QSizePolicy::Minimum);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &nameFilter : nameFilters) {
            QRegExp copy = nameFilter;
            if (copy.exactMatch(node->fileName))
                return true;
        }
```

#### AUTO 


```{c}
auto it = fieldListMap.begin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const TimeEvent& timeEvent : timeEvents) {
    if (!timeEvent.time.isNull()) {
      int code = timeEvent.data.toInt();

      quint32 milliseconds;
#if QT_VERSION >= 0x060000
      if (timeEvent.time.typeId() == QMetaType::QTime) {
#else
      if (timeEvent.time.type() == QVariant::Time) {
#endif
        hasMsTimeStamps = true;
        milliseconds = QTime(0, 0).msecsTo(timeEvent.time.toTime());
      } else {
        milliseconds = timeEvent.data.toUInt();
      }
      synchedData.append(milliseconds);
      synchedData.append(code);
    }
  }
```

#### AUTO 


```{c}
auto sectionActions = new SectionActions(SectionActions::Navigation,
                                           m_fileListBox);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& index : indexes) {
    const QAbstractItemModel* mdl = index.model();
    if (index.column() == 0 &&
        mdl && (mdl->flags(index) & Qt::ItemIsDragEnabled)) {
      if (TaggedFile* tf = FileProxyModel::getTaggedFileOfIndex(index)) {
        tf->closeFileHandle();
      }
    }
  }
```

#### AUTO 


```{c}
auto metadataEdit =
      new StringListEdit(m_enabledMetadataPluginsModel, metadataGroupBox);
```

#### AUTO 


```{c}
auto dataIt = fields.end();
```

#### AUTO 


```{c}
auto fileBatchImport = new QAction(this);
```

#### AUTO 


```{c}
auto match = discTrackPosRe.match(m_position);
```

#### AUTO 


```{c}
auto it = idStrMap.constFind(id);
```

#### AUTO 


```{c}
const auto factories = FileProxyModel::taggedFileFactories();
```

#### RANGE FOR STATEMENT 


```{c}
for (Frame::TagNumber tagNr : Frame::tagNumbersFromMask(tagVersion)) {
        if (it->empty()) {
          taggedFile->getAllFrames(tagNr, *it);
        } else {
          FrameCollection frames;
          taggedFile->getAllFrames(tagNr, frames);
          it->merge(frames);
        }
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& entry : entries) {
              expandedPath.append(partBefore + entry + partAfter); // clazy:exclude=reserve-candidates
            }
```

#### AUTO 


```{c}
auto& r = m_cont[row];
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& index : indexes) {
      if (index.column() == TimeEventModel::CI_Time) {
        m_model->setData(index, index.data().toTime().addMSecs(offset));
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& key : keys) {
      if ((factory->taggedFileFeatures(key) & feature) != 0 &&
          (taggedFile = factory->createTaggedFile(key, fileName, idx,
                                                  feature))
          != nullptr) {
        return taggedFile;
      }
    }
```

#### AUTO 


```{c}
auto durationMatch = durationRe.match(durationStr);
```

#### AUTO 


```{c}
auto it = frameTypes.constBegin();
```

#### AUTO 


```{c}
auto commandsLayout = new QVBoxLayout;
```

#### AUTO 


```{c}
auto method = obj.value(QLatin1String("method")).toString();
```

#### AUTO 


```{c}
auto doc = QJsonDocument::fromJson(albumStr.mid(jsonStart, jsonEnd - jsonStart));
```

#### AUTO 


```{c}
auto dialog = new ConfigDialog(m_platformTools, this, caption,
                                          m_shortcutsModel);
```

#### AUTO 


```{c}
auto rowEndIt = rowEndRe.globalMatch(str);
```

#### AUTO 


```{c}
auto destLayout = new QHBoxLayout;
```

#### AUTO 


```{c}
auto fldIt = m_fields.begin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& srcStr : srcStrs) {
      QStringList propStrs = srcStr.split(QLatin1Char(':'));
      Source src;
      if (propStrs.size() > 0)
        src.setName(propStrs.at(0));
      if (propStrs.size() > 1)
        src.setRequiredAccuracy(propStrs.at(1).toInt());
      if (propStrs.size() > 2) {
        const QString& enableStr = propStrs.at(2);
        src.enableStandardTags(enableStr.contains(QLatin1Char('S')));
        src.enableAdditionalTags(enableStr.contains(QLatin1Char('A')));
        src.enableCoverArt(enableStr.contains(QLatin1Char('C')));
      }
      m_sources.append(src);
    }
```

#### AUTO 


```{c}
auto v1GroupBoxLayout = new QGridLayout(v1GroupBox);
```

#### AUTO 


```{c}
auto it = frames.findByExtendedType(
        Frame::ExtendedType(Frame::FT_Picture));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& freeFormNameType : freeFormNameTypes) {
      typeNameMap.insert(freeFormNameType.type,
                         QString::fromLatin1(freeFormNameType.name));
    }
```

#### AUTO 


```{c}
auto match = catIdTitleRe.match((*it).mid(4));
```

#### AUTO 


```{c}
auto& frame = const_cast<Frame&>(*othersIt);
```

#### AUTO 


```{c}
const auto elements = param.toArray();
```

#### AUTO 


```{c}
auto editFormatsToTagButton =
          new QPushButton(tr("Tag from filename") + QLatin1String("..."));
```

#### AUTO 


```{c}
auto customFrameName = Frame::getNameForCustomFrame(type);
```

#### AUTO 


```{c}
auto h = static_cast<unsigned char>(hexStr[i++].toLatin1());
```

#### RANGE FOR STATEMENT 


```{c}
for (auto type : types) {
    lst.append(Frame::ExtendedType(type, QLatin1String("")). // clazy:exclude=reserve-candidates
               getName());
  }
```

#### AUTO 


```{c}
auto sit = it->second.constBegin();
```

#### AUTO 


```{c}
auto type =
        static_cast<TagLib::ID3v2::EventTimingCodesFrame::EventType>(
          it.next().toInt());
```

#### AUTO 


```{c}
const auto& asfNameTypeValue
```

#### AUTO 


```{c}
auto vc =
              dynamic_cast<FLAC::Metadata::VorbisComment*>(proto);
```

#### AUTO 


```{c}
auto locationLayout = new QHBoxLayout;
```

#### AUTO 


```{c}
auto& valueSet = (*differentValues)[it->getExtendedType()];
```

#### AUTO 


```{c}
auto otherIt = it->getIndex() != -1
        ? other.findByIndex(it->getIndex())
        : other.find(*it);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QPersistentModelIndex& index : selectedIndexes) {
    files.append(model->filePath(index));
  }
```

#### AUTO 


```{c}
auto resetButton = new QToolButton(this);
```

#### AUTO 


```{c}
auto dirPathIt = dirPathComponents.constBegin();
```

#### AUTO 


```{c}
auto rowEndMatch = rowEndIt.next();
```

#### AUTO 


```{c}
auto tag2RightLayout = new QVBoxLayout;
```

#### AUTO 


```{c}
auto buttonLayout = new QHBoxLayout;
```

#### AUTO 


```{c}
const auto model =
             qobject_cast<const FileProxyModel*>(index.model())
```

#### AUTO 


```{c}
auto styleTheme = style.split('/');
```

#### AUTO 


```{c}
auto editSelectAll = new QAction(this);
```

#### AUTO 


```{c}
auto tablayout = new QVBoxLayout;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& key : keys) {
      if ((factory->taggedFileFeatures(key) & feature) != 0 &&
          (taggedFile = factory->createTaggedFile(key, fileName, idx,
                                                  feature))
          != 0) {
        return taggedFile;
      }
    }
```

#### AUTO 


```{c}
auto fsModel = qobject_cast<QFileSystemModel*>(sourceModel);
```

#### AUTO 


```{c}
auto typeOrProperty = static_cast<int>(type.getType());
```

#### LAMBDA EXPRESSION 


```{c}
[]() { return &NetworkConfig::instance(); }
```

#### AUTO 


```{c}
auto firstLabelMap = labels.first().toObject();
```

#### LAMBDA EXPRESSION 


```{c}
[]() { return &TagConfig::instance(); }
```

#### AUTO 


```{c}
auto tag2Layout = new QHBoxLayout(tag2Page);
```

#### AUTO 


```{c}
auto editFormatsButton = new QPushButton(tr("&Edit..."));
```

#### AUTO 


```{c}
const auto stis = m_trackImporters;
```

#### AUTO 


```{c}
auto reply = qobject_cast<QNetworkReply*>(sender())
```

#### AUTO 


```{c}
const auto selectedRanges = mapSelectionFromSource(selected);
```

#### AUTO 


```{c}
auto pictureGroupBoxLayout = new QHBoxLayout(pictureGroupBox);
```

#### AUTO 


```{c}
auto fileImportServer = new QAction(this);
```

#### AUTO 


```{c}
auto fileListGroupBoxLayout = new QGridLayout(fileListGroupBox);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& fileName : paths) {
    QModelIndex index = model->index(fileName);
    if (index.isValid()) {
      m_app->getFileSelectionModel()->setCurrentIndex(
            index, QItemSelectionModel::Select | QItemSelectionModel::Rows);
    } else {
      ok = false;
    }
  }
```

#### AUTO 


```{c}
auto map = var.toMap();
```

#### AUTO 


```{c}
auto action = new QAction(&menu);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& str : strs) {
    io()->writeLine(str);
  }
```

#### AUTO 


```{c}
const auto extraartists = map.value(QLatin1String("extraartists")).toArray();
```

#### AUTO 


```{c}
const auto fsModel =
        qobject_cast<const FileProxyModel*>(idx.model())
```

#### AUTO 


```{c}
auto match = discTrackPosRe.match(position);
```

#### AUTO 


```{c}
auto profileListEdit =
      new BatchImportSourceListEdit(m_profileModel, this);
```

#### AUTO 


```{c}
auto it = headers.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto mode : resizeModes)
    header->setSectionResizeMode(col++,
                                 static_cast<QHeaderView::ResizeMode>(mode));
```

#### AUTO 


```{c}
auto identifier = fieldValue.toString();
```

#### AUTO 


```{c}
auto tagsLayout = new QVBoxLayout(tagsGroupBox);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QPersistentModelIndex& index : selectedIndexes) {
    TaggedFile* taggedFile = FileProxyModel::getTaggedFileOfIndex(index);
    QString absFilename, dirName, fileName;
    if (taggedFile) {
      absFilename = taggedFile->getAbsFilename();
      dirName = taggedFile->getDirname();
      fileName = taggedFile->getFilename();
    } else {
      QFileInfo fi(model->fileInfo(index));
      absFilename = fi.filePath();
      dirName = fi.dir().path();
      fileName = fi.fileName();
    }
    bool ok;
    QString newFileName = QInputDialog::getText(
      m_w,
      tr("Rename File"),
      tr("Enter new file name:"),
      QLineEdit::Normal, fileName, &ok);
    if (ok && !newFileName.isEmpty() && newFileName != fileName) {
      if (taggedFile) {
        if (taggedFile->isChanged()) {
          taggedFile->setFilename(newFileName);
          if (selItems.size() == 1)
            m_form->setFilename(newFileName);
          continue;
        }
        // This will close the file.
        // The file must be closed before renaming on Windows.
        taggedFile->closeFileHandle();
      } else if (model->isDir(index)) {
        // The directory must be closed before renaming on Windows.
        TaggedFileIterator::closeFileHandles(index);
      }
      QString newPath = dirName + QLatin1Char('/') + newFileName;
      bool ok = model->rename(index, newFileName);
      if (!ok && !(index.flags() & Qt::ItemIsEditable)) {
        // The file system model seems to be too restrictive, renaming without
        // write permission is possible on Linux, so try again without
        // using the model.
        ok = QFile::rename(absFilename, newPath);
      }
      if (ok) {
        if (taggedFile) {
          taggedFile->updateCurrentFilename();
          if (selItems.size() == 1) {
            m_form->setFilename(newFileName);
          }
        }
      } else {
#ifdef Q_OS_WIN32
        if (QMessageBox::warning(
              0, tr("File Error"),
              tr("Error while renaming:\n") +
              tr("Rename %1 to %2 failed\n").arg(fileName).arg(newFileName) +
              tr("Retry after closing folders?"),
              QMessageBox::Ok, QMessageBox::Cancel) == QMessageBox::Ok) {
          m_app->tryRenameAfterReset(absFilename, newPath);
        }
#else
        QMessageBox::warning(
          nullptr, tr("File Error"),
          tr("Error while renaming:\n") +
          tr("Rename %1 to %2 failed\n").arg(fileName, newFileName),
          QMessageBox::Ok, QMessageBox::NoButton);
#endif
      }
    }
  }
```

#### AUTO 


```{c}
auto it = findByExtendedType(type);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& key : keys) {
      factory->notifyConfigurationChange(key);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& freeFormNameType : freeFormNameTypes) {
        freeFormNameTypeMap.insert(QString::fromLatin1(freeFormNameType.name), freeFormNameType.type);
      }
```

#### AUTO 


```{c}
const auto lines = toQString(text).split(QLatin1Char('\n'));
```

#### AUTO 


```{c}
auto findAction = new QAction(this);
```

#### AUTO 


```{c}
auto optionsTagsLayout = new QHBoxLayout;
```

#### LAMBDA EXPRESSION 


```{c}
[]() { return &FilenameFormatConfig::instance(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (int value : intList) {
    result.append(QString::number(value));
  }
```

#### AUTO 


```{c}
auto it = strs.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const ShortcutItem& i : g) {
                if (i.activeShortcut() == keyString &&
                    si.action() != i.action() &&
                    (si.action()->shortcutContext() != Qt::WidgetShortcut ||
                     i.action()->shortcutContext() != Qt::WidgetShortcut)) {
                  emit shortcutAlreadyUsed(keyString, g.context(), i.action());
                  return false;
                }
              }
```

#### RANGE FOR STATEMENT 


```{c}
for (int frameType : frameTypes) {
    if (frameType < 64) {
      int column = m_trackDataModel->columnForFrameType(frameType);
      if (column != -1) {
        m_trackDataTable->setColumnHidden(
              column, (m_columnVisibility & (1ULL << frameType)) == 0ULL);
      }
    }
  }
```

#### AUTO 


```{c}
auto tit = trackDataVector.constBegin();
```

#### AUTO 


```{c}
auto vspacer = new QSpacerItem(0, 0,
                                 QSizePolicy::Minimum, QSizePolicy::Expanding);
```

#### AUTO 


```{c}
auto butspacer = new QSpacerItem(16, 0, QSizePolicy::Expanding,
                                           QSizePolicy::Minimum);
```

#### RANGE FOR STATEMENT 


```{c}
for (const ServerTrackImporter* si : stis) {
    QString serverName(QCoreApplication::translate("@default", si->name()));
    QString actionName = QString::fromLatin1(si->name()).toLower()
        .remove(QLatin1Char(' '));
    int dotPos = actionName.indexOf(QLatin1Char('.'));
    if (dotPos != -1)
      actionName.truncate(dotPos);
    actionName = QLatin1String("import_") + actionName;
    action = new QAction(tr("Import from %1...").arg(serverName), this);
    action->setStatusTip(tr("Import from %1").arg(serverName));
    action->setData(importerIdx);
    collection->addAction(actionName, action);
    connect(action, &QAction::triggered, impl(), &BaseMainWindowImpl::slotImport);
    ++importerIdx;
  }
```

#### AUTO 


```{c}
auto it = find(*otherIt);
```

#### AUTO 


```{c}
auto fileReload = new QAction(this);
```

#### AUTO 


```{c}
const auto& twp
```

#### AUTO 


```{c}
const auto& ts
```

#### AUTO 


```{c}
auto hbox = new QHBoxLayout;
```

#### AUTO 


```{c}
auto model = qobject_cast<QAbstractItemModel*>(modelObj)
```

#### AUTO 


```{c}
auto type =
              static_cast<TagLib::ID3v2::RelativeVolumeFrame::ChannelType>(
                typeInt);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& val : trackList) {
    auto track = val.toObject();

    QString position(track.value(QLatin1String("position")).toString());
    bool ok;
    int pos = position.toInt(&ok);
    if (!ok) {
      auto match = discTrackPosRe.match(position);
      if (match.hasMatch()) {
        if (additionalTags) {
          frames.setValue(Frame::FT_Disc, match.captured(1));
        }
        pos = match.captured(2).toInt();
      } else {
        pos = trackNr;
      }
    }
    QString title(track.value(QLatin1String("title")).toString().trimmed());
    if (!title.isEmpty()) {
      titleFound = true;
    }

    int duration = 0;
    if (track.contains(QLatin1String("duration"))) {
      const QStringList durationHms = track.value(QLatin1String("duration"))
          .toString().split(QLatin1Char(':'));
      for (const auto& val : durationHms) {
        duration *= 60;
        duration += val.toInt();
      }
    } else {
      duration = track.value(QLatin1String("durationInSeconds")).toInt();
    }
    if (!allPositionsEmpty && position.isEmpty()) {
      if (additionalTags) {
        framesHdr.setValue(Frame::FT_Subtitle, title);
        frames.setValue(Frame::FT_Subtitle, title);
      }
    } else if (!title.isEmpty() || duration != 0) {
      if (standardTags) {
        frames.setTrack(pos);
        frames.setTitle(title);
      }
      const auto artists((track.contains(QLatin1String("artists"))
                          ? track.value(QLatin1String("artists"))
                          : track.value(QLatin1String("primaryArtists")))
                         .toArray());
      if (!artists.isEmpty()) {
        if (standardTags) {
          frames.setArtist(getArtistString(artists));
        }
        if (additionalTags) {
          frames.setValue(Frame::FT_AlbumArtist, framesHdr.getArtist());
        }
      }
      if (additionalTags) {
        const auto extraartists((track.contains(QLatin1String("extraartists"))
                                 ? track.value(QLatin1String("extraartists"))
                                 : track.value(QLatin1String("trackCredits")))
                                .toArray());
        if (!extraartists.isEmpty()) {
          for (const auto& val : extraartists) {
            ExtraArtist extraArtist(val.toObject());
            extraArtist.addToFrames(frames);
          }
        }
      }
      for (const auto& extraArtist : trackExtraArtists) {
        extraArtist.addToFrames(frames, position);
      }

      if (atTrackDataListEnd) {
        ImportTrackData trackData;
        trackData.setFrameCollection(frames);
        trackData.setImportDuration(duration);
        trackDataVector.append(trackData);
      } else {
        while (!atTrackDataListEnd && !it->isEnabled()) {
          ++it;
          atTrackDataListEnd = (it == trackDataVector.end());
        }
        if (!atTrackDataListEnd) {
          (*it).setFrameCollection(frames);
          (*it).setImportDuration(duration);
          ++it;
          atTrackDataListEnd = (it == trackDataVector.end());
        }
      }
      ++trackNr;
    }
    frames = framesHdr;
  }
```

#### AUTO 


```{c}
auto match = m_regExp.match(str, idx);
```

#### AUTO 


```{c}
auto vlayout = new QVBoxLayout(tagsPage);
```

#### AUTO 


```{c}
auto revertButton = new QToolButton;
```

#### AUTO 


```{c}
const auto errs = component.errors();
```

#### AUTO 


```{c}
auto iterator = indexNode->children.constBegin(), cend = indexNode->children.constEnd();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVariant& var : value) {
        if (!tagStr.isEmpty()) {
          tagStr += QLatin1String(", ");
        }
        tagStr += var.toString();
      }
```

#### AUTO 


```{c}
auto it = channels.begin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& keyVal : constStrRepMap) {
            if (keyVal.first.length() == 1) {
              replaceMap.insert(keyVal.first.at(0), keyVal.second);
            }
          }
```

#### AUTO 


```{c}
auto pluginsListView = new QListView;
```

#### AUTO 


```{c}
auto it = cbegin();
```

#### AUTO 


```{c}
auto previewPage = new QWizardPage;
```

#### LAMBDA EXPRESSION 


```{c}
[]() { return &RenDirConfig::instance(); }
```

#### AUTO 


```{c}
const auto& keyVal
```

#### AUTO 


```{c}
auto it =
        frames.findByExtendedType(Frame::ExtendedType(Frame::FT_Picture));
```

#### AUTO 


```{c}
auto it = m_excludeFolderFilters.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& key : keys) {
      taggedFile = factory->createTaggedFile(key, fileName, idx);
      if (taggedFile) {
        return taggedFile;
      }
    }
```

#### AUTO 


```{c}
auto type = static_cast<Frame::Type>(i);
```

#### AUTO 


```{c}
const auto gs = m_shortcutGroups;
```

#### AUTO 


```{c}
auto vlayout = new QVBoxLayout(appearancePage);
```

#### AUTO 


```{c}
auto it = m_actions.constBegin();
```

#### AUTO 


```{c}
auto cfg = KSharedConfig::openConfig();
```

#### AUTO 


```{c}
auto ucName = name.toUpper().replace(' ', QByteArray());
```

#### AUTO 


```{c}
auto binctl = new BinFieldControl(
              m_platformTools, m_app, fld, frame, taggedFile);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &filter : filters)
        d->nameFilters << QRegExp(filter, caseSensitive, QRegExp::Wildcard);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& iw : idWarning) {
      warnings[QString::fromLatin1(iw.id)] = iw.warning;
    }
```

#### AUTO 


```{c}
const auto localeNames = languages;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& asfNameTypeValue : asfNameTypeValues) {
      if (asfNameTypeValue.type == Frame::FT_Other) {
        lst.append(QString::fromLatin1(asfNameTypeValue.name));
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (ITaggedFileFactory* factory : factories) {
      int idx = pluginOrder.indexOf(factory->name());
      if (idx >= 0) {
        orderedFactories[idx] = factory;
      } else {
        orderedFactories.append(factory);
      }
    }
```

#### AUTO 


```{c}
const auto& wf
```

#### RANGE FOR STATEMENT 


```{c}
for (const ServerImporter* importer : importers) {
    names.append(QString::fromLatin1(importer->name()));
  }
```

#### AUTO 


```{c}
auto match = durationRe.match(
                            line.mid(runtimeStart + 1,
                                     runtimeEnd - runtimeStart - 1));
```

#### AUTO 


```{c}
auto shortcutContext = qobject_cast<QAbstractItemView*>(m_widget)
      ? Qt::WidgetShortcut : Qt::WidgetWithChildrenShortcut;
```

#### AUTO 


```{c}
auto othersIt = others.begin();
```

#### AUTO 


```{c}
auto it = numEntityRe.globalMatch(str);
```

#### LAMBDA EXPRESSION 


```{c}
[this, tagNr]() {
      setFocusPreviousTag(tagNr);
    }
```

#### AUTO 


```{c}
auto mp4Tag =
                     dynamic_cast<TagLib::MP4::Tag*>(tag)
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool checked) {
    setCustomColumnWidthsEnabled(checked);
  }
```

#### AUTO 


```{c}
auto findNextAction = new QAction(this);
```

#### AUTO 


```{c}
auto it = frameList.begin();
```

#### AUTO 


```{c}
auto it = input.constBegin();
```

#### AUTO 


```{c}
auto it = codePos.begin();
```

#### AUTO 


```{c}
auto metadataPluginsLayout = new QVBoxLayout(metadataGroupBox);
```

#### RANGE FOR STATEMENT 


```{c}
for (const ServerImporter* si : sis) {
    QString serverName(QCoreApplication::translate("@default", si->name()));
    QString actionName = QString::fromLatin1(si->name()).toLower().
        remove(QLatin1Char(' '));
    int dotPos = actionName.indexOf(QLatin1Char('.'));
    if (dotPos != -1)
      actionName.truncate(dotPos);
    actionName = QLatin1String("import_") + actionName;
    action = new QAction(tr("Import from %1...").arg(serverName), this);
    action->setData(importerIdx);
    action->setStatusTip(tr("Import from %1").arg(serverName));
    collection->addAction(actionName, action);
    connect(action, SIGNAL(triggered()), impl(), SLOT(slotImport()));
    ++importerIdx;
  }
```

#### AUTO 


```{c}
auto id3Frame =
      dynamic_cast<TagLib::ID3v2::CommentsFrame*>(*it);
```

#### AUTO 


```{c}
auto toolsApplyFilenameFormat = new QAction(this);
```

#### AUTO 


```{c}
auto match = titleRe.match(*it);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& val : genreList) {
      QString genre = val.toString().trimmed();
      if (!genre.isEmpty()) {
        int genreNum = Genres::getNumber(genre);
        if (genreNum != 255) {
          genres.append(QString::fromLatin1(Genres::getName(genreNum)));
        } else {
          customGenres.append(genre);
        }
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& extraArtist : trackExtraArtists) {
    extraArtist.addToFrames(frames, m_position);
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QPersistentModelIndex& index : selectedIndexes) {
    TaggedFile* taggedFile = FileProxyModel::getTaggedFileOfIndex(index);
    QString absFilename, dirName, fileName;
    if (taggedFile) {
      absFilename = taggedFile->getAbsFilename();
      dirName = taggedFile->getDirname();
      fileName = taggedFile->getFilename();
    } else {
      QFileInfo fi(model->fileInfo(index));
      absFilename = fi.filePath();
      dirName = fi.dir().path();
      fileName = fi.fileName();
    }
    bool ok;
    QString newFileName = QInputDialog::getText(
      m_w,
      tr("Rename File"),
      tr("Enter new file name:"),
      QLineEdit::Normal, fileName, &ok);
    if (ok && !newFileName.isEmpty() && newFileName != fileName) {
      if (taggedFile) {
        if (taggedFile->isChanged()) {
          taggedFile->setFilename(newFileName);
          if (selItems.size() == 1)
            m_form->setFilename(newFileName);
          continue;
        }
        // This will close the file.
        // The file must be closed before renaming on Windows.
        taggedFile->closeFileHandle();
      } else if (model->isDir(index)) {
        // The directory must be closed before renaming on Windows.
        TaggedFileIterator::closeFileHandles(index);
      }
      QString newPath = dirName + QLatin1Char('/') + newFileName;
      if (model->rename(index, newFileName)) {
        if (taggedFile) {
          taggedFile->updateCurrentFilename();
          if (selItems.size() == 1) {
            m_form->setFilename(newFileName);
          }
        }
      } else {
#ifdef Q_OS_WIN32
        if (QMessageBox::warning(
              0, tr("File Error"),
              tr("Error while renaming:\n") +
              tr("Rename %1 to %2 failed\n").arg(fileName).arg(newFileName) +
              tr("Retry after closing directories?"),
              QMessageBox::Ok, QMessageBox::Cancel) == QMessageBox::Ok) {
          m_app->tryRenameAfterReset(absFilename, newPath);
        }
#else
        QMessageBox::warning(
          nullptr, tr("File Error"),
          tr("Error while renaming:\n") +
          tr("Rename %1 to %2 failed\n").arg(fileName, newFileName),
          QMessageBox::Ok, Qt::NoButton);
#endif
      }
    }
  }
```

#### AUTO 


```{c}
auto vlayout = new QVBoxLayout(networkPage);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& val : extraartists) {
            ExtraArtist extraArtist(val.toObject());
            extraArtist.addToFrames(frames);
          }
```

#### RANGE FOR STATEMENT 


```{c}
for (QString filter : includeFolders) {
    filter.replace(QLatin1Char('\\'), QLatin1Char('/'));
    m_includeFolderFilters.append(
          QRegExp(filter, Qt::CaseInsensitive, QRegExp::Wildcard));
  }
```

#### AUTO 


```{c}
const auto& mp4NameTypeValue
```

#### AUTO 


```{c}
auto labels = map.value(QLatin1String("labels")).toArray();
```

#### AUTO 


```{c}
auto vlayout = new QVBoxLayout(actionsPage);
```

#### AUTO 


```{c}
auto it = map.constFind(QLatin1String("open_parent"));
```

#### AUTO 


```{c}
auto idHBoxLayout = new QHBoxLayout(m_tagWidget[tagNr]);
```

#### RANGE FOR STATEMENT 


```{c}
for (ServerImporter* importer : importers) {
    if (QString::fromLatin1(importer->name()) == name) {
      return importer;
    }
  }
```

#### AUTO 


```{c}
auto editFormatsFromTagButton =
          new QPushButton(tr("Filename from tag") + QLatin1String("..."));
```

#### RANGE FOR STATEMENT 


```{c}
for (const Frame& frame : frames) {
            TagLib::FLAC::Picture* pic = new TagLib::FLAC::Picture;
            frameToFlacPicture(frame, pic);
            flacFile->addPicture(pic);
          }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QPersistentModelIndex& index : selectedIndexes) {
    TaggedFile* taggedFile = FileProxyModel::getTaggedFileOfIndex(index);
    QString absFilename, dirName, fileName;
    if (taggedFile) {
      absFilename = taggedFile->getAbsFilename();
      dirName = taggedFile->getDirname();
      fileName = taggedFile->getFilename();
    } else {
      QFileInfo fi(model->fileInfo(index));
      absFilename = fi.filePath();
      dirName = fi.dir().path();
      fileName = fi.fileName();
    }
    bool ok;
    QString newFileName = QInputDialog::getText(
      m_w,
      tr("Rename File"),
      tr("Enter new file name:"),
      QLineEdit::Normal, fileName, &ok);
    if (ok && !newFileName.isEmpty() && newFileName != fileName) {
      if (taggedFile) {
        if (taggedFile->isChanged()) {
          taggedFile->setFilename(newFileName);
          if (selItems.size() == 1)
            m_form->setFilename(newFileName);
          continue;
        }
        // This will close the file.
        // The file must be closed before renaming on Windows.
        taggedFile->closeFileHandle();
      } else if (model->isDir(index)) {
        // The directory must be closed before renaming on Windows.
        TaggedFileIterator::closeFileHandles(index);
      }
      QString newPath = dirName + QLatin1Char('/') + newFileName;
      if (!Utils::safeRename(absFilename, newPath)) {
#ifdef Q_OS_WIN32
        if (QMessageBox::warning(
              0, tr("File Error"),
              tr("Error while renaming:\n") +
              tr("Rename %1 to %2 failed\n").arg(fileName).arg(newFileName) +
              tr("Retry after closing directories?"),
              QMessageBox::Ok, QMessageBox::Cancel) == QMessageBox::Ok) {
          m_app->tryRenameAfterReset(absFilename, newPath);
        }
#else
        QMessageBox::warning(
          nullptr, tr("File Error"),
          tr("Error while renaming:\n") +
          tr("Rename %1 to %2 failed\n").arg(fileName, newFileName),
          QMessageBox::Ok, Qt::NoButton);
#endif
      }
    }
  }
```

#### AUTO 


```{c}
auto destLayout = new QFormLayout;
```

#### AUTO 


```{c}
auto toolsNumberTracks = new QAction(this);
```

#### LAMBDA EXPRESSION 


```{c}
[]() { return &PlaylistConfig::instance(); }
```

#### AUTO 


```{c}
auto it = data.constBegin();
```

#### AUTO 


```{c}
const auto idxs = indexesWithChildren;
```

#### AUTO 


```{c}
auto model =
      qobject_cast<FileProxyModel*>(m_form->getFileList()->model())
```

#### AUTO 


```{c}
auto events = result.value(QLatin1String("events")).toArray();
```

#### AUTO 


```{c}
auto le = qobject_cast<QLineEdit*>(editor)
```

#### AUTO 


```{c}
auto it = m_extensions.constBegin();
```

#### AUTO 


```{c}
auto authLayout = new QGridLayout;
```

#### AUTO 


```{c}
const auto selectedIndexes = m_fileSelectionModel->selectedRows();
```

#### AUTO 


```{c}
auto it = genreList.constBegin();
```

#### AUTO 


```{c}
auto deleteAction = new QAction(this);
```

#### AUTO 


```{c}
auto proxyHbox = new QHBoxLayout;
```

#### AUTO 


```{c}
const auto& nameType
```

#### AUTO 


```{c}
auto metaObj = cfg->metaObject()
```

#### AUTO 


```{c}
const auto &update
```

#### AUTO 


```{c}
auto r = reinterpret_cast<char*>(::malloc(name.length() + 1));
```

#### AUTO 


```{c}
auto hspacer = new QSpacerItem(16, 0, QSizePolicy::Expanding,
                                         QSizePolicy::Minimum);
```

#### AUTO 


```{c}
auto& frameFound = const_cast<Frame&>(*it);
```

#### AUTO 


```{c}
auto ed = new QLineEdit;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QFileInfo& fi : entries) {
    QString fileName = fi.fileName();
    if (classify) {
      if (fi.isDir()) fileName += QLatin1Char('/');
      else if (fi.isSymLink()) fileName += QLatin1Char('@');
      else if (fi.isExecutable()) fileName += QLatin1Char('*');
    }
    dirList.append(fileName);
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto field : fields) {
      start = str.indexOf(QString::fromLatin1(field) + QLatin1Char('<'));
      if (start >= 0) {
        start += qstrlen(field); // skip field
        end = str.indexOf(QLatin1String("</div>"), start + 1);
        if (end > start) {
          QString genreStr = str.mid(start, end - start);
          // strip new lines and space after them
          genreStr.replace(nlSpaceRe, QLatin1String(""));
          genreStr = removeHtml(genreStr); // strip HTML tags and entities
          if (genreStr.indexOf(QLatin1Char(',')) >= 0) {
            genreList += genreStr.split(QRegExp(QLatin1String(",\\s*")));
          } else {
            if (!genreStr.isEmpty()) {
              genreList += genreStr;
            }
          }
        }
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl& url : urls) {
    paths.append(url.toLocalFile());
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& param : params) {
            QString arg = param.toString();
            if (arg.isEmpty()) {
              if (param.isArray()) {
                // Special handling for tags parameter of the form [1, 2]
                const auto elements = param.toArray();
                for (const auto& element : elements) {
                  int tagNr = element.toInt();
                  if (tagNr > 0 && tagNr <= Frame::Tag_NumValues) {
                    arg += QLatin1Char('0' + static_cast<char>(tagNr));
                  } else {
                    arg.clear();
                    break;
                  }
                }
              } else if (param.isDouble()) {
                // Allow integer numbers, for example for track numbers
                int argInt = param.toInt(INT_MIN);
                if (argInt != INT_MIN) {
                  arg = QString::number(argInt);
                }
              } else if (param.isBool()) {
                arg = QLatin1String(param.toBool() ? "true" : "false");
              }
            }
            m_args.append(arg);
          }
```

#### AUTO 


```{c}
auto it = urlMap.constBegin();
```

#### AUTO 


```{c}
auto it = m_trackDataVector.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QPersistentModelIndex& index : selectedIndexes) {
        QString absFilename(model->filePath(index));
        if (model->isDir(index)) {
          if (!m_platformTools->moveToTrash(absFilename)) {
            rmdirError = true;
            files.append(absFilename);
          }
        } else {
          if (TaggedFile* taggedFile =
              FileProxyModel::getTaggedFileOfIndex(index)) {
            // This will close the file.
            // The file must be closed before deleting on Windows.
            taggedFile->closeFileHandle();
          }
          if (!m_platformTools->moveToTrash(absFilename)) {
            files.append(absFilename);
          }
        }
      }
```

#### AUTO 


```{c}
auto group =
          const_cast<ShortcutGroup*>(shortcutGroupForIndex(parentIndex))
```

#### AUTO 


```{c}
const auto trackList = map.value(QLatin1String("tracklist")).toArray();
```

#### AUTO 


```{c}
const auto indexes = selModel->selectedRows();
```

#### AUTO 


```{c}
auto mode
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& picturePath : constPicturePaths) {
      PictureFrame frame;
      if (PictureFrame::setDataFromFile(frame, picturePath)) {
        QString fileName(picturePath);
        int slashPos = fileName.lastIndexOf(QLatin1Char('/'));
        if (slashPos != -1) {
          fileName = fileName.mid(slashPos + 1);
        }
        PictureFrame::setMimeTypeFromFileName(frame, fileName);
        PictureFrame::setDescription(frame, fileName);
        PictureFrame::setTextEncoding(frame, frameTextEncodingFromConfig());
        addFrame(Frame::Tag_Picture, &frame);
        emit selectedFilesUpdated();
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (IUserCommandProcessor* userCommandProcessor : userCommandProcessors) {
      if (userCommandProcessor->userCommandKeys().contains(program)) {
        connect(userCommandProcessor->qobject(), SIGNAL(finished(int)),
                this, SIGNAL(finished(int)), Qt::UniqueConnection);
        if (userCommandProcessor->startUserCommand(program, arguments,
                                                   showOutput)) {
          return true;
        }
      }
    }
```

#### AUTO 


```{c}
auto it = rootQuery.constBegin();
```

#### AUTO 


```{c}
const auto &filter
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& frameName : names) {
      QString ucFrameName(frameName.toUpper().remove(QLatin1Char('/')));
#if QT_VERSION >= 0x060000
      if (ucName == ucFrameName.left(len))
#else
      if (ucName == ucFrameName.leftRef(len))
#endif
      {
        return it;
      }
      int nlPos = ucFrameName.indexOf(QLatin1Char('\n'));
#if QT_VERSION >= 0x060000
      if (nlPos > 0 && ucName == ucFrameName.mid(nlPos + 1, len))
#else
      if (nlPos > 0 && ucName == ucFrameName.midRef(nlPos + 1, len))
#endif
      {
        // Description in TXXX, WXXX, COMM, PRIV matches
        return it;
      }
    }
```

#### AUTO 


```{c}
auto cb = qobject_cast<QComboBox*>(editor);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto field : fields) {
      start = str.indexOf(QString::fromLatin1(field) + QLatin1Char('<'));
      if (start >= 0) {
        start += qstrlen(field); // skip field
        end = str.indexOf(QLatin1String("</div>"), start + 1);
        if (end > start) {
          QString genreStr = str.mid(start, end - start);
          // strip new lines and space after them
          genreStr.replace(nlSpaceRe, QLatin1String(""));
          genreStr = removeHtml(genreStr); // strip HTML tags and entities
          genreStr.remove(QLatin1String("RockStyle:"));
          if (genreStr.indexOf(QLatin1Char(',')) >= 0) {
            genreList += genreStr.split(QRegularExpression(QLatin1String(",\\s*")));
          } else {
            if (!genreStr.isEmpty()) {
              genreList += genreStr;
            }
          }
        }
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto instrument : instruments) {
    if (role.contains(QString::fromLatin1(instrument))) {
      return Frame::FT_Performer;
    }
  }
```

#### AUTO 


```{c}
auto namesIt = names.constBegin(), headersIt = headers.constBegin(),
         tracksIt = tracks.constBegin();
```

#### AUTO 


```{c}
const auto idxs = m_items;
```

#### AUTO 


```{c}
auto time = qFromBigEndian<quint32>(
          reinterpret_cast<const uchar*>(bytes.constData()) + textEnd);
```

#### RANGE FOR STATEMENT 


```{c}
for (IUserCommandProcessor* userCommandProcessor : userCommandProcessors) {
    userCommandProcessor->initialize(m_app);
    connect(userCommandProcessor->qobject(), SIGNAL(commandOutput(QString)),
            this, SLOT(showOutputLine(QString)));
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QFileInfo &fi : driveInfoList)
        drives.append(translateDriveName(fi));
```

#### AUTO 


```{c}
auto profileLayout = new QVBoxLayout(profileWidget);
```

#### AUTO 


```{c}
auto vlayout = new QVBoxLayout(page);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& filePath : filePaths) {
          QFile::setPermissions(filePath,
              QFile::permissions(filePath) | QFile::WriteUser);
          if (model &&
              (taggedFile = FileProxyModel::getTaggedFileOfIndex(
                 model->index(filePath))) != 0) {
            taggedFile->undoRevertChangedFilename();
          }
        }
```

#### AUTO 


```{c}
const auto pluginNames = tagCfg.availablePlugins();
```

#### AUTO 


```{c}
auto mpcFile =
                   dynamic_cast<TagLib::MPC::File*>(file)
```

#### AUTO 


```{c}
const auto subTracks((track.contains(QLatin1String("sub_tracks"))
                               ? track.value(QLatin1String("sub_tracks"))
                               : track.value(QLatin1String("subTracks")))
                              .toArray());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &file : files)
                infoList << QFileInfo(file);
```

#### AUTO 


```{c}
auto shortcuts = m_self->shortcutsMap();
```

#### AUTO 


```{c}
auto it = m_frames.upper_bound(frame);
```

#### RANGE FOR STATEMENT 


```{c}
for (FileSystemNode *child : constChildren) {
#endif
                //On windows the root (My computer) has no path so we don't want to add a / for nothing (e.g. /C:/)
                if (!path.isEmpty()) {
                    if (path.endsWith(QLatin1Char('/')))
                        child->updateIcon(iconProvider, path + child->fileName);
                    else
                        child->updateIcon(iconProvider, path + QLatin1Char('/') + child->fileName);
                } else
                    child->updateIcon(iconProvider, child->fileName);
            }
```

#### AUTO 


```{c}
auto vc = new FLAC::Metadata::VorbisComment;
```

#### RANGE FOR STATEMENT 


```{c}
for (const TimeEvent& timeEvent : timeEvents) {
    if (!timeEvent.time.isNull()) {
      QString str = timeEvent.data.toString();
      // Remove escaping, restore new line characters.
      if (str.startsWith(QLatin1Char('_'))) {
        str.remove(0, 1);
      } else if (str.startsWith(QLatin1Char('#'))) {
        str.replace(0, 1, QLatin1Char('\n'));
      } else if (!(str.startsWith(QLatin1Char(' ')) ||
                   str.startsWith(QLatin1Char('-')))) {
        str.prepend(QLatin1Char('\n'));
      }

      quint32 milliseconds;
#if QT_VERSION >= 0x060000
      if (timeEvent.time.typeId() == QMetaType::QTime) {
#else
      if (timeEvent.time.type() == QVariant::Time) {
#endif
        hasMsTimeStamps = true;
        milliseconds = QTime(0, 0).msecsTo(timeEvent.time.toTime());
      } else {
        milliseconds = timeEvent.data.toUInt();
      }
      synchedData.append(milliseconds);
      synchedData.append(str);
    }
  }
```

#### AUTO 


```{c}
auto frameType = map.value(QLatin1String("type")).toInt();
```

#### AUTO 


```{c}
auto itk = keys.constBegin(), itv = values.constBegin();
```

#### AUTO 


```{c}
auto clearButton = new QToolButton(this);
```

#### AUTO 


```{c}
auto intctl = new IntFieldControl(fld);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& pattern : patternList) {
    QString folder = pattern.trimmed();
    if (!folder.isEmpty()) {
      folders.append(folder);
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const TimeEvent& timeEvent : timeEvents) {
    QTime time = timeEvent.time.toTime();
    if (time.isValid()) {
      char firstChar = '\0';
      bool newLine = true;
      QString str;
      if (m_type == EventTimingCodes) {
        str = EventTimeCode(timeEvent.data.toInt()).toString();
      } else {
        str = timeEvent.data.toString();
        if (str.startsWith(QLatin1Char('_'))) {
          str.remove(0, 1);
          newLine = false;
        } else if (str.startsWith(QLatin1Char('#'))) {
          str.remove(0, 1);
        } else if (str.startsWith(QLatin1Char(' ')) ||
                   str.startsWith(QLatin1Char('-'))) {
          firstChar = str.at(0).toLatin1();
          str.remove(0, 1);
          newLine = false;
        }
      }

      if (newLine) {
        if (!atBegin) {
          stream << QLatin1String("\r\n");
        }
        stream << QLatin1Char('[') << timeStampToString(time).toLatin1()
               << QLatin1Char(']') << str.toLatin1();
      } else {
        if (firstChar != '\0') {
          stream << firstChar;
        }
        stream << QLatin1Char('<') << timeStampToString(time).toLatin1()
               << QLatin1Char('>') << str.toLatin1();
      }
      atBegin = false;
    }
  }
```

#### AUTO 


```{c}
auto it = m_cmds.begin();
```

#### AUTO 


```{c}
auto helpHandbook = new QAction(this);
```

#### AUTO 


```{c}
auto toolsApplyTagFormat = new QAction(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& key : keys) {
        m_importers.append(importerFactory->createServerImporter(
                             key, m_netMgr, m_trackDataModel));
      }
```

#### AUTO 


```{c}
auto mainPage = new QWizardPage;
```

#### AUTO 


```{c}
auto i = parentNode->children.constBegin(), cend = parentNode->children.constEnd();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& index : selectedIndexes) {
    if (m_fileProxyModel->isDir(index)) {
      indexes.append(index);
    }
  }
```

#### AUTO 


```{c}
auto model = const_cast<TaggedFileSystemModel*>(
        qobject_cast<const TaggedFileSystemModel*>(index.model()))
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& frameName : names) {
      QString ucFrameName(frameName.toUpper().remove(QLatin1Char('/')));
#if QT_VERSION >= 0x060000
      if (ucName == ucFrameName.left(len))
#else
      // Do not return ASF "Rating Information" when searching for "Rating".
      if (ucName == ucFrameName.leftRef(len) &&
          !(ucName == QLatin1String("RATING") &&
            ucFrameName == QLatin1String("RATING INFORMATION")))
#endif
      {
        return it;
      }
      int nlPos = ucFrameName.indexOf(QLatin1Char('\n'));
#if QT_VERSION >= 0x060000
      if (nlPos > 0 && ucName == ucFrameName.mid(nlPos + 1, len))
#else
      if (nlPos > 0 && ucName == ucFrameName.midRef(nlPos + 1, len))
#endif
      {
        // Description in TXXX, WXXX, COMM, PRIV matches
        return it;
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto field : fields) {
      start = str.indexOf(QString::fromLatin1(field) + QLatin1Char('<'));
      if (start >= 0) {
        start += qstrlen(field); // skip field
        end = str.indexOf(QLatin1String("</div>"), start + 1);
        if (end > start) {
          QString genreStr = str.mid(start, end - start);
          // strip new lines and space after them
          genreStr.replace(nlSpaceRe, QLatin1String(""));
          genreStr = removeHtml(genreStr); // strip HTML tags and entities
          if (genreStr.indexOf(QLatin1Char(',')) >= 0) {
            genreList += genreStr.split(QRegularExpression(QLatin1String(",\\s*")));
          } else {
            if (!genreStr.isEmpty()) {
              genreList += genreStr;
            }
          }
        }
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& freeFormNameType : freeFormNameTypes) {
        freeFormNameTypeMap.insert(QString::fromLatin1(freeFormNameType.name),
                                   freeFormNameType.type);
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& key : keys) {
      extensions.append(factory->supportedFileExtensions(key));
    }
```

#### AUTO 


```{c}
auto fit = files.constBegin();
```

#### AUTO 


```{c}
auto button = qobject_cast<QPushButton*>(sender())
```

#### AUTO 


```{c}
auto namesIt = names.constBegin(), expressionsIt = expressions.constBegin();
```

#### AUTO 


```{c}
const auto constQmlDirs = qmlDirs;
```

#### AUTO 


```{c}
auto topLayout = new QVBoxLayout(this);
```

#### AUTO 


```{c}
auto match = discLenRe.match(text);
```

#### RANGE FOR STATEMENT 


```{c}
for (int column : columns) {
    m_fileListBox->resizeColumnToContents(column);
  }
```

#### AUTO 


```{c}
auto editNextFile = new QAction(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &persistentIndex : persistentList) {
            FileSystemModelPrivate::FileSystemNode *node = d->node(persistentIndex);
            while (node) {
                if (d->bypassFilters.contains(node))
                    break;
                if (node->isDir())
                    d->bypassFilters[node] = true;
                node = node->parent;
            }
        }
```

#### AUTO 


```{c}
const auto fileIndexes = m_fileProxyModelFileIndexes;
```

#### AUTO 


```{c}
auto starEditor = qobject_cast<StarEditor*>(editor)
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& c2n : codeToName) {
    QString from = QString::fromLatin1(c2n.from);
    QString to = QString::fromLatin1(c2n.to);
    from = from.size() == 1 ? QLatin1Char('%') + from : prefix + from + suffix;
    to = prefix + to + suffix;
    pattern.replace(from, to);
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& val : durationHms) {
      duration *= 60;
      duration += val.toInt();
    }
```

#### AUTO 


```{c}
const auto deselectedRanges = mapSelectionFromSource(deselected);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto instrument : instruments) {
            if ((*cit).contains(QString::fromLatin1(instrument))) {
              addInvolvedPeople(frames, Frame::FT_Performer, *cit, name);
              found = true;
              break;
            }
          }
```

#### AUTO 


```{c}
auto fieldObj = new FrameFieldObject(i, this);
```

#### AUTO 


```{c}
auto editor = qobject_cast<StarEditor*>(sender())
```

#### AUTO 


```{c}
auto ttaFile =
            dynamic_cast<TagLib::TrueAudio::File*>(file)
```

#### AUTO 


```{c}
const auto columns = guiCfg.fileListVisibleColumns();
```

#### RANGE FOR STATEMENT 


```{c}
for (QStringList strs : constCmdStrs) {
    QString cmdStr = strs.takeFirst();
    cmdStr += QString(maxLength - cmdStr.size() + 2, QLatin1Char(' '));
    cmdStr += strs.takeFirst();
    writeLine(cmdStr);
    while (!strs.isEmpty()) {
      cmdStr = QString(maxLength + 2, QLatin1Char(' '));
      cmdStr += strs.takeFirst();
      writeLine(cmdStr);
    }
  }
```

#### AUTO 


```{c}
auto rightLayout = new QVBoxLayout;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& filePath :  constFilePaths) {
      QModelIndex index = m_fsModel->index(filePath);
      if (index.isValid()) {
        m_items.append(index);
      }
    }
```

#### AUTO 


```{c}
auto moveUpAction = new QAction(this);
```

#### AUTO 


```{c}
const auto& language
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& val : trackList) {
    auto track = val.toObject();

    TrackInfo trackInfo(track);

    const auto artists((track.contains(QLatin1String("artists"))
                        ? track.value(QLatin1String("artists"))
                        : track.value(QLatin1String("primaryArtists")))
                       .toArray());
    if (!artists.isEmpty()) {
      if (standardTags) {
        frames.setArtist(getArtistString(artists));
      }
      if (additionalTags) {
        frames.setValue(Frame::FT_AlbumArtist, framesHdr.getArtist());
      }
    }
    if (additionalTags) {
      const auto extraartists((track.contains(QLatin1String("extraartists"))
                               ? track.value(QLatin1String("extraartists"))
                               : track.value(QLatin1String("trackCredits")))
                              .toArray());
      if (!extraartists.isEmpty()) {
        for (const auto& val : extraartists) {
          ExtraArtist extraArtist(val.toObject());
          extraArtist.addToFrames(frames);
        }
      }
    }
    if (!allPositionsEmpty && trackInfo.position().isEmpty()) {
      const auto subTracks((track.contains(QLatin1String("sub_tracks"))
                               ? track.value(QLatin1String("sub_tracks"))
                               : track.value(QLatin1String("subTracks")))
                              .toArray());
      if (!subTracks.isEmpty()) {
        if (additionalTags) {
          frames.setValue(Frame::FT_Subtitle, trackInfo.title());
        }
        for (const auto& val : subTracks) {
          TrackInfo subTrackInfo(val.toObject());
          subTrackInfo.addToFrames(frames, trackExtraArtists,
                                   standardTags, additionalTags);
          addFramesToTrackData(frames, subTrackInfo.duration());
        }
      }
    } else if (!trackInfo.title().isEmpty() || trackInfo.duration() != 0) {
      trackInfo.addToFrames(frames, trackExtraArtists,
                            standardTags, additionalTags);
      addFramesToTrackData(frames, trackInfo.duration());
    }
    frames = framesHdr;
  }
```

#### AUTO 


```{c}
auto it = m_columnWidths.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& filePath : filePaths) {
#ifdef Q_OS_MAC
          // On macOS, files may be locked, so try to make them mutable.
          const auto utf8Path = filePath.toUtf8();
          struct stat st;
          if (::stat(utf8Path.constData(), &st) == 0 &&
              st.st_flags & UF_IMMUTABLE) {
            ::chflags(utf8Path.constData(), st.st_flags & ~UF_IMMUTABLE);
          }
#endif
          QFile::setPermissions(filePath,
              QFile::permissions(filePath) | QFile::WriteUser);
          if (model &&
              (taggedFile = FileProxyModel::getTaggedFileOfIndex(
                 model->index(filePath))) != nullptr) {
            taggedFile->undoRevertChangedFilename();
          }
        }
```

#### AUTO 


```{c}
auto initFrameType
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& index : selectedRows) {
    int from = index.row();
    int to = from + diff;
    if (!fromList.contains(from) &&
        from >= 0 && from < numTracks &&
        to >= 0 && to < numTracks) {
      fromList.append(from);
    }
  }
```

#### AUTO 


```{c}
const auto constPicturePaths = picturePaths;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& line : lines) {
    int lineWidth = fm.width(line);
    if (maxWidth < lineWidth) {
      maxWidth = lineWidth;
    }
  }
```

#### AUTO 


```{c}
auto fsModel = static_cast<QFileSystemModel*>(sourceModel());
```

#### AUTO 


```{c}
auto si =
                dynamic_cast<FLAC::Metadata::StreamInfo*>(proto);
```

#### AUTO 


```{c}
const auto genreList = map.value(QLatin1String("styles")).toArray() +
        map.value(QLatin1String("genres")).toArray();
```

#### AUTO 


```{c}
auto fileSave = new QAction(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& part : parts) {
    auto s = part.trimmed();
    bool ok;
    int n = s.toInt(&ok);
    if (s == QLatin1String("RX") || s == QLatin1String("CR")) {
      genres.append(s);
    } else if ((ok && n >= 0 && n <= 255) ||
               (n = getNumber(s)) < 0xff) {
      genres.append(QString::number(n));
    } else if (!parentheses) {
      genres.append(s);
    } else if (genreText.isEmpty()) {
      // For ID3v2.3.0, we can append only one genre text as a refinement
      genreText = s;
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (Frame::TagNumber tagNr : Frame::allTagNumbers()) {
      if (frames2.empty()) {
        taggedFile->getAllFrames(tagNr, frames2);
      } else {
        FrameCollection frames1;
        taggedFile->getAllFrames(tagNr, frames1);
        frames2.merge(frames1);
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& val : trackList) {
    auto track = val.toObject();

    QString position(track.value(QLatin1String("position")).toString());
    bool ok;
    int pos = position.toInt(&ok);
    if (!ok) {
      auto match = discTrackPosRe.match(position);
      if (match.hasMatch()) {
        if (additionalTags) {
          frames.setValue(Frame::FT_Disc, match.captured(1));
        }
        pos = match.captured(2).toInt();
      } else {
        pos = trackNr;
      }
    }
    QString title(track.value(QLatin1String("title")).toString().trimmed());

    const QStringList durationHms = track.value(QLatin1String("duration"))
        .toString().split(QLatin1Char(':'));
    int duration = 0;
    for (const auto& val : durationHms) {
      duration *= 60;
      duration += val.toInt();
    }
    if (!allPositionsEmpty && position.isEmpty()) {
      if (additionalTags) {
        framesHdr.setValue(Frame::FT_Subtitle, title);
      }
    } else if (!title.isEmpty() || duration != 0) {
      if (standardTags) {
        frames.setTrack(pos);
        frames.setTitle(title);
      }
      const auto artists(track.value(QLatin1String("artists")).toArray());
      if (!artists.isEmpty()) {
        if (standardTags) {
          frames.setArtist(getArtistString(artists));
        }
        if (additionalTags) {
          frames.setValue(Frame::FT_AlbumArtist, framesHdr.getArtist());
        }
      }
      if (additionalTags) {
        const auto extraartists(track.value(QLatin1String("extraartists")).toArray());
        if (!extraartists.isEmpty()) {
          for (const auto& val : extraartists) {
            ExtraArtist extraArtist(val.toObject());
            extraArtist.addToFrames(frames);
          }
        }
      }
      for (const auto& extraArtist : trackExtraArtists) {
        extraArtist.addToFrames(frames, position);
      }

      if (atTrackDataListEnd) {
        ImportTrackData trackData;
        trackData.setFrameCollection(frames);
        trackData.setImportDuration(duration);
        trackDataVector.append(trackData);
      } else {
        while (!atTrackDataListEnd && !it->isEnabled()) {
          ++it;
          atTrackDataListEnd = (it == trackDataVector.end());
        }
        if (!atTrackDataListEnd) {
          (*it).setFrameCollection(frames);
          (*it).setImportDuration(duration);
          ++it;
          atTrackDataListEnd = (it == trackDataVector.end());
        }
      }
      ++trackNr;
    }
    frames = framesHdr;
  }
```

#### AUTO 


```{c}
auto reOptions = (filters & QDir::CaseSensitive)
            ? QRegularExpression::NoPatternOption
            : QRegularExpression::CaseInsensitiveOption;
```

#### AUTO 


```{c}
const auto frames = m_extraFrames;
```

#### AUTO 


```{c}
auto it = strNumMap.constFind(name);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QPersistentModelIndex& fileIndex : fileIndexes) {
        m_fileSelectionModel->select(fileIndex,
            QItemSelectionModel::Select | QItemSelectionModel::Rows);
      }
```

#### AUTO 


```{c}
auto butspacer = new QSpacerItem(16, 0, QSizePolicy::Expanding,
                                         QSizePolicy::Minimum);
```

#### AUTO 


```{c}
auto it = customGenres.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& filePath : errorFiles) {
      QFileInfo fileInfo(filePath);
      if (!fileInfo.isWritable()) {
        errorMsgs.append(tr("%1 is not writable").arg(fileInfo.fileName()));
        notWritableFiles.append(filePath);
      } else {
        errorMsgs.append(fileInfo.fileName());
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& c2t : creditToType) {
          if (type == QString::fromLatin1(c2t.credit)) {
            frames.setValue(c2t.type, artist);
            found = true;
            break;
          }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const ServerImporter* si : sis) {
    QString serverName(QCoreApplication::translate("@default", si->name()));
    QString actionName = QString::fromLatin1(
          si->name()).toLower().remove(QLatin1Char(' '));
    int dotPos = actionName.indexOf(QLatin1Char('.'));
    if (dotPos != -1)
      actionName.truncate(dotPos);
    actionName = QLatin1String("import_") + actionName;
    QAction* fileImportServer = new QAction(this);
    fileImportServer->setData(importerIdx);
    fileImportServer->setStatusTip(tr("Import from %1").arg(serverName));
    fileImportServer->setText(tr("Import from %1...").arg(serverName));
    fileImportServer->setObjectName(actionName);
    m_shortcutsModel->registerAction(fileImportServer, menuTitle);
    connect(fileImportServer, SIGNAL(triggered()),
      impl(), SLOT(slotImport()));
    fileMenu->addAction(fileImportServer);
    ++importerIdx;
  }
```

#### AUTO 


```{c}
const auto& r = m_cont.at(row);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& index : indexes) {
    rows.append(index.row());
  }
```

#### AUTO 


```{c}
auto namesIt = names.constBegin(), sourcesIt = sources.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (int frameType : constFrameTypes) {
    QStandardItem* item = new QStandardItem(
          Frame::ExtendedType(static_cast<Frame::Type>(frameType))
          .getTranslatedName());
    item->setData(frameType, Qt::UserRole);
    item->setCheckable(true);
    item->setCheckState((frameMask & (1ULL << frameType))
                        ? Qt::Checked : Qt::Unchecked);
    item->setDropEnabled(false);
    m_quickAccessTagsModel->appendRow(item);
  }
```

#### AUTO 


```{c}
auto it = fields.constBegin();
```

#### AUTO 


```{c}
auto iodev = reinterpret_cast<QIODevice*>(stream)
```

#### AUTO 


```{c}
auto editor =
      qobject_cast<ShortcutsDelegateEditor*>(sender())
```

#### AUTO 


```{c}
auto it = strNumMap.constFind(str);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& element : elements) {
                  int tagNr = element.toInt();
                  if (tagNr > 0 && tagNr <= Frame::Tag_NumValues) {
                    arg += QLatin1Char('0' + static_cast<char>(tagNr));
                  } else {
                    arg.clear();
                    break;
                  }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (QObject* plugin : plugins) {
    checkPlugin(plugin);
  }
```

#### AUTO 


```{c}
const auto names = idStrMap.values();
```

#### AUTO 


```{c}
auto buttonLayout = new QVBoxLayout;
```

#### AUTO 


```{c}
auto wvFile =
                   dynamic_cast<TagLib::WavPack::File*>(file)
```

#### RANGE FOR STATEMENT 


```{c}
for (IUserCommandProcessor* userCommandProcessor : userCommandProcessors) {
      if (userCommandProcessor->userCommandKeys().contains(program) &&
          userCommandProcessor->startUserCommand(program, arguments, showOutput))
        return;
    }
```

#### AUTO 


```{c}
const auto selectedIndexes = selected.indexes();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& pluginName : pluginNames) {
      int pluginIdx = pluginOrder.indexOf(pluginName);
      if (pluginIdx >= 0) {
        metadataPlugins[pluginIdx] = pluginName;
      } else {
        metadataPlugins.append(pluginName); // clazy:exclude=reserve-candidates
      }
    }
```

#### AUTO 


```{c}
auto tabWidget = new QTabWidget(this);
```

#### AUTO 


```{c}
auto catIdTitleMatch = catIdTitleRe.match(str, end);
```

#### AUTO 


```{c}
auto mainLayout = new QVBoxLayout(mainPage);
```

#### AUTO 


```{c}
auto action = new QAction(form());
```

#### AUTO 


```{c}
auto it = m_cmds.constBegin();
```

#### AUTO 


```{c}
auto it = m_playlistModels.begin();
```

#### AUTO 


```{c}
auto formatLayout = new QFormLayout(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& value : strList) {
    result.append(value.toInt());
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& path : pathList) {
    if (!path.isEmpty()) {
      QFileInfo fileInfo(path);
      if (fileCheck && !fileInfo.exists()) {
        ok = false;
        break;
      }
      QString dirPath;
      if (!fileInfo.isDir()) {
        dirPath = fileInfo.absolutePath();
        if (fileInfo.isFile()) {
          filePaths.append(fileInfo.absoluteFilePath());
        }
      } else {
        dirPath = QDir(path).absolutePath();
      }
      QStringList dirPathComponents = dirPath.split(QDir::separator());
      if (dirComponents.isEmpty()) {
        dirComponents = dirPathComponents;
      } else {
        // Reduce dirPath to common prefix.
        QStringList::iterator dirIt = dirComponents.begin();
        QStringList::const_iterator dirPathIt = dirPathComponents.constBegin();
        while (dirIt != dirComponents.end() &&
               dirPathIt != dirPathComponents.constEnd() &&
               *dirIt == *dirPathIt) {
          ++dirIt;
          ++dirPathIt;
        }
        dirComponents.erase(dirIt, dirComponents.end());
      }
    }
  }
```

#### AUTO 


```{c}
auto v2GroupBoxLayout = new QGridLayout(v2GroupBox);
```

#### AUTO 


```{c}
auto it = trackDataList.begin();
```

#### AUTO 


```{c}
auto c = static_cast<unsigned char>(data[i]);
```

#### AUTO 


```{c}
auto nameLayout = new QHBoxLayout;
```

#### RANGE FOR STATEMENT 


```{c}
for (const ServerImporter* si : sis) {
    servers.append(QString::fromLatin1(si->name()));
  }
```

#### AUTO 


```{c}
auto it = m_files.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& line : lines) {
    QStringList strs = line.split(QLatin1Char(' '));
    if (strs.size() > 1) {
      bool ok;
      int typeInt = strs.at(0).toInt(&ok);
      if (ok && typeInt >= 0 && typeInt <= 8) {
        short adj = strs.at(1).toShort(&ok);
        if (ok) {
          auto type =
              static_cast<TagLib::ID3v2::RelativeVolumeFrame::ChannelType>(
                typeInt);
          rva2Frame->setVolumeAdjustmentIndex(adj, type);
          TagLib::ID3v2::RelativeVolumeFrame::PeakVolume peak;
          if (strs.size() > 3) {
            int bitsInt = strs.at(2).toInt(&ok);
            QByteArray ba = QByteArray::fromHex(strs.at(3).toLatin1());
            if (ok && bitsInt > 0 && bitsInt <= 255 &&
                bitsInt <= ba.size() * 8) {
              peak.bitsRepresentingPeak = bitsInt;
              peak.peakVolume.setData(ba.constData(), ba.size());
              rva2Frame->setPeakVolume(peak, type);
            }
          }
        }
      }
    }
  }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { emit finished(0); }
```

#### AUTO 


```{c}
const auto results = obj.value(QLatin1String("results")).toArray();
```

#### AUTO 


```{c}
auto kid3App = new Kid3Application(platformTools);
```

#### AUTO 


```{c}
auto it = m_pictures.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& fileName : fileNames) {
    languages.append(fileName.mid(5, fileName.length() - 8));
  }
```

#### AUTO 


```{c}
auto it = frames.find(
        Frame(Frame::FT_Picture, QLatin1String(""), QLatin1String(""), -1));
```

#### AUTO 


```{c}
auto fileNameForEmptyLayout = new QHBoxLayout;
```

#### RANGE FOR STATEMENT 


```{c}
for (ITaggedFileFactory* factory : factories) {
    const auto keys = factory->taggedFileKeys();
    for (const QString& key : keys) {
      if ((factory->taggedFileFeatures(key) & feature) != 0 &&
          (taggedFile = factory->createTaggedFile(key, fileName, idx,
                                                  feature))
          != nullptr) {
        return taggedFile;
      }
    }
  }
```

#### AUTO 


```{c}
auto editFind = new QAction(this);
```

#### AUTO 


```{c}
auto optionsLayout = new QVBoxLayout(optionsBox);
```

#### AUTO 


```{c}
auto it = sel.begin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QPersistentModelIndex& index : selectedIndexes) {
        QString absFilename(model->filePath(index));
        if (!QFileInfo(absFilename).isWritable()) {
          QFile::setPermissions(absFilename,
              QFile::permissions(absFilename) | QFile::WriteUser);
        }
        if (model->isDir(index)) {
          if (!m_platformTools->moveToTrash(absFilename)) {
            rmdirError = true;
            files.append(absFilename); // clazy:exclude=reserve-candidates
          }
        } else {
          if (TaggedFile* taggedFile =
              FileProxyModel::getTaggedFileOfIndex(index)) {
            // This will close the file.
            // The file must be closed before deleting on Windows.
            taggedFile->closeFileHandle();
          }
          if (!m_platformTools->moveToTrash(absFilename)) {
            files.append(absFilename); // clazy:exclude=reserve-candidates
          }
        }
      }
```

#### AUTO 


```{c}
auto toolsApplyTextEncoding = new QAction(this);
```

#### AUTO 


```{c}
auto it = m_playlistModels.constBegin();
```

#### AUTO 


```{c}
auto numTracks = static_cast<int>(trackDataVector.size());
```

#### AUTO 


```{c}
auto mimeType =
      mimeDb.mimeTypeForData(QByteArray(bv.data(), static_cast<int>(bv.size())));
```

#### AUTO 


```{c}
auto cmd = qobject_cast<CliCommand*>(sender())
```

#### AUTO 


```{c}
const auto ftModel =
      qobject_cast<const FrameTableModel*>(model())
```

#### AUTO 


```{c}
const auto actions = collection->actions();
```

#### AUTO 


```{c}
auto tagsNamesIt = tagsNames.constBegin(), sourcesIt = tagsSources.constBegin(),
         extractionsIt = tagsExtractions.constBegin();
```

#### AUTO 


```{c}
auto it = find(frame);
```

#### AUTO 


```{c}
auto formLayout = new QFormLayout;
```

#### AUTO 


```{c}
auto timeEventCtl = new TimeEventFieldControl(
                m_platformTools, m_app, fld, m_fields, taggedFile, tagNr,
                TimeEventModel::SynchronizedLyrics);
```

#### AUTO 


```{c}
auto yearMatch = yearRe.match(metadata);
```

#### AUTO 


```{c}
const auto extraartists = (map.contains(QLatin1String("extraartists"))
                               ? map.value(QLatin1String("extraartists"))
                               : map.value(QLatin1String("releaseCredits")))
        .toArray();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& key : keys) {
        m_trackImporters.append(importerFactory->createServerTrackImporter(
                             key, m_netMgr, m_trackDataModel));
      }
```

#### AUTO 


```{c}
const auto selectedIndexes = selItems;
```

#### AUTO 


```{c}
const auto& param
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
      m_app->importFromTagsToSelection(
            m_tagImportDialog->getDestination(),
            m_tagImportDialog->getSourceFormat(),
            m_tagImportDialog->getExtractionFormat());
    }
```

#### AUTO 


```{c}
auto fsModel = qobject_cast<TaggedFileSystemModel*>(sourceModel);
```

#### AUTO 


```{c}
auto it = trackDataVector.begin();
```

#### AUTO 


```{c}
auto size = file.size();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& ts : typeStrOfId) {
      if (ts.type == Frame::FT_Other && ts.supported && ts.str) {
        lst.append(QString::fromLatin1(ts.str));
      }
    }
```

#### AUTO 


```{c}
auto act = new QAction(this);
```

#### AUTO 


```{c}
auto name = Frame::ExtendedType(static_cast<Frame::Type>(k),
                                    QLatin1String("")).getName();
```

#### AUTO 


```{c}
auto pic = new TagLib::FLAC::Picture;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& value : values) {
      if (result.isNull()) {
        result = value;
      } else if (value != result) {
        result.clear();
        break;
      }
    }
```

#### AUTO 


```{c}
const auto& uif
```

#### AUTO 


```{c}
auto selModel = qobject_cast<QItemSelectionModel*>(obj)
```

#### AUTO 


```{c}
const auto parts = str.splitRef(Frame::stringListSeparator());
```

#### AUTO 


```{c}
auto match = fdre.match(text);
```

#### AUTO 


```{c}
auto editReplace = new QAction(this);
```

#### AUTO 


```{c}
auto it = stl.begin();
```

#### AUTO 


```{c}
auto dsfFile = dynamic_cast<DSFFile*>(file)
```

#### AUTO 


```{c}
auto it = entries.constBegin();
```

#### AUTO 


```{c}
auto it = trackDataVector.constBegin();
```

#### AUTO 


```{c}
auto binctl = new BinFieldControl(
              m_platformTools, m_app, fld, frame, taggedFile, tagNr);
```

#### AUTO 


```{c}
auto vboxLayout = new QVBoxLayout(this);
```

#### AUTO 


```{c}
auto tag1AndTag2Layout = new QVBoxLayout(tag1AndTag2Page);
```

#### AUTO 


```{c}
auto item = new QStandardItem;
```

#### AUTO 


```{c}
auto it = explicitType.getType() == Frame::FT_UnknownFrame
      ? frames.findByName(frameName, index)
      : frames.findByExtendedType(explicitType, index);
```

#### AUTO 


```{c}
const auto idxs = selectedIndexes();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { setFocusNextTag(Frame::Tag_NumValues); }
```

#### AUTO 


```{c}
const auto indexes = selectedIndexes();
```

#### AUTO 


```{c}
auto fit = tit->cbegin();
```

#### AUTO 


```{c}
auto buttonsVBoxLayout = new QVBoxLayout;
```

#### AUTO 


```{c}
auto md = new MatchData[numTracks];
```

#### RANGE FOR STATEMENT 


```{c}
for (const QPersistentModelIndex& idx : idxs) {
    if (const FileProxyModel* model =
        qobject_cast<const FileProxyModel*>(idx.model())) {
      paths.append(model->filePath(idx));
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const ServerTrackImporter* si : stis) {
    m_serverComboBox->addItem(QCoreApplication::translate("@default", si->name()));
  }
```

#### AUTO 


```{c}
auto selModel = m_app->getFileSelectionModel();
```

#### AUTO 


```{c}
auto it = fields.begin();
```

#### AUTO 


```{c}
auto it = extensions.constBegin();
```

#### AUTO 


```{c}
const auto& fmt
```

#### AUTO 


```{c}
auto writeButtonGroup = new QButtonGroup(pcGroupBox);
```

#### AUTO 


```{c}
auto wavFile =
                   dynamic_cast<TagLib::RIFF::WAV::File*>(file)
```

#### AUTO 


```{c}
auto dffFile = dynamic_cast<DSDIFFFile*>(file)
```

#### AUTO 


```{c}
auto cb = qobject_cast<QComboBox *>(editor);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& value : values) {
      if (value > result) {
        result = value;
      }
    }
```

#### AUTO 


```{c}
auto fldIt = fieldList.constBegin();
```

#### AUTO 


```{c}
auto match = labelRe.match(
                str.mid(detailStart + 8, detailEnd - detailStart - 9));
```

#### AUTO 


```{c}
auto type
```

#### AUTO 


```{c}
auto it = items.begin();
```

#### AUTO 


```{c}
const auto replacements = m_fmtContext->takeReplacements();
```

#### RANGE FOR STATEMENT 


```{c}
for (const ServerImporter* si : sis) {
    m_serverComboBox->addItem(QCoreApplication::translate("@default", si->name()));
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const ServerImporter* si : sis) {
    QString serverName(QCoreApplication::translate("@default", si->name()));
    QString actionName = QString::fromLatin1(si->name()).toLower().
        remove(QLatin1Char(' '));
    int dotPos = actionName.indexOf(QLatin1Char('.'));
    if (dotPos != -1)
      actionName.truncate(dotPos);
    actionName = QLatin1String("import_") + actionName;
    action = new QAction(tr("Import from %1...").arg(serverName), this);
    action->setData(importerIdx);
    action->setStatusTip(tr("Import from %1").arg(serverName));
    collection->addAction(actionName, action);
    connect(action, &QAction::triggered, impl(), &BaseMainWindowImpl::slotImport);
    ++importerIdx;
  }
```

#### AUTO 


```{c}
auto framelist = qobject_cast<FrameList*>(sender());
```

#### AUTO 


```{c}
const auto keys = factory->taggedFileKeys();
```

#### AUTO 


```{c}
const auto indexes = selectModel->selectedRows();
```

#### AUTO 


```{c}
const auto sis = m_importers;
```

#### AUTO 


```{c}
auto theme = styleTheme.size() > 1 ? styleTheme.at(1) : "";
```

#### AUTO 


```{c}
auto pictureType =
                static_cast<PictureFrame::PictureType>(fieldValue.toInt());
```

#### AUTO 


```{c}
const auto rootQuery = data.value(QLatin1String("ROOT_QUERY"))
              .toObject();
```

#### AUTO 


```{c}
auto findLayout = new QHBoxLayout;
```

#### AUTO 


```{c}
const auto fileNames = pluginsDir.entryList(QDir::Files);
```

#### AUTO 


```{c}
auto it = values.begin();
```

#### AUTO 


```{c}
const auto stis = app()->getServerTrackImporters();
```

#### AUTO 


```{c}
auto mp4Tag =
                 dynamic_cast<TagLib::MP4::Tag*>(m_tag[Frame::Tag_2])
```

#### AUTO 


```{c}
auto serverLayout = new QHBoxLayout;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& idx : idxs) {
    selRows.insert(idx.row());
  }
```

#### AUTO 


```{c}
auto tagButtonLayout = new QHBoxLayout;
```

#### AUTO 


```{c}
auto quickAccessTagsLayout = new QVBoxLayout(quickAccessWidget);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& path : paths) {
    QStringList expandedPath;
    int wcIdx = path.indexOf(QRegExp(QLatin1String("[?*]")));
    if (wcIdx != -1) {
      QString partBefore, partAfter;
      int beforeIdx = path.lastIndexOf(QDir::separator(), wcIdx);
      partBefore = path.left(beforeIdx + 1);
      int afterIdx = path.indexOf(QDir::separator(), wcIdx);
      if (afterIdx == -1) {
        afterIdx = path.length();
      }
      partAfter = path.mid(afterIdx + 1);
      QString wildcardPart = path.mid(beforeIdx + 1, afterIdx - beforeIdx);
      if (!wildcardPart.isEmpty()) {
        QDir dir(partBefore);
        if (!dir.exists(wildcardPart)) {
          const QStringList entries = dir.entryList({wildcardPart},
                                    QDir::AllEntries | QDir::NoDotAndDotDot);
          if (!entries.isEmpty()) {
            for (const QString& entry : entries) {
              expandedPath.append(partBefore + entry + partAfter); // clazy:exclude=reserve-candidates
            }
          }
        }
      }
    }
    if (expandedPath.isEmpty()) {
      expandedPaths.append(path); // clazy:exclude=reserve-candidates
    } else {
      expandedPaths.append(expandedPath);
    }
  }
```

#### AUTO 


```{c}
const auto trackList = map.value(map.contains(QLatin1String("tracklist"))
                                   ? QLatin1String("tracklist")
                                   : QLatin1String("tracks")).toArray();
```

#### AUTO 


```{c}
auto hlayout = new QHBoxLayout;
```

#### AUTO 


```{c}
auto it = m_comments.constBegin();
```

#### AUTO 


```{c}
const auto keys = importerFactory->serverImporterKeys();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& pluginName : disabledTagPlugins) {
      disabledTagPluginFileNames.insert(pluginFileName(pluginName),
                                        pluginName);
    }
```

#### AUTO 


```{c}
auto it = idStrMap.constBegin();
```

#### AUTO 


```{c}
const auto keys = importerFactory->serverTrackImporterKeys();
```

#### AUTO 


```{c}
auto it = textEncodingList.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& filter : filters) {
    auto it = wildcardRe.globalMatch(filter);
    while (it.hasNext()) {
      auto match = it.next();
      int pos = match.capturedStart();
      int len = match.capturedLength();
      exts.insert(filter.mid(pos, len).toLower());
    }
  }
```

#### AUTO 


```{c}
auto fieldIt = fields.begin();
```

#### AUTO 


```{c}
const auto& s2l
```

#### AUTO 


```{c}
auto it = languages.begin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray& name : names) {
      nameMap.insert(QCoreApplication::translate("@default", name),
                     QString::fromLatin1(name));
    }
```

#### AUTO 


```{c}
auto it = pics.begin();
```

#### RANGE FOR STATEMENT 


```{c}
for (ITaggedFileFactory* factory : factories) {
      int idx = pluginOrder.indexOf(factory->name());
      if (idx >= 0) {
        orderedFactories[idx] = factory;
      } else {
        orderedFactories.append(factory); // clazy:exclude=reserve-candidates
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& part : parts) {
      auto s = part.trimmed();
      // First extract all genre codes which are in parentheses
      int offset = 0;
      int end = 0;
      while (s.length() > offset && s.at(offset) == QLatin1Char('(') &&
            (end = s.indexOf(QLatin1Char(')'), offset + 1)) > offset) {
        const auto genreCode = s.mid(offset + 1, end - 1);
        s = s.mid(end + 1);
        bool ok;
        int n = genreCode.toInt(&ok);
        if (genreCode == QLatin1String("RX") ||
            genreCode == QLatin1String("CR")) {
#if QT_VERSION >= 0x060000
          genres.append(genreCode);
#else
          genres.append(genreCode.toString());
#endif
        } else if (ok && n >= 0 && n <= 0xff) {
          QString genreText = QString::fromLatin1(getName(n));
          if (!genreText.isEmpty()) {
            genres.append(genreText);
          }
        }
      }
      // Process the rest as a genre code or text
      s = s.trimmed();
      if (!s.isEmpty()) {
        bool ok;
        int n = s.toInt(&ok);
        if (ok && n >= 0 && n <= 0xff) {
          QString genreText = QString::fromLatin1(getName(n));
          if (!genreText.isEmpty()) {
            genres.append(genreText);
          }
        } else {
#if QT_VERSION >= 0x060000
          genres.append(s);
#else
          genres.append(s.toString());
#endif
        }
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QItemSelectionRange& range : selectedRanges)
    emit dataChanged(range.topLeft(), range.bottomRight());
```

#### AUTO 


```{c}
auto fit = fields.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QQmlError& err : errs) {
            emit commandOutput(err.toString());
          }
```

#### AUTO 


```{c}
auto fileQuit = new QAction(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& line : lines) {
#if QT_VERSION >= 0x050b00
    int lineWidth = fm.horizontalAdvance(line);
#else
    int lineWidth = fm.width(line);
#endif
    if (maxWidth < lineWidth) {
      maxWidth = lineWidth;
    }
  }
```

#### AUTO 


```{c}
auto configuredLanguage = configPath.isNull()
      ? QSettings(QSettings::UserScope, QLatin1String("Kid3"),
                  QLatin1String("Kid3"))
        .value(QLatin1String("MainWindow/Language")).toString()
      : QSettings(QFile::decodeName(configPath), QSettings::IniFormat)
        .value(QLatin1String("MainWindow/Language")).toString();
```

#### RANGE FOR STATEMENT 


```{c}
for (IUserCommandProcessor* userCommandProcessor : userCommandProcessors) {
      if (userCommandProcessor->userCommandKeys().contains(program) &&
          userCommandProcessor->startUserCommand(program, arguments, showOutput))
        return true;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &newFile : newFiles) {
        parentNode->visibleChildren.append(newFile);
        parentNode->children.value(newFile)->isVisible = true;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& wf : warningFunc) {
      checks[wf.warning] = wf.func;
    }
```

#### AUTO 


```{c}
auto it = oldUserActions.constBegin();
```

#### AUTO 


```{c}
auto stateCfg = KSharedConfig::openStateConfig();
```

#### AUTO 


```{c}
auto fldIt = frame.getFieldList().constBegin();
```

#### AUTO 


```{c}
auto type = static_cast<Frame::Type>(FT_Custom1 + i);
```

#### AUTO 


```{c}
auto toolsConvertToId3v24 = new QAction(this);
```

#### AUTO 


```{c}
auto tagsTabWidget = new QTabWidget;
```

#### AUTO 


```{c}
auto errStr = error.error != QJsonParseError::NoError
          ? error.errorString() : QLatin1String("missing method");
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& val : extraartists) {
          ExtraArtist extraArtist(val.toObject());
          extraArtist.addToFrames(frames);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& localeName : localeNames) {
    if (
        localeName.startsWith(QLatin1String("en")) ||
#if defined Q_OS_WIN32 || defined Q_OS_MAC || defined Q_OS_ANDROID
        (!translationsDir.isNull() &&
         qtTr->load(QLatin1String(QT_TRANSLATION_PREFIX) + localeName,
                    translationsDir, searchDelimiters)) ||
        qtTr->load(QLatin1String(QT_TRANSLATION_PREFIX) + localeName,
                   QLatin1String("."), searchDelimiters)
#else
        qtTr->load(QLatin1String(QT_TRANSLATION_PREFIX) + localeName,
                   QLibraryInfo::location(QLibraryInfo::TranslationsPath),
                   searchDelimiters)
#endif
        ) {
      break;
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& index : selItems) {
    if (TaggedFile* taggedFile = FileProxyModel::getTaggedFileOfIndex(index)) {
      if (!firstSelectedFile) {
        firstSelectedFile = taggedFile;
      }
      files.append(taggedFile->getAbsFilename());
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (QString filter : excludeFolders) {
    filter.replace(QLatin1Char('\\'), QLatin1Char('/'));
#if QT_VERSION >= 0x050f00
    filter = QRegularExpression::wildcardToRegularExpression(filter);
#else
    filter = FileSystemModel::wildcardToRegularExpression(filter);
#endif
    m_excludeFolderFilters.append(
          QRegularExpression(filter, QRegularExpression::CaseInsensitiveOption));
  }
```

#### AUTO 


```{c}
auto mp4Tag = dynamic_cast<TagLib::MP4::Tag*>(m_tag[Frame::Tag_2])
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& val : artists) {
      auto map = val.toObject();
      if (!artist.isEmpty()) {
        artist += join;
      }
      artist += fixUpArtist((map.contains(QLatin1String("name"))
                             ? map.value(QLatin1String("name"))
                             : map.value(QLatin1String("artist"))
                               .toObject().value(QLatin1String("name")))
                            .toString());
      join = (map.contains(QLatin1String("join"))
              ? map.value(QLatin1String("join"))
              : map.value(QLatin1String("joiningText"))).toString();
      if (join.isEmpty() || join == QLatin1String(",")) {
        join = QLatin1String(", ");
      } else {
        join = QLatin1Char(' ') + join + QLatin1Char(' ');
      }
    }
```

#### AUTO 


```{c}
auto fldIt = fieldList().begin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& val : durationHms) {
        duration *= 60;
        duration += val.toInt();
      }
```

#### AUTO 


```{c}
auto it = frameCollection.cbegin();
```

#### AUTO 


```{c}
auto fsModel = static_cast<FileSystemModel*>(sourceModel());
```

#### AUTO 


```{c}
auto findNextButton = new QToolButton(this);
```

#### AUTO 


```{c}
auto git = m_shortcutGroups.constBegin();
```

#### AUTO 


```{c}
auto it = docPaths.constBegin();
```

#### AUTO 


```{c}
auto formats = map.value(QLatin1String("formats")).toArray();
```

#### LAMBDA EXPRESSION 


```{c}
[&atTrackDataListEnd, &trackDataVector, &it, &trackNr, &titleFound](
      FrameCollection& frames, int duration) {
    if (!frames.getTitle().isEmpty()) {
      titleFound = true;
    }
    if (frames.getTrack() == 0) {
      frames.setTrack(trackNr);
    }
    if (atTrackDataListEnd) {
      ImportTrackData trackData;
      trackData.setFrameCollection(frames);
      trackData.setImportDuration(duration);
      trackDataVector.append(trackData);
    } else {
      while (!atTrackDataListEnd && !it->isEnabled()) {
        ++it;
        atTrackDataListEnd = (it == trackDataVector.end());
      }
      if (!atTrackDataListEnd) {
        (*it).setFrameCollection(frames);
        (*it).setImportDuration(duration);
        ++it;
        atTrackDataListEnd = (it == trackDataVector.end());
      }
    }
    ++trackNr;
  }
```

#### AUTO 


```{c}
auto nextElementMatch = nextElementRe.match(str, end);
```

#### AUTO 


```{c}
auto it = itemListMap.begin();
```

#### AUTO 


```{c}
auto it = extensions.begin();
```

#### AUTO 


```{c}
const auto& tpl = *it;
```

#### AUTO 


```{c}
const auto extraartists((track.contains(QLatin1String("extraartists"))
                                 ? track.value(QLatin1String("extraartists"))
                                 : track.value(QLatin1String("trackCredits")))
                                .toArray());
```

#### AUTO 


```{c}
auto matchLayout = new QHBoxLayout;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& folder : folders) {
    QString pattern = folder.trimmed();
    if (!pattern.isEmpty()) {
      if (pattern.contains(QLatin1Char(' '))) {
        sep = QLatin1Char(';');
      }
      patterns.append(pattern);
    }
  }
```

#### AUTO 


```{c}
const auto frames = m_pictures;
```

#### RANGE FOR STATEMENT 


```{c}
for (const Source& src : srcs) {
    QString enableStr;
    if (src.standardTagsEnabled())   enableStr += QLatin1Char('S');
    if (src.additionalTagsEnabled()) enableStr += QLatin1Char('A');
    if (src.coverArtEnabled())       enableStr += QLatin1Char('C');
    strs.append(src.getName() + QLatin1Char(':') +
                QString::number(src.getRequiredAccuracy()) + QLatin1Char(':') +
                enableStr);
  }
```

#### AUTO 


```{c}
auto trackLayout = new QHBoxLayout;
```

#### AUTO 


```{c}
auto clearListAction = new QAction(this);
```

#### AUTO 


```{c}
auto cit = text.constBegin();
```

#### AUTO 


```{c}
auto match = yearRe.match(
              str.mid(detailStart + 10, detailEnd - detailStart - 11));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& val : trackList) {
    if (!val.toObject().value(QLatin1String("position")).toString().isEmpty()) {
      allPositionsEmpty = false;
      break;
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (ITaggedFileFactory* factory : factories) {
    const auto keys = factory->taggedFileKeys();
    for (const QString& key : keys) {
      factory->notifyConfigurationChange(key);
    }
  }
```

#### AUTO 


```{c}
auto it = ft->frames().findByName(frameName, index);
```

#### AUTO 


```{c}
auto it = propertiesKv.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& path : paths) {
    QStringList expandedPath;
    int wcIdx = path.indexOf(QRegExp(QLatin1String("[?*]")));
    if (wcIdx != -1) {
      QString partBefore, partAfter;
      int beforeIdx = path.lastIndexOf(QDir::separator(), wcIdx);
      partBefore = path.left(beforeIdx + 1);
      int afterIdx = path.indexOf(QDir::separator(), wcIdx);
      if (afterIdx == -1) {
        afterIdx = path.length();
      }
      partAfter = path.mid(afterIdx + 1);
      QString wildcardPart = path.mid(beforeIdx + 1, afterIdx - beforeIdx);
      if (!wildcardPart.isEmpty()) {
        QDir dir(partBefore);
        if (!dir.exists(wildcardPart)) {
          const QStringList entries = dir.entryList({wildcardPart},
                                    QDir::AllEntries | QDir::NoDotAndDotDot);
          if (!entries.isEmpty()) {
            for (const QString& entry : entries) {
              expandedPath.append(partBefore + entry + partAfter);
            }
          }
        }
      }
    }
    if (expandedPath.isEmpty()) {
      expandedPaths.append(path);
    } else {
      expandedPaths.append(expandedPath);
    }
  }
```

#### AUTO 


```{c}
const auto it = map.constFind(name);
```

#### AUTO 


```{c}
auto previewLayout = new QVBoxLayout(m_previewBox);
```

#### RANGE FOR STATEMENT 


```{c}
for (Frame::TagNumber tagNr : Frame::tagNumbersFromMask(tagVersion)) {
    if (empty()) {
      taggedFile.getAllFrames(tagNr, *this);
    } else {
      FrameCollection frames;
      taggedFile.getAllFrames(tagNr, frames);
      merge(frames);
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVariant& var : lst) {
    indexes.append(var.toModelIndex());
  }
```

#### AUTO 


```{c}
auto self = const_cast<FileIOStream*>(this);
```

#### AUTO 


```{c}
auto kid3Tr = new QTranslator(qApp);
```

#### AUTO 


```{c}
const auto indexes = selModel->selectedIndexes();
```

#### AUTO 


```{c}
auto it = m_cmdList.constBegin();
```

#### AUTO 


```{c}
auto it = format.constBegin();
```

#### AUTO 


```{c}
auto fileLayout = new QGridLayout(m_fileWidget);
```

#### AUTO 


```{c}
auto formLayout = getFormLayout()
```

#### AUTO 


```{c}
auto sortTagFieldLayout = new QHBoxLayout;
```

#### AUTO 


```{c}
auto it = lst.constBegin();
```

#### AUTO 


```{c}
auto it = genreNameMap.find(tstr);
```

#### AUTO 


```{c}
const auto extraartists(track.value(QLatin1String("extraartists")).toArray());
```

#### AUTO 


```{c}
const auto params = obj.value(QLatin1String("params")).toArray();
```

#### AUTO 


```{c}
auto myIt = myFrames.find(*it);
```

#### AUTO 


```{c}
auto editor = qobject_cast<QTimeEdit*>(sender())
```

#### RANGE FOR STATEMENT 


```{c}
for (const QQmlError& err : errors) {
      emit commandOutput(err.toString());
    }
```

#### AUTO 


```{c}
auto& frame = const_cast<Frame&>(*it);
```

#### AUTO 


```{c}
auto it = m_pixmapMap.constBegin();
```

#### AUTO 


```{c}
const auto timeEvents = m_timeEvents;
```

#### AUTO 


```{c}
auto cb = qobject_cast<QComboBox*>(editor)
```

#### AUTO 


```{c}
auto it = fromList.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& idx : idxs) {
      printFileProxyModel(model, idx, indent + 2);
    }
```

#### AUTO 


```{c}
auto match = yearRe.match(result);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& uif : uniqIdField) {
      uniques[QString::fromLatin1(uif.id)] = uif.field;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& key : keys) {
        taggedFileFactory->initialize(key);
        features |= taggedFileFactory->taggedFileFeatures(key);
      }
```

#### AUTO 


```{c}
const auto data = dataValue.toObject();
```

#### AUTO 


```{c}
auto it = m_metadata.constFind(name);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& localeName : localeNames) {
    if (
        localeName.startsWith(QLatin1String("en")) ||
        (!translationsDir.isNull() &&
         qtTr->load(QLatin1String(QT_TRANSLATION_PREFIX) + localeName,
                    translationsDir, searchDelimiters)) ||
        qtTr->load(QLatin1String(QT_TRANSLATION_PREFIX) + localeName,
                   QLatin1String("."), searchDelimiters)
#if !(defined Q_OS_WIN32 || defined Q_OS_MAC || defined Q_OS_ANDROID)
        || qtTr->load(QLatin1String(QT_TRANSLATION_PREFIX) + localeName,
#if QT_VERSION >= 0x060000
                   QLibraryInfo::path(QLibraryInfo::TranslationsPath),
#else
                   QLibraryInfo::location(QLibraryInfo::TranslationsPath),
#endif
                   searchDelimiters)
#endif
        ) {
      break;
    }
  }
```

#### AUTO 


```{c}
const auto& soi
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& c2a : creditToArrangement) {
    if (role.contains(
          QString::fromLatin1(c2a.credit))) {
      role = QString::fromLatin1(c2a.arrangement);
      return Frame::FT_Arranger;
    }
  }
```

#### AUTO 


```{c}
auto it = wildcardRe.globalMatch(filter);
```

#### AUTO 


```{c}
auto othersIt = others.find(frame);
```

#### AUTO 


```{c}
auto it = strNumMap.constFind(name.remove(QLatin1Char('=')).toUpper());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& index : selItems) {
      if (TaggedFile* taggedFile = FileProxyModel::getTaggedFileOfIndex(index))
      {
        files.append(taggedFile->getAbsFilename());
      }
    }
```

#### AUTO 


```{c}
auto doc = QJsonDocument::fromJson(searchStr);
```

#### AUTO 


```{c}
auto picNamesIt = picNames.constBegin(), picUrlsIt = picUrls.constBegin();
```

#### AUTO 


```{c}
auto editor = new StarEditor(parent);
```

#### AUTO 


```{c}
auto it = map.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& index : selectedIndexes) {
    if (index.column() == 0) {
      indexes.append(QPersistentModelIndex(index));
    }
  }
```

#### AUTO 


```{c}
auto editSelectAllInDir = new QAction(this);
```

#### AUTO 


```{c}
auto it = m_strRepMap.constBegin();
```

#### AUTO 


```{c}
auto cbox = new IntComboBoxControl(
                fld, PictureFrame::getPictureTypeNames());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QPersistentModelIndex& index : selectedIndexes) {
    files.append(model->filePath(index)); // clazy:exclude=reserve-candidates
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& agn : alternativeGenreNames) {
                    genreNameMap.insert(agn.newName, agn.oldName);
                  }
```

#### RANGE FOR STATEMENT 


```{c}
for (Frame::TagNumber tagNr :
         Frame::tagNumbersFromMask(Frame::tagVersionCast(enumVal))) {
      tagMaskStr += Frame::tagNumberToString(tagNr);
    }
```

#### AUTO 


```{c}
auto totalLayout = new QHBoxLayout;
```

#### AUTO 


```{c}
auto view = qobject_cast<QQuickView*>(sender())
```

#### RANGE FOR STATEMENT 


```{c}
for (const ServerImporter* si : sis) {
    QString serverName(QCoreApplication::translate("@default", si->name()));
    QString actionName = QString::fromLatin1(
          si->name()).toLower().remove(QLatin1Char(' '));
    int dotPos = actionName.indexOf(QLatin1Char('.'));
    if (dotPos != -1)
      actionName.truncate(dotPos);
    actionName = QLatin1String("import_") + actionName;
    auto fileImportServer = new QAction(this);
    fileImportServer->setData(importerIdx);
    fileImportServer->setStatusTip(tr("Import from %1").arg(serverName));
    fileImportServer->setText(tr("Import from %1...").arg(serverName));
    fileImportServer->setObjectName(actionName);
    m_shortcutsModel->registerAction(fileImportServer, menuTitle);
    connect(fileImportServer, &QAction::triggered,
      impl(), &BaseMainWindowImpl::slotImport);
    fileMenu->addAction(fileImportServer);
    ++importerIdx;
  }
```

#### AUTO 


```{c}
auto menu = new QMenu(this);
```

#### AUTO 


```{c}
const auto languages = MainWindowConfig::instance().availableLanguages();
```

#### AUTO 


```{c}
auto it = frames.findByName(frameName, index);
```

#### AUTO 


```{c}
auto it = m_timeEvents.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QItemSelectionRange& range : deselectedRanges)
    emit dataChanged(range.topLeft(), range.bottomRight());
```

#### RANGE FOR STATEMENT 


```{c}
for (int frameType : constFrameTypes) {
    auto name = Frame::ExtendedType(static_cast<Frame::Type>(frameType))
        .getTranslatedName();
    if (Frame::isCustomFrameType(static_cast<Frame::Type>(frameType))) {
      int idx = frameType - Frame::FT_Custom1;
      if (idx >= 0 && idx < customFrameNames.size()) {
        name = customFrameNames.at(idx);
      } else {
        name.clear();
      }
    }
    if (!name.isEmpty()) {
      QStandardItem* item = new QStandardItem(name);
      item->setData(frameType, Qt::UserRole);
      item->setCheckable(true);
      item->setCheckState((frameMask & (1ULL << frameType))
                          ? Qt::Checked : Qt::Unchecked);
      item->setDropEnabled(false);
      m_quickAccessTagsModel->appendRow(item);
    }
  }
```

#### AUTO 


```{c}
auto formatGroupBox = new QGroupBox(tr("Format"), filesPage);
```

#### AUTO 


```{c}
auto vHeader = qobject_cast<QHeaderView*>(sender());
```

#### AUTO 


```{c}
auto model = const_cast<TaggedFileSystemModel*>(getTaggedFileSystemModel());
```

#### AUTO 


```{c}
auto vlayout = new QVBoxLayout(shortcutsPage);
```

#### AUTO 


```{c}
auto splitter = new QSplitter(Qt::Vertical);
```

#### LAMBDA EXPRESSION 


```{c}
[]() { return &FilterConfig::instance(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVariant& var : namesSelected) {
    auto map = var.toMap();
    auto name = map.value(QLatin1String("name")).toString();
    auto frameType = map.value(QLatin1String("type")).toInt();
    auto selected = map.value(QLatin1String("selected")).toBool();
    QStandardItem* item = new QStandardItem(name);
    item->setData(frameType, Qt::UserRole);
    item->setCheckable(true);
    item->setCheckState(selected ? Qt::Checked : Qt::Unchecked);
    item->setDropEnabled(false);
    m_quickAccessTagsModel->appendRow(item);
  }
```

#### AUTO 


```{c}
auto layout = new QHBoxLayout(this);
```

#### AUTO 


```{c}
auto state = static_cast<Qt::CheckState>(value.toInt());
```

#### AUTO 


```{c}
auto timeEventCtl = new TimeEventFieldControl(
                m_platformTools, m_app, fld, m_fields, taggedFile, tagNr,
                TimeEventModel::EventTimingCodes);
```

#### RANGE FOR STATEMENT 


```{c}
for (const ServerImporter* si : sis) {
    QString serverName(QCoreApplication::translate("@default", si->name()));
    QString actionName = QString::fromLatin1(si->name()).toLower()
        .remove(QLatin1Char(' '));
    int dotPos = actionName.indexOf(QLatin1Char('.'));
    if (dotPos != -1)
      actionName.truncate(dotPos);
    actionName = QLatin1String("import_") + actionName;
    action = new QAction(tr("Import from %1...").arg(serverName), this);
    action->setData(importerIdx);
    action->setStatusTip(tr("Import from %1").arg(serverName));
    collection->addAction(actionName, action);
    connect(action, &QAction::triggered, impl(), &BaseMainWindowImpl::slotImport);
    ++importerIdx;
  }
```

#### AUTO 


```{c}
auto fileExport = new QAction(this);
```

#### AUTO 


```{c}
const auto& replacement
```

#### AUTO 


```{c}
auto pictureType =
              static_cast<PictureFrame::PictureType>(fieldValue.toInt());
```

#### LAMBDA EXPRESSION 


```{c}
[]() { return &NumberTracksConfig::instance(); }
```

#### AUTO 


```{c}
auto formLayout = new QFormLayout(this);
```

#### AUTO 


```{c}
const auto srcs = m_sources;
```

#### LAMBDA EXPRESSION 


```{c}
[]() { return &FileConfig::instance(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& nameType : nameTypes) {
        nameTypeMap.insert(QString::fromLatin1(nameType.name), nameType.type);
      }
```

#### AUTO 


```{c}
auto baSize = static_cast<unsigned long>(ba.size());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& idx : idxs) {
      dumpModel(model, idx, indent + 2);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& c2n : codeToName) {
    m_pattern.replace(QString::fromLatin1(c2n.from), QString::fromLatin1(c2n.to));
  }
```

#### AUTO 


```{c}
auto customFramesEdit = new StringListEdit(m_customFramesEditModel, customFramesGroupBox);
```

#### RANGE FOR STATEMENT 


```{c}
for (const ShortcutGroup& g : gs) {
              for (const ShortcutItem& i : g) {
                if (i.activeShortcut() == keyString &&
                    si.action() != i.action() &&
                    (si.action()->shortcutContext() != Qt::WidgetShortcut ||
                     i.action()->shortcutContext() != Qt::WidgetShortcut)) {
                  emit shortcutAlreadyUsed(keyString, g.context(), i.action());
                  return false;
                }
              }
            }
```

#### AUTO 


```{c}
const auto errs = m_qmlView->errors();
```

#### AUTO 


```{c}
auto scrollView = new QScrollArea(this);
```

#### AUTO 


```{c}
auto configuredLanguage = QSettings(
        QSettings::UserScope, QLatin1String("Kid3"), QLatin1String("Kid3"))
      .value(QLatin1String("MainWindow/Language")).toString();
```

#### AUTO 


```{c}
auto selected = map.value(QLatin1String("selected")).toBool();
```

#### AUTO 


```{c}
auto tocCtl =
              new TableOfContentsFieldControl(fld);
```

#### AUTO 


```{c}
const auto artists((track.contains(QLatin1String("artists"))
                          ? track.value(QLatin1String("artists"))
                          : track.value(QLatin1String("primaryArtists")))
                         .toArray());
```

#### AUTO 


```{c}
auto it = s_openFiles.begin();
```

#### AUTO 


```{c}
auto moveDownAction = new QAction(this);
```

#### AUTO 


```{c}
auto it = catIdTitleRe.globalMatch(str);
```

#### AUTO 


```{c}
auto frameType = index.data(Qt::UserRole).toInt();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& index : indexes)
    selItems.append(index);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& s2l : shortToLong) {
      if (s2l.shortCode == c) {
        name = QString::fromLatin1(s2l.longCode);
        break;
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const ShortcutItem& i : g) {
                if (i.activeShortcut() == keyString &&
                    si.action() != i.action()) {
                  emit shortcutAlreadyUsed(keyString, g.context(), i.action());
                  return false;
                }
              }
```

#### AUTO 


```{c}
auto cbox = new IntComboBoxControl(
                fld, Frame::Field::getContentTypeNames());
```

#### AUTO 


```{c}
auto tagsListView = new QListView;
```

#### AUTO 


```{c}
auto fileImport = new QAction(this);
```

#### AUTO 


```{c}
auto stateCfg = cfg;
```

#### AUTO 


```{c}
auto s = part.trimmed();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& c2t : creditToType) {
          if (*cit == QString::fromLatin1(c2t.credit)) {
            frames.setValue(c2t.type, name);
            found = true;
            break;
          }
        }
```

#### AUTO 


```{c}
auto l = static_cast<unsigned char>(hexStr[i++].toLatin1());
```

#### AUTO 


```{c}
auto findPreviousAction = new QAction(this);
```

#### AUTO 


```{c}
const auto& val
```

#### AUTO 


```{c}
auto it = idRe.globalMatch(recordings);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& frameName : {it->getName(), it->getInternalName()}) {
      QString ucFrameName(frameName.toUpper().remove(QLatin1Char('/')));
      if (ucName == ucFrameName.leftRef(len)) {
        return it;
      }
      int nlPos = ucFrameName.indexOf(QLatin1Char('\n'));
      if (nlPos > 0 && ucName == ucFrameName.midRef(nlPos + 1, len)) {
        // Description in TXXX, WXXX, COMM, PRIV matches
        return it;
      }
    }
```

#### AUTO 


```{c}
auto trackSpacer = new QSpacerItem(16, 0, QSizePolicy::Expanding,
                                             QSizePolicy::Minimum);
```

#### AUTO 


```{c}
auto vbox = new QVBoxLayout;
```

#### AUTO 


```{c}
auto findReplaceLayout = new QGridLayout;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& entry : entries) {
              expandedPath.append(partBefore + entry + partAfter);
            }
```

#### AUTO 


```{c}
auto name = Frame::ExtendedType(static_cast<Frame::Type>(k),
                                        QLatin1String("")).getName();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& s2l : shortToLong) {
        if (s2l.shortCode == c) {
          name = QString::fromLatin1(s2l.longCode);
          break;
        }
      }
```

#### AUTO 


```{c}
auto ratingLayout = new QVBoxLayout(ratingGroupBox);
```

#### AUTO 


```{c}
auto tagsCoverLayout = new QHBoxLayout;
```

#### AUTO 


```{c}
const auto& fileName
```

#### RANGE FOR STATEMENT 


```{c}
for (const QPersistentModelIndex& index : selectedIndexes) {
        QString absFilename(model->filePath(index));
        if (model->isDir(index)) {
          if (!m_platformTools->moveToTrash(absFilename)) {
            rmdirError = true;
            files.append(absFilename); // clazy:exclude=reserve-candidates
          }
        } else {
          if (TaggedFile* taggedFile =
              FileProxyModel::getTaggedFileOfIndex(index)) {
            // This will close the file.
            // The file must be closed before deleting on Windows.
            taggedFile->closeFileHandle();
          }
          if (!m_platformTools->moveToTrash(absFilename)) {
            files.append(absFilename); // clazy:exclude=reserve-candidates
          }
        }
      }
```

#### AUTO 


```{c}
auto it = lines.constBegin();
```

#### AUTO 


```{c}
auto  item = static_cast<AlbumListItem*>(albumModel->item(0, 0));
```

#### AUTO 


```{c}
const auto& freeFormNameType
```

#### AUTO 


```{c}
auto it = sectionShortcuts.constBegin();
```

#### AUTO 


```{c}
auto vlayout = new QVBoxLayout(filesPage);
```

#### AUTO 


```{c}
auto map = val.toObject();
```

#### AUTO 


```{c}
auto butlayout = new QHBoxLayout;
```

#### AUTO 


```{c}
const auto frameTypes = checkableFrameTypes();
```

#### AUTO 


```{c}
const auto parts = str.split(Frame::stringListSeparator());
```

#### AUTO 


```{c}
auto it = m_splitterSizes.constBegin();
```

#### AUTO 


```{c}
auto match = rx.match(node->fileName);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& displayName : displayNames) {
    QByteArray frameId = Frame::getFrameIdForTranslatedFrameName(displayName);
    names.append(frameId.isNull()
                 ? Frame::getNameForTranslatedFrameName(displayName)
                 : QString::fromLatin1(frameId));
  }
```

#### AUTO 


```{c}
auto txxxFrame =
      new TagLib::ID3v2::UserTextIdentificationFrame(enc);
```

#### AUTO 


```{c}
auto fileRevert = new QAction(this);
```

#### AUTO 


```{c}
auto helpAbout = new QAction(this);
```

#### LAMBDA EXPRESSION 


```{c}
[]() { return &ImportConfig::instance(); }
```

#### AUTO 


```{c}
const auto genreCode = s.mid(offset + 1, end - 1);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& pluginName : pluginNames) {
      int pluginIdx = pluginOrder.indexOf(pluginName);
      if (pluginIdx >= 0) {
        metadataPlugins[pluginIdx] = pluginName;
      } else {
        metadataPlugins.append(pluginName);
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& val : extraartists) {
        ExtraArtist extraArtist(val.toObject());
        if (extraArtist.hasTrackRestriction()) {
          trackExtraArtists.append(extraArtist);
        } else {
          extraArtist.addToFrames(framesHdr);
        }
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& file : files) {
    m_mediaPlaylist->addMedia(QUrl::fromLocalFile(file));
  }
```

#### AUTO 


```{c}
auto qtTr = new QTranslator(qApp);
```

#### AUTO 


```{c}
auto le = qobject_cast<QLineEdit*>(indexWidget(idx))
```

#### AUTO 


```{c}
auto expNamesIt = expNames.constBegin(), expHeadersIt = expHeaders.constBegin(),
         expTracksIt = expTracks.constBegin(), expTrailersIt = expTrailers.constBegin();
```

#### AUTO 


```{c}
auto tag3Layout = new QVBoxLayout(tag3Page);
```

#### AUTO 


```{c}
auto vlayout = new QVBoxLayout(this);
```

#### AUTO 


```{c}
const auto &persistentIndex
```

#### LAMBDA EXPRESSION 


```{c}
[this, tagNr]() {
      m_app->tag(tagNr)->removeTags();
      setFocusTag(tagNr);
    }
```

#### AUTO 


```{c}
auto doc = QJsonDocument::fromJson(m_jsonRequest.toUtf8(), &error);
```

#### AUTO 


```{c}
auto formatLabel = new QLabel(tr("&Format:"));
```

#### AUTO 


```{c}
auto txxxFrame =
        dynamic_cast<TagLib::ID3v2::UserTextIdentificationFrame*>(id3Frame);
```

#### AUTO 


```{c}
auto match = yearRe.match(released);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { setFocusPreviousTag(Frame::Tag_NumValues); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray& id : ids) {
        if (!id.isEmpty()) {
          it = searchByName(QString::fromLatin1(id));
          if (it != end()) {
            break;
          }
        }
      }
```

#### AUTO 


```{c}
auto it = m_comments.begin();
```

#### AUTO 


```{c}
auto it = frames.begin();
```

#### AUTO 


```{c}
auto it = begin;
```

#### AUTO 


```{c}
auto it = fieldList().end();
```

#### RANGE FOR STATEMENT 


```{c}
for (int frameType : frameTypes) {
      int column = m_trackDataModel->columnForFrameType(frameType);
      if (column != -1) {
        QAction* action = new QAction(&menu);
        action->setText(
              m_trackDataModel->headerData(column, Qt::Horizontal).toString());
        action->setData(frameType);
        action->setCheckable(true);
        action->setChecked((m_columnVisibility & (1ULL << frameType)) != 0ULL);
        connect(action, SIGNAL(triggered(bool)),
                this, SLOT(toggleTableColumnVisibility(bool)));
        menu.addAction(action);
      }
    }
```

#### AUTO 


```{c}
auto it = customFrameNames.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (int column : columns) {
    m_fileListBox->resizeColumnToContents(column);
    if (firstFileSectionSize <= 0 && fileHeader) {
      firstFileSectionSize = fileHeader->sectionSize(column);
    }
  }
```

#### AUTO 


```{c}
auto fsModel = qobject_cast<FileSystemModel*>(sourceModel);
```

#### AUTO 


```{c}
auto name = Frame::ExtendedType(static_cast<Frame::Type>(frameType))
        .getTranslatedName();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& filter : filters) {
    int pos = 0;
    while ((pos = wildcardRe.indexIn(filter, pos)) != -1) {
      int len = wildcardRe.matchedLength();
      exts.insert(filter.mid(pos, len).toLower());
      pos += len;
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& path : pathList) {
    if (!path.isEmpty()) {
      QFileInfo fileInfo(path);
      if (fileCheck && !fileInfo.exists()) {
        ok = false;
        break;
      }
      QString dirPath;
      if (!fileInfo.isDir()) {
        dirPath = fileInfo.absolutePath();
        if (fileInfo.isFile()) {
          filePaths.append(fileInfo.absoluteFilePath());
        }
      } else {
        dirPath = QDir(path).absolutePath();
      }
      QStringList dirPathComponents = dirPath.split(QDir::separator());
      if (dirComponents.isEmpty()) {
        dirComponents = dirPathComponents;
      } else {
        // Reduce dirPath to common prefix.
        auto dirIt = dirComponents.begin();
        auto dirPathIt = dirPathComponents.constBegin();
        while (dirIt != dirComponents.end() &&
               dirPathIt != dirPathComponents.constEnd() &&
               *dirIt == *dirPathIt) {
          ++dirIt;
          ++dirPathIt;
        }
        dirComponents.erase(dirIt, dirComponents.end());
      }
    }
  }
```

#### AUTO 


```{c}
auto commFrame =
        new TagLib::ID3v2::CommentsFrame(enc);
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction* action : actions) {
    if (action) {
      QString name = action->objectName();
      if (!name.isEmpty()) {
        const auto it = map.constFind(name);
        if (it != map.constEnd()) {
          action->setShortcut(*it);
        }
      }
    }
  }
```

#### AUTO 


```{c}
auto iit = git->constBegin();
```

#### AUTO 


```{c}
auto lineEdit = qobject_cast<QLineEdit*>(editor);
```

#### LAMBDA EXPRESSION 


```{c}
[]() { return &BatchImportConfig::instance(); }
```

#### AUTO 


```{c}
auto genresEdit = new StringListEdit(m_genresEditModel, genresGroupBox);
```

#### RANGE FOR STATEMENT 


```{c}
for (const GeneralConfig* cfg : cfgs) {
    cfg->writeToConfig(m_config);
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Frame& frame : frames) {
        QByteArray ba;
        if (PictureFrame::getData(frame, ba)) {
#if MPEG4IP_MAJOR_MINOR_VERSION >= 0x0109
          MP4TagArtwork artwork;
          artwork.data = ba.data();
          artwork.size = static_cast<uint32_t>(ba.size());
          artwork.type = MP4_ART_JPEG;
          QString mimeType;
          if (PictureFrame::getMimeType(frame, mimeType)) {
            if (mimeType == QLatin1String("image/png")) {
              artwork.type = MP4_ART_PNG;
            } else if (mimeType == QLatin1String("image/bmp")) {
              artwork.type = MP4_ART_BMP;
            } else if (mimeType == QLatin1String("image/gif")) {
              artwork.type = MP4_ART_GIF;
            }
          }
          MP4TagsAddArtwork(tags, &artwork);
#else
          MP4SetMetadataCoverArt(handle, reinterpret_cast<uint8_t*>(ba.data()),
                                 ba.size());
#endif
        }
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (QString txt : paths) {
    int lfPos = txt.indexOf(QLatin1Char('\n'));
    if (lfPos > 0 && lfPos < static_cast<int>(txt.length()) - 1) {
      txt.truncate(lfPos + 1);
    }
    QString dir = txt.trimmed();
    if (!dir.isEmpty()) {
      if (dir.endsWith(QLatin1String(".jpg"), Qt::CaseInsensitive) ||
          dir.endsWith(QLatin1String(".jpeg"), Qt::CaseInsensitive) ||
          dir.endsWith(QLatin1String(".png"), Qt::CaseInsensitive)) {
        picturePaths.append(dir); // clazy:exclude=reserve-candidates
      } else {
        filePaths.append(dir); // clazy:exclude=reserve-candidates
      }
    }
  }
```

#### AUTO 


```{c}
auto git = m_shortcutGroups.begin();
```

#### AUTO 


```{c}
auto obj = doc.object();
```

#### AUTO 


```{c}
const auto tagVersions = Frame::availableTagVersions();
```

#### AUTO 


```{c}
auto fileTagImport = new QAction(this);
```

#### AUTO 


```{c}
const auto& part
```

#### AUTO 


```{c}
const auto& element
```

#### AUTO 


```{c}
auto totalSpacer = new QSpacerItem(16, 0, QSizePolicy::Expanding,
                                             QSizePolicy::Minimum);
```

#### AUTO 


```{c}
const auto& efm
```

#### AUTO 


```{c}
auto addFramesToTrackData =
      [&atTrackDataListEnd, &trackDataVector, &it, &trackNr, &titleFound](
      FrameCollection& frames, int duration) {
    if (!frames.getTitle().isEmpty()) {
      titleFound = true;
    }
    if (frames.getTrack() == 0) {
      frames.setTrack(trackNr);
    }
    if (atTrackDataListEnd) {
      ImportTrackData trackData;
      trackData.setFrameCollection(frames);
      trackData.setImportDuration(duration);
      trackDataVector.append(trackData);
    } else {
      while (!atTrackDataListEnd && !it->isEnabled()) {
        ++it;
        atTrackDataListEnd = (it == trackDataVector.end());
      }
      if (!atTrackDataListEnd) {
        (*it).setFrameCollection(frames);
        (*it).setImportDuration(duration);
        ++it;
        atTrackDataListEnd = (it == trackDataVector.end());
      }
    }
    ++trackNr;
  };
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &nameFilter : nameFilters) {
#if QT_VERSION >= 0x050f00
            auto rx = QRegularExpression(
                  QRegularExpression::wildcardToRegularExpression(nameFilter),
                  reOptions);
#else
            auto rx = QRegularExpression(
                  FileSystemModel::wildcardToRegularExpression(nameFilter),
                  reOptions);
#endif
            auto match = rx.match(node->fileName);
            if (match.hasMatch())
                return true;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& index : indexes) {
      if (m_model->isDir(index)) {
        m_dirIndexes.append(getIndexesOfDirWithSubDirs(index));
      }
    }
```

#### AUTO 


```{c}
const auto cfgs = m_configurations;
```

#### AUTO 


```{c}
auto performer = m_trackDataModel->index(row, 13).data().toString();
```

#### AUTO 


```{c}
const auto constFilePaths = filePaths;
```

#### RANGE FOR STATEMENT 


```{c}
for (const Frame& frame : frames) {
              QByteArray ba;
              TagLib::MP4::CoverArt::Format format = TagLib::MP4::CoverArt::JPEG;
              if (PictureFrame::getData(frame, ba)) {
                QString mimeType;
                if (PictureFrame::getMimeType(frame, mimeType)) {
                  if (mimeType == QLatin1String("image/png")) {
                    format = TagLib::MP4::CoverArt::PNG;
                  } else if (mimeType == QLatin1String("image/bmp")) {
                    format = TagLib::MP4::CoverArt::BMP;
                  } else if (mimeType == QLatin1String("image/gif")) {
                    format = TagLib::MP4::CoverArt::GIF;
                  }
                }
              }
              coverArtList.append(TagLib::MP4::CoverArt(
                          format,
                          TagLib::ByteVector(
                            ba.data(), static_cast<unsigned int>(ba.size()))));
            }
```

#### AUTO 


```{c}
auto dialog =
      qobject_cast<EditFrameFieldsDialog*>(sender())
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& index : selItems) {
      files.append(m_fileProxyModel->filePath(index));
    }
```

#### AUTO 


```{c}
auto it = m_aggregatedCodes.constBegin();
```

#### AUTO 


```{c}
auto oggTag =
                     dynamic_cast<TagLib::Ogg::XiphComment*>(tag)
```

#### AUTO 


```{c}
auto mimeData = new QMimeData;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& fmt : fmts) {
            QString format = fmt.toString().trimmed();
            if (!format.isEmpty()) {
              formats.append(format);
            }
          }
```

#### AUTO 


```{c}
auto name = Frame::ExtendedType(static_cast<Frame::Type>(i))
        .getTranslatedName();
```

#### AUTO 


```{c}
auto it = ft->frames().cbegin();
```

#### AUTO 


```{c}
const auto &newFile
```

#### AUTO 


```{c}
auto fileCreatePlaylist = new QAction(this);
```

#### AUTO 


```{c}
const auto userCommandProcessors = m_app->getUserCommandProcessors();
```

#### AUTO 


```{c}
auto result = val.toObject();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& pattern : patternList) {
    QString folder = pattern.trimmed();
    if (!folder.isEmpty()) {
      folders.append(folder); // clazy:exclude=reserve-candidates
    }
  }
```

#### AUTO 


```{c}
auto fileButtonLayout = new QHBoxLayout;
```

#### AUTO 


```{c}
auto slit = stringList.begin();
```

#### AUTO 


```{c}
auto editDeselect = new QAction(this);
```

#### AUTO 


```{c}
auto ratingEdit = new TableModelEdit(m_starRatingMappingsModel);
```

#### AUTO 


```{c}
auto it = m_currentCodes.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& frameName : names) {
      QString ucFrameName(frameName.toUpper().remove(QLatin1Char('/')));
      if (ucName == ucFrameName.leftRef(len)) {
        return it;
      }
      int nlPos = ucFrameName.indexOf(QLatin1Char('\n'));
      if (nlPos > 0 && ucName == ucFrameName.midRef(nlPos + 1, len)) {
        // Description in TXXX, WXXX, COMM, PRIV matches
        return it;
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (int column : dirColumns) {
    m_dirListBox->resizeColumnToContents(column);
    if (firstDirSectionSize <= 0 && dirHeader) {
      firstDirSectionSize = dirHeader->sectionSize(column);
      if (firstDirSectionSize < firstFileSectionSize) {
        // The directory column often only contains "." and "..", which results
        // in a small size. Make it at least as wide as the corresponding
        // file list column.
        dirHeader->resizeSection(column, firstFileSectionSize);
      }
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& val : durationHms) {
      m_duration *= 60;
      m_duration += val.toInt();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &update : updates) {
        QString fileName = update.first;
        Q_ASSERT(!fileName.isEmpty());
        ExtendedInformation info = fileInfoGatherer.getInfo(update.second);
        bool previouslyHere = parentNode->children.contains(fileName);
        if (!previouslyHere) {
            addNode(parentNode, fileName, info.fileInfo());
        }
        FileSystemModelPrivate::FileSystemNode * node = parentNode->children.value(fileName);
        bool isCaseSensitive = parentNode->caseSensitive();
        if (isCaseSensitive) {
            if (node->fileName != fileName)
                continue;
        } else {
            if (QString::compare(node->fileName,fileName,Qt::CaseInsensitive) != 0)
                continue;
        }
        if (isCaseSensitive) {
            Q_ASSERT(node->fileName == fileName);
        } else {
            node->fileName = fileName;
        }

        if (*node != info ) {
            node->populate(info);
            bypassFilters.remove(node);
            // brand new information.
            if (filtersAcceptsNode(node)) {
                if (!node->isVisible) {
                    newFiles.append(fileName);
                } else {
                    rowsToUpdate.append(fileName);
                }
            } else {
                if (node->isVisible) {
                    int visibleLocation = parentNode->visibleLocation(fileName);
                    removeVisibleFile(parentNode, visibleLocation);
                } else {
                    // The file is not visible, don't do anything
                }
            }
        }
    }
```

#### AUTO 


```{c}
auto shortcutsEditor = new ShortcutsDelegateEditor(le, parent);
```

#### AUTO 


```{c}
const auto constStrRepMap = fnCfg.strRepMap();
```

#### RANGE FOR STATEMENT 


```{c}
for (const TimeEvent& timeEvent : timeEvents) {
    if (!timeEvent.time.isNull()) {
      QString str = timeEvent.data.toString();
      // Remove escaping, restore new line characters.
      if (str.startsWith(QLatin1Char('_'))) {
        str.remove(0, 1);
      } else if (str.startsWith(QLatin1Char('#'))) {
        str.replace(0, 1, QLatin1Char('\n'));
      } else if (!(str.startsWith(QLatin1Char(' ')) ||
                   str.startsWith(QLatin1Char('-')))) {
        str.prepend(QLatin1Char('\n'));
      }

      quint32 milliseconds;
      if (timeEvent.time.type() == QVariant::Time) {
        hasMsTimeStamps = true;
        milliseconds = QTime(0, 0).msecsTo(timeEvent.time.toTime());
      } else {
        milliseconds = timeEvent.data.toUInt();
      }
      synchedData.append(milliseconds);
      synchedData.append(str);
    }
  }
```

#### AUTO 


```{c}
auto unicode = new unicode_t[unicode_size + 1];
```

#### AUTO 


```{c}
auto toolsPlay = new QAction(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& name : names) {
    displayNames.append(Frame::getDisplayName(name));
  }
```

#### AUTO 


```{c}
const auto model =
        qobject_cast<const FileProxyModel*>(index.model())
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& extraArtist : trackExtraArtists) {
        extraArtist.addToFrames(frames, position);
      }
```

#### AUTO 


```{c}
auto customFramesEdit = new StringListEdit(m_customFramesEditModel, customFramesWidget);
```

#### AUTO 


```{c}
auto match = re.match(
          urlStr, 0, QRegularExpression::NormalMatch,
          QRegularExpression::AnchoredMatchOption);
```

#### RANGE FOR STATEMENT 


```{c}
for (SectionActions* sectionActions : m_sectionActions) {
    sectionActions->setShortcuts(map);
  }
```

#### LAMBDA EXPRESSION 


```{c}
[]() { return &ExportConfig::instance(); }
```

#### AUTO 


```{c}
auto pt = static_cast<Frame::PictureType>(i);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& filePath :  constFilePaths) {
      QModelIndex index = m_fsModel->index(filePath);
      if (index.isValid()) {
        m_items.append(index);
      } else {
        m_filesNotFound.append(filePath);
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& arg : args) {
    if (isCommand) {
      m_argCommands.append(arg);
      isCommand = false;
    } else if (arg == QLatin1String("-c")) {
      isCommand = true;
    } else if (arg == QLatin1String("-h") || arg == QLatin1String("--help")) {
      writeLine(QLatin1String("kid3-cli " VERSION " (c) " RELEASE_YEAR
                              " Urs Fleisch"));
      writeLine(tr("Usage:") + QLatin1String(
          " kid3-cli [-c command1] [-c command2 ...] [path ...]"));
      writeHelp();
      flushStandardOutput();
      terminate();
      return true;
    } else {
      paths.append(arg);
    }
  }
```

#### AUTO 


```{c}
auto ait = attrList.begin();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto fmt : m_formatters) {
    args = fmt->parseArguments(line);
    if (fmt->isFormatRecognized()) {
      m_formatter = fmt;
      break;
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (QHeaderView::ResizeMode mode : resizeModes)
    header->setSectionResizeMode(col++, mode);
```

#### AUTO 


```{c}
auto startupLayout = new QVBoxLayout;
```

#### RANGE FOR STATEMENT 


```{c}
for (const Frame::Field& fld : fieldList) {
    if (fld.m_id != Frame::ID_ImageFormat &&
        fld.m_id != Frame::ID_ImageProperties) {
      reduced.append(fld);
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& filePath : paths) {
    QModelIndex index = m_fsModel->index(filePath);
    if (index.isValid()) {
      m_items.append(index);
    } else {
      ok = false;
    }
  }
```

#### AUTO 


```{c}
auto it = m_includeFolderFilters.constBegin();
```

#### AUTO 


```{c}
auto& frame = const_cast<Frame&>(*frameIt);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& val : artists) {
      auto map = val.toObject();
      if (!artist.isEmpty()) {
        artist += join;
      }
      artist += fixUpArtist(map.value(QLatin1String("name")).toString());
      join = map.value(QLatin1String("join")).toString();
      if (join.isEmpty() || join == QLatin1String(",")) {
        join = QLatin1String(", ");
      } else {
        join = QLatin1Char(' ') + join + QLatin1Char(' ');
      }
    }
```

#### AUTO 


```{c}
auto it = m_maps.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& name : names) {
    map.insert(getDisplayName(name), name);
  }
```

#### AUTO 


```{c}
auto wavFile = dynamic_cast<WavFile*>(file)
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& soi : strOfId) {
      idStrMap.insert(soi.id, soi.str);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& part : parts) {
      auto s = part.trimmed();
      // First extract all genre codes which are in parentheses
      int offset = 0;
      int end = 0;
      while (s.length() > offset && s.at(offset) == QLatin1Char('(') &&
            (end = s.indexOf(QLatin1Char(')'), offset + 1)) > offset) {
        const auto genreCode = s.mid(offset + 1, end - 1);
        s = s.mid(end + 1);
        bool ok;
        int n = genreCode.toInt(&ok);
        if (genreCode == QLatin1String("RX") ||
            genreCode == QLatin1String("CR")) {
          genres.append(genreCode.toString());
        } else if (ok && n >= 0 && n <= 0xff) {
          QString genreText = QString::fromLatin1(getName(n));
          if (!genreText.isEmpty()) {
            genres.append(genreText);
          }
        }
      }
      // Process the rest as a genre code or text
      s = s.trimmed();
      if (!s.isEmpty()) {
        bool ok;
        int n = s.toInt(&ok);
        if (ok && n >= 0 && n <= 0xff) {
          QString genreText = QString::fromLatin1(getName(n));
          if (!genreText.isEmpty()) {
            genres.append(genreText);
          }
        } else {
          genres.append(s.toString());
        }
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (ITaggedFileFactory* factory : factories) {
    const auto keys = factory->taggedFileKeys();
    for (const QString& key : keys) {
      taggedFile = factory->createTaggedFile(key, fileName, idx);
      if (taggedFile) {
        return taggedFile;
      }
    }
  }
```

#### AUTO 


```{c}
auto frameIt = frameCollection.begin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& localeName : localeNames) {
    if (
        localeName.startsWith(QLatin1String("en")) ||
        (!translationsDir.isNull() &&
         qtTr->load(QLatin1String(QT_TRANSLATION_PREFIX) + localeName,
                    translationsDir, searchDelimiters)) ||
        qtTr->load(QLatin1String(QT_TRANSLATION_PREFIX) + localeName,
                   QLatin1String("."), searchDelimiters)
#if !(defined Q_OS_WIN32 || defined Q_OS_MAC || defined Q_OS_ANDROID)
        || qtTr->load(QLatin1String(QT_TRANSLATION_PREFIX) + localeName,
                   QLibraryInfo::location(QLibraryInfo::TranslationsPath),
                   searchDelimiters)
#endif
        ) {
      break;
    }
  }
```

#### AUTO 


```{c}
auto it = indexes.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& nameType : nameTypes) {
      if (nameType.type != Frame::FT_Other) {
        typeNameMap.insert(nameType.type, QString::fromLatin1(nameType.name));
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BatchImportProfile& profile : profiles) {
      m_profileComboBox->addItem(profile.getName());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const ServerTrackImporter* si : stis) {
    QString serverName(QCoreApplication::translate("@default", si->name()));
    QString actionName = QString::fromLatin1(si->name()).toLower().
        remove(QLatin1Char(' '));
    int dotPos = actionName.indexOf(QLatin1Char('.'));
    if (dotPos != -1)
      actionName.truncate(dotPos);
    actionName = QLatin1String("import_") + actionName;
    action = new QAction(tr("Import from %1...").arg(serverName), this);
    action->setStatusTip(tr("Import from %1").arg(serverName));
    action->setData(importerIdx);
    collection->addAction(actionName, action);
    connect(action, &QAction::triggered, impl(), &BaseMainWindowImpl::slotImport);
    ++importerIdx;
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& value : values) {
      if (result.isNull() || value < result) {
        result = value;
      }
    }
```

#### AUTO 


```{c}
auto it = m_codePos.constBegin();
```

#### AUTO 


```{c}
auto selModel = m_app->getFileSelectionModel()
```

#### RANGE FOR STATEMENT 


```{c}
for (const ServerTrackImporter* si : stis) {
    QString serverName(QCoreApplication::translate("@default", si->name()));
    QString actionName = QString::fromLatin1(si->name()).toLower().
        remove(QLatin1Char(' '));
    int dotPos = actionName.indexOf(QLatin1Char('.'));
    if (dotPos != -1)
      actionName.truncate(dotPos);
    actionName = QLatin1String("import_") + actionName;
    action = new QAction(tr("Import from %1...").arg(serverName), this);
    action->setStatusTip(tr("Import from %1").arg(serverName));
    action->setData(importerIdx);
    collection->addAction(actionName, action);
    connect(action, SIGNAL(triggered()), impl(), SLOT(slotImport()));
    ++importerIdx;
  }
```

#### AUTO 


```{c}
auto end = frames.cend();
```

#### AUTO 


```{c}
auto match = sourceUrlRe.match(ref);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& language : languages) {
      m_languageComboBox->addItem(language);
    }
```

#### AUTO 


```{c}
auto otherIt = frames.begin();
```

#### AUTO 


```{c}
auto frameIt = frameCollection.cbegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& path : paths) {
    QStringList expandedPath;
    int wcIdx = path.indexOf(QRegularExpression(QLatin1String("[?*]")));
    if (wcIdx != -1) {
      QString partBefore, partAfter;
      int beforeIdx = path.lastIndexOf(QDir::separator(), wcIdx);
      partBefore = path.left(beforeIdx + 1);
      int afterIdx = path.indexOf(QDir::separator(), wcIdx);
      if (afterIdx == -1) {
        afterIdx = path.length();
      }
      partAfter = path.mid(afterIdx + 1);
      QString wildcardPart = path.mid(beforeIdx + 1, afterIdx - beforeIdx);
      if (!wildcardPart.isEmpty()) {
        QDir dir(partBefore);
        if (!dir.exists(wildcardPart)) {
          const QStringList entries = dir.entryList({wildcardPart},
                                    QDir::AllEntries | QDir::NoDotAndDotDot);
          if (!entries.isEmpty()) {
            for (const QString& entry : entries) {
              expandedPath.append(partBefore + entry + partAfter); // clazy:exclude=reserve-candidates
            }
          }
        }
      }
    }
    if (expandedPath.isEmpty()) {
      expandedPaths.append(path); // clazy:exclude=reserve-candidates
    } else {
      expandedPaths.append(expandedPath);
    }
  }
```

#### AUTO 


```{c}
auto it = attrListMap.begin();
```

#### AUTO 


```{c}
auto match = dateRe.match(date);
```

#### AUTO 


```{c}
auto time = qFromBigEndian<quint32>(
          reinterpret_cast<const uchar*>(bytes.constData()) + pos);
```

#### AUTO 


```{c}
const auto factories = s_taggedFileFactories;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& localeName : localeNames) {
    if (
        localeName.startsWith(QLatin1String("en")) ||
        (!translationsDir.isNull() &&
         kid3Tr->load(QLatin1String("kid3_") + localeName, translationsDir,
                      searchDelimiters)) ||
        kid3Tr->load(QLatin1String("kid3_") + localeName, QLatin1String("."),
                     searchDelimiters)
        ) {
      break;
    }
  }
```

#### AUTO 


```{c}
auto riffGroupBoxLayout = new QGridLayout(riffGroupBox);
```

#### AUTO 


```{c}
auto pcGroupBoxLayout = new QVBoxLayout(pcGroupBox);
```

#### AUTO 


```{c}
auto field
```

#### AUTO 


```{c}
auto ali = static_cast<AlbumListItem*>(li);
```

#### AUTO 


```{c}
auto conn = std::make_shared<QMetaObject::Connection>();
```

#### AUTO 


```{c}
const auto sis = app()->getServerImporters();
```

#### AUTO 


```{c}
const auto constFrameTypes = frameTypes;
```

#### RANGE FOR STATEMENT 


```{c}
for (auto fieldName : fieldNames) {
    lst.append(QString::fromLatin1(fieldName));
  }
```

#### AUTO 


```{c}
auto action = qobject_cast<QAction*>(sender());
```

#### AUTO 


```{c}
auto quickAccessTagsLayout = new QVBoxLayout(quickAccessTagsGroupBox);
```

#### RANGE FOR STATEMENT 


```{c}
for (const ShortcutGroup& g : gs) {
              for (const ShortcutItem& i : g) {
                if (i.activeShortcut() == keyString &&
                    si.action() != i.action()) {
                  emit shortcutAlreadyUsed(keyString, g.context(), i.action());
                  return false;
                }
              }
            }
```

#### AUTO 


```{c}
auto stateCfg = KSharedConfig::openConfig();
```

#### AUTO 


```{c}
auto editInvertSelection = new QAction(this);
```

#### AUTO 


```{c}
auto name = Frame::ExtendedType(static_cast<Frame::Type>(k), QLatin1String("")). // clazy:exclude=reserve-candidates
          getName();
```

#### AUTO 


```{c}
auto end = frames.end();
```

#### AUTO 


```{c}
auto it = strNumMap.constFind(ucName);
```

#### AUTO 


```{c}
auto it = tagVersions.constBegin();
```

#### AUTO 


```{c}
auto actionLayout = new QFormLayout;
```

#### AUTO 


```{c}
auto rowIt = m_frameOfRow.begin();
```

#### AUTO 


```{c}
auto idTitleMatch = it.next();
```

#### AUTO 


```{c}
auto data = new char[size];
```

#### AUTO 


```{c}
auto fmt
```

#### AUTO 


```{c}
auto it = customFrameNameMap.constFind(ucName);
```

#### AUTO 


```{c}
auto match = yearRe.match(str.mid(start, end));
```

#### AUTO 


```{c}
auto settingsConfigure = new QAction(this);
```

#### AUTO 


```{c}
const auto profiles = m_profiles;
```

#### AUTO 


```{c}
auto fileOpenDirectory = new QAction(this);
```

#### AUTO 


```{c}
const auto &file
```

#### AUTO 


```{c}
auto match = titleRe.match(trackDataStr);
```

#### AUTO 


```{c}
auto it = m_fieldList.constBegin();
```

#### AUTO 


```{c}
const auto& mapping
```

#### AUTO 


```{c}
auto fieldName
```

#### AUTO 


```{c}
const auto artists((track.contains(QLatin1String("artists"))
                        ? track.value(QLatin1String("artists"))
                        : track.value(QLatin1String("primaryArtists")))
                       .toArray());
```

#### AUTO 


```{c}
auto style = QSettings(QSettings::UserScope, QLatin1String("Kid3"),
                         QLatin1String("Kid3"))
      .value(QLatin1String("MainWindow/QtQuickStyle")).toByteArray();
```

#### AUTO 


```{c}
const auto filePaths = notWritableFiles;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& folder : folders) {
    QString pattern = folder.trimmed();
    if (!pattern.isEmpty()) {
      if (pattern.contains(QLatin1Char(' '))) {
        sep = QLatin1Char(';');
      }
      patterns.append(pattern); // clazy:exclude=reserve-candidates
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BatchImportProfile& profile : profiles) {
    names.append(profile.getName());
    sources.append(profile.getSourcesAsString());
  }
```

#### AUTO 


```{c}
auto it = nameFilters.constBegin();
```

#### AUTO 


```{c}
auto iodev = reinterpret_cast<QIODevice*>(stream);
```

#### AUTO 


```{c}
auto model = qobject_cast<const FileProxyModel*>(index.model())
```

#### AUTO 


```{c}
auto cbox = new IntComboBoxControl(
                fld, Frame::Field::getTextEncodingNames());
```

#### AUTO 


```{c}
auto flacFile =
            dynamic_cast<TagLib::FLAC::File*>(file)
```

#### AUTO 


```{c}
auto fieldObj = new FrameFieldObject(-1, this);
```

#### AUTO 


```{c}
auto model = const_cast<FileProxyModel*>(
        qobject_cast<const FileProxyModel*>(index.model()))
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& line : lines) {
    QStringList strs = line.split(QLatin1Char(' '));
    if (strs.size() > 1) {
      bool ok;
      int typeInt = strs.at(0).toInt(&ok);
      if (ok && typeInt >= 0 && typeInt <= 8) {
        short adj = strs.at(1).toShort(&ok);
        if (ok) {
          TagLib::ID3v2::RelativeVolumeFrame::ChannelType type =
              static_cast<TagLib::ID3v2::RelativeVolumeFrame::ChannelType>(
                typeInt);
          rva2Frame->setVolumeAdjustmentIndex(adj, type);
          TagLib::ID3v2::RelativeVolumeFrame::PeakVolume peak;
          if (strs.size() > 3) {
            int bitsInt = strs.at(2).toInt(&ok);
            QByteArray ba = QByteArray::fromHex(strs.at(3).toLatin1());
            if (ok && bitsInt > 0 && bitsInt <= 255 &&
                bitsInt <= ba.size() * 8) {
              peak.bitsRepresentingPeak = bitsInt;
              peak.peakVolume.setData(ba.constData(), ba.size());
              rva2Frame->setPeakVolume(peak, type);
            }
          }
        }
      }
    }
  }
```

#### AUTO 


```{c}
auto name = Frame::ExtendedType(static_cast<Frame::Type>(type),
                                    QLatin1String("")).getName();
```

#### AUTO 


```{c}
const auto& extraArtist
```

#### AUTO 


```{c}
auto formatMatch = formatRe.match(metadata);
```

#### AUTO 


```{c}
auto match = catNoRe.match(labelStr);
```

#### AUTO 


```{c}
auto it = begin();
```

#### AUTO 


```{c}
auto genresEdit = new StringListEdit(m_genresEditModel, genresWidget);
```

#### AUTO 


```{c}
auto toolBar = new QToolBar(this);
```

#### AUTO 


```{c}
auto timeStampFormatIt = fields.end();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QPersistentModelIndex& index : indexes) {
    if (const auto model =
        qobject_cast<const FileProxyModel*>(index.model())) {
      QString filePath = model->filePath(index);
      PlaylistCreator::Entry entry;
      entry.filePath = m_cfg.useFullPath()
          ? filePath
          : playlistDir.relativeFilePath(filePath);
      if (m_cfg.writeInfo()) {
        Item(index, *this).getInfo(entry.info, entry.duration);
      }
      entries.append(entry);
    }
  }
```

#### AUTO 


```{c}
const auto model =
      qobject_cast<const FileProxyModel*>(index.model());
```

#### AUTO 


```{c}
auto iit = git->begin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVariant& var : indexes) {
    QModelIndex index = var.toModelIndex();
    if (!firstIndex.isValid()) {
      firstIndex = index;
    }
    selection.select(index, index);
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& index : indexes) {
      m_model->setData(index, index.column() == TimeEventModel::CI_Time
                       ? emptyTime : emptyData);
    }
```

