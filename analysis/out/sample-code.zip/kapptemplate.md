#### AUTO 


```{c}
const auto templateFiles = QDir(localDescriptionsDir).entryList(QDir::Files);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &archName : qAsConst(templateArchives)) {
        qCDebug(KAPPTEMPLATE) << "processing template" << archName;
#ifdef Q_WS_WIN
        KZip templateArchive(archName);
#else
        KTar templateArchive(archName, "application/x-bzip");
#endif // Q_WS_WIN
        if (templateArchive.open(QIODevice::ReadOnly)) {
            QFileInfo templateInfo(archName);
            const QString descriptionFileName = templateInfo.baseName() + QStringLiteral(".kdevtemplate");
            const KArchiveEntry *templateEntry = templateArchive.directory()->entry(descriptionFileName);
            // but could be different name, if e.g. downloaded, so make a guess
            if (!templateEntry || !templateEntry->isFile()) {
                for (const auto& entryName : templateArchive.directory()->entries()) {
                    if (entryName.endsWith(QLatin1String(".kdevtemplate"))) {
                        templateEntry = templateArchive.directory()->entry(entryName);
                        break;
                    }
                }
            }

            if (!templateEntry || !templateEntry->isFile()) {
                qCDebug(KAPPTEMPLATE) << "template" << archName << "does not contain .kdevtemplate file";
                continue;
            }
            const KArchiveFile *templateFile = (KArchiveFile*)templateEntry;

            qCDebug(KAPPTEMPLATE) << "copy template description to" << localDescriptionsDir;
            if (templateFile->name() == descriptionFileName) {
                templateFile->copyTo(localDescriptionsDir);
            } else {
                // Rename the extracted description
                // so that its basename matches the basename of the template archive
                // Use temporary dir to not overwrite other files with same name
                QTemporaryDir dir;
                templateFile->copyTo(dir.path());
                const QString destinationPath = localDescriptionsDir + descriptionFileName;
                QFile::remove(destinationPath);
                QFile::rename(dir.path() + QLatin1Char('/') + templateFile->name(), destinationPath);
            }
        } else {
            qCDebug(KAPPTEMPLATE) << "could not open template" << archName;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &templateFile : templateFiles) {
        templateArchives.append(localDescriptionsDir + templateFile);
    }
```

#### AUTO 


```{c}
const auto templateArchives = QDir(templatePath).entryList(QDir::Files);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &templateArchive : qAsConst(templateArchives)) {
        QFileInfo archiveInfo(templateArchive);
        QString baseName = archiveInfo.baseName();
        KConfig templateConfig(templateArchive);
        KConfigGroup general(&templateConfig, "General");
        QString name = general.readEntry("Name");
        QString category = general.readEntry("Category");
        qCDebug(KAPPTEMPLATE) << "category " << category;
        QString description = general.readEntry("Comment");
        QString picture = general.readEntry("Icon");
        AppTemplateItem *templateItem = createItem(name, category);
        templateItem->setData(description, DescriptionFileRole);
        templateItem->setData(picture, PictureNameRole);
        templateItem->setData(baseName, BaseNameRole);
    }
```

#### AUTO 


```{c}
const auto& entryName
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &templatePath : qAsConst(templatePaths)) {
        const auto templateFiles = QDir(templatePath).entryList(QDir::Files);
        for (const QString &templateArchive : templateFiles) {
            templateArchives.append(templatePath + templateArchive);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &entry : entries) {
        progress++;
        ui_generate.progressBar->setValue((progress / entries.size()) * 100);

        if (skipList.contains(entry)) {
            continue;
        }

        if (dir->entry(entry)->isDirectory()) {
            const KArchiveDirectory *file = dynamic_cast<const KArchiveDirectory *>(dir->entry(entry));
            QString newdest = dest + "/" + file->name();
            if (!QFileInfo(newdest).exists()) {
                if (!QDir::root().mkdir(newdest)) {
                    displayError(i18n("Path %1 could not be created.", newdest));
                    return false;
                }
            }
            ret |= unpackArchive(file, newdest);
        }
        else if (dir->entry(entry)->isFile()) {
            const KArchiveFile *file = dynamic_cast<const KArchiveFile *>(dir->entry(entry));
            file->copyTo(tdir.path());
            QString destName = KMacroExpander::expandMacros(dest + '/' + file->name(), m_variables);
            if (QFile(QDir::cleanPath(tdir.path() + '/' + file->name())).copy(destName)) {
                if (!extractFileMacros(destName)) {
                    displayError(i18n("Failed to integrate your project information into "
                                      "the file %1. The project has not been generated and "
                                      "all temporary files will be removed.", destName));
                    failed = true;
                    break;
                }
            } else {
                displayError(i18n("Could not copy template file to %1.", destName));
                failed = true;
                break;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &templateArchive : templateArchives) {
            const QString baseName = QFileInfo(templateArchive).baseName();
            if (archiveBaseName.compare(baseName) == 0) {
                archivePath = templatePath + templateArchive;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &templatePath : templatePaths) {
        const auto templateArchives = QDir(templatePath).entryList(QDir::Files);
        for (const QString &templateArchive : templateArchives) {
            const QString baseName = QFileInfo(templateArchive).baseName();
            if (templateName.compare(baseName) == 0) {
                archName = templatePath + templateArchive;
                break;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &templatePath : templatePaths) {
        const auto templateArchives = QDir(templatePath).entryList(QDir::Files);
        for (const QString &templateArchive : templateArchives) {
            const QString baseName = QFileInfo(templateArchive).baseName();
            if (archiveBaseName.compare(baseName) == 0) {
                archivePath = templatePath + templateArchive;
                break;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& entryName : arch->directory()->entries()) {
                if (entryName.endsWith(QLatin1String(".kdevtemplate"))) {
                    templateEntry = arch->directory()->entry(entryName);
                    break;
                }
            }
```

#### AUTO 


```{c}
const auto data = iconFile->data();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &templateArchive : templateArchives) {
            const QString baseName = QFileInfo(templateArchive).baseName();
            if (templateName.compare(baseName) == 0) {
                archName = templatePath + templateArchive;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &entry : path) {
        currentPath << entry;
        qCDebug(KAPPTEMPLATE) << "current path " << currentPath;
        if (!m_templateItems.contains(currentPath.join("/"))) {
            AppTemplateItem *item = new AppTemplateItem(entry);
            parent->appendRow(item);
            m_templateItems[currentPath.join("/")] = item;
            parent = item;
        } else {
            parent = m_templateItems[currentPath.join("/")];
        }
    }
```

#### AUTO 


```{c}
const auto templateFiles = QDir(templatePath).entryList(QDir::Files);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &templateArchive : templateFiles) {
            templateArchives.append(templatePath + templateArchive);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& entryName : templateArchive.directory()->entries()) {
                    if (entryName.endsWith(QLatin1String(".kdevtemplate"))) {
                        templateEntry = templateArchive.directory()->entry(entryName);
                        break;
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& fileName : selectedFiles) {
        qCDebug(KAPPTEMPLATE) << "Copying" << fileName << "to" << saveLocation;
        QFileInfo info(fileName);
        QFile::copy(fileName, saveLocation + info.fileName());
    }
```

