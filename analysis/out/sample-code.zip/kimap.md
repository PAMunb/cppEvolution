#### AUTO 


```{c}
auto child = new KMime::Content;
```

#### AUTO 


```{c}
auto *capabilities = new CapabilitiesJob(&session);
```

#### AUTO 


```{c}
auto job = new KIMAP::ListJob(&session);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &flag : qAsConst(d->flags)) {
            parameters += flag + ' ';
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const MailBoxDescriptor &descriptor : std::as_const(d->namespaces)) {
            QString parameters = QStringLiteral("\"\" \"%1\"");

            if (descriptor.name.endsWith(descriptor.separator)) {
                QString name = encodeImapFolderName(descriptor.name);
                name.chop(1);
                d->tags << d->sessionInternal()->sendCommand(d->command, parameters.arg(name).toUtf8());
            }

            d->tags << d->sessionInternal()->sendCommand(d->command, parameters.arg(descriptor.name + QLatin1Char('*')).toUtf8());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Part &part : std::as_const(content)) {
            if (part.type() == Part::List) {
                result += '(';
                const QList<QByteArray> lstBa = part.toList();
                for (const QByteArray &item : lstBa) {
                    result += ' ';
                    result += item;
                }
                result += " ) ";
            } else {
                result += part.toString() + ' ';
            }
        }
```

#### AUTO 


```{c}
auto append = new AppendJob(session);
```

#### AUTO 


```{c}
auto *myRights = new MyRightsJob(session);
```

#### AUTO 


```{c}
auto *store = new StoreJob(session);
```

#### LAMBDA EXPRESSION 


```{c}
[this, response]() {
        doSslErrorHandlerResponse(response);
    }
```

#### AUTO 


```{c}
const auto allpartskeys = allParts.keys();
```

#### AUTO 


```{c}
auto job = new KIMAP::StatusJob(&session);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &flag : flags) {
            parameters += flag + ' ';
        }
```

#### AUTO 


```{c}
auto *job = new KIMAP::SearchJob(&session);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &interval : std::as_const(intervals)) {
        if (!interval.isEmpty()) {
            result.add(ImapInterval::fromImapSequence(interval));
        }
    }
```

#### AUTO 


```{c}
auto *getMetadataJob = new KIMAP::GetMetaDataJob(&session);
```

#### AUTO 


```{c}
auto *socket = qobject_cast<QSslSocket *>(QObject::sender());
```

#### AUTO 


```{c}
auto *idle = new IdleJob(&session);
```

#### AUTO 


```{c}
auto rename = new RenameJob(session);
```

#### AUTO 


```{c}
auto *unsubscribe = new UnsubscribeJob(session);
```

#### AUTO 


```{c}
auto *expunge = new ExpungeJob(&session);
```

#### AUTO 


```{c}
const auto messagesKey = messages.keys();
```

#### LAMBDA EXPRESSION 


```{c}
[d]() {
        d->resetTimeout();
    }
```

#### AUTO 


```{c}
auto job = new KIMAP::SearchJob(&session);
```

#### LAMBDA EXPRESSION 


```{c}
[this, version]() { doStartSsl(version); }
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString &, const QMap<qint64, qint64> &,
                                const QMap<qint64, qint64> &, const QMap<qint64, MessageFlags> &,
                                const QMap<qint64, MessagePtr> &msgs) {
                        message = msgs[1];
                    }
```

#### LAMBDA EXPRESSION 


```{c}
[d](bool result) {
        d->sslResponse(result);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const Response::Part &part) {
                                                return part.type() == Response::Part::String
                                                        && part.toString() == "STARTTLS";
                                           }
```

#### RANGE FOR STATEMENT 


```{c}
for (qint64 id : messagesKey) {
        qDebug() << "* Message" << id << "(" << sizes[id] << "bytes )";
        qDebug() << "  From      :" << messages[id]->from()->asUnicodeString();
        qDebug() << "  To        :" << messages[id]->to()->asUnicodeString();
        qDebug() << "  Date      :" << messages[id]->date()->asUnicodeString();
        qDebug() << "  Subject   :" << messages[id]->subject()->asUnicodeString();
        qDebug() << "  Message-ID:" << messages[id]->messageID()->asUnicodeString();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, response]() { doSslErrorHandlerResponse(response); }
```

#### AUTO 


```{c}
auto *setmetadata = new SetMetaDataJob(session);
```

#### LAMBDA EXPRESSION 


```{c}
[d]() {
        d->emitStats();
    }
```

#### AUTO 


```{c}
auto *job = new KIMAP::ListJob(&session);
```

#### AUTO 


```{c}
auto *create = new CreateJob(session);
```

#### AUTO 


```{c}
auto expunge = new ExpungeJob(&session);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &capability : qAsConst(d->capabilities)) {
                    if (capability.startsWith(QLatin1String("AUTH="))) {
                        if (capability.midRef(5) == d->authMode) {
                            authModeSupported = true;
                            break;
                        }
                    }
                }
```

#### AUTO 


```{c}
auto *close = new CloseJob(&session);
```

#### RANGE FOR STATEMENT 


```{c}
for (qint64 id : flagsKey) {
        qDebug() << "* Message" << id << "flags:" << flags[id];
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Part &part : qAsConst(content)) {
            if (part.type() == Part::List) {
                result += '(';
                const QList<QByteArray> lstBa = part.toList();
                for (const QByteArray &item : lstBa) {
                    result += ' ';
                    result += item;
                }
                result += " ) ";
            } else {
                result += part.toString() + ' ';
            }
        }
```

#### AUTO 


```{c}
auto *logout = new LogoutJob(&session);
```

#### AUTO 


```{c}
auto job = new KIMAP::CapabilitiesJob(&session);
```

#### AUTO 


```{c}
auto job = new KIMAP::GetQuotaRootJob(&session);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &entry : entriesKeys) {
        const QMap<QByteArray, QByteArray> &values = entries[entry];
        const auto valuesKeys = values.keys();
        for (const QByteArray &attribute : valuesKeys) {
            map.insert(d->addPrefix(entry, attribute), values[attribute]);
        }
    }
```

#### AUTO 


```{c}
auto *job = new KIMAP::StoreJob(&session);
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString &,
                         const QMap<qint64, qint64> &,
                         const QMap<qint64, qint64> &,
                         const QMap<qint64, MessageFlags> &,
                         const QMap<qint64, MessagePtr> &msgs_) {
                         messages = msgs_;
                     }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QList<QByteArray> &scenario : std::as_const(m_scenarios)) {
        if (!scenario.isEmpty()) {
            return false;
        }
    }
```

#### AUTO 


```{c}
auto *fetch = new FetchJob(&session);
```

#### AUTO 


```{c}
const auto valuesKeys = values.keys();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &part : std::as_const(d->scope.parts)) {
                parameters += "BODY.PEEK[" + part + "] ";
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &capability : qAsConst(d->capabilities)) {
                    if (capability.startsWith(QLatin1String("AUTH="))) {
                        if (capability.mid(5) == d->authMode) {
                            authModeSupported = true;
                            break;
                        }
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &key : keys) {
            job->setField(key, values.value(key));
        }
```

#### AUTO 


```{c}
auto setmetadata = new SetMetaDataJob(session);
```

#### AUTO 


```{c}
auto *socket = qobject_cast<QTcpSocket *>(sender());
```

#### AUTO 


```{c}
auto optimizedSet = set;
```

#### AUTO 


```{c}
auto myRights = new MyRightsJob(session);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &namespaceItem : namespaceList) {
            ImapStreamParser parser(nullptr);
            parser.setData(namespaceItem);

            try {
                QList<QByteArray> parts = parser.readParenthesizedList();
                if (parts.size() < 2) {
                    continue;
                }
                MailBoxDescriptor descriptor;
                descriptor.name = QString::fromUtf8(decodeImapFolderName(parts[0]));
                descriptor.separator = QLatin1Char(parts[1][0]);

                result << descriptor;
            } catch (KIMAP::ImapParserException e) {
                qCWarning(KIMAP_LOG) << "The stream parser raised an exception during namespace list parsing:" << e.what();
                qCWarning(KIMAP_LOG) << "namespacelist:" << namespaceList;
            }

        }
```

#### AUTO 


```{c}
auto *latin = (signed char *)calloc(1, str.length() + 1);
```

#### LAMBDA EXPRESSION 


```{c}
[](const ImapInterval &lhs, const ImapInterval &rhs) {
                   return lhs.begin() < rhs.begin();
              }
```

#### AUTO 


```{c}
auto setAcl = new SetAclJob(session);
```

#### AUTO 


```{c}
auto *socket = new QSslSocket();
```

#### AUTO 


```{c}
auto select = new SelectJob(&session);
```

#### AUTO 


```{c}
auto select = new SelectJob(session);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &entry : sortedEntries) {
            parameters += '\"' + entry + "\" ";
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            emitPendings();
        }
```

#### AUTO 


```{c}
auto login = new LoginJob(&session);
```

#### AUTO 


```{c}
auto job = new KIMAP::ExpungeJob(&session);
```

#### AUTO 


```{c}
auto *login = new LoginJob(&session);
```

#### AUTO 


```{c}
auto *child = new KMime::Content;
```

#### RANGE FOR STATEMENT 


```{c}
for (qint64 id : allkeys) {
        qDebug() << "* Message" << id << "parts headers";
        MessageParts parts = allParts[id];
        const auto parsKeys = parts.keys();
        for (const QByteArray &partId : parsKeys) {
            qDebug() << "  ** Part" << partId;
            qDebug() << "     Name       :" << parts[partId]->contentType()->name();
            qDebug() << "     Mimetype   :" << parts[partId]->contentType()->mimeType();
            qDebug() << "     Description:" << parts[partId]->contentDescription()->asUnicodeString().simplified();
        }
    }
```

#### AUTO 


```{c}
auto *job = new KIMAP::DeleteJob(&session);
```

#### AUTO 


```{c}
const auto entriesKeys = entries.keys();
```

#### AUTO 


```{c}
const auto flagsKey = flags.keys();
```

#### AUTO 


```{c}
auto *fetch = new FetchJob(session);
```

#### AUTO 


```{c}
auto fetch = new FetchJob(&session);
```

#### AUTO 


```{c}
auto *getAcl = new GetAclJob(session);
```

#### AUTO 


```{c}
const auto keys = values.keys();
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString &,
                         const QMap<qint64, qint64> &,
                         const QMap<qint64, qint64> &,
                         const QMap<qint64, MessageFlags> &,
                         const QMap<qint64, MessagePtr> &msgs) {
                         message = msgs[1];
                     }
```

#### AUTO 


```{c}
auto getmetadata = new GetMetaDataJob(session);
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString &, const QMap<qint64, qint64> &,
                                const QMap<qint64, MessageParts> &parts_) {
                         allParts = parts_;
                     }
```

#### AUTO 


```{c}
auto job = new KIMAP::StoreJob(&session);
```

#### AUTO 


```{c}
auto *job = new KIMAP::AppendJob(&session);
```

#### AUTO 


```{c}
auto *job = new KIMAP::EnableJob(&session);
```

#### AUTO 


```{c}
auto fetch = new FetchJob(session);
```

#### AUTO 


```{c}
auto job = new KIMAP::MoveJob(&session);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &flag : std::as_const(d->flags)) {
            parameters += flag + ' ';
        }
```

#### AUTO 


```{c}
const auto personalNamespaces = namespaces->personalNamespaces();
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString &,
                         const QMap<qint64, qint64> &,
                         const QMap<qint64, qint64> &,
                         const QMap<qint64, MessageFlags> &flags,
                         const QMap<qint64, MessagePtr> &) {
                         expectedFlags = flags[1];
                     }
```

#### AUTO 


```{c}
auto proxy = new UiProxy();
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString &, const QMap<qint64, qint64> &,
                                const QMap<qint64, qint64> &, const QMap<qint64, MessageFlags> &flags,
                                const QMap<qint64, MessagePtr> &) {
                        expectedFlags = flags[1];
                    }
```

#### AUTO 


```{c}
auto getAcl = new GetAclJob(session);
```

#### RANGE FOR STATEMENT 


```{c}
for (MailBoxDescriptor ns : personalNamespaces) {
        qDebug() << ns.separator << ns.name;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (MailBoxDescriptor ns : userNamespaces) {
        qDebug() << ns.separator << ns.name;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &item : lstBa) {
                        result += ' ';
                        result += item;
                    }
```

#### AUTO 


```{c}
auto socket = qobject_cast<QSslSocket *>(QObject::sender());
```

#### AUTO 


```{c}
const auto sortedAttributes = sort(d->attributes);
```

#### LAMBDA EXPRESSION 


```{c}
[d]() {
        d->emitPendings();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &item : lstBa) {
                    result += ' ';
                    result += item;
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const MailBoxDescriptor &descriptor : completeList) {
        if (descriptor.name.isEmpty()) {
            return true;
        }
    }
```

#### AUTO 


```{c}
auto *getMetadataJob = new KIMAP::GetMetaDataJob( &session);
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString &, const QMap<qint64,qint64> &,
                                const QMap<qint64, qint64> &sizes_,
                                const QMap<qint64, MessageFlags> &,
                                const QMap<qint64, MessagePtr> &msgs_) {
                         sizes = sizes_;
                         messages = msgs_;
                     }
```

#### AUTO 


```{c}
auto *append = new AppendJob(session);
```

#### AUTO 


```{c}
auto *setAcl = new SetAclJob(session);
```

#### AUTO 


```{c}
auto *select = new SelectJob(session);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &part : std::as_const(d->scope.parts)) {
                parameters += "BODY.PEEK[" + part + ".MIME] ";
            }
```

#### AUTO 


```{c}
auto job = new KIMAP::RenameJob(&session);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &entry : keys) {
            QCOMPARE(getMetadataJob->metaData(mailbox, entry), expectedAnnotations.value(entry));
            QCOMPARE(getMetadataJob->metaData(entry), expectedAnnotations.value(entry));
            QCOMPARE(allMetaData.value(entry), expectedAnnotations.value(entry));
        }
```

#### AUTO 


```{c}
auto close = new CloseJob(&session);
```

#### AUTO 


```{c}
auto getMetadataJob = new KIMAP::GetMetaDataJob(&session);
```

#### RANGE FOR STATEMENT 


```{c}
for (const SearchCriteriaValuePair &pair : qAsConst(searchCriteria)) {
            if (pair.second.isEmpty()) {
                job->addSearchCriteria(pair.first);
            } else {
                job->addSearchCriteria(pair.first, pair.second);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Term &t : subterms) {
                d->command += t.serialize() + ' ';
            }
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString &, const QMap<qint64,qint64> &,
                                const QMap<qint64, qint64> &,
                                const QMap<qint64, MessageFlags> &,
                                const QMap<qint64, MessagePtr> &msgs_) {
                         messages = msgs_;
                     }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &entry : sortedEntries) {
                parameters += entry + " ";
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &partId : parsKeys) {
            qDebug() << "  ** Part" << partId;
            qDebug() << "     Name       :" << parts[partId]->contentType()->name();
            qDebug() << "     Mimetype   :" << parts[partId]->contentType()->mimeType();
            qDebug() << "     Description:" << parts[partId]->contentDescription()->asUnicodeString().simplified();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &capability : qAsConst(d->capabilities)) {
                    if (capability.startsWith(QLatin1String("AUTH="))) {
                        if (QStringView(capability).mid(5) == d->authMode) {
                            authModeSupported = true;
                            break;
                        }
                    }
                }
```

#### AUTO 


```{c}
auto socket = qobject_cast<QTcpSocket *>(sender());
```

#### LAMBDA EXPRESSION 


```{c}
[](const ImapInterval &lhs, const ImapInterval &rhs) {
        return lhs.begin() < rhs.begin();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &partId : partsKeys) {
            qDebug() << "* Message" << id << "part" << partId << "content:";
            qDebug() << parts[partId]->body();
        }
```

#### AUTO 


```{c}
auto it = msgs.begin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &item : itemLst) {
                serverGreeting += QLatin1String(item) + QLatin1Char(' ');
            }
```

#### AUTO 


```{c}
auto *setMetadataJob = new KIMAP::SetMetaDataJob(&session);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &part : qAsConst(d->scope.parts)) {
                parameters += "BODY.PEEK[" + part + "] ";
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (int i : { 5, 8, 3, 1, 9, 2, 7, 4, 6 }) {
                imapSet.add(i);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (int id : allpartskeys) {
        MessageParts parts = allParts[id];
        const auto partsKeys = parts.keys();
        for (const QByteArray &partId : partsKeys) {
            qDebug() << "* Message" << id << "part" << partId << "content:";
            qDebug() << parts[partId]->body();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &part : qAsConst(d->scope.parts)) {
                parameters += " BODY.PEEK[" + part + ".MIME] BODY.PEEK[" + part + "]"; // krazy:exclude=doublequote_chars
            }
```

#### AUTO 


```{c}
auto *login = qobject_cast<KIMAP::LoginJob *>(queue.first());
```

#### AUTO 


```{c}
auto *job = new KIMAP::IdJob(&session);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &capability : std::as_const(d->capabilities)) {
                    if (capability.startsWith(QLatin1String("AUTH="))) {
                        if (QStringView(capability).mid(5) == d->authMode) {
                            authModeSupported = true;
                            break;
                        }
                    }
                }
```

#### AUTO 


```{c}
auto it = content.cbegin(), end = content.cend();
```

#### AUTO 


```{c}
auto *job = new KIMAP::UnsubscribeJob(&session);
```

#### AUTO 


```{c}
auto *listRights = new ListRightsJob(session);
```

#### AUTO 


```{c}
const auto msgs = modifiedSpyCatch.at(0).value<Messages>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &attribute : sortedAttributes) {
            parameters += '\"' + attribute + "\" ";
        }
```

#### AUTO 


```{c}
auto *proxy = new UiProxy();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Part &part : qAsConst(content)) {
            if (part.type() == Part::List) {
                result += '(';
                const QList<QByteArray> lstBa = part.toList();
                for (const QByteArray &item : lstBa ) {
                    result += ' ';
                    result += item;
                }
                result += " ) ";
            } else {
                result += part.toString() + ' ';
            }
        }
```

#### AUTO 


```{c}
auto create = new CreateJob(session);
```

#### AUTO 


```{c}
auto namespaces = new NamespaceJob(&session);
```

#### RANGE FOR STATEMENT 


```{c}
for (const ImapInterval &interval : qAsConst(d->intervals)) {
        if (!other.d->intervals.contains(interval)) {
            return false;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString &,
                         const QMap<qint64, qint64> &,
                         const QMap<qint64, qint64> &sizes_,
                         const QMap<qint64, MessageFlags> &,
                         const QMap<qint64, MessagePtr> &msgs_) {
                         sizes = sizes_;
                         messages = msgs_;
                     }
```

#### AUTO 


```{c}
auto job = new KIMAP::CreateJob(&session);
```

#### AUTO 


```{c}
const auto &modifiedSpyCatch
```

#### AUTO 


```{c}
const auto keys = annotations.keys();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &entry : keys ) {
            QCOMPARE(getMetadataJob->metaData(mailbox, entry), expectedAnnotations.value(entry));
            QCOMPARE(getMetadataJob->metaData(entry), expectedAnnotations.value(entry));
            QCOMPARE(allMetaData.value(entry), expectedAnnotations.value(entry));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Acl::Rights r : qAsConst(possible)) {
        strList << QString::fromLatin1(Acl::rightsToString(r));
    }
```

#### AUTO 


```{c}
const auto partsKeys = parts.keys();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &part : qAsConst(d->scope.parts)) {
                parameters += "BODY.PEEK[" + part + ".MIME] ";
            }
```

#### AUTO 


```{c}
auto *thread = new QThread();
```

#### RANGE FOR STATEMENT 


```{c}
for (const MailBoxDescriptor &descriptor : qAsConst(d->namespaces)) {
            QString parameters = QStringLiteral("\"\" \"%1\"");

            if (descriptor.name.endsWith(descriptor.separator)) {
                QString name = encodeImapFolderName(descriptor.name);
                name.chop(1);
                d->tags << d->sessionInternal()->sendCommand(d->command,
                        parameters.arg(name).toUtf8());
            }

            d->tags << d->sessionInternal()->sendCommand(d->command,
                    parameters.arg(descriptor.name + QLatin1Char('*')).toUtf8());
        }
```

#### AUTO 


```{c}
auto *job = new KIMAP::ExpungeJob(&session);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &key : keys) {
        job->setField(key, values.value(key));
    }
```

#### AUTO 


```{c}
const auto userNamespaces = namespaces->userNamespaces();
```

#### AUTO 


```{c}
auto login = qobject_cast<KIMAP::LoginJob *>(queue.first());
```

#### AUTO 


```{c}
auto *getmetadata = new GetMetaDataJob(session);
```

#### AUTO 


```{c}
auto job = new KIMAP::FetchJob(&session);
```

#### AUTO 


```{c}
auto socket = new QSslSocket();
```

#### AUTO 


```{c}
auto *deletejob = new DeleteJob(session);
```

#### AUTO 


```{c}
const auto sharedNamespaces = namespaces->sharedNamespaces();
```

#### AUTO 


```{c}
auto job = new KIMAP::CloseJob(&session);
```

#### RANGE FOR STATEMENT 


```{c}
for (Acl::Rights r : std::as_const(possible)) {
        strList << QString::fromLatin1(Acl::rightsToString(r));
    }
```

#### AUTO 


```{c}
auto unsubscribe = new UnsubscribeJob(session);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &attribute : valuesKeys) {
            map.insert(d->addPrefix(entry, attribute), values[attribute]);
        }
```

#### AUTO 


```{c}
auto capabilities = new CapabilitiesJob(&session);
```

#### AUTO 


```{c}
auto *namespaces = new NamespaceJob(&session);
```

#### AUTO 


```{c}
const auto negotiatedEncryption = d->sessionInternal()->negotiatedEncryption();
```

#### AUTO 


```{c}
const auto keys = expectedAnnotations.keys();
```

#### AUTO 


```{c}
auto list = new ListJob(session);
```

#### RANGE FOR STATEMENT 


```{c}
for (const MailBoxDescriptor &descriptor : qAsConst(d->namespaces)) {
            QString parameters = QStringLiteral("\"\" \"%1\"");

            if (descriptor.name.endsWith(descriptor.separator)) {
                QString name = encodeImapFolderName(descriptor.name);
                name.chop(1);
                d->tags << d->sessionInternal()->sendCommand(d->command, parameters.arg(name).toUtf8());
            }

            d->tags << d->sessionInternal()->sendCommand(d->command, parameters.arg(descriptor.name + QLatin1Char('*')).toUtf8());
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, useProxy]() {
            setUseProxyInternal(useProxy);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (int i : {5, 8, 3, 1, 9, 2, 7, 4, 6}) {
                imapSet.add(i);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QSslError &error : errors) {
        qWarning() << "Received ssl error: " << error.errorString();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QList<QByteArray> &scenario : qAsConst(m_scenarios)) {
        if (!scenario.isEmpty()) {
            return false;
        }
    }
```

#### AUTO 


```{c}
auto *job = new KIMAP::CapabilitiesJob(&session);
```

#### AUTO 


```{c}
auto *job = new KIMAP::GetQuotaRootJob(&session);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Part &part : qAsConst(responseCode)) {
                if (part.type() == Part::List) {
                    result += '(';
                    const QList<QByteArray> lstBa = part.toList();
                    for (const QByteArray &item : lstBa) {
                        result += ' ';
                        result += item;
                    }
                    result += " ) ";
                } else {
                    result += part.toString() + ' ';
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this, protocol]() {
        doStartSsl(protocol);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &interval : qAsConst(intervals)) {
        if (!interval.isEmpty()) {
            result.add(ImapInterval::fromImapSequence(interval));
        }
    }
```

#### AUTO 


```{c}
auto job = new KIMAP::SubscribeJob(&session);
```

#### AUTO 


```{c}
auto setMetadataJob = new KIMAP::SetMetaDataJob(&session);
```

#### AUTO 


```{c}
auto *job = new KIMAP::RenameJob(&session);
```

#### AUTO 


```{c}
auto *job = new KIMAP::SelectJob(&session);
```

#### AUTO 


```{c}
const auto content = response.content[3].toList();
```

#### RANGE FOR STATEMENT 


```{c}
for (ImapSet::Id id : {1, 2, 3, 5, 6, 8, 9, 10, 15, 16, 19, 20, 21, 23}) {
                imapSet.add(id);
            }
```

#### AUTO 


```{c}
auto job = new KIMAP::SelectJob(&session);
```

#### AUTO 


```{c}
auto *list = new ListJob(session);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &entry : keys) {
            setMetadataJob->addMetaData(entry, annotations[entry]);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &namespaceItem : namespaceList) {
            ImapStreamParser parser(nullptr);
            parser.setData(namespaceItem);

            try {
                QList<QByteArray> parts = parser.readParenthesizedList();
                if (parts.size() < 2) {
                    continue;
                }
                MailBoxDescriptor descriptor;
                descriptor.name = QString::fromUtf8(decodeImapFolderName(parts[0]));
                descriptor.separator = QLatin1Char(parts[1][0]);

                result << descriptor;
            } catch (const KIMAP::ImapParserException &e) {
                qCWarning(KIMAP_LOG) << "The stream parser raised an exception during namespace list parsing:" << e.what();
                qCWarning(KIMAP_LOG) << "namespacelist:" << namespaceList;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString &,
                         const QMap<qint64, qint64> &,
                         const QMap<qint64, qint64> &,
                         const QMap<qint64, MessageFlags> &flags_,
                         const QMap<qint64, MessagePtr> &) {
                         flags = flags_;
                     }
```

#### RANGE FOR STATEMENT 


```{c}
for (const ImapInterval &interval : qAsConst(d->intervals)) {
        rv << interval.toImapSequence();
    }
```

#### AUTO 


```{c}
auto deletejob = new DeleteJob(session);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &namespaceItem : namespaceList) {
            ImapStreamParser parser(nullptr);
            parser.setData(namespaceItem);

            try {
                QList<QByteArray> parts = parser.readParenthesizedList();
                if (parts.size() < 2) {
                    continue;
                }
                MailBoxDescriptor descriptor;
                descriptor.name = QString::fromUtf8(decodeImapFolderName(parts[0]));
                descriptor.separator = QLatin1Char(parts[1][0]);

                result << descriptor;
            } catch (const KIMAP::ImapParserException &e) {
                qCWarning(KIMAP_LOG) << "The stream parser raised an exception during namespace list parsing:" << e.what();
                qCWarning(KIMAP_LOG) << "namespacelist:" << namespaceList;
            }

        }
```

#### AUTO 


```{c}
auto job = new KIMAP::DeleteJob(&session);
```

#### AUTO 


```{c}
auto it = response.responseCode.cbegin(), end = response.responseCode.cend();
```

#### AUTO 


```{c}
const auto name = *it;
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString &, const QMap<qint64, qint64> &, const QMap<qint64, MessageParts> &parts_) {
                         allParts = parts_;
                     }
```

#### AUTO 


```{c}
auto *subscribe = new SubscribeJob(session);
```

#### AUTO 


```{c}
auto next = std::next(it);
```

#### AUTO 


```{c}
auto *select = new SelectJob(&session);
```

#### AUTO 


```{c}
auto thread = new QThread();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { emitPendings(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SearchCriteriaValuePair &pair : std::as_const(searchCriteria)) {
            if (pair.second.isEmpty()) {
                job->addSearchCriteria(pair.first);
            } else {
                job->addSearchCriteria(pair.first, pair.second);
            }
        }
```

#### AUTO 


```{c}
auto it = d->intervals.begin();
```

#### AUTO 


```{c}
auto logout = new KIMAP::LogoutJob(session);
```

#### AUTO 


```{c}
auto session = new KIMAP::Session(QStringLiteral("127.0.0.1"), 5989);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &e : keys) {
            QCOMPARE(getMetadataJob->metaData(e), expectedAnnotations.value(e));
            QCOMPARE(allMetaData.value(e), expectedAnnotations.value(e));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (MailBoxDescriptor ns : sharedNamespaces) {
        qDebug() << ns.separator << ns.name;
    }
```

#### AUTO 


```{c}
auto idle = new IdleJob(&session);
```

#### RANGE FOR STATEMENT 


```{c}
for (const ImapInterval &interval : std::as_const(d->intervals)) {
        rv << interval.toImapSequence();
    }
```

#### AUTO 


```{c}
auto job = new KIMAP::UnsubscribeJob(&session);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Part &part : std::as_const(responseCode)) {
                if (part.type() == Part::List) {
                    result += '(';
                    const QList<QByteArray> lstBa = part.toList();
                    for (const QByteArray &item : lstBa) {
                        result += ' ';
                        result += item;
                    }
                    result += " ) ";
                } else {
                    result += part.toString() + ' ';
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &modifiedSpyCatch : modifiedSpy) {
                    const auto msgs = modifiedSpyCatch.at(0).value<Messages>();
                    for (auto it = msgs.begin(); it != msgs.end(); ++it) {
                        collectedModified.insert(it.key(), it.value());
                    }
                }
```

#### AUTO 


```{c}
auto *job = new KIMAP::CloseJob(&session);
```

#### AUTO 


```{c}
auto *job = new KIMAP::CreateJob(&session);
```

#### AUTO 


```{c}
auto *job = new KIMAP::FetchJob(&session);
```

#### AUTO 


```{c}
const auto vanishedSet = ImapSet::fromImapSequenceSet(response.content[3].toString());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &entry : keys) {
            if (legacyMode) {
                setMetadataJob->setEntry(entry);
                setMetadataJob->addMetaData("value.shared", annotations[entry]);
            } else {
                setMetadataJob->addMetaData(QByteArray("/shared") + entry, annotations[entry]);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &part : std::as_const(d->scope.parts)) {
                parameters += " BODY.PEEK[" + part + ".MIME] BODY.PEEK[" + part + "]"; // krazy:exclude=doublequote_chars
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this, useProxy]() { setUseProxyInternal(useProxy); }
```

#### AUTO 


```{c}
auto *job = new KIMAP::SubscribeJob(&session);
```

#### AUTO 


```{c}
const auto sortedEntries = sort(d->entries);
```

#### LAMBDA EXPRESSION 


```{c}
[this, protocol]() { doStartSsl(protocol); }
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString &, const QMap<qint64,qint64> &,
                                const QMap<qint64, qint64> &,
                                const QMap<qint64, MessageFlags> &flags_,
                                const QMap<qint64, MessagePtr> &) {
                         flags = flags_;
                     }
```

#### AUTO 


```{c}
auto *job = new KIMAP::StatusJob(&session);
```

#### AUTO 


```{c}
const auto allkeys = allParts.keys();
```

#### AUTO 


```{c}
auto *logout = new KIMAP::LogoutJob(session);
```

#### AUTO 


```{c}
auto job = new KIMAP::IdJob(&session);
```

#### AUTO 


```{c}
const auto flags = str.split(' ');
```

#### AUTO 


```{c}
auto job = new KIMAP::AppendJob(&session);
```

#### AUTO 


```{c}
auto *rename = new RenameJob(session);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &part : qAsConst(d->scope.parts)) {
                parameters += " BODY.PEEK[" + part + ".MIME] BODY.PEEK[" + part + "]"; //krazy:exclude=doublequote_chars
            }
```

#### AUTO 


```{c}
const auto parsKeys = parts.keys();
```

#### AUTO 


```{c}
auto listRights = new ListRightsJob(session);
```

#### AUTO 


```{c}
auto subscribe = new SubscribeJob(session);
```

#### RANGE FOR STATEMENT 


```{c}
for (const ImapInterval &interval : std::as_const(d->intervals)) {
        if (!other.d->intervals.contains(interval)) {
            return false;
        }
    }
```

#### AUTO 


```{c}
auto store = new StoreJob(session);
```

#### AUTO 


```{c}
auto logout = new LogoutJob(&session);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &item : lstBa ) {
                    result += ' ';
                    result += item;
                }
```

#### AUTO 


```{c}
auto job = new KIMAP::EnableJob(&session);
```

