#### LAMBDA EXPRESSION 


```{c}
[this]() { m_graph3d->resetView(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { m_graph3d->resetViewport(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this, o](){
        page()->runJavaScript(QStringLiteral("window.scrollTo(0, document.body.scrollHeight);"));
        delete o;
    }
```

#### AUTO 


```{c}
const auto uri = "org.kde.kalgebra.mobile";
```

#### AUTO 


```{c}
auto log = m_model->htmlLog();
```

#### AUTO 


```{c}
const auto result = res.toHtml();
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool ok){
        if (!ok) {
            qWarning() << "error loading page" << url();
        }
        page()->runJavaScript(QStringLiteral("window.scrollTo(0, document.body.scrollHeight);"));
    }
```

#### AUTO 


```{c}
const auto newEntry = log.takeLast();
```

#### AUTO 


```{c}
auto px = m_graph3d->grabFramebuffer();
```

