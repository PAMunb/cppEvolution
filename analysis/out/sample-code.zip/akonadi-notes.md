#### RANGE FOR STATEMENT 


```{c}
for (KMime::Content *c : list) {
        if (KMime::Headers::Base *typeHeader = c->headerByType(X_NOTES_CONTENTTYPE_HEADER)) {
            const QString &type = typeHeader->asUnicodeString();
            if (type == CONTENT_TYPE_CUSTOM) {
                parseCustomPart(c);
            } else if (type == CONTENT_TYPE_ATTACHMENT) {
                parseAttachmentPart(c);
            } else {
                qCWarning(AKONADINOTES_LOG) << "unknown type " << type;
            }
        }
    }
```

#### AUTO 


```{c}
auto header = new KMime::Headers::Generic(X_NOTES_LASTMODIFIED_HEADER);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Attachment &a : qAsConst(d->attachments)) {
        msg->addContent(d->createAttachmentPart(a));
    }
```

#### AUTO 


```{c}
auto header = new KMime::Headers::Generic(X_NOTES_CONTENTTYPE_HEADER);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Attachment &a : std::as_const(d->attachments)) {
        msg->addContent(d->createAttachmentPart(a));
    }
```

#### AUTO 


```{c}
const auto list = msg->contents();
```

#### AUTO 


```{c}
auto content = new KMime::Content();
```

