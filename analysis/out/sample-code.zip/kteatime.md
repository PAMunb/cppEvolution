#### AUTO 


```{c}
const auto actions = m_teaActionGroup->actions();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Tea &t : std::as_const(m_tealist)) {
        QAction *a = contextMenu()->addAction(
                   i18nc( "%1 - name of the tea, %2 - the predefined time for "
                          "the tea", "%1 (%2)", t.name(), t.timeToString() )
                     );

        a->setData( ++i );
        m_teaActionGroup->addAction( a );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : indexes) {
        // Only delete a row when column==0, otherwise the row will be delete
        // multiple times (the loop iterate over every cell, not over rows).
        if( index.column() == 0 ) {
            m_model->removeRows( index.row(), 1 );
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Tea &t : qAsConst(m_tealist)) {
        QAction *a = contextMenu()->addAction(
                   i18nc( "%1 - name of the tea, %2 - the predefined time for "
                          "the tea", "%1 (%2)", t.name(), t.timeToString() )
                     );

        a->setData( ++i );
        m_teaActionGroup->addAction( a );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( QAction* a : actions ) {
        m_teaActionGroup->removeAction( a );
    }
```

