#### RANGE FOR STATEMENT 


```{c}
for ( const Pos& d : qAsConst(knightDirs) ) {
			if ( Board::isInBoard ( pos + d ) )
				moves << Move ( pos, pos + d );
		}
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString& text : possibilities ) {
			Move m ( text );
			checkSpecialFlags ( &m, color );
			if ( m.isValid() ) {
				move->setString ( text );
				break;
			}
		}
```

#### RANGE FOR STATEMENT 


```{c}
for ( const Move& move : qAsConst(mMoveHistory) ) {
			QString moveString = QLatin1Char(' ') + move.from().string() + move.to().string();
			if ( move.promotedType() )
				moveString += Piece::charFromType ( move.promotedType() ).toLower();
			str += moveString;
		}
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString& s : Settings::engineConfigurations() ) {
		addClicked();
		EngineConfiguration c = EngineConfiguration ( s );
		ui->tableWidget->setItem ( row, NameColumn, new QTableWidgetItem ( c.name ) );
		ui->tableWidget->setItem ( row, CommandColumn, new QTableWidgetItem ( c.commandLine ) );
		qobject_cast<KComboBox*> ( ui->tableWidget->cellWidget ( row, ProtocolColumn ) )->setCurrentIndex ( (int)c.iface );
		checkInstalled(row, c.commandLine);
		++row;
	}
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString& newLine : all.split( QLatin1Char('\n') ) ) {
				const QString text = line + newLine.trimmed();
				if ( !parseStub(text) && !parseLine(text) )
					line = text;
			}
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& data : list) {
		switch(data.type) {
		case Protocol::ConsoleToolWidget:
			if(data.owner == White) {
				m_wconsoleDock->setWindowTitle(data.title);
				m_wconsoleDock->setWidget(data.widget);
				actionCollection()->action(QStringLiteral("show_console_white"))->setVisible(true);
				if(Settings::showConsole()) {
					m_wconsoleDock->setVisible(true);
					actionCollection()->action(QStringLiteral("show_console_white"))->setChecked(true);
				} else {
					m_wconsoleDock->setVisible(false);
					actionCollection()->action(QStringLiteral("show_console_white"))->setChecked(false);
				}
			} else {
				m_bconsoleDock->setWindowTitle(data.title);
				m_bconsoleDock->setWidget(data.widget);
				actionCollection()->action(QStringLiteral("show_console_black"))->setVisible(true);
				if(Settings::showConsole()) {
					m_bconsoleDock->setVisible(true);
					actionCollection()->action(QStringLiteral("show_console_black"))->setChecked(true);
				} else {
					m_bconsoleDock->setVisible(false);
					actionCollection()->action(QStringLiteral("show_console_black"))->setChecked(false);
				}
			}
			break;

		case Protocol::ChatToolWidget:
			m_chatDock->setWindowTitle(data.title);
			m_chatDock->setWidget(data.widget);
			actionCollection()->action(QStringLiteral("show_chat"))->setVisible(true);
			if(Settings::showChat()) {
				m_chatDock->setVisible(true);
				actionCollection()->action(QStringLiteral("show_chat"))->setChecked(true);
			} else {
				m_chatDock->setVisible(false);
				actionCollection()->action(QStringLiteral("show_chat"))->setChecked(false);
			}
			break;

		default:
			break;
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for ( Item* i : qAsConst(markers) )
		centerOnPos ( i );
```

#### RANGE FOR STATEMENT 


```{c}
for ( Piece* piece : qAsConst(m_grid) ) {
					if ( piece->color() != m_currentPlayer && piece->pieceType() == King )
						addMarker ( piece->boardPos(), Danger );
				}
```

#### RANGE FOR STATEMENT 


```{c}
for ( const Move& m : qAsConst(moves) ) {
		Grid t_grid = *m_grid;
		t_grid.insert ( m.to(), t_grid.take ( pos ) );
		if ( ( isKingMoving && isAttacked ( m.to(), color, &t_grid ) ) || ( !isKingMoving && isAttacked ( currKingPos, color, &t_grid ) ) ) {
			moves.removeOne ( m );
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (KPlotObject* o : plotObjects()) {
		if ( o->points().isEmpty() )
			continue;
		QPointF d = mapToWidget ( o->points().first()->position()) - event->pos() + QPoint(leftPadding(), topPadding());
		if ( d.x() * d.x() + d.y() * d.y() < 64.0 ) {
			isOverPoint = true;
			break;
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QByteArray& str : line.trimmed().split(' ') ) {
				if ( !str.trimmed().isEmpty() && !str.contains('.') && !str.contains("1-0") && !str.contains("0-1") && !str.contains("1/2-1/2") && !str.contains('*') ) {
					// Only move numbers contain dots, not move data itself
					// We also exclude the game termination markers (results)
					qCDebug(LOG_KNIGHTS) << "Read move" << str;
					Move m;
					if (str.contains("O-O-O") || str.contains("o-o-o") || str.contains("0-0-0"))
						m = Move::castling(Move::QueenSide, activePlayer());
					else if (str.contains("O-O") || str.contains("o-o") || str.contains("0-0"))
						m = Move::castling(Move::KingSide, activePlayer());
					else
						m = Move ( QLatin1String(str) );
					m.setFlag ( Move::Forced, true );
					processMove ( m );
				}
			}
```

#### RANGE FOR STATEMENT 


```{c}
for ( const Pos& d : lineDirs )
			moves << movesInDirection ( d, pos, 8, true, grid );
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& data : list) {
		switch(data.type) {
		case Protocol::ConsoleToolWidget:
			if(data.owner == White) {
				m_wconsoleDock->setWindowTitle(data.title);
				m_wconsoleDock->setWidget(data.widget);
				actionCollection()->action(QLatin1String("show_console_white"))->setVisible(true);
				if(Settings::showConsole()) {
					m_wconsoleDock->setVisible(true);
					actionCollection()->action(QLatin1String("show_console_white"))->setChecked(true);
				} else {
					m_wconsoleDock->setVisible(false);
					actionCollection()->action(QLatin1String("show_console_white"))->setChecked(false);
				}
			} else {
				m_bconsoleDock->setWindowTitle(data.title);
				m_bconsoleDock->setWidget(data.widget);
				actionCollection()->action(QLatin1String("show_console_black"))->setVisible(true);
				if(Settings::showConsole()) {
					m_bconsoleDock->setVisible(true);
					actionCollection()->action(QLatin1String("show_console_black"))->setChecked(true);
				} else {
					m_bconsoleDock->setVisible(false);
					actionCollection()->action(QLatin1String("show_console_black"))->setChecked(false);
				}
			}
			break;

		case Protocol::ChatToolWidget:
			m_chatDock->setWindowTitle(data.title);
			m_chatDock->setWidget(data.widget);
			actionCollection()->action(QLatin1String("show_chat"))->setVisible(true);
			if(Settings::showChat()) {
				m_chatDock->setVisible(true);
				actionCollection()->action(QLatin1String("show_chat"))->setChecked(true);
			} else {
				m_chatDock->setVisible(false);
				actionCollection()->action(QLatin1String("show_chat"))->setChecked(false);
			}
			break;

		default:
			break;
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& s : Settings::engineConfigurations()) {
		const  QStringList l = s.split(QLatin1Char(':'), Qt::SkipEmptyParts);
		EngineConfiguration e = EngineConfiguration(s);
		if(!e.name.isEmpty()) {
			programs << e.name;
			configs << e;
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& s : Settings::engineConfigurations()) {
#if QT_VERSION < QT_VERSION_CHECK(5, 15, 0)
		const  QStringList l = s.split(QLatin1Char(':'), QString::SkipEmptyParts);
#else
		const  QStringList l = s.split(QLatin1Char(':'), Qt::SkipEmptyParts);
#endif
		EngineConfiguration e = EngineConfiguration(s);
		if(!e.name.isEmpty()) {
			programs << e.name;
			configs << e;
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for ( Item* t : qAsConst(m_tiles) )
		centerAndResize ( t, tSize, Settings::animateBoard() );
```

#### RANGE FOR STATEMENT 


```{c}
for ( const Pos& d : directions ) {
			for ( const Move& m : movesInDirection ( d, pos, 1 ) )
				moves << m;
		}
```

#### RANGE FOR STATEMENT 


```{c}
for ( Item* item : m_borders )
			item->setZValue ( borderZValue );
```

#### RANGE FOR STATEMENT 


```{c}
for ( const Pos& d : qAsConst(lineDirs) )
			moves << movesInDirection ( d, pos );
```

#### AUTO 


```{c}
auto* dirs
```

#### RANGE FOR STATEMENT 


```{c}
for ( const Move& m : moves ) {
		Grid t_grid = *m_grid;
		t_grid.insert ( m.to(), t_grid.take ( pos ) );
		if ( ( isKingMoving && isAttacked ( m.to(), color, &t_grid ) ) || ( !isKingMoving && isAttacked ( currKingPos, color, &t_grid ) ) ) {
			moves.removeOne ( m );
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString& str : line.split( QLatin1Char(' ') ) ) {
				bool ok;
				int id = str.toInt(&ok);
				if ( ok )
					Q_EMIT challengeRemoved(id);
			}
```

#### RANGE FOR STATEMENT 


```{c}
for ( Piece* p : m_grid )
		centerOnPos ( p );
```

#### RANGE FOR STATEMENT 


```{c}
for ( const Move& m : qAsConst(m_enPassantMoves) ) {
			if ( m.from() == pos )
				moves << m;
		}
```

#### RANGE FOR STATEMENT 


```{c}
for ( const Move& move : Manager::self()->moveHistory() ) {
		if ( move.pieceData() == data )
			return true;
	}
```

#### RANGE FOR STATEMENT 


```{c}
for ( Item* t : m_tiles )
		centerAndResize ( t, tSize, Settings::animateBoard() );
```

#### RANGE FOR STATEMENT 


```{c}
for ( const Move& m : m_enPassantMoves ) {
			if ( m.from() == pos )
				moves << m;
		}
```

#### RANGE FOR STATEMENT 


```{c}
for ( const Pos& d : qAsConst(knightDirs) ) {
			if ( !Board::isInBoard ( pos + d ) )
				continue;
			if ( !m_grid->contains ( pos + d ) )
				moves << Move ( pos, pos + d );
			else if ( m_grid->value ( pos + d )->color() != color )
				moves << Move ( pos, pos + d, Move::Take );
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (const Move& move : list) {
		Move m = move;
		m.setFlag(Move::Additional, true);
		d->extraMoves << m;
	}
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString& str : line.split(QLatin1Char(' ') ) ) {
				bool ok;
				int id = str.toInt(&ok);
				if ( ok )
					emit gameOfferRemoved(id);
			}
```

#### RANGE FOR STATEMENT 


```{c}
for ( const Move& t_move : qAsConst(t_legalMoves) )
					addMarker ( t_move.to(), LegalMove );
```

#### AUTO 


```{c}
auto bBox = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel);
```

#### RANGE FOR STATEMENT 


```{c}
for ( const Pos& d : qAsConst(directions) )
			moves << movesInDirection ( d, pos );
```

#### RANGE FOR STATEMENT 


```{c}
for ( const Move& move : mMoveHistory ) {
			QString moveString = QLatin1Char(' ') + move.from().string() + move.to().string();
			if ( move.promotedType() )
				moveString += Piece::charFromType ( move.promotedType() ).toLower();
			str += moveString;
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (KPlotObject* o : plotObjects()) {
		if ( o->points().isEmpty() )
			continue;
		QPointF d = mapToWidget ( o->points().first()->position()) - event->pos() + QPoint(leftPadding(), topPadding());
		if ( d.x() * d.x() + d.y() * d.y() < 64.0 ) {
			Q_EMIT seekClicked ( m_objects.key(o) );
			return;
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for ( Item* item : qAsConst(m_borders) )
			item->setZValue ( borderZValue );
```

#### RANGE FOR STATEMENT 


```{c}
for ( Piece* piece : qAsConst(m_grid) ) {
				if ( piece->color() == m_currentPlayer && Manager::self()->rules()->isAttacking ( piece->boardPos() ) ) {
					check = true;
					addMarker ( piece->boardPos(), Danger );
				}
			}
```

#### RANGE FOR STATEMENT 


```{c}
for (KPlotObject *po : plotObjects())
		po->draw( &p, this );
```

#### LAMBDA EXPRESSION 


```{c}
[=] () {
		//the current player has changed within one second,
		//don't need to show the notification
		if (Manager::self()->activePlayer() != color)
			return;

		QString name;
		if (color == White)
			name = Protocol::white()->playerName();
		else
			name = Protocol::black()->playerName();
		statusBar()->showMessage(i18n("%1 is thinking...", name));
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (auto* dirs : dirs) {
		for (auto it = dirs->begin(), end = dirs->end(); it != end; ++it) {
			directions.insert(it.key(), it.value());
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for ( const Pos& captureDir : captureDirections ) {
		if ( m_grid->contains ( pos + captureDir ) && m_grid->value ( pos + captureDir )->color() != m_grid->value ( pos )->color() )
			list << Move ( pos, pos + captureDir, Move::Take );
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (OfferWidget* widget : qAsConst(m_offerWidgets)) {
		layout->removeWidget ( widget );
		widget->hide();
	}
```

#### AUTO 


```{c}
auto bBox = new QDialogButtonBox ( QDialogButtonBox::Ok | QDialogButtonBox::Cancel );
```

#### RANGE FOR STATEMENT 


```{c}
for ( const Move& m : movesInDirection ( d, pos, 1 ) )
				moves << m;
```

#### RANGE FOR STATEMENT 


```{c}
for (const Move& m : d->extraMoves)
		additionalMoves << m.reverse();
```

#### RANGE FOR STATEMENT 


```{c}
for ( Item* i : m_tiles )
			centerOnPos ( i );
```

#### RANGE FOR STATEMENT 


```{c}
for ( Direction dir : qAsConst(dirs) )
				if ( m_grid->contains ( m.to() + directions[dir] ) ) {
					Move enPassantMove;
					enPassantMove.setFrom ( m.to() + directions[dir] );
					enPassantMove.setTo ( mid );
					enPassantMove.setFlag ( Move::EnPassant, true );
					m_enPassantMoves << enPassantMove;
				}
```

#### AUTO 


```{c}
auto bBox = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel );
```

#### RANGE FOR STATEMENT 


```{c}
for ( const Pos& d : directions )
			moves << movesInDirection ( d, pos, 1, true, grid );
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString& text : qAsConst(possibilities) ) {
			Move m ( text );
			checkSpecialFlags ( &m, color );
			if ( m.isValid() ) {
				move->setString ( text );
				break;
			}
		}
```

#### RANGE FOR STATEMENT 


```{c}
for ( const Move& t_move : t_legalMoves )
				addMarker ( t_move.to(), LegalMove );
```

#### RANGE FOR STATEMENT 


```{c}
for ( const Pos& d : diagDirs )
			moves << movesInDirection ( d, pos, 8, true, grid );
```

#### RANGE FOR STATEMENT 


```{c}
for ( Item* item : qAsConst(m_notations) )
			item->setZValue ( notationZValue );
```

#### RANGE FOR STATEMENT 


```{c}
for (OfferWidget* widget : qAsConst(m_offerWidgets)) {
		if ( widget->id() == id )
			m_offerWidgets.removeAll(widget);
	}
```

#### RANGE FOR STATEMENT 


```{c}
for ( const Pos& d : directions )
			moves << movesInDirection ( d, pos );
```

#### RANGE FOR STATEMENT 


```{c}
for ( Direction dir : dirs )
				if ( m_grid->contains ( m.to() + directions[dir] ) ) {
					Move enPassantMove;
					enPassantMove.setFrom ( m.to() + directions[dir] );
					enPassantMove.setTo ( mid );
					enPassantMove.setFlag ( Move::EnPassant, true );
					m_enPassantMoves << enPassantMove;
				}
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& data : qAsConst(list)) {
		switch(data.type) {
		case Protocol::ConsoleToolWidget:
			if(data.owner == White) {
				m_wconsoleDock->setWindowTitle(data.title);
				m_wconsoleDock->setWidget(data.widget);
				actionCollection()->action(QStringLiteral("show_console_white"))->setVisible(true);
				if(Settings::showConsole()) {
					m_wconsoleDock->setVisible(true);
					actionCollection()->action(QStringLiteral("show_console_white"))->setChecked(true);
				} else {
					m_wconsoleDock->setVisible(false);
					actionCollection()->action(QStringLiteral("show_console_white"))->setChecked(false);
				}
			} else {
				m_bconsoleDock->setWindowTitle(data.title);
				m_bconsoleDock->setWidget(data.widget);
				actionCollection()->action(QStringLiteral("show_console_black"))->setVisible(true);
				if(Settings::showConsole()) {
					m_bconsoleDock->setVisible(true);
					actionCollection()->action(QStringLiteral("show_console_black"))->setChecked(true);
				} else {
					m_bconsoleDock->setVisible(false);
					actionCollection()->action(QStringLiteral("show_console_black"))->setChecked(false);
				}
			}
			break;

		case Protocol::ChatToolWidget:
			m_chatDock->setWindowTitle(data.title);
			m_chatDock->setWidget(data.widget);
			actionCollection()->action(QStringLiteral("show_chat"))->setVisible(true);
			if(Settings::showChat()) {
				m_chatDock->setVisible(true);
				actionCollection()->action(QStringLiteral("show_chat"))->setChecked(true);
			} else {
				m_chatDock->setVisible(false);
				actionCollection()->action(QStringLiteral("show_chat"))->setChecked(false);
			}
			break;

		default:
			break;
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for ( const ChatWidget::Message& message : qAsConst(messages) )
		m_console->addText ( message );
```

#### RANGE FOR STATEMENT 


```{c}
for ( const Pos& d : qAsConst(lineDirs) )
			moves << movesInDirection ( d, pos, 8, true, grid );
```

#### RANGE FOR STATEMENT 


```{c}
for ( const Pos& d : knightDirs ) {
			if ( !Board::isInBoard ( pos + d ) )
				continue;
			if ( !m_grid->contains ( pos + d ) )
				moves << Move ( pos, pos + d );
			else if ( m_grid->value ( pos + d )->color() != color )
				moves << Move ( pos, pos + d, Move::Take );
		}
```

#### RANGE FOR STATEMENT 


```{c}
for ( const Move& m : moves ) {
		Grid t_grid = *m_grid;
		t_grid.insert ( m.to(), t_grid.take ( pos ) );
		if ( ( isKingMoving && isAttacked ( m.to(), color, &t_grid ) ) || ( !isKingMoving && isAttacked ( kingPos[color], color, &t_grid ) ) )
			moves.removeAll ( m );
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (OfferWidget* widget : m_offerWidgets) {
		layout->removeWidget ( widget );
		widget->hide();
	}
```

#### RANGE FOR STATEMENT 


```{c}
for ( const Pos& d : knightDirs ) {
			if ( Board::isInBoard ( pos + d ) )
				moves << Move ( pos, pos + d );
		}
```

#### RANGE FOR STATEMENT 


```{c}
for ( Item* t : markers )
		centerAndResize ( t, tSize );
```

#### RANGE FOR STATEMENT 


```{c}
for ( Piece* piece : m_grid ) {
					if ( piece->color() != m_currentPlayer && piece->pieceType() == King )
						addMarker ( piece->boardPos(), Danger );
				}
```

#### RANGE FOR STATEMENT 


```{c}
for ( const ChatWidget::Message& message : messages )
		m_console->addText ( message );
```

#### AUTO 


```{c}
const auto& data
```

#### RANGE FOR STATEMENT 


```{c}
for (OfferWidget* widget : m_offerWidgets) {
		if ( widget->id() == id )
			m_offerWidgets.removeAll(widget);
	}
```

#### RANGE FOR STATEMENT 


```{c}
for ( Piece* p : qAsConst(m_grid) )
		centerOnPos ( p );
```

#### RANGE FOR STATEMENT 


```{c}
for ( Item* i : markers )
		centerOnPos ( i );
```

#### AUTO 


```{c}
auto it = dirs->begin(), end = dirs->end();
```

#### AUTO 


```{c}
auto mainLayout = new QVBoxLayout(dialog);
```

#### RANGE FOR STATEMENT 


```{c}
for (KPlotObject* o : plotObjects()) {
		if ( o->points().isEmpty() )
			continue;
		QPointF d = mapToWidget ( o->points().first()->position()) - event->pos() + QPoint(leftPadding(), topPadding());
		if ( d.x() * d.x() + d.y() * d.y() < 64.0 ) {
			emit seekClicked ( m_objects.key(o) );
			return;
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for ( const Pos& d : lineDirs )
			moves << movesInDirection ( d, pos );
```

#### AUTO 


```{c}
auto it = attributes.constBegin(), end = attributes.constEnd();
```

#### RANGE FOR STATEMENT 


```{c}
for ( const Pos& d : diagDirs )
			moves << movesInDirection ( d, pos );
```

#### RANGE FOR STATEMENT 


```{c}
for ( const Pos& d : qAsConst(directions) )
			moves << movesInDirection ( d, pos, 8, true, grid );
```

#### RANGE FOR STATEMENT 


```{c}
for ( const Pos& d : qAsConst(diagDirs) )
			moves << movesInDirection ( d, pos, 8, true, grid );
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& s : Settings::engineConfigurations())
		configs << EngineConfiguration(s);
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString& str : line.split( QLatin1Char(' ') ) ) {
				bool ok;
				int id = str.toInt(&ok);
				if ( ok )
					emit challengeRemoved(id);
			}
```

#### RANGE FOR STATEMENT 


```{c}
for ( Item* i : qAsConst(m_tiles) )
			centerOnPos ( i );
```

#### RANGE FOR STATEMENT 


```{c}
for ( Direction dir : QList<Direction>() << W << E )
				if ( m_grid->contains ( m.to() + directions[dir] ) ) {
					Move enPassantMove;
					enPassantMove.setFrom ( m.to() + directions[dir] );
					enPassantMove.setTo ( mid );
					enPassantMove.setFlag ( Move::EnPassant, true );
					m_enPassantMoves << enPassantMove;
				}
```

#### RANGE FOR STATEMENT 


```{c}
for ( const Move& t_move : t_legalMoves )
					addMarker ( t_move.to(), LegalMove );
```

#### RANGE FOR STATEMENT 


```{c}
for ( const Pos& captureDir : qAsConst(captureDirections) ) {
		if ( m_grid->contains ( pos + captureDir ) && m_grid->value ( pos + captureDir )->color() != m_grid->value ( pos )->color() )
			list << Move ( pos, pos + captureDir, Move::Take );
	}
```

#### RANGE FOR STATEMENT 


```{c}
for ( Item* item : m_notations )
			item->setZValue ( notationZValue );
```

#### RANGE FOR STATEMENT 


```{c}
for ( const Pos& d : qAsConst(directions) )
			moves << movesInDirection ( d, pos, 1, true, grid );
```

#### RANGE FOR STATEMENT 


```{c}
for ( Piece* p : m_grid )
		centerAndResize ( p, tSize );
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& s : Settings::engineConfigurations()) {
		const  QStringList l = s.split(QLatin1Char(':'), QString::SkipEmptyParts);
		EngineConfiguration e = EngineConfiguration(s);
		if(!e.name.isEmpty()) {
			programs << e.name;
			configs << e;
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for ( const Move& additionalMove : m.additionalMoves() )
		movePiece ( additionalMove );
```

#### RANGE FOR STATEMENT 


```{c}
for ( Piece* piece : m_grid ) {
				if ( piece->color() == m_currentPlayer && Manager::self()->rules()->isAttacking ( piece->boardPos() ) ) {
					check = true;
					addMarker ( piece->boardPos(), Danger );
				}
			}
```

#### RANGE FOR STATEMENT 


```{c}
for ( const Move& move : Manager::self()->moveHistory() ) {
		if ( move.pieceData() == data && move.from() == rookPos )
			return true;
	}
```

#### RANGE FOR STATEMENT 


```{c}
for ( Item* t : qAsConst(markers) )
		centerAndResize ( t, tSize );
```

#### RANGE FOR STATEMENT 


```{c}
for ( const Pos& d : directions )
			moves << movesInDirection ( d, pos, 8, true, grid );
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString& str : line.split(QLatin1Char(' ') ) ) {
				bool ok;
				int id = str.toInt(&ok);
				if ( ok )
					Q_EMIT gameOfferRemoved(id);
			}
```

#### RANGE FOR STATEMENT 


```{c}
for ( const Pos& d : qAsConst(directions) ) {
			for ( const Move& m : movesInDirection ( d, pos, 1 ) )
				moves << m;
		}
```

#### RANGE FOR STATEMENT 


```{c}
for ( Piece* p : qAsConst(m_grid) )
		centerAndResize ( p, tSize );
```

#### RANGE FOR STATEMENT 


```{c}
for ( const Pos& d : qAsConst(diagDirs) )
			moves << movesInDirection ( d, pos );
```

