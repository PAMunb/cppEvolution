#### RANGE FOR STATEMENT 


```{c}
for (QGraphicsItem* item : bonds)
    {
        dynamic_cast<KGameRenderedItem*>(item)->setRenderSize(renderSize);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( AtomFieldItem* atom : std::as_const(m_atoms) )
    {
        uint atomNum = atom->atomNum();
        int molecCoordX = atom->fieldX() - minX;
        int molecCoordY = atom->fieldY() - minY;
        if( m_levelData->molecule()->getAtom( molecCoordX, molecCoordY ) != atomNum )
            return false; // nope. not there
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( AtomFieldItem* atom : qAsConst(m_atoms) )
    {
        uint atomNum = atom->atomNum();
        int molecCoordX = atom->fieldX() - minX;
        int molecCoordY = atom->fieldY() - minY;
        if( m_levelData->molecule()->getAtom( molecCoordX, molecCoordY ) != atomNum )
            return false; // nope. not there
    }
```

#### AUTO 


```{c}
const auto atomElements = m_levelData->atomElements();
```

#### RANGE FOR STATEMENT 


```{c}
for ( AtomFieldItem* atom : qAsConst(m_atoms) )
        atom->setPos( toPixX(atom->fieldX()), toPixY(atom->fieldY()));
```

#### RANGE FOR STATEMENT 


```{c}
for ( AtomFieldItem * atom : qAsConst(m_atoms) )
        atom->setPos( toPixX(atom->fieldX()), toPixY(atom->fieldY()));
```

#### RANGE FOR STATEMENT 


```{c}
for ( AtomFieldItem *atom : std::as_const(m_atoms) )
    {
        if( atom->fieldX() == x && atom->fieldY() == y )
            return false;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& dir : dirs) {
        const QStringList fileNames = QDir(dir).entryList(QStringList() << QStringLiteral("*.dat"));
        for (const QString& file : fileNames) {
            fileList.append(dir + QLatin1Char('/') + file);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( AtomFieldItem *item : std::as_const(m_atoms) )
    {
        item->setRenderSize( QSize(m_elemSize, m_elemSize) );

        // this may be true if resize happens during animation
        if( isAnimating() && m_selIdx != -1 && item == m_atoms.at(m_selIdx) )
            continue; // its position will be taken care of in atomAnimFrameChanged()

        item->setPos( toPixX( item->fieldX() ), toPixY( item->fieldY() ) );
        item->show();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& fileName : fileList)
    {
        ls.loadFromFile(fileName);
        QString visibleName = ls.visibleName();
        if (!visibleName.isEmpty())
        {
            QListWidgetItem* item = new QListWidgetItem;
            item->setIcon(QIcon::fromTheme( QStringLiteral( "katomic" )));
            item->setText(visibleName);
            item->setData(KAtomic::LevelSetNameRole, ls.name());
            item->setData(KAtomic::LevelSetDescriptionRole, ls.description());
            item->setData(KAtomic::LevelSetAuthorRole, ls.author());
            item->setData(KAtomic::LevelSetAuthorEmailRole, ls.authorEmail());
            item->setData(KAtomic::LevelSetLevelCountRole, ls.levelCount());
            m_ui.m_lwLevelSets->addItem(item);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( AtomFieldItem* atom : qAsConst(m_atoms) )
    {
        if(atom->fieldX() < minX)
            minX = atom->fieldX();
        if(atom->fieldY() < minY)
            minY = atom->fieldY();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& file : fileNames) {
            fileList.append(dir + QLatin1Char('/') + file);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Element& el : elements)
    {
        if (el.atom == -1)
        {
            m_field[el.x][el.y] = true; // a wall
        }
        else
        {
            m_atoms.append(el);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const LevelData::Element& element : atomElements)
    {
        AtomFieldItem* atom = new AtomFieldItem(&m_renderer, m_levelData->molecule()->getAtom(element.atom), this);
        atom->setFieldXY(element.x, element.y);
        atom->setAtomNum(element.atom);
        m_atoms.append(atom);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( AtomFieldItem *atom : qAsConst(m_atoms) )
    {
        if( atom->fieldX() == x && atom->fieldY() == y )
            return false;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( AtomFieldItem * atom : std::as_const(m_atoms) )
        atom->setPos( toPixX(atom->fieldX()), toPixY(atom->fieldY()));
```

#### RANGE FOR STATEMENT 


```{c}
for ( AtomFieldItem *item : qAsConst(m_atoms) )
    {
        item->setRenderSize( QSize(m_elemSize, m_elemSize) );

        // this may be true if resize happens during animation
        if( isAnimating() && m_selIdx != -1 && item == m_atoms.at(m_selIdx) )
            continue; // its position will be taken care of in atomAnimFrameChanged()

        item->setPos( toPixX( item->fieldX() ), toPixY( item->fieldY() ) );
        item->show();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( AtomFieldItem* atom : std::as_const(m_atoms) )
        atom->setPos( toPixX(atom->fieldX()), toPixY(atom->fieldY()));
```

#### RANGE FOR STATEMENT 


```{c}
for ( AtomFieldItem* atom : std::as_const(m_atoms) )
    {
        if(atom->fieldX() < minX)
            minX = atom->fieldX();
        if(atom->fieldY() < minY)
            minY = atom->fieldY();
    }
```

