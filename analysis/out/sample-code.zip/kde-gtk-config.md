#### AUTO 


```{c}
const auto newRows = QSet<QString>(list).subtract(current);
```

#### AUTO 


```{c}
const auto &statement
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &row: oldRows) {
            for(; from<m_texts.count();) {
                const auto idx = m_texts.indexOf(row, from);
                if (idx<0)
                    break;
                beginRemoveRows({}, idx, idx);
                m_texts.removeAt(idx);
                endRemoveRows();
                from = idx + 1;
            }
        }
```

#### AUTO 


```{c}
auto it = m_settings.begin();
```

#### AUTO 


```{c}
auto a3 = dynamic_cast<AppearanceGTK3*>(a.data());
```

#### AUTO 


```{c}
const auto &buttonType
```

#### AUTO 


```{c}
static auto gtk3ConfigValueSettingsIni = std::bind(gtkConfigValueSettingsIni, QStringLiteral("gtk-3.0"), _1);
```

#### AUTO 


```{c}
const auto model = dynamic_cast<MyStringListModel*>(combo->model());
```

#### AUTO 


```{c}
auto cfg = KSharedConfig::openConfig(path);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QFileInfo &it : availableThemes) {
        QDir themeDir(it.filePath());
        if(!themeDir.entryList(gtk3SubdirPattern, QDir::Dirs).isEmpty())
            themes += it.filePath();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& themesDir : QStandardPaths::locateAll(QStandardPaths::GenericDataLocation, QStringLiteral("themes"), QStandardPaths::LocateDirectory)) {
        QDir root(themesDir);
        availableThemes += root.entryInfoList(QDir::NoDotAndDotDot | QDir::AllDirs);
    }
```

#### AUTO 


```{c}
auto cfg = KSharedConfig::openConfig(file, KConfig::NoGlobals);
```

#### AUTO 


```{c}
const auto &pluginMetaData
```

#### AUTO 


```{c}
const auto &row
```

#### RANGE FOR STATEMENT 


```{c}
for(AbstractAppearance *app : m_app) {
        bool c = app->loadSettings();
        correct = correct || c;
    }
```

#### AUTO 


```{c}
const auto decorationPlugins = KPluginMetaData::findPlugins(QStringLiteral("org.kde.kdecoration2"));
```

#### AUTO 


```{c}
static auto setGtk4ConfigValueSettingsIni = std::bind(setGtkConfigValueSettingsIni, QStringLiteral("gtk-4.0"), _1, _2);
```

#### AUTO 


```{c}
auto config = KSharedConfig::openConfig(colorScheme, KConfig::SimpleConfig);
```

#### AUTO 


```{c}
auto weight = font.weight();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &buttonState : buttonStates) {
            QSvgGenerator svgGenerator {};

            const QString fileDirPath = QDir::tempPath() + QStringLiteral("/plasma-csd-generator");
            QDir(fileDirPath).mkpath(QStringLiteral("."));
            QString filePath = QStringLiteral("%1/%2-%3.svg").arg(fileDirPath, buttonType, buttonState);

            svgGenerator.setFileName(filePath);
            svgGenerator.setViewBox(DecorationPainter::ButtonGeometry);

            QPainter painter {&svgGenerator};
            decorationPainter->paintButton(painter, buttonType, buttonState);
            painter.end();

            decorationsImages.append(filePath);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &pluginMetaData : decorationPlugins) {
        if (pluginMetaData.name() == QStringLiteral("Breeze")) {
            defaultPluginPath = pluginMetaData.fileName();
        }

        if (pluginMetaData.name() == decorationTheme) {
            return pluginMetaData.fileName();
        }
    }
```

#### AUTO 


```{c}
const auto idx = m_texts.indexOf(row, from);
```

#### AUTO 


```{c}
auto findIconAt = [label, theme, iconName](const QDir &where) -> bool {
        const QString path = IconThemesModel::findIconRecursivelyByName(iconName, where);

        if(!path.isEmpty()) {
            QPixmap p;
            QSize s(label->width(), label->height());
            if (path.endsWith(".svg") || path.endsWith(".svgz")) {
                QImage image(s, QImage::Format_ARGB32_Premultiplied);
                image.fill(Qt::transparent);
                QPainter painter(&image);
                QSvgRenderer r(path);
                r.render(&painter);
                painter.end();

                p = QPixmap::fromImage(image);
            } else {
                p = {path};
                Q_ASSERT(!p.isNull());
                p = p.scaled(s);
            }
            label->setPixmap(p);
            return true;
        }
        return false;
    };
```

#### AUTO 


```{c}
auto stretch = font.stretch();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &buttonType : buttonTypes) {
        for (const auto &buttonState : buttonStates) {
            QSvgGenerator svgGenerator {};

            QString filePath = generatedCSDTempPath.filePath(QStringLiteral("%1-%2.svg").arg(buttonType, buttonState));

            svgGenerator.setFileName(filePath);
            svgGenerator.setViewBox(DecorationPainter::ButtonGeometry);

            QPainter painter {&svgGenerator};
            decorationPainter->paintButton(painter, buttonType, buttonState);
            painter.end();

            decorationsImages.append(filePath);
        }
    }
```

#### AUTO 


```{c}
const auto windowDecorationsButtonsImages = configValueProvider->windowDecorationsButtonsImages();
```

#### AUTO 


```{c}
const auto entries = temporal.entryList(QDir::AllDirs|QDir::NoDotAndDotDot);
```

#### AUTO 


```{c}
const auto fontFamily = m_settings["font"].leftRef(nameEnd);
```

#### AUTO 


```{c}
auto cfg = KSharedConfig::openConfig(configFileName());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &buttonImagePath : windowDecorationsButtonsImages) {
        const QString destination = assetsFolder.path() + '/' + QFileInfo(buttonImagePath).fileName();
        QFile(destination).remove();
        QFile(buttonImagePath).rename(buttonImagePath, destination);
    }
```

#### AUTO 


```{c}
const auto &buttonState
```

#### RANGE FOR STATEMENT 


```{c}
for(AbstractAppearance *app : m_app) {
        bool c = app->saveSettings();
        correct = correct && c;
    }
```

#### AUTO 


```{c}
static auto setGtk3ConfigValueSettingsIni = std::bind(setGtkConfigValueSettingsIni, QStringLiteral("gtk-3.0"), _1, _2);
```

#### LAMBDA EXPRESSION 


```{c}
[label, theme, iconName](const QDir &where) -> bool {
        const QString path = IconThemesModel::findIconRecursivelyByName(iconName, where);

        if(!path.isEmpty()) {
            QPixmap p;
            QSize s(label->width(), label->height());
            if (path.endsWith(".svg") || path.endsWith(".svgz")) {
                QImage image(s, QImage::Format_ARGB32_Premultiplied);
                image.fill(Qt::transparent);
                QPainter painter(&image);
                QSvgRenderer r(path);
                r.render(&painter);
                painter.end();

                p = QPixmap::fromImage(image);
            } else {
                p = {path};
                Q_ASSERT(!p.isNull());
                p = p.scaled(s);
            }
            label->setPixmap(p);
            return true;
        }
        return false;
    }
```

#### AUTO 


```{c}
const auto decorationPlugins = KPluginLoader::findPlugins(QStringLiteral("org.kde.kdecoration2"));
```

#### AUTO 


```{c}
auto cfg = KSharedConfig::openConfig(configFileName(), KConfig::NoGlobals);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &row: oldRows) {
            for(; from < m_texts.count();) {
                const auto idx = m_texts.indexOf(row, from);
                if (idx < 0) {
                    break;
                }
                beginRemoveRows({}, idx, idx);
                m_texts.removeAt(idx);
                endRemoveRows();
                from = idx + 1;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &buttonState : buttonStates) {
            QSvgGenerator svgGenerator {};

            QString filePath = generatedCSDTempPath.filePath(QStringLiteral("%1-%2.svg").arg(buttonType, buttonState));

            svgGenerator.setFileName(filePath);
            svgGenerator.setViewBox(DecorationPainter::ButtonGeometry);

            QPainter painter {&svgGenerator};
            decorationPainter->paintButton(painter, buttonType, buttonState);
            painter.end();

            decorationsImages.append(filePath);
        }
```

#### AUTO 


```{c}
const auto oldRows = QSet<QString>(current).subtract(list);
```

#### AUTO 


```{c}
auto decorationSettings = QSharedPointer<KDecoration2::DecorationSettings>::create(this);
```

#### AUTO 


```{c}
static auto gtk4ConfigValueSettingsIni = std::bind(gtkConfigValueSettingsIni, QStringLiteral("gtk-4.0"), _1);
```

#### AUTO 


```{c}
const auto current = m_texts.toSet();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &pluginMetaData : decorationPlugins) {
        if (pluginMetaData.pluginId() == QLatin1String("org.kde.breeze")) {
            defaultPluginPath = pluginMetaData.fileName();
        }

        if (pluginMetaData.name() == decorationTheme) {
            return pluginMetaData.fileName();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QChar &buttonAbbreviation : kdeConfigValue) {
        if (buttonAbbreviation == 'X') {
            gtkNotation += QStringLiteral("close,");
        } else if (buttonAbbreviation == 'I') {
            gtkNotation += QStringLiteral("minimize,");
        } else if (buttonAbbreviation == 'A') {
            gtkNotation += QStringLiteral("maximize,");
        } else if (buttonAbbreviation == 'M') {
            gtkNotation += QStringLiteral("icon,");
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        m_watcher.addPath(m_colorScheme);
        update();
        emit changed();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString &theme : themes) {
        ret += QDir(theme).dirName();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &buttonType : buttonTypes) {
        for (const auto &buttonState : buttonStates) {
            QSvgGenerator svgGenerator {};

            const QString fileDirPath = QDir::tempPath() + QStringLiteral("/plasma-csd-generator");
            QDir(fileDirPath).mkpath(QStringLiteral("."));
            QString filePath = QStringLiteral("%1/%2-%3.svg").arg(fileDirPath, buttonType, buttonState);

            svgGenerator.setFileName(filePath);
            svgGenerator.setViewBox(DecorationPainter::ButtonGeometry);

            QPainter painter {&svgGenerator};
            decorationPainter->paintButton(painter, buttonType, buttonState);
            painter.end();

            decorationsImages.append(filePath);
        }
    }
```

#### AUTO 


```{c}
auto decorationPainter = DecorationPainter::fromThemeName(themeName);
```

#### AUTO 


```{c}
auto it = colorsDefinitions.cbegin();
```

#### AUTO 


```{c}
const auto newFont = stringToFont(appareance->getFont());
```

#### AUTO 


```{c}
auto style = font.style();
```

#### AUTO 


```{c}
auto cfg = KSharedConfig::openConfig(file);
```

#### AUTO 


```{c}
auto cfg = KSharedConfig::openConfig(path, KConfig::NoGlobals);
```

#### AUTO 


```{c}
auto newSettings = std::unique_ptr<DummyDecorationSettings>(new DummyDecorationSettings(parent));
```

#### AUTO 


```{c}
auto ptr = std::unique_ptr<DummyDecoratedClient>(new DummyDecoratedClient(client, decoration));
```

#### AUTO 


```{c}
auto group = globalConfig->group(QStringLiteral("KDE"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &statement : importStatements) {
            if (!gtkCssContents.contains(statement.trimmed())) {
                gtkCssContents.append(statement);
            }
        }
```

#### AUTO 


```{c}
auto group = gtkConfigGroup(versionString);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &buttonType : buttonTypes) {
        for (const auto &buttonState : buttonStates) {
            QSvgGenerator svgGenerator{};

            QString filePath = generatedCSDTempPath.filePath(QStringLiteral("%1-%2.svg").arg(buttonType, buttonState));

            svgGenerator.setFileName(filePath);
            svgGenerator.setViewBox(DecorationPainter::ButtonGeometry);

            QPainter painter{&svgGenerator};
            decorationPainter->paintButton(painter, buttonType, buttonState);
            painter.end();

            decorationsImages.append(filePath);
        }
    }
```

#### AUTO 


```{c}
static auto unsetGtk4ConfigValueSettingsIni = std::bind(unsetGtkConfigValueSettingsIni, QStringLiteral("gtk-4.0"), _1);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &buttonState : buttonStates) {
            QSvgGenerator svgGenerator{};

            QString filePath = generatedCSDTempPath.filePath(QStringLiteral("%1-%2.svg").arg(buttonType, buttonState));

            svgGenerator.setFileName(filePath);
            svgGenerator.setViewBox(DecorationPainter::ButtonGeometry);

            QPainter painter{&svgGenerator};
            decorationPainter->paintButton(painter, buttonType, buttonState);
            painter.end();

            decorationsImages.append(filePath);
        }
```

#### AUTO 


```{c}
auto it = foundSettings.constBegin(), itEnd = foundSettings.constEnd();
```

#### AUTO 


```{c}
const auto &buttonImagePath
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& themesDir : QStandardPaths::locateAll(QStandardPaths::GenericDataLocation, "themes", QStandardPaths::LocateDirectory)) {
        QDir root(themesDir);
        availableThemes += root.entryInfoList(QDir::NoDotAndDotDot | QDir::AllDirs);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &text : texts) {
        int pos = combo->findText(text);
        if(pos >= 0) {
            combo->setCurrentIndex(pos);
            return;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QFileInfo &it : availableThemes) {
        bool hasGtkrc = QDir(it.filePath()).exists("gtk-2.0");

        // If it doesn't exist, we don't want it on the list
        if (hasGtkrc) {
            paths += it.filePath();
        }
    }
```

#### AUTO 


```{c}
auto config = KSharedConfig::openConfig(m_colorScheme, KConfig::SimpleConfig);
```

