#### LAMBDA EXPRESSION 


```{c}
[this](bool toggled) { if (toggled) remoteChanged(0); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& file : fileNames)
    themeList.append(dir + QLatin1Char('/') + file);
```

#### RANGE FOR STATEMENT 


```{c}
for (Themeable *object : std::as_const(mObjects)) {
      object->changeTheme();
  }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool toggled) { if (toggled) remoteChanged(1); }
```

#### RANGE FOR STATEMENT 


```{c}
for (Themeable *object : qAsConst(mObjects)) {
      object->changeTheme();
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& file : fileNames)
    themeList.append(dir + '/' + file);
```

