#### RANGE FOR STATEMENT 


```{c}
for (const auto abstractKey: m_keys)
    {
        Key* const key = qobject_cast<Key*>(abstractKey);
        if (key)
        {
            for (const auto keyChar : key->keyChars())
            {
                result.append(keyChar->value());
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto keyChar : key->keyChars())
            {
                result.append(keyChar->value());
            }
```

#### AUTO 


```{c}
auto context = new KLocalizedContext(qmlEngine);
```

#### LAMBDA EXPRESSION 


```{c}
[=] { updateLessonCharacters(index); }
```

#### AUTO 


```{c}
auto newColorGroup = static_cast<QPalette::ColorGroup>(group);
```

#### LAMBDA EXPRESSION 


```{c}
[=] { emitCharacterChanged(index); }
```

#### AUTO 


```{c}
const auto abstractKey
```

#### AUTO 


```{c}
const auto keyChar
```

#### AUTO 


```{c}
const auto device = painter->device();
```

#### AUTO 


```{c}
auto result = QColor(color);
```

#### LAMBDA EXPRESSION 


```{c}
[=] { onKeyGeometryChanged(m_keys.count() - 1); }
```

#### AUTO 


```{c}
auto newColorSet = static_cast<KColorScheme::ColorSet>(colorSet);
```

#### LAMBDA EXPRESSION 


```{c}
[=](){
        m_zoomSlider->setValue(m_zoomSlider->value() + 1);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](){
        m_zoomSlider->setValue(m_zoomSlider->value() - 1);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=] { emitDataChanged(index); }
```

#### LAMBDA EXPRESSION 


```{c}
[=] { emitCharacterChanged(i); }
```

#### AUTO 


```{c}
auto app = qobject_cast<QGuiApplication*>(QCoreApplication::instance());
```

#### LAMBDA EXPRESSION 


```{c}
[=] { emitLessonChanged(i); }
```

#### LAMBDA EXPRESSION 


```{c}
[=] { emitLessonChanged(index); }
```

