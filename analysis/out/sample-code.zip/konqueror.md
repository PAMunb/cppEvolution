#### LAMBDA EXPRESSION 


```{c}
[this]() { reject(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : rcfiles) {
            const QFileInfo fInfo(dir + QLatin1Char('/') + file);
            QMap<QString, QStringList>::Iterator mapIt = sortedPlugins.find(fInfo.fileName());
            if (mapIt == sortedPlugins.end()) {
                mapIt = sortedPlugins.insert(fInfo.fileName(), QStringList());
            }
            mapIt.value().append(fInfo.absoluteFilePath());
        }
```

#### AUTO 


```{c}
auto addPluginForId = [this](const QString &pluginId) {
        QVector<KPluginMetaData> metaDataList = KPluginMetaData::findPlugins(pluginId + QStringLiteral("/kpartplugins"));
        d->pluginSelector->setConfig(KSharedConfig::openConfig(pluginId + QLatin1String("rc"))->group("KParts Plugins"));
        d->pluginSelector->addPlugins(metaDataList, i18n("Extensions"));
    };
```

#### AUTO 


```{c}
auto realCallBack = [callback, url](const QVariant &jsForms) {
        WebFormList forms = parseFormDetectionResult(jsForms, url);
        callback(forms);
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this, url](const WebFormList &forms){
            removeFormDataFromCache(forms);
            WebEngineSettings::self()->removeCacheableFieldsCustomizationForPage(customFormsKey(url));
        }
```

#### AUTO 


```{c}
auto *job = new KIO::CommandLauncherJob(command);
```

#### LAMBDA EXPRESSION 


```{c}
[=](const KPluginMetaData& metaData) {
        if (!metaData.serviceTypes().contains(QStringLiteral("KFileItemAction/Plugin"))) {
            return false;
        }

        auto mimeType = QMimeDatabase().mimeTypeForName(commonMimeType);
        foreach (const auto &supportedMimeType, metaData.mimeTypes()) {
            if (mimeType.inherits(supportedMimeType)) {
                return true;
            }
        }

        return false;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[serviceName](KService::Ptr s){return s->desktopEntryName() == serviceName;}
```

#### LAMBDA EXPRESSION 


```{c}
[this, page](const WebFormList &forms){saveFormData(page, forms);}
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &pluginId) {
        const QStringList searchPaths =
            QStandardPaths::locateAll(QStandardPaths::GenericDataLocation, pluginId + QStringLiteral("/kpartplugins"), QStandardPaths::LocateDirectory);
        const QStringList files = KFileUtils::findAllUniqueFiles(searchPaths, {QStringLiteral("*.desktop")});
        QVector<KPluginMetaData> metaDataList;
        metaDataList.reserve(files.count());
        for (const QString &file : files) {
            metaDataList << KPluginMetaData::fromDesktopFile(file);
        }
        d->pluginSelector->setConfig(KSharedConfig::openConfig(pluginId + QLatin1String("rc"))->group("KParts Plugins"));
        d->pluginSelector->addPlugins(metaDataList, i18n("Extensions"));
    }
```

#### AUTO 


```{c}
auto mimeType = QMimeDatabase().mimeTypeForName(commonMimeType);
```

#### RANGE FOR STATEMENT 


```{c}
for(const CookieData &d: data){
        QNetworkCookie c = d.cookie();
        QDBusError e = addCookieToKCookieServer(c, d.host);
        QVERIFY2(!e.isValid(), qPrintable(e.message()));
        expected << c;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (int i : it.value()) {
            form.fields.append(oldForm.fields.at(i));
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](){if (m_wallet){m_wallet->customizeFieldsToCache(page(), view());}}
```

#### AUTO 


```{c}
const auto selectedItems = _view->selection();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& url : urls) {
        query.addQueryItem(QStringLiteral("attachment"), url);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](int idx) {
            startURL->setVisible(idx == ShowStartUrlPage);
            displayEmpytStartPageWarningIfNeeded();
            }
```

#### LAMBDA EXPRESSION 


```{c}
[window](const CertificateErrorData &data) {
        return windowForPage(data.page) == window;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, url, page](const WebFormList &forms) {
        if (!WebEngineSettings::self()->isNonPasswordStorableSite(url.host())) {
            fillFormData(page, cacheableForms(url, forms, CacheOperation::Fill));
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[job, this](KJob *) {
        bool modified = false;
        const QUrl _hostUrl = job->property("_hostUrl").value<QUrl>();
        QMap<QUrl, QString>::iterator itEnd = iconMap.end();
        for (QMap<QUrl, QString>::iterator it = iconMap.begin(); it != itEnd; ++it) {
            const QUrl url(it.key());
            if (url.host() == _hostUrl.host()) {
                // For host default-icons still query the favicon manager to get
                // the correct icon for pages that have an own one.
                const QString icon = KIO::favIconForUrl(url);
                if (!icon.isEmpty()) {
                    *it = icon;
                    modified = true;
                }
            }
        }
        if (modified) {
            emit changed();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[origin, feature](FeaturePermissionBar *bar) {
        return bar->url() == origin && bar->feature() == feature;
    }
```

#### AUTO 


```{c}
auto policyLambda = [this, bar](QWebEnginePage::Feature feature, QWebEnginePage::PermissionPolicy policy) {
        slotFeaturePolicyChosen(bar, feature, policy);
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool found) {
        m_searchBar->setFoundMatch(found);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const WebFormList &list){removeFormDataFromCache(list);}
```

#### AUTO 


```{c}
auto launcherJob = new KIO::ApplicationLauncherJob(service);
```

#### LAMBDA EXPRESSION 


```{c}
[this, dlg](){
        QUrl dest = dlg->selectedUrls().value(0);
        if (dest.isValid()) {
            saveUrlUsingKIO(m_url, dest);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, key, url](const WebFormList &list){saveFormDataCallback(key, url, list);}
```

#### LAMBDA EXPRESSION 


```{c}
[]() { new KonqMainWindow(KonqUrl::url(KonqUrl::Type::Blank)); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &pluginInfo : pluginInfos) {
        if (hasPlugin(parent, pluginInfo.m_metaData.pluginId())) {
            continue;
        }

        Plugin *plugin = loadPlugin(parent, pluginInfo.m_metaData);

        if (plugin) {
            plugin->d->m_parentInstance = componentName;
            plugin->setXMLFile(pluginInfo.m_absXMLFileName, false, false);
            plugin->setDOMDocument(pluginInfo.m_document);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &name : entries)
        {
            // Look though the extracted archive files to try to identify the
            // HTML page is to be rendered.  If "index.html" or "index.htm" is
            // found, that file is used;  otherwise, the first HTML file that
            // was found is used.
            const QMimeType mime = db.mimeTypeForFile(tempDir.absoluteFilePath(name), QMimeDatabase::MatchExtension);
            if (mime.inherits("text/html"))
            {
                if (name.startsWith("index.", Qt::CaseInsensitive))
                {					// the index HTML file
                    indexHtml = name;
                    break;				// no need to look further
                }
                else if (indexHtml.isEmpty())		// any other HTML file
                {
                    indexHtml = name;
                }
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[job, this](KJob *) {
        bool modified = false;
        const QUrl _hostUrl = job->property("_hostUrl").value<QUrl>();
        QMap<QUrl, QString>::iterator itEnd = iconMap.end();
        for (QMap<QUrl, QString>::iterator it = iconMap.begin(); it != itEnd; ++it) {
            const QUrl url(it.key());
            if (url.host() == _hostUrl.host() && url.path() == _hostUrl.path()) {
                const QString icon = job->iconFile();
                if (!icon.isEmpty()) {
                    *it = icon;
                    modified = true;
                }
            }
        }
        if (modified) {
            emit changed();
        }
    }
```

#### AUTO 


```{c}
auto lambda = [this](const QVariant &res){emit urlsExtracted(res.toStringList());};
```

#### AUTO 


```{c}
auto it = m_dicts.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QSslCertificate &cert : m_error.certificateChain()) {
        m_ui->certificateChain->addItem(cert.subjectDisplayName());
    }
```

#### AUTO 


```{c}
const auto exec = KProtocolInfo::exec(url.scheme());
```

#### LAMBDA EXPRESSION 


```{c}
[webEngineName](KService::Ptr s){return s->desktopEntryName() != webEngineName;}
```

#### AUTO 


```{c}
auto itemFromString = [](const QString &s){
        QStandardItem *it = new QStandardItem(s);
        it->setTextAlignment(Qt::AlignCenter);
        return it;
    };
```

#### AUTO 


```{c}
auto callback = [this, url](const WebFormList &forms){
            removeFormDataFromCache(forms);
            WebEngineSettings::self()->removeCacheableFieldsCustomizationForPage(customFormsKey(url));
        };
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            slotConfigTrashBin();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            slotShowOriginalFile();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(const CookieData &d: data){
        QNetworkCookie c = d.cookie();
        QDBusError e = addCookieToKCookieServer(c, d.host);
        QVERIFY2(!e.isValid(), qPrintable(e.message()));
        //In case of an empty domain, WebEnginePartCookieJar will use QNetworkCookie::normalize on the cookie
        if (c.domain().isEmpty()) {
            c.setDomain(d.host);
        }
        expected << c;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const WebForm::WebField &f){return f.name;}
```

#### LAMBDA EXPRESSION 


```{c}
[this, bar](QWebEnginePage::Feature feature, QWebEnginePage::PermissionPolicy policy) {
        slotFeaturePolicyChosen(bar, feature, policy);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QPrinter *p){
        QEventLoop loop;
        auto preview = [&](bool) {loop.quit();};
        m_view->page()->print(p, preview);
        loop.exec();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, page](const WebFormList &forms){saveFormData(page, forms, true);}
```

#### AUTO 


```{c}
auto queryItem
```

#### LAMBDA EXPRESSION 


```{c}
[page, s](){page->replaceMisspelledWord(s);}
```

#### LAMBDA EXPRESSION 


```{c}
[this, dlg](int _){handleCertificateError(dlg);}
```

#### AUTO 


```{c}
auto saveLinkAsLambda = [this, url](bool){qobject_cast<WebEngineBrowserExtension*>(m_part->browserExtension())->slotSaveLinkAs(url);};
```

#### AUTO 


```{c}
auto boolToYesNo = [yes, no](bool val){return val ? yes : no;};
```

#### RANGE FOR STATEMENT 


```{c}
for (KService::Ptr offer : offers) {
            // Allowed as default ?
            QVariant prop = offer ->property(QStringLiteral("X-KDE-BrowserView-AllowAsDefault"));
            qCDebug(KONQUEROR_LOG) << offer ->desktopEntryName() << " : X-KDE-BrowserView-AllowAsDefault is valid : " << prop.isValid();
            if (!prop.isValid() || prop.toBool()) {   // defaults to true
                //qCDebug(KONQUEROR_LOG) << "Trying to open lib for service " << service->name();
                viewFactory = tryLoadingService(offer);
                if (!viewFactory.isNull()) {
                    service = offer;
                    break;
                }
            } else {
                qCDebug(KONQUEROR_LOG) << "Not allowed as default " << service->desktopEntryName();
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[yes, no](bool val){return val ? yes : no;}
```

#### AUTO 


```{c}
auto findCookies=[this, &domain, &host, &path, &name](){
        QDBusReply<QStringList> reply = m_server->call(QDBus::Block, "findCookies", QVariant::fromValue(QList<int>{2}), domain, host, path, name);
        return reply;
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const KService::Ptr &service : offers) {
        if (service->desktopEntryName() == serviceName) {
            KIO::ApplicationLauncherJob *job = new KIO::ApplicationLauncherJob(service);
            job->setUrls({ m_currentView->url() });
            job->setUiDelegate(new KIO::JobUiDelegate(KJobUiDelegate::AutoHandlingEnabled, this));
            job->start();
            return;
        }
    }
```

#### AUTO 


```{c}
auto it = std::find(m_closedWindowItemList.begin(), m_closedWindowItemList.end(), closedWindowItem);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &pluginDir : pluginDirs) {
        QDir dir(pluginDir);
        QStringList files = dir.entryList((QStringList() << "*.desktop"), QDir::Files);

        for (const QString &file : files) {
            KDesktopFile df(dir.absoluteFilePath(file)); // no merging. KService warns, and we don't need it.
            services.append(KService::Ptr(new KService(&df)));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &dir : dirs) {
        const auto rcfiles = QDir(dir).entryList(QStringList(QStringLiteral("*.rc")));
        for (const QString &file : rcfiles) {
            const QFileInfo fInfo(dir + QLatin1Char('/') + file);
            QMap<QString, QStringList>::Iterator mapIt = sortedPlugins.find(fInfo.fileName());
            if (mapIt == sortedPlugins.end()) {
                mapIt = sortedPlugins.insert(fInfo.fileName(), QStringList());
            }
            mapIt.value().append(fInfo.absoluteFilePath());
        }
    }
```

#### AUTO 


```{c}
auto callback = [this, page](const WebFormList &forms){
        fillFormDataCallback(page, forms);
    };
```

#### AUTO 


```{c}
auto *p
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &s){
        QStandardItem *it = new QStandardItem(s);
        it->setTextAlignment(Qt::AlignCenter);
        return it;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]{if(page() && m_wallet){m_wallet->detectAndFillPageForms(page());}}
```

#### LAMBDA EXPRESSION 


```{c}
[this, dlg](int){
        applyUserChoice(dlg);}
```

#### AUTO 


```{c}
auto it = data.begin();
```

#### AUTO 


```{c}
auto callback = [wasFilled, this](const QVariant &){emit fillFormRequestCompleted(wasFilled);};
```

#### LAMBDA EXPRESSION 


```{c}
[this](){emitResult();}
```

#### LAMBDA EXPRESSION 


```{c}
[this](int idx) {
            startURL->setEnabled(idx == ShowStartUrlPage);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[host, action]() {
                    action->setIcon(KonqPixmapProvider::self()->iconForUrl(host));
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const WebForm &f){return hasCachedFormData(f);}
```

#### AUTO 


```{c}
auto savePrc = [this, dlg](){
        QUrl dest = dlg->selectedUrls().value(0);
        if (dest.isValid()) {
            saveUrlUsingKIO(m_url, dest);
        }
    };
```

#### LAMBDA EXPRESSION 


```{c}
[&](bool) {loop.quit();}
```

#### LAMBDA EXPRESSION 


```{c}
[this, &domain, &host, &path, &name](){
        QDBusReply<QStringList> reply = m_server->call(QDBus::Block, "findCookies", QVariant::fromValue(QList<int>{2}), domain, host, path, name);
        return reply;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[job, this](KJob *) {
        bool modified = false;
        const QUrl _hostUrl = job->hostUrl();
        QMap<QUrl, QString>::iterator itEnd = iconMap.end();
        for (QMap<QUrl, QString>::iterator it = iconMap.begin(); it != itEnd; ++it) {
            const QUrl url(it.key());
            if (url.host() == _hostUrl.host() && url.path() == _hostUrl.path()) {
                const QString icon = job->iconFile();
                if (!icon.isEmpty() && *it != icon) {
                    *it = icon;
                    modified = true;
                }
            }
        }
        if (modified) {
            emit changed();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &s : suggestions) {
                a = new QAction(s, menu);
                menu->addAction(a);
                connect(a, &QAction::triggered, page, [page, s](){page->replaceMisspelledWord(s);});
            }
```

#### AUTO 


```{c}
auto findExistingBar = [origin, feature](FeaturePermissionBar *bar) {
        return bar->url() == origin && bar->feature() == feature;
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (KonqView *view : window->viewMap()) {
                    lst.append(view->url().toString());
                }
```

#### LAMBDA EXPRESSION 


```{c}
[=](int val) { m_randomWaitCheck->setEnabled(val>0); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QVariant &res){emit urlsExtracted(res.toStringList());}
```

#### AUTO 


```{c}
const auto &pluginInfo
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &text : items) {
            if (rowIndex < count()) {
                const bool changed = (static_cast<KonqListWidgetItem *>(item(rowIndex)))->reuse(text);
                dirty = dirty || changed;
            } else {
                dirty = true;
                //Inserting an item is a way of making this dirty
                addItem(new KonqListWidgetItem(text));
            }
            rowIndex++;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &pluginId) {
        QVector<KPluginMetaData> metaDataList = KPluginMetaData::findPlugins(pluginId + QStringLiteral("/kpartplugins"));
        d->pluginSelector->addPlugins(metaDataList, i18n("Extensions"));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QVariant &value) {
        const QString text = value.toString();
        if (!text.isEmpty()) {
            m_spellTextSelectionStart = 0;
            m_spellTextSelectionEnd = 0;

            Sonnet::BackgroundChecker *backgroundSpellCheck = new Sonnet::BackgroundChecker;
            Sonnet::Dialog* spellDialog = new Sonnet::Dialog(backgroundSpellCheck, view());
            backgroundSpellCheck->setParent(spellDialog);
            spellDialog->setAttribute(Qt::WA_DeleteOnClose, true);
            spellDialog->showSpellCheckCompletionMessage(true);
            connect(spellDialog, SIGNAL(replace(QString,int,QString)), this, SLOT(spellCheckerCorrected(QString,int,QString)));
            connect(spellDialog, SIGNAL(misspelling(QString,int)), this, SLOT(spellCheckerMisspelling(QString,int)));
            spellDialog->setBuffer(text);
            spellDialog->show();
        }
    }
```

#### AUTO 


```{c}
auto filter = [this](const QWebEngineCookieStore::FilterRequest &req){return filterCookie(req);};
```

#### LAMBDA EXPRESSION 


```{c}
[](const WebField &f){return !f.disabled && !f.readOnly && f.autocompleteAllowed;}
```

#### AUTO 


```{c}
auto *job = new KIO::CommandLauncherJob(executable, shellArgs);
```

#### RANGE FOR STATEMENT 


```{c}
for (const WebForm &form : allForms) {
        auto sameForm = [form](const WebEngineSettings::WebFormInfo &info){return info.name == form.name && info.framePath == form.framePath;};
        auto it = std::find_if(customForms.constBegin(), customForms.constEnd(), sameForm);
        if (it == customForms.constEnd()) {
            continue;
        }
        QVector<WebForm::WebField> fields;
        auto filter = [it](const WebForm::WebField &f){return (*it).fields.contains(f.name);};
        std::copy_if(form.fields.constBegin(), form.fields.constEnd(), std::back_inserter(fields), filter);
        if (fields.isEmpty()) {
            continue;
        }
        WebForm f(form);
        f.fields = std::move(fields);
        forms.append(f);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, dlg, url](){
        QUrl destUrl = dlg->selectedUrls().value(0);
        if (destUrl.isValid()) {
            saveUrlUsingKIO(url, destUrl);
        }
    }
```

#### AUTO 


```{c}
auto filter = [it](const WebForm::WebField &f){return (*it).fields.contains(f.name);};
```

#### RANGE FOR STATEMENT 


```{c}
for(const QNetworkCookie &c: qAsConst(m_jar->m_testCookies)){
        if(QString(c.name()).startsWith(baseCookieName)) {
            cookiesInsertedIntoJar << c;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, url](bool){qobject_cast<WebEngineBrowserExtension*>(m_part->browserExtension())->slotSaveLinkAs(url);}
```

#### LAMBDA EXPRESSION 


```{c}
[this](){m_wallet->removeCustomizationForPage(url());}
```

#### RANGE FOR STATEMENT 


```{c}
for (const WebEngineWallet::WebForm &form : allForms) {
        if (q->hasCachedFormData(form)) {
            WebEngineWallet::WebForm f(form.withAutoFillableFieldsOnly());
            if (!f.fields.isEmpty()) {
                list.append(f);
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QVariant &){emit urlsReplaced();}
```

#### LAMBDA EXPRESSION 


```{c}
[this](){slotCompleted(true);}
```

#### AUTO 


```{c}
auto findNext = [window](const CertificateErrorData &data) {
        return windowForPage(data.page) == window;
    };
```

#### AUTO 


```{c}
auto findItemForDialog = [dlg](const std::pair<QObject*, QObject*>& pair){return pair.second == dlg;};
```

#### AUTO 


```{c}
auto connection = QDBusConnection::sessionBus();
```

#### RANGE FOR STATEMENT 


```{c}
for (KonqView *view : qAsConst(views)) {
        QString viewName = view->viewName();
        //qCDebug(KONQUEROR_LOG) << "       - viewName=" << viewName
        //          << "frame names:" << view->frameNames();

        if (!viewName.isEmpty() && viewName == name) {
            qCDebug(KONQUEROR_LOG) << "found existing view by name:" << view;
            if (part) {
                *part = view->part();
            }
            return view;
        }
    }
```

#### AUTO 


```{c}
auto *menu = new KActionMenu(QIcon::fromTheme("kget"), i18n("Download Manager"), actionCollection());
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            slotPopupNewView();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, job](){kioJobFinished(job);}
```

#### LAMBDA EXPRESSION 


```{c}
[](const WebForm &f){return f.hasFieldsWithWrittenValues();}
```

#### LAMBDA EXPRESSION 


```{c}
[wasFilled, this](const QVariant &){emit fillFormRequestCompleted(wasFilled);}
```

#### AUTO 


```{c}
const auto toolbuttons = ltb->findChildren<QToolButton *>();
```

#### RANGE FOR STATEMENT 


```{c}
for(const QNetworkCookie &c: qAsConst(m_jar->m_testCookies)) {
        if (c.name() == data.name) {
            cookiesInsertedIntoJar << c;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[job, this](KJob *){
        bool modified = false;
        const QUrl _hostUrl = job->property("_hostUrl").value<QUrl>();
        QMap<QUrl,QString>::iterator itEnd = iconMap.end();
        for (QMap<QUrl,QString>::iterator it = iconMap.begin(); it != itEnd; ++it) {
            const QUrl url(it.key());
            if (url.host() == _hostUrl.host() && url.path() == _hostUrl.path()) {
                const QString icon = job->iconFile();
                if (!icon.isEmpty()) {
                    *it = icon;
                    modified = true;
                }
            }
       }
        if (modified) {
            emit changed();
        }
   }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &pluginId) {
        reparseConfiguration(pluginId.toLocal8Bit());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, url, fillform, ignorepasswd, callback](const QVariant &result){
        WebFormList res = parseFormData(result, url, fillform, ignorepasswd);
        callback(res);
    }
```

#### AUTO 


```{c}
auto *job = new KIO::ApplicationLauncherJob(service);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &name : names) {
            KService::Ptr s = KService::serviceByDesktopName(name);
            s_mimeTypes.append(s->mimeTypes());
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        slotConfigTrashBin();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[job, this](KJob *) {
        bool modified = false;
        const QUrl _hostUrl = job->hostUrl();
        QMap<QUrl, QString>::iterator itEnd = iconMap.end();
        for (QMap<QUrl, QString>::iterator it = iconMap.begin(); it != itEnd; ++it) {
            const QUrl url(it.key());
            if (url.host() == _hostUrl.host()) {
                // For host default-icons still query the favicon manager to get
                // the correct icon for pages that have an own one.
                const QString icon = KIO::favIconForUrl(url);
                if (!icon.isEmpty() && *it != icon) {
                    *it = icon;
                    modified = true;
                }
            }
        }
        if (modified) {
            emit changed();
        }
    }
```

#### AUTO 


```{c}
auto extractField = [data, start](CookieDetails field){return data.at(start + static_cast<int>(field));};
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &mimeName : mimeNames)
    {
        const QMimeType mimeType = db.mimeTypeForName(mimeName);
        imageNameFilters.append(mimeType.globPatterns());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const WebEngineSettings::WebFormInfo &info : oldSettings) {
            oldSettingsMap.insert(info.name, info.fields);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, page](const WebFormList &forms){
        fillFormDataCallback(page, forms);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KonqMainWindow *win : *mainWindowList) {
            if (win->isPreloaded()) {
                qDebug() << "Reusing preloaded window" << win;
                KStartupInfo::setWindowStartupId(win->winId(), KStartupInfo::startupId());
                ensurePreloadedWindow();
                return win;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, job](){m_page->setHtml(job->data(), QUrl::fromLocalFile("/"));}
```

#### LAMBDA EXPRESSION 


```{c}
[this, text](const QVariant &value) {
                const QString values = value.toString();
                const int pos = values.indexOf(' ');
                m_spellTextSelectionStart = qMax(0, values.leftRef(pos).toInt());
                m_spellTextSelectionEnd = qMax(0, values.midRef(pos + 1).toInt());
                // qCDebug(WEBENGINEPART_LOG) << "selection start:" << m_spellTextSelectionStart << "end:" << m_spellTextSelectionEnd;

                Sonnet::BackgroundChecker *backgroundSpellCheck = new Sonnet::BackgroundChecker;
                Sonnet::Dialog* spellDialog = new Sonnet::Dialog(backgroundSpellCheck, view());
                backgroundSpellCheck->setParent(spellDialog);
                spellDialog->setAttribute(Qt::WA_DeleteOnClose, true);
                spellDialog->showSpellCheckCompletionMessage(true);
                connect(spellDialog, &Sonnet::Dialog::replace, this, &WebEngineBrowserExtension::spellCheckerCorrected);
                connect(spellDialog, &Sonnet::Dialog::misspelling, this, &WebEngineBrowserExtension::spellCheckerMisspelling);
                connect(spellDialog, &Sonnet::Dialog::spellCheckDone, this, &WebEngineBrowserExtension::slotSpellCheckDone);
                spellDialog->setBuffer(text.mid(m_spellTextSelectionStart, (m_spellTextSelectionEnd - m_spellTextSelectionStart)));
                spellDialog->show();
            }
```

#### LAMBDA EXPRESSION 


```{c}
[host, action]() {
            action->setIcon(KonqPixmapProvider::self()->iconForUrl(host));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &pluginInfo : plugins) {
        QDomElement docElem = pluginInfo.m_document.documentElement();
        QString library = docElem.attribute(QStringLiteral("library"));
        QString keyword;

        if (library.isEmpty()) {
            continue;
        }

        // Check configuration
        const QString name = docElem.attribute(QStringLiteral("name"));

        bool pluginEnabled = enableNewPluginsByDefault;
        if (cfgGroup.hasKey(name + QLatin1String("Enabled"))) {
            pluginEnabled = cfgGroup.readEntry(name + QLatin1String("Enabled"), false);
        } else { // no user-setting, load plugin default setting
            QString relPath = componentName + QLatin1Char('/') + pluginInfo.m_relXMLFileName;
            relPath.truncate(relPath.lastIndexOf(QLatin1Char('.'))); // remove extension
            relPath += QLatin1String(".desktop");
            // qDebug() << "looking for " << relPath;
            const QString desktopfile = QStandardPaths::locate(QStandardPaths::GenericDataLocation, relPath);
            if (!desktopfile.isEmpty()) {
                // qDebug() << "loadPlugins found desktop file for " << name << ": " << desktopfile;
                KDesktopFile _desktop(desktopfile);
                const KConfigGroup desktop = _desktop.desktopGroup();
                keyword = desktop.readEntry("X-KDE-PluginKeyword", "");
                pluginEnabled = desktop.readEntry("X-KDE-PluginInfo-EnabledByDefault", enableNewPluginsByDefault);
                if (interfaceVersionRequired != 0) {
                    const int version = desktop.readEntry("X-KDE-InterfaceVersion", 1);
                    if (version != interfaceVersionRequired) {
                        // qDebug() << "Discarding plugin " << name << ", interface version " << version << ", expected " << interfaceVersionRequired;
                        pluginEnabled = false;
                    }
                }
            } else {
                // qDebug() << "loadPlugins no desktop file found in " << relPath;
            }
        }

        // search through already present plugins
        const QObjectList pluginList = parent->children();

        bool pluginFound = false;
        for (auto *p : pluginList) {
            Plugin *plugin = qobject_cast<Plugin *>(p);
            if (plugin && plugin->d->m_library == library) {
                // delete and unload disabled plugins
                if (!pluginEnabled) {
                    // qDebug() << "remove plugin " << name;
                    KXMLGUIFactory *factory = plugin->factory();
                    if (factory) {
                        factory->removeClient(plugin);
                    }
                    delete plugin;
                }

                pluginFound = true;
                break;
            }
        }

        // if the plugin is already loaded or if it's disabled in the
        // configuration do nothing
        if (pluginFound || !pluginEnabled) {
            continue;
        }

        // qDebug() << "load plugin " << name << " " << library << " " << keyword;
        Plugin *plugin = loadPlugin(parent, library, keyword);

        if (plugin) {
            plugin->d->m_parentInstance = componentName;
            plugin->setXMLFile(pluginInfo.m_relXMLFileName, false, false);
            plugin->setDOMDocument(pluginInfo.m_document);
            parentGUIClient->insertChildClient(plugin);
        }
    }
```

#### AUTO 


```{c}
auto found = std::find_if(m_permissionBars.constBegin(), m_permissionBars.constEnd(), findExistingBar);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &text : items) {
            insertItem(rowIndex++, new KonqListWidgetItem(text));
        }
```

#### AUTO 


```{c}
auto it = std::find_if(offers.constBegin(), offers.constEnd(), [serviceName](KService::Ptr s){return s->desktopEntryName() == serviceName;});
```

#### RANGE FOR STATEMENT 


```{c}
for(const QVariant &e : elements) {
           QVariantMap elementMap(e.toMap());
           WebForm::WebField field;
           field.type = WebForm::fieldTypeFromTypeName(elementMap[QL1S("type")].toString().toLower());
           if (field.type == WebForm::WebFieldType::Other) {
               continue;
           }
           field.id = elementMap[QL1S("id")].toString();
           field.name = elementMap[QL1S("name")].toString();
           field.readOnly = elementMap[QL1S("readonly")].toBool();
           field.disabled = elementMap[QL1S("disabled")].toBool();
           field.autocompleteAllowed = elementMap[QL1S("autocompleteAllowed")].toBool();
           field.value = elementMap[QL1S("value")].toString();
           field.label = elementMap[QL1S("label")].toString();
           form.fields.append(field);
        }
```

#### AUTO 


```{c}
auto window = parentWindow(qobject_cast<QWidget*>(obj))
```

#### RANGE FOR STATEMENT 


```{c}
for (TreeMapItem *item : selectedItems) {
        Inode *inode = static_cast<Inode *>(item);
        const QUrl u = QUrl::fromLocalFile(inode->path());
        canCopy++;
        if (KProtocolManager::supportsDeleting(u)) {
            canDel++;
        }
        if (KProtocolManager::supportsMoving(u)) {
            canMove++;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *p : pluginList) {
            Plugin *plugin = qobject_cast<Plugin *>(p);
            if (plugin && plugin->d->m_library == library) {
                // delete and unload disabled plugins
                if (!pluginEnabled) {
                    // qDebug() << "remove plugin " << name;
                    KXMLGUIFactory *factory = plugin->factory();
                    if (factory) {
                        factory->removeClient(plugin);
                    }
                    delete plugin;
                }

                pluginFound = true;
                break;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, menu](const QString &name) {
        QAction *a = actionCollection()->action(name);
        if (a->isEnabled()) {
            menu->addAction(a);
        }
    }
```

#### AUTO 


```{c}
auto callback = [this](const WebFormList &list){removeFormDataFromCache(list);};
```

#### AUTO 


```{c}
auto sameForm = [form](const WebEngineSettings::WebFormInfo &info){return info.name == form.name && info.framePath == form.framePath;};
```

#### LAMBDA EXPRESSION 


```{c}
[this](){done(m_openUrlJob);}
```

#### LAMBDA EXPRESSION 


```{c}
[](const KPluginMetaData &d1, const KPluginMetaData &d2) {
        return d1.pluginId() < d2.pluginId();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString& html) {
            QTemporaryFile tempFile;
            tempFile.setFileTemplate(tempFile.fileTemplate() + QL1S(".html"));
            tempFile.setAutoRemove(false);
            if (tempFile.open()) {
                tempFile.write(html.toUtf8());
                KRun::runUrl(QUrl::fromLocalFile(tempFile.fileName()), QL1S("text/plain"), view(), KRun::RunFlags(KRun::DeleteTemporaryFiles));
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, url, page](const WebFormList &forms) {
        emit formDetectionDone(url, !forms.isEmpty(), d->hasAutoFillableFields(forms));
        if (!WebEngineSettings::self()->isNonPasswordStorableSite(url.host())) {
            fillFormData(page, cacheableForms(url, forms, CacheOperation::Fill));
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { setResult(QDialogButtonBox::Yes); accept(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (TreeMapItem *item : selectedItems) {
        Inode *inode = static_cast<Inode *>(item);
        const QUrl u = QUrl::fromLocalFile(inode->path());
        const QString mimetype = inode->mimeType().name();
        const QFileInfo &info = inode->fileInfo();
        mode_t mode =
            info.isFile() ? S_IFREG :
            info.isDir() ? S_IFDIR :
            info.isSymLink() ? S_IFLNK : (mode_t) - 1;
        items.append(KFileItem(u, mimetype, mode));
     }
```

#### AUTO 


```{c}
auto savePrc = [this, dlg, url](){
        QUrl destUrl = dlg->selectedUrls().value(0);
        if (destUrl.isValid()) {
            saveUrlUsingKIO(url, destUrl);
        }
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                const QString localPath = m_popupItemProperties.urlList().constFirst().toLocalFile();
                // 5.84 because the header wasn't usable in 5.83
#if KIO_VERSION >= QT_VERSION_CHECK(5, 84, 0)
              auto *job = new KTerminalLauncherJob(QString{});
              job->setWorkingDirectory(localPath);
              job->start();
#else
              KToolInvocation::invokeTerminal(QString(), localPath);
#endif
        }
```

#### AUTO 


```{c}
auto pluginResult = KPluginFactory::instantiatePlugin<Plugin>(data, parent);
```

#### AUTO 


```{c}
auto pluginResult = KPluginFactory::instantiatePlugin<KonqSidebarPlugin>(KPluginMetaData(libName), parent);
```

#### AUTO 


```{c}
auto internalCallback = [this, url, fillform, ignorepasswd, callback](const QVariant &result){
        WebFormList res = parseFormData(result, url, fillform, ignorepasswd);
        callback(res);
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &html){emit htmlRetrieved(html);}
```

#### AUTO 


```{c}
auto p = std::remove_if(fields.begin(), fields.end(), [](const WebField &f){return !f.isAutoFillable();});
```

#### LAMBDA EXPRESSION 


```{c}
[](const WebForm &f){return f.hasAutoFillableFields();}
```

#### AUTO 


```{c}
const auto rcfiles = QDir(dir).entryList(QStringList(QStringLiteral("*.rc")));
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString& html) {
            QTemporaryFile tempFile;
            tempFile.setFileTemplate(tempFile.fileTemplate() + QL1S(".html"));
            tempFile.setAutoRemove(false);
            if (tempFile.open()) {
                tempFile.write(html.toUtf8());
                KRun::runUrl(QUrl::fromLocalFile(tempFile.fileName()), QL1S("text/plain"), view(), true, false);
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[callback, url](const QVariant &jsForms) {
        WebFormList forms = parseFormDetectionResult(jsForms, url);
        callback(forms);
    }
```

#### AUTO 


```{c}
auto it = std::find_if(m_certificates.begin(), m_certificates.end(), findNext);
```

#### LAMBDA EXPRESSION 


```{c}
[this]{slotLaunchWalletManager();}
```

#### AUTO 


```{c}
const auto icon = QIcon::fromTheme(QLatin1String(m_pageSecurity == KonqMainWindow::Encrypted ? "security-high" : "security-medium"));
```

#### LAMBDA EXPRESSION 


```{c}
[&pluginId](QObject *p) {
        Plugin *plugin = qobject_cast<Plugin *>(p);
        return (plugin && plugin->d->m_pluginId == pluginId);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[]() { new KonqMainWindow(QUrl(QStringLiteral("about:blank"))); }
```

#### AUTO 


```{c}
auto addAction = [this, menu](const QString &name) {
        QAction *a = actionCollection()->action(name);
        if (a->isEnabled()) {
            menu->addAction(a);
        }
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                slotPopupNewDir();
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                slotOpenShareFileDialog();
            }
```

#### LAMBDA EXPRESSION 


```{c}
[dlg](const std::pair<QObject*, QObject*>& pair){return pair.second == dlg;}
```

#### AUTO 


```{c}
auto printPreview = [this](QPrinter *p){
        QEventLoop loop;
        auto preview = [&](bool) {loop.quit();};
        m_view->page()->print(p, preview);
        loop.exec();
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QVariant &value) {
        const QString text = value.toString();
        if (!text.isEmpty()) {
            view()->page()->runJavaScript(QL1S("this.selectionStart + ' ' + this.selectionEnd"), [this, text](const QVariant &value) {
                const QString values = value.toString();
                const int pos = values.indexOf(' ');
                m_spellTextSelectionStart = qMax(0, values.left(pos).toInt());
                m_spellTextSelectionEnd = qMax(0, values.mid(pos + 1).toInt());
                // kDebug() << "selection start:" << m_spellTextSelectionStart << "end:" << m_spellTextSelectionEnd;

                Sonnet::BackgroundChecker *backgroundSpellCheck = new Sonnet::BackgroundChecker;
                Sonnet::Dialog* spellDialog = new Sonnet::Dialog(backgroundSpellCheck, view());
                backgroundSpellCheck->setParent(spellDialog);
                spellDialog->setAttribute(Qt::WA_DeleteOnClose, true);
                spellDialog->showSpellCheckCompletionMessage(true);
                connect(spellDialog, SIGNAL(replace(QString,int,QString)), this, SLOT(spellCheckerCorrected(QString,int,QString)));
                connect(spellDialog, SIGNAL(misspelling(QString,int)), this, SLOT(spellCheckerMisspelling(QString,int)));
                connect(spellDialog, SIGNAL(done(QString)), this, SLOT(slotSpellCheckDone(QString)));
                spellDialog->setBuffer(text.mid(m_spellTextSelectionStart, (m_spellTextSelectionEnd - m_spellTextSelectionStart)));
                spellDialog->show();
            });
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            slotPopupProperties();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, it](){blobDownloadedToFile(it);}
```

#### LAMBDA EXPRESSION 


```{c}
[](const WebForm &form){return form.toSettingsInfo();}
```

#### LAMBDA EXPRESSION 


```{c}
[](const QNetworkCookie &c1, const QNetworkCookie &c2){
        return c1.name() < c2.name();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (TreeMapItem *item : selectedItems) {
        Inode *inode = static_cast<Inode *>(item);
        const QUrl u = QUrl::fromLocalFile(inode->path());

        canCopy++;
        if (KProtocolManager::supportsDeleting(u)) {
            canDel++;
        }
        if (KProtocolManager::supportsMoving(u)) {
            canMove++;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[page, this](const QUrl& url) {
        if (WebEngineSettings::self()->favIconsEnabled()
            && !page->profile()->isOffTheRecord()){
                m_browserExtension->setIconUrl(url);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { done(QDialogButtonBox::No); }
```

#### LAMBDA EXPRESSION 


```{c}
[form](const WebEngineSettings::WebFormInfo &info){return info.name == form.name && info.framePath == form.framePath;}
```

#### AUTO 


```{c}
auto view = frame->childView()
```

#### AUTO 


```{c}
auto unsetInspectedPageIfNeeded = [this](bool ok) {
        if (ok && inspectedPage() && url().scheme() != QLatin1String("devtools")) {
            setInspectedPage(nullptr);
        }
    };
```

#### AUTO 


```{c}
const auto jsonPlugins = KPluginLoader::findPlugins(QStringLiteral("kf5/kfileitemaction"), [=](const KPluginMetaData& metaData) {
        if (!metaData.serviceTypes().contains(QStringLiteral("KFileItemAction/Plugin"))) {
            return false;
        }

        auto mimeType = QMimeDatabase().mimeTypeForName(commonMimeType);
        foreach (const auto &supportedMimeType, metaData.mimeTypes()) {
            if (mimeType.inherits(supportedMimeType)) {
                return true;
            }
        }

        return false;
    });
```

#### RANGE FOR STATEMENT 


```{c}
for (const QFileInfo &fi : entries)		// second pass, write out entries
        {
            if (fi.isFile())
            {
                qCDebug(WEBARCHIVERPLUGIN_LOG) << "  adding file" << fi.absoluteFilePath();
                archive->addLocalFile(fi.absoluteFilePath(), fi.fileName());
            }
            else if (fi.isDir())
            {
                qCDebug(WEBARCHIVERPLUGIN_LOG) << "  adding dir" << fi.absoluteFilePath();
                archive->addLocalDirectory(fi.absoluteFilePath(), fi.fileName());
            }
            else qCDebug(WEBARCHIVERPLUGIN_LOG) << "unrecognised entry type for" << fi.fileName();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, bar](){deleteFeaturePermissionBar(bar);}
```

#### AUTO 


```{c}
auto *job = new KTerminalLauncherJob(QString{});
```

#### LAMBDA EXPRESSION 


```{c}
[it](const WebForm::WebField &f){return (*it).fields.contains(f.name);}
```

#### AUTO 


```{c}
auto it = std::find_if(m_dialogs.constKeyValueBegin(), m_dialogs.constKeyValueEnd(), findItemForDialog);
```

#### LAMBDA EXPRESSION 


```{c}
[this, lang](bool on){on ? addLanguage(lang) : removeLanguage(lang);}
```

#### LAMBDA EXPRESSION 


```{c}
[host, action]() {
                action->setIcon(KonqPixmapProvider::self()->iconForUrl(host));
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (KonqMainWindow *win : *mainWindowList) {
            if (win->isPreloaded()) {
                qCDebug(KONQUEROR_LOG) << "Reusing preloaded window" << win;
                KStartupInfo::setWindowStartupId(win->winId(), KStartupInfo::startupId());
                ensurePreloadedWindow();
                return win;
            }
        }
```

#### AUTO 


```{c}
auto buttonInfoHandleURL = [&] () {
        buttonInfo.dock->show();
        m_area->show();
        openUrl(m_storedCurViewUrl); // also runs the buttonInfo.module->openUrl()
        m_visibleViews << buttonInfo.file;
        m_latestViewed = page;
    };
```

#### AUTO 


```{c}
auto fieldChanged = [&storedValues](const WebForm::WebField field){
                        return storedValues.contains(field.name) && storedValues.value(field.name) != field.value;
                    };
```

#### LAMBDA EXPRESSION 


```{c}
[this, text](const QVariant &value) {
                const QString values = value.toString();
                const int pos = values.indexOf(' ');
                m_spellTextSelectionStart = qMax(0, values.left(pos).toInt());
                m_spellTextSelectionEnd = qMax(0, values.mid(pos + 1).toInt());
                // kDebug() << "selection start:" << m_spellTextSelectionStart << "end:" << m_spellTextSelectionEnd;

                Sonnet::BackgroundChecker *backgroundSpellCheck = new Sonnet::BackgroundChecker;
                Sonnet::Dialog* spellDialog = new Sonnet::Dialog(backgroundSpellCheck, view());
                backgroundSpellCheck->setParent(spellDialog);
                spellDialog->setAttribute(Qt::WA_DeleteOnClose, true);
                spellDialog->showSpellCheckCompletionMessage(true);
                connect(spellDialog, SIGNAL(replace(QString,int,QString)), this, SLOT(spellCheckerCorrected(QString,int,QString)));
                connect(spellDialog, SIGNAL(misspelling(QString,int)), this, SLOT(spellCheckerMisspelling(QString,int)));
                connect(spellDialog, SIGNAL(done(QString)), this, SLOT(slotSpellCheckDone(QString)));
                spellDialog->setBuffer(text.mid(m_spellTextSelectionStart, (m_spellTextSelectionEnd - m_spellTextSelectionStart)));
                spellDialog->show();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (QToolButton *atb : toolbuttons) {
        if (atb->defaultAction() == clearAction) {
            enable = false;
            break;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString& html) {
            QTemporaryFile tempFile;
            tempFile.setFileTemplate(tempFile.fileTemplate() + QL1S(".html"));
            tempFile.setAutoRemove(false);
            if (tempFile.open()) {
                tempFile.write(html.toUtf8());
                tempFile.close();
                KIO::OpenUrlJob *job = new KIO::OpenUrlJob(QUrl::fromLocalFile(tempFile.fileName()), QL1S("text/plain"));
                job->setUiDelegate(new KIO::JobUiDelegate(KJobUiDelegate::AutoHandlingEnabled, view()));
                job->setDeleteTemporaryFile(true);
                job->start();
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *a : actions) {
            a->setChecked(false);
        }
```

#### AUTO 


```{c}
auto preview = [&](bool) {loop.quit();};
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &item : items) {
        if (!item.isEmpty()) {   // only insert non-empty items
            insertItem(KonqPixmapProvider::self()->pixmapFor(item, KIconLoader::SizeSmall),
                       item, i++, titleOfURL(item));
        }
    }
```

#### AUTO 


```{c}
auto sortLambda = [](const QNetworkCookie &c1, const QNetworkCookie &c2){
        return c1.name() < c2.name();
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this]{if (page() && m_wallet){m_wallet->savePageDataNow(page());}}
```

#### LAMBDA EXPRESSION 


```{c}
[&storedValues](const WebForm::WebField field){
                        return storedValues.contains(field.name) && storedValues.value(field.name) != field.value;
                    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const WebForm &f){return f.hasPasswords();}
```

#### AUTO 


```{c}
auto it = dicts.constBegin();
```

#### LAMBDA EXPRESSION 


```{c}
[this,page](const QString &iconName)
                    { m_buttonBar->tab(page)->setIcon(QIcon::fromTheme(iconName)); }
```

#### AUTO 


```{c}
auto addPluginForId = [this](const QString &pluginId) {
        QVector<KPluginMetaData> metaDataList = KPluginMetaData::findPlugins(pluginId + QStringLiteral("/kpartplugins"));
        d->pluginSelector->addPlugins(metaDataList, i18n("Extensions"));
    };
```

#### AUTO 


```{c}
auto addPluginForId = [this](const QString &pluginId) {
        const QStringList searchPaths =
            QStandardPaths::locateAll(QStandardPaths::GenericDataLocation, pluginId + QStringLiteral("/kpartplugins"), QStandardPaths::LocateDirectory);
        const QStringList files = KFileUtils::findAllUniqueFiles(searchPaths, {QStringLiteral("*.desktop")});
        QVector<KPluginMetaData> metaDataList;
        metaDataList.reserve(files.count());
        for (const QString &file : files) {
            metaDataList << KPluginMetaData::fromDesktopFile(file);
        }
        d->pluginSelector->setConfig(KSharedConfig::openConfig(pluginId + QLatin1String("rc"))->group("KParts Plugins"));
        d->pluginSelector->addPlugins(metaDataList, i18n("Extensions"));
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this, job](){done(job);}
```

#### LAMBDA EXPRESSION 


```{c}
[&library](QObject *p) {
        Plugin *plugin = qobject_cast<Plugin *>(p);
        return (plugin && plugin->d->m_library == library);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString &prot : protocols){
            if (KProtocolInfo::defaultMimetype(prot) == "text/html") {
                localSchemes.append(QByteArray(prot.toLatin1()));
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool ok){if (ok){m_wallet->detectAndFillPageForms(this);}}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : files) {
            KDesktopFile df(dir.absoluteFilePath(file)); // no merging. KService warns, and we don't need it.
            services.append(KService::Ptr(new KService(&df)));
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, job](KJob *) {
            if (!job->error()) {
                loadFavicon();
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->aboutToShow(); }
```

#### AUTO 


```{c}
auto callback = [this, key, url](const WebFormList &list){saveFormDataCallback(key, url, list);};
```

#### AUTO 


```{c}
auto callback = [this](const QVariant &res) {
        bool hasRefresh = res.toBool();
#if KPARTS_VERSION < QT_VERSION_CHECK(5, 81, 0)
        emit completed(hasRefresh);
#else
        emit hasRefresh ? completedWithPendingAction() : completed();
#endif
    };
```

#### AUTO 


```{c}
auto callback = [this](const QString &html){emit finished(html);};
```

#### LAMBDA EXPRESSION 


```{c}
[&ev,&str](const QString& data) {
            str = data;
            ev.quit();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString& text) {
            qDebug() << "HTML: " << text;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QVariant &e : elements) {
           QVariantMap elementMap(e.toMap());
           WebForm::WebField field;
           field.type = WebForm::fieldTypeFromTypeName(elementMap[QL1S("type")].toString().toLower());
           if (field.type == WebForm::WebFieldType::Other) {
               continue;
           }
           field.name = elementMap[QL1S("name")].toString();
           if (shouldFieldBeIgnored(field.name)) {
               continue;
           }

           field.id = elementMap[QL1S("id")].toString();
           field.readOnly = elementMap[QL1S("readonly")].toBool();
           field.disabled = elementMap[QL1S("disabled")].toBool();
           field.autocompleteAllowed = elementMap[QL1S("autocompleteAllowed")].toBool();
           field.value = elementMap[QL1S("value")].toString();
           field.label = elementMap[QL1S("label")].toString();
           form.fields.append(field);
        }
```

#### AUTO 


```{c}
auto callback = [this, url, page](const WebFormList &forms) {
        if (!WebEngineSettings::self()->isNonPasswordStorableSite(url.host())) {
            fillFormData(page, cacheableForms(url, forms, CacheOperation::Fill));
        }
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QVariant &value) {
        const QString text = value.toString();
        if (!text.isEmpty()) {
            m_spellTextSelectionStart = 0;
            m_spellTextSelectionEnd = 0;

            Sonnet::BackgroundChecker *backgroundSpellCheck = new Sonnet::BackgroundChecker;
            Sonnet::Dialog* spellDialog = new Sonnet::Dialog(backgroundSpellCheck, view());
            backgroundSpellCheck->setParent(spellDialog);
            spellDialog->setAttribute(Qt::WA_DeleteOnClose, true);
            spellDialog->showSpellCheckCompletionMessage(true);
            connect(spellDialog, &Sonnet::Dialog::replace, this, &WebEngineBrowserExtension::spellCheckerCorrected);
            connect(spellDialog, &Sonnet::Dialog::misspelling, this, &WebEngineBrowserExtension::spellCheckerMisspelling);
            spellDialog->setBuffer(text);
            spellDialog->show();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVariant &v : variantForms) {
        QJsonObject formMap = QJsonDocument::fromJson(v.toString().toUtf8()).object();
        WebEngineWallet::WebForm form;
        form.url = urlForFrame(QUrl(formMap[QL1S("url")].toString()), pageUrl);
        form.name = formMap[QL1S("name")].toString();
        form.index = formMap[QL1S("index")].toString();
        form.framePath = QVariant(formMap[QL1S("framePath")].toArray().toVariantList()).toStringList().join(",");
        const QVariantList elements = formMap[QL1S("elements")].toArray().toVariantList();
        for(const QVariant &e : elements) {
           QVariantMap elementMap(e.toMap());
           WebForm::WebField field;
           field.type = WebForm::fieldTypeFromTypeName(elementMap[QL1S("type")].toString().toLower());
           if (field.type == WebForm::WebFieldType::Other) {
               continue;
           }
           field.id = elementMap[QL1S("id")].toString();
           field.name = elementMap[QL1S("name")].toString();
           field.readOnly = elementMap[QL1S("readonly")].toBool();
           field.disabled = elementMap[QL1S("disabled")].toBool();
           field.autocompleteAllowed = elementMap[QL1S("autocompleteAllowed")].toBool();
           field.value = elementMap[QL1S("value")].toString();
           field.label = elementMap[QL1S("label")].toString();
           form.fields.append(field);
        }
        if (!form.fields.isEmpty()) {
            list.append(form);
        }
    }
```

#### AUTO 


```{c}
auto buttonInfoHandleURL = [&] () {
        buttonInfo.dock->show();
        m_area->show();
        openUrl(m_storedCurViewUrl); // also runs the buttonInfo.module->openUrl()
        m_visibleViews << buttonInfo.file;
        m_latestViewed = page;
        m_moduleManager.saveOpenViews(m_visibleViews); // TODO: this would be best stored per-window, in the session file
    };
```

#### AUTO 


```{c}
auto it = std::find_if(customForms.constBegin(), customForms.constEnd(), sameForm);
```

#### LAMBDA EXPRESSION 


```{c}
[](const WebField &f){return !f.isAutoFillable();}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : files) {
            metaDataList << KPluginMetaData::fromDesktopFile(file);
        }
```

#### AUTO 


```{c}
auto job = new KIO::CommandLauncherJob(QStringLiteral("kcmshell5"), {QStringLiteral("webshortcuts")});
```

#### RANGE FOR STATEMENT 


```{c}
for (const CookieData &c: cookies) {
        QDBusMessage deleteRep = m_server->call(QDBus::Block, "deleteCookie", c.domain, c.host, c.path, c.name);
        if (m_server->lastError().isValid()) {
            qDebug() << m_server->lastError().message();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QWebEngineCookieStore::FilterRequest &req){return filterCookie(req);}
```

#### AUTO 


```{c}
auto host = bm.url().adjusted(QUrl::RemovePath | QUrl::RemoveQuery);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &pluginInfo : pluginInfos) {
        const QString library = pluginInfo.m_document.documentElement().attribute(QStringLiteral("library"));

        if (library.isEmpty() || hasPlugin(parent, library)) {
            continue;
        }

        Plugin *plugin = loadPlugin(parent, library, pluginInfo.m_document.documentElement().attribute(QStringLiteral("X-KDE-PluginKeyword")));

        if (plugin) {
            plugin->d->m_parentInstance = componentName;
            plugin->setXMLFile(pluginInfo.m_relXMLFileName, false, false);
            plugin->setDOMDocument(pluginInfo.m_document);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](){ slotChanged(); }
```

#### AUTO 


```{c}
auto callback = [this, url, page](const WebFormList &forms) {
        emit formDetectionDone(url, !forms.isEmpty(), d->hasAutoFillableFields(forms));
        if (!WebEngineSettings::self()->isNonPasswordStorableSite(url.host())) {
            fillFormData(page, cacheableForms(url, forms, CacheOperation::Fill));
        }
    };
```

#### AUTO 


```{c}
auto callback = [this, url, page, widget](const WebFormList &forms){
        WebEngineSettings::WebFormInfoList oldSettings = WebEngineSettings::self()->customizedCacheableFieldsForPage(customFormsKey(url));
        QMap<QString, QStringList> oldSettingsMap;
        for (const WebEngineSettings::WebFormInfo &info : oldSettings) {
            oldSettingsMap.insert(info.name, info.fields);
        }
        WebEngineCustomizeCacheableFieldsDlg dlg(forms, oldSettingsMap, widget);
        if (dlg.exec() == QDialog::Rejected) {
            return;
        }
        WebFormList selected = dlg.selectedFields();
        if (selected.isEmpty()) {
            return;
        }
        WebEngineSettings::WebFormInfoList vec;
        vec.reserve(selected.size());
        std::transform(selected.constBegin(), selected.constEnd(), std::back_inserter(vec), [](const WebForm &form){return form.toSettingsInfo();});
        WebEngineSettings::self()->setCustomizedCacheableFieldsForPage(customFormsKey(url), vec);
        if (dlg.immediatelyCacheData()) {
            //Pass only the selected fields to saveFormData instead of all the forms in the page, since
            //we already know they're the ones to be cached.
            saveFormData(page, selected, true);
            emit fillFormRequestCompleted(true);
        }
    };
```

#### AUTO 


```{c}
auto findService = [webEngineName](KService::Ptr s){return s->desktopEntryName() != webEngineName;};
```

#### AUTO 


```{c}
auto it = preferred.constBegin();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { done(QDialogButtonBox::Yes); }
```

#### LAMBDA EXPRESSION 


```{c}
[data, start](CookieDetails field){return data.at(start + static_cast<int>(field));}
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QVariant &value) {
        const QString text = value.toString();
        if (!text.isEmpty()) {
            view()->page()->runJavaScript(QL1S("this.selectionStart + ' ' + this.selectionEnd"), [this, text](const QVariant &value) {
                const QString values = value.toString();
                const int pos = values.indexOf(' ');
                m_spellTextSelectionStart = qMax(0, values.leftRef(pos).toInt());
                m_spellTextSelectionEnd = qMax(0, values.midRef(pos + 1).toInt());
                // qCDebug(WEBENGINEPART_LOG) << "selection start:" << m_spellTextSelectionStart << "end:" << m_spellTextSelectionEnd;

                Sonnet::BackgroundChecker *backgroundSpellCheck = new Sonnet::BackgroundChecker;
                Sonnet::Dialog* spellDialog = new Sonnet::Dialog(backgroundSpellCheck, view());
                backgroundSpellCheck->setParent(spellDialog);
                spellDialog->setAttribute(Qt::WA_DeleteOnClose, true);
                spellDialog->showSpellCheckCompletionMessage(true);
                connect(spellDialog, &Sonnet::Dialog::replace, this, &WebEngineBrowserExtension::spellCheckerCorrected);
                connect(spellDialog, &Sonnet::Dialog::misspelling, this, &WebEngineBrowserExtension::spellCheckerMisspelling);
                connect(spellDialog, &Sonnet::Dialog::spellCheckDone, this, &WebEngineBrowserExtension::slotSpellCheckDone);
                spellDialog->setBuffer(text.mid(m_spellTextSelectionStart, (m_spellTextSelectionEnd - m_spellTextSelectionStart)));
                spellDialog->show();
            });
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &item : lstItems) {
        const QUrl url = item.url();
        lstUrls.append(url);
        if (!bTrashIncluded && ((url.scheme() == QLatin1String("trash") && url.path().length() <= 1))) {
            bTrashIncluded = true;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &fileName : modules()) {
        const QString path = moduleDataPath(fileName);
        if (! QStandardPaths::locate(QStandardPaths::GenericDataLocation, path).isEmpty()) {
            KSharedConfig::Ptr config = KSharedConfig::openConfig(path,
                                        KConfig::NoGlobals,
                                        QStandardPaths::GenericDataLocation);
            KConfigGroup configGroup(config, "Desktop Entry");
            const int weight = configGroup.readEntry("X-KDE-Weight", 0);
            if (curMax < weight) {
                curMax = weight;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &name : qAsConst(localSchemes)){
            QWebEngineUrlScheme scheme(name);
            scheme.setFlags(QWebEngineUrlScheme::LocalScheme|QWebEngineUrlScheme::LocalAccessAllowed);
            scheme.setSyntax(QWebEngineUrlScheme::Syntax::Path);
            QWebEngineUrlScheme::registerScheme(scheme);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QVariant &value) {
        const QString text = value.toString();
        if (!text.isEmpty()) {
            view()->page()->runJavaScript(QL1S("this.selectionStart + ' ' + this.selectionEnd"), [this, text](const QVariant &value) {
                const QString values = value.toString();
                const int pos = values.indexOf(' ');
                m_spellTextSelectionStart = qMax(0, values.leftRef(pos).toInt());
                m_spellTextSelectionEnd = qMax(0, values.midRef(pos + 1).toInt());
                // kDebug() << "selection start:" << m_spellTextSelectionStart << "end:" << m_spellTextSelectionEnd;

                Sonnet::BackgroundChecker *backgroundSpellCheck = new Sonnet::BackgroundChecker;
                Sonnet::Dialog* spellDialog = new Sonnet::Dialog(backgroundSpellCheck, view());
                backgroundSpellCheck->setParent(spellDialog);
                spellDialog->setAttribute(Qt::WA_DeleteOnClose, true);
                spellDialog->showSpellCheckCompletionMessage(true);
                connect(spellDialog, SIGNAL(replace(QString,int,QString)), this, SLOT(spellCheckerCorrected(QString,int,QString)));
                connect(spellDialog, SIGNAL(misspelling(QString,int)), this, SLOT(spellCheckerMisspelling(QString,int)));
                connect(spellDialog, SIGNAL(done(QString)), this, SLOT(slotSpellCheckDone(QString)));
                spellDialog->setBuffer(text.mid(m_spellTextSelectionStart, (m_spellTextSelectionEnd - m_spellTextSelectionStart)));
                spellDialog->show();
            });
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[page, this](const QUrl& url) {
        if (WebEngineSettings::self()->favIconsEnabled()
            && !page->profile()->isOffTheRecord()){
                emit m_browserExtension->setIconUrl(url);
        }
    }
```

#### AUTO 


```{c}
auto job = new KIO::ApplicationLauncherJob(helpCenter);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            slotPopupRestoreTrashedItems();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[host, action]() {
                        action->setIcon(KonqPixmapProvider::self()->iconForUrl(host));
                    }
```

#### LAMBDA EXPRESSION 


```{c}
[job, this](KJob *){
        bool modified = false;
        const QUrl _hostUrl = job->property("_hostUrl").value<QUrl>();
        QMap<QUrl,QString>::iterator itEnd = iconMap.end();
        for (QMap<QUrl,QString>::iterator it = iconMap.begin(); it != itEnd; ++it) {
            const QUrl url(it.key());
            if (url.host() == _hostUrl.host()) {
                // For host default-icons still query the favicon manager to get
                // the correct icon for pages that have an own one.
                const QString icon = KIO::favIconForUrl(url);
                if (!icon.isEmpty()) {
                    *it = icon;
                    modified = true;
                }
            }
        }
        if (modified) {
            emit changed();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const WebField &f){return f.isAutoFillable();}
```

#### RANGE FOR STATEMENT 


```{c}
for (const CookieWithUrl& cookieWithUrl : cookies){
        QNetworkCookie cookie = cookieWithUrl.cookie;
        QDateTime currentTime = QDateTime::currentDateTime();
        //Don't attempt to add expired cookies
        if (cookie.expirationDate().isValid() && cookie.expirationDate() < currentTime) {
            continue;
        }
        QNetworkCookie normalizedCookie(cookie);
        normalizedCookie.normalize(cookieWithUrl.url);
        m_cookiesLoadedFromKCookieServer << cookie;
#ifdef BUILD_TESTING
        m_testCookies << cookie;
#endif
        m_cookieStore->setCookie(cookie, cookieWithUrl.url);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &pluginId) {
        QVector<KPluginMetaData> metaDataList = KPluginMetaData::findPlugins(pluginId + QStringLiteral("/kpartplugins"));
        d->pluginSelector->setConfig(KSharedConfig::openConfig(pluginId + QLatin1String("rc"))->group("KParts Plugins"));
        d->pluginSelector->addPlugins(metaDataList, i18n("Extensions"));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KonqMainWindow *window : *mainWindows) {
            if (!window->isPreloaded()) {
                for (KonqView *view : window->viewMap()) {
                    lst.append(view->url().toString());
                }
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { setResult(QDialogButtonBox::No); accept(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            slotPopupAddToBookmark();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &data : metaDataList) {
        PluginInfo info;
        info.m_metaData = data;
        QString doc;
        const QString fullComponentName = QStringLiteral("konqueror/partsrcfiles/") + QFileInfo(data.fileName()).baseName();
        const auto files = QStandardPaths::locateAll(QStandardPaths::GenericDataLocation, fullComponentName + QLatin1String(".rc"));
        info.m_absXMLFileName = KXMLGUIClient::findMostRecentXMLFile(files, doc);
        doc = KXMLGUIFactory::readConfigFile(info.m_absXMLFileName);
        if (info.m_absXMLFileName.isEmpty()) {
            continue;
        }

        info.m_document.setContent(doc);
        if (info.m_document.documentElement().isNull()) {
            continue;
        }

        const QString tryExec = data.value(QStringLiteral("TryExec"));
        if (!tryExec.isEmpty() && QStandardPaths::findExecutable(tryExec).isEmpty()) {
            continue;
        }

        plugins.append(info);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& url : urls) {
        query.addQueryItem("attachment", url);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto queryItem : items) {
        if (queryItem.first.contains(QL1C('@')) && queryItem.second.isEmpty()) {
            // ### DF: this hack breaks mailto:faure@kde.org, kmail doesn't expect mailto:?to=faure@kde.org
            queryItem.second = queryItem.first;
            queryItem.first = QStringLiteral("to");
        } else if (QString::compare(queryItem.first, QL1S("attach"), Qt::CaseInsensitive) == 0) {
            files << queryItem.second;
            continue;
        }
        sanitizedQuery.addQueryItem(queryItem.first, queryItem.second);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&] () {
        buttonInfo.dock->show();
        m_area->show();
        openUrl(m_storedCurViewUrl); // also runs the buttonInfo.module->openUrl()
        m_visibleViews << buttonInfo.file;
        m_latestViewed = page;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &html){emit finished(html);}
```

#### AUTO 


```{c}
auto job = new KIO::ApplicationLauncherJob(kwalletManager);
```

#### LAMBDA EXPRESSION 


```{c}
[](){ qApp->exit(1); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &name : entries)		// first pass, check file names
        {
            if (name.contains(rx))			// matches "anythingelse.html"
            {						// but not "index.html"
                if (!indexHtml.isEmpty())		// already have found something
                {
                    qCDebug(WEBARCHIVERPLUGIN_LOG) << "multiple HTML files at top level";
                    indexHtml.clear();			// forget trying to rename
                    break;
                }

                qCDebug(WEBARCHIVERPLUGIN_LOG) << "identified index file" << name;
                indexHtml = name;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &pluginInfo : plugins) {
        QDomElement docElem = pluginInfo.m_document.documentElement();

        bool pluginEnabled = pluginInfo.m_metaData.isEnabled(cfgGroup);
        // search through already present plugins
        const QObjectList pluginList = parent->children();

        bool pluginFound = false;
        for (auto *p : pluginList) {
            Plugin *plugin = qobject_cast<Plugin *>(p);
            if (plugin && plugin->d->m_pluginId == pluginInfo.m_metaData.pluginId()) {
                // delete and unload disabled plugins
                if (!pluginEnabled) {
                    // qDebug() << "remove plugin " << name;
                    KXMLGUIFactory *factory = plugin->factory();
                    if (factory) {
                        factory->removeClient(plugin);
                    }
                    delete plugin;
                }

                pluginFound = true;
                break;
            }
        }

        // if the plugin is already loaded or if it's disabled in the
        // configuration do nothing
        if (pluginFound || !pluginEnabled) {
            continue;
        }

        // qDebug() << "load plugin " << name << " " << library << " " << keyword;
        Plugin *plugin = loadPlugin(parent, pluginInfo.m_metaData);

        if (plugin) {
            plugin->d->m_parentInstance = componentName;
            plugin->setXMLFile(pluginInfo.m_absXMLFileName, false, false);
            plugin->setDOMDocument(pluginInfo.m_document);
            parentGUIClient->insertChildClient(plugin);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            slotPopupEmptyTrashBin();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, url, page, widget](const WebFormList &forms){
        WebEngineSettings::WebFormInfoList oldSettings = WebEngineSettings::self()->customizedCacheableFieldsForPage(customFormsKey(url));
        QMap<QString, QStringList> oldSettingsMap;
        for (const WebEngineSettings::WebFormInfo &info : oldSettings) {
            oldSettingsMap.insert(info.name, info.fields);
        }
        WebEngineCustomizeCacheableFieldsDlg dlg(forms, oldSettingsMap, widget);
        if (dlg.exec() == QDialog::Rejected) {
            return;
        }
        WebFormList selected = dlg.selectedFields();
        if (selected.isEmpty()) {
            return;
        }
        WebEngineSettings::WebFormInfoList vec;
        vec.reserve(selected.size());
        std::transform(selected.constBegin(), selected.constEnd(), std::back_inserter(vec), [](const WebForm &form){return form.toSettingsInfo();});
        WebEngineSettings::self()->setCustomizedCacheableFieldsForPage(customFormsKey(url), vec);
        if (dlg.immediatelyCacheData()) {
            //Pass only the selected fields to saveFormData instead of all the forms in the page, since
            //we already know they're the ones to be cached.
            saveFormData(page, selected, true);
            emit fillFormRequestCompleted(true);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QVariant &res) {
        bool hasRefresh = res.toBool();
#if KPARTS_VERSION < QT_VERSION_CHECK(5, 81, 0)
        emit completed(hasRefresh);
#else
        emit hasRefresh ? completedWithPendingAction() : completed();
#endif
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVariant &v : variantForms) {
        QJsonObject formMap = QJsonDocument::fromJson(v.toString().toUtf8()).object();
        WebEngineWallet::WebForm form;
        form.url = urlForFrame(QUrl(formMap[QL1S("url")].toString()), pageUrl);
        form.name = formMap[QL1S("name")].toString();
        form.index = formMap[QL1S("index")].toString();
        form.framePath = QVariant(formMap[QL1S("framePath")].toArray().toVariantList()).toStringList().join(",");
        const QVariantList elements = formMap[QL1S("elements")].toArray().toVariantList();
        for(const QVariant &e : elements) {
           QVariantMap elementMap(e.toMap());
           WebForm::WebField field;
           field.type = WebForm::fieldTypeFromTypeName(elementMap[QL1S("type")].toString().toLower());
           if (field.type == WebForm::WebFieldType::Other) {
               continue;
           }
           field.name = elementMap[QL1S("name")].toString();
           if (shouldFieldBeIgnored(field.name)) {
               continue;
           }

           field.id = elementMap[QL1S("id")].toString();
           field.readOnly = elementMap[QL1S("readonly")].toBool();
           field.disabled = elementMap[QL1S("disabled")].toBool();
           field.autocompleteAllowed = elementMap[QL1S("autocompleteAllowed")].toBool();
           field.value = elementMap[QL1S("value")].toString();
           field.label = elementMap[QL1S("label")].toString();
           form.fields.append(field);
        }
        if (!form.fields.isEmpty()) {
            list.append(form);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&] () {
        buttonInfo.dock->show();
        m_area->show();
        openUrl(m_storedCurViewUrl); // also runs the buttonInfo.module->openUrl()
        m_visibleViews << buttonInfo.file;
        m_latestViewed = page;
        m_moduleManager.saveOpenViews(m_visibleViews); // TODO: this would be best stored per-window, in the session file
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const WebField &f){return !f.readOnly && !f.value.isEmpty();}
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool ok) {
        if (ok && inspectedPage() && url().scheme() != QLatin1String("devtools")) {
            setInspectedPage(nullptr);
        }
    }
```

#### AUTO 


```{c}
auto factoryResult = KPluginFactory::loadFactory(KPluginInfo(service).toMetaData())
```

#### LAMBDA EXPRESSION 


```{c}
[this, it, page](){blobDownloadedToFile(it, page);}
```

#### LAMBDA EXPRESSION 


```{c}
[](const WebField &f){return f.type == WebFieldType::Password;}
```

#### LAMBDA EXPRESSION 


```{c}
[](const WebEngineWallet::WebForm::WebField &f){return f.name;}
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &f){return f.chopped(5);}
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            KToolInvocation::invokeTerminal(QString(),  m_popupItemProperties.urlList().constFirst().toLocalFile());
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) {
                if (job->error()) {
                    qApp->exit(1);
                } else {
                    ClientApp::delayedQuit();
                }
            }
```

#### AUTO 


```{c}
const auto files = QStandardPaths::locateAll(QStandardPaths::GenericDataLocation, fullComponentName + QLatin1String(".rc"));
```

#### RANGE FOR STATEMENT 


```{c}
for(auto queryItem : items) {
        if (queryItem.first.contains(QL1C('@')) && queryItem.second.isEmpty()) {
            // ### DF: this hack breaks mailto:faure@kde.org, kmail doesn't expect mailto:?to=faure@kde.org
            queryItem.second = queryItem.first;
            queryItem.first = "to";
        } else if (QString::compare(queryItem.first, QL1S("attach"), Qt::CaseInsensitive) == 0) {
            files << queryItem.second;
            continue;
        }
        sanitizedQuery.addQueryItem(queryItem.first, queryItem.second);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString& text) {
            kDebug() << "HTML: " << text;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, text](const QVariant &value) {
                const QString values = value.toString();
                const int pos = values.indexOf(' ');
                m_spellTextSelectionStart = qMax(0, values.leftRef(pos).toInt());
                m_spellTextSelectionEnd = qMax(0, values.midRef(pos + 1).toInt());
                // kDebug() << "selection start:" << m_spellTextSelectionStart << "end:" << m_spellTextSelectionEnd;

                Sonnet::BackgroundChecker *backgroundSpellCheck = new Sonnet::BackgroundChecker;
                Sonnet::Dialog* spellDialog = new Sonnet::Dialog(backgroundSpellCheck, view());
                backgroundSpellCheck->setParent(spellDialog);
                spellDialog->setAttribute(Qt::WA_DeleteOnClose, true);
                spellDialog->showSpellCheckCompletionMessage(true);
                connect(spellDialog, SIGNAL(replace(QString,int,QString)), this, SLOT(spellCheckerCorrected(QString,int,QString)));
                connect(spellDialog, SIGNAL(misspelling(QString,int)), this, SLOT(spellCheckerMisspelling(QString,int)));
                connect(spellDialog, SIGNAL(done(QString)), this, SLOT(slotSpellCheckDone(QString)));
                spellDialog->setBuffer(text.mid(m_spellTextSelectionStart, (m_spellTextSelectionEnd - m_spellTextSelectionStart)));
                spellDialog->show();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *p : pluginList) {
            Plugin *plugin = qobject_cast<Plugin *>(p);
            if (plugin && plugin->d->m_pluginId == pluginInfo.m_metaData.pluginId()) {
                // delete and unload disabled plugins
                if (!pluginEnabled) {
                    // qDebug() << "remove plugin " << name;
                    KXMLGUIFactory *factory = plugin->factory();
                    if (factory) {
                        factory->removeClient(plugin);
                    }
                    delete plugin;
                }

                pluginFound = true;
                break;
            }
        }
```

