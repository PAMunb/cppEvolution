#### AUTO 


```{c}
auto ghost = new GhostItem(p_game->getGhosts()[i]);
```

#### AUTO 


```{c}
auto settingsDialog = new KConfigDialog(this, QStringLiteral("settings"), Settings::self());
```

#### AUTO 


```{c}
const auto remainingTime{m_preyTimer->remainingTime()};
```

#### AUTO 


```{c}
auto element = new ElementItem(m_game->getMaze()->getCell(i, j).getElement());
```

#### RANGE FOR STATEMENT 


```{c}
for (auto* theme : themes) {
        if (theme->identifier() == themeIdentifier) {
            m_themeProvider->setCurrentTheme(theme);
            break;
        }
    }
```

#### AUTO 


```{c}
auto model = (Kapman *)getModel();
```

#### AUTO 


```{c}
const auto remainingTime{m_bonusTimer->remainingTime()};
```

#### AUTO 


```{c}
auto window = new KapmanMainWindow();
```

#### AUTO 


```{c}
auto item = dynamic_cast<ElementItem *>(collidingList[i]);
```

#### AUTO 


```{c}
auto soundAction = new KToggleAction(i18n("&Play Sounds"), this);
```

#### AUTO 


```{c}
auto levelAction = new QAction(i18n("&Change Level"), this);
```

#### AUTO 


```{c}
auto* theme
```

