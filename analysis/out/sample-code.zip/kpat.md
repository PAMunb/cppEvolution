#### AUTO 


```{c}
const auto moves = solver()->firstMoves();
```

#### CONST EXPRESSION 


```{c}
constexpr auto NNEED = 8;
```

#### RANGE FOR STATEMENT 


```{c}
for (KCard * c : qAsConst(d->cards))
        c->setPile( nullptr );
```

#### RANGE FOR STATEMENT 


```{c}
for (const DealerInfo * i : games) {
        GameSelectionBox * box = new GameSelectionBox( i->baseName(), i->baseId() );
        m_boxes.append( box );
        addItem( box );

        connect( box, &GameSelectionBox::selected, this, &GameSelectionScene::gameSelected );
        connect( box, &GameSelectionBox::hoverChanged, this, &GameSelectionScene::boxHoverChanged );
    }
```

#### AUTO 


```{c}
const auto fc = freecell[i];
```

#### RANGE FOR STATEMENT 


```{c}
for (KCardPile * p : piles)
        p->clear();
```

#### AUTO 


```{c}
const auto items = q->collidingItems(cardsBeingDragged.first(), Qt::IntersectsItemBoundingRect);
```

#### RANGE FOR STATEMENT 


```{c}
for (KCardPile * p1 : qAsConst(visiblePiles)) {
        if ( p1->widthPolicy() == KCardPile::GrowLeft )
        {
            areas[p1].setLeft( 0 );
            for (KCardPile * p2 : qAsConst(visiblePiles)) {
                if ( p2 != p1 && areas[p1].intersects( areas[p2] ) )
                {
                    if ( p2->widthPolicy() == KCardPile::GrowRight )
                        areas[p1].setLeft( (reserve[p1].left() + reserve[p2].right() + spacing) / 2 );
                    else
                        areas[p1].setLeft( reserve[p2].right() + spacing );
                }
            }
        }
    }
```

#### AUTO 


```{c}
auto solver = new SimonSolver( this );
```

#### AUTO 


```{c}
const auto piles = previewString.split(QLatin1Char(';'));
```

#### RANGE FOR STATEMENT 


```{c}
for (DealerInfo * di : games) {
        if ( (wanted_game < 0) ? (di->untranslatedBaseName().toString() == name) : di->providesId( wanted_game ) )
        {
            DealerScene * d = di->createGame();
            Q_ASSERT( d );
            d->setDeck( new KCardDeck( KCardTheme(), d ) );
            d->initialize();

            if ( !d->solver() )
            {
                qCCritical(KPAT_LOG) << "There is no solver for" << di->baseName();
                return nullptr;
            }

            return d;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const PatPile * p : patPiles) {
        xml.writeStartElement( QStringLiteral("pile") );
        xml.writeAttribute( QStringLiteral("index"), QString::number( p->index() ) );
        xml.writeAttribute( QStringLiteral("z"), QString::number( p->zValue() ) );

        const auto cards = p->cards();
        for (const KCard * c : cards) {
            xml.writeStartElement( QStringLiteral("card") );
            xml.writeAttribute( QStringLiteral("suit"), QString::number( c->suit() ) );
            xml.writeAttribute( QStringLiteral("value"), QString::number( c->rank() ) );
            xml.writeAttribute( QStringLiteral("faceup"), QString::number( c->isFaceUp() ) );
            xml.writeAttribute( QStringLiteral("z"), QString::number( c->zValue() ) );
            xml.writeEndElement();
        }
        xml.writeEndElement();
    }
```

#### AUTO 


```{c}
auto from = m->from;
```

#### RANGE FOR STATEMENT 


```{c}
for (KCard * c : cards)
            c->setBackPixmap( pix );
```

#### AUTO 


```{c}
const auto cards = store[column]->cards();
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCardDeck::Suit & s : suits)
                ids << KCardDeck::getId( s, r, number++ );
```

#### AUTO 


```{c}
constexpr auto NNEED = 8;
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCardPile * p : piles) {
        if ( p->layoutPos().x() >= 0 )
            usedWidth = qMax( usedWidth, p->layoutPos().x() + 1 + p->rightPadding() );
        else
            extraWidth = qMax( extraWidth, p->leftPadding() + 1 + p->rightPadding() );

        if ( p->layoutPos().y() >= 0 )
            usedHeight = qMax( usedHeight, p->layoutPos().y() + 1 + p->bottomPadding() );
        else
            extraHeight = qMax( extraHeight, p->topPadding() + 1 + p->bottomPadding() );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QPointF & pos : positions) {
        minX = qMin( minX, pos.x() );
        maxX = qMax( maxX, pos.x() );
        minY = qMin( minY, pos.y() );
        maxY = qMax( maxY, pos.y() );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (PatPile * store : patPiles) {
        if (store->isFoundation() || store->isEmpty())
            continue;

        QList<KCard*> cards = store->cards();
        while (cards.count() && !cards.first()->isFaceUp())
            cards.erase(cards.begin());

        QList<KCard*>::Iterator iti = cards.begin();
        while (iti != cards.end())
        {
            if (allowedToRemove(store, (*iti)))
            {
                for (PatPile * dest : patPiles) {
                    int cardIndex = store->indexOf(*iti);
                    if (cardIndex == 0 && dest->isEmpty() && !dest->isFoundation())
                        continue;

                    if (!checkAdd(dest, dest->cards(), cards))
                        continue;

                    if (dest->isFoundation())
                    {
                        hintList << MoveHint( *iti, dest, 127 );
                    }
                    else
                    {
                        QList<KCard*> cardsBelow = cards.mid(0, cardIndex);
 
                        // if it could be here as well, then it's no use
                        if ((cardsBelow.isEmpty() && !dest->isEmpty()) || !checkAdd(store, cardsBelow, cards))
                        {
                            hintList << MoveHint( *iti, dest, 0 );
                        }
                        else if (checkPrefering(dest, dest->cards(), cards)
                                 && !checkPrefering(store, cardsBelow, cards))
                        { // if checkPrefers says so, we add it nonetheless
                            hintList << MoveHint( *iti, dest, 10 );
                        }
                    }
                }
            }
            cards.erase(iti);
            iti = cards.begin();
        }
    }
```

#### AUTO 


```{c}
const auto games = DealerInfoList::self()->games();
```

#### RANGE FOR STATEMENT 


```{c}
for (KCardPile * p1 : qAsConst(visiblePiles)) {
        if ( p1->heightPolicy() == KCardPile::GrowDown )
        {
            areas[p1].setBottom( contentHeight );
            for (KCardPile * p2 : qAsConst(visiblePiles)) {
                if ( p2 != p1 && areas[p1].intersects( areas[p2] ) )
                {
                    if ( p2->heightPolicy() == KCardPile::GrowUp )
                        areas[p1].setBottom( (reserve[p1].bottom() + reserve[p2].top() - spacing) / 2 );
                    else
                        areas[p1].setBottom( reserve[p2].top() - spacing );
                }
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KCardPile * p : piles)
        updatePileLayout( p, 0 );
```

#### AUTO 


```{c}
const auto currentCardsWaitedFor = d->cardsWaitedFor;
```

#### RANGE FOR STATEMENT 


```{c}
for (KCardPile * p1 : qAsConst(visiblePiles)) {
        if ( p1->heightPolicy() == KCardPile::GrowUp )
        {
            areas[p1].setTop( 0 );
            for (KCardPile * p2 : qAsConst(visiblePiles)) {
                if ( p2 != p1 && areas[p1].intersects( areas[p2] ) )
                {
                    if ( p2->heightPolicy() == KCardPile::GrowDown )
                        areas[p1].setTop( (reserve[p1].top() + reserve[p2].bottom() + spacing) / 2 );
                    else
                        areas[p1].setTop( reserve[p2].bottom() + spacing );
                }
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (PatPile * dest : patPiles) {
                    int cardIndex = store->indexOf(*iti);
                    if (cardIndex == 0 && dest->isEmpty() && !dest->isFoundation())
                        continue;

                    if (!checkAdd(dest, dest->cards(), cards))
                        continue;

                    if (dest->isFoundation())
                    {
                        hintList << MoveHint( *iti, dest, 127 );
                    }
                    else
                    {
                        QList<KCard*> cardsBelow = cards.mid(0, cardIndex);
 
                        // if it could be here as well, then it's no use
                        if ((cardsBelow.isEmpty() && !dest->isEmpty()) || !checkAdd(store, cardsBelow, cards))
                        {
                            hintList << MoveHint( *iti, dest, 0 );
                        }
                        else if (checkPrefering(dest, dest->cards(), cards)
                                 && !checkPrefering(store, cardsBelow, cards))
                        { // if checkPrefers says so, we add it nonetheless
                            hintList << MoveHint( *iti, dest, 10 );
                        }
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (KCard *card : currentCards)
        remove( card );
```

#### RANGE FOR STATEMENT 


```{c}
for (KCard * c : cards)
        addItem( c );
```

#### RANGE FOR STATEMENT 


```{c}
for (const DealerInfo * di : games) {
        m_dealer_map.insert( di->baseId(), di );
        const auto subtypeIds = di->subtypeIds();
        for (int id : subtypeIds)
            m_dealer_map.insert( id, di );
    }
```

#### AUTO 


```{c}
const auto unhighlightedItems = d->highlightedItems.subtract(s);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString & card : pile) {
                renderer.render( &p, card, QRectF( QPointF( xPos, yPos ), size ) );
                xPos += 0.3 * spacingWidth;
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (KCard * c : change.cards) {
                m_lastKnownCardStates.insert( c, destState );

                c->setFaceUp( destState.faceUp );
                destState.pile->insert( destState.index, c );

                if ( notDroppable )
                    m_cardsRemovedFromFoundations.insert( c );
                else
                    m_cardsRemovedFromFoundations.remove( c );

                ++sourceState.index;
                ++destState.index;
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (quint32 id : ids) {
        KCard * c = new KCard( id, this );

        c->setObjectName( elementName( c->id() ) );

        connect( c, &KCard::animationStarted, d, &KAbstractCardDeckPrivate::cardStartedAnimation );
        connect( c, &KCard::animationStopped, d, &KAbstractCardDeckPrivate::cardStoppedAnimation );

        QString elementId = elementName( id, true );
        d->frontIndex[ elementId ].cardUsers.append( c );

        elementId = elementName( id, false );
        d->backIndex[ elementId ].cardUsers.append( c );

        d->cards << c;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &d : entries) {
            QString indexFilePath = index + QLatin1Char('/') + d + QLatin1String("/index.desktop");
            if (QFile::exists(indexFilePath)) {
                QString directoryName = QFileInfo( indexFilePath ).dir().dirName();
                KCardTheme t( directoryName );
                if ( t.isValid() && t.supportedFeatures().contains( neededFeatures ) )
                    result << t;

            }
        }
```

#### AUTO 


```{c}
constexpr auto Ntpiles = 4;
```

#### RANGE FOR STATEMENT 


```{c}
for (int id : ids)
            nameToIdMap.insert( game->nameForId( id ), id );
```

#### AUTO 


```{c}
const auto SOFT_SUSPEND = FCS_STATE_SUSPEND_PROCESS;
```

#### AUTO 


```{c}
const auto cards = m_cardDeck->cards();
```

#### RANGE FOR STATEMENT 


```{c}
for (PatPile * store : patPiles) {
        if (store->isEmpty())
            continue;

        QList<KCard*> cards = store->cards();
        while (cards.count() && !cards.first()->isFaceUp())
            cards.erase(cards.begin());

        QList<KCard*>::Iterator iti = cards.begin();
        while (iti != cards.end())
        {
            if (allowedToRemove(store, (*iti)))
            {
                const auto patPiles = this->patPiles();
                for (PatPile * dest : patPiles) {
                    int cardIndex = store->indexOf(*iti);
                    if (cardIndex == 0 && dest->isEmpty() && !dest->isFoundation())
                        continue;

                    if (!checkAdd(dest, dest->cards(), cards))
                        continue;

                    if ( dest->isFoundation() ) // taken care by solver
                        continue;

                    QList<KCard*> cardsBelow = cards.mid(0, cardIndex);
                    // if it could be here as well, then it's no use
                    if ((cardsBelow.isEmpty() && !dest->isEmpty()) || !checkAdd(store, cardsBelow, cards))
                    {
                        hintList << MoveHint( *iti, dest, 0 );
                    }
                    else if (checkPrefering( dest, dest->cards(), cards )
                             && !checkPrefering( store, cardsBelow, cards ))
                    { // if checkPrefers says so, we add it nonetheless
                        hintList << MoveHint( *iti, dest, 0 );
                    }
                }
            }
            cards.erase(iti);
            iti = cards.begin();
        }
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr auto NQUEUES = 127;
```

#### RANGE FOR STATEMENT 


```{c}
for (KCard * c : cards) {
        c->disconnect( this );
        c->stopAnimation();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QGraphicsItem * item : items) {
        KCardPile * p = qgraphicsitem_cast<KCardPile*>( item );
        if ( !p )
        {
            KCard * c = qgraphicsitem_cast<KCard*>( item );
            if ( c )
                p = c->pile();
        }
        if ( p )
            targets << p;
    }
```

#### AUTO 


```{c}
const auto dpr = qApp->devicePixelRatio();
```

#### AUTO 


```{c}
const auto items = this->items();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& workspace: W) {
        workspace = new card_t[84];
        memset( workspace, 0, sizeof( card_t ) * 84 );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KCard * c : qAsConst(d->cards))
            c->setVisible( visible );
```

#### RANGE FOR STATEMENT 


```{c}
for (const DealerInfo *di : games) {
        KLocalizedString localizedKey = di->untranslatedBaseName();
        //QT5 const QString translatedKey = lowerAlphaNum( localizedKey.toString( tmpLocale ) );
        //QT5 gameList << translatedKey;
        //QT5 indexMap.insert( translatedKey, di->baseId() );
        indexMap.insert( di->baseIdString(), di->baseId() );
    }
```

#### AUTO 


```{c}
auto to = m->to;
```

#### RANGE FOR STATEMENT 


```{c}
for (KCard * c : cards) {
        c->setPos( talon->pos() );
        c->setFaceUp( false );
        talon->add( c );
    }
```

#### AUTO 


```{c}
const auto cards = it.value().cardUsers;
```

#### AUTO 


```{c}
const auto piles = this->piles();
```

#### RANGE FOR STATEMENT 


```{c}
for (KCardPile * p2 : qAsConst(visiblePiles)) {
                if ( p2 != p1 && areas[p1].intersects( areas[p2] ) )
                {
                    if ( p2->heightPolicy() == KCardPile::GrowUp )
                        areas[p1].setBottom( (reserve[p1].bottom() + reserve[p2].top() - spacing) / 2 );
                    else
                        areas[p1].setBottom( reserve[p2].top() - spacing );
                }
            }
```

#### AUTO 


```{c}
auto themeSelector = new KgThemeSelector(provider, KgThemeSelector::EnableNewStuffDownload, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (DealerInfo * game : games) {
		const auto ids = game->distinctIds();
		for (int id : ids)
			nameToIdMap.insert( game->nameForId( id ), id );
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (KCard * c : cards)
        cardHash.insert( c->id(), c );
```

#### RANGE FOR STATEMENT 


```{c}
for (KCard * c : qAsConst(cardsBeingDragged))
        c->setPos( c->pos() + delta );
```

#### AUTO 


```{c}
const auto get_possible_moves__ret = get_possible_moves(&no_use, &num_moves);
```

#### RANGE FOR STATEMENT 


```{c}
for (KCard * c : qAsConst(cards)) {
                c->completeAnimation();
                QPointF destPos = c->pos();
                c->setPos( oldPositions.value( c ) );

                int duration = speedUpTime( DURATION_AUTODROP + count * DURATION_AUTODROP / 10 );
                c->animate( destPos, c->zValue(), 0, c->isFaceUp(), true, duration );

                ++count;
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString & element : qAsConst(m_elementsToRender)) {
        {
            QMutexLocker l( &m_haltMutex );
            if ( m_haltFlag )
                return;
        }

        QString key = keyForPixmap( element, size );
        if ( !d->cache->contains( key ) )
        {
            //qCDebug(LIBKCARDGAME_LOG) << "Renderering" << key << "in rendering thread.";
            QImage img = d->renderCard( element, size );
            d->cache->insertImage( key, img );
            Q_EMIT renderingDone( element, img );
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (PatPile *p : patPiles) {
        if (!p->isFoundation() && !p->isEmpty())
            return false;
    }
```

#### AUTO 


```{c}
static constexpr auto NQUEUES = 127;
```

#### CONST EXPRESSION 


```{c}
static constexpr auto MAXMOVES = 64;
```

#### RANGE FOR STATEMENT 


```{c}
for (KCard * c : deckCards)
        cards.insert( (c->id() & 0xffff), c );
```

#### RANGE FOR STATEMENT 


```{c}
for (KCard * c : cards)
            m_cardsRemovedFromFoundations.insert( c );
```

#### AUTO 


```{c}
const auto subtypeIds = di->subtypeIds();
```

#### RANGE FOR STATEMENT 


```{c}
for (KCardPile * p2 : qAsConst(visiblePiles)) {
                if ( p2 != p1 && areas[p1].intersects( areas[p2] ) )
                {
                    if ( p2->widthPolicy() == KCardPile::GrowLeft )
                        areas[p1].setRight( (reserve[p1].right() + reserve[p2].left() - spacing) / 2 );
                    else
                        areas[p1].setRight( reserve[p2].left() - spacing );
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this](){this->free();}
```

#### RANGE FOR STATEMENT 


```{c}
for (KCard *c : cards)
                targetRect |= c->sceneBoundingRect();
```

#### RANGE FOR STATEMENT 


```{c}
for (KCardPile * p : currentPiles) {
        removePile( p );
        delete p;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KCard * c : qAsConst(d->cardsBeingDragged)) {
                c->stopAnimation();
                c->raise();
                c->setPos( c->pos() + offset );
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const MoveHint & h : moveHints)
        toHighlight << h.card();
```

#### RANGE FOR STATEMENT 


```{c}
for (KCardPile * p1 : qAsConst(visiblePiles)) {
        if ( p1->widthPolicy() == KCardPile::GrowRight )
        {
            areas[p1].setRight( contentWidth );
            for (KCardPile * p2 : qAsConst(visiblePiles)) {
                if ( p2 != p1 && areas[p1].intersects( areas[p2] ) )
                {
                    if ( p2->widthPolicy() == KCardPile::GrowLeft )
                        areas[p1].setRight( (reserve[p1].right() + reserve[p2].left() - spacing) / 2 );
                    else
                        areas[p1].setRight( reserve[p2].left() - spacing );
                }
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KCard * c : cards)
            c->setFrontPixmap( pix );
```

#### AUTO 


```{c}
constexpr auto NUM_DECK = 9;
```

#### AUTO 


```{c}
const auto themes = KCardTheme::findAllWithFeatures(d->requiredFeatures);
```

#### AUTO 


```{c}
const auto deckCards = deck()->cards();
```

#### RANGE FOR STATEMENT 


```{c}
for (QGraphicsItem * i : s)
        setItemHighlight( i, true );
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCardTheme & theme : qAsConst(m_themes)) {
        {
            QMutexLocker l( &m_haltMutex );
            if ( m_haltFlag )
                return;
        }

        const auto dpr = qApp->devicePixelRatio();
        QImage img( d->previewSize * dpr, QImage::Format_ARGB32 );
        img.setDevicePixelRatio( dpr );
        img.fill( Qt::transparent );
        QPainter p( &img );

        QSvgRenderer renderer( theme.graphicsFilePath() );

        QSizeF size = renderer.boundsOnElement(QStringLiteral("back")).size();
        size.scale( 1.5 * d->baseCardSize.width(), d->baseCardSize.height(), Qt::KeepAspectRatio );

        qreal yPos = ( d->previewSize.height() - size.height() ) / 2;
        qreal spacingWidth = d->baseCardSize.width()
                             * ( d->previewSize.width() - d->previewLayout.size() * size.width() )
                             / ( d->previewSize.width() - d->previewLayout.size() * d->baseCardSize.width() );

        qreal xPos = 0;
        for (const QList<QString> & pile : qAsConst(d->previewLayout)) {
            for (const QString & card : pile) {
                renderer.render( &p, card, QRectF( QPointF( xPos, yPos ), size ) );
                xPos += 0.3 * spacingWidth;
            }
            xPos += 1 * size.width() + ( 0.1 - 0.3 ) * spacingWidth;
        }

        Q_EMIT previewRendered( theme, img );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &index : indexFiles) {
        const QStringList entries = QDir(index).entryList(QDir::Dirs);
        for (const QString &d : entries) {
            QString indexFilePath = index + QLatin1Char('/') + d + QLatin1String("/index.desktop");
            if (QFile::exists(indexFilePath)) {
                QString directoryName = QFileInfo( indexFilePath ).dir().dirName();
                KCardTheme t( directoryName );
                if ( t.isValid() )
                    result << t;

            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (PatPile * dest : patPiles) {
                    int cardIndex = store->indexOf(*iti);
                    if (cardIndex == 0 && dest->isEmpty() && !dest->isFoundation())
                        continue;

                    if (!checkAdd(dest, dest->cards(), cards))
                        continue;

                    if ( dest->isFoundation() ) // taken care by solver
                        continue;

                    QList<KCard*> cardsBelow = cards.mid(0, cardIndex);
                    // if it could be here as well, then it's no use
                    if ((cardsBelow.isEmpty() && !dest->isEmpty()) || !checkAdd(store, cardsBelow, cards))
                    {
                        hintList << MoveHint( *iti, dest, 0 );
                    }
                    else if (checkPrefering( dest, dest->cards(), cards )
                             && !checkPrefering( store, cardsBelow, cards ))
                    { // if checkPrefers says so, we add it nonetheless
                        hintList << MoveHint( *iti, dest, 0 );
                    }
                }
```

#### AUTO 


```{c}
const auto patPiles = this->patPiles();
```

#### RANGE FOR STATEMENT 


```{c}
for (KCard * c : cards) {
            if(c->rank() == KCardDeck::King)
            {
            	int index = store[column]->indexOf(c);
                store[column]->swapCards(index, counter);
                counter++;
                
                if(m_stackFacedown == 1)
                    c->setFaceUp( false );
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (KCardPile * p2 : qAsConst(visiblePiles)) {
                if ( p2 != p1 && areas[p1].intersects( areas[p2] ) )
                {
                    if ( p2->heightPolicy() == KCardPile::GrowDown )
                        areas[p1].setTop( (reserve[p1].top() + reserve[p2].bottom() + spacing) / 2 );
                    else
                        areas[p1].setTop( reserve[p2].bottom() + spacing );
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QList<QString> & pile : qAsConst(d->previewLayout)) {
            for (const QString & card : pile) {
                renderer.render( &p, card, QRectF( QPointF( xPos, yPos ), size ) );
                xPos += 0.3 * spacingWidth;
            }
            xPos += 1 * size.width() + ( 0.1 - 0.3 ) * spacingWidth;
        }
```

#### CONST EXPRESSION 


```{c}
constexpr auto Ntpiles = 4;
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCard * c : cards) {
            xml.writeStartElement( QStringLiteral("card") );
            xml.writeAttribute( QStringLiteral("suit"), QString::number( c->suit() ) );
            xml.writeAttribute( QStringLiteral("value"), QString::number( c->rank() ) );
            xml.writeAttribute( QStringLiteral("faceup"), QString::number( c->isFaceUp() ) );
            xml.writeAttribute( QStringLiteral("z"), QString::number( c->zValue() ) );
            xml.writeEndElement();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (KCard * c : cards)
            m_cardsRemovedFromFoundations.remove( c );
```

#### RANGE FOR STATEMENT 


```{c}
for (QGraphicsItem * i : qAsConst(d->highlightedItems))
        setItemHighlight( i, false );
```

#### RANGE FOR STATEMENT 


```{c}
for (KCardPile * p : piles)
            updatePileLayout( p, 0 );
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCardTheme & theme : themes) {
        if ( !theme.isValid() )
            continue;

        QPixmap * pix = new QPixmap();
        QDateTime timestamp;
        if ( cacheFind( d->cache, timestampKey( theme ), &timestamp )
             && timestamp >= theme.lastModified() 
             && d->cache->findPixmap( previewKey( theme, d->previewString ), pix )
             && pix->size() == d->previewSize * dpr )
        {
            pix->setDevicePixelRatio( dpr );
            m_previews.insert( theme.displayName(), pix );
        }
        else
        {
            delete pix;
            m_previews.insert( theme.displayName(), nullptr );
            previewsNeeded << theme;
        }

        m_themes.insert( theme.displayName(), theme );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KCardPile * p : piles) {
        QList<KCard*> currentRun;
        CardState oldRunState;
        CardState newRunState;
        
        for ( int i = 0; i < p->count(); ++i )
        {
            KCard * c = p->at( i );

            const CardState & oldState = m_lastKnownCardStates.value( c );
            CardState newState( p, i, c->isFaceUp(), m_cardsRemovedFromFoundations.contains( c ) );

            // The card has changed.
            if ( newState != oldState )
            {
                // There's a run in progress, but this card isn't part of it.
                if ( !currentRun.isEmpty()
                     && (oldState.pile != oldRunState.pile
                         || (oldState.index != -1 && oldState.index != oldRunState.index + currentRun.size())
                         || oldState.faceUp != oldRunState.faceUp
                         || newState.faceUp != newRunState.faceUp
                         || oldState.takenDown != oldRunState.takenDown
                         || newState.takenDown != newRunState.takenDown) )
                {
                    changes << CardStateChange( oldRunState, newRunState, currentRun );
                    currentRun.clear();
                }

                // This card is the start of a new run.
                if ( currentRun.isEmpty() )
                {
                    oldRunState = oldState;
                    newRunState = newState;
                }
                
                currentRun << c;

                m_lastKnownCardStates.insert( c, newState );
            }
        }
        // Add the last run, if any.
        if ( !currentRun.isEmpty() )
        {
            changes << CardStateChange( oldRunState, newRunState, currentRun );
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Rank & r : ranks )
                ids << getId( s, r, number++ );
```

#### AUTO 


```{c}
const auto currentPiles = d->piles;
```

#### RANGE FOR STATEMENT 


```{c}
for( KCard * c : cards) {
        positions << currentPosition;
        qreal adjustment = c->isFaceUp() ? 1 : 0.6;
        currentPosition += adjustment * spread();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (DealerInfo * di : games) {
        fprintf(stderr, "di=%p\n", di);
        if ( di->providesId( wanted_game ) )
        {
            DealerScene * d = di->createGame();
            Q_ASSERT( d );
            d->setDeck( new KCardDeck( KCardTheme(), d ) );
            d->initialize();

            if ( !d->solver() )
            {
                qCCritical(KPAT_LOG) << "There is no solver for" << di->nameForId( wanted_game );;
                return nullptr;
            }

            return d;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KCard *c : cards) {
        distOnRect += spacing;
        QPointF pos2 = posAlongRect( distOnRect, justOffScreen );
        QPointF delta = c->pos() - pos2;
        qreal dist = sqrt( delta.x() * delta.x() + delta.y() * delta.y() );

        c->setFaceUp( true );
        c->animate( pos2, c->zValue(), 0, true, false, dist / speed );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const MoveHint & mh : moveHints) {
        if ( mh.pile()
             && mh.pile()->isFoundation()
             && mh.priority() > 120
             && !m_cardsRemovedFromFoundations.contains( mh.card() ) )
        {
            QList<KCard*> cards = mh.card()->pile()->topCardsDownTo( mh.card() );

            QMap<KCard*,QPointF> oldPositions;
            for (KCard * c : qAsConst(cards))
                oldPositions.insert( c, c->pos() );

            moveCardsToPile( cards, mh.pile(), DURATION_MOVE );

            int count = 0;
            for (KCard * c : qAsConst(cards)) {
                c->completeAnimation();
                QPointF destPos = c->pos();
                c->setPos( oldPositions.value( c ) );

                int duration = speedUpTime( DURATION_AUTODROP + count * DURATION_AUTODROP / 10 );
                c->animate( destPos, c->zValue(), 0, c->isFaceUp(), true, duration );

                ++count;
            }

            m_dropSpeedFactor *= AUTODROP_SPEEDUP_FACTOR;

            takeState();

            return true;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (PatPile * p : patPiles) {
            if ( p->isFoundation() && allowedToAdd( p, cardList ) )
            {
                moveCardToPile( card , p, DURATION_MOVE );
                return true;
            }
        }
```

#### AUTO 


```{c}
auto& workspace
```

#### RANGE FOR STATEMENT 


```{c}
for (KCard * c : qAsConst(d->cards))
        delete c;
```

#### AUTO 


```{c}
auto solver = new BakersDozenSolver( this );
```

#### CONST EXPRESSION 


```{c}
constexpr auto NUM_DECK = 9;
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCard * card : change.cards) {
                xml.writeStartElement( QStringLiteral("card") );
                xml.writeAttribute( QStringLiteral("id"), QStringLiteral("%1").arg( card->id(), 7, 10, QLatin1Char('0') ) );
                xml.writeAttribute( QStringLiteral("suit"), suitToString( card->suit() ) );
                xml.writeAttribute( QStringLiteral("rank"), rankToString( card->rank() ) );
                if ( faceChanged )
                    xml.writeAttribute( QStringLiteral("turn"), change.newState.faceUp ? QStringLiteral("face-up") : QStringLiteral("face-down") );
                xml.writeEndElement();
            }
```

#### AUTO 


```{c}
const auto seed = QRandomGenerator::global()->generate();
```

#### RANGE FOR STATEMENT 


```{c}
for (DealerInfo * game : games) {
        const auto ids = game->distinctIds();
        for (int id : ids)
            nameToIdMap.insert( game->nameForId( id ), id );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KCard * c : qAsConst(cards))
                oldPositions.insert( c, c->pos() );
```

#### AUTO 


```{c}
const auto moveHints = getHints();
```

#### AUTO 


```{c}
auto o = SUIT(card);
```

#### RANGE FOR STATEMENT 


```{c}
for (KCardPile * p : qAsConst(targets)) {
        if ( p != cardsBeingDragged.first()->pile() && q->allowedToAdd( p, cardsBeingDragged ) )
        {
            QRectF targetRect = p->sceneBoundingRect();
            const auto cards = p->cards();
            for (KCard *c : cards)
                targetRect |= c->sceneBoundingRect();

            QRectF intersection = targetRect & cardsBeingDragged.first()->sceneBoundingRect();
            qreal area = intersection.width() * intersection.height();
            if ( area > bestArea )
            {
                bestTarget = p;
                bestArea = area;
            }
        }
    }
```

#### AUTO 


```{c}
const auto cards = p->cards();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &d : entries) {
            QString indexFilePath = index + QLatin1Char('/') + d + QLatin1String("/index.desktop");
            if (QFile::exists(indexFilePath)) {
                QString directoryName = QFileInfo( indexFilePath ).dir().dirName();
                KCardTheme t( directoryName );
                if ( t.isValid() )
                    result << t;

            }
        }
```

#### AUTO 


```{c}
const auto cards = this->cards();
```

#### AUTO 


```{c}
static constexpr auto MAXMOVES = 64;
```

#### AUTO 


```{c}
auto cleanup = [this](){this->free();};
```

#### RANGE FOR STATEMENT 


```{c}
for (PatPile * p : patPiles) {
        removePatPile( p );
        removePile( p );
    }
```

#### AUTO 


```{c}
constexpr auto Ntpiles = 0;
```

#### AUTO 


```{c}
auto solver = new CastleSolver( this );
```

#### AUTO 


```{c}
auto bytes = kpat.readAllStandardOutput();
```

#### RANGE FOR STATEMENT 


```{c}
for (const CardStateChange & change : qAsConst(state->changes)) {
            xml.writeStartElement( QStringLiteral("move") );
            xml.writeAttribute( QStringLiteral("pile"), change.newState.pile->objectName() );
            xml.writeAttribute( QStringLiteral("position"), QString::number( change.newState.index ) );

            bool faceChanged = !change.oldState.pile
                               || change.oldState.faceUp != change.newState.faceUp;

            for (const KCard * card : change.cards) {
                xml.writeStartElement( QStringLiteral("card") );
                xml.writeAttribute( QStringLiteral("id"), QStringLiteral("%1").arg( card->id(), 7, 10, QLatin1Char('0') ) );
                xml.writeAttribute( QStringLiteral("suit"), suitToString( card->suit() ) );
                xml.writeAttribute( QStringLiteral("rank"), rankToString( card->rank() ) );
                if ( faceChanged )
                    xml.writeAttribute( QStringLiteral("turn"), change.newState.faceUp ? QStringLiteral("face-up") : QStringLiteral("face-down") );
                xml.writeEndElement();
            }

            xml.writeEndElement();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &index : indexFiles) {
        const QStringList entries = QDir(index).entryList(QDir::Dirs);
        for (const QString &d : entries) {
            QString indexFilePath = index + QLatin1Char('/') + d + QLatin1String("/index.desktop");
            if (QFile::exists(indexFilePath)) {
                QString directoryName = QFileInfo( indexFilePath ).dir().dirName();
                KCardTheme t( directoryName );
                if ( t.isValid() && t.supportedFeatures().contains( neededFeatures ) )
                    result << t;

            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KCard * c : cards)
        c->completeAnimation();
```

#### CONST EXPRESSION 


```{c}
constexpr auto Ntpiles = 0;
```

#### RANGE FOR STATEMENT 


```{c}
for (const Suit & s : suits )
            for (const Rank & r : ranks )
                ids << getId( s, r, number++ );
```

#### RANGE FOR STATEMENT 


```{c}
for (KCardPile * p2 : qAsConst(visiblePiles)) {
                if ( p2 != p1 && areas[p1].intersects( areas[p2] ) )
                {
                    if ( p2->widthPolicy() == KCardPile::GrowRight )
                        areas[p1].setLeft( (reserve[p1].left() + reserve[p2].right() + spacing) / 2 );
                    else
                        areas[p1].setLeft( reserve[p2].right() + spacing );
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (KCardPile * p : piles) {
        QPointF layoutPos = p->layoutPos();
        if ( layoutPos.x() < 0 )
            layoutPos.rx() += contentWidth - 1;
        if ( layoutPos.y() < 0 )
            layoutPos.ry() += contentHeight - 1;

        p->setPos( layoutPos.x() * cardSize.width(), layoutPos.y() * cardSize.height() );
        p->setGraphicSize( cardSize );

        if ( p->isVisible() )
        {
            visiblePiles << p;

            reserve[p] = QRectF( layoutPos, QSize( 1, 1 ) ).adjusted( -p->leftPadding(),
                                                                      -p->topPadding(),
                                                                       p->rightPadding(),
                                                                       p->bottomPadding() );
            areas[p] =  reserve[p];
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KCard * c : qAsConst(d->cardsBeingDragged)) {
                    c->stopAnimation();
                    c->raise();
                }
```

#### AUTO 


```{c}
const auto ranks = KCardDeck::standardRanks();
```

#### RANGE FOR STATEMENT 


```{c}
for (int id : subtypeIds)
            m_dealer_map.insert( id, di );
```

#### AUTO 


```{c}
const auto currentCards = d->cards;
```

#### AUTO 


```{c}
const auto ids = game->distinctIds();
```

#### CONST EXPRESSION 


```{c}
constexpr auto Nwpiles = 8;
```

#### CONST EXPRESSION 


```{c}
constexpr auto Nwpiles = 13;
```

#### RANGE FOR STATEMENT 


```{c}
for (KCard * card : qAsConst(d->cardsBeingDragged))
                card->setPos( card->pos() + e->scenePos() - d->startOfDrag );
```

#### CONST EXPRESSION 


```{c}
constexpr auto NUM_PILE = 8;
```

#### AUTO 


```{c}
const auto size = m_size * qApp->devicePixelRatio();
```

#### RANGE FOR STATEMENT 


```{c}
for (int id : ids)
			nameToIdMap.insert( game->nameForId( id ), id );
```

#### RANGE FOR STATEMENT 


```{c}
for (KCard * c : cards) {
            if ( !m_initDealPositions.contains( c ) )
                continue;

            QPointF pos2 = c->pos();
            c->setPos( m_initDealPositions.value( c ) );

            QPointF delta = c->pos() - pos2;
            qreal dist = sqrt( delta.x() * delta.x() + delta.y() * delta.y() );
            int duration = qRound( dist / speed );
            c->animate( pos2, c->zValue(), 0, c->isFaceUp(), false, duration );
        }
```

#### AUTO 


```{c}
constexpr auto NUM_PILE = 8;
```

#### AUTO 


```{c}
constexpr auto Nwpiles = 8;
```

#### RANGE FOR STATEMENT 


```{c}
for (const DealerInfo * di : games) {
            if ( di->baseIdString() == gameType )
            {
                gameId = di->baseId();
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (KCardPile * p : piles)
        pileHash.insert( p->objectName(), p );
```

#### RANGE FOR STATEMENT 


```{c}
for (KCard * c : cards)
        c->hide();
```

#### RANGE FOR STATEMENT 


```{c}
for (const CardStateChange & change : changes) {
            CardState sourceState = undo ? change.newState : change.oldState;
            CardState destState = undo ? change.oldState : change.newState;

            PatPile * sourcePile = dynamic_cast<PatPile*>( sourceState.pile );
            PatPile * destPile = dynamic_cast<PatPile*>( destState.pile );
            bool notDroppable = destState.takenDown
                                || ((sourcePile && sourcePile->isFoundation())
                                    && !(destPile && destPile->isFoundation()));

            pilesAffected << sourceState.pile << destState.pile;
            
            for (KCard * c : change.cards) {
                m_lastKnownCardStates.insert( c, destState );

                c->setFaceUp( destState.faceUp );
                destState.pile->insert( destState.index, c );

                if ( notDroppable )
                    m_cardsRemovedFromFoundations.insert( c );
                else
                    m_cardsRemovedFromFoundations.remove( c );

                ++sourceState.index;
                ++destState.index;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (GameSelectionBox * box : qAsConst(m_boxes)) {
        // Reduce font size until the label fits
        while ( pixelFontSize > minimumFontSize
                && p.boundingRect( QRectF(), box->label() ).width() > maxLabelWidth )
        {
            f.setPixelSize( --pixelFontSize );
            p.setFont( f );
        }

        // Position and size the boxes
        box->setPos( col * ( boxWidth * ( 1 + spacingRatio ) ),
                      row * ( boxHeight * ( 1 + spacingRatio ) ) );
        box->setSize( QSize( boxWidth, boxHeight ) );

        // Increment column and row
        ++col;
        if ( col == m_columns )
        {
            col = 0;
            ++row;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString & element : qAsConst(m_elementsToRender)) {
        if ( m_haltFlag )
            return;

        const QImage img = d->renderCard( element, size );
        Q_EMIT renderingDone( element, img );
    }
```

#### AUTO 


```{c}
constexpr auto Nwpiles = 13;
```

#### AUTO 


```{c}
auto solver = new GolfSolver( this );
```

#### RANGE FOR STATEMENT 


```{c}
for (const MOVE & m : moves) {
        MoveHint mh = solver()->translateMove( m );
	hintList << mh;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QGraphicsItem * item : items) {
        Q_ASSERT( item->zValue() >= 0 );
        itemsByZ.insert( item->zValue(), item );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QGraphicsItem * item : qAsConst(itemsByZ)) {
        if ( item->isVisible() )
        {
            p.save();
            p.setTransform( item->deviceTransform( p.worldTransform() ), false );
            item->paint( &p, nullptr );
            p.restore();
        }
    }
```

#### AUTO 


```{c}
const auto cards = pile->cards();
```

#### RANGE FOR STATEMENT 


```{c}
for (KCard * c : cards)
        removeItem( c );
```

#### AUTO 


```{c}
const auto cards = deck()->cards();
```

#### AUTO 


```{c}
auto solver = new FreecellSolver( this );
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCardDeck::Rank & r : ranks)
            for (const KCardDeck::Suit & s : suits)
                ids << KCardDeck::getId( s, r, number++ );
```

#### RANGE FOR STATEMENT 


```{c}
for (KCard * c : currentCardsWaitedFor)
       c->stopAnimation();
```

#### RANGE FOR STATEMENT 


```{c}
for (QGraphicsItem * i : unhighlightedItems)
        setItemHighlight( i, false );
```

#### RANGE FOR STATEMENT 


```{c}
for (KCardPile * p : qAsConst(pilesAffected)) {
            int i = 0;
            while ( i < p->count() )
            {
                int index = m_lastKnownCardStates.value( p->at( i ) ).index;
                if ( i == index )
                    ++i;
                else
                    p->swapCards( i, index );
            }

            updatePileLayout( p, 0 );
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString & pile : piles)
        d->previewLayout << pile.split(QLatin1Char(','));
```

#### RANGE FOR STATEMENT 


```{c}
for (PatPile * p : patPiles)
        piles.insert( p->index(), p );
```

#### RANGE FOR STATEMENT 


```{c}
for (PatPile * p : patPiles) {
        updatePileLayout( p, 0 );
        const auto cards = p->cards();
        for (KCard * c : cards) {
            if ( !m_initDealPositions.contains( c ) )
                continue;

            QPointF pos2 = c->pos();
            c->setPos( m_initDealPositions.value( c ) );

            QPointF delta = c->pos() - pos2;
            qreal dist = sqrt( delta.x() * delta.x() + delta.y() * delta.y() );
            int duration = qRound( dist / speed );
            c->animate( pos2, c->zValue(), 0, c->isFaceUp(), false, duration );
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (DealerInfo * di : games) {
        if ( (wanted_game < 0) ? (QString::fromUtf8(di->untranslatedBaseName()) == name) : di->providesId( wanted_game ) )
        {
            DealerScene * d = di->createGame();
            Q_ASSERT( d );
            d->setDeck( new KCardDeck( KCardTheme(), d ) );
            d->initialize();

            if ( !d->solver() )
            {
                qCCritical(KPAT_LOG) << "There is no solver for" << di->baseName();
                return nullptr;
            }

            return d;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DealerInfo *di : games) {
        KLocalizedString localizedKey = ki18n( di->untranslatedBaseName().constData() );
        //QT5 const QString translatedKey = lowerAlphaNum( localizedKey.toString( tmpLocale ) );
        //QT5 gameList << translatedKey;
        //QT5 indexMap.insert( translatedKey, di->baseId() );
        indexMap.insert( di->baseIdString(), di->baseId() );
    }
```

