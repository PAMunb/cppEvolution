#### RANGE FOR STATEMENT 


```{c}
for (const QChar &letter : qAsConst(m_userAnswer))
    {
        returnList.append(letter);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const QList<KNS3::Entry> &changedEntries) {
        if (!changedEntries.isEmpty()) {
            refreshView();
	}
    }
```

#### AUTO 


```{c}
auto context = new KLocalizedContext(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const QList<KNSCore::Entry> &changedEntries) {
        if (!changedEntries.isEmpty()) {
            refreshView();
	}
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& languageCode : languageCodes)
    {
        KConfigGroup group = entry.group(languageCode);

        QString languageName = group.readEntry("Name");
        if (languageName.isEmpty())
        {
            languageName = i18nc("@item:inlistbox no language for that locale", "None");
        }

        languageNames.append(languageName);
        m_languageCodeNameHash.insert(languageCode, languageName);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &userLanguageCode : userLanguagesCode)
        {
            if (sharedKvtmlFilesLanguages.contains(userLanguageCode))
            {
                foundLanguage = userLanguageCode;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QChar &userLetter : qAsConst(m_anagram))
    {
        resultList.append(userLetter);
    }
```

