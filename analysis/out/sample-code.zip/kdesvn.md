#### RANGE FOR STATEMENT 


```{c}
for (const QString &dir : qAsConst(_tempDirs)) {
            QDir(dir).removeRecursively();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const svn::LogChangePathEntry &entry : _data.changedPaths) {
        if (entry.action == 'A' &&
                !entry.copyFromPath.isEmpty() &&
                isParent(entry.path, _realName)) {
            QString r = _realName.mid(entry.path.length());
            _n = entry.copyFromPath;
            _n += r;
            _rev = entry.copyFromRevision;
            return true;
        }
    }
```

#### AUTO 


```{c}
const auto colE(index(idx.row(), columnCount() - 1, idx.parent()));
```

#### RANGE FOR STATEMENT 


```{c}
for (const svn::InfoEntry &entry : entries) {
        if (val > 0) {
            text += QStringLiteral("<hline>");
        }
        ++val;
        text += QStringLiteral("<p align=\"center\">");
        text += QStringLiteral("<table cellspacing=0 cellpadding=0>");
        if (!entry.Name().isEmpty()) {
            text += rb + i18n("Name") + cs + (entry.Name()) + re;
        }
        if (all) {
            text += rb + i18n("URL") + cs + (entry.url().toDisplayString()) + re;
            if (!entry.reposRoot().toString().isEmpty()) {
                text += rb + i18n("Canonical repository URL") + cs + (entry.reposRoot().toDisplayString()) + re;
            }
            if (!entry.checksum().isEmpty()) {
                text += rb + i18n("Checksum") + cs + (entry.checksum()) + re;
            }
        }
        text += rb + i18n("Type") + cs;
        switch (entry.kind()) {
        case svn_node_none:
            text += i18n("Absent");
            break;
        case svn_node_file:
            text += i18n("File");
            break;
        case svn_node_dir:
            text += i18n("Folder");
            break;
        case svn_node_unknown:
        default:
            text += i18n("Unknown");
            break;
        }
        text += re;
        if (entry.kind() == svn_node_file) {
            text += rb + i18n("Size") + cs;
            if (entry.size() != svn::InfoEntry::SVNQT_SIZE_UNKNOWN) {
                text += helpers::ByteToString(entry.size());
            } else if (entry.working_size() != svn::InfoEntry::SVNQT_SIZE_UNKNOWN) {
                text += helpers::ByteToString(entry.working_size());
            }
            text += re;
        }
        if (all) {
            text += rb + i18n("Schedule") + cs;
            switch (entry.Schedule()) {
            case svn_wc_schedule_normal:
                text += i18n("Normal");
                break;
            case svn_wc_schedule_add:
                text += i18n("Addition");
                break;
            case svn_wc_schedule_delete:
                text += i18n("Deletion");
                break;
            case svn_wc_schedule_replace:
                text += i18n("Replace");
                break;
            default:
                text += i18n("Unknown");
                break;
            }
            text += re;
            text += rb + i18n("UUID") + cs + (entry.uuid()) + re;
        }
        text += rb + i18n("Last author") + cs + (entry.cmtAuthor()) + re;
        if (entry.cmtDate().IsValid()) {
            text += rb + i18n("Last committed") + cs + entry.cmtDate().toString() + re;
        }
        text += rb + i18n("Last revision") + cs + entry.cmtRev().toString() + re;
        if (entry.textTime().IsValid()) {
            text += rb + i18n("Content last changed") + cs + entry.textTime().toString() + re;
        }
        if (all) {
            if (entry.propTime().IsValid()) {
                text += rb + i18n("Property last changed") + cs + entry.propTime().toString() + re;
            }
            for (const auto & _cfi : entry.conflicts()) {
                text += rb + i18n("New version of conflicted file") + cs + (_cfi->theirFile());
            }
            if (entry.prejfile().length()) {
                text += rb + i18n("Property reject file") +
                        cs + (entry.prejfile()) + re;
            }

            if (!entry.copyfromUrl().isEmpty()) {
                text += rb + i18n("Copy from URL") + cs + (entry.copyfromUrl().toDisplayString()) + re;
            }
            if (entry.lockEntry().Locked()) {
                text += rb + i18n("Lock token") + cs + (entry.lockEntry().Token()) + re;
                text += rb + i18n("Owner") + cs + (entry.lockEntry().Owner()) + re;
                text += rb + i18n("Locked on") + cs +
                        entry.lockEntry().Date().toString() +
                        re;
                text += rb + i18n("Lock comment") + cs +
                        entry.lockEntry().Comment() + re;
            } else {
                svn::StatusPtr d;
                if (checkReposLockCache(_what, d) && d && d->lockEntry().Locked()) {
                    text += rb + i18n("Lock token") + cs + (d->lockEntry().Token()) + re;
                    text += rb + i18n("Owner") + cs + (d->lockEntry().Owner()) + re;
                    text += rb + i18n("Locked on") + cs +
                            d->lockEntry().Date().toString() +
                            re;
                    text += rb + i18n("Lock comment") + cs +
                            d->lockEntry().Comment() + re;
                }
            }
        }
        text += QStringLiteral("</table></p>\n");
    }
```

#### AUTO 


```{c}
auto it = dlist.begin();
```

#### AUTO 


```{c}
const auto &url
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &historyEntry : qAsConst(sLogHistory)) {
        if (historyEntry.length() <= 40) {
            m_LogHistory->addItem(historyEntry);
        } else {
            m_LogHistory->addItem(historyEntry.leftRef(37) + QStringLiteral("..."));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &outputLine : m_outputLines) {
        if (m_pid.isEmpty()) {
            int pos = cshPidRx.indexIn(outputLine);
            if (pos > -1) {
                m_pid = cshPidRx.cap(1);
                continue;
            }

            pos = bashPidRx.indexIn(outputLine);
            if (pos > -1) {
                m_pid = bashPidRx.cap(1);
                continue;
            }
        }

        if (m_authSock.isEmpty()) {
            int pos = cshSockRx.indexIn(outputLine);
            if (pos > -1) {
                m_authSock = cshSockRx.cap(1);
                continue;
            }

            pos = bashSockRx.indexIn(outputLine);
            if (pos > -1) {
                m_authSock = bashSockRx.cap(1);
                continue;
            }
        }
    }
```

#### AUTO 


```{c}
const auto &fi
```

#### RANGE FOR STATEMENT 


```{c}
for (const SvnItem *cur : lst) {
        if (cur->isVersioned()) {
            KMessageBox::error(m_Data->m_ParentList->realWidget(), i18n("<center>The entry<br/>%1<br/>is versioned - break.</center>",
                                                                        cur->fullName()));
            return;
        }
        items.push_back(svn::Path(cur->fullName()));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {done(QDialogButtonBox::Cancel);}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &reason : reasons) {
            text += reason + QStringLiteral("<br/><hline>");
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto item : fileList) {
      if (!item) {
          // root item
          continue;
      }
      if (item->isChanged()) {
          at_least_one_changed = true;
      }
      if (item->isConflicted()) {
          at_least_one_conflicted = true;
      }
      if (item->isLocalAdded()) {
          at_least_one_local_added = true;
      }
      if (item->isRealVersioned()) {
          all_unversioned = false;
      } else {
          all_versioned = false;
      }
      if (item->isDir()) {
          at_least_one_directory = true;
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto & _cfi : (*it).conflicts()) {
                text += rb + i18n("New version of conflicted file") + cs + (_cfi->theirFile());
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const RevisionRange &rr : qAsConst(m_ranges)) {
            range = (svn_opt_revision_range_t *)apr_palloc(pool, sizeof(*range));
            range->start = *rr.first.revision();
            range->end  = *rr.second.revision();
            APR_ARRAY_PUSH(ranges, svn_opt_revision_range_t *) = range;
        }
```

#### AUTO 


```{c}
const auto &tgt
```

#### RANGE FOR STATEMENT 


```{c}
for (const KService::Ptr &ptr : qAsConst(m_List)) {
        if (_found.contains(ptr->name())) {
            continue;
        }
        _found.append(ptr->name());
        QString actionName(ptr->name().replace(QLatin1Char('&'), QLatin1String("&&")));
        QAction *act = addAction(SmallIcon(ptr->icon()), actionName);
        act->setData(m_mapPopup.size());

        m_mapPopup.push_back(ptr);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &exclude : excludeList.data()) {
                if (_p.startsWith(exclude)) {
                    blocked = true;
                    break;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const svn::LogEntry &entry : qAsConst(*log)) {
        SvnLogModelNodePtr np(new SvnLogModelNode(entry));
        m_data.append(np);
        if (entry.revision > m_max) {
            m_max = entry.revision;
        }
        if (entry.revision < m_min || m_min == -1) {
            m_min = entry.revision;
        }
        itemMap[entry.revision] = np;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &entry : qAsConst(dlist)) {
        if (!entry->isVersioned()) {
            rlist.append(entry);
            displist.append(entry->path());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &entry : notchecked) {
            m_List.append(CommitModelNodePtr(new CommitModelNode(entry, false)));
        }
```

#### AUTO 


```{c}
const auto it = m_subMap.find(what.at(0));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &idx : _mi) {
        ret.push_back(m_Data->sourceNode(idx, true));
    }
```

#### AUTO 


```{c}
auto pit = pmap.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &item : aList) {
            m_List.append(CommitModelNodePtr(new CommitModelNode(item)));
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {setResult(QDialogButtonBox::No);}
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {setResult(QDialogButtonBox::No);}
```

#### AUTO 


```{c}
auto item = m_Data->m_Model->nodeForIndex(_t);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &ex : exclude.data()) {
        sItems += QLatin1String(" and changeditem not like '") + ex + QLatin1String("%'");
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const svn::LogChangePathEntry &logPathEntry : logEntry.changedPaths) {
                const QString num(QString::number(m_pData->m_Listener.counter()).rightJustified(10, QLatin1Char('0')));
                setMetaData(num + QStringLiteral("rev"), QString::number(logEntry.revision));
                setMetaData(num + QStringLiteral("path"), url.path());
                setMetaData(num + QStringLiteral("loggedpath"), logPathEntry.path);
                setMetaData(num + QStringLiteral("loggedaction"), QString(QLatin1Char(logPathEntry.action)));
                setMetaData(num + QStringLiteral("loggedcopyfrompath"), logPathEntry.copyFromPath);
                setMetaData(num + QStringLiteral("loggedcopyfromrevision"), QString::number(logPathEntry.copyFromRevision));
                m_pData->m_Listener.incCounter();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &it : m_subMap) {
        if (it.second.isValid() || it.second.hasValidSubs()) {
            return true;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &child : m_Children) {
        if (child->shortName() == parts[0]) {
            if (parts.size() == 1) {
                return child;
            } else if (child->isDir()) {
                return static_cast<SvnItemModelNodeDir *>(child)->findPath(parts.mid(1));
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &content : m_content) {
        const QByteArray s = content.toUtf8();
        char *t2 = apr_pstrndup(apr_pool, s.data(), s.size());
        (*((const char **) apr_array_push(apr_targets))) = t2;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {setResult(QDialogButtonBox::Cancel);}
```

#### AUTO 


```{c}
auto it = m_outputLines.begin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const SvnItem *item : lst) {
        if (all) {
            res += QStringLiteral("<h4 align=\"center\">%1</h4>").arg(item->fullName());
        }
        res += getInfo(item->fullName(), rev, peg, recursive, all);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const LogEntry &le : qAsConst(_internal)) {
            _insertLogEntry(le);
            if (cp && cp->getListener()) {
                //cp->getListener()->contextProgress(++icount,_internal.size());
                if (cp->getListener()->contextCancel()) {
                    throw DatabaseException(QStringLiteral("Could not retrieve values: User cancel."));
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &path : paths)
        ret.push_back(svn::Path(path));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &ptr : sEntries) {
        if (ptr->validReposStatus()) {
            m_Data->m_UpdateCache.insertKey(ptr, ptr->path());
            if (!(ptr->validLocalStatus())) {
                newer = true;
            }
        }
        if (ptr->isLocked() &&
                !(ptr->entry().lockEntry().Locked())) {
            m_Data->m_repoLockCache.insertKey(ptr, ptr->path());
        }
        emit sigRefreshItem(ptr->path());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &fi : list) {
        if (!(n->contains(fi.absoluteFilePath()) || fi.absoluteFilePath() == n->fullName())) {
            svn::StatusPtr stat(new svn::Status(fi.absoluteFilePath()));
            dlist.append(stat);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SvnItemModelNode *qNode : qAsConst(m_NodeQueue)) {
        if (qNode->fullName() == node->fullName()) {
            found = true;
            break;
        }
    }
```

#### AUTO 


```{c}
auto it = lst.cbegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &ptr : sEntries) {
        if (ptr->isRealVersioned() && (
                    ptr->nodeStatus() == svn_wc_status_modified ||
                    ptr->nodeStatus() == svn_wc_status_added ||
                    ptr->nodeStatus() == svn_wc_status_deleted ||
                    ptr->nodeStatus() == svn_wc_status_replaced ||
                    ptr->nodeStatus() == svn_wc_status_modified
                )) {
            m_Data->m_Cache.insertKey(ptr, ptr->path());
        } else if (ptr->nodeStatus() == svn_wc_status_conflicted) {
            m_Data->m_conflictCache.insertKey(ptr, ptr->path());
        }
        emit sigRefreshItem(ptr->path());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Path &path : parameter.srcPath().targets()) {
        svn_client_copy_source_t *source = (svn_client_copy_source_t *)apr_palloc(pool, sizeof(svn_client_copy_source_t));
        source->path = apr_pstrdup(pool, path.path().toUtf8());
        source->revision = parameter.srcRevision().revision();
        source->peg_revision = parameter.pegRevision().revision();
        APR_ARRAY_PUSH(sources, svn_client_copy_source_t *) = source;
    }
```

#### AUTO 


```{c}
const auto it = m_Data->m_logCache.constFind(bti->rev());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &url : urls) {
        svn::LogEntriesMap logs;
        try {
            m_pData->m_Svnclient->log(params.targets(makeSvnPath(url)), logs);
        } catch (const svn::ClientException &e) {
            extraError(KIO::ERR_SLAVE_DEFINED, e.msg());
            break;
        }
        if (logs.isEmpty()) {
            const QString num(QString::number(m_pData->m_Listener.counter()).rightJustified(10, QLatin1Char('0')));
            setMetaData(num + QStringLiteral("path"), url.path());
            setMetaData(num + QStringLiteral("string"),
                        i18n("Empty logs"));
            m_pData->m_Listener.incCounter();
            continue;
        }

        for (const svn::LogEntry &logEntry : qAsConst(logs)) {
            const QString num(QString::number(m_pData->m_Listener.counter()).rightJustified(10, QLatin1Char('0')));
            setMetaData(num + QStringLiteral("path"), url.path());
            setMetaData(num + QStringLiteral("rev"), QString::number(logEntry.revision));
            setMetaData(num + QStringLiteral("author"), logEntry.author);
            setMetaData(num + QStringLiteral("logmessage"), logEntry.message);
            m_pData->m_Listener.incCounter();
            for (const svn::LogChangePathEntry &logPathEntry : logEntry.changedPaths) {
                const QString num(QString::number(m_pData->m_Listener.counter()).rightJustified(10, QLatin1Char('0')));
                setMetaData(num + QStringLiteral("rev"), QString::number(logEntry.revision));
                setMetaData(num + QStringLiteral("path"), url.path());
                setMetaData(num + QStringLiteral("loggedpath"), logPathEntry.path);
                setMetaData(num + QStringLiteral("loggedaction"), QString(QLatin1Char(logPathEntry.action)));
                setMetaData(num + QStringLiteral("loggedcopyfrompath"), logPathEntry.copyFromPath);
                setMetaData(num + QStringLiteral("loggedcopyfromrevision"), QString::number(logPathEntry.copyFromRevision));
                m_pData->m_Listener.incCounter();
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : lst)
            tmp.push_back(svn::Path(base + url.fileName()));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &tgt : targets.targets()) {
            try {
                StopDlg sdlg(m_Data->m_SvnContextListener, m_Data->m_ParentList->realWidget(),
                             i18nc("@title:window", "Status / List"), i18n("Creating list / check status"));
                _Cache = m_Data->m_Svnclient->status(params.path(tgt.path()));
            } catch (const svn::Exception &e) {
                emit clientException(e.msg());
                return false;
            }
            for (const svn::StatusPtr &ptr : qAsConst(_Cache)) {
                const QString _p = ptr->path();
                // check the node status, not the text status (it does not cover the prop status)
                if (ptr->isRealVersioned() && (
                            ptr->nodeStatus() == svn_wc_status_modified ||
                            ptr->nodeStatus() == svn_wc_status_added ||
                            ptr->nodeStatus() == svn_wc_status_replaced ||
                            ptr->nodeStatus() == svn_wc_status_deleted ||
                            ptr->nodeStatus() == svn_wc_status_modified
                        )) {
                    if (ptr->nodeStatus() == svn_wc_status_deleted) {
                        _check.append(CommitActionEntry(_p, i18n("Delete"), CommitActionEntry::DELETE));
                    } else {
                        _check.append(CommitActionEntry(_p, i18n("Commit"), CommitActionEntry::COMMIT));
                    }
                } else if (ptr->nodeStatus() == svn_wc_status_missing) {
                    _uncheck.append(CommitActionEntry(_p, i18n("Delete and Commit"), CommitActionEntry::MISSING_DELETE));
                } else if (!ptr->isVersioned()) {
                    _uncheck.append(CommitActionEntry(_p, i18n("Add and Commit"), CommitActionEntry::ADD_COMMIT));
                }
            }
        }
```

#### AUTO 


```{c}
auto it = m_contentMap.begin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : urls)
        ret.push_back(svn::Path((preferLocalFile && url.isLocalFile()) ? url.toLocalFile() : url.url()));
```

#### AUTO 


```{c}
const auto &outputLine
```

#### AUTO 


```{c}
const auto &it
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {setResult(QDialogButtonBox::Cancel);}
```

#### AUTO 


```{c}
auto it = m_Data->m_OldHistory.begin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &text : qAsConst(displist)) {
            QTreeWidgetItem *n = new QTreeWidgetItem(ptr);
            n->setText(0, text);
            n->setCheckState(0, Qt::Checked);
        }
```

#### AUTO 


```{c}
auto it = wlist.begin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &ignore : ignorePattern) {
        int it = lst.indexOf(ignore);
        if (it != -1) {
            if (unignore) {
                lst.removeAt(it);
                result = true;
            }
        } else {
            if (!unignore) {
                lst.append(ignore);
                result = true;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QLatin1String &schema : VALID_SCHEMAS) {
        const QStringRef urlComp = urlTest.leftRef(schema.size());

        if (schema == urlComp) {
            return true;
        }
    }
```

#### AUTO 


```{c}
const auto colS(index(idx.row(), 0, idx.parent()));
```

#### RANGE FOR STATEMENT 


```{c}
for (const svn::DirEntry &entry : qAsConst(res)) {
        QString d = entry.time().toString(QStringLiteral("yyyy-MM-dd hh:mm::ss"));
        m_pCPart->Stdout
                << (entry.kind() == svn_node_dir ? "D" : "F") << " "
                << d << " "
                << entry.name() << endl;
    }
```

#### AUTO 


```{c}
const auto &entry
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &it : m_subMap) {
        if (it.second.isValid()) {
            t.append(it.second.content());
        }
        it.second.appendValidSub(t);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QStringRef &str : wlist) {
        if (str == QLatin1String("%1")) {
            *proc << first;
        } else if (str == QLatin1String("%2")) {
            *proc << second;
        } else {
            *proc << str.toString();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SvnItem *item : which)
            what.append(svn::Path(item->fullName()));
```

#### AUTO 


```{c}
const auto &item
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {setResult(QDialogButtonBox::Yes);}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVariant &v : list) {
        if (v.type() == QVariant::ByteArray) {
            data << v.toByteArray();
        } else {
            data << v.toString().toUtf8();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const svn::StatusPtr &sp : dlist) {
#ifdef DEBUG_TIMER
        _counttime.restart();
#endif
        if (m_Data->MustCreateDir(*sp)) {
            node = new SvnItemModelNodeDir(parent, svnWrapper(), m_Data->m_Display);
        } else {
            node = new SvnItemModelNode(parent, svnWrapper(), m_Data->m_Display);
        }
        node->setStat(sp);
#ifdef DEBUG_TIMER
//        qCDebug(KDESVN_LOG)<<"Time creating item: "<<_counttime.elapsed();
        _counttime.restart();
#endif
        if (m_Data->m_Display->isWorkingCopy() && m_Data->m_DirWatch) {
            if (node->isDir()) {
                m_Data->addWatchDir(node->fullName());
            } else {
                m_Data->addWatchFile(node->fullName());
            }
        }
#ifdef DEBUG_TIMER
//        qCDebug(KDESVN_LOG)<<"Time add watch: "<<_counttime.elapsed();
        _counttime.restart();
#endif
        parent->m_Children.append(node);
#ifdef DEBUG_TIMER
//        qCDebug(KDESVN_LOG)<<"Time append node: "<<_counttime.elapsed();
#endif
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &str : urlList) {
        if (str.contains(QLatin1Char('@')))
            urls += QUrl(str + QLatin1Char('@'));
        else
            urls += QUrl(str);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const CommitActionEntry &entry : _result) {
            _commit.append(entry.name());
            if (entry.type() == CommitActionEntry::ADD_COMMIT) {
                _add.append(entry.name());
            } else if (entry.type() == CommitActionEntry::MISSING_DELETE) {
                _delete.append(entry.name());
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &fn : qAsConst(_tempFiles)) {
            QFile::remove(fn);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const svn::Path &item : items) {
            m_Data->m_Svnclient->add(item, depth);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const svn::Path &tgt : m_targets) {
        const QByteArray s = tgt.path().toUtf8();
        char *t2 = apr_pstrndup(apr_pool, s.data(), s.size());
        (*((const char **) apr_array_push(apr_targets))) = t2;
    }
```

#### AUTO 


```{c}
const auto &ptr
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &child : node->m_Children) {
            if (child->NodeIsDir()) {
                // both other parameters makes no sense at this point - defaults
                refreshDirnode(static_cast<SvnItemModelNodeDir *>(child), false, false);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const CommitActionEntry &entry : qAsConst(_result)) {
            _commit.append(entry.name());
            if (entry.type() == CommitActionEntry::ADD_COMMIT) {
                _add.append(entry.name());
            } else if (entry.type() == CommitActionEntry::MISSING_DELETE) {
                _delete.append(entry.name());
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto & _cfi : entry.conflicts()) {
                text += rb + i18n("New version of conflicted file") + cs + (_cfi->theirFile());
            }
```

#### AUTO 


```{c}
auto it = entries.begin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &tgt : target.targets()) {
        m_Data->m_Cache.deleteKey(tgt.path(), depth != svn::DepthInfinity);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const svn::LogChangePathEntry &entry : _l->changedPaths()) {
        _list.append(new LogChangePathItem(entry));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const LogChangePathEntry &cp : aEntry.changedPaths) {
        _q.bindValue(0, j);
        _q.bindValue(1, cp.path);
        _q.bindValue(2, QString(QLatin1Char(cp.action)));
        _q.bindValue(3, cp.copyFromPath);
        _q.bindValue(4, Q_LLONG(cp.copyFromRevision));
        if (!_q.exec()) {
            //qDebug("Could not insert values: %s",_q.lastError().text().toUtf8().data());
            //qDebug() << _q.lastQuery();
            throw svn::cache::DatabaseException(QStringLiteral("Could not insert values: %1, %2").arg(_q.lastError().text(), _q.lastError().nativeErrorCode()));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &child : m_Children) {
            child->refreshStatus(children);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &key : what) {
        m_Data->m_UpdateCache.deleteKey(key, exact_only);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DirEntry &dirEntry : dirEntries) {
        if (dirEntry.name().isEmpty()) {
            continue;
        }
        entries.push_back(dirEntryToStatus(params.path(), dirEntry));
    }
```

#### AUTO 


```{c}
const auto item
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &entry : dlist) {
        if (!entry->isVersioned()) {
            rlist.append(entry);
            displist.append(entry->path());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &entry : list)
        balist.append(entry.toUtf8());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &idx : _mi) {
        ret.push_back(m_Data->sourceNode(idx, false));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &it : its) {
        if (it->type() == GRAPHTREE_LABEL) {
            return static_cast<GraphTreeLabel *>(it);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &entry : qAsConst(dlist)) {
            if (entry->path() == n->fullName()) {
                found = true;
                break;
            }
        }
```

#### AUTO 


```{c}
const auto pred = [&](const svn::StatusPtr &sp) -> bool
    {
      return n->contains(sp->path()) || sp->path() == what;
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &info : infoList) {
        text += QLatin1String("<h4 align=\"center\">") + info + QLatin1String("</h4>");
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &url : urls) {
        QString userstring;
        if (nnum != svn::Revision::UNDEFINED) {
            userstring = i18n("Committed revision %1.", nnum.toString());
        } else {
            userstring = i18n("Nothing to commit.");
        }
        const QString num(QString::number(m_pData->m_Listener.counter()).rightJustified(10, QLatin1Char('0')));
        const QString zero(QStringLiteral("0"));
        setMetaData(num + QLatin1String("path"), url.path());
        setMetaData(num + QLatin1String("action"), zero);
        setMetaData(num + QLatin1String("kind"), zero);
        setMetaData(num + QLatin1String("mime_t"), QString());
        setMetaData(num + QLatin1String("content"), zero);
        setMetaData(num + QLatin1String("prop"), zero);
        setMetaData(num + QLatin1String("rev") , QString::number(nnum));
        setMetaData(num + QLatin1String("string"), userstring);
        m_pData->m_Listener.incCounter();
    }
```

#### AUTO 


```{c}
const auto it = m_contentMap.find(m);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &key : what) {
        m_Data->m_repoLockCache.deleteKey(key, true);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : indexes) {
        if (index.column() == 0) {
            urls << m_Data->nodeForIndex(index)->kdeName(m_Data->m_Display->baseRevision());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KService::Ptr &ptr : qAsConst(m_List)) {
        if (_found.contains(ptr->name())) {
            continue;
        }
        _found.append(ptr->name());
        QString actionName(ptr->name().replace(QLatin1Char('&'), QLatin1String("&&")));
        QAction *act = addAction(SmallIcon(ptr->icon()), actionName);
        QVariant _data = m_mapPopup.size();
        act->setData(_data);

        m_mapPopup.push_back(ptr);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const T &value : list)
        data.append(qVariantFromValue(value));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto item : lst) {
        const QString text = getInfo(item->fullName(), rev, peg, recursive, true);
        if (!text.isEmpty()) {
            infoList += text;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const svn::LogEntry &logEntry : qAsConst(logs)) {
            const QString num(QString::number(m_pData->m_Listener.counter()).rightJustified(10, QLatin1Char('0')));
            setMetaData(num + QStringLiteral("path"), url.path());
            setMetaData(num + QStringLiteral("rev"), QString::number(logEntry.revision));
            setMetaData(num + QStringLiteral("author"), logEntry.author);
            setMetaData(num + QStringLiteral("logmessage"), logEntry.message);
            m_pData->m_Listener.incCounter();
            for (const svn::LogChangePathEntry &logPathEntry : logEntry.changedPaths) {
                const QString num(QString::number(m_pData->m_Listener.counter()).rightJustified(10, QLatin1Char('0')));
                setMetaData(num + QStringLiteral("rev"), QString::number(logEntry.revision));
                setMetaData(num + QStringLiteral("path"), url.path());
                setMetaData(num + QStringLiteral("loggedpath"), logPathEntry.path);
                setMetaData(num + QStringLiteral("loggedaction"), QString(QLatin1Char(logPathEntry.action)));
                setMetaData(num + QStringLiteral("loggedcopyfrompath"), logPathEntry.copyFromPath);
                setMetaData(num + QStringLiteral("loggedcopyfromrevision"), QString::number(logPathEntry.copyFromRevision));
                m_pData->m_Listener.incCounter();
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &item : q) {
            if (item.first == QLatin1String("rev")) {
                svn::Revision re = item.second;
                if (re) {
                    m_pCPart->extraRevisions[j - 2] = re;
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const svn::StatusPtr &ptr: qAsConst(res)) {
        if (!ptr->isRealVersioned() || ptr->entry().kind() != svn_node_dir) {
            continue;
        }
        m_Data->m_Model->svnWrapper()->makeIgnoreEntry(ptr->path(), _pattern, unignore);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &entry : checked) {
            m_List.append(CommitModelNodePtr(new CommitModelNode(entry, true)));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KService::Ptr &ptr : qAsConst(m_List)) {
        if (_found.contains(ptr->name())) {
            continue;
        }
        _found.append(ptr->name());
        QString actionName(ptr->name().replace(QLatin1Char('&'), QLatin1String("&&")));
        QAction *act = addAction(QIcon::fromTheme(ptr->icon()), actionName);
        act->setData(m_mapPopup.size());

        m_mapPopup.push_back(ptr);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QUrl &url : lst) {
        url.setQuery(QUrlQuery());
        if (!nProto.isEmpty())
            url.setScheme(nProto);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QStringRef &str : wlist) {
        if (str == QLatin1String("%o") || str == QLatin1String("%l")) {
            *proc << i1.conflicts()[0]->baseFile();
        } else if (str == QLatin1String("%m") || str == QLatin1String("%w")) {
            *proc << i1.conflicts()[0]->myFile();
        } else if (str == QLatin1String("%n") || str == QLatin1String("%r")) {
            *proc << i1.conflicts()[0]->theirFile();
        } else if (str == QLatin1String("%t")) {
            *proc << p;
        } else {
            *proc << str.toString();
        }
    }
```

#### AUTO 


```{c}
auto it = reposCacheNames.begin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const myStrPair &p : q) {
        if (p.first == QLatin1String("rev")) {
            const QString v = p.second;
            svn::Revision tmp;
            m_Svnclient->url2Revision(v, rev, tmp);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &s : strList)
        vec << s.toInt();
```

#### RANGE FOR STATEMENT 


```{c}
for (const SvnItem *item : lst) {
        displist.append(item->fullName());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {done(QDialogButtonBox::Yes);}
```

#### RANGE FOR STATEMENT 


```{c}
for (const SvnItem *cur : lst) {
            if (!cur->isVersioned()) {
                KMessageBox::error(m_Data->m_ParentList->realWidget(), i18n("<center>The entry<br/>%1<br/>is not versioned - break.</center>", cur->fullName()));
                return;
            }
            displist.append(cur->fullName());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QStringRef &str : wlist) {
        if (str == QLatin1String("%s1")) {
            *proc << first;
        } else if (str == QLatin1String("%s2")) {
            if (!second.isEmpty()) {
                *proc << second;
            }
        } else if (str == QLatin1String("%t")) {
            *proc << target;
        } else {
            *proc << str.toString();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QStringRef &str : wlist) {
            if (str == QLatin1String("%f")) {
                QTemporaryFile tfile;
                tfile.setAutoRemove(false);
                tfile.open();
                fname_used = true;
                QDataStream ds(&tfile);
                ds.writeRawData(ex, ex.size());
                *proc << tfile.fileName();
                proc->appendTempFile(tfile.fileName());
                tfile.close();
            } else {
                *proc << str.toString();
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SvnItem *item : lst) {
        if (!item->isRealVersioned()) {
            QUrl _uri(QUrl::fromLocalFile(item->fullName()));
            kioList.append(_uri);
        } else {
            items.push_back(item->fullName());
        }
        displist.append(item->fullName());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {done(QDialogButtonBox::No);}
```

#### AUTO 


```{c}
auto &child
```

#### AUTO 


```{c}
const auto it = m_contentMap.find(what.at(0));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &dbName : reposCacheNames) {
            if (QSqlDatabase::database(dbName).isOpen()) {
                QSqlDatabase::database(dbName).commit();
                QSqlDatabase::database(dbName).close();
            }
            QSqlDatabase::removeDatabase(dbName);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &offer : qAsConst(offers)) {
        if (offer->noDisplay()) {
            continue;
        }
        break;
    }
```

#### AUTO 


```{c}
auto it = m_Data->m_shadingMap.find(line.revision());
```

#### LAMBDA EXPRESSION 


```{c}
[&](const svn::StatusPtr &sp) -> bool
    {
      return n->contains(sp->path()) || sp->path() == what;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &l : lst) {
        const QString text = getInfo(l, rev, peg, recursive, true);
        if (!text.isEmpty()) {
            infoList += text;
        }
    }
```

#### AUTO 


```{c}
auto bit = blame.begin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const svn::StatusPtr &ptr : qAsConst(_Cache)) {
                const QString _p = ptr->path();
                // check the node status, not the text status (it does not cover the prop status)
                if (ptr->isRealVersioned() && (
                            ptr->nodeStatus() == svn_wc_status_modified ||
                            ptr->nodeStatus() == svn_wc_status_added ||
                            ptr->nodeStatus() == svn_wc_status_replaced ||
                            ptr->nodeStatus() == svn_wc_status_deleted ||
                            ptr->nodeStatus() == svn_wc_status_modified
                        )) {
                    if (ptr->nodeStatus() == svn_wc_status_deleted) {
                        _check.append(CommitActionEntry(_p, i18n("Delete"), CommitActionEntry::DELETE));
                    } else {
                        _check.append(CommitActionEntry(_p, i18n("Commit"), CommitActionEntry::COMMIT));
                    }
                } else if (ptr->nodeStatus() == svn_wc_status_missing) {
                    _uncheck.append(CommitActionEntry(_p, i18n("Delete and Commit"), CommitActionEntry::MISSING_DELETE));
                } else if (!ptr->isVersioned()) {
                    _uncheck.append(CommitActionEntry(_p, i18n("Add and Commit"), CommitActionEntry::ADD_COMMIT));
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const svn::StatusPtr &s : qAsConst(dlist)) {
        if (!s) {
            continue;
        }
        const QString cntStr(QString::number(m_pData->m_Listener.counter()).rightJustified(10, QLatin1Char('0')));
        //QDataStream stream(params, QIODevice::WriteOnly);
        setMetaData(cntStr + QLatin1String("path"), s->path());
        setMetaData(cntStr + QLatin1String("node"), QString::number(s->nodeStatus()));
        setMetaData(cntStr + QLatin1String("text"), QString::number(s->textStatus()));
        setMetaData(cntStr + QLatin1String("prop"), QString::number(s->propStatus()));
        setMetaData(cntStr + QLatin1String("reptxt"), QString::number(s->reposTextStatus()));
        setMetaData(cntStr + QLatin1String("repprop"), QString::number(s->reposPropStatus()));
        setMetaData(cntStr + QLatin1String("rev"), QString::number(s->entry().cmtRev()));
        m_pData->m_Listener.incCounter();
    }
```

#### AUTO 


```{c}
auto item
```

#### RANGE FOR STATEMENT 


```{c}
for (const SvnItem *item : k)
            what.append(svn::Path(item->fullName()));
```

#### AUTO 


```{c}
const auto & _cfi
```

#### RANGE FOR STATEMENT 


```{c}
for (const queryPair &p : q) {
        if (p.first == QLatin1String("rev")) {
            const QString v = p.second;
            svn::Revision tmp;
            m_Data->m_Model->svnWrapper()->svnclient()->url2Revision(v, m_Data->m_remoteRevision, tmp);
            if (m_Data->m_remoteRevision == svn::Revision::UNDEFINED) {
                m_Data->m_remoteRevision = svn::Revision::HEAD;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto item : fileList) {
      if (!item) {
          // root item
          continue;
      }
      if (item->isChanged()) {
          at_least_one_changed = true;
      }
      if (item->isConflicted()) {
          at_least_one_conflicted = true;
      }
      if (item->isLocalAdded()) {
          at_least_one_local_added = true;
      }
      if (item->isRealVersioned()) {
          all_unversioned = false;
      } else {
          all_versioned = false;
      }
      if (item->isDir()) {
          at_least_one_directory = true;
          if (item->isChildModified())
            at_least_one_changed = true;
      }
    }
```

#### AUTO 


```{c}
auto it = _map.begin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const SvnItem *item : which) {
            targets.push_back(svn::Path(
                                  m_Data->m_ParentList->relativePath(item)
                              ));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &entry : m_List) {
        if (entry->checked()) {
            res.append(entry->actionEntry());
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {setResult(QDialogButtonBox::Yes);}
```

#### AUTO 


```{c}
const auto &offer
```

#### AUTO 


```{c}
auto &it
```

#### AUTO 


```{c}
const auto it = m_contentMap.find(_keys.at(0));
```

