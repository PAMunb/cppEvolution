#### AUTO 


```{c}
auto *w = static_cast<QWidget *>(o);
```

#### AUTO 


```{c}
auto *edit = new QLineEdit(&dlg);
```

#### AUTO 


```{c}
auto *label = new QLabel(&dlg);
```

#### AUTO 


```{c}
auto *dateWidget = new KDatePicker(defaultEntry, &dlg);
```

#### AUTO 


```{c}
auto *buttonBox = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel);
```

#### AUTO 


```{c}
auto *mainLayout = new QVBoxLayout(&dlg);
```

#### AUTO 


```{c}
auto *head = new QLabel(&dlg);
```

#### AUTO 


```{c}
auto it = list.constBegin();
```

#### AUTO 


```{c}
auto *buttonBox = new QDialogButtonBox(&dialog);
```

#### AUTO 


```{c}
auto type = static_cast<KMessageBox::DialogType>(0);
```

#### AUTO 


```{c}
auto *edit = new KTextEdit(&dlg);
```

#### AUTO 


```{c}
auto *timer = new QTimer();
```

#### AUTO 


```{c}
auto *cb = dialog.findChild<QCheckBox *>();
```

#### LAMBDA EXPRESSION 


```{c}
[serviceName](){
                std::cout << serviceName.toLatin1().constData() << " /ProgressDialog" << std::endl << std::flush;
                qApp->quit();
            }
```

#### AUTO 


```{c}
auto *vLayout = new QVBoxLayout(this);
```

#### AUTO 


```{c}
auto *combo = new QComboBox(&dlg);
```

#### LAMBDA EXPRESSION 


```{c}
[serviceName](){
                   std::cout << serviceName.toLatin1().constData() << " /ProgressDialog" << std::endl << std::flush;
                   qApp->quit();
           }
```

#### AUTO 


```{c}
const auto ret = QDialogButtonBox::StandardButton(dialog.exec());
```

#### AUTO 


```{c}
auto *buttonBox = new QDialogButtonBox(buttons, &dlg);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QChar c : str) {
        if (escaped) {
            escaped = false;
            if (c == QLatin1Char('\\')) {
                ret += c;
            } else if (c == QLatin1Char('n')) {
                ret += QLatin1Char('\n');
            } else {
                qWarning() << qPrintable(QString::fromLatin1("Unrecognized escape sequence \\%1").arg(c));
                ret += QLatin1Char('\\');
                ret += c;
            }
        } else {
            if (c == QLatin1Char('\\')) {
                escaped = true;
            } else {
                ret += c;
            }
        }
    }
```

#### AUTO 


```{c}
auto *slider = new QSlider(&dlg);
```

