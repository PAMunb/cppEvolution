#### AUTO 


```{c}
const auto limitValue = urlQuery.queryItemValue(QStringLiteral("limit"));
```

#### AUTO 


```{c}
const auto& xAddr
```

#### AUTO 


```{c}
const auto flushEntries = [this, &list]() {
        if (list.isEmpty()) {
            return;
        }
        listEntries(list);
        list.clear();
    };
```

#### AUTO 


```{c}
auto onvifDiscover = new OnvifDiscover(&app);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto entry : list) {
            QUrl entryUrl(dirUrl);
            QString path = entryUrl.path();
            if (!path.endsWith(QLatin1Char('/'))) {
                path += QLatin1Char('/');
            }
            // UDS_NAME is e.g. "foo/bar/somefile.txt"
            entryUrl.setPath(path + entry.stringValue(KIO::UDSEntry::UDS_NAME));

            const QString urlStr = entryUrl.toDisplayString();
            entry.replace(KIO::UDSEntry::UDS_URL, urlStr);

            const QString fileName = entryUrl.fileName();
            entry.replace(KIO::UDSEntry::UDS_NAME, fileName);

            if (entry.isDir()) {
                // Also search the target of a dir symlink
                if (const QString linkDest = entry.stringValue(KIO::UDSEntry::UDS_LINK_DEST); !linkDest.isEmpty()) {
                    // Remember the dir to prevent endless loops
                    const auto [it, isInserted] = iteratedDirs.insert(linkDest);
                    if (isInserted) {
                        pendingDirs.push(entryUrl.resolved(QUrl(linkDest)));
                    }
                }

                iteratedDirs.insert(urlStr);
            }

            if (match(entry, regex, searchContents)) {
                // UDS_DISPLAY_NAME is e.g. "foo/bar/somefile.txt"
                entry.replace(KIO::UDSEntry::UDS_DISPLAY_NAME, fileName);
                listEntry(entry);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &dirUrl : qAsConst(m_searchUrls)) {
        if (urlPath.startsWith(dirUrl.path())) {
            org::kde::KDirNotify::emitFilesAdded(dirUrl);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& activity: activitiesList) {
                    if (activitiesForLinking.contains(activity) ||
                            !activitiesForUnlinking.contains(activity)) {
                        actions << createAction(activity, true);
                    }
                }
```

#### AUTO 


```{c}
const auto coverData = picture->data();
```

#### AUTO 


```{c}
const auto &plugin
```

#### RANGE FOR STATEMENT 


```{c}
for (const NetService& service : mServiceList) {
        const NetServicePrivate* const d = service.dPtr();
        if( d->id() == id )
        {
            result = true;
            break;
        }
    }
```

#### AUTO 


```{c}
auto xAddr
```

#### LAMBDA EXPRESSION 


```{c}
[&](const Discovery::Ptr &discovery) { list.append(discovery->toEntry()); }
```

#### AUTO 


```{c}
const auto blockSize = dirStat.f_bsize * frames;
```

#### AUTO 


```{c}
const auto path = fullPath.midRef(fullPath.startsWith('/') ? 1 : 0);
```

#### RANGE FOR STATEMENT 


```{c}
for(auto type : matchedService->typeList()) {
        qDebug() << "  Type:"  << type.localName() << "in namespace" << type.nameSpace();
    }
```

#### AUTO 


```{c}
auto xiphComment = dynamic_cast<TagLib::Ogg::XiphComment*>(fileRef.tag());
```

#### AUTO 


```{c}
const auto &device
```

#### AUTO 


```{c}
auto maybeFinished = [&] { // finishes if all discoveries finished
        bool allFinished = true;
        for (const auto &discoverer : discoverers) {
            allFinished = allFinished && discoverer->isFinished();
        }
        if (allFinished) {
            flushEntries();
            e.quit();
        }
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &name : entries) {
            if (!name.contains(QLatin1String("cover"), Qt::CaseInsensitive)) {
                continue;
            }

            entry = zip.directory()->file(name);
            if (!entry) {
                continue;
            }

            if (image.loadFromData(entry->data())) {
                return true;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &it_dir : dirs)
        {
            QDir d(it_dir+"/man"+it_sect);
            if (d.exists())
            {
                l << it_sect;
                break;
            }
        }
```

#### AUTO 


```{c}
const static auto plugins = availablePlugins();
```

#### AUTO 


```{c}
const auto coverData = item.second.binaryData();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &dirUrl : m_searchUrls) {
        for (const QString &file : files) {
            if (file.startsWith(dirUrl.path())) {
                QUrl url(file);
                url.setScheme(QStringLiteral("filenamesearch"));
                fileList << url;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const NetDevice& device : qAsConst(deviceList)) {
            const bool isSameAddress = ( device.ipAddress() == ipAddress );
//qDebug()<<"existing device:"<<device.hostName()<<"at"<<device.ipAddress()<<"vs."<<ipAddress<<":"<<isSameAddress;
            // TODO: lookup hostname and try to use that
            if( isSameAddress )
            {
                d = device.dPtr();
                deviceOfService = &device;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QLocale &it_loc : locales)
        {
            // TODO: languageToString() is wrong, that returns the readable name
            // of the language.  We want the country code returned by name().
            QString lang = QLocale::languageToString(it_loc.language());
            if ( !lang.isEmpty() && lang!=QString("C") )
            {
                QString dir = it_dir+'/'+lang;
                QDir d(dir);
                if (d.exists())
                {
                    const QString p = d.canonicalPath();
                    if (!man_dirs.contains(p)) man_dirs += p;
                }
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[listJob]() {
        listJob->kill();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& result: query) {
                const auto linkedFileCount = result[1].toInt();
                const auto activity = result[0].toString();
                if (linkedFileCount < itemsSize) {
                    activitiesForLinking << activity;
                }

                if (linkedFileCount > 0) {
                    activitiesForUnlinking << activity;
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[=] {
            ++m_resolvedCount;
            Q_EMIT newDiscovery(Discovery::Ptr(new DNSSDDiscovery(service)));
            maybeFinish();
        }
```

#### AUTO 


```{c}
const auto *entry = zip.directory()->entry(QStringLiteral("META-INF/container.xml"));
```

#### AUTO 


```{c}
const auto *thumbnailEntry = zip.directory()->entry(thumbnailPath);
```

#### LAMBDA EXPRESSION 


```{c}
[&ring, &abort]() -> bool {
            for (auto i = 0; i <= runs && !abort; ++i) {
                auto s = ring.nextFree();
                memset(s->buf.data(), i, fileSize);
                if (abort) {
                    ring.done();
                    return false;
                }
                ring.push();
            }
            ring.done();
            return true;
        }
```

#### AUTO 


```{c}
const auto pair = getPath(storagePath);
```

#### RANGE FOR STATEMENT 


```{c}
for (const NetDevice& device : deviceList) {
        if( device.hostAddress() == hostAddress )
        {
            result = device;
            break;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&ring, &abort]() -> bool {
            for (auto i = 0; i <= runs && !abort; ++i) {
                auto s = ring.nextFree();
                memset(s->buf.data(), i, fileSize);
                ring.push();
                if (abort) {
                    ring.done();
                    return false;
                }
                // Slow down this thread to simulate slow network reads.
                std::this_thread::sleep_for(std::chrono::milliseconds(5));
            }
            ring.done();
            return true;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&](const Discovery::Ptr &discovery) {
                if (discoveredNames.contains(discovery->udsName())) {
                    return;
                }
                discoveredNames << discovery->udsName();
                list.append(discovery->toEntry());
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this, parentId, descriptor, filename] {
        int result = 1;
        QT_STATBUF srcBuf;
        if (QT_FSTAT(descriptor.fileDescriptor(), &srcBuf) != -1) {
            const QDateTime lastModified = QDateTime::fromSecsSinceEpoch(srcBuf.st_mtim.tv_sec);

            LIBMTP_file_t *file = LIBMTP_new_file_t();
            file->parent_id = parentId;
            file->filename = qstrdup(filename.toUtf8().data());
            file->filetype = getFiletype(filename);
            file->filesize = quint64(srcBuf.st_size);
            file->modificationdate = lastModified.toSecsSinceEpoch();   // no matter what to set here, current time is taken
            file->storage_id = m_id;

            result = LIBMTP_Send_File_From_File_Descriptor(getDevice(), descriptor.fileDescriptor(), file, onDataProgress, this);
            LIBMTP_destroy_file_t(file);

            if (result) {
                LIBMTP_Dump_Errorstack(getDevice());
                LIBMTP_Clear_Errorstack(getDevice());
            }
        }
        emit copyFinished(result);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[file] { sftp_close(file); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const NetDevice& device : deviceList) {
        if( device.hostAddress() == hostAddress )
        {
            result = device.serviceList();
            break;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[filefd] {
        smbc_close(filefd);
    }
```

#### AUTO 


```{c}
auto actionInfo
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &attribute : attributes) {
                        if (attribute.name() == QLatin1String("href")) {
                            coverId = attribute.value().toString();
                            if (coverId.startsWith(QLatin1Char('#'))) {
                                coverId = coverId.mid(1);
                            }
                        }
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &plugin : plugins) {
        if (plugin.supportsMimeType(mimeType)) {
            return plugin;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &plugin : plugins) {
        const QStringList mimeTypes = plugin.mimeTypes() + plugin.value(QStringLiteral("ServiceTypes"), QStringList());
        for (const QString& mime : mimeTypes) {
            if(mime.endsWith('*')) {
                const auto mimeGroup = QStringView(mime).left(mime.length()-1);
                if(mimeType.startsWith(mimeGroup)) {
                    return plugin;
                }
            }
        }
    }
```

#### AUTO 


```{c}
const auto result = chmod(url, permissions);
```

#### AUTO 


```{c}
const auto url = fileItems.first().url();
```

#### LAMBDA EXPRESSION 


```{c}
[&e, &flushEntries]() {
        flushEntries();
        e.quit();
    }
```

#### AUTO 


```{c}
const auto end       = pattern.constEnd();
```

#### LAMBDA EXPRESSION 


```{c}
[this, parentId, descriptor, filename] {
        int result = 1;
        QT_STATBUF srcBuf;
        if (QT_FSTAT(descriptor.fileDescriptor(), &srcBuf) != -1) {
            const QDateTime lastModified = QDateTime::fromSecsSinceEpoch(srcBuf.st_mtim.tv_sec);

            LIBMTP_file_t *file = LIBMTP_new_file_t();
            file->parent_id = parentId;
            file->filename = qstrdup(filename.toUtf8().data());
            file->filetype = getFiletype(filename);
            file->filesize = quint64(srcBuf.st_size);
            file->modificationdate = lastModified.toTime_t();   // no matter what to set here, current time is taken
            file->storage_id = m_id;

            result = LIBMTP_Send_File_From_File_Descriptor(getDevice(), descriptor.fileDescriptor(), file, onDataProgress, this);
            LIBMTP_destroy_file_t(file);

            if (result) {
                LIBMTP_Dump_Errorstack(getDevice());
                LIBMTP_Clear_Errorstack(getDevice());
            }
        }
        emit copyFinished(result);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const StandardName &standardName : STANDARD_NAMES)
                    {
                        if ( args[0] == standardName.abbrev )
                        {
                            found = true;
                            out_html(standardName.formalName);
                            break;
                        }
                    }
```

#### AUTO 


```{c}
const auto devices = m_kmtpDaemon.devices();
```

#### AUTO 


```{c}
auto matches = regExp.globalMatch(output);
```

#### AUTO 


```{c}
auto getSubCreator = [&filePath, this]() -> ThumbCreatorWithMetadata* {
        const QMimeDatabase db;
        const KPluginMetaData  subPlugin = pluginForMimeType(db.mimeTypeForFile(filePath).name());
        if (!subPlugin.isValid() || !m_enabledPlugins.contains(subPlugin.pluginId())) {
            return nullptr;
        }
        return getThumbCreator(subPlugin.fileName());
    };
```

#### AUTO 


```{c}
const auto maxDimension = qMin(1024, 512 * m_devicePixelRatio);
```

#### AUTO 


```{c}
const auto agentValue = urlQuery.queryItemValue(QStringLiteral("agent"));
```

#### AUTO 


```{c}
const auto dirEntries = dir->entries();
```

#### AUTO 


```{c}
const auto fileFree = qScopeGuard([file]{ sftp_close(file); });
```

#### RANGE FOR STATEMENT 


```{c}
for (const UpnpNetSystemAble* factory : mNetSystemFactoryList) {
                    if( factory->canCreateNetSystemFromUpnp(upnpDevice) )
                    {
                        id = factory->upnpId( upnpDevice );
                        break;
                    }
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this](Discovery::Ptr discovery) {
        ++m_resolvedCount;
        Q_EMIT newDiscovery(discovery);
        maybeFinish();
    }
```

#### AUTO 


```{c}
auto discoverer
```

#### AUTO 


```{c}
const auto loginResult = sftpLogin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& result: query) {
                    const auto linkedFileCount = result[1].toInt();
                    const auto activity = result[0].toString();
                    if (linkedFileCount < itemsSize) {
                        activitiesForLinking << activity;
                    }

                    if (linkedFileCount > 0) {
                        activitiesForUnlinking << activity;
                    }
                }
```

#### AUTO 


```{c}
const auto coverData = coverArtList[0].data();
```

#### LAMBDA EXPRESSION 


```{c}
[udi] (const KMTPDeviceInterface *device) {
        return device->udi() == udi;
    }
```

#### AUTO 


```{c}
const auto start = data+i+1;
```

#### AUTO 


```{c}
auto job = KIO::special(QUrl(QStringLiteral("recentlyused:/")), packedArgs);
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractNetSystemFactory* factory : qAsConst(mNetSystemFactoryList)) {
            builder->registerNetSystemFactory( factory );
        }
```

#### AUTO 


```{c}
const auto available = blockSize * ((dirStat.f_bavail != 0) ? dirStat.f_bavail : dirStat.f_bfree);
```

#### AUTO 


```{c}
auto ptr = search->second.lock();
```

#### LAMBDA EXPRESSION 


```{c}
[&filePath, this]() -> ThumbCreator* {
        const QMimeDatabase db;
        const QString subPlugin = pluginForMimeType(db.mimeTypeForFile(filePath).name());
        if (subPlugin.isEmpty() || !m_enabledPlugins.contains(subPlugin)) {
            return nullptr;
        }
        return getThumbCreator(subPlugin);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
            const std::lock_guard<std::mutex> lock(m_mutex);
            sendWithLock();
        }
```

#### AUTO 


```{c}
auto xscale = (1.0 * desiredWidth) / width;
```

#### LAMBDA EXPRESSION 


```{c}
[&](Discovery::Ptr discovery) {
               list.append(discovery->toEntry());
           }
```

#### RANGE FOR STATEMENT 


```{c}
for (const CSTRDEF &standardchar : standardchars)
    {
        const int nr = standardchar.nr;
        const char temp[3] = { char(nr / 256), char(nr % 256), 0 };
        QByteArray name(temp);
        s_characterDefinitionMap.insert(name, StringDefinition(standardchar.slen, standardchar.st));
    }
```

#### AUTO 


```{c}
auto ret = process.waitForFinished(-1);
```

#### LAMBDA EXPRESSION 


```{c}
[pattern](const KFileItem &item) -> bool {
            return item.determineMimeType().inherits(QStringLiteral("text/plain")) &&
            contentContainsPattern(item.url(), pattern);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &item : urlList) {
        service.asyncCall(
                link ? "LinkResourceToActivity" : "UnlinkResourceFromActivity",
                QString(),
                item.toLocalFile(),
                activity);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](KDNSSD::RemoteService::Ptr service){
        qCDebug(KIO_SMB_LOG) << "DNSSD added:"
                             << service->serviceName()
                             << service->type()
                             << service->domain()
                             << service->hostName()
                             << service->port();
        // Manual contains check. We need to use the == of the underlying
        // objects, not the pointers. The same service may have >1
        // RemoteService* instances representing it, so the == impl of
        // RemoteService::Ptr is useless here.
        for (const auto &servicePtr : qAsConst(m_services)) {
            if (*service == *servicePtr) {
                return;
            }
        }

        connect(service.data(), &KDNSSD::RemoteService::resolved, this, [=] {
            ++m_resolvedCount;
            emit newDiscovery(Discovery::Ptr(new DNSSDDiscovery(service)));
            maybeFinish();
        });

        // Schedule resolution of hostname. We'll later call resolve
        // which will block until the resolution is done. This basically
        // gives us a head start on discovery.
        service->resolveAsync();
        m_services.append(service);
    }
```

#### AUTO 


```{c}
auto future = std::async(std::launch::async, [&buffer, &filefd]() -> int {
        while (true) {
            TransferSegment *s = buffer.nextFree();
            s->size = smbc_read(filefd, s->buf.data(), s->buf.capacity());
            if (s->size <= 0) {
                buffer.push();
                buffer.done();
                if (s->size < 0) {
                    return KIO::ERR_CANNOT_READ;
                }
                break;
            }
            buffer.push();
        }
        return KJob::NoError;
    });
```

#### AUTO 


```{c}
auto currentPosition = pattern.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& entry : qAsConst(entries)) {
        // Skip MacOS resource forks
        if (entry.startsWith(QLatin1String("__MACOSX"), Qt::CaseInsensitive) ||
                entry.startsWith(QLatin1String(".DS_Store"), Qt::CaseInsensitive)) {
            continue;
        }
        if (entry.endsWith(QLatin1String(".gif"), Qt::CaseInsensitive) ||
                entry.endsWith(QLatin1String(".jpg"), Qt::CaseInsensitive) ||
                entry.endsWith(QLatin1String(".jpeg"), Qt::CaseInsensitive) ||
                entry.endsWith(QLatin1String(".png"), Qt::CaseInsensitive) ||
                entry.endsWith(QLatin1String(".webp"), Qt::CaseInsensitive)) {
            entryMap.insert(entry.toLower(), entry);
        }
    }
```

#### AUTO 


```{c}
const auto &item
```

#### AUTO 


```{c}
auto result = execQuery(query);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KMTPFile &file : files) {
                    listEntry(getEntry(file));
                }
```

#### LAMBDA EXPRESSION 


```{c}
[&buffer, &srcfd, &isErr]() -> int {
        while (!isErr) {
            TransferSegment *segment = buffer.nextFree();
            segment->size = smbc_read(srcfd, segment->buf.data(), segment->buf.capacity());
            if (segment->size <= 0) {
                buffer.push();
                buffer.done();
                if (segment->size < 0) {
                    return KIO::ERR_CANNOT_READ;
                }
                break;
            }
            buffer.push();
        }
        return KJob::NoError;
    }
```

#### AUTO 


```{c}
const auto freeKey = qScopeGuard([srv_pubkey] {
        ssh_key_free(srv_pubkey);
    });
```

#### AUTO 


```{c}
const auto quitLoop = [&e, &flushEntries]() {
               flushEntries();
               e.quit();
           };
```

#### AUTO 


```{c}
auto action
```

#### AUTO 


```{c}
auto fileContainsPattern = [&pattern](const QString &path) -> bool {
        QFile file(path);
        if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
            return false;
        }

        QTextStream in(&file);
        while (!in.atEnd()) {
            const QString line = in.readLine();
            if (line.contains(pattern)) {
                return true;
            }
        }

        return false;
    };
```

#### AUTO 


```{c}
auto it = services.begin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : entries)
            {
                QString sect;
                if (file.startsWith(man)) sect = file.mid(man.length());
                else if (file.startsWith(sman)) sect = file.mid(sman.length());
                // Should never happen, because of the name filter above.
                if (sect.isEmpty()) continue;

                if (sect.toLower()==it_real) it_real = sect;

                // Only add sect if not already contained, avoid duplicates
                if (!sect_list.contains(sect) && _section.isEmpty())
                {
                    //qCDebug(KIO_MAN_LOG) << "another section " << sect;
                    sect_list += sect;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &dirUrl : m_searchUrls) {
        if (urlString.startsWith(dirUrl.path())) {
            org::kde::KDirNotify::emitFilesAdded(dirUrl);
        }
    }
```

#### AUTO 


```{c}
const auto& actionInfo
```

#### AUTO 


```{c}
const auto result = d->init();
```

#### LAMBDA EXPRESSION 


```{c}
[&services](KDNSSD::RemoteService::Ptr service){
        qCDebug(KIO_SMB) << "DNSSD removed:"
                         << service->serviceName()
                         << service->type()
                         << service->domain()
                         << service->hostName()
                         << service->port();
        services.removeAll(service);
    }
```

#### AUTO 


```{c}
const auto it = std::find_if(list.constBegin(), list.constEnd(), [pathItems](const KMTPFile & file) {
                    return file.filename() == pathItems.last();
                });
```

#### AUTO 


```{c}
auto length = static_cast<KIO::filesize_t *>(data);
```

#### AUTO 


```{c}
auto stringFromIterators = [&](const QString::const_iterator &currentStart,
                                   const QString::const_iterator &currentPosition) {
        return pattern.mid(
                std::distance(begin, currentStart),
                std::distance(currentStart, currentPosition));
    };
```

#### AUTO 


```{c}
auto dnssdHost = QHostInfo::fromName(dnssd);
```

#### AUTO 


```{c}
auto splitPosition = strippedPath.indexOf("/");
```

#### AUTO 


```{c}
auto *theSlave = static_cast<SMBSlave *>(smbc_option_get(context, "user_data"));
```

#### AUTO 


```{c}
static const auto queryString = QStringLiteral(
                                            "SELECT targettedResource "
                                            "FROM ResourceLink "
                                            "WHERE usedActivity = '%1' "
                                            "AND initiatingAgent = \":global\" "
                                        );
```

#### AUTO 


```{c}
const auto urlList = items.urlList();
```

#### LAMBDA EXPRESSION 


```{c}
[&e, &flushEntries]() {
                flushEntries();
                e.quit();
            }
```

#### AUTO 


```{c}
const auto quitLoop = [&e, &flushEntries]() {
            flushEntries();
            e.quit();
        };
```

#### AUTO 


```{c}
auto pullFuture = std::async(std::launch::async, [&ring, &abort]() -> bool {
            for (auto i = 0; i <= runs && !abort; ++i) {
                auto s = ring.pop();
                if (!QTest::qCompare(s->buf.data()[0], static_cast<char>(i),
                                     qPrintable(QStringLiteral("On pull iteration %1").arg(i)), "",
                                     __FILE__, __LINE__)) {
                    abort = true;
                }
                // Slow down this thread to simulate slow local writes.
                std::this_thread::sleep_for(std::chrono::milliseconds(5));
                ring.unpop();
            }
            return true;
        });
```

#### AUTO 


```{c}
const auto result = d->openConnection();
```

#### AUTO 


```{c}
const auto& xAddrList = matchedService->xAddrList();
```

#### LAMBDA EXPRESSION 


```{c}
[](const struct smbc_notify_callback_action *actions, size_t num_actions, void *private_data) -> int {
        auto *context = static_cast<NotifyContext *>(private_data);

        // Some relevant docs for how this works under the hood
        //   https://docs.microsoft.com/en-us/openspecs/windows_protocols/ms-fasod/271a36e8-c94b-4527-8735-e884f5504cd9
        //   https://docs.microsoft.com/en-us/openspecs/windows_protocols/ms-smb2/14f9d050-27b2-49df-b009-54e08e8bf7b5

        qCDebug(KIO_SMB_LOG) << "notifiying for n actions:" << num_actions;

        // Moves are a bit award. They arrive in two subsequent events this object helps us collect the events.
        MoveAction pendingMove;

        // Values @ 2.7.1 FILE_NOTIFY_INFORMATION
        //   https://docs.microsoft.com/en-us/openspecs/windows_protocols/ms-fscc/634043d7-7b39-47e9-9e26-bda64685e4c9
        for (size_t i = 0; i < num_actions; ++i, ++actions) {
            qCDebug(KIO_SMB_LOG) << "  " << actions->action << actions->filename;
            QUrl url(context->url);
            url.setPath(url.path() + "/" + actions->filename);

            if (actions->action != SMBC_NOTIFY_ACTION_MODIFIED) {
                // If the current action isn't a modification forget a possible pending modification from a previous
                // action.
                // NB: by default every copy is followed by a move from f.part to f
                context->modificationLimiter.forget(url);
            }

            switch (actions->action) {
            case SMBC_NOTIFY_ACTION_ADDED:
                OrgKdeKDirNotifyInterface::emitFilesAdded(context->url /* dir */);
                continue;
            case SMBC_NOTIFY_ACTION_REMOVED:
                OrgKdeKDirNotifyInterface::emitFilesRemoved({url});
                continue;
            case SMBC_NOTIFY_ACTION_MODIFIED:
                context->modificationLimiter.notify(url);
                continue;
            case SMBC_NOTIFY_ACTION_OLD_NAME:
                Q_ASSERT(!pendingMove.isComplete());
                pendingMove.from = url;
                continue;
            case SMBC_NOTIFY_ACTION_NEW_NAME:
                pendingMove.to = url;
                Q_ASSERT(pendingMove.isComplete());
                OrgKdeKDirNotifyInterface::emitFileRenamed(pendingMove.from, pendingMove.to);
                pendingMove = MoveAction();
                continue;
            case SMBC_NOTIFY_ACTION_ADDED_STREAM: Q_FALLTHROUGH();
            case SMBC_NOTIFY_ACTION_REMOVED_STREAM: Q_FALLTHROUGH();
            case SMBC_NOTIFY_ACTION_MODIFIED_STREAM:
                // https://docs.microsoft.com/en-us/windows/win32/fileio/file-streams
                // Streams have no real use for us I think. They sound like proprietary
                // information an application might attach to a file.
                continue;
            }
            qCWarning(KIO_SMB_LOG) << "Unhandled action" << actions->action << "on URL" << url;
        }

        return 0;
    }
```

#### AUTO 


```{c}
const auto storages = mtpDevice->storages();
```

#### RANGE FOR STATEMENT 


```{c}
for (const KMTPFile &file : list) {
        argument << file;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&buffer, &filefd]() -> int {
        while (true) {
            TransferSegment *s = buffer.nextFree();
            s->size = smbc_read(filefd, s->buf.data(), s->buf.capacity());
            if (s->size <= 0) {
                buffer.push();
                buffer.done();
                if (s->size < 0) {
                    return KIO::ERR_CANNOT_READ;
                }
                break;
            }
            buffer.push();
        }
        return KJob::NoError;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &it : qAsConst(path))
        {
            const QString dir = QDir::cleanPath(it);
            QString mandir = manpath_map[ dir ];

            if ( !mandir.isEmpty() ) {
                // a path mapping exists
                if ( constr_path.indexOf( mandir ) == -1 )
                    constr_path += mandir;
            }
            else {
                // no manpath mapping, use "<path>/man" and "<path>/../man"

                mandir = dir + QString( "/man" );
                if ( constr_path.indexOf( mandir ) == -1 )
                    constr_path += mandir;

                int pos = dir.lastIndexOf( '/' );
                if ( pos > 0 ) {
                    mandir = dir.left( pos ) + QString("/man");
                    if ( constr_path.indexOf( mandir ) == -1 )
                        constr_path += mandir;
                }
            }
            QString catmandir = mandb_map[ mandir ];
            if ( !mandir.isEmpty() )
            {
                if ( constr_catmanpath.indexOf( catmandir ) == -1 )
                    constr_catmanpath += catmandir;
            }
            else
            {
                // What is the default mapping?
                catmandir = mandir;
                catmandir.replace("/usr/share/","/var/cache/");
                if ( constr_catmanpath.indexOf( catmandir ) == -1 )
                    constr_catmanpath += catmandir;
            }
        }
```

#### IF STATEMENT WITH INITIALIZER 


```{c}
if (const Result result = sftpSendMimetype(file, url); !result.success) {
        return result;
    }
```

#### AUTO 


```{c}
auto err = KSFTP_ISDIR(sb) ? KIO::ERR_DIR_ALREADY_EXIST : KIO::ERR_FILE_ALREADY_EXIST;
```

#### AUTO 


```{c}
const auto &coverList
```

#### RANGE FOR STATEMENT 


```{c}
for(const QUrl &scope : m_scopeList) {
        if(matchingScope == scope)
            return true;
    }
```

#### AUTO 


```{c}
auto walResult = ptr->pragma(QStringLiteral("journal_mode = WAL"));
```

#### AUTO 


```{c}
auto appendDiscovery = [&](const Discovery::Ptr &discovery) { list.append(discovery->toEntry()); };
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : files) {
        QUrl url(file);
        if (!url.isLocalFile()) {
            continue;
        }
        const QString urlPath = url.path();
        for (const QUrl &dirUrl : m_searchUrls) {
            if (urlPath.startsWith(dirUrl.path())) {
                url.setScheme(QStringLiteral("filenamesearch"));
                fileList << url;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& actionInfo: actions) {
        if (actionInfo.icon != "-") {
            auto action = new QAction(nullptr);

            action->setText(actionInfo.title);
            action->setIcon(QIcon::fromTheme(actionInfo.icon));
            action->setProperty("activity", actionInfo.activity);
            action->setProperty("link", actionInfo.link);

            rootMenu->addAction(action);

            connect(action, &QAction::triggered,
                    this, &Private::actionTriggered);

        } else {
            auto action = new QAction(actionInfo.title, nullptr);
            action->setSeparator(true);

            rootMenu->addAction(action);
        }
    }
```

#### AUTO 


```{c}
const auto i = static_cast<unsigned int>(iInt);
```

#### LAMBDA EXPRESSION 


```{c}
[&](KJob *, const KIO::UDSEntryList &list) {
        if (listJob->error()) {
            qCWarning(KIO_FILENAMESEARCH) << "Searching failed:" << listJob->errorText();
            return;
        }

        for (auto entry : list) {
            QUrl entryUrl(dirUrl);
            QString path = entryUrl.path();
            if (!path.endsWith(QLatin1Char('/'))) {
                path += QLatin1Char('/');
            }
            // UDS_NAME is e.g. "foo/bar/somefile.txt"
            entryUrl.setPath(path + entry.stringValue(KIO::UDSEntry::UDS_NAME));

            const QString urlStr = entryUrl.toDisplayString();
            entry.replace(KIO::UDSEntry::UDS_URL, urlStr);

            const QString fileName = entryUrl.fileName();
            entry.replace(KIO::UDSEntry::UDS_NAME, fileName);

            if (entry.isDir()) {
                // Also search the target of a dir symlink
                if (const QString linkDest = entry.stringValue(KIO::UDSEntry::UDS_LINK_DEST); !linkDest.isEmpty()) {
                    // Remember the dir to prevent endless loops
                    const auto [it, isInserted] = iteratedDirs.insert(linkDest);
                    if (isInserted) {
                        pendingDirs.push(entryUrl.resolved(QUrl(linkDest)));
                    }
                }

                iteratedDirs.insert(urlStr);
            }

            if (match(entry, regex, searchContents)) {
                // UDS_DISPLAY_NAME is e.g. "foo/bar/somefile.txt"
                entry.replace(KIO::UDSEntry::UDS_DISPLAY_NAME, fileName);
                listEntry(entry);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Cagibi::Device& upnpDevice : upnpDevices) {
        const QString ipAddress = upnpDevice.ipAddress();

        QMutableListIterator<NetDevice> it( deviceList );
        while( it.hasNext())
        {
            const NetDevice& device = it.next();
            if( device.ipAddress() == ipAddress )
            {
                QString id;
                for (const UpnpNetSystemAble* factory : mNetSystemFactoryList) {
                    if( factory->canCreateNetSystemFromUpnp(upnpDevice) )
                    {
                        id = factory->upnpId( upnpDevice );
                        break;
                    }
                }
                NetDevicePrivate* d = device.dPtr();
                NetService netService = d->removeService( id );
                if( ! netService.isValid() )
                    break;

                removedServices.append( netService );

                // remove device on last service
                if( d->serviceList().count() == 0 )
                {
                    removedDevices.append( device );
                    // remove only after taking copy from reference into removed list
                    it.remove();
                }
                break;
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&] { // finishes if all discoveries finished
            bool allFinished = true;
            for (auto discoverer : discoverers) {
                allFinished = allFinished && discoverer->isFinished();
            }
            if (allFinished) {
                quitLoop();
            }
        }
```

#### AUTO 


```{c}
auto createFn = (newCreator)library.resolve("new_creator");
```

#### RANGE FOR STATEMENT 


```{c}
for(const QUrl& scope : m_scopeList) {
        isMatch = probeMatchService->isMatchingScope(scope) && isMatch;
    }
```

#### AUTO 


```{c}
const auto domainMatch = domainExpression.match(info);
```

#### AUTO 


```{c}
const auto childValues = response.childValues();
```

#### LAMBDA EXPRESSION 


```{c}
[pattern](const KFileItem &item) -> bool {
            return item.text().contains(pattern);
        }
```

#### AUTO 


```{c}
auto apicFrame = dynamic_cast<TagLib::ID3v2::AttachedPictureFrame*>(map["APIC"].front());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &error : std::as_const(m_errors)) {
            qDebug() << "ERROR{" << KIO::buildErrorString(error.id, error.message) << "}";
        }
```

#### AUTO 


```{c}
const auto it = std::find_if(list.constBegin(), list.constEnd(), [pathItems](const KMTPFile &file) {
                    return file.filename() == pathItems.last();
                });
```

#### RANGE FOR STATEMENT 


```{c}
for (const NetService& service : serviceList) {
        const QString id = dirIdFor( service );
        notifyAboutAdded( id );
    }
```

#### AUTO 


```{c}
const auto getResult = sftpGet(url, offset, fd);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto actionInfo: actions) {
        if (actionInfo.icon != "-") {
            auto action = new QAction(nullptr);

            action->setText(actionInfo.title);
            action->setIcon(QIcon::fromTheme(actionInfo.icon));
            action->setProperty("activity", actionInfo.activity);
            action->setProperty("link", actionInfo.link);

            rootMenu->addAction(action);

            connect(action, &QAction::triggered,
                    this, &Private::actionTriggered);

        } else {
            auto action = new QAction(actionInfo.title, nullptr);
            action->setSeparator(true);

            rootMenu->addAction(action);
        }
    }
```

#### AUTO 


```{c}
const auto agents = agentValue.split(QLatin1Char(','));
```

#### AUTO 


```{c}
auto autoQueue = qScopeGuard([this] {
        queue();
    });
```

#### AUTO 


```{c}
const auto badInode = static_cast<ino_t>(-1);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& entry : qAsConst(entries)) {
        // Skip MacOS resource forks
        if (entry.startsWith(QLatin1String("__MACOSX"), Qt::CaseInsensitive) ||
                entry.startsWith(QLatin1String(".DS_Store"), Qt::CaseInsensitive)) {
            continue;
        }
        if (entry.endsWith(QLatin1String(".gif"), Qt::CaseInsensitive) ||
                entry.endsWith(QLatin1String(".jpg"), Qt::CaseInsensitive) ||
                entry.endsWith(QLatin1String(".jpeg"), Qt::CaseInsensitive) ||
                entry.endsWith(QLatin1String(".png"), Qt::CaseInsensitive)) {
            entryMap.insert(entry.toLower(), entry);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& activity: activitiesList) {
            actions << createAction(activity, true);
        }
```

#### IF STATEMENT WITH INITIALIZER 


```{c}
if (const auto [it, isInserted] = iteratedDirs.insert(linkDest); isInserted) {
                        pendingDirs.push_back(entryUrl.resolved(QUrl(linkDest)));
                    }
```

#### AUTO 


```{c}
auto fileSize = dir.fileInfo().size();
```

#### LAMBDA EXPRESSION 


```{c}
[](const QUrl &url) {
        return url.isLocalFile();
    }
```

#### AUTO 


```{c}
const auto fullPath = url.adjusted(QUrl::StripTrailingSlash).path();
```

#### AUTO 


```{c}
const auto data = coverData.data();
```

#### AUTO 


```{c}
auto future = std::async(std::launch::async, [&buffer, &filefd]() -> int {
        while (true) {
            TransferSegment *s = buffer.nextFree();
            s->size = smbc_read(filefd, s->buf.data(), s->buf.capacity());
            if (s->size <= 0) {
                buffer.push();
                buffer.done();
                if (s->size < 0) {
                    return KIO::ERR_COULD_NOT_READ;
                }
                break;
            }
            buffer.push();
        }
        return KJob::NoError;
    });
```

#### LAMBDA EXPRESSION 


```{c}
[&filePath, this]() -> ThumbCreatorWithMetadata* {
        const QMimeDatabase db;
        const QString subPlugin = pluginForMimeType(db.mimeTypeForFile(filePath).name());
        if (subPlugin.isEmpty() || !m_enabledPlugins.contains(subPlugin)) {
            return nullptr;
        }
        return getThumbCreator(subPlugin);
    }
```

#### AUTO 


```{c}
auto database = Common::Database::instance(
                            Common::Database::ResourcesDatabase,
                            Common::Database::ReadOnly);
```

#### AUTO 


```{c}
auto type
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &page : list)
        {
            // Remove any compression suffix present
            QString name = stripCompression(page);
            // Remove any preceding pathname components, just leave the base name
            int pos = name.lastIndexOf('/');
            if (pos>0) name = name.mid(pos+1);
            // Remove the section suffix
            pos = name.lastIndexOf('.');
            if (pos>0) name.truncate(pos);

            uds_entry.clear();
            uds_entry.fastInsert(KIO::UDSEntry::UDS_NAME, name);
            uds_entry.fastInsert(KIO::UDSEntry::UDS_URL, ("man:" + page));
            uds_entry.fastInsert(KIO::UDSEntry::UDS_FILE_TYPE, S_IFREG);
            uds_entry.fastInsert(KIO::UDSEntry::UDS_MIME_TYPE, QStringLiteral("text/html"));
            listEntry(uds_entry);
        }
```

#### AUTO 


```{c}
auto model = runQuery(url);
```

#### AUTO 


```{c}
const auto& scopeList = matchedService->scopeList();
```

#### AUTO 


```{c}
auto partUrl = tmpUrl("noResumeButPartial/thing.part");
```

#### LAMBDA EXPRESSION 


```{c}
[description] (KMTPStorageInterface *storage) {
        return storage->description() == description;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &section : qAsConst(childValues)) {
                computer = section
                        .childValues().child("Relationship")
                        .childValues().child("Host")
                        .childValues().child("Computer").value().toString();
                if (!computer.isEmpty()) {
                    break;
                }
            }
```

#### AUTO 


```{c}
auto maybeFinished = [&] { // finishes if all discoveries finished
                bool allFinished = true;
                for (auto discoverer : discoverers) {
                    allFinished = allFinished && discoverer->isFinished();
                }
                if (allFinished) {
                    quitLoop();
                }
            };
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& result: query) {
                auto path = result[0].toString();

                if (!QFile(path).exists()) continue;

                KIO::UDSEntry uds;

                udslist << d->filesystemEntry(path);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &name : entries) {
            if (!name.contains(QLatin1String("cover"), Qt::CaseInsensitive)) {
                continue;
            }

            entry = zip.directory()->entry(name);
            if (!entry || !entry->isFile()) {
                continue;
            }

            if (image.loadFromData(static_cast<const KZipFileEntry *>(entry)->data())) {
                return true;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](const struct smbc_notify_callback_action *actions, size_t num_actions, void *private_data) -> int {
        auto *context = static_cast<NotifyContext *>(private_data);

        // Some relevant docs for how this works under the hood
        //   https://docs.microsoft.com/en-us/openspecs/windows_protocols/ms-fasod/271a36e8-c94b-4527-8735-e884f5504cd9
        //   https://docs.microsoft.com/en-us/openspecs/windows_protocols/ms-smb2/14f9d050-27b2-49df-b009-54e08e8bf7b5

        qCDebug(KIO_SMB_LOG) << "notifying for n actions:" << num_actions;

        // Moves are a bit award. They arrive in two subsequent events this object helps us collect the events.
        MoveAction pendingMove;

        // Values @ 2.7.1 FILE_NOTIFY_INFORMATION
        //   https://docs.microsoft.com/en-us/openspecs/windows_protocols/ms-fscc/634043d7-7b39-47e9-9e26-bda64685e4c9
        for (size_t i = 0; i < num_actions; ++i, ++actions) {
            qCDebug(KIO_SMB_LOG) << "  " << actions->action << actions->filename;
            QUrl url(context->url);
            url.setPath(url.path() + "/" + actions->filename);

            if (actions->action != SMBC_NOTIFY_ACTION_MODIFIED) {
                // If the current action isn't a modification forget a possible pending modification from a previous
                // action.
                // NB: by default every copy is followed by a move from f.part to f
                context->modificationLimiter.forget(url);
            }

            switch (actions->action) {
            case SMBC_NOTIFY_ACTION_ADDED:
                OrgKdeKDirNotifyInterface::emitFilesAdded(context->url /* dir */);
                continue;
            case SMBC_NOTIFY_ACTION_REMOVED:
                OrgKdeKDirNotifyInterface::emitFilesRemoved({url});
                continue;
            case SMBC_NOTIFY_ACTION_MODIFIED:
                context->modificationLimiter.notify(url);
                continue;
            case SMBC_NOTIFY_ACTION_OLD_NAME:
                Q_ASSERT(!pendingMove.isComplete());
                pendingMove.from = url;
                continue;
            case SMBC_NOTIFY_ACTION_NEW_NAME:
                pendingMove.to = url;
                Q_ASSERT(pendingMove.isComplete());
                OrgKdeKDirNotifyInterface::emitFileRenamed(pendingMove.from, pendingMove.to);
                pendingMove = MoveAction();
                continue;
            case SMBC_NOTIFY_ACTION_ADDED_STREAM: Q_FALLTHROUGH();
            case SMBC_NOTIFY_ACTION_REMOVED_STREAM: Q_FALLTHROUGH();
            case SMBC_NOTIFY_ACTION_MODIFIED_STREAM:
                // https://docs.microsoft.com/en-us/windows/win32/fileio/file-streams
                // Streams have no real use for us I think. They sound like proprietary
                // information an application might attach to a file.
                continue;
            }
            qCWarning(KIO_SMB_LOG) << "Unhandled action" << actions->action << "on URL" << url;
        }

        return 0;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](KDNSSD::RemoteService::Ptr service){
        qCDebug(KIO_SMB_LOG) << "DNSSD added:"
                             << service->serviceName()
                             << service->type()
                             << service->domain()
                             << service->hostName()
                             << service->port();
        // Manual contains check. We need to use the == of the underlying
        // objects, not the pointers. The same service may have >1
        // RemoteService* instances representing it, so the == impl of
        // RemoteService::Ptr is useless here.
        for (const auto &servicePtr : qAsConst(m_services)) {
            if (*service == *servicePtr) {
                return;
            }
        }

        connect(service.data(), &KDNSSD::RemoteService::resolved,
                this, [=] {
            ++m_resolvedCount;
            emit newDiscovery(Discovery::Ptr(new DNSSDDiscovery(service)));
            maybeFinish();
        });

        // Schedule resolution of hostname. We'll later call resolve
        // which will block until the resolution is done. This basically
        // gives us a head start on discovery.
        service->resolveAsync();
        m_services.append(service);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &it_sect : qAsConst(m_sectionNames))
    {
        for (const QString &it_dir : dirs)
        {
            QDir d(it_dir+"/man"+it_sect);
            if (d.exists())
            {
                l << it_sect;
                break;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto action: rootMenu->actions()) {
        rootMenu->removeAction(action);
        action->deleteLater();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        queue();
    }
```

#### AUTO 


```{c}
auto ptr = std::make_shared<Database>();
```

#### AUTO 


```{c}
auto service = plugins.first();
```

#### LAMBDA EXPRESSION 


```{c}
[dh] { smbc_closedir(dh); }
```

#### AUTO 


```{c}
const auto& item
```

#### AUTO 


```{c}
auto aggregatedService = d->targetServiceMap.value(endpointReference);
```

#### AUTO 


```{c}
auto it = m_creators.constFind(plugin);
```

#### AUTO 


```{c}
auto pushFuture = std::async(std::launch::async, [&ring, &abort]() -> bool {
            for (auto i = 0; i <= runs && !abort; ++i) {
                auto s = ring.nextFree();
                memset(s->buf.data(), i, fileSize);
                if (abort) {
                    ring.done();
                    return false;
                }
                ring.push();
            }
            ring.done();
            return true;
        });
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &item : urlList) {
        service.asyncCall(
            link ? "LinkResourceToActivity" : "UnlinkResourceFromActivity",
            QString(),
            item.toLocalFile(),
            activity);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &it : services) {
            if (*service == *it) {
                return;
            }
        }
```

#### AUTO 


```{c}
const auto size = coverData.size();
```

#### AUTO 


```{c}
const auto& type
```

#### AUTO 


```{c}
auto dhClose = qScopeGuard([dh] { smbc_closedir(dh); });
```

#### AUTO 


```{c}
const auto flushEntries = [this, &list]() {
               if (list.isEmpty()) {
                   return;
               }
               listEntries(list);
               list.clear();
           };
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& entry : dirEntries) {
        const KArchiveEntry *e = dir->entry(entry);
        if (e->isDirectory()) {
        getArchiveFileList(entries, prefix + entry + '/',
            static_cast<const KArchiveDirectory*>(e));
        } else if (e->isFile()) {
            entries.append(prefix + entry);
        }
    }
```

#### AUTO 


```{c}
auto coverArtList = coverList.second.toCoverArtList();
```

#### RANGE FOR STATEMENT 


```{c}
for(const KDQName& type : qAsConst(m_typeList)) {
        isMatch = probeMatchService.isMatchingType(type) && isMatch;
    }
```

#### AUTO 


```{c}
const auto itemsSize = items.urlList().size();
```

#### RANGE FOR STATEMENT 


```{c}
for (const DNSSDNetSystemAble* factory : qAsConst(mNetSystemFactoryList)) {
                if( factory->canCreateNetSystemFromDNSSD(serviceType) )
                {
                    id = factory->dnssdId( service );
                    break;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &item : map) {
        if (item.second.type() != TagLib::APE::Item::Binary) {
            continue;
        }
        const auto coverData = item.second.binaryData();
        const auto data = coverData.data();
        const auto size = coverData.size();
        for (size_t i=0; i<size; ++i) {
            if (data[i] == '\0' && (i+1) < size) {
                const auto start = data+i+1;
                img.loadFromData((uchar *)start, size-(start-data));
                return true;
            }
        }
    }
```

#### AUTO 


```{c}
auto action = new QAction(actionInfo.title, nullptr);
```

#### LAMBDA EXPRESSION 


```{c}
[pathItems](const KMTPFile & file) {
                    return file.filename() == pathItems.last();
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& mime : mimeTypes) {
            if(mime.endsWith('*')) {
                const auto mimeGroup = mime.leftRef(mime.length()-1);
                if(mimeType.startsWith(mimeGroup))
                    return plugin->library();
            }
        }
```

#### AUTO 


```{c}
auto database = QSqlDatabase::addDatabase(
                                QStringLiteral("QSQLITE"),
                                connectionName);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &dir2 : qAsConst(constr_path))
            {
                if (dir2.isEmpty()) continue;		// don't add a null entry
                if (m_manpath.contains(dir2)) continue;	// ignore if already present
							// add to list if exists
                if (QDir(dir2).exists()) m_manpath += dir2;
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& mime : mimeTypes) {
            if(mime.endsWith('*')) {
                const auto mimeGroup = mime.leftRef(mime.length()-1);
                if(mimeType.startsWith(mimeGroup))
                    return plugin.fileName();
            }
        }
```

#### AUTO 


```{c}
const auto joinedMatch = notJoinedExpression.match(info);
```

#### AUTO 


```{c}
auto aggrigatedService = d->targetServiceMap.value(endpointReference);
```

#### AUTO 


```{c}
auto appendDiscovery = [&](const Discovery::Ptr &discovery) {
        if (discoveredNames.contains(discovery->udsName(), Qt::CaseInsensitive)) {
            return;
        }
        // Not tracking hosts. Tracking hosts means **guessing** if foo.local
        // and foo and foo.kio-discovery-wsd will actually resolve to the same
        // IP address, which is tricky to do at best. In the interest of efficiency
        // I'd rather have the de-duplication requirement be that the name of
        // two competing service discovery systems needs to be the same.
        discoveredNames << discovery->udsName();
        list.append(discovery->toEntry());
    };
```

#### AUTO 


```{c}
const auto &pool
```

#### AUTO 


```{c}
auto it = std::find_if(list.constBegin(), list.constEnd(), [element] (const KMTPFile &file) {
            return file.filename() == element;
        });
```

#### AUTO 


```{c}
const auto &section
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        browser.disconnect(); // Stop sending anything, we'll exit here.
        // Resolution still requires an event loop. So, let the resolutions
        // finish and then quit the loop. Services that fail resolution
        // get dropped since we won't be able to access them properly.
        for (auto it = services.begin(); it != services.end(); ++it) {
            auto service = *it;
            if (!service->resolve()) {
                qCWarning(KIO_SMB) << "Failed to resolve DNSSD service"
                                   << service->serviceName();
                it = services.erase(it);
            }
        }
        e.quit();
    }
```

#### AUTO 


```{c}
auto notify = [](const struct smbc_notify_callback_action *actions, size_t num_actions, void *private_data) -> int {
        auto *context = static_cast<NotifyContext *>(private_data);

        // Some relevant docs for how this works under the hood
        //   https://docs.microsoft.com/en-us/openspecs/windows_protocols/ms-fasod/271a36e8-c94b-4527-8735-e884f5504cd9
        //   https://docs.microsoft.com/en-us/openspecs/windows_protocols/ms-smb2/14f9d050-27b2-49df-b009-54e08e8bf7b5

        qCDebug(KIO_SMB_LOG) << "notifiying for n actions:" << num_actions;

        // Moves are a bit award. They arrive in two subsequent events this object helps us collect the events.
        MoveAction pendingMove;

        // Values @ 2.7.1 FILE_NOTIFY_INFORMATION
        //   https://docs.microsoft.com/en-us/openspecs/windows_protocols/ms-fscc/634043d7-7b39-47e9-9e26-bda64685e4c9
        for (size_t i = 0; i < num_actions; ++i, ++actions) {
            qCDebug(KIO_SMB_LOG) << "  " << actions->action << actions->filename;
            QUrl url(context->url);
            url.setPath(url.path() + "/" + actions->filename);

            if (actions->action != SMBC_NOTIFY_ACTION_MODIFIED) {
                // If the current action isn't a modification forget a possible pending modification from a previous
                // action.
                // NB: by default every copy is followed by a move from f.part to f
                context->modificationLimiter.forget(url);
            }

            switch (actions->action) {
            case SMBC_NOTIFY_ACTION_ADDED:
                OrgKdeKDirNotifyInterface::emitFilesAdded(context->url /* dir */);
                continue;
            case SMBC_NOTIFY_ACTION_REMOVED:
                OrgKdeKDirNotifyInterface::emitFilesRemoved({url});
                continue;
            case SMBC_NOTIFY_ACTION_MODIFIED:
                context->modificationLimiter.notify(url);
                continue;
            case SMBC_NOTIFY_ACTION_OLD_NAME:
                Q_ASSERT(!pendingMove.isComplete());
                pendingMove.from = url;
                continue;
            case SMBC_NOTIFY_ACTION_NEW_NAME:
                pendingMove.to = url;
                Q_ASSERT(pendingMove.isComplete());
                OrgKdeKDirNotifyInterface::emitFileRenamed(pendingMove.from, pendingMove.to);
                pendingMove = MoveAction();
                continue;
            case SMBC_NOTIFY_ACTION_ADDED_STREAM: Q_FALLTHROUGH();
            case SMBC_NOTIFY_ACTION_REMOVED_STREAM: Q_FALLTHROUGH();
            case SMBC_NOTIFY_ACTION_MODIFIED_STREAM:
                // https://docs.microsoft.com/en-us/windows/win32/fileio/file-streams
                // Streams have no real use for us I think. They sound like proprietary
                // information an application might attach to a file.
                continue;
            }
            qCWarning(KIO_SMB_LOG) << "Unhandled action" << actions->action << "on URL" << url;
        }

        return 0;
    };
```

#### AUTO 


```{c}
auto yscale = (1.0 * desiredHeight) / height;
```

#### LAMBDA EXPRESSION 


```{c}
[&hash] { ssh_clean_pubkey_hash(&hash); }
```

#### AUTO 


```{c}
auto resume = Transfer::shouldResume<QFileResumeIO>(url, KIO::Resume, &worker);
```

#### AUTO 


```{c}
const auto resume = optionalResume.value();
```

#### AUTO 


```{c}
const auto workgroupMatch = workgroupExpression.match(info);
```

#### IF STATEMENT WITH INITIALIZER 


```{c}
if (QUrlQuery query(*this); query.queryItemValue("kio-printer") == "true") {
        return m_type = SMBURLTYPE_PRINTER;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&filePath, this]() -> ThumbCreatorWithMetadata* {
        const QMimeDatabase db;
        const KPluginMetaData  subPlugin = pluginForMimeType(db.mimeTypeForFile(filePath).name());
        if (!subPlugin.isValid() || !m_enabledPlugins.contains(subPlugin.pluginId())) {
            return nullptr;
        }
        return getThumbCreator(subPlugin.fileName());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const KDQName &type : d->typeList) {
        if(matchingType.nameSpace() == type.nameSpace() &&
                matchingType.localName() == type.localName()) {
            return true;
        }
    }
```

#### AUTO 


```{c}
const auto &it
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& activity: activitiesList) {
                if (activitiesForLinking.contains(activity) ||
                        !activitiesForUnlinking.contains(activity)) {
                    actions << createAction(activity, true);
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for(const WSDiscovery200504::TNS__ProbeMatchType& probeMatch : probeMatches.probeMatch()) {
            const QString& endpointReference = probeMatch.endpointReference().address();
            QSharedPointer<WSDiscoveryTargetService> service = m_targetServiceMap.value(endpointReference);
            if(service.isNull()) {
                service = QSharedPointer<WSDiscoveryTargetService>::create(endpointReference);
                m_targetServiceMap.insert(endpointReference, service);
            }
            service->setTypeList(probeMatch.types().entries());
            service->setScopeList(QUrl::fromStringList(probeMatch.scopes().value().entries()));
            service->setXAddrList(QUrl::fromStringList(probeMatch.xAddrs().entries()));
            service->updateLastSeen();
            emit probeMatchReceived(service);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&] { // finishes if all discoveries finished
        bool allFinished = true;
        for (const auto &discoverer : discoverers) {
            allFinished = allFinished && discoverer->isFinished();
        }
        if (allFinished) {
            quitLoop();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[device] {
                            device->setDevicesUpdatedStatus(true);
                            org::kde::KDirNotify::emitFilesAdded(device->url());
                        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& activity: activities.activities()) {
                udslist << d->activityEntry(activity);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &section : qAsConst(childValues)) {
                computer = section
                           .childValues().child("Relationship")
                           .childValues().child("Host")
                           .childValues().child("Computer").value().toString();
                if (!computer.isEmpty()) {
                    break;
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[pathItems](const KMTPFile &file) {
                    return file.filename() == pathItems.last();
                }
```

#### AUTO 


```{c}
auto stringFromIterators = [&](const QString::const_iterator &currentStart,
    const QString::const_iterator &currentPosition) {
        return pattern.mid(
                   std::distance(begin, currentStart),
                   std::distance(currentStart, currentPosition));
    };
```

#### IF STATEMENT WITH INITIALIZER 


```{c}
if (KPluginInfo info(plugin); info.isValid()) {
            jsonMetaDataPlugins << info.toMetaData();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto query: queries) {
        result = execQuery(query);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto& type : typeList) {
        qDebug() << "  Type:"  << type.localName() << "in namespace" << type.nameSpace();
    }
```

#### AUTO 


```{c}
auto notifier = m_watches.take(url);
```

#### AUTO 


```{c}
const auto &entryName
```

#### AUTO 


```{c}
auto loader = FileItemLinkingPluginActionLoader::create(items);
```

#### AUTO 


```{c}
const auto activitiesList = activities.activities();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto entry : list) {
            QUrl entryUrl(dirUrl);
            QString path = entryUrl.path();
            if (!path.endsWith(QLatin1Char('/'))) {
                path += QLatin1Char('/');
            }
            // UDS_NAME is e.g. "foo/bar/somefile.txt"
            entryUrl.setPath(path + entry.stringValue(KIO::UDSEntry::UDS_NAME));

            const QString urlStr = entryUrl.toDisplayString();
            entry.replace(KIO::UDSEntry::UDS_URL, urlStr);

            const QString fileName = entryUrl.fileName();
            entry.replace(KIO::UDSEntry::UDS_NAME, fileName);

            if (entry.isDir()) {
                // Also search the target of a dir symlink
                if (const QString linkDest = entry.stringValue(KIO::UDSEntry::UDS_LINK_DEST); !linkDest.isEmpty()) {
                    // Remember the dir to prevent endless loops
                    if (const auto [it, isInserted] = iteratedDirs.insert(linkDest); isInserted) {
                        pendingDirs.push_back(entryUrl.resolved(QUrl(linkDest)));
                    }
                }

                iteratedDirs.insert(urlStr);
            }

            if (match(entry, regex, searchContents)) {
                // UDS_DISPLAY_NAME is e.g. "foo/bar/somefile.txt"
                entry.replace(KIO::UDSEntry::UDS_DISPLAY_NAME, fileName);
                listEntry(entry);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& activity: activitiesList) {
            actions << createAction(activity, false);
        }
```

#### AUTO 


```{c}
auto currentStart    = pattern.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& result: query) {
            auto path = result[0].toString();

            if (!QFile(path).exists()) continue;

            KIO::UDSEntry uds;

            udslist << d->filesystemEntry(path);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[dh]{ smbc_closedir(dh); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &pool : pools) {
            if (pool.minSize < wants) {
                continue;
            } else if (cacheSize == 0) {
                // the lowest cache size the thumbnail could be at
                cacheSize = pool.minSize;
            }
            // try in folders with higher image quality as well
            if (thumbnail.load(m_thumbBasePath + pool.path + thumbName, "png")) {
                break;
            }
        }
```

#### AUTO 


```{c}
const auto fileFree = qScopeGuard([file] { sftp_close(file); });
```

#### AUTO 


```{c}
auto query = database.execQuery(
        QStringLiteral("SELECT value FROM SchemaInfo WHERE key = 'version'"),
        /* ignore error */ true);
```

#### RANGE FOR STATEMENT 


```{c}
for(auto xAddr : matchedService->xAddrList()) {
        qDebug() << "  XAddr:" << xAddr.toString();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&](KJob *, const KIO::UDSEntryList &list) {
        if (listJob->error()) {
            qCWarning(KIO_FILENAMESEARCH) << "Searching failed:" << listJob->errorText();
            return;
        }

        for (auto entry : list) {
            QUrl entryUrl(dirUrl);
            QString path = entryUrl.path();
            if (!path.endsWith(QLatin1Char('/'))) {
                path += QLatin1Char('/');
            }
            // UDS_NAME is e.g. "foo/bar/somefile.txt"
            entryUrl.setPath(path + entry.stringValue(KIO::UDSEntry::UDS_NAME));

            const QString urlStr = entryUrl.toDisplayString();
            entry.replace(KIO::UDSEntry::UDS_URL, urlStr);

            const QString fileName = entryUrl.fileName();
            entry.replace(KIO::UDSEntry::UDS_NAME, fileName);

            if (entry.isDir()) {
                // Also search the target of a dir symlink
                if (const QString linkDest = entry.stringValue(KIO::UDSEntry::UDS_LINK_DEST); !linkDest.isEmpty()) {
                    // Remember the dir to prevent endless loops
                    if (const auto [it, isInserted] = iteratedDirs.insert(linkDest); isInserted) {
                        pendingDirs.push_back(entryUrl.resolved(QUrl(linkDest)));
                    }
                }

                iteratedDirs.insert(urlStr);
            }

            if (match(entry, regex, searchContents)) {
                // UDS_DISPLAY_NAME is e.g. "foo/bar/somefile.txt"
                entry.replace(KIO::UDSEntry::UDS_DISPLAY_NAME, fileName);
                listEntry(entry);
            }
        }
    }
```

#### AUTO 


```{c}
const auto blockSize =  dirStat.f_bsize * frames;
```

#### LAMBDA EXPRESSION 


```{c}
[&](const Discovery::Ptr &discovery) {
        if (discoveredNames.contains(discovery->udsName(), Qt::CaseInsensitive)) {
            return;
        }
        // Not tracking hosts. Tracking hosts means **guessing** if foo.local
        // and foo and foo.kio-discovery-wsd will actually resolve to the same
        // IP address, which is tricky to do at best. In the interest of efficiency
        // I'd rather have the de-duplication requirement be that the name of
        // two competing service discovery systems needs to be the same.
        discoveredNames << discovery->udsName();
        list.append(discovery->toEntry());
    }
```

#### AUTO 


```{c}
const auto urlList = fileItemInfos.urlList();
```

#### IF STATEMENT WITH INITIALIZER 


```{c}
if (const QString linkDest = entry.stringValue(KIO::UDSEntry::UDS_LINK_DEST); !linkDest.isEmpty()) {
                    // Remember the dir to prevent endless loops
                    const auto [it, isInserted] = iteratedDirs.insert(linkDest);
                    if (isInserted) {
                        pendingDirs.push(entryUrl.resolved(QUrl(linkDest)));
                    }
                }
```

#### LAMBDA EXPRESSION 


```{c}
[&](const Discovery::Ptr &discovery) {
        if (discoveredNames.contains(discovery->udsName(), Qt::CaseInsensitive)) {
            return;
        }
        // Not tracking hosts. Tracking hosts means **guessing** if foo.local
        // and foo and foo.kio-discovery-wsd will actually resolve to the same
        // IP address, which is tricky to do at best. In the interest of efficency
        // I'd rather have the de-duplication requirement be that the name of
        // two competing service discovery systems needs to be the same.
        discoveredNames << discovery->udsName();
        list.append(discovery->toEntry());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractNetworkBuilder* builder : qAsConst(mNetworkBuilderList)) {
        for (AbstractNetSystemFactory* factory : qAsConst(mNetSystemFactoryList)) {
            builder->registerNetSystemFactory( factory );
        }
        p->connect( builder, SIGNAL(initDone()), SLOT(onBuilderInit()) );
        builder->start();
    }
```

#### AUTO 


```{c}
auto match = regExp.match(output);
```

#### LAMBDA EXPRESSION 


```{c}
[element] (const KMTPFile &file) {
            return file.filename() == element;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, parentId, descriptor, filename] {
        int result = 1;
        QT_STATBUF srcBuf;
        if (QT_FSTAT(descriptor.fileDescriptor(), &srcBuf) != -1) {
            const QDateTime lastModified = QDateTime::fromSecsSinceEpoch(srcBuf.st_mtim.tv_sec);

            std::unique_ptr<LIBMTP_file_t> file(LIBMTP_new_file_t());
            file->parent_id = parentId;
            file->filename = qstrdup(filename.toUtf8().data());
            file->filetype = getFiletype(filename);
            file->filesize = quint64(srcBuf.st_size);
            file->modificationdate = lastModified.toSecsSinceEpoch();   // no matter what to set here, current time is taken
            file->storage_id = m_id;

            result = LIBMTP_Send_File_From_File_Descriptor(getDevice(), descriptor.fileDescriptor(), file.get(), onDataProgress, this);

            if (result) {
                LIBMTP_Dump_Errorstack(getDevice());
                LIBMTP_Clear_Errorstack(getDevice());
            }
        }
        Q_EMIT copyFinished(result);
    }
```

#### AUTO 


```{c}
const auto &map = file.tag()->itemMap();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &name : entries) {
            if (!name.contains(QLatin1String("cover"), Qt::CaseInsensitive)) {
                continue;
            }

            entry = zip.directory()->file(name);
            if (!entry) {
                continue;
            }

            zipDevice.reset(entry->createDevice());
            if (image.load(zipDevice.data(), "")) {
                return true;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(const KDQName& type : m_typeList) {
        isMatch = probeMatchService->isMatchingType(type) && isMatch;
    }
```

#### AUTO 


```{c}
const auto query
```

#### AUTO 


```{c}
const auto result = open(url, QIODevice::ReadOnly);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& entry : dirEntries) {
        const KArchiveEntry *e = dir->entry(entry);
        if (e->isDirectory()) {
            getArchiveFileList(entries, prefix + entry + '/',
                               static_cast<const KArchiveDirectory*>(e));
        } else if (e->isFile()) {
            entries.append(prefix + entry);
        }
    }
```

#### AUTO 


```{c}
const auto propertyList = properties.split(QChar(' '), Qt::SkipEmptyParts);
```

#### RANGE FOR STATEMENT 


```{c}
for(const QUrl& scope : qAsConst(m_scopeList)) {
        isMatch = probeMatchService.isMatchingScope(scope) && isMatch;
    }
```

#### AUTO 


```{c}
const auto model = runQuery(url);
```

#### AUTO 


```{c}
const auto mimeGroup = mime.leftRef(mime.length()-1);
```

#### AUTO 


```{c}
const auto path = QStringView(fullPath).mid(fullPath.startsWith(QLatin1Char('/')) ? 1 : 0);
```

#### AUTO 


```{c}
const auto storagePath = path.section(QLatin1Char('/'), 0, 2, QString::SectionIncludeLeadingSep);
```

#### AUTO 


```{c}
auto future = std::async(std::launch::async, [&buffer, &srcfd, &isErr]() -> int {
        while (!isErr) {
            TransferSegment *segment = buffer.nextFree();
            segment->size = smbc_read(srcfd, segment->buf.data(), segment->buf.capacity());
            if (segment->size <= 0) {
                buffer.push();
                buffer.done();
                if (segment->size < 0) {
                    return KIO::ERR_CANNOT_READ;
                }
                break;
            }
            buffer.push();
        }
        return KJob::NoError;
    });
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &element : pathItems) {
        const KMTPFileList list = getFilesAndFoldersCached(currentPath, currentParent);
        auto it = std::find_if(list.constBegin(), list.constEnd(), [element] (const KMTPFile &file) {
            return file.filename() == element;
        });

        if (it != list.constEnd()) {
            currentParent = it->itemId();
        } else {
            qCDebug(LOG_KIOD_KMTPD) << "File not found!";
            return KMTPFile();
        }
        currentPath.append(QLatin1Char('/') + element);
    }
```

#### AUTO 


```{c}
const auto *zipEntry = static_cast<const KZipFileEntry *>(entry);
```

#### AUTO 


```{c}
const auto freeHash = qScopeGuard([&hash] { ssh_clean_pubkey_hash(&hash); });
```

#### AUTO 


```{c}
const auto lenSize = static_cast<size_t>(len);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &plugin : plugins) {
        if (KPluginInfo info(plugin); info.isValid()) {
            jsonMetaDataPlugins << info.toMetaData();
        }
    }
```

#### AUTO 


```{c}
auto connectionName =
            QStringLiteral("kactivities_db_resources_")
            + QString::number((quintptr) this);
```

#### LAMBDA EXPRESSION 


```{c}
[this](Discovery::Ptr discovery) {
        ++m_resolvedCount;
        emit newDiscovery(discovery);
        maybeFinish();
    }
```

#### AUTO 


```{c}
auto dhClose = qScopeGuard([dh]{ smbc_closedir(dh); });
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& query: queries) {
        result = execQuery(query);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &dirUrl : qAsConst(m_searchUrls)) {
            if (urlPath.startsWith(dirUrl.path())) {
                url.setScheme(QStringLiteral("filenamesearch"));
                fileList << url;
            }
        }
```

#### AUTO 


```{c}
auto service = WSDiscoveryTargetService(endpointReference);
```

#### LAMBDA EXPRESSION 


```{c}
[this,&totalBytesSent](int bytes) {
                totalBytesSent += bytes;
                q->processedSize(totalBytesSent);
            }
```

#### AUTO 


```{c}
const auto result = sftpGet(url);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& mime : mimeTypes) {
            if(mime.endsWith('*')) {
                const auto mimeGroup = QStringView(mime).left(mime.length()-1);
                if(mimeType.startsWith(mimeGroup))
                    return plugin.fileName();
            }
        }
```

#### AUTO 


```{c}
auto strippedPath = path.mid(path.indexOf(QStringLiteral("/")) + 1);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto discoverer : discoverers) {
                   allFinished = allFinished && discoverer->isFinished();
               }
```

#### CONST EXPRESSION 


```{c}
constexpr auto HTTP_TIMEOUT = 20s;
```

#### AUTO 


```{c}
static const auto pools = {
            CachePool{QStringLiteral("normal/"), 128},
            CachePool{QStringLiteral("large/"), 256},
        };
```

#### RANGE FOR STATEMENT 


```{c}
for (const NetDevice& device : deviceList) {
        const QString id = dirIdFor( device );
        notifyAboutAdded( id );
    }
```

#### AUTO 


```{c}
auto segment = m_buffer[tail].get();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& activity: activitiesList) {
                if (activitiesForUnlinking.contains(activity)) {
                    actions << createAction(activity, false);
                }
            }
```

#### AUTO 


```{c}
const auto activity = result[0].toString();
```

#### AUTO 


```{c}
auto maybeFinished = [&] { // finishes if all discoveries finished
               bool allFinished = true;
               for (auto discoverer : discoverers) {
                   allFinished = allFinished && discoverer->isFinished();
               }
               if (allFinished) {
                   quitLoop();
               }
           };
```

#### AUTO 


```{c}
const auto quitLoop = [&e, &flushEntries]() {
                flushEntries();
                e.quit();
            };
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto activity: activities.activities()) {
                udslist << d->activityEntry(activity);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[&services](KDNSSD::RemoteService::Ptr service){
        qCDebug(KIO_SMB) << "DNSSD added:"
                         << service->serviceName()
                         << service->type()
                         << service->domain()
                         << service->hostName()
                         << service->port();
        // Manual contains check. We need to use the == of the underlying
        // objects, not the pointers. The same service may have >1
        // RemoteService* instances representing it, so the == impl of
        // RemoteService::Ptr is useless here.
        for (const auto &it : services) {
            if (*service == *it) {
                return;
            }
        }
        // Schedule resolution of hostname. We'll later call resolve
        // which will block until the resolution is done. This basically
        // gives us a head start.
        service->resolveAsync();
        services.append(service);
    }
```

#### AUTO 


```{c}
auto database = QSqlDatabase::addDatabase(
                QStringLiteral("QSQLITE"),
                connectionName);
```

#### LAMBDA EXPRESSION 


```{c}
[&] { // finishes if all discoveries finished
               bool allFinished = true;
               for (auto discoverer : discoverers) {
                   allFinished = allFinished && discoverer->isFinished();
               }
               if (allFinished) {
                   quitLoop();
               }
           }
```

#### IF STATEMENT WITH INITIALIZER 


```{c}
if (const Result result = sftpSendMimetype(mOpenFile, mOpenUrl); !result.success) {
            close();
            return result;
        }
```

#### AUTO 


```{c}
auto notify = [](const struct smbc_notify_callback_action *actions, size_t num_actions, void *private_data) -> int {
        auto *context = static_cast<NotifyContext *>(private_data);

        // Some relevant docs for how this works under the hood
        //   https://docs.microsoft.com/en-us/openspecs/windows_protocols/ms-fasod/271a36e8-c94b-4527-8735-e884f5504cd9
        //   https://docs.microsoft.com/en-us/openspecs/windows_protocols/ms-smb2/14f9d050-27b2-49df-b009-54e08e8bf7b5

        qCDebug(KIO_SMB_LOG) << "notifying for n actions:" << num_actions;

        // Moves are a bit award. They arrive in two subsequent events this object helps us collect the events.
        MoveAction pendingMove;

        // Values @ 2.7.1 FILE_NOTIFY_INFORMATION
        //   https://docs.microsoft.com/en-us/openspecs/windows_protocols/ms-fscc/634043d7-7b39-47e9-9e26-bda64685e4c9
        for (size_t i = 0; i < num_actions; ++i, ++actions) {
            qCDebug(KIO_SMB_LOG) << "  " << actions->action << actions->filename;
            QUrl url(context->url);
            url.setPath(url.path() + "/" + actions->filename);

            if (actions->action != SMBC_NOTIFY_ACTION_MODIFIED) {
                // If the current action isn't a modification forget a possible pending modification from a previous
                // action.
                // NB: by default every copy is followed by a move from f.part to f
                context->modificationLimiter.forget(url);
            }

            switch (actions->action) {
            case SMBC_NOTIFY_ACTION_ADDED:
                OrgKdeKDirNotifyInterface::emitFilesAdded(context->url /* dir */);
                continue;
            case SMBC_NOTIFY_ACTION_REMOVED:
                OrgKdeKDirNotifyInterface::emitFilesRemoved({url});
                continue;
            case SMBC_NOTIFY_ACTION_MODIFIED:
                context->modificationLimiter.notify(url);
                continue;
            case SMBC_NOTIFY_ACTION_OLD_NAME:
                Q_ASSERT(!pendingMove.isComplete());
                pendingMove.from = url;
                continue;
            case SMBC_NOTIFY_ACTION_NEW_NAME:
                pendingMove.to = url;
                Q_ASSERT(pendingMove.isComplete());
                OrgKdeKDirNotifyInterface::emitFileRenamed(pendingMove.from, pendingMove.to);
                pendingMove = MoveAction();
                continue;
            case SMBC_NOTIFY_ACTION_ADDED_STREAM: Q_FALLTHROUGH();
            case SMBC_NOTIFY_ACTION_REMOVED_STREAM: Q_FALLTHROUGH();
            case SMBC_NOTIFY_ACTION_MODIFIED_STREAM:
                // https://docs.microsoft.com/en-us/windows/win32/fileio/file-streams
                // Streams have no real use for us I think. They sound like proprietary
                // information an application might attach to a file.
                continue;
            }
            qCWarning(KIO_SMB_LOG) << "Unhandled action" << actions->action << "on URL" << url;
        }

        return 0;
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const MTPStorage *storage : m_storages) {
        list.append(QDBusObjectPath(storage->dbusObjectPath()));
    }
```

#### AUTO 


```{c}
const auto coverData = apicFrame->picture();
```

#### AUTO 


```{c}
auto s = ring.pop();
```

#### AUTO 


```{c}
const auto total = blockSize * dirStat.f_blocks;
```

#### AUTO 


```{c}
auto resolver = new WSDResolver(endpoint, this);
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString::const_iterator &currentStart,
                                   const QString::const_iterator &currentPosition) {
        return pattern.mid(
                std::distance(begin, currentStart),
                std::distance(currentStart, currentPosition));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const NetDevice& device : qAsConst(deviceList)) {
        const QString deviceHostName = device.hostName();
        const bool useIpAddress = ( deviceHostName.isEmpty() || hostName.isEmpty() );
        const bool isSameAddress = useIpAddress ?
            ( device.ipAddress() == ipAddress ) :
            ( deviceHostName == hostName );

        if( isSameAddress )
        {
            d = device.dPtr();
            // workaround: KDNSSD currently (4.7.0) emits two signals per service
            // just relying on service->serviceName() is fragile, but matches
            // current approach in removeService(...)
            QString id;
            const QString serviceType = service->type();
            for (const DNSSDNetSystemAble* factory : qAsConst(mNetSystemFactoryList)) {
                if( factory->canCreateNetSystemFromDNSSD(serviceType) )
                {
                    id = factory->dnssdId( service );
                    break;
                }
            }
            if( d->hasService(id) )
                return;

            deviceOfService = &device;
            break;
        }
    }
```

#### AUTO 


```{c}
auto datagram = testSocket.receiveDatagram();
```

#### CONST EXPRESSION 


```{c}
constexpr int readLimit = 1024;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QDBusObjectPath &storageName : storageNames) {
        m_storages.append(new KMTPStorageInterface(storageName.path(), this));
    }
```

#### AUTO 


```{c}
auto maybeFinished = [&] { // finishes if all discoveries finished
        bool allFinished = true;
        for (const auto &discoverer : discoverers) {
            allFinished = allFinished && discoverer->isFinished();
        }
        if (allFinished) {
            quitLoop();
        }
    };
```

#### AUTO 


```{c}
const auto &url
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& entry : qAsConst(entries)) {
        if (entry.endsWith(QLatin1String(".gif"), Qt::CaseInsensitive) ||
                entry.endsWith(QLatin1String(".jpg"), Qt::CaseInsensitive) ||
                entry.endsWith(QLatin1String(".jpeg"), Qt::CaseInsensitive) ||
                entry.endsWith(QLatin1String(".png"), Qt::CaseInsensitive)) {
            entryMap.insert(entry.toLower(), entry);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Cagibi::Device& upnpDevice : upnpDevices) {
        if( upnpDevice.hasParentDevice() )
            continue;

        const QString ipAddress = upnpDevice.ipAddress();

        NetDevicePrivate* d = nullptr;
        const NetDevice* deviceOfService = nullptr;
        for (const NetDevice& device : qAsConst(deviceList)) {
            const bool isSameAddress = ( device.ipAddress() == ipAddress );
//qDebug()<<"existing device:"<<device.hostName()<<"at"<<device.ipAddress()<<"vs."<<ipAddress<<":"<<isSameAddress;
            // TODO: lookup hostname and try to use that
            if( isSameAddress )
            {
                d = device.dPtr();
                deviceOfService = &device;
                break;
            }
        }
        if( ! d )
        {
            const QString displayName = upnpDevice.friendlyName();

            const QString deviceName = displayName;
            d = new NetDevicePrivate( deviceName );
            d->setIpAddress( ipAddress );

            NetDevice device( d );
            addedDevices.append( device );
            deviceList.append( device );
            deviceOfService = &deviceList.last();
//qDebug()<<"new device:"<<deviceName<<"at"<<ipAddress;
        }

        NetServicePrivate* netServicePrivate = nullptr;
        // do a priority based lookup who can build the object
        // TODO: priorisation
        for (const UpnpNetSystemAble* factory : qAsConst(mNetSystemFactoryList)) {
            if( factory->canCreateNetSystemFromUpnp(upnpDevice) )
            {
                // TODO: here we should rather see if this service already exists
                netServicePrivate = factory->createNetService( upnpDevice, *deviceOfService );
                break;
            }
        }

        NetService netService( netServicePrivate );
        d->addService( netService );

        addedServices.append( netService );
//qDebug()<<"new service:"<<netService.name()<<netService.url();

        // try guessing the device type by the services on it
        // TODO: move into  devicefactory
        const QString serviceType = upnpDevice.type();
        NetDevice::Type deviceTypeByService = NetDevice::Unknown;
        QString deviceName;
        if( serviceType == QLatin1String("InternetGatewayDevice1") )
            deviceTypeByService = NetDevice::Router;
        else if( serviceType == QLatin1String("PrinterBasic1")
                 || serviceType == QLatin1String("PrinterEnhanced1") )
            deviceTypeByService = NetDevice::Printer;
        else if( serviceType == QLatin1String("Scanner1") )
            deviceTypeByService = NetDevice::Scanner;

        if( deviceTypeByService != NetDevice::Unknown )
        {
            if( deviceTypeByService > d->type() )
            {
                d->setType( deviceTypeByService );
                if( ! deviceName.isEmpty() )
                    d->setName( deviceName );
            }
        }
    }
```

#### AUTO 


```{c}
constexpr auto MATCH_TIMEOUT = 10s;
```

#### LAMBDA EXPRESSION 


```{c}
[&ring, &abort]() -> bool {
            for (auto i = 0; i <= runs && !abort; ++i) {
                auto s = ring.pop();
                if (!QTest::qCompare(s->buf.data()[0], static_cast<char>(i),
                                     qPrintable(QStringLiteral("On pull iteration %1").arg(i)), "",
                                     __FILE__, __LINE__)) {
                    abort = true;
                    return false;
                }
                ring.unpop();
            }
            return true;
        }
```

#### AUTO 


```{c}
const auto activity
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &man_dir : man_dirs)
        {
            // Find all subdirectories named "man*" and "sman*"
            // to extend the list of sections and find the correct
            // case for the section suffix.
            QDir dp(man_dir);
            dp.setFilter(QDir::Dirs|QDir::NoDotAndDotDot);
            dp.setNameFilters(nameFilters);
            const QStringList entries = dp.entryList();
            for (const QString &file : entries)
            {
                QString sect;
                if (file.startsWith(man)) sect = file.mid(man.length());
                else if (file.startsWith(sman)) sect = file.mid(sman.length());
                // Should never happen, because of the name filter above.
                if (sect.isEmpty()) continue;

                if (sect.toLower()==it_real) it_real = sect;

                // Only add sect if not already contained, avoid duplicates
                if (!sect_list.contains(sect) && _section.isEmpty())
                {
                    //qCDebug(KIO_MAN_LOG) << "another section " << sect;
                    sect_list += sect;
                }
            }

            if (it_s!=star)				// finding pages, not just sections
            {
                const QString dir = man_dir + '/' + man + it_real + '/';
                list.append(findManPagesInSection(dir, title, full_path));

                const QString sdir = man_dir + '/' + sman + it_real + '/';
                list.append(findManPagesInSection(sdir, title, full_path));
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[dstFile](struct utimbuf utbuf) {
        utbuf.actime = QFileInfo(dstFile).lastRead().toSecsSinceEpoch(); // access time, unchanged
        utime(QFile::encodeName(dstFile).constData(), &utbuf);
    }
```

#### AUTO 


```{c}
const auto types = typeValue.split(QLatin1Char(','));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto entryName: dir->entries()) {
        auto entry = dir->entry(entryName);
        if (entry->isFile()) {
            auto fileEntry = static_cast<const KArchiveFile *>(entry);
            totalSize += fileEntry->size();
        }
        else if (entry->isDirectory()) {
            const auto dirEntry = static_cast<const KArchiveDirectory *>(entry);
            // recurse
            totalSize += computeArchiveDirSize(dirEntry);
        }
    }
```

#### AUTO 


```{c}
const auto& scope
```

#### LAMBDA EXPRESSION 


```{c}
[](const struct smbc_notify_callback_action *actions, size_t num_actions, void *private_data) -> int {
        auto *context = static_cast<NotifyContext *>(private_data);

        // Some relevant docs for how this works under the hood
        //   https://docs.microsoft.com/en-us/openspecs/windows_protocols/ms-fasod/271a36e8-c94b-4527-8735-e884f5504cd9
        //   https://docs.microsoft.com/en-us/openspecs/windows_protocols/ms-smb2/14f9d050-27b2-49df-b009-54e08e8bf7b5

        qCDebug(KIO_SMB_LOG) << "notifying for n actions:" << num_actions;

        // Moves are a bit award. They arrive in two subsequent events this object helps us collect the events.
        MoveAction pendingMove;

        // Values @ 2.7.1 FILE_NOTIFY_INFORMATION
        //   https://docs.microsoft.com/en-us/openspecs/windows_protocols/ms-fscc/634043d7-7b39-47e9-9e26-bda64685e4c9
        for (size_t i = 0; i < num_actions; ++i, ++actions) {
            qCDebug(KIO_SMB_LOG) << "  " << actions->action << actions->filename;
            QUrl url(context->url);
            url.setPath(url.path() + "/" + actions->filename);

            if (actions->action != SMBC_NOTIFY_ACTION_MODIFIED) {
                // If the current action isn't a modification forget a possible pending modification from a previous
                // action.
                // NB: by default every copy is followed by a move from f.part to f
                context->modificationLimiter.forget(url);
            }

            context->pendingRemove.newEventFor(actions->action, url);

            switch (actions->action) {
            case SMBC_NOTIFY_ACTION_ADDED:
                OrgKdeKDirNotifyInterface::emitFilesAdded(context->url /* dir */);
                continue;
            case SMBC_NOTIFY_ACTION_REMOVED:
                context->pendingRemove.schedule(url);
                continue;
            case SMBC_NOTIFY_ACTION_MODIFIED:
                context->modificationLimiter.notify(url);
                continue;
            case SMBC_NOTIFY_ACTION_OLD_NAME:
                Q_ASSERT(!pendingMove.isComplete());
                pendingMove.from = url;
                continue;
            case SMBC_NOTIFY_ACTION_NEW_NAME:
                pendingMove.to = url;
                Q_ASSERT(pendingMove.isComplete());
                OrgKdeKDirNotifyInterface::emitFileRenamed(pendingMove.from, pendingMove.to);
                pendingMove = MoveAction();
                continue;
            case SMBC_NOTIFY_ACTION_ADDED_STREAM:
                Q_FALLTHROUGH();
            case SMBC_NOTIFY_ACTION_REMOVED_STREAM:
                Q_FALLTHROUGH();
            case SMBC_NOTIFY_ACTION_MODIFIED_STREAM:
                // https://docs.microsoft.com/en-us/windows/win32/fileio/file-streams
                // Streams have no real use for us I think. They sound like proprietary
                // information an application might attach to a file.
                continue;
            }
            qCWarning(KIO_SMB_LOG) << "Unhandled action" << actions->action << "on URL" << url;
        }

        return 0;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &it_sect : qAsConst(sections))
    {
        if (it_sect.isEmpty()) continue;		// guard back() below

        // create a unique access key
        QChar accessKey = it_sect.back();		// rightmost char
        while (accessKeys.contains(accessKey)) accessKey = alternateAccessKey++;
        accessKeys.insert(accessKey);

        os << "<tr><td><a href=\"man:(" << it_sect << ")\" accesskey=\"" << accessKey
           << "\">" << i18n("Section %1", it_sect)
           << "</a></td><td>&nbsp;</td><td> " << sectionName(it_sect) << "</td></tr>\n";
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&](KJob *, const KIO::UDSEntryList &list) {
        if (listJob->error()) {
            qCWarning(KIO_FILENAMESEARCH) << "Searching failed:" << listJob->errorText();
            return;
        }

        for (auto entry : list) {
            QUrl entryUrl(dirUrl);
            QString path = entryUrl.path();
            if (!path.endsWith(QLatin1Char('/'))) {
                path += QLatin1Char('/');
            }
            // UDS_NAME is e.g. "foo/bar/somefile.txt"
            entryUrl.setPath(path + entry.stringValue(KIO::UDSEntry::UDS_NAME));

            const QString urlStr = entryUrl.toDisplayString();
            entry.replace(KIO::UDSEntry::UDS_URL, urlStr);

            const QString fileName = entryUrl.fileName();
            entry.replace(KIO::UDSEntry::UDS_NAME, fileName);

            if (entry.isDir()) {
                // Also search the target of a dir symlink
                if (const QString linkDest = entry.stringValue(KIO::UDSEntry::UDS_LINK_DEST); !linkDest.isEmpty()) {
                    // Remember the dir to prevent endless loops
                    if (const auto [it, isInserted] = iteratedDirs.insert(linkDest); isInserted) {
                        pendingDirs.push(entryUrl.resolved(QUrl(linkDest)));
                    }
                }

                iteratedDirs.insert(urlStr);
            }

            if (match(entry, regex, searchContents)) {
                // UDS_DISPLAY_NAME is e.g. "foo/bar/somefile.txt"
                entry.replace(KIO::UDSEntry::UDS_DISPLAY_NAME, fileName);
                listEntry(entry);
            }
        }
    }
```

#### AUTO 


```{c}
const auto entries = zip.directory()->entries();
```

#### AUTO 


```{c}
auto deviceIt = std::find_if(m_devices.constBegin(), m_devices.constEnd(), [udi] (const KMTPDeviceInterface *device) {
        return device->udi() == udi;
    });
```

#### AUTO 


```{c}
const auto textLines = text.splitRef(QLatin1Char('\n'));
```

#### LAMBDA EXPRESSION 


```{c}
[&services](KDNSSD::RemoteService::Ptr service){
        qCDebug(KIO_SMB_LOG) << "DNSSD added:"
                         << service->serviceName()
                         << service->type()
                         << service->domain()
                         << service->hostName()
                         << service->port();
        // Manual contains check. We need to use the == of the underlying
        // objects, not the pointers. The same service may have >1
        // RemoteService* instances representing it, so the == impl of
        // RemoteService::Ptr is useless here.
        for (const auto &it : services) {
            if (*service == *it) {
                return;
            }
        }
        // Schedule resolution of hostname. We'll later call resolve
        // which will block until the resolution is done. This basically
        // gives us a head start.
        service->resolveAsync();
        services.append(service);
    }
```

#### AUTO 


```{c}
auto pullFuture = std::async(std::launch::async, [&ring, &abort]() -> bool {
            for (auto i = 0; i <= runs && !abort; ++i) {
                auto s = ring.pop();
                if (!QTest::qCompare(s->buf.data()[0], static_cast<char>(i),
                                     qPrintable(QStringLiteral("On pull iteration %1").arg(i)), "",
                                     __FILE__, __LINE__)) {
                    abort = true;
                    return false;
                }
                ring.unpop();
            }
            return true;
        });
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString::const_iterator &currentStart,
    const QString::const_iterator &currentPosition) {
        return pattern.mid(
                   std::distance(begin, currentStart),
                   std::distance(currentStart, currentPosition));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &xAddr : service.xAddrList()) {
        // https://docs.microsoft.com/en-us/windows/win32/wsdapi/xaddr-validation-rules
        // "At least one IP address included in the XAddrs (or IP address resolved from
        // a hostname included in the XAddrs) must be on the same subnet as the adapter
        // over which the ProbeMatches or ResolveMatches message was received."
        const auto hostInfo = QHostInfo::fromName(xAddr.host());
        if (hostInfo.error() == QHostInfo::NoError) {
            addr = xAddr;
            break;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[pattern](const KFileItem &item) -> bool {
            return item.determineMimeType().inherits(QStringLiteral("text/plain")) &&
                   contentContainsPattern(item.url(), pattern);
        }
```

#### AUTO 


```{c}
static const auto queryString = QStringLiteral(
                "SELECT usedActivity, COUNT(targettedResource) "
                "FROM ResourceLink "
                "WHERE targettedResource IN (%1) "
                    "AND initiatingAgent = \":global\" "
                    "AND usedActivity != \":global\" "
                "GROUP BY usedActivity");
```

#### RANGE FOR STATEMENT 


```{c}
for (const NetDevice& device : deviceList) {
        const QString dirId = dirIdFor( device );
        const QString itemPath = pathFor( device );
        notifyAboutRemoved( dirId, itemPath );
    }
```

#### AUTO 


```{c}
auto entry = dir->entry(entryName);
```

#### IF STATEMENT WITH INITIALIZER 


```{c}
if (const QString linkDest = entry.stringValue(KIO::UDSEntry::UDS_LINK_DEST); !linkDest.isEmpty()) {
                    // Remember the dir to prevent endless loops
                    if (const auto [it, isInserted] = iteratedDirs.insert(linkDest); isInserted) {
                        pendingDirs.push(entryUrl.resolved(QUrl(linkDest)));
                    }
                }
```

#### AUTO 


```{c}
auto scope
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &url: qAsConst(urls)) {
            if (url.isLocalFile() || url.scheme().isEmpty()) {
                paths.append(url.path());
            } else {
                paths.append(url.toString());
            }
        }
```

#### AUTO 


```{c}
auto result = d->query(query);
```

#### AUTO 


```{c}
const auto storageNames = m_dbusInterface->listStorages().value();
```

#### AUTO 


```{c}
static const auto pools = {
            CachePool{QStringLiteral("normal/"), 128},
            CachePool{QStringLiteral("large/"), 256},
            CachePool{QStringLiteral("x-large/"), 512},
            CachePool{QStringLiteral("xx-large/"), 1024},
        };
```

#### AUTO 


```{c}
auto hostInfo = QHostInfo::fromName(m_endpointUrl.host());
```

#### AUTO 


```{c}
auto oldestIt = m_limiter.begin();
```

#### AUTO 


```{c}
static const auto queryString = QStringLiteral(
                "SELECT targettedResource "
                "FROM ResourceLink "
                "WHERE usedActivity = '%1' "
                    "AND initiatingAgent = \":global\" "
                );
```

#### LAMBDA EXPRESSION 


```{c}
[&ring, &abort]() -> bool {
            for (auto i = 0; i <= runs && !abort; ++i) {
                auto s = ring.pop();
                if (!QTest::qCompare(s->buf.data()[0], static_cast<char>(i),
                                     qPrintable(QStringLiteral("On pull iteration %1").arg(i)), "",
                                     __FILE__, __LINE__)) {
                    abort = true;
                }
                // Slow down this thread to simulate slow local writes.
                std::this_thread::sleep_for(std::chrono::milliseconds(5));
                ring.unpop();
            }
            return true;
        }
```

#### AUTO 


```{c}
const auto *entry = zip.directory()->file(QStringLiteral("META-INF/container.xml"));
```

#### AUTO 


```{c}
const auto entries = dir->entries();
```

#### RANGE FOR STATEMENT 


```{c}
for (const UpnpNetSystemAble* factory : qAsConst(mNetSystemFactoryList)) {
                    if( factory->canCreateNetSystemFromUpnp(upnpDevice) )
                    {
                        id = factory->upnpId( upnpDevice );
                        break;
                    }
                }
```

#### AUTO 


```{c}
auto job = new KIO::ApplicationLauncherJob(bookmarksKCM);
```

#### AUTO 


```{c}
const auto mimeGroup = QStringView(mime).left(mime.length()-1);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &pool : pools) {
            if (pool.minSize < wants) {
                continue;
            } else if (cacheSize == 0) {
                // the lowest cache size the thumbnail could be at
                cacheSize = pool.minSize;
            }
            // try in folders with higher image quality as well
            if (thumbnail.load(m_thumbBasePath + pool.path + thumbName, "png")) {
                thumbnail.setDevicePixelRatio(m_devicePixelRatio);
                break;
            }
        }
```

#### AUTO 


```{c}
const auto freeFingerprint = qScopeGuard([fingerprint] {
        ssh_string_free_char(fingerprint);
    });
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &picture : pictureList) {
        if (picture->type() != TagLib::FLAC::Picture::FrontCover) {
            continue;
        }
        const auto coverData = picture->data();
        img.loadFromData((uchar *)coverData.data(), coverData.size());
        return true;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& mime : mimeTypes) {
            if(mime.endsWith('*')) {
                const auto mimeGroup = QStringView(mime).left(mime.length()-1);
                if(mimeType.startsWith(mimeGroup)) {
                    return plugin;
                }
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[file]{ sftp_close(file); }
```

#### AUTO 


```{c}
static const auto queryString = QStringLiteral(
                    "SELECT usedActivity, COUNT(targettedResource) "
                    "FROM ResourceLink "
                    "WHERE targettedResource IN (%1) "
                        "AND initiatingAgent = \":global\" "
                        "AND usedActivity != \":global\" "
                    "GROUP BY usedActivity");
```

#### LAMBDA EXPRESSION 


```{c}
[this, fileItems, fileItemInfos](){
        QList<QUrl> urls;
        for (const auto &item: fileItems) {
            urls << item.targetUrl();
        }

        QByteArray packedArgs;
        QDataStream stream(&packedArgs, QIODevice::WriteOnly);
        stream << int(1); // Forget, see kio-extras/recentlyused/recentlyused.cpp special
        stream << urls;

        auto job = KIO::special(QUrl(QStringLiteral("recentlyused:/")), packedArgs);

        connect(job, &KJob::finished, this, [fileItems](const KJob *job) {
            if (!job->error()) {
                org::kde::KDirNotify::emitFilesRemoved({fileItems.urlList()});
            }
        });
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const NetService& service : serviceList) {
                if( service.name() == serviceName && service.type() == serviceType )
                {
                    result = service;
                    break;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &sect : m_sectionNames)
        {
            uds_entry.clear();				// sectionName() is already I18N'ed
            uds_entry.fastInsert( KIO::UDSEntry::UDS_NAME, (sect + " - " + sectionName(sect)) );
            uds_entry.fastInsert( KIO::UDSEntry::UDS_URL, ("man:/(" + sect + ')') );
            uds_entry.fastInsert( KIO::UDSEntry::UDS_FILE_TYPE, S_IFDIR );
            listEntry(uds_entry);
        }
```

#### AUTO 


```{c}
constexpr auto HTTP_TIMEOUT = 20s;
```

#### RANGE FOR STATEMENT 


```{c}
for (const DNSSDNetSystemAble* factory : qAsConst(mNetSystemFactoryList)) {
        if( factory->canCreateNetSystemFromDNSSD(serviceType) )
        {
            // TODO: here we should rather see if this service already exists
            netServicePrivate = factory->createNetService( service, *deviceOfService );
            break;
        }
    }
```

#### AUTO 


```{c}
const auto& result
```

#### AUTO 


```{c}
const auto flushEntries = [this, &list]() {
            if (list.isEmpty()) {
                return;
            }
            listEntries(list);
            list.clear();
        };
```

#### LAMBDA EXPRESSION 


```{c}
[&services](KDNSSD::RemoteService::Ptr service){
        qCDebug(KIO_SMB_LOG) << "DNSSD removed:"
                         << service->serviceName()
                         << service->type()
                         << service->domain()
                         << service->hostName()
                         << service->port();
        services.removeAll(service);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KMTPFile &file : files) {
                        listEntry(getEntry(file));
                    }
```

#### AUTO 


```{c}
auto url = QUrl::fromLocalFile(path);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &it_name : qAsConst(names))
        {
            count0 = i.count();
            if (addWhatIs(i, (it_dir+'/'+it_name), mark))
            {
                qCDebug(KIO_MAN_LOG) << "added" << (i.count()-count0) << "from" << it_name << "in" << it_dir;
                added = true;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Mollet::NetService& serviceData : serviceDataList) {
                        KIO::UDSEntry entry;
                        feedEntryAsService( &entry, serviceData );
                        listEntry( entry );
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &name : names)
    {
        if (title_given)
        {
            // check title if we're looking for a specific page
            if (!name.startsWith(title)) continue;
            // beginning matches, do a more thorough check...
            const QString tmp_name = stripExtension(name);
            if (tmp_name!=title) continue;
        }

        list.append(full_path ? dir+name : name);
    }
```

#### AUTO 


```{c}
auto action = new QAction(actionInfo.title, Q_NULLPTR);
```

#### AUTO 


```{c}
auto action = new QAction(Q_NULLPTR);
```

#### LAMBDA EXPRESSION 


```{c}
[=] {
            ++m_resolvedCount;
            emit newDiscovery(Discovery::Ptr(new DNSSDDiscovery(service)));
            maybeFinish();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&buffer, &filefd]() -> int {
        while (true) {
            TransferSegment *s = buffer.nextFree();
            s->size = smbc_read(filefd, s->buf.data(), s->buf.capacity());
            if (s->size <= 0) {
                buffer.push();
                buffer.done();
                if (s->size < 0) {
                    return KIO::ERR_COULD_NOT_READ;
                }
                break;
            }
            buffer.push();
        }
        return KJob::NoError;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &line : output) {
        if ( regExp.indexIn(line) != -1 && regExp.cap(1).toInt() == 14 )
            icons << qMakePair(regExp.cap(2), 14);
    }
```

#### AUTO 


```{c}
const auto *relsFileEntry = static_cast<const KZipFileEntry *>(relsEntry);
```

#### LAMBDA EXPRESSION 


```{c}
[this, itemId, descriptor] {
            const int result = LIBMTP_Get_File_To_File_Descriptor(getDevice(), itemId, descriptor.fileDescriptor(), onDataProgress, this);
            if (result) {
                LIBMTP_Dump_Errorstack(getDevice());
                LIBMTP_Clear_Errorstack(getDevice());
            }
            emit copyFinished(result);
        }
```

#### AUTO 


```{c}
const auto srcSize = st.st_size;
```

#### AUTO 


```{c}
const auto quitLoop = [&e, &flushEntries]() {
        flushEntries();
        e.quit();
    };
```

#### AUTO 


```{c}
const auto bytesread = request.readChunks(filedata);
```

#### AUTO 


```{c}
auto strippedPath = path.mid(path.indexOf("/") + 1);
```

#### AUTO 


```{c}
auto details = getStatDetails();
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &item : items) {
        if (itemValidator(item)) {
            KIO::UDSEntry entry = item.entry();
            entry.replace(KIO::UDSEntry::UDS_URL, item.url().url());
            listEntry(entry);
        }

        if (item.isDir()) {
            if (item.isLink()) {
                // Assure that no endless searching is done in directories that
                // have already been iterated.
                const QUrl linkDest = item.url().resolved(QUrl::fromLocalFile(item.linkDest()));
                if (!iteratedDirs.contains(linkDest.path())) {
                    pendingDirs.append(linkDest);
                }
            } else {
                pendingDirs.append(item.url());
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const NetService& service : serviceList) {
        const QString dirId = dirIdFor( service );
        const QString itemPath = pathFor( service );
        notifyAboutRemoved( dirId, itemPath );
    }
```

#### AUTO 


```{c}
auto endpointReference = receivedService.endpointReference();
```

#### AUTO 


```{c}
const auto directoryEntry = static_cast<const KArchiveDirectory *>(archiveEntry);
```

#### AUTO 


```{c}
auto query = database.execQuery(
                     QStringLiteral("SELECT value FROM SchemaInfo WHERE key = 'version'"),
                     /* ignore error */ true);
```

#### AUTO 


```{c}
auto query = UsedResources
                 | Limit(30);
```

#### LAMBDA EXPRESSION 


```{c}
[this, itemId, descriptor] {
            const int result = LIBMTP_Get_File_To_File_Descriptor(getDevice(), itemId, descriptor.fileDescriptor(), onDataProgress, this);
            if (result) {
                LIBMTP_Dump_Errorstack(getDevice());
                LIBMTP_Clear_Errorstack(getDevice());
            }
            Q_EMIT copyFinished(result);
        }
```

#### AUTO 


```{c}
auto *slave = static_cast<SFTPInternal *>(userdata);
```

#### LAMBDA EXPRESSION 


```{c}
[this, &list]() {
                if (list.isEmpty()) {
                    return;
                }
                listEntries(list);
                list.clear();
            }
```

#### AUTO 


```{c}
auto i = 0;
```

#### AUTO 


```{c}
auto scopeList = QList<QUrl>() << QUrl(QStringLiteral("onvif://www.onvif.org/Profile/Streaming"));
```

#### RANGE FOR STATEMENT 


```{c}
for(const WSDiscovery200504::TNS__ProbeMatchType& probeMatch : probeMatchList) {
            const QString& endpointReference = probeMatch.endpointReference().address();
            auto service = WSDiscoveryTargetService(endpointReference);
            service.setTypeList(probeMatch.types().entries());
            service.setScopeList(QUrl::fromStringList(probeMatch.scopes().value().entries()));
            service.setXAddrList(QUrl::fromStringList(probeMatch.xAddrs().entries()));
            service.updateLastSeen();
            emit probeMatchReceived(service);
        }
```

#### AUTO 


```{c}
auto url = tmpUrl("resumeInPlace/thing");
```

#### AUTO 


```{c}
auto appendDiscovery = [&](const Discovery::Ptr &discovery) {
            if (discoveredNames.contains(discovery->udsName())) {
                return;
            }
            discoveredNames << discovery->udsName();
            list.append(discovery->toEntry());
        };
```

#### AUTO 


```{c}
auto zeroedDatagram = zeroOutUuid(datagram.data());
```

#### AUTO 


```{c}
auto urlQuery = QUrlQuery(url);
```

#### AUTO 


```{c}
auto *context = static_cast<NotifyContext *>(private_data);
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString &path) {
        QFile file(path);
        if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
            return false;
        }

        QTextStream in(&file);
        while (!in.atEnd()) {
            const QString line = in.readLine();
            if (regex.match(line).hasMatch()) {
                return true;
            }
        }

        return false;
    }
```

#### AUTO 


```{c}
const auto typeValue = urlQuery.queryItemValue(QStringLiteral("type"));
```

#### AUTO 


```{c}
auto it = pendingDirs.begin();
```

#### AUTO 


```{c}
auto getSubCreator = [&filePath, this]() -> ThumbCreatorWithMetadata* {
        const QMimeDatabase db;
        const QString subPlugin = pluginForMimeType(db.mimeTypeForFile(filePath).name());
        if (subPlugin.isEmpty() || !m_enabledPlugins.contains(subPlugin)) {
            return nullptr;
        }
        return getThumbCreator(subPlugin);
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& item: items.urlList()) {
                field.setValue(QFileInfo(item.toLocalFile()).canonicalFilePath());
                escapedFiles << database.driver()->formatValue(field);
            }
```

#### AUTO 


```{c}
const auto limitInt = limitValue.toInt(&parseOk);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &entryPath : entries) {
            if (entries.count() > 1 && !entryPath.endsWith(QLatin1String(".fb2"))) { // can this done a bit more cleverly?
                continue;
            }

            const auto *entry = zip.directory()->entry(entryPath);
            if (!entry || !entry->isFile()) {
                return false;
            }

            zipDevice.reset(static_cast<const KZipFileEntry *>(entry)->createDevice());
        }
```

#### AUTO 


```{c}
auto sampleScale = std::min(1.0, std::min(xscale, yscale));
```

#### AUTO 


```{c}
auto future = std::async(std::launch::async, [&buffer, &srcfd, &isErr]() -> int {
        while (!isErr) {
            TransferSegment *segment = buffer.nextFree();
            segment->size = smbc_read(srcfd, segment->buf.data(), segment->buf.capacity());
            if (segment->size <= 0) {
                buffer.push();
                buffer.done();
                if (segment->size < 0) {
                    return KIO::ERR_COULD_NOT_READ;
                }
                break;
            }
            buffer.push();
        }
        return KJob::NoError;
    });
```

#### RANGE FOR STATEMENT 


```{c}
for (KMTPStorageInterface *storage : storages) {
                    listEntry(getEntry(storage));
                }
```

#### IF STATEMENT WITH INITIALIZER 


```{c}
if (const auto [it, isInserted] = iteratedDirs.insert(linkDest); isInserted) {
                        pendingDirs.push(entryUrl.resolved(QUrl(linkDest)));
                    }
```

#### AUTO 


```{c}
auto storageIt = std::find_if(m_storages.constBegin(), m_storages.constEnd(), [description] (KMTPStorageInterface *storage) {
        return storage->description() == description;
    });
```

#### AUTO 


```{c}
const auto result = sftpOpenConnection(info);
```

#### RANGE FOR STATEMENT 


```{c}
for(const KDQName &type : m_typeList) {
        if(matchingType.nameSpace() == type.nameSpace() &&
                matchingType.localName() == type.localName())
            return true;
    }
```

#### AUTO 


```{c}
auto maybeFinished = [&] { // finishes if all discoveries finished
        bool allFinished = true;
        for (auto discoverer : discoverers) {
            allFinished = allFinished && discoverer->isFinished();
        }
        if (allFinished) {
            quitLoop();
        }
    };
```

#### AUTO 


```{c}
auto oldestIt = m_watches.cbegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &device : m_devices) {
        list.append(QDBusObjectPath(device->dbusObjectName()));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto discoverer : discoverers) {
            allFinished = allFinished && discoverer->isFinished();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, itemId] {
            const int result = LIBMTP_Get_File_To_Handler(getDevice(), itemId, onDataPut, this, onDataProgress, this);
            if (result) {
                LIBMTP_Dump_Errorstack(getDevice());
                LIBMTP_Clear_Errorstack(getDevice());
            }
            Q_EMIT copyFinished(result);
        }
```

#### AUTO 


```{c}
const auto trimmedLine = line.trimmed();
```

#### AUTO 


```{c}
auto mangled = mangledPath(path);
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const QByteArray &data) {
                    MTPSlave::data(data);
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KMTPDeviceInterface *device : devices) {
            listEntry(getEntry(device));
        }
```

#### AUTO 


```{c}
auto l = new FileItemLinkingPluginActionLoader(items);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &plugin : plugins) {
        const QStringList mimeTypes = plugin.mimeTypes() + plugin.value(QStringLiteral("ServiceTypes"), QStringList());
        for (const QString& mime : mimeTypes) {
            if(mime.endsWith('*')) {
                const auto mimeGroup = mime.leftRef(mime.length()-1);
                if(mimeType.startsWith(mimeGroup))
                    return plugin.fileName();
            }
        }
    }
```

#### AUTO 


```{c}
auto it = m_limiter.begin();
```

#### AUTO 


```{c}
const auto highlightingTheme = m_highlightingRepository.defaultTheme(KSyntaxHighlighting::Repository::LightTheme);
```

#### AUTO 


```{c}
auto database = Common::Database::instance(
                Common::Database::ResourcesDatabase,
                Common::Database::ReadOnly);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &servicePtr : qAsConst(m_services)) {
            if (*service == *servicePtr) {
                return;
            }
        }
```

#### AUTO 


```{c}
const auto& activity
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &page : list)
        {
            // Remove any compression suffix present
            QString name = stripCompression(page);
            // Remove any preceding pathname components, just leave the base name
            int pos = name.lastIndexOf('/');
            if (pos>0) name = name.mid(pos+1);
            // Reformat the section suffix into the standard form
            pos = name.lastIndexOf('.');
            if (pos>0) name = name.left(pos)+" ("+name.mid(pos+1)+')';

            uds_entry.clear();
            uds_entry.fastInsert(KIO::UDSEntry::UDS_NAME, name);
            uds_entry.fastInsert(KIO::UDSEntry::UDS_URL, ("man:" + page));
            uds_entry.fastInsert(KIO::UDSEntry::UDS_FILE_TYPE, S_IFREG);
            uds_entry.fastInsert(KIO::UDSEntry::UDS_MIME_TYPE, QStringLiteral("text/html"));
            listEntry(uds_entry);
        }
```

#### AUTO 


```{c}
const auto frames = (dirStat.f_frsize == 0) ? 1 : dirStat.f_frsize;
```

#### AUTO 


```{c}
auto skippedPages = (skipped + visibleCount - 1) / visibleCount;
```

#### IF STATEMENT WITH INITIALIZER 


```{c}
if (const QString linkDest = entry.stringValue(KIO::UDSEntry::UDS_LINK_DEST); !linkDest.isEmpty()) {
                    // Remember the dir to prevent endless loops
                    if (const auto [it, isInserted] = iteratedDirs.insert(linkDest); isInserted) {
                        pendingDirs.push_back(entryUrl.resolved(QUrl(linkDest)));
                    }
                }
```

#### AUTO 


```{c}
const auto &error
```

#### AUTO 


```{c}
auto database = QSqlDatabase::addDatabase(
            QStringLiteral("QSQLITE"),
            QStringLiteral("kactivities_db_resources_")
            + QString::number((quintptr) this));
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto& xAddr : xAddrList) {
        qDebug() << "  XAddr:" << xAddr.toString();
    }
```

#### AUTO 


```{c}
const auto entryName
```

#### AUTO 


```{c}
const auto [it, isInserted] = iteratedDirs.insert(linkDest);
```

#### AUTO 


```{c}
auto normalizedUrl = url.adjusted(QUrl::NormalizePathSegments);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& item: urlList) {
                    field.setValue(QFileInfo(item.toLocalFile()).canonicalFilePath());
                    escapedFiles << database.driver()->formatValue(field);
                }
```

#### AUTO 


```{c}
auto search = databases.find(info);
```

#### AUTO 


```{c}
auto effectiveSamples = width * height * sampleScale * sampleScale * depth;
```

#### AUTO 


```{c}
const auto &servicePtr
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &name : entries) {
        const KArchiveEntry *entry = dir->entry(name);

        QString fullPath = name;

        if (!path.isEmpty()) {
            fullPath.prepend(QLatin1Char('/'));
            fullPath.prepend(path);
        }

        if (entry->isFile()) {
            list << fullPath;
        } else {
            list << getEntryList(static_cast<const KArchiveDirectory *>(entry), fullPath);
        }
    }
```

#### AUTO 


```{c}
const auto& line
```

#### AUTO 


```{c}
auto dnssdHost = KDNSSD::ServiceBrowser::resolveHostName(dnssd);
```

#### AUTO 


```{c}
const auto &service
```

#### LAMBDA EXPRESSION 


```{c}
[&](const Discovery::Ptr &discovery) {
            if (discoveredNames.contains(discovery->udsName())) {
                return;
            }
            discoveredNames << discovery->udsName();
            list.append(discovery->toEntry());
        }
```

#### AUTO 


```{c}
const auto hostInfo = QHostInfo::fromName(xAddr.host());
```

#### AUTO 


```{c}
const auto path = url.path();
```

#### RANGE FOR STATEMENT 


```{c}
for (const NetDevice& device : qAsConst(deviceList)) {
        const QString deviceHostName = device.hostName();
        const bool useIpAddress = ( deviceHostName.isEmpty() || hostName.isEmpty() );
        const bool isSameAddress = useIpAddress ?
            ( device.ipAddress() == ipAddress ) :
            ( deviceHostName == hostName );
//qDebug()<<"existing device:"<<deviceHostName<<"at"<<device.ipAddress()<<"vs."<<hostName<<"at"<<ipAddress<<":"<<isSameAddress;

        if( isSameAddress )
        {
            d = device.dPtr();
            // workaround: KDNSSD currently (4.7.0) emits two signals per service
            // just relying on service->serviceName() is fragile, but matches
            // current approach in removeService(...)
            QString id;
            const QString serviceType = service->type();
            for (const DNSSDNetSystemAble* factory : qAsConst(mNetSystemFactoryList)) {
                if( factory->canCreateNetSystemFromDNSSD(serviceType) )
                {
                    id = factory->dnssdId( service );
                    break;
                }
            }
            if( d->hasService(id) )
                return;

            deviceOfService = &device;
            break;
        }
    }
```

#### AUTO 


```{c}
auto *resolver = new PBSDResolver(addr, service.endpointReference(), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& entry : qAsConst(entries)) {
        // Skip MacOS resource forks
        if (entry.startsWith(QLatin1String("__MACOSX"), Qt::CaseInsensitive) ||
            entry.startsWith(QLatin1String(".DS_Store"), Qt::CaseInsensitive)) {
            continue;
        }
        if (entry.endsWith(QLatin1String(".gif"), Qt::CaseInsensitive) ||
                entry.endsWith(QLatin1String(".jpg"), Qt::CaseInsensitive) ||
                entry.endsWith(QLatin1String(".jpeg"), Qt::CaseInsensitive) ||
                entry.endsWith(QLatin1String(".png"), Qt::CaseInsensitive)) {
            entryMap.insert(entry.toLower(), entry);
        }
    }
```

#### AUTO 


```{c}
auto storage = (LIBMTP_devicestorage_t *)pair.first;
```

#### AUTO 


```{c}
auto deviceIt = std::find_if(m_devices.constBegin(), m_devices.constEnd(), [udi] (const MTPDevice *device) {
        return device->udi() == udi;
    });
```

#### AUTO 


```{c}
const auto *entry = zip.directory()->file(entryPath);
```

#### CONST EXPRESSION 


```{c}
constexpr auto MATCH_TIMEOUT = 10s;
```

#### LAMBDA EXPRESSION 


```{c}
[=](KDNSSD::RemoteService::Ptr service) {
        qCDebug(KIO_SMB_LOG) << "DNSSD added:"
                             << service->serviceName()
                             << service->type()
                             << service->domain()
                             << service->hostName()
                             << service->port();
        // Manual contains check. We need to use the == of the underlying
        // objects, not the pointers. The same service may have >1
        // RemoteService* instances representing it, so the == impl of
        // RemoteService::Ptr is useless here.
        for (const auto &servicePtr : qAsConst(m_services)) {
            if (*service == *servicePtr) {
                return;
            }
        }

        connect(service.data(), &KDNSSD::RemoteService::resolved, this, [=] {
            ++m_resolvedCount;
            emit newDiscovery(Discovery::Ptr(new DNSSDDiscovery(service)));
            maybeFinish();
        });

        // Schedule resolution of hostname. We'll later call resolve
        // which will block until the resolution is done. This basically
        // gives us a head start on discovery.
        service->resolveAsync();
        m_services.append(service);
    }
```

#### AUTO 


```{c}
auto partUrl = tmpUrl("resume/thing.part");
```

#### RANGE FOR STATEMENT 


```{c}
for(auto scope : matchedService->scopeList()) {
        qDebug() << "  Scope:"  << scope.toString();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[srv_pubkey] {
        ssh_key_free(srv_pubkey);
    }
```

#### AUTO 


```{c}
auto deviceIt = std::find_if(m_devices.constBegin(), m_devices.constEnd(), [friendlyName] (const KMTPDeviceInterface *device) {
        return device->friendlyName() == friendlyName;
    });
```

#### AUTO 


```{c}
auto typeList = QList<KDQName>() << type;
```

#### LAMBDA EXPRESSION 


```{c}
[&] { // finishes if all discoveries finished
        bool allFinished = true;
        for (const auto &discoverer : discoverers) {
            allFinished = allFinished && discoverer->isFinished();
        }
        if (allFinished) {
            flushEntries();
            e.quit();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& line : textLines) {
                const auto trimmedLine = line.trimmed();
                if ( trimmedLine.contains( '\t' ) || trimmedLine.contains( "  " ) ) {
                    font.setFamily( QFontDatabase::systemFont(QFontDatabase::FixedFont).family());
                    break;
                }
            }
```

#### AUTO 


```{c}
auto url = tmpUrl("resume/thing");
```

#### AUTO 


```{c}
const auto attributes = xml.attributes();
```

#### RANGE FOR STATEMENT 


```{c}
for (const CSTRDEF &standardchar : standardchars)
  {
    const int nr = standardchar.nr;
    const char temp[3] = { char(nr / 256), char(nr % 256), 0 };
    QByteArray name(temp);
    s_characterDefinitionMap.insert(name, StringDefinition(standardchar.slen, standardchar.st));
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Mollet::NetDevice& deviceData : deviceDataList) {
                    KIO::UDSEntry entry;
                    feedEntryAsDevice( &entry, deviceData );
                    listEntry( entry );
                }
```

#### AUTO 


```{c}
auto job = new KIO::ApplicationLauncherJob(keditbookmarks);
```

#### LAMBDA EXPRESSION 


```{c}
[this, udi, url] {
            if (!deviceFromUdi(udi)) {
                qCDebug(LOG_KIOD_KMTPD) << "executing scheduled removal of " << udi;
                org::kde::KDirNotify::emitFilesRemoved({url});
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &item: fileItems) {
            urls << item.targetUrl();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &line : output) {
        if ( regExp.indexIn(line) != -1 && regExp.cap(1).toInt() == 3 )
            icons << qMakePair(regExp.cap(2), 3);
    }
```

#### AUTO 


```{c}
auto head = strippedPath.mid(0, splitPosition);
```

#### AUTO 


```{c}
const auto result = sftpPut(url, permissions, flags, fd);
```

#### AUTO 


```{c}
auto fileContainsPattern = [&](const QString &path) {
        QFile file(path);
        if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
            return false;
        }

        QTextStream in(&file);
        while (!in.atEnd()) {
            const QString line = in.readLine();
            if (regex.match(line).hasMatch()) {
                return true;
            }
        }

        return false;
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &pool : pools) {
                    if (pool.minSize < wants) {
                        continue;
                    } else if (thumbPath.isEmpty()) {
                        // that's the appropriate path for this thumbnail
                        thumbPath = m_thumbBasePath + pool.path;
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Cagibi::Device& upnpDevice : upnpDevices) {
        const QString ipAddress = upnpDevice.ipAddress();

        QMutableListIterator<NetDevice> it( deviceList );
        while( it.hasNext())
        {
            const NetDevice& device = it.next();
            if( device.ipAddress() == ipAddress )
            {
                QString id;
                for (const UpnpNetSystemAble* factory : qAsConst(mNetSystemFactoryList)) {
                    if( factory->canCreateNetSystemFromUpnp(upnpDevice) )
                    {
                        id = factory->upnpId( upnpDevice );
                        break;
                    }
                }
                NetDevicePrivate* d = device.dPtr();
                NetService netService = d->removeService( id );
                if( ! netService.isValid() )
                    break;

                removedServices.append( netService );

                // remove device on last service
                if( d->serviceList().count() == 0 )
                {
                    removedDevices.append( device );
                    // remove only after taking copy from reference into removed list
                    it.remove();
                }
                break;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto discoverer : discoverers) {
                allFinished = allFinished && discoverer->isFinished();
            }
```

#### AUTO 


```{c}
const auto linkedFileCount = result[1].toInt();
```

#### AUTO 


```{c}
const auto match = matches.next();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &discoverer : discoverers) {
            allFinished = allFinished && discoverer->isFinished();
        }
```

#### AUTO 


```{c}
auto service = *it;
```

#### AUTO 


```{c}
auto pushFuture = std::async(std::launch::async, [&ring, &abort]() -> bool {
            for (auto i = 0; i <= runs && !abort; ++i) {
                auto s = ring.nextFree();
                memset(s->buf.data(), i, fileSize);
                ring.push();
                if (abort) {
                    ring.done();
                    return false;
                }
                // Slow down this thread to simulate slow network reads.
                std::this_thread::sleep_for(std::chrono::milliseconds(5));
            }
            ring.done();
            return true;
        });
```

#### AUTO 


```{c}
const auto orderValue = urlQuery.queryItemValue(QStringLiteral("order"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &pool : pools) {
                        if (pool.minSize < wants) {
                            continue;
                        } else if (thumbPath.isEmpty()) {
                            // that's the appropriate path for this thumbnail
                            thumbPath = m_thumbBasePath + pool.path;
                        }
                    }
```

#### AUTO 


```{c}
const auto deviceNames = m_dbusInterface->listDevices().value();
```

#### LAMBDA EXPRESSION 


```{c}
[this] (qulonglong sent, qulonglong total) {
        Q_UNUSED(total)
        processedSize(sent);
    }
```

#### AUTO 


```{c}
const auto activityValue = urlQuery.queryItemValue(QStringLiteral("activity"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& activity: activities.activities()) {
            udslist << d->activityEntry(activity);
        }
```

#### AUTO 


```{c}
const auto &picture
```

#### AUTO 


```{c}
auto optionalResume = Transfer::shouldResume<QFileResumeIO>(kdst, flags, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &plugin : plugins) {
        if (plugin.supportsMimeType(mimeType)) {
            return plugin.fileName();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &dirUrl : m_searchUrls) {
            if (urlPath.startsWith(dirUrl.path())) {
                url.setScheme(QStringLiteral("filenamesearch"));
                fileList << url;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& item: items.urlList()) {
                    field.setValue(QFileInfo(item.toLocalFile()).canonicalFilePath());
                    escapedFiles << database.driver()->formatValue(field);
                }
```

#### LAMBDA EXPRESSION 


```{c}
[fileItems](const KJob *job) {
            if (!job->error()) {
                org::kde::KDirNotify::emitFilesRemoved({fileItems.urlList()});
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &xAddr : service->xAddrList()) {
        // https://docs.microsoft.com/en-us/windows/win32/wsdapi/xaddr-validation-rules
        // "At least one IP address included in the XAddrs (or IP address resolved from
        // a hostname included in the XAddrs) must be on the same subnet as the adapter
        // over which the ProbeMatches or ResolveMatches message was received."
        const auto hostInfo = QHostInfo::fromName(xAddr.host());
        if (hostInfo.error() == QHostInfo::NoError) {
            addr = xAddr;
            break;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&] { // finishes if all discoveries finished
                bool allFinished = true;
                for (auto discoverer : discoverers) {
                    allFinished = allFinished && discoverer->isFinished();
                }
                if (allFinished) {
                    quitLoop();
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this, &list]() {
            if (list.isEmpty()) {
                return;
            }
            listEntries(list);
            list.clear();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& entry : list) {
            if (KDesktopFile::isDesktopFile(entry)) {
                QFileInfo info(entry);
                KDesktopFile file(entry);

                QUrl urlInside(file.readUrl());
                QString toDisplayString = urlInside.toDisplayString();

                // Filter out things that can't be viewed in a file manager because they don't
                // meet the user definition of a file for the purpose of "recently accessed files"
                if (urlInside.scheme() == "recentdocuments"
                    || !KProtocolManager::supportsListing(urlInside)
                    || urlSet.contains(toDisplayString))
                    continue;

                KIO::UDSEntry uds;
                if (urlInside.isLocalFile()) {
                    KIO::StatJob* job = KIO::stat(urlInside, KIO::HideProgressInfo);
                    // we do not want to wait for the event loop to delete the job
                    QScopedPointer<KIO::StatJob> sp(job);
                    job->setAutoDelete(false);
                    if (job->exec()) {
                        uds = job->statResult();
                    }
                }

                urlSet.insert(toDisplayString);
                uds.replace(KIO::UDSEntry::UDS_NAME, info.completeBaseName());

                if (urlInside.isLocalFile()) {
                    uds.replace(KIO::UDSEntry::UDS_DISPLAY_NAME, urlInside.toLocalFile());
                    uds.replace(KIO::UDSEntry::UDS_LOCAL_PATH, urlInside.path());
                } else {
                    uds.fastInsert(KIO::UDSEntry::UDS_DISPLAY_NAME, toDisplayString);
                    uds.fastInsert(KIO::UDSEntry::UDS_ICON_NAME, file.readIcon());
                }
                uds.replace(KIO::UDSEntry::UDS_TARGET_URL, toDisplayString);
                udslist << uds;
            }
        }
```

#### AUTO 


```{c}
const auto newHead = (head + 1) % m_capacity;
```

#### AUTO 


```{c}
auto app = QCoreApplication::instance();
```

#### AUTO 


```{c}
auto action = new QAction(nullptr);
```

#### AUTO 


```{c}
const auto properties = attributes.value(QStringLiteral("properties")).toString();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &page : matchingPages)
    {
        os << "<li><a href='man:" << page << "' accesskey='" << acckey << "'>" << page << "</a><br>\n<br>\n";
        ++acckey;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QUrl &scope : d->scopeList) {
        if(matchingScope == scope) {
            return true;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&] { // finishes if all discoveries finished
        bool allFinished = true;
        for (auto discoverer : discoverers) {
            allFinished = allFinished && discoverer->isFinished();
        }
        if (allFinished) {
            quitLoop();
        }
    }
```

#### AUTO 


```{c}
const auto pictureList = file.pictureList();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &entryName: entries) {
        auto entry = dir->entry(entryName);
        if (entry->isFile()) {
            auto fileEntry = static_cast<const KArchiveFile *>(entry);
            totalSize += fileEntry->size();
        }
        else if (entry->isDirectory()) {
            const auto dirEntry = static_cast<const KArchiveDirectory *>(entry);
            // recurse
            totalSize += computeArchiveDirSize(dirEntry);
        }
    }
```

#### AUTO 


```{c}
auto resume = Transfer::shouldResume<QFileResumeIO>(url, KIO::JobFlags(), &worker);
```

#### AUTO 


```{c}
const auto &attribute
```

#### RANGE FOR STATEMENT 


```{c}
for (const MTPDevice *device : qAsConst(m_devices)) {
        deviceRemoved(device->udi());
    }
```

#### AUTO 


```{c}
const auto urlQuery = QUrlQuery(url);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto discoverer : discoverers) {
                    allFinished = allFinished && discoverer->isFinished();
                }
```

#### LAMBDA EXPRESSION 


```{c}
[fingerprint] {
        ssh_string_free_char(fingerprint);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &pendingDir : qAsConst(pendingDirs)) {
        searchDirectory(pendingDir, itemValidator, iteratedDirs);
    }
```

#### AUTO 


```{c}
const auto &xAddr
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &it_dir : qAsConst(man_dirs))
    {
        if (!QFile::exists(it_dir)) continue;

        bool added = false;
        for (const QString &it_name : qAsConst(names))
        {
            count0 = i.count();
            if (addWhatIs(i, (it_dir+'/'+it_name), mark))
            {
                qCDebug(KIO_MAN_LOG) << "added" << (i.count()-count0) << "from" << it_name << "in" << it_dir;
                added = true;
                break;
            }
        }

        if (!added)
        {
            // Nothing was able to be added by scanning the directory,
            // so try parsing the output of the whatis(1) command.
            QProcess proc;
            proc.setProgram("whatis");
            proc.setArguments(QStringList() << "-M" << it_dir << "-w" << "*");
            proc.setProcessChannelMode( QProcess::ForwardedErrorChannel );
            proc.start();
            proc.waitForFinished();
            QTextStream t( proc.readAllStandardOutput(), QIODevice::ReadOnly );

            count0 = i.count();
            parseWhatIs( i, t, mark );
            qCDebug(KIO_MAN_LOG) << "added" << (i.count()-count0) << "from whatis in" << it_dir;
        }
    }
```

#### AUTO 


```{c}
auto entry
```

#### AUTO 


```{c}
const auto runs = 127;
```

#### AUTO 


```{c}
const auto dirEntry = static_cast<const KArchiveDirectory *>(entry);
```

#### LAMBDA EXPRESSION 


```{c}
[](const struct smbc_notify_callback_action *actions, size_t num_actions, void *private_data) -> int {
        auto *context = static_cast<NotifyContext *>(private_data);

        // Some relevant docs for how this works under the hood
        //   https://docs.microsoft.com/en-us/openspecs/windows_protocols/ms-fasod/271a36e8-c94b-4527-8735-e884f5504cd9
        //   https://docs.microsoft.com/en-us/openspecs/windows_protocols/ms-smb2/14f9d050-27b2-49df-b009-54e08e8bf7b5

        qCDebug(KIO_SMB_LOG) << "notifying for n actions:" << num_actions;

        // Moves are a bit award. They arrive in two subsequent events this object helps us collect the events.
        MoveAction pendingMove;

        // Values @ 2.7.1 FILE_NOTIFY_INFORMATION
        //   https://docs.microsoft.com/en-us/openspecs/windows_protocols/ms-fscc/634043d7-7b39-47e9-9e26-bda64685e4c9
        for (size_t i = 0; i < num_actions; ++i, ++actions) {
            qCDebug(KIO_SMB_LOG) << "  " << actions->action << actions->filename;
            QUrl url(context->url);
            url.setPath(url.path() + "/" + actions->filename);

            if (actions->action != SMBC_NOTIFY_ACTION_MODIFIED) {
                // If the current action isn't a modification forget a possible pending modification from a previous
                // action.
                // NB: by default every copy is followed by a move from f.part to f
                context->modificationLimiter.forget(url);
            }

            context->pendingRemove.newEventFor(actions->action, url);

            switch (actions->action) {
            case SMBC_NOTIFY_ACTION_ADDED:
                OrgKdeKDirNotifyInterface::emitFilesAdded(context->url /* dir */);
                continue;
            case SMBC_NOTIFY_ACTION_REMOVED:
                context->pendingRemove.schedule(url);
                continue;
            case SMBC_NOTIFY_ACTION_MODIFIED:
                context->modificationLimiter.notify(url);
                continue;
            case SMBC_NOTIFY_ACTION_OLD_NAME:
                Q_ASSERT(!pendingMove.isComplete());
                pendingMove.from = url;
                continue;
            case SMBC_NOTIFY_ACTION_NEW_NAME:
                pendingMove.to = url;
                Q_ASSERT(pendingMove.isComplete());
                OrgKdeKDirNotifyInterface::emitFileRenamed(pendingMove.from, pendingMove.to);
                pendingMove = MoveAction();
                continue;
            case SMBC_NOTIFY_ACTION_ADDED_STREAM: Q_FALLTHROUGH();
            case SMBC_NOTIFY_ACTION_REMOVED_STREAM: Q_FALLTHROUGH();
            case SMBC_NOTIFY_ACTION_MODIFIED_STREAM:
                // https://docs.microsoft.com/en-us/windows/win32/fileio/file-streams
                // Streams have no real use for us I think. They sound like proprietary
                // information an application might attach to a file.
                continue;
            }
            qCWarning(KIO_SMB_LOG) << "Unhandled action" << actions->action << "on URL" << url;
        }

        return 0;
    }
```

#### AUTO 


```{c}
const auto& query
```

#### AUTO 


```{c}
auto fileEntry = static_cast<const KArchiveFile *>(entry);
```

#### RANGE FOR STATEMENT 


```{c}
for (const NetDevice& device : qAsConst(deviceList)) {
        const bool isSameAddress = ( device.ipAddress() == ipAddress );
//qDebug()<<"existing device:"<<device.hostName()<<"at"<<device.ipAddress()<<"vs."<<ipAddress<<":"<<isSameAddress;
            // TODO: lookup hostname and try to use that
            if( isSameAddress )
            {
                d = device.dPtr();
                deviceOfService = &device;
                break;
            }
        }
```

#### AUTO 


```{c}
const auto pathValue = urlQuery.queryItemValue(QStringLiteral("path"));
```

#### AUTO 


```{c}
const auto flushEntries = [this, &list]() {
                if (list.isEmpty()) {
                    return;
                }
                listEntries(list);
                list.clear();
            };
```

#### RANGE FOR STATEMENT 


```{c}
for (const QDBusObjectPath &deviceName : deviceNames) {
        m_devices.append(new KMTPDeviceInterface(deviceName.path(), this));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const UpnpNetSystemAble* factory : qAsConst(mNetSystemFactoryList)) {
            if( factory->canCreateNetSystemFromUpnp(upnpDevice) )
            {
                // TODO: here we should rather see if this service already exists
                netServicePrivate = factory->createNetService( upnpDevice, *deviceOfService );
                break;
            }
        }
```

#### AUTO 


```{c}
auto it = m_watches.cbegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto actionInfo: actions) {
        if (actionInfo.icon != "-") {
            auto action = new QAction(Q_NULLPTR);

            action->setText(actionInfo.title);
            action->setIcon(QIcon::fromTheme(actionInfo.icon));
            action->setProperty("activity", actionInfo.activity);
            action->setProperty("link", actionInfo.link);

            rootMenu->addAction(action);

            connect(action, &QAction::triggered,
                    this, &Private::actionTriggered);

        } else {
            auto action = new QAction(actionInfo.title, Q_NULLPTR);
            action->setSeparator(true);

            rootMenu->addAction(action);
        }
    }
```

#### AUTO 


```{c}
auto notify = [](const struct smbc_notify_callback_action *actions, size_t num_actions, void *private_data) -> int {
        auto *context = static_cast<NotifyContext *>(private_data);

        // Some relevant docs for how this works under the hood
        //   https://docs.microsoft.com/en-us/openspecs/windows_protocols/ms-fasod/271a36e8-c94b-4527-8735-e884f5504cd9
        //   https://docs.microsoft.com/en-us/openspecs/windows_protocols/ms-smb2/14f9d050-27b2-49df-b009-54e08e8bf7b5

        qCDebug(KIO_SMB_LOG) << "notifying for n actions:" << num_actions;

        // Moves are a bit award. They arrive in two subsequent events this object helps us collect the events.
        MoveAction pendingMove;

        // Values @ 2.7.1 FILE_NOTIFY_INFORMATION
        //   https://docs.microsoft.com/en-us/openspecs/windows_protocols/ms-fscc/634043d7-7b39-47e9-9e26-bda64685e4c9
        for (size_t i = 0; i < num_actions; ++i, ++actions) {
            qCDebug(KIO_SMB_LOG) << "  " << actions->action << actions->filename;
            QUrl url(context->url);
            url.setPath(url.path() + "/" + actions->filename);

            if (actions->action != SMBC_NOTIFY_ACTION_MODIFIED) {
                // If the current action isn't a modification forget a possible pending modification from a previous
                // action.
                // NB: by default every copy is followed by a move from f.part to f
                context->modificationLimiter.forget(url);
            }

            context->pendingRemove.newEventFor(actions->action, url);

            switch (actions->action) {
            case SMBC_NOTIFY_ACTION_ADDED:
                OrgKdeKDirNotifyInterface::emitFilesAdded(context->url /* dir */);
                continue;
            case SMBC_NOTIFY_ACTION_REMOVED:
                context->pendingRemove.schedule(url);
                continue;
            case SMBC_NOTIFY_ACTION_MODIFIED:
                context->modificationLimiter.notify(url);
                continue;
            case SMBC_NOTIFY_ACTION_OLD_NAME:
                Q_ASSERT(!pendingMove.isComplete());
                pendingMove.from = url;
                continue;
            case SMBC_NOTIFY_ACTION_NEW_NAME:
                pendingMove.to = url;
                Q_ASSERT(pendingMove.isComplete());
                OrgKdeKDirNotifyInterface::emitFileRenamed(pendingMove.from, pendingMove.to);
                pendingMove = MoveAction();
                continue;
            case SMBC_NOTIFY_ACTION_ADDED_STREAM:
                Q_FALLTHROUGH();
            case SMBC_NOTIFY_ACTION_REMOVED_STREAM:
                Q_FALLTHROUGH();
            case SMBC_NOTIFY_ACTION_MODIFIED_STREAM:
                // https://docs.microsoft.com/en-us/windows/win32/fileio/file-streams
                // Streams have no real use for us I think. They sound like proprietary
                // information an application might attach to a file.
                continue;
            }
            qCWarning(KIO_SMB_LOG) << "Unhandled action" << actions->action << "on URL" << url;
        }

        return 0;
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const IconInExe &icon : qAsConst(icons)) {

        QString name = icon.first;
        int type = icon.second;

        if ( name.at(0) == '\'' )
            name = name.mid(1, name.size()-2);

        wrestool.start("wrestool", QStringList() << "-x" << "-t" << QString::number(type) << "-n" << name << inputFileName);
        wrestool.waitForFinished();

        if (wrestool.exitCode() != 0) {
            return false;
        }

        const QByteArray iconData = wrestool.readAllStandardOutput();

        if (outputDevice->write(iconData) != iconData.size()) {
            return false;
        }

        return true;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& activity: activitiesList) {
                    if (activitiesForUnlinking.contains(activity)) {
                        actions << createAction(activity, false);
                    }
                }
```

#### AUTO 


```{c}
auto jsonMetaDataPlugins = KPluginMetaData::findPlugins(QStringLiteral("kf5/thumbcreator"));
```

#### AUTO 


```{c}
const auto result = d->open(url, mode);
```

#### AUTO 


```{c}
auto targetSamples = desiredWidth * desiredHeight * 32;
```

#### LAMBDA EXPRESSION 


```{c}
[this, &list]() {
        if (list.isEmpty()) {
            return;
        }
        listEntries(list);
        list.clear();
    }
```

#### AUTO 


```{c}
auto *that = static_cast<SMBCContext *>(smbc_option_get(context, "user_data"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &dirUrl : m_searchUrls) {
        if (urlPath.startsWith(dirUrl.path())) {
            org::kde::KDirNotify::emitFilesAdded(dirUrl);
        }
    }
```

#### AUTO 


```{c}
auto appendDiscovery = [&](Discovery::Ptr discovery) {
               list.append(discovery->toEntry());
           };
```

#### LAMBDA EXPRESSION 


```{c}
[this, parentId, descriptor, filename] {
        int result = 1;
        QT_STATBUF srcBuf;
        if (QT_FSTAT(descriptor.fileDescriptor(), &srcBuf) != -1) {
            const QDateTime lastModified = QDateTime::fromSecsSinceEpoch(srcBuf.st_mtim.tv_sec);

            LIBMTP_file_t *file = LIBMTP_new_file_t();
            file->parent_id = parentId;
            file->filename = qstrdup(filename.toUtf8().data());
            file->filetype = getFiletype(filename);
            file->filesize = quint64(srcBuf.st_size);
            file->modificationdate = lastModified.toSecsSinceEpoch();   // no matter what to set here, current time is taken
            file->storage_id = m_id;

            result = LIBMTP_Send_File_From_File_Descriptor(getDevice(), descriptor.fileDescriptor(), file, onDataProgress, this);
            LIBMTP_destroy_file_t(file);

            if (result) {
                LIBMTP_Dump_Errorstack(getDevice());
                LIBMTP_Clear_Errorstack(getDevice());
            }
        }
        Q_EMIT copyFinished(result);
    }
```

#### AUTO 


```{c}
const auto *entry = zip.directory()->entry(entryPath);
```

#### AUTO 


```{c}
const auto begin     = pattern.constBegin();
```

#### LAMBDA EXPRESSION 


```{c}
[this](const WSDiscoveryTargetService &service) {
            Q_ASSERT(service.endpointReference() == m_endpoint);
            Q_EMIT resolved(service);
            stop();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const NetDevice& device : deviceList) {
        if( device.hostAddress() == hostAddress )
        {
            const QList<NetService> serviceList = device.serviceList();

            for (const NetService& service : serviceList) {
                if( service.name() == serviceName && service.type() == serviceType )
                {
                    result = service;
                    break;
                }
            }
            break;
        }
    }
```

#### AUTO 


```{c}
static const auto queryString = QStringLiteral(
                                                    "SELECT usedActivity, COUNT(targettedResource) "
                                                    "FROM ResourceLink "
                                                    "WHERE targettedResource IN (%1) "
                                                    "AND initiatingAgent = \":global\" "
                                                    "AND usedActivity != \":global\" "
                                                    "GROUP BY usedActivity");
```

#### LAMBDA EXPRESSION 


```{c}
[] (QString str) {
        return str.replace(QLatin1String("%"), QLatin1String("\\%")).replace(QLatin1String("_"), QLatin1String("\\_"));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Cagibi::Device& upnpDevice : upnpDevices) {
        if( upnpDevice.hasParentDevice() )
            continue;

        const QString ipAddress = upnpDevice.ipAddress();

        NetDevicePrivate* d = nullptr;
        const NetDevice* deviceOfService = nullptr;
        for (const NetDevice& device : qAsConst(deviceList)) {
        const bool isSameAddress = ( device.ipAddress() == ipAddress );
//qDebug()<<"existing device:"<<device.hostName()<<"at"<<device.ipAddress()<<"vs."<<ipAddress<<":"<<isSameAddress;
            // TODO: lookup hostname and try to use that
            if( isSameAddress )
            {
                d = device.dPtr();
                deviceOfService = &device;
                break;
            }
        }
        if( ! d )
        {
            const QString displayName = upnpDevice.friendlyName();

            const QString deviceName = displayName;
            d = new NetDevicePrivate( deviceName );
            d->setIpAddress( ipAddress );

            NetDevice device( d );
            addedDevices.append( device );
            deviceList.append( device );
            deviceOfService = &deviceList.last();
//qDebug()<<"new device:"<<deviceName<<"at"<<ipAddress;
        }

        NetServicePrivate* netServicePrivate = nullptr;
        // do a priority based lookup who can build the object
        // TODO: priorisation
        for (const UpnpNetSystemAble* factory : qAsConst(mNetSystemFactoryList)) {
            if( factory->canCreateNetSystemFromUpnp(upnpDevice) )
            {
                // TODO: here we should rather see if this service already exists
                netServicePrivate = factory->createNetService( upnpDevice, *deviceOfService );
                break;
            }
        }

        NetService netService( netServicePrivate );
        d->addService( netService );

        addedServices.append( netService );
//qDebug()<<"new service:"<<netService.name()<<netService.url();

        // try guessing the device type by the services on it
        // TODO: move into  devicefactory
        const QString serviceType = upnpDevice.type();
        NetDevice::Type deviceTypeByService = NetDevice::Unknown;
        QString deviceName;
        if( serviceType == QLatin1String("InternetGatewayDevice1") )
            deviceTypeByService = NetDevice::Router;
        else if( serviceType == QLatin1String("PrinterBasic1")
             || serviceType == QLatin1String("PrinterEnhanced1") )
            deviceTypeByService = NetDevice::Printer;
        else if( serviceType == QLatin1String("Scanner1") )
            deviceTypeByService = NetDevice::Scanner;

        if( deviceTypeByService != NetDevice::Unknown )
        {
            if( deviceTypeByService > d->type() )
            {
                d->setType( deviceTypeByService );
                if( ! deviceName.isEmpty() )
                    d->setName( deviceName );
            }
        }
    }
```

#### AUTO 


```{c}
auto maybeFinished = [&] { // finishes if all discoveries finished
            bool allFinished = true;
            for (auto discoverer : discoverers) {
                allFinished = allFinished && discoverer->isFinished();
            }
            if (allFinished) {
                quitLoop();
            }
        };
```

#### AUTO 


```{c}
const auto openResult = openConnection();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &plugin : plugins) {
        const QStringList mimeTypes = plugin.mimeTypes() + plugin.value(QStringLiteral("ServiceTypes"), QStringList());
        for (const QString& mime : mimeTypes) {
            if(mime.endsWith('*')) {
                const auto mimeGroup = QStringView(mime).left(mime.length()-1);
                if(mimeType.startsWith(mimeGroup))
                    return plugin.fileName();
            }
        }
    }
```

#### AUTO 


```{c}
const auto name = uds.stringValue(KIO::UDSEntry::UDS_NAME);
```

#### AUTO 


```{c}
const auto dateValue = urlQuery.queryItemValue(QStringLiteral("date"));
```

#### AUTO 


```{c}
auto rc = m_soapUdpClient->sendMessage(message, KDSoapHeaders(), DISCOVERY_ADDRESS_IPV4, DISCOVERY_PORT);
```

#### LAMBDA EXPRESSION 


```{c}
[=](KDNSSD::RemoteService::Ptr service) {
        qCDebug(KIO_SMB_LOG) << "DNSSD added:"
                             << service->serviceName()
                             << service->type()
                             << service->domain()
                             << service->hostName()
                             << service->port();
        // Manual contains check. We need to use the == of the underlying
        // objects, not the pointers. The same service may have >1
        // RemoteService* instances representing it, so the == impl of
        // RemoteService::Ptr is useless here.
        for (const auto &servicePtr : qAsConst(m_services)) {
            if (*service == *servicePtr) {
                return;
            }
        }

        connect(service.data(), &KDNSSD::RemoteService::resolved, this, [=] {
            ++m_resolvedCount;
            Q_EMIT newDiscovery(Discovery::Ptr(new DNSSDDiscovery(service)));
            maybeFinish();
        });

        // Schedule resolution of hostname. We'll later call resolve
        // which will block until the resolution is done. This basically
        // gives us a head start on discovery.
        service->resolveAsync();
        m_services.append(service);
    }
```

#### AUTO 


```{c}
const auto length = qMin<int>(MAX_XFER_BUF_SIZE, buffer.size() - offset);
```

#### LAMBDA EXPRESSION 


```{c}
[&e, &flushEntries]() {
            flushEntries();
            e.quit();
        }
```

#### AUTO 


```{c}
auto url = tmpUrl("noResumeButPartial/thing");
```

#### AUTO 


```{c}
auto ram = maximumThumbnailRam();
```

#### AUTO 


```{c}
auto resolveMatch = resolveMatches.resolveMatch();
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto& scope : scopeList) {
        qDebug() << "  Scope:"  << scope.toString();
    }
```

#### AUTO 


```{c}
auto splitPosition = strippedPath.indexOf(QStringLiteral("/"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &coverList : map) {
        auto coverArtList = coverList.second.toCoverArtList();
        if (coverArtList.isEmpty()) {
            continue;
        }
        const auto coverData = coverArtList[0].data();
        img.loadFromData((uchar *)coverData.data(), coverData.size());
        return true;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, endpoint] {
            if (m_endpointResolvers.contains(endpoint)) {
                m_endpointResolvers.take(endpoint)->deleteLater();
            }
            maybeFinish();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const NetDevice& device : qAsConst(deviceList)) {
        const QString deviceHostName = device.hostName();
        const bool useIpAddress = ( deviceHostName.isEmpty() || hostName.isEmpty() );
        const bool isSameAddress = useIpAddress ?
                                   ( device.ipAddress() == ipAddress ) :
                                   ( deviceHostName == hostName );

        if( isSameAddress )
        {
            d = device.dPtr();
            // workaround: KDNSSD currently (4.7.0) emits two signals per service
            // just relying on service->serviceName() is fragile, but matches
            // current approach in removeService(...)
            QString id;
            const QString serviceType = service->type();
            for (const DNSSDNetSystemAble* factory : qAsConst(mNetSystemFactoryList)) {
                if( factory->canCreateNetSystemFromDNSSD(serviceType) )
                {
                    id = factory->dnssdId( service );
                    break;
                }
            }
            if( d->hasService(id) )
                return;

            deviceOfService = &device;
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &page : qAsConst(pages))
    {
        // I look for the beginning of the man page name
        // i.e. "bla/pagename.3.gz" by looking for the last "/"
        // Then look for the end of the name by searching backwards
        // for the last ".", not counting zip extensions.
        // If the len of the name is >0,
        // store it in the list structure, to be sorted later

        struct man_index_t *manindex = new man_index_t;
        manindex->manpath = strdup(page.toUtf8());

        manindex->manpage_begin = strrchr(manindex->manpath, '/');
        if (manindex->manpage_begin)
        {
            manindex->manpage_begin++;
            Q_ASSERT(manindex->manpage_begin >= manindex->manpath);
        }
        else
        {
            manindex->manpage_begin = manindex->manpath;
            Q_ASSERT(manindex->manpage_begin >= manindex->manpath);
        }

        // Skip extension ".section[.gz]"

        const char *begin = manindex->manpage_begin;
        const int len = strlen( begin );
        const char *end = begin+(len-1);

        if ( len >= 3 && strcmp( end-2, ".gz" ) == 0 )
            end -= 3;
        else if ( len >= 2 && strcmp( end-1, ".Z" ) == 0 )
            end -= 2;
        else if ( len >= 2 && strcmp( end-1, ".z" ) == 0 )
            end -= 2;
        else if ( len >= 4 && strcmp( end-3, ".bz2" ) == 0 )
            end -= 4;
        else if ( len >= 5 && strcmp( end-4, ".lzma" ) == 0 )
            end -= 5;
        else if ( len >= 3 && strcmp( end-2, ".xz" ) == 0 )
            end -= 3;

        while ( end >= begin && *end != '.' )
            end--;

        if (end <begin)
        {
            // no '.' ending ???
            // set the pointer past the end of the filename
            manindex->manpage_len = page.length();
            manindex->manpage_len -= (manindex->manpage_begin - manindex->manpath);
            Q_ASSERT(manindex->manpage_len >= 0);
        }
        else
        {
            const char *manpage_end = end;
            manindex->manpage_len = (manpage_end - manindex->manpage_begin);
            Q_ASSERT(manindex->manpage_len >= 0);
        }

        if (manindex->manpage_len>0)
        {
            indexlist[listlen] = manindex;
            listlen++;
        }
        else delete manindex;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&buffer, &srcfd, &isErr]() -> int {
        while (!isErr) {
            TransferSegment *segment = buffer.nextFree();
            segment->size = smbc_read(srcfd, segment->buf.data(), segment->buf.capacity());
            if (segment->size <= 0) {
                buffer.push();
                buffer.done();
                if (segment->size < 0) {
                    return KIO::ERR_COULD_NOT_READ;
                }
                break;
            }
            buffer.push();
        }
        return KJob::NoError;
    }
```

#### AUTO 


```{c}
auto appendDiscovery = [&](const Discovery::Ptr &discovery) {
        if (discoveredNames.contains(discovery->udsName(), Qt::CaseInsensitive)) {
            return;
        }
        // Not tracking hosts. Tracking hosts means **guessing** if foo.local
        // and foo and foo.kio-discovery-wsd will actually resolve to the same
        // IP address, which is tricky to do at best. In the interest of efficency
        // I'd rather have the de-duplication requirement be that the name of
        // two competing service discovery systems needs to be the same.
        discoveredNames << discovery->udsName();
        list.append(discovery->toEntry());
    };
```

#### AUTO 


```{c}
const auto& typeList = matchedService->typeList();
```

#### LAMBDA EXPRESSION 


```{c}
[this, itemId] {
            const int result = LIBMTP_Get_File_To_Handler(getDevice(), itemId, onDataPut, this, onDataProgress, this);
            if (result) {
                LIBMTP_Dump_Errorstack(getDevice());
                LIBMTP_Clear_Errorstack(getDevice());
            }
            emit copyFinished(result);
        }
```

#### AUTO 


```{c}
auto notify = [](const struct smbc_notify_callback_action *actions, size_t num_actions, void *private_data) -> int {
        auto *context = static_cast<NotifyContext *>(private_data);

        // Some relevant docs for how this works under the hood
        //   https://docs.microsoft.com/en-us/openspecs/windows_protocols/ms-fasod/271a36e8-c94b-4527-8735-e884f5504cd9
        //   https://docs.microsoft.com/en-us/openspecs/windows_protocols/ms-smb2/14f9d050-27b2-49df-b009-54e08e8bf7b5

        qCDebug(KIO_SMB_LOG) << "notifying for n actions:" << num_actions;

        // Moves are a bit award. They arrive in two subsequent events this object helps us collect the events.
        MoveAction pendingMove;

        // Values @ 2.7.1 FILE_NOTIFY_INFORMATION
        //   https://docs.microsoft.com/en-us/openspecs/windows_protocols/ms-fscc/634043d7-7b39-47e9-9e26-bda64685e4c9
        for (size_t i = 0; i < num_actions; ++i, ++actions) {
            qCDebug(KIO_SMB_LOG) << "  " << actions->action << actions->filename;
            QUrl url(context->url);
            url.setPath(url.path() + "/" + actions->filename);

            if (actions->action != SMBC_NOTIFY_ACTION_MODIFIED) {
                // If the current action isn't a modification forget a possible pending modification from a previous
                // action.
                // NB: by default every copy is followed by a move from f.part to f
                context->modificationLimiter.forget(url);
            }

            context->pendingRemove.newEventFor(actions->action, url);

            switch (actions->action) {
            case SMBC_NOTIFY_ACTION_ADDED:
                OrgKdeKDirNotifyInterface::emitFilesAdded(context->url /* dir */);
                continue;
            case SMBC_NOTIFY_ACTION_REMOVED:
                context->pendingRemove.schedule(url);
                continue;
            case SMBC_NOTIFY_ACTION_MODIFIED:
                context->modificationLimiter.notify(url);
                continue;
            case SMBC_NOTIFY_ACTION_OLD_NAME:
                Q_ASSERT(!pendingMove.isComplete());
                pendingMove.from = url;
                continue;
            case SMBC_NOTIFY_ACTION_NEW_NAME:
                pendingMove.to = url;
                Q_ASSERT(pendingMove.isComplete());
                OrgKdeKDirNotifyInterface::emitFileRenamed(pendingMove.from, pendingMove.to);
                pendingMove = MoveAction();
                continue;
            case SMBC_NOTIFY_ACTION_ADDED_STREAM: Q_FALLTHROUGH();
            case SMBC_NOTIFY_ACTION_REMOVED_STREAM: Q_FALLTHROUGH();
            case SMBC_NOTIFY_ACTION_MODIFIED_STREAM:
                // https://docs.microsoft.com/en-us/windows/win32/fileio/file-streams
                // Streams have no real use for us I think. They sound like proprietary
                // information an application might attach to a file.
                continue;
            }
            qCWarning(KIO_SMB_LOG) << "Unhandled action" << actions->action << "on URL" << url;
        }

        return 0;
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &xAddr : xAddrList) {
        // https://docs.microsoft.com/en-us/windows/win32/wsdapi/xaddr-validation-rules
        // "At least one IP address included in the XAddrs (or IP address resolved from
        // a hostname included in the XAddrs) must be on the same subnet as the adapter
        // over which the ProbeMatches or ResolveMatches message was received."
        const auto hostInfo = QHostInfo::fromName(xAddr.host());
        if (hostInfo.error() == QHostInfo::NoError) {
            addr = xAddr;
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& entry : list) {
            if (KDesktopFile::isDesktopFile(entry)) {
                QFileInfo info(entry);
                KDesktopFile file(entry);

                QUrl urlInside(file.readUrl());
                QString toDisplayString = urlInside.toDisplayString();

                // Filter out things that can't be viewed in a file manager because they don't
                // meet the user definition of a file for the purpose of "recently accessed files"
                if (urlInside.scheme() == "recentdocuments"
                        || !KProtocolManager::supportsListing(urlInside)
                        || urlSet.contains(toDisplayString))
                    continue;

                KIO::UDSEntry uds;
                if (urlInside.isLocalFile()) {
                    KIO::StatJob* job = KIO::stat(urlInside, KIO::HideProgressInfo);
                    // we do not want to wait for the event loop to delete the job
                    QScopedPointer<KIO::StatJob> sp(job);
                    job->setAutoDelete(false);
                    if (job->exec()) {
                        uds = job->statResult();
                    }
                }

                urlSet.insert(toDisplayString);
                uds.replace(KIO::UDSEntry::UDS_NAME, info.completeBaseName());

                if (urlInside.isLocalFile()) {
                    uds.replace(KIO::UDSEntry::UDS_DISPLAY_NAME, urlInside.toLocalFile());
                    uds.replace(KIO::UDSEntry::UDS_LOCAL_PATH, urlInside.path());
                } else {
                    uds.fastInsert(KIO::UDSEntry::UDS_DISPLAY_NAME, toDisplayString);
                    uds.fastInsert(KIO::UDSEntry::UDS_ICON_NAME, file.readIcon());
                }
                uds.replace(KIO::UDSEntry::UDS_TARGET_URL, toDisplayString);
                udslist << uds;
            }
        }
```

#### AUTO 


```{c}
auto device = new MTPDevice(QStringLiteral("/modules/kmtpd/device%1").arg(m_devices.count()), mtpDevice, rawDevice, solidDevice.udi());
```

#### AUTO 


```{c}
auto s = ring.nextFree();
```

#### AUTO 


```{c}
const auto fileSize = 8;
```

#### AUTO 


```{c}
auto url = tmpUrl("noResumeAndNoPartial/thing");
```

#### AUTO 


```{c}
auto path = m_archiveFile->fileName();
```

#### AUTO 


```{c}
auto getSubCreator = [&filePath, this]() -> ThumbCreator* {
        const QMimeDatabase db;
        const QString subPlugin = pluginForMimeType(db.mimeTypeForFile(filePath).name());
        if (subPlugin.isEmpty() || !m_enabledPlugins.contains(subPlugin)) {
            return nullptr;
        }
        return getThumbCreator(subPlugin);
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const KService::Ptr& plugin : plugins) {
        const QStringList mimeTypes = plugin->serviceTypes();
        for (const QString& mime : mimeTypes) {
            if(mime.endsWith('*')) {
                const auto mimeGroup = mime.leftRef(mime.length()-1);
                if(mimeType.startsWith(mimeGroup))
                    return plugin->library();
            }
        }
    }
```

#### AUTO 


```{c}
const auto &discoverer
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &entryPath : entries) {
            if (entries.count() > 1 && !entryPath.endsWith(QLatin1String(".fb2"))) { // can this done a bit more cleverly?
                continue;
            }

            const auto *entry = zip.directory()->file(entryPath);
            if (!entry) {
                return false;
            }

            zipDevice.reset(entry->createDevice());
        }
```

#### LAMBDA EXPRESSION 


```{c}
[friendlyName] (const KMTPDeviceInterface *device) {
        return device->friendlyName() == friendlyName;
    }
```

#### AUTO 


```{c}
auto appendDiscovery = [&](const Discovery::Ptr &discovery) {
                if (discoveredNames.contains(discovery->udsName())) {
                    return;
                }
                discoveredNames << discovery->udsName();
                list.append(discovery->toEntry());
            };
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &it_dir : qAsConst(m_manpath))
    {
        // Translated pages in "<mandir>/<lang>" if the directory
        // exists
        for (const QLocale &it_loc : locales)
        {
            // TODO: languageToString() is wrong, that returns the readable name
            // of the language.  We want the country code returned by name().
            QString lang = QLocale::languageToString(it_loc.language());
            if ( !lang.isEmpty() && lang!=QString("C") )
            {
                QString dir = it_dir+'/'+lang;
                QDir d(dir);
                if (d.exists())
                {
                    const QString p = d.canonicalPath();
                    if (!man_dirs.contains(p)) man_dirs += p;
                }
            }
        }

        // Untranslated pages in "<mandir>"
        const QString p = QDir(it_dir).canonicalPath();
        if (!man_dirs.contains(p)) man_dirs += p;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &page : list)
        {
            // Remove any compression suffix present
            QString name = stripCompression(page);
            QString displayName;
            // Remove any preceding pathname components, just leave the base name
            int pos = name.lastIndexOf('/');
            if (pos>0) name = name.mid(pos+1);
            // Remove the section suffix
            pos = name.lastIndexOf('.');
            if (pos>0)
            {
                displayName = name.left(pos)+" ("+name.mid(pos+1)+')';
                name.truncate(pos);
            }

            uds_entry.clear();
            uds_entry.fastInsert(KIO::UDSEntry::UDS_NAME, name);
            if (!displayName.isEmpty()) uds_entry.fastInsert(KIO::UDSEntry::UDS_DISPLAY_NAME, displayName);
            uds_entry.fastInsert(KIO::UDSEntry::UDS_URL, ("man:" + page));
            uds_entry.fastInsert(KIO::UDSEntry::UDS_FILE_TYPE, S_IFREG);
            uds_entry.fastInsert(KIO::UDSEntry::UDS_MIME_TYPE, QStringLiteral("text/html"));
            listEntry(uds_entry);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[udi] (const MTPDevice *device) {
        return device->udi() == udi;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : files) {
        QUrl url(file);
        if (!url.isLocalFile()) {
            continue;
        }
        const QString urlPath = url.path();
        for (const QUrl &dirUrl : qAsConst(m_searchUrls)) {
            if (urlPath.startsWith(dirUrl.path())) {
                url.setScheme(QStringLiteral("filenamesearch"));
                fileList << url;
            }
        }
    }
```

#### AUTO 


```{c}
const auto &map = file.APETag()->itemListMap();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &dir : path_list_env)
    {
        if (!dir.isEmpty())				// non empty part - add if exists
        {
            if (m_manpath.contains(dir)) continue;	// ignore if already present
            if (QDir(dir).exists()) m_manpath += dir;	// add to list if exists
        }
        else						// empty part - merge constructed path
        {
            // Insert constructed path ($MANPATH was empty, or
            // there was a ":" at either end or "::" within)
            for (const QString &dir2 : qAsConst(constr_path))
            {
                if (dir2.isEmpty()) continue;		// don't add a null entry
                if (m_manpath.contains(dir2)) continue;	// ignore if already present
							// add to list if exists
                if (QDir(dir2).exists()) m_manpath += dir2;
            }
        }
    }
```

#### AUTO 


```{c}
auto filefdClose = qScopeGuard([filefd] {
        smbc_close(filefd);
    });
```

#### RANGE FOR STATEMENT 


```{c}
for (const StandardName &standardName : STANDARD_NAMES)
            {
              if ( args[0] == standardName.abbrev )
              {
                found = true;
                out_html(standardName.formalName);
                break;
              }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        browser.disconnect(); // Stop sending anything, we'll exit here.
        // Resolution still requires an event loop. So, let the resolutions
        // finish and then quit the loop. Services that fail resolution
        // get dropped since we won't be able to access them properly.
        for (auto it = services.begin(); it != services.end(); ++it) {
            auto service = *it;
            if (!service->resolve()) {
                qCWarning(KIO_SMB_LOG) << "Failed to resolve DNSSD service"
                                   << service->serviceName();
                it = services.erase(it);
            }
        }
        e.quit();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&pattern](const QString &path) -> bool {
        QFile file(path);
        if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
            return false;
        }

        QTextStream in(&file);
        while (!in.atEnd()) {
            const QString line = in.readLine();
            if (line.contains(pattern)) {
                return true;
            }
        }

        return false;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto entry : list) {
            QUrl entryUrl(dirUrl);
            QString path = entryUrl.path();
            if (!path.endsWith(QLatin1Char('/'))) {
                path += QLatin1Char('/');
            }
            // UDS_NAME is e.g. "foo/bar/somefile.txt"
            entryUrl.setPath(path + entry.stringValue(KIO::UDSEntry::UDS_NAME));

            const QString urlStr = entryUrl.toDisplayString();
            entry.replace(KIO::UDSEntry::UDS_URL, urlStr);

            const QString fileName = entryUrl.fileName();
            entry.replace(KIO::UDSEntry::UDS_NAME, fileName);

            if (entry.isDir()) {
                // Also search the target of a dir symlink
                if (const QString linkDest = entry.stringValue(KIO::UDSEntry::UDS_LINK_DEST); !linkDest.isEmpty()) {
                    // Remember the dir to prevent endless loops
                    if (const auto [it, isInserted] = iteratedDirs.insert(linkDest); isInserted) {
                        pendingDirs.push(entryUrl.resolved(QUrl(linkDest)));
                    }
                }

                iteratedDirs.insert(urlStr);
            }

            if (match(entry, regex, searchContents)) {
                // UDS_DISPLAY_NAME is e.g. "foo/bar/somefile.txt"
                entry.replace(KIO::UDSEntry::UDS_DISPLAY_NAME, fileName);
                listEntry(entry);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : files) {
            if (file.startsWith(dirUrl.path())) {
                QUrl url(file);
                url.setScheme(QStringLiteral("filenamesearch"));
                fileList << url;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (LPTSTR iconRes : qAsConst(iconResources)) {
            if ( !IS_INTRESOURCE(iconRes) )
            {
                delete [] iconRes;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, &list]() {
               if (list.isEmpty()) {
                   return;
               }
               listEntries(list);
               list.clear();
           }
```

#### AUTO 


```{c}
auto tail = strippedPath.mid(splitPosition);
```

#### AUTO 


```{c}
auto path = result[0].toString();
```

#### AUTO 


```{c}
const auto &map = file.ID3v2Tag()->frameListMap();
```

#### LAMBDA EXPRESSION 


```{c}
[&e, &flushEntries]() {
               flushEntries();
               e.quit();
           }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &service : services) {
        udsentry.fastInsert(KIO::UDSEntry::UDS_NAME, service->serviceName());

        udsentry.fastInsert(KIO::UDSEntry::UDS_FILE_TYPE, S_IFDIR);
        udsentry.fastInsert(KIO::UDSEntry::UDS_ACCESS, (S_IRUSR | S_IXUSR | S_IRGRP | S_IXGRP | S_IROTH | S_IXOTH));

        // TODO: it may be better to resolve the host to an ip address. dnssd
        //   being able to find a service doesn't mean name resolution is
        //   properly set up for its domain. So, we may not be able to resolve
        //   this without help from avahi. OTOH KDNSSD doesn't have API for this
        //   and from a platform POV we should probably assume that if avahi
        //   is functional it is also set up as resolution provider.
        //   Given the plugin design on glibc's libnss however I am not sure
        //   that assumption will be true all the time. ~sitter, 2018
        QUrl u(QStringLiteral("smb://"));
        u.setHost(service->hostName());
        if (service->port() > 0 && service->port() != 445 /* default smb */) {
            u.setPort(service->port());
        }

        udsentry.fastInsert(KIO::UDSEntry::UDS_URL, u.url());
        udsentry.fastInsert(KIO::UDSEntry::UDS_MIME_TYPE,
                            QStringLiteral("application/x-smb-server"));

        listEntry(udsentry);
        udsentry.clear();
    }
```

#### AUTO 


```{c}
auto query = database->execQuery(queryString.arg(activity));
```

