#### LAMBDA EXPRESSION 


```{c}
[this](bool enable) { d->togglePreview(enable); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &row : mapping) {
        const QStringList locations = QStandardPaths::standardLocations(row.location);
        for (const QString &location : locations) {
            map.insert(location, row.name);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &lang : qAsConst(langs)) {
            search.append(QStringLiteral("%1/%2/%3").arg(localDoc[id], lang, fname));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &info : fileInfoList) {
        const QString filesPath = info.physicalPath;
        if (synchronousDel(filesPath, true, true) || m_lastErrorCode == KIO::ERR_DOES_NOT_EXIST) {
            QFile::remove(infoPath(info.trashId, info.fileId));
        } else {
            // error code is set by synchronousDel, let's remember it
            // (so that successfully removing another file doesn't erase the error)
            myErrorCode = m_lastErrorCode;
            myErrorMsg = m_lastErrorMessage;
            // and remember not to remove this file
            unremovableFiles.insert(filesPath);
            qCDebug(KIO_TRASH) << "Unremovable:" << filesPath;
        }

        TrashSizeCache trashSize(trashDirectoryPath(info.trashId));
        trashSize.clear();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KIO::Job *job, const KIO::UDSEntryList &list) {gotEntries(job, list);}
```

#### LAMBDA EXPRESSION 


```{c}
[q](KIO::Job*, const QUrl&, const QString&, const QUrl &to) {
            emit q->itemCreated(to);
    }
```

#### AUTO 


```{c}
auto *delegate = new KDialogJobUiDelegate;
```

#### LAMBDA EXPRESSION 


```{c}
[](QPointer<KProcessRunner> r) {
        return r.isNull() || r->waitForStarted();
    }
```

#### AUTO 


```{c}
const auto ituend = itemsInUse.cend();
```

#### LAMBDA EXPRESSION 


```{c}
[this, applyOtherChanges]() {
        connect(d->m_permissionsPropsPlugin, &KFilePermissionsPropsPlugin::changesApplied, this, [applyOtherChanges]() {
            applyOtherChanges();
        });

        d->m_permissionsPropsPlugin->applyChanges();
    }
```

#### AUTO 


```{c}
auto privilegeRestore = qScopeGuard([&origPrivilege]() {
            gainPrivilege(origPrivilege.data());
        });
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &key : keys) {
            l.append(prepend + QLatin1Char('$') + key);
        }
```

#### CONST EXPRESSION 


```{c}
static constexpr int DEFAULT_MAX_CACHE_SIZE = 50 * 1024;
```

#### AUTO 


```{c}
auto *dlg = new KIO::RenameDialog(KJobWidgets::window(job), caption,
                                      src, dest, options,
                                      sizeSrc, sizeDest,
                                      ctimeSrc, ctimeDest,
                                      mtimeSrc, mtimeDest);
```

#### AUTO 


```{c}
auto it = std::find_if(storage.cbegin(), storage.cend(), [udsField](const Field &entry) {
        return entry.m_index == udsField;
    });
```

#### RANGE FOR STATEMENT 


```{c}
for (const AuthInfoContainer &current : *authList) {
            qCDebug(category) << "Evaluating: " << current.info.url.scheme() << current.info.url.host() << current.info.username;
            if (current.info.url.scheme() == protocol && current.info.url.host() == host && (current.info.username == user || user.isEmpty())) {
                qCDebug(category) << "Removing this entry";
                removeAuthInfoItem(dictIterator.key(), current.info); // warning, this can modify m_authDict!
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : trashFiles) {
        if (file == QLatin1Char('.') || file == QLatin1String("..")) {
            continue;
        }
        QUrl url;
        url.setScheme(QStringLiteral("trash"));
        url.setPath(QLatin1String("0-") + file);
        KIO::StatJob *statJob = KIO::mostLocalUrl(url, KIO::HideProgressInfo);
        QVERIFY(statJob->exec());
        QCOMPARE(url, statJob->mostLocalUrl());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KIO::Job *job, KIO::filesize_t offset) {
                slotCanResume(job, offset);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        const int errCode = job->error();
        if (errCode) {
            // ERR_NO_CONTENT is not an error, but an indication no further
            // actions need to be taken.
            if (errCode != KIO::ERR_NO_CONTENT) {
                q->setError(errCode);
                // We're a KJob, not a KIO::Job, so build the error string here
                q->setErrorText(KIO::buildErrorString(errCode, job->errorText()));
            }
            q->emitResult();
            return;
        }
        if (m_followRedirections) { // Update our URL in case of a redirection
            m_url = job->url();
        }

        const KIO::UDSEntry entry = job->statResult();

        const QString localPath = entry.stringValue(KIO::UDSEntry::UDS_LOCAL_PATH);
        if (!localPath.isEmpty()) {
            m_url = QUrl::fromLocalFile(localPath);
        }

        // MIME type already known? (e.g. print:/manager)
        m_mimeTypeName = entry.stringValue(KIO::UDSEntry::UDS_MIME_TYPE);
        if (!m_mimeTypeName.isEmpty()) {
            q->emitResult();
            return;
        }

        if (entry.isDir()) {
            m_mimeTypeName = QStringLiteral("inode/directory");
            q->emitResult();
        } else { // It's a file
            // Start the timer. Once we get the timer event this
            // protocol server is back in the pool and we can reuse it.
            // This gives better performance than starting a new slave
            QTimer::singleShot(0, q, [this] {
                scanFileWithGet();
            });
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { _k_slotUrlDesktopFile(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : urls) {
        KFileItem item = d->dirLister->findByUrl(url);
        if (d->shouldFetchForItems && item.isNull()) {
            d->itemsToBeSetAsCurrent << url;
            d->dirModel->expandToUrl(url);
            continue;
        }
        itemList << item;
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr int s_slaveConnectionTimeoutMax = 3600;
```

#### AUTO 


```{c}
auto *abstractPlugin = service->createInstance<KAbstractFileItemActionPlugin>();
```

#### LAMBDA EXPRESSION 


```{c}
[this](QDBusPendingCallWatcher *watcher) {
        QDBusPendingReply<> reply = *watcher;
        watcher->deleteLater();
        if (reply.isError()) {
            qCWarning(KIO_GUI) << "Failed to unref service:" << m_serviceName << reply.error().name() << reply.error().message();
            return systemdError(reply.error().name());
        }
        qCDebug(KIO_GUI) << "Successfully unref'd service:" << m_serviceName;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const KPropertiesDialogPlugin *page) {
        return page->isDirty();
    }
```

#### AUTO 


```{c}
const auto storResult = ftpOpenCommand("stor", dest, '?', ERR_CANNOT_WRITE, offset);
```

#### RANGE FOR STATEMENT 


```{c}
for (uint field : fields) {
        if (!other.contains(field)) {
            return false;
        }

        if (field & UDSEntry::UDS_STRING) {
            if (entry.stringValue(field) != other.stringValue(field)) {
                return false;
            }
        } else {
            if (entry.numberValue(field) != other.numberValue(field)) {
                return false;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *widget : widgetsList) {
        KFileWidget *fw = widget->findChild<KFileWidget *>();
        if (fw) {
            widgets.append(fw);
        }
    }
```

#### AUTO 


```{c}
auto propReply = m_serviceProperties->GetAll(QString());
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job, qulonglong totalSize) {
        slotTotalSize(job, totalSize);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KSslError::Error e : errors) {
        QSslError::SslError error = KSslErrorPrivate::errorFromKSslError(e);
        if (!isErrorIgnored(error)) {
            d->ignoredErrors.append(error);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &mimeType : mimeTypeList) {
        const KService::Ptr serv = preferredService(mimeType, traderConstraint);
        const QString newOffer = serv ? serv->storageId() : QString();
        serviceIdList << newOffer;
    }
```

#### AUTO 


```{c}
auto job = KIO::copy({QUrl::fromLocalFile(QFINDTESTDATA("ftp/testOverwriteCopy2"))}, url, KIO::Overwrite);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QModelIndex &idx, bool success) {
            storageSetupDone(idx, success);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Request *request : std::as_const(m_authPending)) {
        if (request->key != key) {
            continue;
        }

        if (info.verifyPath) {
            const QString path1(request->info.url.path().left(info.url.path().indexOf(QLatin1Char('/')) + 1));
            if (!path2.startsWith(path1)) {
                continue;
            }
        }

        return true;
    }
```

#### AUTO 


```{c}
const auto writeOnce = [&putDataBuffer, &size, putDataContents]() {
        const auto pos = putDataBuffer.pos();
        size += putDataBuffer.write(putDataContents);
        putDataBuffer.seek(pos);
        //         qDebug() << "written" << size;
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : indexes) {
        const KFileItem &item = d->nodeForIndex(index)->item();
        urls << item.url();
        bool isLocal;
        mostLocalUrls << item.mostLocalUrl(isLocal);
        if (!isLocal) {
            canUseMostLocalUrls = false;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &mountDir : mountDirs) {
            const QString type = mountDir.section(QLatin1Char(':'), 0, 0);
            if (type.isEmpty()) {
                continue;
            }

            KMountPoint::Ptr gvfsmp(new KMountPoint);
            gvfsmp->d->m_mountedFrom = m_mountedFrom;
            gvfsmp->d->m_mountPoint = m_mountPoint + QLatin1Char('/') + mountDir;
            gvfsmp->d->m_mountType = type;
            result.append(gvfsmp);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QueuedRequest &request : qAsConst(m_requestQueue)) {
            QDBusConnection::sessionBus().send(request.transaction.createReply(QLatin1String("DIRECT")));
        }
```

#### AUTO 


```{c}
auto *dlg = new KIO::RenameDialog(KJobWidgets::window(job), caption, src, dest, options, sizeSrc, sizeDest, ctimeSrc, ctimeDest, mtimeSrc, mtimeDest);
```

#### LAMBDA EXPRESSION 


```{c}
[&removalWithinTopLevel](const QModelIndex &index) {
        if (!index.isValid()) {
            // yes, that's what we have been waiting for
            removalWithinTopLevel = true;
        }
    }
```

#### AUTO 


```{c}
auto *askUserActionInterface = KIO::delegateExtension<AskUserActionInterface *>(q);
```

#### AUTO 


```{c}
const auto exec = KProtocolInfo::exec(d->m_strURL.scheme());
```

#### AUTO 


```{c}
auto it = dirCache.constFind(QFile::encodeName(fileName));
```

#### AUTO 


```{c}
auto init()
{
    system(R"(
echo "Making some directories for the test..."

rm -rf ~/.cache/kio-test-files
mkdir -p ~/.cache/kio-test-files

echo "hello world" > ~/.cache/kio-test-files/1
echo "hello world" > ~/.cache/kio-test-files/2
echo "hello world" > ~/.cache/kio-test-files/3
echo "hello world" > ~/.cache/kio-test-files/4
echo "hello world" > ~/.cache/kio-test-files/5
echo "hello world" > ~/.cache/kio-test-files/6
echo "hello world" > ~/.cache/kio-test-files/7
echo "hello world" > ~/.cache/kio-test-files/8
echo "hello world" > ~/.cache/kio-test-files/9
echo "hello world" > ~/.cache/kio-test-files/10

mkdir -p ~/.cache/kio-test-files/more-files

echo "hello world" > ~/.cache/kio-test-files/more-files/1
echo "hello world" > ~/.cache/kio-test-files/more-files/2
echo "hello world" > ~/.cache/kio-test-files/more-files/3
echo "hello world" > ~/.cache/kio-test-files/more-files/4
echo "hello world" > ~/.cache/kio-test-files/more-files/5
echo "hello world" > ~/.cache/kio-test-files/more-files/6
echo "hello world" > ~/.cache/kio-test-files/more-files/7
echo "hello world" > ~/.cache/kio-test-files/more-files/8
echo "hello world" > ~/.cache/kio-test-files/more-files/9
echo "hello world" > ~/.cache/kio-test-files/more-files/10

sudo rm -rf /.kio-test-files/
sudo mkdir -p /.kio-test-files/

echo "Made them!"
    )");
}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &str : sslList) {
        certChain.append(QSslCertificate(str.toUtf8()));
        if (certChain.last().isNull()) {
            decodedOk = false;
            break;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](QDBusPendingCallWatcher *watcher) {
        QDBusPendingReply<void> reply = *watcher;
        watcher->deleteLater();

        if (reply.isError()) {
            // Try the KRun strategy as fallback, also calls emitResult inside
            OpenFileManagerWindowKRunStrategy kRunStrategy(job);
            kRunStrategy.start(urls, asn);
            return;
        }

        emitResultProxy();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString & /*text */) { _k_delayedSlotTextChanged(); }
```

#### LAMBDA EXPRESSION 


```{c}
[=] {
            done(OpenFile);
        }
```

#### AUTO 


```{c}
auto *job = new KIO::ApplicationLauncherJob(app);
```

#### LAMBDA EXPRESSION 


```{c}
[this](KIO::filesize_t length) { slotTruncated(length); }
```

#### AUTO 


```{c}
const auto checkMaxTime = [&max_mtime](const qint64 lastModTime) {
        if (lastModTime > max_mtime) {
            max_mtime = lastModTime;
        }
    };
```

#### AUTO 


```{c}
auto it = mGroupcache.find(gid);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->slotProperties(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : urls) {
            subst(option, url, ret);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { slotAboutToHide(); }
```

#### LAMBDA EXPRESSION 


```{c}
[&putDataBuffer]() {
        Q_EMIT putDataBuffer.readChannelFinished();
    }
```

#### AUTO 


```{c}
const auto iconSize
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        mkdir();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &match : *matches) {
        QString& matchString = match.value();
        if (!matchString.isNull()) {
            if (matchString.endsWith(QLatin1Char('/'))) {
                d->quoteText(&matchString, false, true);    // don't quote trailing '/'
            } else {
                d->quoteText(&matchString, false, false);    // quote the whole text
            }

            matchString.prepend(d->m_text_start);
        }
    }
```

#### AUTO 


```{c}
auto addUrl = [u, &urls](const QString &partial_name) {
        if (partial_name.trimmed().isEmpty()) {
            return;
        }

        // We have to use setPath here, so that something like "test#file"
        // isn't interpreted to have path "test" and fragment "file".
        QUrl partial_url;
        partial_url.setPath(partial_name);

        // This returns QUrl(partial_name) for absolute URLs.
        // Otherwise, returns the concatenated url.
        const QUrl finalUrl = u.resolved(partial_url);

        if (finalUrl.isValid()) {
            urls.append(finalUrl);
        } else {
            // This can happen in the first quote! (ex: ' "something here"')
            qCDebug(KIO_KFILEWIDGETS_FW) << "Discarding Invalid" << finalUrl;
        }
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this](KIO::Job *job, const KIO::UDSEntryList &entries) {
                    _k_slotEntries(job, entries);
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->slotSortByDate(); }
```

#### AUTO 


```{c}
auto list = QStringList();
```

#### AUTO 


```{c}
const auto requiredNumbers = cfg.readEntry("X-KDE-RequiredNumberOfUrls", QList<int>());
```

#### AUTO 


```{c}
const auto url = QUrl::fromLocalFile(path);
```

#### AUTO 


```{c}
const auto fileUrl = QUrl::fromLocalFile(QDir::homePath() + QLatin1Char('/'));
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->slotTreeView();
    }
```

#### AUTO 


```{c}
auto shares = KSambaSharePrivate::parse(usershareData);
```

#### AUTO 


```{c}
auto it = std::find_if(cbegin(), cend(), [&fileName](const KFileItem &item) {
        return item.name() == fileName;
    });
```

#### LAMBDA EXPRESSION 


```{c}
[&buff, &realPath](const KMountPoint::Ptr &mountPtr) {
            // For a bind mount, the deviceId() is that of the base mount point, e.g. /mnt/foo,
            // however the path we're looking for, e.g. /home/user/bar, doesn't start with the
            // mount point of the base device, so we go on searching
            return mountPtr->deviceId() == buff.st_dev && realPath.startsWith(mountPtr->mountPoint());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QueuedRequest &request : std::as_const(m_requestQueue)) {
            QDBusConnection::sessionBus().send(request.transaction.createReply(QLatin1String("DIRECT")));
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &attrName, const QString &value, const QString &fileName) {
                return QStringList{QLatin1String("-w"), attrName, value, fileName};
            }
```

#### AUTO 


```{c}
const static auto pools = {
            CachePool{QStringLiteral("/normal/"), 128},
            CachePool{QStringLiteral("/large/"), 256},
            CachePool{QStringLiteral("/x-large/"), 512},
            CachePool{QStringLiteral("/xx-large/"), 1024},
        };
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &path) {
            enterUrl(path);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &domain : domainList) {
            const KHttpCookieList *list = mCookieJar->getCookieList(domain, fqdn);
            if (!list) {
                continue;
            }
            for (const KHttpCookie &cookie : *list) {
                if (cookie.isExpired()) {
                    continue;
                }
                putCookie(result, cookie, fields);
            }
        }
```

#### AUTO 


```{c}
const auto& mimeFilter
```

#### LAMBDA EXPRESSION 


```{c}
[this](QModelIndex index) { d->triggerPreview(index); }
```

#### LAMBDA EXPRESSION 


```{c}
[=](KIO::Job *, const QString &mimetype) {
        if (m_followRedirections) { // Update our URL in case of a redirection
            m_url = job->url();
        }
        if (mimetype.isEmpty()) {
            qCWarning(KIO_GUI) << "get() didn't emit a MIME type! Probably a kioslave bug, please check the implementation of" << m_url.scheme();
        }
        m_mimeTypeName = mimetype;

        // If the current MIME type is the default MIME type, then attempt to
        // determine the "real" MIME type from the file name (bug #279675)
        const QMimeType mime = fixupMimeType(m_mimeTypeName, m_suggestedFileName.isEmpty() ? m_url.fileName() : m_suggestedFileName);
        const QString mimeName = mime.name();
        if (mime.isValid() && mimeName != m_mimeTypeName) {
            m_mimeTypeName = mimeName;
        }

        if (m_suggestedFileName.isEmpty()) {
            m_suggestedFileName = job->queryMetaData(QStringLiteral("content-disposition-filename"));
        }

        job->putOnHold();
        KIO::Scheduler::publishSlaveOnHold();
        runUrlWithMimeType();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
            const QUrl resolvedTargetLocation = properties->item().url().resolved(QUrl(d->m_ui->symlinkTargetEdit->text()));

            KIO::StatJob *statJob = KIO::statDetails(resolvedTargetLocation, KIO::StatJob::SourceSide, KIO::StatNoDetails, KIO::HideProgressInfo);
            connect(statJob, &KJob::finished, this, [this, statJob] {
                if (statJob->error()) {
                    d->m_ui->symlinkTargetMessageWidget->setText(statJob->errorString());
                    d->m_ui->symlinkTargetMessageWidget->animatedShow();
                    return;
                }

                KIO::highlightInFileManager({statJob->url()});
                properties->close();
            });
        }
```

#### LAMBDA EXPRESSION 


```{c}
[parentWindow](bool allowDelete, const QList<QUrl> &, KIO::AskUserActionInterface::DeletionType, QWidget *parent) {
                            if (parent != parentWindow || !allowDelete) {
                                return;
                            }

                            KIO::Job *job = KIO::emptyTrash();
                            job->setUiDelegate(new KIO::JobUiDelegate(KJobUiDelegate::AutoHandlingEnabled, parentWindow));
                        }
```

#### AUTO 


```{c}
const auto kend = items.cend();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : std::as_const(deletedUrls)) {
        removedCount += clipboardUrls.removeAll(url);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&_name](const KFileItem &item) {
        return _name == item.name();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &serviceId : serviceIdList) {
        KFileItemList serviceItems;
        for (const KFileItem &item : fileItems) {
            const KService::Ptr serv = preferredService(item.mimetype(), m_traderConstraint);
            const QString preferredServiceId = serv ? serv->storageId() : QString();
            if (preferredServiceId == serviceId) {
                serviceItems << item;
            }
        }

        if (serviceId.isEmpty()) { // empty means: no associated app for this MIME type
            openWithByMime(serviceItems);
            continue;
        }

        const KService::Ptr servicePtr = KService::serviceByStorageId(serviceId); // can be nullptr
        auto *job = new KIO::ApplicationLauncherJob(servicePtr);
        job->setUrls(serviceItems.urlList());
        job->setUiDelegate(new KIO::JobUiDelegate(KJobUiDelegate::AutoHandlingEnabled, m_parentWidget));
        job->start();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KIO::Job *job, const KIO::UDSEntryList &list) {
                slotEntries(job, list);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &text) {
        d->locationAccepted(text);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        slotReturnPressed();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &opt : std::as_const(upgradeOffers)) {
            if (opt == QLatin1String("TLS/1.0")) {
                if (!startSsl() && upgradeRequired) {
                    error(ERR_UPGRADE_REQUIRED, opt);
                    return false;
                }
            } else if (opt == QLatin1String("HTTP/1.1")) {
                httpRev = HTTP_11;
            } else if (upgradeRequired) {
                // we are told to do an upgrade we don't understand
                error(ERR_UPGRADE_REQUIRED, opt);
                return false;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job, const QString &info) {
        _k_slotInfoMessage(job, info);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        slotOpen();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KCoreDirLister *kdl : listers) {
            kdl->d->jobDone(job);
            if (job->error() != KJob::KilledJobError) {
                kdl->handleError(job);
            }
            const bool silent = job->property("_kdlc_silent").toBool();
            if (!silent) {
                emit kdl->canceled(jobUrl);
            }

            if (kdl->d->numJobs() == 0) {
                kdl->d->complete = true;
                if (!silent) {
                    emit kdl->canceled();
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (KCoreDirLister *kdl : listers) {
                    if (kdl->d->rootFileItem.isNull() && kdl->d->url == jobUrl) {
                        kdl->d->rootFileItem = dir->rootItem;
                    }
                }
```

#### AUTO 


```{c}
const auto [it, isInserted] = m_parentDirs.insert(parentDir);
```

#### AUTO 


```{c}
auto *copyJob = qobject_cast<KIO::CopyJob*>(job)
```

#### RANGE FOR STATEMENT 


```{c}
for (KProcessRunner *r : qAsConst(d->m_processRunners)) {
        qApp->sendPostedEvents(r); // so slotStarted gets called
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool show) { d->toggleBookmarks(show); }
```

#### AUTO 


```{c}
auto *runningSlave
```

#### AUTO 


```{c}
auto fit = dirItem->lstItems.begin(), fend = dirItem->lstItems.end();
```

#### LAMBDA EXPRESSION 


```{c}
[&entriesListed] (KIO::Job*, const KIO::UDSEntryList &entries) {
                            entriesListed += entries.size();
                            qDebug() << "Listed" << entriesListed << "files.";
                         }
```

#### AUTO 


```{c}
auto length = static_cast<KIO::filesize_t *>(data);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &udi : qAsConst(devices)) {
        bookmark = KFilePlacesItem::createDeviceBookmark(bookmarkManager, udi);
        if (!bookmark.isNull()) {
            KFilePlacesItem *item = new KFilePlacesItem(bookmarkManager, bookmark.address(), udi, q);
            QObject::connect(item, &KFilePlacesItem::itemChanged, q, [this](const QString &id) {
                itemChanged(id);
            });
            // TODO: Update bookmark internal element
            items << item;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KJob *job : std::as_const(m_previewJobs)) {
        Q_ASSERT(job);
        job->kill();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &path : templates) {
        dir.setPath(path);
        const QStringList &entryList(dir.entryList(QStringList() << QStringLiteral("*.desktop"), QDir::Files));
        files.reserve(files.size() + entryList.size());
        for (const QString &entry : entryList) {
            const QString file = concatPaths(dir.path(), entry);
            files.append(file);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &domain : mCookieJar->getDomainList()) {
        // Ignore domains that have policy set for but contain
        // no cookies whatsoever...
        const KHttpCookieList *list = mCookieJar->getCookieList(domain, QString());
        if (list && !list->isEmpty()) {
            result << domain;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        clipboard->setText(d->m_sha512);
    }
```

#### AUTO 


```{c}
auto *processRunner = new KProcessRunner(service, urlsToRun,
                                             windowId, flags, suggestedFileName, asn);
```

#### AUTO 


```{c}
const auto urlDest = QUrl::fromLocalFile(dest);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *action : openWithActions) {
        d->m_actionMenu->menu()->removeAction(action);
    }
```

#### AUTO 


```{c}
const auto exitStatus = signalCode == CLD_EXITED ? QProcess::ExitStatus::NormalExit : QProcess::ExitStatus::CrashExit;
```

#### LAMBDA EXPRESSION 


```{c}
[&putDataBuffer, &size, putDataContents]() {
        putDataBuffer.write(putDataContents);
        putDataBuffer.seek(0);
//         qDebug() << "written" << putDataBuffer.size();
        size = putDataBuffer.bytesAvailable();
    }
```

#### AUTO 


```{c}
const auto urlStr = url.toString();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->_k_reloadBookmarks(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &user : allUsers) {
        QVERIFY2(matches.contains(QLatin1Char('~') + user), qPrintable(matches.join(QLatin1Char(' '))));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &shorthand : shorthands) {
        Q_FOREACH (const SearchProvider* provider, m_providers) {
            if (provider != m_provider && provider->keys().contains(shorthand)) {
                contenders.insert(shorthand, provider);
                break;
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QList<QPair<KFileItem,KFileItem> > &items){d->_k_slotRefreshItems(items);}
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &item : qAsConst(m_pendingItems)) {
            if (item.isMimeTypeKnown()) {
                m_resolvedMimeTypes.append(item);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (KMountPoint::Ptr mountPoint : mountPoints) {
        qDebug().nospace() << "Mounted from: " << mountPoint->mountedFrom() << ", device name: " << mountPoint->realDeviceName()
                           << ", mount point: " << mountPoint->mountPoint() << ", mount type: " << mountPoint->mountType();
        QVERIFY(!mountPoint->mountedFrom().isEmpty());
        QVERIFY(!mountPoint->mountPoint().isEmpty());
        QVERIFY(!mountPoint->mountType().isEmpty());
        // old bug, happened because KMountPoint called KStandardDirs::realPath instead of realFilePath
        if (mountPoint->realDeviceName().startsWith(QLatin1String("/dev"))) { // skip this check for cifs mounts for instance
            QVERIFY(!mountPoint->realDeviceName().endsWith('/'));
        }

        // keep one (any) mountpoint with a device name for the test below
        if (!mountPoint->realDeviceName().isEmpty() && !mountWithDevice) {
            mountWithDevice = mountPoint;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->slotToggleDirsFirst(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &domain : mCookieJar->getDomainList()) {
        // Ignore domains that have policy set for but contain
        // no cookies whatsoever...
        const KHttpCookieList *list =  mCookieJar->getCookieList(domain, QString());
        if (list && !list->isEmpty()) {
            result << domain;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        _k_slotAbortDialog();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &groupName : groupNames) {
        QByteArray certDigest = groupName.toLatin1();
        const QStringList keys = d->config.group(groupName).keyList();
        for (const QString &key : keys) {
            if (key == QLatin1String("CertificatePEM")) {
                continue;
            }
            KSslCertificateRule r = rule(QSslCertificate(certDigest), key);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &entry : entries) {
        const QString url = entry.stringValue(KIO::UDSEntry::UDS_URL);

        QString entry_name;
        if (!url.isEmpty()) {
            // qDebug() << "url:" << url;
            entry_name = QUrl(url).fileName();
        } else {
            entry_name = entry.stringValue(KIO::UDSEntry::UDS_NAME);
        }

        // This can happen with kdeconnect://deviceId as a completion for kdeconnect:/,
        // there's no fileName [and the UDS_NAME is unrelated, can't use that].
        // This code doesn't support completing hostnames anyway (see addPathToUrl below).
        if (entry_name.isEmpty()) {
            continue;
        }

        if (entry_name.at(0) == QLatin1Char('.')
            && (list_urls_no_hidden || entry_name.length() == 1 || (entry_name.length() == 2 && entry_name.at(1) == QLatin1Char('.')))) {
            continue;
        }

        const bool isDir = entry.isDir();

        if (mode == KUrlCompletion::DirCompletion && !isDir) {
            continue;
        }

        if (filter_len != 0 && QStringView(entry_name).left(filter_len) != filter) {
            continue;
        }

        if (!mimeTypeFilters.isEmpty() && !isDir && !mimeTypeFilters.contains(entry.stringValue(KIO::UDSEntry::UDS_MIME_TYPE))) {
            continue;
        }

        QString toAppend = entry_name;

        if (isDir) {
            toAppend.append(QLatin1Char('/'));
        }

        if (!list_urls_only_exe || (entry.numberValue(KIO::UDSEntry::UDS_ACCESS) & s_modeExe) // true if executable
        ) {
            if (complete_url) {
                QUrl url(prepend);
                url = addPathToUrl(url, toAppend);
                matchList.append(url.toDisplayString());
            } else {
                matchList.append(prepend + toAppend);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &info : infoList) {
            del(trashId, info.fileName()); // delete trashed file

            if (util.usage(TrashSizeCache(trashPath).calculateSize() + additionalSize) < percent) { // check whether we have enough space now
                return true;
            }
        }
```

#### AUTO 


```{c}
const auto result = ftpRename(dest_orig, dest_part, KIO::Overwrite);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVector<UDSTestField> &testCase : testCases) {
            stream << testCase.count();

            for (const UDSTestField &field : testCase) {
                uint uds = field.m_uds;
                stream << uds;

                if (uds & KIO::UDSEntry::UDS_STRING) {
                    stream << field.m_string;
                } else {
                    Q_ASSERT(uds & KIO::UDSEntry::UDS_NUMBER);
                    stream << field.m_long;
                }
            }
        }
```

#### AUTO 


```{c}
auto copy(const QList<QUrl>& items, const QUrl& to)
{
    auto job = KIO::move(items, to);

    Fum->recordCopyJob(job);

    return jobToFuture(QStringLiteral("copy %1 to %2").arg(toStr(items)).arg(toStr(to)), job);
}
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &request : qAsConst(requests)) {
        if (!request.reply.isError()) {
            d->urls[request.urlIndex] = QUrl::fromLocalFile(request.reply.value());
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
            if (filesJob->error()) {
                filesJob->uiDelegate()->showErrorMessage();
            }

            chmodDirs();
        }
```

#### AUTO 


```{c}
auto *job = new KIO::ApplicationLauncherJob(service);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : args) {
        // get full path
        const QString fullFilePath(QDir::current().absoluteFilePath(file));

        // construct kconfig for protocol file
        KConfig sconfig(fullFilePath);
        sconfig.setLocale(QString());
        KConfigGroup config(&sconfig, "Protocol");

        // name must be set, sanity check that file got read
        const QString name(config.readEntry("protocol"));
        if (name.isEmpty()) {
            qFatal("Failed to read input file %s.", qPrintable(fullFilePath));
        }

        // construct protocol data
        QVariantMap protocolData;

        // convert the different types
        for (const QString &key : stringAttributes) {
            if (config.hasKey(key)) {
                protocolData.insert(key, config.readEntry(key, QString()));
            }
        }
        for (const QString &key : stringListAttributes) {
            if (config.hasKey(key)) {
                protocolData.insert(key, config.readEntry(key, QStringList()));
            }
        }
        for (const QString &key : boolAttributes) {
            if (config.hasKey(key)) {
                protocolData.insert(key, config.readEntry(key, bool(false)));
            }
        }
        for (const QString &key : intAttributes) {
            if (config.hasKey(key)) {
                protocolData.insert(key, config.readEntry(key, int(0)));
            }
        }

        // handle translated keys
        for (const QString &key : translatedStringListAttributes) {
            // read untranslated entry first in any case!
            sconfig.setLocale(QString());
            const QStringList untranslatedValues = config.readEntry(key, QStringList());
            if (!untranslatedValues.isEmpty()) {
                protocolData.insert(key, untranslatedValues);
            }

            // collect all locales for this key
            QFile f(fullFilePath);
            QStringList foundLocalesForKey;
            if (!f.open(QIODevice::ReadOnly | QIODevice::Text)) {
                qFatal("Failed to open file %s.", qPrintable(fullFilePath));
            }
            while (!f.atEnd()) {
                const QString line = QString::fromUtf8(f.readLine());
                const QRegularExpressionMatch match = localeRegex.match(line);
                if (match.hasMatch()) {
                    foundLocalesForKey.append(match.captured(1));
                }
            }

            // insert all entries for all found locales, reparse config for this
            for (const QString &locale : qAsConst(foundLocalesForKey)) {
                sconfig.setLocale(locale);
                protocolData.insert(QStringLiteral("%1[%2]").arg(key, locale), config.readEntry(key, QStringList()));
            }
        }

        // use basename of protocol for toplevel map in json, like it is done for .protocol files
        const QString baseName(QFileInfo(fullFilePath).baseName());
        protocolsData.insert(baseName, protocolData);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool allowDelete, const QList<QUrl> &urls, KIO::AskUserActionInterface::DeletionType deletionType, QWidget *parentWidget) {
                         slotAskUserDeleteResult(allowDelete, urls, deletionType, parentWidget);
                     }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job, ulong speed) {
            Q_UNUSED(job);
            emitSpeed(speed);
        }
```

#### AUTO 


```{c}
const auto perms = item.permissions();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &dir : dirs) {
        KFileItemList deletedItems;

        const QList<KFileItem> *itemList = kDirListerCache()->itemsForDir(dir);
        if (!itemList) {
            continue;
        }

        auto kit = itemList->begin();
        const auto kend = itemList->end();
        for (; kit != kend; ++kit) {
            const KFileItem &item = *kit;
            const QString text = item.text();
            if (text == QLatin1Char('.') || text == QLatin1String("..")) {
                continue;
            }
            const bool wasVisible = oldVisibleItems.contains(item.name());
            const bool nowVisible = isItemVisible(item) && q->matchesMimeFilter(item);
            if (nowVisible && !wasVisible) {
                addNewItem(dir, item);    // takes care of emitting newItem or itemsFilteredByMime
            } else if (!nowVisible && wasVisible) {
                deletedItems.append(*kit);
            }
        }
        if (!deletedItems.isEmpty()) {
            Q_EMIT q->itemsDeleted(deletedItems);
        }
        emitItems();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&name](const QRegExp &filter) {
        return filter.exactMatch(name);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->assureVisibleSelection();
    }
```

#### AUTO 


```{c}
const auto networkError = d->sock.socketError();
```

#### LAMBDA EXPRESSION 


```{c}
[q](KIO::Job*, const QUrl&, const QString&, const QUrl &to) {
            Q_EMIT q->itemCreated(to);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        configChanged();
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr int KIO_MAX_ENTRIES_PER_BATCH = 200;
```

#### AUTO 


```{c}
const auto networkError = error();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                _k_slotOtherDesktopFileClosed();
            }
```

#### AUTO 


```{c}
auto createSystemBookmark =
            [this, &seenUrls](const char *untranslatedLabel,
                              const QUrl &url,
                              const QString &iconName,
                              const KBookmark &after) {
                if (!seenUrls.contains(url)) {
                    return KFilePlacesItem::createSystemBookmark(d->bookmarkManager, untranslatedLabel, url, iconName, after);
                }
                return KBookmark();
            };
```

#### LAMBDA EXPRESSION 


```{c}
[q](KIO::Job*, const QUrl &, const QUrl &to) {
            Q_EMIT q->itemCreated(to);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]{done(ExecuteFile);}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &key : stringAttributes) {
            if (config.hasKey(key)) {
                protocolData.insert(key, config.readEntry(key, QString()));
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&origPrivilege]() {
            gainPrivilege(origPrivilege.data());
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=](KIO::SkipDialog_Result result, KJob *parentJob) {
                        Q_ASSERT(q != parentJob);
                        q->disconnect(askUserActionInterface, skipSignal, q, nullptr);

                        switch (result) {
                        case Result_AutoSkip:
                            m_bAutoSkipFiles = true;
                            // fall through
                            Q_FALLTHROUGH();
                        case Result_Skip:
                            QMetaObject::invokeMethod(q, "_k_chmodNextFile", Qt::QueuedConnection);
                            return;
                        case Result_Retry:
                            m_infos.push(std::move(info));
                            QMetaObject::invokeMethod(q, "_k_chmodNextFile", Qt::QueuedConnection);
                            return;
                        case Result_Cancel:
                        default:
                            q->setError(ERR_USER_CANCELED);
                            q->emitResult();
                            return;
                        }
                    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const KIO::UDSEntryList &list){ slotListEntries(list);}
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *provider : allProviders) {
        if (!provider->isHidden()) {
            providers << provider;
        }
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr auto s_pollFreeSpaceInterval = 1min;
```

#### AUTO 


```{c}
const auto result =
                    KMessageBox::questionYesNo(nullptr,
                                               i18n("The file\n%1\nhas been modified.\nDo you want to upload the changes?", dest.toDisplayString()),
                                               i18n("File Changed"),
                                               KGuiItem(i18n("Upload")),
                                               KGuiItem(i18n("Do Not Upload")));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &providerName : qAsConst(m_deletedProviders)) {
        QStringList matches;
        for (const QString &dir : servicesDirs) {
            QString current = dir + QLatin1Char('/') + providerName + QLatin1String(".desktop");
            if (QFile::exists(current)) {
                matches += current;
            }
        }

        // Shouldn't happen
        if (matches.isEmpty()) {
            continue;
        }

        changedProviderCount++;

        if (matches.size() == 1 && matches.first().startsWith(path)) {
            // If only the local copy existed, unlink it
            // TODO: error handling
            QFile::remove(matches.first());
            continue;
        }

        KConfig _service(path + providerName + QLatin1String(".desktop"), KConfig::SimpleConfig);
        KConfigGroup service(&_service, "Desktop Entry");
        service.writeEntry("Type", "Service");
        service.writeEntry("X-KDE-ServiceTypes", "SearchProvider");
        service.writeEntry("Hidden", true);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KIO::Job* job, const QUrl &src, const QUrl &dest) {
                slotCopyingDone(job, src, dest);
            }
```

#### AUTO 


```{c}
auto *subjob = new KIO::ApplicationLauncherJob(service, this);
```

#### AUTO 


```{c}
auto it = std::find_if(buttonsList.cbegin(), buttonsList.cend(), [](const QPushButton *button) {
            return button->text().contains("OK");
        });
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &dir : d->m_parentDirs) {
            KDirWatch::self()->restartDirScan(dir);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &parentMimeType : parentMimeTypes) {
                            pluginIt = mimeMap.constFind(parentMimeType);
                            if (pluginIt != mimeMap.constEnd()) {
                                break;
                            }
                        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &protocol : qAsConst(protocols)) {
            // We cannot use mimeTypes() here, it doesn't support groups such as: text/*
            const QStringList mtypes = (*it)->serviceTypes();
            // Add supported MIME type for this protocol
            QStringList &_ms = m_remoteProtocolPlugins[protocol];
            for (const QString &_m : mtypes) {
                if (_m != QLatin1String("ThumbCreator")) {
                    protocolMap[protocol].insert(_m, *it);
                    if (!_ms.contains(_m)) {
                        _ms.append(_m);
                    }
                }
            }
        }
```

#### CONST EXPRESSION 


```{c}
static constexpr int s_maxTimeoutValue = 3600;
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &item : std::as_const(orderedItems)) {
        m_pendingItems.append(item);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, parentWindow](bool allowDelete, const QList<QUrl> &,
                                            KIO::AskUserActionInterface::DeletionType, QWidget *parent) {
                if (parent != parentWindow || !allowDelete) {
                    return;
                }

                KIO::Job *job = KIO::emptyTrash();
                job->setUiDelegate(new KIO::JobUiDelegate(KJobUiDelegate::AutoHandlingEnabled, parentWindow));
            }
```

#### AUTO 


```{c}
auto plugin = KPluginFactory::instantiatePlugin<KPropertiesDialogPlugin>(jsonMetadata, q).plugin
```

#### AUTO 


```{c}
const auto items = lister.items();
```

#### RANGE FOR STATEMENT 


```{c}
for (const KHttpCookie &cookie : std::as_const(allCookies)) {
            cookieStr = cookieStr + cookie.cookieStr(useDOMFormat) + QStringLiteral("; ");
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (KIO::DropMenu *menu : qAsConst(d->m_menus)) {
        menu->popup(p, atAction);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KCoreDirLister *kdl : listers) {
            kdl->d->jobDone(job);

            //don't bother the user
            //kdl->handleError( job );

            const bool silent = job->property("_kdlc_silent").toBool();
            if (!silent) {
                Q_EMIT kdl->canceled(jobUrl);
            }
            if (kdl->d->numJobs() == 0) {
                kdl->d->complete = true;
                if (!silent) {
                    Q_EMIT kdl->canceled();
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (KIO::DropMenu *menu : std::as_const(d->m_menus)) {
        menu->addExtraActions(d->m_appActions, d->m_pluginActions);
    }
```

#### AUTO 


```{c}
auto err = execWithElevatedPrivilege(RENAME, dest, dest_orig)
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            _k_slotFillTemplates();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &itemPath : std::as_const(dirsToDelete)) {
        // qDebug() << "QDir::rmdir" << itemPath;
        if (!dir.rmdir(itemPath)) {
            if (auto err = execWithElevatedPrivilege(RMDIR, {itemPath}, errno)) {
                if (!err.wasCanceled()) {
                    error(KIO::ERR_CANNOT_DELETE, itemPath);
                }
                return false;
            }
        }
    }
```

#### AUTO 


```{c}
auto bookmarks = reader.elementsByTagName("bookmark");
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &u : qAsConst(info.digestURIs)) {
            send &= (m_resource.scheme().toLower() == u.scheme().toLower());
            send &= (m_resource.host().toLower() == u.host().toLower());

            if (m_resource.port() > 0 && u.port() > 0) {
                send &= (m_resource.port() == u.port());
            }

            QString digestPath = u.adjusted(QUrl::RemoveFilename).path();
            if (digestPath.isEmpty()) {
                digestPath = QLatin1Char('/');
            }

            send &= (requestPath.startsWith(digestPath));

            if (send) {
                break;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->zoomOutIconsSize(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &deletedUrl : std::as_const(affectedItems)) {
        // stop all jobs for deletedUrlStr
        DirectoryDataHash::iterator dit = directoryData.find(deletedUrl);
        if (dit != directoryData.end()) {
            // we need a copy because stop modifies the list
            const QList<KCoreDirLister *> listers = (*dit).listersCurrentlyListing;
            for (KCoreDirLister *kdl : listers) {
                stopListingUrl(kdl, deletedUrl);
            }
            // tell listers holding deletedUrl to forget about it
            // this will stop running updates for deletedUrl as well

            // we need a copy because forgetDirs modifies the list
            const QList<KCoreDirLister *> holders = (*dit).listersCurrentlyHolding;
            for (KCoreDirLister *kdl : holders) {
                // lister's root is the deleted item
                if (kdl->d->url == deletedUrl) {
                    // tell the view first. It might need the subdirs' items (which forgetDirs will delete)
                    if (!kdl->d->rootFileItem.isNull()) {
                        Q_EMIT kdl->itemsDeleted(KFileItemList{kdl->d->rootFileItem});
                    }
                    forgetDirs(kdl);
                    kdl->d->rootFileItem = KFileItem();
                } else {
                    const bool treeview = kdl->d->lstDirs.count() > 1;
                    if (!treeview) {
                        Q_EMIT kdl->clear();
                        kdl->d->lstDirs.clear();
                    } else {
                        kdl->d->lstDirs.removeAll(deletedUrl);
                    }

                    forgetDirs(kdl, deletedUrl, treeview);
                }
            }
        }

        // delete the entry for deletedUrl - should not be needed, it's in
        // items cached now
        int count = itemsInUse.remove(deletedUrl);
        Q_ASSERT(count == 0);
        Q_UNUSED(count); // keep gcc "unused variable" complaining quiet when in release mode
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QModelIndex &index) {
            d->slotViewDoubleClicked(index);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KIO::filesize_t dataWritten) {
        slotWritten(dataWritten);
    }
```

#### AUTO 


```{c}
const auto mountPoints = KMountPoint::currentMountPoints();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &dir : std::as_const(m_parentDirs)) {
        KDirWatch::self()->stopDirScan(dir);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[prefKey](const KPluginMetaData &a, const KPluginMetaData &b) {
        return a.rawData().value(prefKey).toInt() > b.rawData().value(prefKey).toInt();
    }
```

#### AUTO 


```{c}
const auto plugins = KIO::PreviewJobPrivate::loadAvailablePlugins();
```

#### CONST EXPRESSION 


```{c}
static constexpr int KIO_MAX_SEND_BATCH_TIME = 300;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &filter : list) {
        d->settings.lstFilters.append(QRegExp(filter, Qt::CaseInsensitive, QRegExp::Wildcard));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](Solid::ErrorType error, QVariant errorData) {
            d->_k_storageTeardownDone(error, errorData);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &protocol : protocols) {
        // Check that hasSchemeHandler will return true
        QVERIFY(!KProtocolInfo::isKnownProtocol(protocol));
        QVERIFY(!KProtocolInfo::isHelperProtocol(protocol));
        QVERIFY(KApplicationTrader::preferredService(QLatin1String("x-scheme-handler/") + protocol));

        const QList<QUrl> urls({QUrl(QStringLiteral("%1://root@10.1.1.1").arg(protocol))});
        KIO::DesktopExecParser parser(*service, urls);
        QCOMPARE(KShell::joinArgs(parser.resultingArguments()),
                 QStringLiteral("%1 %2://root@10.1.1.1").arg(KShell::quoteArg(ktelnetExec), protocol));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool enable) { d->toggleInlinePreviews(enable); }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        m_errorPage = true;
    }
```

#### AUTO 


```{c}
const auto exitCodeOrSignalNumber = properties[QStringLiteral("ExecMainStatus")].value<qint32>();
```

#### AUTO 


```{c}
auto *job = new KIO::OpenFileManagerWindowJob();
```

#### AUTO 


```{c}
auto job = KIO::copy({ QUrl::fromLocalFile(QFINDTESTDATA("ftp/testCopy1")) }, inaccessibleUrl, KIO::Resume);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : qAsConst(d->urls)) {
            if (!isProtocolInSupportedList(url, appSupportedProtocols) && !hasSchemeHandler(url)) {
                useKioexec = true;
                //qCDebug(KIO_CORE) << "application does not support url, using kioexec:" << url;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &name : filenames) {
            if (!names_found.contains(name) && createEntry(entry, dirpath, name)) {
                list.append(entry);
                names_found.append(name);
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { slotOpen(); }
```

#### AUTO 


```{c}
auto *job = new KTerminalLauncherJob(command);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : dir.entryList({QStringLiteral("*.desktop")}, QDir::Files)) {
            if (!m_searchProvidersByDesktopName.contains(file)) {
                const QString filePath = dir.path() + QLatin1Char('/') + file;
                auto *provider = new SearchProvider(filePath);
                m_searchProvidersByDesktopName.insert(file, provider);
                m_searchProviders.append(provider);
                for (const QString &key : provider->keys()) {
                    m_searchProvidersByKey.insert(key, provider);
                }
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[urls]() {
                // The action may update the desktop file. Example: eject unmounts (#5129).
                org::kde::KDirNotify::emitFilesChanged(urls);
                }
```

#### AUTO 


```{c}
auto it = protocols.begin();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->slotSimpleView(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &dir : dirs) {
        if (dir == itemParentDir || dir.path().isEmpty()) {
            isOldPreview = false;
            break;
        }
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr int s_lateralMargin = 4;
```

#### LAMBDA EXPRESSION 


```{c}
[&path](const FileInfo &i) { return (i.path == path); }
```

#### AUTO 


```{c}
const auto &dir
```

#### AUTO 


```{c}
auto err = tryOpen(f, QFile::encodeName(dest), oflags, filemode)
```

#### AUTO 


```{c}
const auto connectionResult = synchronousConnectToHost(host, static_cast<quint16>(portnum));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QChar ch : text) {
        if (escaped) {
            escaped = false;
            result.insert(result.length(), ch);
        } else if (in_quote && ch == p_last_quote_char) {
            in_quote = false;
        } else if (!in_quote && ch == m_quote_char1) {
            p_last_quote_char = m_quote_char1;
            in_quote = true;
        } else if (!in_quote && ch == m_quote_char2) {
            p_last_quote_char = m_quote_char2;
            in_quote = true;
        } else if (ch == m_escape_char) {
            escaped = true;
            result.insert(result.length(), ch);
        } else {
            result.insert(result.length(), ch);
        }
    }
```

#### AUTO 


```{c}
auto err = execWithElevatedPrivilege(DEL, _dest)
```

#### RANGE FOR STATEMENT 


```{c}
for (const QRegExp &filter : filters) {
        if (filter.exactMatch(name)) {
            return true;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->slotToggleDirsFirst();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] { scanFileWithGet(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { disconnected(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job, qulonglong _speed) { slotSpeed(job, _speed); }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        slotStatResult();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        Q_EMIT result(true);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[currValue](KIconLoader::StdSizes size) { return size > currValue; }
```

#### LAMBDA EXPRESSION 


```{c}
[&index](AnimationState *state) {
            return state->index == index;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&buff, &path](const KMountPoint::Ptr &mountPtr) {
            // For a bind mount, the deviceId() is that of the base mount point, e.g. /mnt/foo,
            // however the path we're looking for, e.g. /home/user/bar, doesn't start with the
            // mount point of the base device, so we go on searching
            return mountPtr->deviceId() == buff.st_dev && path.startsWith(mountPtr->mountPoint());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &mimeType : servicesTypes) {
        if (mimeType.startsWith(QLatin1String("x-scheme-handler/"))) {
            supportedProtocols << mimeType.mid(17);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QModelIndex &index) {
        if (qGuiApp->keyboardModifiers() == Qt::ShiftModifier && isSignalConnected(QMetaMethod::fromSignal(&KFilePlacesView::activeTabRequested))) {
            d->placeClicked(index, &KFilePlacesView::activeTabRequested);
        } else if (isSignalConnected(QMetaMethod::fromSignal(&KFilePlacesView::tabRequested))) {
            d->placeClicked(index, &KFilePlacesView::tabRequested);
        } else {
            d->placeClicked(index, &KFilePlacesView::placeActivated);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QString &lang : langs) {
        if (lang == QLatin1String("en_US")) {
            lang = QStringLiteral("en");
        }
    }
```

#### AUTO 


```{c}
auto err = tryOpen(src_file, _src, O_RDONLY, S_IRUSR)
```

#### RANGE FOR STATEMENT 


```{c}
for (const QSslCipher &c : list) {
            allCiphers.insert(c.name(), c);
        }
```

#### AUTO 


```{c}
auto *mime = const_cast<QMimeData *>(event->mimeData());
```

#### AUTO 


```{c}
const auto &supportedSchemes = d->m_model->supportedSchemes();
```

#### AUTO 


```{c}
auto isBasicOperation = [this](const BasicOperation &op) {
        return (op.m_type == BasicOperation::Directory && !op.m_renamed)
                || (op.m_type == BasicOperation::Link && !d->m_current.isMoveCommand());
    };
```

#### LAMBDA EXPRESSION 


```{c}
[udsField](const Field &entry) {
                                  return entry.m_index == udsField;
                              }
```

#### AUTO 


```{c}
auto it = std::find_if(m_stdIconSizes.cbegin(), itEnd,
                 [currValue](KIconLoader::StdSizes size) { return size > currValue; });
```

#### LAMBDA EXPRESSION 


```{c}
[currValue](KIconLoader::StdSizes size) {
        return size < currValue;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &item : qAsConst(orderedItems)) {
        m_pendingItems.append(item);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &httpHeader : httpHeaders) {
            int index = httpHeader.indexOf(QL1C(':'));
            // Handle HTTP status line...
            if (index == -1) {
                // Except for the status line, all HTTP header must be an nvpair of
                // type "<name>:<value>"
                if (!httpHeader.startsWith(QLatin1String("HTTP/"), Qt::CaseInsensitive)) {
                    continue;
                }

                QStringList statusLineAttrs(httpHeader.split(QL1C(' '), Qt::SkipEmptyParts));
                if (statusLineAttrs.count() > 1) {
                    setAttribute(QNetworkRequest::HttpStatusCodeAttribute, statusLineAttrs.at(1));
                }

                if (statusLineAttrs.count() > 2) {
                    setAttribute(QNetworkRequest::HttpReasonPhraseAttribute, statusLineAttrs.at(2));
                }

                continue;
            }

            const QStringRef headerName = httpHeader.leftRef(index);
            QString headerValue = httpHeader.mid(index + 1);

            // Ignore cookie header since it is handled by the http ioslave.
            if (headerName.startsWith(QLatin1String("set-cookie"), Qt::CaseInsensitive)) {
                continue;
            }

            if (headerName.startsWith(QLatin1String("content-disposition"), Qt::CaseInsensitive) &&
                    ignoreContentDisposition(metaData)) {
                continue;
            }

            // Without overriding the corrected mime-type sent by kio_http, add
            // back the "charset=" portion of the content-type header if present.
            if (headerName.startsWith(QLatin1String("content-type"), Qt::CaseInsensitive)) {

                QString mimeType(header(QNetworkRequest::ContentTypeHeader).toString());

                if (m_ignoreContentDisposition) {
                    // If the server returned application/octet-stream, try to determine the
                    // real content type from the disposition filename.
                    if (mimeType == QLatin1String("application/octet-stream")) {
                        const QString fileName(metaData.value(QStringLiteral("content-disposition-filename")));
                        QMimeDatabase db;
                        QMimeType mime = db.mimeTypeForFile((fileName.isEmpty() ? url().path() : fileName), QMimeDatabase::MatchExtension);
                        mimeType = mime.name();
                    }
                    metaData.remove(QStringLiteral("content-disposition-type"));
                    metaData.remove(QStringLiteral("content-disposition-filename"));
                }

                if (!headerValue.contains(mimeType, Qt::CaseInsensitive)) {
                    index = headerValue.indexOf(QL1C(';'));
                    if (index == -1) {
                        headerValue = mimeType;
                    } else {
                        headerValue.replace(0, index, mimeType);
                    }
                    //qDebug() << "Changed mime-type from" << mimeType << "to" << headerValue;
                }
            }
            setRawHeader(headerName.trimmed().toUtf8(), headerValue.trimmed().toUtf8());
        }
```

#### AUTO 


```{c}
const auto actions = plugin->setup(itemProps, m_destUrl);
```

#### CONST EXPRESSION 


```{c}
static constexpr double s_mPI2 = 1.57079632679489661923;
```

#### AUTO 


```{c}
auto listDir = [this](const QModelIndex &index) {
        QSignalSpy completedSpy(m_dirModel->dirLister(), qOverload<>(&KDirLister::completed));
        m_dirModel->fetchMore(index);
        return completedSpy.wait();
    };
```

#### AUTO 


```{c}
auto it = std::find_if(this->cbegin(), this->cend(), [&buff, &realPath](const KMountPoint::Ptr &mountPtr) {
            // For a bind mount, the deviceId() is that of the base mount point, e.g. /mnt/foo,
            // however the path we're looking for, e.g. /home/user/bar, doesn't start with the
            // mount point of the base device, so we go on searching
            return mountPtr->deviceId() == buff.st_dev && realPath.startsWith(mountPtr->mountPoint());
        });
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            d->_k_slotFileDialogAccepted();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool visible) {
        togglePlacesPanel(visible, m_placesDock);
    }
```

#### AUTO 


```{c}
const auto &opQueue = d->m_current.m_opQueue;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &path : templates) {
        dir.setPath(path);
        const QStringList &entryList(dir.entryList(QStringList() << QStringLiteral("*.desktop"), QDir::Files));
        files.reserve(files.size() + entryList.size());
        Q_FOREACH (const QString &entry, entryList) {
            const QString file = concatPaths(dir.path(), entry);
            files.append(file);
        }
    }
```

#### AUTO 


```{c}
const auto destination = op.m_dst;
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &path) {
            Q_D(KSambaShare);
            d->_k_slotFileChange(path);
        }
```

#### AUTO 


```{c}
auto mimeType = db.mimeTypeForName(commonMimeType);
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        if (job->error()) {
            app.exit(1);
        } else {
            qDebug() << "Started";
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job, qulonglong totalSize) {
            slotTotalSize(job, totalSize);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { openPathSelectorMenu(); }
```

#### AUTO 


```{c}
const auto filtersList = QStringList{ QStringLiteral("kshorturifilter") };
```

#### RANGE FOR STATEMENT 


```{c}
for (const QSslError &e : qsslErrors) {
        ret.append(KSslError(e));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : urls) {
        QUrl newUrl = url;
        newUrl.setPath(url.path() + QLatin1String("_renamed"));
        KIO::SimpleJob *job = KIO::rename(url, newUrl, KIO::HideProgressInfo);
        QVERIFY(job->exec());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &key : keysChanged) {
        AuthInfoContainerList *authList = m_authDict.value(key);
        if (!authList) {
            continue;
        }

        QMutableVectorIterator<AuthInfoContainer> it(*authList);
        while (it.hasNext()) {
            AuthInfoContainer &current = it.next();
            if (current.expire == AuthInfoContainer::expWindowClose) {
                if (current.windowList.removeAll(windowId) && current.windowList.isEmpty()) {
                    it.remove();
                }
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SubnetPair &subnet : std::as_const(noProxySubnets)) {
                if (address.isInSubnet(subnet)) {
                    isMatch = true;
                    break;
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        changeIconsSize(ZoomIn);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QPoint pos) {
        d->openContextMenu(pos);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, iconSize]() {
            q->setIconSize(QSize(iconSize, iconSize));
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=](const int buttonCode) {
        const bool isDelete = buttonCode == QDialogButtonBox::Yes;

        emit askUserDeleteResult(isDelete, urls, deletionType, parent);

        if (isDelete) {
            KConfigGroup cg = kioConfig->group("Confirmations");
            cg.writeEntry(keyName, !dlg->isDontAskAgainChecked());
            cg.sync();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KSslCipher &c : ciphers) {
        cl.append(d->ccc.converted(c));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            _k_slotOtherDesktopFile();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &filter : list) {
        d->settings.lstFilters.append(QRegularExpression(QRegularExpression::wildcardToRegularExpression(filter), QRegularExpression::CaseInsensitiveOption));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](SkipDialog_Result result, KJob *parentJob) {
                Q_ASSERT(parentJob == q);
                // Only receive askUserRenameResult once per rename dialog
                QObject::disconnect(askUserActionInterface, &KIO::AskUserActionInterface::askUserRenameResult,
                                    q, nullptr);
                processFileRenameDialogResult(it, result, QUrl() /* no new url in skip */, QDateTime{});
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : files) {
        const KDesktopFile desktopFile(file);
        const KConfigGroup cfg = desktopFile.desktopGroup();

        if (!shouldDisplayServiceMenu(cfg, protocol)) {
            continue;
        }

        if (cfg.hasKey("Actions") || cfg.hasKey("X-KDE-GetActionMenu")) {
            if (!checkTypesMatch(cfg)) {
                continue;
            }

            const QString priority = cfg.readEntry("X-KDE-Priority");
            const QString submenuName = cfg.readEntry("X-KDE-Submenu");

            ServiceList &list = s.selectList(priority, submenuName);
            const ServiceList userServices = KDesktopFileActions::userDefinedServices(file, desktopFile, isLocal, urlList);
            for (const KServiceAction &action : userServices) {
                if (showGroup.readEntry(action.name(), true) && !excludeList.contains(action.name())) {
                    list += action;
                }
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const KFileItem &item) {
        return isItemVisible(item) || q->matchesMimeFilter(item);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->slotIOFinished();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : qAsConst(files)) {
        //qDebug() << file;
        if (file[0] != QLatin1Char('.')) {
            KNewFileMenuSingleton::Entry e;
            e.filePath = file;
            e.entryType = KNewFileMenuSingleton::Unknown; // not parsed yet

            // Put Directory first in the list (a bit hacky),
            // and TextFile before others because it's the most used one.
            // This also sorts by user-visible name.
            // The rest of the re-ordering is done in fillMenu.
            const KDesktopFile config(file);
            QString url = config.desktopGroup().readEntry("URL");
            QString key = config.desktopGroup().readEntry("Name");
            if (file.endsWith(QLatin1String("Directory.desktop"))) {
                key.prepend(QLatin1Char('0'));
            } else if (file.startsWith(QDir::homePath())) {
                key.prepend(QLatin1Char('1'));
            } else if (file.endsWith(QLatin1String("TextFile.desktop"))) {
                key.prepend(QLatin1Char('2'));
            } else {
                key.prepend(QLatin1Char('3'));
            }
            EntryWithName en = { key, e };
            if (ulist.contains(url)) {
                ulist.remove(url);
            }
            ulist.insert(url, en);
        }
    }
```

#### AUTO 


```{c}
auto findDir = [this](const QModelIndex &parentIndex, const QString &name) {
        for (int row = 0; row < m_dirModel->rowCount(parentIndex); ++row) {
            QModelIndex idx = m_dirModel->index(row, 0, parentIndex);
            if (m_dirModel->itemForIndex(idx).isDir() && m_dirModel->itemForIndex(idx).name() == name) {
                return idx;
            }
        }
        return QModelIndex();
    };
```

#### AUTO 


```{c}
auto [it, inserted] = pluginIds.insert(info.pluginName());
```

#### LAMBDA EXPRESSION 


```{c}
[&thumbRootMount](KMountPoint::Ptr mount) {
        return (thumbRootMount != mount) && (mount->mountType() == QLatin1String("fuse.cryfs") || mount->mountType() == QLatin1String("fuse.encfs"));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->slotSortBySize(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this, timeLine]() {
        capacityBarFadeValueChanged(timeLine);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &domainName : std::as_const(m_domainList)) {
        bool domainPrinted = false;

        KHttpCookieList *cookieList = m_cookieDomains.value(domainName);
        if (!cookieList) {
            continue;
        }

        QMutableListIterator<KHttpCookie> cookieIterator(*cookieList);
        while (cookieIterator.hasNext()) {
            const KHttpCookie &cookie = cookieIterator.next();

            if (cookie.isExpired()) {
                // Delete expired cookies
                cookieIterator.remove();
                continue;
            }
            if (cookieIsPersistent(cookie)) {
                // Only save cookies that are not "session-only cookies"
                if (!domainPrinted) {
                    domainPrinted = true;
                    ts << '[' << domainName.toLocal8Bit().data() << "]\n";
                }
                // Store persistent cookies
                const QString path = QLatin1Char('"') + cookie.path() + QLatin1Char('"');
                const QString domain = QLatin1Char('"') + cookie.domain() + QLatin1Char('"');
                const QString host = hostWithPort(&cookie);

                // TODO: replace with direct QTextStream output ?
                const QString str = QString::asprintf("%-20s %-20s %-12s %10lld  %3d %-20s %-4i %s\n",
                                                      host.toLatin1().constData(),
                                                      domain.toLatin1().constData(),
                                                      path.toLatin1().constData(),
                                                      cookie.expireDate(),
                                                      cookie.protocolVersion(),
                                                      cookie.name().isEmpty() ? cookie.value().toLatin1().constData() : cookie.name().toLatin1().constData(),
                                                      (cookie.isSecure() ? 1 : 0) + (cookie.isHttpOnly() ? 2 : 0) + (cookie.hasExplicitPath() ? 4 : 0)
                                                          + (cookie.name().isEmpty() ? 8 : 0),
                                                      cookie.value().toLatin1().constData());
                ts << str.toLatin1();
            }
        }
    }
```

#### AUTO 


```{c}
const auto srcUrls = copyJob->srcUrls();
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QModelIndex &index) {
        d->placeClicked(index);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &lang : std::as_const(languageListFinal)) {
        header += lang;
        if (prio < 10) {
            header += QLatin1String(";q=0.") + QString::number(prio);
        }
        // do not add cosmetic whitespace in here : it is less compatible (#220677)
        header += QLatin1Char(',');
        if (prio > 1) {
            --prio;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KCModule *module : std::as_const(modules)) {
        module->defaults();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &md : plugins) {
        // get slave name & protocols it supports, if any
        const QString slavePath = md.fileName();
        const QJsonObject protocols(md.rawData().value(QStringLiteral("KDE-KIO-Protocols")).toObject());
        qCDebug(KIO_CORE) << slavePath << "supports protocols" << protocols.keys();

        // add all protocols, does nothing if object invalid
        for (auto it = protocols.begin(); it != protocols.end(); ++it) {
            // skip empty objects
            const QJsonObject protocol(it.value().toObject());
            if (protocol.isEmpty()) {
                continue;
            }

            // add to cache, skip double entries
            if (!m_cache.contains(it.key())) {
                m_cache.insert(it.key(), new KProtocolInfoPrivate(it.key(), slavePath, protocol));
            }
        }
    }
```

#### AUTO 


```{c}
auto it = runningListJobs.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &encoding : encodings) {
        bool found = false;
        QTextCodec *codecForEnc = KCharsets::charsets()->codecForName(encoding, found);

        if (found) {
            d->encoding->addItem(encoding);
            if ((codecForEnc->name() == sEncoding) || (encoding == sEncoding)) {
                d->encoding->setCurrentIndex(insert);
                foundRequested = true;
            }

            if ((codecForEnc->name() == systemEncoding) || (encoding == systemEncoding)) {
                system = insert;
            }
            insert++;
        }
    }
```

#### AUTO 


```{c}
const auto result = ftpPut(-1, url, permissions, flags);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &protocol : std::as_const(protocols)) {
            // We cannot use mimeTypes() here, it doesn't support groups such as: text/*
            const QStringList mtypes = (*it)->serviceTypes();
            // Add supported MIME type for this protocol
            QStringList &_ms = m_remoteProtocolPlugins[protocol];
            for (const QString &_m : mtypes) {
                if (_m != QLatin1String("ThumbCreator")) {
                    protocolMap[protocol].insert(_m, *it);
                    if (!_ms.contains(_m)) {
                        _ms.append(_m);
                    }
                }
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &protocol) { slotProtocolChanged(protocol); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &item : items) {
        addNewItem(directoryUrl, item);
    }
```

#### AUTO 


```{c}
auto pidWatcher = new QDBusPendingCallWatcher(call, this);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        slotFilterChanged();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
            if (job->error()) {
                q->setError(KIO::ERR_CANNOT_LAUNCH_PROCESS);
                q->setErrorText(destFile);
            }
            q->emitResult();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KIO::Job *job) {
        d->m_messageWidget->setText(job->errorString());
        d->m_messageWidget->animatedShow();
    }
```

#### AUTO 


```{c}
auto plugin
```

#### AUTO 


```{c}
auto job = KIO::copy(QUrl::fromLocalFile(path), dest);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QHostAddress &address : addresses) {
            if (isIPv4Address(address) && !isSpecialAddress(address) && !isLocalHostAddress(address)) {
                ipAddress = address.toString();
                break;
            }
        }
```

#### AUTO 


```{c}
auto it = std::find_if(this->cbegin(), this->cend(), [&buff, &path](const KMountPoint::Ptr &mountPtr) {
            // For a bind mount, the deviceId() is that of the base mount point, e.g. /mnt/foo,
            // however the path we're looking for, e.g. /home/user/bar, doesn't start with the
            // mount point of the base device, so we go on searching
            return mountPtr->deviceId() == buff.st_dev && path.startsWith(mountPtr->mountPoint());
        });
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &item : fileItems) {
            if (item.mimetype() == mimeType) {
                mimeItems << item;
            }
        }
```

#### AUTO 


```{c}
auto job = KIO::copy(url, dir_url, KIO::DefaultFlags);
```

#### LAMBDA EXPRESSION 


```{c}
[&mit](const std::unique_ptr<const KUrlComboBoxPrivate::KUrlComboItem>& item) {
                return item.get() == mit.value();
            }
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QUrl &doc1, const QUrl &doc2) {
        return documents.value(doc1) < documents.value(doc2);
    }
```

#### AUTO 


```{c}
auto it = std::find_if(list->cbegin(), list->cend(), [&index](AnimationState *state) {
            return state->index == index;
        });
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob* job, qulonglong size) { _k_slotProcessedSize(job, size); }
```

#### AUTO 


```{c}
const auto pos = putDataBuffer.pos();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &key : keys) {
        if (key.length() > name.length()) {
            name = key.toLower();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &mimeType : mimeTypeList) {
        KFileItemList mimeItems;
        for (const KFileItem &item : fileItems) {
            if (item.mimetype() == mimeType) {
                mimeItems << item;
            }
        }
        // Show Open With dialog
        auto *job = new KIO::ApplicationLauncherJob();
        job->setUrls(mimeItems.urlList());
        job->setUiDelegate(new KIO::JobUiDelegate(KJobUiDelegate::AutoHandlingEnabled, m_parentWidget));
        job->start();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &dirUrl : qAsConst(dirsToUpdate)) {
        updateDirectory(dirUrl);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &jsonMetadata : jsonPlugins) {
        // The plugin has been disabled
        if (!showGroup.readEntry(jsonMetadata.pluginId(), true)) {
            continue;
        }

        // The plugin also has a .desktop file and has already been added.
        if (addedPlugins.contains(jsonMetadata.pluginId())) {
            continue;
        }

        KPluginFactory *factory = KPluginLoader(jsonMetadata.fileName()).factory();
        if (!factory) {
            continue;
        }
        auto *abstractPlugin = factory->create<KAbstractFileItemActionPlugin>();
        if (abstractPlugin) {
            abstractPlugin->setParent(this);
            auto actions = abstractPlugin->actions(d->m_props, d->m_parentWidget);
            itemCount += actions.count();
            mainMenu->addActions(actions);
            addedPlugins.append(jsonMetadata.pluginId());
        }
    }
```

#### AUTO 


```{c}
auto items = lister.items();
```

#### AUTO 


```{c}
auto &match
```

#### AUTO 


```{c}
const auto [it, isInserted] = pendingDirectoryUpdates.insert(dir);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : std::as_const(lister->d->lstDirs)) {
        DirItem *dirItem = itemsInUse.value(url);
        Q_ASSERT(dirItem);
        if (enable) {
            dirItem->incAutoUpdate();
        } else {
            dirItem->decAutoUpdate();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QUrl &url) {
        d->enterUrl(url);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &text) { _k_slotTextChanged(text); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : urls) {
            // TODO: use KIO::stat in order to get the UDS_DISPLAY_NAME too
            KIO::MimetypeJob *job = KIO::mimetype(url);

            QString mimeString;
            if (!job->exec()) {
                mimeString = QStringLiteral("unknown");
            } else {
                mimeString = job->mimetype();
            }

            QMimeType mimetype = db.mimeTypeForName(mimeString);

            if (!mimetype.isValid()) {
                qWarning() << "URL not added to Places as MIME type could not be determined!";
                continue;
            }

            if (!mimetype.inherits(QStringLiteral("inode/directory"))) {
                // Only directories are allowed
                continue;
            }

            KFileItem item(url, mimetype.name(), S_IFDIR);

            KBookmark bookmark = KFilePlacesItem::createBookmark(d->bookmarkManager, url.fileName(), url, item.iconName());
            group.moveBookmark(bookmark, afterBookmark);
            afterBookmark = bookmark;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (KCoreDirLister *kdl : qAsConst(listers)) {
        // For a directory, look for dirlisters where it's the root item.
        QUrl directoryUrl(oldItem.url());
        if (oldItem.isDir() && kdl->d->rootFileItem == oldItem) {
            const KFileItem oldRootItem = kdl->d->rootFileItem;
            kdl->d->rootFileItem = fileitem;
            kdl->d->addRefreshItem(directoryUrl, oldRootItem, fileitem);
        } else {
            directoryUrl = directoryUrl.adjusted(QUrl::RemoveFilename | QUrl::StripTrailingSlash);
            kdl->d->addRefreshItem(directoryUrl, oldItem, fileitem);
        }
        listersToRefresh.insert(kdl);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &item : items) {
                    const QString name = item.name();

                    if (!tags.contains(name)) {
                        tags.append(name);
                    }
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->_k_slotFinished(); }
```

#### AUTO 


```{c}
auto xbelFile = QFile(m_xbelPath);
```

#### RANGE FOR STATEMENT 


```{c}
for (KJob *job : qAsConst(m_previewJobs)) {
        Q_ASSERT(job != nullptr);
        job->suspend();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KIO::Job *job, QByteArray &data) {
        d_func()->slotStoredDataReq(job, data);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto plugin : m_plugins->text().split(";"))
        enabledPlugins << plugin.trimmed();
```

#### RANGE FOR STATEMENT 


```{c}
for (const URLHint &hint : qAsConst(m_urlHints)) {
            qCDebug(category) << "testing regexp for" << hint.prepend;
            if (hint.hintRe.match(cmd).capturedStart() == 0) {
                const QString cmdStr = hint.prepend + cmd;
                QUrl url(cmdStr);
                qCDebug(category) << "match - prepending" << hint.prepend << "->" << cmdStr << "->" << url;
                setFilteredUri(data, url);
                setUriType(data, hint.type);
                return true;
            }
        }
```

#### AUTO 


```{c}
auto isBasicOperation = [this](const BasicOperation &op) {
        return (op.m_type == BasicOperation::Directory && !op.m_renamed)
                || (op.m_type == BasicOperation::Link && !m_current.isMoveCommand());
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this, launchedSerial](int tokenSerial, const QString &token) {
                            if (tokenSerial == launchedSerial) {
                                m_process->setEnv(QStringLiteral("XDG_ACTIVATION_TOKEN"), token);
                                Q_EMIT xdgActivationTokenArrived();
                            }
                        }
```

#### AUTO 


```{c}
auto partialLayout = new QFormLayout;
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QUrl &, const QUrl &newUrl) {
        slotOpenUrlOnRename(newUrl);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &filter : list) {
        d->settings.lstFilters.append(QRegularExpression(unanchoredPattern(filter), QRegularExpression::CaseInsensitiveOption));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const char *str : DefaultSambaConfigFilePathList) {
        const QString filePath = QString::fromLatin1(str);
        if (QFile::exists(filePath)) {
            smbConf = filePath;
            return true;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &jsonMetadata : jsonPlugins) {
        KPluginFactory *factory = KPluginLoader(jsonMetadata.fileName()).factory();
        if (!factory) {
            continue;
        }
        KPropertiesDialogPlugin *plugin = factory->create<KPropertiesDialogPlugin>(q);
        if (plugin) {
            q->insertPlugin(plugin);
            addedPlugins.append(jsonMetadata.pluginId());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (SearchProvider *provider : providers) {
        if (!provider->isDirty()) {
            continue;
        }

        changedProviderCount++;

        KConfig _service(path + provider->desktopEntryName() + QLatin1String(".desktop"), KConfig::SimpleConfig);
        KConfigGroup service(&_service, "Desktop Entry");
        service.writeEntry("Type", "Service");
        service.writeEntry("X-KDE-ServiceTypes", "SearchProvider");
        service.writeEntry("Name", provider->name());
        service.writeEntry("Query", provider->query());
        service.writeEntry("Keys", provider->keys());
        service.writeEntry("Charset", provider->charset());
        service.writeEntry("Hidden", false); // we might be overwriting a hidden entry
    }
```

#### AUTO 


```{c}
auto useIfAvailable = [&exec](const QString &terminalApp) {
            const bool found = !QStandardPaths::findExecutable(terminalApp).isEmpty();
            if (found) {
                exec = terminalApp;
            }
            return found;
        };
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &key : list) {
        const QByteArray value = request.rawHeader(key);
        if (value.length()) {
            customHeaders << (QString::fromUtf8(key) + QLatin1String(": ") + QString::fromUtf8(value));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : urlList) {
            urls += QStringLiteral("\"%1\" ").arg(escapeDoubleQuotes(relativePathOrUrl(currUrl, url)));
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QModelIndex &index) {
        d->_k_placeLeft(index);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->zoomInIconsSize(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KIO::Job *job, const QByteArray &data) {
            slotData(job, data);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->slotSortByName(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *widget : widgetsList) {
            QDialog* dialog = qobject_cast<QDialog*>(widget);
            if (dialog && !dialog->inherits("KPasswordDialog")) {
                dialog->done(code);
                return;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (KCoreDirLister *kdl : listers) {
            kdl->d->jobDone(job);

            // don't bother the user: no jobError signal emitted

            const bool silent = job->property("_kdlc_silent").toBool();
            if (!silent) {
#if KIOCORE_BUILD_DEPRECATED_SINCE(5, 79)
                Q_EMIT kdl->canceled(jobUrl);
#endif
                Q_EMIT kdl->listingDirCanceled(jobUrl);
            }
            if (kdl->d->numJobs() == 0) {
                kdl->d->complete = true;
                if (!silent) {
                    Q_EMIT kdl->canceled();
                }
            }
        }
```

#### CONST EXPRESSION 


```{c}
static constexpr int s_maxIPCSize = 1024 * 32;
```

#### AUTO 


```{c}
const auto startReply = m_manager->StartTransientUnit(m_serviceName,
        QStringLiteral("fail"), // mode defines what to do in the case of a name conflict, in this case, just do nothing
        { // Properties of the transient service unit
            { QStringLiteral("Type"), QStringLiteral("oneshot") },
            { QStringLiteral("Slice"), QStringLiteral("app.slice") },
            { QStringLiteral("Description"), m_description },
            { QStringLiteral("SourcePath"), m_desktopFilePath },
            { QStringLiteral("AddRef"), true }, // Asks systemd to avoid garbage collecting the service if it immediately crashes,
                                                // so we can be notified (see https://github.com/systemd/systemd/pull/3984)
            { QStringLiteral("Environment"), m_process->environment() },
            { QStringLiteral("WorkingDirectory"), m_process->workingDirectory() },
            { QStringLiteral("ExecStart"), QVariant::fromValue(ExecCommandList { { m_process->program().first(), m_process->program(), false } }) },
            { QStringLiteral("KillMode"), QStringLiteral("process")}
        },
        {} // aux is currently unused and should be passed as empty array.
    );
```

#### RANGE FOR STATEMENT 


```{c}
for (KDirModelNode *node : dirNode->m_childNodes) {
            node->setPreview(QIcon());
            //node->setPreview(QIcon::fromTheme(node->item().iconName()));
            if (isDir(node)) {
                // recurse into child dirs
                clearAllPreviews(static_cast<KDirModelDirNode *>(node));
            }
            lastNode = node;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QSslCertificate &cert : qAsConst(ud->certificateChain)) {
                QList<KSslError::Error> errors;
                for (const KSslError &error : qAsConst(ud->sslErrors)) {
                    if (error.certificate() == cert) {
                        // we keep only the error code enum here
                        errors.append(error.error());
                    }
                }
                meh.append(errors);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QPoint pos) { d->openContextMenu(pos); }
```

#### LAMBDA EXPRESSION 


```{c}
[this, job, dlg](const int exitCode) {
        KIO::RenameDialog_Result result = static_cast<RenameDialog_Result>(exitCode);
        const QUrl newUrl = result == Result_AutoRename ? dlg->autoDestUrl() : dlg->newDestUrl();
        emit askUserRenameResult(result, newUrl, job);
    }
```

#### LAMBDA EXPRESSION 


```{c}
do {
        return move({"more-files"_hc}, ""_rc);
    }
```

#### AUTO 


```{c}
const auto litend = dirItem->lstItems.constEnd();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QSslError &e : errors) {
            kErrors.append(KSslError(e));
        }
```

#### AUTO 


```{c}
const auto jsonPlugins = KPluginMetaData::findPlugins(QStringLiteral("kf5/kfileitemaction"), [&db, commonMimeType](const KPluginMetaData &metaData) {
        auto mimeType = db.mimeTypeForName(commonMimeType);
        const QStringList list = metaData.mimeTypes();
        return std::any_of(list.constBegin(), list.constEnd(), [mimeType](const QString &supportedMimeType) {
            return mimeType.inherits(supportedMimeType);
        });
    });
```

#### AUTO 


```{c}
auto kit = itemList->begin();
```

#### AUTO 


```{c}
auto it = std::find_if(storage.begin(), storage.end(), [udsField](const Field &entry) {
        return entry.m_index == udsField;
    });
```

#### AUTO 


```{c}
const auto &url
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &p : patterns) {
        rx.setPattern(QRegularExpression::anchoredPattern(
                                        QRegularExpression::wildcardToRegularExpression(p)));
        if (rx.match(filename).hasMatch()) {
            return p;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QPair<int, int> be : it.value().beginEnd) {
            qDebug() << "  " << QByteArray(buffer + be.first, be.second - be.first);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &item : std::as_const(dir->lstItems)) {
        fileItems.insert(item.name(), item);
    }
```

#### AUTO 


```{c}
auto *menu = qobject_cast<QMenu *>(watched)
```

#### AUTO 


```{c}
auto beginIt = m_stdIconSizes.cbegin();
```

#### AUTO 


```{c}
auto it = lstItems.find(url);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->slotSimpleView();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KHttpCookie &cookie : std::as_const(*mPendingCookies)) {
        if (cookie.match(fqdn, domains, path)) {
            if (!cookieList) {
                return true;
            }
            cookieList->append(cookie);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& serviceId : serviceIdList) {
        KFileItemList serviceItems;
        for (const KFileItem &item : fileItems) {
            const KService::Ptr serv = preferredService(item.mimetype(), m_traderConstraint);
            const QString preferredServiceId = serv ? serv->storageId() : QString();
            if (preferredServiceId == serviceId) {
                serviceItems << item;
            }
        }

        if (serviceId.isEmpty()) { // empty means: no associated app for this mimetype
            openWithByMime(serviceItems);
            continue;
        }

        const KService::Ptr servicePtr = KService::serviceByStorageId(serviceId);
        if (!servicePtr) {
            KRun::displayOpenWithDialog(serviceItems.urlList(), m_parentWidget);
            continue;
        }
        KRun::runService(*servicePtr, serviceItems.urlList(), m_parentWidget);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->slotStarted();
    }
```

#### AUTO 


```{c}
const auto it = m_sequenceIndices.constFind(items[0].url());
```

#### LAMBDA EXPRESSION 


```{c}
[&url](const PreviewItem &pItem) {
        return url == pItem.item.url();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto item : qAsConst(items)) {
        QVERIFY(item.isMimeTypeKnown());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[destFileExists, destPartFile](KJob *job, qulonglong totalSize) {
        Q_UNUSED(job);
        Q_UNUSED(totalSize);
        QCOMPARE(destFileExists, QFile::exists(destPartFile));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&origPrivilege]() {
            gainPrivilege(&origPrivilege);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[applyOtherChanges]() {
            applyOtherChanges();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->slotDetailsView(); }
```

#### LAMBDA EXPRESSION 


```{c}
[job]() {
        job->kill();
    }
```

#### AUTO 


```{c}
const auto systemdService = QStringLiteral("org.freedesktop.systemd1");
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &cachedDir : cachedDirs) {
        DirItem *dirItem = itemsCached.object(cachedDir);
        qCDebug(KIO_CORE_DIRLISTER) << "   " << cachedDir
                                    << "rootItem:" << (!dirItem->rootItem.isNull() ? dirItem->rootItem.url().toString() : QStringLiteral("NULL")) << "with"
                                    << dirItem->lstItems.count() << "items.";
    }
```

#### AUTO 


```{c}
auto *job = KIO::statDetails(url, KIO::StatJob::DestinationSide, details, KIO::HideProgressInfo);
```

#### RANGE FOR STATEMENT 


```{c}
for (KCoreDirLister *kdl : listers) {
        kdl->d->addNewItems(url, newItems);
    }
```

#### AUTO 


```{c}
auto *job = new KIO::CommandLauncherJob(executable, {
        srcPath, destName
    }, this);
```

#### IF STATEMENT WITH INITIALIZER 


```{c}
if (const auto tag = QLatin1String("UUID="); m_mountedFrom.startsWith(tag)) {
        potentialDevice = QFile::symLinkTarget(QLatin1String("/dev/disk/by-uuid/") + QStringView(m_mountedFrom).mid(tag.size()));
    } else if (const auto tag = QLatin1String("LABEL="); m_mountedFrom.startsWith(tag)) {
        potentialDevice = QFile::symLinkTarget(QLatin1String("/dev/disk/by-label/") + QStringView(m_mountedFrom).mid(tag.size()));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[base_fd]() {
        if (base_fd != -1) {
            close(base_fd);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QSslError &e : list) {
        qCDebug(KIO_CORE) << e.errorString();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        slotPrivilegeOperationRequested();
    }
```

#### AUTO 


```{c}
auto *job = new KIO::CommandLauncherJob(QStringLiteral("kcmshell5"), {QStringLiteral("webshortcuts")});
```

#### RANGE FOR STATEMENT 


```{c}
for (const QMimeType &m : mimeTypes) {
        qDebug() << m.name();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KService::Ptr &s : services) {
        qDebug() << s->name() << " " << s->entryPath();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : qAsConst(d->urls)) {
            if (!url.isLocalFile() && !hasSchemeHandler(url)) {
                useKioexec = true;
                //qCDebug(KIO_CORE) << "non-local files, application does not support urls, using kioexec";
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &itemPath : qAsConst(dirsToDelete)) {
        // qDebug() << "QDir::rmdir" << itemPath;
        if (!dir.rmdir(itemPath)) {
            if (auto err = execWithElevatedPrivilege(RMDIR, {itemPath}, errno)) {
                if (!err.wasCanceled()) {
                    error(KIO::ERR_CANNOT_DELETE, itemPath);
                }
                return false;
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const KFileItemList &items) {
        d->_k_slotDeleteItems(items);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        KService::Ptr service = dialog->service();
        if (!service) {
            service = KService::Ptr(new KService(QString() /*name*/, dialog->text(), QString() /*icon*/));
        }
        Q_EMIT serviceSelected(service);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->slotSortByType();
    }
```

#### AUTO 


```{c}
auto *action
```

#### LAMBDA EXPRESSION 


```{c}
[&] {
        QVERIFY(QDir().rmdir(dest));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](SkipDialog_Result result, KJob *parentJob) {
                            Q_ASSERT(parentJob == q);

                            // Only receive askUserSkipResult once per skip dialog
                            QObject::disconnect(askUserActionInterface, skipSignal, q, nullptr);

                            processCreateNextDir(it, result);
                        }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &s) {
        return s.startsWith(QLatin1String("init"));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : trashFiles) {
        if (file == QLatin1Char('.') || file == QLatin1String("..")) {
            continue;
        }
        QUrl url;
        url.setScheme(QStringLiteral("trash"));
        url.setPath(QLatin1String("0-") + file);
        KIO::StatJob *statJob = KIO::mostLocalUrl(url, KIO::HideProgressInfo);
        QVERIFY(statJob->exec());
        QCOMPARE(QUrl::fromLocalFile(m_trashDir + QStringLiteral("/files/") + file), statJob->mostLocalUrl());
    }
```

#### AUTO 


```{c}
static constexpr auto statFlags = KIO::StatBasic | KIO::StatResolveSymlink | KIO::StatMimeType;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &srcUrl : std::as_const(sources)) {
        QVERIFY(QFileInfo::exists(srcUrl.toLocalFile())); // no moving happened
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { slotIODeviceClosed(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](int value) {
        slotIconSizeSliderMoved(value);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &mountDir : mountDirs) {
                const QString type = mountDir.section(QLatin1Char(':'), 0, 0);
                if (type.isEmpty()) {
                    continue;
                }

                Ptr gvfsmp(new KMountPoint);
                gvfsmp->d->mountedFrom = mp->d->mountedFrom;
                gvfsmp->d->mountPoint = mp->d->mountPoint + QLatin1Char('/') + mountDir;
                gvfsmp->d->mountType = type;
                result.append(gvfsmp);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const KService::Ptr &service) {
        startService(service);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](QDBusPendingCallWatcher *watcher) {
        QDBusPendingReply<void> reply = *watcher;
        watcher->deleteLater();

        if (reply.isError()) {
            // Try the KRun strategy as fallback, also calls emitResult inside
            AbstractOpenFileManagerWindowStrategy *kRunStrategy = job->d->createKRunStrategy();
            kRunStrategy->start(urls, asn);
            return;
        }

        emitResultProxy();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KMountPoint::Ptr &mountPoint : *this) {
        if (realDevice.compare(mountPoint->d->m_device, cs) == 0 || realDevice.compare(mountPoint->d->m_mountedFrom, cs) == 0) {
            return mountPoint;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QChar c : qAsConst(password)) {
      unsigned int num = (c.unicode() ^ 173) + 17;
      unsigned int a1 = (num & 0xFC00) >> 10;
      unsigned int a2 = (num & 0x3E0) >> 5;
      unsigned int a3 = (num & 0x1F);
      scrambled += QLatin1Char((char)(a1+'0'));
      scrambled += QLatin1Char((char)(a2+'A'));
      scrambled += QLatin1Char((char)(a3+'0'));
   }
```

#### AUTO 


```{c}
auto removeFunc = [this](const UDSEntry &entry) {
            const QString filename = entry.stringValue(KIO::UDSEntry::UDS_NAME);
            // Avoid returning entries like subdir/. and subdir/.., but include . and .. for
            // the toplevel dir, and skip hidden files/dirs if that was requested
            const bool shouldEmit = (m_prefix.isNull() || (filename != QLatin1String("..") && filename != QLatin1String(".")))
                && (includeHidden || (filename[0] != QLatin1Char('.')));
            return !shouldEmit;
        };
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItemActionsPrivate::ServiceRank &tempRank : std::as_const(rankings)) {
        result << tempRank.service;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[udsField](const Field &entry) {return entry.m_index == udsField;}
```

#### RANGE FOR STATEMENT 


```{c}
for (const KServiceType::Ptr &st : list) {
        qDebug() << st->name();
    }
```

#### AUTO 


```{c}
const auto startReply = manager->StartTransientUnit(
        serviceName,
        QStringLiteral("fail"), // mode defines what to do in the case of a name conflict, in this case, just do nothing
        { // Properties of the transient service unit
          { QStringLiteral("Slice"), QStringLiteral("app.slice") },
          { QStringLiteral("Description"), m_description },
          { QStringLiteral("SourcePath"), m_desktopFilePath },
          { QStringLiteral("PIDs"), QVariant::fromValue(QList<uint> { static_cast<quint32>(m_process->pid()) }) } },
        {} // aux is currently unused and should be passed as empty array.
    );
```

#### LAMBDA EXPRESSION 


```{c}
[urls]() {
            // The action may update the desktop file. Example: eject unmounts (#5129).
            org::kde::KDirNotify::emitFilesChanged(urls);
        }
```

#### AUTO 


```{c}
auto err = execWithElevatedPrivilege(MKDIR, {path, permissions}, errno)
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &item : items) {
        if (!mimeTypeList.contains(item.mimetype())) {
            mimeTypeList << item.mimetype();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](RenameDialog_Result result, const QUrl &newUrl, KJob *parentJob) {
        Q_ASSERT(parentJob == q);
        // Only receive askUserRenameResult once per rename dialog
        QObject::disconnect(askUserActionInterface, renameSignal, q, nullptr);

        if (m_reportTimer) {
            m_reportTimer->start(s_reportTimeout);
        }

        const QString existingDest = (*it).uDest.path();

        switch (result) {
        case Result_Cancel:
            q->setError(ERR_USER_CANCELED);
            q->emitResult();
            return;
        case Result_AutoRename:
            m_bAutoRenameDirs = true;
            // fall through
            Q_FALLTHROUGH();
        case Result_Rename:
            renameDirectory(it, newUrl);
            break;
        case Result_AutoSkip:
            m_bAutoSkipDirs = true;
            // fall through
            Q_FALLTHROUGH();
        case Result_Skip:
            m_skipList.append(existingDest);
            skip((*it).uSource, true);
            // Move on to next dir
            dirs.erase(it);
            ++m_processedDirs;
            break;
        case Result_Overwrite:
            m_overwriteList.insert(existingDest);
            Q_EMIT q->copyingDone(q, (*it).uSource, finalDestUrl((*it).uSource, (*it).uDest), (*it).mtime, true /* directory */, false /* renamed */);
            // Move on to next dir
            dirs.erase(it);
            ++m_processedDirs;
            break;
        case Result_OverwriteAll:
            m_bOverwriteAllDirs = true;
            Q_EMIT q->copyingDone(q, (*it).uSource, finalDestUrl((*it).uSource, (*it).uDest), (*it).mtime, true /* directory */, false /* renamed */);
            // Move on to next dir
            dirs.erase(it);
            ++m_processedDirs;
            break;
        default:
            Q_ASSERT(0);
        }
        state = STATE_CREATING_DIRS;
        createNextDir();
    }
```

#### AUTO 


```{c}
const auto type = QStringView(itemMimeType).left(itemMimeType.indexOf(QLatin1Char('/')));
```

#### AUTO 


```{c}
auto *dialog = new KMessageDialog(KMessageDialog::Information,
                                      i18n("The peer SSL certificate chain appears to be corrupt."),
                                      parent);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const KIO::UDSEntryList &list) {
        slotListEntries(list);
    }
```

#### AUTO 


```{c}
auto err = execWithElevatedPrivilege(UTIME, path, qint64(utbuf.actime), qint64(utbuf.modtime))
```

#### RANGE FOR STATEMENT 


```{c}
for (KUriFilterPlugin *plugin : std::as_const(d->pluginList)) {
        // If no specific filters were requested, iterate through all the plugins.
        // Otherwise, only use available filters.
        if (filters.isEmpty() || filters.contains(plugin->objectName())) {
            if (plugin->filterUri(data)) {
                filtered = true;
            }
        }
    }
```

#### AUTO 


```{c}
const auto url = button->url();
```

#### AUTO 


```{c}
const auto jsonPlugins = KPluginLoader::findPlugins(QStringLiteral("kf5/kfileitemaction"), [&db, commonMimeType](const KPluginMetaData& metaData) {
        if (!metaData.serviceTypes().contains(QLatin1String("KFileItemAction/Plugin"))) {
            return false;
        }

        auto mimeType = db.mimeTypeForName(commonMimeType);
        const QStringList list = metaData.mimeTypes();
        for (const auto &supportedMimeType : list) {
            if (mimeType.inherits(supportedMimeType)) {
                return true;
            }
        }

        return false;
    });
```

#### AUTO 


```{c}
auto *job = new KIO::ApplicationLauncherJob(service, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KHttpCookie &cookie : std::as_const(allCookies)) {
        if (cookie.protocolVersion() > protVersion) {
            protVersion = cookie.protocolVersion();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KCoreDirLister *kdl : std::as_const(curHolders)) { // holders of newUrl
                kdl->jobStarted(job);
                Q_EMIT kdl->started(newUrl);
            }
```

#### AUTO 


```{c}
auto cleanupFunc = [this, mgr]() {
        QFile::remove(bookmarksFile());
        // let KDirWatch process the deletion
        QTRY_VERIFY(mgr->root().first().isNull());
        createPlacesModels();
        testInitialList();
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this](KIO::Job *job, const QByteArray &data) { slotThumbData(job, data); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KIO::Job *job, QByteArray &data) {
        slotDataReq(job, data);
    }
```

#### AUTO 


```{c}
auto err = execWithElevatedPrivilege(DEL, {dest}, errno)
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob * job) {
            m_error = job->error();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : qAsConst(m_filesToRemove)) {
        QFile::remove(file);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KIO::Job *job, KIO::filesize_t offset) {
        slotCanResume(job, offset);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KSycocaEntry::Ptr &p : list) {
        QString icon;
        QString text;
        QString entryPath;
        QString exec;
        bool isDir = false;
        if (p->isType(KST_KService)) {
            const KService::Ptr service(static_cast<KService*>(p.data()));

            if (service->noDisplay()) {
                continue;
            }

            icon = service->icon();
            text = service->name();
            exec = service->exec();
            entryPath = service->entryPath();
        } else if (p->isType(KST_KServiceGroup)) {
            const KServiceGroup::Ptr serviceGroup(static_cast<KServiceGroup*>(p.data()));

            if (serviceGroup->noDisplay() || serviceGroup->childCount() == 0) {
                continue;
            }

            icon = serviceGroup->icon();
            text = serviceGroup->caption();
            entryPath = serviceGroup->entryPath();
            isDir = true;
        } else {
            qCWarning(KIO_WIDGETS) << "KServiceGroup: Unexpected object in list!";
            continue;
        }

        KDEPrivate::AppNode *newnode = new KDEPrivate::AppNode();
        newnode->icon = icon;
        newnode->text = text;
        newnode->entryPath = entryPath;
        newnode->exec = exec;
        newnode->isDir = isDir;
        newnode->parent = node;
        node->children.append(newnode);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[parent_fd]() {
        close(parent_fd);
    }
```

#### AUTO 


```{c}
auto dataIt = jobData.cbegin();
```

#### LAMBDA EXPRESSION 


```{c}
[this, url](){ Q_EMIT q->tabRequested(url); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &str : qAsConst(searchProviders)) {
        actionData.append(filterData.queryForPreferredSearchProvider(str));
    }
```

#### AUTO 


```{c}
const auto result = properties[QStringLiteral("Result")].toString();
```

#### LAMBDA EXPRESSION 


```{c}
[=](const int result) {
        KIO::SlaveBase::ButtonCode btnCode;
        switch (result) {
        case QDialogButtonBox::Yes:
            if (dlgType == KMessageDialog::WarningContinueCancel) {
                btnCode = KIO::SlaveBase::Continue;
            } else {
                btnCode = KIO::SlaveBase::Yes;
            }
            break;
        case QDialogButtonBox::No:
            btnCode = KIO::SlaveBase::No;
            break;
        case QDialogButtonBox::Cancel:
            btnCode = KIO::SlaveBase::Cancel;
            break;
        case QDialogButtonBox::Ok:
            btnCode = KIO::SlaveBase::Ok;
            break;
        default:
            qCWarning(KIO_WIDGETS) << "Unknown message dialog result" << result;
            return;
        }

        emit messageBoxResult(btnCode);

        if (result != QDialogButtonBox::Cancel) {
            KConfigGroup cg = reqMsgConfig->group("Notification Messages");
            cg.writeEntry(dontAskAgainName, !dialog->isDontAskAgainChecked());
            cg.sync();
        }
    }
```

#### AUTO 


```{c}
const auto keys = provider->keys();
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString &mimeType) {
         foundMime = mimeType;
         job->kill();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, job]() {
        slotPreviewJobFinished(job);
    }
```

#### AUTO 


```{c}
const auto &fileItem
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &u : std::as_const(info.digestURIs)) {
            send &= (m_resource.scheme().toLower() == u.scheme().toLower());
            send &= (m_resource.host().toLower() == u.host().toLower());

            if (m_resource.port() > 0 && u.port() > 0) {
                send &= (m_resource.port() == u.port());
            }

            QString digestPath = u.adjusted(QUrl::RemoveFilename).path();
            if (digestPath.isEmpty()) {
                digestPath = QLatin1Char('/');
            }

            send &= (requestPath.startsWith(digestPath));

            if (send) {
                break;
            }
        }
```

#### AUTO 


```{c}
auto *delegate = qobject_cast<KFilePlacesViewDelegate *>(view->itemDelegate())
```

#### AUTO 


```{c}
auto end_unique = std::unique(urlList.begin(), urlList.end());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &protocol : qAsConst(protocols)) {
            // We cannot use mimeTypes() here, it doesn't support groups such as: text/*
            const QStringList mtypes = (*it)->serviceTypes();
            // Add supported mimetype for this protocol
            QStringList &_ms = m_remoteProtocolPlugins[protocol];
            for (const QString &_m : mtypes) {
                if (_m != QLatin1String("ThumbCreator")) {
                    protocolMap[protocol].insert(_m, *it);
                    if (!_ms.contains(_m)) {
                        _ms.append(_m);
                    }
                }
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        _k_slotUrlDesktopFile();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        zoomInIconsSize();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KCoreDirLister *kdl : holders) {
        kdl->jobStarted(job);
        // do it like when starting a new list-job that will redirect later
        // TODO: maybe don't emit started if there's an update running for newUrl already?
        Q_EMIT kdl->started(oldUrl);

        kdl->d->redirect(oldUrl, newUrl, false /*clear items*/);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const HTTPRequest &r : qAsConst(m_requestQueue)) {
            m_request = r;
            qCDebug(KIO_HTTP) << "check two: isKeepAlive =" << m_request.isKeepAlive;
            setMetaData(QStringLiteral("request-id"), QString::number(requestId++));
            sendAndKeepMetaData();
            if (!(readResponseHeader() && readBody())) {
                return;
            }
            // the "next job" signal for ParallelGetJob is data of size zero which
            // readBody() sends without our intervention.
            qCDebug(KIO_HTTP) << "check three: isKeepAlive =" << m_request.isKeepAlive;
            httpClose(m_request.isKeepAlive); // actually keep-alive is mandatory for pipelining
        }
```

#### AUTO 


```{c}
auto mit = d->itemMapper.constBegin();
```

#### AUTO 


```{c}
auto i = offset;
```

#### LAMBDA EXPRESSION 


```{c}
[this](KIO::filesize_t size) {
            slotProcessedSize(size);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QModelIndex index) {
        d->slotActivated(index);
    }
```

#### AUTO 


```{c}
auto *window = KJobWidgets::window(q);
```

#### AUTO 


```{c}
auto it = lstItems.cbegin();
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &mimeType) { slotMimetype(mimeType); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool allowDelete, const QList<QUrl> &urls,
                               KIO::AskUserActionInterface::DeletionType deletionType, QWidget *parentWidget) {
                        slotAskUserDeleteResult(allowDelete, urls, deletionType, parentWidget);
                     }
```

#### AUTO 


```{c}
auto *askUserHandler = new PredefinedAnswerAskUserInterface(job->uiDelegate());
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->m_pid = d->m_processRunner->pid();
        emitResult();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[job, &goticonFile](KJob *) {
            if (!job->error()) {
                goticonFile = job->iconFile();
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob* job) { _k_slotResult(job); }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        slotSymLink();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&jobs, job]() {
            jobs.removeOne(job);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &key : keys) {
        d->cachedProxyData[key]->removeAddress(proxy);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &mountDir : mountDirs) {
                const QString type = mountDir.section(QLatin1Char(':'), 0, 0);
                if (type.isEmpty()) {
                    continue;
                }

                Ptr gvfsmp(new KMountPoint);
                gvfsmp->d->m_mountedFrom = mp->d->m_mountedFrom;
                gvfsmp->d->m_mountPoint = mp->d->m_mountPoint + QLatin1Char('/') + mountDir;
                gvfsmp->d->m_mountType = type;
                result.append(gvfsmp);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &proxy : proxies) {
            if (proxy == QL1S("DIRECT")) {
                proxyList << proxy;
            } else {
                QUrl u(proxy);
                if (!u.isEmpty() && u.isValid() && !u.scheme().isEmpty()) {
                    proxyList << proxy;
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : std::as_const(d->m_attachments)) {
        query.addQueryItem(QStringLiteral("attach"), url.toString());
    }
```

#### AUTO 


```{c}
const auto recentDocs = recentDocuments();
```

#### AUTO 


```{c}
auto findDir = [this](const QModelIndex &parentIndex, const QString &name){
        for (int row = 0; row < m_dirModel->rowCount(parentIndex); ++row) {
            QModelIndex idx = m_dirModel->index(row, 0, parentIndex);
            if (m_dirModel->itemForIndex(idx).isDir() && m_dirModel->itemForIndex(idx).name() == name) {
                return idx;
            }
        }
        return QModelIndex();
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &fileName : list) {
        QString pathDesktop;
        if (fileName.startsWith(QLatin1Char(':'))) {
            // See: https://bugreports.qt.io/browse/QTBUG-11223
            pathDesktop = KRecentDocument::recentDocumentDirectory() + fileName;
        } else {
            pathDesktop = d.absoluteFilePath(fileName);
        }
        KDesktopFile tmpDesktopFile(pathDesktop);
        QUrl urlDesktopFile(tmpDesktopFile.desktopGroup().readPathEntry("URL", QString()));
        if (urlDesktopFile.isLocalFile() && !QFile(urlDesktopFile.toLocalFile()).exists()) {
            d.remove(pathDesktop);
        } else {
            fullList.append(pathDesktop);
        }
    }
```

#### AUTO 


```{c}
auto job = KIO::copy({QUrl::fromLocalFile(testCopy2)}, url, KIO::Resume);
```

#### LAMBDA EXPRESSION 


```{c}
[this](QDBusPendingCallWatcher *watcher) {
        QDBusPendingReply<QDBusObjectPath> reply = *watcher;
        watcher->deleteLater();
        if (reply.isError()) {
            qCWarning(KIO_GUI) << "Failed to launch process as service:" << m_serviceName << reply.error().name() << reply.error().message();
            return systemdError(reply.error().message());
        }
        qCDebug(KIO_GUI) << "Successfully asked systemd to launch process as service:" << m_serviceName;
        m_jobPath = reply.argumentAt<0>().path();
    }
```

#### AUTO 


```{c}
auto *filesJob = KIO::chmod(files, orFilePermissions, ~andFilePermissions, owner, group, false);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QSslCertificate &cert : certs) {
        QByteArray digest = cert.digest();
        const auto [it, isInserted] = digests.insert(digest);
        if (isInserted) {
            ret.append(cert);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : dirs) {
        items << dirLister->itemsForDir(url);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QAction* action) {
            m_triggered = true;
            slotTriggered(action);
        }
```

#### AUTO 


```{c}
auto addUrl = [u, &urls](const QString &partial_name)
    {
        if (partial_name.trimmed().isEmpty()) {
            return;
        }

        // We have to use setPath here, so that something like "test#file"
        // isn't interpreted to have path "test" and fragment "file".
        QUrl partial_url;
        partial_url.setPath(partial_name);

        // This returns QUrl(partial_name) for absolute URLs.
        // Otherwise, returns the concatenated url.
        const QUrl finalUrl = u.resolved(partial_url);

        if (finalUrl.isValid()) {
            urls.append(finalUrl);
        } else {
            // This can happen in the first quote! (ex: ' "something here"')
            qCDebug(KIO_KFILEWIDGETS_FW) << "Discarding Invalid" << finalUrl;
        }
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->_k_triggerDevicePolling();
    }
```

#### AUTO 


```{c}
auto job = KIO::del(items);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        q->setError(KIO::ERR_USER_CANCELED);
        q->emitResult();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KJob *job : std::as_const(m_previewJobs)) {
        Q_ASSERT(job);
        job->suspend();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job, qulonglong _size) { slotTotalSize(job, _size); }
```

#### AUTO 


```{c}
auto err = execWithElevatedPrivilege(DEL, dest)
```

#### LAMBDA EXPRESSION 


```{c}
[&]() -> bool {
                const QString out = proc.readAllStandardOutput();
                if (!out.isEmpty()) {
                    qDebug() << "STDERR:" << out;
                }
                if (!out.endsWith("Serving on http://0.0.0.0:30000 ...\n")) {
                    return false;
                }
                return true;
            }
```

#### AUTO 


```{c}
const auto charSetIt = metaData.constFind(QStringLiteral("charset"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QHostAddress& address : addresses) {
        if (!isSpecialAddress(address) && !isLocalHostAddress(address)) {
            ipAddressList << address.toString();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (ProtoQueue *p : qAsConst(m_protocols)) {
            const QList<KIO::Slave *> list = p->allSlaves();
            for (Slave *slave : list) {
                slave->kill();
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QString &match : *matches) {
        if (!match.isNull()) {
            if (match.endsWith(QLatin1Char('/'))) {
                d->quoteText(&match, false, true); // don't quote trailing '/'
            } else {
                d->quoteText(&match, false, false); // quote the whole text
            }

            match.prepend(d->m_text_start);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &entry : entries) {
        const QString udsUrl = entry.stringValue(KIO::UDSEntry::UDS_URL);

        QString entry_name;
        if (!udsUrl.isEmpty()) {
            // qDebug() << "url:" << url;
            entry_name = QUrl(udsUrl).fileName();
        } else {
            entry_name = entry.stringValue(KIO::UDSEntry::UDS_NAME);
        }

        // This can happen with kdeconnect://deviceId as a completion for kdeconnect:/,
        // there's no fileName [and the UDS_NAME is unrelated, can't use that].
        // This code doesn't support completing hostnames anyway (see addPathToUrl below).
        if (entry_name.isEmpty()) {
            continue;
        }

        if (entry_name.at(0) == QLatin1Char('.')
            && (list_urls_no_hidden || entry_name.length() == 1 || (entry_name.length() == 2 && entry_name.at(1) == QLatin1Char('.')))) {
            continue;
        }

        const bool isDir = entry.isDir();

        if (mode == KUrlCompletion::DirCompletion && !isDir) {
            continue;
        }

        if (filter_len != 0 && QStringView(entry_name).left(filter_len) != filter) {
            continue;
        }

        if (!mimeTypeFilters.isEmpty() && !isDir && !mimeTypeFilters.contains(entry.stringValue(KIO::UDSEntry::UDS_MIME_TYPE))) {
            continue;
        }

        QString toAppend = entry_name;

        if (isDir) {
            toAppend.append(QLatin1Char('/'));
        }

        if (!list_urls_only_exe || (entry.numberValue(KIO::UDSEntry::UDS_ACCESS) & s_modeExe) // true if executable
        ) {
            if (complete_url) {
                QUrl url(prepend);
                url = addPathToUrl(url, toAppend);
                matchList.append(url.toDisplayString());
            } else {
                matchList.append(prepend + toAppend);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QSslError &error : std::as_const(ud->sslErrors)) {
                    if (error.certificate() == cert) {
                        // we keep only the error code enum here
                        errors.append(error.error());
                    }
                }
```

#### AUTO 


```{c}
const auto exec = KProtocolInfo::exec(m_url.scheme());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QXmlStreamAttribute &old : attributes) {
                        if (old.qualifiedName() == modifiedAttribute) {
                            continue;
                        }
                        if (old.qualifiedName() == visitedAttribute) {
                            continue;
                        }
                        newAttributes.append(old);
                    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QDBusPendingCallWatcher *watcher) {
        watcher->deleteLater();
        if (watcher->isError()) {
            Q_EMIT error(watcher->error().name());
            terminateStartupNotification();
            m_finished = true;
            deleteLater();
            return;
        }
        auto call = QDBusConnection::sessionBus().interface()->asyncCall(QStringLiteral("GetConnectionUnixProcessID"), m_desktopName);
        auto pidWatcher = new QDBusPendingCallWatcher(call, this);
        connect(pidWatcher, &QDBusPendingCallWatcher::finished, this, [this](QDBusPendingCallWatcher *watcher) {
            m_finished = true;
            QDBusPendingReply<uint> reply = *watcher;
            if (reply.isError()) {
                Q_EMIT error(watcher->error().name());
                terminateStartupNotification();
            } else {
                Q_EMIT processStarted(reply.value());
            }
            deleteLater();
        });
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &action) {
         return KAuthorized::authorize(action.trimmed());
    }
```

#### AUTO 


```{c}
const auto itend = lstItems.cend();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &validPath : validSearchPaths) {
        if (path.endsWith(validPath)) {
            searchUrl.setScheme(QStringLiteral("baloosearch"));
            return searchUrl;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &udi : qAsConst(devices)) {
        bookmark = KFilePlacesItem::createDeviceBookmark(bookmarkManager, udi);
        if (!bookmark.isNull()) {
            KFilePlacesItem *item = new KFilePlacesItem(bookmarkManager, bookmark.address(), udi);
            connect(item, &KFilePlacesItem::itemChanged, q, [this](const QString &id) {
                itemChanged(id);
            });
            // TODO: Update bookmark internal element
            items << item;
        }
    }
```

#### AUTO 


```{c}
const auto &error
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &trashPath : qAsConst(m_trashDirectories)) {
            TrashSizeCache trashSize(trashPath);
            TrashSizeCache::SizeAndModTime res = trashSize.calculateSizeAndLatestModDate();
            size += res.size;

            // Find latest modification date
            if (res.mtime > latestModifiedDate) {
                latestModifiedDate = res.mtime;
            }
        }
```

#### AUTO 


```{c}
const auto src = arg1.toUrl();
```

#### AUTO 


```{c}
auto iter = deviceIdMap.find(path);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &item : items) {
        bool isLocal = false;
        const QUrl url = item.mostLocalUrl(&isLocal);
        m_isLocal = m_isLocal && isLocal;
        m_supportsReading  = m_supportsReading  && KProtocolManager::supportsReading(url);
        m_supportsDeleting = m_supportsDeleting && KProtocolManager::supportsDeleting(url);
        m_supportsWriting  = m_supportsWriting  && KProtocolManager::supportsWriting(url) && item.isWritable();
        m_supportsMoving   = m_supportsMoving   && KProtocolManager::supportsMoving(url);

        // For local files we can do better: check if we have write permission in parent directory
        // TODO: if we knew about the parent KFileItem, we could even do that for remote protocols too
#ifndef Q_OS_WIN
        if (m_isLocal && (m_supportsDeleting || m_supportsMoving)) {
            const QString directory = url.adjusted(QUrl::RemoveFilename | QUrl::StripTrailingSlash).toLocalFile();
            if (parentDirInfo.filePath() != directory) {
                parentDirInfo.setFile(directory);
            }
            if (!parentDirInfo.isWritable()) {
                m_supportsDeleting = false;
                m_supportsMoving = false;
            }
        }
#else
        if (m_isLocal && m_supportsDeleting) {
            if (!QFileInfo(url.toLocalFile()).isWritable())
                m_supportsDeleting = false;
        }
#endif
        if (m_isDirectory && !item.isDir()) {
            m_isDirectory = false;
        }

        if (m_isFile && !item.isFile()) {
            m_isFile = false;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KCoreDirLister *kdl : listers) {
            kdl->d->jobDone(job);

            // don't bother the user
            // kdl->handleError( job );

            const bool silent = job->property("_kdlc_silent").toBool();
            if (!silent) {
#if KIOCORE_BUILD_DEPRECATED_SINCE(5, 79)
                Q_EMIT kdl->canceled(jobUrl);
#endif
                Q_EMIT kdl->listingDirCanceled(jobUrl);
            }
            if (kdl->d->numJobs() == 0) {
                kdl->d->complete = true;
                if (!silent) {
                    Q_EMIT kdl->canceled();
                }
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Task &task) { commandReceived(task); }
```

#### LAMBDA EXPRESSION 


```{c}
[job, &goticonFile](KJob *){
            if (!job->error()) {
                goticonFile = job->iconFile();
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (KCoreDirLister *kdl : holders) {
                kdl->jobStarted(job);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (KMountPoint::Ptr mountPoint : mountPoints) {
        qDebug() << "Mount: " << mountPoint->mountedFrom() << " (" << mountPoint->realDeviceName() << ") " << mountPoint->mountPoint() << " "
                 << mountPoint->mountType();
        QVERIFY(!mountPoint->mountedFrom().isEmpty());
        QVERIFY(!mountPoint->mountPoint().isEmpty());
        QVERIFY(!mountPoint->mountType().isEmpty());
        // old bug, happened because KMountPoint called KStandardDirs::realPath instead of realFilePath
        if (mountPoint->realDeviceName().startsWith(QLatin1String("/dev"))) { // skip this check for cifs mounts for instance
            QVERIFY(!mountPoint->realDeviceName().endsWith('/'));
        }

        // keep one (any) mountpoint with a device name for the test below
        if (!mountPoint->realDeviceName().isEmpty() && !mountWithDevice) {
            mountWithDevice = mountPoint;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KIO::Job *job, const QUrl &src, const QUrl &dest) {
                slotCopyingDone(job, src, dest);
            }
```

#### AUTO 


```{c}
const auto actionHelper = [](ActionType action) -> QString {
        switch (action) {
        case ActionType::CHMOD:   return i18n("Authentication is required to change this file's permissions.");
        case ActionType::CHOWN:   return i18n("Authentication is required to change who owns this file.");
        case ActionType::DEL:     return i18n("Authentication is required to delete this file.");
        case ActionType::MKDIR:   return i18n("Authentication is required to create a folder.");
        case ActionType::OPEN:    return i18n("Authentication is required to open this file.");
        case ActionType::OPENDIR: return i18n("Authentication is required to open this folder.");
        case ActionType::RENAME:  return i18n("Authentication is required to rename this file.");
        case ActionType::RMDIR:   return i18n("Authentication is required to delete this folder.");
        case ActionType::SYMLINK: return i18n("Authentication is required to create a symlink.");
        case ActionType::UTIME:   return i18n("Authentication is required to modify this file's last updated time.");
        case ActionType::COPY:    return i18n("Authentication is required to copy this item.");
        case ActionType::UNKNOWN: return i18n("Authentication is required to perform this action.");
        }
        Q_UNREACHABLE();
        return QString();
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        Q_EMIT result(false);
    }
```

#### AUTO 


```{c}
auto it = itBegin;
```

#### AUTO 


```{c}
auto actions = abstractPlugin->actions(m_props, m_parentWidget);
```

#### AUTO 


```{c}
const auto &mimeFilter
```

#### AUTO 


```{c}
const auto jsonPlugins = KPluginLoader::findPlugins(QStringLiteral("kf5/kfileitemaction"), [&db, commonMimeType](const KPluginMetaData& metaData) {
        if (!metaData.serviceTypes().contains(QLatin1String("KFileItemAction/Plugin"))) {
            return false;
        }

        auto mimeType = db.mimeTypeForName(commonMimeType);
        const QStringList list = metaData.mimeTypes();
        return std::any_of(list.constBegin(), list.constEnd(), [mimeType](const QString &supportedMimeType) {
            return mimeType.inherits(supportedMimeType);
        });
    });
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : additionalActions) {
        if (action->priority() == QAction::HighPriority) {
            menu.insertAction(highPriorityActionsPlaceholder, action);
        } else {
            menu.addAction(action);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->slotFilterChanged(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *urlJob) {
        if (urlJob->error()) {
            emitResultProxy(OpenFileManagerWindowJob::LaunchFailedError);
        } else {
            emitResultProxy();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&mit](const std::unique_ptr<const KUrlComboBoxPrivate::KUrlComboItem> &item) {
                return item.get() == mit.value();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &plugin : plugins) {
        result += plugin.mimeTypes();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KIO::ListJob *job, KIO::ListJob *subJob) {
        slotSubError(job, subJob);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (int port : qAsConst(mPorts)) {
                    portNums += QString::number(port) + QLatin1Char(' ');
                }
```

#### LAMBDA EXPRESSION 


```{c}
[itemMimeType, item](const QString &i) {
        if (i == itemMimeType || i == QLatin1String("all/all")) {
            return true;
        }
        if (item.isFile() && (i == QLatin1String("allfiles") || i == QLatin1String("all/allfiles") || i == QLatin1String("application/octet-stream"))) {
            return true;
        }

        if (item.currentMimeType().inherits(i)) {
            return true;
        }

        const int iSlashPos = i.indexOf(QLatin1Char(QLatin1Char('/')));
        Q_ASSERT(iSlashPos > 0);
        const QStringRef iSubType = i.midRef(iSlashPos + 1);

        if (iSubType == QLatin1String("*")) {
            const int itemSlashPos = itemMimeType.indexOf(QLatin1Char('/'));
            Q_ASSERT(itemSlashPos > 0);
            const QStringRef iTopLevelType = i.midRef(0, iSlashPos);
            const QStringRef itemTopLevelType = itemMimeType.midRef(0, itemSlashPos);

            return itemTopLevelType == iTopLevelType;
        }
        return false;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QUrl& url) {
        Q_EMIT q->urlAboutToBeChanged(url);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, job]() { d->slotResult(job); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &lang : std::as_const(languageList)) {
        const QStringList langs = replacementCodes.readEntry(lang, QStringList());
        if (langs.isEmpty()) {
            languageListFinal += lang;
        } else {
            languageListFinal += langs;
        }
    }
```

#### AUTO 


```{c}
const auto &[localUrl, isLocal] = properties->item().isMostLocalUrl();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : srcUrls) {
            QUrl dUrl = copyJob->destUrl().adjusted(QUrl::StripTrailingSlash);
            dUrl.setPath(concatPaths(dUrl.path(), url.fileName()));
            newUrls.append(dUrl);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &urlFetched : std::as_const(urlsBeingFetched)) {
                if (dirUrl.matches(urlFetched, QUrl::StripTrailingSlash) || dirUrl.isParentOf(urlFetched)) {
                    // qDebug() << "Listing found" << dirUrl.url() << "which is a parent of fetched url" << urlFetched;
                    const QModelIndex parentIndex = indexForNode(node, dirNode->m_childNodes.count() - 1);
                    Q_ASSERT(parentIndex.isValid());
                    emitExpandFor.append(parentIndex);
                    if (isDir && dirUrl != urlFetched) {
                        q->fetchMore(parentIndex);
                        m_urlsBeingFetched[node].append(urlFetched);
                    }
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &jsonMetadata : jsonPlugins) {
        if (auto plugin = KPluginFactory::instantiatePlugin<KPropertiesDialogPlugin>(jsonMetadata, q).plugin) {
            q->insertPlugin(plugin);
            addedPlugins.append(jsonMetadata.pluginId());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &rlitem : refList) {
                if (found) {
                    break;
                }

                const QRegularExpression rangeRe(QStringLiteral("([0-9]*)\\-([0-9]*)"));
                const QRegularExpressionMatch rangeMatch = rangeRe.match(rlitem);
                // Substitute a range of keywords
                if (rangeMatch.hasMatch()) {
                    int first = rangeMatch.captured(1).toInt();
                    int last = rangeMatch.captured(2).toInt();

                    if (first == 0) {
                        first = 1;
                    }

                    if (last == 0) {
                        last = count;
                    }

                    for (int i = first; i <= last; i++) {
                        v += map[QString::number(i)] + QLatin1Char(' ');
                        // Remove used value from ql (needed for \{@}):
                        ql[i-1].clear();
                    }

                    v = v.trimmed();
                    if (!v.isEmpty()) {
                        found = true;
                    }

                    PDVAR(QLatin1String("    range"), QString::number(first) + QLatin1Char('-') + QString::number(last) + QLatin1String(" => '") + v + QLatin1Char('\''));
                    v = encodeString(v, codec);
                } else if (rlitem.startsWith(QLatin1Char('\"')) && rlitem.endsWith(QLatin1Char('\"'))) {
                    // Use default string from query definition:
                    found = true;
                    QString s = rlitem.mid(1, rlitem.length() - 2);
                    v = encodeString(s, codec);
                    PDVAR("    default", s);
                } else if (map.contains(rlitem)) {
                    // Use value from substitution map:
                    found = true;
                    PDVAR(QLatin1String("    map['") + rlitem + QLatin1String("']"), map[rlitem]);
                    v = encodeString(map[rlitem], codec);

                    // Remove used value from ql (needed for \{@}):
                    const QChar c = rlitem.at(0); // rlitem can't be empty at this point
                    if (c == QLatin1Char('0')) {
                        // It's a numeric reference to '0'
                        for (QStringList::Iterator it = ql.begin(); it != ql.end(); ++it) {
                            (*it).clear();
                        }
                    } else if ((c >= QLatin1String("0")) && (c <= QLatin1String("9"))) { // krazy:excludeall=doublequote_chars
                        // It's a numeric reference > '0'
                        int n = rlitem.toInt();
                        ql[n-1].clear();
                    } else {
                        // It's a alphanumeric reference
                        QStringList::Iterator it = ql.begin();
                        while ((it != ql.end()) && !it->startsWith(rlitem + QLatin1Char('='))) {
                            ++it;
                        }
                        if (it != ql.end()) {
                            it->clear();
                        }
                    }

                    // Encode '+', otherwise it would be interpreted as space in the resulting url:
                    v.replace(QLatin1Char('+'), QLatin1String("%2B"));
                } else if (rlitem == QLatin1String("@")) {
                    v = QStringLiteral("\\@");
                    PDVAR("    v", v);
                }
            }
```

#### AUTO 


```{c}
constexpr auto statFlags = KIO::StatBasic | KIO::StatResolveSymlink | KIO::StatMimeType;
```

#### RANGE FOR STATEMENT 


```{c}
for (const KService::Ptr &plugin : plugins) {
        result += plugin->mimeTypes();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, processRunner]() {
                d->slotStarted(this, processRunner);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (UDSEntry &newone : newlist) {
            // Modify the name in the UDSEntry
            const QString filename = newone.stringValue(KIO::UDSEntry::UDS_NAME);
            QString displayName = newone.stringValue(KIO::UDSEntry::UDS_DISPLAY_NAME);
            if (displayName.isEmpty()) {
                displayName = filename;
            }

            // ## Didn't find a way to use the iterator instead of re-doing a key lookup
            newone.replace(KIO::UDSEntry::UDS_NAME, m_prefix + filename);
            newone.replace(KIO::UDSEntry::UDS_DISPLAY_NAME, m_displayPrefix + displayName);
        }
```

#### AUTO 


```{c}
auto instance = makeInstance();
```

#### LAMBDA EXPRESSION 


```{c}
[this, job, text, applyUrl]() {
        // If there is a dir matching "text" relative to the current url, use that, e.g.
        // typing "bar" while at "/path/to/foo", the url becomes "/path/to/foo/bar/"
        if (!job->error() && job->statResult().isDir()) {
            applyUrl(job->url());
        } else { // ... otherwise fallback to whatever QUrl::fromUserInput() returns
            applyUrl(QUrl::fromUserInput(text));
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](KFilePlacesItem *itemA, KFilePlacesItem *itemB) {
        return (itemA->groupType() < itemB->groupType());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[job, text, applyUrl]() {
        // If there is a dir matching "text" relative to the current url, use that, e.g.
        // typing "bar" while at "/path/to/foo", the url becomes "/path/to/foo/bar/"
        if (!job->error() && job->statResult().isDir()) {
            applyUrl(job->url());
        } else { // ... otherwise fallback to whatever QUrl::fromUserInput() returns
            applyUrl(QUrl::fromUserInput(text));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &str : supported) {
                // wilcard matching because the "mimetype" can be "image/*"
                re.setPattern(QRegularExpression::wildcardToRegularExpression(str));

                if (mimeTypes.indexOf(re) != -1) { // matches! -> we want previews
                    return true;
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this](int iconSize) {
        slotDirOpIconSizeChanged(iconSize);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job, qulonglong processedSize) {
            slotProcessedSize(job, processedSize);
        }
```

#### AUTO 


```{c}
auto job = KIO::copy({ QUrl::fromLocalFile(QFINDTESTDATA("ftp/testCopy2")) }, url, KIO::Resume);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &protocol : protocols) {
        // Check that hasSchemeHandler will return true
        QVERIFY(!KProtocolInfo::isKnownProtocol(protocol));
        QVERIFY(!KProtocolInfo::isHelperProtocol(protocol));
        QVERIFY(KMimeTypeTrader::self()->preferredService(QLatin1String("x-scheme-handler/") + protocol));

        const QList<QUrl> urls({QUrl(QStringLiteral("%1://root@10.1.1.1").arg(protocol))});
        KIO::DesktopExecParser parser(*service, urls);
        QCOMPARE(KShell::joinArgs(parser.resultingArguments()),
                 QStringLiteral("%1 %2://root@10.1.1.1").arg(KShell::quoteArg(ktelnetExec), protocol));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const KFileItemList &items) {
                for (const KFileItem &item : items) {
                    tags.removeAll(item.name());
                }
                reloadBookmarks();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &header : headers) {
        // Do not allow Request line to be specified and ignore
        // the other HTTP headers.
        if (!header.contains(QLatin1Char(':')) ||
                header.startsWith(QLatin1String("host"), Qt::CaseInsensitive) ||
                header.startsWith(QLatin1String("proxy-authorization"), Qt::CaseInsensitive) ||
                header.startsWith(QLatin1String("via"), Qt::CaseInsensitive) ||
                header.startsWith(QLatin1String("depth"), Qt::CaseInsensitive)) {
            continue;
        }

        sanitizedHeaders += header + QLatin1String("\r\n");
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr int s_kioDataPollInterval = 0;
```

#### AUTO 


```{c}
auto err = execWithElevatedPrivilege(CHMOD, _path, permissions)
```

#### LAMBDA EXPRESSION 


```{c}
[this](QAction* action) { slotTriggered(action); }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &str) {
        QFileInfo info(str);
        return info.exists() && info.isFile() && info.isReadable();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KCoreDirLister *kdl : listers) {
        kdl->jobStarted(job);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KSslError::Error e : l) {
            qErrors.push_back(KSslErrorPrivate::errorFromKSslError(e));
        }
```

#### AUTO 


```{c}
auto *askUserActionInterface = KIO::delegateExtension<KIO::AskUserActionInterface *>(kioJob);
```

#### LAMBDA EXPRESSION 


```{c}
[=](RenameDialog_Result result, const QUrl &newUrl, KJob *parentJob) {
                        Q_ASSERT(parentJob == q);
                        // Only receive askUserRenameResult once per rename dialog
                        QObject::disconnect(askUserActionInterface, &KIO::AskUserActionInterface::askUserRenameResult,
                                            q, nullptr);

                        processDirectRenamingConflictResult(result, isDir, destIsDir, mtimeSrc, mtimeDest, dest, newUrl);
                    }
```

#### AUTO 


```{c}
auto doRename(const QUrl& from, const QUrl& to)
{
    auto job = KIO::rename(from, to);

    Fum->recordJob(KIO::FileUndoManager::Rename, {from}, to, job);

    return jobToFuture(QStringLiteral("rename %1 to %2").arg(toStr(from)).arg(toStr(to)), job);
}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &p : patterns) {
        rx.setPattern(QRegularExpression::wildcardToRegularExpression(p));
        if (rx.match(filename).hasMatch()) {
            return p;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](int pos, int index) { placesViewSplitterMoved(pos, index); }
```

#### AUTO 


```{c}
auto job = KIO::rename(from, to);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->m_terminalOptionStr = d->m_uiAdvanced->terminalEdit->text().trimmed();
        d->m_terminalBool = d->m_uiAdvanced->terminalCheck->isChecked();
        d->m_suidBool = d->m_uiAdvanced->suidCheck->isChecked();
        d->m_suidUserStr = d->m_uiAdvanced->suidEdit->text().trimmed();
        if (d->m_hasDiscreteGpuBool) {
            d->m_runOnDiscreteGpuBool = d->m_uiAdvanced->discreteGpuCheck->isChecked();
        }
        d->m_startupBool = d->m_uiAdvanced->startupInfoCheck->isChecked();

        if (d->m_uiAdvanced->terminalCloseCheck->isChecked()) {
            d->m_terminalOptionStr.append(QLatin1String(" --noclose"));
        }

        switch (d->m_uiAdvanced->dbusCombo->currentIndex()) {
        case 1:
            d->m_dbusStartupType = QStringLiteral("multi");
            break;
        case 2:
            d->m_dbusStartupType = QStringLiteral("unique");
            break;
        case 3:
            d->m_dbusStartupType = QStringLiteral("wait");
            break;
        default:
            d->m_dbusStartupType = QStringLiteral("none");
            break;
        }
    }
```

#### AUTO 


```{c}
auto clipboard = QApplication::clipboard();
```

#### AUTO 


```{c}
const auto startReply = manager->StartTransientUnit(
        serviceName,
        QStringLiteral("fail"), // mode defines what to do in the case of a name conflict, in this case, just do nothing
        { // Properties of the transient service unit
          { QStringLiteral("Slice"), QStringLiteral("app.slice") },
          { QStringLiteral("PIDs"), QVariant::fromValue(QList<uint> { static_cast<quint32>(m_process->pid()) }) } },
        {} // aux is currently unused and should be passed as empty array.
    );
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &proxy : qAsConst(proxyList)) {
            QUrl u(proxy);
            if (u.isValid() && KProtocolInfo::isKnownProtocol(u.scheme())) {
                protocol = u.scheme();
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QChar ch : text) {

        if (escaped) {
            escaped = false;
            result.insert(result.length(), ch);
        } else if (in_quote && ch == p_last_quote_char) {
            in_quote = false;
        } else if (!in_quote && ch == m_quote_char1) {
            p_last_quote_char = m_quote_char1;
            in_quote = true;
        } else if (!in_quote && ch == m_quote_char2) {
            p_last_quote_char = m_quote_char2;
            in_quote = true;
        } else if (ch == m_escape_char) {
            escaped = true;
            result.insert(result.length(), ch);
        } else {
            result.insert(result.length(), ch);
        }

    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KCModule *module : std::as_const(modules)) {
        module->save();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job, qulonglong size) {
        _k_slotProcessedSize(job, size);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *page : d->m_pages) {
            if (d->m_aborted) {
                break;
            }

            if (page->isDirty()) {
                // qDebug() << "applying changes for " << page->metaObject()->className();
                page->applyChanges();
            }
            /* else {
                qDebug() << "skipping page " << page->metaObject()->className();
            } */
        }
```

#### AUTO 


```{c}
const auto properties = reply.argumentAt<0>();
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) {
        _k_slotResult(job);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KCoreDirLister *kdl : listers) {
        if (job) {
            kdl->d->jobDone(job);
        }
#if KIOCORE_BUILD_DEPRECATED_SINCE(5, 79)
        Q_EMIT kdl->canceled(oldUrl);
#endif
        Q_EMIT kdl->listingDirCanceled(oldUrl);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &item : qAsConst(m_items)) {
        const QString itemMimeType = item.mimetype();
        // Determine if common MIME type among all items
        if (m_mimeType != itemMimeType) {
            m_mimeType.clear();
            if (m_mimeGroup != itemMimeType.leftRef(itemMimeType.indexOf(QLatin1Char('/')))) {
                m_mimeGroup.clear(); // MIME type groups are different as well!
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const KFileItem &item) {
        fileSelected(item);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &httpHeader : httpHeaders) {
            int index = httpHeader.indexOf(QLatin1Char(':'));
            // Handle HTTP status line...
            if (index == -1) {
                // Except for the status line, all HTTP header must be an nvpair of
                // type "<name>:<value>"
                if (!httpHeader.startsWith(QLatin1String("HTTP/"), Qt::CaseInsensitive)) {
                    continue;
                }

                QStringList statusLineAttrs(httpHeader.split(QLatin1Char(' '), Qt::SkipEmptyParts));
                if (statusLineAttrs.count() > 1) {
                    setAttribute(QNetworkRequest::HttpStatusCodeAttribute, statusLineAttrs.at(1));
                }

                if (statusLineAttrs.count() > 2) {
                    setAttribute(QNetworkRequest::HttpReasonPhraseAttribute, statusLineAttrs.at(2));
                }

                continue;
            }

            const QStringRef headerName = httpHeader.leftRef(index);
            QString headerValue = httpHeader.mid(index + 1);

            // Ignore cookie header since it is handled by the http ioslave.
            if (headerName.startsWith(QLatin1String("set-cookie"), Qt::CaseInsensitive)) {
                continue;
            }

            if (headerName.startsWith(QLatin1String("content-disposition"), Qt::CaseInsensitive) && ignoreContentDisposition(metaData)) {
                continue;
            }

            // Without overriding the corrected mime-type sent by kio_http, add
            // back the "charset=" portion of the content-type header if present.
            if (headerName.startsWith(QLatin1String("content-type"), Qt::CaseInsensitive)) {
                QString mimeType(header(QNetworkRequest::ContentTypeHeader).toString());

                if (m_ignoreContentDisposition) {
                    // If the server returned application/octet-stream, try to determine the
                    // real content type from the disposition filename.
                    if (mimeType == QLatin1String("application/octet-stream")) {
                        const QString fileName(metaData.value(QStringLiteral("content-disposition-filename")));
                        QMimeDatabase db;
                        QMimeType mime = db.mimeTypeForFile((fileName.isEmpty() ? url().path() : fileName), QMimeDatabase::MatchExtension);
                        mimeType = mime.name();
                    }
                    metaData.remove(QStringLiteral("content-disposition-type"));
                    metaData.remove(QStringLiteral("content-disposition-filename"));
                }

                if (!headerValue.contains(mimeType, Qt::CaseInsensitive)) {
                    index = headerValue.indexOf(QLatin1Char(';'));
                    if (index == -1) {
                        headerValue = mimeType;
                    } else {
                        headerValue.replace(0, index, mimeType);
                    }
                    // qDebug() << "Changed mime-type from" << mimeType << "to" << headerValue;
                }
            }
            setRawHeader(headerName.trimmed().toUtf8(), headerValue.trimmed().toUtf8());
        }
```

#### AUTO 


```{c}
const auto checkMaxTime = [&max_mtime] (const qint64 lastModTime) {
        if (lastModTime > max_mtime) {
            max_mtime = lastModTime;
        }
    };
```

#### IF STATEMENT WITH INITIALIZER 


```{c}
if (QT_STATBUF buff; QT_LSTAT(QFile::encodeName(realPath).constData(), &buff) == 0) {
        auto it = std::find_if(this->cbegin(), this->cend(), [&buff, &realPath](const KMountPoint::Ptr &mountPtr) {
            // For a bind mount, the deviceId() is that of the base mount point, e.g. /mnt/foo,
            // however the path we're looking for, e.g. /home/user/bar, doesn't start with the
            // mount point of the base device, so we go on searching
            return mountPtr->deviceId() == buff.st_dev && realPath.startsWith(mountPtr->mountPoint());
        });

        if (it != this->cend()) {
            result = *it;
        }
    }
```

#### AUTO 


```{c}
const auto modifiers = qGuiApp->keyboardModifiers();
```

#### AUTO 


```{c}
const auto &supportedSchemes = d->model->supportedSchemes();
```

#### LAMBDA EXPRESSION 


```{c}
[this](const int result) {
        emit q->messageBoxResult(result == QDialogButtonBox::Ok ? KIO::SlaveBase::Ok : KIO::SlaveBase::Cancel);
    }
```

#### AUTO 


```{c}
const auto actionIndex = d->m_watcher->hoveredActionIndex();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            // KSslInfoDialog only has one button, QDialogButtonBox::Close
            emit q->messageBoxResult(KIO::SlaveBase::Cancel);
        }
```

#### AUTO 


```{c}
const auto mimeTypeGroup = QStringView(mimeType).left(slashIndex);
```

#### LAMBDA EXPRESSION 


```{c}
[this](KIO::filesize_t size){ slotTotalSize(size);}
```

#### AUTO 


```{c}
auto *popupFilter = new KUrlNavigatorPathSelectorEventFilter(popup.data());
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QUrl &url) {
        setCurrentItem(url);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &domainName : qAsConst(m_domainList)) {
        bool domainPrinted = false;

        KHttpCookieList *cookieList = m_cookieDomains.value(domainName);
        if (!cookieList) {
            continue;
        }

        QMutableListIterator<KHttpCookie> cookieIterator(*cookieList);
        while (cookieIterator.hasNext()) {
            const KHttpCookie &cookie = cookieIterator.next();

            if (cookie.isExpired()) {
                // Delete expired cookies
                cookieIterator.remove();
                continue;
            }
            if (cookieIsPersistent(cookie)) {
                // Only save cookies that are not "session-only cookies"
                if (!domainPrinted) {
                    domainPrinted = true;
                    ts << '[' << domainName.toLocal8Bit().data() << "]\n";
                }
                // Store persistent cookies
                const QString path = QLatin1Char('"') + cookie.path() + QLatin1Char('"');
                const QString domain = QLatin1Char('"') + cookie.domain() + QLatin1Char('"');
                const QString host = hostWithPort(&cookie);

                // TODO: replace with direct QTextStream output ?
                const QString str = QString::asprintf("%-20s %-20s %-12s %10lld  %3d %-20s %-4i %s\n",
                                                      host.toLatin1().constData(),
                                                      domain.toLatin1().constData(),
                                                      path.toLatin1().constData(),
                                                      cookie.expireDate(),
                                                      cookie.protocolVersion(),
                                                      cookie.name().isEmpty() ? cookie.value().toLatin1().constData() : cookie.name().toLatin1().constData(),
                                                      (cookie.isSecure() ? 1 : 0) + (cookie.isHttpOnly() ? 2 : 0) + (cookie.hasExplicitPath() ? 4 : 0)
                                                          + (cookie.name().isEmpty() ? 8 : 0),
                                                      cookie.value().toLatin1().constData());
                ts << str.toLatin1();
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &message) {
        _k_slotSlaveInfoMessage(message);
    }
```

#### AUTO 


```{c}
auto mimeData = clipboard->mimeData();
```

#### AUTO 


```{c}
auto it = std::find_if(d->items.cbegin(), d->items.cend(), [&url](const PreviewItem &pItem) {
        return url == pItem.item.url();
    });
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &udi : qAsConst(devices)) {
        bookmark = KFilePlacesItem::createDeviceBookmark(bookmarkManager, udi);
        if (!bookmark.isNull()) {
            KFilePlacesItem *item = new KFilePlacesItem(bookmarkManager,
                    bookmark.address(), udi);
            connect(item, SIGNAL(itemChanged(QString)),
                    q, SLOT(_k_itemChanged(QString)));
            // TODO: Update bookmark internal element
            items << item;
        }
    }
```

#### AUTO 


```{c}
auto windowId = WId{};
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->slotAutoSelectExtClicked(); }
```

#### AUTO 


```{c}
const auto jsonPlugins = KPluginLoader::findPlugins(QStringLiteral("kf5/propertiesdialog"));
```

#### AUTO 


```{c}
auto err = tryOpen(dest_file, _dest, O_WRONLY | O_TRUNC | O_CREAT, S_IRUSR | S_IWUSR, errno)
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : m_dirsToUpdate) {
            //qDebug() << "Notifying FilesAdded for " << url;
            org::kde::KDirNotify::emitFilesAdded(url);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &filter : list) {
        d->settings.lstFilters.append(
            QRegularExpression(QRegularExpression::wildcardToRegularExpression(filter),
                               QRegularExpression::CaseInsensitiveOption));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &ba : qAsConst(results)) {
        QList<QByteArray> values = ba.split('\t');
        const QString key(QString::fromLatin1(values.takeFirst()));

        QVERIFY(parameters.contains(key));

        const QByteArray val = values.takeFirst();
        QVERIFY(values.isEmpty());

        QCOMPARE(parameters[key], QString::fromUtf8(val.constData(), val.length()));
    }
```

#### AUTO 


```{c}
auto it = std::lower_bound(dirItem->lstItems.begin(), dirItem->lstItems.end(), oldUrl);
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        if (job->error()) {
            qWarning() << job->errorString();
            app.exit(1);
        } else {
            qDebug() << "Successfully started";
            app.exit(0);
        }
    }
```

#### AUTO 


```{c}
auto mimeType = mimeTypes.mimeTypeForFile(file_info);
```

#### AUTO 


```{c}
const auto startReply =
        manager->StartTransientUnit(serviceName,
                                    QStringLiteral("fail"), // mode defines what to do in the case of a name conflict, in this case, just do nothing
                                    {// Properties of the transient service unit
                                     {QStringLiteral("Slice"), QStringLiteral("app.slice")},
                                     {QStringLiteral("Description"), m_description},
                                     {QStringLiteral("SourcePath"), m_desktopFilePath},
                                     {QStringLiteral("PIDs"), QVariant::fromValue(QList<uint>{static_cast<uint>(m_process->processId())})}},
                                    {} // aux is currently unused and should be passed as empty array.
        );
```

#### AUTO 


```{c}
const auto destFileSystem = KFileSystemType::fileSystemType(it->uDest.adjusted(QUrl::StripTrailingSlash | QUrl::RemoveFilename).toLocalFile());
```

#### AUTO 


```{c}
auto it = m_previewProviders.cbegin();
```

#### LAMBDA EXPRESSION 


```{c}
[](const QModelIndex &idx){ return QPersistentModelIndex(idx); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : m_urls) {
        fileItems.append(KFileItem(url));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : indexes) {
        const KFileItem &item = d->nodeForIndex(index)->item();
        urls << item.url();
        bool isLocal;
        mostLocalUrls << item.mostLocalUrl(&isLocal);
        if (!isLocal) {
            canUseMostLocalUrls = false;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &protocol : qAsConst(items[category])) {
                QAction *action = menu->addAction(protocol);
                action->setData(protocol);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (KJob *job : jobs) {
        job->kill(); // ret val ignored, see below
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &key : translatedStringListAttributes) {
            // read untranslated entry first in any case!
            sconfig.setLocale(QString());
            const QStringList untranslatedValues = config.readEntry(key, QStringList());
            if (!untranslatedValues.isEmpty()) {
                protocolData.insert(key, untranslatedValues);
            }

            // collect all locales for this key
            QFile f(fullFilePath);
            QStringList foundLocalesForKey;
            if (!f.open(QIODevice::ReadOnly | QIODevice::Text)) {
                qFatal("Failed to open file %s.", qPrintable(fullFilePath));
            }
            while (!f.atEnd()) {
                const QString line = QString::fromUtf8(f.readLine());
                const QRegularExpressionMatch match = localeRegex.match(line);
                if (match.hasMatch()) {
                    foundLocalesForKey.append(match.captured(1));
                }
            }

            // insert all entries for all found locales, reparse config for this
            for (const QString &locale : qAsConst(foundLocalesForKey)) {
                sconfig.setLocale(locale);
                protocolData.insert(QStringLiteral("%1[%2]").arg(key, locale), config.readEntry(key, QStringList()));
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, job]() { slotPreviewJobFinished(job); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KServicePtr &service : qAsConst(offers)) {
                QAction *act = createAppAction(service, false);
                subMenu->addAction(act);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KServiceAction &action : list) {
        if (keys.isEmpty() || keys.contains(action.name())) {
            const QString exec = action.exec();
            if (bLocalFiles || exec.contains(QLatin1String("%U")) || exec.contains(QLatin1String("%u"))) {
                result.append(action);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : indexList) {
        KFileItem item = d->m_dirModel->itemForIndex(index);
        if (!item.isNull()) {
            itemList.append(item);
        }
    }
```

#### AUTO 


```{c}
const auto shares = KSambaShare::instance()->shareNames();
```

#### RANGE FOR STATEMENT 


```{c}
for (KUrlNavigatorButton *button : std::as_const(buttonsToShow)) {
        button->show();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[]() {
        if (QDBusConnection::sessionBus().interface()->isServiceRegistered(systemdService)) {
            runAsService = true;
            qDBusRegisterMetaType<QVariantMultiItem>();
            qDBusRegisterMetaType<QVariantMultiMap>();
            qDBusRegisterMetaType<TransientAux>();
            qDBusRegisterMetaType<TransientAuxList>();
            qDBusRegisterMetaType<ExecCommand>();
            qDBusRegisterMetaType<ExecCommandList>();
        }
    }
```

#### AUTO 


```{c}
auto futureWatcher = new QFutureWatcher<QString>(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { slotStatResult(); }
```

#### LAMBDA EXPRESSION 


```{c}
[d]() {
                d->slotStart();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QTreeWidgetItem *item : selectedItems) {
        nextItem = mUi.policyTreeWidget->itemBelow(item);
        if (!nextItem)
            nextItem = mUi.policyTreeWidget->itemAbove(item);

        mDomainPolicyMap.remove(item->text(0));
        delete item;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QModelIndex &index) {
        d->_k_placeClicked(index);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&menu](QAction *action) {
        if (action) { // silence warning when adding null action
            menu.addAction(action);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool allow) { d->slotToggleAllowExpansion(allow); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const ItemInUseChange &i : itemsToChange) {
        emitRedirections(QUrl(i.oldUrl), QUrl(i.newUrl));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &item : items) {
        bool isLocal = false;
        const QUrl url = item.mostLocalUrl(&isLocal);
        m_isLocal = m_isLocal && isLocal;
        m_supportsReading = m_supportsReading && KProtocolManager::supportsReading(url);
        m_supportsDeleting = m_supportsDeleting && KProtocolManager::supportsDeleting(url);
        m_supportsWriting = m_supportsWriting && KProtocolManager::supportsWriting(url) && item.isWritable();
        m_supportsMoving = m_supportsMoving && KProtocolManager::supportsMoving(url);

        // For local files we can do better: check if we have write permission in parent directory
        // TODO: if we knew about the parent KFileItem, we could even do that for remote protocols too
#ifndef Q_OS_WIN
        if (m_isLocal && (m_supportsDeleting || m_supportsMoving)) {
            const QString directory = url.adjusted(QUrl::RemoveFilename | QUrl::StripTrailingSlash).toLocalFile();
            if (parentDirInfo.filePath() != directory) {
                parentDirInfo.setFile(directory);
            }
            if (!parentDirInfo.isWritable()) {
                m_supportsDeleting = false;
                m_supportsMoving = false;
            }
        }
#else
        if (m_isLocal && m_supportsDeleting) {
            if (!QFileInfo(url.toLocalFile()).isWritable())
                m_supportsDeleting = false;
        }
#endif
        if (m_isDirectory && !item.isDir()) {
            m_isDirectory = false;
        }

        if (m_isFile && !item.isFile()) {
            m_isFile = false;
        }
    }
```

#### AUTO 


```{c}
const auto activeState = properties[QStringLiteral("ActiveState")].toString();
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &service : plugin_offers) {
        KPluginFactory *factory = KPluginLoader(service.fileName()).factory();
        if (factory) {
            KIO::DndPopupMenuPlugin *plugin = factory->create<KIO::DndPopupMenuPlugin>();
            if (plugin) {
                const auto actions = plugin->setup(itemProps, m_destUrl);
                for (auto action : actions) {
                    action->setParent(popup);
                }
                m_pluginActions += actions;
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QPoint &pos) { openContextMenu(pos); }
```

#### RANGE FOR STATEMENT 


```{c}
for (SimpleJob *job : m_runningJobs) {
        Slave *slave = jobSlave(job);
        Q_ASSERT(slave);
        ret.append(slave);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : std::as_const(m_filesToRemove)) {
        QFile::remove(file);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &fileItem : std::as_const(initialItems)) {
        PreviewItem item;
        item.item = fileItem;

        const QString mimeType = item.item.mimetype();
        KPluginMetaData plugin;

        // look for protocol-specific thumbnail plugins first
        auto it = protocolMap.constFind(item.item.url().scheme());
        if (it != protocolMap.constEnd()) {
            plugin = it.value().value(mimeType);
        }

        if (!plugin.isValid()) {
            auto pluginIt = mimeMap.constFind(mimeType);
            if (pluginIt == mimeMap.constEnd()) {
                // check MIME type inheritance, resolve aliases
                QMimeDatabase db;
                const QMimeType mimeInfo = db.mimeTypeForName(mimeType);
                if (mimeInfo.isValid()) {
                    const QStringList parentMimeTypes = mimeInfo.allAncestors();
                    for (const QString &parentMimeType : parentMimeTypes) {
                        pluginIt = mimeMap.constFind(parentMimeType);
                        if (pluginIt != mimeMap.constEnd()) {
                            break;
                        }
                    }
                }

                // Check the wildcards last, see BUG 453480
                QString groupMimeType = mimeType;
                static const QRegularExpression expr(QStringLiteral("/.*"));
                groupMimeType.replace(expr, QStringLiteral("/*"));
                pluginIt = mimeMap.constFind(groupMimeType);
            }

            if (pluginIt != mimeMap.constEnd()) {
                plugin = *pluginIt;
            }
        }

        if (plugin.isValid()) {
            item.plugin = plugin;
            items.push_back(item);
            if (!bNeedCache && bSave && plugin.value(QStringLiteral("CacheThumbnail"), true)) {
                const QUrl url = fileItem.url();
                if (!url.isLocalFile() || !url.adjusted(QUrl::RemoveFilename).toLocalFile().startsWith(thumbRoot)) {
                    bNeedCache = true;
                }
            }
        } else {
            Q_EMIT q->failed(fileItem);
        }
    }
```

#### AUTO 


```{c}
const auto match = envVarExp.match(path);
```

#### LAMBDA EXPRESSION 


```{c}
[this, job]() {
        d->slotResult(job);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { slotToggleEditableButtonPressed(); }
```

#### AUTO 


```{c}
const auto mimeTypes = plugin.mimeTypes();
```

#### LAMBDA EXPRESSION 


```{c}
[this, statJob, messageWidget] {
                if (statJob->error()) {
                    messageWidget->setText(statJob->errorString());
                    messageWidget->animatedShow();
                    return;
                }

                KIO::highlightInFileManager({statJob->url()});
                properties->close();
            }
```

#### AUTO 


```{c}
auto err = tryOpen(destFile, _dest, O_WRONLY | O_TRUNC | O_CREAT, S_IRUSR | S_IWUSR, errno)
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &supportedMime : qAsConst(m_supportedMimeTypes)) {
                                if (mime.inherits(supportedMime)) {
                                    keep = true;
                                    break;
                                }
                            }
```

#### AUTO 


```{c}
const auto url = this->url(path);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : urls) {
            KIO::StatJob *job = KIO::statDetails(url, KIO::StatJob::SourceSide, KIO::StatBasic);

            if (!job->exec()) {
                Q_EMIT errorMessage(i18nc("Placeholder is error message", "Could not add to the Places panel: %1", job->errorString()));
                continue;
            }

            KFileItem item(job->statResult(), url, true /*delayed mime types*/);

            if (!item.isDir()) {
                Q_EMIT errorMessage(i18n("Only folders can be added to the Places panel."));
                continue;
            }

            KBookmark bookmark = KFilePlacesItem::createBookmark(d->bookmarkManager, item.text(), url, KIO::iconNameForUrl(url));

            group.moveBookmark(bookmark, afterBookmark);
            afterBookmark = bookmark;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QSslCertificate &cert : certificateChain) {
        QString name;
        static const QSslCertificate::SubjectInfo si[] = {
            QSslCertificate::CommonName,
            QSslCertificate::Organization,
            QSslCertificate::OrganizationalUnitName
        };
        for (int j = 0; j < 3 && name.isEmpty(); j++)
        {
            name = cert.subjectInfo(si[j]).join(QLatin1String(", "));
        }
        d->ui.certSelector->addItem(name);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SearchProvider *provider : qAsConst(m_providers)) {
            if (provider != m_provider && provider->keys().contains(shorthand)) {
                contenders.insert(shorthand, provider);
                break;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                slotIODeviceClosed();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (QFile::Permission perm : permissionsCheck) {
        points += info.permission(perm) ? 1 : 0;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](ulong speed){ slotSpeed(speed);}
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        const int errCode = job->error();
        if (errCode) {
            // ERR_NO_CONTENT is not an error, but an indication no further
            // actions needs to be taken.
            if (errCode != KIO::ERR_NO_CONTENT) {
                q->setError(errCode);
                q->setErrorText(KIO::buildErrorString(errCode, job->errorText()));
            }
            q->emitResult();
            return;
        }
        if (m_followRedirections) { // Update our URL in case of a redirection
            m_url = job->url();
        }

        const KIO::UDSEntry entry = job->statResult();

        const QString localPath = entry.stringValue(KIO::UDSEntry::UDS_LOCAL_PATH);
        if (!localPath.isEmpty()) {
            m_url = QUrl::fromLocalFile(localPath);
        }

        // mimetype already known? (e.g. print:/manager)
        m_mimeTypeName = entry.stringValue(KIO::UDSEntry::UDS_MIME_TYPE);
        if (!m_mimeTypeName.isEmpty()) {
            runUrlWithMimeType();
            return;
        }

        if (entry.isDir()) {
            m_mimeTypeName = QStringLiteral("inode/directory");
            runUrlWithMimeType();
        } else { // it's a file
            // Start the timer. Once we get the timer event this
            // protocol server is back in the pool and we can reuse it.
            // This gives better performance than starting a new slave
            QTimer::singleShot(0, q, [this] { scanFileWithGet(); });
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QPoint &pos) {
        openContextMenu(pos);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QTreeWidgetItem *item : selectedItems) {
        nextItem = mUi.policyTreeWidget->itemBelow (item);
        if (!nextItem)
            nextItem = mUi.policyTreeWidget->itemAbove (item);

        mDomainPolicyMap.remove (item->text(0));
        delete item;
    }
```

#### AUTO 


```{c}
auto &opQueue = d->m_current.m_opQueue;
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        m_statRunning = false;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : qAsConst(deletedSubdirs)) {
        // in case of a dir, check if we have any known children, there's much to do in that case
        // (stopping jobs, removing dirs from cache etc.)
        deleteDir(url);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, button](const QUrl &destination, QDropEvent *event) {
                               dropUrls(destination, event, button);
                           }
```

#### AUTO 


```{c}
auto *askUserActionInterface = KIO::delegateExtension<KIO::AskUserActionInterface *>(q);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->slotCanceled();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &entry : entries) {
        const QString name = entry.stringValue(KIO::UDSEntry::UDS_NAME);

        Q_ASSERT(!name.isEmpty());
        if (name.isEmpty()) {
            continue;
        }

        if (name == QLatin1Char('.')) {
            Q_ASSERT(dir->rootItem.isNull());
            // Try to reuse an existing KFileItem (if we listed the parent dir)
            // rather than creating a new one. There are many reasons:
            // 1) renames and permission changes to the item would have to emit the signals
            // twice, otherwise, so that both views manage to recognize the item.
            // 2) with kio_ftp we can only know that something is a symlink when
            // listing the parent, so prefer that item, which has more info.
            // Note that it gives a funky name() to the root item, rather than "." ;)
            dir->rootItem = itemForUrl(url);
            if (dir->rootItem.isNull()) {
                dir->rootItem = KFileItem(entry, url, delayedMimeTypes, true);
            }

            for (KCoreDirLister *kdl : listers) {
                if (kdl->d->rootFileItem.isNull() && kdl->d->url == url) {
                    kdl->d->rootFileItem = dir->rootItem;
                }
            }
        } else if (name != QLatin1String("..")) {
            KFileItem item(entry, url, delayedMimeTypes, true);

            // get the names of the files listed in ".hidden", if it exists and is a local file
            if (!dotHiddenChecked) {
                const QString localPath = item.localPath();
                if (!localPath.isEmpty()) {
                    const QString rootItemPath = QFileInfo(localPath).absolutePath();
                    cachedHidden = cachedDotHiddenForDir(rootItemPath);
                }
                dotHiddenChecked = true;
            }

            // hide file if listed in ".hidden"
            if (cachedHidden && cachedHidden->listedFiles.find(name) != cachedHidden->listedFiles.cend()) {
                item.setHidden();
            }

            qCDebug(KIO_CORE_DIRLISTER) << "Adding item: " << item.url();
            newItems.append(item);
        }
    }
```

#### AUTO 


```{c}
auto r_itEnd = m_stdIconSizes.crend();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QSslCertificate &cert : certificateChain) {
        QString name;
        static const QSslCertificate::SubjectInfo si[] = {QSslCertificate::CommonName, QSslCertificate::Organization, QSslCertificate::OrganizationalUnitName};
        for (int j = 0; j < 3 && name.isEmpty(); j++) {
            name = cert.subjectInfo(si[j]).join(QLatin1String(", "));
        }
        d->ui.certSelector->addItem(name);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&] {
        QVERIFY(QFile(dst_dir).setPermissions(QFile::Permissions(QFile::ReadOwner | QFile::WriteOwner | QFile::ExeOwner)));
        QVERIFY(QDir(dst_dir).removeRecursively());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Request *request : qAsConst(m_authPending)) {
        if (request->key != key) {
            continue;
        }

        if (info.verifyPath) {
            const QString path1 (request->info.url.path().left(info.url.path().indexOf(QLatin1Char('/'))+1));
            if (!path2.startsWith(path1)) {
                continue;
            }
        }

        return true;
    }
```

#### AUTO 


```{c}
const auto &mimeType
```

#### RANGE FOR STATEMENT 


```{c}
for (Slave *slave : list) {
            slave->send(CMD_REPARSECONFIGURATION);
            slave->resetHost();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KIO::Job *job, const KIO::UDSEntryList &list) {
                        gotEntries(job, list);
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QHostAddress &address : info.addresses()) {
                if (isSpecialAddress(address)) {
                    continue;
                }

                if (address.isInSubnet(subnet)) {
                    isInSubNet = true;
                    break;
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[&] {
        QFile(inaccessible).setPermissions(QFile::Permissions(QFile::ReadOwner | QFile::WriteOwner | QFile::ExeOwner));

        qDebug() << "Cleaning up" << src_dir << "and" << dst_dir;
        KIO::DeleteJob *deljob1 = KIO::del(QUrl::fromLocalFile(src_dir), KIO::HideProgressInfo);
        deljob1->setUiDelegate(nullptr); // no skip dialog, thanks
        const bool job1OK = deljob1->exec();
        QVERIFY(job1OK);

        KIO::DeleteJob *deljob2 = KIO::del(QUrl::fromLocalFile(dst_dir), KIO::HideProgressInfo);
        deljob2->setUiDelegate(nullptr); // no skip dialog, thanks
        const bool job2OK = deljob2->exec();
        QVERIFY(job2OK);

        qDebug() << "Result:" << job1OK << job2OK;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &id) {
                        _k_itemChanged(id);
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &mountDir : mountDirs) {
                const QString type = mountDir.section(QLatin1Char(':'), 0, 0);
                if (type.isEmpty()) {
                    continue;
                }

                Ptr gvfsmp(new KMountPoint);
                gvfsmp->d->mountedFrom = mp->d->mountedFrom;
                gvfsmp->d->mountPoint = mp->d->mountPoint + QLatin1Char('/') + mountDir;
                gvfsmp->d->mountType = type;
                result.append(gvfsmp);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[itemMimeType, item](const QString &i) {
        if (i == itemMimeType || i == QLatin1String("all/all")) {
            return true;
        }
        if (item.isFile() && (i == QLatin1String("allfiles") ||
            i == QLatin1String("all/allfiles") || i == QLatin1String("application/octet-stream"))) {
            return true;
        }

        if (item.currentMimeType().inherits(i)) {
            return true;
        }

        const int iSlashPos = i.indexOf(QLatin1Char(QLatin1Char('/')));
        Q_ASSERT(iSlashPos > 0);
        const QStringRef iSubType = i.midRef(iSlashPos+1);

        if (iSubType == QLatin1String("*")) {
            const int itemSlashPos = itemMimeType.indexOf(QLatin1Char('/'));
            Q_ASSERT(itemSlashPos > 0);
            const QStringRef iTopLevelType = i.midRef(0, iSlashPos);
            const QStringRef itemTopLevelType = itemMimeType.midRef(0, itemSlashPos);

            return itemTopLevelType == iTopLevelType;
        }
        return false;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (SearchProvider *provider : providers) {
        if (!provider->isDirty()) {
            continue;
        }

        KConfig _service(path + provider->desktopEntryName() + QLatin1String(".desktop"), KConfig::SimpleConfig);
        KConfigGroup service(&_service, "Desktop Entry");
        service.writeEntry("Type", "Service");
        service.writeEntry("Name", provider->name());
        service.writeEntry("Query", provider->query());
        service.writeEntry("Keys", provider->keys());
        service.writeEntry("Charset", provider->charset());
        service.writeEntry("Hidden", false); // we might be overwriting a hidden entry
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QSslCertificate &cert : std::as_const(certs)) {
        const QByteArray digest = cert.digest().toHex();
        if (!group.hasKey(digest.constData())) {
            defaultCaCertificates += cert;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &item : items) {
        if (!node) { // don't lookup the first item twice
            url = item.url();
            node = nodeForUrl(url);
            if (!node) {
                qCWarning(category) << "No node found for item that was just removed:" << url;
                continue;
            }
            if (!node->parent()) {
                // The root node has been deleted, but it was not first in the list 'items'.
                // see https://bugs.kde.org/show_bug.cgi?id=196695
                return;
            }
        }
        rowNumbers.setBit(node->rowNumber(), 1); // O(n)
        removeFromNodeHash(node, url);
        node = nullptr;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        d->m_delegate->stopPollingFreeSpace();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : qAsConst(files)) {
        // qDebug() << file;
        if (file[0] != QLatin1Char('.')) {
            KNewFileMenuSingleton::Entry e;
            e.filePath = file;
            e.entryType = KNewFileMenuSingleton::Unknown; // not parsed yet

            // Put Directory first in the list (a bit hacky),
            // and TextFile before others because it's the most used one.
            // This also sorts by user-visible name.
            // The rest of the re-ordering is done in fillMenu.
            const KDesktopFile config(file);
            QString url = config.desktopGroup().readEntry("URL");
            QString key = config.desktopGroup().readEntry("Name");
            if (file.endsWith(QLatin1String("Directory.desktop"))) {
                key.prepend(QLatin1Char('0'));
            } else if (file.startsWith(QDir::homePath())) {
                key.prepend(QLatin1Char('1'));
            } else if (file.endsWith(QLatin1String("TextFile.desktop"))) {
                key.prepend(QLatin1Char('2'));
            } else {
                key.prepend(QLatin1Char('3'));
            }
            EntryWithName en = {key, e};
            if (ulist.contains(url)) {
                ulist.remove(url);
            }
            ulist.insert(url, en);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Field &field : storage) {
        stream << " " << nameOfUdsField(field.m_index) << "=";
        if (field.m_index & KIO::UDSEntry::UDS_STRING) {
            stream << field.m_str;
        } else if (field.m_index & KIO::UDSEntry::UDS_NUMBER) {
            stream << field.m_long;
        } else {
            Q_ASSERT_X(false, "KIO::UDSEntry", "Found a field with an invalid type");
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool show) {
        d->slotToggleHidden(show);
    }
```

#### AUTO 


```{c}
auto &item
```

#### AUTO 


```{c}
auto addApplicationTag = [&output, desktopEntryName, currentTimestamp]() {
        output.writeEmptyElement(applicationBookmarkTag);
        output.writeAttribute(nameAttribute, desktopEntryName);
        auto service = KService::serviceByDesktopName(desktopEntryName);
        if (service) {
            output.writeAttribute(execAttribute, service->exec() + QLatin1String(" %u"));
        } else {
            output.writeAttribute(execAttribute, QCoreApplication::instance()->applicationName() + QLatin1String(" %u"));
        }
        output.writeAttribute(modifiedAttribute, currentTimestamp);
        output.writeAttribute(countAttribute, QStringLiteral("1"));
    };
```

#### AUTO 


```{c}
const auto name = line.mid(secondSpace + 1, line.length() - secondSpace - 2);
```

#### AUTO 


```{c}
const auto compFileEndingWithDot = m_completion->allMatches();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &udi : qAsConst(devices)) {
        bookmark = KFilePlacesItem::createDeviceBookmark(bookmarkManager, udi);
        if (!bookmark.isNull()) {
            KFilePlacesItem *item = new KFilePlacesItem(bookmarkManager, bookmark.address(), udi);
            connect(item, &KFilePlacesItem::itemChanged, q, [this](const QString &id) {
                _k_itemChanged(id);
            });
            // TODO: Update bookmark internal element
            items << item;
        }
    }
```

#### IF STATEMENT WITH INITIALIZER 


```{c}
if (const QDateTime dt = firstItem.time(KFileItem::ModificationTime); !dt.isNull()) {
            d->m_ui->modifiedTimeLabel->setText(locale.toString(dt, QLocale::LongFormat));
        } else {
            d->m_ui->modifiedTimeLabel->hide();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&](KJob *job) {
            loop.exit(job->error());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (unsigned char &b : bl->challenge) {
        b = QRandomGenerator::global()->bounded(0xff);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &item : qAsConst(m_dispatchedItems)) {
        KFileItemList::iterator begin = m_pendingItems.begin();
        KFileItemList::iterator end = m_pendingItems.end();
        for (KFileItemList::iterator it = begin; it != end; ++it) {
            if ((*it).url() == item.url()) {
                m_pendingItems.erase(it);
                break;
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const EntryInfo &a, const EntryInfo &b) {
        return a.key < b.key;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &arg) {
        return QUrl::fromUserInput(arg, QDir::currentPath());
    }
```

#### IF STATEMENT WITH INITIALIZER 


```{c}
if (auto [it, inserted] = pluginIds.insert(info.pluginName()); inserted) {
                    jsonMetaDataPlugins << info.toMetaData();
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->slotItemsChanged(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QSslError &err : std::as_const(d->sslErrors)) {
        message += err.errorString() + QLatin1Char('\n');
    }
```

#### AUTO 


```{c}
auto it = std::lower_bound(lstItems.cbegin(), lstItems.cend(), url);
```

#### AUTO 


```{c}
auto it = m_queuesByHostname.cbegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &lang : qAsConst(languageList)) {
        const QStringList langs = replacementCodes.readEntry(lang, QStringList());
        if (langs.isEmpty()) {
            languageListFinal += lang;
        } else {
            languageListFinal += langs;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KSslError &error : errors) {
        if (!isErrorIgnored(error.error())) {
            ret.append(error);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto button : std::as_const(m_navButtons)) {
            if (button->geometry().contains(p)) {
                const auto url = button->url();
                QAction *openInTab = popup->addAction(QIcon::fromTheme(QStringLiteral("tab-new")), i18n("Open %1 in tab", button->text()));
                q->connect(openInTab, &QAction::triggered, q, [this, url]() {
                    Q_EMIT q->tabRequested(url);
                });
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &item : fileItems) {
            const KService::Ptr serv = preferredService(item.mimetype(), m_traderConstraint);
            const QString preferredServiceId = serv ? serv->storageId() : QString();
            if (preferredServiceId == serviceId) {
                serviceItems << item;
            }
        }
```

#### AUTO 


```{c}
const auto list = action->menu()->actions();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &statement : qAsConst(l)) {
                const int index = statement.indexOf('=');
                if (index <= 0) {
                    mediaAttribute = toQString(statement.mid(0, index));
                } else {
                    mediaAttribute = toQString(statement.mid(0, index));
                    mediaValue = toQString(statement.mid(index + 1));
                }
                mediaAttribute = mediaAttribute.trimmed();
                mediaValue = mediaValue.trimmed();

                bool quoted = false;
                if (mediaValue.startsWith(QLatin1Char('"'))) {
                    quoted = true;
                    mediaValue.remove(0, 1);
                }

                if (mediaValue.endsWith(QLatin1Char('"'))) {
                    mediaValue.chop(1);
                }

                qCDebug(KIO_HTTP) << "Encoding-type:" << mediaAttribute << "=" << mediaValue;

                if (mediaAttribute == QLatin1String("charset")) {
                    mediaValue = mediaValue.toLower();
                    m_request.cacheTag.charset = mediaValue;
                    setMetaData(QStringLiteral("charset"), mediaValue);
                } else {
                    setMetaData(QLatin1String("media-") + mediaAttribute, mediaValue);
                    if (quoted) {
                        setMetaData(QLatin1String("media-") + mediaAttribute + QLatin1String("-kio-quoted"), QStringLiteral("true"));
                    }
                }
            }
```

#### AUTO 


```{c}
auto checkFile = [](const QString &str) {
        QFileInfo info(str);
        return info.exists() && info.isFile() && info.isReadable();
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &errorMessage) {
        m_messageWidget->setText(errorMessage);
        m_messageWidget->animatedShow();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &fileName : list) {
            if (fileName == QLatin1Char('.') || fileName == QLatin1String("..")) {
                continue;
            }
            const QString filePath = filesDir + QLatin1Char('/') + fileName;
            if (!unremovableFiles.contains(filePath)) {
                qCWarning(KIO_TRASH) << "Removing orphaned file" << filePath;
                QFile::remove(filePath);
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QUrl &dirUrl) {
        d->_k_slotCompleted(dirUrl);
    }
```

#### AUTO 


```{c}
auto err = execWithElevatedPrivilege(UTIME, {path, qint64(utbuf.actime), qint64(utbuf.modtime)}, errno)
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QUrl &url) {
        d->urlEntered(url);
    }
```

#### AUTO 


```{c}
auto err = execWithElevatedPrivilege(SYMLINK, dest, target)
```

#### RANGE FOR STATEMENT 


```{c}
for (const QPair<int, int> be : tokenizer.value(key).beginEnd) {
            comparisonValues.append(QByteArray(buffer + be.first, be.second - be.first));
        }
```

#### AUTO 


```{c}
const auto startReply = m_manager->StartTransientUnit(
        m_serviceName,
        QStringLiteral("fail"), // mode defines what to do in the case of a name conflict, in this case, just do nothing
        {// Properties of the transient service unit
         {QStringLiteral("Type"), QStringLiteral("oneshot")},
         {QStringLiteral("Slice"), QStringLiteral("app.slice")},
         {QStringLiteral("Description"), m_description},
         {QStringLiteral("SourcePath"), m_desktopFilePath},
         {QStringLiteral("AddRef"), true}, // Asks systemd to avoid garbage collecting the service if it immediately crashes,
                                           // so we can be notified (see https://github.com/systemd/systemd/pull/3984)
         {QStringLiteral("Environment"), m_process->environment()},
         {QStringLiteral("WorkingDirectory"), m_process->workingDirectory()},
         {QStringLiteral("ExecStart"), QVariant::fromValue(ExecCommandList{{m_process->program().first(), m_process->program(), false}})},
         {QStringLiteral("KillMode"), QStringLiteral("process")}},
        {} // aux is currently unused and should be passed as empty array.
    );
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job, ulong _percent) {
        slotPercent(job, _percent);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &trashPath: qAsConst(m_trashDirectories)) {

        TrashSizeCache trashSize(trashPath);
        TrashSizeCache::SizeAndModTime res = trashSize.calculateSizeAndLatestModDate();
        size += res.size;

        // Find latest modification date
        if (res.mtime > latestModifiedDate) {
            latestModifiedDate = res.mtime;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QDBusPendingCallWatcher *watcher) {
        watcher->deleteLater();
        if (watcher->isError()) {
            Q_EMIT error(watcher->error().message());
            terminateStartupNotification();
            m_finished = true;
            deleteLater();
            return;
        }
        auto call = QDBusConnection::sessionBus().interface()->asyncCall(QStringLiteral("GetConnectionUnixProcessID"), m_desktopName);
        auto pidWatcher = new QDBusPendingCallWatcher(call, this);
        connect(pidWatcher, &QDBusPendingCallWatcher::finished, this, [this](QDBusPendingCallWatcher *watcher) {
            m_finished = true;
            QDBusPendingReply<uint> reply = *watcher;
            if (reply.isError()) {
                Q_EMIT error(watcher->error().message());
                terminateStartupNotification();
            } else {
                Q_EMIT processStarted(reply.value());
            }
            deleteLater();
        });
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString& attrName, const QString& value, const QString& fileName) {
                return QStringList{QLatin1String("-w"), attrName, value, fileName};
            }
```

#### AUTO 


```{c}
auto job = KIO::copy({QUrl::fromLocalFile(QFINDTESTDATA("ftp/testCopy1"))}, inaccessibleUrl, KIO::Resume);
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job, qulonglong processedSize) {
        slotProcessedSize(job, processedSize);
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr int s_maxRecentDirs = 10;
```

#### AUTO 


```{c}
const auto acl1 = list.at(0);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QModelIndex &index) {
        d->_k_placeEntered(index);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &match : *matches) {
        QString &matchString = match.value();
        if (!matchString.isNull()) {
            if (matchString.endsWith(QLatin1Char('/'))) {
                d->quoteText(&matchString, false, true); // don't quote trailing '/'
            } else {
                d->quoteText(&matchString, false, false); // quote the whole text
            }

            matchString.prepend(d->m_text_start);
        }
    }
```

#### AUTO 


```{c}
auto undo()
{
    Future<bool> dummy;

    QObject::connect(Fum, &KIO::FileUndoManager::undoJobFinished, Fum, [dummy]() mutable {
        dummy.succeed("undo", true);
    });

    Fum->undo();

    return dummy;
}
```

#### AUTO 


```{c}
auto chmodDirs = [=]() {
        if (dirs.isEmpty()) {
            setDirty(false);
            Q_EMIT changesApplied();
            return;
        }

        auto *dirsJob = KIO::chmod(dirs, orDirPermissions, ~andDirPermissions, owner, group, recursive);
        processACLChanges(dirsJob);

        connect(dirsJob, &KJob::result, this, [this, dirsJob]() {
            if (dirsJob->error()) {
                dirsJob->uiDelegate()->showErrorMessage();
            }

            setDirty(false);
            Q_EMIT changesApplied();
        });
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (auto item : qAsConst(items)) {
        QVERIFY(!item.isMimeTypeKnown());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QStringRef &header : headers) {
        // Do not allow Request line to be specified and ignore
        // the other HTTP headers.
        if (!header.contains(QLatin1Char(':')) ||
                header.startsWith(QLatin1String("host"), Qt::CaseInsensitive) ||
                header.startsWith(QLatin1String("proxy-authorization"), Qt::CaseInsensitive) ||
                header.startsWith(QLatin1String("via"), Qt::CaseInsensitive) ||
                header.startsWith(QLatin1String("depth"), Qt::CaseInsensitive)) {
            continue;
        }

        sanitizedHeaders += header + QLatin1String("\r\n");
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const KFileItem &item) {
        d->fileHighlighted(item);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        m_autoResizeItems = true;
        adaptItemSize();
        writeConfig();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->slotDetailsView();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &[oldItem, newItem] : items) {
        Q_ASSERT(!oldItem.isNull());
        Q_ASSERT(!newItem.isNull());
        const QUrl oldUrl = oldItem.url();
        const QUrl newUrl = newItem.url();
        KDirModelNode *node = nodeForUrl(oldUrl); // O(n); maybe we could look up to the parent only once
        // qDebug() << "in model for" << m_dirLister->url() << ":" << oldUrl << "->" << newUrl << "node=" << node;
        if (!node) { // not found [can happen when renaming a dir, redirection was emitted already]
            continue;
        }
        if (node != m_rootNode) { // we never set an item in the rootnode, we use m_dirLister->rootItem instead.
            bool hasNewNode = false;
            // A file became directory (well, it was overwritten)
            if (oldItem.isDir() != newItem.isDir()) {
                // qDebug() << "DIR/FILE STATUS CHANGE";
                const int r = node->rowNumber();
                removeFromNodeHash(node, oldUrl);
                KDirModelDirNode *dirNode = node->parent();
                delete dirNode->m_childNodes.takeAt(r); // i.e. "delete node"
                node = newItem.isDir() ? new KDirModelDirNode(dirNode, newItem) : new KDirModelNode(dirNode, newItem);
                dirNode->m_childNodes.insert(r, node); // same position!
                hasNewNode = true;
            } else {
                node->setItem(newItem);
            }

            if (oldUrl != newUrl || hasNewNode) {
                // What if a renamed dir had children? -> kdirlister takes care of emitting for each item
                // qDebug() << "Renaming" << oldUrl << "to" << newUrl << "in node hash";
                m_nodeHash.remove(cleanupUrl(oldUrl));
                m_nodeHash.insert(cleanupUrl(newUrl), node);
            }
            // MIME type changed -> forget cached icon (e.g. from "cut", #164185 comment #13)
            if (oldItem.determineMimeType().name() != newItem.determineMimeType().name()) {
                node->setPreview(QIcon());
            }

            const QModelIndex index = indexForNode(node);
            if (!topLeft.isValid() || index.row() < topLeft.row()) {
                topLeft = index;
            }
            if (!bottomRight.isValid() || index.row() > bottomRight.row()) {
                bottomRight = index;
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QUrl &dirUrl, const KFileItemList &items) {
        d->_k_slotNewItems(dirUrl, items);
    }
```

#### AUTO 


```{c}
auto list = spyRenamed.takeFirst();
```

#### AUTO 


```{c}
auto dialogFinished = [this](bool shouldExecute) {
            if (shouldExecute) {
                executeCommand();
            } else {
                openInPreferredApp();
            }
        };
```

#### AUTO 


```{c}
const auto manager = new systemd1::Manager(systemdService, systemdPath, QDBusConnection::sessionBus(), this);
```

#### AUTO 


```{c}
auto *subjob = new KIO::CommandLauncherJob(d->m_fullCommand, this);
```

#### AUTO 


```{c}
const auto dest = arg2.toUrl();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Solid::Device &device : lst) {
        QString topdir = device.as<Solid::StorageAccess>()->filePath();
        QString trashDir = trashForMountPoint(topdir, false);
        if (!trashDir.isEmpty()) {
            // OK, trashDir is a valid trash directory. Ensure it's registered.
            int trashId = idForTrashDirectory(trashDir);
            if (trashId == -1) {
                // new trash dir found, register it
#ifdef Q_OS_OSX
                trashId = idForMountPoint(topdir);
#else
                trashId = idForDevice(device);
#endif
                if (trashId == -1) {
                    continue;
                }
                m_trashDirectories.insert(trashId, trashDir);
                //qCDebug(KIO_TRASH) << "found" << trashDir << "gave it id" << trashId;
                if (!topdir.endsWith(QLatin1Char('/'))) {
                    topdir += QLatin1Char('/');
                }
                m_topDirectories.insert(trashId, topdir);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &dir : qAsConst(lstDirs)) {
        const QList<KFileItem> *itemList = kDirListerCache()->itemsForDir(dir);
        if (!itemList) {
            continue;
        }

        for (const KFileItem &item : *itemList) {
            if (isItemVisible(item) && q->matchesMimeFilter(item)) {
                oldVisibleItems.insert(item.name());
            }
        }
    }
```

#### AUTO 


```{c}
const auto destFileSystem = KFileSystemType::fileSystemType(m_globalDest.toLocalFile());
```

#### LAMBDA EXPRESSION 


```{c}
[u, &urls](const QString &partial_name)
    {
        if (partial_name.trimmed().isEmpty()) {
            return;
        }

        // We have to use setPath here, so that something like "test#file"
        // isn't interpreted to have path "test" and fragment "file".
        QUrl partial_url;
        partial_url.setPath(partial_name);

        // This returns QUrl(partial_name) for absolute URLs.
        // Otherwise, returns the concatenated url.
        const QUrl finalUrl = u.resolved(partial_url);

        if (finalUrl.isValid()) {
            urls.append(finalUrl);
        } else {
            // This can happen in the first quote! (ex: ' "something here"')
            qCDebug(KIO_KFILEWIDGETS_FW) << "Discarding Invalid" << finalUrl;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const AuthInfoContainer *current : *authList) {
            qCDebug(category) << "Evaluating: " << current->info.url.scheme() << current->info.url.host() << current->info.username;
            if (current->info.url.scheme() == protocol && current->info.url.host() == host && (current->info.username == user || user.isEmpty())) {
                qCDebug(category) << "Removing this entry";
                removeAuthInfoItem(dictIterator.key(), current->info);
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QUrl &oldUrl, const QUrl &newUrl){d->_k_slotRedirection(oldUrl, newUrl);}
```

#### AUTO 


```{c}
const auto jsonPlugins = KPluginLoader::findPlugins(QStringLiteral("kf5/kfileitemaction"), [&db, commonMimeType](const KPluginMetaData &metaData) {
        if (!metaData.serviceTypes().contains(QLatin1String("KFileItemAction/Plugin"))) {
            return false;
        }

        auto mimeType = db.mimeTypeForName(commonMimeType);
        const QStringList list = metaData.mimeTypes();
        return std::any_of(list.constBegin(), list.constEnd(), [mimeType](const QString &supportedMimeType) {
            return mimeType.inherits(supportedMimeType);
        });
    });
```

#### RANGE FOR STATEMENT 


```{c}
for (KCoreDirLister *kdl : holders) {
                kdl->jobStarted(job);
                emit kdl->started(dir);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[statJob, parentUrl, url, this]() {
            if (!statJob->error()) {
                const KIO::UDSEntry entry = statJob->statResult();
                KFileItem visibleRootItem(entry, url);
                visibleRootItem.setName(url.path() == QLatin1String("/") ? QStringLiteral("/") : url.fileName());
                d->_k_slotNewItems(parentUrl, QList<KFileItem>{visibleRootItem});
                Q_ASSERT(d->m_rootNode->m_childNodes.count() == 1);
                expandToUrl(url);
            } else {
                qWarning() << statJob->errorString();
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QModelIndex &index) { d->_k_placeLeft(index); }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        Q_EMIT applied();
        Q_EMIT propertiesClosed();
        deleteLater(); // Somewhat like Qt::WA_DeleteOnClose would do.
        KPageDialog::accept();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        if (!m_triggered) {
            q->setError(KIO::ERR_USER_CANCELED);
            q->emitResult();
        }
    }
```

#### AUTO 


```{c}
static const auto systemdService = QStringLiteral("org.freedesktop.systemd1");
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &fileItem : std::as_const(initialItems)) {
        PreviewItem item;
        item.item = fileItem;

        const QString mimeType = item.item.mimetype();
        KPluginMetaData plugin;

        // look for protocol-specific thumbnail plugins first
        auto it = protocolMap.constFind(item.item.url().scheme());
        if (it != protocolMap.constEnd()) {
            plugin = it.value().value(mimeType);
        }

        if (!plugin.isValid()) {
            auto pluginIt = mimeMap.constFind(mimeType);
            if (pluginIt == mimeMap.constEnd()) {
                QString groupMimeType = mimeType;
                groupMimeType.replace(QRegularExpression(QStringLiteral("/.*")), QStringLiteral("/*"));
                pluginIt = mimeMap.constFind(groupMimeType);

                if (pluginIt == mimeMap.constEnd()) {
                    QMimeDatabase db;
                    // check MIME type inheritance, resolve aliases
                    const QMimeType mimeInfo = db.mimeTypeForName(mimeType);
                    if (mimeInfo.isValid()) {
                        const QStringList parentMimeTypes = mimeInfo.allAncestors();
                        for (const QString &parentMimeType : parentMimeTypes) {
                            pluginIt = mimeMap.constFind(parentMimeType);
                            if (pluginIt != mimeMap.constEnd()) {
                                break;
                            }
                        }
                    }
                }
            }

            if (pluginIt != mimeMap.constEnd()) {
                plugin = *pluginIt;
            }
        }

        if (plugin.isValid()) {
            item.plugin = plugin;
            items.push_back(item);
            if (!bNeedCache && bSave && plugin.value(QStringLiteral("CacheThumbnail"), true)) {
                const QUrl url = fileItem.url();
                if (!url.isLocalFile() || !url.adjusted(QUrl::RemoveFilename).toLocalFile().startsWith(thumbRoot)) {
                    bNeedCache = true;
                }
            }
        } else {
            Q_EMIT q->failed(fileItem);
        }
    }
```

#### AUTO 


```{c}
auto it = contenders.cbegin();
```

#### LAMBDA EXPRESSION 


```{c}
[this, dialog](int result){
        onDialogFinished(result, dialog->isDontAskAgainChecked());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &lang : qAsConst(languageListFinal)) {
        header += lang;
        if (prio < 10) {
            header += QL1S(";q=0.") + QString::number(prio);
        }
        // do not add cosmetic whitespace in here : it is less compatible (#220677)
        header += QL1C(',');
        if (prio > 1) {
            --prio;
        }
    }
```

#### AUTO 


```{c}
auto *statJob = qobject_cast<KIO::StatJob *>(kioJob)
```

#### RANGE FOR STATEMENT 


```{c}
for (Slave *slave : list) {
                slave->kill();
            }
```

#### AUTO 


```{c}
auto it = std::find_if(stdIconSizes.crbegin(), r_itEnd,
                 [currValue](KIconLoader::StdSizes size) { return size < currValue; });
```

#### AUTO 


```{c}
auto itEnd = stdIconSizes.cend();
```

#### AUTO 


```{c}
const auto &supportedMimeType
```

#### CONST EXPRESSION 


```{c}
constexpr auto details = KIO::StatBasic | KIO::StatResolveSymlink;
```

#### LAMBDA EXPRESSION 


```{c}
[=](RenameDialog_Result result, const QUrl &newUrl, KJob *parentJob) {
        Q_ASSERT(parentJob == q);
        // Only receive askUserRenameResult once per rename dialog
        QObject::disconnect(askUserActionInterface, &KIO::AskUserActionInterface::askUserRenameResult,
                            q, nullptr);

        if (m_reportTimer) {
            m_reportTimer->start(REPORT_TIMEOUT);
        }

        const QString existingDest = (*it).uDest.path();

        switch (result) {
        case Result_Cancel:
            q->setError(ERR_USER_CANCELED);
            q->emitResult();
            return;
        case Result_AutoRename:
            m_bAutoRenameDirs = true;
        // fall through
            Q_FALLTHROUGH();
        case Result_Rename:
            renameDirectory(it, newUrl);
            break;
        case Result_AutoSkip:
            m_bAutoSkipDirs = true;
        // fall through
            Q_FALLTHROUGH();
        case Result_Skip:
            m_skipList.append(existingDest);
            skip((*it).uSource, true);
            // Move on to next dir
            dirs.erase(it);
            ++m_processedDirs;
            break;
        case Result_Overwrite:
            m_overwriteList.insert(existingDest);
            Q_EMIT q->copyingDone(q, (*it).uSource, finalDestUrl((*it).uSource, (*it).uDest), (*it).mtime, true /* directory */, false /* renamed */);
            // Move on to next dir
            dirs.erase(it);
            ++m_processedDirs;
            break;
        case Result_OverwriteAll:
            m_bOverwriteAllDirs = true;
            Q_EMIT q->copyingDone(q, (*it).uSource, finalDestUrl((*it).uSource, (*it).uDest), (*it).mtime, true /* directory */, false /* renamed */);
            // Move on to next dir
            dirs.erase(it);
            ++m_processedDirs;
            break;
        default:
            Q_ASSERT(0);
        }
        state = STATE_CREATING_DIRS;
        createNextDir();
    }
```

#### AUTO 


```{c}
auto *dlg = new QDialog(d->m_frame);
```

#### AUTO 


```{c}
const auto headerName = QStringView(httpHeader).left(index);
```

#### AUTO 


```{c}
const auto ituend = itemsInUse.end();
```

#### LAMBDA EXPRESSION 


```{c}
[this](qreal value) {
        d->itemAppearUpdate(value);
    }
```

#### AUTO 


```{c}
auto it = lstItems.cbegin() ;
```

#### AUTO 


```{c}
auto *provider = new SearchProvider(filePath);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &item : *itemList) {
            if (isItemVisible(item) && m_parent->matchesMimeFilter(item)) {
                oldVisibleItems.insert(item.name());
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &s) {
            QUrl url;
            url.setScheme(s);
            return !KProtocolManager::supportsListing(url);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QUrl &dirUrl, const KFileItemList &items){d->_k_slotNewItems(dirUrl, items);}
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->slotShowProgress();
    }
```

#### AUTO 


```{c}
auto it = staticGroupCache.find(gid);
```

#### LAMBDA EXPRESSION 


```{c}
[this](ulong speed) {
            slotSpeed(speed);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QHostAddress &address : info.addresses()) {
            if (!isSpecialAddress(address) && isIPv4Address(address)) {
                hasResolvableIPv4Address = true;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &fileItem : std::as_const(initialItems)) {
        PreviewItem item;
        item.item = fileItem;

        const QString mimeType = item.item.mimetype();
        KPluginMetaData plugin;

        // look for protocol-specific thumbnail plugins first
        auto it = protocolMap.constFind(item.item.url().scheme());
        if (it != protocolMap.constEnd()) {
            plugin = it.value().value(mimeType);
        }

        if (!plugin.isValid()) {
            auto pluginIt = mimeMap.constFind(mimeType);
            if (pluginIt == mimeMap.constEnd()) {
                QString groupMimeType = mimeType;
                static const QRegularExpression expr(QStringLiteral("/.*"));
                groupMimeType.replace(expr, QStringLiteral("/*"));
                pluginIt = mimeMap.constFind(groupMimeType);

                if (pluginIt == mimeMap.constEnd()) {
                    QMimeDatabase db;
                    // check MIME type inheritance, resolve aliases
                    const QMimeType mimeInfo = db.mimeTypeForName(mimeType);
                    if (mimeInfo.isValid()) {
                        const QStringList parentMimeTypes = mimeInfo.allAncestors();
                        for (const QString &parentMimeType : parentMimeTypes) {
                            pluginIt = mimeMap.constFind(parentMimeType);
                            if (pluginIt != mimeMap.constEnd()) {
                                break;
                            }
                        }
                    }
                }
            }

            if (pluginIt != mimeMap.constEnd()) {
                plugin = *pluginIt;
            }
        }

        if (plugin.isValid()) {
            item.plugin = plugin;
            items.push_back(item);
            if (!bNeedCache && bSave && plugin.value(QStringLiteral("CacheThumbnail"), true)) {
                const QUrl url = fileItem.url();
                if (!url.isLocalFile() || !url.adjusted(QUrl::RemoveFilename).toLocalFile().startsWith(thumbRoot)) {
                    bNeedCache = true;
                }
            }
        } else {
            Q_EMIT q->failed(fileItem);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]{done(OpenFile);}
```

#### LAMBDA EXPRESSION 


```{c}
[&] {
        QVERIFY(QFile(sourceFile).remove());
        QVERIFY(QDir(dest).removeRecursively());
    }
```

#### AUTO 


```{c}
auto itu = itemsInUse.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto iconSize : iconSizes) {
        auto *act = new QAction(group);
        act->setCheckable(true);

        switch (iconSize) {
        case KIconLoader::SizeSmall:
            act->setText(i18nc("Small icon size", "Small (%1x%1)", KIconLoader::SizeSmall));
            break;
        case KIconLoader::SizeSmallMedium:
            act->setText(i18nc("Medium icon size", "Medium (%1x%1)", KIconLoader::SizeSmallMedium));
            break;
        case KIconLoader::SizeMedium:
            act->setText(i18nc("Large icon size", "Large (%1x%1)", KIconLoader::SizeMedium));
            break;
        case KIconLoader::SizeLarge:
            act->setText(i18nc("Huge icon size", "Huge (%1x%1)", KIconLoader::SizeLarge));
            break;
        default:
            break;
        }

        QObject::connect(act, &QAction::toggled, q, [this, iconSize]() {
            q->setIconSize(QSize(iconSize, iconSize));
        });

        if (!m_autoResizeItems) {
            act->setChecked(iconSize == m_delegate->iconSize());
        }

        submenu->addAction(act);
    }
```

#### AUTO 


```{c}
auto it = authList->begin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : qAsConst(deletedUrls)) {
        removedCount += clipboardUrls.removeAll(url);
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr int s_readBufferSize = 8192;
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->slotSortByName();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &text) {
        _k_slotTextChanged(text);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &lang : qAsConst(languageListFinal)) {
        header += lang;
        if (prio < 10) {
            header += QLatin1String(";q=0.") + QString::number(prio);
        }
        // do not add cosmetic whitespace in here : it is less compatible (#220677)
        header += QLatin1Char(',');
        if (prio > 1) {
            --prio;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const BasicOperation &op) {
        return (op.m_type == BasicOperation::Directory && !op.m_renamed)
                || (op.m_type == BasicOperation::Link && !d->m_current.isMoveCommand());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QUrl &url) { enterUrl(url); }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { _k_capacityBarFadeValueChanged(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &serviceDir : serviceDirs) {
        QDirIterator it(serviceDir);
        while (it.hasNext()) {
            const QString file = it.next();
            if (file.endsWith(QLatin1String(".protocol"))) {
                const QString prot = it.fileInfo().baseName();
                // add to cache, skip double entries
                if (!m_cache.contains(prot)) {
                    m_cache.insert(prot, new KProtocolInfoPrivate(file));
                }
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QDBusPendingCallWatcher *watcher) {
            m_finished = true;
            QDBusPendingReply<uint> reply = *watcher;
            if (reply.isError()) {
                Q_EMIT error(watcher->error().message());
                terminateStartupNotification();
            } else {
                Q_EMIT processStarted(reply.value());
            }
            deleteLater();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](){ qDebug() << "canceled"; }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString& attrName, const QString& value, const QString& fileName) {
                return QStringList{QLatin1String("user"), attrName, value, fileName};
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const KFileItem &item) { d->_k_slotFailed(item); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &protocol : std::as_const(protocols)) {
            // Add supported MIME type for this protocol
            QStringList &_ms = m_remoteProtocolPlugins[protocol];
            const auto mimeTypes = plugin.mimeTypes();
            for (const QString &_m : mimeTypes) {
                protocolMap[protocol].insert(_m, plugin);
                if (!_ms.contains(_m)) {
                    _ms.append(_m);
                }
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->slotOpenFileManager(); }
```

#### AUTO 


```{c}
auto it = std::find_if(cbegin(), cend(), [&url](const KFileItem &item) {
        return item.url() == url;
    });
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->slotIconsView();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](bool result) {
        if (result) {
            QString errorString;
            if (untrustedProgramHandler->setExecuteBit(filePath, errorString)) {
                executeCommand();
            } else {
                q->setError(KJob::UserDefinedError);
                q->setErrorText(i18n("Unable to make file \"%1\" executable.\n%2.", filePath, errorString));
                q->emitResult();
            }
        } else {
            q->setError(KIO::ERR_USER_CANCELED);
            q->emitResult();
        }
    }
```

#### AUTO 


```{c}
auto removeFunc = [](const QString &path) {
        return path.startsWith(QLatin1Char('.'));
    };
```

#### AUTO 


```{c}
auto i = parameters.constBegin();
```

#### AUTO 


```{c}
auto *parentWindow = window();
```

#### RANGE FOR STATEMENT 


```{c}
for (QLabel *label : labels) {
        label->setTextFormat(Qt::PlainText);
    }
```

#### IF STATEMENT WITH INITIALIZER 


```{c}
if (const QDateTime dt = firstItem.time(KFileItem::CreationTime); !dt.isNull()) {
            d->m_ui->createdTimeLabel->setText(locale.toString(dt, QLocale::LongFormat));
        } else {
            d->m_ui->createdTimeLabel->hide();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &entry : entryList) {
            const QString file = concatPaths(dir.path(), entry);
            files.append(file);
        }
```

#### AUTO 


```{c}
auto addString = [&](const char *token, const QString &str) {
        if (!str.isEmpty()) {
            arg += QLatin1String(token) + quote + str + quote;
        }
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (KUrlNavigatorButton *button : std::as_const(m_navButtons)) {
            button->removeEventFilter(q);
        }
```

#### AUTO 


```{c}
auto *processRunner = KProcessRunner::fromApplication(d->m_service, d->m_urls,
                                                          d->m_runFlags, d->m_suggestedFileName, d->m_startupId);
```

#### AUTO 


```{c}
auto begin = d->m_history.begin();
```

#### LAMBDA EXPRESSION 


```{c}
[this, subjob] {
            // NB: must go through emitResult otherwise we don't get correctly finished!
            // TODO KF6: maybe change the base to KCompositeJob so we can get rid of this nonesense
            if (subjob->error()) {
                setError(subjob->error());
                setErrorText(subjob->errorText());
            }
            emitResult();
        }
```

#### AUTO 


```{c}
auto job = KIO::copy({ QUrl::fromLocalFile(testCopy1) }, url, KIO::DefaultFlags);
```

#### AUTO 


```{c}
const auto host = sender->hostName();
```

#### AUTO 


```{c}
auto *copyJob = qobject_cast<KIO::CopyJob *>(job)
```

#### AUTO 


```{c}
auto end = d->m_history.end();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &path : templates) {
        dir.setPath(path);
        const QStringList &entryList(dir.entryList(QStringList() << QStringLiteral("*.desktop"), QDir::Files));
        Q_FOREACH (const QString &entry, entryList) {
            const QString file = dir.path() + QLatin1Char('/') + entry;
            files.append(file);
        }
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr int TTL = 300;
```

#### AUTO 


```{c}
auto window = KJobWidgets::window(q);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        slotNeedSubUrlData();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KIO::Job *job, KIO::UDSEntryList list) {
        slotEntries(job, list);
    }
```

#### AUTO 


```{c}
const auto result = ftpOpenConnection(LoginMode::Deferred);
```

#### LAMBDA EXPRESSION 


```{c}
[=](KIO::Job *, const QString &mimetype) {
        if (m_followRedirections) { // Update our URL in case of a redirection
            m_url = job->url();
        }
        if (mimetype.isEmpty()) {
            qCWarning(KIO_GUI) << "get() didn't emit a mimetype! Probably a kioslave bug, please check the implementation of" << m_url.scheme();
        }
        m_mimeTypeName = mimetype;

        // If the current mime-type is the default mime-type, then attempt to
        // determine the "real" mimetype from the file name (bug #279675)
        QMimeType mime = fixupMimeType(m_mimeTypeName, m_suggestedFileName.isEmpty() ? m_url.fileName() : m_suggestedFileName);
        if (mime.isValid() && mime.name() != m_mimeTypeName) {
            m_mimeTypeName = mime.name();
        }

        if (m_suggestedFileName.isEmpty()) {
            m_suggestedFileName = job->queryMetaData(QStringLiteral("content-disposition-filename"));
        }

        job->putOnHold();
        KIO::Scheduler::publishSlaveOnHold();
        runUrlWithMimeType();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : qAsConst(indexes)) {
        QUrl itemUrl = url(index);
        if (itemUrl.isValid()) {
            urls << itemUrl;
        }
        stream << index.row();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](int value) { d->slotIconSizeSliderMoved(value); }
```

#### AUTO 


```{c}
auto wqIt = m_waitQueue.begin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QSslError &err : qAsConst(ud->sslErrors)) {
        message.append(err.errorString() + QLatin1Char('\n'));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            slotFillTemplates();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& tag: tagsList) {
        bookmark = KFilePlacesItem::createTagBookmark(bookmarkManager, tag);
        if (!bookmark.isNull()) {
            KFilePlacesItem *item = new KFilePlacesItem(bookmarkManager,
                    bookmark.address(), tag);
            connect(item, &KFilePlacesItem::itemChanged,
                    q, [this](const QString &id) { _k_itemChanged(id); });
            items << item;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KIO::filesize_t size){ slotProcessedSize(size);}
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &pluginMetaData : qAsConst(plugins)) {
        const QString fileName = pluginMetaData.fileName().section(QLatin1Char('/'), -1);
        if (!pluginNames.contains(fileName)) {
            pluginNames << fileName;
            KPluginFactory *factory = qobject_cast<KPluginFactory *>(pluginMetaData.instantiate());
            if (factory) {
                KUriFilterPlugin *plugin = factory->create<KUriFilterPlugin>(nullptr);
                if (plugin) {
                    d->pluginList << plugin;
                }
            }
        }
    }
```

#### AUTO 


```{c}
auto* group = this->group(groupPath);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &dir : qAsConst(lstDirs)) {
        const QList<KFileItem> *itemList = kDirListerCache()->itemsForDir(dir);
        if (!itemList) {
            continue;
        }

        for (const KFileItem &item : *itemList) {
            if (isItemVisible(item) && m_parent->matchesMimeFilter(item)) {
                oldVisibleItems.insert(item.name());
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](SkipDialog_Result result, KJob *parentJob) {
                Q_ASSERT(parentJob == q);
                // Only receive askUserSkipResult once per skip dialog
                QObject::disconnect(askUserActionInterface, skipSignal, q, nullptr);
                processFileRenameDialogResult(it, result, QUrl() /* no new url in skip */, QDateTime{});
            }
```

#### AUTO 


```{c}
auto it = std::find(devices.begin(), devices.end(), udi);
```

#### AUTO 


```{c}
auto job = KIO::copy({ QUrl::fromLocalFile(QFINDTESTDATA("ftp/testCopy2")) }, inaccessibleUrl, KIO::Resume);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QUrl &url) {
        d->slotDirectoryCreated(url);
    }
```

#### AUTO 


```{c}
auto teardown = std::unique_ptr<QAction>{placesModel->teardownActionForIndex(actionIndex)}
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &entry : buf) {
        // Form the complete url
        KFileItem item(entry, jobUrl, delayedMimeTypes, true);

        const QString name = item.name();
        Q_ASSERT(!name.isEmpty()); // A kioslave setting an empty UDS_NAME is utterly broken, fix the kioslave!

        // we duplicate the check for dotdot here, to avoid iterating over
        // all items again and checking in matchesFilter() that way.
        if (name.isEmpty() || name == QLatin1String("..")) {
            continue;
        }

        if (name == QLatin1Char('.')) {
            // if the update was started before finishing the original listing
            // there is no root item yet
            if (dir->rootItem.isNull()) {
                dir->rootItem = item;

                for (KCoreDirLister *kdl : listers) {
                    if (kdl->d->rootFileItem.isNull() && kdl->d->url == jobUrl) {
                        kdl->d->rootFileItem = dir->rootItem;
                    }
                }
            }
            continue;
        } else {
            // get the names of the files listed in ".hidden", if it exists and is a local file
            if (!dotHiddenChecked) {
                const QString localPath = item.localPath();
                if (!localPath.isEmpty()) {
                    const QString rootItemPath = QFileInfo(localPath).absolutePath();
                    cachedHidden = cachedDotHiddenForDir(rootItemPath);
                }
                dotHiddenChecked = true;
            }
        }

        // hide file if listed in ".hidden"
        if (cachedHidden && cachedHidden->listedFiles.find(name) != cachedHidden->listedFiles.cend()) {
            item.setHidden();
        }

        // Find this item
        FileItemHash::iterator fiit = fileItems.find(item.name());
        if (fiit != fileItems.end()) {
            const KFileItem tmp = fiit.value();
            auto pru_it = pendingRemoteUpdates.find(tmp);
            const bool inPendingRemoteUpdates = pru_it != pendingRemoteUpdates.end();

            // check if something changed for this file, using KFileItem::cmp()
            if (!tmp.cmp(item) || inPendingRemoteUpdates) {
                if (inPendingRemoteUpdates) {
                    pendingRemoteUpdates.erase(pru_it);
                }

                qCDebug(KIO_CORE_DIRLISTER) << "file changed:" << tmp.name();

                reinsert(item, tmp.url());
                for (KCoreDirLister *kdl : listers) {
                    kdl->d->addRefreshItem(jobUrl, tmp, item);
                }
            }
            // Seen, remove
            fileItems.erase(fiit);
        } else { // this is a new file
            qCDebug(KIO_CORE_DIRLISTER) << "new file:" << name;
            dir->insert(item);

            for (KCoreDirLister *kdl : listers) {
                kdl->d->addNewItem(jobUrl, item);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (SearchProvider *provider : providers)
  {
    if (defaultSearchEngine == provider->desktopEntryName())
      defaultProviderIndex = providers.size();
  }
```

#### AUTO 


```{c}
auto it = m_cutItemsCache.cbegin();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        KFilePlacesModel *placesModel = qobject_cast<KFilePlacesModel *>(model());
        if (!placesModel) {
            return;
        }

        const auto actionIndex = d->m_watcher->hoveredActionIndex();
        if (placesModel->isTeardownAllowed(actionIndex)) {
            QString toolTipText;

            if (auto eject = std::unique_ptr<QAction>{placesModel->ejectActionForIndex(actionIndex)}) {
                toolTipText = eject->toolTip();
            } else if (auto teardown = std::unique_ptr<QAction>{placesModel->teardownActionForIndex(actionIndex)}) {
                toolTipText = teardown->toolTip();
            }

            if (!toolTipText.isEmpty()) {
                // TODO widget + rect
                QToolTip::showText(QCursor::pos(), toolTipText);
            }
        }
    }
```

#### AUTO 


```{c}
auto itu = itemsInUse.begin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &jsonMetadata : jsonPlugins) {
        // The plugin has been disabled
        if (!showGroup.readEntry(jsonMetadata.pluginId(), true)) {
            continue;
        }

        // The plugin also has a .desktop file and has already been added.
        if (addedPlugins.contains(jsonMetadata.pluginId())) {
            continue;
        }

        KPluginFactory *factory = KPluginLoader(jsonMetadata.fileName()).factory();
        if (!factory) {
            continue;
        }
        KAbstractFileItemActionPlugin* abstractPlugin = factory->create<KAbstractFileItemActionPlugin>();
        if (abstractPlugin) {
            abstractPlugin->setParent(this);
            auto actions = abstractPlugin->actions(d->m_props, d->m_parentWidget);
            itemCount += actions.count();
            mainMenu->addActions(actions);
            addedPlugins.append(jsonMetadata.pluginId());
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job, const QString &plain) { slotInfoMessage(job, plain); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const KFileItem &item) { d->fileHighlighted(item); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &fileName : files) {
        createTestFile(path + fileName);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &data : std::as_const(jsonMetaDataPlugins)) {
            pluginIds.insert(data.pluginId());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QAction *action : actionsList) {
            const QVariant userData = action->data();
            if (userData.isValid()) {
                actions |= userData.value<Qt::DropAction>();
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[q](KJob *, ulong percent) {
        if (percent > q->percent()) {
            q->setPercent(percent);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &filter : nameFilters) {
                if (filter == QLatin1Char('*')) {
                    return true;
                }

                const QMimeType mt = db.mimeTypeForFile(filter, QMimeDatabase::MatchExtension /*fast mode, no file contents exist*/);
                if (!mt.isValid()) {
                    continue;
                }
                const QString mime = mt.name();

                for (const QString &str : supported) {
                    // the "mimetypes" we get from the PreviewJob can be "image/*"
                    // so we need to check in wildcard mode
                    re.setPattern(QRegularExpression::wildcardToRegularExpression(str));
                    if (re.match(mime).hasMatch()) {
                        return true;
                    }
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[](const KUrlNavigatorButton *button) {
        return button->minimumWidth();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &key : provider->keys()) {
                    m_searchProvidersByKey.insert(key, provider);
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QModelIndex &index) {
        d->actionClicked(index);
    }
```

#### AUTO 


```{c}
auto itEnd = m_stdIconSizes.cend();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &dir : dirs) {
        KFileItemList deletedItems;

        const QList<KFileItem> *itemList = kDirListerCache()->itemsForDir(dir);
        if (!itemList) {
            continue;
        }

        auto kit = itemList->begin();
        const auto kend = itemList->end();
        for (; kit != kend; ++kit) {
            const KFileItem &item = *kit;
            const QString text = item.text();
            if (text == QLatin1Char('.') || text == QLatin1String("..")) {
                continue;
            }
            const bool wasVisible = oldVisibleItems.contains(item.name());
            const bool nowVisible = isItemVisible(item) && q->matchesMimeFilter(item);
            if (nowVisible && !wasVisible) {
                addNewItem(dir, item); // takes care of emitting newItem or itemsFilteredByMime
            } else if (!nowVisible && wasVisible) {
                deletedItems.append(*kit);
            }
        }
        if (!deletedItems.isEmpty()) {
            Q_EMIT q->itemsDeleted(deletedItems);
        }
        emitItems();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Solid::Device &device : lst) {
        QString topdir = device.as<Solid::StorageAccess>()->filePath();
        QString trashDir = trashForMountPoint(topdir, false);
        if (!trashDir.isEmpty()) {
            // OK, trashDir is a valid trash directory. Ensure it's registered.
            int trashId = idForTrashDirectory(trashDir);
            if (trashId == -1) {
                // new trash dir found, register it
#ifdef Q_OS_OSX
                trashId = idForMountPoint(topdir);
#else
                trashId = idForDevice(device);
#endif
                if (trashId == -1) {
                    continue;
                }

                insertTrashDir(trashId, trashDir, topdir);
            }
        }
    }
```

#### AUTO 


```{c}
auto dirIt = dirCache.constFind(QFile::encodeName(fileName));
```

#### AUTO 


```{c}
auto *processRunner =
                KProcessRunner::fromApplication(d->m_service, d->m_serviceEntryPath, {d->m_urls.at(i)}, d->m_runFlags, d->m_suggestedFileName, QByteArray{});
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        if (m_exited) {
            return;
        }
        qCDebug(KIO_GUI) << "Got PropertiesChanged signal:" << m_serviceName;
        // We need to look at the full list of properties rather than only those which changed
        auto reply = m_serviceProperties->GetAll(QString());
        connect(new QDBusPendingCallWatcher(reply, this), &QDBusPendingCallWatcher::finished, this, &SystemdProcessRunner::handleProperties);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            done(KIO::Result_ReplaceInvalidChars);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (SearchProvider *provider : providers) {
        if (defaultSearchEngine == provider->desktopEntryName()) {
            defaultProviderIndex = providers.indexOf(provider);
            break;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[bufferSize](qint64 pos, QFile &f, QByteArray &buffer) {
        auto ioresult = f.seek(pos);
        int bytesRead;
        if (ioresult) {
            bytesRead = f.read(buffer.data(), bufferSize);
            ioresult = bytesRead != -1;
        }
        if (!ioresult) {
            qCWarning(KIO_WIDGETS) << "Could not read file for comparison:" << f.fileName();
            return false;
        }
        return true;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QUrl &destination, QDropEvent *event) { dropUrls(destination, event); }
```

#### AUTO 


```{c}
auto pendingIt = pendingUpdates.cbegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const KMountPoint::Ptr &mp : mountPoints) {
        QString mountPoint = mp->mountPoint();
        QString device = mp->mountedFrom();
        // qDebug()<<"mountPoint :"<<mountPoint<<" device :"<<device<<" mp->mountType() :"<<mp->mountType();

        if ((mountPoint != QLatin1String("-")) && (mountPoint != QLatin1String("none")) && !mountPoint.isEmpty() && device != QLatin1String("none")) {
            devices.append(device + QLatin1String(" (") + mountPoint + QLatin1Char(')'));
            d->m_devicelist.append(device);
            d->mountpointlist.append(mountPoint);
        }
    }
```

#### AUTO 


```{c}
auto it = writableTopDirs.constBegin();
```

#### LAMBDA EXPRESSION 


```{c}
[](const KUriFilterPlugin *plugin) {
        return plugin->objectName();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        if (!QDesktopServices::openUrl(d->m_url)) {
            // Is this an actual error, or USER_CANCELED?
            setError(KJob::UserDefinedError);
            setErrorText(i18n("Failed to open %1", d->m_url.toDisplayString()));
        }
        emitResult();
    }
```

#### AUTO 


```{c}
const auto connectionResult = synchronousConnectToHost(host, port);
```

#### LAMBDA EXPRESSION 


```{c}
[q](KIO::filesize_t offset) {
        emit q->canResume(q, offset);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &s : qAsConst(sl)) {
        if (s == QLatin1String("Reject")) {
            isRejected = true;
            ignoredErrors.clear();
            break;
        }
        if (!d->stringToSslError.contains(s)) {
            continue;
        }
        ignoredErrors.append(d->stringToSslError.value(s));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KUrlNavigatorButton *button : qAsConst(d->m_navButtons)) {
            button->setActive(active);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&] {
        QDir(destDir).removeRecursively();
    }
```

#### AUTO 


```{c}
const auto permsTexts = permissionsTexts[static_cast<int>(d->pmode)];
```

#### LAMBDA EXPRESSION 


```{c}
[&db, commonMimeType](const KPluginMetaData& metaData) {
        if (!metaData.serviceTypes().contains(QLatin1String("KFileItemAction/Plugin"))) {
            return false;
        }

        auto mimeType = db.mimeTypeForName(commonMimeType);
        foreach (const auto& supportedMimeType, metaData.mimeTypes()) {
            if (mimeType.inherits(supportedMimeType)) {
                return true;
            }
        }

        return false;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KSslError &e : errors) {
        el.append(e.error());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &desktopFilePath : list) {
        dir.remove(desktopFilePath);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const UDSTestField &field : testCase) {
                uint uds = field.m_uds;
                stream << uds;

                if (uds & KIO::UDSEntry::UDS_STRING) {
                    stream << field.m_string;
                } else {
                    Q_ASSERT(uds & KIO::UDSEntry::UDS_NUMBER);
                    stream << field.m_long;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : qAsConst(m_dirsToUpdate)) {
            // qDebug() << "Notifying FilesAdded for " << url;
            org::kde::KDirNotify::emitFilesAdded(url);
        }
```

#### AUTO 


```{c}
auto filelight = KService::serviceByDesktopName(QStringLiteral("org.kde.filelight"))
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &item : items) {
        if (cutUrls.contains(item.url())) {
            const QModelIndex index = dirModel->indexForItem(item);
            const QVariant value = dirModel->data(index, Qt::DecorationRole);
            if (value.type() == QVariant::Icon) {
                const QIcon icon(qvariant_cast<QIcon>(value));
                const QSize actualSize = icon.actualSize(m_viewAdapter->iconSize());
                QPixmap pixmap = icon.pixmap(actualSize);

                const QHash<QUrl, QPixmap>::const_iterator cacheIt = m_cutItemsCache.constFind(item.url());
                if ((cacheIt == m_cutItemsCache.constEnd()) || (cacheIt->cacheKey() != pixmap.cacheKey())) {
                    pixmap = iconEffect->apply(pixmap, KIconLoader::Desktop, KIconLoader::DisabledState);
                    dirModel->setData(index, QIcon(pixmap), Qt::DecorationRole);

                    m_cutItemsCache.insert(item.url(), pixmap);
                }
            }
        }
    }
```

#### AUTO 


```{c}
const auto weekday = QStringView(value).left(index);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QModelIndex &idx, bool success) {
        d->storageSetupDone(idx, success);
    }
```

#### AUTO 


```{c}
const auto buttonsList = dialog->findChildren<QPushButton *>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &mimeType : servicesTypes) {
        if (mimeType.startsWith(xScheme)) {
            supportedProtocols << mimeType.mid(xScheme.size());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &fileItem : std::as_const(initialItems)) {
        PreviewItem item;
        item.item = fileItem;

        const QString mimeType = item.item.mimetype();
        KService::Ptr plugin(nullptr);

        // look for protocol-specific thumbnail plugins first
        auto it = protocolMap.constFind(item.item.url().scheme());
        if (it != protocolMap.constEnd()) {
            plugin = it.value().value(mimeType);
        }

        if (!plugin) {
            QMap<QString, KService::Ptr>::ConstIterator pluginIt = mimeMap.constFind(mimeType);
            if (pluginIt == mimeMap.constEnd()) {
                QString groupMimeType = mimeType;
                groupMimeType.replace(QRegularExpression(QStringLiteral("/.*")), QStringLiteral("/*"));
                pluginIt = mimeMap.constFind(groupMimeType);

                if (pluginIt == mimeMap.constEnd()) {
                    QMimeDatabase db;
                    // check MIME type inheritance, resolve aliases
                    const QMimeType mimeInfo = db.mimeTypeForName(mimeType);
                    if (mimeInfo.isValid()) {
                        const QStringList parentMimeTypes = mimeInfo.allAncestors();
                        for (const QString &parentMimeType : parentMimeTypes) {
                            pluginIt = mimeMap.constFind(parentMimeType);
                            if (pluginIt != mimeMap.constEnd()) {
                                break;
                            }
                        }
                    }
                }
            }

            if (pluginIt != mimeMap.constEnd()) {
                plugin = *pluginIt;
            }
        }

        if (plugin) {
            item.plugin = plugin;
            items.push_back(item);
            if (!bNeedCache && bSave && plugin->property(QStringLiteral("CacheThumbnail")).toBool()) {
                const QUrl url = fileItem.url();
                if (!url.isLocalFile() || !url.adjusted(QUrl::RemoveFilename).toLocalFile().startsWith(thumbRoot)) {
                    bNeedCache = true;
                }
            }
        } else {
            Q_EMIT q->failed(fileItem);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[prefKey](const KPluginMetaData &a, const KPluginMetaData &b) {
            return a.rawData().value(prefKey).toInt() > b.rawData().value(prefKey).toInt();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const KFileItem &item) { d->fileSelected(item); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QUrl &src) {
            return m_destUrl.matches(src.adjusted(QUrl::RemoveFilename), QUrl::StripTrailingSlash);
        }
```

#### AUTO 


```{c}
auto job = KIO::storedGet(url);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { _k_slotSymLink(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this, url](){
                    setCurrentItem(url);
                    QObject::disconnect(d->m_connection);
                }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &name, const QString &type) {
            QVariant::Type variantType = QVariant::nameToType(type.toLatin1().constData());
            // currently QVariant::Type and ExtraField::Type use the same subset of values, so we can just cast.
            return KProtocolInfo::ExtraField(name, static_cast<KProtocolInfo::ExtraField::Type>(variantType));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : indexList) {
        KFileItem item = d->dirModel->itemForIndex(index);
        if (!item.isNull()) {
            itemList.append(item);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &lang : std::as_const(langs)) {
            search.append(QStringLiteral("%1/%2/%3").arg(localDoc[id], lang, fname));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &item : group->items) {
            if (item.name == itemName) {
                return item;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&fileName](const KFileItem &item) {
        return item.name() == fileName;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QModelIndex &topLeft, const QModelIndex &bottomRight) {
            updateIcons(topLeft, bottomRight);
        }
```

#### AUTO 


```{c}
auto it = std::find_if(m_stdIconSizes.cbegin(), itEnd, [currValue](KIconLoader::StdSizes size) {
        return size > currValue;
    });
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &deletedUrl : qAsConst(affectedItems)) {
        // stop all jobs for deletedUrlStr
        DirectoryDataHash::iterator dit = directoryData.find(deletedUrl);
        if (dit != directoryData.end()) {
            // we need a copy because stop modifies the list
            const QList<KCoreDirLister *> listers = (*dit).listersCurrentlyListing;
            for (KCoreDirLister *kdl : listers) {
                stopListingUrl(kdl, deletedUrl);
            }
            // tell listers holding deletedUrl to forget about it
            // this will stop running updates for deletedUrl as well

            // we need a copy because forgetDirs modifies the list
            const QList<KCoreDirLister *> holders = (*dit).listersCurrentlyHolding;
            for (KCoreDirLister *kdl : holders) {
                // lister's root is the deleted item
                if (kdl->d->url == deletedUrl) {
                    // tell the view first. It might need the subdirs' items (which forgetDirs will delete)
                    if (!kdl->d->rootFileItem.isNull()) {
                        Q_EMIT kdl->itemsDeleted(KFileItemList{kdl->d->rootFileItem});
                    }
                    forgetDirs(kdl);
                    kdl->d->rootFileItem = KFileItem();
                } else {
                    const bool treeview = kdl->d->lstDirs.count() > 1;
                    if (!treeview) {
                        Q_EMIT kdl->clear();
                        kdl->d->lstDirs.clear();
                    } else {
                        kdl->d->lstDirs.removeAll(deletedUrl);
                    }

                    forgetDirs(kdl, deletedUrl, treeview);
                }
            }
        }

        // delete the entry for deletedUrl - should not be needed, it's in
        // items cached now
        int count = itemsInUse.remove(deletedUrl);
        Q_ASSERT(count == 0);
        Q_UNUSED(count); // keep gcc "unused variable" complaining quiet when in release mode
    }
```

#### LAMBDA EXPRESSION 


```{c}
[q, this](KJob *job, qulonglong processedSize) {
        if (job == m_copyJob) {
            m_bFileCopyInProgress = processedSize > 0;
        }
        q->setProcessedAmount(KJob::Bytes, processedSize);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&exec](const QString &terminalApp) {
            const bool found = !QStandardPaths::findExecutable(terminalApp).isEmpty();
            if (found) {
                exec = terminalApp;
            }
            return found;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QSslCertificate &cert : certs) {
        QByteArray digest = cert.digest();
        if (!digests.contains(digest)) {
            digests.insert(digest);
            ret.append(cert);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto index : m_places->groupIndexes(groupType)) {
            QCOMPARE(index.data(KFilePlacesModel::GroupHiddenRole).toBool(), groupShouldBeHidden);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(QObject *obj : QObjectList(m_placesMenu->children())) {
        delete qobject_cast<QMenu*>(obj); // Noop for nullptr
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KServiceAction &action : userServices) {
                if (showGroup.readEntry(action.name(), true) && !excludeList.contains(action.name())) {
                    list += action;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &s : sl) {
        QList<KSslError::Error> certErrors;
        const QStringList sl2 = s.split(QLatin1Char('\t'), QString::SkipEmptyParts);
        for (const QString &s2 : sl2) {
            bool didConvert;
            KSslError::Error error = static_cast<KSslError::Error>(s2.toInt(&didConvert));
            if (didConvert) {
                certErrors.append(error);
            }
        }
        ret.append(certErrors);
    }
```

#### AUTO 


```{c}
auto it = std::lower_bound(dirItem->lstItems.begin(), dirItem->lstItems.end(), url);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &parentMimeType : parentMimeTypes) {
            provider = m_previewProviders.value(parentMimeType);
            if (provider) {
                return provider;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &item : std::as_const(m_items)) {
        const QString itemMimeType = item.mimetype();
        // Determine if common MIME type among all items
        if (m_mimeType != itemMimeType) {
            m_mimeType.clear();
            const auto type = QStringView(itemMimeType).left(itemMimeType.indexOf(QLatin1Char('/')));
            if (m_mimeGroup != type) {
                m_mimeGroup.clear(); // MIME type groups are different as well!
            }
        }
    }
```

#### AUTO 


```{c}
const auto& item
```

#### AUTO 


```{c}
auto *filePropsPlugin = qobject_cast<KFilePropsPlugin *>(it)
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : urlList) {
            urls += QStringLiteral("\"%1\" ").arg(
                escapeDoubleQuotes(relativePathOrUrl(currUrl, url))
            );
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](qreal value) { d->_k_adaptItemsUpdate(value); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KIO::Job *job, const QByteArray &data) {
        slotSubUrlData(job, data);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &path : qAsConst(search)) {
        // qDebug() << "Looking for help in: " << path;

        QFileInfo info(path);
        if (info.exists() && info.isFile() && info.isReadable()) {
            return path;
        }

        if (path.endsWith(QLatin1String(".html"))) {
            const QString file = path.leftRef(path.lastIndexOf(QLatin1Char('/'))) + QLatin1String("/index.docbook");
            // qDebug() << "Looking for help in: " << file;
            info.setFile(file);
            if (info.exists() && info.isFile() && info.isReadable()) {
                return path;
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        slotRealFileOrDir();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KIO::Job *job, const KIO::UDSEntryList &list) {
        slotEntries(job, list);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &dir : urls) {
            QUrl aliasUrl(dir);
            aliasUrl.setPath(concatPaths(aliasUrl.path(), url.fileName()));
            handleFileDirty(aliasUrl);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QUrl &url) { slotRedirection(url); }
```

#### LAMBDA EXPRESSION 


```{c}
[&name](const QRegularExpression &filter) {
        return filter.match(name).hasMatch();
    }
```

#### AUTO 


```{c}
auto err = execWithElevatedPrivilege(RMDIR, _path)
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &entry : *s->templatesList) {
        ++idx;
        if (entry.entryType != KNewFileMenuSingleton::Unknown) {
            // There might be a .desktop for that one already, if it's a kdelnk
            // This assumes we read .desktop files before .kdelnk files ...

            // In fact, we skip any second item that has the same text as another one.
            // Duplicates in a menu look bad in any case.
            const auto [it, isInserted] = seenTexts.insert(entry.text);
            if (isInserted) {
                // const KNewFileMenuSingleton::Entry entry = templatesList->at(i-1);

                const QString templatePath = entry.templatePath;
                // The best way to identify the "Create Directory", "Link to Location", "Link to Application" was the template
                if (templatePath.endsWith(QLatin1String("emptydir"))) {
                    QAction *act = new QAction(q);
                    m_newDirAction = act;
                    act->setIcon(QIcon::fromTheme(entry.icon));
                    act->setText(i18nc("@item:inmenu Create New", "%1", entry.text));
                    act->setActionGroup(m_newMenuGroup);

                    // If there is a shortcut available in the action collection, use it.
                    QAction *act2 = m_actionCollection->action(QStringLiteral("create_dir"));
                    if (act2) {
                        act->setShortcuts(act2->shortcuts());
                        // Both actions have now the same shortcut, so this will prevent the "Ambiguous shortcut detected" dialog.
                        act->setShortcutContext(Qt::WidgetShortcut);
                        // We also need to react to shortcut changes.
                        QObject::connect(act2, &QAction::changed, act, [=]() {
                            act->setShortcuts(act2->shortcuts());
                        });
                    }

                    menu->addAction(act);
                    menu->addSeparator();
                } else {
                    if (lastTemplatePath.startsWith(QDir::homePath()) && !templatePath.startsWith(QDir::homePath())) {
                        menu->addSeparator();
                    }
                    if (!m_supportedMimeTypes.isEmpty()) {
                        bool keep = false;

                        // We need to do MIME type filtering, for real files.
                        const bool createSymlink = entry.templatePath == QLatin1String("__CREATE_SYMLINK__");
                        if (createSymlink) {
                            keep = true;
                        } else if (!KDesktopFile::isDesktopFile(entry.templatePath)) {
                            // Determine MIME type on demand
                            QMimeDatabase db;
                            QMimeType mime;
                            if (entry.mimeType.isEmpty()) {
                                mime = db.mimeTypeForFile(entry.templatePath);
                                // qDebug() << entry.templatePath << "is" << mime.name();
                                entry.mimeType = mime.name();
                            } else {
                                mime = db.mimeTypeForName(entry.mimeType);
                            }
                            for (const QString &supportedMime : std::as_const(m_supportedMimeTypes)) {
                                if (mime.inherits(supportedMime)) {
                                    keep = true;
                                    break;
                                }
                            }
                        }

                        if (!keep) {
                            // qDebug() << "Not keeping" << entry.templatePath;
                            continue;
                        }
                    }

                    QAction *act = new QAction(q);
                    act->setData(idx);
                    act->setIcon(QIcon::fromTheme(entry.icon));
                    act->setText(i18nc("@item:inmenu Create New", "%1", entry.text));
                    act->setActionGroup(m_newMenuGroup);

                    // qDebug() << templatePath << entry.filePath;

                    if (templatePath.endsWith(QLatin1String("/URL.desktop"))) {
                        linkURL = act;
                    } else if (templatePath.endsWith(QLatin1String("/Program.desktop"))) {
                        linkApp = act;
                    } else if (entry.filePath.endsWith(QLatin1String("/linkPath.desktop"))) {
                        linkPath = act;
                    } else if (KDesktopFile::isDesktopFile(templatePath)) {
                        KDesktopFile df(templatePath);
                        if (df.readType() == QLatin1String("FSDevice")) {
                            m_menuDev->menu()->addAction(act);
                        } else {
                            menu->addAction(act);
                        }
                    } else {
                        if (!m_firstFileEntry) {
                            m_firstFileEntry = &entry;
                            // If there is a shortcut available in the action collection, use it.
                            QAction *act2 = m_actionCollection->action(QStringLiteral("create_file"));
                            if (act2) {
                                act->setShortcuts(act2->shortcuts());
                                // Both actions have now the same shortcut, so this will prevent the "Ambiguous shortcut detected" dialog.
                                act->setShortcutContext(Qt::WidgetShortcut);
                                // We also need to react to shortcut changes.
                                QObject::connect(act2, &QAction::changed, act, [=]() {
                                    act->setShortcuts(act2->shortcuts());
                                });
                            }
                        }
                        menu->addAction(act);
                    }
                }
            }
            lastTemplatePath = entry.templatePath;
        } else { // Separate system from personal templates
            Q_ASSERT(entry.entryType != 0);
            menu->addSeparator();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QModelIndex &parent, int first, int last) {
            rowsAboutToBeRemoved(parent, first, last);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (int i : fields) {
        switch (i) {
        case CF_DOMAIN:
            out << cookie.domain();
            break;
        case CF_NAME:
            out << cookie.name();
            break;
        case CF_PATH:
            out << cookie.path();
            break;
        case CF_HOST:
            out << cookie.host();
            break;
        case CF_VALUE:
            out << cookie.value();
            break;
        case CF_EXPIRE:
            out << QString::number(cookie.expireDate());
            break;
        case CF_PROVER:
            out << QString::number(cookie.protocolVersion());
            break;
        case CF_SECURE:
            out << QString::number(cookie.isSecure() ? 1 : 0);
            break;
        default:
            out << QString();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &dirUrl : std::as_const(lister->d->lstDirs)) {
        DirItem *dirItem = itemsInUse.value(dirUrl);
        Q_ASSERT(dirItem);

        auto it = std::find_if(dirItem->lstItems.cbegin(), dirItem->lstItems.cend(), isMatch);
        if (it != dirItem->lstItems.cend()) {
            return *it;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KPropertiesDialogPlugin *it : qAsConst(d->m_pageList)) {
        if (qobject_cast<KUrlPropsPlugin *>(it) || qobject_cast<KDesktopPropsPlugin *>(it)) {
            // qDebug() << "Setting page dirty";
            it->setDirty();
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QSslCertificate &cert : qAsConst(certs)) {
        const QByteArray digest = cert.digest().toHex();
        if (!group.hasKey(digest.constData())) {
            defaultCaCertificates += cert;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[dummy]() mutable {
        dummy.succeed("undo", true);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &providerName : qAsConst(m_deletedProviders)) {
        QStringList matches;
        for (const QString &dir : servicesDirs) {
            QString current = dir + QLatin1Char('/') + providerName + QLatin1String(".desktop");
            if (QFile::exists(current)) {
                matches += current;
            }
        }

        // Shouldn't happen
        if (matches.isEmpty()) {
            continue;
        }

        if (matches.size() == 1 && matches.first().startsWith(path)) {
            // If only the local copy existed, unlink it
            // TODO: error handling
            QFile::remove(matches.first());
            continue;
        }

        KConfig _service(path + providerName + QLatin1String(".desktop"), KConfig::SimpleConfig);
        KConfigGroup service(&_service, "Desktop Entry");
        service.writeEntry("Type", "Service");
        service.writeEntry("Hidden", true);
    }
```

#### AUTO 


```{c}
const auto [it, isInserted] = seenTexts.insert(entry.text);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QHostAddress &address : info.addresses()) {
                if (isIPv4Address(address) || isIPv6Address(address)) {
                    hasResolvableIPAddress = true;
                    break;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : fileList) {
        const QList<QUrl> dirUrls = directoriesForCanonicalPath(url);
        for (const QUrl &dir : dirUrls) {
            DirItem *dirItem = dirItemForUrl(dir); // is it a listed directory?
            if (dirItem) {
                deletedSubdirs.append(dir);
                if (!dirItem->rootItem.isNull()) {
                    removedItemsByDir[url].append(dirItem->rootItem);
                }
            }
        }

        const QUrl parentDir = url.adjusted(QUrl::RemoveFilename | QUrl::StripTrailingSlash);
        const QList<QUrl> parentDirUrls = directoriesForCanonicalPath(parentDir);
        for (const QUrl &dir : parentDirUrls) {
            DirItem *dirItem = dirItemForUrl(dir);
            if (!dirItem) {
                continue;
            }

            auto dirItemIt = std::find_if(dirItem->lstItems.begin(), dirItem->lstItems.end(), [&url](const KFileItem &fitem) {
                return fitem.url() == url;
            });
            if (dirItemIt != dirItem->lstItems.end()) {
                const KFileItem fileitem = *dirItemIt;
                removedItemsByDir[dir].append(fileitem);
                // If we found a fileitem, we can test if it's a dir. If not, we'll go to deleteDir just in case.
                if (fileitem.isNull() || fileitem.isDir()) {
                    deletedSubdirs.append(url);
                }
                dirItem->lstItems.erase(dirItemIt); // remove fileitem from list
            }
        }
    }
```

#### AUTO 


```{c}
auto job = KIO::copy({ QUrl::fromLocalFile(QFINDTESTDATA("ftp/testOverwriteCopy2")) }, url, KIO::Overwrite);
```

#### RANGE FOR STATEMENT 


```{c}
for (KProtocolInfoPrivate *allProtocol : allProtocols) {
            const QStringList archiveMimetypes = allProtocol->m_archiveMimeTypes;
            for (const QString &mime : archiveMimetypes) {
                d->protocolForArchiveMimetypes.insert(mime, allProtocol->m_name);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &error : ksslErrors) {
        d->sslErrors.push_back(error.sslError());
    }
```

#### AUTO 


```{c}
auto *job = new KIO::OpenUrlJob(QUrl(QStringLiteral("http://www.kde.org")));
```

#### AUTO 


```{c}
auto applyOtherChanges = [this, acceptAndClose]() {
        Q_ASSERT(!d->m_filePropsPlugin->isDirty());
        Q_ASSERT(!d->m_permissionsPropsPlugin->isDirty());

        // Apply the changes for the rest of the plugins
        for (auto *page : d->m_pages) {
            if (d->m_aborted) {
                break;
            }

            if (page->isDirty()) {
                // qDebug() << "applying changes for " << page->metaObject()->className();
                page->applyChanges();
            }
            /* else {
                qDebug() << "skipping page " << page->metaObject()->className();
            } */
        }

        if (!d->m_aborted && d->m_filePropsPlugin) {
            d->m_filePropsPlugin->postApplyChanges();
        }

        if (!d->m_aborted) {
            acceptAndClose();
        } // Else, keep dialog open for user to fix the problem.
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : list) {
        action->setShortcutContext(Qt::WidgetWithChildrenShortcut);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QString srcPath : entries) {
        if (srcPath == QLatin1Char('.') || srcPath == QLatin1String("..") || srcPath == QLatin1String(".directory")) {
            continue;
        }
        srcPath.prepend(oldTrashDir); // make absolute
        int trashId;
        QString fileId;
        if (!createInfo(srcPath, trashId, fileId)) {
            qCWarning(KIO_TRASH) << "Trash migration: failed to create info for" << srcPath;
            allOK = false;
        } else {
            bool ok = moveToTrash(srcPath, trashId, fileId);
            if (!ok) {
                (void)deleteInfo(trashId, fileId);
                qCWarning(KIO_TRASH) << "Trash migration: failed to create info for" << srcPath;
                allOK = false;
            } else {
                qCDebug(KIO_TRASH) << "Trash migration: moved" << srcPath;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &subDir : entries) {
        QString subPath = m_path + subDir;
        KFileCopyToDirectoryMenu *subMenu = new KFileCopyToDirectoryMenu(this, m_mainMenu, subPath);
        QString menuTitle(subDir);
        // Replace '&' by "&&" to make sure that '&' inside the directory name is displayed
        // correctly and not misinterpreted as an indicator for a keyboard shortcut
        subMenu->setTitle(menuTitle.replace(QLatin1Char('&'), QLatin1String("&&")));
        const QString iconName = dirMime.iconName();
        subMenu->setIcon(QIcon::fromTheme(iconName));
        if (QFileInfo(subPath).isSymLink()) {
            QFont font = subMenu->menuAction()->font();
            font.setItalic(true);
            subMenu->menuAction()->setFont(font);
        }
        addMenu(subMenu);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KCModule *module : qAsConst(modules)) {
        module->defaults();
    }
```

#### AUTO 


```{c}
auto it = lister->d->lstDirs.constBegin(), cend = lister->d->lstDirs.constEnd();
```

#### AUTO 


```{c}
const auto dir_url = this->url(dir_path);
```

#### AUTO 


```{c}
auto it = runningListJobs.cbegin();
```

#### LAMBDA EXPRESSION 


```{c}
[destFile, suspend, overwrite](KJob *job, qulonglong processedSize) {
        if (processedSize > 0) {
            const QString destToCheck = (!overwrite) ? destFile : destFile + QStringLiteral(".part");
            QVERIFY(QFile::exists(destToCheck));
            if (suspend) {
                job->suspend();
            }
            job->kill();
            QVERIFY(!QFile::exists(destToCheck));
        }
    }
```

#### AUTO 


```{c}
const auto compMimeFolder = m_completionWithMimeFilter->allMatches();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& domain : domains)
  {
    const QString siteName = (domain.startsWith(QLatin1Char('.')) ? domain.mid(1) : domain);
    if (mUi.cookiesTreeWidget->findItems(siteName, Qt::MatchFixedString).isEmpty()) {
        dom = new CookieListViewItem(mUi.cookiesTreeWidget, domain);
        dom->setChildIndicatorPolicy(QTreeWidgetItem::ShowIndicator);
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &plugin : plugins) {
        result << plugin.pluginId();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &dirpath : dirList) {
        QDir dir(dirpath);
        if (!dir.exists()) {
            continue;
        }

        const QStringList filenames = dir.entryList({QStringLiteral("*.desktop")},
                                                    QDir::Files | QDir::Readable);

        KIO::UDSEntry entry;
        for (const QString &name : filenames) {
            if (!names_found.contains(name) && createEntry(entry, dirpath, name)) {
                list.append(entry);
                names_found.append(name);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &item : items) {
        bool isLocal = false;
        const QUrl url = item.mostLocalUrl(&isLocal);
        m_isLocal = m_isLocal && isLocal;
        m_supportsPrivilegeExecution = KProtocolManager::supportsPrivilegeExecution(url);
#ifndef Q_OS_WIN
        m_isOwner = m_isOwner && (item.user() == KUser(getuid()).loginName());
#endif
        m_supportsReading  = m_supportsReading  && KProtocolManager::supportsReading(url);
        m_supportsDeleting = m_supportsDeleting && KProtocolManager::supportsDeleting(url);
        m_supportsWriting  = m_supportsWriting  && KProtocolManager::supportsWriting(url) && (m_supportsPrivilegeExecution || item.isWritable());
        m_supportsMoving   = m_supportsMoving   && KProtocolManager::supportsMoving(url);

        // For local files we can do better: check if we have write permission in parent directory
        // TODO: if we knew about the parent KFileItem, we could even do that for remote protocols too
#ifndef Q_OS_WIN
        if (m_isLocal && (m_supportsDeleting || m_supportsMoving)) {
            const QString directory = url.adjusted(QUrl::RemoveFilename | QUrl::StripTrailingSlash).toLocalFile();
            if (parentDirInfo.filePath() != directory) {
                parentDirInfo.setFile(directory);
            }
            if (!parentDirInfo.isWritable() && !m_supportsPrivilegeExecution) {
                m_supportsDeleting = false;
                m_supportsMoving = false;
            }
        }
#else
        if (m_isLocal && m_supportsDeleting) {
            if (!QFileInfo(url.toLocalFile()).isWritable())
                m_supportsDeleting = false;
        }
#endif
        if (m_isDirectory && !item.isDir()) {
            m_isDirectory = false;
        }

        if (m_isFile && !item.isFile()) {
            m_isFile = false;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &filename : fileList) {
            createTestFile(m_homeDir + filename);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &cookie : cookies) {
        const int index = cookie.indexOf(QL1C('='));
        const QStringRef name = cookie.leftRef(index);
        const QStringRef value = cookie.rightRef((cookie.length() - index - 1));
        cookieList << QNetworkCookie(name.toUtf8(), value.toUtf8());
        // qDebug() << "cookie: name=" << name << ", value=" << value;
    }
```

#### AUTO 


```{c}
const auto jsonPlugins = KPluginLoader::findPlugins(QStringLiteral("kf5/kfileitemaction"), [&db, commonMimeType](const KPluginMetaData &metaData) {
        auto mimeType = db.mimeTypeForName(commonMimeType);
        const QStringList list = metaData.mimeTypes();
        return std::any_of(list.constBegin(), list.constEnd(), [mimeType](const QString &supportedMimeType) {
            return mimeType.inherits(supportedMimeType);
        });
    });
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &domainName : std::as_const(m_domainList)) {
        bool domainPrinted = false;

        KHttpCookieList *cookieList = m_cookieDomains.value(domainName);
        if (!cookieList) {
            continue;
        }

        QMutableListIterator<KHttpCookie> cookieIterator(*cookieList);
        while (cookieIterator.hasNext()) {
            const KHttpCookie &cookie = cookieIterator.next();

            if (cookie.isExpired()) {
                // Delete expired cookies
                cookieIterator.remove();
                continue;
            }
            if (cookieIsPersistent(cookie)) {
                // Only save cookies that are not "session-only cookies"
                if (!domainPrinted) {
                    domainPrinted = true;
                    ts << '[' << domainName.toLocal8Bit().data() << "]\n";
                }
                // Store persistent cookies
                const QString path = QLatin1Char('"') + cookie.path() + QLatin1Char('"');
                const QString domain = QLatin1Char('"') + cookie.domain() + QLatin1Char('"');
                const QString host = hostWithPort(&cookie);

                // TODO: replace with direct QTextStream output ?
                const QString fullStr = QString::asprintf(
                    "%-20s %-20s %-12s %10lld  %3d %-20s %-4i %s\n",
                    host.toLatin1().constData(),
                    domain.toLatin1().constData(),
                    path.toLatin1().constData(),
                    cookie.expireDate(),
                    cookie.protocolVersion(),
                    cookie.name().isEmpty() ? cookie.value().toLatin1().constData() : cookie.name().toLatin1().constData(),
                    (cookie.isSecure() ? 1 : 0) + (cookie.isHttpOnly() ? 2 : 0) + (cookie.hasExplicitPath() ? 4 : 0) + (cookie.name().isEmpty() ? 8 : 0),
                    cookie.value().toLatin1().constData());
                ts << fullStr.toLatin1();
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : m_filesToRemove) {
        QFile::remove(file);
    }
```

#### AUTO 


```{c}
const auto jsonPlugins = KPluginMetaData::findPlugins(QStringLiteral("kf5/propertiesdialog"));
```

#### LAMBDA EXPRESSION 


```{c}
[desc, ret, job]() mutable {
        KIO::Job* it = job;
        if (it->error() == KIO::Job::NoError) {
            ret.succeed(desc, job);
        } else {
            ret.fail(desc, job);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto groupType : {KFilePlacesModel::PlacesType,
                           KFilePlacesModel::RemoteType,
                           KFilePlacesModel::RecentlySavedType,
                           KFilePlacesModel::SearchForType,
                           KFilePlacesModel::DevicesType,
                           KFilePlacesModel::RemovableDevicesType}) {
        const bool groupShouldBeHidden = (groupType == KFilePlacesModel::SearchForType);
        for (auto index : m_places->groupIndexes(groupType)) {
            QCOMPARE(index.data(KFilePlacesModel::GroupHiddenRole).toBool(), groupShouldBeHidden);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &plugin : splittedText) {
        enabledPlugins << plugin.trimmed();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QPushButton *button) {
            return button->text() == QLatin1String("&OK");
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : qAsConst(m_appActions)) {
        removeAction(action);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, &seenUrls](const char *translationContext,
                              const QByteArray &untranslatedLabel,
                              const QUrl &url,
                              const QString &iconName,
                              const KBookmark &after) {
                if (!seenUrls.contains(url)) {
                    return KFilePlacesItem::createSystemBookmark(d->bookmarkManager, translationContext, untranslatedLabel, url, iconName, after);
                }
                return KBookmark();
            }
```

#### AUTO 


```{c}
const auto startReply = manager->StartTransientUnit(
        serviceName,
        QStringLiteral("fail"), // mode defines what to do in the case of a name conflict, in this case, just do nothing
        { // Properties of the transient service unit
          { QStringLiteral("Slice"), QStringLiteral("app.slice") },
          { QStringLiteral("Description"), m_description },
          { QStringLiteral("SourcePath"), m_desktopFilePath },
          { QStringLiteral("PIDs"), QVariant::fromValue(QList<uint> { static_cast<uint>(m_process->processId()) }) } },
        {} // aux is currently unused and should be passed as empty array.
    );
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &pluginMetaData : qAsConst(plugins)) {
        const QString fileName = pluginMetaData.fileName().section(QLatin1Char('/'), -1);
        if (!pluginNames.contains(fileName)) {
            pluginNames << fileName;
            if (auto plugin = KPluginFactory::instantiatePlugin<KUriFilterPlugin>(pluginMetaData).plugin) {
                d->pluginList << plugin;
            }
        }
    }
```

#### AUTO 


```{c}
auto expected = R"foo(<?xml version="1.0" encoding="UTF-8"?>
<xbel version="1.0" xmlns:bookmark="http://www.freedesktop.org/standards/desktop-bookmarks" xmlns:mime="http://www.freedesktop.org/standards/shared-mime-info">)foo";
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool show) {
        d->togglePlacesPanel(show);
    }
```

#### AUTO 


```{c}
auto doTrash(const QList<QUrl>& items)
{
    auto job = KIO::trash(items);

    Fum->recordJob(KIO::FileUndoManager::Trash, items, QUrl("trash:/"), job);

    return jobToFuture(QStringLiteral("trash %1").arg(toStr(items)), job);
}
```

#### LAMBDA EXPRESSION 


```{c}
do {
        return move({"3"_hc}, "3"_rc);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &mimeType : mimeTypeList) {
        const KService::Ptr serv = preferredService(mimeType, excludedDesktopEntryNames, traderConstraint);
        serviceIdList << (serv ? serv->storageId() : QString()); // empty string means mimetype has no associated apps
    }
```

#### AUTO 


```{c}
auto *job = new KIO::CommandLauncherJob(cmd);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &shorthand : shorthands) {
        for (const SearchProvider *provider : qAsConst(m_providers)) {
            if (provider != m_provider && provider->keys().contains(shorthand)) {
                contenders.insert(shorthand, provider);
                break;
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KIO::filesize_t dataWritten) { slotWritten(dataWritten); }
```

#### AUTO 


```{c}
auto *grpStruct = getgrnam("audio");
```

#### AUTO 


```{c}
const auto actions = m_placesMenu->actions();
```

#### AUTO 


```{c}
auto err = execWithElevatedPrivilege(SYMLINK, {dest, target}, errno)
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QUrl &url) { d->urlEntered(url); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString& message){ _k_slotSlaveInfoMessage(message);}
```

#### AUTO 


```{c}
const auto servicesTypes = service.serviceTypes();
```

#### RANGE FOR STATEMENT 


```{c}
for (KUrlNavigatorButton *button : std::as_const(m_navButtons)) {
        button->hide();
        button->deleteLater();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        slotLoadingFinished();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KSslCaCertificate &cert : ret) {
        if (group.hasKey(cert.certHash.constData())) {
            cert.isBlacklisted = true;
            //qDebug() << "is blacklisted";
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KCoreDirLister *kdl : listers) {
        kdl->d->emitItems();

        kdl->d->jobDone(job);
#if KIOCORE_BUILD_DEPRECATED_SINCE(5, 79)
        Q_EMIT kdl->completed(jobUrl);
#endif
        Q_EMIT kdl->listingDirCompleted(jobUrl);
        if (kdl->d->numJobs() == 0) {
            kdl->d->complete = true;
            Q_EMIT kdl->completed();
        }
    }
```

#### AUTO 


```{c}
const auto path = QDir::cleanPath(destFI.absoluteFilePath() + QStringLiteral("/") + srcFI.baseName());
```

#### AUTO 


```{c}
auto *page
```

#### LAMBDA EXPRESSION 


```{c}
[this] { q->accept(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : urls) {
        QUrl dUrl = destDirUrl.adjusted(QUrl::StripTrailingSlash);
        dUrl.setPath(dUrl.path() + '/' + url.fileName());
        urls2 << dUrl;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        _k_capacityBarFadeValueChanged();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KUriFilterPlugin *plugin : qAsConst(d->pluginList)) {
        // If no specific filters were requested, iterate through all the plugins.
        // Otherwise, only use available filters.
        if (filters.isEmpty() || filters.contains(plugin->objectName())) {
            if (plugin->filterUri(data)) {
                filtered = true;
            }
        }
    }
```

#### AUTO 


```{c}
auto call = QDBusConnection::sessionBus().asyncCall(message);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KSslError &err : qAsConst(ud->sslErrors)) {
        message.append(err.errorString() + QLatin1Char('\n'));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &dir : dirUrls) {
            DirItem *dirItem = dirItemForUrl(dir); // is it a listed directory?
            if (dirItem) {
                deletedSubdirs.append(dir);
                if (!dirItem->rootItem.isNull()) {
                    removedItemsByDir[url].append(dirItem->rootItem);
                }
            }
        }
```

#### AUTO 


```{c}
auto propertyToString = [](const KService::Ptr &service, const QString &prop) {
        return service->property(prop).toString();
    };
```

#### LAMBDA EXPRESSION 


```{c}
[mime](const QString &archiveType) {
        return mime.inherits(archiveType);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[]() {
        return qgetenv("KIO_ENABLE_WORKER_THREADS") != "0";
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : additionalActions) {
            actionsMenu->addAction(action);
        }
```

#### AUTO 


```{c}
const auto &header
```

#### RANGE FOR STATEMENT 


```{c}
for (const KIO::AuthInfo& info : infos) {
            const qlonglong id = server.queryAuthInfoAsync(
                info,
                QString(),
                windowId, seqNr, 16 /*usertime*/);
            QVERIFY(id >= 0); // requestId, ever increasing
            idList << id;
        }
```

#### AUTO 


```{c}
auto list = group.readEntry("Paths", QStringList{});
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->_k_slotClear();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d_func()->slotReport();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &dir : std::as_const(dirs)) {
        QVERIFY(!QFile::exists(dir.toLocalFile()));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, launchedSerial](int tokenSerial, const QString &token) {
                                if (tokenSerial == launchedSerial) {
                                    m_process->setEnv(QStringLiteral("XDG_ACTIVATION_TOKEN"), token);
                                    Q_EMIT xdgActivationTokenArrived();
                                    m_waitingForXdgToken = false;
                                }
                            }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->_k_initDeviceList(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob * job) {
        Q_EMIT d->q->error(job->error(), job->errorString());
    }
```

#### AUTO 


```{c}
const auto parentDir = info.path();
```

#### AUTO 


```{c}
auto h(const QString& it)
{
    auto home = QDir::homePath();
    auto path = it;

    return QUrl::fromLocalFile(QDir::cleanPath(home + QDir::separator() + path));
}
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { slotReturnPressed(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &u : qAsConst(urls)) {
            m_nodeHash.remove(u);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &shorthand : shorthands) {
        Q_FOREACH (const SearchProvider *provider, m_providers) {
            if (provider != m_provider && provider->keys().contains(shorthand)) {
                contenders.insert(shorthand, provider);
                break;
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](QPointer<KProcessRunner> r) { return r.isNull() || r->waitForStarted(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QAction *act : actionsList) {
        if (!act->data().isNull()) {
            QVERIFY(actionData.contains(act->data().toString()));
            count++;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &statement : qAsConst(l)) {
                const int index = statement.indexOf('=');
                if (index <= 0) {
                    mediaAttribute = toQString(statement.mid(0, index));
                } else {
                    mediaAttribute = toQString(statement.mid(0, index));
                    mediaValue = toQString(statement.mid(index + 1));
                }
                mediaAttribute = mediaAttribute.trimmed();
                mediaValue     = mediaValue.trimmed();

                bool quoted = false;
                if (mediaValue.startsWith(QLatin1Char('"'))) {
                    quoted = true;
                    mediaValue.remove(0, 1);
                }

                if (mediaValue.endsWith(QLatin1Char('"'))) {
                    mediaValue.chop(1);
                }

                qCDebug(KIO_HTTP) << "Encoding-type:" << mediaAttribute << "=" << mediaValue;

                if (mediaAttribute == QLatin1String("charset")) {
                    mediaValue = mediaValue.toLower();
                    m_request.cacheTag.charset = mediaValue;
                    setMetaData(QStringLiteral("charset"), mediaValue);
                } else {
                    setMetaData(QLatin1String("media-") + mediaAttribute, mediaValue);
                    if (quoted) {
                        setMetaData(QLatin1String("media-") + mediaAttribute + QLatin1String("-kio-quoted"),
                                    QStringLiteral("true"));
                    }
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KIO::Job *job, KIO::filesize_t offset) { _k_slotCanResume(job, offset); }
```

#### LAMBDA EXPRESSION 


```{c}
[beforeOpenWith](QAction *a) {
        return beforeOpenWith.contains(a);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &skipPath : qAsConst(m_skipList)) {
        if (path.startsWith(skipPath)) {
            return true;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { resolveMimeType(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &rlitem : refList) {
                if (found) {
                    break;
                }

                const QRegularExpression rangeRe(QStringLiteral("([0-9]*)\\-([0-9]*)"));
                const QRegularExpressionMatch rangeMatch = rangeRe.match(rlitem);
                // Substitute a range of keywords
                if (rangeMatch.hasMatch()) {
                    int first = rangeMatch.captured(1).toInt();
                    int last = rangeMatch.captured(2).toInt();

                    if (first == 0) {
                        first = 1;
                    }

                    if (last == 0) {
                        last = count;
                    }

                    for (int i = first; i <= last; i++) {
                        v += map[QString::number(i)] + QLatin1Char(' ');
                        // Remove used value from ql (needed for \{@}):
                        ql[i - 1].clear();
                    }

                    v = v.trimmed();
                    if (!v.isEmpty()) {
                        found = true;
                    }

                    kuriikws_debug(QStringLiteral("    range"),
                                   QString::number(first) + QLatin1Char('-') + QString::number(last) + QLatin1String(" => '") + v + QLatin1Char('\''));
                    v = encodeString(v, codec);
                } else if (rlitem.startsWith(QLatin1Char('\"')) && rlitem.endsWith(QLatin1Char('\"'))) {
                    // Use default string from query definition:
                    found = true;
                    QString s = rlitem.mid(1, rlitem.length() - 2);
                    v = encodeString(s, codec);
                    kuriikws_debug(QStringLiteral("    default"), s);
                } else if (map.contains(rlitem)) {
                    // Use value from substitution map:
                    found = true;
                    kuriikws_debug(QLatin1String("    map['") + rlitem + QLatin1String("']"), map[rlitem]);
                    v = encodeString(map[rlitem], codec);

                    // Remove used value from ql (needed for \{@}):
                    const QChar c = rlitem.at(0); // rlitem can't be empty at this point
                    if (c == QLatin1Char('0')) {
                        // It's a numeric reference to '0'
                        for (QStringList::Iterator it = ql.begin(); it != ql.end(); ++it) {
                            (*it).clear();
                        }
                    } else if ((c >= QLatin1String("0")) && (c <= QLatin1String("9"))) { // krazy:excludeall=doublequote_chars
                        // It's a numeric reference > '0'
                        int n = rlitem.toInt();
                        ql[n - 1].clear();
                    } else {
                        // It's a alphanumeric reference
                        QStringList::Iterator it = ql.begin();
                        while ((it != ql.end()) && !it->startsWith(rlitem + QLatin1Char('='))) {
                            ++it;
                        }
                        if (it != ql.end()) {
                            it->clear();
                        }
                    }

                    // Encode '+', otherwise it would be interpreted as space in the resulting url:
                    v.replace(QLatin1Char('+'), QLatin1String("%2B"));
                } else if (rlitem == QLatin1String("@")) {
                    v = QStringLiteral("\\@");
                    kuriikws_debug(QStringLiteral("    v"), v);
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->slotChangeDecorationPosition();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KIO::Job *job, const QUrl &from, const QString &target, const QUrl &to) {
                slotCopyingLinkDone(job, from, target, to);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KHttpCookie &cookie : *list) {
                if (cookie.isExpired()) {
                    continue;
                }
                putCookie(result, cookie, fields);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (QUrl &url : urls) {
            bool supported = KIO::DesktopExecParser::isProtocolInSupportedList(url, appSupportedProtocols);
            //qDebug() << "Looking at url=" << url << " supported=" << supported;
            if (!supported && KProtocolInfo::protocolClass(url.scheme()) == QLatin1String(":local")) {
                // Maybe we can resolve to a local URL?
                KIO::StatJob *job = KIO::mostLocalUrl(url);
                if (job->exec()) { // ## nasty nested event loop!
                    const QUrl localURL = job->mostLocalUrl();
                    if (localURL != url) {
                        url = localURL;
                        //qDebug() << "Changed to" << localURL;
                    }
                }
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=](const int buttonCode) {
        const bool isDelete = buttonCode == QDialogButtonBox::Yes;

        Q_EMIT askUserDeleteResult(isDelete, urls, deletionType, parent);

        if (isDelete) {
            KConfigGroup cg = kioConfig->group("Confirmations");
            cg.writeEntry(keyName, !dlg->isDontAskAgainChecked());
            cg.sync();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &item : *itemList) {
            const QString text = item.text();
            if (text == QLatin1Char('.') || text == QLatin1String("..")) {
                continue;
            }
            const bool wasVisible = oldVisibleItems.find(item.name()) != oldVisibleItems.cend();
            const bool nowVisible = isItemVisible(item) && q->matchesMimeFilter(item);
            if (nowVisible && !wasVisible) {
                addNewItem(dir, item); // takes care of emitting newItem or itemsFilteredByMime
            } else if (!nowVisible && wasVisible) {
                deletedItems.append(item);
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=](KIO::Job *, const QString &mimetype) {
        if (m_followRedirections) { // Update our URL in case of a redirection
            m_url = job->url();
        }
        if (mimetype.isEmpty()) {
            qCWarning(KIO_CORE) << "get() didn't emit a MIME type! Probably a kioslave bug, please check the implementation of" << m_url.scheme();
        }
        m_mimeTypeName = mimetype;

        // If the current MIME type is the default MIME type, then attempt to
        // determine the "real" MIME type from the file name (bug #279675)
        const QMimeType mime = fixupMimeType(m_mimeTypeName, m_suggestedFileName.isEmpty() ? m_url.fileName() : m_suggestedFileName);
        if (mime.isValid()) {
            m_mimeTypeName = mime.name();
        }

        if (m_suggestedFileName.isEmpty()) {
            m_suggestedFileName = job->queryMetaData(QStringLiteral("content-disposition-filename"));
        }

        if (!m_url.isLocalFile()) { // #434455
            job->putOnHold();
        }
        q->emitResult();
    }
```

#### AUTO 


```{c}
auto u(const QString& it)
{
    return QUrl::fromLocalFile(it);
}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QSslError &error : qAsConst(ud->sslErrors)) {
                    if (error.certificate() == cert) {
                        // we keep only the error code enum here
                        errors.append(error.error());
                    }
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) {
            _k_slotStatResult(job);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const ItemInUseChange &i : qAsConst(itemsToChange)) {
        itemsInUse.remove(i.oldUrl);
        itemsInUse.insert(i.newUrl, i.dirItem);
    }
```

#### AUTO 


```{c}
const auto permsTexts =  permissionsTexts[static_cast<int>(d->pmode)];
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &ipAddress : ipAddressList) {
        QHostAddress address(ipAddress);
        switch (address.protocol()) {
        case QAbstractSocket::IPv4Protocol:
            ipV4List << address;
            actualEntryMap.insert(address.toString(), ipAddress);
            break;
        case QAbstractSocket::IPv6Protocol:
            ipV6List << address;
            actualEntryMap.insert(address.toString(), ipAddress);
            break;
        default:
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KDirModelNode *node : qAsConst(dirNode->m_childNodes)) {
            node->setPreview(QIcon());
            //node->setPreview(QIcon::fromTheme(node->item().iconName()));
            if (isDir(node)) {
                // recurse into child dirs
                clearAllPreviews(static_cast<KDirModelDirNode *>(node));
            }
            lastNode = node;
        }
```

#### AUTO 


```{c}
auto partialLayout = new QFormLayout(partialWidget);
```

#### IF STATEMENT WITH INITIALIZER 


```{c}
if (const auto tag = QLatin1String("LABEL="); m_mountedFrom.startsWith(tag)) {
        potentialDevice = QFile::symLinkTarget(QLatin1String("/dev/disk/by-label/") + QStringView(m_mountedFrom).mid(tag.size()));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QUrl url) {

        // Parts of the following code have been taken from the class KateFileSelector
        // located in kate/app/katefileselector.hpp of Kate.
        // SPDX-FileCopyrightText: 2001 Christoph Cullmann <cullmann@kde.org>
        // SPDX-FileCopyrightText: 2001 Joseph Wenninger <jowenn@kde.org>
        // SPDX-FileCopyrightText: 2001 Anders Lund <anders.lund@lund.tdcadsl.dk>

        // For example "desktop:/" _not_ "desktop:", see the comment in slotProtocolChanged()
        if (!url.isEmpty() && url.path().isEmpty()
            && KProtocolInfo::protocolClass(url.scheme()) == QLatin1String(":local")) {
            url.setPath(QStringLiteral("/"));
        }

        const auto urlStr = url.toString();
        QStringList urls = m_pathBox->urls();
        urls.removeAll(urlStr);
        urls.prepend(urlStr);
        m_pathBox->setUrls(urls, KUrlComboBox::RemoveBottom);

        q->setLocationUrl(url);
        // The URL might have been adjusted by KUrlNavigator::setUrl(), hence
        // synchronize the result in the path box.
        m_pathBox->setUrl(q->locationUrl());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, existingDest](KIO::Job *spaceJob, KIO::filesize_t size, KIO::filesize_t available) {
                Q_UNUSED(size)
                if (!spaceJob->error()) {
                    m_freeSpace = available;
                } else {
                    qCDebug(KIO_COPYJOB_DEBUG) << "Couldn't determine free space information for" << existingDest;
                }
                statCurrentSrc();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &dirtyUrl : std::as_const(dirtyUrls)) {
        if (KDirModelNode *node = nodeForUrl(QUrl(dirtyUrl))) {
            const QModelIndex idx = indexForNode(node);
            Q_EMIT q->dataChanged(idx, idx, {KDirModel::HasJobRole});
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &text) {
        mUi.useReverseProxyCheckBox->setEnabled(!text.isEmpty());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QModelIndex &index) {
        d->headerAreaLeft(index);
    }
```

#### AUTO 


```{c}
const auto timeVal = entry.numberValue(KIO::UDSEntry::UDS_MODIFICATION_TIME, -1);
```

#### AUTO 


```{c}
auto err = tryOpen(src_file, _src, O_RDONLY, S_IRUSR, errno)
```

#### RANGE FOR STATEMENT 


```{c}
for (KJob *job : qAsConst(m_previewJobs)) {
        Q_ASSERT(job != nullptr);
        job->kill();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QMenu *menu : d->m_menus) {
        if (!d->m_appActions.isEmpty() || !d->m_pluginActions.isEmpty()) {
            menu->addSeparator();
            menu->addActions(d->m_appActions);
            menu->addActions(d->m_pluginActions);
        }
    }
```

#### AUTO 


```{c}
auto dit = directoryData.constFind(deletedUrl);
```

#### LAMBDA EXPRESSION 


```{c}
[this, &searchTerm](const QString &key) {
        SearchProvider *provider = nullptr;
        // If the key contains a : an assertion in the isKnownProtocol method would fail. This can be
        // the case if the delimiter is switched to space, see kiowidgets_space_separator_test
        if (!key.isEmpty() && (key.contains(QLatin1Char(':')) || !KProtocolInfo::isKnownProtocol(key))) {
            provider = m_registry.findByKey(key);
            if (provider) {
                if (!m_bUseOnlyPreferredWebShortcuts || m_preferredWebShortcuts.contains(provider->desktopEntryName())) {
                    qCDebug(category) << "found provider" << provider->desktopEntryName() << "searchTerm=" << searchTerm;
                } else {
                    provider = nullptr;
                }
            }
        }
        return provider;
    }
```

#### AUTO 


```{c}
auto job = KIO::copy({ QUrl::fromLocalFile(QFINDTESTDATA("ftp/testOverwriteCopy2")) }, url, KIO::DefaultFlags);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &tag : tagsList) {
        bookmark = KFilePlacesItem::createTagBookmark(bookmarkManager, tag);
        if (!bookmark.isNull()) {
            KFilePlacesItem *item = new KFilePlacesItem(bookmarkManager, bookmark.address(), tag);
            connect(item, &KFilePlacesItem::itemChanged, q, [this](const QString &id) {
                itemChanged(id);
            });
            items << item;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job, ulong _percent){ _k_slotPercent(job, _percent); }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        changeSitePolicy(ui.sitePolicyTreeWidget->currentItem());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const KFileItem &item, const QPixmap &pixmap) { addToPreviewQueue(item, pixmap); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &dir : urls) {
        QUrl aliasUrl(dir);
        aliasUrl.setPath(concatPaths(aliasUrl.path(), url.fileName()));
        handleFileDirty(aliasUrl);
    }
```

#### AUTO 


```{c}
const auto openResult = ftpOpenConnection(LoginMode::Implicit);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : m_urls) {
        const bool local = url.isLocalFile();
        if (!local /*optimization*/ && url.scheme() == QLatin1String("trash")) {
            if (url.path().isEmpty() || url.path() == QLatin1String("/")) {
                containsTrashRoot = true;
            }
        } else {
            allItemsAreFromTrash = false;
        }
        if (url.matches(m_destUrl, QUrl::StripTrailingSlash)) {
            slotDropActionDetermined(KIO::ERR_DROP_ON_ITSELF);
            return;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&url](const KFileItem &fitem) {
                return fitem.url() == url;
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->_k_slotFileDialogAccepted(); }
```

#### AUTO 


```{c}
const auto checkLastModTime = [this, checkMaxTime] (const QString &fileName) {
        const auto trashFileInfo = getTrashFileInfo(fileName);
        if (!trashFileInfo.exists()) {
            return;
        }
        checkMaxTime(trashFileInfo.lastModified().toMSecsSinceEpoch());
    };
```

#### LAMBDA EXPRESSION 


```{c}
[&app, fileWidget]() {
        qDebug() << "canceled";
        fileWidget->slotCancel();
        app.exit();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](KCoreDirLister *lister) {
        return lister->requestMimeTypeWhileListing();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &idx : qAsConst(emitExpandFor)) {
        Q_EMIT q->expand(idx);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KIO::Job *job, const KIO::UDSEntryList &entries) { _k_slotEntries(job, entries); }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->slotTreeView(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](){ slotPrivilegeOperationRequested();}
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { mFileWidget->slotOk(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { mkdir(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &portNum : portNums) {
                        const int port = portNum.toInt(&ok);
                        if (ok) {
                            lastCookie.mPorts.append(port);
                        }
                    }
```

#### AUTO 


```{c}
auto it = std::find_if(fileList.begin(), fileList.end(),
                                   [&path](const FileInfo &i) { return i.path == path; });
```

#### LAMBDA EXPRESSION 


```{c}
do {
        return copy({"4"_hc}, "4"_rc);
    }
```

#### AUTO 


```{c}
auto attemptWithAuthentication = [=]() {
        auto err = execWithElevatedPrivilege(COPY, {srcUrl, destUrl}, errno);
        if (err) {
            if (!err.wasCanceled()) {
                error(KIO::ERR_UNKNOWN, QString());
            }
        } else {
            finished();
        }
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->slotCompactView(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &ipAddress : ipAddressList) {
            QHostAddress address(ipAddress);
            switch (address.protocol()) {
            case QAbstractSocket::IPv4Protocol:
                ipV4List << address;
                actualEntryMap.insert(address.toString(), ipAddress);
                break;
            case QAbstractSocket::IPv6Protocol:
                ipV6List << address;
                actualEntryMap.insert(address.toString(), ipAddress);
                break;
            default:
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (KCoreDirLister *kdl : listers) {
                    kdl->d->addRefreshItem(jobUrl, tmp, item);
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : qAsConst(pendingUpdates)) { // always a local path
        qCDebug(KIO_CORE_DIRLISTER) << file;
        QUrl u = QUrl::fromLocalFile(file);
        KFileItem item = findByUrl(nullptr, u);   // search all items
        if (!item.isNull()) {
            // we need to refresh the item, because e.g. the permissions can have changed.
            KFileItem oldItem = item;
            item.refresh();

            if (!oldItem.cmp(item)) {
                reinsert(item, oldItem.url());
                listers |= emitRefreshItem(oldItem, item);
            }
        }
    }
```

#### AUTO 


```{c}
auto *askUserHandler = new MockAskUserInterface(job->uiDelegate());
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &service) {
            _k_serviceRegistered(service);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &attrName, const QString &value, const QString &fileName) {
            return QStringList{QLatin1String("-n"), attrName, QLatin1String("-v"), value, fileName};
        }
```

#### IF STATEMENT WITH INITIALIZER 


```{c}
if (const QDateTime dt = firstItem.time(KFileItem::CreationTime); !dt.isNull()) {
            d->m_ui->createdTimeLabel->setText(locale.toString(dt, QLocale::LongFormat));
        } else {
            d->m_ui->createdTimeLabel->hide();
            d->m_ui->createdTimeLabel_Left->hide();
        }
```

#### AUTO 


```{c}
auto copyJob = KIO::copy(source, dest, KIO::HideProgressInfo);
```

#### RANGE FOR STATEMENT 


```{c}
for (const SubnetPair &subnet : qAsConst(noProxySubnets)) {
                if (address.isInSubnet(subnet)) {
                    isMatch = true;
                    break;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QRegularExpression &filter : d->settings.lstFilters) {
        if (filter.match(name).hasMatch()) {
            return true;
        }
    }
```

#### AUTO 


```{c}
auto job = KIO::storedPut(&tempFile, destUrl, -1);
```

#### RANGE FOR STATEMENT 


```{c}
for (KIO::DropMenu *menu : qAsConst(d->m_menus)) {
        menu->addExtraActions(d->m_appActions, d->m_pluginActions);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &path : list) {
        QUrl u = m_resource.resolved(QUrl(QString::fromUtf8(path)));
        if (u.isValid()) {
            info.digestURIs.append(u);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const ItemInfo &preview : qAsConst(m_previews)) {
                const QModelIndex idx = dirModel->indexForUrl(preview.url);
                if (idx.isValid() && (idx.column() == 0)) {
                    dirModel->setData(idx, QIcon(preview.pixmap), Qt::DecorationRole);
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &pluginMetaData : plugins) {
        const QString fileName = pluginMetaData.fileName().section(QLatin1Char('/'), -1);
        if (!pluginNames.contains(fileName)) {
            pluginNames << fileName;
            KPluginFactory *factory = qobject_cast<KPluginFactory *>(pluginMetaData.instantiate());
            if (factory) {
                KUriFilterPlugin *plugin = factory->create<KUriFilterPlugin>(nullptr);
                if (plugin) {
                    d->pluginList << plugin;
                }
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const int index) {
                slotPolicyChanged(mUi.cbPolicy->itemText(index));
            }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &service : fileItemPlugins) {
        if (!showGroup.readEntry(service->desktopEntryName(), true)) {
            // The plugin has been disabled
            continue;
        }

        auto *abstractPlugin = service->createInstance<KAbstractFileItemActionPlugin>();
        if (abstractPlugin) {
            abstractPlugin->setParent(mainMenu);
            auto actions = abstractPlugin->actions(d->m_props, d->m_parentWidget);
            itemCount += actions.count();
            mainMenu->addActions(actions);
            addedPlugins.append(service->desktopEntryName());
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &id) {
                itemChanged(id);
            }
```

#### AUTO 


```{c}
auto *factory = qobject_cast<WorkerFactory *>(loader.instance());
```

#### AUTO 


```{c}
auto eject = std::unique_ptr<QAction>{placesModel->ejectActionForIndex(actionIndex)}
```

#### AUTO 


```{c}
const auto itEnd = m_navButtons.end();
```

#### LAMBDA EXPRESSION 


```{c}
[this](int percent) { d->slotProgress(percent); }
```

#### LAMBDA EXPRESSION 


```{c}
[this, existingDest](KIO::Job *spaceJob, KIO::filesize_t /*size*/, KIO::filesize_t available) {
                       if (!spaceJob->error()) {
                           m_freeSpace = available;
                       } else {
                           qCDebug(KIO_COPYJOB_DEBUG) << "Couldn't determine free space information for" << existingDest;
                       }
                       // After knowing what the dest is, we can start stat'ing the first src.
                       statCurrentSrc();
                   }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &row : mapping) {
        const QStringList locations = QStandardPaths::standardLocations(row.location);
        for (const QString &location : locations) {
            map.insert(location, row.name);
        }
        // Qt does not provide an easy way to receive the xdg dir for the templates and public directory so we have to find it on our own (QTBUG-86106 and QTBUG-78092)
#if QT_VERSION < 0x060300
#ifdef Q_OS_UNIX
        const QString xdgUserDirs = QStandardPaths::locate(QStandardPaths::ConfigLocation, QStringLiteral("user-dirs.dirs"), QStandardPaths::LocateFile);
        QFile xdgUserDirsFile(xdgUserDirs);
        if (!xdgUserDirs.isEmpty() && xdgUserDirsFile.open(QIODevice::ReadOnly | QIODevice::Text)) {
            QTextStream in(&xdgUserDirsFile);
            const QLatin1String templatesLine("XDG_TEMPLATES_DIR=\"");
            const QLatin1String publicShareLine("XDG_PUBLICSHARE_DIR=\"");
            while (!in.atEnd()) {
                const QString line = in.readLine();
                if (line.startsWith(templatesLine)) {
                    QString xdgTemplates = line.mid(templatesLine.size()).chopped(1);
                    xdgTemplates.replace(QStringLiteral("$HOME"), QDir::homePath());
                    map.insert(xdgTemplates, QStringLiteral("folder-templates"));
                } else if (line.startsWith(publicShareLine)) {
                    QString xdgPublicShare = line.mid(publicShareLine.size()).chopped(1);
                    xdgPublicShare.replace(QStringLiteral("$HOME"), QDir::homePath());
                    map.insert(xdgPublicShare, QStringLiteral("folder-public"));
                }
            }
        }
#endif
#endif
    }
```

#### AUTO 


```{c}
auto *job = KIO::statDetails(url,  KIO::StatJob::DestinationSide, details, KIO::HideProgressInfo);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &r : std::as_const(d->m_processRunners)) {
        if (!r.isNull()) {
            qApp->sendPostedEvents(r); // so slotStarted gets called
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &mimeFilter : mimeFilters) {
                    regex.setPattern(mimeFilter);
                    if (regex.match(fileMimeType.name()).hasMatch()) { // matches!
                        mimeFilterPass = true;
                        break;
                    }
                }
```

#### AUTO 


```{c}
auto it = m_trashDirectories.cbegin();
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &path) {
        return path.startsWith(QLatin1Char('.'));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            slotProcessExited(255, m_process->exitStatus());
        }
```

#### AUTO 


```{c}
const auto destination = (*it).m_dst;
```

#### LAMBDA EXPRESSION 


```{c}
[](QByteArray &line) {
                                          return line.startsWith("Load smb config files from");
                                      }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &ba : std::as_const(results)) {
        QList<QByteArray> values = ba.split('\t');
        const QString key(QString::fromLatin1(values.takeFirst()));

        QVERIFY(parameters.contains(key));

        const QByteArray val = values.takeFirst();
        QVERIFY(values.isEmpty());

        QCOMPARE(parameters[key], QString::fromUtf8(val.constData(), val.length()));
    }
```

#### AUTO 


```{c}
const auto jsonPlugins = KPluginLoader::findPlugins(QStringLiteral("kf5/kfileitemaction"), [&db, commonMimeType](const KPluginMetaData& metaData) {
        if (!metaData.serviceTypes().contains(QLatin1String("KFileItemAction/Plugin"))) {
            return false;
        }

        auto mimeType = db.mimeTypeForName(commonMimeType);
        foreach (const auto& supportedMimeType, metaData.mimeTypes()) {
            if (mimeType.inherits(supportedMimeType)) {
                return true;
            }
        }

        return false;
    });
```

#### LAMBDA EXPRESSION 


```{c}
[this](const BasicOperation &op) {
        return (op.m_type == BasicOperation::Directory && !op.m_renamed) || (op.m_type == BasicOperation::Link && !m_current.isMoveCommand());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        this->d->_k_slotSortReversed(true);
    }
```

#### AUTO 


```{c}
const auto &l
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &dir : installedTemplates) {
            instance->dirWatch->addDir(dir);
        }
```

#### AUTO 


```{c}
auto it = m_watched.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (unsigned char &b : key) {
        const bool needsParity = ((((b >> 7) ^ (b >> 6) ^ (b >> 5) ^ (b >> 4) ^ (b >> 3) ^ (b >> 2) ^ (b >> 1)) & 0x01) == 0);

        if (needsParity) {
            b |= 0x01;
        } else {
            b &= 0xfe;
        }
    }
```

#### AUTO 


```{c}
const auto &p
```

#### AUTO 


```{c}
auto dit = directoryData.constFind(rit.key());
```

#### AUTO 


```{c}
auto it = std::lower_bound(lstItems.begin(), lstItems.end(), item.url());
```

#### AUTO 


```{c}
const auto &r
```

#### AUTO 


```{c}
auto listDir = [this](const QModelIndex &index) {
        QSignalSpy completedSpy(m_dirModel->dirLister(), QOverload<>::of(&KDirLister::completed));
        m_dirModel->fetchMore(index);
        return completedSpy.wait();
    };
```

#### LAMBDA EXPRESSION 


```{c}
[&excludeList, &showGroup](const KServiceAction &srvAction) {
                return showGroup.readEntry(srvAction.name(), true) && !excludeList.contains(srvAction.name());
            }
```

#### AUTO 


```{c}
const auto compAllHidden = m_completion->allMatches();
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &l) {
        return l == QLatin1String("en_US");
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &key : std::as_const(domains)) {
        KHttpCookieList *list;

        if (key.isNull()) {
            list = m_cookieDomains.value(QLatin1String(""));
        } else {
            list = m_cookieDomains.value(key);
        }

        if (list) {
            removeDuplicateFromList(list, cookie, false, true);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QFuture<QString> &future) { return !future.isFinished(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](int logicalIndex, Qt::SortOrder order) {
            d->synchronizeSortingState(logicalIndex, order);
        }
```

#### AUTO 


```{c}
const auto &c
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { _k_slotFillTemplates(); }
```

#### AUTO 


```{c}
auto err = tryOpen(f, QFile::encodeName(dest), oflags, filemode, errno)
```

#### AUTO 


```{c}
auto fid = open("/tmp/kio-kauth-filehelper-long-randomish-name", O_RDWR | O_CREAT, 0644);
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job, const QString &text) {
        _k_slotWarning(job, text);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        changeIconsSize(ZoomOut);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &dir : std::as_const(lstDirs)) {
        const QList<KFileItem> *itemList = kDirListerCache()->itemsForDir(dir);
        if (!itemList) {
            continue;
        }

        for (const KFileItem &item : *itemList) {
            if (isItemVisible(item) && q->matchesMimeFilter(item)) {
                oldVisibleItems.insert(item.name());
            }
        }
    }
```

#### AUTO 


```{c}
const auto qsslErrors = d->sock.sslHandshakeErrors();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &key : boolAttributes) {
            if (config.hasKey(key)) {
                protocolData.insert(key, config.readEntry(key, bool(false)));
            }
        }
```

#### AUTO 


```{c}
const auto service = KApplicationTrader::preferredService(mimeType);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->slotShowProgress(); }
```

#### AUTO 


```{c}
const auto &u
```

#### AUTO 


```{c}
const auto kend = itemList->end();
```

#### AUTO 


```{c}
auto *act = new QAction(group);
```

#### LAMBDA EXPRESSION 


```{c}
[&types, &excludeTypes](const KFileItem &i)
                                {
                                    return mimeTypeListContains(types, i) && !mimeTypeListContains(excludeTypes, i);
                                }
```

#### LAMBDA EXPRESSION 


```{c}
[](KJob *job) {
        if (job->error()) {
            KMessageBox::error(nullptr, job->errorString());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &key : translatedStringListAttributes) {
            // read untranslated entry first in any case!
            sconfig.setLocale(QString());
            const QStringList untranslatedValues = config.readEntry(key, QStringList());
            if (!untranslatedValues.isEmpty()) {
                protocolData.insert(key, untranslatedValues);
            }

            // collect all locales for this key
            QFile f(fullFilePath);
            QStringList foundLocalesForKey;
            if (!f.open(QIODevice::ReadOnly | QIODevice::Text)) {
                qFatal("Failed to open file %s.", qPrintable(fullFilePath));
            }
            while (!f.atEnd()) {
                const QString line = QString::fromUtf8(f.readLine());
                const QRegularExpressionMatch match = localeRegex.match(line);
                if (match.hasMatch()) {
                    foundLocalesForKey.append(match.captured(1));
                }
            }

            // insert all entries for all found locales, reparse config for this
            for (const QString &locale : std::as_const(foundLocalesForKey)) {
                sconfig.setLocale(locale);
                protocolData.insert(QStringLiteral("%1[%2]").arg(key, locale), config.readEntry(key, QStringList()));
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (SearchProvider *p : std::as_const(providers)) {
        searchProviders << p;
    }
```

#### AUTO 


```{c}
auto *job = new KIO::CommandLauncherJob(executable, {srcPath, destName}, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const UDSTestField &field : testCase) {
                uint uds = field.m_uds;
                if (uds & KIO::UDSEntry::UDS_STRING) {
                    entry.fastInsert(uds, field.m_string);
                } else {
                    Q_ASSERT(uds & KIO::UDSEntry::UDS_NUMBER);
                    entry.fastInsert(uds, field.m_long);
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[prefKey](const KPluginMetaData &a, const KPluginMetaData &b) {
        return a.value(prefKey, 0) > b.value(prefKey, 0);
    }
```

#### AUTO 


```{c}
auto it = std::find_if(storage.begin(), storage.end(),
                                [udsField](const Field &entry) {return entry.m_index == udsField;});
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &mimetype : list) {
            QMimeType p = db.mimeTypeForName(mimetype);
            if (!p.isValid()) {
                continue;
            }

            bool found = false;
            int count = d->w->filetypeList->topLevelItemCount();
            for (int i = 0; !found && i < count; ++i) {
                if (d->w->filetypeList->topLevelItem(i)->text(0) == mimetype) {
                    found = true;
                }
            }
            if (!found) {
                QTreeWidgetItem *item = new QTreeWidgetItem();
                item->setText(0, p.name());
                item->setText(1, p.comment());
                d->w->filetypeList->addTopLevelItem(item);
            }
            d->w->filetypeList->resizeColumnToContents(0);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QHostAddress &address : addresses) {
            if (!isSpecialAddress(address) && !isLocalHostAddress(address)) {
                ipAddressList << address.toString();
            }
        }
```

#### AUTO 


```{c}
auto job = new DirectCopyJob(slave_url, packedArgs);
```

#### RANGE FOR STATEMENT 


```{c}
for (AnimationState *state : *list)
            if (state->index == index) {
                return state;
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QByteArray &ba) {
        slotData(ba);
    }
```

#### AUTO 


```{c}
auto findProvider = [this](const QString &shorthand) {
        return std::find_if(m_providers.cbegin(), m_providers.cend(), [this, &shorthand](const SearchProvider *provider) {
            return provider != m_provider && provider->keys().contains(shorthand);
        });
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : m_appActions) {
        removeAction(action);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &str : supported) {
                // wildcard matching because the "mimetype" can be "image/*"
                re.setPattern(QRegularExpression::wildcardToRegularExpression(str));

                if (mimeTypes.indexOf(re) != -1) { // matches! -> we want previews
                    return true;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : qAsConst(m_srcList)) {
            const QString extension = db.suffixForFileName(url.path());
            const auto [it, isInserted] = extensions.insert(extension);
            if (!isInserted) {
                m_allExtensionsDifferent = false;
                break;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) {
        d->_k_slotResult(job);
    }
```

#### AUTO 


```{c}
auto plugin = KPluginFactory::instantiatePlugin<KUriFilterPlugin>(pluginMetaData).plugin
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &entry : buf) {
        // Form the complete url
        KFileItem item(entry, jobUrl, delayedMimeTypes, true);

        const QString name = item.name();
        Q_ASSERT(!name.isEmpty()); // A kioslave setting an empty UDS_NAME is utterly broken, fix the kioslave!

        // we duplicate the check for dotdot here, to avoid iterating over
        // all items again and checking in matchesFilter() that way.
        if (name.isEmpty() || name == QLatin1String("..")) {
            continue;
        }

        if (name == QLatin1Char('.')) {
            // if the update was started before finishing the original listing
            // there is no root item yet
            if (dir->rootItem.isNull()) {
                dir->rootItem = item;

                for (KCoreDirLister *kdl : listers) {
                    if (kdl->d->rootFileItem.isNull() && kdl->d->url == jobUrl) {
                        kdl->d->rootFileItem = dir->rootItem;
                    }
                }
            }
            continue;
        } else {
            // get the names of the files listed in ".hidden", if it exists and is a local file
            if (!dotHiddenChecked) {
                const QString localPath = item.localPath();
                if (!localPath.isEmpty()) {
                    const QString rootItemPath = QFileInfo(localPath).absolutePath();
                    cachedHidden = cachedDotHiddenForDir(rootItemPath);
                }
                dotHiddenChecked = true;
            }
        }

        // hide file if listed in ".hidden"
        if (cachedHidden && cachedHidden->listedFiles.find(name) != cachedHidden->listedFiles.cend()) {
            item.setHidden();
        }

        // Find this item
        FileItemHash::iterator fiit = fileItems.find(item.name());
        if (fiit != fileItems.end()) {
            const KFileItem tmp = fiit.value();
            auto pru_it = pendingRemoteUpdates.find(tmp);
            const bool inPendingRemoteUpdates = pru_it != pendingRemoteUpdates.end();

            // check if something changed for this file, using KFileItem::cmp()
            if (!tmp.cmp(item) || inPendingRemoteUpdates) {
                if (inPendingRemoteUpdates) {
                    pendingRemoteUpdates.erase(pru_it);
                }

                qCDebug(KIO_CORE_DIRLISTER) << "file changed:" << tmp.name();

                reinsert(item, tmp.url());
                for (KCoreDirLister *kdl : listers) {
                    kdl->d->addRefreshItem(jobUrl, tmp, item);
                }
            }
            // Seen, remove
            fileItems.erase(fiit);
        } else { // this is a new file
            qCDebug(KIO_CORE_DIRLISTER) << "new file:" << name;
            newItems.append(item);
        }
    }
```

#### AUTO 


```{c}
auto *urlPropsPlugin = qobject_cast<KUrlPropsPlugin *>(it)
```

#### RANGE FOR STATEMENT 


```{c}
for (const KSycocaEntry::Ptr &p : list) {
        QString icon;
        QString text;
        QString tooltip;
        QString entryPath;
        QString exec;
        bool isDir = false;
        if (p->isType(KST_KService)) {
            const KService::Ptr service(static_cast<KService*>(p.data()));

            if (service->noDisplay()) {
                continue;
            }

            icon = service->icon();
            text = service->name();

            // no point adding a tooltip that only repeats service->name()
            const QString generic = service->genericName();
            tooltip = generic != text ? generic : QString();

            exec = service->exec();
            entryPath = service->entryPath();
        } else if (p->isType(KST_KServiceGroup)) {
            const KServiceGroup::Ptr serviceGroup(static_cast<KServiceGroup*>(p.data()));

            if (serviceGroup->noDisplay() || serviceGroup->childCount() == 0) {
                continue;
            }

            icon = serviceGroup->icon();
            text = serviceGroup->caption();
            entryPath = serviceGroup->entryPath();
            isDir = true;
        } else {
            qCWarning(KIO_WIDGETS) << "KServiceGroup: Unexpected object in list!";
            continue;
        }

        KDEPrivate::AppNode *newnode = new KDEPrivate::AppNode();
        newnode->icon = icon;
        newnode->text = text;
        newnode->tooltip = tooltip;
        newnode->entryPath = entryPath;
        newnode->exec = exec;
        newnode->isDir = isDir;
        newnode->parent = node;
        node->children.append(newnode);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &item : items) {
            if (!item.isNull()) {
                const QModelIndex dirIndex = d->dirModel->indexForItem(item);
                proxyIndex = d->proxyModel->mapFromSource(dirIndex);
                selModel->select(proxyIndex, QItemSelectionModel::Select);
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[q](KIO::Job *, const QUrl &, const QString &, const QUrl &to) {
        Q_EMIT q->itemCreated(to);
    }
```

#### AUTO 


```{c}
auto *tJob = qobject_cast<KIO::TransferJob *>(kioJob)
```

#### RANGE FOR STATEMENT 


```{c}
for (const KMountPoint::Ptr &mountPoint : *this) {
        if (realDevice.compare(mountPoint->d->m_device, cs) == 0 ||
                realDevice.compare(mountPoint->d->m_mountedFrom, cs) == 0) {
            return mountPoint;
        }
    }
```

#### AUTO 


```{c}
auto err = execWithElevatedPrivilege(CHOWN, _path, uid, gid)
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
                    const QUrl targetLocation = QUrl::fromLocalFile(d->m_linkTargetLineEdit->text());
                    KIO::StatJob *statJob = KIO::stat(targetLocation, KIO::HideProgressInfo);
                    bool ok = statJob->exec();
                    if (ok) {
                        KIO::highlightInFileManager({targetLocation});
                        _props->close();
                        return;
                    }
                    // Show error message if the link destination doesn't exist
                    messageWidget->animatedShow();
                }
```

#### LAMBDA EXPRESSION 


```{c}
[parentWindow](bool allowDelete, const QList<QUrl> &, KIO::AskUserActionInterface::DeletionType, QWidget *parent) {
                        if (parent != parentWindow || !allowDelete) {
                            return;
                        }

                        KIO::Job *job = KIO::emptyTrash();
                        job->setUiDelegate(new KIO::JobUiDelegate(KJobUiDelegate::AutoHandlingEnabled, parentWindow));
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KCoreDirLister *kdl : listers) {
        kdl->d->emitItems();

        kdl->d->jobDone(job);

        Q_EMIT kdl->completed(jobUrl);
        if (kdl->d->numJobs() == 0) {
            kdl->d->complete = true;
            Q_EMIT kdl->completed();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        resumeIconUpdates();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, untrustedProgramHandler](bool result) {
            if (result) {
                // Assume that service is an absolute path since we're being called (relative paths
                // would have been allowed unless Kiosk said no, therefore we already know where the
                // .desktop file is.  Now add a header to it if it doesn't already have one
                // and add the +x bit.

                QString errorString;
                if (untrustedProgramHandler->makeServiceFileExecutable(d->m_serviceEntryPath, errorString)) {
                    proceedAfterSecurityChecks();
                } else {
                    QString serviceName = d->m_service->name();
                    if (serviceName.isEmpty()) {
                        serviceName = d->m_service->genericName();
                    }
                    setError(KJob::UserDefinedError);
                    setErrorText(i18n("Unable to make the service %1 executable, aborting execution.\n%2.", serviceName, errorString));
                    emitResult();
                }
            } else {
                setError(KIO::ERR_USER_CANCELED);
                emitResult();
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, dialog, mime](const int result) {
        if (result == ExecutableFileOpenDialog::Rejected) {
            Q_EMIT canceled();
            return;
        }

        const bool isExecute = result == ExecutableFileOpenDialog::ExecuteFile;
        Q_EMIT executeFile(isExecute);

        if (dialog->isDontAskAgainChecked()) {
            KConfigGroup cfgGroup(KSharedConfig::openConfig(QStringLiteral("kiorc")), "Executable scripts");
            cfgGroup.writeEntry("behaviourOnLaunch", isExecute ? "execute" : "open");
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : _urls) {
            KRecentDocument::add(url, _service.desktopEntryName());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &item : items) {
        if (!node) { // don't lookup the first item twice
            url = item.url();
            node = nodeForUrl(url);
            if (!node) {
                qCWarning(KIO_WIDGETS) << "No node found for item that was just removed:" << url;
                continue;
            }
            if (!node->parent()) {
                // The root node has been deleted, but it was not first in the list 'items'.
                // see https://bugs.kde.org/show_bug.cgi?id=196695
                return;
            }
        }
        rowNumbers.setBit(node->rowNumber(), 1); // O(n)
        removeFromNodeHash(node, url);
        node = nullptr;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &proxyUrl : std::as_const(m_proxyUrls)) {
        const QUrl url(proxyUrl);
        const QString scheme(url.scheme());

        if (!supportedProxyScheme(scheme)) {
            // TODO: Need a new error code to indicate unsupported URL scheme.
            result = Result::fail(ERR_CANNOT_CONNECT, url.toString());
            continue;
        }

        if (!isSocksProxyScheme(scheme)) {
            const Result result = ftpOpenControlConnection(url.host(), url.port());
            if (result.success) {
                return Result::pass();
            }
            continue;
        }

        qCDebug(KIO_FTP) << "Connecting to SOCKS proxy @" << url;
        m_proxyURL = url;
        result = ftpOpenControlConnection(m_host, m_port);
        if (result.success) {
            return result;
        }
        m_proxyURL.clear();
    }
```

#### AUTO 


```{c}
const auto result = ftpRename(dest, dest_orig, KIO::Overwrite);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &domain : qAsConst(m_domainList)) {
        KCookieAdvice advice = getDomainAdvice(domain);
        if (advice != KCookieDunno) {
            const QString value = domain + QLatin1Char(':') + adviceToStr(advice);
            domainSettings.append(value);
        }
    }
```

#### AUTO 


```{c}
auto algorithm = detectAlgorithm(input);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : qAsConst(pendingUpdates)) { // always a local path
        qCDebug(KIO_CORE_DIRLISTER) << file;
        QUrl u = QUrl::fromLocalFile(file);
        KFileItem item = findByUrl(nullptr, u); // search all items
        if (!item.isNull()) {
            // we need to refresh the item, because e.g. the permissions can have changed.
            KFileItem oldItem = item;
            item.refresh();

            if (!oldItem.cmp(item)) {
                reinsert(item, oldItem.url());
                listers |= emitRefreshItem(oldItem, item);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QTreeWidgetItem *item : selectedItems) {
        nextItem = mUi.policyTreeWidget->itemBelow(item);
        if (!nextItem) {
            nextItem = mUi.policyTreeWidget->itemAbove(item);
        }

        mDomainPolicyMap.remove(item->text(0));
        delete item;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, watcher] {
            Q_Q(DropJob);

            if (watcher->isError()) {
                q->setError(KIO::ERR_UNKNOWN);
            }
            q->emitResult();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->_k_slotCreateDirectory(); }
```

#### AUTO 


```{c}
auto it = std::find_if(uniqueEntries.begin(), uniqueEntries.end(), [&url](const EntryInfo &info) {
            return url == info.url;
        });
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) {
            _k_slotIOFinished(job);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QSize &newSize) {
        d->m_autoResizeItems = (newSize.width() < 1 || newSize.height() < 1);

        if (d->m_autoResizeItems) {
            d->adaptItemSize();
        } else {
            const int iconSize = qMin(newSize.width(), newSize.height());
            d->relayoutIconSize(iconSize);
        }
        d->writeConfig();
    }
```

#### AUTO 


```{c}
static constexpr auto s_pollFreeSpaceInterval = 1min;
```

#### LAMBDA EXPRESSION 


```{c}
[&]{
        QFile(inaccessible).setPermissions(QFile::Permissions(QFile::ReadOwner | QFile::WriteOwner | QFile::ExeOwner));

        KIO::DeleteJob *deljob1 = KIO::del(QUrl::fromLocalFile(src_dir), KIO::HideProgressInfo);
        deljob1->setUiDelegate(nullptr); // no skip dialog, thanks
        QVERIFY(deljob1->exec());

        KIO::DeleteJob *deljob2 = KIO::del(QUrl::fromLocalFile(dst_dir), KIO::HideProgressInfo);
        deljob2->setUiDelegate(nullptr); // no skip dialog, thanks
        QVERIFY(deljob2->exec());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &proxyUrl : std::as_const(m_request.proxyUrls)) {
            if (proxyUrl == QLatin1String("DIRECT")) {
                QNetworkProxy::setApplicationProxy(QNetworkProxy::NoProxy);
                connectError = connectToHost(m_request.url.host(), m_request.url.port(defaultPort()), &errorString);
                if (connectError == 0) {
                    // qDebug() << "Connected DIRECT: host=" << m_request.url.host() << "port=" << m_request.url.port(defaultPort());
                    break;
                } else {
                    continue;
                }
            }

            const QUrl url(proxyUrl);
            const QString proxyScheme(url.scheme());
            if (!supportedProxyScheme(proxyScheme)) {
                connectError = ERR_CANNOT_CONNECT;
                errorString = url.toDisplayString();
                badProxyUrls << url;
                continue;
            }

            QNetworkProxy::ProxyType proxyType = QNetworkProxy::NoProxy;
            if (proxyScheme == QLatin1String("socks")) {
                proxyType = QNetworkProxy::Socks5Proxy;
            } else if (isAutoSsl()) {
                proxyType = QNetworkProxy::HttpProxy;
            }

            qCDebug(KIO_HTTP) << "Connecting to proxy: address=" << proxyUrl << "type=" << proxyType;

            if (proxyType == QNetworkProxy::NoProxy) {
                QNetworkProxy::setApplicationProxy(QNetworkProxy::NoProxy);
                connectError = connectToHost(url.host(), url.port(), &errorString);
                if (connectError == 0) {
                    m_request.proxyUrl = url;
                    // qDebug() << "Connected to proxy: host=" << url.host() << "port=" << url.port();
                    break;
                } else {
                    if (connectError == ERR_UNKNOWN_HOST) {
                        connectError = ERR_UNKNOWN_PROXY_HOST;
                    }
                    // qDebug() << "Failed to connect to proxy:" << proxyUrl;
                    badProxyUrls << url;
                }
            } else {
                QNetworkProxy proxy(proxyType, url.host(), url.port(), url.userName(), url.password());
                QNetworkProxy::setApplicationProxy(proxy);
                connectError = connectToHost(m_request.url.host(), m_request.url.port(defaultPort()), &errorString);
                if (connectError == 0) {
                    qCDebug(KIO_HTTP) << "Tunneling thru proxy: host=" << url.host() << "port=" << url.port();
                    break;
                } else {
                    if (connectError == ERR_UNKNOWN_HOST) {
                        connectError = ERR_UNKNOWN_PROXY_HOST;
                    }
                    qCDebug(KIO_HTTP) << "Failed to connect to proxy:" << proxyUrl;
                    badProxyUrls << url;
                    QNetworkProxy::setApplicationProxy(QNetworkProxy::NoProxy);
                }
            }
        }
```

#### AUTO 


```{c}
auto urlSetterClosure = [this, url](){
                    setCurrentItem(url);
                    QObject::disconnect(d->m_connection);
                };
```

#### RANGE FOR STATEMENT 


```{c}
for (const QHostAddress &address : addressList) {
        if (!result.isEmpty()) {
            result += QLatin1Char(';');
        }
        result += actualEntryMap.value(address.toString());
    }
```

#### AUTO 


```{c}
auto applyUrl = [this](QUrl url) {

        // Parts of the following code have been taken from the class KateFileSelector
        // located in kate/app/katefileselector.hpp of Kate.
        // SPDX-FileCopyrightText: 2001 Christoph Cullmann <cullmann@kde.org>
        // SPDX-FileCopyrightText: 2001 Joseph Wenninger <jowenn@kde.org>
        // SPDX-FileCopyrightText: 2001 Anders Lund <anders.lund@lund.tdcadsl.dk>

        // For example "desktop:/" _not_ "desktop:", see the comment in slotProtocolChanged()
        if (!url.isEmpty() && url.path().isEmpty()
            && KProtocolInfo::protocolClass(url.scheme()) == QLatin1String(":local")) {
            url.setPath(QStringLiteral("/"));
        }

        const auto urlStr = url.toString();
        QStringList urls = m_pathBox->urls();
        urls.removeAll(urlStr);
        urls.prepend(urlStr);
        m_pathBox->setUrls(urls, KUrlComboBox::RemoveBottom);

        q->setLocationUrl(url);
        // The URL might have been adjusted by KUrlNavigator::setUrl(), hence
        // synchronize the result in the path box.
        m_pathBox->setUrl(q->locationUrl());
    };
```

#### LAMBDA EXPRESSION 


```{c}
[&dlg]() {
        qDebug() << "Selected dir URL:" << dlg.fileWidget()->selectedUrl();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QHostAddress &address : info.addresses()) {
            if (!isSpecialAddress(address)) {
                addressList << address.toString();
            }
        }
```

#### AUTO 


```{c}
auto skipSignal = &KIO::AskUserActionInterface::askUserSkipResult;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : args) {
        // get full path
        const QString fullFilePath(QDir::current().absoluteFilePath(file));

        // construct kconfig for protocol file
        KConfig sconfig(fullFilePath);
        sconfig.setLocale(QString());
        KConfigGroup config(&sconfig, "Protocol");

        // name must be set, sanity check that file got read
        const QString name(config.readEntry("protocol"));
        if (name.isEmpty()) {
            qFatal("Failed to read input file %s.", qPrintable(fullFilePath));
        }

        // construct protocol data
        QVariantMap protocolData;

        // convert the different types
        for (const QString &key : stringAttributes) {
            if (config.hasKey(key)) {
                protocolData.insert(key, config.readEntry(key, QString()));
            }
        }
        for (const QString &key : stringListAttributes) {
            if (config.hasKey(key)) {
                protocolData.insert(key, config.readEntry(key, QStringList()));
            }
        }
        for (const QString &key : boolAttributes) {
            if (config.hasKey(key)) {
                protocolData.insert(key, config.readEntry(key, bool(false)));
            }
        }
        for (const QString& key : intAttributes) {
            if (config.hasKey(key)) {
                protocolData.insert(key, config.readEntry(key, int(0)));
            }
        }

        // handle translated keys
        for (const QString &key : translatedStringListAttributes) {
            // read untranslated entry first in any case!
            sconfig.setLocale(QString());
            protocolData.insert(key, config.readEntry(key, QStringList()));

            // collect all locales for this key
            QFile f(fullFilePath);
            QStringList foundLocalesForKey;
            if (!f.open(QIODevice::ReadOnly | QIODevice::Text)) {
                qFatal("Failed to open file %s.", qPrintable(fullFilePath));
            }
            while (!f.atEnd()) {
                const QString line = QString::fromUtf8(f.readLine());
                const QRegularExpressionMatch match = localeRegex.match(line);
                if (match.hasMatch()) {
                    foundLocalesForKey.append(match.captured(1));
                }
            }

            // insert all entries for all found locales, reparse config for this
            for (const QString &locale : qAsConst(foundLocalesForKey)) {
                sconfig.setLocale(locale);
                protocolData.insert(QStringLiteral("%1[%2]").arg(key, locale), config.readEntry(key, QStringList()));
            }
        }

        // use basename of protocol for toplevel map in json, like it is done for .protocol files
        const QString baseName(QFileInfo (fullFilePath).baseName());
        protocolsData.insert(baseName, protocolData);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, dialogFinished](bool shouldExecute) {
        m_runExecutables = shouldExecute;
        dialogFinished(shouldExecute);
    }
```

#### AUTO 


```{c}
const auto result = ftpOpenConnection(LoginMode::Defered);
```

#### RANGE FOR STATEMENT 


```{c}
for (const HeaderFieldTemplate &ft : headerFieldTemplates) {
        insert(QByteArray(ft.name), HeaderField(ft.isMultiValued));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (KJob *job) { _k_slotStatResult(job); }
```

#### AUTO 


```{c}
auto lid = lock();
```

#### RANGE FOR STATEMENT 


```{c}
for (KCoreDirLister *kdl : std::as_const(curListers)) { // listers of newUrl
                kdl->d->jobDone(oldJob);

                kdl->jobStarted(job);
                kdl->d->connectJob(job);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[mimeType](const QString &supportedMimeType) {
            return mimeType.inherits(supportedMimeType);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->slotSortByDate();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &device) { _k_deviceAdded(device); }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                fileDialogMode = KFile::File;
                applyFileMode(m_parent->fileDialog(), fileDialogMode, fileDialogAcceptMode);
                m_fileDialogModeWasDirAndFile = true;
                createFileDialog();
            }
```

#### LAMBDA EXPRESSION 


```{c}
[](KIO::Slave *slave) {
            schedulerPrivate()->slotSlaveDied(slave);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            slotAboutToHide();
        }
```

#### AUTO 


```{c}
auto error = job->error();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        const QStringList protocols = d->service.property(QStringLiteral("X-KDE-Protocols")).toStringList();
        return !protocols.isEmpty() && !protocols.contains(QLatin1String("KIO"));
    }
```

#### AUTO 


```{c}
auto removePredicate = [&mit](const std::unique_ptr<const KUrlComboBoxPrivate::KUrlComboItem> &item) {
                return item.get() == mit.value();
            };
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        Q_EMIT q->urlChanged(m_coreUrlNavigator->currentLocationUrl());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &location : locations) {
            map.insert(location, mapping[i].name);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &httpHeader : httpHeaders) {
            int index = httpHeader.indexOf(QL1C(':'));
            // Handle HTTP status line...
            if (index == -1) {
                // Except for the status line, all HTTP header must be an nvpair of
                // type "<name>:<value>"
                if (!httpHeader.startsWith(QLatin1String("HTTP/"), Qt::CaseInsensitive)) {
                    continue;
                }

#if QT_VERSION < QT_VERSION_CHECK(5, 15, 0)
                QStringList statusLineAttrs(httpHeader.split(QL1C(' '), QString::SkipEmptyParts));
#else
                QStringList statusLineAttrs(httpHeader.split(QL1C(' '), Qt::SkipEmptyParts));
#endif
                if (statusLineAttrs.count() > 1) {
                    setAttribute(QNetworkRequest::HttpStatusCodeAttribute, statusLineAttrs.at(1));
                }

                if (statusLineAttrs.count() > 2) {
                    setAttribute(QNetworkRequest::HttpReasonPhraseAttribute, statusLineAttrs.at(2));
                }

                continue;
            }

            const QStringRef headerName = httpHeader.leftRef(index);
            QString headerValue = httpHeader.mid(index + 1);

            // Ignore cookie header since it is handled by the http ioslave.
            if (headerName.startsWith(QLatin1String("set-cookie"), Qt::CaseInsensitive)) {
                continue;
            }

            if (headerName.startsWith(QLatin1String("content-disposition"), Qt::CaseInsensitive) &&
                    ignoreContentDisposition(metaData)) {
                continue;
            }

            // Without overriding the corrected mime-type sent by kio_http, add
            // back the "charset=" portion of the content-type header if present.
            if (headerName.startsWith(QLatin1String("content-type"), Qt::CaseInsensitive)) {

                QString mimeType(header(QNetworkRequest::ContentTypeHeader).toString());

                if (m_ignoreContentDisposition) {
                    // If the server returned application/octet-stream, try to determine the
                    // real content type from the disposition filename.
                    if (mimeType == QLatin1String("application/octet-stream")) {
                        const QString fileName(metaData.value(QStringLiteral("content-disposition-filename")));
                        QMimeDatabase db;
                        QMimeType mime = db.mimeTypeForFile((fileName.isEmpty() ? url().path() : fileName), QMimeDatabase::MatchExtension);
                        mimeType = mime.name();
                    }
                    metaData.remove(QStringLiteral("content-disposition-type"));
                    metaData.remove(QStringLiteral("content-disposition-filename"));
                }

                if (!headerValue.contains(mimeType, Qt::CaseInsensitive)) {
                    index = headerValue.indexOf(QL1C(';'));
                    if (index == -1) {
                        headerValue = mimeType;
                    } else {
                        headerValue.replace(0, index, mimeType);
                    }
                    //qDebug() << "Changed mime-type from" << mimeType << "to" << headerValue;
                }
            }
            setRawHeader(headerName.trimmed().toUtf8(), headerValue.trimmed().toUtf8());
        }
```

#### AUTO 


```{c}
const auto it = std::find_if(buttons.cbegin(), buttons.cend(), [](QPushButton *button) {
            return button->text() == QLatin1String("&Here");
            });
```

#### RANGE FOR STATEMENT 


```{c}
for (const KService::Ptr &plugin : plugins) {
        const QString desktopEntryName = plugin->desktopEntryName();
        if (!result.contains(desktopEntryName)) {
            result.append(desktopEntryName);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        slotConnected();
    }
```

#### AUTO 


```{c}
auto err = execWithElevatedPrivilege(MKDIR, path)
```

#### AUTO 


```{c}
auto *job = new KIO::ApplicationLauncherJob();
```

#### AUTO 


```{c}
const auto &format
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        openPathSelectorMenu();
    }
```

#### AUTO 


```{c}
auto *processRunner = new KProcessRunner(cmd, execName, iconName, windowId, asn, workingDirectory);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QUrl &url) {
        slotRedirection(url);
    }
```

#### AUTO 


```{c}
auto err = execWithElevatedPrivilege(MKDIR, {path}, errno)
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &mimeType) {
        slotMimetype(mimeType);
    }
```

#### AUTO 


```{c}
auto err = execWithElevatedPrivilege(RMDIR, {_path}, errno)
```

#### RANGE FOR STATEMENT 


```{c}
for (const KUrlNavigatorButton *button : qAsConst(m_navButtons)) {
        requiredButtonWidth += button->minimumWidth();
    }
```

#### AUTO 


```{c}
const auto ignoredErrors = rule.ignoredErrors();
```

#### AUTO 


```{c}
auto updateContentFunc = [this]() {
            updateContent();
        };
```

#### RANGE FOR STATEMENT 


```{c}
for (KJob *job : subjobs()) {
        if (!job->suspend()) {
            return false;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        const int errCode = job->error();
        if (errCode) {
            // ERR_NO_CONTENT is not an error, but an indication no further
            // actions need to be taken.
            if (errCode != KIO::ERR_NO_CONTENT) {
                q->setError(errCode);
                q->setErrorText(job->errorText());
            }
            q->emitResult();
        }
        // if the job succeeded, we certainly hope it emitted mimeTypeFound()...
        if (m_mimeTypeName.isEmpty()) {
            qCWarning(KIO_CORE) << "KIO::get didn't emit a mimetype! Please fix the ioslave for URL" << m_url;
            q->setError(KIO::ERR_INTERNAL);
            q->setErrorText(i18n("Unable to determine the type of file for %1", m_url.toDisplayString()));
            q->emitResult();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &text) { d->_k_slotNameTextChanged(text); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job, const QString &plain){ _k_slotInfoMessage(job, plain); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &id) { _k_itemChanged(id); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : urlList) {
        QMimeType mimetype = db.mimeTypeForUrl(url);
        if (mimetype.inherits(QStringLiteral("inode/directory"))) {
            m_placesModel->addPlace(url.fileName(), url);
        }
    }
```

#### AUTO 


```{c}
const auto &val = it.value();
```

#### RANGE FOR STATEMENT 


```{c}
for (KUrlNavigatorButton *button : qAsConst(d->m_navButtons)) {
            button->setShowMnemonic(false);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &arg) {
        return !arg.contains(QLatin1Char('='));
    }
```

#### AUTO 


```{c}
const auto ksslErrors = socket->sslErrors();
```

#### AUTO 


```{c}
auto *processRunner = new KProcessRunner(d->m_service, d->m_urls,
                                             d->m_runFlags, d->m_suggestedFileName, d->m_startupId);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &item : items) {
        mimeType = item.mimetype();
        const int slashIndex = mimeType.indexOf(QLatin1Char('/'));
        const auto mimeTypeGroup = QStringView(mimeType).left(slashIndex);
        if (mimeTypeGroup == QLatin1String("image")) {
            imageItems.append(item);
        } else {
            otherItems.append(item);
        }
    }
```

#### AUTO 


```{c}
const auto symLinkFileName = QFile::encodeName(dest + "/symlink_to_dir").constData();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QHostAddress& address : addresses) {
        if (isIPv4Address(address) && !isSpecialAddress(address) && !isLocalHostAddress(address)) {
            ipAddress = address.toString();
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KPropertiesDialogPlugin *it : qAsConst(d->m_pageList)) {
        if (qobject_cast<KUrlPropsPlugin *>(it) ||
                qobject_cast<KDesktopPropsPlugin *>(it)) {
            //qDebug() << "Setting page dirty";
            it->setDirty();
            break;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString &mt) {
        if (mt == itemMimeType || mt == QLatin1String("all/all")) {
            return true;
        }

        if (item.isFile() //
            && (mt == QLatin1String("allfiles") || mt == QLatin1String("all/allfiles") || mt == QLatin1String("application/octet-stream"))) {
            return true;
        }

        if (item.currentMimeType().inherits(mt)) {
            return true;
        }

        if (mt.endsWith(QLatin1String("/*"))) {
            const int slashPos = mt.indexOf(QLatin1Char('/'));
            const auto topLevelType = QStringView(mt).mid(0, slashPos);
            return itemMimeType.startsWith(topLevelType);
        }
        return false;
    }
```

#### AUTO 


```{c}
auto watcher = std::make_shared<QDBusPendingCallWatcher>(pending);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KServiceAction &serviceAction : std::as_const(sortedList)) {
        if (serviceAction.isSeparator()) {
            const QList<QAction *> actions = menu->actions();
            if (!actions.isEmpty() && !actions.last()->isSeparator()) {
                menu->addSeparator();
            }
            continue;
        }

        if (isBuiltin || !serviceAction.noDisplay()) {
            QAction *act = new QAction(q);
            act->setObjectName(QStringLiteral("menuaction")); // for the unittest
            QString text = serviceAction.text();
            text.replace(QLatin1Char('&'), QLatin1String("&&"));
            act->setText(text);
            if (!serviceAction.icon().isEmpty()) {
                act->setIcon(QIcon::fromTheme(serviceAction.icon()));
            }
            act->setData(QVariant::fromValue(serviceAction));
            m_executeServiceActionGroup.addAction(act);

            menu->addAction(act); // Add to toplevel menu
            ++count;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &domain : list) {
        eatCookiesForDomain(domain);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &deletedUrl : qAsConst(affectedItems)) {
        // stop all jobs for deletedUrlStr
        DirectoryDataHash::iterator dit = directoryData.find(deletedUrl);
        if (dit != directoryData.end()) {
            // we need a copy because stop modifies the list
            const QList<KCoreDirLister *> listers = (*dit).listersCurrentlyListing;
            for (KCoreDirLister *kdl : listers) {
                stopListingUrl(kdl, deletedUrl);
            }
            // tell listers holding deletedUrl to forget about it
            // this will stop running updates for deletedUrl as well

            // we need a copy because forgetDirs modifies the list
            const QList<KCoreDirLister *> holders = (*dit).listersCurrentlyHolding;
            for (KCoreDirLister *kdl : holders) {
                // lister's root is the deleted item
                if (kdl->d->url == deletedUrl) {
                    // tell the view first. It might need the subdirs' items (which forgetDirs will delete)
                    if (!kdl->d->rootFileItem.isNull()) {
                        emit kdl->itemsDeleted(KFileItemList() << kdl->d->rootFileItem);
                    }
                    forgetDirs(kdl);
                    kdl->d->rootFileItem = KFileItem();
                } else {
                    const bool treeview = kdl->d->lstDirs.count() > 1;
                    if (!treeview) {
                        emit kdl->clear();
                        kdl->d->lstDirs.clear();
                    } else {
                        kdl->d->lstDirs.removeAll(deletedUrl);
                    }

                    forgetDirs(kdl, deletedUrl, treeview);
                }
            }
        }

        // delete the entry for deletedUrl - should not be needed, it's in
        // items cached now
        int count = itemsInUse.remove(deletedUrl);
        Q_ASSERT(count == 0);
        Q_UNUSED(count);   //keep gcc "unused variable" complaining quiet when in release mode
    }
```

#### AUTO 


```{c}
auto *askUserInterface = KIO::delegateExtension<AskUserActionInterface *>(q);
```

#### AUTO 


```{c}
auto qtOpenUrl = [this]() {
        if (!QDesktopServices::openUrl(d->m_url)) {
            // Is this an actual error, or USER_CANCELED?
            setError(KJob::UserDefinedError);
            setErrorText(i18n("Failed to open %1", d->m_url.toDisplayString()));
        }
        emitResult();
    };
```

#### LAMBDA EXPRESSION 


```{c}
[](const KUriFilterPlugin *plugin) { return plugin->objectName(); }
```

#### AUTO 


```{c}
auto index
```

#### LAMBDA EXPRESSION 


```{c}
[this](qreal value) { d->_k_itemDisappearUpdate(value); }
```

#### IF STATEMENT WITH INITIALIZER 


```{c}
if (const QDateTime dt = firstItem.time(KFileItem::AccessTime); !dt.isNull()) {
            d->m_ui->accessTimeLabel->setText(locale.toString(dt, QLocale::LongFormat));
        } else {
            d->m_ui->accessTimeLabel->hide();
        }
```

#### CONST EXPRESSION 


```{c}
static constexpr int DEFAULT_MAX_CACHE_AGE = 60 * 60 * 24 * 14;
```

#### AUTO 


```{c}
const auto attributes = xml.attributes();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &group : qAsConst(groups)) {
                    output.writeTextElement(bookmarkGroup, stringForRecentDocumentGroup(group));
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this](int value) {
        slotIconSizeChanged(value);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[udsField](const Field &entry) {
        return entry.m_index == udsField;
    }
```

#### AUTO 


```{c}
const auto kend = allItems->constEnd();
```

#### LAMBDA EXPRESSION 


```{c}
[this, query](const QHostInfo &info) {
        queryFinished(info, query);
    }
```

#### AUTO 


```{c}
auto inaccessibleUrl = this->url(inaccessiblePath);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &path) {
            d->_k_slotFileChange(path);
        }
```

#### AUTO 


```{c}
auto removePredicate = [&mit](const std::unique_ptr<const KUrlComboBoxPrivate::KUrlComboItem>& item) {
                return item.get() == mit.value();
            };
```

#### LAMBDA EXPRESSION 


```{c}
[&url](const KFileItem &item) {
        return item.url() == url;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->assureVisibleSelection(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QModelIndex &idx, bool success) {
            _k_storageSetupDone(idx, success);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[launchedSerial, job](int serial, const QString &token) {
            if (serial == launchedSerial) {
                job->setStartupId(token.toLatin1());
                job->start();
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=](RenameDialog_Result result, const QUrl &newUrl, KJob *parentJob) {
                Q_ASSERT(parentJob == q);
                // Only receive askUserRenameResult once per rename dialog
                QObject::disconnect(askUserActionInterface, renameSignal, q, nullptr);
                processFileRenameDialogResult(it, result, newUrl, destmtime);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        const QString checksum = futureWatcher->result();
        futureWatcher->deleteLater();

        label->setText(checksum);
        cacheChecksum(checksum, algorithm);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QUrl &, const KFileItemList &items) {
                if (tags.isEmpty()) {
                    QList<QUrl> existingBookmarks;

                    KBookmarkGroup root = bookmarkManager->root();
                    KBookmark bookmark = root.first();

                    while (!bookmark.isNull()) {
                        existingBookmarks.append(bookmark.url());
                        bookmark = root.next(bookmark);
                    }

                    if (!existingBookmarks.contains(QUrl(tagsUrlBase))) {
                        KBookmark alltags = KFilePlacesItem::createSystemBookmark(bookmarkManager,
                                                                                  "All tags",
                                                                                  i18n("All tags").toUtf8().data(),
                                                                                  QUrl(tagsUrlBase),
                                                                                  QStringLiteral("tag"));
                    }
                }

                for (const KFileItem &item : items) {
                    const QString name = item.name();

                    if (!tags.contains(name)) {
                        tags.append(name);
                    }
                }
                reloadBookmarks();
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const int index) {
        slotPolicyChanged(mUi.cbPolicy->itemText(index));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job, const QString &plain) {
        slotInfoMessage(job, plain);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KUrlNavigatorButton *button : std::as_const(d->m_navButtons)) {
            button->setShowMnemonic(false);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &encoding : encodings) {
        bool found = false;
        QTextCodec *codecForEnc = KCharsets::charsets()->codecForName(encoding, found);

        if (found) {
            d->encoding->addItem(encoding);
            const QString codecName = QLatin1String(codecForEnc->name());
            if ((codecName == sEncoding) || (encoding == sEncoding)) {
                d->encoding->setCurrentIndex(insert);
                foundRequested = true;
            }

            if ((codecName == systemEncoding) || (encoding == systemEncoding)) {
                system = insert;
            }
            insert++;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&mime](const QString &filter) {
        return mime == filter;
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr int s_slaveConnectionTimeoutMin = 2;
```

#### LAMBDA EXPRESSION 


```{c}
[this, persistentIndex](KIO::Job *job, KIO::filesize_t size, KIO::filesize_t available) {
                         if (!persistentIndex.isValid()) {
                             return;
                         }

                         if (job->error()) {
                             return;
                         }

                         PlaceFreeSpaceInfo &info = m_freeSpaceInfo[persistentIndex];

                         info.size = size;
                         info.used = size - available;

                         m_view->update(persistentIndex);
                     }
```

#### RANGE FOR STATEMENT 


```{c}
for (const ItemInfo &preview : std::as_const(m_previews)) {
                const QModelIndex idx = dirModel->indexForUrl(preview.url);
                if (idx.isValid() && (idx.column() == 0)) {
                    dirModel->setData(idx, QIcon(preview.pixmap), Qt::DecorationRole);
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool show) { d->slotToggleHidden(show); }
```

#### AUTO 


```{c}
auto *job = new KTerminalLauncherJob(command, this);
```

#### AUTO 


```{c}
const auto value = cookieView.right(cookie.length() - index - 1);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &urlFetched : qAsConst(urlsBeingFetched)) {
                if (dirUrl.matches(urlFetched, QUrl::StripTrailingSlash) || dirUrl.isParentOf(urlFetched)) {
                    //qDebug() << "Listing found" << dirUrl.url() << "which is a parent of fetched url" << urlFetched;
                    const QModelIndex parentIndex = indexForNode(node, dirNode->m_childNodes.count() - 1);
                    Q_ASSERT(parentIndex.isValid());
                    emitExpandFor.append(parentIndex);
                    if (isDir && dirUrl != urlFetched) {
                        q->fetchMore(parentIndex);
                        m_urlsBeingFetched[node].append(urlFetched);
                    }
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KService::Ptr &handler : handlers) {
            if (handler->desktopEntryName() == d->service.desktopEntryName()) {
                useKioexec = false;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (KDirModelNode *node : m_childNodes) {
            const KFileItem &item = node->item();
            urls.append(cleanupUrl(item.url()));
            if (item.isDir()) {
                static_cast<KDirModelDirNode *>(node)->collectAllChildUrls(urls);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto iconSize : iconSizes) {
        auto *act = new QAction(group);
        act->setCheckable(true);

        switch (iconSize) {
        case KIconLoader::SizeSmall:
            act->setText(i18nc("Small icon size", "Small (%1x%1)", KIconLoader::SizeSmall));
            break;
        case KIconLoader::SizeSmallMedium:
            act->setText(i18nc("Medium icon size", "Medium (%1x%1)", KIconLoader::SizeSmallMedium));
            break;
        case KIconLoader::SizeMedium:
            act->setText(i18nc("Large icon size", "Large (%1x%1)", KIconLoader::SizeMedium));
            break;
        case KIconLoader::SizeLarge:
            act->setText(i18nc("Huge icon size", "Huge (%1x%1)", KIconLoader::SizeLarge));
            break;
        default:
            break;
        }

        QObject::connect(act, &QAction::toggled, q, [this, iconSize]() {
            m_autoResizeItems = false;
            relayoutIconSize(iconSize);
            // Store the new icon size in m_iconSz; which will be used by writeConfig(),
            // otherwise if m_smoothItemResizing is true, the delegate icon size will be
            // changed after the m_adaptItemsTimeline times out, by which time writeConfig
            // has already finished, which means it won't save the new icon size
            m_iconSz = iconSize;
            writeConfig();
        });

        if (!m_autoResizeItems) {
            act->setChecked(iconSize == m_delegate->iconSize());
        }

        submenu->addAction(act);
    }
```

#### AUTO 


```{c}
auto it = currentGroup->subGroups.constFind(group);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &service) { _k_serviceRegistered(service); }
```

#### LAMBDA EXPRESSION 


```{c}
[this, dlg](int result) {
                retryDialogDone(result, dlg);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QUrl &url) {
        urlEntered(url);
    }
```

#### AUTO 


```{c}
auto *navBtn = *it;
```

#### AUTO 


```{c}
const auto fileMime = mimeDb.mimeTypeForUrl(url).name();
```

#### LAMBDA EXPRESSION 


```{c}
[&](KJob *job) {
            app.exit(job->error());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](int pos, int index) {
        d->slotSplitterMoved(pos, index);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &errorText) {
        setError(KJob::UserDefinedError);
        setErrorText(errorText);
        emitResult();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KCoreDirLister *listit : std::as_const(listersWithoutJob)) {
        qCWarning(KIO_CORE) << "Fatal Error: HUH? Lister" << listit << "is supposed to be listing, but has no job!";
        abort();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { slotFinished(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &match) {
        d->fileCompletion(match);
    }
```

#### AUTO 


```{c}
auto it = items.cbegin(), itEnd = items.constEnd();
```

#### RANGE FOR STATEMENT 


```{c}
for (KUrlNavigatorButton *button : qAsConst(buttonsToShow)) {
        button->show();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &filename : fileList) {
            const QString filePath = m_homeDir + filename;
            if (!QFile::exists(filePath)) {
                return false;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const AutoLogin &log : l) {
        if ((mode & defaultOnly) == defaultOnly && log.machine == QLatin1String("default") && (login.login.isEmpty() || login.login == log.login)) {
            login.type = log.type;
            login.machine = log.machine;
            login.login = log.login;
            login.password = log.password;
            login.macdef = log.macdef;
        }

        if ((mode & presetOnly) == presetOnly && log.machine == QLatin1String("preset") && (login.login.isEmpty() || login.login == log.login)) {
            login.type = log.type;
            login.machine = log.machine;
            login.login = log.login;
            login.password = log.password;
            login.macdef = log.macdef;
        }

        if ((mode & exactOnly) == exactOnly && log.machine == url.host() && (login.login.isEmpty() || login.login == log.login)) {
            login.type = log.type;
            login.machine = log.machine;
            login.login = log.login;
            login.password = log.password;
            login.macdef = log.macdef;
            break;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, localPath, isNativeBinary](bool shouldExecute) {
            if (shouldExecute) {
                if (isNativeBinary) {
                    if (!hasExecuteBit(localPath)) {
                        showUntrustedProgramWarningDialog(localPath);
                        return;
                    }
                    executeCommand(); // Local executable with execute bit, proceed
                } else { // For .exe files, open in the default app (e.g. WINE)
                    openInPreferredApp();
                }
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[] {
        QFile::remove(otherTmpDir() + "anotherFile");
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KIO::ListJob *job, KIO::ListJob *ljob) {slotSubError(job, ljob);}
```

#### LAMBDA EXPRESSION 


```{c}
[this, filePath](bool shouldExecute) {
                if (shouldExecute) { // Run the file
                    KService::Ptr service(new KService(filePath));
                    startService(service, {});
                    return;
                }
                // The user selected "open"
                openInPreferredApp();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KServicePtr &service : std::as_const(offers)) {
                QAction *act = createAppAction(service, false);
                subMenu->addAction(act);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &dir : qAsConst(installedTemplates)) {
            s->dirWatch->addDir(dir);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&p](const KUrlNavigatorButton *button) {
            return button->geometry().contains(p);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QModelIndex &index) {
        d->placeLeft(index);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const char *mimeType : {"text/plain", "application/x-shellscript"}) {
        KService::Ptr preferredTextEditor = KApplicationTrader::preferredService(QString::fromLatin1(mimeType));
        QVERIFY(preferredTextEditor);
        QCOMPARE(preferredTextEditor->entryPath(), fakeService);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KUriFilterSearchProvider *searchProvider : providers) {
        data.d->searchProviderList << searchProvider->name();
        data.d->searchProviderMap.insert(searchProvider->name(), searchProvider);
    }
```

#### AUTO 


```{c}
const auto itemsList = properties->items();
```

#### LAMBDA EXPRESSION 


```{c}
[this, &shorthand](const SearchProvider *provider) {
            return provider != m_provider && provider->keys().contains(shorthand);
        }
```

#### AUTO 


```{c}
auto job = KIO::copy({ QUrl::fromLocalFile(QFINDTESTDATA("ftp/testCopy1")) }, url, KIO::DefaultFlags);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &device) {
        _k_deviceRemoved(device);
    }
```

#### AUTO 


```{c}
auto dialogFinished = [this, localPath, isNativeBinary](bool shouldExecute) {
            // shouldExecute is always true if we get here, because for binaries the
            // dialog only offers Execute/Cancel
            Q_UNUSED(shouldExecute)

            handleBinariesHelper(localPath, isNativeBinary);
        };
```

#### AUTO 


```{c}
const auto signalCode = properties[QStringLiteral("ExecMainCode")].value<qint32>();
```

#### AUTO 


```{c}
const auto urlSrc = QUrl::fromLocalFile(src);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &text) { d->locationAccepted(text); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &filename : fileList) {
            const QString filePath = m_homeDir + filename;
            srcList.append(QUrl::fromLocalFile(filePath));
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                slotDataReqFromDevice();
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this](){ slotConnected();}
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob* job, ulong speed) { _k_slotSpeed(job, speed); }
```

#### RANGE FOR STATEMENT 


```{c}
for (KCoreDirLister *kdl : qAsConst(curHolders)) { // holders of newUrl
                kdl->jobStarted(job);
                Q_EMIT kdl->started(newUrl);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &item : std::as_const(m_items)) {
        const QString itemMimeType = item.mimetype();
        // Determine if common MIME type among all items
        if (m_mimeType != itemMimeType) {
            m_mimeType.clear();
            if (m_mimeGroup != itemMimeType.leftRef(itemMimeType.indexOf(QLatin1Char('/')))) {
                m_mimeGroup.clear(); // MIME type groups are different as well!
            }
        }
    }
```

#### AUTO 


```{c}
auto *processRunner = KProcessRunner::fromApplication(d->m_service, { d->m_urls.at(i) },
                                                                  d->m_runFlags, d->m_suggestedFileName, QByteArray());
```

#### RANGE FOR STATEMENT 


```{c}
for (const KServiceAction &action : userServices) {
                if (showGroup.readEntry(action.name(), true)) {
                    list += action;
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KIO::Job *job, const KIO::UDSEntryList &list) {
            _k_slotEntries(job, list);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, localPath, isNativeBinary](bool shouldExecute) {
            // shouldExecute is always true if we get here, because for binaries the
            // dialog only offers Execute/Cancel
            Q_UNUSED(shouldExecute)

            handleBinariesHelper(localPath, isNativeBinary);
        }
```

#### AUTO 


```{c}
auto *job = new KIO::ApplicationLauncherJob(servicePtr);
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &action) {
        return KAuthorized::authorize(action.trimmed());
    }
```

#### AUTO 


```{c}
auto xbelContent = xbelFile.readAll();
```

#### AUTO 


```{c}
auto it = d->mapConfig.cbegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &dir : urls) {
            handleFileDirty(dir); // e.g. for permission changes
            handleDirDirty(dir);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : lst) {
        fnames += QDir::toNativeSeparators(url.path());
    }
```

#### AUTO 


```{c}
const auto result = KMessageBox::questionYesNo(
                    nullptr,
                    i18n("The supposedly temporary file\n%1\nhas been modified.\nDo you still want to delete it?", dest.toDisplayString(QUrl::PreferLocalFile)),
                    i18n("File Changed"),
                    KStandardGuiItem::del(),
                    KGuiItem(i18n("Do Not Delete")));
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &item : items) {
            qDebug() << "Item:" << item.url();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QSslError::SslError error : errors) {
        if (!isErrorIgnored(error)) {
            d->ignoredErrors.append(error);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const KFileItemList &items) { updateIcons(items); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : files) {
        // qDebug() << file;
        KNewFileMenuSingleton::Entry entry;
        entry.filePath = file;
        entry.entryType = KNewFileMenuSingleton::Unknown; // not parsed yet

        // Put Directory first in the list (a bit hacky),
        // and TextFile before others because it's the most used one.
        // This also sorts by user-visible name.
        // The rest of the re-ordering is done in fillMenu.
        const KDesktopFile config(file);
        const QString url = config.desktopGroup().readEntry("URL");
        QString key = config.desktopGroup().readEntry("Name");
        if (file.endsWith(QLatin1String("Directory.desktop"))) {
            key.prepend(QLatin1Char('0'));
        } else if (file.startsWith(QDir::homePath())) {
            key.prepend(QLatin1Char('1'));
        } else if (file.endsWith(QLatin1String("TextFile.desktop"))) {
            key.prepend(QLatin1Char('2'));
        } else {
            key.prepend(QLatin1Char('3'));
        }

        EntryInfo eInfo = {key, url, entry};
        auto it = std::find_if(uniqueEntries.begin(), uniqueEntries.end(), [&url](const EntryInfo &info) {
            return url == info.url;
        });

        if (it != uniqueEntries.cend()) {
            *it = eInfo;
        } else {
            uniqueEntries.push_back(eInfo);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &domain : list) {
        setDomainAdvice(domain, KCookieDunno);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        updateCutItems();
    }
```

#### AUTO 


```{c}
const auto groupName = groupNameFromIndex(index);
```

#### AUTO 


```{c}
auto item = d->itemMapper.value(index);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : qAsConst(m_urls)) {
        args << url.toLocalFile(); // assume local files
    }
```

#### AUTO 


```{c}
auto *placesModel = qobject_cast<const KFilePlacesModel *>(index.model())
```

#### AUTO 


```{c}
auto reply = QDBusConnection::sessionBus().call(msg);
```

#### LAMBDA EXPRESSION 


```{c}
[this, persistentIndex](KIO::Job *job, KIO::filesize_t size, KIO::filesize_t available) {
                    PlaceFreeSpaceInfo &info = m_freeSpaceInfo[persistentIndex];

                    // even if we receive an error we want to refresh lastUpdated to avoid repeatedly querying in this case
                    info.lastUpdated = QDateTime::currentDateTimeUtc();

                    if (job->error()) {
                        return;
                    }

                    info.size = size;
                    info.used = size - available;

                    // FIXME scheduleDelayedItemsLayout but we're in the delegate here, not the view
                }
```

#### LAMBDA EXPRESSION 


```{c}
do {
        return copy({"4!"_rc}, "4! copy"_rc);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        d->m_ui.lineEdit->setText(clipboard->text());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QSslError::SslError e : ignoredErrors) {
#endif
            sl.append(d->sslErrorToString.value(e));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : urls) {
            // TODO: use KIO::stat in order to get the UDS_DISPLAY_NAME too
            KIO::MimetypeJob *job = KIO::mimetype(url);

            QString mimeString;
            if (!job->exec()) {
                mimeString = QStringLiteral("unknown");
            } else {
                mimeString = job->mimetype();
            }

            QMimeType mimetype = db.mimeTypeForName(mimeString);

            if (!mimetype.isValid()) {
                qWarning() << "URL not added to Places as MIME type could not be determined!";
                continue;
            }

            if (!mimetype.inherits(QStringLiteral("inode/directory"))) {
                // Only directories are allowed
                continue;
            }

            KFileItem item(url, mimetype.name(), S_IFDIR);

            KBookmark bookmark = KFilePlacesItem::createBookmark(d->bookmarkManager,
                                 url.fileName(), url,
                                 item.iconName());
            group.moveBookmark(bookmark, afterBookmark);
            afterBookmark = bookmark;
        }
```

#### AUTO 


```{c}
auto it = list.cbegin() + 1;
```

#### LAMBDA EXPRESSION 


```{c}
do {
        return doRename({"4"_rc}, "4!"_rc);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString & envVar : envVars) {
        const QByteArray envVarUtf8(envVar.toUtf8());
        const QByteArray envVarValue = qgetenv(envVarUtf8.constData());
        if (!envVarValue.isEmpty()) {
            if (showValue) {
                mProxyMap[edit->objectName()] = envVar;
                edit->setText(QString::fromUtf8(envVarValue));
            } else {
                edit->setText(envVar);
            }
            edit->setEnabled(!showValue);
            return true;
        }
    }
```

#### AUTO 


```{c}
auto mountPoint = KMountPoint::currentMountPoints().findByPath(m_access->filePath());
```

#### LAMBDA EXPRESSION 


```{c}
[=] {
            done(ExecuteFile);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &s : sl) {
        QList<KSslError::Error> certErrors;
#if QT_VERSION < QT_VERSION_CHECK(5, 15, 0)
        const QStringList sl2 = s.split(QLatin1Char('\t'), QString::SkipEmptyParts);
#else
        const QStringList sl2 = s.split(QLatin1Char('\t'), Qt::SkipEmptyParts);
#endif
        for (const QString &s2 : sl2) {
            bool didConvert;
            KSslError::Error error = KSslErrorPrivate::errorFromQSslError(static_cast<QSslError::SslError>(s2.toInt(&didConvert)));
            if (didConvert) {
                certErrors.append(error);
            }
        }
        ret.append(certErrors);
    }
```

#### AUTO 


```{c}
auto createSystemBookmark = [this, &seenUrls](const char *translationContext,
                const QByteArray &untranslatedLabel,
                const QUrl &url,
                const QString &iconName) {
            if (!seenUrls.contains(url)) {
                KFilePlacesItem::createSystemBookmark(d->bookmarkManager, translationContext, untranslatedLabel, url, iconName);
            }
        };
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &data : plugin_offers) {
        if (auto plugin = KPluginFactory::instantiatePlugin<KIO::DndPopupMenuPlugin>(data).plugin) {
            const auto actions = plugin->setup(itemProps, m_destUrl);
            for (auto action : actions) {
                action->setParent(popup);
            }
            m_pluginActions += actions;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        zoomOutIconsSize();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : std::as_const(m_srcList)) {
            const QString extension = db.suffixForFileName(url.path());
            const auto [it, isInserted] = extensions.insert(extension);
            if (!isInserted) {
                m_allExtensionsDifferent = false;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const HTTPRequest &r : std::as_const(m_requestQueue)) {
            m_request = r;
            qCDebug(KIO_HTTP) << "check two: isKeepAlive =" << m_request.isKeepAlive;
            setMetaData(QStringLiteral("request-id"), QString::number(requestId++));
            sendAndKeepMetaData();
            if (!(readResponseHeader() && readBody())) {
                return;
            }
            // the "next job" signal for ParallelGetJob is data of size zero which
            // readBody() sends without our intervention.
            qCDebug(KIO_HTTP) << "check three: isKeepAlive =" << m_request.isKeepAlive;
            httpClose(m_request.isKeepAlive); // actually keep-alive is mandatory for pipelining
        }
```

#### AUTO 


```{c}
const auto &jsonMetadata
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &service : fileItemPlugins) {
        if (!showGroup.readEntry(service->desktopEntryName(), true)) {
            // The plugin has been disabled
            continue;
        }

        KAbstractFileItemActionPlugin *abstractPlugin = m_loadedPlugins.value(service->desktopEntryName());
        if (!abstractPlugin) {
            abstractPlugin = service->createInstance<KAbstractFileItemActionPlugin>(this);
            connect(abstractPlugin, &KAbstractFileItemActionPlugin::error, q, &KFileItemActions::error);
            m_loadedPlugins.insert(service->desktopEntryName(), abstractPlugin);
        }
        if (abstractPlugin) {
            auto actions = abstractPlugin->actions(m_props, m_parentWidget);
            itemCount += actions.count();
            mainMenu->addActions(actions);
            addedPlugins.append(service->desktopEntryName());
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        d->m_delegate->paletteChange();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](qint64 pid) {
        d->slotStarted(pid);
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr int DEFAULT_CACHE_EXPIRE = 3 * 60;
```

#### RANGE FOR STATEMENT 


```{c}
for (KCoreDirLister *kdl : holders) {
                // lister's root is the deleted item
                if (kdl->d->url == deletedUrl) {
                    // tell the view first. It might need the subdirs' items (which forgetDirs will delete)
                    if (!kdl->d->rootFileItem.isNull()) {
                        emit kdl->itemsDeleted(KFileItemList{kdl->d->rootFileItem});
                    }
                    forgetDirs(kdl);
                    kdl->d->rootFileItem = KFileItem();
                } else {
                    const bool treeview = kdl->d->lstDirs.count() > 1;
                    if (!treeview) {
                        emit kdl->clear();
                        kdl->d->lstDirs.clear();
                    } else {
                        kdl->d->lstDirs.removeAll(deletedUrl);
                    }

                    forgetDirs(kdl, deletedUrl, treeview);
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[=](RenameDialog_Result result, const QUrl &newUrl, KJob *parentJob) {
                Q_ASSERT(parentJob == q);
                // Only receive askUserRenameResult once per rename dialog
                QObject::disconnect(askUserActionInterface, &KIO::AskUserActionInterface::askUserRenameResult,
                                    q, nullptr);
                processFileRenameDialogResult(it, result, newUrl, destmtime);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : urls) {
        stopListingUrl(lister, url, silent);
    }
```

#### AUTO 


```{c}
auto applyPermissionsChanges = [this, applyOtherChanges]() {
        connect(d->m_permissionsPropsPlugin, &KFilePermissionsPropsPlugin::changesApplied, this, [applyOtherChanges]() {
            applyOtherChanges();
        });

        d->m_permissionsPropsPlugin->applyChanges();
    };
```

#### AUTO 


```{c}
auto addUrl = [u, &urls](const QString & partial_name) 
    { 
        if (partial_name.trimmed().isEmpty()) {
            return;
        }

        // This returns QUrl(partial_name) for absolute URLs.
        // Otherwise, returns the concatenated url.
        QUrl finalUrl = u.resolved(QUrl(partial_name));
        if (finalUrl.isValid()) {
            urls.append(finalUrl);
        } else {
            // This can happen in the first quote! (ex: ' "something here"')
            qCDebug(KIO_KFILEWIDGETS_FW) << "Discarding Invalid" << finalUrl;
        }
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &match : matchesB) {
        QVERIFY2(!match.startsWith(QLatin1Char('g')), qPrintable(match));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QAction *action) {
        d->slotActionTriggered(action);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &device) { _k_deviceRemoved(device); }
```

#### AUTO 


```{c}
const auto currentTrashIt = mConfigMap.constFind(mCurrentTrash);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVector<UDSTestField> &testCase : testCases) {
            stream << static_cast<quint32>(testCase.count());

            for (const UDSTestField &field : testCase) {
                uint uds = field.m_uds;
                stream << uds;

                if (uds & KIO::UDSEntry::UDS_STRING) {
                    stream << field.m_string;
                } else {
                    Q_ASSERT(uds & KIO::UDSEntry::UDS_NUMBER);
                    stream << field.m_long;
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (KCoreDirLister *kdl : listers) {
            kdl->d->jobDone(job);
            emit kdl->completed(jobUrl);
            if (kdl->d->numJobs() == 0) {
                kdl->d->complete = true;
                emit kdl->completed();
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const KFileItem &item) {
        fileHighlighted(item);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &recentDir : recentDirs) {
        const QUrl url = QUrl::fromLocalFile(recentDir);
        const QString text = KStringHandler::csqueeze(url.toDisplayString(QUrl::PreferLocalFile), 60); // shorten very long paths (#61386)
        QAction *act = new QAction(text, this);
        act->setObjectName(recentDir);
        act->setData(url);
        m_actionGroup.addAction(act);
        addAction(act);
    }
```

#### AUTO 


```{c}
auto end = d->mapConfig.cend();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : fileList) {
        DirItem *dirItem = dirItemForUrl(url); // is it a listed directory?
        if (dirItem) {
            deletedSubdirs.append(url);
            if (!dirItem->rootItem.isNull()) {
                removedItemsByDir[url].append(dirItem->rootItem);
            }
        }

        const QUrl parentDir = url.adjusted(QUrl::RemoveFilename | QUrl::StripTrailingSlash);
        dirItem = dirItemForUrl(parentDir);
        if (!dirItem) {
            continue;
        }
        for (auto fit = dirItem->lstItems.begin(), fend = dirItem->lstItems.end(); fit != fend; ++fit) {
            if ((*fit).url() == url) {
                const KFileItem fileitem = *fit;
                removedItemsByDir[parentDir].append(fileitem);
                // If we found a fileitem, we can test if it's a dir. If not, we'll go to deleteDir just in case.
                if (fileitem.isNull() || fileitem.isDir()) {
                    deletedSubdirs.append(url);
                }
                dirItem->lstItems.erase(fit); // remove fileitem from list
                break;
            }
        }
    }
```

#### AUTO 


```{c}
static auto map = standardLocationsMap();
```

#### AUTO 


```{c}
auto *lastMock = m_uiInterface->askUserMockInterface();
```

#### IF STATEMENT WITH INITIALIZER 


```{c}
if (QT_STATBUF buff; QT_LSTAT(QFile::encodeName(path).constData(), &buff) == 0) {
        auto it = std::find_if(this->cbegin(), this->cend(), [&buff, &path](const KMountPoint::Ptr &mountPtr) {
            // For a bind mount, the deviceId() is that of the base mount point, e.g. /mnt/foo,
            // however the path we're looking for, e.g. /home/user/bar, doesn't start with the
            // mount point of the base device, so we go on searching
            return mountPtr->deviceId() == buff.st_dev && path.startsWith(mountPtr->mountPoint());
        });

        if (it != this->cend()) {
            result = *it;
        }
    }
```

#### AUTO 


```{c}
const auto loginIt = d->loginMap.constFind(type);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { updateButtonVisibility(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (KIO::DropMenu *menu : std::as_const(d->m_menus)) {
        menu->popup(p, atAction);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &path : templates) {
        dir.setPath(path);
        const QStringList entryList = dir.entryList(QStringList{QStringLiteral("*.desktop")}, QDir::Files);
        files.reserve(files.size() + entryList.size());
        for (const QString &entry : entryList) {
            const QString file = concatPaths(dir.path(), entry);
            files.append(file);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QChar c) {
            return c.isDigit();
        }
```

#### AUTO 


```{c}
auto rit = removedItemsByDir.constBegin(), cend = removedItemsByDir.constEnd();
```

#### AUTO 


```{c}
auto itu = itemsInUse.begin(), ituend = itemsInUse.end();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &dir : dirs) {
        KFileItemList deletedItems;

        const QList<KFileItem> *itemList = kDirListerCache()->itemsForDir(dir);
        if (!itemList) {
            continue;
        }

        auto kit = itemList->begin();
        const auto kend = itemList->end();
        for (; kit != kend; ++kit) {
            const KFileItem &item = *kit;
            const QString text = item.text();
            if (text == QLatin1Char('.') || text == QLatin1String("..")) {
                continue;
            }
            const bool wasVisible = oldVisibleItems.find(item.name()) != oldVisibleItems.cend();
            const bool nowVisible = isItemVisible(item) && q->matchesMimeFilter(item);
            if (nowVisible && !wasVisible) {
                addNewItem(dir, item); // takes care of emitting newItem or itemsFilteredByMime
            } else if (!nowVisible && wasVisible) {
                deletedItems.append(*kit);
            }
        }
        if (!deletedItems.isEmpty()) {
            Q_EMIT q->itemsDeleted(deletedItems);
        }
        emitItems();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &path) -> QUrl {
        return QUrl::fromLocalFile(homeTmpDir() + path);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            d->adaptItemSize();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            slotProcessExited(255, process->exitStatus());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &dir : lstDirsCopy) {
        forgetDirs(lister, dir, false);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KServiceAction &serviceAction : list) {
        if (serviceAction.isSeparator()) {
            const QList<QAction *> actions = menu->actions();
            if (!actions.isEmpty() && !actions.last()->isSeparator()) {
                menu->addSeparator();
            }
            continue;
        }

        if (isBuiltin || !serviceAction.noDisplay()) {
            QAction *act = new QAction(q);
            act->setObjectName(QStringLiteral("menuaction")); // for the unittest
            QString text = serviceAction.text();
            text.replace(QLatin1Char('&'), QLatin1String("&&"));
            act->setText(text);
            if (!serviceAction.icon().isEmpty()) {
                act->setIcon(QIcon::fromTheme(serviceAction.icon()));
            }
            act->setData(QVariant::fromValue(serviceAction));
            m_executeServiceActionGroup.addAction(act);

            menu->addAction(act); // Add to toplevel menu
            ++count;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &dirPath : servicesDirs) {
        QDir dir(dirPath);
        for (const QString &file : dir.entryList({QStringLiteral("*.desktop")}, QDir::Files)) {
            if (!m_searchProvidersByDesktopName.contains(file)) {
                const QString filePath = dir.path() + QLatin1Char('/') + file;
                auto *provider = new SearchProvider(filePath);
                m_searchProvidersByDesktopName.insert(file, provider);
                m_searchProviders.append(provider);
                for (const QString &key : provider->keys()) {
                    m_searchProvidersByKey.insert(key, provider);
                }
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, processRunner]() {
        d->slotStarted(processRunner);
    }
```

#### AUTO 


```{c}
auto *openOrExecuteFileHandler = KIO::delegateExtension<KIO::OpenOrExecuteFileInterface *>(q);
```

#### LAMBDA EXPRESSION 


```{c}
[](KCoreDirLister *lister) {
                          return lister->requestMimeTypeWhileListing();
                      }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &plugin : plugins) {
            if (KPluginInfo info(plugin); info.isValid()) {
                if (auto [it, inserted] = pluginIds.insert(info.pluginName()); inserted) {
                    jsonMetaDataPlugins << info.toMetaData();
                }
            } else {
                // Hack for directory thumbnailer: It has a hardcoded plugin id in the kio-slave and not any C++ plugin
                // Consequently we just use the base name as the plugin file for our KPluginMetaData object
                const QString path = QStandardPaths::locate(QStandardPaths::GenericDataLocation, QLatin1String("kservices5/") + plugin->entryPath());
                KPluginMetaData tmpData = KPluginMetaData::fromDesktopFile(path);
                jsonMetaDataPlugins << KPluginMetaData(tmpData.rawData(), QFileInfo(path).baseName(), path);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KIO::UDSEntry &entry : entries) {
        if (entry.isDir()) {
            const QString name = entry.stringValue(KIO::UDSEntry::UDS_NAME);
            QString displayName = entry.stringValue(KIO::UDSEntry::UDS_DISPLAY_NAME);
            if (displayName.isEmpty()) {
                displayName = name;
            }
            if ((name != QLatin1String(".")) && (name != QLatin1String(".."))) {
                m_subDirs.append(qMakePair(name, displayName));
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &s : sl) {
            certChain.append(QSslCertificate(s.toLatin1())); //or is it toLocal8Bit or whatever?
            if (certChain.last().isNull()) {
                decodedOk = false;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (KUrlNavigatorButton *button : std::as_const(d->m_navButtons)) {
            button->setActive(active);
        }
```

#### AUTO 


```{c}
auto it = fileList.cbegin(), cend = fileList.end();
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        q->accept();
    }
```

#### CONST EXPRESSION 


```{c}
constexpr auto statFlags = KIO::StatBasic | KIO::StatResolveSymlink | KIO::StatMimeType;
```

#### AUTO 


```{c}
auto doTheTestOperations()
{

    // Single file

    // Drag-and-drop move to /
    move({"1"_hc}, "1"_rc)
    // Undo dnd move to /
    .andThen(doUndo)
    // Drag-and-drop copy to /
    .andThen(do {
        return copy({"2"_hc}, "2"_rc);
    })
    // Undo dnd copy one file to /
    .andThen(doUndo)
    // Cut-and-paste to /
    .andThen(do {
        return move({"3"_hc}, "3"_rc);
    })
    // Undo cut-and-paste to /
    .andThen(doUndo)
    // Copy-and-paste to /
    .andThen(do {
        return copy({"4"_hc}, "4"_rc);
    })
    // Undo copy-and-paste to /
    .andThen(doUndo)
    // Rename file on /
    .andThen(do {
        return doRename({"4"_rc}, "4!"_rc);
    })
    // Duplicate file on /
    .andThen(do {
        return copy({"4!"_rc}, "4! copy"_rc);
    })
    // Undo duplication of a file on /
    .andThen(doUndo)


    // Four individual files


    // Drag-and-drop move to /
    .andThen(do {
        return move({"5"_hc, "6"_hc, "7"_hc, "8"_hc}, ""_rc);
    })
    // Undo dnd move to /
    .andThen(doUndo)
    // Copy-and-paste to /
    .andThen(do {
        return copy({"5"_hc, "6"_hc, "7"_hc, "8"_hc}, ""_rc);
    })
    // Undo copy-and-paste to /
    .andThen(doUndo)
    // Cut-and-paste to /
    .andThen(do {
        return move({"5"_hc, "6"_hc, "7"_hc, "8"_hc}, ""_rc);
    })
    // Undo cut-and-paste to /
    .andThen(doUndo)
    // Rename four files on /
    // TODO: figure out this
    // Duplicate four files on /
    // Undo duplicate four files on /
    // TODO: figure out this


    // Single Folder full of stuff


    // Drag-and-drop move to /
    .andThen(do {
        return move({"more-files"_hc}, ""_rc);
    })
    // Undo Drag-and-drop move to /
    .andThen(doUndo)
    // Drag-and-drop copy to /
    .andThen(do {
        return copy({"more-files"_hc}, ""_rc);
    })
    // Undo drag-and-drop copy to /
    .andThen(doUndo)
    // Copy again
    .andThen(do {
        return copy({"more-files"_hc}, ""_rc);
    })
    // Rename folder full of stuff on /
    .andThen(do {
        return doRename("more-files"_rc, "filesier"_rc);
    })
    // Duplicate folder full of stuff on /


    // Miscellaneous


    // Create folder on /
    .andThen(do {
        return makeFolderExist("idk"_rc);
    })
    // Undo creating folder on /
    .andThen(doUndo);
    // Create a file on /
    // Undo creating a file on /
    // Edit permissions for file on /
}
```

#### AUTO 


```{c}
const auto bytes = input.toUtf8();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& serviceId : serviceIdList) {
        KFileItemList serviceItems;
        for (const KFileItem &item : fileItems) {
            const KService::Ptr serv = preferredService(item.mimetype(), m_traderConstraint);
            const QString preferredServiceId = serv ? serv->storageId() : QString();
            if (preferredServiceId == serviceId) {
                serviceItems << item;
            }
        }

        if (serviceId.isEmpty()) { // empty means: no associated app for this mimetype
            openWithByMime(serviceItems);
            continue;
        }

        const KService::Ptr servicePtr = KService::serviceByStorageId(serviceId); // can be nullptr
        auto *job = new KIO::ApplicationLauncherJob(servicePtr);
        job->setUrls(serviceItems.urlList());
        job->setUiDelegate(new KIO::JobUiDelegate(KJobUiDelegate::AutoHandlingEnabled, m_parentWidget));
        job->start();
    }
```

#### AUTO 


```{c}
const auto url1 = QUrl("file:///foo/bar/1");
```

#### AUTO 


```{c}
const auto fileSystem = KFileSystemType::fileSystemType(m_globalDest.toString());
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        mFileWidget->slotOk();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QModelIndex &index) { d->_k_placeClicked(index); }
```

#### AUTO 


```{c}
auto err = execWithElevatedPrivilege(RMDIR, {itemPath}, errno)
```

#### AUTO 


```{c}
const auto socketError = m_control->socketError();
```

#### AUTO 


```{c}
auto it = std::lower_bound(storage.cbegin(), storage.cend(), udsField, less);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &group : groupPath) {
        auto it = currentGroup->subGroups.constFind(group);
        if (it == currentGroup->subGroups.constEnd()) {
            return nullptr;
        }
        currentGroup = &*it;
    }
```

#### AUTO 


```{c}
auto makeFolderExist(const QUrl& at)
{
    auto job = KIO::mkdir(at);

    Fum->recordJob(KIO::FileUndoManager::Mkdir, {}, at, job);

    return jobToFuture(QStringLiteral("make directory at %1").arg(toStr(at)), job);
}
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->slotIOFinished(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QModelIndex &index, int sequenceIndex) {
            requestSequenceIcon(index, sequenceIndex);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &validPath : validSearchPaths) {
            if (path.endsWith(validPath)) {
                searchUrl.setScheme(QStringLiteral("baloosearch"));
                return searchUrl;
            }
        }
```

#### AUTO 


```{c}
auto *untrustedProgramHandler = KIO::delegateExtension<KIO::UntrustedProgramHandlerInterface *>(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &text) {
        locationAccepted(text);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](ActionType action) -> QString {
        switch (action) {
        case ActionType::CHMOD:   return i18n("Authentication is required to change this file's permissions.");
        case ActionType::CHOWN:   return i18n("Authentication is required to change who owns this file.");
        case ActionType::DEL:     return i18n("Authentication is required to delete this file.");
        case ActionType::MKDIR:   return i18n("Authentication is required to create a folder.");
        case ActionType::OPEN:    return i18n("Authentication is required to open this file.");
        case ActionType::OPENDIR: return i18n("Authentication is required to open this folder.");
        case ActionType::RENAME:  return i18n("Authentication is required to rename this file.");
        case ActionType::RMDIR:   return i18n("Authentication is required to delete this folder.");
        case ActionType::SYMLINK: return i18n("Authentication is required to create a symlink.");
        case ActionType::UTIME:   return i18n("Authentication is required to modify this file's last updated time.");
        case ActionType::COPY:    return i18n("Authentication is required to copy this item.");
        case ActionType::UNKNOWN: return i18n("Authentication is required to perform this action.");
        }
        Q_UNREACHABLE();
        return QString();
    }
```

#### AUTO 


```{c}
auto teardownAction = m_model->teardownAction(index);
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : qAsConst(m_pluginActions)) {
        removeAction(action);
    }
```

#### AUTO 


```{c}
auto const scrollerState = m_scroller->state();
```

#### LAMBDA EXPRESSION 


```{c}
[this](const KFileItem &item) {
        d->_k_slotFailed(item);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &u : urls) {
                const QUrl url = d->mostLocalUrl(u);
                if (url.isLocalFile()) {
                    list.append(url.toLocalFile());
                }
            }
```

#### IF STATEMENT WITH INITIALIZER 


```{c}
if (const auto extraFields = KProtocolInfo::extraFields(url); !d->bMultiple && !extraFields.isEmpty()) {
        int curRow = d->m_ui->gridLayout->rowCount();
        KSeparator *sep = new KSeparator(Qt::Horizontal, &d->m_mainWidget);
        d->m_ui->gridLayout->addWidget(sep, curRow++, 0, 1, 3);

        QLocale locale;
        for (int i = 0; i < extraFields.count(); ++i) {
            const auto &field = extraFields.at(i);

            QString text = firstItem.entry().stringValue(KIO::UDSEntry::UDS_EXTRA + i);
            if (field.type == KProtocolInfo::ExtraField::Invalid || text.isEmpty()) {
                continue;
            }

            if (field.type == KProtocolInfo::ExtraField::DateTime) {
                const QDateTime date = QDateTime::fromString(text, Qt::ISODate);
                if (!date.isValid()) {
                    continue;
                }

                text = locale.toString(date, QLocale::LongFormat);
            }

            auto *label = new QLabel(i18n("%1:", field.name), &d->m_mainWidget);
            d->m_ui->gridLayout->addWidget(label, curRow, 0, Qt::AlignRight);

            auto *squeezedLabel = new KSqueezedTextLabel(text, &d->m_mainWidget);
            if (properties->layoutDirection() == Qt::RightToLeft) {
                squeezedLabel->setAlignment(Qt::AlignRight);
            } else {
                squeezedLabel->setLayoutDirection(Qt::LeftToRight);
            }

            d->m_ui->gridLayout->addWidget(squeezedLabel, curRow++, 2);
            squeezedLabel->setTextInteractionFlags(Qt::TextSelectableByMouse | Qt::TextSelectableByKeyboard);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &item : items) {
        mimeType = item.mimetype();
        const int slashIndex = mimeType.indexOf(QLatin1Char('/'));
        const QStringRef mimeTypeGroup = mimeType.leftRef(slashIndex);
        if (mimeTypeGroup == QLatin1String("image")) {
            imageItems.append(item);
        } else {
            otherItems.append(item);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        slotAbortDialog();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KCoreDirLister *kdl : listers) {
                if (kdl->d->rootFileItem.isNull() && kdl->d->url == url) {
                    kdl->d->rootFileItem = dir->rootItem;
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        mFileWidget->slotCancel();
        q->reject();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto button : qAsConst(m_navButtons)) {
            if (button->geometry().contains(p)) {
                const auto url = button->url();
                QAction *openInTab = popup->addAction(QIcon::fromTheme(QStringLiteral("tab-new")), i18n("Open %1 in tab", button->text()));
                q->connect(openInTab, &QAction::triggered, q, [this, url]() {
                    Q_EMIT q->tabRequested(url);
                });
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QHostAddress &address : info.addresses()) {
            if (!isSpecialAddress(address) && isIPv4Address(address)) {
                resolvedAddress = address.toString();
                break;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[mountType](const QLatin1String netfs) {
        return mountType == netfs;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KDirModelNode *node : qAsConst(dirNode->m_childNodes)) {
            node->setPreview(QIcon());
            // node->setPreview(QIcon::fromTheme(node->item().iconName()));
            if (isDir(node)) {
                // recurse into child dirs
                clearAllPreviews(static_cast<KDirModelDirNode *>(node));
            }
            lastNode = node;
        }
```

#### AUTO 


```{c}
auto it = m_parentDirs.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &pathDesktop : recentDocs) {
        const KDesktopFile tmpDesktopFile(pathDesktop);
        const QUrl url(tmpDesktopFile.readUrl());
        if (url.isEmpty()) {
            continue;
        }
        const QDateTime lastModified = QFileInfo(pathDesktop).lastModified();
        const QDateTime documentLastModified = documents.value(url);
        if (documentLastModified.isValid() && documentLastModified > lastModified) {
            continue;
        }
        documents[url] = lastModified;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &untranslatedText) {
                KBookmarkGroup root = d->bookmarkManager->root();
                KBookmark bItem = root.first();
                while (!bItem.isNull()) {
                    const bool isSystemItem = bItem.metaDataItem(QStringLiteral("isSystemItem")) == QLatin1String("true");
                    if (isSystemItem && bItem.fullText() == untranslatedText) {
                        return bItem;
                    }
                    bItem = root.next(bItem);
                }
                return KBookmark();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (bool nullService : {false, true}) {
        const char *nullServiceStr = nullService ? "pass_null_service" : "default_ctor";
        QTest::addRow("without_handler_%s", nullServiceStr) << false << false << nullService;
        QTest::addRow("false_canceled_%s", nullServiceStr) << true << false << nullService;
        QTest::addRow("true_service_selected_%s", nullServiceStr) << true << true << nullService;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVector<UDSTestField> &testCase : testCases) {
            KIO::UDSEntry entry;

            for (const UDSTestField &field : testCase) {
                uint uds = field.m_uds;
                if (uds & KIO::UDSEntry::UDS_STRING) {
                    entry.fastInsert(uds, field.m_string);
                } else {
                    Q_ASSERT(uds & KIO::UDSEntry::UDS_NUMBER);
                    entry.fastInsert(uds, field.m_long);
                }
            }

            QCOMPARE(entry.count(), testCase.count());
            stream << entry;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &proxyUrl : std::as_const(m_proxyUrls)) {
        const QUrl url(proxyUrl);
        const QString scheme(url.scheme());

        if (!supportedProxyScheme(scheme)) {
            // TODO: Need a new error code to indicate unsupported URL scheme.
            result = Result::fail(ERR_CANNOT_CONNECT, url.toString());
            continue;
        }

        if (!isSocksProxyScheme(scheme)) {
            const Result result = ftpOpenControlConnection(url.host(), url.port());
            if (result.success()) {
                return Result::pass();
            }
            continue;
        }

        qCDebug(KIO_FTP) << "Connecting to SOCKS proxy @" << url;
        m_proxyURL = url;
        result = ftpOpenControlConnection(m_host, m_port);
        if (result.success()) {
            return result;
        }
        m_proxyURL.clear();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&](const char *token, const QString &str) {
        if (!str.isEmpty()) {
            arg += QLatin1String(token) + quote + str + quote;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, launchedSerial](int tokenSerial, const QString &token) {
                                if (tokenSerial == launchedSerial) {
                                    m_process->setEnv(QStringLiteral("XDG_ACTIVATION_TOKEN"), token);
                                    Q_EMIT xdgActivationTokenArrived();
                                }
                            }
```

#### RANGE FOR STATEMENT 


```{c}
for (SearchProvider *provider : std::as_const(providers)) {
        if (defaultSearchEngine == provider->desktopEntryName()) {
            defaultProviderIndex = providers.indexOf(provider);
            break;
        }
    }
```

#### AUTO 


```{c}
auto [_, inserted] = uniqueFileNames.insert(fileFromDisk.split(QLatin1Char('/')).last());
```

#### LAMBDA EXPRESSION 


```{c}
[this](const BasicOperation &op) {
        return (op.m_type == BasicOperation::Directory && !op.m_renamed)
                || (op.m_type == BasicOperation::Link && !m_current.isMoveCommand());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : lst) {
        fnames += url.isLocalFile() ? QDir::toNativeSeparators(url.toLocalFile()) : url.toString();
    }
```

#### AUTO 


```{c}
auto it = std::find_if(storage.cbegin(), storage.cend(),
                                [udsField](const Field &entry) {return entry.m_index == udsField;});
```

#### RANGE FOR STATEMENT 


```{c}
for (const QSslCipher &c : candidates) {
        ret.append(KSslCipher(c));
    }
```

#### AUTO 


```{c}
const auto end = lstItems.cend();
```

#### LAMBDA EXPRESSION 


```{c}
[=](bool allowDelete) {
                    if (allowDelete) {
                        d->startUndo();
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &key : translatedStringListAttributes) {
            // read untranslated entry first in any case!
            sconfig.setLocale(QString());
            protocolData.insert(key, config.readEntry(key, QStringList()));

            // collect all locales for this key
            QFile f(fullFilePath);
            QStringList foundLocalesForKey;
            if (!f.open(QIODevice::ReadOnly | QIODevice::Text)) {
                qFatal("Failed to open file %s.", qPrintable(fullFilePath));
            }
            while (!f.atEnd()) {
                const QString line = QString::fromUtf8(f.readLine());
                const QRegularExpressionMatch match = localeRegex.match(line);
                if (match.hasMatch()) {
                    foundLocalesForKey.append(match.captured(1));
                }
            }

            // insert all entries for all found locales, reparse config for this
            for (const QString &locale : qAsConst(foundLocalesForKey)) {
                sconfig.setLocale(locale);
                protocolData.insert(QStringLiteral("%1[%2]").arg(key, locale), config.readEntry(key, QStringList()));
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &request : requests) {
        request.reply.waitForFinished();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QObject *obj : QObjectList(m_placesMenu->children())) {
        delete qobject_cast<QMenu *>(obj); // Noop for nullptr
    }
```

#### LAMBDA EXPRESSION 


```{c}
[c](const QString &a, const QString &b) {
        return c.compare(a.endsWith(QStringLiteral("/")) ? a.chopped(1) : a, b.endsWith(QStringLiteral("/")) ? b.chopped(1) : b) < 0;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Slave *slave : slaves) {
        // kill the slave process and remove the interface in our process
        slave->kill();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &str : std::as_const(m_responseHeaders)) {
        const QString header = str.trimmed();
        if (header.startsWith(QLatin1String("content-type:"), Qt::CaseInsensitive)) {
            int pos = header.indexOf(QLatin1String("charset="), Qt::CaseInsensitive);
            if (pos != -1) {
                const QString charset = header.mid(pos + 8).toLower();
                m_request.cacheTag.charset = charset;
                setMetaData(QStringLiteral("charset"), charset);
            }
        } else if (header.startsWith(QLatin1String("content-language:"), Qt::CaseInsensitive)) {
            const QString language = header.mid(17).trimmed().toLower();
            setMetaData(QStringLiteral("content-language"), language);
        } else if (header.startsWith(QLatin1String("content-disposition:"), Qt::CaseInsensitive)) {
            parseContentDisposition(header.mid(20).toLower());
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](int value) {
        d->slotIconSizeSliderMoved(value);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &l : validationErrors) {
        QList<QSslError::SslError> qErrors;
        qErrors.reserve(l.size());
        for (const KSslError::Error e : l) {
            qErrors.push_back(KSslErrorPrivate::errorFromKSslError(e));
        }
        qValidationErrors.push_back(qErrors);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->zoomInIconsSize();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KCoreDirLister *kdl : listers) {
            kdl->d->jobDone(job);
#if KIOCORE_BUILD_DEPRECATED_SINCE(5, 79)
            Q_EMIT kdl->completed(jobUrl);
#endif
            Q_EMIT kdl->listingDirCompleted(jobUrl);
            if (kdl->d->numJobs() == 0) {
                kdl->d->complete = true;
                Q_EMIT kdl->completed();
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[next, outerFuture](T val) mutable {
            Future<X> innerFuture = next(val);
            innerFuture.then([outerFuture](X val) mutable {
                outerFuture.succeed("andThen", val);
            });
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &folder : folders) {
                    label.append(QLatin1Char('\n'));
                    label.append(indentation);
                    label.append(folder);
                    label.append(QStringLiteral("/"));
                    indentation.append(QStringLiteral("    "));
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this](int value) {
        d->slotIconSizeChanged(value);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QLabel *label : labels) {
            if (label->text() == i18n("&Name:"))
                return label->buddy();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVariant &arg : args) {
        out << arg;
    }
```

#### AUTO 


```{c}
const auto dest = m_watched.value(path);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QModelIndex &parentIndex) {
        for (int row = 0; row < m_dirModel->rowCount(parentIndex); ++row) {
            QModelIndex idx = m_dirModel->index(row, 0, parentIndex);
            if (m_dirModel->itemForIndex(idx).isDir()) {
                return idx;
            }
        }
        return QModelIndex();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &protocol : protocols) {
        // Check that hasSchemeHandler will return true
        QVERIFY(!KProtocolInfo::isKnownProtocol(protocol));
        QVERIFY(!KProtocolInfo::isHelperProtocol(protocol));
        QVERIFY(KApplicationTrader::preferredService(QLatin1String("x-scheme-handler/") + protocol));

        const QList<QUrl> urls({QUrl(QStringLiteral("%1://root@10.1.1.1").arg(protocol))});
        KIO::DesktopExecParser parser(*service, urls);
        QCOMPARE(KShell::joinArgs(parser.resultingArguments()), QStringLiteral("%1 %2://root@10.1.1.1").arg(KShell::quoteArg(ktelnetExec), protocol));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->slotDetailedTreeView();
    }
```

#### AUTO 


```{c}
const auto &entry
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &entry : topLevelContent) {
        if (entry.isDir) {
            createTestDirectory(entry.name, Empty);
        } else {
            createTestFile(entry.name, false, entry.content);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : actions) {
        if (action->data() == teardownActionId) {
            delete action;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &dir : m_parentDirs) {
                KDirWatch::self()->stopDirScan(dir);
            }
```

#### AUTO 


```{c}
auto err = execWithElevatedPrivilege(DEL, {itemPath}, errno)
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            disconnected();
        }
```

#### AUTO 


```{c}
const auto &item
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &supportedMime : std::as_const(m_supportedMimeTypes)) {
                                if (mime.inherits(supportedMime)) {
                                    keep = true;
                                    break;
                                }
                            }
```

#### AUTO 


```{c}
auto err = execWithElevatedPrivilege(CHOWN, {_path, uid, gid}, errno)
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVector<UDSTestField> &testCase : testCases) {
            KIO::UDSEntry entry;
            stream >> entry;
            QCOMPARE(entry.count(), testCase.count());

            for (const UDSTestField &field : testCase) {
                uint uds = field.m_uds;
                QVERIFY(entry.contains(uds));

                if (uds & KIO::UDSEntry::UDS_STRING) {
                    QCOMPARE(entry.stringValue(uds), field.m_string);
                } else {
                    Q_ASSERT(uds & KIO::UDSEntry::UDS_NUMBER);
                    QCOMPARE(entry.numberValue(uds), field.m_long);
                }
            }
        }
```

#### CONST EXPRESSION 


```{c}
static constexpr char s_ipAddressExpression[] = "(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)";
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        slotViewKeyEnterReturnPressed();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &p : patterns) {
        QRegExp rx(p);
        rx.setPatternSyntax(QRegExp::Wildcard);
        if (rx.exactMatch(filename)) {
            return p;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const AutoLogin &log : l) {
        if ((mode & defaultOnly) == defaultOnly &&
                log.machine == QLatin1String("default") &&
                (login.login.isEmpty() || login.login == log.login)) {
            login.type = log.type;
            login.machine = log.machine;
            login.login = log.login;
            login.password = log.password;
            login.macdef = log.macdef;
        }

        if ((mode & presetOnly) == presetOnly &&
                log.machine == QLatin1String("preset") &&
                (login.login.isEmpty() || login.login == log.login)) {
            login.type = log.type;
            login.machine = log.machine;
            login.login = log.login;
            login.password = log.password;
            login.macdef = log.macdef;
        }

        if ((mode & exactOnly) == exactOnly &&
                log.machine == url.host() &&
                (login.login.isEmpty() || login.login == log.login)) {
            login.type = log.type;
            login.machine = log.machine;
            login.login = log.login;
            login.password = log.password;
            login.macdef = log.macdef;
            break;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        _k_slotFileSelected();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &cookie : cookies) {
        const int index = cookie.indexOf(QLatin1Char('='));
        const QStringView cookieView(cookie);
        const auto name = cookieView.left(index);
        const auto value = cookieView.right(cookie.length() - index - 1);
        cookieList << QNetworkCookie(name.toUtf8(), value.toUtf8());
        // qDebug() << "cookie: name=" << name << ", value=" << value;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const MountRequest &request) { return request.reply.isError(); }
```

#### AUTO 


```{c}
auto err = execWithElevatedPrivilege(RENAME, _src, _dest)
```

#### RANGE FOR STATEMENT 


```{c}
for (const KServicePtr &service : qAsConst(offers)) {
                    QAction *act = d->createAppAction(service,
                                                      // no submenu -> prefix single offer
                                                      menu == topMenu);
                    menu->addAction(act);
                }
```

#### AUTO 


```{c}
auto action
```

#### LAMBDA EXPRESSION 


```{c}
[this, applyPermissionsChanges, applyOtherChanges]() {
            if (d->m_permissionsPropsPlugin && d->m_permissionsPropsPlugin->isDirty()) {
                applyPermissionsChanges();
            } else {
                applyOtherChanges();
            }
        }
```

#### AUTO 


```{c}
auto slotFunc = [this]() {
            slotFillTemplates();
        };
```

#### LAMBDA EXPRESSION 


```{c}
[this](const KIO::UDSEntry &entry) {
        slotStatEntry(entry);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
                                    act->setShortcuts(act2->shortcuts());
                                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &cachedDir : cachedDirs) {
        if (dir == cachedDir || dir.isParentOf(cachedDir)) {
            itemsCached.remove(cachedDir);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &dirpath : dirList) {
        if (QFileInfo::exists(dirpath + QLatin1Char('/') + filename)) {
            directory = dirpath + QLatin1Char('/');
            return true;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) { _k_slotIOFinished(job); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &url : std::as_const(m_request.proxyUrls)) {
            if (url != QLatin1String("DIRECT")) {
                if (isCompatibleNextUrl(m_server.proxyUrl, QUrl(url))) {
                    return false;
                }
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                d->assureVisibleSelection();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &service : fileItemPlugins) {
        if (!showGroup.readEntry(service->desktopEntryName(), true)) {
            // The plugin has been disabled
            continue;
        }

        auto *abstractPlugin = service->createInstance<KAbstractFileItemActionPlugin>();
        if (abstractPlugin) {
            abstractPlugin->setParent(mainMenu);
            auto actions = abstractPlugin->actions(m_props, m_parentWidget);
            itemCount += actions.count();
            mainMenu->addActions(actions);
            addedPlugins.append(service->desktopEntryName());
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const KFileItem &item) {
            return d->isItemVisible(item) && matchesMimeFilter(item);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](QPushButton *button) {
        return button->text() == QLatin1String("&Here");
    }
```

#### AUTO 


```{c}
auto *subjob = new KIO::CommandLauncherJob(exec, thunderbirdArguments(), this);
```

#### LAMBDA EXPRESSION 


```{c}
[this, statJob] {
                if (statJob->error()) {
                    d->m_ui->symlinkTargetMessageWidget->setText(statJob->errorString());
                    d->m_ui->symlinkTargetMessageWidget->animatedShow();
                    return;
                }

                KIO::highlightInFileManager({statJob->url()});
                properties->close();
            }
```

#### LAMBDA EXPRESSION 


```{c}
[=](KIO::RenameDialog_Result result, const QUrl &, KJob *askJob) {
                    Q_ASSERT(kioJob == askJob);

                    // Only receive askUserRenameResult once per rename dialog
                    QObject::disconnect(askUserActionInterface, renameSignal, q, nullptr);

                    processCanResumeResult(job, result, offset);
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &match) {
        fileCompletion(match);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](int value) { d->slotIconSizeChanged(value); }
```

#### AUTO 


```{c}
auto job2 = KIO::copy({QUrl::fromLocalFile(testOverwriteCopy2)}, url, KIO::Overwrite);
```

#### LAMBDA EXPRESSION 


```{c}
[this, acceptAndClose]() {
        Q_ASSERT(!d->m_filePropsPlugin->isDirty());
        Q_ASSERT(!d->m_permissionsPropsPlugin->isDirty());

        // Apply the changes for the rest of the plugins
        for (auto *page : d->m_pages) {
            if (d->m_aborted) {
                break;
            }

            if (page->isDirty()) {
                // qDebug() << "applying changes for " << page->metaObject()->className();
                page->applyChanges();
            }
            /* else {
                qDebug() << "skipping page " << page->metaObject()->className();
            } */
        }

        if (!d->m_aborted && d->m_filePropsPlugin) {
            d->m_filePropsPlugin->postApplyChanges();
        }

        if (!d->m_aborted) {
            acceptAndClose();
        } // Else, keep dialog open for user to fix the problem.
    }
```

#### AUTO 


```{c}
auto instance = makeInstance(KIO::DesktopExecParser::executablePath(execName));
```

#### AUTO 


```{c}
auto *copyjob = KIO::copy(u, d, KIO::HideProgressInfo);
```

#### RANGE FOR STATEMENT 


```{c}
for (QByteArray offer : offers) {
        QByteArray scheme;
        QByteArray cont;

        parseChallenge(offer, &scheme, &cont);

        while (!cont.isEmpty()) {
            offer.chop(cont.length());
            alloffers << offer;
            offer = cont;
            cont.clear();
            parseChallenge(offer, &scheme, &cont);
        }
        alloffers << offer;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &item : std::as_const(m_dispatchedItems)) {
        auto it = std::remove_if(m_pendingItems.begin(), m_pendingItems.end(), [&item](const KFileItem &pending) {
            return pending.url() == item.url();
        });
        m_pendingItems.erase(it, m_pendingItems.end());
    }
```

#### AUTO 


```{c}
auto deleteJob = KIO::del(dest, KIO::HideProgressInfo);
```

#### AUTO 


```{c}
const auto compHiddenStartingWith2 = m_completion->allMatches();
```

#### AUTO 


```{c}
auto job = new KIO::CommandLauncherJob(terminal, cmd);
```

#### AUTO 


```{c}
auto *dirsJob = KIO::chmod(dirs, orDirPermissions, ~andDirPermissions, owner, group, recursive);
```

#### LAMBDA EXPRESSION 


```{c}
[this](KIO::Job *job, const QByteArray &data) {
        slotThumbData(job, data);
    }
```

#### AUTO 


```{c}
const auto info = m_freeSpaceInfo.value(persistentIndex);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &text) {
        d->_k_slotNameTextChanged(text);
    }
```

#### AUTO 


```{c}
auto it = std::remove_if(m_protocols.begin(), m_protocols.end(), [](const QString &s) {
            QUrl url;
            url.setScheme(s);
            return !KProtocolManager::supportsListing(url);
        });
```

#### AUTO 


```{c}
auto it = lstNewItems.cbegin();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { updateContent(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &plugin : blacklist) {
        defaultPlugins.removeAll(plugin);
    }
```

#### AUTO 


```{c}
const auto tag = QLatin1String("UUID=");
```

#### AUTO 


```{c}
const auto dit = directoryData.find(jobUrl);
```

#### LAMBDA EXPRESSION 


```{c}
[this](KIO::Job *job, const QByteArray &data) {
        d_func()->slotStoredData(job, data);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &offer : offers) {
        const QByteArray scheme = offer.mid(0, offer.indexOf(' ')).toLower();
#if HAVE_LIBGSSAPI
        if (scheme == "negotiate") { // krazy:exclude=strings
            negotiateOffer = offer;
        } else
#endif
            if (scheme == "digest") { // krazy:exclude=strings
                digestOffer = offer;
            } else if (scheme == "ntlm") { // krazy:exclude=strings
                ntlmOffer = offer;
            } else if (scheme == "basic") { // krazy:exclude=strings
                basicOffer = offer;
            }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](Solid::ErrorType error, QVariant errorData) {
            d->_k_storageSetupDone(error, errorData);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : qAsConst(m_srcList)) {
            const QString extension = db.suffixForFileName(url.path());
            if (extensions.contains(extension)) {
                m_allExtensionsDifferent = false;
                break;
            }

            extensions.insert(extension);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *runningSlave : slaves) {
                    if (slave->host() == runningSlave->host()) {
                        slave->setConfig(metaDataFor(slave->protocol(), jobPriv->m_proxyList, job->url()));
                        /*qDebug() << "Updated configuration of" << slave->protocol()
                                     << "ioslave, pid=" << slave->slave_pid();*/
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &item : itemList) {
            d->completion.addItem(item.name());
            if (item.isDir()) {
                d->dirCompletion.addItem(item.name());
            }
        }
```

#### AUTO 


```{c}
auto it = std::find_if(storage.begin(), storage.end(),
                                  [udsField](const Field &entry) {return entry.m_index == udsField;});
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        Q_EMIT canceled();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool show) {
        togglePlacesPanel(show);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KServiceType::Ptr st : list) {
        qDebug() << st->name();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &idx : std::as_const(emitExpandFor)) {
        Q_EMIT q->expand(idx);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KCoreDirLister *kdl : holders) {
                curHolders.append(kdl);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[&putDataBuffer](){ Q_EMIT putDataBuffer.readChannelFinished(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : std::as_const(files)) {
        // qDebug() << file;
        if (file[0] != QLatin1Char('.')) {
            KNewFileMenuSingleton::Entry e;
            e.filePath = file;
            e.entryType = KNewFileMenuSingleton::Unknown; // not parsed yet

            // Put Directory first in the list (a bit hacky),
            // and TextFile before others because it's the most used one.
            // This also sorts by user-visible name.
            // The rest of the re-ordering is done in fillMenu.
            const KDesktopFile config(file);
            QString url = config.desktopGroup().readEntry("URL");
            QString key = config.desktopGroup().readEntry("Name");
            if (file.endsWith(QLatin1String("Directory.desktop"))) {
                key.prepend(QLatin1Char('0'));
            } else if (file.startsWith(QDir::homePath())) {
                key.prepend(QLatin1Char('1'));
            } else if (file.endsWith(QLatin1String("TextFile.desktop"))) {
                key.prepend(QLatin1Char('2'));
            } else {
                key.prepend(QLatin1Char('3'));
            }
            EntryWithName en = {key, e};
            if (ulist.contains(url)) {
                ulist.remove(url);
            }
            ulist.insert(url, en);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QSslCertificate &cert : userList) {
        ret += KSslCaCertificate(cert, KSslCaCertificate::UserStore, false);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, &seenUrls](const char *translationContext,
                const QByteArray &untranslatedLabel,
                const QUrl &url,
                const QString &iconName,
                const KBookmark &after) {
            if (!seenUrls.contains(url)) {
                return KFilePlacesItem::createSystemBookmark(d->bookmarkManager, translationContext, untranslatedLabel, url, iconName, after);
            }
            return KBookmark();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, menu]() {
                m_menus.remove(menu);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this](qreal value) { d->_k_itemAppearUpdate(value); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &s : sl) {
        QList<QSslError::SslError> certErrors;
        const QStringList sl2 = s.split(QLatin1Char('\t'), Qt::SkipEmptyParts);
        for (const QString &s2 : sl2) {
            bool didConvert;
            QSslError::SslError error = static_cast<QSslError::SslError>(s2.toInt(&didConvert));
            if (didConvert) {
                certErrors.append(error);
            }
        }
        ret.append(certErrors);
    }
```

#### AUTO 


```{c}
auto err = execWithElevatedPrivilege(DEL, {_dest}, errno)
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItemActionsPrivate::ServiceRank &tempRank : qAsConst(rankings)) {
        result << tempRank.service;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &domainName : qAsConst(m_domainList)) {
        bool domainPrinted = false;

        KHttpCookieList *cookieList = m_cookieDomains.value(domainName);
        if (!cookieList) {
            continue;
        }

        QMutableListIterator<KHttpCookie> cookieIterator(*cookieList);
        while (cookieIterator.hasNext()) {
            const KHttpCookie &cookie = cookieIterator.next();

            if (cookie.isExpired()) {
                // Delete expired cookies
                cookieIterator.remove();
                continue;
            }
            if (cookieIsPersistent(cookie)) {
                // Only save cookies that are not "session-only cookies"
                if (!domainPrinted) {
                    domainPrinted = true;
                    ts << '[' << domainName.toLocal8Bit().data() << "]\n";
                }
                // Store persistent cookies
                const QString path = QL1C('"') + cookie.path() + QL1C('"');
                const QString domain = QL1C('"') + cookie.domain() + QL1C('"');
                const QString host = hostWithPort(&cookie);

                // TODO: replace with direct QTextStream output ?
                const QString str = QString::asprintf("%-20s %-20s %-12s %10lld  %3d %-20s %-4i %s\n",
                                                      host.toLatin1().constData(),
                                                      domain.toLatin1().constData(),
                                                      path.toLatin1().constData(),
                                                      cookie.expireDate(),
                                                      cookie.protocolVersion(),
                                                      cookie.name().isEmpty() ? cookie.value().toLatin1().constData() : cookie.name().toLatin1().constData(),
                                                      (cookie.isSecure() ? 1 : 0) + (cookie.isHttpOnly() ? 2 : 0) + (cookie.hasExplicitPath() ? 4 : 0)
                                                          + (cookie.name().isEmpty() ? 8 : 0),
                                                      cookie.value().toLatin1().constData());
                ts << str.toLatin1();
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (int port : ports) {
        portList << QString::number(port);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QUrl &url) {
        enterUrl(url);
    }
```

#### AUTO 


```{c}
auto *p = static_cast<AskUserActionInterface**>(data);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &id) {
                        itemChanged(id);
                    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](KIO::Job *, const QString &mimetype) {
        if (m_followRedirections) { // Update our URL in case of a redirection
            m_url = job->url();
        }
        if (mimetype.isEmpty()) {
            qCWarning(KIO_CORE) << "get() didn't emit a MIME type! Probably a kioslave bug, please check the implementation of" << m_url.scheme();
        }
        m_mimeTypeName = mimetype;

        // If the current MIME type is the default MIME type, then attempt to
        // determine the "real" MIME type from the file name (bug #279675)
        const QMimeType mime = fixupMimeType(m_mimeTypeName, m_suggestedFileName.isEmpty() ? m_url.fileName() : m_suggestedFileName);
        if (mime.isValid()) {
            m_mimeTypeName = mime.name();
        }

        if (m_suggestedFileName.isEmpty()) {
            m_suggestedFileName = job->queryMetaData(QStringLiteral("content-disposition-filename"));
        }

        if (!m_url.isLocalFile()) { // #434455
            job->putOnHold();
            KIO::Scheduler::publishSlaveOnHold();
        }
        q->emitResult();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                assureVisibleSelection();
            }
```

#### AUTO 


```{c}
auto *thread = new WorkerThread(factory, slaveAddress.toString().toLocal8Bit());
```

#### LAMBDA EXPRESSION 


```{c}
[this](KIO::filesize_t size) { slotTotalSize(size); }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            assureVisibleSelection();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &text) {
        d->slotLocationChanged(text);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QChar ch : text) {
        if (ch != QLatin1Char('\\')) {
            result.append(ch);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KCoreDirLister *kdl : listers) {
        if (job) {
            kdl->d->jobDone(job);
        }

        Q_EMIT kdl->canceled(oldUrl);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCoreDirLister *kdl : listers) {
            qCDebug(KIO_CORE_DIRLISTER) << "lister" << kdl << "m_cachedItemsJobs=" << kdl->d->m_cachedItemsJobs;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        const QString checksum = futureWatcher->result();
        futureWatcher->deleteLater();

        label->setText(checksum);
        cacheChecksum(checksum, algorithm);

        copyButton->show();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &itemPath : qAsConst(dirsToDelete)) {
        //qDebug() << "QDir::rmdir" << itemPath;
        if (!dir.rmdir(itemPath)) {
            if (auto err = execWithElevatedPrivilege(RMDIR, {itemPath}, errno)) {
                if (!err.wasCanceled()) {
                    error(KIO::ERR_CANNOT_DELETE, itemPath);
                }
                return false;
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, button]() {
            slotLaunchTest(button);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &trashPath : std::as_const(m_trashDirectories)) {
            TrashSizeCache trashSize(trashPath);
            TrashSizeCache::SizeAndModTime res = trashSize.calculateSizeAndLatestModDate();
            size += res.size;

            // Find latest modification date
            if (res.mtime > latestModifiedDate) {
                latestModifiedDate = res.mtime;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &ba : redirectResults) {
        QList<QByteArray> values = ba.split('\t');
        QByteArray key = values.takeFirst();
        nValues += values.count();

        QList<QByteArray> comparisonValues;
        for (const QPair<int, int> be : tokenizer.value(key).beginEnd) {
            comparisonValues.append(QByteArray(buffer + be.first, be.second - be.first));
        }

        QCOMPARE(comparisonValues.count(), values.count());
        for (int i = 0; i < values.count(); i++) {
            QVERIFY(comparisonValues[i].startsWith(values[i]));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &jsonMetadata : jsonPlugins) {
        KPluginFactory *factory = KPluginLoader(jsonMetadata.fileName()).factory();
        if (!factory) {
            continue;
        }
        KPropertiesDialogPlugin* plugin = factory->create<KPropertiesDialogPlugin>(q);
        if (plugin) {
            q->insertPlugin(plugin);
            addedPlugins.append(jsonMetadata.pluginId());
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        _k_slotTextChanged(m_lineEdit->text());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &key : qAsConst(domains)) {
        KHttpCookieList *list;

        if (key.isNull()) {
            list = m_cookieDomains.value(QLatin1String(""));
        } else {
            list = m_cookieDomains.value(key);
        }

        if (list) {
            removeDuplicateFromList(list, cookie, false, true);
        }
    }
```

#### AUTO 


```{c}
const auto &name
```

#### RANGE FOR STATEMENT 


```{c}
for (KCoreDirLister *kdl : qAsConst(curListers)) {   // listers of newUrl
                kdl->d->jobDone(oldJob);

                kdl->jobStarted(job);
                kdl->d->connectJob(job);
            }
```

#### CONST EXPRESSION 


```{c}
static constexpr auto statFlags = KIO::StatBasic | KIO::StatResolveSymlink | KIO::StatMimeType;
```

#### RANGE FOR STATEMENT 


```{c}
for (KCoreDirLister *kdl : listers) {
            kdl->d->jobDone(job);

            //don't bother the user
            //kdl->handleError( job );

            const bool silent = job->property("_kdlc_silent").toBool();
            if (!silent) {
                emit kdl->canceled(jobUrl);
            }
            if (kdl->d->numJobs() == 0) {
                kdl->d->complete = true;
                if (!silent) {
                    emit kdl->canceled();
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (uint field : fields) {
         if (!other.contains(field)) {
             return false;
         }

         if (field & UDSEntry::UDS_STRING) {
             if (entry.stringValue(field) != other.stringValue(field)) {
                 return false;
             }
         } else {
             if (entry.numberValue(field) != other.numberValue(field)) {
                 return false;
             }
         }
     }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { _k_slotDbClick(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (uint field : fields) {
        if (!b.contains(field)) {
            return false;
        }

        if (field & UDSEntry::UDS_STRING) {
            if (a.stringValue(field) != b.stringValue(field)) {
                return false;
            }
        } else {
            if (a.numberValue(field) != b.numberValue(field)) {
                return false;
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KIO::filesize_t pos) { slotPosition(pos); }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->_k_slotFinished();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &location : locations) {
            map.insert(location, row.name);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &pluginMetaData : plugins) {
        KPluginFactory *factory = qobject_cast<KPluginFactory *>(pluginMetaData.instantiate());
        if (factory) {
            KUriFilterPlugin *plugin = factory->create<KUriFilterPlugin>(nullptr);
            if (plugin) {
                const QString &pluginName = plugin->objectName();
                Q_ASSERT(!pluginName.isEmpty());
                d->plugins.insert(pluginName, plugin);
                // Needed to ensure the order of filtering is honored since
                // items are ordered arbitrarily in a QHash and QMap always
                // sorts by keys. Both undesired behavior.
                d->pluginNames << pluginName;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : additionalActions) {
        actionMenu->addAction(action);
    }
```

#### AUTO 


```{c}
const auto networkError = this->networkError();
```

#### RANGE FOR STATEMENT 


```{c}
for (KCoreDirLister *kdl : listers) {
        kdl->d->addNewItems(jobUrl, newItems);
    }
```

#### AUTO 


```{c}
const auto qsslErrors = socket->sslErrors();
```

#### AUTO 


```{c}
const auto itBegin = m_navButtons.begin() + newButtonCount;
```

#### RANGE FOR STATEMENT 


```{c}
for (AnimationState *state : *list) {
            if (state->index == index) {
                return state;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &u : std::as_const(m_popupFiles)) {
        QUrl dest = u;
        dest.setPath(concatPaths(dest.path(), KIO::encodeFileName(chosenFileName)));

        QList<QUrl> lstSrc;
        lstSrc.append(uSrc);
        KIO::Job *kjob;
        if (m_copyData.m_isSymlink) {
            KIO::CopyJob *linkJob = KIO::linkAs(uSrc, dest);
            kjob = linkJob;
            KIO::FileUndoManager::self()->recordCopyJob(linkJob);
        } else if (src.startsWith(QLatin1String(":/"))) {
            QFile srcFile(src);
            if (!srcFile.open(QIODevice::ReadOnly)) {
                return;
            }
            // The QFile won't live long enough for the job, so let's buffer the contents
            const QByteArray srcBuf(srcFile.readAll());
            KIO::StoredTransferJob *putJob = KIO::storedPut(srcBuf, dest, -1);
            kjob = putJob;
            KIO::FileUndoManager::self()->recordJob(KIO::FileUndoManager::Put, QList<QUrl>(), dest, putJob);
        } else {
            // qDebug() << "KIO::copyAs(" << uSrc.url() << "," << dest.url() << ")";
            KIO::CopyJob *job = KIO::copyAs(uSrc, dest);
            job->setDefaultPermissions(true);
            kjob = job;
            KIO::FileUndoManager::self()->recordCopyJob(job);
        }
        KJobWidgets::setWindow(kjob, m_parentWidget);
        QObject::connect(kjob, &KJob::result, q, &KNewFileMenu::slotResult);
    }
```

#### AUTO 


```{c}
const auto jsonPlugins = KPluginLoader::findPlugins(QStringLiteral("kf5/kfileitemaction"), [&db, commonMimeType](const KPluginMetaData& metaData) {
        if (!metaData.serviceTypes().contains(QStringLiteral("KFileItemAction/Plugin"))) {
            return false;
        }

        auto mimeType = db.mimeTypeForName(commonMimeType);
        foreach (const auto& supportedMimeType, metaData.mimeTypes()) {
            if (mimeType.inherits(supportedMimeType)) {
                return true;
            }
        }

        return false;
    });
```

#### LAMBDA EXPRESSION 


```{c}
[this](KIO::Job *job, const KIO::UDSEntryList &list) { _k_slotEntries(job, list); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](int percent) {
        d->slotProgress(percent);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &path : templates) {
        dir.setPath(path);
        const QStringList &entryList(dir.entryList(QStringList() << QStringLiteral("*.desktop"), QDir::Files));
        Q_FOREACH (const QString &entry, entryList) {
            const QString file = concatPaths(dir.path(), entry);
            files.append(file);
        }
    }
```

#### AUTO 


```{c}
const auto &request
```

#### LAMBDA EXPRESSION 


```{c}
[this, url]() {
                    setCurrentItem(url);
                    QObject::disconnect(d->m_connection);
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QModelIndex &index) { d->_k_placeEntered(index); }
```

#### AUTO 


```{c}
auto result = KPluginFactory::instantiatePlugin<KDEDModule>(KPluginMetaData(QLatin1String("kf5/kiod/") + name));
```

#### AUTO 


```{c}
const auto topLevelType = QStringView(mt).mid(0, slashPos);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto button : qAsConst(m_navButtons)) {
            if (button->geometry().contains(p)) {
                const auto url = button->url();
                QAction* openInTab = popup->addAction(QIcon::fromTheme(QStringLiteral("tab-new")), i18n("Open %1 in tab", button->text()));
                q->connect(openInTab, &QAction::triggered, q, [this, url](){ Q_EMIT q->tabRequested(url); });
                break;
            }
        }
```

#### AUTO 


```{c}
auto *dialog = new KPropertiesDialog(list, q);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &s : sl) {
        QList<QSslError::SslError> certErrors;
#if QT_VERSION < QT_VERSION_CHECK(5, 15, 0)
        const QStringList sl2 = s.split(QLatin1Char('\t'), QString::SkipEmptyParts);
#else
        const QStringList sl2 = s.split(QLatin1Char('\t'), Qt::SkipEmptyParts);
#endif
        for (const QString &s2 : sl2) {
            bool didConvert;
            QSslError::SslError error = static_cast<QSslError::SslError>(s2.toInt(&didConvert));
            if (didConvert) {
                certErrors.append(error);
            }
        }
        ret.append(certErrors);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[excludedDesktopEntryNames](const KService::Ptr &service) {
            return !excludedDesktopEntryNames.contains(service->desktopEntryName());
        }
```

#### AUTO 


```{c}
auto err = execWithElevatedPrivilege(DEL, itemPath)
```

#### RANGE FOR STATEMENT 


```{c}
for (KCoreDirLister *kdl : listers) {
            kdl->d->jobDone(job);
            if (job->error() != KJob::KilledJobError) {
                kdl->handleError(job);
            }
            const bool silent = job->property("_kdlc_silent").toBool();
            if (!silent) {
                Q_EMIT kdl->canceled(jobUrl);
            }

            if (kdl->d->numJobs() == 0) {
                kdl->d->complete = true;
                if (!silent) {
                    Q_EMIT kdl->canceled();
                }
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &text) {
        // Select the text without MIME-type extension
        int selectionLength = text.length();

        QMimeDatabase db;
        const QString extension = db.suffixForFileName(text);
        if (extension.isEmpty()) {
            // For an unknown extension just exclude the extension after
            // the last point. This does not work for multiple extensions like
            // *.tar.gz but usually this is anyhow a known extension.
            selectionLength = text.lastIndexOf(QLatin1Char('.'));

            // If no point could be found, use whole text length for selection.
            if (selectionLength < 1) {
                selectionLength = text.length();
            }

        } else {
            selectionLength -= extension.length() + 1;
        }

        return selectionLength;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[widget](KJob *job) {
        if (job->error()) {
            QEventLoopLocker locker;
            KMessageBox::sorry(widget, job->errorString());
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                    updateButtonVisibility();
                }
```

#### AUTO 


```{c}
auto service = KApplicationTrader::preferredService(QLatin1String("x-scheme-handler/") + _protocol)
```

#### RANGE FOR STATEMENT 


```{c}
for (const KServiceAction &action : userServices) {
                    if (showGroup.readEntry(action.name(), true)) {
                        list += action;
                    }
                }
```

#### AUTO 


```{c}
const auto startReply = m_manager->StartTransientUnit(m_serviceName,
        QStringLiteral("fail"), // mode defines what to do in the case of a name conflict, in this case, just do nothing
        { // Properties of the transient service unit
            { QStringLiteral("Type"), QStringLiteral("oneshot") },
            { QStringLiteral("Slice"), QStringLiteral("app.slice") },
            { QStringLiteral("AddRef"), true }, // Asks systemd to avoid garbage collecting the service if it immediately crashes,
                                                // so we can be notified (see https://github.com/systemd/systemd/pull/3984)
            { QStringLiteral("Environment"), m_process->environment() },
            { QStringLiteral("WorkingDirectory"), m_process->workingDirectory() },
            { QStringLiteral("ExecStart"), QVariant::fromValue(ExecCommandList { { m_process->program().first(), m_process->program(), false } }) },
            { QStringLiteral("KillMode"), QStringLiteral("process")}
        },
        {} // aux is currently unused and should be passed as empty array.
    );
```

#### AUTO 


```{c}
auto future = QtConcurrent::run(&KChecksumsPlugin::computeChecksum, algorithm, properties->item().localPath());
```

#### AUTO 


```{c}
auto rrc = connect(m_dirModel, &KDirModel::rowsRemoved, this, [&removalWithinTopLevel](const QModelIndex &index) {
        if (!index.isValid()) {
            // yes, that's what we have been waiting for
            removalWithinTopLevel = true;
        }
    });
```

#### AUTO 


```{c}
auto *openWithHandler = KIO::delegateExtension<KIO::OpenWithHandlerInterface *>(q);
```

#### AUTO 


```{c}
auto kit = items.cbegin();
```

#### LAMBDA EXPRESSION 


```{c}
[=](bool result, bool isLink){
            this->rmFileResult(result, isLink);
        }
```

#### AUTO 


```{c}
auto watcher = QSharedPointer<QDBusPendingCallWatcher>::create(pending);
```

#### LAMBDA EXPRESSION 


```{c}
[]() {
            qDebug() << "applied";
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->slotProperties();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const KService::Ptr &service, const QString &prop) {
        return service->property(prop).toString();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *act : actionsList) {
            if (act->text().contains(actionText)) {
                textAct = act;
            }
        }
```

#### AUTO 


```{c}
auto *uiDelegate = new KJobUiDelegate;
```

#### AUTO 


```{c}
auto dirItemIt = std::find_if(dirItem->lstItems.begin(), dirItem->lstItems.end(), [&url](const KFileItem &fitem) {
                return fitem.url() == url;
            });
```

#### LAMBDA EXPRESSION 


```{c}
[this, menu]() {
            m_menus.remove(menu);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        this->d->slotSortReversed(true);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->slotOpenFileManager();
    }
```

#### AUTO 


```{c}
auto ejectAction = m_model->ejectAction(index);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& mimeType : mimeTypeList) {
        KFileItemList mimeItems;
        for (const KFileItem &item : fileItems) {
            if (item.mimetype() == mimeType) {
                mimeItems << item;
            }
        }
        // Show Open With dialog
        auto *job = new KIO::ApplicationLauncherJob();
        job->setUrls(mimeItems.urlList());
        job->setUiDelegate(new KIO::JobUiDelegate(KJobUiDelegate::AutoHandlingEnabled, m_parentWidget));
        job->start();
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr int NTLM_BLOB_SIZE = 28;
```

#### AUTO 


```{c}
const auto &user
```

#### AUTO 


```{c}
auto itu = itemsInUse.cbegin();
```

#### LAMBDA EXPRESSION 


```{c}
[this, &seenUrls](const char *translationContext,
                const QByteArray &untranslatedLabel,
                const QUrl &url,
                const QString &iconName) {
            if (!seenUrls.contains(url)) {
                KFilePlacesItem::createSystemBookmark(d->bookmarkManager, translationContext, untranslatedLabel, url, iconName);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& mimeType : mimeTypeList) {
        KFileItemList mimeItems;
        for (const KFileItem &item : fileItems) {
            if (item.mimetype() == mimeType) {
                mimeItems << item;
            }
        }
        KRun::displayOpenWithDialog(mimeItems.urlList(), m_parentWidget);
    }
```

#### AUTO 


```{c}
auto *simpleJob = ::qobject_cast<KIO::SimpleJob *>(job);
```

#### AUTO 


```{c}
auto action = std::find_if(actions.cbegin(), actions.cend(), [service](const KServiceAction &action) {
            return action.exec() == service->exec();
        });
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &str : std::as_const(searchProviders)) {
        actionData.append(filterData.queryForPreferredSearchProvider(str));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->reloadBookmarks();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        auto err = execWithElevatedPrivilege(COPY, {srcUrl, destUrl}, errno);
        if (err) {
            if (!err.wasCanceled()) {
                error(KIO::ERR_UNKNOWN, QString());
            }
        } else {
            finished();
        }
    }
```

#### AUTO 


```{c}
auto it = m_deleted.begin();
```

#### RANGE FOR STATEMENT 


```{c}
for (KCoreDirLister *kdl : std::as_const(listers)) {
        // deduplicate listers
        listersToRefresh.insert(kdl);
    }
```

#### AUTO 


```{c}
const auto filtersList = QStringList{QStringLiteral("kshorturifilter")};
```

#### RANGE FOR STATEMENT 


```{c}
for (const char c : s_msdosInvalidChars) {
        name.replace(QLatin1Char(c), QLatin1String("_"));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&path](const FileInfo &i) { return i.path == path; }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->slotViewKeyEnterReturnPressed();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const URLHint &hint : qAsConst(m_urlHints)) {
            qCDebug(category) << "testing regexp for" << hint.prepend;
            if (hint.regexp.indexIn(cmd) == 0) {
                const QString cmdStr = hint.prepend + cmd;
                QUrl url(cmdStr);
                qCDebug(category) << "match - prepending" << hint.prepend << "->" << cmdStr << "->" << url;
                setFilteredUri(data, url);
                setUriType(data, hint.type);
                return true;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : std::as_const(m_dirsToUpdate)) {
            // qDebug() << "Notifying FilesAdded for " << url;
            org::kde::KDirNotify::emitFilesAdded(url);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        slotFinished();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KIO::Job *job, QByteArray &data) { _k_slotDataReq(job, data); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &protocol : qAsConst(m_protocols)) {
        if (m_categories.contains(protocol)) {
            const ProtocolCategory category = m_categories.value(protocol);
            items[category].append(protocol);
        } else {
            items[OtherCategory].append(protocol);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        if (dirs.isEmpty()) {
            setDirty(false);
            Q_EMIT changesApplied();
            return;
        }

        auto *dirsJob = KIO::chmod(dirs, orDirPermissions, ~andDirPermissions, owner, group, recursive);
        processACLChanges(dirsJob);

        connect(dirsJob, &KJob::result, this, [this, dirsJob]() {
            if (dirsJob->error()) {
                dirsJob->uiDelegate()->showErrorMessage();
            }

            setDirty(false);
            Q_EMIT changesApplied();
        });
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](int index) { _k_slotActivated(index); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KIO::Job *job) {
        m_messageWidget->setText(job->errorString());
        m_messageWidget->animatedShow();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& mimeFilter : mimeFilters) {
                    regex.setPattern(mimeFilter);
                    if (regex.match(fileMimeType.name()).hasMatch()) {   // matches!
                        mimeFilterPass = true;
                        break;
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& mimeType : mimeTypeList) {
        KFileItemList mimeItems;
        for (const KFileItem &item : fileItems) {
            if (item.mimetype() == mimeType) {
                mimeItems << item;
            }
        }
        // Show Open With dialog
        KIO::ApplicationLauncherJob *job = new KIO::ApplicationLauncherJob();
        job->setUrls(mimeItems.urlList());
        job->setUiDelegate(new KIO::JobUiDelegate(KJobUiDelegate::AutoHandlingEnabled, m_parentWidget));
        job->start();
    }
```

#### AUTO 


```{c}
const auto url2 = QUrl("file:///foo/bar/2");
```

#### AUTO 


```{c}
const auto result = ftpSendMimeType(url);
```

#### LAMBDA EXPRESSION 


```{c}
[this](QAction* action) {
                m_triggered = true;
                slotTriggered(action);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
            qDebug() << "ftpd STDERR:" << m_daemonProc.readAllStandardError();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QUrl &url) {
        QString dest;
        if (url.isLocalFile()) {
            dest = KShell::tildeCollapse(url.toLocalFile());
        } else {
            dest = targetUrl().toDisplayString();
        }
        return dest;
    }
```

#### AUTO 


```{c}
auto createSystemBookmark =
            [this, &seenUrls](const char *translationContext,
                              const QByteArray &untranslatedLabel,
                              const QUrl &url,
                              const QString &iconName,
                              const KBookmark &after) {
                if (!seenUrls.contains(url)) {
                    return KFilePlacesItem::createSystemBookmark(d->bookmarkManager, translationContext, untranslatedLabel, url, iconName, after);
                }
                return KBookmark();
            };
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        const QString checksum = futureWatcher->result();
        futureWatcher->deleteLater();

        cacheChecksum(checksum, algorithm);

        switch (algorithm) {
        case QCryptographicHash::Md5:
            slotShowMd5();
            break;
        case QCryptographicHash::Sha1:
            slotShowSha1();
            break;
        case QCryptographicHash::Sha256:
            slotShowSha256();
            break;
        case QCryptographicHash::Sha512:
            slotShowSha512();
            break;
        default:
            break;
        }

        const bool isMatch = (checksum == input);
        if (isMatch) {
            setMatchState();
        } else {
            setMismatchState();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const URLHint &hint : std::as_const(m_urlHints)) {
            qCDebug(category) << "testing regexp for" << hint.prepend;
            if (hint.hintRe.match(cmd).capturedStart() == 0) {
                const QString cmdStr = hint.prepend + cmd;
                QUrl url(cmdStr);
                qCDebug(category) << "match - prepending" << hint.prepend << "->" << cmdStr << "->" << url;
                setFilteredUri(data, url);
                setUriType(data, hint.type);
                return true;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& tag: tagsList) {
        bookmark = KFilePlacesItem::createTagBookmark(bookmarkManager, tag);
        if (!bookmark.isNull()) {
            KFilePlacesItem *item = new KFilePlacesItem(bookmarkManager,
                    bookmark.address(), tag);
            connect(item, SIGNAL(itemChanged(QString)),
                    q, SLOT(_k_itemChanged(QString)));
            items << item;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KCoreDirLister *kdl : holders) {
                // lister's root is the deleted item
                if (kdl->d->url == deletedUrl) {
                    // tell the view first. It might need the subdirs' items (which forgetDirs will delete)
                    if (!kdl->d->rootFileItem.isNull()) {
                        Q_EMIT kdl->itemsDeleted(KFileItemList{kdl->d->rootFileItem});
                    }
                    forgetDirs(kdl);
                    kdl->d->rootFileItem = KFileItem();
                } else {
                    const bool treeview = kdl->d->lstDirs.count() > 1;
                    if (!treeview) {
                        Q_EMIT kdl->clear();
                        kdl->d->lstDirs.clear();
                    } else {
                        kdl->d->lstDirs.removeAll(deletedUrl);
                    }

                    forgetDirs(kdl, deletedUrl, treeview);
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this, menu]() { m_menus.remove(menu); }
```

#### CONST EXPRESSION 


```{c}
static constexpr int MAX_IPC_SIZE = 1024 * 8;
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->slotCompactView();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KCoreDirLister *listit : listers) {
            list += QLatin1String(" 0x") + QString::number(reinterpret_cast<qlonglong>(listit), 16);
        }
```

#### AUTO 


```{c}
const auto pending = QDBusConnection::sessionBus().asyncCall(message);
```

#### AUTO 


```{c}
auto privilegeRestore = qScopeGuard([&origPrivilege]() {
            gainPrivilege(&origPrivilege);
        });
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &item : items) {
            if (!item.isNull()) {
                const QModelIndex dirIndex = d->m_dirModel->indexForItem(item);
                proxyIndex = d->m_proxyModel->mapFromSource(dirIndex);
                selModel->select(proxyIndex, QItemSelectionModel::Select);
            }
        }
```

#### AUTO 


```{c}
auto it = m_navButtons.crbegin();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { _k_slotUpdateUrl(); }
```

#### AUTO 


```{c}
const auto checkLastModTime = [this, checkMaxTime](const QString &fileName) {
        const auto trashFileInfo = getTrashFileInfo(fileName);
        if (!trashFileInfo.exists()) {
            return;
        }
        checkMaxTime(trashFileInfo.lastModified().toMSecsSinceEpoch());
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (KIO::DropMenu *menu : d->m_menus) {
        menu->addExtraActions(d->m_appActions, d->m_pluginActions);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[destFile, suspend, destToCheck](KJob *job, qulonglong processedSize) {
        if (processedSize > 0) {
            QVERIFY2(QFile::exists(destToCheck), qPrintable(destToCheck));
            if (suspend) {
                job->suspend();
            }
            QVERIFY(job->kill());
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool allowDelete, const QList<QUrl> &urls,
                               KIO::AskUserActionInterface::DeletionType deletionType, QWidget *parentWidget) {
                        _k_slotAskUserDeleteResult(allowDelete, urls, deletionType, parentWidget);
                     }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        slotCreateDirectory();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const KFileItemList &items){d->_k_slotDeleteItems(items);}
```

#### AUTO 


```{c}
const auto resultingActions = menu.actions();
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool shouldExecute) {
            if (shouldExecute) {
                executeCommand();
            } else {
                openInPreferredApp();
            }
        }
```

#### AUTO 


```{c}
const auto srcFileName = QFile::encodeName(QFileInfo(QFINDTESTDATA("jobtest.cpp")).absolutePath()).constData();
```

#### LAMBDA EXPRESSION 


```{c}
[this](KIO::Job *job, KIO::filesize_t offset) {
                    slotCanResume(job, offset);
                }
```

#### AUTO 


```{c}
auto *batchRenameJob = qobject_cast<KIO::BatchRenameJob *>(job)
```

#### AUTO 


```{c}
const auto startReply = m_manager->StartTransientUnit(m_serviceName,
        QStringLiteral("fail"), // mode defines what to do in the case of a name conflict, in this case, just do nothing
        { // Properties of the transient service unit
            { QStringLiteral("Type"), QStringLiteral("oneshot") },
            { QStringLiteral("Slice"), QStringLiteral("app.slice") },
            { QStringLiteral("AddRef"), true }, // Asks systemd to avoid garbage collecting the service if it immediately crashes,
                                                // so we can be notified (see https://github.com/systemd/systemd/pull/3984)
            { QStringLiteral("Environment"), m_process->environment() },
            { QStringLiteral("WorkingDirectory"), m_process->workingDirectory() },
            { QStringLiteral("ExecStart"), QVariant::fromValue(ExecCommandList { { m_process->program().first(), m_process->program(), false } }) } },
        {} // aux is currently unused and should be passed as empty array.
    );
```

#### LAMBDA EXPRESSION 


```{c}
[this, job](const int exitCode) {
        Q_EMIT askUserSkipResult(static_cast<KIO::SkipDialog_Result>(exitCode), job);
    }
```

#### AUTO 


```{c}
const auto fileSize = f.size();
```

#### AUTO 


```{c}
const auto testOverwriteCopy1 = QFINDTESTDATA("ftp/testOverwriteCopy1");
```

#### LAMBDA EXPRESSION 


```{c}
[&itemsToDelete](const KFileItem &item) {
        return itemsToDelete.contains(item.name());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &supportedMimeType : list) {
            if (mimeType.inherits(supportedMimeType)) {
                return true;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QModelIndex &parentIndex, const QString &name){
        for (int row = 0; row < m_dirModel->rowCount(parentIndex); ++row) {
            QModelIndex idx = m_dirModel->index(row, 0, parentIndex);
            if (m_dirModel->itemForIndex(idx).isDir() && m_dirModel->itemForIndex(idx).name() == name) {
                return idx;
            }
        }
        return QModelIndex();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->slotAutoSelectExtClicked();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { configChanged(); }
```

#### AUTO 


```{c}
auto r
```

#### LAMBDA EXPRESSION 


```{c}
[this](QDBusPendingCallWatcher *watcher) {
        QDBusPendingReply<QDBusObjectPath> reply = *watcher;
        watcher->deleteLater();
        if (reply.isError()) {
            qCWarning(KIO_GUI) << "Failed to launch process as service:" << m_serviceName << reply.error().name() << reply.error().message();
            return systemdError(reply.error().name());
        }
        qCDebug(KIO_GUI) << "Successfully asked systemd to launch process as service:" << m_serviceName;
        m_jobPath = reply.argumentAt<0>().path();
    }
```

#### IF STATEMENT WITH INITIALIZER 


```{c}
if (QT_STATBUF buff_dest; QT_LSTAT(dest_c.constData(), &buff_dest) == 0) {
                error(S_ISDIR(buff_dest.st_mode) ? KIO::ERR_DIR_ALREADY_EXIST : KIO::ERR_FILE_ALREADY_EXIST, dest);
            } else { // Can't happen, we already know "dest" exists
                error(KIO::ERR_CANNOT_SYMLINK, dest);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Solid::Device &device : deviceList) {
        availableDevices << device.udi();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const ItemInUseChange &i : itemsToChange) {
        itemsInUse.remove(i.oldUrl);
        itemsInUse.insert(i.newUrl, i.dirItem);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KIO::Job *job, const QString &type) {
                slotMimetype(job, type);
            }
```

#### AUTO 


```{c}
auto service = KService::serviceByDesktopName(desktopEntryName);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QHostAddress &address : info.addresses()) {
                if (!isSpecialAddress(address) && isIPv4Address(address)) {
                    resolvedAddress = address.toString();
                    break;
                }
            }
```

#### IF STATEMENT WITH INITIALIZER 


```{c}
if (KServicePtr service = serviceFromConfig(fallbackToKonsoleService); service) {
        d->m_desktopName = service->desktopEntryName();
        exec = service->exec();
    } else {
        // konsole not found by desktop file, let's see what PATH has for us
        auto useIfAvailable = [&exec](const QString &terminalApp) {
            const bool found = !QStandardPaths::findExecutable(terminalApp).isEmpty();
            if (found) {
                exec = terminalApp;
            }
            return found;
        };
        if (!useIfAvailable(QStringLiteral("konsole")) && !useIfAvailable(QStringLiteral("xterm"))) {
            setError(KJob::UserDefinedError);
            setErrorText(i18n("No terminal emulator found"));
            return;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &item : *this) {
        lst.append(item.targetUrl());
    }
```

#### AUTO 


```{c}
const auto data = dataIt.value();
```

#### AUTO 


```{c}
const auto destFs = KFileSystemType::fileSystemType(destPath);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &tag : tagsList) {
        bookmark = KFilePlacesItem::createTagBookmark(bookmarkManager, tag);
        if (!bookmark.isNull()) {
            KFilePlacesItem *item = new KFilePlacesItem(bookmarkManager, bookmark.address(), tag);
            connect(item, &KFilePlacesItem::itemChanged, q, [this](const QString &id) {
                _k_itemChanged(id);
            });
            items << item;
        }
    }
```

#### AUTO 


```{c}
auto *askUserActionInterface = KIO::delegateExtension<KIO::AskUserActionInterface *>(q)
```

#### AUTO 


```{c}
auto it = std::remove_if(lstItems.begin(), lstItems.end(), [&itemsToDelete](const KFileItem &item) {
        return itemsToDelete.contains(item.name());
    });
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &portStr : list) {
            const int portNum = portStr.toInt(&ok);
            if (ok) {
                ports->append(portNum);
            }
        }
```

#### AUTO 


```{c}
auto backShortcuts = backAction->shortcuts();
```

#### LAMBDA EXPRESSION 


```{c}
[this](KIO::Job* job, const KIO::UDSEntryList &list) { slotEntries(job, list); }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        if (job->error()) {
            app.exit(1);
        } else {
            qDebug() << "Started. pid=" << job->pid();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KCoreDirLister *kdl : listers) {
            kdl->d->jobDone(job);
            Q_EMIT kdl->completed(jobUrl);
            if (kdl->d->numJobs() == 0) {
                kdl->d->complete = true;
                Q_EMIT kdl->completed();
            }
        }
```

#### AUTO 


```{c}
const auto additionalActions = actions();
```

#### RANGE FOR STATEMENT 


```{c}
for (const KService::Ptr &ptr : offers) {
        KPropertiesDialogPlugin *plugin = ptr->createInstance<KPropertiesDialogPlugin>(q);
        if (!plugin) {
            continue;
        }
        plugin->setObjectName(ptr->name());

        q->insertPlugin(plugin);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KMountPoint::Ptr mountPoint : mountPoints) {
        // keep one (first) mountpoint with a device name
        if (!mountWithDevice && !mountPoint->realDeviceName().isEmpty()) {
            mountWithDevice = mountPoint;
        }

        // keep one (first) ZFS mountpoint
        if (!anyZfsMount && mountPoint->mountType() == QLatin1String("zfs")) {
            anyZfsMount = mountPoint;
        }
        
        // keep one (first) mountpoint with any options
        if (!mountWithOptions && !mountPoint->mountOptions().empty()) {
            mountWithOptions = mountPoint;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KCoreDirLister *kdl : listers) {
            kdl->d->jobDone(job);
            if (job->error() != KJob::KilledJobError) {
                kdl->handleError(job);
            }
            const bool silent = job->property("_kdlc_silent").toBool();
            if (!silent) {
#if KIOCORE_BUILD_DEPRECATED_SINCE(5, 79)
                Q_EMIT kdl->canceled(jobUrl);
#endif
                Q_EMIT kdl->listingDirCanceled(jobUrl);
            }

            if (kdl->d->numJobs() == 0) {
                kdl->d->complete = true;
                if (!silent) {
                    Q_EMIT kdl->canceled();
                }
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        _k_delayedSlotTextChanged();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&] {
        QFile(inaccessible).setPermissions(QFile::Permissions(QFile::ReadOwner | QFile::WriteOwner | QFile::ExeOwner));

        KIO::DeleteJob *deljob1 = KIO::del(QUrl::fromLocalFile(src_dir), KIO::HideProgressInfo);
        deljob1->setUiDelegate(nullptr); // no skip dialog, thanks
        QVERIFY(deljob1->exec());

        KIO::DeleteJob *deljob2 = KIO::del(QUrl::fromLocalFile(dst_dir), KIO::HideProgressInfo);
        deljob2->setUiDelegate(nullptr); // no skip dialog, thanks
        QVERIFY(deljob2->exec());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](bool result, bool isLink) {
            this->rmFileResult(result, isLink);
        }
```

#### AUTO 


```{c}
auto job = KIO::copy({QUrl::fromLocalFile(QFINDTESTDATA("ftp/testCopy2"))}, url, KIO::Resume);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &str : supported) {
                    // the "mimetypes" we get from the PreviewJob can be "image/*"
                    // so we need to check in wildcard mode
                    re.setPattern(QRegularExpression::wildcardToRegularExpression(str));
                    if (re.match(mime).hasMatch()) {
                        return true;
                    }
                }
```

#### LAMBDA EXPRESSION 


```{c}
[destFileExists, destPartFile](KJob *job, qulonglong totalSize) {
        Q_UNUSED(job);
        if (totalSize > 0) {
            QCOMPARE(destFileExists, QFile::exists(destPartFile));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KUrlNavigatorButton *button : std::as_const(d->m_navButtons)) {
            button->setShowMnemonic(true);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[q](KIO::Job *, const QUrl &, const QUrl &to) {
        Q_EMIT q->itemCreated(to);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[bufferSize](qint64 pos, QFile &f, QByteArray &buffer) {
        auto ioresult = f.seek(pos);
        if (ioresult) {
            const int bytesRead = f.read(buffer.data(), bufferSize);
            ioresult = bytesRead != -1;
        }
        if (!ioresult) {
            qCWarning(KIO_WIDGETS) << "Could not read file for comparison:" << f.fileName();
            return false;
        }
        return true;
    }
```

#### AUTO 


```{c}
auto rejectButton = KGuiItem(buttonNo, iconNo);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->updateButtonVisibility();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto r : qAsConst(d->m_processRunners)) {
        if (!r.isNull()) {
            qApp->sendPostedEvents(r); // so slotStarted gets called
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](uint jobId, const QDBusObjectPath &jobPath, const QString &unitName, const QString &result) {
            Q_UNUSED(jobId)
            if (jobPath.path() == m_jobPath && unitName == m_serviceName && result != QLatin1String("done")) {
                qCWarning(KIO_GUI) << "Failed to launch process as service:" << m_serviceName << ", result " << result;
                // result=failed is not a fatal error, service is actually created in this case
                if (result != QLatin1String("failed")) {
                    systemdError(result);
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : args) {
        // get full path
        const QString fullFilePath(QDir::current().absoluteFilePath(file));

        // construct kconfig for protocol file
        KConfig sconfig(fullFilePath);
        sconfig.setLocale(QString());
        KConfigGroup config(&sconfig, "Protocol");

        // name must be set, sanity check that file got read
        const QString name(config.readEntry("protocol"));
        if (name.isEmpty()) {
            qFatal("Failed to read input file %s.", qPrintable(fullFilePath));
        }

        // construct protocol data
        QVariantMap protocolData;

        // convert the different types
        for (const QString &key : stringAttributes) {
            if (config.hasKey(key)) {
                protocolData.insert(key, config.readEntry(key, QString()));
            }
        }
        for (const QString &key : stringListAttributes) {
            if (config.hasKey(key)) {
                protocolData.insert(key, config.readEntry(key, QStringList()));
            }
        }
        for (const QString &key : boolAttributes) {
            if (config.hasKey(key)) {
                protocolData.insert(key, config.readEntry(key, bool(false)));
            }
        }
        for (const QString &key : intAttributes) {
            if (config.hasKey(key)) {
                protocolData.insert(key, config.readEntry(key, int(0)));
            }
        }

        // handle translated keys
        for (const QString &key : translatedStringListAttributes) {
            // read untranslated entry first in any case!
            sconfig.setLocale(QString());
            const QStringList untranslatedValues = config.readEntry(key, QStringList());
            if (!untranslatedValues.isEmpty()) {
                protocolData.insert(key, untranslatedValues);
            }

            // collect all locales for this key
            QFile f(fullFilePath);
            QStringList foundLocalesForKey;
            if (!f.open(QIODevice::ReadOnly | QIODevice::Text)) {
                qFatal("Failed to open file %s.", qPrintable(fullFilePath));
            }
            while (!f.atEnd()) {
                const QString line = QString::fromUtf8(f.readLine());
                const QRegularExpressionMatch match = localeRegex.match(line);
                if (match.hasMatch()) {
                    foundLocalesForKey.append(match.captured(1));
                }
            }

            // insert all entries for all found locales, reparse config for this
            for (const QString &locale : std::as_const(foundLocalesForKey)) {
                sconfig.setLocale(locale);
                protocolData.insert(QStringLiteral("%1[%2]").arg(key, locale), config.readEntry(key, QStringList()));
            }
        }

        // use basename of protocol for toplevel map in json, like it is done for .protocol files
        const QString baseName(QFileInfo(fullFilePath).baseName());
        protocolsData.insert(baseName, protocolData);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool enable) {
        d->togglePreview(enable);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool show) {
        toggleBookmarks(show);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        d->m_delegate->checkFreeSpace();
        // Start polling even if checkFreeSpace() wouldn't because we might just have checked
        // free space before the timeout and so the poll timer would never get started again
        d->m_delegate->startPollingFreeSpace();
    }
```

#### AUTO 


```{c}
const auto acl2 = list.at(1);
```

#### LAMBDA EXPRESSION 


```{c}
[this](QAction *action) {
        d->_k_slotActionTriggered(action);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &cookie : cookies) {
        const int index = cookie.indexOf(QLatin1Char('='));
        const QStringRef name = cookie.leftRef(index);
        const QStringRef value = cookie.rightRef((cookie.length() - index - 1));
        cookieList << QNetworkCookie(name.toUtf8(), value.toUtf8());
        // qDebug() << "cookie: name=" << name << ", value=" << value;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KCModule *module : std::as_const(modules)) {
        module->load();
    }
```

#### AUTO 


```{c}
auto home = QDir::homePath();
```

#### AUTO 


```{c}
const auto [it, isInserted] = pendingUpdates.insert(filePath);
```

#### AUTO 


```{c}
auto pluginIt = mimeMap.constFind(mimeType);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->slotSelectionChanged(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KMountPoint::Ptr &mp : *this) {
        const QString mountpoint = mp->d->mountPoint;
        const int length = mountpoint.length();
        if (length > max && pathsAreParentAndChildOrEqual(mountpoint, realname)) {
            max = length;
            result = mp;
            // keep iterating to check for a better match (bigger max)
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &parentMimeType : parentMimeTypes) {
                        pluginIt = mimeMap.constFind(parentMimeType);
                        if (pluginIt != mimeMap.constEnd()) {
                            break;
                        }
                    }
```

#### AUTO 


```{c}
auto it = lstItems.begin();
```

#### LAMBDA EXPRESSION 


```{c}
[&mimeptr](const QString &filter) {
        return mimeptr.inherits(filter);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job, ulong _percent) { slotPercent(job, _percent); }
```

#### AUTO 


```{c}
auto item
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &item : qAsConst(m_resolvedMimeTypes)) {
            const QModelIndex idx = dirModel->indexForItem(item);
            dirModel->itemChanged(idx);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job, qulonglong _psize) { slotProcessedSize(job, _psize); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &domain : domainList) {
            const KHttpCookieList *list = mCookieJar->getCookieList(domain, fqdn);
            if (!list) {
                continue;
            }
            for (const KHttpCookie &cookie : *list) {
                if (cookie.isExpired()) {
                    continue;
                }
                if (cookieMatches(cookie, domain, fqdn, path, name)) {
                    putCookie(result, cookie, fields);
                    break;
                }
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=](bool result){
            this->rmdirResult(result);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KIO::Job *job, const QString &mimeType) { _k_slotMimetype(job, mimeType); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool enable) {
        d->toggleInlinePreviews(enable);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, dirsJob]() {
            if (dirsJob->error()) {
                dirsJob->uiDelegate()->showErrorMessage();
            }

            setDirty(false);
            Q_EMIT changesApplied();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, job](const int exitCode) {
        emit askUserSkipResult(static_cast<KIO::SkipDialog_Result>(exitCode), job);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](const int result) {
        KIO::SlaveBase::ButtonCode btnCode;
        switch (result) {
        case QDialogButtonBox::Yes:
            if (dlgType == KMessageDialog::WarningContinueCancel) {
                btnCode = KIO::SlaveBase::Continue;
            } else {
                btnCode = KIO::SlaveBase::Yes;
            }
            break;
        case QDialogButtonBox::No:
            btnCode = KIO::SlaveBase::No;
            break;
        case QDialogButtonBox::Cancel:
            btnCode = KIO::SlaveBase::Cancel;
            break;
        case QDialogButtonBox::Ok:
            btnCode = KIO::SlaveBase::Ok;
            break;
        default:
            qCWarning(KIO_WIDGETS) << "Unknown message dialog result" << result;
            return;
        }

        Q_EMIT messageBoxResult(btnCode);

        if (result != QDialogButtonBox::Cancel) {
            KConfigGroup cg = reqMsgConfig->group("Notification Messages");
            cg.writeEntry(dontAskAgainName, !dialog->isDontAskAgainChecked());
            cg.sync();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->slotCanceled(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (WId windowId : cookie.windowIds()) {
                    if (windowId && (!cookiePtr.windowIds().contains(windowId))) {
                        cookiePtr.windowIds().append(windowId);
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &criterion : requiredNumberOfUrls) {
            const int number = criterion.toInt();
            if (number < 1) {
                continue;
            }

            if (urlList.count() == number) {
                matchesAtLeastOneCriterion = true;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &item : *itemList) {
            if (isItemVisible(item) && q->matchesMimeFilter(item)) {
                oldVisibleItems.insert(item.name());
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KIO::Job *job, const QString &mimeType) {
        _k_slotMimetype(job, mimeType);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KIO::Job *job, const QByteArray &data) {
        _k_slotData(job, data);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &info : infoList) {
            del(trashId, info.fileName()); // delete trashed file

            TrashSizeCache trashSize(trashPath);
            if (util.usage(trashSize.calculateSize() + additionalSize) < percent) { // check whether we have enough space now
                return true;
            }
        }
```

#### CONST EXPRESSION 


```{c}
static constexpr int s_reportTimeout = 200;
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->zoomOutIconsSize();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &p : pools) {
            if (p.minSize < wants) {
                continue;
            } else {
                thumbDir = p.path;
                break;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](Solid::ErrorType error, QVariant errorData) {
            d->storageTeardownDone(error, errorData);
        }
```

#### AUTO 


```{c}
auto *askUserHandler = new MockAskUserInterface(uiDelegate);
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        const int errCode = job->error();
        if (errCode) {
             // ERR_NO_CONTENT is not an error, but an indication no further
             // actions need to be taken.
             if (errCode != KIO::ERR_NO_CONTENT) {
                 q->setError(errCode);
                 q->setErrorText(job->errorText());
             }
             q->emitResult();
        }
        // if the job succeeded, we certainly hope it emitted mimeTypeFound()...
        if (m_mimeTypeName.isEmpty()) {
            qCWarning(KIO_CORE) << "KIO::get didn't emit a mimetype! Please fix the ioslave for URL" << m_url;
            q->setError(KIO::ERR_INTERNAL);
            q->setErrorText(i18n("Unable to determine the type of file for %1", m_url.toDisplayString()));
            q->emitResult();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        dispatchIconUpdateQueue();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &offer : offers) {
        const QByteArray scheme = offer.mid(0, offer.indexOf(' ')).toLower();
#if HAVE_LIBGSSAPI
        if (scheme == "negotiate") { // krazy:exclude=strings
            negotiateOffer = offer;
        } else
#endif
            if (scheme == "digest") { // krazy:exclude=strings
            digestOffer = offer;
        } else if (scheme == "ntlm") { // krazy:exclude=strings
            ntlmOffer = offer;
        } else if (scheme == "basic") { // krazy:exclude=strings
            basicOffer = offer;
        }
    }
```

#### AUTO 


```{c}
const auto previousGroupName = groupNameFromIndex(previousVisibleIndex(index));
```

#### CONST EXPRESSION 


```{c}
static constexpr auto DEFAULT_CACHE_CONTROL = KIO::CC_Refresh;
```

#### RANGE FOR STATEMENT 


```{c}
for (KSslError::Error e : errorsList) {
            KSslError classError(e);
            trusted += QLatin1Char('\n') + classError.errorString();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &locale : qAsConst(foundLocalesForKey)) {
                sconfig.setLocale(locale);
                protocolData.insert(QStringLiteral("%1[%2]").arg(key, locale), config.readEntry(key, QStringList()));
            }
```

#### LAMBDA EXPRESSION 


```{c}
[&max_mtime] (const qint64 lastModTime) {
        if (lastModTime > max_mtime) {
            max_mtime = lastModTime;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&root](KFilePlacesModel::GroupType type) {
        root.setMetaDataItem(stateNameForGroupType(type), QStringLiteral("false"));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KIO::ListJob *job, KIO::ListJob *ljob) {
                        slotSubError(job, ljob);
                    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, dlg](int result) {
        passwordDialogDone(result, dlg);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &item : fileItems) {
            const KService::Ptr serv = preferredService(item.mimetype(), QStringList(), m_traderConstraint);
            const QString preferredServiceId = serv ? serv->storageId() : QString();
            if (preferredServiceId == serviceId) {
                serviceItems << item;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (KCoreDirLister *kdl : listers) {
        if (job) {
            kdl->d->jobDone(job);
        }

        emit kdl->canceled(oldUrl);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KIO::Job *job, const QByteArray &data) {
        d->slotData(job, data);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &path : std::as_const(search)) {
        // qDebug() << "Looking for help in: " << path;

        if (checkFile(path)) {
            return path;
        }

        if (path.endsWith(QLatin1String(".html"))) {
            const QString file = QStringView(path).left(path.lastIndexOf(QLatin1Char('/'))) + QLatin1String("/index.docbook");
            // qDebug() << "Looking for help in: " << file;
            if (checkFile(file)) {
                return path;
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const KFileItemList &items) {
            updateIcons(items);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString & f) {
        QFile::remove(f);
    }
```

#### AUTO 


```{c}
auto *mkpathJob = qobject_cast<KIO::MkpathJob *>(job)
```

#### RANGE FOR STATEMENT 


```{c}
for (SearchProvider *provider : providers) {
        if (defaultSearchEngine == provider->desktopEntryName()) {
            defaultProviderIndex = providers.size();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[d]() {
            d->slotStart();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &item : deletedItems) {
        if (item.isDir()) {
            deleteDir(item.url());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &s : sl) {
        QList<KSslError::Error> certErrors;
        const QStringList sl2 = s.split(QLatin1Char('\t'), QString::SkipEmptyParts);
        for (const QString &s2 : sl2) {
            bool didConvert;
            KSslError::Error error = KSslErrorPrivate::errorFromQSslError(static_cast<QSslError::SslError>(s2.toInt(&didConvert)));
            if (didConvert) {
                certErrors.append(error);
            }
        }
        ret.append(certErrors);
    }
```

#### AUTO 


```{c}
auto doDelete(const QList<QUrl>& items)
{
    auto job = KIO::del(items);

    return jobToFuture(QStringLiteral("delete %1").arg(toStr(items)), job);
}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &filter : nameFilters) {
                if (filter == QLatin1Char('*')) {
                    return true;
                }

                const QMimeType mt = db.mimeTypeForFile(filter, QMimeDatabase::MatchExtension /*fast mode, no file contents exist*/);
                if (!mt.isValid()) {
                    continue;
                }
                const QString mime = mt.name();

                for (const QString &str : supported) {
                // the "mimetypes" we get from the PreviewJob can be "image/*"
                // so we need to check in wildcard mode
                    re.setPattern(QRegularExpression::wildcardToRegularExpression(str));
                    if (re.match(mime).hasMatch()) {
                        return true;
                    }
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (KCoreDirLister *kdl : listers) {
        kdl->d->redirect(oldUrl, newUrl, false /*clear items*/);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[]() {
            qDebug() << "canceled";
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&putDataBuffer, &size, putDataContents]() {
        const auto pos = putDataBuffer.pos();
        size += putDataBuffer.write(putDataContents);
        putDataBuffer.seek(pos);
//         qDebug() << "written" << size;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : qAsConst(m_srcList)) {
            if (m_dest.scheme() == url.scheme() && m_dest.host() == url.host()) {
                QString srcPath = url.path();
                if (!srcPath.endsWith(QLatin1Char('/'))) {
                    srcPath += QLatin1Char('/');
                }
                if (m_dest.path().startsWith(srcPath)) {
                    q->setError(KIO::ERR_CANNOT_MOVE_INTO_ITSELF);
                    q->emitResult();
                    return;
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &key : keys) {
        if (key.length() > name.length()) {
            // We should avoid hidden files and directory paths, BUG: 407944
            name = key.toLower().remove(QLatin1Char('.')).remove(QLatin1Char('/'));;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const HTTPRequest &r : qAsConst(m_requestQueue)) {
            m_request = r;
            qCDebug(KIO_HTTP) << "check two: isKeepAlive =" << m_request.isKeepAlive;
            setMetaData(QStringLiteral("request-id"), QString::number(requestId++));
            sendAndKeepMetaData();
            if (!(readResponseHeader() && readBody())) {
                return;
            }
            // the "next job" signal for ParallelGetJob is data of size zero which
            // readBody() sends without our intervention.
            qCDebug(KIO_HTTP) << "check three: isKeepAlive =" << m_request.isKeepAlive;
            httpClose(m_request.isKeepAlive);  //actually keep-alive is mandatory for pipelining
        }
```

#### LAMBDA EXPRESSION 


```{c}
[destFile, suspend, destToCheck](KJob *job, qulonglong processedSize) {
        if (processedSize > 0) {
            QVERIFY2(QFile::exists(destToCheck), qPrintable(destToCheck));
            qDebug() << "processedSize=" << processedSize << "file size" << QFileInfo(destToCheck).size();
            if (suspend) {
                job->suspend();
            }
            QVERIFY(job->kill());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &fileName : entryNames) {
            if (fileName == QLatin1Char('.') || fileName == QLatin1String("..")) {
                continue;
            }
            if (!fileName.endsWith(tail)) {
                qCWarning(KIO_TRASH) << "Invalid info file found in" << infoPath << ":" << fileName;
                continue;
            }

            TrashedFileInfo info;
            if (infoForFile(trashId, fileName.chopped(tailLength), info)) {
                lst << info;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        _k_slotSymLink();
    }
```

#### AUTO 


```{c}
auto *abstractPlugin = factory->create<KAbstractFileItemActionPlugin>();
```

#### AUTO 


```{c}
auto *mimeFilterReq = new KUrlRequester();
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
                scanFileWithGet();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const AuthInfoContainer *current : *authList) {
            qCDebug(category) << "Evaluating: " << current->info.url.scheme()
                              << current->info.url.host() << current->info.username;
            if (current->info.url.scheme() == protocol
                && current->info.url.host() == host
                && (current->info.username == user || user.isEmpty())) {
                qCDebug(category) << "Removing this entry";
                removeAuthInfoItem(dictIterator.key(), current->info);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QMenu *menu : d->m_menus) {
        for (QAction *action : d->m_appActions) {
            menu->removeAction(action);
        }
        for (QAction *action : d->m_pluginActions) {
            menu->removeAction(action);
        }
    }
```

#### AUTO 


```{c}
auto err = execWithElevatedPrivilege(OPEN, {path, flags, mode, sockPath}, errcode)
```

#### RANGE FOR STATEMENT 


```{c}
for (const UDSEntry &entry : list) {
        stream << entry;
    }
```

#### AUTO 


```{c}
auto *job = new OpenFileManagerWindowJob();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &dirPath : servicesDirs) {
        QDir dir(dirPath);
        const auto files = dir.entryList({QStringLiteral("*.desktop")}, QDir::Files);
        for (const QString &file : files) {
            if (!m_searchProvidersByDesktopName.contains(file)) {
                const QString filePath = dir.path() + QLatin1Char('/') + file;
                auto *provider = new SearchProvider(filePath);
                m_searchProvidersByDesktopName.insert(file, provider);
                m_searchProviders.append(provider);
                const auto keys = provider->keys();
                for (const QString &key : keys) {
                    m_searchProvidersByKey.insert(key, provider);
                }
            }
        }
    }
```

#### AUTO 


```{c}
auto *processRunner =
        KProcessRunner::fromApplication(d->m_service, d->m_serviceEntryPath, d->m_urls, d->m_runFlags, d->m_suggestedFileName, d->m_startupId);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QModelIndex &index) {
        d->placeEntered(index);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
            m_process->start();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { _k_slotRealFileOrDir(); }
```

#### AUTO 


```{c}
const auto formats = event->mimeData()->formats();
```

#### RANGE FOR STATEMENT 


```{c}
for (CacheFileInfo *fi : fiList) {
            realFiles.insert(CacheIndex(fi->baseName));
        }
```

#### AUTO 


```{c}
auto it = std::find(availableDevices.begin(), availableDevices.end(), udi);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &jsonMetadata : jsonPlugins) {
        // The plugin has been disabled
        const QString pluginId = jsonMetadata.pluginId();
        if (!showGroup.readEntry(pluginId, true) || excludeList.contains(pluginId)) {
            continue;
        }

        // The plugin also has a .desktop file and has already been added.
        if (addedPlugins.contains(jsonMetadata.pluginId())) {
            continue;
        }

        KPluginFactory *factory = KPluginLoader(jsonMetadata.fileName()).factory();
        if (!factory) {
            continue;
        }
        KAbstractFileItemActionPlugin *abstractPlugin = m_loadedPlugins.value(pluginId);
        if (!abstractPlugin) {
            abstractPlugin = factory->create<KAbstractFileItemActionPlugin>(this);
            connect(abstractPlugin, &KAbstractFileItemActionPlugin::error, q, &KFileItemActions::error);
            m_loadedPlugins.insert(pluginId, abstractPlugin);
        }
        if (abstractPlugin) {
            connect(abstractPlugin, &KAbstractFileItemActionPlugin::error, q, &KFileItemActions::error);
            const QList<QAction *> actions = abstractPlugin->actions(m_props, m_parentWidget);
            itemCount += actions.count();
            const QString showInSubmenu = jsonMetadata.value(QStringLiteral("X-KDE-Show-In-Submenu"));
            if (showInSubmenu == QLatin1String("true")) {
                actionsMenu->addActions(actions);
            } else {
                mainMenu->addActions(actions);
            }
            addedPlugins.append(jsonMetadata.pluginId());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &idx : qAsConst(emitExpandFor)) {
        emit q->expand(idx);
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr bool s_workaroundBrokenInotify = false;
```

#### AUTO 


```{c}
auto isBasicOperation = [this](const BasicOperation &op) {
        return (op.m_type == BasicOperation::Directory && !op.m_renamed) || (op.m_type == BasicOperation::Link && !m_current.isMoveCommand());
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (KCoreDirLister *kdl : listers) {
                kdl->d->addNewItem(url, item);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const KIO::UDSEntry &entry) { slotStatEntry(entry); }
```

#### AUTO 


```{c}
auto *askUser = new MockAskUserInterface(job->uiDelegate());
```

#### RANGE FOR STATEMENT 


```{c}
for (auto item : std::as_const(items)) {
        QVERIFY(!item.isMimeTypeKnown());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : std::as_const(deletedSubdirs)) {
        // in case of a dir, check if we have any known children, there's much to do in that case
        // (stopping jobs, removing dirs from cache etc.)
        deleteDir(url);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &cookie : cookies) {
        const int index = cookie.indexOf(QL1C('='));
        const QStringRef name = cookie.leftRef(index);
        const QStringRef value = cookie.rightRef((cookie.length() - index - 1));
        cookieList << QNetworkCookie(name.toUtf8(), value.toUtf8());
        //qDebug() << "cookie: name=" << name << ", value=" << value;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QString &match : *matches) {
        if (!match.isNull()) {
            if (match.endsWith(QLatin1Char('/'))) {
                d->quoteText(&match, false, true);    // don't quote trailing '/'
            } else {
                d->quoteText(&match, false, false);    // quote the whole text
            }

            match.prepend(d->m_text_start);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : qAsConst(m_srcList)) {
            const QString extension = db.suffixForFileName(url.toDisplayString().toLower());
            if (extensions.contains(extension)) {
                m_allExtensionsDifferent = false;
                break;
            }

            extensions.insert(extension);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, untrustedProgramHandler](bool result) {
            if (result) {
                // Assume that service is an absolute path since we're being called (relative paths
                // would have been allowed unless Kiosk said no, therefore we already know where the
                // .desktop file is.  Now add a header to it if it doesn't already have one
                // and add the +x bit.

                QString errorString;
                if (untrustedProgramHandler->makeServiceFileExecutable(d->m_service->entryPath(), errorString)) {
                    proceedAfterSecurityChecks();
                } else {
                    QString serviceName = d->m_service->name();
                    if (serviceName.isEmpty()) {
                        serviceName = d->m_service->genericName();
                    }
                    setError(KJob::UserDefinedError);
                    setErrorText(i18n("Unable to make the service %1 executable, aborting execution.\n%2.",
                                      serviceName, errorString));
                    emitResult();
                }
            } else {
                setError(KIO::ERR_USER_CANCELED);
                emitResult();
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& serviceId : serviceIdList) {
        KFileItemList serviceItems;
        for (const KFileItem &item : fileItems) {
            const KService::Ptr serv = preferredService(item.mimetype(), m_traderConstraint);
            const QString preferredServiceId = serv ? serv->storageId() : QString();
            if (preferredServiceId == serviceId) {
                serviceItems << item;
            }
        }

        if (serviceId.isEmpty()) { // empty means: no associated app for this mimetype
            openWithByMime(serviceItems);
            continue;
        }

        const KService::Ptr servicePtr = KService::serviceByStorageId(serviceId); // can be nullptr
        KIO::ApplicationLauncherJob *job = new KIO::ApplicationLauncherJob(servicePtr);
        job->setUrls(serviceItems.urlList());
        job->setUiDelegate(new KIO::JobUiDelegate(KJobUiDelegate::AutoHandlingEnabled, m_parentWidget));
        job->start();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &text) {
        d->_k_slotURLTextChanged(text);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->slotSortBySize();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &entry : final_entries) {
        q->prepareUDSEntry(entry, true);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, job](const KFileItem &item, const QPixmap &pixmap) {
        addToPreviewQueue(item, pixmap, job);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[favJob, &goticonFile](KJob *) {
            if (!favJob->error()) {
                goticonFile = favJob->iconFile();
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : urls) {
            const int index = clipboardUrls.indexOf(url);
            if (index > -1) {
                QUrl dUrl = copyJob->destUrl().adjusted(QUrl::StripTrailingSlash);
                dUrl.setPath(concatPaths(dUrl.path(), url.fileName()));
                clipboardUrls.replace(index, dUrl);
                update = true;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& item : d->itemList) {
        d->insertUrlItem(item.get());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : urls) {
        if (url.scheme() == QLatin1String("trash")) {
            QString path = url.path();
            // HACK (#98983): remove "0-foo". Note that it works better than
            // displaying KFileItem::name(), for files under a subdir.
            path.remove(QRegularExpression(QStringLiteral("^/[0-9]+-")));
            prettyList.append(path);
        } else {
            prettyList.append(url.toDisplayString(QUrl::PreferLocalFile));
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QUrl &url) { d->enterUrl(url); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &path : qAsConst(search)) {
        //qDebug() << "Looking for help in: " << path;

        QFileInfo info(path);
        if (info.exists() && info.isFile() && info.isReadable()) {
            return path;
        }

        if (path.endsWith(QLatin1String(".html"))) {
            const QString file = path.leftRef(path.lastIndexOf(QLatin1Char('/'))) + QLatin1String("/index.docbook");
            //qDebug() << "Looking for help in: " << file;
            info.setFile(file);
            if (info.exists() && info.isFile() && info.isReadable()) {
                return path;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &item : std::as_const(m_resolvedMimeTypes)) {
            const QModelIndex idx = dirModel->indexForItem(item);
            dirModel->itemChanged(idx);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](uint jobId, const QDBusObjectPath &jobPath, const QString &unitName, const QString &result) {
            Q_UNUSED(jobId)
            if (jobPath.path() == m_jobPath && unitName == m_serviceName && result != QStringLiteral("done")) {
                qCWarning(KIO_GUI) << "Failed to launch process as service:" << m_serviceName << ", result " << result;
                // result=failed is not a fatal error, service is actually created in this case
                if (result != QStringLiteral("failed")) {
                    systemdError(result);
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KServicePtr &entry : entries) {
        QString file = QStandardPaths::locate(QStandardPaths::GenericDataLocation, QLatin1String("kservices5/") + entry->entryPath());
        const KDesktopFile desktopFile(file);
        const KConfigGroup cfg = desktopFile.desktopGroup();

        if (!d->shouldDisplayServiceMenu(cfg, protocol)) {
            continue;
        }

        if (cfg.hasKey("Actions") || cfg.hasKey("X-KDE-GetActionMenu")) {
            if (!d->checkTypesMatch(cfg)) {
                continue;
            }

            const QString priority = cfg.readEntry("X-KDE-Priority");
            const QString submenuName = cfg.readEntry("X-KDE-Submenu");

            ServiceList &list = s.selectList(priority, submenuName);
            const ServiceList userServices = KDesktopFileActions::userDefinedServices(*entry, isLocal, urlList);
            for (const KServiceAction &action : userServices) {
                if (showGroup.readEntry(action.name(), true)) {
                    list += action;
                }
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[serviceName](QDBusPendingCallWatcher *watcher) {
                QDBusPendingReply<QDBusObjectPath> reply = *watcher;
                watcher->deleteLater();
                if (reply.isError()) {
                    qCWarning(KIO_GUI) << "Failed to register new cgroup:" << serviceName << reply.error().name()
                                       << reply.error().message();
                } else {
                    qCDebug(KIO_GUI) << "Successfully registered new cgroup:" << serviceName;
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[udsField](const Field &entry) {
                              return entry.m_index == udsField;
                          }
```

#### AUTO 


```{c}
auto label = new QLabel(i18nc("@action:button", "Calculating..."), &d->m_widget);
```

#### AUTO 


```{c}
const auto files = dir.entryList({QStringLiteral("*.desktop")}, QDir::Files);
```

#### AUTO 


```{c}
auto job = KIO::copy({QUrl::fromLocalFile(QFINDTESTDATA("ftp/testCopy1"))}, url, KIO::DefaultFlags);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QUrl &, const QUrl &newUrl) { slotOpenUrlOnRename(newUrl); }
```

#### AUTO 


```{c}
auto it = std::lower_bound(lstItems.begin(), lstItems.end(), u);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { _k_slotOtherDesktopFile(); }
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString &mimeType) {
        foundMime = mimeType;
        job->kill();
    }
```

#### IF STATEMENT WITH INITIALIZER 


```{c}
if (const QDateTime dt = firstItem.time(KFileItem::ModificationTime); !dt.isNull()) {
            d->m_ui->modifiedTimeLabel->setText(locale.toString(dt, QLocale::LongFormat));
        } else {
            d->m_ui->modifiedTimeLabel->hide();
            d->m_ui->modifiedTimeLabel_Left->hide();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (KCoreDirLister *kdl : listers) {
            kdl->d->jobDone(job);
            if (job->error() != KJob::KilledJobError) {
                Q_EMIT kdl->jobError(job);
                if (kdl->d->m_autoErrorHandling && !errorShown) {
                    errorShown = true; // do it only once
                    job->uiDelegate()->showErrorMessage();
                }
#if KIOCORE_BUILD_DEPRECATED_SINCE(5, 82)
                kdl->handleError(job);
#endif
            }
            const bool silent = job->property("_kdlc_silent").toBool();
            if (!silent) {
#if KIOCORE_BUILD_DEPRECATED_SINCE(5, 79)
                Q_EMIT kdl->canceled(jobUrl);
#endif
                Q_EMIT kdl->listingDirCanceled(jobUrl);
            }

            if (kdl->d->numJobs() == 0) {
                kdl->d->complete = true;
                if (!silent) {
                    Q_EMIT kdl->canceled();
                }
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QModelIndex &index) {
        d->actionEntered(index);
    }
```

#### AUTO 


```{c}
auto end = begin + d->m_historyIndex;
```

#### LAMBDA EXPRESSION 


```{c}
do {
        return makeFolderExist("idk"_rc);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](qreal value) {
        d->_k_itemDisappearUpdate(value);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& serviceId : serviceIdList) {
        KFileItemList serviceItems;
        for (const KFileItem &item : fileItems) {
            const KService::Ptr serv = preferredService(item.mimetype(), m_traderConstraint);
            const QString preferredServiceId = serv ? serv->storageId() : QString();
            if (preferredServiceId == serviceId) {
                serviceItems << item;
            }
        }

        if (serviceId.isEmpty()) { // empty means: no associated app for this MIME type
            openWithByMime(serviceItems);
            continue;
        }

        const KService::Ptr servicePtr = KService::serviceByStorageId(serviceId); // can be nullptr
        auto *job = new KIO::ApplicationLauncherJob(servicePtr);
        job->setUrls(serviceItems.urlList());
        job->setUiDelegate(new KIO::JobUiDelegate(KJobUiDelegate::AutoHandlingEnabled, m_parentWidget));
        job->start();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &item : items) {
            if (item == firstItem) { // No need to check the first one again
                continue;
            }

            const bool isItemDir = item.isDir();
            const bool isItemLink = item.isLink();

            if (!d->isIrregular) {
                d->isIrregular |= isIrregular(item.permissions(), isItemDir == isDir, isItemLink == isLink);
            }

            d->hasExtendedACL = d->hasExtendedACL || item.hasExtendedACL();

            if (isItemLink != isLink) {
                isLink = false;
            }

            if (isItemDir != isDir) {
                isDir = false;
            }
            hasDir |= isItemDir;

            if (item.permissions() != d->permissions) {
                d->permissions &= item.permissions();
                d->partialPermissions |= item.permissions();
            }

            if (item.user() != d->strOwner) {
                d->strOwner.clear();
            }

            if (item.group() != d->strGroup) {
                d->strGroup.clear();
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (KCoreDirLister *listit : listers) {
            if (!listit->d->m_cachedItemsJobs.isEmpty()) {
                qCDebug(KIO_CORE_DIRLISTER) << "  Lister" << listit << "has CachedItemsJobs" << listit->d->m_cachedItemsJobs;
            } else if (KIO::ListJob *listJob = jobForUrl(dit.key())) {
                qCDebug(KIO_CORE_DIRLISTER) << "  Lister" << listit << "has ListJob" << listJob;
            } else {
                listersWithoutJob.append(listit);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &c : bytes) {
        if ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c == ':' || c == '_' || c == '.') {
            res += QLatin1Char(c);
        } else {
            res += QStringLiteral("\\x%1").arg(c, 2, 16, QLatin1Char('0'));
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        const int errCode = job->error();
        if (errCode) {
            // ERR_NO_CONTENT is not an error, but an indication no further
            // actions needs to be taken.
            if (errCode != KIO::ERR_NO_CONTENT) {
                q->setError(errCode);
                q->setErrorText(KIO::buildErrorString(errCode, job->errorText()));
            }
            q->emitResult();
            return;
        }
        if (m_followRedirections) { // Update our URL in case of a redirection
            m_url = job->url();
        }

        const KIO::UDSEntry entry = job->statResult();

        const QString localPath = entry.stringValue(KIO::UDSEntry::UDS_LOCAL_PATH);
        if (!localPath.isEmpty()) {
            m_url = QUrl::fromLocalFile(localPath);
        }

        // MIME type already known? (e.g. print:/manager)
        m_mimeTypeName = entry.stringValue(KIO::UDSEntry::UDS_MIME_TYPE);
        if (!m_mimeTypeName.isEmpty()) {
            runUrlWithMimeType();
            return;
        }

        if (entry.isDir()) {
            m_mimeTypeName = QStringLiteral("inode/directory");
            runUrlWithMimeType();
        } else { // it's a file
            // Start the timer. Once we get the timer event this
            // protocol server is back in the pool and we can reuse it.
            // This gives better performance than starting a new slave
            QTimer::singleShot(0, q, [this] { scanFileWithGet(); });
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            // KSslInfoDialog only has one button, QDialogButtonBox::Close
            Q_EMIT q->messageBoxResult(KIO::SlaveBase::Cancel);
        }
```

#### LAMBDA EXPRESSION 


```{c}
do {
        return doRename("more-files"_rc, "filesier"_rc);
    }
```

#### AUTO 


```{c}
auto *processRunner = new KProcessRunner(p, executable, id);
```

#### LAMBDA EXPRESSION 


```{c}
[](const KPluginMetaData &a, const KPluginMetaData &b) {
            return a.rawData().value("X-KDE-InitialPreference").toInt() > b.rawData().value("X-KDE-InitialPreference").toInt();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &fileName : entryNames) {
        if (fileName == QLatin1String("..")) {
            continue;
        }
        const QString filePath = info.physicalPath + QLatin1Char('/') + fileName;
        // shouldn't be necessary
        // const QString url = TrashImpl::makeURL( trashId, fileId, relativePath + '/' + fileName );
        entry.clear();
        TrashedFileInfo infoForItem(info);
        infoForItem.origPath += QLatin1Char('/') + fileName;
        if (createUDSEntry(filePath, fileName, fileName, entry, infoForItem)) {
            listEntry(entry);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QUrl &, const KFileItemList &items) {
                if (tags.isEmpty()) {
                    QList<QUrl> existingBookmarks;

                    KBookmarkGroup root = bookmarkManager->root();
                    KBookmark bookmark = root.first();

                    while (!bookmark.isNull()) {
                        existingBookmarks.append(bookmark.url());
                        bookmark = root.next(bookmark);
                    }

                    if (!existingBookmarks.contains(QUrl(tagsUrlBase))) {
                        KBookmark alltags = KFilePlacesItem::createSystemBookmark(bookmarkManager,
                                                                                  kli18nc("KFile System Bookmarks", "All tags").untranslatedText(),
                                                                                  QUrl(tagsUrlBase),
                                                                                  QStringLiteral("tag"));
                    }
                }

                for (const KFileItem &item : items) {
                    const QString name = item.name();

                    if (!tags.contains(name)) {
                        tags.append(name);
                    }
                }
                reloadBookmarks();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &subGroupName : subGroupNames) {
        listEntry(dirEntry(subGroupName));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job, qulonglong _size){ _k_slotTotalSize(job, _size); }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QList<QVariant> &spy){
            return spy.at(1).toUrl().path().contains("innerfile");
        }
```

#### AUTO 


```{c}
auto seekFillBuffer = [bufferSize](qint64 pos, QFile &f, QByteArray &buffer) {
        auto ioresult = f.seek(pos);
        if (ioresult) {
            const int bytesRead = f.read(buffer.data(), bufferSize);
            ioresult = bytesRead != -1;
        }
        if (!ioresult) {
            qCWarning(KIO_WIDGETS) << "Could not read file for comparison:" << f.fileName();
            return false;
        }
        return true;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[&jobFinished, &putDataBuffer] {
        putDataBuffer.readyRead();
        jobFinished = true;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &protocol : protocols) {
        QAction *action = m_menu->addAction(protocol);
        action->setData(protocol);
    }
```

#### AUTO 


```{c}
auto plugin = KPluginFactory::instantiatePlugin<KIO::DndPopupMenuPlugin>(data).plugin
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &jsonMetadata : jsonPlugins) {
        // The plugin has been disabled
        const QString pluginId = jsonMetadata.pluginId();
        if (!showGroup.readEntry(pluginId, true) || excludeList.contains(pluginId)) {
            continue;
        }

        KAbstractFileItemActionPlugin *abstractPlugin = m_loadedPlugins.value(pluginId);
        if (!abstractPlugin) {
            abstractPlugin = KPluginFactory::instantiatePlugin<KAbstractFileItemActionPlugin>(jsonMetadata, this).plugin;
            m_loadedPlugins.insert(pluginId, abstractPlugin);
        }
        if (abstractPlugin) {
            connect(abstractPlugin, &KAbstractFileItemActionPlugin::error, q, &KFileItemActions::error);
            const QList<QAction *> actions = abstractPlugin->actions(m_props, m_parentWidget);
            itemCount += actions.count();
            const QString showInSubmenu = jsonMetadata.value(QStringLiteral("X-KDE-Show-In-Submenu"));
            if (showInSubmenu == QLatin1String("true")) {
                actionsMenu->addActions(actions);
            } else {
                mainMenu->addActions(actions);
            }
            addedPlugins.append(jsonMetadata.pluginId());
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QModelIndex &parentIndex, const QString &name) {
        for (int row = 0; row < m_dirModel->rowCount(parentIndex); ++row) {
            QModelIndex idx = m_dirModel->index(row, 0, parentIndex);
            if (m_dirModel->itemForIndex(idx).isDir() && m_dirModel->itemForIndex(idx).name() == name) {
                return idx;
            }
        }
        return QModelIndex();
    }
```

#### AUTO 


```{c}
const auto url = QUrl::fromLocalFile(m_testFile);
```

#### AUTO 


```{c}
auto &opQueue = m_current.m_opQueue;
```

#### AUTO 


```{c}
const auto it = d->extraFields.constFind(fieldName);
```

#### AUTO 


```{c}
auto findSystemBookmark = [this](const QString &untranslatedText) {
                KBookmarkGroup root = d->bookmarkManager->root();
                KBookmark bItem = root.first();
                while (!bItem.isNull()) {
                    const bool isSystemItem = bItem.metaDataItem(QStringLiteral("isSystemItem")) == QLatin1String("true");
                    if (isSystemItem && bItem.fullText() == untranslatedText) {
                        return bItem;
                    }
                    bItem = root.next(bItem);
                }
                return KBookmark();
            };
```

#### AUTO 


```{c}
auto it = std::find_if(storage.begin(), storage.end(), [udsField](const Field &entry) {
            return entry.m_index == udsField;
        });
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : qAsConst(m_dirsToUpdate)) {
            //qDebug() << "Notifying FilesAdded for " << url;
            org::kde::KDirNotify::emitFilesAdded(url);
        }
```

#### IF STATEMENT WITH INITIALIZER 


```{c}
if (const QString currIcon = d->m_ui->iconButton->icon(); str != currIcon) {
            sIcon = currIcon;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, errorMsg]() {
        Q_EMIT error(errorMsg);
        deleteLater();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &h : std::as_const(responseHeaders)) {
            out << h << '\n';
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QUrl &, const QUrl &newUrl) {
        d->slotRedirected(newUrl);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const ItemInUseChange& i : qAsConst(itemsToChange)) {
        emitRedirections(QUrl(i.oldUrl), QUrl(i.newUrl));
    }
```

#### AUTO 


```{c}
const auto networkError = d->sock.error();
```

#### AUTO 


```{c}
const auto useThreads = []() {
        return qgetenv("KIO_ENABLE_WORKER_THREADS") != "0";
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &text) { d->_k_slotURLTextChanged(text); }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        _k_slotOpenDialog();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { delayedIconUpdate(); }
```

#### LAMBDA EXPRESSION 


```{c}
[=](KIO::Job *, const QString &mimetype) {
        if (m_followRedirections) { // Update our URL in case of a redirection
            m_url = job->url();
        }
        if (mimetype.isEmpty()) {
            qCWarning(KIO_CORE) << "get() didn't emit a MIME type! Probably a kioslave bug, please check the implementation of" << m_url.scheme();
        }
        m_mimeTypeName = mimetype;

        // If the current MIME type is the default MIME type, then attempt to
        // determine the "real" MIME type from the file name (bug #279675)
        const QMimeType mime = fixupMimeType(m_mimeTypeName, m_suggestedFileName.isEmpty() ? m_url.fileName() : m_suggestedFileName);
        if (mime.isValid()) {
            m_mimeTypeName = mime.name();
        }

        if (m_suggestedFileName.isEmpty()) {
            m_suggestedFileName = job->queryMetaData(QStringLiteral("content-disposition-filename"));
        }

        job->putOnHold();
        KIO::Scheduler::publishSlaveOnHold();
        q->emitResult();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        _k_slotCreateDirectory();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->slotDetailedView(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) {
            m_error = job->error();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &cachedDir : cachedDirs) {
        DirItem *dirItem = itemsCached.object(cachedDir);
        qCDebug(KIO_CORE_DIRLISTER) << "   " << cachedDir << "rootItem:"
                 << (!dirItem->rootItem.isNull() ? dirItem->rootItem.url().toString() : QStringLiteral("NULL"))
                 << "with" << dirItem->lstItems.count() << "items.";
    }
```

#### AUTO 


```{c}
auto *dialog = new KMessageDialog(dlgType, text, parent);
```

#### LAMBDA EXPRESSION 


```{c}
[serviceName](QDBusPendingCallWatcher *watcher) {
        QDBusPendingReply<QDBusObjectPath> reply = *watcher;
        watcher->deleteLater();
        if (reply.isError()) {
            qCWarning(KIO_GUI) << "Failed to register new cgroup:" << serviceName << reply.error().name() << reply.error().message();
        } else {
            qCDebug(KIO_GUI) << "Successfully registered new cgroup:" << serviceName;
        }
    }
```

#### AUTO 


```{c}
auto teardown = std::unique_ptr<QAction>{placesModel->teardownActionForIndex(index)}
```

#### AUTO 


```{c}
auto addList = [&](const char *token, const QStringList &list) {
        if (!list.isEmpty()) {
            arg += QLatin1String(token) + quote + list.join(QLatin1Char(',')) + quote;
        }
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : urls) {
        KIO::StatJob *job = KIO::stat(url);
        KJobWidgets::setWindow(job, parent);
        job->exec();
        KIO::UDSEntry entry = job->statResult();

        d->m_items.append(KFileItem(entry, url));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &domain : qAsConst(m_domainList)) {
        eatSessionCookies(domain, windowId, false);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QChar c : qAsConst(password)) {
      unsigned int num = (c.unicode() ^ 173) + 17;
      unsigned int a1 = (num & 0xFC00) >> 10;
      unsigned int a2 = (num & 0x3E0) >> 5;
      unsigned int a3 = (num & 0x1F);
      scrambled += (char)(a1+'0');
      scrambled += (char)(a2+'A');
      scrambled += (char)(a3+'0');
   }
```

#### AUTO 


```{c}
auto applyUrl = [this](QUrl url) {
        // Parts of the following code have been taken from the class KateFileSelector
        // located in kate/app/katefileselector.hpp of Kate.
        // SPDX-FileCopyrightText: 2001 Christoph Cullmann <cullmann@kde.org>
        // SPDX-FileCopyrightText: 2001 Joseph Wenninger <jowenn@kde.org>
        // SPDX-FileCopyrightText: 2001 Anders Lund <anders.lund@lund.tdcadsl.dk>

        // For example "desktop:/" _not_ "desktop:", see the comment in slotProtocolChanged()
        if (!url.isEmpty() && url.path().isEmpty() && KProtocolInfo::protocolClass(url.scheme()) == QLatin1String(":local")) {
            url.setPath(QStringLiteral("/"));
        }

        const auto urlStr = url.toString();
        QStringList urls = m_pathBox->urls();
        urls.removeAll(urlStr);
        urls.prepend(urlStr);
        m_pathBox->setUrls(urls, KUrlComboBox::RemoveBottom);

        q->setLocationUrl(url);
        // The URL might have been adjusted by KUrlNavigator::setUrl(), hence
        // synchronize the result in the path box.
        m_pathBox->setUrl(q->locationUrl());
    };
```

#### AUTO 


```{c}
const auto matches = m_completionEmptyCwd->allMatches();
```

#### AUTO 


```{c}
const auto setDefaultMetadataItemForGroup = [&root](KFilePlacesModel::GroupType type) {
        root.setMetaDataItem(stateNameForGroupType(type), QStringLiteral("false"));
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const QueuedRequest &request : qAsConst(m_requestQueue)) {
            if (request.sendAll) {
                const QVariant result(handleRequest(request.url));
                QDBusConnection::sessionBus().send(request.transaction.createReply(result));
            } else {
                const QVariant result(handleRequest(request.url).constFirst());
                QDBusConnection::sessionBus().send(request.transaction.createReply(result));
            }
        }
```

#### CONST EXPRESSION 


```{c}
static constexpr bool s_enableCanResume = true;
```

#### LAMBDA EXPRESSION 


```{c}
do {
        return move({"5"_hc, "6"_hc, "7"_hc, "8"_hc}, ""_rc);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](int step) {
        slotIconSizeSliderMoved(m_stdIconSizes[step]);
    }
```

#### AUTO 


```{c}
auto activationWatcher = new QDBusPendingCallWatcher(call, this);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { updateCutItems(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &format : allFormats) {
        if (format == QLatin1String("application/x-qiconlist")) { // Q3IconView and kde4's libkonq
            continue;
        }
        if (format == QLatin1String("application/x-kde-cutselection")) { // see isClipboardDataCut
            continue;
        }
        if (format == QLatin1String("application/x-kde-suggestedfilename")) {
            continue;
        }
        if (format.startsWith(QLatin1String("application/x-qt-"))) { // Qt-internal
            continue;
        }
        if (format.startsWith(QLatin1String("x-kmail-drag/"))) { // app-internal
            continue;
        }
        if (!format.contains(QLatin1Char('/'))) { // e.g. TARGETS, MULTIPLE, TIMESTAMP
            continue;
        }
        formats.append(format);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](KIO::SkipDialog_Result result, KJob *parentJob) {
                        Q_ASSERT(q == parentJob);
                        q->disconnect(askUserActionInterface, skipSignal, q, nullptr);

                        switch (result) {
                        case Result_AutoSkip:
                            m_bAutoSkipFiles = true;
                            // fall through
                            Q_FALLTHROUGH();
                        case Result_Skip:
                            QMetaObject::invokeMethod(q, "_k_chmodNextFile", Qt::QueuedConnection);
                            return;
                        case Result_Retry:
                            m_infos.push(std::move(info));
                            QMetaObject::invokeMethod(q, "_k_chmodNextFile", Qt::QueuedConnection);
                            return;
                        case Result_Cancel:
                        default:
                            q->setError(ERR_USER_CANCELED);
                            q->emitResult();
                            return;
                        }
                    }
```

#### AUTO 


```{c}
const auto cacheIt = m_cutItemsCache.constFind(item.url());
```

#### AUTO 


```{c}
auto &request
```

#### LAMBDA EXPRESSION 


```{c}
[destFile, suspend, overwrite](KJob *job, qulonglong processedSize) {
        if (processedSize > 0) {
            const QString destToCheck = (!overwrite) ? destFile : destFile + QStringLiteral(".part");
            QVERIFY2(QFile::exists(destToCheck), qPrintable(destToCheck));
            if (suspend) {
                job->suspend();
            }
            job->kill();
            QVERIFY(!QFile::exists(destToCheck));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &s2 : sl2) {
            bool didConvert;
            KSslError::Error error = KSslErrorPrivate::errorFromQSslError(static_cast<QSslError::SslError>(s2.toInt(&didConvert)));
            if (didConvert) {
                certErrors.append(error);
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { dispatchIconUpdateQueue(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->slotLoadingFinished(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) {
        Q_EMIT d->q->error(job->error(), job->errorString());
    }
```

#### AUTO 


```{c}
const auto &service
```

#### LAMBDA EXPRESSION 


```{c}
[currValue](KIconLoader::StdSizes size) {
        return size > currValue;
    }
```

#### AUTO 


```{c}
auto job1 = KIO::copy({QUrl::fromLocalFile(testCopy1)}, url, KIO::DefaultFlags);
```

#### AUTO 


```{c}
auto dit = directoryData.constBegin();
```

#### AUTO 


```{c}
const auto systemdPath = QStringLiteral("/org/freedesktop/systemd1");
```

#### AUTO 


```{c}
auto actions = abstractPlugin->actions(d->m_props, d->m_parentWidget);
```

#### LAMBDA EXPRESSION 


```{c}
[this, filePath, service](bool shouldExecute) {
                    if (shouldExecute) { // Run the file
                        startService(service, {});
                        return;
                    }
                    // The user selected "open"
                    openInPreferredApp();
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &key : keys) {
        if (key.length() > name.length()) {
            // We should avoid hidden files and directory paths, BUG: 407944
            name = key.toLower().remove(QLatin1Char('.')).remove(QLatin1Char('/'));
            ;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &path : templates) {
        dir.setPath(path);
        const QStringList &entryList(dir.entryList(QStringList{QStringLiteral("*.desktop")}, QDir::Files));
        files.reserve(files.size() + entryList.size());
        for (const QString &entry : entryList) {
            const QString file = concatPaths(dir.path(), entry);
            files.append(file);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
                            act->setShortcuts(act2->shortcuts());
                        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KIO::UDSEntry &entry : lst) {
        QString name = entry.stringValue(KIO::UDSEntry::UDS_NAME);
        QString displayName = entry.stringValue(KIO::UDSEntry::UDS_DISPLAY_NAME);
        QUrl url(entry.stringValue(KIO::UDSEntry::UDS_URL));
        qDebug() << "name" << name << "displayName" << displayName << " UDS_URL=" << url;
        if (!url.isEmpty()) {
            QVERIFY(url.scheme() == QStringLiteral("trash"));
        }
        m_listResult << name;
        m_displayNameListResult << displayName;
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr char s_ftpPasswd[] = "anonymous@";
```

#### RANGE FOR STATEMENT 


```{c}
for (const QHostAddress &address : info.addresses()) {
            if (isIPv4Address(address) || isIPv6Address(address)) {
                hasResolvableIPAddress = true;
                break;
            }
        }
```

#### AUTO 


```{c}
auto addActionToMenu = [&menu](QAction *action) {
        if (action) { // silence warning when adding null action
            menu.addAction(action);
        }
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
                    m_process->start();
                }
```

#### AUTO 


```{c}
auto view = QStringView{fullExec}.trimmed();
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QUrl &url) { d->slotRedirected(url); }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                done(KIO::Result_ReplaceAllInvalidChars);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        _k_slotRealFileOrDir();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KJob *job : subjobs()) {
        job->kill(KJob::Quietly);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KFileItemDelegate::Information info : informationList) {
        if (info == KFileItemDelegate::NoInformation) {
            continue;
        }

        if (!string.isEmpty()) {
            string += QChar::LineSeparator;
        }

        switch (info) {
        case KFileItemDelegate::Size:
            string += itemSize(index, item);
            break;

        case KFileItemDelegate::Permissions:
            string += item.permissionsString();
            break;

        case KFileItemDelegate::OctalPermissions:
            string += QLatin1Char('0') + QString::number(item.permissions(), 8);
            break;

        case KFileItemDelegate::Owner:
            string += item.user();
            break;

        case KFileItemDelegate::OwnerAndGroup:
            string += item.user() + QLatin1Char(':') + item.group();
            break;

        case KFileItemDelegate::CreationTime:
            string += item.timeString(KFileItem::CreationTime);
            break;

        case KFileItemDelegate::ModificationTime:
            string += item.timeString(KFileItem::ModificationTime);
            break;

        case KFileItemDelegate::AccessTime:
            string += item.timeString(KFileItem::AccessTime);
            break;

        case KFileItemDelegate::MimeType:
            string += item.isMimeTypeKnown() ? item.mimetype() : i18nc("@info mimetype", "Unknown");
            break;

        case KFileItemDelegate::FriendlyMimeType:
            string += item.isMimeTypeKnown() ? item.mimeComment() : i18nc("@info mimetype", "Unknown");
            break;

        case KFileItemDelegate::LinkDest:
            string += item.linkDest();
            break;

        case KFileItemDelegate::LocalPathOrUrl:
            if (!item.localPath().isEmpty()) {
                string += item.localPath();
            } else {
                string += item.url().toDisplayString();
            }
            break;

        case KFileItemDelegate::Comment:
            string += item.comment();
            break;

        default:
            break;
        } // switch (info)
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { changeSitePolicy(ui.sitePolicyTreeWidget->currentItem()); }
```

#### LAMBDA EXPRESSION 


```{c}
[=](RenameDialog_Result result, const QUrl &newUrl, KJob *parentJob) {
        Q_ASSERT(parentJob == q);
        // Only receive askUserRenameResult once per rename dialog
        QObject::disconnect(askUserActionInterface, &KIO::AskUserActionInterface::askUserRenameResult,
                            q, nullptr);

        if (m_reportTimer) {
            m_reportTimer->start(REPORT_TIMEOUT);
        }

        const QString existingDest = (*it).uDest.path();

        switch (result) {
        case Result_Cancel:
            q->setError(ERR_USER_CANCELED);
            q->emitResult();
            return;
        case Result_AutoRename:
            m_bAutoRenameDirs = true;
        // fall through
            Q_FALLTHROUGH();
        case Result_Rename:
            renameDirectory(it, newUrl);
            break;
        case Result_AutoSkip:
            m_bAutoSkipDirs = true;
        // fall through
            Q_FALLTHROUGH();
        case Result_Skip:
            m_skipList.append(existingDest);
            skip((*it).uSource, true);
            // Move on to next dir
            dirs.erase(it);
            ++m_processedDirs;
            break;
        case Result_Overwrite:
            m_overwriteList.insert(existingDest);
            emit q->copyingDone(q, (*it).uSource, finalDestUrl((*it).uSource, (*it).uDest), (*it).mtime, true /* directory */, false /* renamed */);
            // Move on to next dir
            dirs.erase(it);
            ++m_processedDirs;
            break;
        case Result_OverwriteAll:
            m_bOverwriteAllDirs = true;
            emit q->copyingDone(q, (*it).uSource, finalDestUrl((*it).uSource, (*it).uDest), (*it).mtime, true /* directory */, false /* renamed */);
            // Move on to next dir
            dirs.erase(it);
            ++m_processedDirs;
            break;
        default:
            Q_ASSERT(0);
        }
        state = STATE_CREATING_DIRS;
        createNextDir();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KIO::Job *job, const QByteArray &data) { d_func()->slotStoredData(job, data); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool result) {
            if (result) {
                // Assume that service is an absolute path since we're being called (relative paths
                // would have been allowed unless Kiosk said no, therefore we already know where the
                // .desktop file is.  Now add a header to it if it doesn't already have one
                // and add the +x bit.

                QString errorString;
                if (s_untrustedProgramHandler->makeServiceFileExecutable(d->m_service->entryPath(), errorString)) {
                    proceedAfterSecurityChecks();
                } else {
                    QString serviceName = d->m_service->name();
                    if (serviceName.isEmpty()) {
                        serviceName = d->m_service->genericName();
                    }
                    setError(KJob::UserDefinedError);
                    setErrorText(i18n("Unable to make the service %1 executable, aborting execution.\n%2.",
                                      serviceName, errorString));
                    emitResult();
                }
            } else {
                setError(KIO::ERR_USER_CANCELED);
                emitResult();
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &udi : std::as_const(devices)) {
        bookmark = KFilePlacesItem::createDeviceBookmark(bookmarkManager, udi);
        if (!bookmark.isNull()) {
            KFilePlacesItem *item = new KFilePlacesItem(bookmarkManager, bookmark.address(), udi, q);
            QObject::connect(item, &KFilePlacesItem::itemChanged, q, [this](const QString &id) {
                itemChanged(id);
            });
            // TODO: Update bookmark internal element
            items << item;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KFileItem &item : dir->lstItems) {
                const KFileItem oldItem = item;
                KFileItem newItem = oldItem;
                const QUrl &oldItemUrl = oldItem.url();
                QUrl newItemUrl(oldItemUrl);
                newItemUrl.setPath(concatPaths(newDirUrl.path(), oldItemUrl.fileName()));
                qCDebug(KIO_CORE_DIRLISTER) << "renaming" << oldItemUrl << "to" << newItemUrl;
                newItem.setUrl(newItemUrl);

                listers |= emitRefreshItem(oldItem, newItem);
                // Change the item
                item.setUrl(newItemUrl);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &folder : qAsConst(folders)) {
                    label.append(QLatin1Char('\n'));
                    label.append(indentation);
                    label.append(folder);
                    label.append(QStringLiteral("/"));
                    indentation.append(QStringLiteral("    "));
                }
```

#### AUTO 


```{c}
auto urlSetterClosure = [this, url]() {
                    setCurrentItem(url);
                    QObject::disconnect(d->m_connection);
                };
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &providerName : std::as_const(m_deletedProviders)) {
        QStringList matches;
        for (const QString &dir : servicesDirs) {
            QString current = dir + QLatin1Char('/') + providerName + QLatin1String(".desktop");
            if (QFile::exists(current)) {
                matches += current;
            }
        }

        // Shouldn't happen
        if (matches.isEmpty()) {
            continue;
        }

        if (matches.size() == 1 && matches.first().startsWith(path)) {
            // If only the local copy existed, unlink it
            // TODO: error handling
            QFile::remove(matches.first());
            continue;
        }

        KConfig _service(path + providerName + QLatin1String(".desktop"), KConfig::SimpleConfig);
        KConfigGroup service(&_service, "Desktop Entry");
        service.writeEntry("Type", "Service");
        service.writeEntry("Hidden", true);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QModelIndex &idx) {
        return QPersistentModelIndex(idx);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](KFilePlacesItem *itemA, KFilePlacesItem *itemB) {
       return (itemA->groupType() < itemB->groupType());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *button : std::as_const(d->m_navButtons)) {
        button->removeEventFilter(this);
    }
```

#### AUTO 


```{c}
auto kit = dir->lstItems.begin(), kend = dir->lstItems.end();
```

#### AUTO 


```{c}
auto item = itemMapper.value(index);
```

#### LAMBDA EXPRESSION 


```{c}
[](const QPushButton *button) {
            return button->text().contains("OK");
        }
```

#### AUTO 


```{c}
auto job = KIO::copy({QUrl::fromLocalFile(testOverwriteCopy2)}, url, KIO::DefaultFlags);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &httpHeader : httpHeaders) {
            int index = httpHeader.indexOf(QL1C(':'));
            // Handle HTTP status line...
            if (index == -1) {
                // Except for the status line, all HTTP header must be an nvpair of
                // type "<name>:<value>"
                if (!httpHeader.startsWith(QLatin1String("HTTP/"), Qt::CaseInsensitive)) {
                    continue;
                }

                QStringList statusLineAttrs(httpHeader.split(QL1C(' '), Qt::SkipEmptyParts));
                if (statusLineAttrs.count() > 1) {
                    setAttribute(QNetworkRequest::HttpStatusCodeAttribute, statusLineAttrs.at(1));
                }

                if (statusLineAttrs.count() > 2) {
                    setAttribute(QNetworkRequest::HttpReasonPhraseAttribute, statusLineAttrs.at(2));
                }

                continue;
            }

            const QStringRef headerName = httpHeader.leftRef(index);
            QString headerValue = httpHeader.mid(index + 1);

            // Ignore cookie header since it is handled by the http ioslave.
            if (headerName.startsWith(QLatin1String("set-cookie"), Qt::CaseInsensitive)) {
                continue;
            }

            if (headerName.startsWith(QLatin1String("content-disposition"), Qt::CaseInsensitive) && ignoreContentDisposition(metaData)) {
                continue;
            }

            // Without overriding the corrected mime-type sent by kio_http, add
            // back the "charset=" portion of the content-type header if present.
            if (headerName.startsWith(QLatin1String("content-type"), Qt::CaseInsensitive)) {
                QString mimeType(header(QNetworkRequest::ContentTypeHeader).toString());

                if (m_ignoreContentDisposition) {
                    // If the server returned application/octet-stream, try to determine the
                    // real content type from the disposition filename.
                    if (mimeType == QLatin1String("application/octet-stream")) {
                        const QString fileName(metaData.value(QStringLiteral("content-disposition-filename")));
                        QMimeDatabase db;
                        QMimeType mime = db.mimeTypeForFile((fileName.isEmpty() ? url().path() : fileName), QMimeDatabase::MatchExtension);
                        mimeType = mime.name();
                    }
                    metaData.remove(QStringLiteral("content-disposition-type"));
                    metaData.remove(QStringLiteral("content-disposition-filename"));
                }

                if (!headerValue.contains(mimeType, Qt::CaseInsensitive)) {
                    index = headerValue.indexOf(QL1C(';'));
                    if (index == -1) {
                        headerValue = mimeType;
                    } else {
                        headerValue.replace(0, index, mimeType);
                    }
                    // qDebug() << "Changed mime-type from" << mimeType << "to" << headerValue;
                }
            }
            setRawHeader(headerName.trimmed().toUtf8(), headerValue.trimmed().toUtf8());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KHttpCookie &cookie : qAsConst(allCookies)) {
            cookieStr = cookieStr + cookie.cookieStr(useDOMFormat) + QStringLiteral("; ");
        }
```

#### LAMBDA EXPRESSION 


```{c}
[q](KJob *job, ulong percent) {
        Q_UNUSED(job);
        if (percent > q->percent()) {
            q->setPercent(percent);
        }
    }
```

#### AUTO 


```{c}
const auto text = QStringLiteral("foobar");
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &s2 : sl2) {
            bool didConvert;
            KSslError::Error error = static_cast<KSslError::Error>(s2.toInt(&didConvert));
            if (didConvert) {
                certErrors.append(error);
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, errorMsg]() {
        emit error(errorMsg);
        deleteLater();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const UDSEntry &entry) {
            const QString filename = entry.stringValue(KIO::UDSEntry::UDS_NAME);
            // Avoid returning entries like subdir/. and subdir/.., but include . and .. for
            // the toplevel dir, and skip hidden files/dirs if that was requested
            const bool shouldEmit = (m_prefix.isNull() || (filename != QLatin1String("..") && filename != QLatin1String(".")))
                && (includeHidden || (filename[0] != QLatin1Char('.')));
            return !shouldEmit;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, mgr]() {
        QFile::remove(bookmarksFile());
        // let KDirWatch process the deletion
        QTRY_VERIFY(mgr->root().first().isNull());
        createPlacesModels();
        testInitialList();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &text) { slotPathBoxChanged(text); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &srcUrl : qAsConst(sources)) {
        QVERIFY(QFileInfo::exists(srcUrl.toLocalFile())); // no moving happened
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QChar ch : qAsConst(d->m_text_start)) {
        if (ch != d->m_word_break_char) {
            is_exe_completion = false;
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &item : d->itemList) {
        d->insertUrlItem(item.get());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &item : items) {
        if (!d->m_mimeTypeList.contains(item.mimetype())) {
            d->m_mimeTypeList << item.mimetype();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&output, desktopEntryName, currentTimestamp]() {
        output.writeEmptyElement(applicationBookmarkTag);
        output.writeAttribute(nameAttribute, desktopEntryName);
        auto service = KService::serviceByDesktopName(desktopEntryName);
        if (service) {
            output.writeAttribute(execAttribute, service->exec() + QLatin1String(" %u"));
        } else {
            output.writeAttribute(execAttribute, QCoreApplication::instance()->applicationName() + QLatin1String(" %u"));
        }
        output.writeAttribute(modifiedAttribute, currentTimestamp);
        output.writeAttribute(countAttribute, QStringLiteral("1"));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &s2 : sl2) {
            bool didConvert;
            QSslError::SslError error = static_cast<QSslError::SslError>(s2.toInt(&didConvert));
            if (didConvert) {
                certErrors.append(error);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &url : qAsConst(m_request.proxyUrls)) {
            if (url != QLatin1String("DIRECT")) {
                if (isCompatibleNextUrl(m_server.proxyUrl, QUrl(url))) {
                    return false;
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &domain : domainList) {
            const KHttpCookieList *list =  mCookieJar->getCookieList(domain, fqdn);
            if (!list) {
                continue;
            }
            for (const KHttpCookie &cookie : *list) {
                if (cookie.isExpired()) {
                    continue;
                }
                if (cookieMatches(cookie, domain, fqdn, path, name)) {
                    putCookie(result, cookie, fields);
                    break;
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &key : keys) {
                    m_searchProvidersByKey.insert(key, provider);
                }
```

#### AUTO 


```{c}
auto baseFdCleanup = qScopeGuard([base_fd]() {
        if (base_fd != -1) {
            close(base_fd);
        }
    });
```

#### IF STATEMENT WITH INITIALIZER 


```{c}
if (KPluginInfo info(plugin); info.isValid()) {
                if (auto [it, inserted] = pluginIds.insert(info.pluginName()); inserted) {
                    jsonMetaDataPlugins << info.toMetaData();
                }
            } else {
                // Hack for directory thumbnailer: It has a hardcoded plugin id in the kio-slave and not any C++ plugin
                // Consequently we just use the base name as the plugin file for our KPluginMetaData object
                const QString path = QStandardPaths::locate(QStandardPaths::GenericDataLocation, QLatin1String("kservices5/") + plugin->entryPath());
                KPluginMetaData tmpData = KPluginMetaData::fromDesktopFile(path);
                jsonMetaDataPlugins << KPluginMetaData(tmpData.rawData(), QFileInfo(path).baseName(), path);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this](int value) {
        d->iconSizeSlider->setValue(value);
        d->zoomOutAction->setDisabled(value <= d->iconSizeSlider->minimum());
        d->zoomInAction->setDisabled(value >= d->iconSizeSlider->maximum());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &str : supported) {
                // wilcard matching because the "mimetype" can be "image/*"
                re.setPattern(QRegularExpression::wildcardToRegularExpression(str));

                if (mimeTypes.indexOf(re) != -1) {  // matches! -> we want previews
                    return true;
                }
            }
```

#### AUTO 


```{c}
auto job1 = KIO::copy({ QUrl::fromLocalFile(testCopy1) }, url, KIO::DefaultFlags);
```

#### CONST EXPRESSION 


```{c}
static constexpr int s_capacitybarHeight = 6;
```

#### RANGE FOR STATEMENT 


```{c}
for (const KUrlNavigatorButton *button : std::as_const(m_navButtons)) {
        requiredButtonWidth += button->minimumWidth();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &domainName : qAsConst(m_domainList)) {
        bool domainPrinted = false;

        KHttpCookieList *cookieList = m_cookieDomains.value(domainName);
        if (!cookieList) {
            continue;
        }

        QMutableListIterator<KHttpCookie> cookieIterator(*cookieList);
        while (cookieIterator.hasNext()) {
            const KHttpCookie &cookie = cookieIterator.next();

            if (cookie.isExpired()) {
                // Delete expired cookies
                cookieIterator.remove();
                continue;
            }
            if (cookieIsPersistent(cookie)) {
                // Only save cookies that are not "session-only cookies"
                if (!domainPrinted) {
                    domainPrinted = true;
                    ts << '[' << domainName.toLocal8Bit().data() << "]\n";
                }
                // Store persistent cookies
                const QString path = QL1C('"') + cookie.path() + QL1C('"');
                const QString domain = QL1C('"') + cookie.domain() + QL1C('"');
                const QString host = hostWithPort(&cookie);

                // TODO: replace with direct QTextStream output ?
                const QString str = QString::asprintf("%-20s %-20s %-12s %10lld  %3d %-20s %-4i %s\n",
                          host.toLatin1().constData(), domain.toLatin1().constData(),
                          path.toLatin1().constData(), cookie.expireDate(),
                          cookie.protocolVersion(),
                          cookie.name().isEmpty() ? cookie.value().toLatin1().constData() : cookie.name().toLatin1().constData(),
                          (cookie.isSecure() ? 1 : 0) + (cookie.isHttpOnly() ? 2 : 0) +
                          (cookie.hasExplicitPath() ? 4 : 0) + (cookie.name().isEmpty() ? 8 : 0),
                          cookie.value().toLatin1().constData());
                ts << str.toLatin1();
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[q](KIO::filesize_t offset) {
        Q_EMIT q->canResume(q, offset);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->activateUrlNavigator();
    }
```

#### AUTO 


```{c}
auto *label = new QLabel(_error_text, this);
```

#### LAMBDA EXPRESSION 


```{c}
[u, &urls](const QString & partial_name) 
    { 
        if (partial_name.trimmed().isEmpty()) {
            return;
        }

        // This returns QUrl(partial_name) for absolute URLs.
        // Otherwise, returns the concatenated url.
        QUrl finalUrl = u.resolved(QUrl(partial_name));
        if (finalUrl.isValid()) {
            urls.append(finalUrl);
        } else {
            // This can happen in the first quote! (ex: ' "something here"')
            qCDebug(KIO_KFILEWIDGETS_FW) << "Discarding Invalid" << finalUrl;
        }
    }
```

#### AUTO 


```{c}
auto dialogFinished = [this, filePath](bool shouldExecute) {
                if (shouldExecute) { // Run the file
                    KService::Ptr service(new KService(filePath));
                    startService(service, {});
                    return;
                }
                // The user selected "open"
                openInPreferredApp();
            };
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &item : d->defaultList) {
        d->insertUrlItem(item.get());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KIO::Job *job, KIO::filesize_t offset) {
        _k_slotCanResume(job, offset);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KSslError &err : qAsConst(d->sslErrors)) {
        message += err.errorString() + QLatin1Char('\n');
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &jsonMetadata : jsonPlugins) {
        // The plugin has been disabled
        const QString pluginId = jsonMetadata.pluginId();
        if (!showGroup.readEntry(pluginId, true) || excludeList.contains(pluginId)) {
            continue;
        }

        KPluginFactory *factory = KPluginLoader(jsonMetadata.fileName()).factory();
        if (!factory) {
            continue;
        }
        KAbstractFileItemActionPlugin *abstractPlugin = m_loadedPlugins.value(pluginId);
        if (!abstractPlugin) {
            abstractPlugin = factory->create<KAbstractFileItemActionPlugin>(this);
            m_loadedPlugins.insert(pluginId, abstractPlugin);
        }
        if (abstractPlugin) {
            connect(abstractPlugin, &KAbstractFileItemActionPlugin::error, q, &KFileItemActions::error);
            const QList<QAction *> actions = abstractPlugin->actions(m_props, m_parentWidget);
            itemCount += actions.count();
            const QString showInSubmenu = jsonMetadata.value(QStringLiteral("X-KDE-Show-In-Submenu"));
            if (showInSubmenu == QLatin1String("true")) {
                actionsMenu->addActions(actions);
            } else {
                mainMenu->addActions(actions);
            }
            addedPlugins.append(jsonMetadata.pluginId());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : urls) {
            if (url.scheme() == QLatin1String("trash")) {
                QString path = url.path();
                // HACK (#98983): remove "0-foo". Note that it works better than
                // displaying KFileItem::name(), for files under a subdir.
                path.remove(QRegExp(QStringLiteral("^/[0-9]*-")));
                prettyList.append(path);
            } else {
                prettyList.append(url.toDisplayString(QUrl::PreferLocalFile));
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (KCoreDirLister *kdl : qAsConst(listers)) {
        kdl->d->emitItems();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const ItemInUseChange& i : itemsToChange) {
        emitRedirections(QUrl(i.oldUrl), QUrl(i.newUrl));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &item : items) {
        if (cutUrls.contains(item.url())) {
            const QModelIndex index = dirModel->indexForItem(item);
            const QVariant value = dirModel->data(index, Qt::DecorationRole);
            if (value.type() == QVariant::Icon) {
                const QIcon icon(qvariant_cast<QIcon>(value));
                const QSize actualSize = icon.actualSize(m_viewAdapter->iconSize());
                QPixmap pixmap = icon.pixmap(actualSize);

                const auto cacheIt = m_cutItemsCache.constFind(item.url());
                if ((cacheIt == m_cutItemsCache.constEnd()) || (cacheIt->cacheKey() != pixmap.cacheKey())) {
                    pixmap = iconEffect->apply(pixmap, KIconLoader::Desktop, KIconLoader::DisabledState);
                    dirModel->setData(index, QIcon(pixmap), Qt::DecorationRole);

                    m_cutItemsCache.insert(item.url(), pixmap);
                }
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const MountRequest &request) {
        return request.reply.isError();
    }
```

#### AUTO 


```{c}
auto job = KIO::trash(items);
```

#### RANGE FOR STATEMENT 


```{c}
for (QSslError::SslError e : errorsList) {
            QSslError classError(e);
            trusted += QLatin1Char('\n') + classError.errorString();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KIO::AuthInfo &info : infos) {
            const qlonglong id = server.queryAuthInfoAsync(info, QString(), windowId, seqNr, 16 /*usertime*/);
            QVERIFY(id >= 0); // requestId, ever increasing
            idList << id;
        }
```

#### AUTO 


```{c}
const auto socketError = m_control->error();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : pendingUpdates) { // always a local path
        qCDebug(KIO_CORE_DIRLISTER) << file;
        QUrl u = QUrl::fromLocalFile(file);
        KFileItem item = findByUrl(nullptr, u); // search all items
        if (!item.isNull()) {
            // we need to refresh the item, because e.g. the permissions can have changed.
            KFileItem oldItem = item;
            item.refresh();

            if (!oldItem.cmp(item)) {
                reinsert(item, oldItem.url());
                listers.merge(emitRefreshItem(oldItem, item));
            }
        }
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr int s_noFiltering = -2;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &key : intAttributes) {
            if (config.hasKey(key)) {
                protocolData.insert(key, config.readEntry(key, int(0)));
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (SearchProvider *provider : qAsConst(providers)) {
        if (defaultSearchEngine == provider->desktopEntryName()) {
            defaultProviderIndex = providers.indexOf(provider);
            break;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        slotToggleEditableButtonPressed();
    }
```

#### AUTO 


```{c}
auto begin = d->m_history.begin() + historyMax;
```

#### LAMBDA EXPRESSION 


```{c}
[&](KJob *job) {
        app.exit(job->error());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        _k_slotAccepted();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->activateUrlNavigator(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &item : *this) {
        lst.append(item.url());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, persistentIndex](KIO::Job *job, KIO::filesize_t size, KIO::filesize_t available) {
                            PlaceFreeSpaceInfo &info = m_freeSpaceInfo[persistentIndex];

                            // even if we receive an error we want to refresh lastUpdated to avoid repeatedly querying in this case
                            info.lastUpdated = QDateTime::currentDateTimeUtc();

                            if (job->error()) {
                                return;
                            }

                            info.size = size;
                            info.used = size - available;

                            // FIXME scheduleDelayedItemsLayout but we're in the delegate here, not the view
                        }
```

#### LAMBDA EXPRESSION 


```{c}
[&path](const FileInfo &i) {
                return i.path == path;
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : urls) {
            KRecentDocument::add(url, service.desktopEntryName());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &httpHeader : httpHeaders) {
            int index = httpHeader.indexOf(QLatin1Char(':'));
            // Handle HTTP status line...
            if (index == -1) {
                // Except for the status line, all HTTP header must be an nvpair of
                // type "<name>:<value>"
                if (!httpHeader.startsWith(QLatin1String("HTTP/"), Qt::CaseInsensitive)) {
                    continue;
                }

                QStringList statusLineAttrs(httpHeader.split(QLatin1Char(' '), Qt::SkipEmptyParts));
                if (statusLineAttrs.count() > 1) {
                    setAttribute(QNetworkRequest::HttpStatusCodeAttribute, statusLineAttrs.at(1));
                }

                if (statusLineAttrs.count() > 2) {
                    setAttribute(QNetworkRequest::HttpReasonPhraseAttribute, statusLineAttrs.at(2));
                }

                continue;
            }

            const auto headerName = QStringView(httpHeader).left(index);
            // Ignore cookie header since it is handled by the http ioslave.
            if (headerName.startsWith(QLatin1String("set-cookie"), Qt::CaseInsensitive)) {
                continue;
            }

            if (headerName.startsWith(QLatin1String("content-disposition"), Qt::CaseInsensitive) && ignoreContentDisposition(metaData)) {
                continue;
            }

            QString headerValue = httpHeader.mid(index + 1);
            // Without overriding the corrected mime-type sent by kio_http, add
            // back the "charset=" portion of the content-type header if present.
            if (headerName.startsWith(QLatin1String("content-type"), Qt::CaseInsensitive)) {
                QString mimeType(header(QNetworkRequest::ContentTypeHeader).toString());

                if (m_ignoreContentDisposition) {
                    // If the server returned application/octet-stream, try to determine the
                    // real content type from the disposition filename.
                    if (mimeType == QLatin1String("application/octet-stream")) {
                        const QString fileName(metaData.value(QStringLiteral("content-disposition-filename")));
                        QMimeDatabase db;
                        QMimeType mime = db.mimeTypeForFile((fileName.isEmpty() ? url().path() : fileName), QMimeDatabase::MatchExtension);
                        mimeType = mime.name();
                    }
                    metaData.remove(QStringLiteral("content-disposition-type"));
                    metaData.remove(QStringLiteral("content-disposition-filename"));
                }

                if (!headerValue.contains(mimeType, Qt::CaseInsensitive)) {
                    index = headerValue.indexOf(QLatin1Char(';'));
                    if (index == -1) {
                        headerValue = mimeType;
                    } else {
                        headerValue.replace(0, index, mimeType);
                    }
                    // qDebug() << "Changed mime-type from" << mimeType << "to" << headerValue;
                }
            }
            setRawHeader(headerName.trimmed().toUtf8(), headerValue.trimmed().toUtf8());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &str : supported) {
                // the "mimetypes" we get from the PreviewJob can be "image/*"
                // so we need to check in wildcard mode
                    re.setPattern(QRegularExpression::wildcardToRegularExpression(str));
                    if (re.match(mime).hasMatch()) {
                        return true;
                    }
                }
```

#### LAMBDA EXPRESSION 


```{c}
[bufferSize](qint64 pos, QFile &f, QByteArray &buffer){
        auto ioresult = f.seek(pos);
        int bytesRead;
        if (ioresult) {
            bytesRead = f.read(buffer.data(), bufferSize);
            ioresult = bytesRead != -1;
        }
        if (!ioresult) {
            qCWarning(KIO_WIDGETS) << "Could not read file for comparison:" << f.fileName();
            return false;
        }
        return true;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QAction *action) {
            m_triggered = true;
            slotTriggered(action);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&types, &excludeTypes, this](const KFileItem &i)
            {
                const QString mimetype = i.mimetype();
                return mimeTypeListContains(types, i) && !mimeTypeListContains(excludeTypes, i);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QByteArray &ba) { slotData(ba); }
```

#### AUTO 


```{c}
const auto exploded = line.split(' ');
```

#### LAMBDA EXPRESSION 


```{c}
[this](QUrl url) {
        // Parts of the following code have been taken from the class KateFileSelector
        // located in kate/app/katefileselector.hpp of Kate.
        // SPDX-FileCopyrightText: 2001 Christoph Cullmann <cullmann@kde.org>
        // SPDX-FileCopyrightText: 2001 Joseph Wenninger <jowenn@kde.org>
        // SPDX-FileCopyrightText: 2001 Anders Lund <anders.lund@lund.tdcadsl.dk>

        // For example "desktop:/" _not_ "desktop:", see the comment in slotProtocolChanged()
        if (!url.isEmpty() && url.path().isEmpty() && KProtocolInfo::protocolClass(url.scheme()) == QLatin1String(":local")) {
            url.setPath(QStringLiteral("/"));
        }

        const auto urlStr = url.toString();
        QStringList urls = m_pathBox->urls();
        urls.removeAll(urlStr);
        urls.prepend(urlStr);
        m_pathBox->setUrls(urls, KUrlComboBox::RemoveBottom);

        q->setLocationUrl(url);
        // The URL might have been adjusted by KUrlNavigator::setUrl(), hence
        // synchronize the result in the path box.
        m_pathBox->setUrl(q->locationUrl());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](qreal value) {
        d->_k_adaptItemsUpdate(value);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QSslError &err : qAsConst(d->sslErrors)) {
        message += err.errorString() + QLatin1Char('\n');
    }
```

#### AUTO 


```{c}
auto it = std::find_if(fileList.begin(), fileList.end(),
                                   [&path](const FileInfo &i) { return (i.path == path); });
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &service : fileItemPlugins) {
        if (!showGroup.readEntry(service->desktopEntryName(), true)) {
            // The plugin has been disabled
            continue;
        }

        KAbstractFileItemActionPlugin *abstractPlugin = service->createInstance<KAbstractFileItemActionPlugin>();
        if (abstractPlugin) {
            abstractPlugin->setParent(mainMenu);
            auto actions = abstractPlugin->actions(d->m_props, d->m_parentWidget);
            itemCount += actions.count();
            mainMenu->addActions(actions);
            addedPlugins.append(service->desktopEntryName());
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](qreal value) {
        d->_k_itemAppearUpdate(value);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &s : std::as_const(sl)) {
        if (s == QLatin1String("Reject")) {
            isRejected = true;
            ignoredErrors.clear();
            break;
        }
        if (!d->stringToSslError.contains(s)) {
            continue;
        }
        ignoredErrors.append(d->stringToSslError.value(s));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&putDataBuffer](){ putDataBuffer.readChannelFinished(); }
```

#### LAMBDA EXPRESSION 


```{c}
[&db, commonMimeType](const KPluginMetaData& metaData) {
        if (!metaData.serviceTypes().contains(QLatin1String("KFileItemAction/Plugin"))) {
            return false;
        }

        auto mimeType = db.mimeTypeForName(commonMimeType);
        const QStringList list = metaData.mimeTypes();
        return std::any_of(list.constBegin(), list.constEnd(), [mimeType](const QString &supportedMimeType) {
            return mimeType.inherits(supportedMimeType);
        });
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &f : std::as_const(m_topLevelFileNames)) {
        createTestFile(path + f);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &certFilename : dirList) {
            const QString certPath = userCertDir + certFilename;
            QList<QSslCertificate> certs = QSslCertificate::fromPath(certPath);

            if (!certs.isEmpty() && certs.at(0).digest().toHex() == old.certHash) {
                if (QFile::remove(certPath)) {
                    removed = true;
                } else {
                    // maybe the file is readable but not writable
                    return false;
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &request : qAsConst(requests)) {
        d->urls[request.urlIndex] = QUrl::fromLocalFile(request.reply.value());
    }
```

#### AUTO 


```{c}
auto *placesModel = qobject_cast<KFilePlacesModel *>(q->model())
```

#### AUTO 


```{c}
auto err = tryOpen(f, QFile::encodeName(path), O_RDONLY, S_IRUSR, errno)
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &source : sources) {
        if (moveDirs) {
            QVERIFY(QDir().mkdir(source));
        } else {
            createTestFile(source);
        }
    }
```

#### AUTO 


```{c}
auto *cachedItemsJob = new KCoreDirListerPrivate::CachedItemsJob(lister, _url, _reload);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { Q_EMIT result(true); }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &f) {
        QFile::remove(f);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &protocol : std::as_const(items[category])) {
                QAction *action = menu->addAction(protocol);
                action->setData(protocol);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[&types, &excludeTypes](const KFileItem &i)
            {
                return mimeTypeListContains(types, i) && !mimeTypeListContains(excludeTypes, i);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[](const KSslError &e) {
        return e.error() == KSslError::NoPeerCertificate || e.error() == KSslError::PathLengthExceeded;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool checked) {
        d->m_urlNavigator->setSortHiddenFoldersLast(checked);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : urls) {
            // TODO: use KIO::stat in order to get the UDS_DISPLAY_NAME too
            KIO::MimetypeJob *job = KIO::mimetype(url);

            QString mimeString;
            if (!job->exec()) {
                mimeString = QStringLiteral("unknown");
            } else {
                mimeString = job->mimetype();
            }

            QMimeType mimetype = db.mimeTypeForName(mimeString);

            if (!mimetype.isValid()) {
                qWarning() << "URL not added to Places as mimetype could not be determined!";
                continue;
            }

            if (!mimetype.inherits(QStringLiteral("inode/directory"))) {
                // Only directories are allowed
                continue;
            }

            KFileItem item(url, mimetype.name(), S_IFDIR);

            KBookmark bookmark = KFilePlacesItem::createBookmark(d->bookmarkManager,
                                 url.fileName(), url,
                                 item.iconName());
            group.moveBookmark(bookmark, afterBookmark);
            afterBookmark = bookmark;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job, qulonglong _psize) {
        slotProcessedSize(job, _psize);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](qreal value) {
        d->itemDisappearUpdate(value);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KMountPoint::Ptr &mp : mountPoints) {
        QString mountPoint = mp->mountPoint();
        QString device = mp->mountedFrom();
        // qDebug()<<"mountPoint :"<<mountPoint<<" device :"<<device<<" mp->mountType() :"<<mp->mountType();

        if ((mountPoint != QLatin1String("-")) && (mountPoint != QLatin1String("none")) && !mountPoint.isEmpty()
                && device != QLatin1String("none")) {
            devices.append(device + QLatin1String(" (")
                           + mountPoint + QLatin1Char(')'));
            d->m_devicelist.append(device);
            d->mountpointlist.append(mountPoint);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &shorthand) {
        return std::find_if(m_providers.cbegin(), m_providers.cend(), [this, &shorthand](const SearchProvider *provider) {
            return provider != m_provider && provider->keys().contains(shorthand);
        });
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &service : fileItemPlugins) {
        if (!showGroup.readEntry(service->desktopEntryName(), true)) {
            // The plugin has been disabled
            continue;
        }

        auto *abstractPlugin = service->createInstance<KAbstractFileItemActionPlugin>();
        if (abstractPlugin) {
            abstractPlugin->setParent(mainMenu);
            auto actions = abstractPlugin->actions(m_props, m_parentWidget);
            itemCount += actions.count();
            mainMenu->addActions(actions);
            addedPlugins.append(service->desktopEntryName());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KHttpCookie &cookie : qAsConst(*mPendingCookies)) {
        if (cookie.match(fqdn, domains, path)) {
            if (!cookieList) {
                return true;
            }
            cookieList->append(cookie);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, button](const QUrl &destination, QDropEvent *event) {
                    dropUrls(destination, event, button);
                }
```

#### LAMBDA EXPRESSION 


```{c}
do {
        return copy({"2"_hc}, "2"_rc);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QAction *action : actionsList) {
            ret.append(action->objectName());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &fileName : entryNames) {
        if (fileName == QLatin1String("..")) {
            continue;
        }
        const QString filePath = info.physicalPath + QLatin1Char('/') + fileName;
        // shouldn't be necessary
        //const QString url = TrashImpl::makeURL( trashId, fileId, relativePath + '/' + fileName );
        entry.clear();
        TrashedFileInfo infoForItem(info);
        infoForItem.origPath += QLatin1Char('/') + fileName;
        if (createUDSEntry(filePath, fileName, fileName, entry, infoForItem)) {
            listEntry(entry);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &deletedUrl : qAsConst(affectedItems)) {
        // stop all jobs for deletedUrlStr
        DirectoryDataHash::iterator dit = directoryData.find(deletedUrl);
        if (dit != directoryData.end()) {
            // we need a copy because stop modifies the list
            const QList<KCoreDirLister *> listers = (*dit).listersCurrentlyListing;
            for (KCoreDirLister *kdl : listers) {
                stopListingUrl(kdl, deletedUrl);
            }
            // tell listers holding deletedUrl to forget about it
            // this will stop running updates for deletedUrl as well

            // we need a copy because forgetDirs modifies the list
            const QList<KCoreDirLister *> holders = (*dit).listersCurrentlyHolding;
            for (KCoreDirLister *kdl : holders) {
                // lister's root is the deleted item
                if (kdl->d->url == deletedUrl) {
                    // tell the view first. It might need the subdirs' items (which forgetDirs will delete)
                    if (!kdl->d->rootFileItem.isNull()) {
                        emit kdl->itemsDeleted(KFileItemList{kdl->d->rootFileItem});
                    }
                    forgetDirs(kdl);
                    kdl->d->rootFileItem = KFileItem();
                } else {
                    const bool treeview = kdl->d->lstDirs.count() > 1;
                    if (!treeview) {
                        emit kdl->clear();
                        kdl->d->lstDirs.clear();
                    } else {
                        kdl->d->lstDirs.removeAll(deletedUrl);
                    }

                    forgetDirs(kdl, deletedUrl, treeview);
                }
            }
        }

        // delete the entry for deletedUrl - should not be needed, it's in
        // items cached now
        int count = itemsInUse.remove(deletedUrl);
        Q_ASSERT(count == 0);
        Q_UNUSED(count);   //keep gcc "unused variable" complaining quiet when in release mode
    }
```

#### AUTO 


```{c}
auto *dlg = new KIO::SkipDialog(KJobWidgets::window(job), options, errorText);
```

#### LAMBDA EXPRESSION 


```{c}
[this](KIO::Job *job, QByteArray &data) { d_func()->slotStoredDataReq(job, data); }
```

#### RANGE FOR STATEMENT 


```{c}
for (QString srcPath : entries) {
        if (srcPath == QLatin1Char('.') || srcPath == QLatin1String("..") || srcPath == QLatin1String(".directory")) {
            continue;
        }
        srcPath.prepend(oldTrashDir);   // make absolute
        int trashId;
        QString fileId;
        if (!createInfo(srcPath, trashId, fileId)) {
            qCWarning(KIO_TRASH) << "Trash migration: failed to create info for" << srcPath;
            allOK = false;
        } else {
            bool ok = moveToTrash(srcPath, trashId, fileId);
            if (!ok) {
                (void)deleteInfo(trashId, fileId);
                qCWarning(KIO_TRASH) << "Trash migration: failed to create info for" << srcPath;
                allOK = false;
            } else {
                qCDebug(KIO_TRASH) << "Trash migration: moved" << srcPath;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &dir : parentDirUrls) {
            DirItem *dirItem = dirItemForUrl(dir);
            if (!dirItem) {
                continue;
            }
            for (auto fit = dirItem->lstItems.begin(), fend = dirItem->lstItems.end(); fit != fend; ++fit) {
                if ((*fit).url() == url) {
                    const KFileItem fileitem = *fit;
                    removedItemsByDir[dir].append(fileitem);
                    // If we found a fileitem, we can test if it's a dir. If not, we'll go to deleteDir just in case.
                    if (fileitem.isNull() || fileitem.isDir()) {
                        deletedSubdirs.append(url);
                    }
                    dirItem->lstItems.erase(fit); // remove fileitem from list
                    break;
                }
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, existingDest](KIO::Job *spaceJob, KIO::filesize_t size, KIO::filesize_t available) {
                           Q_UNUSED(size)
                           if (!spaceJob->error()) {
                               m_freeSpace = available;
                           } else {
                               qCDebug(KIO_COPYJOB_DEBUG) << "Couldn't determine free space information for" << existingDest;
                           }
                           statCurrentSrc();
                       }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &httpHeader : httpHeaders) {
            int index = httpHeader.indexOf(QL1C(':'));
            // Handle HTTP status line...
            if (index == -1) {
                // Except for the status line, all HTTP header must be an nvpair of
                // type "<name>:<value>"
                if (!httpHeader.startsWith(QLatin1String("HTTP/"), Qt::CaseInsensitive)) {
                    continue;
                }

                QStringList statusLineAttrs(httpHeader.split(QL1C(' '), QString::SkipEmptyParts));
                if (statusLineAttrs.count() > 1) {
                    setAttribute(QNetworkRequest::HttpStatusCodeAttribute, statusLineAttrs.at(1));
                }

                if (statusLineAttrs.count() > 2) {
                    setAttribute(QNetworkRequest::HttpReasonPhraseAttribute, statusLineAttrs.at(2));
                }

                continue;
            }

            const QStringRef headerName = httpHeader.leftRef(index);
            QString headerValue = httpHeader.mid(index + 1);

            // Ignore cookie header since it is handled by the http ioslave.
            if (headerName.startsWith(QLatin1String("set-cookie"), Qt::CaseInsensitive)) {
                continue;
            }

            if (headerName.startsWith(QLatin1String("content-disposition"), Qt::CaseInsensitive) &&
                    ignoreContentDisposition(metaData)) {
                continue;
            }

            // Without overriding the corrected mime-type sent by kio_http, add
            // back the "charset=" portion of the content-type header if present.
            if (headerName.startsWith(QLatin1String("content-type"), Qt::CaseInsensitive)) {

                QString mimeType(header(QNetworkRequest::ContentTypeHeader).toString());

                if (m_ignoreContentDisposition) {
                    // If the server returned application/octet-stream, try to determine the
                    // real content type from the disposition filename.
                    if (mimeType == QStringLiteral("application/octet-stream")) {
                        const QString fileName(metaData.value(QStringLiteral("content-disposition-filename")));
                        QMimeDatabase db;
                        QMimeType mime = db.mimeTypeForFile((fileName.isEmpty() ? url().path() : fileName), QMimeDatabase::MatchExtension);
                        mimeType = mime.name();
                    }
                    metaData.remove(QStringLiteral("content-disposition-type"));
                    metaData.remove(QStringLiteral("content-disposition-filename"));
                }

                if (!headerValue.contains(mimeType, Qt::CaseInsensitive)) {
                    index = headerValue.indexOf(QL1C(';'));
                    if (index == -1) {
                        headerValue = mimeType;
                    } else {
                        headerValue.replace(0, index, mimeType);
                    }
                    //qDebug() << "Changed mime-type from" << mimeType << "to" << headerValue;
                }
            }
            setRawHeader(headerName.trimmed().toUtf8(), headerValue.trimmed().toUtf8());
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, processRunner]() {
                d->slotStarted(processRunner);
            }
```

#### AUTO 


```{c}
const auto imgFileUrl = QUrl::fromLocalFile(tempJpegFile.fileName());
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool visible) { togglePlacesPanel(visible, m_placesDock); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KIO::Job *job, const QByteArray &data) { _k_slotData(job, data); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &base : dirs) {
        QDir base_dir = QDir(base);
        if (base_dir.exists() && canonical.startsWith(base_dir.canonicalPath())) {
            return canonical.mid(base.length() + 1);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KJob *job : qAsConst(m_previewJobs)) {
        Q_ASSERT(job);
        job->suspend();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : urls) {
            KRecentDocument::add(url, service->desktopEntryName());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto action : actions) {
                action->setParent(popup);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : std::as_const(m_pluginActions)) {
        removeAction(action);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &request : std::as_const(requests)) {
        if (!request.reply.isError()) {
            d->urls[request.urlIndex] = QUrl::fromLocalFile(request.reply.value());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KServicePtr &entry : entries) {
        QString file = QStandardPaths::locate(QStandardPaths::GenericDataLocation, QLatin1String("kservices5/") + entry->entryPath());
        const KDesktopFile desktopFile(file);
        const KConfigGroup cfg = desktopFile.desktopGroup();

        if (!shouldDisplayServiceMenu(cfg, protocol)) {
            continue;
        }

        if (cfg.hasKey("Actions") || cfg.hasKey("X-KDE-GetActionMenu")) {
            if (!checkTypesMatch(cfg)) {
                continue;
            }

            const QString priority = cfg.readEntry("X-KDE-Priority");
            const QString submenuName = cfg.readEntry("X-KDE-Submenu");

            ServiceList &list = s.selectList(priority, submenuName);
            const ServiceList userServices = KDesktopFileActions::userDefinedServices(*entry, isLocal, urlList);
            for (const KServiceAction &action : userServices) {
                if (showGroup.readEntry(action.name(), true) && !excludeList.contains(action.name())) {
                    list += action;
                }
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QDBusPendingCallWatcher *watcher) {
        QDBusPendingReply<> reply = *watcher;
        watcher->deleteLater();
        if (reply.isError()) {
            qCWarning(KIO_GUI) << "Failed to unref service:" << m_serviceName << reply.error().name() << reply.error().message();
            return systemdError(reply.error().message());
        }
        qCDebug(KIO_GUI) << "Successfully unref'd service:" << m_serviceName;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KUriFilterPlugin *plugin : d->pluginList) {
        // If no specific filters were requested, iterate through all the plugins.
        // Otherwise, only use available filters.
        if (filters.isEmpty() || filters.contains(plugin->objectName())) {
            if (plugin->filterUri(data)) {
                filtered = true;
            }
        }
    }
```

#### AUTO 


```{c}
auto res = execWithElevatedPrivilege(SYMLINK, {dest, target}, errno);
```

#### AUTO 


```{c}
auto groupType
```

#### LAMBDA EXPRESSION 


```{c}
[](QByteArray &line) {
            return line.startsWith("Load smb config files from");
        }
```

#### AUTO 


```{c}
auto it = mUsercache.find(uid);
```

#### RANGE FOR STATEMENT 


```{c}
for (const URLHint &hint : std::as_const(m_urlHints)) {
            qCDebug(category) << "testing regexp for" << hint.prepend;
            if (hint.hintRe.match(cmd).capturedStart() == 0) {
                const QString cmdStr = hint.prepend + cmd;
                QUrl cmdUrl(cmdStr);
                qCDebug(category) << "match - prepending" << hint.prepend << "->" << cmdStr << "->" << cmdUrl;
                setFilteredUri(data, cmdUrl);
                setUriType(data, hint.type);
                return true;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : d->m_pluginActions) {
            menu->removeAction(action);
        }
```

#### AUTO 


```{c}
auto err = execWithElevatedPrivilege(CHOWN, _dest, getuid(), getgid())
```

#### LAMBDA EXPRESSION 


```{c}
[&item](const KFileItem &pending) {
            return pending.url() == item.url();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&url](const EntryInfo &info) {
            return url == info.url;
        }
```

#### AUTO 


```{c}
const auto urlString = xml.attributes().value(QLatin1String("href"));
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { Q_EMIT result(false); }
```

#### AUTO 


```{c}
const auto &plugin
```

#### AUTO 


```{c}
auto dstAttrs = readXattr(dest);
```

#### RANGE FOR STATEMENT 


```{c}
for (QByteArray offer : offers) {
        QByteArray scheme, cont;

        parseChallenge(offer, &scheme, &cont);

        while (!cont.isEmpty()) {
            offer.chop(cont.length());
            alloffers << offer;
            offer = cont;
            cont.clear();
            parseChallenge(offer, &scheme, &cont);
        }
        alloffers << offer;
    }
```

#### AUTO 


```{c}
auto it = m_lookups.find(hostInfo.lookupId());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QSslError &error : errors) {
        if (!isErrorIgnored(error.error())) {
            ret.append(error);
        }
    }
```

#### AUTO 


```{c}
const auto actions = service->actions();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &s : sl) {
            certChain.append(QSslCertificate(s.toLatin1())); // or is it toLocal8Bit or whatever?
            if (certChain.last().isNull()) {
                decodedOk = false;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QXmlStreamAttribute &old : qAsConst(attributes)) {
                    if (old.qualifiedName() == countAttribute) {
                        continue;
                    }
                    if (old.qualifiedName() == modifiedAttribute) {
                        continue;
                    }
                    newAttributes.append(old);
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (KCoreDirLister *kdl : listers) {
            kdl->d->emitItems();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QHostAddress &address : info.addresses()) {
            if (isSpecialAddress(address)) {
                continue;
            }

            if (address.isInSubnet(subnet)) {
                isInSubNet = true;
                break;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->slotItemsChanged();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &jsonMetadata : jsonPlugins) {
        // The plugin has been disabled
        const QString pluginId = jsonMetadata.pluginId();
        if (!showGroup.readEntry(pluginId, true) || excludeList.contains(pluginId)) {
            continue;
        }

        KPluginFactory *factory = KPluginLoader(jsonMetadata.fileName()).factory();
        if (!factory) {
            continue;
        }
        KAbstractFileItemActionPlugin *abstractPlugin = m_loadedPlugins.value(pluginId);
        if (!abstractPlugin) {
            abstractPlugin = factory->create<KAbstractFileItemActionPlugin>(this);
            connect(abstractPlugin, &KAbstractFileItemActionPlugin::error, q, &KFileItemActions::error);
            m_loadedPlugins.insert(pluginId, abstractPlugin);
        }
        if (abstractPlugin) {
            connect(abstractPlugin, &KAbstractFileItemActionPlugin::error, q, &KFileItemActions::error);
            const QList<QAction *> actions = abstractPlugin->actions(m_props, m_parentWidget);
            itemCount += actions.count();
            const QString showInSubmenu = jsonMetadata.value(QStringLiteral("X-KDE-Show-In-Submenu"));
            if (showInSubmenu == QLatin1String("true")) {
                actionsMenu->addActions(actions);
            } else {
                mainMenu->addActions(actions);
            }
            addedPlugins.append(jsonMetadata.pluginId());
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString& attrName, const QString& value, const QString& fileName) {
            return QStringList{QLatin1String("-n"), attrName, QLatin1String("-v"), value, fileName};
        }
```

#### AUTO 


```{c}
auto *p = static_cast<AskUserActionInterface **>(data);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &name : groups) {
        if (name.startsWith(QLatin1Char('/'))) {
            const KConfigGroup group = config.group(name);

            ConfigEntry entry;
            entry.useTimeLimit = group.readEntry("UseTimeLimit", false);
            entry.days = group.readEntry("Days", 7);
            entry.useSizeLimit = group.readEntry("UseSizeLimit", true);
            entry.percent = group.readEntry("Percent", 10.0);
            entry.actionType = group.readEntry("LimitReachedAction", 0);
            mConfigMap.insert(name, entry);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &dir : servicesDirs) {
            QString current = dir + QLatin1Char('/') + providerName + QLatin1String(".desktop");
            if (QFile::exists(current)) {
                matches += current;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &filter : list) {
                QString match = findMatchingFilter(filter, filename);
                if (!match.isEmpty()) {
                    if (match != QLatin1String("*")) {   // never match the catch-all filter
                        filterWidget->setCurrentFilter(filter);
                    }
                    return; // do not repeat, could match a later filter
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QSslError &e : sslErrors) {
        d->sslErrors.append(KSslError(e));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &src : std::as_const(lst)) {
        QMap<QString, QString>::ConstIterator it = metaData.find("trashURL-" + src.path());
        QVERIFY(it != metaData.constEnd());
        trashUrls.append(QUrl(it.value()));
    }
```

#### AUTO 


```{c}
const auto it = std::find_if(buttons.cbegin(), buttons.cend(), [](QPushButton *button) {
        return button->text() == QLatin1String("&Here");
    });
```

#### RANGE FOR STATEMENT 


```{c}
for (auto action : actions) {
                    action->setParent(popup);
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this, access](Solid::ErrorType error, QVariant errorData) {
            d->storageSetupDone(error, errorData, access);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->_k_triggerDevicePolling(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &share : shares) {
        KSambaShareData shareData = KSambaShare::instance()->getShareByName(share);

        // KSambaShare reads acl from net usershare info's "usershare_acl" field with no validation
        QCOMPARE(shareData.setAcl(shareData.acl()), KSambaShareData::UserShareAclOk);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QThread *thread, const QStringList &matches) {
            slotCompletionThreadDone(thread, matches);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &match) { d->fileCompletion(match); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QDBusPendingCallWatcher *watcher) {
            m_finished = true;
            QDBusPendingReply<uint> reply = *watcher;
            if (reply.isError()) {
                Q_EMIT error(watcher->error().name());
                terminateStartupNotification();
            } else {
                Q_EMIT processStarted(reply.value());
            }
            deleteLater();
        }
```

#### AUTO 


```{c}
auto it = std::find_if(stdIconSizes.cbegin(), itEnd,
                 [currValue](KIconLoader::StdSizes size) { return size > currValue; });
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &proxyUrl : qAsConst(m_proxyUrls)) {
        const QUrl url(proxyUrl);
        const QString scheme(url.scheme());

        if (!supportedProxyScheme(scheme)) {
            // TODO: Need a new error code to indicate unsupported URL scheme.
            result = Result::fail(ERR_CANNOT_CONNECT, url.toString());
            continue;
        }

        if (!isSocksProxyScheme(scheme)) {
            const Result result = ftpOpenControlConnection(url.host(), url.port());
            if (result.success) {
                return Result::pass();
            }
            continue;
        }

        qCDebug(KIO_FTP) << "Connecting to SOCKS proxy @" << url;
        m_proxyURL = url;
        result = ftpOpenControlConnection(m_host, m_port);
        if (result.success) {
            return result;
        }
        m_proxyURL.clear();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &key : keysChanged) {
        AuthInfoContainerList *authList = m_authDict.value(key);
        if (!authList) {
            continue;
        }

        QMutableListIterator<AuthInfoContainer *> it(*authList);
        while (it.hasNext()) {
            AuthInfoContainer *current = it.next();
            if (current->expire == AuthInfoContainer::expWindowClose) {
                if (current->windowList.removeAll(windowId) && current->windowList.isEmpty()) {
                    delete current;
                    it.remove();
                }
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &path) { enterUrl(path); }
```

#### LAMBDA EXPRESSION 


```{c}
[job, this]() {
        const int errCode = job->error();
        if (errCode) {
            setError(errCode);
            setErrorText(job->errorText());
            emitResult();
        } else {
            d->m_suggestedFileName = job->suggestedFileName();
            d->m_mimeTypeName = job->mimeType();
            d->runUrlWithMimeType();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &searchProvider : searchProviders) {
                QAction *action = new QAction(i18nc("@action:inmenu Search for <text> with", "%1", searchProvider), webShortcutsMenu);
                action->setIcon(QIcon::fromTheme(filterData.iconNameForPreferredSearchProvider(searchProvider)));
                action->setData(filterData.queryForPreferredSearchProvider(searchProvider));
                webShortcutsMenu->addAction(action);
                actionGroup->addAction(action);
            }
```

#### AUTO 


```{c}
auto *autoAct = new QAction(i18nc("@item:inmenu Auto set icon size based on available space in"
                                      "the Places side-panel",
                                      "Auto Resize"),
                                group);
```

#### LAMBDA EXPRESSION 


```{c}
[&types, &excludeTypes, this](const KFileItem &i)
            {
                return mimeTypeListContains(types, i) && !mimeTypeListContains(excludeTypes, i);
            }
```

#### AUTO 


```{c}
auto processACLChanges = [this, ACLChange, defaultACLChange](KIO::ChmodJob *chmodJob) {
        if (!d->fileSystemSupportsACLs) {
            return;
        }

        if (ACLChange) {
            chmodJob->addMetaData(QStringLiteral("ACL_STRING"), d->extendedACL.isValid() ? d->extendedACL.asString() : QStringLiteral("ACL_DELETE"));
        }

        if (defaultACLChange) {
            chmodJob->addMetaData(QStringLiteral("DEFAULT_ACL_STRING"), d->defaultACL.isValid() ? d->defaultACL.asString() : QStringLiteral("ACL_DELETE"));
        }
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &item : std::as_const(d->items)) {
            const QString extension = db.suffixForFileName(item.name());

            if (extensions.contains(extension)) {
                d->allExtensionsDifferent = false;
                break;
            }

            extensions.insert(extension);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { _k_slotOtherDesktopFileClosed(); }
```

#### AUTO 


```{c}
const auto itEnd = m_parentDirs.constEnd();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->enableSmoothItemResizing();
    }
```

#### AUTO 


```{c}
auto it = std::lower_bound(storage.begin(), storage.end(), udsField, less);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &mimeType : mimeTypes) {
                mimeMap.insert(mimeType, plugin);
            }
```

#### AUTO 


```{c}
const auto mountsList = KMountPoint::currentMountPoints();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &ba : messyResultsList) {
        QList<QByteArray> values = ba.split('\t');
        QByteArray key = values.takeFirst();
        nValues += values.count();

        QList<QByteArray> comparisonValues;
        for (const QPair<int, int> be : tokenizer.value(key).beginEnd) {
            comparisonValues.append(QByteArray(buffer + be.first, be.second - be.first));
        }

        QCOMPARE(comparisonValues.count(), values.count());
        for (int i = 0; i < values.count(); i++) {
            QVERIFY(comparisonValues[i].startsWith(values[i]));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &name : groups) {
        if (name.startsWith(QLatin1Char('/'))) {
            config.deleteGroup(name);
        }
    }
```

#### AUTO 


```{c}
auto *label = new QLabel(i18n("%1:", field.name), &d->m_mainWidget);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &h : qAsConst(responseHeaders)) {
            out << h << '\n';
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, url]() {
                    Q_EMIT q->newWindowRequested(url);
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (SearchProvider* provider : providers)
  {
    if (!provider->isDirty())
      continue;

    changedProviderCount++;

    KConfig _service(path + provider->desktopEntryName() + QLatin1String(".desktop"), KConfig::SimpleConfig);
    KConfigGroup service(&_service, "Desktop Entry");
    service.writeEntry("Type", "Service");
    service.writeEntry("X-KDE-ServiceTypes", "SearchProvider");
    service.writeEntry("Name", provider->name());
    service.writeEntry("Query", provider->query());
    service.writeEntry("Keys", provider->keys());
    service.writeEntry("Charset", provider->charset());
    service.writeEntry("Hidden", false); // we might be overwriting a hidden entry
  }
```

#### IF STATEMENT WITH INITIALIZER 


```{c}
if (const auto extraFields = KProtocolInfo::extraFields(url); !d->bMultiple && !extraFields.isEmpty()) {
        int curRow = d->m_ui->gridLayout->rowCount();
        KSeparator *sep = new KSeparator(Qt::Horizontal, &d->m_mainWidget);
        d->m_ui->gridLayout->addWidget(sep, curRow++, 0, 1, 3);

        QLocale locale;
        for (int i = 0; i < extraFields.count(); ++i) {
            const auto &field = extraFields.at(i);

            QString text = firstItem.entry().stringValue(KIO::UDSEntry::UDS_EXTRA + i);
            if (field.type == KProtocolInfo::ExtraField::Invalid || text.isEmpty()) {
                continue;
            }

            if (field.type == KProtocolInfo::ExtraField::DateTime) {
                const QDateTime date = QDateTime::fromString(text, Qt::ISODate);
                if (!date.isValid()) {
                    continue;
                }

                text = locale.toString(date, QLocale::LongFormat);
            }

            auto *label = new QLabel(i18n("%1:", field.name), &d->m_mainWidget);
            d->m_ui->gridLayout->addWidget(label, curRow, 0, Qt::AlignRight);

            auto *squeezedLabel = new KSqueezedTextLabel(text, &d->m_mainWidget);
            if (properties->layoutDirection() == Qt::RightToLeft) {
                squeezedLabel->setAlignment(Qt::AlignRight);
            } else {
                squeezedLabel->setLayoutDirection(Qt::LeftToRight);
            }

            d->m_ui->gridLayout->addWidget(squeezedLabel, curRow++, 1);
            squeezedLabel->setTextInteractionFlags(Qt::TextSelectableByMouse | Qt::TextSelectableByKeyboard);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() -> bool {
            const QString out = proc.readAllStandardOutput();
            if (!out.isEmpty()) {
                qDebug() << "STDERR:" << out;
            }
            if (!out.endsWith("Serving on http://0.0.0.0:30000 ...\n")) {
                return false;
            }
            return true;
        }
```

#### AUTO 


```{c}
const auto files = m_uiInterface->files();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Field &field : storage) {
        res.append(field.m_index);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QChar c : qAsConst(password)) {
        unsigned int num = (c.unicode() ^ 173) + 17;
        unsigned int a1 = (num & 0xFC00) >> 10;
        unsigned int a2 = (num & 0x3E0) >> 5;
        unsigned int a3 = (num & 0x1F);
        scrambled += QLatin1Char((char)(a1 + '0'));
        scrambled += QLatin1Char((char)(a2 + 'A'));
        scrambled += QLatin1Char((char)(a3 + '0'));
    }
```

#### AUTO 


```{c}
auto super = QAbstractItemModel::roleNames();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : args) {
        // get full path
        const QString fullFilePath(QDir::current().absoluteFilePath(file));

        // construct kconfig for protocol file
        KConfig sconfig(fullFilePath);
        sconfig.setLocale(QString());
        KConfigGroup config(&sconfig, "Protocol");

        // name must be set, sanity check that file got read
        const QString name(config.readEntry("protocol"));
        if (name.isEmpty()) {
            qFatal("Failed to read input file %s.", qPrintable(fullFilePath));
        }

        // construct protocol data
        QVariantMap protocolData;

        // convert the different types
        for (const QString &key : stringAttributes) {
            if (config.hasKey(key)) {
                protocolData.insert(key, config.readEntry(key, QString()));
            }
        }
        for (const QString &key : stringListAttributes) {
            if (config.hasKey(key)) {
                protocolData.insert(key, config.readEntry(key, QStringList()));
            }
        }
        for (const QString &key : boolAttributes) {
            if (config.hasKey(key)) {
                protocolData.insert(key, config.readEntry(key, bool(false)));
            }
        }
        for (const QString &key : intAttributes) {
            if (config.hasKey(key)) {
                protocolData.insert(key, config.readEntry(key, int(0)));
            }
        }

        // handle translated keys
        for (const QString &key : translatedStringListAttributes) {
            // read untranslated entry first in any case!
            sconfig.setLocale(QString());
            protocolData.insert(key, config.readEntry(key, QStringList()));

            // collect all locales for this key
            QFile f(fullFilePath);
            QStringList foundLocalesForKey;
            if (!f.open(QIODevice::ReadOnly | QIODevice::Text)) {
                qFatal("Failed to open file %s.", qPrintable(fullFilePath));
            }
            while (!f.atEnd()) {
                const QString line = QString::fromUtf8(f.readLine());
                const QRegularExpressionMatch match = localeRegex.match(line);
                if (match.hasMatch()) {
                    foundLocalesForKey.append(match.captured(1));
                }
            }

            // insert all entries for all found locales, reparse config for this
            for (const QString &locale : qAsConst(foundLocalesForKey)) {
                sconfig.setLocale(locale);
                protocolData.insert(QStringLiteral("%1[%2]").arg(key, locale), config.readEntry(key, QStringList()));
            }
        }

        // use basename of protocol for toplevel map in json, like it is done for .protocol files
        const QString baseName(QFileInfo(fullFilePath).baseName());
        protocolsData.insert(baseName, protocolData);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &tag : tagsList) {
        bookmark = KFilePlacesItem::createTagBookmark(bookmarkManager, tag);
        if (!bookmark.isNull()) {
            KFilePlacesItem *item = new KFilePlacesItem(bookmarkManager, bookmark.address(), tag, q);
            QObject::connect(item, &KFilePlacesItem::itemChanged, q, [this](const QString &id) {
                itemChanged(id);
            });
            items << item;
        }
    }
```

#### AUTO 


```{c}
auto *button
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &localFile : qAsConst(existingFiles)) {
        QFile file(dir.path() + '/' + localFile);
        QVERIFY(file.open(QIODevice::WriteOnly));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &_m : mimeTypes) {
                protocolMap[protocol].insert(_m, plugin);
                if (!_ms.contains(_m)) {
                    _ms.append(_m);
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &dir : dirs) {
        KFileItemList deletedItems;

        const QList<KFileItem> *itemList = kDirListerCache()->itemsForDir(dir);
        if (!itemList) {
            continue;
        }

        for (const auto &item : *itemList) {
            const QString text = item.text();
            if (text == QLatin1Char('.') || text == QLatin1String("..")) {
                continue;
            }
            const bool wasVisible = oldVisibleItems.find(item.name()) != oldVisibleItems.cend();
            const bool nowVisible = isItemVisible(item) && q->matchesMimeFilter(item);
            if (nowVisible && !wasVisible) {
                addNewItem(dir, item); // takes care of emitting newItem or itemsFilteredByMime
            } else if (!nowVisible && wasVisible) {
                deletedItems.append(item);
            }
        }
        if (!deletedItems.isEmpty()) {
            Q_EMIT q->itemsDeleted(deletedItems);
        }
        emitItems();
    }
```

#### AUTO 


```{c}
auto seekFillBuffer = [bufferSize](qint64 pos, QFile &f, QByteArray &buffer) {
        auto ioresult = f.seek(pos);
        int bytesRead;
        if (ioresult) {
            bytesRead = f.read(buffer.data(), bufferSize);
            ioresult = bytesRead != -1;
        }
        if (!ioresult) {
            qCWarning(KIO_WIDGETS) << "Could not read file for comparison:" << f.fileName();
            return false;
        }
        return true;
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const QNetworkCookie &cookie : cookieList) {
        QByteArray cookieHeader("Set-Cookie: ");
        if (d->isStorageDisabled && !cookie.isSessionCookie()) {
            QNetworkCookie sessionCookie(cookie);
            sessionCookie.setExpirationDate(QDateTime());
            cookieHeader += sessionCookie.toRawForm();
        } else {
            cookieHeader += cookie.toRawForm();
        }
        kcookiejar.call(QStringLiteral("addCookies"), url.toString(QUrl::RemoveUserInfo), cookieHeader, (qlonglong)d->windowId);
        //qDebug() << "[" << d->windowId << "]" << cookieHeader << " from " << url;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Task &task : qAsConst(outgoingTasks)) {
        q->sendnow(task.cmd, task.data);
    }
```

#### AUTO 


```{c}
auto err = execWithElevatedPrivilege(RENAME, {_src, _dest}, errno)
```

#### AUTO 


```{c}
auto job = KIO::mkdir(at);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &error : qAsConst(errors)) {
                errorString += QLatin1String("<li>") + error + QLatin1String("</li>");
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (KCoreDirLister *kdl : holders) {
        kdl->jobStarted(job);
        // do it like when starting a new list-job that will redirect later
        // TODO: maybe don't emit started if there's an update running for newUrl already?
        emit kdl->started(oldUrl);

        kdl->d->redirect(oldUrl, newUrl, false /*clear items*/);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KCoreDirLister *kdl : holders) {
                kdl->jobStarted(job);
                Q_EMIT kdl->started(dir);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job, qulonglong size) {
        _k_slotTotalSize(job, size);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KCoreDirLister *listit : holders) {
            list += QLatin1String(" 0x") + QString::number(reinterpret_cast<qlonglong>(listit), 16);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { _k_slotCreateDirectory(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &text) {
        slotLocationChanged(text);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
            if (d->m_pendingDragActivation.isValid()) {
                d->placeClicked(d->m_pendingDragActivation, &KFilePlacesView::placeActivated);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &criterion : requiredNumberOfUrls) {
                const int number = criterion.toInt();
                if (number < 1) {
                    continue;
                }

                if (urlList.count() == number) {
                    matchesAtLeastOneCriterion = true;
                    break;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : items) {
        Q_ASSERT(url.isValid());   // please call us with valid urls only
        fileItems.append(KFileItem(url));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, checkMaxTime] (const QString &fileName) {
        const auto trashFileInfo = getTrashFileInfo(fileName);
        if (!trashFileInfo.exists()) {
            return;
        }
        checkMaxTime(trashFileInfo.lastModified().toMSecsSinceEpoch());
    }
```

#### AUTO 


```{c}
auto func = [](const QString &name, const QString &type) {
            QVariant::Type variantType = QVariant::nameToType(type.toLatin1().constData());
            // currently QVariant::Type and ExtraField::Type use the same subset of values, so we can just cast.
            return KProtocolInfo::ExtraField(name, static_cast<KProtocolInfo::ExtraField::Type>(variantType));
        };
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { _k_slotAbortDialog(); }
```

#### AUTO 


```{c}
auto pru_it = pendingRemoteUpdates.find(tmp);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &meta : metalist) {
        const QStringList metadata = meta.split(QLatin1Char('='));
        Q_ASSERT(metadata.count() == 2);
        exp_attrs[metadata[0]] = metadata[1];
    }
```

#### AUTO 


```{c}
const auto &mountPoint
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob * job) {
        emit d->q->error(job->error(), job->errorString());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[d]() {
        d->slotStart();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QModelIndex index) {
            d->slotExpandToUrl(index);
        }
```

#### CONST EXPRESSION 


```{c}
static constexpr int KJOB_NO_ERROR = static_cast<int>(KJob::NoError);
```

#### AUTO 


```{c}
auto window = qGuiApp->focusWindow();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &row : mapping) {
        const QStringList locations = QStandardPaths::standardLocations(row.location);
        for (const QString &location : locations) {
            map.insert(location, row.name);
        }
        // Qt does not provide an easy way to receive the xdg dir for the templates and public directory so we have to find it on our own (QTBUG-86106 and QTBUG-78092)
#if QT_VERSION < QT_VERSION_CHECK(6, 4, 0)
#ifdef Q_OS_UNIX
        const QString xdgUserDirs = QStandardPaths::locate(QStandardPaths::ConfigLocation, QStringLiteral("user-dirs.dirs"), QStandardPaths::LocateFile);
        QFile xdgUserDirsFile(xdgUserDirs);
        if (!xdgUserDirs.isEmpty() && xdgUserDirsFile.open(QIODevice::ReadOnly | QIODevice::Text)) {
            QTextStream in(&xdgUserDirsFile);
            const QLatin1String templatesLine("XDG_TEMPLATES_DIR=\"");
            const QLatin1String publicShareLine("XDG_PUBLICSHARE_DIR=\"");
            while (!in.atEnd()) {
                const QString line = in.readLine();
                if (line.startsWith(templatesLine)) {
                    QString xdgTemplates = line.mid(templatesLine.size()).chopped(1);
                    xdgTemplates.replace(QStringLiteral("$HOME"), QDir::homePath());
                    map.insert(xdgTemplates, QStringLiteral("folder-templates"));
                } else if (line.startsWith(publicShareLine)) {
                    QString xdgPublicShare = line.mid(publicShareLine.size()).chopped(1);
                    xdgPublicShare.replace(QStringLiteral("$HOME"), QDir::homePath());
                    map.insert(xdgPublicShare, QStringLiteral("folder-public"));
                }
            }
        }
#endif
#endif
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QSslError &err : std::as_const(ud->sslErrors)) {
        message.append(err.errorString() + QLatin1Char('\n'));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KCoreDirLister *kdl : allListers) {
            if (kdl->d->rootFileItem.isNull() && kdl->d->url == newUrl) {
                kdl->d->rootFileItem = newDir->rootItem;
            }

            kdl->d->addNewItems(newUrl, newDir->lstItems);
            kdl->d->emitItems();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &fileFromDisk : fromDisk) {
        if (auto [_, inserted] = uniqueFileNames.insert(fileFromDisk.split(QLatin1Char('/')).last()); inserted) {
            filePaths << fileFromDisk;
        }
    }
```

#### AUTO 


```{c}
auto job = KIO::move(items, to);
```

#### AUTO 


```{c}
const auto result = KMessageBox::questionYesNo(nullptr,
                                                   i18n("The file %1\nhas been modified. Do you want to upload the changes?", dest.toDisplayString()),
                                                   i18n("File Changed"),
                                                   KGuiItem(i18n("Upload")),
                                                   KGuiItem(i18n("Do Not Upload")));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &s : list) {
        qCDebug(KIO_HTTP) << s;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&app, fileWidget]() {
        qDebug() << "accepted";
        fileWidget->accept();
        qDebug() << "Selected File:" << fileWidget->selectedFile();
        qDebug() << "Selected Url:" << fileWidget->selectedUrl();
        qDebug() << "Selected Files:" << fileWidget->selectedFiles();
        qDebug() << "Selected Urls:" << fileWidget->selectedUrls();
        app.exit();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->initDeviceList();
    }
```

#### AUTO 


```{c}
auto srcAttrs = readXattr(src);
```

#### AUTO 


```{c}
const auto kend = item->lstItems.constEnd();
```

#### AUTO 


```{c}
const auto result = d->openConnection();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            updateContent();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &service : qAsConst(m_providers)) {
        QString tmp = propertyToString(service, QStringLiteral("X-KDE-UA-FULL"));

        if (service->property(QStringLiteral("X-KDE-UA-DYNAMIC-ENTRY")).toBool()) {
            tmp.replace(QLatin1String("appSysName"), QSysInfo::productType());
            tmp.replace(QLatin1String("appSysRelease"), QSysInfo::kernelVersion());
            tmp.replace(QLatin1String("appMachineType"), QSysInfo::currentCpuArchitecture());

            QStringList languageList = QLocale().uiLanguages();
            if (!languageList.isEmpty()) {
                int ind = languageList.indexOf(QLatin1String("C"));
                if (ind >= 0) {
                    if (languageList.contains(QLatin1String("en"))) {
                        languageList.removeAt(ind);
                    } else {
                        languageList.value(ind) = QStringLiteral("en");
                    }
                }
            }

            tmp.replace(QLatin1String("appLanguage"), languageList.join(QLatin1String(", ")));
            tmp.replace(QLatin1String("appPlatform"), QLatin1String("X11"));
        }

        // Ignore dups...
        if (m_lstIdentity.contains(tmp)) {
            continue;
        }

        m_lstIdentity << tmp;

        tmp = QLatin1String("%1 %2").arg(propertyToString(service, QStringLiteral("X-KDE-UA-SYSNAME")),
                                         propertyToString(service, QStringLiteral("X-KDE-UA-SYSRELEASE")));
        if (tmp.trimmed().isEmpty()) {
            tmp = QLatin1String("%1 %2").arg(propertyToString(service, QStringLiteral("X-KDE-UA-NAME")),
                                             propertyToString(service, QStringLiteral("X-KDE-UA-VERSION")));
        } else {
            tmp = QLatin1String("%1 %2 on %3").arg(propertyToString(service, QStringLiteral("X-KDE-UA-NAME")), (QStringLiteral("X-KDE-UA-VERSION")), tmp);
        }

        m_lstAlias << tmp;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &domain : std::as_const(m_domainList)) {
        KCookieAdvice advice = getDomainAdvice(domain);
        if (advice != KCookieDunno) {
            const QString value = domain + QLatin1Char(':') + adviceToStr(advice);
            domainSettings.append(value);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](int value) { d->_k_slotStepAnimation(value); }
```

#### LAMBDA EXPRESSION 


```{c}
[this, messageWidget] {
            const QUrl resolvedTargetLocation = properties->item().url().resolved(QUrl(d->m_linkTargetLineEdit->text()));

            KIO::StatJob *statJob = KIO::stat(resolvedTargetLocation, KIO::StatJob::SourceSide, KIO::StatNoDetails, KIO::HideProgressInfo);
            connect(statJob, &KJob::finished, this, [this, statJob, messageWidget] {
                if (statJob->error()) {
                    messageWidget->setText(statJob->errorString());
                    messageWidget->animatedShow();
                    return;
                }

                KIO::highlightInFileManager({statJob->url()});
                properties->close();
            });
        }
```

#### AUTO 


```{c}
const auto [it, isInserted] = digests.insert(digest);
```

#### AUTO 


```{c}
auto dialogFinished = [this, filePath, service](bool shouldExecute) {
                    if (shouldExecute) { // Run the file
                        startService(service, {});
                        return;
                    }
                    // The user selected "open"
                    openInPreferredApp();
                };
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &bcc : std::as_const(d->m_bcc)) {
        query.addQueryItem(QStringLiteral("bcc"), bcc);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString plugin : blacklist) {
        defaultPlugins.removeAll(plugin);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KCoreDirLister *kdl : holders) {
        kdl->d->redirect(oldUrl, newUrl, true /*keep items*/);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KMountPoint::Ptr &mp : *this) {
        const QString mountpoint = mp->d->m_mountPoint;
        const int length = mountpoint.length();
        if (length > max && pathsAreParentAndChildOrEqual(mountpoint, realname)) {
            max = length;
            result = mp;
            // keep iterating to check for a better match (bigger max)
        }
    }
```

#### AUTO 


```{c}
const auto &[oldItem, newItem]
```

#### LAMBDA EXPRESSION 


```{c}
[&] {
        QVERIFY(QFile::remove(sourceFile));
        QVERIFY(QFile::remove(dest));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *widget : widgetsList) {
            if (QMenu *menu = qobject_cast<QMenu *>(widget)) {
                return menu;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &metaData : plugins) {
        const QString serviceName = metaData.value(QStringLiteral("X-KDE-DBus-ServiceName"));
        if (serviceName.isEmpty()) {
            qCWarning(KIOD_CATEGORY) << "No X-KDE-DBus-ServiceName found in" << metaData.fileName();
            continue;
        }
        if (!bus->registerService(serviceName)) {
            qCWarning(KIOD_CATEGORY) << "Couldn't register name" << serviceName << "with DBUS - another process owns it already!";
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &dir : std::as_const(installedTemplates)) {
            s->dirWatch->addDir(dir);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[widget](const QString &errorString) {
        QEventLoopLocker locker;
        KMessageBox::sorry(widget, errorString);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { _k_delayedSlotTextChanged(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &info : uniqueEntries) {
        instance->templatesList->append(info.entry);
    }
```

#### AUTO 


```{c}
auto it = std::find_if(m_stdIconSizes.crbegin(), r_itEnd,
                 [currValue](KIconLoader::StdSizes size) { return size < currValue; });
```

#### RANGE FOR STATEMENT 


```{c}
for (const QSslError &error : errors) {
        if (!isErrorIgnored(error.error())) {
            d->ignoredErrors.append(error.error());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KSslCaCertificate &cert : ret) {
        if (group.hasKey(cert.certHash.constData())) {
            cert.isBlacklisted = true;
            // qDebug() << "is blacklisted";
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QModelIndex &index) {
        d->headerAreaEntered(index);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](RenameDialog_Result result, const QUrl &newUrl, KJob *parentJob) {
                        Q_ASSERT(parentJob == q);
                        // Only receive askUserRenameResult once per rename dialog
                        QObject::disconnect(askUserActionInterface, renameSignal, q, nullptr);

                        processDirectRenamingConflictResult(result, isDir, destIsDir, mtimeSrc, mtimeDest, dest, newUrl);
                    }
```

#### AUTO 


```{c}
auto it = values.cbegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QChar ch : std::as_const(d->m_text_start)) {
        if (ch != d->m_word_break_char) {
            is_exe_completion = false;
            break;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d_func()->slotIODeviceClosedBeforeStart(); }
```

#### LAMBDA EXPRESSION 


```{c}
[&](const KService::Ptr &serv) {
            return !excludedDesktopEntryNames.contains(serv->desktopEntryName());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (KMountPoint::Ptr mountPoint : mountPoints) {
        qDebug() << "Mount: " << mountPoint->mountedFrom()
                 << " (" << mountPoint->realDeviceName() << ") "
                 << mountPoint->mountPoint() << " " << mountPoint->mountType();
        QVERIFY(!mountPoint->mountedFrom().isEmpty());
        QVERIFY(!mountPoint->mountPoint().isEmpty());
        QVERIFY(!mountPoint->mountType().isEmpty());
        // old bug, happened because KMountPoint called KStandardDirs::realPath instead of realFilePath
        if (mountPoint->realDeviceName().startsWith(QLatin1String("/dev"))) { // skip this check for cifs mounts for instance
            QVERIFY(!mountPoint->realDeviceName().endsWith('/'));
        }

        // keep one (any) mountpoint with a device name for the test below
        if (!mountPoint->realDeviceName().isEmpty() && !mountWithDevice) {
            mountWithDevice = mountPoint;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, dialog](int result){
                         onDialogFinished(result, dialog->isDontAskAgainChecked());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {_k_slotAccepted();}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QChar c : std::as_const(password)) {
        unsigned int num = (c.unicode() ^ 173) + 17;
        unsigned int a1 = (num & 0xFC00) >> 10;
        unsigned int a2 = (num & 0x3E0) >> 5;
        unsigned int a3 = (num & 0x1F);
        scrambled += QLatin1Char((char)(a1 + '0'));
        scrambled += QLatin1Char((char)(a2 + 'A'));
        scrambled += QLatin1Char((char)(a3 + '0'));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[outerFuture](X val) mutable {
                outerFuture.succeed("andThen", val);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[&](const char *token, const QStringList &list) {
        if (!list.isEmpty()) {
            arg += QLatin1String(token) + quote + list.join(QLatin1Char(',')) + quote;
        }
    }
```

#### AUTO 


```{c}
const auto match = bangRegex.match(typedString);
```

#### LAMBDA EXPRESSION 


```{c}
[=](QDBusPendingCallWatcher *watcher) {
        QDBusPendingReply<void> reply = *watcher;
        watcher->deleteLater();

        if (reply.isError()) {
            // Try the KRun strategy as fallback, also calls emitResult inside
            AbstractOpenFileManagerWindowStrategy *kRunStrategy = m_job->d->createKRunStrategy();
            kRunStrategy->start(urls, asn);
            return;
        }

        emitResultProxy();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&entriesListed](KIO::Job *, const KIO::UDSEntryList &entries) {
            entriesListed += entries.size();
            qDebug() << "Listed" << entriesListed << "files.";
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &dir : dirs) {
        KFileItemList deletedItems;

        const QList<KFileItem> *itemList = kDirListerCache()->itemsForDir(dir);
        if (!itemList) {
            continue;
        }

        auto kit = itemList->begin();
        const auto kend = itemList->end();
        for (; kit != kend; ++kit) {
            const KFileItem &item = *kit;
            const QString text = item.text();
            if (text == QLatin1Char('.') || text == QLatin1String("..")) {
                continue;
            }
            const bool wasVisible = oldVisibleItems.contains(item.name());
            const bool nowVisible = isItemVisible(item) && m_parent->matchesMimeFilter(item);
            if (nowVisible && !wasVisible) {
                addNewItem(dir, item);    // takes care of emitting newItem or itemsFilteredByMime
            } else if (!nowVisible && wasVisible) {
                deletedItems.append(*kit);
            }
        }
        if (!deletedItems.isEmpty()) {
            emit m_parent->itemsDeleted(deletedItems);
        }
        emitItems();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &src : qAsConst(lst)) {
        QMap<QString, QString>::ConstIterator it = metaData.find("trashURL-" + src.path());
        QVERIFY(it != metaData.constEnd());
        trashUrls.append(QUrl(it.value()));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QStringList &urlList) { d->_k_slotJobUrlsChanged(urlList); }
```

#### AUTO 


```{c}
auto it = std::remove_if(m_pendingItems.begin(), m_pendingItems.end(), [&item](const KFileItem &pending) {
            return pending.url() == item.url();
        });
```

#### RANGE FOR STATEMENT 


```{c}
for (const QSslCertificate &cert : list) {
        ret += KSslCaCertificate(cert, KSslCaCertificate::SystemStore, false);
    }
```

#### AUTO 


```{c}
auto result = ftpOpenConnection(LoginMode::Implicit);
```

#### CONST EXPRESSION 


```{c}
static constexpr int s_maxDirHistory = 3;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& serviceId : serviceIdList) {
        KFileItemList serviceItems;
        for (const KFileItem &item : fileItems) {
            const KService::Ptr serv = preferredService(item.mimetype(), m_traderConstraint);
            const QString preferredServiceId = serv ? serv->storageId() : QString();
            if (preferredServiceId == serviceId) {
                serviceItems << item;
            }
        }

        if (serviceId.isEmpty()) { // empty means: no associated app for this mimetype
            openWithByMime(serviceItems);
            continue;
        }

        const KService::Ptr servicePtr = KService::serviceByStorageId(serviceId);
        if (!servicePtr) {
            KRun::displayOpenWithDialog(serviceItems.urlList(), m_parentWidget);
            continue;
        }
        KRun::runApplication(*servicePtr, serviceItems.urlList(), m_parentWidget);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &protocol : protocols) {
        // Check that hasSchemeHandler will return true
        QVERIFY(!KProtocolInfo::isKnownProtocol(protocol));
        QVERIFY(!KProtocolInfo::isHelperProtocol(protocol));
        QVERIFY(KMimeTypeTrader::self()->preferredService(QLatin1String("x-scheme-handler/") + protocol));

        const QList<QUrl> urls({QUrl(QStringLiteral("%1://root@10.1.1.1").arg(protocol))});
        KIO::DesktopExecParser parser(*service, urls);
        QCOMPARE(KShell::joinArgs(parser.resultingArguments()),
                 QStringLiteral("%1 %2://root@10.1.1.1").arg(ktelnetExec, protocol));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KUrlNavigatorButton *button : qAsConst(m_navButtons)) {
        button->hide();
        button->deleteLater();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KIO::Job *job, const QString &type) {
            slotMimetype(job, type);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : urlList) {
            urls += QStringLiteral("\"%1\"").arg(relativePathOrUrl(currUrl, url)) + QLatin1Char(' ');
        }
```

#### AUTO 


```{c}
const auto trashFileInfo = getTrashFileInfo(fileName);
```

#### LAMBDA EXPRESSION 


```{c}
[=](KIO::Job *, const QString &mimetype) {
        if (m_followRedirections) { // Update our URL in case of a redirection
            m_url = job->url();
        }
        if (mimetype.isEmpty()) {
            qCWarning(KIO_CORE) << "get() didn't emit a MIME type! Probably a kioslave bug, please check the implementation of" << m_url.scheme();
        }
        m_mimeTypeName = mimetype;

        // If the current MIME type is the default MIME type, then attempt to
        // determine the "real" MIME type from the file name (bug #279675)
        const QMimeType mime = fixupMimeType(m_mimeTypeName, m_suggestedFileName.isEmpty() ? m_url.fileName() : m_suggestedFileName);
        if (mime.isValid()) {
            m_mimeTypeName = mime.name();
        }

        if (m_suggestedFileName.isEmpty()) {
            m_suggestedFileName = job->queryMetaData(QStringLiteral("content-disposition-filename"));
        }

        q->emitResult();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
            updateDefaultHandler(d->mimeType);
        }
```

#### IF STATEMENT WITH INITIALIZER 


```{c}
if (const QDateTime dt = firstItem.time(KFileItem::AccessTime); !dt.isNull()) {
            d->m_ui->accessTimeLabel->setText(locale.toString(dt, QLocale::LongFormat));
        } else {
            d->m_ui->accessTimeLabel->hide();
            d->m_ui->accessTimeLabel_Left->hide();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job, qulonglong _size) {
        slotTotalSize(job, _size);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &base : dirs) {
        QDir base_dir = QDir(base);
        if (base_dir.exists() && absolute.startsWith(base_dir.canonicalPath())) {
            return absolute.mid(base.length() + 1);
        }
    }
```

#### AUTO 


```{c}
auto dialogFinished = [this, localPath, isNativeBinary](bool shouldExecute) {
            if (shouldExecute) {
                if (isNativeBinary) {
                    if (!hasExecuteBit(localPath)) {
                        showUntrustedProgramWarningDialog(localPath);
                        return;
                    }
                    executeCommand(); // Local executable with execute bit, proceed
                } else { // For .exe files, open in the default app (e.g. WINE)
                    openInPreferredApp();
                }
            }
        };
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        clipboard->setText(d->m_sha256);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& key : keys)
  {
    if (key.length() > name.length())
      name = key.toLower();
  }
```

#### AUTO 


```{c}
auto it = opQueue.rbegin();
```

#### AUTO 


```{c}
auto dcc = connect(m_dirModel, &KDirModel::dataChanged, this, [&dataChangedAtFirstLevel](const QModelIndex &index) {
        if (index.isValid() && !index.parent().isValid()) {
            // a change of a node whose parent is root, yay, that's it
            dataChangedAtFirstLevel = true;
        }
    });
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &dirtyUrl : qAsConst(dirtyUrls)) {
        if (KDirModelNode *node = nodeForUrl(QUrl(dirtyUrl))) {
            const QModelIndex idx = indexForNode(node);
            Q_EMIT q->dataChanged(idx, idx, {KDirModel::HasJobRole});
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &domain : domainList) {
            const KHttpCookieList *list =  mCookieJar->getCookieList(domain, fqdn);
            if (!list) {
                continue;
            }
            for (const KHttpCookie &cookie : *list) {
                if (cookie.isExpired()) {
                    continue;
                }
                putCookie(result, cookie, fields);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QSslCertificate &cert : std::as_const(ud->certificateChain)) {
                QList<QSslError::SslError> errors;
                for (const QSslError &error : std::as_const(ud->sslErrors)) {
                    if (error.certificate() == cert) {
                        // we keep only the error code enum here
                        errors.append(error.error());
                    }
                }
                meh.append(errors);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this](uint jobId, const QDBusObjectPath &jobPath, const QString &unitName, const QString &result) {
                Q_UNUSED(jobId)
                if (jobPath.path() == m_jobPath && unitName == m_serviceName && result != QLatin1String("done")) {
                    qCWarning(KIO_GUI) << "Failed to launch process as service:" << m_serviceName << ", result " << result;
                    // result=failed is not a fatal error, service is actually created in this case
                    if (result != QLatin1String("failed")) {
                        systemdError(result);
                    }
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Task &task) {
            commandReceived(task);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](qreal value) {
        d->adaptItemsUpdate(value);
    }
```

#### AUTO 


```{c}
const auto sslConfig = reply->sslConfiguration();
```

#### LAMBDA EXPRESSION 


```{c}
[this, job, dlg](const int exitCode) {
        KIO::RenameDialog_Result result = static_cast<RenameDialog_Result>(exitCode);
        const QUrl newUrl = result == Result_AutoRename ? dlg->autoDestUrl() : dlg->newDestUrl();
        Q_EMIT askUserRenameResult(result, newUrl, job);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &s : sl) {
        QList<QSslError::SslError> certErrors;
        const QStringList sl2 = s.split(QLatin1Char('\t'), QString::SkipEmptyParts);
        for (const QString &s2 : sl2) {
            bool didConvert;
            QSslError::SslError error = static_cast<QSslError::SslError>(s2.toInt(&didConvert));
            if (didConvert) {
                certErrors.append(error);
            }
        }
        ret.append(certErrors);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Task &task : std::as_const(outgoingTasks)) {
        q->sendnow(task.cmd, task.data);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        const int errCode = job->error();
        if (errCode) {
            // ERR_NO_CONTENT is not an error, but an indication no further
            // actions needs to be taken.
            if (errCode != KIO::ERR_NO_CONTENT) {
                q->setError(errCode);
                q->setErrorText(KIO::buildErrorString(errCode, job->errorText()));
            }
            q->emitResult();
            return;
        }
        if (m_followRedirections) { // Update our URL in case of a redirection
            m_url = job->url();
        }

        const KIO::UDSEntry entry = job->statResult();

        const QString localPath = entry.stringValue(KIO::UDSEntry::UDS_LOCAL_PATH);
        if (!localPath.isEmpty()) {
            m_url = QUrl::fromLocalFile(localPath);
        }

        // mimetype already known? (e.g. print:/manager)
        m_mimeTypeName = entry.stringValue(KIO::UDSEntry::UDS_MIME_TYPE);
        if (!m_mimeTypeName.isEmpty()) {
            runUrlWithMimeType();
            return;
        }

        const mode_t mode = entry.numberValue(KIO::UDSEntry::UDS_FILE_TYPE);
        if ((mode & QT_STAT_MASK) == QT_STAT_DIR) { // it's a dir
            m_mimeTypeName = QStringLiteral("inode/directory");
            runUrlWithMimeType();
        } else { // it's a file
            // Start the timer. Once we get the timer event this
            // protocol server is back in the pool and we can reuse it.
            // This gives better performance than starting a new slave
            QTimer::singleShot(0, q, [this] { scanFileWithGet(); });
        }
    }
```

#### AUTO 


```{c}
auto path = it;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &path : std::as_const(search)) {
        // qDebug() << "Looking for help in: " << path;

        QFileInfo info(path);
        if (info.exists() && info.isFile() && info.isReadable()) {
            return path;
        }

        if (path.endsWith(QLatin1String(".html"))) {
            const QString file = path.leftRef(path.lastIndexOf(QLatin1Char('/'))) + QLatin1String("/index.docbook");
            // qDebug() << "Looking for help in: " << file;
            info.setFile(file);
            if (info.exists() && info.isFile() && info.isReadable()) {
                return path;
            }
        }
    }
```

#### AUTO 


```{c}
auto createUrl = [](const QString &path) -> QUrl {
        return QUrl::fromLocalFile(homeTmpDir() + path);
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (KCoreDirLister *kdl : std::as_const(listersToRefresh)) {
        // For a directory, look for dirlisters where it's the root item.
        QUrl directoryUrl(oldItem.url());
        if (oldItem.isDir() && kdl->d->rootFileItem == oldItem) {
            const KFileItem oldRootItem = kdl->d->rootFileItem;
            kdl->d->rootFileItem = fileitem;
            kdl->d->addRefreshItem(directoryUrl, oldRootItem, fileitem);
        } else {
            directoryUrl = directoryUrl.adjusted(QUrl::RemoveFilename | QUrl::StripTrailingSlash);
            kdl->d->addRefreshItem(directoryUrl, oldItem, fileitem);
        }
    }
```

#### AUTO 


```{c}
auto reply = execAction.execute();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : urls) {
        QUrl newUrl = url;
        newUrl.setPath(url.path() + QLatin1String("_renamed"));
        KIO::SimpleJob *job = KIO::rename(url, newUrl, KIO::HideProgressInfo);
        QVERIFY2(job->exec(), qPrintable(job->errorString()));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QModelIndex &index) {
        QSignalSpy completedSpy(m_dirModel->dirLister(), QOverload<>::of(&KDirLister::completed));
        m_dirModel->fetchMore(index);
        return completedSpy.wait();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QUrl &, const QUrl &newUrl) { d->slotRedirected(newUrl); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &key : keysChanged)
   {
      AuthInfoContainerList *authList = m_authDict.value(key);
      if (!authList)
         continue;

      QMutableListIterator<AuthInfoContainer*> it (*authList);
      while (it.hasNext())
      {
        AuthInfoContainer* current = it.next();
        if (current->expire == AuthInfoContainer::expWindowClose)
        {
           if (current->windowList.removeAll(windowId) && current->windowList.isEmpty())
           {
              delete current;
              it.remove();
           }
        }
      }
   }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool show) {
        d->toggleBookmarks(show);
    }
```

#### LAMBDA EXPRESSION 


```{c}
do {
        return copy({"5"_hc, "6"_hc, "7"_hc, "8"_hc}, ""_rc);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const TrashedFileInfo &fileInfo : lst) {
        const QUrl url = TrashImpl::makeURL(fileInfo.trashId, fileInfo.fileId, QString());
        entry.clear();
        const QString fileDisplayName = fileInfo.fileId;

        if (createUDSEntry(fileInfo.physicalPath, fileDisplayName, url.fileName(), entry, fileInfo)) {
            listEntry(entry);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const char *mimeType : {"text/plain", "application/x-shellscript"}) {
        KService::Ptr preferredTextEditor = KApplicationTrader::preferredService(QString::fromLatin1(mimeType));
        QVERIFY(preferredTextEditor);
        QCOMPARE(preferredTextEditor->entryPath(), m_fakeService);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &source : sources) {
        if (moveDirs) {
            QVERIFY(QDir().mkdir(source));
            createTestFile(source + "/innerfile");
            createTestFile(source + "/innerfile2");
        } else {
            createTestFile(source);
        }
    }
```

#### AUTO 


```{c}
auto plugin = KPluginFactory::instantiatePlugin<KPreviewWidgetBase>(data, parent).plugin
```

#### AUTO 


```{c}
const auto suffix = QStringView(cmd).mid(lastIndex);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &item : std::as_const(m_pendingItems)) {
            if (item.isMimeTypeKnown()) {
                m_resolvedMimeTypes.append(item);
            }
        }
```

#### AUTO 


```{c}
auto lit = dirItem->lstItems.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &str : qAsConst(m_responseHeaders)) {
        const QString header = str.trimmed();
        if (header.startsWith(QLatin1String("content-type:"), Qt::CaseInsensitive)) {
            int pos = header.indexOf(QLatin1String("charset="), Qt::CaseInsensitive);
            if (pos != -1) {
                const QString charset = header.mid(pos + 8).toLower();
                m_request.cacheTag.charset = charset;
                setMetaData(QStringLiteral("charset"), charset);
            }
        } else if (header.startsWith(QLatin1String("content-language:"), Qt::CaseInsensitive)) {
            const QString language = header.mid(17).trimmed().toLower();
            setMetaData(QStringLiteral("content-language"), language);
        } else if (header.startsWith(QLatin1String("content-disposition:"), Qt::CaseInsensitive)) {
            parseContentDisposition(header.mid(20).toLower());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &deletedUrl : qAsConst(affectedItems)) {
        // stop all jobs for deletedUrlStr
        DirectoryDataHash::iterator dit = directoryData.find(deletedUrl);
        if (dit != directoryData.end()) {
            // we need a copy because stop modifies the list
            const QList<KCoreDirLister *> listers = (*dit).listersCurrentlyListing;
            for (KCoreDirLister *kdl : listers) {
                stopListingUrl(kdl, deletedUrl);
            }
            // tell listers holding deletedUrl to forget about it
            // this will stop running updates for deletedUrl as well

            // we need a copy because forgetDirs modifies the list
            const QList<KCoreDirLister *> holders = (*dit).listersCurrentlyHolding;
            for (KCoreDirLister *kdl : holders) {
                // lister's root is the deleted item
                if (kdl->d->url == deletedUrl) {
                    // tell the view first. It might need the subdirs' items (which forgetDirs will delete)
                    if (!kdl->d->rootFileItem.isNull()) {
                        Q_EMIT kdl->itemsDeleted(KFileItemList{kdl->d->rootFileItem});
                    }
                    forgetDirs(kdl);
                    kdl->d->rootFileItem = KFileItem();
                } else {
                    const bool treeview = kdl->d->lstDirs.count() > 1;
                    if (!treeview) {
                        Q_EMIT kdl->clear();
                        kdl->d->lstDirs.clear();
                    } else {
                        kdl->d->lstDirs.removeAll(deletedUrl);
                    }

                    forgetDirs(kdl, deletedUrl, treeview);
                }
            }
        }

        // delete the entry for deletedUrl - should not be needed, it's in
        // items cached now
        int count = itemsInUse.remove(deletedUrl);
        Q_ASSERT(count == 0);
        Q_UNUSED(count);   //keep gcc "unused variable" complaining quiet when in release mode
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KIO::filesize_t size) {
        slotTotalSize(size);
    }
```

#### AUTO 


```{c}
const auto &dirUrl
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &item : qAsConst(d->items)) {
            const QString extension = db.suffixForFileName(item.name());

            if (extensions.contains(extension)) {
                d->allExtensionsDifferent = false;
                break;
            }

            extensions.insert(extension);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (KCoreDirLister *kdl : qAsConst(curHolders)) {    // holders of newUrl
                kdl->jobStarted(job);
                Q_EMIT kdl->started(newUrl);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &to : std::as_const(d->m_to)) {
        if (url.path().isEmpty()) {
            url.setPath(to);
        } else {
            query.addQueryItem(QStringLiteral("to"), to);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->slotSelectionChanged();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QUrl &url, Qt::MouseButton btn, Qt::KeyboardModifiers modifiers) {
                    slotNavigatorButtonClicked(url, btn, modifiers);
                }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
                        QEventLoopLocker locker;
                        KMessageBox::sorry(nullptr, error);
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KService::Ptr &ptr : offers) {
        if (addedPlugins.contains(ptr->desktopEntryName())) {
            continue;
        }
        qCWarning(KIO_WIDGETS) << "Plugin" << ptr->desktopEntryName() << "is using the deprecated loading style. Please port it to JSON loading.";
        KPropertiesDialogPlugin *plugin = ptr->createInstance<KPropertiesDialogPlugin>(q);
        if (!plugin) {
            continue;
        }
        plugin->setObjectName(ptr->name());

        q->insertPlugin(plugin);
        addedPlugins.append(ptr->desktopEntryName());
    }
```

#### AUTO 


```{c}
auto firstSubdirIndex = [this](const QModelIndex &parentIndex) {
        for (int row = 0; row < m_dirModel->rowCount(parentIndex); ++row) {
            QModelIndex idx = m_dirModel->index(row, 0, parentIndex);
            if (m_dirModel->itemForIndex(idx).isDir()) {
                return idx;
            }
        }
        return QModelIndex();
    };
```

#### AUTO 


```{c}
auto acceptButton = KGuiItem(buttonYes, iconYes);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : urls) {
        KFileItem item = d->m_dirLister->findByUrl(url);
        if (d->m_shouldFetchForItems && item.isNull()) {
            d->m_itemsToBeSetAsCurrent << url;

            if (d->m_viewKind == KFile::DetailTree) {
                d->m_dirModel->expandToUrl(url);
            }

            continue;
        }

        itemList << item;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&thumbRootMount] (KMountPoint::Ptr mount) {
                     return (thumbRootMount != mount) &&
                            (mount->mountType() == QLatin1String("fuse.cryfs") ||
                             mount->mountType() == QLatin1String("fuse.encfs"));
                 }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        _k_slotUpdateUrl();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
                        startProcess();
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &filter : list) {
                QString match = findMatchingFilter(filter, filename);
                if (!match.isEmpty()) {
                    if (match != QLatin1String("*")) {   // never match the catch-all filter
                        m_filterWidget->setCurrentFilter(filter);
                    }
                    return; // do not repeat, could match a later filter
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob* job, const QString &text) { _k_slotWarning(job, text); }
```

#### LAMBDA EXPRESSION 


```{c}
[u, &urls](const QString &partial_name) {
        if (partial_name.trimmed().isEmpty()) {
            return;
        }

        // We have to use setPath here, so that something like "test#file"
        // isn't interpreted to have path "test" and fragment "file".
        QUrl partial_url;
        partial_url.setPath(partial_name);

        // This returns QUrl(partial_name) for absolute URLs.
        // Otherwise, returns the concatenated url.
        const QUrl finalUrl = u.resolved(partial_url);

        if (finalUrl.isValid()) {
            urls.append(finalUrl);
        } else {
            // This can happen in the first quote! (ex: ' "something here"')
            qCDebug(KIO_KFILEWIDGETS_FW) << "Discarding Invalid" << finalUrl;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &protocol : std::as_const(m_protocols)) {
        if (m_categories.contains(protocol)) {
            const ProtocolCategory category = m_categories.value(protocol);
            items[category].append(protocol);
        } else {
            items[OtherCategory].append(protocol);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &domain : std::as_const(m_domainList)) {
        eatSessionCookies(domain, windowId, false);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KSslError::Error error : errors) {
        if (!isErrorIgnored(error)) {
            ret.append(error);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KUrlNavigatorButton *button : qAsConst(d->m_navButtons)) {
            button->setShowMnemonic(true);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        Q_EMIT q->historyChanged();
    }
```

#### AUTO 


```{c}
const auto group = config.group(trashPath);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QNetworkCookie &cookie : cookieList) {
        QByteArray cookieHeader("Set-Cookie: ");
        if (d->isStorageDisabled && !cookie.isSessionCookie()) {
            QNetworkCookie sessionCookie(cookie);
            sessionCookie.setExpirationDate(QDateTime());
            cookieHeader += sessionCookie.toRawForm();
        } else {
            cookieHeader += cookie.toRawForm();
        }
        kcookiejar.call(QStringLiteral("addCookies"), url.toString(QUrl::RemoveUserInfo), cookieHeader, (qlonglong)d->windowId);
        // qDebug() << "[" << d->windowId << "]" << cookieHeader << " from " << url;
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr int DEFAULT_KEEP_ALIVE_TIMEOUT = 60;
```

#### LAMBDA EXPRESSION 


```{c}
[this](qint64 pid) {
                d->slotStarted(pid);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &src : m_urls) {
            if (!m_destUrl.matches(src.adjusted(QUrl::RemoveFilename), QUrl::StripTrailingSlash)) {
                equalDestination = false;
                break;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](int value) {
        m_iconSizeSlider->setValue(value);
        m_zoomOutAction->setDisabled(value <= m_iconSizeSlider->minimum());
        m_zoomInAction->setDisabled(value >= m_iconSizeSlider->maximum());
    }
```

#### AUTO 


```{c}
auto job = KIO::copy({QUrl::fromLocalFile(testCopy1)}, url, KIO::DefaultFlags);
```

#### LAMBDA EXPRESSION 


```{c}
[destFileExists, destPartFile](KJob *job, qulonglong totalSize) {
        Q_UNUSED(job);
        Q_UNUSED(totalSize);
        QCOMPARE(destFileExists,  QFile::exists(destPartFile));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &folder : std::as_const(folders)) {
                    label.append(QLatin1Char('\n'));
                    label.append(indentation);
                    label.append(folder);
                    label.append(QStringLiteral("/"));
                    indentation.append(QStringLiteral("    "));
                }
```

#### CONST EXPRESSION 


```{c}
static constexpr int s_saveDelay = 3;
```

#### IF STATEMENT WITH INITIALIZER 


```{c}
if (auto [_, inserted] = uniqueFileNames.insert(fileFromDisk.split(QLatin1Char('/')).last()); inserted) {
            filePaths << fileFromDisk;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, checkMaxTime](const QString &fileName) {
        const auto trashFileInfo = getTrashFileInfo(fileName);
        if (!trashFileInfo.exists()) {
            return;
        }
        checkMaxTime(trashFileInfo.lastModified().toMSecsSinceEpoch());
    }
```

#### AUTO 


```{c}
auto it = staticUserCache.find(uid);
```

#### AUTO 


```{c}
auto it = keys.cbegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (KFileItem &item : dir->lstItems) {
                const KFileItem oldItem = item;
                KFileItem newItem = oldItem;
                const QUrl &oldItemUrl = oldItem.url();
                QUrl newItemUrl(oldItemUrl);
                newItemUrl.setPath(concatPaths(newDirUrl.path(), oldItemUrl.fileName()));
                qCDebug(KIO_CORE_DIRLISTER) << "renaming" << oldItemUrl << "to" << newItemUrl;
                newItem.setUrl(newItemUrl);

                listers.merge(emitRefreshItem(oldItem, newItem));
                // Change the item
                item.setUrl(newItemUrl);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {

        const QString checksum = futureWatcher->result();
        futureWatcher->deleteLater();

        cacheChecksum(checksum, algorithm);

        switch (algorithm) {
        case QCryptographicHash::Md5:
            slotShowMd5();
            break;
        case QCryptographicHash::Sha1:
            slotShowSha1();
            break;
        case QCryptographicHash::Sha256:
            slotShowSha256();
            break;
        case QCryptographicHash::Sha512:
            slotShowSha512();
            break;
        default:
            break;
        }

        const bool isMatch = (checksum == input);
        if (isMatch) {
            setMatchState();
        } else {
            setMismatchState();
        }
    }
```

#### AUTO 


```{c}
const auto compSourceFile = m_completionWithMimeFilter->allMatches();
```

#### LAMBDA EXPRESSION 


```{c}
[this](QDBusPendingCallWatcher *watcher) {
            QDBusPendingReply<> reply = *watcher;
            watcher->deleteLater();
            if (reply.isError()) {
                qCWarning(KIO_GUI) << "Failed to unref service:" << m_serviceName << reply.error().name()
                                   << reply.error().message();
                return systemdError(reply.error().name());
            }
            qCDebug(KIO_GUI) << "Successfully unref'd service:" << m_serviceName;
        }
```

#### AUTO 


```{c}
const auto socketError = socket->socketError();
```

#### AUTO 


```{c}
auto it = d->items.cbegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &domain : domainList) {
            const KHttpCookieList *list =  mCookieJar->getCookieList(domain, fqdn);
            if (!list) {
                continue;
            }
            Q_FOREACH (const KHttpCookie &cookie, *list) {
                if (cookie.isExpired()) {
                    continue;
                }
                if (cookieMatches(cookie, domain, fqdn, path, name)) {
                    putCookie(result, cookie, fields);
                    break;
                }
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[excludedDesktopEntryNames](const KService::Ptr &service) {
                return !excludedDesktopEntryNames.contains(service->desktopEntryName());
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { assureVisibleSelection(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QModelIndex index) {
        d->triggerPreview(index);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &mime : archiveMimetypes) {
                d->protocolForArchiveMimetypes.insert(mime, (*it)->m_name);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[&](KJob *job, qulonglong size) {
        Q_UNUSED(job);
        if (size > 0 && size < srcSize) {
            // To avoid overwriting dest, we want the kioslave to use dest.part
            QCOMPARE(QFileInfo::exists(destPartFile), destFileExists);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KCoreDirLister *kdl : listers) {
        kdl->d->emitItems();

        kdl->d->jobDone(job);

        emit kdl->completed(jobUrl);
        if (kdl->d->numJobs() == 0) {
            kdl->d->complete = true;
            emit kdl->completed();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &item : qAsConst(m_items)) {
        const QString itemMimeType = item.mimetype();
        // Determine if common mimetype among all items
        if (m_mimeType != itemMimeType) {
            m_mimeType.clear();
            if (m_mimeGroup != itemMimeType.leftRef(itemMimeType.indexOf(QLatin1Char('/')))) {
                m_mimeGroup.clear(); // mimetype groups are different as well!
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[]() {
        if (qEnvironmentVariableIntValue("KDE_APPLICATIONS_AS_SCOPE") &&
            (QDBusConnection::sessionBus().interface()->isServiceRegistered(systemdService))) {
            runAsService = true;
            qDBusRegisterMetaType<QVariantMultiItem>();
            qDBusRegisterMetaType<QVariantMultiMap>();
            qDBusRegisterMetaType<TransientAux>();
            qDBusRegisterMetaType<TransientAuxList>();
            qDBusRegisterMetaType<ExecCommand>();
            qDBusRegisterMetaType<ExecCommandList>();
        }
    }
```

#### AUTO 


```{c}
auto eject = std::unique_ptr<QAction>{placesModel->ejectActionForIndex(index)}
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
            d->jobViewServerSupport = KDynamicJobTrackerPrivate::NeedsChecking;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : d->m_appActions) {
            menu->removeAction(action);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *widget : widgetsList) {
            QDialog *dialog = qobject_cast<QDialog *>(widget);
            if (dialog && !dialog->inherits("KPasswordDialog")) {
                dialog->done(code);
                return;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &dir : qAsConst(pendingDirectoryUpdates)) {
        updateDirectory(QUrl::fromLocalFile(dir));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&db, commonMimeType](const KPluginMetaData& metaData) {
        if (!metaData.serviceTypes().contains(QLatin1String("KFileItemAction/Plugin"))) {
            return false;
        }

        auto mimeType = db.mimeTypeForName(commonMimeType);
        const QStringList list = metaData.mimeTypes();
        for (const auto &supportedMimeType : list) {
            if (mimeType.inherits(supportedMimeType)) {
                return true;
            }
        }

        return false;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCoreDirLister *kdl : listers) {
        delayedMimeTypes &= kdl->d->delayedMimeTypes;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job, qulonglong _speed){ _k_slotSpeed(job, _speed); }
```

#### AUTO 


```{c}
const auto thumbRootMount = mountsList.findByPath(thumbRoot);
```

#### LAMBDA EXPRESSION 


```{c}
[&max_mtime](const qint64 lastModTime) {
        if (lastModTime > max_mtime) {
            max_mtime = lastModTime;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool show) { d->togglePlacesPanel(show); }
```

#### RANGE FOR STATEMENT 


```{c}
for (KCoreDirLister *kdl : listers) {
                stopListingUrl(kdl, deletedUrl);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() mutable {
        if (!nameJob->error()) {
            d->m_baseUrl = nameJob->baseUrl();
            name = nameJob->finalName();
        }
        d->showNewDirNameDlg(name);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        q->setIconSize(QSize(-1, -1));
    }
```

#### AUTO 


```{c}
auto it = std::find_if(dirItem->lstItems.cbegin(), dirItem->lstItems.cend(), isMatch);
```

#### AUTO 


```{c}
auto it = mIncomingMetaData.find(key);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &httpHeader : httpHeaders) {
            int index = httpHeader.indexOf(QL1C(':'));
            // Handle HTTP status line...
            if (index == -1) {
                // Except for the status line, all HTTP header must be an nvpair of
                // type "<name>:<value>"
                if (!httpHeader.startsWith(QLatin1String("HTTP/"), Qt::CaseInsensitive)) {
                    continue;
                }

                QStringList statusLineAttrs(httpHeader.split(QL1C(' '), QString::SkipEmptyParts));
                if (statusLineAttrs.count() > 1) {
                    setAttribute(QNetworkRequest::HttpStatusCodeAttribute, statusLineAttrs.at(1));
                }

                if (statusLineAttrs.count() > 2) {
                    setAttribute(QNetworkRequest::HttpReasonPhraseAttribute, statusLineAttrs.at(2));
                }

                continue;
            }

            const QStringRef headerName = httpHeader.leftRef(index);
            QString headerValue = httpHeader.mid(index + 1);

            // Ignore cookie header since it is handled by the http ioslave.
            if (headerName.startsWith(QLatin1String("set-cookie"), Qt::CaseInsensitive)) {
                continue;
            }

            if (headerName.startsWith(QLatin1String("content-disposition"), Qt::CaseInsensitive) &&
                    ignoreContentDisposition(metaData)) {
                continue;
            }

            // Without overriding the corrected mime-type sent by kio_http, add
            // back the "charset=" portion of the content-type header if present.
            if (headerName.startsWith(QLatin1String("content-type"), Qt::CaseInsensitive)) {

                QString mimeType(header(QNetworkRequest::ContentTypeHeader).toString());

                if (m_ignoreContentDisposition) {
                    // If the server returned application/octet-stream, try to determine the
                    // real content type from the disposition filename.
                    if (mimeType == QLatin1String("application/octet-stream")) {
                        const QString fileName(metaData.value(QStringLiteral("content-disposition-filename")));
                        QMimeDatabase db;
                        QMimeType mime = db.mimeTypeForFile((fileName.isEmpty() ? url().path() : fileName), QMimeDatabase::MatchExtension);
                        mimeType = mime.name();
                    }
                    metaData.remove(QStringLiteral("content-disposition-type"));
                    metaData.remove(QStringLiteral("content-disposition-filename"));
                }

                if (!headerValue.contains(mimeType, Qt::CaseInsensitive)) {
                    index = headerValue.indexOf(QL1C(';'));
                    if (index == -1) {
                        headerValue = mimeType;
                    } else {
                        headerValue.replace(0, index, mimeType);
                    }
                    //qDebug() << "Changed mime-type from" << mimeType << "to" << headerValue;
                }
            }
            setRawHeader(headerName.trimmed().toUtf8(), headerValue.trimmed().toUtf8());
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QDBusPendingCallWatcher *watcher) {
            QDBusPendingReply<QDBusObjectPath> reply = *watcher;
            watcher->deleteLater();
            if (reply.isError()) {
                qCWarning(KIO_GUI) << "Failed to launch process as service:" << m_serviceName << reply.error().name()
                                   << reply.error().message();
                return systemdError(reply.error().name());
            }
            qCDebug(KIO_GUI) << "Successfully asked systemd to launch process as service:" << m_serviceName;
            m_jobPath = reply.argumentAt<0>().path();
        }
```

#### AUTO 


```{c}
auto *untrustedProgramHandler = KIO::delegateExtension<KIO::UntrustedProgramHandlerInterface *>(q);
```

#### AUTO 


```{c}
auto err = execWithElevatedPrivilege(OPEN, path, flags, mode)
```

#### LAMBDA EXPRESSION 


```{c}
[&types, &excludeTypes](const KFileItem &i) {
        return mimeTypeListContains(types, i) && !mimeTypeListContains(excludeTypes, i);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { _k_slotFileSelected(); }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        clipboard->setText(d->m_md5);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[url](KJob *job) {
        if (job->error() == KJob::NoError) {
            org::kde::KDirNotify::emitFilesAdded(url.adjusted(QUrl::RemoveFilename | QUrl::StripTrailingSlash));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &f : qAsConst(m_topLevelFileNames)) {
        createTestFile(path + f);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KIO::Job *job, const KIO::UDSEntryList &entries) {
        _k_slotEntries(job, entries);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->slotDetailedTreeView(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &request : requests) {
        request.reply.waitForFinished();
        if (request.reply.isError()) {
            useKioexec = true;
            // At this point we should just send the original urls to kioexec.
            // There's no point sending urls to kioexec that go through kiofuse.
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (int i : fields) {
        switch (i) {
        case CF_DOMAIN :
            out << cookie.domain();
            break;
        case CF_NAME :
            out << cookie.name();
            break;
        case CF_PATH :
            out << cookie.path();
            break;
        case CF_HOST :
            out << cookie.host();
            break;
        case CF_VALUE :
            out << cookie.value();
            break;
        case CF_EXPIRE :
            out << QString::number(cookie.expireDate());
            break;
        case CF_PROVER :
            out << QString::number(cookie.protocolVersion());
            break;
        case CF_SECURE :
            out << QString::number(cookie.isSecure() ? 1 : 0);
            break;
        default :
            out << QString();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool allowDelete) {
            if (allowDelete) {
                slotDropActionDetermined(KJob::NoError);
            } else {
                slotDropActionDetermined(KIO::ERR_USER_CANCELED);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (KJob *job : subjobs()) {
        if (!job->resume()) {
            return false;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        slotUrlDesktopFile();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QHostAddress &address : info.addresses()) {
            if (!isSpecialAddress(address) && isIPv4Address(address) && address.isInSubnet(subnet)) {
                isInSubNet = true;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &dirtyUrl : dirtyUrls) {
        if (KDirModelNode *node = nodeForUrl(QUrl(dirtyUrl))) {
            const QModelIndex idx = indexForNode(node);
            emit q->dataChanged(idx, idx, {KDirModel::HasJobRole});
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KCModule *module : qAsConst(modules)) {
        module->load();
    }
```

#### AUTO 


```{c}
const auto name = cookieView.left(index);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &cc : std::as_const(d->m_cc)) {
        query.addQueryItem(QStringLiteral("cc"), cc);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->_k_reloadBookmarks();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        if (m_exited) {
            return;
        }
        qCDebug(KIO_GUI) << "Got PropertiesChanged signal:" << m_serviceName;
        // We need to look at the full list of properties rather than only those which changed
        auto reply = m_serviceProperties->GetAll(QString());
        connect(new QDBusPendingCallWatcher(reply, this),
            &QDBusPendingCallWatcher::finished,
            this,
            &SystemdProcessRunner::handleProperties);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KSycocaEntry::Ptr &p : list) {
        QString icon;
        QString text;
        QString tooltip;
        QString entryPath;
        QString exec;
        bool isDir = false;
        if (p->isType(KST_KService)) {
            const KService::Ptr service(static_cast<KService *>(p.data()));

            if (service->noDisplay()) {
                continue;
            }

            icon = service->icon();
            text = service->name();

            // no point adding a tooltip that only repeats service->name()
            const QString generic = service->genericName();
            tooltip = generic != text ? generic : QString();

            exec = service->exec();
            entryPath = service->entryPath();
        } else if (p->isType(KST_KServiceGroup)) {
            const KServiceGroup::Ptr serviceGroup(static_cast<KServiceGroup *>(p.data()));

            if (serviceGroup->noDisplay() || serviceGroup->childCount() == 0) {
                continue;
            }

            icon = serviceGroup->icon();
            text = serviceGroup->caption();
            entryPath = serviceGroup->entryPath();
            isDir = true;
        } else {
            qCWarning(KIO_WIDGETS) << "KServiceGroup: Unexpected object in list!";
            continue;
        }

        KDEPrivate::AppNode *newnode = new KDEPrivate::AppNode();
        newnode->icon = icon;
        newnode->text = text;
        newnode->tooltip = tooltip;
        newnode->entryPath = entryPath;
        newnode->exec = exec;
        newnode->isDir = isDir;
        newnode->parent = node;
        node->children.append(newnode);
    }
```

#### AUTO 


```{c}
auto &info = m_freeSpaceInfo[persistentIndex];
```

#### LAMBDA EXPRESSION 


```{c}
[this](KIO::Job* job, const QUrl &from, const QString &target, const QUrl &to) {
                slotCopyingLinkDone(job, from, target, to);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KIO::filesize_t length) {
        slotTruncated(length);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &f) { QFile::remove(f); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &text) { d->slotLocationChanged(text); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &item : qAsConst(m_dispatchedItems)) {
        KFileItemList::iterator begin = m_pendingItems.begin();
        KFileItemList::iterator end   = m_pendingItems.end();
        for (KFileItemList::iterator it = begin; it != end; ++it) {
            if ((*it).url() == item.url()) {
                m_pendingItems.erase(it);
                break;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KMountPoint::Ptr mountPoint : mountPoints) {
        qDebug() << "Possible mount: " << mountPoint->mountedFrom() << " (" << mountPoint->realDeviceName() << ") " << mountPoint->mountPoint() << " "
                 << mountPoint->mountType() << " options:" << mountPoint->mountOptions();
        QVERIFY(!mountPoint->mountedFrom().isEmpty());
        QVERIFY(!mountPoint->mountPoint().isEmpty());
        QVERIFY(!mountPoint->mountType().isEmpty());
        QVERIFY(!mountPoint->mountOptions().isEmpty());
        // old bug, happened because KMountPoint called KStandardDirs::realPath instead of realFilePath
        QVERIFY(!mountPoint->realDeviceName().endsWith('/'));

        // keep one (any) mountpoint with a device name for the test below
        if (!mountPoint->realDeviceName().isEmpty()) {
            mountWithDevice = mountPoint;
        }
    }
```

#### AUTO 


```{c}
const auto tag = QLatin1String("LABEL=");
```

#### RANGE FOR STATEMENT 


```{c}
for (const SearchProvider *provider : std::as_const(m_providers)) {
            if (provider != m_provider && provider->keys().contains(shorthand)) {
                contenders.insert(shorthand, provider);
                break;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&putDataBuffer, &size, putDataContents]() {
        const auto pos = putDataBuffer.pos();
        size += putDataBuffer.write(putDataContents);
        putDataBuffer.seek(pos);
        //         qDebug() << "written" << size;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->_k_initDeviceList();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &item : items) {
        const auto perms = item.permissions();
        if (item.isDir()) {
            dirs.append(item);
            if (perms != ((perms & andDirPermissions) | orDirPermissions)) {
                permissionChange = true;
            }
            continue;
        }

        if (item.isFile()) {
            files.append(item);
            if (perms != ((perms & andFilePermissions) | orFilePermissions)) {
                permissionChange = true;
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job, qulonglong _speed) {
        slotSpeed(job, _speed);
    }
```

#### AUTO 


```{c}
const auto getProviderForKey = [this, &searchTerm](const QString &key) {
        SearchProvider *provider = nullptr;
        // If the key contains a : an assertion in the isKnownProtocol method would fail. This can be
        // the case if the delimiter is switched to space, see kiowidgets_space_separator_test
        if (!key.isEmpty() && (key.contains(QLatin1Char(':')) || !KProtocolInfo::isKnownProtocol(key))) {
            provider = m_registry.findByKey(key);
            if (provider) {
                if (!m_bUseOnlyPreferredWebShortcuts || m_preferredWebShortcuts.contains(provider->desktopEntryName())) {
                    qCDebug(category) << "found provider" << provider->desktopEntryName() << "searchTerm=" << searchTerm;
                } else {
                    provider = nullptr;
                }
            }
        }
        return provider;
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &match : matchesA) {
        QVERIFY2(!match.startsWith(QLatin1Char('g')), qPrintable(match));
    }
```

#### AUTO 


```{c}
const auto resultiongActions = menu.actions();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &opt : qAsConst(upgradeOffers)) {
            if (opt == QLatin1String("TLS/1.0")) {
                if (!startSsl() && upgradeRequired) {
                    error(ERR_UPGRADE_REQUIRED, opt);
                    return false;
                }
            } else if (opt == QLatin1String("HTTP/1.1")) {
                httpRev = HTTP_11;
            } else if (upgradeRequired) {
                // we are told to do an upgrade we don't understand
                error(ERR_UPGRADE_REQUIRED, opt);
                return false;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCoreDirLister *kdl : listers) {
            KCoreDirListerPrivate::CachedItemsJob *cachedItemsJob = kdl->d->cachedItemsJobForUrl(dir);
            if (cachedItemsJob) {
                cachedItemsJob->setEmitCompleted(false);
                cachedItemsJob->done(); // removes from cachedItemsJobs list
                delete cachedItemsJob;
                killed = true;
            }
        }
```

#### AUTO 


```{c}
auto err = tryOpen(dest_file, _dest, O_WRONLY | O_TRUNC | O_CREAT, S_IRUSR | S_IWUSR)
```

#### LAMBDA EXPRESSION 


```{c}
[this](QAction *action) { d->_k_slotActionTriggered(action); }
```

#### AUTO 


```{c}
auto urls = KRecentDocument::recentUrls();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &dir : urls) {
            handleDirDirty(dir);
        }
```

#### AUTO 


```{c}
auto result = ftpGet(iCopyFile, sCopyFile, url, hCopyOffset);
```

#### LAMBDA EXPRESSION 


```{c}
[this](KIO::filesize_t size) {
            slotTotalSize(size);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QUrl &dirUrl){d->_k_slotCompleted(dirUrl);}
```

#### AUTO 


```{c}
const auto ituend = itemsInUse.constEnd();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &dir : pendingDirectoryUpdates) {
        updateDirectory(QUrl::fromLocalFile(dir));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &item : items) {
                    tags.removeAll(item.name());
                }
```

#### AUTO 


```{c}
auto partialWidget = new QWidget(this);
```

#### AUTO 


```{c}
auto it = m_changedItems.cbegin();
```

#### LAMBDA EXPRESSION 


```{c}
[this](QAction *action) {
        activatePlace(action, &KUrlNavigatorPlacesSelector::placeActivated);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QUrl &url){ slotRedirection(url);}
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        const int errCode = job->error();
        if (errCode) {
            // ERR_NO_CONTENT is not an error, but an indication no further
            // actions need to be taken.
            if (errCode != KIO::ERR_NO_CONTENT) {
                q->setError(errCode);
                // We're a KJob, not a KIO::Job, so build the error string here
                q->setErrorText(KIO::buildErrorString(errCode, job->errorText()));
            }
            q->emitResult();
            return;
        }
        if (m_followRedirections) { // Update our URL in case of a redirection
            m_url = job->url();
        }

        const KIO::UDSEntry entry = job->statResult();

        qCDebug(KIO_CORE) << "UDSEntry from StatJob in MimeTypeFinderJob" << entry;

        const QString localPath = entry.stringValue(KIO::UDSEntry::UDS_LOCAL_PATH);
        if (!localPath.isEmpty()) {
            m_url = QUrl::fromLocalFile(localPath);
        }

        // MIME type already known? (e.g. print:/manager)
        m_mimeTypeName = entry.stringValue(KIO::UDSEntry::UDS_MIME_TYPE);
        if (!m_mimeTypeName.isEmpty()) {
            q->emitResult();
            return;
        }

        if (entry.isDir()) {
            m_mimeTypeName = QStringLiteral("inode/directory");
            q->emitResult();
        } else { // It's a file
            // Start the timer. Once we get the timer event this
            // protocol server is back in the pool and we can reuse it.
            // This gives better performance than starting a new slave
            QTimer::singleShot(0, q, [this] {
                scanFileWithGet();
            });
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &mime : archiveMimetypes) {
                d->protocolForArchiveMimetypes.insert(mime, allProtocol->m_name);
            }
```

#### AUTO 


```{c}
auto it = std::find_if(fileList.begin(), fileList.end(), [&path](const FileInfo &i) {
                return i.path == path;
            });
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &header : headers) {
        // Do not allow Request line to be specified and ignore
        // the other HTTP headers.
        if (!header.contains(QLatin1Char(':')) ||
                header.startsWith(QLatin1String("host"), Qt::CaseInsensitive) ||
                header.startsWith(QLatin1String("proxy-authorization"), Qt::CaseInsensitive) ||
                header.startsWith(QLatin1String("via"), Qt::CaseInsensitive)) {
            continue;
        }

        sanitizedHeaders += header + QLatin1String("\r\n");
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, andPermissions, orPermissions](const KFileItem &item) {
        return isIrregular((item.permissions() & andPermissions) | orPermissions, item.isDir(), item.isLink());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : fileList) {
        const QList<QUrl> dirUrls = directoriesForCanonicalPath(url);
        for (const QUrl &dir : dirUrls) {
            DirItem *dirItem = dirItemForUrl(dir); // is it a listed directory?
            if (dirItem) {
                deletedSubdirs.append(dir);
                if (!dirItem->rootItem.isNull()) {
                    removedItemsByDir[url].append(dirItem->rootItem);
                }
            }
        }

        const QUrl parentDir = url.adjusted(QUrl::RemoveFilename | QUrl::StripTrailingSlash);
        const QList<QUrl> parentDirUrls = directoriesForCanonicalPath(parentDir);
        for (const QUrl &dir : parentDirUrls) {
            DirItem *dirItem = dirItemForUrl(dir);
            if (!dirItem) {
                continue;
            }
            for (auto fit = dirItem->lstItems.begin(), fend = dirItem->lstItems.end(); fit != fend; ++fit) {
                if ((*fit).url() == url) {
                    const KFileItem fileitem = *fit;
                    removedItemsByDir[dir].append(fileitem);
                    // If we found a fileitem, we can test if it's a dir. If not, we'll go to deleteDir just in case.
                    if (fileitem.isNull() || fileitem.isDir()) {
                        deletedSubdirs.append(url);
                    }
                    dirItem->lstItems.erase(fit); // remove fileitem from list
                    break;
                }
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &info : trashedFiles) {
            if (info.trashId != trashId) {
                continue;
            }

            if (info.deletionDate.daysTo(currentDate) > maxDays) {
                del(info.trashId, info.fileId);
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KIO::Job *job, const QByteArray &data) { d->slotData(job, data); }
```

#### AUTO 


```{c}
auto scriptHelper = new ScriptHelper(engine, engine);
```

#### AUTO 


```{c}
auto *squeezedLabel = new KSqueezedTextLabel(text, &d->m_mainWidget);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &error : qAsConst(errors)) {
            errorString += QLatin1String("<li>") + error + QLatin1String("</li>");
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &envVar : envVars) {
        const QByteArray envVarUtf8(envVar.toUtf8());
        const QByteArray envVarValue = qgetenv(envVarUtf8.constData());
        if (!envVarValue.isEmpty()) {
            if (showValue) {
                mProxyMap[edit->objectName()] = envVar;
                edit->setText(QString::fromUtf8(envVarValue));
            } else {
                edit->setText(envVar);
            }
            edit->setEnabled(!showValue);
            return true;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        const int errCode = job->error();
        if (errCode) {
             // ERR_NO_CONTENT is not an error, but an indication no further
             // actions needs to be taken.
             if (errCode != KIO::ERR_NO_CONTENT) {
                 q->setError(errCode);
                 q->setErrorText(job->errorText());
             }
             q->emitResult();
        }
        // if the job succeeded, we certainly hope it emitted mimetype()...
    }
```

#### AUTO 


```{c}
auto job = KIO::copy({QUrl::fromLocalFile(QFINDTESTDATA("ftp/testCopy2"))}, inaccessibleUrl, KIO::Resume);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->slotChangeDecorationPosition(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &plugin : splittedText)
        enabledPlugins << plugin.trimmed();
```

#### AUTO 


```{c}
auto toDisplayUrl = [this](const QUrl &url) {
        QString dest;
        if (url.isLocalFile()) {
            dest = KShell::tildeCollapse(url.toLocalFile());
        } else {
            dest = targetUrl().toDisplayString();
        }
        return dest;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job, ulong speed) {
        _k_slotSpeed(job, speed);
    }
```

#### AUTO 


```{c}
auto *cancelBtn = buttonBox->addButton(QDialogButtonBox::Cancel);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KHttpCookie &cookie : qAsConst(allCookies)) {
        if (cookie.protocolVersion() > protVersion) {
            protVersion = cookie.protocolVersion();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &error : std::as_const(errors)) {
                errorString += QLatin1String("<li>") + error + QLatin1String("</li>");
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : urls) {
            if (url.scheme() == QLatin1String("trash")) {
                QString path = url.path();
                // HACK (#98983): remove "0-foo". Note that it works better than
                // displaying KFileItem::name(), for files under a subdir.
                path.remove(QRegularExpression(QStringLiteral("^/[0-9]*-")));
                prettyList.append(path);
            } else {
                prettyList.append(url.toDisplayString(QUrl::PreferLocalFile));
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) { d->_k_slotResult(job); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &item : items) {
        const auto perms = item.permissions();
        if (item.isDir()) {
            dirs.append(item);
            if (!permissionChange && (recursive || perms != ((perms & andDirPermissions) | orDirPermissions))) {
                permissionChange = true;
            }
            continue;
        }

        if (item.isFile()) {
            files.append(item);
            if (!permissionChange && perms != ((perms & andFilePermissions) | orFilePermissions)) {
                permissionChange = true;
            }
        }
    }
```

#### AUTO 


```{c}
auto job2 = KIO::copy(url, dir_url, KIO::DefaultFlags);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->slotViewKeyEnterReturnPressed(); }
```

#### LAMBDA EXPRESSION 


```{c}
[=](SkipDialog_Result result, KJob *parentJob) {
                        Q_ASSERT(parentJob == q);
                        // Only receive askUserSkipResult once per skip dialog
                        QObject::disconnect(askUserActionInterface, skipSignal, q, nullptr);

                        processCopyNextFile(it, result);
                    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &device) {
        deviceRemoved(device);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &dir : dirs) {
        KFileItemList deletedItems;

        const QList<KFileItem> *itemList = kDirListerCache()->itemsForDir(dir);
        if (!itemList) {
            continue;
        }

        auto kit = itemList->begin();
        const auto kend = itemList->end();
        for (; kit != kend; ++kit) {
            const KFileItem &item = *kit;
            const QString text = item.text();
            if (text == QLatin1Char('.') || text == QLatin1String("..")) {
                continue;
            }
            const bool wasVisible = oldVisibleItems.contains(item.name());
            const bool nowVisible = isItemVisible(item) && q->matchesMimeFilter(item);
            if (nowVisible && !wasVisible) {
                addNewItem(dir, item);    // takes care of emitting newItem or itemsFilteredByMime
            } else if (!nowVisible && wasVisible) {
                deletedItems.append(*kit);
            }
        }
        if (!deletedItems.isEmpty()) {
            emit q->itemsDeleted(deletedItems);
        }
        emitItems();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &jsonMetadata : jsonPlugins) {
        // The plugin has been disabled
        if (!showGroup.readEntry(jsonMetadata.pluginId(), true)) {
            continue;
        }

        // The plugin also has a .desktop file and has already been added.
        if (addedPlugins.contains(jsonMetadata.pluginId())) {
            continue;
        }

        KPluginFactory *factory = KPluginLoader(jsonMetadata.fileName()).factory();
        if (!factory) {
            continue;
        }
        auto *abstractPlugin = factory->create<KAbstractFileItemActionPlugin>();
        if (abstractPlugin) {
            abstractPlugin->setParent(this);
            const QList<QAction *> actions = abstractPlugin->actions(d->m_props, d->m_parentWidget);
            itemCount += actions.count();
            mainMenu->addActions(actions);
            addedPlugins.append(jsonMetadata.pluginId());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &serviceId : serviceIdList) {
        KFileItemList serviceItems;
        for (const KFileItem &item : fileItems) {
            const KService::Ptr serv = preferredService(item.mimetype(), QStringList(), m_traderConstraint);
            const QString preferredServiceId = serv ? serv->storageId() : QString();
            if (preferredServiceId == serviceId) {
                serviceItems << item;
            }
        }

        if (serviceId.isEmpty()) { // empty means: no associated app for this MIME type
            openWithByMime(serviceItems);
            continue;
        }

        const KService::Ptr servicePtr = KService::serviceByStorageId(serviceId); // can be nullptr
        auto *job = new KIO::ApplicationLauncherJob(servicePtr);
        job->setUrls(serviceItems.urlList());
        job->setUiDelegate(new KIO::JobUiDelegate(KJobUiDelegate::AutoHandlingEnabled, m_parentWidget));
        job->start();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool checked) {
        d->m_proxyModel->setSortHiddenFilesLast(checked);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &metaData : plugins) {
        const QString serviceName = metaData.rawData().value(QStringLiteral("X-KDE-DBus-ServiceName")).toString();
        if (serviceName.isEmpty()) {
            qCWarning(KIOD_CATEGORY) << "No X-KDE-DBus-ServiceName found in" << metaData.fileName();
            continue;
        }
        if (!bus->registerService(serviceName)) {
            qCWarning(KIOD_CATEGORY) << "Couldn't register name" << serviceName << "with DBUS - another process owns it already!";
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &entry : entries) {
        const QString name = entry.stringValue(KIO::UDSEntry::UDS_NAME);

        Q_ASSERT(!name.isEmpty());
        if (name.isEmpty()) {
            continue;
        }

        if (name == QLatin1Char('.')) {
            Q_ASSERT(dir->rootItem.isNull());
            // Try to reuse an existing KFileItem (if we listed the parent dir)
            // rather than creating a new one. There are many reasons:
            // 1) renames and permission changes to the item would have to emit the signals
            // twice, otherwise, so that both views manage to recognize the item.
            // 2) with kio_ftp we can only know that something is a symlink when
            // listing the parent, so prefer that item, which has more info.
            // Note that it gives a funky name() to the root item, rather than "." ;)
            dir->rootItem = itemForUrl(url);
            if (dir->rootItem.isNull()) {
                dir->rootItem = KFileItem(entry, url, delayedMimeTypes, true);
            }

            for (KCoreDirLister *kdl : listers) {
                if (kdl->d->rootFileItem.isNull() && kdl->d->url == url) {
                    kdl->d->rootFileItem = dir->rootItem;
                }
            }
        } else if (name != QLatin1String("..")) {
            KFileItem item(entry, url, delayedMimeTypes, true);

            // get the names of the files listed in ".hidden", if it exists and is a local file
            if (!dotHiddenChecked) {
                const QString localPath = item.localPath();
                if (!localPath.isEmpty()) {
                    const QString rootItemPath = QFileInfo(localPath).absolutePath();
                    cachedHidden = cachedDotHiddenForDir(rootItemPath);
                }
                dotHiddenChecked = true;
            }

            // hide file if listed in ".hidden"
            if (cachedHidden && cachedHidden->listedFiles.find(name) != cachedHidden->listedFiles.cend()) {
                item.setHidden();
            }

            qCDebug(KIO_CORE_DIRLISTER) << "Adding item: " << item.url();
            // Add the items sorted by url, needed by findByUrl
            dir->insert(item);

            for (KCoreDirLister *kdl : listers) {
                kdl->d->addNewItem(url, item);
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[udsField](const Field &entry) {
            return entry.m_index == udsField;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &_m : mtypes) {
                if (_m != QLatin1String("ThumbCreator")) {
                    protocolMap[protocol].insert(_m, *it);
                    if (!_ms.contains(_m)) {
                        _ms.append(_m);
                    }
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QStringList &urlList) {
            d->_k_slotJobUrlsChanged(urlList);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &locale : std::as_const(foundLocalesForKey)) {
                sconfig.setLocale(locale);
                protocolData.insert(QStringLiteral("%1[%2]").arg(key, locale), config.readEntry(key, QStringList()));
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QAction *act) {
        slotMenuActionClicked(act, Qt::LeftButton);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &statement : std::as_const(l)) {
                const int index = statement.indexOf('=');
                if (index <= 0) {
                    mediaAttribute = toQString(statement.mid(0, index));
                } else {
                    mediaAttribute = toQString(statement.mid(0, index));
                    mediaValue = toQString(statement.mid(index + 1));
                }
                mediaAttribute = mediaAttribute.trimmed();
                mediaValue = mediaValue.trimmed();

                bool quoted = false;
                if (mediaValue.startsWith(QLatin1Char('"'))) {
                    quoted = true;
                    mediaValue.remove(0, 1);
                }

                if (mediaValue.endsWith(QLatin1Char('"'))) {
                    mediaValue.chop(1);
                }

                qCDebug(KIO_HTTP) << "Encoding-type:" << mediaAttribute << "=" << mediaValue;

                if (mediaAttribute == QLatin1String("charset")) {
                    mediaValue = mediaValue.toLower();
                    m_request.cacheTag.charset = mediaValue;
                    setMetaData(QStringLiteral("charset"), mediaValue);
                } else {
                    setMetaData(QLatin1String("media-") + mediaAttribute, mediaValue);
                    if (quoted) {
                        setMetaData(QLatin1String("media-") + mediaAttribute + QLatin1String("-kio-quoted"), QStringLiteral("true"));
                    }
                }
            }
```

#### AUTO 


```{c}
auto it = std::find_if(mountPoints.cbegin(), mountPoints.cend(), [&storageFilePath](const KMountPoint::Ptr &mountPoint) {
            return mountPoint->mountPoint() == storageFilePath;
        });
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                fileDialogMode = KFile::Directory;
                applyFileMode(m_parent->fileDialog(), fileDialogMode, fileDialogAcceptMode);
                m_fileDialogModeWasDirAndFile = true;
                createFileDialog();
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            d_func()->slotIODeviceClosedBeforeStart();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (KCoreDirLister *kdl : listers) {
        kdl->d->emitItems();
    }
```

#### AUTO 


```{c}
const auto groups = m_model->groups();
```

#### LAMBDA EXPRESSION 


```{c}
[this](KIO::Job *job, const QByteArray &data) {
                slotData(job, data);
            }
```

#### LAMBDA EXPRESSION 


```{c}
doUndo
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &mountPoint : mountPoints) {
            if (mountPoint->mountPoint() == m_access->filePath()) {
                if (mountPoint->mountedFrom().startsWith(QLatin1String("kdeconnect@"))) {
                    // Hide only if the user never set the "Hide" checkbox on the device.
                    if (m_bookmark.metaDataItem(QStringLiteral("IsHidden")).isEmpty()) {
                        setHidden(true);
                    }
                }
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QStringRef &header : headers) {
        // Do not allow Request line to be specified and ignore
        // the other HTTP headers.
        if (!header.contains(QLatin1Char(':')) || header.startsWith(QLatin1String("host"), Qt::CaseInsensitive)
            || header.startsWith(QLatin1String("proxy-authorization"), Qt::CaseInsensitive) || header.startsWith(QLatin1String("via"), Qt::CaseInsensitive)
            || header.startsWith(QLatin1String("depth"), Qt::CaseInsensitive)) {
            continue;
        }

        sanitizedHeaders += header + QLatin1String("\r\n");
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QModelIndex &index) {
        const auto modifiers = qGuiApp->keyboardModifiers();
        if (modifiers == (Qt::ControlModifier | Qt::ShiftModifier) && isSignalConnected(QMetaMethod::fromSignal(&KFilePlacesView::activeTabRequested))) {
            d->placeClicked(index, &KFilePlacesView::activeTabRequested);
        } else if (modifiers == Qt::ControlModifier && isSignalConnected(QMetaMethod::fromSignal(&KFilePlacesView::tabRequested))) {
            d->placeClicked(index, &KFilePlacesView::tabRequested);
        } else if (modifiers == Qt::ShiftModifier && isSignalConnected(QMetaMethod::fromSignal(&KFilePlacesView::newWindowRequested))) {
            d->placeClicked(index, &KFilePlacesView::newWindowRequested);
        } else {
            d->placeClicked(index, &KFilePlacesView::placeActivated);
        }
    }
```

#### AUTO 


```{c}
auto &entry
```

#### AUTO 


```{c}
auto kit = item->lstItems.constBegin();
```

#### AUTO 


```{c}
auto err = tryOpen(srcFile, _src, O_RDONLY, S_IRUSR, errno)
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QUrl &url) {
        Q_EMIT q->urlSelectionRequested(url);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](qint64 pid) {
        d->m_pid = pid;
        emitResult();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KCoreDirLister *kdl : listers) {
            kdl->d->jobDone(job);

            //don't bother the user
            //kdl->handleError( job );

            const bool silent = job->property("_kdlc_silent").toBool();
            if (!silent) {
#if KIOCORE_BUILD_DEPRECATED_SINCE(5, 79)
                Q_EMIT kdl->canceled(jobUrl);
#endif
                Q_EMIT kdl->listingDirCanceled(jobUrl);
            }
            if (kdl->d->numJobs() == 0) {
                kdl->d->complete = true;
                if (!silent) {
                    Q_EMIT kdl->canceled();
                }
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, messageWidget] {
            const QUrl resolvedTargetLocation = properties->item().url().resolved(QUrl(d->m_linkTargetLineEdit->text()));

            KIO::StatJob *statJob = KIO::statDetails(resolvedTargetLocation, KIO::StatJob::SourceSide, KIO::StatNoDetails, KIO::HideProgressInfo);
            connect(statJob, &KJob::finished, this, [this, statJob, messageWidget] {
                if (statJob->error()) {
                    messageWidget->setText(statJob->errorString());
                    messageWidget->animatedShow();
                    return;
                }

                KIO::highlightInFileManager({statJob->url()});
                properties->close();
            });
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](QPushButton *button) {
            return button->text() == QLatin1String("&Here");
            }
```

#### AUTO 


```{c}
const auto &group
```

#### RANGE FOR STATEMENT 


```{c}
for (const UDSTestField &field : testCase) {
                uint uds = field.m_uds;
                QVERIFY(entry.contains(uds));

                if (uds & KIO::UDSEntry::UDS_STRING) {
                    QCOMPARE(entry.stringValue(uds), field.m_string);
                } else {
                    Q_ASSERT(uds & KIO::UDSEntry::UDS_NUMBER);
                    QCOMPARE(entry.numberValue(uds), field.m_long);
                }
            }
```

#### AUTO 


```{c}
auto skipSignal = &AskUserActionInterface::askUserSkipResult;
```

#### LAMBDA EXPRESSION 


```{c}
[=](const QString &text) {
        slotVerifyChecksum(text.toLower());
    }
```

#### AUTO 


```{c}
auto it = std::find_if(storage.cbegin(), storage.cend(), [udsField](const Field &entry) {
            return entry.m_index == udsField;
        });
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &id) {
                _k_itemChanged(id);
            }
```

#### AUTO 


```{c}
auto it = std::lower_bound(beginIt, endIt, size);
```

#### AUTO 


```{c}
auto ioresult = f.seek(pos);
```

#### AUTO 


```{c}
auto c = fieldVal.cbegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &url : std::as_const(m_popupFiles)) {
        QString text = entry.text;
        text.remove(QStringLiteral("...")); // the ... is fine for the menu item but not for the default filename
        text = text.trimmed(); // In some languages, there is a space in front of "...", see bug 268895
        // KDE5 TODO: remove the "..." from link*.desktop files and use i18n("%1...") when making
        // the action.
        QString name = text;
        text.append(QStringLiteral(".desktop"));

        const QUrl directory = mostLocalUrl(url);
        const QUrl defaultFile = QUrl::fromLocalFile(directory.toLocalFile() + QLatin1Char('/') + KIO::encodeFileName(text));
        if (defaultFile.isLocalFile() && QFile::exists(defaultFile.toLocalFile())) {
            text = KFileUtils::suggestName(directory, text);
        }

        QUrl templateUrl;
        bool usingTemplate = false;
        if (entry.templatePath.startsWith(QLatin1String(":/"))) {
            QTemporaryFile *tmpFile = QTemporaryFile::createNativeFile(entry.templatePath);
            tmpFile->setAutoRemove(false);
            QString tempFileName = tmpFile->fileName();
            tmpFile->close();

            KDesktopFile df(tempFileName);
            KConfigGroup group = df.desktopGroup();
            group.writeEntry("Name", name);
            templateUrl = QUrl::fromLocalFile(tempFileName);
            m_tempFileToDelete = tempFileName;
            usingTemplate = true;
        } else {
            templateUrl = QUrl::fromLocalFile(entry.templatePath);
        }
        KPropertiesDialog *dlg = new KPropertiesDialog(templateUrl, directory, text, m_parentWidget);
        dlg->setModal(q->isModal());
        dlg->setAttribute(Qt::WA_DeleteOnClose);
        QObject::connect(dlg, &KPropertiesDialog::applied, q, [this, dlg]() {
            _k_slotOtherDesktopFile(dlg);
        });
        if (usingTemplate) {
            QObject::connect(dlg, &KPropertiesDialog::propertiesClosed, q, [this]() {
                slotOtherDesktopFileClosed();
            });
        }
        dlg->show();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &item : itemsList) {
            if (item == firstItem) {
                continue;
            }

            const QUrl url = item.url();
            // qDebug() << "KFilePropsPlugin::KFilePropsPlugin " << url.toDisplayString();
            // The list of things we check here should match the variables defined
            // at the beginning of this method.
            if (url.isLocalFile() != isLocal) {
                isLocal = false; // not all local
            }
            if (bDesktopFile && item.isDesktopFile() != bDesktopFile) {
                bDesktopFile = false; // not all desktop files
            }
            if (item.mode() != mode) {
                mode = static_cast<mode_t>(0);
            }
            if (KIO::iconNameForUrl(url) != iconStr) {
                iconStr = QStringLiteral("document-multiple");
            }
            if (url.adjusted(QUrl::RemoveFilename | QUrl::StripTrailingSlash).path() != directory) {
                directory.clear();
            }
            if (url.scheme() != protocol) {
                protocol.clear();
            }
            if (!mimeComment.isNull() && item.mimeComment() != mimeComment) {
                mimeComment.clear();
            }
            if (isLocal && !magicMimeComment.isNull()) {
                QMimeType magicMimeType = db.mimeTypeForFile(url.toLocalFile(), QMimeDatabase::MatchContent);
                if (magicMimeType.isValid() && magicMimeType.comment() != magicMimeComment) {
                    magicMimeComment.clear();
                }
            }

            if (isLocal && url.path() == QLatin1String("/")) {
                hasRoot = true;
            }
            if (item.isDir() && !item.isLink()) {
                iDirCount++;
                hasDirs = true;
            } else {
                iFileCount++;
                totalSize += item.size();
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
do {
        return copy({"more-files"_hc}, ""_rc);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &format : formats) {
                    d->m_dropUrlsMimeData->setData(format, event->mimeData()->data(format));
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QModelIndex index) { d->slotExpandToUrl(index); }
```

#### RANGE FOR STATEMENT 


```{c}
for (KJob *job : qAsConst(m_previewJobs)) {
        Q_ASSERT(job);
        job->kill();
    }
```

#### AUTO 


```{c}
auto initIt = std::find_if(list.cbegin(), list.cend(), [](const QString &s) {
        return s.startsWith(QLatin1String("init"));
    });
```

#### RANGE FOR STATEMENT 


```{c}
for (const KIO::UDSEntry &entry : lst) {
        QString name = entry.stringValue(KIO::UDSEntry::UDS_NAME);
        QString displayName = entry.stringValue(KIO::UDSEntry::UDS_DISPLAY_NAME);
        QUrl url(entry.stringValue(KIO::UDSEntry::UDS_URL));
        qDebug() << "name" << name << "displayName" << displayName << " UDS_URL=" << url;
        if (!url.isEmpty()) {
            QCOMPARE(url.scheme(), QStringLiteral("trash"));
        }
        m_listResult << name;
        m_displayNameListResult << displayName;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QModelIndex index) { d->slotActivated(index); }
```

#### LAMBDA EXPRESSION 


```{c}
[&storageFilePath](const KMountPoint::Ptr &mountPoint) {
            return mountPoint->mountPoint() == storageFilePath;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool allow) {
        d->slotToggleAllowExpansion(allow);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &protocol) {
        slotProtocolChanged(protocol);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KCoreDirLister *kdl : listers) {
            emit kdl->started(newUrl);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KServicePtr &service : qAsConst(offers)) {
                QAction *act = d->createAppAction(service, false);
                subMenu->addAction(act);
            }
```

#### AUTO 


```{c}
auto isMatch = [&_name](const KFileItem &item) {
        return _name == item.name();
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &skipPath : std::as_const(m_skipList)) {
        if (path.startsWith(skipPath)) {
            return true;
        }
    }
```

#### AUTO 


```{c}
auto *job = new KEMailClientLauncherJob;
```

#### RANGE FOR STATEMENT 


```{c}
for (KCoreDirLister *kdl : listers) {
                kdl->d->addNewItem(jobUrl, item);
            }
```

#### AUTO 


```{c}
auto kit = itemsToDelete.cbegin(), endIt = itemsToDelete.cend();
```

#### RANGE FOR STATEMENT 


```{c}
for (ProtoQueue *p : std::as_const(m_protocols)) {
            const QList<KIO::Slave *> list = p->allSlaves();
            for (Slave *slave : list) {
                slave->kill();
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](int pos, int index) {
        placesViewSplitterMoved(pos, index);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Slave *slave : slaves) {
        // kill the slave process, then remove the interface in our process
        slave->kill();
        slave->deref();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[service](const KServiceAction &action) {
            return action.exec() == service->exec();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto item : std::as_const(items)) {
        QVERIFY(item.isMimeTypeKnown());
    }
```

#### AUTO 


```{c}
auto *dialog = new KMessageDialog(KMessageDialog::Information, i18n("The peer SSL certificate chain appears to be corrupt."), parent);
```

#### RANGE FOR STATEMENT 


```{c}
for (KCoreDirLister *kdl : holders) {
        if (job) {
            kdl->d->jobDone(job);
        }
    }
```

#### AUTO 


```{c}
auto endIt = m_stdIconSizes.cend();
```

#### RANGE FOR STATEMENT 


```{c}
for (CachedItemsJob *job : m_cachedItemsJobs) {
        if (job->url() == url) {
            return job;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        const int errCode = job->error();
        if (errCode) {
            // ERR_NO_CONTENT is not an error, but an indication no further
            // actions need to be taken.
            if (errCode != KIO::ERR_NO_CONTENT) {
                q->setError(errCode);
                // We're a KJob, not a KIO::Job, so build the error string here
                q->setErrorText(KIO::buildErrorString(errCode, job->errorText()));
            }
            q->emitResult();
            return;
        }
        if (m_followRedirections) { // Update our URL in case of a redirection
            m_url = job->url();
        }

        const KIO::UDSEntry entry = job->statResult();

        const QString localPath = entry.stringValue(KIO::UDSEntry::UDS_LOCAL_PATH);
        if (!localPath.isEmpty()) {
            m_url = QUrl::fromLocalFile(localPath);
        }

        // MIME type already known? (e.g. print:/manager)
        m_mimeTypeName = entry.stringValue(KIO::UDSEntry::UDS_MIME_TYPE);
        if (!m_mimeTypeName.isEmpty()) {
            q->emitResult();
            return;
        }

        if (entry.isDir()) {
            m_mimeTypeName = QStringLiteral("inode/directory");
            q->emitResult();
        } else { // It's a file
            // Start the timer. Once we get the timer event this
            // protocol server is back in the pool and we can reuse it.
            // This gives better performance than starting a new slave
            QTimer::singleShot(0, q, [this] { scanFileWithGet(); });
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](SkipDialog_Result result, KJob *parentJob) {
                Q_ASSERT(parentJob == q);
                // Only receive askUserSkipResult once per skip dialog
                QObject::disconnect(askUserActionInterface, skipSignal, q, nullptr);

                processCopyNextFile(it, result, skipType);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[&loop, &success]() {
        loop.quit();
        success = true;
    }
```

#### AUTO 


```{c}
auto isNonKIO = [this]() {
        const QStringList protocols = d->service.property(QStringLiteral("X-KDE-Protocols")).toStringList();
        return !protocols.isEmpty() && !protocols.contains(QLatin1String("KIO"));
    };
```

#### AUTO 


```{c}
auto expectedLastModified = lastModified;
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob* job, qulonglong size) { _k_slotTotalSize(job, size); }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        this->d->_k_slotSortReversed(false);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        _k_slotDbClick();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &dir : std::as_const(m_dirList)) {
        if (terminationRequested()) {
            break;
        }

        // qDebug() << "Scanning directory" << dir;

        QDirIterator current_dir_iterator(dir, iterator_filter);

        while (current_dir_iterator.hasNext() && !terminationRequested()) {
            current_dir_iterator.next();

            QFileInfo file_info = current_dir_iterator.fileInfo();
            const QString file_name = file_info.fileName();

            // qDebug() << "Found" << file_name;

            if (!m_filter.isEmpty() && !file_name.startsWith(m_filter)) {
                continue;
            }

            if (!m_mimeTypeFilters.isEmpty() && !file_info.isDir()) {
                auto mimeType = mimeTypes.mimeTypeForFile(file_info);
                if (!m_mimeTypeFilters.contains(mimeType.name())) {
                    continue;
                }
            }

            QString toAppend = file_name;
            // Add '/' to directories
            if (m_appendSlashToDir && file_info.isDir()) {
                toAppend.append(QLatin1Char('/'));
            }

            if (m_complete_url) {
                QUrl info(m_prepend);
                info = addPathToUrl(info, toAppend);
                addMatch(info.toDisplayString());
            } else {
                addMatch(m_prepend + toAppend);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (unsigned char &b : bl->challenge) {
        b = KRandom::random() % 0xff;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const GetRequest &entry : m_activeQueue) {
            if (entry.id == id) {
                m_currentEntry = entry;
                return true;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QueuedRequest &request : std::as_const(m_requestQueue)) {
            if (request.sendAll) {
                const QVariant result(handleRequest(request.url));
                QDBusConnection::sessionBus().send(request.transaction.createReply(result));
            } else {
                const QVariant result(handleRequest(request.url).constFirst());
                QDBusConnection::sessionBus().send(request.transaction.createReply(result));
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QSslError &e) {
        return e.error() == QSslError::NoPeerCertificate || e.error() == QSslError::PathLengthExceeded || e.error() == QSslError::NoSslSupport;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KIO::filesize_t pos) {
        slotPosition(pos);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KCoreDirLister *kdl : qAsConst(curHolders)) {    // holders of newUrl
                kdl->jobStarted(job);
                emit kdl->started(newUrl);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (KCoreDirLister *kdl : holders) {
                // lister's root is the deleted item
                if (kdl->d->url == deletedUrl) {
                    // tell the view first. It might need the subdirs' items (which forgetDirs will delete)
                    if (!kdl->d->rootFileItem.isNull()) {
                        emit kdl->itemsDeleted(KFileItemList() << kdl->d->rootFileItem);
                    }
                    forgetDirs(kdl);
                    kdl->d->rootFileItem = KFileItem();
                } else {
                    const bool treeview = kdl->d->lstDirs.count() > 1;
                    if (!treeview) {
                        emit kdl->clear();
                        kdl->d->lstDirs.clear();
                    } else {
                        kdl->d->lstDirs.removeAll(deletedUrl);
                    }

                    forgetDirs(kdl, deletedUrl, treeview);
                }
            }
```

#### AUTO 


```{c}
auto reply = m_serviceProperties->GetAll(QString());
```

#### AUTO 


```{c}
auto *provider
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &device) {
        deviceAdded(device);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &item : items) {
        listEntry(fileEntry(item));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                slotOtherDesktopFileClosed();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &dir : installedTemplates) {
            s->dirWatch->addDir(dir);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&db, commonMimeType](const KPluginMetaData &metaData) {
        if (!metaData.serviceTypes().contains(QLatin1String("KFileItemAction/Plugin"))) {
            return false;
        }

        auto mimeType = db.mimeTypeForName(commonMimeType);
        const QStringList list = metaData.mimeTypes();
        return std::any_of(list.constBegin(), list.constEnd(), [mimeType](const QString &supportedMimeType) {
            return mimeType.inherits(supportedMimeType);
        });
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        this->d->slotSortReversed(false);
    }
```

#### AUTO 


```{c}
auto err = execWithElevatedPrivilege(CHMOD, {_path, permissions}, errno)
```

#### LAMBDA EXPRESSION 


```{c}
[this](){d->_k_slotClear();}
```

#### RANGE FOR STATEMENT 


```{c}
for (const Solid::Device &device : lst) {
        QString topdir = device.as<Solid::StorageAccess>()->filePath();
        QString trashDir = trashForMountPoint(topdir, false);
        if (!trashDir.isEmpty()) {
            // OK, trashDir is a valid trash directory. Ensure it's registered.
            int trashId = idForTrashDirectory(trashDir);
            if (trashId == -1) {
                // new trash dir found, register it
#ifdef Q_OS_OSX
                trashId = idForMountPoint(topdir);
#else
                trashId = idForDevice(device);
#endif
                if (trashId == -1) {
                    continue;
                }
                m_trashDirectories.insert(trashId, trashDir);
                // qCDebug(KIO_TRASH) << "found" << trashDir << "gave it id" << trashId;
                if (!topdir.endsWith(QLatin1Char('/'))) {
                    topdir += QLatin1Char('/');
                }
                m_topDirectories.insert(trashId, topdir);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &header : headers) {
        // Do not allow Request line to be specified and ignore
        // the other HTTP headers.
        if (!header.contains(QLatin1Char(':')) || header.startsWith(QLatin1String("host"), Qt::CaseInsensitive)
            || header.startsWith(QLatin1String("proxy-authorization"), Qt::CaseInsensitive) || header.startsWith(QLatin1String("via"), Qt::CaseInsensitive)
            || header.startsWith(QLatin1String("depth"), Qt::CaseInsensitive)) {
            continue;
        }

        sanitizedHeaders += header + QLatin1String("\r\n");
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, errorMsg]() {
            Q_EMIT error(errorMsg);
            deleteLater();
        }
```

#### AUTO 


```{c}
const auto getSelectionLength = [](const QString &text) {
        // Select the text without MIME-type extension
        int selectionLength = text.length();

        QMimeDatabase db;
        const QString extension = db.suffixForFileName(text);
        if (extension.isEmpty()) {
            // For an unknown extension just exclude the extension after
            // the last point. This does not work for multiple extensions like
            // *.tar.gz but usually this is anyhow a known extension.
            selectionLength = text.lastIndexOf(QLatin1Char('.'));

            // If no point could be found, use whole text length for selection.
            if (selectionLength < 1) {
                selectionLength = text.length();
            }

        } else {
            selectionLength -= extension.length() + 1;
        }

        return selectionLength;
    };
```

#### AUTO 


```{c}
auto it = storage.cbegin(), end = storage.cend();
```

#### LAMBDA EXPRESSION 


```{c}
[q](KJob *job, qulonglong processedSize) {
        Q_UNUSED(job);
        q->setProcessedAmount(KJob::Bytes, processedSize);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Field &field : storage) {
        uint uds = field.m_index;
        s << uds;

        if (uds & KIO::UDSEntry::UDS_STRING) {
            s << field.m_str;
        } else if (uds & KIO::UDSEntry::UDS_NUMBER) {
            s << field.m_long;
        } else {
            Q_ASSERT_X(false, "KIO::UDSEntry", "Found a field with an invalid type");
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : files) {
            if (!m_searchProvidersByDesktopName.contains(file)) {
                const QString filePath = dir.path() + QLatin1Char('/') + file;
                auto *provider = new SearchProvider(filePath);
                m_searchProvidersByDesktopName.insert(file, provider);
                m_searchProviders.append(provider);
                const auto keys = provider->keys();
                for (const QString &key : keys) {
                    m_searchProvidersByKey.insert(key, provider);
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& item : d->defaultList) {
        d->insertUrlItem(item.get());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        q->emitResult();
    }
```

#### AUTO 


```{c}
auto err = execWithElevatedPrivilege(COPY, {srcUrl, destUrl}, errno);
```

#### AUTO 


```{c}
const auto &row
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &item : itemList) {
            d->m_completion.addItem(item.name());
            if (item.isDir()) {
                d->m_dirCompletion.addItem(item.name());
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->slotDetailedView();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &u : urls) {
        updateDirectory(u);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](){ qDebug() << "applied"; }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->slotLoadingFinished();
    }
```

#### AUTO 


```{c}
auto result = ftpOpenCommand("list -la", QString(), 'I', KJob::NoError);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : files) {
        const KDesktopFile desktopFile(file);
        const KConfigGroup cfg = desktopFile.desktopGroup();

        if (!shouldDisplayServiceMenu(cfg, protocol)) {
            continue;
        }

        if (cfg.hasKey("Actions") || cfg.hasKey("X-KDE-GetActionMenu")) {
            if (!checkTypesMatch(cfg)) {
                continue;
            }

            const QString priority = cfg.readEntry("X-KDE-Priority");
            const QString submenuName = cfg.readEntry("X-KDE-Submenu");

            ServiceList &list = s.selectList(priority, submenuName);
            const ServiceList userServices = KDesktopFileActions::userDefinedServices(KService(file), isLocal, urlList);
            std::copy_if(userServices.cbegin(), userServices.cend(), std::back_inserter(list), [&excludeList, &showGroup](const KServiceAction &srvAction) {
                return showGroup.readEntry(srvAction.name(), true) && !excludeList.contains(srvAction.name());
            });
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (SimpleJob *job : waitingJobs) {
        // ### for compatibility with the old scheduler we don't touch the running job, if any.
        // make sure that the job doesn't call back into Scheduler::cancelJob(); this would
        // a) crash and b) be unnecessary because we clean up just fine.
        SimpleJobPrivate::get(job)->m_schedSerial = 0;
        job->kill();
    }
```

#### AUTO 


```{c}
const auto &field = extraFields.at(i);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &domain : domains) {
        const QString siteName = (domain.startsWith(QLatin1Char('.')) ? domain.mid(1) : domain);
        if (mUi.cookiesTreeWidget->findItems(siteName, Qt::MatchFixedString).isEmpty()) {
            dom = new CookieListViewItem(mUi.cookiesTreeWidget, domain);
            dom->setChildIndicatorPolicy(QTreeWidgetItem::ShowIndicator);
        }
    }
```

#### AUTO 


```{c}
auto it = list.begin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : files) {
        const KDesktopFile desktopFile(file);
        const KConfigGroup cfg = desktopFile.desktopGroup();

        if (!shouldDisplayServiceMenu(cfg, protocol)) {
            continue;
        }

        if (cfg.hasKey("Actions") || cfg.hasKey("X-KDE-GetActionMenu")) {
            if (!checkTypesMatch(cfg)) {
                continue;
            }

            const QString priority = cfg.readEntry("X-KDE-Priority");
            const QString submenuName = cfg.readEntry("X-KDE-Submenu");

            ServiceList &list = s.selectList(priority, submenuName);
            const ServiceList userServices = KDesktopFileActions::userDefinedServices(KService(file), isLocal, urlList);
            for (const KServiceAction &action : userServices) {
                if (showGroup.readEntry(action.name(), true) && !excludeList.contains(action.name())) {
                    list += action;
                }
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const AuthInfoContainer *current : *authList) {
            qCDebug(category) << "Evaluating: " << current->info.url.scheme()
                     << current->info.url.host()
                     << current->info.username;
            if (current->info.url.scheme() == protocol &&
               current->info.url.host() == host &&
               (current->info.username == user || user.isEmpty()))
            {
                qCDebug(category) << "Removing this entry";
                removeAuthInfoItem(dictIterator.key(), current->info);
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->slotIconsView(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (KSslError::Error e : errors)
        if (!isErrorIgnored(e)) {
            d->ignoredErrors.append(e);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &text) {
        slotPathBoxChanged(text);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &folder : folders) {
                    label.append(QStringLiteral("\n"));
                    label.append(indentation);
                    label.append(folder);
                    label.append(QStringLiteral("/"));
                    indentation.append(QStringLiteral("    "));
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &key : stringListAttributes) {
            if (config.hasKey(key)) {
                protocolData.insert(key, config.readEntry(key, QStringList()));
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &path) { d->_k_slotFileChange(path); }
```

#### LAMBDA EXPRESSION 


```{c}
[currValue](KIconLoader::StdSizes size) { return size < currValue; }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : indexes) {
            QCOMPARE(index.data(KFilePlacesModel::GroupHiddenRole).toBool(), groupShouldBeHidden);
        }
```

#### AUTO 


```{c}
auto it = std::find_if(m_stdIconSizes.crbegin(), r_itEnd, [currValue](KIconLoader::StdSizes size) {
        return size < currValue;
    });
```

#### AUTO 


```{c}
auto renameSignal = &KIO::AskUserActionInterface::askUserRenameResult;
```

#### RANGE FOR STATEMENT 


```{c}
for (KCoreDirLister *listit : qAsConst(listersWithoutJob)) {
        qCWarning(KIO_CORE) << "Fatal Error: HUH? Lister" << listit << "is supposed to be listing, but has no job!";
        abort();
    }
```

#### AUTO 


```{c}
auto locations = QStandardPaths::standardLocations(mapping[i].location);
```

#### AUTO 


```{c}
auto *processRunner = new KProcessRunner(d->m_service, { d->m_urls.at(i) },
                                                     d->m_runFlags, d->m_suggestedFileName, QByteArray());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QHostAddress &address : info.addresses()) {
                if (!isSpecialAddress(address) && isIPv4Address(address) && address.isInSubnet(subnet)) {
                    isInSubNet = true;
                    break;
                }
            }
```

#### AUTO 


```{c}
auto MinWidth = [](const KUrlNavigatorButton *button) {
        return button->minimumWidth();
    };
```

#### LAMBDA EXPRESSION 


```{c}
[&db, commonMimeType](const KPluginMetaData& metaData) {
        if (!metaData.serviceTypes().contains(QStringLiteral("KFileItemAction/Plugin"))) {
            return false;
        }

        auto mimeType = db.mimeTypeForName(commonMimeType);
        foreach (const auto& supportedMimeType, metaData.mimeTypes()) {
            if (mimeType.inherits(supportedMimeType)) {
                return true;
            }
        }

        return false;
    }
```

#### AUTO 


```{c}
auto button
```

#### LAMBDA EXPRESSION 


```{c}
[this, iconSize]() {
            m_autoResizeItems = false;
            relayoutIconSize(iconSize);
            // Store the new icon size in m_iconSz; which will be used by writeConfig(),
            // otherwise if m_smoothItemResizing is true, the delegate icon size will be
            // changed after the m_adaptItemsTimeline times out, by which time writeConfig
            // has already finished, which means it won't save the new icon size
            m_iconSz = iconSize;
            writeConfig();
        }
```

#### AUTO 


```{c}
auto job2 = KIO::copy({ QUrl::fromLocalFile(testOverwriteCopy2) }, url, KIO::Overwrite);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &shorthand : shorthands) {
        for (const SearchProvider *provider : std::as_const(m_providers)) {
            if (provider != m_provider && provider->keys().contains(shorthand)) {
                contenders.insert(shorthand, provider);
                break;
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](KProcessRunner *r) { return r->waitForStarted(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (KDirModelNode *node : std::as_const(dirNode->m_childNodes)) {
            node->setPreview(QIcon());
            // node->setPreview(QIcon::fromTheme(node->item().iconName()));
            if (isDir(node)) {
                // recurse into child dirs
                clearAllPreviews(static_cast<KDirModelDirNode *>(node));
            }
            lastNode = node;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (KCoreDirLister *kdl : listers) {
            Q_EMIT kdl->started(newUrl);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->slotFilterChanged();
    }
```

#### AUTO 


```{c}
auto renameSignal = &AskUserActionInterface::askUserRenameResult;
```

#### LAMBDA EXPRESSION 


```{c}
[q](KIO::Job*, const QUrl &, const QUrl &to) {
            emit q->itemCreated(to);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : m_urls) {
        const bool local = url.isLocalFile();
        if (!local /*optimization*/ && url.scheme() == QLatin1String("trash")) {
            if (url.path().isEmpty() || url.path() == QLatin1String("/")) {
                containsTrashRoot = true;
            }
        } else {
            allItemsAreFromTrash = false;
        }
        if (url.matches(m_destUrl, QUrl::StripTrailingSlash)) {
            return KIO::ERR_DROP_ON_ITSELF;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &proxy : proxies) {
            if (proxy == QLatin1String("DIRECT")) {
                proxyList << proxy;
            } else {
                QUrl u(proxy);
                if (!u.isEmpty() && u.isValid() && !u.scheme().isEmpty()) {
                    proxyList << proxy;
                }
            }
        }
```

#### AUTO 


```{c}
auto it = std::find_if(m_navButtons.cbegin(), m_navButtons.cend(), [&p](const KUrlNavigatorButton *button) {
            return button->geometry().contains(p);
        });
```

#### LAMBDA EXPRESSION 


```{c}
[this, url]() {
                    Q_EMIT q->tabRequested(url);
                }
```

#### CONST EXPRESSION 


```{c}
static constexpr int s_maxIPCSize = 1024 * 512;
```

#### LAMBDA EXPRESSION 


```{c}
[=](bool result) {
            if (result) {
                QString errorString;
                if (untrustedProgramHandler->setExecuteBit(localPath, errorString)) {
                    executeCommand();
                } else {
                    q->setError(KJob::UserDefinedError);
                    q->setErrorText(i18n("Unable to make file \"%1\" executable.\n%2.", localPath, errorString));
                    q->emitResult();
                }
            } else {
                q->setError(KIO::ERR_USER_CANCELED);
                q->emitResult();
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &key : qAsConst(domains)) {
        KHttpCookieList *list;

        if (key.isNull()) {
            list = m_cookieDomains.value(QL1S(""));
        } else {
            list = m_cookieDomains.value(key);
        }

        if (list) {
            removeDuplicateFromList(list, cookie, false, true);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KMountPoint::Ptr mountPoint : mountPoints) {
        qDebug() << "Possible mount: " << mountPoint->mountedFrom()
                 << " (" << mountPoint->realDeviceName() << ") "
                 << mountPoint->mountPoint() << " " << mountPoint->mountType()
                 << " options:" << mountPoint->mountOptions();
        QVERIFY(!mountPoint->mountedFrom().isEmpty());
        QVERIFY(!mountPoint->mountPoint().isEmpty());
        QVERIFY(!mountPoint->mountType().isEmpty());
        QVERIFY(!mountPoint->mountOptions().isEmpty());
        // old bug, happened because KMountPoint called KStandardDirs::realPath instead of realFilePath
        QVERIFY(!mountPoint->realDeviceName().endsWith('/'));

        // keep one (any) mountpoint with a device name for the test below
        if (!mountPoint->realDeviceName().isEmpty()) {
            mountWithDevice = mountPoint;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &proxyUrl : qAsConst(m_request.proxyUrls)) {
            if (proxyUrl == QLatin1String("DIRECT")) {
                QNetworkProxy::setApplicationProxy(QNetworkProxy::NoProxy);
                connectError = connectToHost(m_request.url.host(), m_request.url.port(defaultPort()), &errorString);
                if (connectError == 0) {
                    // qDebug() << "Connected DIRECT: host=" << m_request.url.host() << "port=" << m_request.url.port(defaultPort());
                    break;
                } else {
                    continue;
                }
            }

            const QUrl url(proxyUrl);
            const QString proxyScheme(url.scheme());
            if (!supportedProxyScheme(proxyScheme)) {
                connectError = ERR_CANNOT_CONNECT;
                errorString = url.toDisplayString();
                badProxyUrls << url;
                continue;
            }

            QNetworkProxy::ProxyType proxyType = QNetworkProxy::NoProxy;
            if (proxyScheme == QLatin1String("socks")) {
                proxyType = QNetworkProxy::Socks5Proxy;
            } else if (isAutoSsl()) {
                proxyType = QNetworkProxy::HttpProxy;
            }

            qCDebug(KIO_HTTP) << "Connecting to proxy: address=" << proxyUrl << "type=" << proxyType;

            if (proxyType == QNetworkProxy::NoProxy) {
                QNetworkProxy::setApplicationProxy(QNetworkProxy::NoProxy);
                connectError = connectToHost(url.host(), url.port(), &errorString);
                if (connectError == 0) {
                    m_request.proxyUrl = url;
                    // qDebug() << "Connected to proxy: host=" << url.host() << "port=" << url.port();
                    break;
                } else {
                    if (connectError == ERR_UNKNOWN_HOST) {
                        connectError = ERR_UNKNOWN_PROXY_HOST;
                    }
                    // qDebug() << "Failed to connect to proxy:" << proxyUrl;
                    badProxyUrls << url;
                }
            } else {
                QNetworkProxy proxy(proxyType, url.host(), url.port(), url.userName(), url.password());
                QNetworkProxy::setApplicationProxy(proxy);
                connectError = connectToHost(m_request.url.host(), m_request.url.port(defaultPort()), &errorString);
                if (connectError == 0) {
                    qCDebug(KIO_HTTP) << "Tunneling thru proxy: host=" << url.host() << "port=" << url.port();
                    break;
                } else {
                    if (connectError == ERR_UNKNOWN_HOST) {
                        connectError = ERR_UNKNOWN_PROXY_HOST;
                    }
                    qCDebug(KIO_HTTP) << "Failed to connect to proxy:" << proxyUrl;
                    badProxyUrls << url;
                    QNetworkProxy::setApplicationProxy(QNetworkProxy::NoProxy);
                }
            }
        }
```

#### AUTO 


```{c}
auto it = opQueue.crbegin();
```

#### LAMBDA EXPRESSION 


```{c}
[this](const KService::Ptr &service) {
        Q_ASSERT(service);
        m_service = service;
        q->start();
    }
```

#### AUTO 


```{c}
auto createSystemBookmark = [this, &seenUrls](const char *translationContext,
                const QByteArray &untranslatedLabel,
                const QUrl &url,
                const QString &iconName,
                const KBookmark &after) {
            if (!seenUrls.contains(url)) {
                return KFilePlacesItem::createSystemBookmark(d->bookmarkManager, translationContext, untranslatedLabel, url, iconName, after);
            }
            return KBookmark();
        };
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {

        const QString checksum = futureWatcher->result();
        futureWatcher->deleteLater();

        cacheChecksum(checksum, algorithm);

        switch (algorithm) {
        case QCryptographicHash::Md5:
            slotShowMd5();
            break;
        case QCryptographicHash::Sha1:
            slotShowSha1();
            break;
        case QCryptographicHash::Sha256:
            slotShowSha256();
            break;
        default:
            break;
        }

        const bool isMatch = (checksum == input);
        if (isMatch) {
            setMatchState();
        } else {
            setMismatchState();
        }
    }
```

#### AUTO 


```{c}
auto job = KIO::copy({ QUrl::fromLocalFile(testCopy2) }, url, KIO::Resume);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &key : keys) {
            if (key == QLatin1String("CertificatePEM")) {
                continue;
            }
            KSslCertificateRule r = rule(QSslCertificate(certDigest), key);
        }
```

#### AUTO 


```{c}
const auto &info
```

#### LAMBDA EXPRESSION 


```{c}
[=](bool result) {
            this->rmdirResult(result);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&] {
        QVERIFY(QFile::remove(dest));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &domain : domainList) {
            const KHttpCookieList *list =  mCookieJar->getCookieList(domain, fqdn);
            if (!list) {
                continue;
            }
            Q_FOREACH (const KHttpCookie &cookie, *list) {
                if (cookie.isExpired()) {
                    continue;
                }
                putCookie(result, cookie, fields);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &url : list) {
        if (atmost-- == 0) {
            break;
        }

        // we strip the last slash (-1) because KUrlComboBox does that as well
        // when operating in file-mode. If we wouldn't , dupe-finding wouldn't
        // work.
        const QString file = url.toDisplayString(QUrl::StripTrailingSlash | QUrl::PreferLocalFile);

        // remove dupes
        for (int i = 1; i < d->m_locationEdit->count(); ++i) {
            if (d->m_locationEdit->itemText(i) == file) {
                d->m_locationEdit->removeItem(i--);
                break;
            }
        }
        // FIXME I don't think this works correctly when the KUrlComboBox has some default urls.
        // KUrlComboBox should provide a function to add an url and rotate the existing ones, keeping
        // track of maxItems, and we shouldn't be able to insert items as we please.
        d->m_locationEdit->insertItem(1, file);
    }
```

#### AUTO 


```{c}
auto current = d->m_coreUrlNavigator->locationState().value<KUrlNavigatorData>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &item : qAsConst(dir->lstItems)) {
        fileItems.insert(item.name(), item);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &rlitem : refList) {
                if (found) {
                    break;
                }

                const QRegularExpression rangeRe(QStringLiteral("([0-9]*)\\-([0-9]*)"));
                const QRegularExpressionMatch rangeMatch = rangeRe.match(rlitem);
                // Substitute a range of keywords
                if (rangeMatch.hasMatch()) {
                    int first = rangeMatch.captured(1).toInt();
                    int last = rangeMatch.captured(2).toInt();

                    if (first == 0) {
                        first = 1;
                    }

                    if (last == 0) {
                        last = count;
                    }

                    for (int i = first; i <= last; i++) {
                        v += map[QString::number(i)] + QLatin1Char(' ');
                        // Remove used value from ql (needed for \{@}):
                        ql[i - 1].clear();
                    }

                    v = v.trimmed();
                    if (!v.isEmpty()) {
                        found = true;
                    }

                    PDVAR(QLatin1String("    range"),
                          QString::number(first) + QLatin1Char('-') + QString::number(last) + QLatin1String(" => '") + v + QLatin1Char('\''));
                    v = encodeString(v, codec);
                } else if (rlitem.startsWith(QLatin1Char('\"')) && rlitem.endsWith(QLatin1Char('\"'))) {
                    // Use default string from query definition:
                    found = true;
                    QString s = rlitem.mid(1, rlitem.length() - 2);
                    v = encodeString(s, codec);
                    PDVAR("    default", s);
                } else if (map.contains(rlitem)) {
                    // Use value from substitution map:
                    found = true;
                    PDVAR(QLatin1String("    map['") + rlitem + QLatin1String("']"), map[rlitem]);
                    v = encodeString(map[rlitem], codec);

                    // Remove used value from ql (needed for \{@}):
                    const QChar c = rlitem.at(0); // rlitem can't be empty at this point
                    if (c == QLatin1Char('0')) {
                        // It's a numeric reference to '0'
                        for (QStringList::Iterator it = ql.begin(); it != ql.end(); ++it) {
                            (*it).clear();
                        }
                    } else if ((c >= QLatin1String("0")) && (c <= QLatin1String("9"))) { // krazy:excludeall=doublequote_chars
                        // It's a numeric reference > '0'
                        int n = rlitem.toInt();
                        ql[n - 1].clear();
                    } else {
                        // It's a alphanumeric reference
                        QStringList::Iterator it = ql.begin();
                        while ((it != ql.end()) && !it->startsWith(rlitem + QLatin1Char('='))) {
                            ++it;
                        }
                        if (it != ql.end()) {
                            it->clear();
                        }
                    }

                    // Encode '+', otherwise it would be interpreted as space in the resulting url:
                    v.replace(QLatin1Char('+'), QLatin1String("%2B"));
                } else if (rlitem == QLatin1String("@")) {
                    v = QStringLiteral("\\@");
                    PDVAR("    v", v);
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QSslError &e : qsslErrors) {
        d->sslErrors.append(KSslError(e));
    }
```

#### AUTO 


```{c}
const auto handlers = KApplicationTrader::queryByMimeType(QLatin1String("x-scheme-handler/") + url.scheme());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &item : items) {
        const bool isDir = item.isDir();
        KDirModelNode *node = isDir ? new KDirModelDirNode(dirNode, item) : new KDirModelNode(dirNode, item);
#ifndef NDEBUG
        // Test code for possible duplication of items in the childnodes list,
        // not sure if/how it ever happened.
        // if (dirNode->m_childNodes.count() &&
        //    dirNode->m_childNodes.last()->item().name() == item.name()) {
        //    qCWarning(category) << "Already having" << item.name() << "in" << directoryUrl
        //             << "url=" << dirNode->m_childNodes.last()->item().url();
        //    abort();
        //}
#endif
        dirNode->m_childNodes.append(node);
        const QUrl url = item.url();
        m_nodeHash.insert(cleanupUrl(url), node);

        if (!urlsBeingFetched.isEmpty()) {
            const QUrl &dirUrl = url;
            for (const QUrl &urlFetched : std::as_const(urlsBeingFetched)) {
                if (dirUrl.matches(urlFetched, QUrl::StripTrailingSlash) || dirUrl.isParentOf(urlFetched)) {
                    // qDebug() << "Listing found" << dirUrl.url() << "which is a parent of fetched url" << urlFetched;
                    const QModelIndex parentIndex = indexForNode(node, dirNode->m_childNodes.count() - 1);
                    Q_ASSERT(parentIndex.isValid());
                    emitExpandFor.append(parentIndex);
                    if (isDir && dirUrl != urlFetched) {
                        q->fetchMore(parentIndex);
                        m_urlsBeingFetched[node].append(urlFetched);
                    }
                }
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->slotStarted(); }
```

#### AUTO 


```{c}
auto nameJob = new KIO::NameFinderJob(d->m_baseUrl, name, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (KCoreDirLister *kdl : qAsConst(curListers)) { // listers of newUrl
                kdl->d->jobDone(oldJob);

                kdl->jobStarted(job);
                kdl->d->connectJob(job);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QModelIndex &index) {
        QSignalSpy completedSpy(m_dirModel->dirLister(), qOverload<>(&KDirLister::completed));
        m_dirModel->fetchMore(index);
        return completedSpy.wait();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KHttpCookie &cookie : *list) {
                if (cookie.isExpired()) {
                    continue;
                }
                if (cookieMatches(cookie, domain, fqdn, path, name)) {
                    putCookie(result, cookie, fields);
                    break;
                }
            }
```

#### AUTO 


```{c}
auto it = findProvider(shorthand);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &domain : qAsConst(m_domainList)) {
        KCookieAdvice advice = getDomainAdvice(domain);
        if (advice != KCookieDunno) {
            const QString value = domain + QL1C(':') + adviceToStr(advice);
            domainSettings.append(value);
        }
    }
```

#### AUTO 


```{c}
auto trit = m_trashDirectories.cbegin();
```

#### LAMBDA EXPRESSION 


```{c}
[q](KJob *job, qulonglong totalSize) {
        Q_UNUSED(job);
        if (totalSize != q->totalAmount(KJob::Bytes)) {
            q->setTotalAmount(KJob::Bytes, totalSize);
        }
    }
```

#### AUTO 


```{c}
static auto *askUserInterface = delegate ? delegate->findChild<AskUserActionInterface *>(QString(), Qt::FindDirectChildrenOnly) : nullptr;
```

#### LAMBDA EXPRESSION 


```{c}
[&app, fileWidget]() {
        qDebug() << "accepted";
        fileWidget->accept();
        qDebug() << fileWidget->selectedFile();
        qDebug() << fileWidget->selectedUrl();
        qDebug() << fileWidget->selectedFiles();
        qDebug() << fileWidget->selectedUrls();
        app.exit();
    }
```

#### AUTO 


```{c}
const auto socketError = socket->error();
```

#### LAMBDA EXPRESSION 


```{c}
[this](KIO::Job *job, QByteArray &data) {
        _k_slotDataReq(job, data);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, dlg]() {
            _k_slotOtherDesktopFile(dlg);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, &seenUrls](const char *untranslatedLabel,
                              const QUrl &url,
                              const QString &iconName,
                              const KBookmark &after) {
                if (!seenUrls.contains(url)) {
                    return KFilePlacesItem::createSystemBookmark(d->bookmarkManager, untranslatedLabel, url, iconName, after);
                }
                return KBookmark();
            }
```

#### AUTO 


```{c}
auto match = sEnvVarExp.match(path);
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : m_pluginActions) {
        removeAction(action);
    }
```

#### AUTO 


```{c}
const auto [it, isInserted] = extensions.insert(extension);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &proxy : std::as_const(proxyList)) {
            QUrl u(proxy);
            if (u.isValid() && KProtocolInfo::isKnownProtocol(u.scheme())) {
                protocol = u.scheme();
                break;
            }
        }
```

#### AUTO 


```{c}
static constexpr auto DEFAULT_CACHE_CONTROL = KIO::CC_Refresh;
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &item : std::as_const(m_dispatchedItems)) {
        KFileItemList::iterator begin = m_pendingItems.begin();
        KFileItemList::iterator end = m_pendingItems.end();
        for (KFileItemList::iterator it = begin; it != end; ++it) {
            if ((*it).url() == item.url()) {
                m_pendingItems.erase(it);
                break;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &deletedUrl : std::as_const(affectedItems)) {
        // stop all jobs for deletedUrlStr
        auto dit = directoryData.constFind(deletedUrl);
        if (dit != directoryData.cend()) {
            // we need a copy because stop modifies the list
            const QList<KCoreDirLister *> listers = (*dit).listersCurrentlyListing;
            for (KCoreDirLister *kdl : listers) {
                stopListingUrl(kdl, deletedUrl);
            }
            // tell listers holding deletedUrl to forget about it
            // this will stop running updates for deletedUrl as well

            // we need a copy because forgetDirs modifies the list
            const QList<KCoreDirLister *> holders = (*dit).listersCurrentlyHolding;
            for (KCoreDirLister *kdl : holders) {
                // lister's root is the deleted item
                if (kdl->d->url == deletedUrl) {
                    // tell the view first. It might need the subdirs' items (which forgetDirs will delete)
                    if (!kdl->d->rootFileItem.isNull()) {
                        Q_EMIT kdl->itemsDeleted(KFileItemList{kdl->d->rootFileItem});
                    }
                    forgetDirs(kdl);
                    kdl->d->rootFileItem = KFileItem();
                } else {
                    const bool treeview = kdl->d->lstDirs.count() > 1;
                    if (!treeview) {
                        Q_EMIT kdl->clear();
                        kdl->d->lstDirs.clear();
                    } else {
                        kdl->d->lstDirs.removeAll(deletedUrl);
                    }

                    forgetDirs(kdl, deletedUrl, treeview);
                }
            }
        }

        // delete the entry for deletedUrl - should not be needed, it's in
        // items cached now
        int count = itemsInUse.remove(deletedUrl);
        Q_ASSERT(count == 0);
        Q_UNUSED(count); // keep gcc "unused variable" complaining quiet when in release mode
    }
```

#### AUTO 


```{c}
auto url = QUrl::fromLocalFile(origPath);
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : std::as_const(m_appActions)) {
        removeAction(action);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &item : items) {
                it = std::lower_bound(it, lstItems.end(), item.url());
                it = lstItems.insert(it, item);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &plugin : plugins) {
        QStringList protocols = plugin.value(QStringLiteral("X-KDE-Protocols"), QStringList());
        const QString p = plugin.value(QStringLiteral("X-KDE-Protocol"));
        if (!p.isEmpty()) {
            protocols.append(p);
        }
        for (const QString &protocol : std::as_const(protocols)) {
            // Add supported MIME type for this protocol
            QStringList &_ms = m_remoteProtocolPlugins[protocol];
            const auto mimeTypes = plugin.mimeTypes();
            for (const QString &_m : mimeTypes) {
                protocolMap[protocol].insert(_m, plugin);
                if (!_ms.contains(_m)) {
                    _ms.append(_m);
                }
            }
        }
        if (enabledPlugins.contains(plugin.pluginId())) {
            const auto mimeTypes = plugin.mimeTypes();
            for (const QString &mimeType : mimeTypes) {
                mimeMap.insert(mimeType, plugin);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &udi : qAsConst(devices)) {
        bookmark = KFilePlacesItem::createDeviceBookmark(bookmarkManager, udi);
        if (!bookmark.isNull()) {
            KFilePlacesItem *item = new KFilePlacesItem(bookmarkManager,
                    bookmark.address(), udi);
            connect(item, &KFilePlacesItem::itemChanged,
                    q, [this](const QString &id) { _k_itemChanged(id); });
            // TODO: Update bookmark internal element
            items << item;
        }
    }
```

#### AUTO 


```{c}
auto shouldReplace = [](const QString &l) {
        return l == QLatin1String("en_US");
    };
```

#### LAMBDA EXPRESSION 


```{c}
[](QAction *act) {
            return act->text().contains("Custom");
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KHttpCookie &cookie : list) {
        dbg << cookie;
    }
```

#### AUTO 


```{c}
auto err = execWithElevatedPrivilege(CHOWN, {_dest, getuid(), getgid()}, errno)
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &shorthand : shorthands) {
        auto it = findProvider(shorthand);
        if (it != m_providers.cend()) {
            contenders.insert(shorthand, *it);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &i : list) {

        if (i == itemMimeType || i == QLatin1String("all/all")) {
            return true;
        }

        if (item.isFile() && (i == QLatin1String("allfiles") ||
            i == QLatin1String("all/allfiles") || i == QLatin1String("application/octet-stream"))) {
            return true;
        }

        if (item.currentMimeType().inherits(i)) {
            return true;
        }

        const int iSlashPos = i.indexOf(QLatin1Char(QLatin1Char('/')));
        Q_ASSERT(iSlashPos > 0);
        const QStringRef iSubType = i.midRef(iSlashPos+1);

        if (iSubType == QLatin1String("*")) {
            const int itemSlashPos = itemMimeType.indexOf(QLatin1Char('/'));
            Q_ASSERT(itemSlashPos > 0);
            const QStringRef iTopLevelType = i.midRef(0, iSlashPos);
            const QStringRef itemTopLevelType = itemMimeType.midRef(0, itemSlashPos);

            if (itemTopLevelType == iTopLevelType) {
                return true;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const GetRequest &entry : queue) {
        stream << entry.url << entry.metaData;
    }
```

#### AUTO 


```{c}
const auto writeOnce = [&putDataBuffer, &size, putDataContents]() {
        const auto pos = putDataBuffer.pos();
        size += putDataBuffer.write(putDataContents);
        putDataBuffer.seek(pos);
//         qDebug() << "written" << size;
    };
```

#### AUTO 


```{c}
auto parentFdCleanup = qScopeGuard([parent_fd]() {
        close(parent_fd);
    });
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job, qulonglong _psize){ _k_slotProcessedSize(job, _psize); }
```

#### AUTO 


```{c}
auto it = std::find_if(args.cbegin(), args.cend(), [](const QString &arg) {
        return !arg.contains(QLatin1Char('='));
    });
```

#### AUTO 


```{c}
const auto fileSystem = KFileSystemType::fileSystemType(m_globalDest.toLocalFile());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &trashPath: qAsConst(m_trashDirectories)) {

            TrashSizeCache trashSize(trashPath);
            TrashSizeCache::SizeAndModTime res = trashSize.calculateSizeAndLatestModDate();
            size += res.size;

            // Find latest modification date
            if (res.mtime > latestModifiedDate) {
                latestModifiedDate = res.mtime;
            }
        }
```

#### AUTO 


```{c}
auto err = execWithElevatedPrivilege(DEL, {_path}, errno)
```

#### AUTO 


```{c}
auto err = execWithElevatedPrivilege(DEL, _path)
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl& url : urls) {
        KIO::StatJob *job = KIO::stat(url);
        KJobWidgets::setWindow(job, parent);
        job->exec();
        KIO::UDSEntry entry = job->statResult();

        d->m_items.append(KFileItem(entry, url));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KPropertiesDialogPlugin *it : qAsConst(d->m_pageList)) {
        if (auto *filePropsPlugin = qobject_cast<KFilePropsPlugin *>(it)) {
            filePropsPlugin->setFileNameReadOnly(ro);
        } else if (auto *urlPropsPlugin = qobject_cast<KUrlPropsPlugin *>(it)) {
            urlPropsPlugin->setFileNameReadOnly(ro);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &device) {
        _k_deviceAdded(device);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KSslError &error : qAsConst(ud->sslErrors)) {
                    if (error.certificate() == cert) {
                        // we keep only the error code enum here
                        errors.append(error.error());
                    }
                }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        if (moveDirs) {
            QDir().rmdir(file1);
            QDir().rmdir(file2);
            QDir().rmdir(file3);
            QDir().rmdir(file4);
        } else {
            QFile::remove(file1);
            QFile::remove(file2);
            QFile::remove(file3);
            QFile::remove(file4);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &dir : parentDirUrls) {
            DirItem *dirItem = dirItemForUrl(dir);
            if (!dirItem) {
                continue;
            }

            auto dirItemIt = std::find_if(dirItem->lstItems.begin(), dirItem->lstItems.end(), [&url](const KFileItem &fitem) {
                return fitem.url() == url;
            });
            if (dirItemIt != dirItem->lstItems.end()) {
                const KFileItem fileitem = *dirItemIt;
                removedItemsByDir[dir].append(fileitem);
                // If we found a fileitem, we can test if it's a dir. If not, we'll go to deleteDir just in case.
                if (fileitem.isNull() || fileitem.isDir()) {
                    deletedSubdirs.append(url);
                }
                dirItem->lstItems.erase(dirItemIt); // remove fileitem from list
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](int step) {
        slotIconSizeChanged(m_stdIconSizes[step]);
    }
```

#### AUTO 


```{c}
auto instance = makeInstance(KIO::DesktopExecParser::executablePath(service->exec()));
```

#### LAMBDA EXPRESSION 


```{c}
[this, ACLChange, defaultACLChange](KIO::ChmodJob *chmodJob) {
        if (!d->fileSystemSupportsACLs) {
            return;
        }

        if (ACLChange) {
            chmodJob->addMetaData(QStringLiteral("ACL_STRING"), d->extendedACL.isValid() ? d->extendedACL.asString() : QStringLiteral("ACL_DELETE"));
        }

        if (defaultACLChange) {
            chmodJob->addMetaData(QStringLiteral("DEFAULT_ACL_STRING"), d->defaultACL.isValid() ? d->defaultACL.asString() : QStringLiteral("ACL_DELETE"));
        }
    }
```

#### AUTO 


```{c}
auto job = KIO::copy({QUrl::fromLocalFile(QFINDTESTDATA("ftp/testOverwriteCopy2"))}, url, KIO::DefaultFlags);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->triggerDevicePolling();
    }
```

#### AUTO 


```{c}
auto kit = allItems->constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (KCoreDirLister *kdl : listers) {
                curListers.append(kdl);
            }
```

#### AUTO 


```{c}
auto err = execWithElevatedPrivilege(RENAME, {dest, dest_orig}, errno)
```

#### AUTO 


```{c}
const auto applicationElement = apps.at(i).toElement();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                resolveMimeType();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &pluginMetaData : std::as_const(plugins)) {
        const QString fileName = pluginMetaData.fileName().section(QLatin1Char('/'), -1);
        if (!pluginNames.contains(fileName)) {
            pluginNames << fileName;
            if (auto plugin = KPluginFactory::instantiatePlugin<KUriFilterPlugin>(pluginMetaData).plugin) {
                d->pluginList << plugin;
            }
        }
    }
```

#### AUTO 


```{c}
auto it = std::find_if(list.cbegin(), list.cend(), [](QAction *act) {
            return act->text().contains("Custom");
        });
```

#### AUTO 


```{c}
const auto extraFields = KProtocolInfo::extraFields(url);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &dirUrl : std::as_const(dirsToUpdate)) {
        updateDirectory(dirUrl);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](RenameDialog_Result result, const QUrl &newUrl, KJob *parentJob) {
        Q_ASSERT(parentJob == q);
        // Only receive askUserRenameResult once per rename dialog
        QObject::disconnect(askUserActionInterface, renameSignal, q, nullptr);

        if (m_reportTimer) {
            m_reportTimer->start(REPORT_TIMEOUT);
        }

        const QString existingDest = (*it).uDest.path();

        switch (result) {
        case Result_Cancel:
            q->setError(ERR_USER_CANCELED);
            q->emitResult();
            return;
        case Result_AutoRename:
            m_bAutoRenameDirs = true;
            // fall through
            Q_FALLTHROUGH();
        case Result_Rename:
            renameDirectory(it, newUrl);
            break;
        case Result_AutoSkip:
            m_bAutoSkipDirs = true;
            // fall through
            Q_FALLTHROUGH();
        case Result_Skip:
            m_skipList.append(existingDest);
            skip((*it).uSource, true);
            // Move on to next dir
            dirs.erase(it);
            ++m_processedDirs;
            break;
        case Result_Overwrite:
            m_overwriteList.insert(existingDest);
            Q_EMIT q->copyingDone(q, (*it).uSource, finalDestUrl((*it).uSource, (*it).uDest), (*it).mtime, true /* directory */, false /* renamed */);
            // Move on to next dir
            dirs.erase(it);
            ++m_processedDirs;
            break;
        case Result_OverwriteAll:
            m_bOverwriteAllDirs = true;
            Q_EMIT q->copyingDone(q, (*it).uSource, finalDestUrl((*it).uSource, (*it).uDest), (*it).mtime, true /* directory */, false /* renamed */);
            // Move on to next dir
            dirs.erase(it);
            ++m_processedDirs;
            break;
        default:
            Q_ASSERT(0);
        }
        state = STATE_CREATING_DIRS;
        createNextDir();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob* job, const QString &info) { _k_slotInfoMessage(job, info); }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { _k_slotOpenDialog(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCoreDirLister *kdl : listers) {
            KCoreDirLister::Private::CachedItemsJob *cachedItemsJob = kdl->d->cachedItemsJobForUrl(dir);
            if (cachedItemsJob) {
                cachedItemsJob->setEmitCompleted(false);
                cachedItemsJob->done(); // removes from cachedItemsJobs list
                delete cachedItemsJob;
                killed = true;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Request *request : qAsConst(m_authPending)) {
        if (request->key != key) {
            continue;
        }

        if (info.verifyPath) {
            const QString path1(request->info.url.path().left(info.url.path().indexOf(QLatin1Char('/')) + 1));
            if (!path2.startsWith(path1)) {
                continue;
            }
        }

        return true;
    }
```

#### AUTO 


```{c}
auto *autoAct = new QAction(i18nc("@item:inmenu Auto set icon size based on available space in"
                                      "the Places side-panel", "Auto Resize"),
                                group);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &urlFetched : qAsConst(urlsBeingFetched)) {
                if (dirUrl.matches(urlFetched, QUrl::StripTrailingSlash) || dirUrl.isParentOf(urlFetched)) {
                    // qDebug() << "Listing found" << dirUrl.url() << "which is a parent of fetched url" << urlFetched;
                    const QModelIndex parentIndex = indexForNode(node, dirNode->m_childNodes.count() - 1);
                    Q_ASSERT(parentIndex.isValid());
                    emitExpandFor.append(parentIndex);
                    if (isDir && dirUrl != urlFetched) {
                        q->fetchMore(parentIndex);
                        m_urlsBeingFetched[node].append(urlFetched);
                    }
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                    dispatchIconUpdateQueue();
                }
```

#### AUTO 


```{c}
const auto apps = reader.elementsByTagName("bookmark:application");
```

#### AUTO 


```{c}
auto it = std::find_if(storage.cbegin(), storage.cend(),
                                  [udsField](const Field &entry) {return entry.m_index == udsField;});
```

#### AUTO 


```{c}
constexpr auto details = KIO::StatBasic | KIO::StatResolveSymlink;
```

#### AUTO 


```{c}
auto it = protocolMap.constFind(item.item.url().scheme());
```

#### AUTO 


```{c}
auto err = tryOpen(f, QFile::encodeName(path), O_RDONLY, S_IRUSR)
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &filter : list) {
                QString match = findMatchingFilter(filter, filename);
                if (!match.isEmpty()) {
                    if (match != QLatin1String("*")) { // never match the catch-all filter
                        m_filterWidget->setCurrentFilter(filter);
                    }
                    return; // do not repeat, could match a later filter
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (KCoreDirLister *kdl : listers) {
        kdl->d->emitItemsDeleted(deletedItems);
    }
```

#### AUTO 


```{c}
auto it = std::remove_if(toRemove.begin(), toRemove.end(), [beforeOpenWith](QAction *a) {
        return beforeOpenWith.contains(a);
    });
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { resumeIconUpdates(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const KFileItem &item) {
        d->fileSelected(item);
    }
```

#### AUTO 


```{c}
const auto qsslErrors = d->sock.sslErrors();
```

#### LAMBDA EXPRESSION 


```{c}
[](const KSslError::Error &e) {
        return e == KSslError::NoPeerCertificate || e == KSslError::PathLengthExceeded;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : std::as_const(indexes)) {
        QUrl itemUrl = url(index);
        if (itemUrl.isValid()) {
            urls << itemUrl;
        }
        stream << index.row();
    }
```

#### AUTO 


```{c}
auto job = KIO::copy({ QUrl::fromLocalFile(testOverwriteCopy2) }, url, KIO::DefaultFlags);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const int result) {
        Q_EMIT q->messageBoxResult(result == QDialogButtonBox::Ok ? KIO::SlaveBase::Ok : KIO::SlaveBase::Cancel);
    }
```

#### AUTO 


```{c}
const auto *button = *it;
```

#### AUTO 


```{c}
auto *job = new KIO::ApplicationLauncherJob(serviceAction);
```

#### RANGE FOR STATEMENT 


```{c}
for (KCoreDirLister *kdl : listers) {
            kdl->d->jobDone(job);
            if (job->error() != KJob::KilledJobError) {
                Q_EMIT kdl->jobError(job);
                if (kdl->d->m_autoErrorHandling && !errorShown) {
                    errorShown = true; // do it only once
                    if (job->uiDelegate()) {
                        job->uiDelegate()->showErrorMessage();
                    }
                }
#if KIOCORE_BUILD_DEPRECATED_SINCE(5, 82)
                kdl->handleError(job);
#endif
            }
            const bool silent = job->property("_kdlc_silent").toBool();
            if (!silent) {
#if KIOCORE_BUILD_DEPRECATED_SINCE(5, 79)
                Q_EMIT kdl->canceled(jobUrl);
#endif
                Q_EMIT kdl->listingDirCanceled(jobUrl);
            }

            if (kdl->d->numJobs() == 0) {
                kdl->d->complete = true;
                if (!silent) {
                    Q_EMIT kdl->canceled();
                }
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        clipboard->setText(d->m_sha1);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for  (const KCoreDirLister *kdl : listers) {
        delayedMimeTypes &= kdl->d->delayedMimeTypes;
    }
```

#### AUTO 


```{c}
const auto [it, isNewInode] = visitedInodes.insert(inode);
```

#### RANGE FOR STATEMENT 


```{c}
for (int port : std::as_const(mPorts)) {
                    portNums += QString::number(port) + QLatin1Char(' ');
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QHostAddress &address : info.addresses()) {
                if (!isSpecialAddress(address)) {
                    addressList << address.toString();
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &r : qAsConst(d->m_processRunners)) {
        if (!r.isNull()) {
            qApp->sendPostedEvents(r); // so slotStarted gets called
        }
    }
```

#### AUTO 


```{c}
auto r_itEnd = stdIconSizes.crend();
```

#### RANGE FOR STATEMENT 


```{c}
for (const KMountPoint::Ptr &mountPoint : *this) {
        if (realDevice.compare(mountPoint->d->device, cs) == 0 ||
                realDevice.compare(mountPoint->d->mountedFrom, cs) == 0) {
            return mountPoint;
        }
    }
```

#### AUTO 


```{c}
auto seekFillBuffer = [bufferSize](qint64 pos, QFile &f, QByteArray &buffer){
        auto ioresult = f.seek(pos);
        int bytesRead;
        if (ioresult) {
            bytesRead = f.read(buffer.data(), bufferSize);
            ioresult = bytesRead != -1;
        }
        if (!ioresult) {
            qCWarning(KIO_WIDGETS) << "Could not read file for comparison:" << f.fileName();
            return false;
        }
        return true;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d_func()->slotReport(); }
```

#### AUTO 


```{c}
const auto dirit = directoryData.find(url);
```

#### LAMBDA EXPRESSION 


```{c}
[=](KIO::Job *, const QString &mimetype) {
        if (m_followRedirections) { // Update our URL in case of a redirection
            m_url = job->url();
        }
        if (mimetype.isEmpty()) {
            qCWarning(KIO_GUI) << "get() didn't emit a mimetype! Probably a kioslave bug, please check the implementation of" << m_url.scheme();
        }
        m_mimeTypeName = mimetype;

        // If the current mime-type is the default mime-type, then attempt to
        // determine the "real" mimetype from the file name (bug #279675)
        const QMimeType mime = fixupMimeType(m_mimeTypeName, m_suggestedFileName.isEmpty() ? m_url.fileName() : m_suggestedFileName);
        const QString mimeName = mime.name();
        if (mime.isValid() && mimeName != m_mimeTypeName) {
            m_mimeTypeName = mimeName;
        }

        if (m_suggestedFileName.isEmpty()) {
            m_suggestedFileName = job->queryMetaData(QStringLiteral("content-disposition-filename"));
        }

        job->putOnHold();
        KIO::Scheduler::publishSlaveOnHold();
        runUrlWithMimeType();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QList<QPair<KFileItem, KFileItem>> &items) {
        d->_k_slotRefreshItems(items);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& key : intAttributes) {
            if (config.hasKey(key)) {
                protocolData.insert(key, config.readEntry(key, int(0)));
            }
        }
```

#### AUTO 


```{c}
const auto result = ftpOpenConnection(LoginMode::Implicit);
```

#### AUTO 


```{c}
auto acceptAndClose = [this]() {
        Q_EMIT applied();
        Q_EMIT propertiesClosed();
        deleteLater(); // Somewhat like Qt::WA_DeleteOnClose would do.
        KPageDialog::accept();
    };
```

#### AUTO 


```{c}
auto call = QDBusConnection::sessionBus().interface()->asyncCall(QStringLiteral("GetConnectionUnixProcessID"), m_desktopName);
```

#### AUTO 


```{c}
auto it = std::find(tagsList.begin(), tagsList.end(), tag);
```

#### LAMBDA EXPRESSION 


```{c}
[](const QList<QVariant> &spy) {
                                            return spy.at(1).toUrl().path().contains("innerfile");
                                        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QUrl &oldUrl, const QUrl &newUrl) {
        d->_k_slotRedirection(oldUrl, newUrl);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &attrName, const QString &value, const QString &fileName) {
                return QStringList{QLatin1String("user"), attrName, value, fileName};
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->slotSortByType(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &dirpath : dirList) {
        QDir dir(dirpath);
        if (!dir.exists()) {
            continue;
        }

        const QStringList filenames = dir.entryList({QStringLiteral("*.desktop")}, QDir::Files | QDir::Readable);

        KIO::UDSEntry entry;
        for (const QString &name : filenames) {
            if (!names_found.contains(name) && createEntry(entry, dirpath, name)) {
                list.append(entry);
                names_found.append(name);
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &text) {
        mUi.useSameProxyCheckBox->setEnabled(!text.isEmpty());
    }
```

#### AUTO 


```{c}
auto bookmarksGroups = reader.elementsByTagName("bookmark:groups");
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        slotReport();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QModelIndex &index) {
        d->actionLeft(index);
    }
```

#### AUTO 


```{c}
const auto locations = QStandardPaths::standardLocations(mapping[i].location);
```

#### LAMBDA EXPRESSION 


```{c}
[&] {
        QDir(srcDir).removeRecursively();
        QDir(destDir).removeRecursively();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QSslCertificate &cert : qAsConst(ud->certificateChain)) {
                QList<QSslError::SslError> errors;
                for (const QSslError &error : qAsConst(ud->sslErrors)) {
                    if (error.certificate() == cert) {
                        // we keep only the error code enum here
                        errors.append(error.error());
                    }
                }
                meh.append(errors);
            }
```

#### AUTO 


```{c}
auto move(const QList<QUrl>& items, const QUrl& to)
{
    auto job = KIO::move(items, to);

    Fum->recordCopyJob(job);

    return jobToFuture(QStringLiteral("move %1 to %2").arg(toStr(items)).arg(toStr(to)), job);
}
```

#### LAMBDA EXPRESSION 


```{c}
[=](const char c) {
        return dest.contains(QLatin1Char(c));
    }
```

#### AUTO 


```{c}
auto openMode = openModeFromFlags(flags);
```

#### LAMBDA EXPRESSION 


```{c}
[&dataChangedAtFirstLevel](const QModelIndex &index) {
        if (index.isValid() && !index.parent().isValid()) {
            // a change of a node whose parent is root, yay, that's it
            dataChangedAtFirstLevel = true;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](int index) {
        _k_slotActivated(index);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](int value) {
        d->_k_slotStepAnimation(value);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QThread *thread, const QStringList &matches){ slotCompletionThreadDone(thread, matches); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : std::as_const(m_srcList)) {
            if (m_dest.scheme() == url.scheme() && m_dest.host() == url.host()) {
                QString srcPath = url.path();
                if (!srcPath.endsWith(QLatin1Char('/'))) {
                    srcPath += QLatin1Char('/');
                }
                if (m_dest.path().startsWith(srcPath)) {
                    q->setError(KIO::ERR_CANNOT_MOVE_INTO_ITSELF);
                    q->emitResult();
                    return;
                }
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&itemParentDir](const QUrl &dir) {
        return dir == itemParentDir || dir.path().isEmpty();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &u : std::as_const(urls)) {
            m_nodeHash.remove(u);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto groupType : {KFilePlacesModel::PlacesType,
                           KFilePlacesModel::RemoteType,
                           KFilePlacesModel::RecentlySavedType,
                           KFilePlacesModel::SearchForType,
                           KFilePlacesModel::DevicesType,
                           KFilePlacesModel::RemovableDevicesType}) {
        const bool groupShouldBeHidden = (groupType == KFilePlacesModel::SearchForType);
        const QModelIndexList indexes = m_places->groupIndexes(groupType);
        for (const QModelIndex &index : indexes) {
            QCOMPARE(index.data(KFilePlacesModel::GroupHiddenRole).toBool(), groupShouldBeHidden);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->adaptItemSize(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KService::Ptr s : services) {
        qDebug() << s->name() << " " << s->entryPath();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const KServiceAction &a1, const KServiceAction &a2) {
        return a1.name() < a2.name();
    }
```

#### AUTO 


```{c}
const auto archiveFileUrl = QUrl::fromLocalFile(temparchiveFile.fileName());
```

#### AUTO 


```{c}
auto *job = new KIO::MimeTypeFinderJob(d->m_url, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &jsonMetadata : jsonPlugins) {
        // The plugin has been disabled
        const QString pluginId = jsonMetadata.pluginId();
        if (!showGroup.readEntry(pluginId, true) || excludeList.contains(pluginId)) {
            continue;
        }

        // The plugin also has a .desktop file and has already been added.
        if (addedPlugins.contains(jsonMetadata.pluginId())) {
            continue;
        }

        KPluginFactory *factory = KPluginLoader(jsonMetadata.fileName()).factory();
        if (!factory) {
            continue;
        }
        auto *abstractPlugin = factory->create<KAbstractFileItemActionPlugin>();
        if (abstractPlugin) {
            abstractPlugin->setParent(this);
            const QList<QAction *> actions = abstractPlugin->actions(m_props, m_parentWidget);
            itemCount += actions.count();
            const QString showInSubmenu = jsonMetadata.value(QStringLiteral("X-KDE-Show-In-Submenu"));
            if (showInSubmenu == QLatin1String("true")) {
                actionsMenu->addActions(actions);
            } else {
                mainMenu->addActions(actions);
            }
            addedPlugins.append(jsonMetadata.pluginId());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &item : items) {
        QVERIFY(filteredFiles.indexOf(item.name()) != -1);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KCoreDirLister *kdl : std::as_const(listers)) {
        // For a directory, look for dirlisters where it's the root item.
        QUrl directoryUrl(oldItem.url());
        if (oldItem.isDir() && kdl->d->rootFileItem == oldItem) {
            const KFileItem oldRootItem = kdl->d->rootFileItem;
            kdl->d->rootFileItem = fileitem;
            kdl->d->addRefreshItem(directoryUrl, oldRootItem, fileitem);
        } else {
            directoryUrl = directoryUrl.adjusted(QUrl::RemoveFilename | QUrl::StripTrailingSlash);
            kdl->d->addRefreshItem(directoryUrl, oldItem, fileitem);
        }
        listersToRefresh.insert(kdl);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &dir : qAsConst(dirs)) {
        QVERIFY(!QFile::exists(dir.toLocalFile()));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : urls) {
        KFileItem item = d->m_dirLister->findByUrl(url);
        if (d->m_shouldFetchForItems && item.isNull()) {
            d->m_itemsToBeSetAsCurrent << url;
            d->m_dirModel->expandToUrl(url);
            continue;
        }
        itemList << item;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QAction *act : actionsList) {
                qDebug() << act << act->text() << act->data();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : qAsConst(m_srcList)) {
            if (m_dest.scheme() == url.scheme() && m_dest.host() == url.host()) {
                QString srcPath = url.path();
                if (!srcPath.endsWith(QLatin1Char('/')))
                    srcPath += QLatin1Char('/');
                if (m_dest.path().startsWith(srcPath)) {
                    q->setError(KIO::ERR_CANNOT_MOVE_INTO_ITSELF);
                    q->emitResult();
                    return;
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &proxyUrl : qAsConst(m_request.proxyUrls)) {
            if (proxyUrl == QLatin1String("DIRECT")) {
                QNetworkProxy::setApplicationProxy(QNetworkProxy::NoProxy);
                connectError = connectToHost(m_request.url.host(), m_request.url.port(defaultPort()), &errorString);
                if (connectError == 0) {
                    //qDebug() << "Connected DIRECT: host=" << m_request.url.host() << "port=" << m_request.url.port(defaultPort());
                    break;
                } else {
                    continue;
                }
            }

            const QUrl url(proxyUrl);
            const QString proxyScheme(url.scheme());
            if (!supportedProxyScheme(proxyScheme)) {
                connectError = ERR_CANNOT_CONNECT;
                errorString = url.toDisplayString();
                badProxyUrls << url;
                continue;
            }

            QNetworkProxy::ProxyType proxyType = QNetworkProxy::NoProxy;
            if (proxyScheme == QLatin1String("socks")) {
                proxyType = QNetworkProxy::Socks5Proxy;
            } else if (isAutoSsl()) {
                proxyType = QNetworkProxy::HttpProxy;
            }

            qCDebug(KIO_HTTP) << "Connecting to proxy: address=" << proxyUrl << "type=" << proxyType;

            if (proxyType == QNetworkProxy::NoProxy) {
                QNetworkProxy::setApplicationProxy(QNetworkProxy::NoProxy);
                connectError = connectToHost(url.host(), url.port(), &errorString);
                if (connectError == 0) {
                    m_request.proxyUrl = url;
                    //qDebug() << "Connected to proxy: host=" << url.host() << "port=" << url.port();
                    break;
                } else {
                    if (connectError == ERR_UNKNOWN_HOST) {
                        connectError = ERR_UNKNOWN_PROXY_HOST;
                    }
                    //qDebug() << "Failed to connect to proxy:" << proxyUrl;
                    badProxyUrls << url;
                }
            } else {
                QNetworkProxy proxy(proxyType, url.host(), url.port(), url.userName(), url.password());
                QNetworkProxy::setApplicationProxy(proxy);
                connectError = connectToHost(m_request.url.host(), m_request.url.port(defaultPort()), &errorString);
                if (connectError == 0) {
                    qCDebug(KIO_HTTP) << "Tunneling thru proxy: host=" << url.host() << "port=" << url.port();
                    break;
                } else {
                    if (connectError == ERR_UNKNOWN_HOST) {
                        connectError = ERR_UNKNOWN_PROXY_HOST;
                    }
                    qCDebug(KIO_HTTP) << "Failed to connect to proxy:" << proxyUrl;
                    badProxyUrls << url;
                    QNetworkProxy::setApplicationProxy(QNetworkProxy::NoProxy);
                }
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](int value) {
        d->m_iconSizeSlider->setValue(value);
        d->m_zoomOutAction->setDisabled(value <= d->m_iconSizeSlider->minimum());
        d->m_zoomInAction->setDisabled(value >= d->m_iconSizeSlider->maximum());
    }
```

#### AUTO 


```{c}
auto it = std::find_if(buttonsList.cbegin(), buttonsList.cend(), [](const QPushButton *button) {
            return button->text() == QLatin1String("&OK");
        });
```

#### RANGE FOR STATEMENT 


```{c}
for (KCModule *module : qAsConst(modules)) {
        module->save();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &service : _offers) {
        if (!excludedDesktopEntryNames.contains(service->desktopEntryName())) {
            offers << service;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        delayedIconUpdate();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &dirtyUrl : qAsConst(dirtyUrls)) {
        if (KDirModelNode *node = nodeForUrl(QUrl(dirtyUrl))) {
            const QModelIndex idx = indexForNode(node);
            emit q->dataChanged(idx, idx, {KDirModel::HasJobRole});
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : std::as_const(m_urls)) {
        args << url.toLocalFile(); // assume local files
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (int port : qAsConst(mPorts)) {
                    portNums += QString::number(port) + QL1C(' ');
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &arg : args) {
        if (!arg.contains(QLatin1Char('='))) {
            return arg;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : urls) {
        QUrl urlInfo(url);
        urlInfo.setPath(concatPaths(urlInfo.path(), fileName));
        fileUrls << urlInfo.toString();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &fileUrl : fileList) {
        const QUrl url(fileUrl);
        const KFileItem &fileitem = findByUrl(nullptr, url);
        if (fileitem.isNull()) {
            qCDebug(KIO_CORE_DIRLISTER) << "item not found for" << url;
            continue;
        }
        if (url.isLocalFile()) {
            pendingUpdates.insert(url.toLocalFile()); // delegate the work to processPendingUpdates
        } else {
            pendingRemoteUpdates.insert(fileitem);
            // For remote files, we won't be able to figure out the new information,
            // we have to do a update (directory listing)
            const QUrl dir = url.adjusted(QUrl::RemoveFilename | QUrl::StripTrailingSlash);
            if (!dirsToUpdate.contains(dir)) {
                dirsToUpdate.prepend(dir);
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&db, commonMimeType](const KPluginMetaData &metaData) {
        auto mimeType = db.mimeTypeForName(commonMimeType);
        const QStringList list = metaData.mimeTypes();
        return std::any_of(list.constBegin(), list.constEnd(), [mimeType](const QString &supportedMimeType) {
            return mimeType.inherits(supportedMimeType);
        });
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QModelIndex &idx, bool success) { _k_storageSetupDone(idx, success); }
```

#### AUTO 


```{c}
const auto &mountDir
```

#### RANGE FOR STATEMENT 


```{c}
for (const QHostAddress &address : info.addresses()) {
                if (!isSpecialAddress(address) && isIPv4Address(address)) {
                    hasResolvableIPv4Address = true;
                    break;
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this, processRunner]() {
        d->slotStarted(this, processRunner);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &protocol : protocols) {
            if (schemes.contains(protocol)) {
                return true;
            }
        }
```

