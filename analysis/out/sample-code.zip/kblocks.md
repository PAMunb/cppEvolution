#### AUTO 


```{c}
auto *prepareCellBefore = dynamic_cast<MockSvgItem*>(
        itemGroup.getPrepareCell(0)
    );
```

#### RANGE FOR STATEMENT 


```{c}
for (SvgItemInterface *pItem : qAsConst(mItemList)) {
        pItem->setOpacity(value);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (SvgItemInterface *pItem : qAsConst(mItemList)) {
        pItem->execPosAnim(value);
    }
```

#### AUTO 


```{c}
auto *freezeCellAfter = dynamic_cast<MockSvgItem*>(
        itemGroup.getFreezeCell(0)
    );
```

#### RANGE FOR STATEMENT 


```{c}
for (SvgItemInterface *pItem : std::as_const(mItemList)) {
        pItem->setOpacity(value);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (SvgItemInterface *tmpItem : std::as_const(mDropItems)) {
        tmpItem->stopPosAnim();
    }
```

#### AUTO 


```{c}
auto *prepareCellAfter = dynamic_cast<MockSvgItem*>(
        itemGroup.getPrepareCell(0)
    );
```

#### RANGE FOR STATEMENT 


```{c}
for (SvgItemInterface *pItem : std::as_const(mItemList)) {
        pItem->execPosAnim(value);
    }
```

#### AUTO 


```{c}
const auto now = std::chrono::system_clock::now();
```

#### RANGE FOR STATEMENT 


```{c}
for (KBlocksSvgItem *pItem : qAsConst(mItemList)) {
        pItem->setOpacity(value);
    }
```

#### AUTO 


```{c}
auto *freezeCellBefore = dynamic_cast<MockSvgItem*>(
        itemGroup.getFreezeCell(0)
    );
```

#### RANGE FOR STATEMENT 


```{c}
for (SvgItemInterface *tmpItem : qAsConst(mDropItems)) {
        tmpItem->stopPosAnim();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KBlocksSvgItem *tmpItem : qAsConst(mDropItems)) {
        tmpItem->stopPosAnim();
    }
```

#### AUTO 


```{c}
auto* theme
```

#### RANGE FOR STATEMENT 


```{c}
for (KBlocksSvgItem *tmpItem : qAsConst(mFadeOutItems)) {
        tmpItem->setOpacity(1);
        tmpItem->stopOpAnim();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (SvgItemInterface *tmpItem : qAsConst(mFadeOutItems)) {
        tmpItem->setOpacity(1);
        tmpItem->stopOpAnim();
    }
```

#### AUTO 


```{c}
auto *freezeCell = itemGroup.getFreezeCell(i);
```

#### AUTO 


```{c}
auto random = QRandomGenerator::global();
```

#### RANGE FOR STATEMENT 


```{c}
for (KBlocksSvgItem *pItem : qAsConst(mItemList)) {
        pItem->execPosAnim(value);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto* theme : themes) {
        if (theme->identifier() == themeIdentifier) {
            themeProvider.setCurrentTheme(theme);
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (SvgItemInterface *tmpItem : std::as_const(mFadeOutItems)) {
        tmpItem->setOpacity(1);
        tmpItem->stopOpAnim();
    }
```

#### AUTO 


```{c}
auto *prepareCell = itemGroup.getPrepareCell(i);
```

