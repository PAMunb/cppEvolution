#### RANGE FOR STATEMENT 


```{c}
for (const KeyString& keyString : keys)
        {
            Key key(keyString.latin1());
            typename Data::const_iterator it = src.findKey(key);
            typename Data::iterator destIt = dest.findKey(key);

            if (destIt == dest.end())
            {
                if (it != src.end())
                {
                    dest.add(*it);
                }
            }
            else
            {
                if (it == src.end())
                {
                    dest.erase(destIt);
                }
                else
                {
                    *destIt = *it;
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const TransformationAction& action : qAsConst(actions))
    {
        *this *= Matrix::matrix(action);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KeyString& keyString : keys)
        {
            Key key(keyString.latin1());
            typename Data::const_iterator it = src.findKey(key);

            if (it == src.end())
            {
                continue;
            }

            typename Data::iterator destIt = dest.findKey(key);

            if (destIt == dest.end())
            {
                dest.add(*it);
            }
            else
            {
                *destIt = *it;
            }
        }
```

