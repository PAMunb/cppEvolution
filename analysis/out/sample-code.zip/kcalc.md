#### AUTO 


```{c}
auto tmp_action = new QAction(i18n(scienceConstantListItem.name.toLatin1().data()), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractButton *btn : std::as_const(const_buttons_)) {
            btn->show();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractButton *btn : std::as_const(const_buttons_)) {
        if (auto const constbtn = qobject_cast<KCalcConstButton *>(btn)) {
            constbtn->setLabelAndTooltip();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractButton *btn : qAsConst(stat_buttons_)) {
			btn->show();
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (QObject *obj : leftPadLst) {
        if (auto const button = qobject_cast<KCalcButton *>(obj)) {
            button->setFont(KCalcSettings::buttonFont());
        }
    }
```

#### AUTO 


```{c}
auto const button = qobject_cast<KCalcButton *>(obj);
```

#### AUTO 


```{c}
auto const q = new knumber_fraction(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (QObject *obj : numericPadList) {
        if (auto const button = qobject_cast<KCalcButton *>(obj)) {
            // let pb0 expand freely
            if (button != pb0) {
                button->setFixedWidth(em.width() * 3 + margin * 2);
            }
            button->installEventFilter(this);
        }
    }
```

#### AUTO 


```{c}
auto btn = qobject_cast<KCalcConstButton *>(const_buttons_[button])
```

#### RANGE FOR STATEMENT 


```{c}
for(QAbstractButton *btn : qAsConst(const_buttons_)) {
			btn->hide();
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractButton *btn : qAsConst(mem_button_list_)) {
            btn->hide();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractButton *btn : std::as_const(scientific_buttons_)) {
            btn->show();
        }
```

#### AUTO 


```{c}
auto const menu = new KCalcConstMenu(i18n("&Constants"), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractButton *btn : qAsConst(function_button_list_)) {
		qobject_cast<KCalcButton*>(btn)->setTextColor(funcFontColor);
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const KNumber &x : std::as_const(data_)) {
            result += (x - mean_value) * (x - mean_value);
        }
```

#### AUTO 


```{c}
const auto bin_prec = static_cast<unsigned long int>(::ceil(precision * M_LN10 / M_LN2) + 1);
```

#### AUTO 


```{c}
auto const constbtn = qobject_cast<KCalcConstButton *>(btn)
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractButton *btn : qAsConst(scientific_buttons_)) {
            btn->show();
        }
```

#### AUTO 


```{c}
const auto rightPadLst = rightPad->children();
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractButton *btn : std::as_const(function_button_list_)) {
        btn->setStyleSheet(sheet.arg(funcPal.name()));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractButton* btn : buttons) {
            btn->show();
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractButton *btn : qAsConst(const_buttons_)) {
            btn->hide();
        }
```

#### AUTO 


```{c}
auto const central = new QWidget(this);
```

#### AUTO 


```{c}
const auto stringAtI = string.at(i);
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractButton *btn : std::as_const(function_button_list_)) {
        qobject_cast<KCalcButton *>(btn)->setTextColor(funcFontColor);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QObject *obj : numericPadLst) {
		if (auto const button = qobject_cast<KCalcButton*>(obj)) {
			button->setFont(KCalcSettings::buttonFont());
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (QObject *obj : rightPadList) {
        auto const button = qobject_cast<KCalcButton *>(obj);
        // let Shift expand freely
        if (button && button != pbShift) {
            button->setFixedWidth(em.width() * 3 + margin * 2);
            button->installEventFilter(this);
        }
    }
```

#### AUTO 


```{c}
auto label = new QLabel(this);
```

#### AUTO 


```{c}
auto modeGroup = new QActionGroup(this);
```

#### AUTO 


```{c}
auto l = new QLabel(indicatorTexts.at(0), this);
```

#### AUTO 


```{c}
auto n = new knumber_integer(den);
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractButton *btn : qAsConst(stat_buttons_)) {
        qobject_cast<KCalcButton *>(btn)->setTextColor(statFontColor);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractButton *btn : std::as_const(logic_buttons_)) {
            btn->hide();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractButton *btn : std::as_const(stat_buttons_)) {
            btn->hide();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractButton *btn : qAsConst(stat_buttons_)) {
            btn->show();
        }
```

#### AUTO 


```{c}
auto const a = new QAction(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractButton *btn : qAsConst(logic_buttons_)) {
			btn->hide();
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (QObject *obj : leftPadLst) {
		if (auto const button = qobject_cast<KCalcButton*>(obj)) {
			button->setFont(KCalcSettings::buttonFont());
		}
	}
```

#### AUTO 


```{c}
auto const dialog = new KConfigDialog(this, QStringLiteral("settings"), KCalcSettings::self());
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractButton *btn : qAsConst(const_buttons_)) {
        btn->setStyleSheet(sheet.arg(coPal.name()));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QLabel *lbl : base_conversion_labels_) {
            lbl->show();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QObject *obj : numericPadLst) {
        if (auto const button = qobject_cast<KCalcButton *>(obj)) {
            button->setFont(buttonFont);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractButton *btn : qAsConst(scientific_buttons_)) {
			btn->show();
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractButton *btn : std::as_const(const_buttons_)) {
        qobject_cast<KCalcButton *>(btn)->setTextColor(coFontColor);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractButton *btn : qAsConst(logic_buttons_)) {
            btn->show();
        }
```

#### AUTO 


```{c}
auto const p = dynamic_cast<knumber_fraction *>(rhs)
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractButton *btn : qAsConst(mem_button_list_)) {
		qobject_cast<KCalcButton*>(btn)->setTextColor(memFontColor);
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractButton *btn : qAsConst(scientific_buttons_)) {
                btn->setEnabled(true);
            }
```

#### AUTO 


```{c}
auto const p = dynamic_cast<detail::knumber_float *>(value_)
```

#### AUTO 


```{c}
auto const button = qobject_cast<KCalcButton*>(obj)
```

#### AUTO 


```{c}
auto const tmpBitButton = new BitButton(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractButton *btn : qAsConst(scientific_buttons_)) {
			btn->hide();
		}
```

#### AUTO 


```{c}
auto calc = new KCalculator(nullptr);
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractButton *btn : qAsConst(operation_button_list_)) {
        btn->setStyleSheet(sheet.arg(opPal.name()));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QLabel* lbl : base_conversion_labels_) {
			lbl->show();
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (const KNumber &x : qAsConst(data_)) {
        result += x;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QObject *obj : rightPadList) {
        if (auto const button = qobject_cast<KCalcButton *>(obj)) {
            button->setMinimumWidth(em.width() * 3 + margin * 2);
            button->setMinimumHeight(em.height() * 1.25 + margin * 2);
            button->installEventFilter(this);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractButton* btn : buttons) {
			btn->show();
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (QLabel *lbl : base_conversion_labels_) {
            lbl->hide();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractButton *btn : std::as_const(mem_button_list_)) {
            btn->hide();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractButton *btn : std::as_const(mem_button_list_)) {
        qobject_cast<KCalcButton *>(btn)->setTextColor(memFontColor);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QObject *obj : leftPadList) {
		if (auto const button = qobject_cast<KCalcButton *>(obj)) {
			button->setFixedWidth(em.width() * 4 + margin * 2);
			button->installEventFilter(this);
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractButton *btn : qAsConst(function_button_list_)) {
        qobject_cast<KCalcButton *>(btn)->setTextColor(funcFontColor);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractButton *btn : qAsConst(function_button_list_)) {
		btn->setStyleSheet(sheet.arg(funcPal.name()));
	}
```

#### AUTO 


```{c}
auto e = new knumber_error(knumber_error::ERROR_UNDEFINED);
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractButton *btn : qAsConst(mem_button_list_)) {
		btn->setStyleSheet(sheet.arg(memPal.name()));
	}
```

#### AUTO 


```{c}
auto const button = qobject_cast<KCalcButton *>(obj)
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &text : indicatorTexts) {
        maxWidth = qMax(maxWidth, fm.boundingRect(text).width());
    }
```

#### AUTO 


```{c}
auto const general = new General(nullptr);
```

#### AUTO 


```{c}
const auto buttons = base_choose_group_->buttons();
```

#### AUTO 


```{c}
auto const p = dynamic_cast<knumber_error *>(rhs)
```

#### AUTO 


```{c}
auto const p = dynamic_cast<knumber_integer *>(rhs)
```

#### AUTO 


```{c}
auto const ev = reinterpret_cast<QDropEvent *>(e);
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractButton *btn : std::as_const(scientific_buttons_)) {
                btn->setEnabled(true);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractButton *btn : qAsConst(operation_button_list_)) {
		qobject_cast<KCalcButton*>(btn)->setTextColor(opFontColor);
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const KNumber &x : qAsConst(data_)) {
		result += (x * x);
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractButton *btn : std::as_const(scientific_buttons_)) {
            btn->hide();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KNumber &x : qAsConst(data_)) {
		result += x;
	}
```

#### AUTO 


```{c}
auto e = new knumber_error(knumber_error::ERROR_POS_INFINITY);
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractButton *btn : std::as_const(mem_button_list_)) {
            btn->show();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KNumber &x : qAsConst(data_)) {
			result += (x - mean_value) * (x - mean_value);
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractButton *btn : qAsConst(logic_buttons_)) {
			btn->show();
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (QObject *obj : leftPadLst) {
        if (auto const button = qobject_cast<KCalcButton *>(obj)) {
            if (button->isVisible()) {
                if (button->width() < minButtonWidth)
                    minButtonWidth = button->width();
                if (button->height() < minButtonHeight)
                    minButtonHeight = button->height();
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractButton *btn : std::as_const(scientific_buttons_)) {
                btn->setEnabled(false);
            }
```

#### AUTO 


```{c}
auto btn = qobject_cast<KCalcConstButton*>(const_buttons_[button])
```

#### AUTO 


```{c}
auto q = new knumber_float(this);
```

#### AUTO 


```{c}
auto layout = new QGridLayout(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KNumber &x : std::as_const(data_)) {
        result += x;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KNumber &x : std::as_const(data_)) {
        result += (x * x);
    }
```

#### AUTO 


```{c}
auto const fonts = new Fonts(nullptr);
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractButton *btn : std::as_const(logic_buttons_)) {
            btn->show();
        }
```

#### AUTO 


```{c}
auto n = new knumber_integer(num);
```

#### RANGE FOR STATEMENT 


```{c}
for (QObject *obj : bit_button_group_->buttons()) {
            if (auto const button = qobject_cast<BitButton *>(obj)) {
                QSize size = QSize(button->renderSize());
                size.setWidth(minWidth);
                size.setHeight(minHeight);
                button->setRenderSize(size);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractButton *btn : qAsConst(const_buttons_)) {
        if (auto const constbtn = qobject_cast<KCalcConstButton *>(btn)) {
            constbtn->setLabelAndTooltip();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractButton *btn : std::as_const(stat_buttons_)) {
            btn->show();
        }
```

#### AUTO 


```{c}
auto const calcButton = qobject_cast<KCalcButton *>(o);
```

#### AUTO 


```{c}
auto const p = dynamic_cast<detail::knumber_integer *>(value_)
```

#### AUTO 


```{c}
auto const wordlayout = new QHBoxLayout();
```

#### RANGE FOR STATEMENT 


```{c}
for (QObject *obj : numericPadLst) {
        if (auto const button = qobject_cast<KCalcButton *>(obj)) {
            if (button->isVisible()) {
                if (button->width() < minButtonWidth)
                    minButtonWidth = button->width();
                if (button->height() < minButtonHeight)
                    minButtonHeight = button->height();
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QObject *obj : rightPadLst) {
		if (auto const button = qobject_cast<KCalcButton*>(obj)) {
			button->setFont(KCalcSettings::buttonFont());
		}
	}
```

#### AUTO 


```{c}
auto f = new knumber_fraction(this);
```

#### AUTO 


```{c}
auto n = new knumber_integer(0);
```

#### AUTO 


```{c}
const auto rightPadList = rightPad->children();
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractButton *btn : qAsConst(scientific_buttons_)) {
			btn->setEnabled(true);
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractButton *btn : std::as_const(stat_buttons_)) {
        qobject_cast<KCalcButton *>(btn)->setTextColor(statFontColor);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractButton *btn : qAsConst(logic_buttons_)) {
            btn->hide();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractButton *btn : qAsConst(function_button_list_)) {
        btn->setStyleSheet(sheet.arg(funcPal.name()));
    }
```

#### AUTO 


```{c}
auto const color = new Colors(nullptr);
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractButton *btn : qAsConst(mem_button_list_)) {
        btn->setStyleSheet(sheet.arg(memPal.name()));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(QAbstractButton *btn : qAsConst(const_buttons_)) {
			btn->show();
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (QObject *obj : leftPadLst) {
        if (auto const button = qobject_cast<KCalcButton *>(obj)) {
            button->setFont(buttonFont);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractButton *btn : qAsConst(const_buttons_)) {
            btn->show();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractButton *btn : qAsConst(const_buttons_)) {
        qobject_cast<KCalcButton *>(btn)->setTextColor(coFontColor);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractButton *btn : qAsConst(stat_buttons_)) {
		qobject_cast<KCalcButton*>(btn)->setTextColor(statFontColor);
	}
```

#### AUTO 


```{c}
const auto leftPadLst = leftPad->children();
```

#### RANGE FOR STATEMENT 


```{c}
for (QObject *obj : bit_button_group_->buttons()) {
        if (auto const button = qobject_cast<BitButton *>(obj)) {
            minWidth = qMin(minWidth, button->rect().width());
            minHeight = qMin(minHeight, button->rect().height());
        }
    }
```

#### AUTO 


```{c}
auto const p = dynamic_cast<detail::knumber_error *>(value_)
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractButton *btn : qAsConst(mem_button_list_)) {
            btn->show();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractButton *btn : buttons) {
            btn->show();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractButton *btn : qAsConst(mem_button_list_)) {
			btn->hide();
		}
```

#### AUTO 


```{c}
const auto scienceConstantListItem = scienceConstantList.at(i);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KNumber &x : qAsConst(data_)) {
        result += (x * x);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractButton *btn : std::as_const(stat_buttons_)) {
        btn->setStyleSheet(sheet.arg(statPal.name()));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractButton *btn : std::as_const(const_buttons_)) {
            btn->hide();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QLabel* lbl : base_conversion_labels_) {
			lbl->hide();
		}
```

#### AUTO 


```{c}
const auto numericPadList = numericPad->children();
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractButton *btn : qAsConst(stat_buttons_)) {
			btn->hide();
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (QObject *obj : leftPadList) {
        if (auto const button = qobject_cast<KCalcButton *>(obj)) {
            button->setMinimumWidth(em.width() * 4 + margin * 2);
            button->setMinimumHeight(em.height() * 1.25 + margin * 2);
            button->installEventFilter(this);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractButton *btn : qAsConst(stat_buttons_)) {
            btn->hide();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractButton *btn : qAsConst(const_buttons_)) {
		qobject_cast<KCalcButton*>(btn)->setTextColor(coFontColor);
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractButton *btn : qAsConst(scientific_buttons_)) {
                btn->setEnabled(false);
            }
```

#### AUTO 


```{c}
auto const p = dynamic_cast<detail::knumber_fraction *>(value_)
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractButton *btn : qAsConst(scientific_buttons_)) {
            btn->hide();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QObject *obj : rightPadList) {
        auto const button = qobject_cast<KCalcButton *>(obj);
        // let Shift expand freely
        if (button && button != pbShift) {
            button->setMinimumWidth(em.width() * 3 + margin * 2);
            button->installEventFilter(this);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractButton *btn : qAsConst(const_buttons_)) {
        if (auto const constbtn = qobject_cast<KCalcConstButton*>(btn)) {
			constbtn->setLabelAndTooltip();
		}
    }
```

#### AUTO 


```{c}
const auto leftPadList = leftPad->children();
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractButton *btn : qAsConst(stat_buttons_)) {
        btn->setStyleSheet(sheet.arg(statPal.name()));
    }
```

#### AUTO 


```{c}
auto f = new knumber_float(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (QObject *obj : numericPadList) {
		if (auto const button = qobject_cast<KCalcButton *>(obj)) {
			// let pb0 expand freely
			if (button != pb0) {
				button->setFixedWidth(em.width() * 3 + margin * 2);
			}
			button->installEventFilter(this);
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractButton *btn : qAsConst(mem_button_list_)) {
			btn->show();
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (QObject *obj : numericPadList) {
        if (auto const button = qobject_cast<KCalcButton *>(obj)) {
            // let pb0 expand freely
            if (button != pb0) {
                button->setMinimumWidth(em.width() * 3 + margin * 2);
            }
            button->installEventFilter(this);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractButton *btn : std::as_const(mem_button_list_)) {
        btn->setStyleSheet(sheet.arg(memPal.name()));
    }
```

#### AUTO 


```{c}
auto i = new knumber_integer(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractButton *btn : buttons) {
            btn->hide();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractButton *btn : qAsConst(operation_button_list_)) {
        qobject_cast<KCalcButton *>(btn)->setTextColor(opFontColor);
    }
```

#### AUTO 


```{c}
auto tmp_action = new QAction(i18n(scienceConstantList.at(i).name.toLatin1().data()), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (QObject *obj : numericPadLst) {
        if (auto const button = qobject_cast<KCalcButton *>(obj)) {
            button->setFont(KCalcSettings::buttonFont());
        }
    }
```

#### AUTO 


```{c}
auto const constbtn = qobject_cast<KCalcConstButton*>(btn)
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractButton *btn : qAsConst(const_buttons_)) {
		btn->setStyleSheet(sheet.arg(coPal.name()));
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractButton *btn : qAsConst(operation_button_list_)) {
		btn->setStyleSheet(sheet.arg(opPal.name()));
	}
```

#### AUTO 


```{c}
const auto buttons = angle_choose_group_->buttons();
```

#### RANGE FOR STATEMENT 


```{c}
for (QObject *obj : numericPadList) {
        if (auto const button = qobject_cast<KCalcButton *>(obj)) {
            button->setMinimumWidth(em.width() * 3 + margin * 2);
            button->setMinimumHeight(em.height() * 1.25 + margin * 2);
            button->installEventFilter(this);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QObject *obj : leftPadList) {
        if (auto const button = qobject_cast<KCalcButton *>(obj)) {
            button->setFixedWidth(em.width() * 4 + margin * 2);
            button->installEventFilter(this);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QObject *obj : rightPadLst) {
        if (auto const button = qobject_cast<KCalcButton *>(obj)) {
            button->setFont(KCalcSettings::buttonFont());
        }
    }
```

#### AUTO 


```{c}
auto const p = dynamic_cast<knumber_float *>(rhs)
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractButton* btn : buttons) {
			btn->hide();
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractButton *btn : qAsConst(mem_button_list_)) {
        qobject_cast<KCalcButton *>(btn)->setTextColor(memFontColor);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractButton *btn : std::as_const(operation_button_list_)) {
        qobject_cast<KCalcButton *>(btn)->setTextColor(opFontColor);
    }
```

#### AUTO 


```{c}
auto const f = new knumber_float(this);
```

#### AUTO 


```{c}
auto bb = qobject_cast<BitButton *>(bit_button_group_->button(i))
```

#### AUTO 


```{c}
auto bb = qobject_cast<BitButton*>(bit_button_group_->button(i))
```

#### AUTO 


```{c}
auto q = new knumber_fraction(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractButton *btn : qAsConst(stat_buttons_)) {
		btn->setStyleSheet(sheet.arg(statPal.name()));
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (QObject *obj : rightPadLst) {
        if (auto const button = qobject_cast<KCalcButton *>(obj)) {
            if (button->isVisible() && button != pbShift) {
                if (button->width() < minButtonWidth)
                    minButtonWidth = button->width();
                if (button->height() < minButtonHeight)
                    minButtonHeight = button->height();
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QObject *obj : leftPadList) {
        if (auto const button = qobject_cast<KCalcButton *>(obj)) {
            button->setMinimumWidth(em.width() * 4 + margin * 2);
            button->installEventFilter(this);
        }
    }
```

#### AUTO 


```{c}
auto e = new knumber_error(p);
```

#### AUTO 


```{c}
auto const ev = reinterpret_cast<QDragEnterEvent *>(e);
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractButton *btn : std::as_const(operation_button_list_)) {
        btn->setStyleSheet(sheet.arg(opPal.name()));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KNumber &x : qAsConst(data_)) {
            result += (x - mean_value) * (x - mean_value);
        }
```

#### AUTO 


```{c}
const auto numericPadLst = numericPad->children();
```

#### AUTO 


```{c}
auto const tmp_menu = new KCalcConstMenu(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractButton *btn : qAsConst(scientific_buttons_)) {
			btn->setEnabled(false);
		}
```

#### AUTO 


```{c}
auto const button = qobject_cast<BitButton *>(obj)
```

#### RANGE FOR STATEMENT 


```{c}
for (QObject *obj : rightPadList) {
		auto const button = qobject_cast<KCalcButton *>(obj);
		// let Shift expand freely
		if (button && button != pbShift) {
			button->setFixedWidth(em.width() * 3 + margin * 2);
			button->installEventFilter(this);
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractButton *btn : std::as_const(const_buttons_)) {
        btn->setStyleSheet(sheet.arg(coPal.name()));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QObject *obj : rightPadLst) {
        if (auto const button = qobject_cast<KCalcButton *>(obj)) {
            button->setFont(buttonFont);
        }
    }
```

