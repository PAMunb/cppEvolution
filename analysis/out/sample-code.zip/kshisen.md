#### AUTO 


```{c}
auto pt1 = m_connection.constBegin();
```

#### AUTO 


```{c}
auto const fontsize = static_cast<int>(boxHeight / 13);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto iter : m_path) {
            qCDebug(KSHISEN_LOG) << "    Path:" << iter.x() << "," << iter.y();
        }
```

#### AUTO 


```{c}
auto const tilePos2 = TilePos(m_random.bounded(tx), m_random.bounded(ty));
```

#### AUTO 


```{c}
auto const configGroup = QStringLiteral("%1x%2").arg(m_board->xTiles()).arg(m_board->yTiles());
```

#### AUTO 


```{c}
auto const r = QRect(xOffset() + tilePos.x() * m_tiles.qWidth() * 2,
                         yOffset() + tilePos.y() * m_tiles.qHeight() * 2,
                         m_tiles.width(),
                         m_tiles.height());
```

#### AUTO 


```{c}
auto distance = -1;
```

#### AUTO 


```{c}
auto n = move->x1() - move->slideX1();
```

#### AUTO 


```{c}
auto const fw = m_tiles.qWidth() * 2;
```

#### AUTO 


```{c}
auto app = new App();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto const &move : std::as_const(m_possibleMoves)) {
            auto pt1 = move.path().cbegin();
            auto pt2 = pt1 + 1;
            while (pt2 != move.path().cend()) {
                p.drawLine(midCoord(*pt1), midCoord(*pt2));
                ++pt1;
                ++pt2;
            }
        }
```

#### AUTO 


```{c}
auto const numberOfTiles = m_board->tiles();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto const move : m_possibleMoves) {
            auto pt1 = move.m_path.constBegin();
            auto pt2 = pt1 + 1;
            while (pt2 != move.m_path.constEnd()) {
                p.drawLine(midCoord(pt1->x, pt1->y), midCoord(pt2->x, pt2->y));
                ++pt1;
                ++pt2;
            }
        }
```

#### AUTO 


```{c}
auto tempX = tilePos1.x() + dx.at(i);
```

#### AUTO 


```{c}
auto const clickedTile = field(TilePos(posX, posY));
```

#### AUTO 


```{c}
auto wptr = yTiles() - 1;
```

#### DECLTYPE 


```{c}
decltype(xTiles()) xx = 0;
```

#### CONST EXPRESSION 


```{c}
static constexpr char description[] = I18N_NOOP("A KDE game similar to Mahjongg");
```

#### AUTO 


```{c}
auto withSlide = 0;
```

#### AUTO 


```{c}
auto const tilePos2 = TilePos(m_random.getLong(tx), m_random.getLong(ty));
```

#### DECLTYPE 


```{c}
decltype(xTiles()) x = 0;
```

#### AUTO 


```{c}
auto const dy = slide.front().y() - slide.back().y();
```

#### AUTO 


```{c}
auto curTile = 1;
```

#### AUTO 


```{c}
auto numberOfPaths = 0;
```

#### AUTO 


```{c}
auto const errMessage = QStringLiteral("Removing unmatched tiles: (%1,%2) => %3 (%4,%5) => %6")
                                        .arg(p.front().path().front().x())
                                        .arg(p.front().path().front().y())
                                        .arg(field(tile1))
                                        .arg(p.front().path().back().x())
                                        .arg(p.front().path().back().y())
                                        .arg(field(tile2));
```

#### AUTO 


```{c}
auto iter = m_path.cbegin();
```

#### AUTO 


```{c}
auto pathX = iter->x();
```

#### DECLTYPE 


```{c}
decltype(xTiles()) column = 0;
```

#### AUTO 


```{c}
auto const dy = slide.back().y() - slide.front().y();
```

#### AUTO 


```{c}
auto tempY = tilePos1.y() + dy.at(i);
```

#### AUTO 


```{c}
auto const oldHighlighted = m_highlightedTile;
```

#### AUTO 


```{c}
auto const ty = yTiles();
```

#### DECLTYPE 


```{c}
decltype(tx * ty * m_shuffle) i = 0;
```

#### RANGE FOR STATEMENT 


```{c}
for (auto move : qAsConst(m_possibleMoves)) {
            if (move.isInPath(tilePos)) {
                performMove(move);
                emit selectATile();
                return;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto move : qAsConst(m_possibleMoves)) {
                if (move.isInPath(tilePos)) {
                    performMove(move);
                    emit selectATile();
                    return;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto move : qAsConst(m_possibleMoves)) {
                if (move.isInPath(tilePos)) {
                    performMove(move);
                    Q_EMIT selectATile();
                    return;
                }
            }
```

#### AUTO 


```{c}
auto const r = QRect(xpos, ypos, w, h);
```

#### AUTO 


```{c}
auto wptrPos = TilePos(column, wptr);
```

#### AUTO 


```{c}
auto const oldConnection = m_connection;
```

#### AUTO 


```{c}
auto pt1 = m_connection.cbegin();
```

#### AUTO 


```{c}
auto app = new KShisen::App();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto const &iter : qAsConst(m_path)) {
        qCDebug(KSHISEN_General) << "    Path:" << iter.x() << "," << iter.y();
    }
```

#### AUTO 


```{c}
auto const column
```

#### AUTO 


```{c}
auto const message = i18n("Congratulations!\nYou made it into the hall of fame.");
```

#### AUTO 


```{c}
auto i = qMin(tilePos1.y(), tilePos2.y()) + 1;
```

#### RANGE FOR STATEMENT 


```{c}
for (auto move : std::as_const(m_possibleMoves)) {
            if (move.isInPath(tilePos)) {
                performMove(move);
                Q_EMIT selectATile();
                return;
            }
        }
```

#### AUTO 


```{c}
auto endFree = xTiles();
```

#### AUTO 


```{c}
auto rptrPos = TilePos(column, rptr);
```

#### AUTO 


```{c}
auto const t = field(tilePos1);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto const column : affectedColumns) {
        auto rptr = yTiles() - 1;
        auto wptr = yTiles() - 1;
        while (rptr >= 0) {
            auto wptrPos = TilePos(column, wptr);
            if (field(wptrPos) != EMPTY) {
                --rptr;
                --wptr;
            } else {
                auto rptrPos = TilePos(column, rptr);
                if (field(rptrPos) != EMPTY) {
                    setField(wptrPos, field(rptrPos));
                    setField(rptrPos, EMPTY);
                    repaintTile(rptrPos);
                    repaintTile(wptrPos);
                    --wptr;
                    --rptr;
                    if (Prefs::sounds()) {
                        m_soundFall.start();
                    }
                } else {
                    --rptr;
                }
            }
        }
    }
```

#### AUTO 


```{c}
auto i = qMin(pt1->x(), pt2->x());
```

#### AUTO 


```{c}
auto i = tilePos1.x() + 1;
```

#### AUTO 


```{c}
auto const timeString = i18nc("time string: hh:mm:ss", "%1:%2:%3",
                                      QString().sprintf("%02d", m_board->currentTime() / 3600),
                                      QString().sprintf("%02d", (m_board->currentTime() / 60) % 60),
                                      QString().sprintf("%02d", m_board->currentTime() % 60));
```

#### AUTO 


```{c}
auto const tile = field(TilePos(i, j));
```

#### AUTO 


```{c}
auto dpi = logicalDpiX();
```

#### AUTO 


```{c}
auto numberOfPaths = findSimplePath(tilePos1, tilePos2, possibleMoves);
```

#### DECLTYPE 


```{c}
decltype(m_field) pos(m_field.size());
```

#### DECLTYPE 


```{c}
decltype(xTiles()) i = 0;
```

#### AUTO 


```{c}
auto tileCount = 0;
```

#### AUTO 


```{c}
auto const h = qRound(m_tiles.qHeight() * 2.0 * minScale) * yTiles() + m_tiles.height();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto move : m_possibleMoves) {
            if (move.isInPath(tilePos)) {
                performMove(move);
                emit selectATile();
                return;
            }
        }
```

#### AUTO 


```{c}
auto const tile2 = field(tilePos);
```

#### AUTO 


```{c}
auto const r2 = m_random.getLong(numberOfTiles);
```

#### AUTO 


```{c}
auto i = slide.front().x();
```

#### AUTO 


```{c}
auto const tile1 = TilePos(m_connection.front().x(), m_connection.front().y());
```

#### AUTO 


```{c}
auto th = m_tiles.qHeight() * 2;
```

#### DECLTYPE 


```{c}
decltype(move->y2()) y = 0;
```

#### AUTO 


```{c}
auto const apos = pos.at(r2);
```

#### AUTO 


```{c}
auto const move
```

#### CONST EXPRESSION 


```{c}
static int constexpr nTiles = 42;
```

#### AUTO 


```{c}
auto rptr = yTiles() - 1;
```

#### AUTO 


```{c}
auto const boxWidth = width() * 0.6;
```

#### AUTO 


```{c}
auto iter = m_path.constBegin();
```

#### AUTO 


```{c}
auto currentTile = 0;
```

#### RANGE FOR STATEMENT 


```{c}
for (auto iter : m_slide) {
                qCDebug(KSHISEN_LOG) << "    Slide:" << iter.x() << "," << iter.y();
            }
```

#### AUTO 


```{c}
auto timer = new QTimer(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto const &iter : std::as_const(m_slide)) {
            qCDebug(KSHISEN_General) << "    Slide:" << iter.x() << "," << iter.y();
        }
```

#### AUTO 


```{c}
auto simplePath = 0;
```

#### RANGE FOR STATEMENT 


```{c}
for (auto const move : m_possibleMoves) {
            auto pt1 = move.m_path.cbegin();
            auto pt2 = pt1 + 1;
            while (pt2 != move.m_path.cend()) {
                p.drawLine(midCoord(pt1->x, pt1->y), midCoord(pt2->x, pt2->y));
                ++pt1;
                ++pt2;
            }
        }
```

#### AUTO 


```{c}
auto const tile = field(TilePos(x, y));
```

#### AUTO 


```{c}
auto iter = m_slide.cbegin();
```

#### AUTO 


```{c}
auto const tile1 = field(TilePos(m_markX, m_markY));
```

#### DECLTYPE 


```{c}
decltype(yTiles()) yy = 0;
```

#### AUTO 


```{c}
auto const xpos = xOffset() + i * fw;
```

#### AUTO 


```{c}
auto const minScale = 0.2;
```

#### AUTO 


```{c}
auto i = tilePos.x() + 1;
```

#### AUTO 


```{c}
auto const currentTime = m_board->currentTime();
```

#### AUTO 


```{c}
auto const tile1 = TilePos(p.front().path().front().x(), p.front().path().front().y());
```

#### AUTO 


```{c}
auto const oldTilePos = TilePos(m_markX, m_markY);
```

#### LAMBDA EXPRESSION 


```{c}
[](int field) { return field != EMPTY; }
```

#### AUTO 


```{c}
auto pt1 = move.m_path.cbegin();
```

#### AUTO 


```{c}
auto move = m_redo.takeFirst();
```

#### LAMBDA EXPRESSION 


```{c}
[](auto field) { return field != EMPTY; }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto const &iter : qAsConst(m_slide)) {
            qCDebug(KSHISEN_General) << "    Slide:" << iter.x() << "," << iter.y();
        }
```

#### AUTO 


```{c}
auto const points = tilespersec / 0.14 * 100.0;
```

#### AUTO 


```{c}
auto endFree = -1;
```

#### AUTO 


```{c}
auto i = tilePos1.x() - 1;
```

#### AUTO 


```{c}
auto i = tilePos1.y() + 1;
```

#### AUTO 


```{c}
auto const dx = slide.back().x() - slide.front().x();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto const move : m_possibleMoves) {
            auto pt1 = move.m_path.cbegin();
            auto pt2 = pt1 + 1;
            while (pt2 != move.m_path.cend()) {
                p.drawLine(midCoord(*pt1), midCoord(*pt2));
                ++pt1;
                ++pt2;
            }
        }
```

#### AUTO 


```{c}
auto i = startFree + 1;
```

#### CONST EXPRESSION 


```{c}
auto constexpr minScale = 0.2;
```

#### AUTO 


```{c}
auto move = std::move(m_undo.back());
```

#### AUTO 


```{c}
auto const h = m_tiles.height();
```

#### AUTO 


```{c}
auto const tile2 = TilePos(m_connection.back().x(), m_connection.back().y());
```

#### AUTO 


```{c}
auto const r1 = m_random.bounded(numberOfTiles);
```

#### AUTO 


```{c}
auto i = move->x1() + dx;
```

#### AUTO 


```{c}
auto tw = m_tiles.qWidth() * 2;
```

#### RANGE FOR STATEMENT 


```{c}
for (auto move : m_possibleMoves) {
                if (move.isInPath(x, y)) {
                    performMove(move);
                    emit selectATile();
                    return;
                }
            }
```

#### AUTO 


```{c}
auto iter = m_slide.constBegin();
```

#### AUTO 


```{c}
auto const fh = m_tiles.qHeight() * 2;
```

#### RANGE FOR STATEMENT 


```{c}
for (auto move : m_possibleMoves) {
            if (move.isInPath(x, y)) {
                performMove(move);
                emit selectATile();
                return;
            }
        }
```

#### AUTO 


```{c}
auto posX = (e->pos().x() - xOffset()) / (m_tiles.qWidth() * 2);
```

#### AUTO 


```{c}
auto i = 0;
```

#### AUTO 


```{c}
auto const h = m_tiles.qHeight() * 2;
```

#### RANGE FOR STATEMENT 


```{c}
for (auto const &move : qAsConst(m_possibleMoves)) {
                move.Debug();
                if (move.hasSlide()) {
                    ++withSlide;
                }
            }
```

#### AUTO 


```{c}
auto const &move
```

#### AUTO 


```{c}
auto pt1 = oldConnection.cbegin();
```

#### AUTO 


```{c}
auto pt1 = move.path().cbegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto const &move : qAsConst(m_possibleMoves)) {
            auto pt1 = move.path().cbegin();
            auto pt2 = pt1 + 1;
            while (pt2 != move.path().cend()) {
                p.drawLine(midCoord(*pt1), midCoord(*pt2));
                ++pt1;
                ++pt2;
            }
        }
```

#### AUTO 


```{c}
auto const sizebonus = std::sqrt(ntiles / static_cast<double>(14.0 * 6.0));
```

#### AUTO 


```{c}
auto soundAction = new KToggleAction(QIcon::fromTheme(QStringLiteral("speaker")), i18n("Play Sounds"), this);
```

#### AUTO 


```{c}
auto move
```

#### RANGE FOR STATEMENT 


```{c}
for (auto const &move : std::as_const(m_possibleMoves)) {
                move.Debug();
                if (move.hasSlide()) {
                    ++withSlide;
                }
            }
```

#### AUTO 


```{c}
auto const tilespersec = ntiles / static_cast<double>(seconds);
```

#### AUTO 


```{c}
auto posY = (e->pos().y() - yOffset()) / (m_tiles.qHeight() * 2);
```

#### AUTO 


```{c}
auto i = move->slideX2();
```

#### AUTO 


```{c}
auto const newsize = m_tiles.preferredTileSize(QSize(width(), height()), xTiles(), yTiles());
```

#### DECLTYPE 


```{c}
decltype(m_field) oldField;
```

#### AUTO 


```{c}
auto constexpr minScale = 0.2;
```

#### AUTO 


```{c}
auto const message = i18n("\nYou could have been in the highscores\nif you did not use Undo or Hint.\nTry without them next time.");
```

#### AUTO 


```{c}
auto const tilePos1 = TilePos(m_random.getLong(tx), m_random.getLong(ty));
```

#### AUTO 


```{c}
auto i = tilePos.x() - 1;
```

#### AUTO 


```{c}
auto i = tilePos.y() + 1;
```

#### AUTO 


```{c}
auto const r2 = m_random.bounded(numberOfTiles);
```

#### DECLTYPE 


```{c}
decltype(yTiles()) j = 0;
```

#### AUTO 


```{c}
auto const message = i18nc("%1 - time string like hh:mm:ss", "You made it in %1", timeString);
```

#### AUTO 


```{c}
auto const boxHeight = height() * 0.6;
```

#### DECLTYPE 


```{c}
decltype(move->slideY1()) j = 0;
```

#### AUTO 


```{c}
auto const message = i18n("Your time: %1:%2:%3 %4",
                              QString::asprintf("%02d", currentTime / 3600),
                              QString::asprintf("%02d", (currentTime / 60) % 60),
                              QString::asprintf("%02d", currentTime % 60),
                              m_board->isPaused() ? i18n("(Paused) ") : QString());
```

#### AUTO 


```{c}
auto i = tilePos1.y() - 1;
```

#### AUTO 


```{c}
auto width = qRound(m_tiles.height() / 10.0);
```

#### AUTO 


```{c}
auto const ypos = yOffset() + j * fh;
```

#### AUTO 


```{c}
auto pathY = iter->y();
```

#### LAMBDA EXPRESSION 


```{c}
[](int field){ return field != EMPTY; }
```

#### AUTO 


```{c}
auto const message = i18n("Your time: %1:%2:%3 %4",
                              QString().sprintf("%02d", currentTime / 3600),
                              QString().sprintf("%02d", (currentTime / 60) % 60),
                              QString().sprintf("%02d", currentTime % 60),
                              m_board->isPaused() ? i18n("(Paused) ") : QString());
```

#### AUTO 


```{c}
auto i = qMin(pt1->y(), pt2->y());
```

#### AUTO 


```{c}
auto numberOfTiles = 0;
```

#### AUTO 


```{c}
auto i = startFree - 1;
```

#### AUTO 


```{c}
auto const tile = tiles.at(r1);
```

#### AUTO 


```{c}
auto const tilePos1 = TilePos(m_random.bounded(tx), m_random.bounded(ty));
```

#### AUTO 


```{c}
auto startFree = -1;
```

#### RANGE FOR STATEMENT 


```{c}
for (auto move : std::as_const(m_possibleMoves)) {
                if (move.isInPath(tilePos)) {
                    performMove(move);
                    Q_EMIT selectATile();
                    return;
                }
            }
```

#### AUTO 


```{c}
auto const ntiles = static_cast<double>(x * y);
```

#### AUTO 


```{c}
auto const &iter
```

#### AUTO 


```{c}
auto const ur = e->rect();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto move : m_possibleMoves) {
                if (move.isInPath(tilePos)) {
                    performMove(move);
                    emit selectATile();
                    return;
                }
            }
```

#### AUTO 


```{c}
auto const tile2 = TilePos(p.front().path().back().x(), p.front().path().back().y());
```

#### DECLTYPE 


```{c}
decltype(yTiles()) y = 0;
```

#### AUTO 


```{c}
auto oldfield = m_field;
```

#### AUTO 


```{c}
auto pt1 = move.m_path.constBegin();
```

#### AUTO 


```{c}
auto iter
```

#### AUTO 


```{c}
auto errMessage = QStringLiteral("Removing unmatched tiles: (%1,%2) => %3 (%4,%5) => %6")
                                  .arg(p.front().path().front().x())
                                  .arg(p.front().path().front().y())
                                  .arg(field(tile1))
                                  .arg(p.front().path().back().x())
                                  .arg(p.front().path().back().y())
                                  .arg(field(tile2));
```

#### AUTO 


```{c}
auto move = std::move(m_redo.front());
```

#### AUTO 


```{c}
auto maxAttempts = 200;
```

#### AUTO 


```{c}
auto dx = move->slideX2() - move->slideX1();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto const &iter : std::as_const(m_path)) {
        qCDebug(KSHISEN_General) << "    Path:" << iter.x() << "," << iter.y();
    }
```

#### DECLTYPE 


```{c}
decltype(m_field) tiles(m_field.size());
```

#### AUTO 


```{c}
auto dialog = new KMahjonggConfigDialog(this, QStringLiteral("settings"), Prefs::self());
```

#### AUTO 


```{c}
auto const w = m_tiles.qWidth() * 2;
```

#### AUTO 


```{c}
auto const contentsRect = QRect((width() - boxWidth) / 2, (height() - boxHeight) / 2, boxWidth, boxHeight);
```

#### AUTO 


```{c}
auto const timeString = i18nc("time string: hh:mm:ss", "%1:%2:%3",
                                      QString::asprintf("%02d", m_board->currentTime() / 3600),
                                      QString::asprintf("%02d", (m_board->currentTime() / 60) % 60),
                                      QString::asprintf("%02d", m_board->currentTime() % 60));
```

#### AUTO 


```{c}
auto const fieldTile = field(TilePos(i, j));
```

#### AUTO 


```{c}
auto const w = m_tiles.width();
```

#### AUTO 


```{c}
auto pt1 = oldConnection.constBegin();
```

#### AUTO 


```{c}
auto const dx = slide.front().x() - slide.back().x();
```

#### DECLTYPE 


```{c}
decltype(xTiles() * yTiles()) i = 0;
```

#### RANGE FOR STATEMENT 


```{c}
for (auto move : qAsConst(m_possibleMoves)) {
            if (move.isInPath(tilePos)) {
                performMove(move);
                Q_EMIT selectATile();
                return;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto const move : m_possibleMoves) {
                move.Debug();
                if (move.m_hasSlide) {
                    ++withSlide;
                }
            }
```

#### AUTO 


```{c}
auto i = tilePos.y() - 1;
```

#### AUTO 


```{c}
auto pt2 = pt1 + 1;
```

#### AUTO 


```{c}
auto const r1 = m_random.getLong(numberOfTiles);
```

#### AUTO 


```{c}
auto endFree = yTiles();
```

#### AUTO 


```{c}
auto const w = qRound(m_tiles.qWidth() * 2.0 * minScale) * xTiles() + m_tiles.width();
```

#### AUTO 


```{c}
auto const tx = xTiles();
```

#### AUTO 


```{c}
auto i = slide.front().y();
```

#### AUTO 


```{c}
auto const left = tilesLeft();
```

#### AUTO 


```{c}
auto i = move->x1() - dx;
```

#### AUTO 


```{c}
auto i = qMin(tilePos1.x(), tilePos2.x()) + 1;
```

#### DECLTYPE 


```{c}
decltype(move->y1()) y = 0;
```

