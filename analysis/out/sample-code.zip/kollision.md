#### RANGE FOR STATEMENT 


```{c}
for (Ball* ball : qAsConst(m_balls)) {
        if (m_man && collide(
                ball->position(),
                m_man->position(),
                m_ballDiameter,
                m_manBallDiameter,
                collision)) {
            if(m_soundEnabled)
                m_soundYouLose.start();
            abort();
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Ball* ball : std::as_const(m_fading)) {
        ball->setVisible(!m_paused);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Ball* ball : std::as_const(m_balls)) {
        // position
        ball->setPosition(ball->position() +
            ball->velocity() * t);

        // velocity
        if (m_death) {
            ball->setVelocity(ball->velocity() +
                QPointF(0, 0.001) * t);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& message : qAsConst(m_welcomeMsg)) {
            message->setOpacityF(0.0);
            anim->add(new FadeAnimation(message, 0.0, 1.0, 1000));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Ball* fball : qAsConst(m_fading)) {
            fball->setOpacityF(1.0);
            fball->setVelocity(QPointF(0.0, 0.0));
            m_balls.push_back(fball);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Animation* a : qAsConst(m_animations)) {
        a->start(t);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Ball* ball : std::as_const(m_balls)) {
                ball->setRenderSize(QSize(m_ballDiameter, m_ballDiameter));
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &line : lines) {
        m_welcomeMsg.append(
            QExplicitlySharedDataPointer<Message>(new Message(line, m_msgFont, m_size)));
    }
```

#### AUTO 


```{c}
const auto& message
```

#### RANGE FOR STATEMENT 


```{c}
for (Animation* a : std::as_const(m_animations)) {
        a->start(t);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Ball* ball : std::as_const(m_balls)) {
        if (m_man && collide(
                ball->position(),
                m_man->position(),
                m_ballDiameter,
                m_manBallDiameter,
                collision)) {
            if(m_soundEnabled)
                m_soundYouLose.start();
            abort();
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Ball* fball : std::as_const(m_fading)) {
            fball->setOpacityF(1.0);
            fball->setVelocity(QPointF(0.0, 0.0));
            m_balls.push_back(fball);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& message : std::as_const(m_welcomeMsg)) {
            message->setOpacityF(0.0);
            anim->add(new FadeAnimation(message, 0.0, 1.0, 1000));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Ball* ball : qAsConst(m_fading)) {
            if (collide(pos, ball->position(), m_ballDiameter, m_ballDiameter, tmp)) {
                done = false;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Ball* ball : std::as_const(m_fading)) {
            if (collide(pos, ball->position(), m_ballDiameter, m_ballDiameter, tmp)) {
                done = false;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Ball* ball : qAsConst(m_balls)) {
        ball->setVisible(!m_paused);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Ball* ball : qAsConst(m_fading)) {
        ball->setVisible(!m_paused);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Ball* ball : std::as_const(m_balls)) {
        ball->setVisible(!m_paused);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& message : messages) {
      totalHeight += message->height();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Ball* ball : qAsConst(m_balls)) {
        // position
        ball->setPosition(ball->position() +
            ball->velocity() * t);

        // velocity
        if (m_death) {
            ball->setVelocity(ball->velocity() +
                QPointF(0, 0.001) * t);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Ball* ball : qAsConst(m_balls)) {
                ball->setRenderSize(QSize(m_ballDiameter, m_ballDiameter));
            }
```

