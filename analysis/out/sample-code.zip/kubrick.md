#### RANGE FOR STATEMENT 


```{c}
for (Cubie * cubie : qAsConst(cubies)) {

	if (cubie->hasNoStickers()) {
	    // This cubie is deep inside the cube: save time by not drawing it.
	    continue;
	}

	// Draw the cubie and its stickers.
	cubie->drawCubie (gameGLView, cubieSize,
		  moveInProgressAxis, moveInProgressSlice, moveInProgressAngle);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& dir : dirs) {
        const QStringList fileNames = QDir(dir).entryList(QStringList() << QStringLiteral("*.svgz"));  // Find files.
        for (const QString& file : fileNames) {
            themeFilepaths.append(dir + QLatin1Char('/') + file);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Cubie * cubie : qAsConst(cubies)) {
	d = cubie->findCloserSticker (distance, location, faceCentre);
	if (d < distance) {
	    distance = d;
	    result = true;
	}
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] { game->setMoveAxis(0); }
```

#### RANGE FOR STATEMENT 


```{c}
for (Cubie * cubie : qAsConst(cubies)) {
	cubie->setBlinkingOn (axis, location, sizes[axis]);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Cubie * cubie : qAsConst(cubies)) {
		cubie->addSticker ((FaceColor) color, (Axis) n, location, sign);
	    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] { game->changeScene(TwoCubes); }
```

#### LAMBDA EXPRESSION 


```{c}
[this, i] { game->setMoveSlice(i); }
```

#### RANGE FOR STATEMENT 


```{c}
for (Sticker * s : qAsConst(stickers)) {
		temp   = s->currentFaceCentre [coord1];
		s->currentFaceCentre [coord1] = - s->currentFaceCentre [coord2];
		s->currentFaceCentre [coord2] = + temp;
	    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Sticker * sticker : qAsConst(stickers)) {
	// Calculate the integer unit-vector normal to this sticker's face
	// and the centre of the face, in floating OpenGL co-ordinates.
	LOOP (j, nAxes) {
	    faceNormal [j] = sticker->currentFaceCentre [j] - currentCentre [j];
	    faceCentre [j] = ((float) sticker->currentFaceCentre [j]) *
					    cubieSize / 2.0;
	}

	// Draw this sticker in the required color, blink-intensity and size.
	gameGLView->drawASticker (cubieSize, (int) sticker->color,
			  sticker->blinking, faceNormal, faceCentre);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Sticker * s : qAsConst(stickers)) {
		s->currentFaceCentre [coord1] = - s->currentFaceCentre [coord1];
		s->currentFaceCentre [coord2] = - s->currentFaceCentre [coord2];
	    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] { game->setMoveAxis(1); }
```

#### RANGE FOR STATEMENT 


```{c}
for (Move * m : qAsConst(moves)) {
	list.append (QString::asprintf ("%d", (int) m->axis));
	list.append (QString::asprintf ("%d", m->slice));
	list.append (QString::asprintf ("%d", (int) m->direction));
	list.append (QString::asprintf ("%d", m->degrees));

	n++;
	configGroup.writeEntry (QString::asprintf ("m) %03d", n), list);
	list.clear ();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] { game->setMoveDirection(0); }
```

#### LAMBDA EXPRESSION 


```{c}
[this, mapping] { game->smInput(mapping); }
```

#### LAMBDA EXPRESSION 


```{c}
[this] { game->changeScene(ThreeCubes); }
```

#### LAMBDA EXPRESSION 


```{c}
[this] { game->setMoveSlice(0); }
```

#### RANGE FOR STATEMENT 


```{c}
for (Sticker * s : qAsConst(stickers)) {
	    LOOP (i, nAxes) {
		if (s->currentFaceCentre [i] != s->originalFaceCentre [i])
		    moved = true;
	    }
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (Sticker * sticker : qAsConst(stickers)) {
	double d = 0.0;
	LOOP (n, nAxes) {
	    len = location[n] - sticker->currentFaceCentre[n];
	    d   = d + len * len;
	}
	d = sqrt (d);
	if (d < dmin) {
	    dmin = d;
	    foundSticker = sticker;
	}
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Sticker * sticker : qAsConst(stickers)) {
	    printf ("<%d> at ", (int) sticker->color);
	    LOOP (n, nAxes) {
		printf ("%2d ", sticker->currentFaceCentre [n]);
	    }
	}
```

#### LAMBDA EXPRESSION 


```{c}
[this] { game->setMoveDirection(1); }
```

#### RANGE FOR STATEMENT 


```{c}
for (CubeView * v : qAsConst(cubeViews)) {
	if (v->sceneID != currentSceneID)
	    continue;			// Skip unwanted scene IDs.

	v->position [X] = v->relX * fieldWidth;
	v->position [Y] = v->relY * fieldHeight;
	v->position [Z] = cubeCentreZ;

	gameGLView->pushGLMatrix ();
	gameGLView->moveGLView (v->position[X],
				v->position[Y],
				v->position[Z]);
	v->cubieSize = v->size / nMax;

	// Turn and tilt, to make 3 faces visible.
	gameGLView->rotateGLView (v->turn, 0.0, 1.0, 0.0);
	gameGLView->rotateGLView (v->tilt, 1.0, 0.0, -1.0);

	// Save the matrix for this (standard) view of the cube.
	glGetDoublev (GL_MODELVIEW_MATRIX, v->matrix0);

	// Tumble or rotate the cube as required, if this cube-view can rotate.
	if (v->rotates) {
	    if (demoPhase) {
		// Calculate a pseudo-random rotation.
		tumble();
	    }
	    else {
		// Apply the total of the user's arbitrary rotations (if any).
		moveTracker->usersRotation();
	    }
	}

	// Save the matrix for this (fully rotated) view of the cube.
	glGetDoublev (GL_MODELVIEW_MATRIX, v->matrix);

	cube->drawCube (gameGLView, v->cubieSize);

	gameGLView->popGLMatrix ();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] { game->setMoveAxis(2); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& dir : dirs) {
        const QStringList fileNames = QDir(dir).entryList(QStringList() << QStringLiteral("*.svgz"));  // Find files.
        for (const QString& file : fileNames) {
            themeFilepaths.append(dir + '/' + file);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Sticker * sticker : qAsConst(stickers)) {
	if (abs(sticker->currentFaceCentre [axis]) != cubeBoundary) {
	    sticker->blinking = true;
	}
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Cubie * cubie : qAsConst(cubies)) {
	cubie->rotate (axis, location, direction);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Sticker * s : qAsConst(stickers)) {
		temp   = s->currentFaceCentre [coord1];
		s->currentFaceCentre [coord1] = + s->currentFaceCentre [coord2];
		s->currentFaceCentre [coord2] = - temp;
	    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& file : fileNames) {
            themeFilepaths.append(dir + QLatin1Char('/') + file);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Sticker * sticker : qAsConst(stickers)) {
	sticker->blinking = false;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Move * m : qAsConst(moves)) {
	value.sprintf ("%d", (int) m->axis);
	list.append (value);
	value.sprintf ("%d", m->slice);
	list.append (value);
	value.sprintf ("%d", (int) m->direction);
	list.append (value);
	value.sprintf ("%d", m->degrees);
	list.append (value);

	n++;
	value.sprintf ("m) %03d", n);
	configGroup.writeEntry (value, list);
	list.clear ();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (CubeView * v : qAsConst(cubeViews)) {
	if ((v->sceneID != currentSceneID) || (v->label == NoLabel))
	    continue;			// Skip unwanted scene IDs and labels.

	// Convert label-index to run-time label object pointer.
	switch ((int) v->label) {
	case FrontLbl:
	    labelObj = frontVL;
	    break;
	case BackLbl:
	    labelObj = backVL;
	    break;
	}

	// Position the label in 1/8ths of gameGLView dimensions.
	x = (v->labelX * w)/8 - labelObj->width()/2 + 10;
	y = (v->labelY * h)/8 + labelObj->height();
	labelObj->move (x, y);
	labelObj->setVisible (true);
    }
```

#### AUTO 


```{c}
auto slot = &Kubrick::patternSelected;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& file : fileNames) {
            themeFilepaths.append(dir + '/' + file);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] { game->changeScene(OneCube); }
```

#### RANGE FOR STATEMENT 


```{c}
for (Cubie * cubie : qAsConst(cubies)) {
	cubie->setBlinkingOff ();
    }
```

