#### AUTO 


```{c}
auto validator = new QRegularExpressionValidator(rx, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &value : errorPolicySupported) {
        ui->errorPolicyCB->addItem(errorPolicyString(value), value);
    }
```

#### AUTO 


```{c}
auto page = qobject_cast<GenericPage*>(currentPage()->widget());
```

#### AUTO 


```{c}
const auto it = m_arguments.constFind(KCUPS_TIME_AT_CREATION);
```

#### AUTO 


```{c}
auto fileCopyJob = qobject_cast<KIO::FileCopyJob*>(job);
```

#### AUTO 


```{c}
auto conn = new KCupsConnection(url, this);
```

#### AUTO 


```{c}
auto job = new KIO::CommandLauncherJob(QStringLiteral("kde-add-printer"), {QLatin1String("--new-printer-from-device"), arg});
```

#### AUTO 


```{c}
auto button = new QRadioButton(cText, widget);
```

#### AUTO 


```{c}
auto widget = qobject_cast<SelectMakeModel*>(dialog->mainWidget());
```

#### AUTO 


```{c}
auto moveToMenu = new QMenu(i18n("Move to"), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (QStandardItem *make : makes) {
        // Check if the item is in this make
        for (int i = 0; i < make->rowCount(); i++) {
            if (make->child(i)->data(PPDModel::PPDMakeAndModel).toString() == m_makeAndModel) {
                ui->makeView->selectionModel()->setCurrentIndex(make->index(),
                                                                QItemSelectionModel::SelectCurrent);
                ui->ppdsLV->selectionModel()->setCurrentIndex(make->child(i)->index(),
                                                              QItemSelectionModel::SelectCurrent);
                return;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCupsPrinter &printer : printers) {
                ui->connectionsCB->addItem(printer.name(), QVariant::fromValue(printer));
            }
```

#### AUTO 


```{c}
auto ui = qobject_cast<QWidget*>(sender());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : indexes) {
            if (index.column() == 0) {
                switch (static_cast<ipp_jstate_t>(index.data(JobModel::RoleJobState).toInt())) {
                    case IPP_JOB_CANCELED :
                    case IPP_JOB_COMPLETED :
                    case IPP_JOB_ABORTED :
                        break;
                    case IPP_JOB_HELD :
                    case IPP_JOB_STOPPED :
                        release = true;
                        cancel = true;
                        break;
                    default:
                        cancel = hold = true;
                        break;
                }
                if (index.data(JobModel::RoleJobRestartEnabled).toBool()) {
                    reprint = true;
                }
            }
        }
```

#### AUTO 


```{c}
auto comboBox = qobject_cast<QComboBox*>(sender());
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCupsPrinter &printer : printers) {
        QString destName = printer.name();
        if (destName != m_printerName) {
            auto item = new QStandardItem;
            item->setText(destName);
            item->setCheckable(true);
            item->setEditable(false);
            item->setData(printer.uriSupported());
            updateItemState(item);

            m_model->appendRow(item);
        }
    }
```

#### AUTO 


```{c}
auto ui = new ConfigureDialog(printer.name(), printer.isClass());
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCupsPrinter &printer : printers) {
            // If there is a printer and it's not the current one add it
            // as a new destination
            if (printer.name() != m_destName) {
                QAction *action = moveToMenu->addAction(printer.info());
                action->setData(printer.name());
                connect(action, &QAction::triggered, this, [=] () {
                    this->modifyJob(JobModel::Move, action->data().toString());
                });
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : indexes) {
            if (index.column() == 0 && index.flags() & Qt::ItemIsDragEnabled) {
                // Found a move to item
                moveTo = true;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DriverMatch &driverMatch : driverMatchList) {
            qCDebug(LIBKCUPS) << driverMatch.ppd << driverMatch.match;
        }
```

#### AUTO 


```{c}
auto comboBox = new QComboBox(parent);
```

#### AUTO 


```{c}
auto aboutData = new KAboutData(QLatin1String("kcm_print"),
                                    i18n("Print settings"),
                                    QLatin1String(PM_VERSION),
                                    i18n("Print settings"),
                                    KAboutLicense::GPL,
                                    i18n("(C) 2010-2018 Daniel Nicoletti"));
```

#### LAMBDA EXPRESSION 


```{c}
[notify, arg] () {
        qCDebug(PM_KDED);
        // This function will show the PPD browser dialog
        // to choose a better PPD, queue name, location
        // in this case the printer was not added
        auto job = new KIO::CommandLauncherJob(QStringLiteral("kde-add-printer"), {QLatin1String("--new-printer-from-device"), arg});
        job->setDesktopName(QStringLiteral("org.kde.PrintQueue"));
        job->start();
    }
```

#### AUTO 


```{c}
auto page = qobject_cast<GenericPage*>(widget);
```

#### AUTO 


```{c}
auto widget = new QWidget(parent);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : indexes) {
        if (index.column() == JobModel::Columns::ColStatus) {
            QScopedPointer<KCupsRequest> authRequest(new KCupsRequest);
            authRequest->authenticateJob(m_destName, authInfo, index.data(JobModel::Role::RoleJobId).toInt());
            authRequest->waitTillFinished();
            if (authRequest->hasError()) {
                qWarning() << "Error authenticating jobs" << authRequest->error() << authRequest->errorMsg();
                // remove cache on fail
                passwdServerClient->removeAuthInfo(info.url.host(), info.url.scheme(), info.username);
                return;
            }
        }
    }
```

#### AUTO 


```{c}
auto request = new KCupsRequest(conn);
```

#### AUTO 


```{c}
auto watcher = new QDBusPendingCallWatcher(reply, this);
```

#### AUTO 


```{c}
auto makeItem = new QStandardItem(make);
```

#### RANGE FOR STATEMENT 


```{c}
for (const DriverMatch &driver : driverMatch) {
        // Find the matched PPD on the PPDs list
        for (const QVariantHash &ppd : ppds) {
            if (ppd[QLatin1String("ppd-name")].toString() == driver.ppd) {
                // Create the PPD
                QStandardItem *ppdItem = createPPDItem(ppd, true);

                if (recommended == nullptr) {
                    recommended = new QStandardItem;
                    recommended->setText(i18n("Recommended Drivers"));
                    appendRow(recommended);
                }
                recommended->appendRow(ppdItem);

                break;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : indexes) {
        if (index.isValid() && index.column() == 0) {
            // serialize the jobId and fromDestName
            stream << data(index, RoleJobId).toInt()
                   << data(index, RoleJobPrinter).toString()
                   << item(index.row(), ColName)->text();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : indexes) {
        if (index.column() == 0) {
            KCupsRequest *request;
            request = m_model->modifyJob(index.row(),
                                         static_cast<JobModel::JobAction>(action),
                                         destName);
            if (!request) {
                // probably the job already has this state
                // or this is an unknown action
                continue;
            }
            request->waitTillFinished();
            if (request->hasError()) {
                QString msg, jobName;
                jobName = m_model->item(index.row(), static_cast<int>(JobModel::ColName))->text();
                switch (action) {
                case JobModel::Cancel:
                    msg = i18n("Failed to cancel '%1'", jobName);
                    break;
                case JobModel::Hold:
                    msg = i18n("Failed to hold '%1'", jobName);
                    break;
                case JobModel::Release:
                    msg = i18n("Failed to release '%1'", jobName);
                    break;
                case JobModel::Reprint:
                    msg = i18n("Failed to reprint '%1'", jobName);
                    break;
                case JobModel::Move:
                    msg = i18n("Failed to move '%1' to '%2'", jobName, destName);
                    break;
                }
                KMessageBox::detailedSorry(this,
                                           msg,
                                           request->errorMsg(),
                                           i18n("Failed"));
            }
            request->deleteLater();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&app](const QStringList &arguments) {
        if (!arguments.isEmpty()) {
            app.showQueues(arguments.mid(1)); // strip off executable name
        }
    }
```

#### AUTO 


```{c}
auto job = new KIO::CommandLauncherJob(QStringLiteral("kde-add-printer"), {QStringLiteral("--change-ppd"), printerName});
```

#### AUTO 


```{c}
auto sortModel = new PrinterSortFilterModel(this);
```

#### AUTO 


```{c}
const auto it = m_arguments.constFind(KCUPS_TIME_AT_PROCESSING);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCupsPrinter &printerItem : printers) {
            if (printerItem.name() == destName) {
                printer = printerItem;
                found = true;
                break;
            }
        }
```

#### AUTO 


```{c}
const auto printers = uris.value<KCupsPrinters>();
```

#### AUTO 


```{c}
auto listView = new QListView(parent);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVariantHash &arguments : ret) {
            // Inject the printer name back to the arguments hash
            QVariantHash args = arguments;
            args[KCUPS_PRINTER_NAME] = printerName;
            m_printers << KCupsPrinter(args);
        }
```

#### AUTO 


```{c}
auto stdItem = new QStandardItem(printer.name());
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCupsPrinter &printer : printers) {
            // If there is a printer and it's not the current one add it
            // as a new destination
            int dest_row = destRow(printer.name());
            if (dest_row == -1) {
                // not found, insert new one
                insertDest(0, printer);
            } else {
                // update the printer
                updateDest(item(dest_row), printer);
            }
        }
```

#### AUTO 


```{c}
const auto groupeDevices = qdbus_cast<QList<QStringList> >(argument);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVariantHash &arguments : ret) {
            m_jobs << KCupsJob(arguments);
        }
```

#### AUTO 


```{c}
auto job = new KIO::CommandLauncherJob(QStringLiteral("kde-add-printer"), { QStringLiteral("--add-printer") });
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVariantHash &ppd : ppds) {
            if (ppd[QLatin1String("ppd-name")].toString() == driver.ppd) {
                // Create the PPD
                QStandardItem *ppdItem = createPPDItem(ppd, true);

                if (recommended == nullptr) {
                    recommended = new QStandardItem;
                    recommended->setText(i18n("Recommended Drivers"));
                    appendRow(recommended);
                }
                recommended->appendRow(ppdItem);

                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QString &authInfoRequired : printer.authInfoRequired()) {
        if (authInfoRequired == QStringLiteral("domain")) {
            authInfo << info.getExtraField(QStringLiteral("domain")).toString();
        } else if (authInfoRequired == QStringLiteral("username")) {
            authInfo << info.username;
        } else if (authInfoRequired == QStringLiteral("password")) {
            authInfo << info.password;
        } else {
            qWarning() << "No auth info for: " << authInfoRequired;
            authInfo << QString();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCupsPrinter &p : printers) {
            if (p.name() == destName) {
                printer = p;
                found = true;
                break;
            }
        }
```

#### AUTO 


```{c}
auto pogressBar = new QProgressBar;
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {
            emit finished(this);
        }
```

#### AUTO 


```{c}
auto layout = new QHBoxLayout(widget);
```

#### AUTO 


```{c}
auto winId = static_cast<qlonglong>(this->winId());
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        auto dialog = new QFileDialog(this);
        dialog->setDirectoryUrl(QUrl(QStringLiteral("smb://")));
        dialog->setMimeTypeFilters({QStringLiteral("inode/vnd.kde.kio.smb.printer")});
        dialog->setSupportedSchemes({QStringLiteral("smb")});
        connect(dialog, &QFileDialog::accepted, this, [dialog, this] {
            dialog->hide();
            dialog->deleteLater();
            const QList<QUrl> urls = dialog->selectedUrls();
            if (urls.isEmpty()) {
                return;
            }
            QUrl url = urls.constFirst();
            url.setQuery(QString()); // clear kio-smb query artifacts such as ?kio-printer=true
            ui->addressLE->setText(url.toString());
        });
        dialog->show();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &pair : deviceId.split(QLatin1Char(';'))) {
                if (pair.startsWith(QLatin1String("MDL:"))) {
                    // Build the make and model string
                    if (make.isNull()) {
                        makeAndModel = pair.section(QLatin1Char(':'), 1);
                    } else {
                        makeAndModel = make + QLatin1Char(' ') + pair.section(QLatin1Char(':'), 1);
                    }
                    break;
                }
            }
```

#### AUTO 


```{c}
auto ui = new PrintQueueUi(printer);
```

#### AUTO 


```{c}
auto button = m_bbox->button(QDialogButtonBox::Help);
```

#### LAMBDA EXPRESSION 


```{c}
[this, notify, status, name] (KCupsRequest *request) {
            const QString ppdFileName = request->printerPPD();
            // Get a list of missing executables
            getMissingExecutables(notify, status, name, ppdFileName);
            request->deleteLater();
        }
```

#### AUTO 


```{c}
auto delJobShortcut = new QShortcut(QKeySequence::Delete, ui->jobsView);
```

#### AUTO 


```{c}
auto le = qobject_cast<QLineEdit *>(sender());
```

#### AUTO 


```{c}
auto statusItem = new QStandardItem(jobStatus(jobState));
```

#### AUTO 


```{c}
auto addMenu = new QMenu(this);
```

#### AUTO 


```{c}
auto page = qobject_cast<GenericPage*>(ui->stackedWidget->currentWidget());
```

#### AUTO 


```{c}
auto groupBox = new QGroupBox(text, ui->scrollArea);
```

#### AUTO 


```{c}
auto nextPage = qobject_cast<GenericPage*>(page->widget());
```

#### AUTO 


```{c}
auto job = new KIO::CommandLauncherJob(QStringLiteral("kde-print-queue"), { m_destName });
```

#### AUTO 


```{c}
auto label = new QLabel(data[KCUPS_MARKER_NAMES].toStringList().at(i), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &uri : uris.toStringList()) {
                ui->connectionsCB->addItem(uriText(uri), uri);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {
        new NewPrinterNotification(this);
    }
```

#### AUTO 


```{c}
auto validator = new QRegExpValidator(rx, this);
```

#### AUTO 


```{c}
auto ret = new QStandardItem;
```

#### AUTO 


```{c}
const auto it = m_arguments.constFind(KCUPS_TIME_AT_COMPLETED);
```

#### LAMBDA EXPRESSION 


```{c}
[notify, arg] () {
        qCDebug(PM_KDED);
        // This function will show the PPD browser dialog
        // to choose a better PPD, queue name, location
        // in this case the printer was not added
        KToolInvocation::kdeinitExec(QLatin1String("kde-add-printer"), {
                                         QLatin1String("--new-printer-from-device"),
                                         arg
                                     });
    }
```

#### AUTO 


```{c}
auto dialog = new QFileDialog(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {
            Q_EMIT finished(this);
        }
```

#### AUTO 


```{c}
auto watcher = new QDBusServiceWatcher(QLatin1String("com.redhat.NewPrinterNotification"),
                                               QDBusConnection::systemBus(),
                                               QDBusServiceWatcher::WatchForUnregistration,
                                               this);
```

#### AUTO 


```{c}
const auto argument = message.arguments().first().value<QDBusArgument>();
```

#### LAMBDA EXPRESSION 


```{c}
[] (const KCupsRawRequest &a, const KCupsRawRequest &b) {
        return a.group < b.group;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : indexes) {
        if (index.column() == JobModel::Columns::ColStatus) {
            if (index.flags() & Qt::ItemIsDragEnabled) {
                // Found a move to item
                moveTo = true;
            }
            if (index.data(JobModel::Role::RoleJobAuthenticationRequired).toBool()) {
                // Found an item which requires authentication
                authenticate = true;
            }
        }
    }
```

#### AUTO 


```{c}
auto gFormLayout = new QFormLayout(groupBox);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVariantHash &arguments : ret) {
            m_printers << KCupsPrinter(arguments);
        }
```

#### AUTO 


```{c}
auto tempFile = new QTemporaryFile;
```

#### AUTO 


```{c}
auto name = m_proxyModel->headerData(i, Qt::Horizontal, Qt::DisplayRole).toString();
```

#### AUTO 


```{c}
auto systemMenu = qobject_cast<QMenu*>(sender());
```

#### AUTO 


```{c}
auto busySeq = new KPixmapSequenceOverlayPainter(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &pair : deviceId.split(QLatin1Char(';'))) {
            if (pair.startsWith(QLatin1String("MFG:"))) {
                make = pair.section(QLatin1Char(':'), 1);
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVariantHash &ppd : ppds) {
            if (ppd[QLatin1String("ppd-name")].toString() == driver.ppd) {
                // Create the PPD
                QStandardItem *ppdItem = createPPDItem(ppd, true);

                if (recommended == 0) {
                    recommended = new QStandardItem;
                    recommended->setText(i18n("Recommended Drivers"));
                    appendRow(recommended);
                }
                recommended->appendRow(ppdItem);

                break;
            }
        }
```

#### AUTO 


```{c}
auto moveToMenu = new QMenu(i18n("Move to"), menu);
```

#### AUTO 


```{c}
auto catItem = new QStandardItem(category);
```

#### AUTO 


```{c}
auto it = m_customValues.constFind(keyword);
```

#### AUTO 


```{c}
auto currentPage = qobject_cast<PrinterPage*>(current->widget());
```

#### AUTO 


```{c}
auto wizard = new AddPrinterAssistant();
```

#### AUTO 


```{c}
auto item = new QStandardItem;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &value : opPolicySupported) {
        ui->operationPolicyCB->addItem(operationPolicyString(value), value);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &queue : queues) {
            showQueue(queue);
        }
```

#### AUTO 


```{c}
auto menu = new QMenu(ui->maintenancePB);
```

#### AUTO 


```{c}
auto page = qobject_cast<PrinterPage *>(currentPage()->widget());
```

#### AUTO 


```{c}
auto i = values.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const DriverMatch &driver : driverMatch) {
        // Find the matched PPD on the PPDs list
        for (const QVariantHash &ppd : ppds) {
            if (ppd[QLatin1String("ppd-name")].toString() == driver.ppd) {
                // Create the PPD
                QStandardItem *ppdItem = createPPDItem(ppd, true);

                if (recommended == 0) {
                    recommended = new QStandardItem;
                    recommended->setText(i18n("Recommended Drivers"));
                    appendRow(recommended);
                }
                recommended->appendRow(ppdItem);

                break;
            }
        }
    }
```

#### AUTO 


```{c}
auto request = static_cast<KCupsRequest*>(user_data);
```

#### AUTO 


```{c}
auto dialog = qobject_cast<SelectMakeModelDialog*>(sender());
```

#### AUTO 


```{c}
auto layout = new QVBoxLayout(this);
```

#### AUTO 


```{c}
auto menu = new QMenu(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QStringList &list : groupeDevices) {
            if (list.isEmpty()) {
                continue;
            }

            const QString uri = list.first();
            const MapSS device = m_mappedDevices[uri];
            insertDevice(device[KCUPS_DEVICE_CLASS],
                         device[KCUPS_DEVICE_ID],
                         device[KCUPS_DEVICE_INFO],
                         device[KCUPS_DEVICE_MAKE_AND_MODEL],
                         uri,
                         device[KCUPS_DEVICE_LOCATION],
                         list.size() > 1 ? list : QStringList());
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, notify, name] (KCupsRequest *request) {
        request->deleteLater();

        QString driver;
        // Get the new printer driver
        if (!request->printers().isEmpty()){
            const KCupsPrinter &printer = request->printers().first();
            driver = printer.makeAndModel();
        }

        // The cups request might have failed
        if (driver.isEmpty()) {
            notify->setText(i18n("'%1' has been added, please check its driver.", name));
            notify->setActions({ i18n("Configure") });
            connect(notify, &KNotification::action1Activated, this, &NewPrinterNotification::configurePrinter);
        } else {
            notify->setText(i18n("'%1' has been added, using the '%2' driver.", name, driver));
            notify->setActions({ i18n("Print test page"), i18n("Find driver") });
            connect(notify, &KNotification::action1Activated, this, &NewPrinterNotification::printTestPage);
            connect(notify, &KNotification::action2Activated, this, &NewPrinterNotification::findDriver);
        }
        notify->sendEvent();
    }
```

#### AUTO 


```{c}
auto page = qobject_cast<PrinterPage*>(currentPage()->widget());
```

#### AUTO 


```{c}
auto printerBehavior = new PrinterBehavior(destName, isClass, this);
```

#### AUTO 


```{c}
auto notify = new KNotification(QLatin1String("NewPrinterNotification"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &value : jobSheetsSupported) {
        ui->startingBannerCB->addItem(jobSheetsString(value), value);
        ui->endingBannerCB->addItem(jobSheetsString(value), value);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVariantHash &ppd : ppds) {
        // Find or create the PPD parent (printer Make)
        QStandardItem *makeItem = findCreateMake(ppd[QLatin1String("ppd-make")].toString());

        // Create the PPD
        QStandardItem *ppdItem = createPPDItem(ppd, false);
        makeItem->appendRow(ppdItem);
    }
```

#### AUTO 


```{c}
auto beforePage = qobject_cast<PrinterPage*>(before->widget());
```

#### LAMBDA EXPRESSION 


```{c}
[=] () {
                    this->modifyJob(JobModel::Move, action->data().toString());
                }
```

#### AUTO 


```{c}
auto mimeData = new QMimeData();
```

#### AUTO 


```{c}
auto job = new KIO::CommandLauncherJob(QStringLiteral("kde-add-printer"), { QStringLiteral("--add-class") });
```

#### AUTO 


```{c}
auto radioGroup = new QButtonGroup(widget);
```

#### LAMBDA EXPRESSION 


```{c}
[dialog, this] {
            dialog->hide();
            dialog->deleteLater();
            const QList<QUrl> urls = dialog->selectedUrls();
            if (urls.isEmpty()) {
                return;
            }
            QUrl url = urls.constFirst();
            url.setQuery(QString()); // clear kio-smb query artifacts such as ?kio-printer=true
            ui->addressLE->setText(url.toString());
        }
```

#### AUTO 


```{c}
auto passwordDialog = static_cast<KCupsPasswordDialog *>(user_data);
```

#### AUTO 


```{c}
auto currPage = qobject_cast<GenericPage*>(currentPage()->widget());
```

#### LAMBDA EXPRESSION 


```{c}
[this, watcher, notify, status, name] () {
        watcher->deleteLater();
        QDBusPendingReply<QStringList> reply = *watcher;
        if (!reply.isValid()) {
            qCWarning(PM_KDED) << "Invalid reply" << reply.error();
            notify->deleteLater();
            return;
        }

        const QStringList missingExecutables = reply;
        if (!missingExecutables.isEmpty()) {
            // TODO check with PackageKit about missing drivers
            qCWarning(PM_KDED) << "Missing executables:" << missingExecutables;
            notify->deleteLater();
            return;
        } else if (status == STATUS_SUCCESS) {
            printerReadyNotification(notify, name);
        } else {
            // Model mismatch
            checkPrinterCurrentDriver(notify, name);
        }
    }
```

#### AUTO 


```{c}
auto usertime = static_cast<qlonglong>(KUserTimestamp::userTimestamp());
```

#### AUTO 


```{c}
auto model = new QStandardItemModel(listView);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCupsPrinter &printer : printers) {
                ui->connectionsCB->addItem(printer.name(), qVariantFromValue(printer));
            }
```

#### AUTO 


```{c}
auto notify = new KNotification(QLatin1String("GetReady"));
```

#### AUTO 


```{c}
auto request = new KCupsRequest;
```

#### AUTO 


```{c}
auto dialog = new SelectMakeModelDialog(m_make, m_makeAndModel, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCupsPrinter &printer : printers) {
                // If there is a printer and it's not the current one add it
                // as a new destination
                if (printer.name() != m_destName) {
                    QAction *action = moveToMenu->addAction(printer.info());
                    action->setData(printer.name());
                }
            }
```

#### AUTO 


```{c}
auto i = m_customValues.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCupsRawRequest &request :requests) {
        switch (request.value.type()) {
        case QVariant::Bool:
            ippAddBoolean(ipp,
                          request.group,
                          request.name.toUtf8().constData(),
                          request.value.toBool());
            break;
        case QVariant::Int:
        case QVariant::UInt:
            ippAddInteger(ipp,
                          request.group,
                          request.valueTag,
                          request.name.toUtf8().constData(),
                          request.value.toInt());
            break;
        case QVariant::String:
            ippAddString(ipp,
                         request.group,
                         request.valueTag,
                         request.name.toUtf8().constData(),
                         "utf-8",
                         request.value.toString().toUtf8().constData());
            break;
        case QVariant::StringList:
        {
            QStringList list = request.value.toStringList();
            QList<QByteArray> valuesQByteArrayList;
            const char **values = qStringListToCharPtrPtr(list, valuesQByteArrayList);

            ippAddStrings(ipp,
                          request.group,
                          request.valueTag,
                          request.name.toUtf8().constData(),
                          list.size(),
                          "utf-8",
                          values);

            // ippAddStrings deep copies everything so we can throw away the values.
            // the QBAList and content is auto discarded when going out of scope.
            delete [] values;
            break;
        }
        default:
            qCWarning(LIBKCUPS) << "type NOT recognized! This will be ignored:" << request.name << "values" << request.value;
        }
    }
```

#### AUTO 


```{c}
auto systemMenu = new QMenu(this);
```

#### AUTO 


```{c}
auto item = new QStandardItem(cText);
```

#### AUTO 


```{c}
auto stdItem = new QStandardItem;
```

