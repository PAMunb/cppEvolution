#### LAMBDA EXPRESSION 


```{c}
[=]() {
                d->fullRepresentationResizeTimer.start();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (Applet *a : lstApplets)
        a->d->setDestroyed(destroyed);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &info : std::as_const(wallpaperList)) {
                    const QString actionText = i18nc("Set wallpaper", "Set %1", info.name());
                    QAction *action = new QAction(actionText, m_dropMenu);
                    if (!info.iconName().isEmpty()) {
                        action->setIcon(QIcon::fromTheme(info.iconName()));
                    }
                    m_dropMenu->addAction(action);
                    actionsToWallpapers.insert(action, info.pluginId());
                    const QUrl url = tjob->url();
                    connect(action, &QAction::triggered, this, [this, url]() {
                        // set wallpapery stuff
                        if (m_wallpaperInterface && url.isValid()) {
                            m_wallpaperInterface->setUrl(url);
                        }
                    });
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &dataDay : data.values(currentDate)) {
                if (stopCounter >= maxEventDisplayed) {
                    break;
                }
                stopCounter++;
                m_eventsData.insert(currentDate, dataDay);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
                    setDestroyed(false);
                    if (!q->isContainment() && q->containment()) {
                        Plasma::Applet *containmentApplet = static_cast<Plasma::Applet *>(q->containment());
                        if (containmentApplet && containmentApplet->d->deleteNotificationTimer) {
                            emit containmentApplet->destroyedChanged(false);
                            //when an applet gets transient, it's "systemimmutable"
                            emit q->immutabilityChanged(q->immutability());
                            delete containmentApplet->d->deleteNotificationTimer;
                            containmentApplet->d->deleteNotificationTimer = nullptr;
                        }

                        //make sure the applets are sorted by id
                        auto position = std::lower_bound(q->containment()->d->applets.begin(), q->containment()->d->applets.end(), q, [](Plasma::Applet *a1,  Plasma::Applet *a2) {
                            return a1->id() < a2->id();
                        });
                        q->containment()->d->applets.insert(position, q);
                        emit q->containment()->appletAdded(q);
                    }
                    if (deleteNotification) {
                        deleteNotification->close();
                    } else if (deleteNotificationTimer) {
                        deleteNotificationTimer->stop();
                        deleteNotificationTimer->deleteLater();
                        deleteNotificationTimer = nullptr;
                    }
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            m_waylandShadowManager->deleteLater();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        delete m_activityInfo;
        m_activityInfo = new KActivities::Info(m_containment->activity(), this);
        connect(m_activityInfo, &KActivities::Info::nameChanged, this, &ContainmentInterface::activityNameChanged);
        Q_EMIT activityNameChanged();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &d : dirList) {
        QString dst_path = dst + QLatin1Char('/') + d;
        dir.mkpath(dst_path);
        copyPath(src + QLatin1Char('/') + d, dst_path);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto data : d->internalPackage->files()) {
        files << data.constData();
    }
```

#### AUTO 


```{c}
auto filter = [type](const KPluginMetaData &md) -> bool {
        return md.value(QStringLiteral("X-Plasma-ContainmentType")) == type;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[ = ]() {
        setVisible(false);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
                    //If the timer still exists, it means the undo action was NOT triggered
                    if (transient) {
                        emit q->destroyedChanged(true);
                        cleanUpAndDelete();
                    }
                    if (deleteNotificationTimer) {
                        deleteNotificationTimer->stop();
                        deleteNotificationTimer->deleteLater();
                        deleteNotificationTimer = 0;
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto a : std::as_const(actions)) {
            if (a->shortcut().isEmpty()) {
                continue;
            }

            if (!a->isEnabled()) {
                continue;
            }

            // this will happen on a normal, non emacs shortcut
            if (seq.matches(a->shortcut()) == QKeySequence::ExactMatch) {
                event->accept();
                a->trigger();
                m_oldKeyboardShortcut = 0;
                return true;

                // first part of an emacs style shortcut?
            } else if (seq.matches(a->shortcut()) == QKeySequence::PartialMatch) {
                keySequenceUsed = true;
                m_oldKeyboardShortcut = ke->key() | ke->modifiers();

                // no match at all, but it can be the second part of an emacs style shortcut
            } else {
                QKeySequence seq(m_oldKeyboardShortcut, ke->key() | ke->modifiers());

                if (seq.matches(a->shortcut()) == QKeySequence::ExactMatch) {
                    event->accept();
                    a->trigger();

                    return true;
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (DataContainer *dc : lst) {
            out << "                * " << dc->objectName() << '\n';
            out << "                       Data count: " << dc->d->data.count() << '\n';
            out << "                       Stored: " << dc->isStorageEnabled() << " \n";
            const int directs = dc->receivers(SIGNAL(dataUpdated(QString,Plasma::DataEngine::Data)));
            if (directs > 0) {
                out << "                       Direction Connections: " << directs << " \n";
            }

            const int relays = dc->d->relays.count();
            if (relays > 0) {
                out << "                       Relays: " << dc->d->relays.count() << '\n';
                QString times;
                for (SignalRelay *relay : qAsConst(dc->d->relays)) {
                    times.append(QLatin1Char(' ') + QString::number(relay->m_interval));
                }
                out << "                       Relay Timeouts: " << times << " \n";
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&parentApp](const KPluginMetaData &md) -> bool {
        const QString pa = md.value(QStringLiteral("X-KDE-ParentApp"));
        return (parentApp.isEmpty() || pa == parentApp) //
            && !KPluginMetaData::readStringList(md.rawData(), QStringLiteral("X-Plasma-DropUrlPatterns")).isEmpty();
    }
```

#### AUTO 


```{c}
auto plugins = d->plasmoidCache.findPluginsById(name, { PluginLoaderPrivate::s_plasmoidsPluginDir, {} });
```

#### AUTO 


```{c}
auto plasmoid = applet.data()->property("_plasma_graphicObject").value<QObject *>();
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        if (m_fillScreen) {
            setGeometry(this->screen()->geometry());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &metadata : metaDataList) {
            plugins.insert(metadata.pluginId(), metadata);
        }
```

#### AUTO 


```{c}
auto it = m_jobs.constBegin();
```

#### LAMBDA EXPRESSION 


```{c}
[this, cont](bool ready) {
                    if (ready && !cont->destroyed()) {
                        q->setVisible(true);
                    }
                }
```

#### LAMBDA EXPRESSION 


```{c}
[&parentApp](const KPluginMetaData &md) -> bool
    {
        return md.value("X-KDE-ParentApp") == parentApp;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](int id) {
            if (id == applet()->containment()->screen()) {
                emit screenGeometryChanged();
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &engine : qAsConst(d->loadedEngines)) {
        DataEngineManager::self()->unloadEngine(engine);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &appletGroup : std::as_const(groups)) {
        // qCDebug(LOG_PLASMA) << "reading from applet group" << appletGroup;
        KConfigGroup appletConfig(&applets, appletGroup);
        appletConfigs.append(appletConfig);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QObject *appletObject : std::as_const(m_appletInterfaces)) {
        if (AppletInterface *ai = qobject_cast<AppletInterface *>(appletObject)) {
            if (ai->isVisible() && ai->contains(ai->mapFromItem(this, event->localPos()))) {
                applet = ai->applet();
                break;
            } else {
                ai = nullptr;
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](){m_syncTimer->start(0);}
```

#### LAMBDA EXPRESSION 


```{c}
[=](){
                    --containmentsStarting;
                    if (containmentsStarting <= 0) {
                        qDebug() << "Corona Startup Completed";
                        emit q->startupCompleted();
                    }
                }
```

#### AUTO 


```{c}
auto fail = [job](const QString &text) {
                            KNotification::event(QStringLiteral("plasmoidInstallationFailed"), i18n("Package Installation Failed"),
                                                 text, QStringLiteral("dialog-error"), 0, KNotification::CloseOnTimeout, QStringLiteral("plasma_workspace"));
                        };
```

#### AUTO 


```{c}
const auto it = m_manager->m_availablePlugins.cbegin() + index.row();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto action : desktopMenu->actions()) {
        if (action->menu()) {
            connect(action->menu(), &QMenu::aboutToShow, desktopMenu, [action, desktopMenu] {
                if (action->menu()->windowHandle()) {
                    // Need to add the transient parent otherwise Qt will create a new toplevel
                    action->menu()->windowHandle()->setTransientParent(desktopMenu->windowHandle());
                }
            });
        }
    }
```

#### AUTO 


```{c}
const auto directories = d->internalPackage->directories();
```

#### AUTO 


```{c}
auto idSize = size.isValid() && size != naturalSize ? size : QSizeF{-1.0, -1.0};
```

#### LAMBDA EXPRESSION 


```{c}
[=] () {
        loadPixmap();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto cont : m_corona->containments()) {
        switch (cont->id()) {
        case 1:
            QCOMPARE(cont->applets().count(), 2);
            break;
        default:
            QCOMPARE(cont->applets().count(), 0);
            break;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&category](const KPluginMetaData &md) -> bool
    {
        return md.value(QStringLiteral("X-KDE-PluginInfo-Category")) == category;
    }
```

#### AUTO 


```{c}
const auto md = loader.metaData().value(QStringLiteral("MetaData")).toObject();
```

#### LAMBDA EXPRESSION 


```{c}
[] (QObject * handler)
                {
                    return handler->property("priority").toInt();
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                if (m_toolTipMainText.isNull()) {
                    emit toolTipMainTextChanged();
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &theme : std::as_const(fallbackThemes)) {
            QString metadataPath(
                QStandardPaths::locate(QStandardPaths::GenericDataLocation,
                                       QStringLiteral(PLASMA_RELATIVE_DATA_INSTALL_DIR "/desktoptheme/") % theme % QStringLiteral("/metadata.desktop")));
            KConfig metadata(metadataPath, KConfig::SimpleConfig);
            processWallpaperSettings(&metadata);
        }
```

#### AUTO 


```{c}
const auto &parts = token.split(QLatin1Char('x'));
```

#### AUTO 


```{c}
auto margins = frameSvgItem->fixedMargins();
```

#### LAMBDA EXPRESSION 


```{c}
[&mimeType](const KPluginMetaData &md) -> bool
    {
        return md.serviceTypes().contains(QLatin1String("Plasma/Containment"))
            && KPluginMetaData::readStringList(md.rawData(), QStringLiteral("X-Plasma-DropMimeTypes")).contains(mimeType);
    }
```

#### AUTO 


```{c}
auto insertIntoCache = [this](const QString &pluginPath) {
            KPluginMetaData metadata(pluginPath);
            if (!metadata.isValid()) {
                qWarning() << "invalid metadata" << pluginPath;
                return;
            }

            plugins[metadata.pluginId()].append(metadata);
        };
```

#### AUTO 


```{c}
auto position = std::lower_bound(d->applets.begin(), d->applets.end(), applet, [](Plasma::Applet *a1,  Plasma::Applet *a2) {
        return a1->id() < a2->id();
    });
```

#### AUTO 


```{c}
const auto lst = m_dataSource->data()->keys();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &theme : qAsConst(fallbackThemes)) {
            QString metadataPath(QStandardPaths::locate(QStandardPaths::GenericDataLocation, QLatin1Literal(PLASMA_RELATIVE_DATA_INSTALL_DIR "/desktoptheme/") % theme % QStringLiteral("/metadata.desktop")));
            KConfig metadata(metadataPath, KConfig::SimpleConfig);
            processWallpaperSettings(&metadata);
        }
```

#### AUTO 


```{c}
const auto items = applet->configScheme()->items();
```

#### RANGE FOR STATEMENT 


```{c}
for (Plasma::Containment *cont : qAsConst(containments)) {
        QCOMPARE(cont->immutability(), Plasma::Types::SystemImmutable);
        const auto lstApplets = cont->applets();
        for (Plasma::Applet *app : lstApplets) {
            QCOMPARE(app->immutability(), Plasma::Types::SystemImmutable);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=] (Plasma::Applet *a) {
        if (Plasma::Applet *p = qobject_cast<Plasma::Applet *>(parent())) {
            emit p->containment()->configureRequested(a);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&mimeType](const KPluginMetaData &md) -> bool
    {
        return md.value("X-KDE-ServiceTypes").contains("Plasma/Containment") && md.value("X-Plasma-DropMimeTypes").contains(mimeType);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Containment *containment : std::as_const(containments)) {
        if (!containment->isUiReady() && containment->screen() >= 0) {
            ++containmentsStarting;
            QObject::connect(containment, &Plasma::Containment::uiReadyChanged, q, [this](bool ready) {
                containmentReady(ready);
            });
        }
    }
```

#### AUTO 


```{c}
const auto cs = s_attachedScopes.value(object);
```

#### AUTO 


```{c}
auto it = reg.begin();
```

#### RANGE FOR STATEMENT 


```{c}
for (QObject *child : children) {
        // find for the needed property of Layout: minimum/maximum/preferred sizes and fillWidth/fillHeight
        /* clang-format off */
        if (child->property("minimumWidth").isValid()
            && child->property("minimumHeight").isValid()
            && child->property("preferredWidth").isValid()
            && child->property("preferredHeight").isValid()
            && child->property("maximumWidth").isValid()
            && child->property("maximumHeight").isValid()
            && child->property("fillWidth").isValid()
            && child->property("fillHeight").isValid()) { /* clang-format on */
            ownLayout = child;
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &plugin : qAsConst(plugins)) {
        engines << plugin.pluginId();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QMenuItem *item : std::as_const(m_items)) {
        if (item->section()) {
            if (!item->isVisible()) {
                continue;
            }

            m_menu->addSection(item->text());
        } else {
            m_menu->addAction(item->action());
            if (item->action()->menu()) {
                // This ensures existence of the QWindow
                m_menu->winId();
                item->action()->menu()->winId();
                item->action()->menu()->windowHandle()->setTransientParent(m_menu->windowHandle());
            }
        }
    }
```

#### AUTO 


```{c}
const auto metaDataList = KPluginMetaData::findPlugins(dir);
```

#### LAMBDA EXPRESSION 


```{c}
[=](bool expanded) {
        //if both compactRepresentationItem and fullRepresentationItem exist,
        //the applet is in a popup
        if (expanded) {
            if (compactRepresentationItem() && fullRepresentationItem() &&
                fullRepresentationItem()->window() && compactRepresentationItem()->window() &&
                fullRepresentationItem()->window() != compactRepresentationItem()->window() &&
                fullRepresentationItem()->parentItem()) {
                fullRepresentationItem()->parentItem()->installEventFilter(this);
            } else if (fullRepresentationItem() && fullRepresentationItem()->parentItem()) {
                fullRepresentationItem()->parentItem()->removeEventFilter(this);
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&mimeType](const KPluginMetaData &md) -> bool {
        return md.serviceTypes().contains(QLatin1String("Plasma/Containment"))
            && KPluginMetaData::readStringList(md.rawData(), QStringLiteral("X-Plasma-DropMimeTypes")).contains(mimeType);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto a : qAsConst(actions)) {
            if (a->shortcut().isEmpty()) {
                continue;
            }

            if (!a->isEnabled()) {
                continue;
            }

            // this will happen on a normal, non emacs shortcut
            if (seq.matches(a->shortcut()) == QKeySequence::ExactMatch) {
                event->accept();
                a->trigger();
                m_oldKeyboardShortcut = 0;
                return true;

                // first part of an emacs style shortcut?
            } else if (seq.matches(a->shortcut()) == QKeySequence::PartialMatch) {
                keySequenceUsed = true;
                m_oldKeyboardShortcut = ke->key() | ke->modifiers();

                // no match at all, but it can be the second part of an emacs style shortcut
            } else {
                QKeySequence seq(m_oldKeyboardShortcut, ke->key() | ke->modifiers());

                if (seq.matches(a->shortcut()) == QKeySequence::ExactMatch) {
                    event->accept();
                    a->trigger();

                    return true;
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &s : list) {
            ret += QString::number(s.width()) % QLatin1Char('x') % QString::number(s.height()) % QLatin1Char(',');
        }
```

#### LAMBDA EXPRESSION 


```{c}
[ = ]() {
        fullRepresentationResizeTimer.start();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QAction *action, const QKeySequence &shortcut) {
            if (action == d->activationAction) {
                d->activationAction->setShortcut(shortcut);
                d->globalShortcutChanged();
            }
        }
```

#### AUTO 


```{c}
const auto itEnd = reg.end();
```

#### AUTO 


```{c}
auto filter = [&excluded, &parentApp](const KPluginMetaData &md) -> bool
        {
            const QString pa = md.value("X-KDE-ParentApp");
            return (pa.isEmpty() || pa == parentApp) && !excluded.contains(md.category());
        };
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &dir : dirs) {
            KPluginMetaData res = KPluginMetaData::findPluginById(dir, pluginName);
            if (res.isValid()) {
                return res;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](const KPluginMetaData &md) -> bool {
        return md.value(QStringLiteral("X-Plasma-API")) == QLatin1String("declarativeappletscript")
            && md.value(QStringLiteral("X-Plasma-ComponentTypes")).contains(QLatin1String("Applet"));
    }
```

#### AUTO 


```{c}
const auto & dir
```

#### LAMBDA EXPRESSION 


```{c}
[ = ]() {
            transient = true;
            cleanUpAndDelete();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool configurationRequired, const QString &reason) {
        Q_UNUSED(configurationRequired);
        Q_UNUSED(reason);
        emit configurationRequiredChanged();
        emit configurationRequiredReasonChanged();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&provides](const KPluginMetaData &md) -> bool {
                    const QStringList provided = KPluginMetaData::readStringList(md.rawData(), QStringLiteral("X-Plasma-Provides"));
                    for (const QString &p : provides) {
                        if (provided.contains(p)) {
                            return true;
                        }
                    }
                    return false;
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QFileInfo &file : files) {
                if (currentCacheFileName.isEmpty() //
                    || !file.absoluteFilePath().endsWith(currentCacheFileName)) {
                    QFile::remove(file.absoluteFilePath());
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &path : paths) {
            if (QFile::exists(path + QStringLiteral("/org/kde/plasma/core"))) {
                m_qmlObject->setSource(QUrl::fromLocalFile(path + QStringLiteral("/org/kde/plasma/core/private/DefaultToolTip.qml")));
                break;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        // in case the applet doesn't want to get shrunk on reactivation,
        // we always expand it again (only in order to conform with legacy behaviour)
        bool activate = !(isExpanded() && isActivationTogglesExpanded());

        setExpanded(activate);
        if (activate) {
            if (QQuickItem *i = qobject_cast<QQuickItem *>(fullRepresentationItem())) {
                // Bug 372476: never pull focus away from it, only setFocus(true)
                i->setFocus(true, Qt::ShortcutFocusReason);
            }
        }
    }
```

#### AUTO 


```{c}
auto platforms = KDeclarative::KDeclarative::runtimePlatform();
```

#### AUTO 


```{c}
auto list = imageGroup.readEntry("Invalidelements", QList<unsigned int>());
```

#### AUTO 


```{c}
auto filter = [&mimeType](const KPluginMetaData &md) -> bool {
        return md.value(QStringLiteral("X-Plasma-DropMimeTypes"), QStringList()).contains(mimeType);
    };
```

#### LAMBDA EXPRESSION 


```{c}
[=] {
            if (q->containment()) {
                emit q->containment()->appletAlternativesRequested(q);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Containment *containment : containments) {
        QString cid = QString::number(containment->id());
        KConfigGroup containmentConfig(&containmentsGroup, cid);
        containment->save(containmentConfig);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &pluginPath) {
            KPluginMetaData metadata(pluginPath);
            if (!metadata.isValid()) {
                qWarning() << "invalid metadata" << pluginPath;
                return;
            }

            plugins[metadata.pluginId()].append(metadata);
        }
```

#### AUTO 


```{c}
auto newFd = FrameSvgPrivate::s_sharedFrames[q->theme()->d].value(newKey);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                findParentScope();
                checkColorGroupChanged();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &group : qAsConst(groups)) {
        KConfigGroup containmentConfig(&containmentsGroup, group);

        if (containmentConfig.entryMap().isEmpty()) {
            continue;
        }

        uint cid = group.toUInt();
        if (containmentsIds.contains(cid)) {
            cid = ++AppletPrivate::s_maxAppletId;
        } else if (cid > AppletPrivate::s_maxAppletId) {
            AppletPrivate::s_maxAppletId = cid;
        }

        if (mergeConfig) {
            KConfigGroup realConf(q->config(), "Containments");
            realConf = KConfigGroup(&realConf, QString::number(cid));
            // in case something was there before us
            realConf.deleteGroup();
            containmentConfig.copyTo(&realConf);
        }

        // qCDebug(LOG_PLASMA) << "got a containment in the config, trying to make a" << containmentConfig.readEntry("plugin", QString()) << "from" << group;
#ifndef NDEBUG
        // qCDebug(LOG_PLASMA) << "!!{} STARTUP TIME" << QTime().msecsTo(QTime::currentTime()) << "Adding Containment" << containmentConfig.readEntry("plugin",
        // QString());
#endif
        Containment *c = addContainment(containmentConfig.readEntry("plugin", QString()), QVariantList(), cid, -1);
        if (!c) {
            continue;
        }

        newContainments.append(c);
        containmentsIds.insert(c->id());

#ifndef NDEBUG
//         qCDebug(LOG_PLASMA) << "!!{} STARTUP TIME" << QTime().msecsTo(QTime::currentTime()) << "Restored Containment" << c->pluginName();
#endif
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&parentApp](const KPluginMetaData &md) -> bool
    {
        const QString pa = md.value("X-KDE-ParentApp");
        return (pa.isEmpty() || pa == parentApp) && !md.value("X-Plasma-DropUrlPatterns").isEmpty();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
                    transient = true;
                    if (deleteNotification) {
                        deleteNotification->close();
                    } else {
                        Q_EMIT q->destroyedChanged(true);
                        cleanUpAndDelete();
                    }
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
            if (q->containment()) {
                emit q->containment()->appletAlternativesRequested(q);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QMenuItem *item : qAsConst(m_items)) {
            if (item->section()) {
                if (!item->isVisible()) {
                    continue;
                }

                m_menu->addSection(item->text());
            } else {
                m_menu->addAction(item->action());
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &kcm : qAsConst(kcms)) {
            KPluginLoader loader(KPluginLoader::findPlugin(QLatin1String("kcms/") + kcm));
            KPluginMetaData md(loader.fileName());

            if (!md.isValid()) {
                qWarning() << "Could not find" << kcm << "specified in X-Plasma-ConfigPlugins";
                continue;
            }

            configModel->appendCategory(md.iconName(), md.name(), QString(), loader.fileName());
        }
```

#### AUTO 


```{c}
auto i = rNames.begin();
```

#### AUTO 


```{c}
auto it = m_eventsData.find(date);
```

#### AUTO 


```{c}
const auto plugins = m_pluginsManager->plugins();
```

#### RANGE FOR STATEMENT 


```{c}
for (Plasma::DataEngine *engine : qAsConst(engines)) {
            delete engine;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[ = ]() {
                    --containmentsStarting;
                    if (containmentsStarting <= 0) {
                        emit q->startupCompleted();
                    }
                }
```

#### LAMBDA EXPRESSION 


```{c}
[ = ]() {
        // in case the applet doesn't want to get shrinked on reactivation,
        // we always expand it again (only in order to conform with legacy behaviour)
        bool activate = !( isExpanded() && isActivationTogglesExpanded() );

        setExpanded(activate);
        if (activate) {
            if (QQuickItem *i = qobject_cast<QQuickItem *>(fullRepresentationItem())) {
                // Bug 372476: never pull focus away from it, only setFocus(true)
                i->setFocus(true, Qt::ShortcutFocusReason);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &group : std::as_const(groups)) {
        KConfigGroup containmentConfig(&containmentsGroup, group);

        if (containmentConfig.entryMap().isEmpty()) {
            continue;
        }

        uint cid = group.toUInt();
        if (containmentsIds.contains(cid)) {
            cid = ++AppletPrivate::s_maxAppletId;
        } else if (cid > AppletPrivate::s_maxAppletId) {
            AppletPrivate::s_maxAppletId = cid;
        }

        if (mergeConfig) {
            KConfigGroup realConf(q->config(), "Containments");
            realConf = KConfigGroup(&realConf, QString::number(cid));
            // in case something was there before us
            realConf.deleteGroup();
            containmentConfig.copyTo(&realConf);
        }

        // qCDebug(LOG_PLASMA) << "got a containment in the config, trying to make a" << containmentConfig.readEntry("plugin", QString()) << "from" << group;
#ifndef NDEBUG
        // qCDebug(LOG_PLASMA) << "!!{} STARTUP TIME" << QTime().msecsTo(QTime::currentTime()) << "Adding Containment" << containmentConfig.readEntry("plugin",
        // QString());
#endif
        Containment *c = addContainment(containmentConfig.readEntry("plugin", QString()), QVariantList(), cid, -1);
        if (!c) {
            continue;
        }

        newContainments.append(c);
        containmentsIds.insert(c->id());

#ifndef NDEBUG
//         qCDebug(LOG_PLASMA) << "!!{} STARTUP TIME" << QTime().msecsTo(QTime::currentTime()) << "Restored Containment" << c->pluginName();
#endif
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &key : keys) {
        dataUpdated(key, m_dataSource->data()->value(key).value<Plasma::DataEngine::Data>());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Containment *cont : qAsConst(d->containments)) {
        if (cont->lastScreen() == screen &&
            (cont->activity().isEmpty() || cont->activity() == activity) &&
            (cont->containmentType() == Plasma::Types::DesktopContainment ||
             cont->containmentType() == Plasma::Types::CustomContainment)) {
            containment = cont;
        }
    }
```

#### AUTO 


```{c}
const auto entryList = dir.entryList(QDir::Files);
```

#### LAMBDA EXPRESSION 


```{c}
[=](bool ready) {
                    if (!ready) {
                        return;
                    }
                    --containmentsStarting;
                    if (containmentsStarting <= 0) {
                        emit q->startupCompleted();
                    }
                }
```

#### LAMBDA EXPRESSION 


```{c}
[&provides](const KPluginMetaData &md) -> bool
            {
                foreach (const QString &p, provides) {
                    if (md.value(QStringLiteral("X-Plasma-Provides")).contains(p)) {
                        return true;
                    }
                }
                return false;
            }
```

#### AUTO 


```{c}
const auto children = q->rootObject()->children();
```

#### RANGE FOR STATEMENT 


```{c}
for (Containment *containment : qAsConst(containments)) {
        if (!containment->isUiReady() && containment->screen() >= 0) {
            ++containmentsStarting;
            QObject::connect(containment, &Plasma::Containment::uiReadyChanged, q, [this](bool ready) {
                containmentReady(ready);
            });
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &md : allApplets) {
        const QStringList urlPatterns = KPluginMetaData::readStringList(md.rawData(), QStringLiteral("X-Plasma-DropUrlPatterns"));
        for (const QString &glob : urlPatterns) {
            QRegExp rx(glob);
            rx.setPatternSyntax(QRegExp::Wildcard);
            if (rx.exactMatch(url.toString())) {
                filtered << md;
            }
        }
    }
```

#### AUTO 


```{c}
auto plugin
```

#### LAMBDA EXPRESSION 


```{c}
[](Plasma::Applet *a1, Plasma::Applet *a2) {
        return a1->id() < a2->id();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &info : qAsConst(appletList)) {
                const QString actionText = i18nc("Add widget", "Add %1", info.name());
                QAction *action = new QAction(actionText, m_dropMenu);
                if (!info.iconName().isEmpty()) {
                    action->setIcon(QIcon::fromTheme(info.iconName()));
                }
                m_dropMenu->addAction(action);
                action->setData(info.pluginId());
                const QUrl url = tjob->url();
                connect(action, &QAction::triggered, this, [this, action, mimetype, url]() {
                    Plasma::Applet *applet = createApplet(action->data().toString(), QVariantList(), QRect(m_dropMenu->dropPoint(), QSize(-1, -1)));
                    setAppletArgs(applet, mimetype, url.toString());
                });
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &pluginPath : std::as_const(pluginsList)) {
        loadPlugin(pluginPath);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&type, &category, &parentApp](const KPluginMetaData &md) -> bool
    {
        if (!md.serviceTypes().contains("Plasma/Containment")) {
            return false;
        }
        const QString pa = md.value("X-KDE-ParentApp");
        if (!pa.isEmpty() && pa != parentApp) {
            return false;
        }

        if (!type.isEmpty() && md.value("X-Plasma-ContainmentType") != type) {
            return false;
        }

        if (!category.isEmpty() && md.value("X-KDE-PluginInfo-Category") != category) {
            return false;
        }

        return true;
    }
```

#### AUTO 


```{c}
auto data = QFINDTESTDATA("../src/desktoptheme/" + theme + "/metadata.desktop");
```

#### AUTO 


```{c}
auto emitChange = [this, c] {
        const int row = categories.indexOf(c);
        if (row > -1) {
            QModelIndex modelIndex = q->index(row);
            Q_EMIT q->dataChanged(modelIndex, modelIndex);
        }
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &overlay : qAsConst(m_overlays)) {
        if (!overlay.isEmpty()) {
            // There is at least one overlay, draw all overlays above m_pixmap
            // and cancel the check
            KIconLoader::global()->drawOverlays(m_overlays, result, KIconLoader::Desktop);
            break;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
            bool hasAlternatives = false;

            const QStringList provides = KPluginMetaData::readStringList(q->pluginMetaData().rawData(), QStringLiteral("X-Plasma-Provides"));
            if (!provides.isEmpty() && q->immutability() == Types::Mutable) {
                auto filter = [&provides](const KPluginMetaData &md) -> bool
                {
                    const QStringList provided = KPluginMetaData::readStringList(md.rawData(), QStringLiteral("X-Plasma-Provides"));
                    foreach (const QString &p, provides) {
                        if (provided.contains(p)) {
                            return true;
                        }
                    }
                    return false;
                };
                QList<KPluginMetaData> applets = KPackage::PackageLoader::self()->findPackages(QStringLiteral("Plasma/Applet"), QString(), filter);

                if (applets.count() > 1) {
                    hasAlternatives = true;
                }
            }
            a->setVisible(hasAlternatives);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QFileInfo &file : cacheDir.entryInfoList()) {
            if (!file.absoluteFilePath().endsWith(svgElementsFileName)) {
                QFile::remove(file.absoluteFilePath());
            }
        }
```

#### AUTO 


```{c}
auto ee = static_cast<QExposeEvent*>(event);
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *a : qAsConst(listActions)) {
        if (a->objectName() == QLatin1String("lock widgets") || a->menu()) {
            // It is up to the Containment to decide if the user is allowed or not
            // to lock/unluck the widgets, so corona should not add one when there is none
            //(user is not allow) and it shouldn't add another one when there is already
            // one
            continue;
        }

        if (!actionOrder.contains(a->objectName())) {
            actions.insert(a->data().toInt() * 100 + i, a);
        } else {
            orderedActions[a->objectName()] = a;
        }
        ++i;
    }
```

#### AUTO 


```{c}
const auto keyList = defaultActionsCfg.keyList();
```

#### AUTO 


```{c}
auto plugins = KPluginLoader::findPlugins(QStringLiteral("plasmacalendarplugins"), [](const KPluginMetaData &md) {
        return md.serviceTypes().contains(QLatin1String("PlasmaCalendar/Plugin"));
    });
```

#### LAMBDA EXPRESSION 


```{c}
[](const QList<QSize> &list) {
        QString ret;
        for (const auto &s : list) {
            ret += QString::number(s.width()) % QLatin1Char('x') % QString::number(s.height()) % QLatin1Char(',');
        }
        return ret;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&excluded, &parentApp](const KPluginMetaData &md) -> bool
        {
            const QString pa = md.value("X-KDE-ParentApp");
            return (pa.isEmpty() || pa == parentApp) && !excluded.contains(md.category());
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&mimeType](const KPluginMetaData &md) -> bool
    {
        return md.value(QStringLiteral("X-Plasma-DropMimeTypes")).contains(mimeType);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=] () {
                m_positionPaneltimer.start();
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QQuickWindow *window) {
        if (!window) {
            return;
        }
        // restart the redirection, it might not have been active yet
        stopRedirecting();
        startRedirecting();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
                    //If the timer still exists, it means the undo action was NOT triggered
                    if (transient) {
                        cleanUpAndDelete();
                    }
                    if (deleteNotificationTimer) {
                        deleteNotificationTimer->stop();
                        deleteNotificationTimer->deleteLater();
                        deleteNotificationTimer = nullptr;
                    }
                }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString element) {
        bool ok;
        element.toLong(&ok);
        return ok;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &key : keyList) {
                    setContainmentActions(key, defaultActionsCfg.readEntry(key, QString()));
                }
```

#### AUTO 


```{c}
auto filter = [](const KPluginMetaData &md) -> bool
    {
        return md.value(QStringLiteral("X-Plasma-API")) == QLatin1String("declarativeappletscript")
            && md.value(QStringLiteral("X-Plasma-ComponentTypes")).contains(QLatin1String("Applet"));
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (QObject *child : children) {
        //find for the needed property of Layout: minimum/maximum/preferred sizes and fillWidth/fillHeight
        if (child->property("minimumWidth").isValid() && child->property("minimumHeight").isValid() &&
                child->property("preferredWidth").isValid() && child->property("preferredHeight").isValid() &&
                child->property("maximumWidth").isValid() && child->property("maximumHeight").isValid() &&
                child->property("fillWidth").isValid() && child->property("fillHeight").isValid()
            ) {
            layout = child;
            break;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&name](const KPluginMetaData &md) -> bool {
        return md.pluginId() == name;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QScreen *screen : screens) {
        // we check geometry() but then take availableGeometry()
        // to reliably check in which screen a position is, we need the full
        // geometry, including areas for panels
        if (screen->geometry().contains(pos)) {
            avail = screen->availableGeometry();
            break;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](Plasma::Containment *c1,  Plasma::Containment *c2) {
        return c1->id() < c2->id();
    }
```

#### AUTO 


```{c}
auto insertIntoCache = [this](const QString &pluginPath) {
            KPluginMetaData metadata(pluginPath);
            if (!metadata.isValid()) {
                qCWarning(LOG_PLASMA) << "invalid metadata" << pluginPath;
                return;
            }

            plugins[metadata.pluginId()].append(metadata);
        };
```

#### RANGE FOR STATEMENT 


```{c}
for (CalendarEvents::CalendarEventsPlugin *eventsPlugin : plugins) {
            eventsPlugin->loadEventsForDateRange(modelFirstDay, modelFirstDay.addDays(42));
        }
```

#### AUTO 


```{c}
auto filterNormal = [&category](const KPluginMetaData &md) -> bool
    {
        return md.value(QStringLiteral("X-KDE-PluginInfo-Category")) == category;
    };
```

#### AUTO 


```{c}
auto willing = [] (QObject * handler)
                {
                    return handler->property("willing").toBool();
                };
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &plugin : plugins) {
        if (!filter(plugin)) {
            continue;
        }
        const QStringList componentTypes = KPluginMetaData::readStringList(plugins.first().rawData(), QStringLiteral("X-Plasma-ComponentTypes"));
        if (((types & Types::AppletComponent) && componentTypes.contains(QLatin1String("Applet")))
            || ((types & Types::DataEngineComponent) && componentTypes.contains(QLatin1String("DataEngine")))) {
            ret << plugin;
        }
    }
```

#### AUTO 


```{c}
const auto metaDataList = KPluginMetaData::findPlugins(pluginNamespace, {}, KPluginMetaData::AllowEmptyMetaData);
```

#### AUTO 


```{c}
auto margin = d->frameSvgItem->fixedMargins();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &plugin : allApplets) {
        if (plugin.category().isEmpty()) {
            if (!categories.contains(i18nc("misc category", "Miscellaneous"))) {
                categories << i18nc("misc category", "Miscellaneous");
            }
        } else {
            categories << plugin.category();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Plasma::Applet *app : cont->applets()) {
            QCOMPARE(app->immutability(), Plasma::Types::UserImmutable);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&language](const KPluginMetaData &md) -> bool
    {
        return md.value(QStringLiteral("X-Plasma-API")) == language;
    }
```

#### AUTO 


```{c}
auto filter = [&parentApp, &excluded, visibleOnly](const KPluginMetaData &md) -> bool {
        const QString pa = md.value(QStringLiteral("X-KDE-ParentApp"));
        return (parentApp.isEmpty() || pa == parentApp) //
            && (excluded.isEmpty() || excluded.contains(md.value(QStringLiteral("X-KDE-PluginInfo-Category")))) //
            && (!visibleOnly || !md.isHidden());
    };
```

#### AUTO 


```{c}
const auto lstFiles = d->internalPackage->files();
```

#### AUTO 


```{c}
auto ptr = s_instance.lock();
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool uiReady) {
            if (uiReady && d->s_preloadPolicy >= AppletQuickItemPrivate::Adaptive) {
                const int preloadWeight = d->preloadWeight();
                qCDebug(LOG_PLASMAQUICK) << "New Applet " << d->applet->title() << "with a weight of" << preloadWeight;

                // don't preload applets less then a certain weight
                if (d->s_preloadPolicy >= AppletQuickItemPrivate::Aggressive || preloadWeight >= AppletQuickItemPrivate::DelayedPreloadWeight) {
                    // spread the creation over a random delay to make it look
                    // plasma started already, and load the popup in the background
                    // without big noticeable freezes, the bigger the weight the smaller is likely
                    // to be the delay, smaller minimum walue, smaller spread
                    const int min = (100 - preloadWeight) * 20;
                    const int max = (100 - preloadWeight) * 100;
                    const int delay = QRandomGenerator::global()->bounded((max + 1) - min) + min;
                    QTimer::singleShot(delay, this, [this, delay]() {
                        qCDebug(LOG_PLASMAQUICK) << "Delayed preload of " << d->applet->title() << "after" << (qreal)delay / 1000 << "seconds";
                        d->preloadForExpansion();
                    });
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &f : entryList) {
        QFile::copy(src + QLatin1Char('/') + f, dst + QLatin1Char('/') + f);
    }
```

#### AUTO 


```{c}
const auto listActions = applet->contextualActions();
```

#### LAMBDA EXPRESSION 


```{c}
[&mimetype, &formFactor](const KPluginMetaData &md) -> bool {
        if (!formFactor.isEmpty() && !md.value(QStringLiteral("X-Plasma-FormFactors")).contains(formFactor)) {
            return false;
        }
        return KPluginMetaData::readStringList(md.rawData(), QStringLiteral("X-Plasma-DropMimeTypes")).contains(mimetype);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&category, &parentApp](const KPluginMetaData &md) -> bool
        {
            const QString pa = md.value("X-KDE-ParentApp");
            if (category == "Miscellaneous") {
                return (pa.isEmpty() || pa == parentApp) && (md.category() == category || md.category().isEmpty());
            } else {
                return (pa.isEmpty() || pa == parentApp) && md.category() == category;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](QQmlEngine *engine, QJSEngine *) -> QObject * {
        engine->setObjectOwnership(&Units::instance(), QQmlEngine::CppOwnership);
        return &Units::instance();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVariant &item : list) {
                const QVariantMap &vh = item.value<QVariantMap>();
                QMapIterator<QString, QVariant> it(vh);
                while (it.hasNext()) {
                    it.next();
                    const QString &roleName = it.key();
                    if (!m_roleIds.contains(roleName)) {
                        ++m_maxRoleId;
                        m_roleNames[m_maxRoleId] = roleName.toLatin1();
                        m_roleIds[roleName] = m_maxRoleId;
                    }
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto & dir: QDir(s_shellsDir).entryList(QDir::Dirs | QDir::NoDotAndDotDot)) {
        const QString qmlFile = s_shellsDir + dir + s_shellLoaderPath;
        // qDebug() << "Making a new instance of " << qmlFile;

        QQmlComponent handlerComponent(engine,
                QUrl::fromLocalFile(qmlFile)
            );
        auto handler = handlerComponent.create();

        // Writing out the errors
        for (const auto & error: handlerComponent.errors()) {
            qWarning() << "Error: " << error;
        }

        if (handler) {
            registerHandler(handler);
        }
    }
```

#### AUTO 


```{c}
auto filter = [&type, &category, &parentApp](const KPluginMetaData &md) -> bool
    {
        if (!md.serviceTypes().contains("Plasma/Containment")) {
            return false;
        }
        const QString pa = md.value("X-KDE-ParentApp");
        if (!pa.isEmpty() && pa != parentApp) {
            return false;
        }

        if (!type.isEmpty() && md.value("X-Plasma-ContainmentType") != type) {
            return false;
        }

        if (!category.isEmpty() && md.value("X-KDE-PluginInfo-Category") != category) {
            return false;
        }

        return true;
    };
```

#### AUTO 


```{c}
const auto lstChild = mainItem->children();
```

#### AUTO 


```{c}
auto sizeListToString = [] (const QList<QSize> &list) {
        QString ret;
        for (const auto &s : list) {
            ret += QString::number(s.width()) % QLatin1Char('x') % QString::number(s.height()) % QLatin1Char(',');
        }
        return ret;
    };
```

#### AUTO 


```{c}
auto i = s_renderers.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &info : qAsConst(appletList)) {
                    sorted.insert(info.name(), info);
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this, cont](bool ready) {
                if (ready && !cont->destroyed()) {
                    q->setVisible(true);
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (QMenuItem *item : qAsConst(m_items)) {
        if (item->section()) {
            if (!item->isVisible()) {
                continue;
            }

            m_menu->addSection(item->text());
        } else {
            m_menu->addAction(item->action());
            if (item->action()->menu()) {
                //This ensures existence of the QWindow
                m_menu->winId();
                item->action()->menu()->winId();
                item->action()->menu()->windowHandle()->setTransientParent(m_menu->windowHandle());
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &kcm : std::as_const(kcms)) {
            // Only look for KCMs in the "kcms_" folder where new QML KCMs live
            // because we don't support loading QWidgets KCMs
            KPluginMetaData md(QLatin1String("kcms/") + kcm);

            if (!md.isValid()) {
                qWarning() << "Could not find" << kcm
                           << "requested by X-Plasma-ConfigPlugins. Ensure that it exists, is a QML KCM, and lives in the 'kcms/' subdirectory.";
                continue;
            }

            configModel->appendCategory(md.iconName(), md.name(), QString(), QLatin1String("kcms/") + kcm);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *a : std::as_const(listActions)) {
        if (a->objectName() == QLatin1String("lock widgets") || a->menu()) {
            // It is up to the Containment to decide if the user is allowed or not
            // to lock/unluck the widgets, so corona should not add one when there is none
            //(user is not allow) and it shouldn't add another one when there is already
            // one
            continue;
        }

        if (!actionOrder.contains(a->objectName())) {
            actions.insert(a->data().toInt() * 100 + i, a);
        } else {
            orderedActions[a->objectName()] = a;
        }
        ++i;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto md : KPackage::PackageLoader::self()->findPackages("Plasma/Applet", QString(), filter)) {
            auto pi = KPluginInfo(KService::serviceByStorageId(md.metaDataFileName()));
            if (!pi.isValid()) {
                qWarning() << "Could not load plugin info:" << md.metaDataFileName()   << "skipping plugin";
                continue;
            }
            list << pi;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Applet *applet : std::as_const(d->applets)) {
        KConfigGroup appletConfig(&applets, QString::number(applet->id()));
        applet->save(appletConfig);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[category, parentApp, platforms](const KPluginMetaData &md) -> bool
        {
            if (!platforms.isEmpty() && !md.formFactors().isEmpty()) {
                bool found = false;
                for (const auto &plat : platforms) {
                    if (md.formFactors().contains(plat)) {
                        found = true;
                        break;
                    }
                }

                if (!found) {
                    return false;
                }
            }

            const QString pa = md.value(QStringLiteral("X-KDE-ParentApp"));

            if (category == QLatin1String("Miscellaneous")) {
                return (parentApp.isEmpty() || pa == parentApp) && (md.category() == category || md.category().isEmpty());
            } else {
                return (parentApp.isEmpty() || pa == parentApp) && md.category() == category;
            }
        }
```

#### AUTO 


```{c}
auto plugin = d->plasmoidCache.findPluginById(name, PluginLoaderPrivate::s_plasmoidsPluginDir);
```

#### AUTO 


```{c}
const auto groupList = loader.groupList();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& info : offers) {
            //const QString proot = "";
            //Plasma::PackageStructure* structure = Plasma::PackageStructure::load(info.pluginName());
            QString name = info.name();
            QString comment = info.comment();
            QString plugin = info.pluginName();
            //QString path = structure->defaultPackageRoot();
            //QString path = defaultPackageRoot;
            plugins.insert(name, QStringList() << name << plugin << comment);
            //qDebug() << "KService stuff:" << name << plugin << comment;
        }
```

#### AUTO 


```{c}
const auto &md
```

#### AUTO 


```{c}
const auto &data
```

#### LAMBDA EXPRESSION 


```{c}
[&category, &parentApp](const KPluginMetaData &md) -> bool {
        return md.value(QStringLiteral("X-KDE-ParentApp")) == parentApp //
            && md.value(QStringLiteral("X-KDE-PluginInfo-Category")) == category;
    }
```

#### AUTO 


```{c}
auto filter = [&mimeType](const KPluginMetaData &md) -> bool
    {
        return md.value("X-KDE-ServiceTypes").contains("Plasma/Containment") && md.value("X-Plasma-DropMimeTypes").contains(mimeType);
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &key : keyList) {
                // qCDebug(LOG_PLASMA) << "loading" << key;
                setContainmentActions(key, cfg.readEntry(key, QString()));
            }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
                    d->syncTimer->start(0);
                }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() { d->slotWindowPositionChanged(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (Plasma::Containment *containment : cs) {
            insertContainment(activity->name(), containment->lastScreen(), containment);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            if (!d->ownLayout) {
                d->connectLayoutAttached(d->currentRepresentationItem);
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {
        findParentScope();
        checkColorGroupChanged();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&category](const KPluginMetaData &md) -> bool
    {
        return md.value("X-KDE-PluginInfo-Category") == category;
    }
```

#### AUTO 


```{c}
const auto pluginName = name.splitRef(QLatin1Char('/')).last();
```

#### AUTO 


```{c}
auto position = std::lower_bound(containments.begin(), containments.end(), containment, [](Plasma::Containment *c1,  Plasma::Containment *c2) {
        return c1->id() < c2->id();
    });
```

#### LAMBDA EXPRESSION 


```{c}
[&provides](const KPluginMetaData &md) -> bool
            {
                foreach (const QString &p, provides) {
                    if (md.value("X-Plasma-Provides").contains(p)) {
                        return true;
                    }
                }
                return false;
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this, item]() {
        removeMenuItem(item);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&mimetype, &formFactor](const KPluginMetaData &md) -> bool
    {
        if (!formFactor.isEmpty() && !md.value(QStringLiteral("X-Plasma-FormFactors")).contains(formFactor)) {
            return false;
        }
        return md.value(QStringLiteral("X-Plasma-DropMimeTypes")).contains(mimetype);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool ready) {
                containmentReady(ready);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[](const KPluginMetaData &) -> bool {
        return true;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (DataContainer *source : qAsConst(d->sources)) {
        if (source->isUsed()) {
            source->forceImmediateUpdate();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto a : qAsConst(actions)) {

            if (a->shortcut().isEmpty()) {
                continue;
            }

            //this will happen on a normal, non emacs shortcut
            if (seq.matches(a->shortcut()) == QKeySequence::ExactMatch) {
                event->accept();
                a->trigger();
                m_oldKeyboardShortcut = 0;
                return true;

            //first part of an emacs style shortcut?
            } else if (seq.matches(a->shortcut()) == QKeySequence::PartialMatch) {
                keySequenceUsed = true;
                m_oldKeyboardShortcut = ke->key()|ke->modifiers();

            //no match at all, but it can be the second part of an emacs style shortcut
            } else {
                QKeySequence seq(m_oldKeyboardShortcut, ke->key()|ke->modifiers());

                if (seq.matches(a->shortcut()) == QKeySequence::ExactMatch) {
                    event->accept();
                    a->trigger();

                    return true;
                }
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool uiReady) {
                if (uiReady && d->s_preloadPolicy >= AppletQuickItemPrivate::Adaptive) {
                    const int preloadWeight = d->preloadWeight();
                    qCDebug(LOG_PLASMAQUICK) << "New Applet " << d->applet->title() << "with a weight of" << preloadWeight;

                    //don't preload applets less then a certain weight
                    if (d->s_preloadPolicy >= AppletQuickItemPrivate::Aggressive || preloadWeight >= AppletQuickItemPrivate::DelayedPreloadWeight) {
                        //spread the creation over a random delay to make it look
                        //plasma started already, and load the popup in the background
                        //without big noticeable freezes, the bigger the weight the smaller is likely
                        //to be the delay, smaller minimum walue, smaller spread
                        const int min = (100 - preloadWeight) * 20;
                        const int max = (100 - preloadWeight) * 100;
                        const int delay = qrand() % ((max + 1) - min) + min;
                        QTimer::singleShot(delay, this, [this, delay]() {
                            qCDebug(LOG_PLASMAQUICK) << "Delayed preload of " << d->applet->title() << "after" << (qreal)delay/1000 << "seconds";
                            d->preloadForExpansion();
                        });
                    }
                }
            }
```

#### AUTO 


```{c}
auto& info
```

#### LAMBDA EXPRESSION 


```{c}
[this, delay]() {
                qCInfo(LOG_PLASMAQUICK) << "Delayed preload of " << d->applet->title() << "after" << (qreal)delay/1000 << "seconds";
                d->preloadForExpansion();
            }
```

#### LAMBDA EXPRESSION 


```{c}
[=] () {
            box->close();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&mimeType](const KPluginMetaData &md) -> bool
    {
        return KPluginMetaData::readStringList(md.rawData(), QStringLiteral("X-Plasma-DropMimeTypes")).contains(mimeType);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &pluginPath) {
            KPluginMetaData metadata(pluginPath);
            if (!metadata.isValid()) {
                return;
            }

            d->pluginCache[metadata.pluginId()].append(metadata);
        }
```

#### AUTO 


```{c}
const auto call = QDBusMessage::createMethodCall(QStringLiteral("org.kde.kded5"), QStringLiteral("/kbuildsycoca"),
        QStringLiteral("org.kde.kbuildsycoca"), QStringLiteral("recreate"));
```

#### AUTO 


```{c}
auto position = std::lower_bound(containments.begin(), containments.end(), containment, [](Plasma::Containment *c1, Plasma::Containment *c2) {
        return c1->id() < c2->id();
    });
```

#### LAMBDA EXPRESSION 


```{c}
[] (const KPluginMetaData &) -> bool { return true;}
```

#### AUTO 


```{c}
auto filter = [&mimetype, &formFactor](const KPluginMetaData &md) -> bool
    {
        if (!formFactor.isEmpty() && !md.value("X-Plasma-FormFactors").contains(formFactor)) {
            return false;
        }
        return md.value("X-Plasma-DropMimeTypes").contains(mimetype);
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &dir : dirs) {
            KPluginLoader::forEachPlugin(dir, insertIntoCache);
        }
```

#### AUTO 


```{c}
auto filter = [&parentApp](const KPluginMetaData &md) -> bool
    {
        const QString pa = md.value(QStringLiteral("X-KDE-ParentApp"));
        return (parentApp.isEmpty() || pa == parentApp) && !KPluginMetaData::readStringList(md.rawData(), QStringLiteral("X-Plasma-DropUrlPatterns")).isEmpty();
    };
```

#### AUTO 


```{c}
const auto result = KPluginFactory::instantiatePlugin<KQuickAddons::ConfigModule>(KPluginMetaData(pluginName), const_cast<ConfigModel *>(this));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QDate date : qAsConst(updatesList)) {
        const QModelIndex changedIndex = indexForDate(date);
        if (changedIndex.isValid()) {
            Q_EMIT dataChanged(changedIndex, changedIndex, {containsEventItems, containsMajorEventItems, containsMinorEventItems});
        }

        Q_EMIT agendaUpdated(date);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Applet *applet : lstApplets) {
        if (!applet->pluginMetaData().isValid()) {
            applet->updateConstraints(Plasma::Types::UiReadyConstraint);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto plugin : plugins) {
        if ((types & Types::AppletComponent) &&
            plugin.value("X-Plasma-ComponentTypes") == "Applet") {
            languages << plugin.value("X-Plasma-API");
        } else if ((types & Types::DataEngineComponent) &&
            plugin.value("X-Plasma-ComponentTypes") == "DataEngine") {
            languages << plugin.value("X-Plasma-API");
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[job](const QString &text) {
                            KNotification::event(QStringLiteral("plasmoidInstallationFailed"), i18n("Package Installation Failed"),
                                                 text, QStringLiteral("dialog-error"), nullptr, KNotification::CloseOnTimeout, QStringLiteral("plasma_workspace"));
                        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &plugin : plugins) {
        languages << plugin.value(QStringLiteral("X-Plasma-API"));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Plasma::Applet *app : lstApplets) {
            QCOMPARE(app->immutability(), Plasma::Types::UserImmutable);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto plugin : plugins) {
        engines << plugin.pluginId();
    }
```

#### AUTO 


```{c}
auto margin = d->frameSvgItem->margins();
```

#### RANGE FOR STATEMENT 


```{c}
for (DataContainer *source : std::as_const(d->sources)) {
        if (source->isUsed()) {
            source->forceImmediateUpdate();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &plugin : plugins) {
                if (seenPlugins.contains(plugin.pluginId())) {
                    continue;
                }

                seenPlugins.insert(plugin.pluginId(), plugin);
                pluginFormats.insert(plugin.pluginId(), format);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &name : qAsConst(actionOrder)) {
        QAction *a = orderedActions.value(name);
        if (a && !a->menu()) {
            actionList << a;
        }
        ++i;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QQmlError &error : errors) {
                reason += error.toString() + QLatin1Char('\n');
            }
```

#### LAMBDA EXPRESSION 


```{c}
[&pluginName](const KPluginMetaData &md) -> bool
    {
        return md.pluginId() == pluginName;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[type](const KPluginMetaData &md) -> bool {
        return md.value(QStringLiteral("X-Plasma-ContainmentType")) == type;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, tjob, posi, packagePath]() {
                    using namespace KPackage;
                    PackageStructure *structure = PackageLoader::self()->loadPackageStructure(QStringLiteral("Plasma/Applet"));
                    Package package(structure);

                    KJob *installJob = package.update(packagePath);
                    connect(installJob, &KJob::result, this, [this, packagePath, structure, posi](KJob *job) {
                        auto fail = [job](const QString &text) {
                            KNotification::event(QStringLiteral("plasmoidInstallationFailed"), i18n("Package Installation Failed"),
                                                 text, QStringLiteral("dialog-error"), 0, KNotification::CloseOnTimeout, QStringLiteral("plasma_workspace"));
                        };

                        // if the applet is already installed, just add it to the containment
                        if (job->error() != KJob::NoError
                            && job->error() != Package::PackageAlreadyInstalledError
                            && job->error() != Package::NewerVersionAlreadyInstalledError) {
                            fail(job->errorText());
                            return;
                        }

                        using namespace KPackage;
                        Package package(structure);
                        // TODO how can I get the path of the actual package?

                        package.setPath(packagePath);

                        // TODO how can I get the plugin id? Package::metadata() is deprecated
                        if (!package.isValid() || !package.metadata().isValid()) {
                            fail(i18n("The package you just dropped is invalid."));
                            return;
                        }

                        createApplet(package.metadata().pluginId(), QVariantList(), QRect(posi, QSize(-1,-1)));
                    });
                }
```

#### AUTO 


```{c}
auto position = std::lower_bound(d->applets.begin(), d->applets.end(), applet, [](Plasma::Applet *a1, Plasma::Applet *a2) {
        return a1->id() < a2->id();
    });
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        q->setEditMode(!q->isEditMode());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        m_svgElementsCache->sync();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](Plasma::Containment *c1, Plasma::Containment *c2) {
        return c1->id() < c2->id();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[ = ]() {
                d->fullRepresentationResizeTimer.start();
            }
```

#### AUTO 


```{c}
auto& plugin
```

#### RANGE FOR STATEMENT 


```{c}
for (QObject *child : lstChild) {
                //find for the needed property of Layout: minimum/maximum/preferred sizes and fillWidth/fillHeight
                if (child->property("minimumWidth").isValid() && child->property("minimumHeight").isValid() &&
                        child->property("preferredWidth").isValid() && child->property("preferredHeight").isValid() &&
                        child->property("maximumWidth").isValid() && child->property("maximumHeight").isValid() &&
                        child->property("fillWidth").isValid() && child->property("fillHeight").isValid()
                   ) {
                    layout = child;
                    break;
                }
            }
```

#### AUTO 


```{c}
const auto lstApplets = Containment::applets();
```

#### LAMBDA EXPRESSION 


```{c}
[this](QObject *obj) {
                m_appletInterfaces.removeAll(obj);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &info : qAsConst(seenPlugins)) {
                QAction *action;
                if (!info.iconName().isEmpty()) {
                    action = new QAction(QIcon::fromTheme(info.iconName()), info.name(), m_dropMenu);
                } else {
                    action = new QAction(info.name(), m_dropMenu);
                }
                m_dropMenu->addAction(action);
                action->setData(info.pluginId());
                connect(action, &QAction::triggered, this, [this, x, y, mimeData, action]() {
                    const QString selectedPlugin = action->data().toString();
                    Plasma::Applet *applet = createApplet(selectedPlugin, QVariantList(), QRect(x, y, -1, -1));
                    setAppletArgs(applet, selectedPlugin, QString::fromUtf8(mimeData->data(selectedPlugin)));
                });

                actionsToPlugins.insert(action, info.pluginId());
            }
```

#### AUTO 


```{c}
auto& priv = ThemePrivate::themes[themeName];
```

#### AUTO 


```{c}
const auto &dataDay
```

#### AUTO 


```{c}
auto ungrabMouseHack = [this]() {
        if (window() && window()->mouseGrabberItem()) {
            window()->mouseGrabberItem()->ungrabMouse();
        }
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this, delay]() {
                            qCDebug(LOG_PLASMAQUICK) << "Delayed preload of " << d->applet->title() << "after" << (qreal)delay/1000 << "seconds";
                            d->preloadForExpansion();
                        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &path : qAsConst(m_candidates)) {
        // qDebug() << "Searching for:" << path + path;
        if (m_possiblePaths.contains(path + key)) {
            resolved = *m_possiblePaths.object(path + key);
            if (!resolved.isEmpty()) {
                break;
            } else {
                continue;
            }
        }

        QDir tmpPath(m_basePath);

        if (tmpPath.isAbsolute()) {
            resolved = m_basePath + path + key;
        } else {
            resolved = QStandardPaths::locate(QStandardPaths::GenericDataLocation, m_basePath + QLatin1Char('/') + path + key);
        }

        m_possiblePaths.insert(path + key, new QString(resolved));
        if (!resolved.isEmpty()) {
            break;
        }
    }
```

#### AUTO 


```{c}
const auto it = localRectCache.constFind(id);
```

#### LAMBDA EXPRESSION 


```{c}
[job](const QString &text) {
                            KNotification::event(QStringLiteral("plasmoidInstallationFailed"), i18n("Package Installation Failed"),
                                                 text, QStringLiteral("dialog-error"), 0, KNotification::CloseOnTimeout, QStringLiteral("plasma_workspace"));
                        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QObject *appletObject : qAsConst(m_appletInterfaces)) {
        if (AppletInterface *ai = qobject_cast<AppletInterface *>(appletObject)) {
            if (ai->isVisible() && ai->contains(ai->mapFromItem(this, event->localPos()))) {
                applet = ai->applet();
                break;
            } else {
                ai = nullptr;
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
            setDestroyed(false);
            if (!q->isContainment() && q->containment()) {
                Plasma::Applet *containmentApplet = static_cast<Plasma::Applet *>(q->containment());
                if (containmentApplet && containmentApplet->d->deleteNotificationTimer) {
                    Q_EMIT containmentApplet->destroyedChanged(false);
                    // when an applet gets transient, it's "systemimmutable"
                    Q_EMIT q->immutabilityChanged(q->immutability());
                    delete containmentApplet->d->deleteNotificationTimer;
                    containmentApplet->d->deleteNotificationTimer = nullptr;
                }

                // make sure the applets are sorted by id
                auto position =
                    std::lower_bound(q->containment()->d->applets.begin(), q->containment()->d->applets.end(), q, [](Plasma::Applet *a1, Plasma::Applet *a2) {
                        return a1->id() < a2->id();
                    });
                q->containment()->d->applets.insert(position, q);
                Q_EMIT q->containment()->appletAdded(q);
            }
            if (deleteNotification) {
                deleteNotification->close();
            } else if (deleteNotificationTimer) {
                deleteNotificationTimer->stop();
                deleteNotificationTimer->deleteLater();
                deleteNotificationTimer = nullptr;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, action, posi, mimetype, url](){
                    Plasma::Applet *applet = createApplet(action->data().toString(), QVariantList(), QRect(posi, QSize(-1,-1)));
                    setAppletArgs(applet, mimetype, url.toString());
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &pluginPath) {
            KPluginMetaData metadata(pluginPath);
            if (!metadata.isValid()) {
                qCWarning(LOG_PLASMA) << "invalid metadata" << pluginPath;
                return;
            }

            plugins[metadata.pluginId()].append(metadata);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Plasma::Containment *cont : qAsConst(containments)) {
        QCOMPARE(cont->immutability(), Plasma::Types::UserImmutable);
        const auto lstApplets = cont->applets();
        for (Plasma::Applet *app : lstApplets) {
            QCOMPARE(app->immutability(), Plasma::Types::UserImmutable);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&mimeType](const KPluginMetaData &md) -> bool {
        return KPluginMetaData::readStringList(md.rawData(), QStringLiteral("X-Plasma-DropMimeTypes")).contains(mimeType);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[ = ]() {
        m_models->clear(sourceName);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, delay]() {
                qCInfo(LOG_PLASMAQUICK) << "Delayed preload of " << d->applet->title() << "after" << (qreal)delay/1000 << "seconds";
                d->createFullRepresentationItem();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginInfo &containmentInfo : containmentInfos) {
        const QStringList theseTypes = containmentInfo.service()->property(QStringLiteral("X-Plasma-ContainmentType")).toStringList();
        for (const QString &type : theseTypes) {
            types.insert(type);
        }
    }
```

#### AUTO 


```{c}
auto containment = qobject_cast<Plasma::Containment*>(obj);
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
                    transient = false;
                    if (!q->isContainment() && q->containment()) {
                        Plasma::Applet *containmentApplet = static_cast<Plasma::Applet *>(q->containment());
                        if (containmentApplet && containmentApplet->d->deleteNotificationTimer) {
                            emit containmentApplet->destroyedChanged(false);
                            //when an applet gets transient, it's "systemimmutable"
                            emit q->immutabilityChanged(q->immutability());
                            delete containmentApplet->d->deleteNotificationTimer;
                            containmentApplet->d->deleteNotificationTimer = 0;
                        }

                        //make sure the applets are sorted by id
                        auto position = std::lower_bound(q->containment()->d->applets.begin(), q->containment()->d->applets.end(), q, [](Plasma::Applet *a1,  Plasma::Applet *a2) {
                            return a1->id() < a2->id();
                        });
                        q->containment()->d->applets.insert(position, q);
                        emit q->containment()->appletAdded(q);
                    }
                    emit q->destroyedChanged(false);
                    //when an applet gets transient, it's "systemimmutable"
                    emit q->immutabilityChanged(q->immutability());
                    if (deleteNotification) {
                        deleteNotification->close();
                    } else if (deleteNotificationTimer) {
                        deleteNotificationTimer->stop();
                        deleteNotificationTimer->deleteLater();
                        deleteNotificationTimer = 0;
                    }
                }
```

#### AUTO 


```{c}
const auto plugins = Plasma::PluginLoader::self()->listAppletMetaDataForMimeType(format);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &hint : elementSizeHints) {

                if (hint.width() >= s.width() * ratio && hint.height() >= s.height() * ratio &&
                        (!bestFit.isValid() ||
                         (bestFit.width() * bestFit.height()) > (hint.width() * hint.height()))) {
                    bestFit = hint;
                }
            }
```

#### AUTO 


```{c}
auto &priv = ThemePrivate::themes[themeName];
```

#### AUTO 


```{c}
auto filter = [&type, &category, &parentApp](const KPluginMetaData &md) -> bool
    {
        if (!md.serviceTypes().contains(QStringLiteral("Plasma/Containment"))) {
            return false;
        }
        if (!parentApp.isEmpty() && md.value(QStringLiteral("X-KDE-ParentApp")) != parentApp) {
            return false;
        }

        if (!type.isEmpty() && md.value(QStringLiteral("X-Plasma-ContainmentType")) != type) {
            return false;
        }

        if (!category.isEmpty() && md.value(QStringLiteral("X-KDE-PluginInfo-Category")) != category) {
            return false;
        }

        return true;
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (Plasma::Containment *cont : std::as_const(containments)) {
        QCOMPARE(cont->immutability(), Plasma::Types::Mutable);
        const auto lstApplets = cont->applets();
        for (Plasma::Applet *app : lstApplets) {
            QCOMPARE(app->immutability(), Plasma::Types::Mutable);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&category, &parentApp](const KPluginMetaData &md) -> bool
        {
            const QString pa = md.value(QStringLiteral("X-KDE-ParentApp"));
            if (category == QLatin1String("Miscellaneous")) {
                return (pa.isEmpty() || pa == parentApp) && (md.category() == category || md.category().isEmpty());
            } else {
                return (pa.isEmpty() || pa == parentApp) && md.category() == category;
            }
        }
```

#### AUTO 


```{c}
const auto *iconTheme = m_iconLoader->theme();
```

#### LAMBDA EXPRESSION 


```{c}
[&parentApp, &excluded, visibleOnly](const KPluginMetaData &md) -> bool
    {
        const QString pa = md.value(QStringLiteral("X-KDE-ParentApp"));
        return (pa.isEmpty() || pa == parentApp)
            && (excluded.isEmpty() || excluded.contains(md.value(QStringLiteral("X-KDE-PluginInfo-Category"))))
            && (!visibleOnly || !md.isHidden());
    }
```

#### AUTO 


```{c}
auto &plugin
```

#### AUTO 


```{c}
const auto &wp
```

#### AUTO 


```{c}
auto it = d->searchJobs.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& plugin : packagePlugins) {
        engines << plugin.pluginId();
    }
```

#### AUTO 


```{c}
auto filterParentApp = [&category, &parentApp](const KPluginMetaData &md) -> bool
    {
        return md.value(QStringLiteral("X-KDE-ParentApp")) == parentApp
            && md.value(QStringLiteral("X-KDE-PluginInfo-Category")) == category;
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : urls) {
            if (firstMimetype != db.mimeTypeForUrl(url)) {
                m_dropMenu->setMultipleMimetypes(true);
                break;
            }
        }
```

#### AUTO 


```{c}
auto filter = [&category, &parentApp](const KPluginMetaData &md) -> bool
        {
            const QString pa = md.value("X-KDE-ParentApp");
            if (category == "Miscellaneous") {
                return (pa.isEmpty() || pa == parentApp) && (md.category() == category || md.category().isEmpty());
            } else {
                return (pa.isEmpty() || pa == parentApp) && md.category() == category;
            }
        };
```

#### LAMBDA EXPRESSION 


```{c}
[] (QObject * handler)
                {
                    return handler->property("willing").toBool();
                }
```

#### AUTO 


```{c}
auto filter = [&mimetype, &formFactor](const KPluginMetaData &md) -> bool
    {
        if (!formFactor.isEmpty() && !md.value(QStringLiteral("X-Plasma-FormFactors")).contains(formFactor)) {
            return false;
        }
        return KPluginMetaData::readStringList(md.rawData(), QStringLiteral("X-Plasma-DropMimeTypes")).contains(mimetype);
    };
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        showToolTip();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto plugin : plugins) {
        const QStringList componentTypes = KPluginMetaData::readStringList(plugins.first().rawData(), QStringLiteral("X-Plasma-ComponentTypes"));
        if (((types & Types::AppletComponent)     && !componentTypes.contains(QLatin1String("Applet")))
          ||((types & Types::DataEngineComponent) && !componentTypes.contains(QLatin1String("DataEngine")))) {
            languages << plugin.value(QStringLiteral("X-Plasma-API"));
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
                transient = true;
                if (deleteNotification) {
                    deleteNotification->close();
                } else {
                    Q_EMIT q->destroyedChanged(true);
                    cleanUpAndDelete();
                }
            }
```

#### AUTO 


```{c}
const auto match = re.match(s);
```

#### AUTO 


```{c}
auto filter = [&provides](const KPluginMetaData &md) -> bool {
                    const QStringList provided = KPluginMetaData::readStringList(md.rawData(), QStringLiteral("X-Plasma-Provides"));
                    for (const QString &p : provides) {
                        if (provided.contains(p)) {
                            return true;
                        }
                    }
                    return false;
                };
```

#### AUTO 


```{c}
const auto children = q->children();
```

#### RANGE FOR STATEMENT 


```{c}
for (QMenuItem *item : std::as_const(m_items)) {
            if (item->section()) {
                if (!item->isVisible()) {
                    continue;
                }

                m_menu->addSection(item->text());
            } else {
                m_menu->addAction(item->action());
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&language](const KPluginMetaData &md) -> bool
    {
        return md.value("X-Plasma-API") == language;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, action, mimetype, url]() {
                    Plasma::Applet *applet = createApplet(action->data().toString(), QVariantList(), QRect(m_dropMenu->dropPoint(), QSize(-1, -1)));
                    setAppletArgs(applet, mimetype, url.toString());
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this, info, url]() {
                        // Change wallpaper plugin if it's not the current one
                        if (containment()->wallpaper() != info.pluginId()) {
                            containment()->setWallpaper(info.pluginId());
                        }

                        // set wallpapery stuff
                        if (m_wallpaperInterface && url.isValid()) {
                            m_wallpaperInterface->setUrl(url);
                        }
                    }
```

#### LAMBDA EXPRESSION 


```{c}
[ = ]() {
                    --containmentsStarting;
                    if (containmentsStarting <= 0) {
                        qDebug() << "Corona Startup Completed";
                        emit q->startupCompleted();
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &path : std::as_const(m_candidates)) {
        // qDebug() << "Searching for:" << path + path;
        if (m_possiblePaths.contains(path + key)) {
            resolved = *m_possiblePaths.object(path + key);
            if (!resolved.isEmpty()) {
                break;
            } else {
                continue;
            }
        }

        QDir tmpPath(m_basePath);

        if (tmpPath.isAbsolute()) {
            resolved = m_basePath + path + key;
        } else {
            resolved = QStandardPaths::locate(QStandardPaths::GenericDataLocation, m_basePath + QLatin1Char('/') + path + key);
        }

        m_possiblePaths.insert(path + key, new QString(resolved));
        if (!resolved.isEmpty()) {
            break;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, c] {
        const int row = categories.indexOf(c);
        if (row > -1) {
            QModelIndex modelIndex = q->index(row);
            Q_EMIT q->dataChanged(modelIndex, modelIndex);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &info : qAsConst(wallpaperList)) {
                    const QString actionText = i18nc("Set wallpaper", "Set %1", info.name());
                    QAction *action = new QAction(actionText, m_dropMenu);
                    if (!info.iconName().isEmpty()) {
                        action->setIcon(QIcon::fromTheme(info.iconName()));
                    }
                    m_dropMenu->addAction(action);
                    actionsToWallpapers.insert(action, info.pluginId());
                    const QUrl url = tjob->url();
                    connect(action, &QAction::triggered, this, [this, url]() {
                        // set wallpapery stuff
                        if (m_wallpaperInterface && url.isValid()) {
                            m_wallpaperInterface->setUrl(url);
                        }
                    });
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (DataContainer *s : std::as_const(d->sources)) {
        d->connectSource(s, visualization, pollingInterval, intervalAlignment);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](bool ready) {
                    if (!ready)
                        return;

                    --containmentsStarting;
                    if (containmentsStarting <= 0) {
                        emit q->startupCompleted();
                    }
                }
```

#### LAMBDA EXPRESSION 


```{c}
[&category, &parentApp](const KPluginMetaData &md) -> bool
    {
        return md.value("X-KDE-ParentApp") == parentApp && md.value("X-KDE-PluginInfo-Category") == category;
    }
```

#### AUTO 


```{c}
const auto &eventData = eventDatas[row];
```

#### AUTO 


```{c}
const auto qttestPath = QStandardPaths::standardLocations(QStandardPaths::GenericDataLocation).constFirst();
```

#### AUTO 


```{c}
auto elements = m_invalidElements.value(filePath);
```

#### LAMBDA EXPRESSION 


```{c}
[=](QObject *obj) {
        // when QObject::destroyed arrives, ~Plasma::Containment has run,
        // members of Containment are not accessible anymore,
        // so keep ugly bookeeping by hand
        auto containment = static_cast<Plasma::Containment*>(obj);
        for (auto a : d->desktopContainments) {
            QMutableHashIterator<int, Plasma::Containment *> it(a);
            while (it.hasNext()) {
                it.next();
                if (it.value() == containment) {
                    it.remove();
                    return;
                }
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, parentObject]() {
                findParentScope();
                checkColorGroupChanged();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &fileName : entryList) {
            const QString absolutePath = dir.absoluteFilePath(fileName);
            if (m_availablePlugins.contains(absolutePath)) {
                continue;
            }

            QPluginLoader loader(absolutePath);
            // Load only our own plugins
            if (loader.metaData().value(QStringLiteral("IID")) == QLatin1String("org.kde.CalendarEventsPlugin")) {
                const auto md = loader.metaData().value(QStringLiteral("MetaData")).toObject();
                m_availablePlugins.insert(absolutePath,
                                          {md.value(QStringLiteral("Name")).toString(),
                                           md.value(QStringLiteral("Description")).toString(),
                                           md.value(QStringLiteral("Icon")).toString(),
                                           md.value(QStringLiteral("ConfigUi")).toString()});
            }
        }
```

#### AUTO 


```{c}
const auto lstApplets = cont->applets();
```

#### LAMBDA EXPRESSION 


```{c}
[category, parentApp](const KPluginMetaData &md) -> bool
        {
            const QString pa = md.value(QStringLiteral("X-KDE-ParentApp"));
            if (category == QLatin1String("Miscellaneous")) {
                return (pa.isEmpty() || pa == parentApp) && (md.category() == category || md.category().isEmpty());
            } else {
                return (pa.isEmpty() || pa == parentApp) && md.category() == category;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[ = ]() {
                    d->resizeOrigin = DialogPrivate::MainItem;
                    d->syncTimer->start(0);
                }
```

#### LAMBDA EXPRESSION 


```{c}
[ = ]() {
        setExpanded(true);
        if (QQuickItem *i = qobject_cast<QQuickItem *>(fullRepresentationItem())) {
            i->forceActiveFocus(Qt::ShortcutFocusReason);
        }
    }
```

#### AUTO 


```{c}
auto plugins = KPluginLoader::findPlugins(
            QStringLiteral("plasmacalendarplugins"),
            [](const KPluginMetaData &md) {
                return md.serviceTypes().contains(QLatin1String("PlasmaCalendar/Plugin"));
            });
```

#### AUTO 


```{c}
const auto paths = m_qmlObject->engine()->importPathList();
```

#### AUTO 


```{c}
const auto &eventDatas = data(parent, Roles::Events).value<QList<CalendarEvents::EventData>>();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto md : KPackage::PackageLoader::self()->findPackages("Plasma/Applet", QString(), filter)) {
            auto pi =  KPluginInfo(KService::serviceByStorageId(md.metaDataFileName()));
            if (!pi.isValid()) {
                qWarning() << "Could not load plugin info for plugin :" << md.pluginId() << "skipping plugin";
                continue;
            }
            list << pi;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &hint : elementSizeHints) {
                if (hint.width() >= s.width() * ratio && hint.height() >= s.height() * ratio
                    && (!bestFit.isValid() || (bestFit.width() * bestFit.height()) > (hint.width() * hint.height()))) {
                    bestFit = hint;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (Containment *containment : qAsConst(d->containments)) {
        if (containment->screen() == screen &&
            (containment->containmentType() == Plasma::Types::DesktopContainment ||
             containment->containmentType() == Plasma::Types::CustomContainment)) {
            return containment;
        }
    }
```

#### AUTO 


```{c}
auto filter = [&parentApp](const KPluginMetaData &md) -> bool {
        return md.value(QStringLiteral("X-KDE-ParentApp")) == parentApp;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this](QQuickWindow * window) {
        if (!window) {
            return;
        }
        // restart the redirection, it might not have been active yet
        stopRedirecting();
        startRedirecting();
        update();
    }
```

#### AUTO 


```{c}
auto filter = [&mimeType](const KPluginMetaData &md) -> bool {
        return KPluginMetaData::readStringList(md.rawData(), QStringLiteral("X-Plasma-DropMimeTypes")).contains(mimeType);
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto & error: handlerComponent.errors()) {
            qWarning() << "Error: " << error;
        }
```

#### AUTO 


```{c}
const auto & error
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &p : provides) {
                        if (provided.contains(p)) {
                            return true;
                        }
                    }
```

#### AUTO 


```{c}
auto plugins = KPluginLoader::findPlugins(QStringLiteral("plasmacalendarplugins"), [](const KPluginMetaData &md) {
        return md.rawData().contains(QStringLiteral("KPlugin"));
    });
```

#### AUTO 


```{c}
auto filter = [&provides](const KPluginMetaData &md) -> bool
            {
                foreach (const QString &p, provides) {
                    if (md.value(QStringLiteral("X-Plasma-Provides")).contains(p)) {
                        return true;
                    }
                }
                return false;
            };
```

#### AUTO 


```{c}
auto position = std::lower_bound(q->containment()->d->applets.begin(), q->containment()->d->applets.end(), q, [](Plasma::Applet *a1,  Plasma::Applet *a2) {
                            return a1->id() < a2->id();
                        });
```

#### AUTO 


```{c}
const auto keys = m_dataSource->data()->keys();
```

#### AUTO 


```{c}
const auto info = corona->kPackage().metadata();
```

#### AUTO 


```{c}
auto containment = static_cast<Plasma::Containment*>(obj);
```

#### LAMBDA EXPRESSION 


```{c}
[this](Qt::WindowState newState) {
        if (newState == Qt::WindowMinimized) {
            setVisible(false);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &appletName : appletNames) {
            qDebug() << "adding" << appletName;

            metaObject()->invokeMethod(this, "createApplet", Qt::QueuedConnection, Q_ARG(QString, appletName), Q_ARG(QVariantList, QVariantList()), Q_ARG(QRectF, QRectF(x, y, -1, -1)));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &key : imageGroup.keyList()) {
        bool ok = false;
        uint keyUInt = key.toUInt(&ok);
        if (ok) {
            const QRectF rect = imageGroup.readEntry(key, QRectF());
            m_localRectCache.insert(keyUInt, rect);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &data : lstFiles) {
        files << data.constData();
    }
```

#### AUTO 


```{c}
const auto &plugin
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &dir : dirs) {
            ret = KPluginLoader::findPluginsById(dir, pluginName);
            if (!ret.isEmpty())
                break;
        }
```

#### AUTO 


```{c}
const auto &hint
```

#### RANGE FOR STATEMENT 


```{c}
for (auto md : KPackage::PackageLoader::self()->findPackages("Plasma/Applet", QString(), filter)) {
            auto pi =  KPluginInfo(KService::serviceByStorageId(md.metaDataFileName()));
            if (!pi.isValid()) {
                qWarning() << "Could not load plugin info:" << md.metaDataFileName()   << "skipping plugin";
                continue;
            }
            list << pi;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QDate date : std::as_const(updatesList)) {
        const QModelIndex changedIndex = indexForDate(date);
        if (changedIndex.isValid()) {
            Q_EMIT dataChanged(changedIndex, changedIndex, {containsEventItems, containsMajorEventItems, containsMinorEventItems, EventColor});
        }
        Q_EMIT agendaUpdated(date);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, delay]() {
                            qCInfo(LOG_PLASMAQUICK) << "Delayed preload of " << d->applet->title() << "after" << (qreal)delay/1000 << "seconds";
                            d->preloadForExpansion();
                        }
```

#### AUTO 


```{c}
auto filter = [&provides](const KPluginMetaData &md) -> bool
                {
                    const QStringList provided = KPluginMetaData::readStringList(md.rawData(), QStringLiteral("X-Plasma-Provides"));
                    foreach (const QString &p, provides) {
                        if (provided.contains(p)) {
                            return true;
                        }
                    }
                    return false;
                };
```

#### RANGE FOR STATEMENT 


```{c}
for (Plasma::Applet *app : lstApplets) {
            QCOMPARE(app->immutability(), Plasma::Types::SystemImmutable);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        if (!isVisible()) {
            stopRedirecting();
            releaseResources();
        } else if (isEnabled()) {
            startRedirecting();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Containment *c : qAsConst(containments)) {
        // we need to tell each containment that immutability has been altered
        c->updateConstraints(Types::ImmutableConstraint);
    }
```

#### AUTO 


```{c}
auto filter = [](const KPluginMetaData &md) -> bool {
        return md.value(QStringLiteral("X-Plasma-API")) == QLatin1String("declarativeappletscript")
            && md.value(QStringLiteral("X-Plasma-ComponentTypes")).contains(QLatin1String("Applet"));
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &plugin : qAsConst(plugins)) {
        m_availablePlugins.insert(plugin.fileName(),
                                  {plugin.name(), plugin.description(), plugin.iconName(), plugin.value(QStringLiteral("X-KDE-PlasmaCalendar-ConfigUi"))});
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, packagePath]() {
                    using namespace KPackage;
                    PackageStructure *structure = PackageLoader::self()->loadPackageStructure(QStringLiteral("Plasma/Applet"));
                    Package package(structure);

                    KJob *installJob = package.update(packagePath);
                    connect(installJob, &KJob::result, this, [this, packagePath, structure](KJob *job) {
                        auto fail = [](const QString &text) {
                            KNotification::event(QStringLiteral("plasmoidInstallationFailed"), i18n("Package Installation Failed"),
                                                 text, QStringLiteral("dialog-error"), nullptr, KNotification::CloseOnTimeout, QStringLiteral("plasma_workspace"));
                        };

                        // if the applet is already installed, just add it to the containment
                        if (job->error() != KJob::NoError
                            && job->error() != Package::PackageAlreadyInstalledError
                            && job->error() != Package::NewerVersionAlreadyInstalledError) {
                            fail(job->errorText());
                            return;
                        }

                        using namespace KPackage;
                        Package package(structure);
                        // TODO how can I get the path of the actual package?

                        package.setPath(packagePath);

                        // TODO how can I get the plugin id? Package::metadata() is deprecated
                        if (!package.isValid() || !package.metadata().isValid()) {
                            fail(i18n("The package you just dropped is invalid."));
                            return;
                        }

                        createApplet(package.metadata().pluginId(), QVariantList(), QRect(m_dropMenu->dropPoint(), QSize(-1,-1)));
                    });
                }
```

#### LAMBDA EXPRESSION 


```{c}
[packageFormat](const KPluginMetaData &md) -> bool
        {
            return md.value(QStringLiteral("X-KDE-PluginInfo-Name")) == packageFormat;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        if (!isEnabled()) {
            stopRedirecting();
            releaseResources();
        } else if (isVisible()) {
            startRedirecting();
            update();
        }
    }
```

#### AUTO 


```{c}
auto handler =* std::min_element(d->handlers.cbegin(), d->handlers.cend(),
            [] (QObject * left, QObject * right)
            {
                auto willing = [] (QObject * handler)
                {
                    return handler->property("willing").toBool();
                };

                auto priority = [] (QObject * handler)
                {
                    return handler->property("priority").toInt();
                };

                return
                    // If one is willing and the other is not,
                    // return it - it has the priority
                    willing(left) && !willing(right) ? true :
                    !willing(left) && willing(right) ? false :
                    // otherwise just compare the priorities
                    priority(left) < priority(right);
            }
         );
```

#### AUTO 


```{c}
const auto match = sizeHintedKeyExpr.match(key);
```

#### AUTO 


```{c}
auto item = qobject_cast<QQuickItem *>(graphicObject)
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &appletGroup : qAsConst(groups)) {
        // qCDebug(LOG_PLASMA) << "reading from applet group" << appletGroup;
        KConfigGroup appletConfig(&applets, appletGroup);
        appletConfigs.append(appletConfig);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](QScreen *screen){setScreen(screen); syncGeometry();}
```

#### LAMBDA EXPRESSION 


```{c}
[ = ]() {
                m_status = DialogStatus::Closed;
                emit statusChanged();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &plugin : std::as_const(plugins)) {
        engines << plugin.pluginId();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, posi, mimetype, url](){
                    Plasma::Applet *applet = createApplet(QStringLiteral("org.kde.plasma.icon"), QVariantList(), QRect(posi, QSize(-1,-1)));
                    setAppletArgs(applet, mimetype, url.toString());
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (Containment *cont : std::as_const(d->containments)) {
        /* clang-format off */
        if (cont->lastScreen() == screen
            && ((cont->activity().isEmpty() || activity.isEmpty()) || cont->activity() == activity)
            && (cont->containmentType() == Plasma::Types::DesktopContainment
                || cont->containmentType() == Plasma::Types::CustomContainment)) { /* clang-format on */
            containment = cont;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            QQuickItem *parentItem = this->parentItem();
            if (parentItem && parentItem->window() && parentItem->window()->mouseGrabberItem()) {
                parentItem->window()->mouseGrabberItem()->ungrabMouse();
            }
        }
```

#### AUTO 


```{c}
const auto it = d->pixmapsToCache.constFind(id);
```

#### AUTO 


```{c}
auto filter = [&mimetype, &formFactor](const KPluginMetaData &md) -> bool
    {
        if (!formFactor.isEmpty() && !md.value(QStringLiteral("X-Plasma-FormFactors")).contains(formFactor)) {
            return false;
        }
        return md.value(QStringLiteral("X-Plasma-DropMimeTypes")).contains(mimetype);
    };
```

#### AUTO 


```{c}
const auto plugins = d->plasmoidCache.findPluginsById(name, { PluginLoaderPrivate::s_plasmoidsPluginDir, {} });
```

#### AUTO 


```{c}
auto filter = [&parentApp](const KPluginMetaData &md) -> bool
    {
        return md.value("X-KDE-ParentApp") == parentApp;
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (Plasma::Containment *c : qAsConst(containments)) {
        c->save(dummy);
        c->config().reparent(&dest);

        //ensure the containment is unlocked
        //this is done directly because we have to bypass any Types::SystemImmutable checks
        c->Applet::d->immutability = Types::Mutable;
        const auto lstApplet = c->applets();
        for (Applet *a : lstApplet) {
            a->d->immutability = Types::Mutable;
        }

        c->destroy();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KConfigSkeletonItem *item : items) {
                item->setGroup(item->group().replace(0, oldGroupPrefix.length(), newGroupPrefix));
            }
```

#### LAMBDA EXPRESSION 


```{c}
[=] () {
                d->transient = true;
                d->cleanUpAndDelete();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (Applet *applet : qAsConst(applets)) {
            applet->updateConstraints(appletConstraints);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Plasma::Containment *c : qAsConst(containments)) {
        c->save(dummy);
        c->config().reparent(&dest);

        // ensure the containment is unlocked
        // this is done directly because we have to bypass any Types::SystemImmutable checks
        c->Applet::d->immutability = Types::Mutable;
        const auto lstApplet = c->applets();
        for (Applet *a : lstApplet) {
            a->d->immutability = Types::Mutable;
        }

        c->destroy();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&mimeType](const KPluginMetaData &md) -> bool {
        return md.value(QStringLiteral("X-Plasma-DropMimeTypes"), QStringList()).contains(mimeType);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
                if (!m_containment) {
                    return;
                }
                disconnect(m_containment.data(), &Plasma::Containment::appletRemoved,
                           this, &ContainmentInterface::appletRemovedForward);
            }
```

#### AUTO 


```{c}
auto insertIntoCache = [this](const QString &pluginPath) {
            KPluginMetaData metadata(pluginPath);
            if (!metadata.isValid()) {
                qCDebug(LOG_PLASMA) << "invalid metadata" << pluginPath;
                return;
            }

            plugins[metadata.pluginId()].append(metadata);
        };
```

#### RANGE FOR STATEMENT 


```{c}
for (Containment *containment : containments) {
        if (containment->screen() == screen &&
                freeEdges.contains(containment->location())) {
            freeEdges.removeAll(containment->location());
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&parentApp](const KPluginMetaData &md) -> bool
    {
        const QString pa = md.value(QStringLiteral("X-KDE-ParentApp"));
        return (pa.isEmpty() || pa == parentApp) && !md.value(QStringLiteral("X-Plasma-DropUrlPatterns")).isEmpty();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &glob : urlPatterns) {
            QRegExp rx(glob);
            rx.setPatternSyntax(QRegExp::Wildcard);
            if (rx.exactMatch(url.toString())) {
#ifndef NDEBUG
                // qCDebug(LOG_PLASMA) << md.name() << "matches" << glob << url;
#endif
                filtered << md;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, posi, packagePath]() {
                    using namespace KPackage;
                    PackageStructure *structure = PackageLoader::self()->loadPackageStructure(QStringLiteral("Plasma/Applet"));
                    Package package(structure);

                    KJob *installJob = package.update(packagePath);
                    connect(installJob, &KJob::result, this, [this, packagePath, structure, posi](KJob *job) {
                        auto fail = [](const QString &text) {
                            KNotification::event(QStringLiteral("plasmoidInstallationFailed"), i18n("Package Installation Failed"),
                                                 text, QStringLiteral("dialog-error"), nullptr, KNotification::CloseOnTimeout, QStringLiteral("plasma_workspace"));
                        };

                        // if the applet is already installed, just add it to the containment
                        if (job->error() != KJob::NoError
                            && job->error() != Package::PackageAlreadyInstalledError
                            && job->error() != Package::NewerVersionAlreadyInstalledError) {
                            fail(job->errorText());
                            return;
                        }

                        using namespace KPackage;
                        Package package(structure);
                        // TODO how can I get the path of the actual package?

                        package.setPath(packagePath);

                        // TODO how can I get the plugin id? Package::metadata() is deprecated
                        if (!package.isValid() || !package.metadata().isValid()) {
                            fail(i18n("The package you just dropped is invalid."));
                            return;
                        }

                        createApplet(package.metadata().pluginId(), QVariantList(), QRect(posi, QSize(-1,-1)));
                    });
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto a : qAsConst(actions)) {
            if (a->shortcut().isEmpty()) {
                continue;
            }

            // this will happen on a normal, non emacs shortcut
            if (seq.matches(a->shortcut()) == QKeySequence::ExactMatch) {
                event->accept();
                a->trigger();
                m_oldKeyboardShortcut = 0;
                return true;

                // first part of an emacs style shortcut?
            } else if (seq.matches(a->shortcut()) == QKeySequence::PartialMatch) {
                keySequenceUsed = true;
                m_oldKeyboardShortcut = ke->key() | ke->modifiers();

                // no match at all, but it can be the second part of an emacs style shortcut
            } else {
                QKeySequence seq(m_oldKeyboardShortcut, ke->key() | ke->modifiers());

                if (seq.matches(a->shortcut()) == QKeySequence::ExactMatch) {
                    event->accept();
                    a->trigger();

                    return true;
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &md : allApplets) {
        const QStringList urlPatterns = md.value(QStringLiteral("X-Plasma-DropUrlPatterns"), QStringList());
        for (const QString &glob : urlPatterns) {
            QRegExp rx(glob);
            rx.setPatternSyntax(QRegExp::Wildcard);
            if (rx.exactMatch(url.toString())) {
                filtered << md;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (DataContainer *s : qAsConst(d->sources)) {
        d->connectSource(s, visualization, pollingInterval, intervalAlignment);
    }
```

#### AUTO 


```{c}
auto insertIntoCache = [this](const QString &pluginPath) {
            KPluginMetaData metadata(pluginPath);
            if (!metadata.isValid()) {
                return;
            }

            d->pluginCache[metadata.pluginId()].append(metadata);
        };
```

#### AUTO 


```{c}
const auto groupList = config.groupList();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &libraryPath : paths) {
        const QString path(libraryPath + QStringLiteral("/plasmacalendarplugins"));
        QDir dir(path);

        if (!dir.exists()) {
            continue;
        }

        const QStringList entryList = dir.entryList(QDir::Files | QDir::NoDotAndDotDot);

        for (const QString &fileName : entryList) {
            const QString absolutePath = dir.absoluteFilePath(fileName);
            if (m_availablePlugins.contains(absolutePath)) {
                continue;
            }

            QPluginLoader loader(absolutePath);
            // Load only our own plugins
            if (loader.metaData().value(QStringLiteral("IID")) == QLatin1String("org.kde.CalendarEventsPlugin")) {
                const auto md = loader.metaData().value(QStringLiteral("MetaData")).toObject();
                m_availablePlugins.insert(absolutePath,
                                          {md.value(QStringLiteral("Name")).toString(),
                                           md.value(QStringLiteral("Description")).toString(),
                                           md.value(QStringLiteral("Icon")).toString(),
                                           md.value(QStringLiteral("ConfigUi")).toString()});
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Containment *containment : qAsConst(d->containments)) {
        if (containment->screen() == screen //
            && (containment->containmentType() == Plasma::Types::DesktopContainment //
                || containment->containmentType() == Plasma::Types::CustomContainment)) {
            return containment;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Applet *a : lstApplet) {
            a->d->immutability = Types::Mutable;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &key : lst) {
                if (!m_sourceFilter.isEmpty() && m_sourceFilterRE.isValid() && !isExactMatch(m_sourceFilterRE, key)) {
                    continue;
                }
                QVariant value = m_dataSource->data()->value(key);
                if (value.isValid() && value.canConvert<Plasma::DataEngine::Data>()) {
                    Plasma::DataEngine::Data data = value.value<Plasma::DataEngine::Data>();
                    data[QStringLiteral("DataEngineSource")] = key;
                    list.append(data);
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &dataDay : data.values(currentDate)) {
                if (stopCounter > nextIndex) {
                    break;
                }
                stopCounter++;
                m_eventsData.insert(currentDate, dataDay);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (KService::Ptr s : offers) {
        if (!knownPlugins.contains(s->pluginKeyword())) {
            list.append(KPluginInfo(s));
        }
    }
```

#### AUTO 


```{c}
auto sizeListToString = [](const QList<QSize> &list) {
        QString ret;
        for (const auto &s : list) {
            ret += QString::number(s.width()) % QLatin1Char('x') % QString::number(s.height()) % QLatin1Char(',');
        }
        return ret;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                if (m_toolTipMainText.isNull()) {
                    Q_EMIT toolTipMainTextChanged();
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[&parentApp](const KPluginMetaData &md) -> bool
    {
        return md.value(QStringLiteral("X-KDE-ParentApp")) == parentApp;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const KConfigGroup &group, const QByteArrayList &names) {
        if (group.name() == QLatin1String("KDE") && names.contains(QByteArrayLiteral("AnimationDurationFactor"))) {
            updateAnimationSpeed();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[excluded, parentApp, platforms](const KPluginMetaData &md) -> bool {
            if (!platforms.isEmpty() && !md.formFactors().isEmpty()) {
                bool found = false;
                for (const auto &plat : platforms) {
                    if (md.formFactors().contains(plat)) {
                        found = true;
                        break;
                    }
                }

                if (!found) {
                    return false;
                }
            }

            const QString pa = md.value(QStringLiteral("X-KDE-ParentApp"));
            return (parentApp.isEmpty() || pa == parentApp) && !excluded.contains(md.category());
        }
```

#### AUTO 


```{c}
auto dialog = d->dialog.instance();
```

#### LAMBDA EXPRESSION 


```{c}
[this, posi, packagePath]() {
                    using namespace KPackage;
                    PackageStructure *structure = PackageLoader::self()->loadPackageStructure(QStringLiteral("Plasma/Applet"));
                    Package package(structure);

                    KJob *installJob = package.update(packagePath);
                    connect(installJob, &KJob::result, this, [this, packagePath, structure, posi](KJob *job) {
                        auto fail = [job](const QString &text) {
                            KNotification::event(QStringLiteral("plasmoidInstallationFailed"), i18n("Package Installation Failed"),
                                                 text, QStringLiteral("dialog-error"), 0, KNotification::CloseOnTimeout, QStringLiteral("plasma_workspace"));
                        };

                        // if the applet is already installed, just add it to the containment
                        if (job->error() != KJob::NoError
                            && job->error() != Package::PackageAlreadyInstalledError
                            && job->error() != Package::NewerVersionAlreadyInstalledError) {
                            fail(job->errorText());
                            return;
                        }

                        using namespace KPackage;
                        Package package(structure);
                        // TODO how can I get the path of the actual package?

                        package.setPath(packagePath);

                        // TODO how can I get the plugin id? Package::metadata() is deprecated
                        if (!package.isValid() || !package.metadata().isValid()) {
                            fail(i18n("The package you just dropped is invalid."));
                            return;
                        }

                        createApplet(package.metadata().pluginId(), QVariantList(), QRect(posi, QSize(-1,-1)));
                    });
                }
```

#### AUTO 


```{c}
auto filter = [packageFormat](const KPluginMetaData &md) -> bool
        {
            return md.value(QStringLiteral("X-KDE-PluginInfo-Name")) == packageFormat;
        };
```

#### LAMBDA EXPRESSION 


```{c}
[&parentApp](const KPluginMetaData &md) -> bool {
        return md.value(QStringLiteral("X-KDE-ParentApp")) == parentApp;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Applet *applet : std::as_const(applets)) {
            if (applet->status() > appletStatus && applet->status() != Plasma::Types::HiddenStatus) {
                appletStatus = applet->status();
            }
        }
```

#### AUTO 


```{c}
auto info
```

#### LAMBDA EXPRESSION 


```{c}
[screen](Containment *cont) {
        return cont->lastScreen() == screen //
            && (cont->containmentType() == Plasma::Types::DesktopContainment //
                || cont->containmentType() == Plasma::Types::CustomContainment);
    }
```

#### AUTO 


```{c}
const auto &f
```

#### AUTO 


```{c}
auto filter = [&parentApp](const KPluginMetaData &md) -> bool {
        const QString pa = md.value(QStringLiteral("X-KDE-ParentApp"));
        return (parentApp.isEmpty() || pa == parentApp) //
            && !md.value(QStringLiteral("X-Plasma-DropUrlPatterns"), QStringList()).isEmpty();
    };
```

#### AUTO 


```{c}
const auto &d
```

#### LAMBDA EXPRESSION 


```{c}
[](Plasma::Applet *a1, Plasma::Applet *a2) {
                        return a1->id() < a2->id();
                    }
```

#### AUTO 


```{c}
auto filter = [&type, &category, &parentApp](const KPluginMetaData &md) -> bool
    {
        if (!md.serviceTypes().contains(QStringLiteral("Plasma/Containment"))) {
            return false;
        }
        const QString pa = md.value(QStringLiteral("X-KDE-ParentApp"));
        if (!pa.isEmpty() && pa != parentApp) {
            return false;
        }

        if (!type.isEmpty() && md.value(QStringLiteral("X-Plasma-ContainmentType")) != type) {
            return false;
        }

        if (!category.isEmpty() && md.value(QStringLiteral("X-KDE-PluginInfo-Category")) != category) {
            return false;
        }

        return true;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[] (const QList<QSize> &list) {
        QString ret;
        for (const auto &s : list) {
            ret += QString::number(s.width()) % QLatin1Char('x') % QString::number(s.height()) % QLatin1Char(',');
        }
        return ret;
    }
```

#### AUTO 


```{c}
const auto &s
```

#### LAMBDA EXPRESSION 


```{c}
[=](QObject *obj) {
                    d->panelViews.remove(cont);
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this](int id) {
            if (id == applet()->containment()->screen()) {
                Q_EMIT screenGeometryChanged();
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &libraryPath : paths) {
        const QString path(libraryPath + QStringLiteral("/plasmacalendarplugins"));
        QDir dir(path);

        if (!dir.exists()) {
            continue;
        }

        const QStringList entryList = dir.entryList(QDir::Files | QDir::NoDotAndDotDot);

        for (const QString &fileName : entryList) {
            const QString absolutePath = dir.absoluteFilePath(fileName);
            if (m_availablePlugins.contains(absolutePath)) {
                continue;
            }

            QPluginLoader loader(absolutePath);
            // Load only our own plugins
            if (loader.metaData().value(QStringLiteral("IID")) == QLatin1String("org.kde.CalendarEventsPlugin")) {
                const auto md = loader.metaData().value(QStringLiteral("MetaData")).toObject();
                m_availablePlugins.insert(absolutePath,
                                          { md.value(QStringLiteral("Name")).toString(),
                                            md.value(QStringLiteral("Description")).toString(),
                                            md.value(QStringLiteral("Icon")).toString(),
                                            md.value(QStringLiteral("ConfigUi")).toString()
                                          });
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QFileInfo &file : cacheDir.entryInfoList()) {
                if (currentCacheFileName.isEmpty() ||
                        !file.absoluteFilePath().endsWith(currentCacheFileName)) {
                    QFile::remove(file.absoluteFilePath());
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (DataContainer *dc : lst) {
            out << "                * " << dc->objectName() << '\n';
            out << "                       Data count: " << dc->d->data.count() << '\n';
            out << "                       Stored: " << dc->isStorageEnabled() << " \n";
            const int directs = dc->receivers(SIGNAL(dataUpdated(QString, Plasma::DataEngine::Data)));
            if (directs > 0) {
                out << "                       Direction Connections: " << directs << " \n";
            }

            const int relays = dc->d->relays.count();
            if (relays > 0) {
                out << "                       Relays: " << dc->d->relays.count() << '\n';
                QString times;
                for (SignalRelay *relay : qAsConst(dc->d->relays)) {
                    times.append(QLatin1Char(' ') + QString::number(relay->m_interval));
                }
                out << "                       Relay Timeouts: " << times << " \n";
            }
        }
```

#### AUTO 


```{c}
auto ret = QQuickWindow::event(event);
```

#### LAMBDA EXPRESSION 


```{c}
[&parentApp](const KPluginMetaData &md) -> bool
    {
        const QString pa = md.value(QStringLiteral("X-KDE-ParentApp"));
        return (pa.isEmpty() || pa == parentApp) && !KPluginMetaData::readStringList(md.rawData(), QStringLiteral("X-Plasma-DropUrlPatterns")).isEmpty();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&mimeType](const KPluginMetaData &md) -> bool
    {
        return md.value(QStringLiteral("X-KDE-ServiceTypes")).contains(QLatin1String("Plasma/Containment"))
            && md.value(QStringLiteral("X-Plasma-DropMimeTypes")).contains(mimeType);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &plugin : qAsConst(plugins)) {
        m_availablePlugins.insert(plugin.fileName(),
                                  { plugin.name(),
                                    plugin.description(),
                                    plugin.iconName(),
                                    plugin.value(QStringLiteral("X-KDE-PlasmaCalendar-ConfigUi"))
                                  });
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QObject *child : children) {
        // find for the needed property of Layout: minimum/maximum/preferred sizes and fillWidth/fillHeight
        if (child->property("minimumWidth").isValid() && child->property("minimumHeight").isValid() && child->property("preferredWidth").isValid()
            && child->property("preferredHeight").isValid() && child->property("maximumWidth").isValid() && child->property("maximumHeight").isValid()
            && child->property("fillWidth").isValid() && child->property("fillHeight").isValid()) {
            layout = child;
            break;
        }
    }
```

#### AUTO 


```{c}
auto filter = [&parentApp, &excluded, visibleOnly](const KPluginMetaData &md) -> bool
    {
        const QString pa = md.value(QStringLiteral("X-KDE-ParentApp"));
        return (pa.isEmpty() || pa == parentApp)
            && (excluded.isEmpty() || excluded.contains(md.value(QStringLiteral("X-KDE-PluginInfo-Category"))))
            && (!visibleOnly || !md.isHidden());
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this, url]() {
                        // set wallpapery stuff
                        if (m_wallpaperInterface && url.isValid()) {
                            m_wallpaperInterface->setUrl(url);
                        }
                    }
```

#### AUTO 


```{c}
auto item = qobject_cast<QQuickItem *>(oldGraphicObject)
```

#### AUTO 


```{c}
auto &job = (*it);
```

#### RANGE FOR STATEMENT 


```{c}
for (Plasma::Containment *cont : qAsConst(containments)) {
        QCOMPARE(cont->immutability(), Plasma::Types::Mutable);
        const auto lstApplets = cont->applets();
        for (Plasma::Applet *app : lstApplets) {
            QCOMPARE(app->immutability(), Plasma::Types::Mutable);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](QQmlEngine *engine, QJSEngine *) -> QObject * {
        return new Plasma::QuickTheme(engine);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Plasma::Containment *cont : m_corona->containments()) {
        QCOMPARE(cont->immutability(), Plasma::Types::Mutable);
        for (Plasma::Applet *app : cont->applets()) {
            QCOMPARE(app->immutability(), Plasma::Types::Mutable);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&type, &category, &parentApp](const KPluginMetaData &md) -> bool
    {
        if (!md.serviceTypes().contains(QStringLiteral("Plasma/Containment"))) {
            return false;
        }
        if (!parentApp.isEmpty() && md.value(QStringLiteral("X-KDE-ParentApp")) != parentApp) {
            return false;
        }

        if (!type.isEmpty() && md.value(QStringLiteral("X-Plasma-ContainmentType")) != type) {
            return false;
        }

        if (!category.isEmpty() && md.value(QStringLiteral("X-KDE-PluginInfo-Category")) != category) {
            return false;
        }

        return true;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&category](const KPluginMetaData &md) -> bool {
        return md.value(QStringLiteral("X-KDE-PluginInfo-Category")) == category;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
            bool hasAlternatives = false;

            const QStringList provides = q->pluginMetaData().value(QStringLiteral("X-Plasma-Provides"), QStringList());
            if (!provides.isEmpty() && q->immutability() == Types::Mutable) {
                auto filter = [&provides](const KPluginMetaData &md) -> bool {
                    const QStringList provided = md.value(QStringLiteral("X-Plasma-Provides"), QStringList());
                    for (const QString &p : provides) {
                        if (provided.contains(p)) {
                            return true;
                        }
                    }
                    return false;
                };
                QList<KPluginMetaData> applets = KPackage::PackageLoader::self()->findPackages(QStringLiteral("Plasma/Applet"), QString(), filter);

                if (applets.count() > 1) {
                    hasAlternatives = true;
                }
            }
            a->setVisible(hasAlternatives);
        }
```

#### AUTO 


```{c}
auto filter = [&mimeType](const KPluginMetaData &md) -> bool {
        return md.serviceTypes().contains(QLatin1String("Plasma/Containment"))
            && KPluginMetaData::readStringList(md.rawData(), QStringLiteral("X-Plasma-DropMimeTypes")).contains(mimeType);
    };
```

#### AUTO 


```{c}
auto pi =  KPluginInfo(KService::serviceByStorageId(md.metaDataFileName()));
```

#### LAMBDA EXPRESSION 


```{c}
[] (QObject * left, QObject * right)
            {
                auto willing = [] (QObject * handler)
                {
                    return handler->property("willing").toBool();
                };

                auto priority = [] (QObject * handler)
                {
                    return handler->property("priority").toInt();
                };

                return
                    // If one is willing and the other is not,
                    // return it - it has the priority
                    willing(left) && !willing(right) ? true :
                    !willing(left) && willing(right) ? false :
                    // otherwise just compare the priorities
                    priority(left) < priority(right);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        if (m_toolTipMainText.isNull()) {
            Q_EMIT toolTipMainTextChanged();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](Plasma::Applet *a) {
        if (Plasma::Applet *p = qobject_cast<Plasma::Applet *>(parent())) {
            Q_EMIT p->containment()->configureRequested(a);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](bool expanded) {
        // if both compactRepresentationItem and fullRepresentationItem exist,
        // the applet is in a popup
        if (expanded) {
            /* clang-format off */
            if (compactRepresentationItem()
                && fullRepresentationItem()
                && fullRepresentationItem()->window()
                && compactRepresentationItem()->window()
                && fullRepresentationItem()->window() != compactRepresentationItem()->window()
                && fullRepresentationItem()->parentItem()) {
                /* clang-format on */
                fullRepresentationItem()->parentItem()->installEventFilter(this);
            } else if (fullRepresentationItem() && fullRepresentationItem()->parentItem()) {
                fullRepresentationItem()->parentItem()->removeEventFilter(this);
            }
        }
    }
```

#### AUTO 


```{c}
auto it = d->pluginCache.constFind(pluginName);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &key : imageGroup.keyList()) {
        bool ok = false;
        if (ok) {
            const QRectF rect = imageGroup.readEntry(key, QRectF());
            m_localRectCache.insert(key.toUInt(), rect);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        scheduleThemeChangeNotification(PixmapCache | SvgElementsCache);
    }
```

#### AUTO 


```{c}
auto it = discoveries.constFind(image);
```

#### CONST EXPRESSION 


```{c}
constexpr int defaultLongDuration = 200;
```

#### LAMBDA EXPRESSION 


```{c}
[&provides](const KPluginMetaData &md) -> bool
                {
                    const QStringList provided = KPluginMetaData::readStringList(md.rawData(), QStringLiteral("X-Plasma-Provides"));
                    for (const QString &p : provides) {
                        if (provided.contains(p)) {
                            return true;
                        }
                    }
                    return false;
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this, packagePath, structure](KJob *job) {
                        auto fail = [](const QString &text) {
                            KNotification::event(QStringLiteral("plasmoidInstallationFailed"), i18n("Package Installation Failed"),
                                                 text, QStringLiteral("dialog-error"), nullptr, KNotification::CloseOnTimeout, QStringLiteral("plasma_workspace"));
                        };

                        // if the applet is already installed, just add it to the containment
                        if (job->error() != KJob::NoError
                            && job->error() != Package::PackageAlreadyInstalledError
                            && job->error() != Package::NewerVersionAlreadyInstalledError) {
                            fail(job->errorText());
                            return;
                        }

                        using namespace KPackage;
                        Package package(structure);
                        // TODO how can I get the path of the actual package?

                        package.setPath(packagePath);

                        // TODO how can I get the plugin id? Package::metadata() is deprecated
                        if (!package.isValid() || !package.metadata().isValid()) {
                            fail(i18n("The package you just dropped is invalid."));
                            return;
                        }

                        createApplet(package.metadata().pluginId(), QVariantList(), QRect(m_dropMenu->dropPoint(), QSize(-1,-1)));
                    }
```

#### LAMBDA EXPRESSION 


```{c}
[activity](Containment *cont) { return cont->activity() == activity && 
                     (cont->containmentType() == Plasma::Types::DesktopContainment ||
                      cont->containmentType() == Plasma::Types::CustomContainment);}
```

#### RANGE FOR STATEMENT 


```{c}
for (Plasma::Containment *c : lst) {
        ContainmentInterface *contInterface = c->property("_plasma_graphicObject").value<ContainmentInterface *>();

        if (contInterface && contInterface->isVisible()) {
            QWindow *w = contInterface->window();
            if (w && w->geometry().contains(QPoint(window()->x(), window()->y()) + QPoint(x, y))) {
                if (c->containmentType() == Plasma::Types::CustomEmbeddedContainment) {
                    continue;
                }
                if (c->containmentType() == Plasma::Types::DesktopContainment) {
                    desktop = contInterface;
                } else {
                    return contInterface;
                }
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&name](const KPluginMetaData &md) -> bool
    {
        return md.pluginId() == name;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Containment *c : std::as_const(containments)) {
        // we need to tell each containment that immutability has been altered
        c->updateConstraints(Types::ImmutableConstraint);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        fullRepresentationResizeTimer.start();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Plasma::Applet *app : cont->applets()) {
            QCOMPARE(app->immutability(), Plasma::Types::Mutable);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &kcm) {
        return !KAuthorized::authorizeControlModule(kcm + QLatin1String(".desktop"));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &plugin : plugins) {
        if (!filter(plugin))
            continue;
        const QStringList componentTypes = KPluginMetaData::readStringList(plugins.first().rawData(), QStringLiteral("X-Plasma-ComponentTypes"));
        if (((types & Types::AppletComponent)     && componentTypes.contains(QStringLiteral("Applet")))
          ||((types & Types::DataEngineComponent) && componentTypes.contains(QStringLiteral("DataEngine")))) {
            ret << plugin;
        }
    }
```

#### AUTO 


```{c}
auto it = references.constBegin(), end = references.constEnd();
```

#### AUTO 


```{c}
auto listActions = m_containment->actions()->actions();
```

#### AUTO 


```{c}
auto ownFilter = [filter](const KPluginMetaData &md) -> bool {
        return isContainmentMetaData(md) && filter(md);
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const QDate date : qAsConst(updatesList)) {
        const QModelIndex changedIndex = indexForDate(date);
        if (changedIndex.isValid()) {
            Q_EMIT dataChanged(changedIndex, changedIndex, {containsEventItems, containsMajorEventItems, containsMinorEventItems});
        }
        Q_EMIT agendaUpdated(date);
    }
```

#### AUTO 


```{c}
auto action = m_containment->corona()->actions()->action(QStringLiteral("edit mode"));
```

#### LAMBDA EXPRESSION 


```{c}
[ = ]() {
        loadPixmap();
    }
```

#### AUTO 


```{c}
auto scopeChange = [this] () {
        findParentScope();
        checkColorGroupChanged();
    };
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &text) {
                            KNotification::event(QStringLiteral("plasmoidInstallationFailed"),
                                                 i18n("Package Installation Failed"),
                                                 text,
                                                 QStringLiteral("dialog-error"),
                                                 nullptr,
                                                 KNotification::CloseOnTimeout,
                                                 QStringLiteral("plasma_workspace"));
                        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, mimetype, url]() {
                    Plasma::Applet *applet = createApplet(QStringLiteral("org.kde.plasma.icon"), QVariantList(), QRect(m_dropMenu->dropPoint(), QSize(-1, -1)));
                    setAppletArgs(applet, mimetype, url.toString());
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this, packagePath, structure, posi](KJob *job) {
                        auto fail = [job](const QString &text) {
                            KNotification::event(QStringLiteral("plasmoidInstallationFailed"), i18n("Package Installation Failed"),
                                                 text, QStringLiteral("dialog-error"), 0, KNotification::CloseOnTimeout, QStringLiteral("plasma_workspace"));
                        };

                        // if the applet is already installed, just add it to the containment
                        if (job->error() != KJob::NoError
                            && job->error() != Package::PackageAlreadyInstalledError
                            && job->error() != Package::NewerVersionAlreadyInstalledError) {
                            fail(job->errorText());
                            return;
                        }

                        using namespace KPackage;
                        Package package(structure);
                        // TODO how can I get the path of the actual package?
                        package.setPath(packagePath);

                        // TODO how can I get the plugin id? Package::metadata() is deprecated
                        if (!package.isValid() || !package.metadata().isValid()) {
                            fail(i18n("The package you just dropped is invalid."));
                            return;
                        }

                        createApplet(package.metadata().pluginId(), QVariantList(), posi);
                    }
```

#### AUTO 


```{c}
auto filter = [&provides](const KPluginMetaData &md) -> bool {
                    const QStringList provided = md.value(QStringLiteral("X-Plasma-Provides"), QStringList());
                    for (const QString &p : provides) {
                        if (provided.contains(p)) {
                            return true;
                        }
                    }
                    return false;
                };
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
                    q->setStatus(Types::PassiveStatus);
                }
```

#### LAMBDA EXPRESSION 


```{c}
[=](QQmlEngine*, QJSEngine*) -> QObject* { return &Units::instance(); }
```

#### AUTO 


```{c}
const auto lst = cacheAndColorsTheme()->listCachedRectKeys(path);
```

#### RANGE FOR STATEMENT 


```{c}
for (QObject *child : lstChildren) {
        //find for the needed property of Layout: minimum/maximum/preferred sizes and fillWidth/fillHeight
        if (child->property("minimumWidth").isValid() && child->property("minimumHeight").isValid() &&
                child->property("preferredWidth").isValid() && child->property("preferredHeight").isValid() &&
                child->property("maximumWidth").isValid() && child->property("maximumHeight").isValid() &&
                child->property("fillWidth").isValid() && child->property("fillHeight").isValid()
           ) {
            layout = child;
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &e : allEngines) {
        Plasma::DataEngine *engine = Plasma::PluginLoader::self()->loadDataEngine(e);
        if (engine) {
            engine->connectSource(QStringLiteral("Europe/Amsterdam"), this);
            engine->connectSource(QStringLiteral("Battery"), this);
            engine->connectAllSources(this);
            qDebug() << "SOURCE: " << engine->sources();
            ok = true;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, packagePath]() {
                    using namespace KPackage;
                    PackageStructure *structure = PackageLoader::self()->loadPackageStructure(QStringLiteral("Plasma/Applet"));
                    Package package(structure);

                    KJob *installJob = package.update(packagePath);
                    connect(installJob, &KJob::result, this, [this, packagePath, structure](KJob *job) {
                        auto fail = [](const QString &text) {
                            KNotification::event(QStringLiteral("plasmoidInstallationFailed"),
                                                 i18n("Package Installation Failed"),
                                                 text,
                                                 QStringLiteral("dialog-error"),
                                                 nullptr,
                                                 KNotification::CloseOnTimeout,
                                                 QStringLiteral("plasma_workspace"));
                        };

                        // if the applet is already installed, just add it to the containment
                        if (job->error() != KJob::NoError && job->error() != Package::PackageAlreadyInstalledError
                            && job->error() != Package::NewerVersionAlreadyInstalledError) {
                            fail(job->errorText());
                            return;
                        }

                        using namespace KPackage;
                        Package package(structure);
                        // TODO how can I get the path of the actual package?

                        package.setPath(packagePath);

                        // TODO how can I get the plugin id? Package::metadata() is deprecated
                        if (!package.isValid() || !package.metadata().isValid()) {
                            fail(i18n("The package you just dropped is invalid."));
                            return;
                        }

                        createApplet(package.metadata().pluginId(), QVariantList(), QRect(m_dropMenu->dropPoint(), QSize(-1, -1)));
                    });
                }
```

#### AUTO 


```{c}
auto i = rNames.constBegin();
```

#### AUTO 


```{c}
auto plugins = d->plasmoidCache.findPluginsById(name, {PluginLoaderPrivate::s_plasmoidsPluginDir, {}});
```

#### RANGE FOR STATEMENT 


```{c}
for (auto a : containmentHash) {
            a->destroy();
        }
```

#### AUTO 


```{c}
auto pi = md.metaDataFileName().endsWith(QLatin1String(".json")) ? KPluginInfo(md) : KPluginInfo(KService::serviceByStorageId(md.metaDataFileName()));
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
            bool hasAlternatives = false;

            const QStringList provides = KPluginMetaData::readStringList(q->pluginMetaData().rawData(), QStringLiteral("X-Plasma-Provides"));
            if (!provides.isEmpty() && q->immutability() == Types::Mutable) {
                auto filter = [&provides](const KPluginMetaData &md) -> bool
                {
                    const QStringList provided = KPluginMetaData::readStringList(md.rawData(), QStringLiteral("X-Plasma-Provides"));
                    for (const QString &p : provides) {
                        if (provided.contains(p)) {
                            return true;
                        }
                    }
                    return false;
                };
                QList<KPluginMetaData> applets = KPackage::PackageLoader::self()->findPackages(QStringLiteral("Plasma/Applet"), QString(), filter);

                if (applets.count() > 1) {
                    hasAlternatives = true;
                }
            }
            a->setVisible(hasAlternatives);
        }
```

#### AUTO 


```{c}
auto metadata = first.toMap().value(QStringLiteral("MetaData")).toMap();
```

#### LAMBDA EXPRESSION 


```{c}
[filter](const KPluginMetaData &md) -> bool {
        return isContainmentMetaData(md) && filter(md);
    }
```

#### AUTO 


```{c}
auto filter = [&mimeType](const KPluginMetaData &md) -> bool
    {
        return md.value(QStringLiteral("X-KDE-ServiceTypes")).contains(QLatin1String("Plasma/Containment"))
            && md.value(QStringLiteral("X-Plasma-DropMimeTypes")).contains(mimeType);
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &fileName : entryList) {
            const QString absolutePath = dir.absoluteFilePath(fileName);
            if (m_availablePlugins.contains(absolutePath)) {
                continue;
            }

            QPluginLoader loader(absolutePath);
            // Load only our own plugins
            if (loader.metaData().value(QStringLiteral("IID")) == QLatin1String("org.kde.CalendarEventsPlugin")) {
                const auto md = loader.metaData().value(QStringLiteral("MetaData")).toObject();
                m_availablePlugins.insert(absolutePath,
                                          { md.value(QStringLiteral("Name")).toString(),
                                            md.value(QStringLiteral("Description")).toString(),
                                            md.value(QStringLiteral("Icon")).toString(),
                                            md.value(QStringLiteral("ConfigUi")).toString()
                                          });
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Plasma::DataEngine *engine : std::as_const(engines)) {
            delete engine;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &source : qAsConst(m_connectedSources)) {
        m_dataEngine->connectSource(source, this, m_interval, m_intervalAlignment);
        emit sourceConnected(source);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&provides](const KPluginMetaData &md) -> bool
                {
                    const QStringList provided = KPluginMetaData::readStringList(md.rawData(), QStringLiteral("X-Plasma-Provides"));
                    foreach (const QString &p, provides) {
                        if (provided.contains(p)) {
                            return true;
                        }
                    }
                    return false;
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &data : directories) {
        dirs << data.constData();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool uiReady) {
                if (uiReady && d->s_preloadPolicy >= AppletQuickItemPrivate::Adaptive) {
                    const int preloadWeight = d->preloadWeight();
                    qCInfo(LOG_PLASMAQUICK) << "New Applet " << d->applet->title() << "with a weight of" << preloadWeight;

                    //don't preload applets less then a certain weigth
                    if (d->s_preloadPolicy >= AppletQuickItemPrivate::Aggressive || preloadWeight >= AppletQuickItemPrivate::DelayedPreloadWeight) {
                        //spread the creation over a random delay to make it look
                        //plasma started already, and load the popup in the background
                        //without big noticeable freezes, the bigger the weight the smaller is likely
                        //to be the delay, smaller minimum walue, smaller spread
                        const int min = (100 - preloadWeight) * 20;
                        const int max = (100 - preloadWeight) * 100;
                        const int delay = qrand() % ((max + 1) - min) + min;
                        QTimer::singleShot(delay, this, [this, delay]() {
                            qCInfo(LOG_PLASMAQUICK) << "Delayed preload of " << d->applet->title() << "after" << (qreal)delay/1000 << "seconds";
                            d->preloadForExpansion();
                        });
                    }
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const CalendarEvents::EventData &event : qAsConst(events)) {
        m_qmlData << new EventDataDecorator(event, this);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[category, parentApp](const KPluginMetaData &md) -> bool
        {
            const QString pa = md.value(QStringLiteral("X-KDE-ParentApp"));
            if (category == QLatin1String("Miscellaneous")) {
                return (parentApp.isEmpty() || pa == parentApp) && (md.category() == category || md.category().isEmpty());
            } else {
                return (parentApp.isEmpty() || pa == parentApp) && md.category() == category;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(Plasma::Containment *containment : cs) {
        insertContainment(activity->name(), containment->lastScreen(), containment);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *a : qAsConst(listActions)) {
        if (!actionOrder.contains(a->objectName())) {
            // FIXME QML visualizations don't support menus for now, *and* there is no way to
            // distinguish them on QML side
            if (!a->menu()) {
                actions.insert(a->data().toInt() * 100 + i, a);
                ++i;
            }
        } else {
            orderedActions[a->objectName()] = a;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&parentApp](const KPluginMetaData &md) -> bool {
        const QString pa = md.value(QStringLiteral("X-KDE-ParentApp"));
        return (parentApp.isEmpty() || pa == parentApp) //
            && !md.value(QStringLiteral("X-Plasma-DropUrlPatterns"), QStringList()).isEmpty();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto info : offers) {
            //const QString proot = "";
            //Plasma::PackageStructure* structure = Plasma::PackageStructure::load(info.pluginName());
            QString name = info.name();
            QString comment = info.comment();
            QString plugin = info.pluginName();
            //QString path = structure->defaultPackageRoot();
            //QString path = defaultPackageRoot;
            plugins.insert(name, QStringList() << name << plugin << comment);
            //qDebug() << "KService stuff:" << name << plugin << comment;
        }
```

#### AUTO 


```{c}
const auto lstFiles = d->internalPackage->requiredFiles();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &prefix : std::as_const(m_prefixes)) {
        if (m_frameSvg->hasElementPrefix(prefix)) {
            m_frameSvg->setElementPrefix(prefix);
            found = true;
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &plugin : plugins) {
        if (!filter(plugin))
            continue;
        const QStringList componentTypes = KPluginMetaData::readStringList(plugins.first().rawData(), QStringLiteral("X-Plasma-ComponentTypes"));
        if (((types & Types::AppletComponent) && componentTypes.contains(QLatin1String("Applet")))
            || ((types & Types::DataEngineComponent) && componentTypes.contains(QLatin1String("DataEngine")))) {
            ret << plugin;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &info : qAsConst(appletList)) {
                const QString actionText = i18nc("Add widget", "Add %1", info.name());
                QAction *action = new QAction(actionText, m_dropMenu);
                if (!info.iconName().isEmpty()) {
                    action->setIcon(QIcon::fromTheme(info.iconName()));
                }
                m_dropMenu->addAction(action);
                action->setData(info.pluginId());
                const QUrl url = tjob->url();
                connect(action, &QAction::triggered, this, [this, action, mimetype, url]() {
                    Plasma::Applet *applet = createApplet(action->data().toString(), QVariantList(), QRect(m_dropMenu->dropPoint(), QSize(-1,-1)));
                    setAppletArgs(applet, mimetype, url.toString());
                });
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &key : imageGroup.keyList()) {
            bool ok = false;
            uint keyUInt = key.toUInt(&ok);
            if (ok) {
                const QRectF rect = imageGroup.readEntry(key, QRectF());
                m_localRectCache.insert(keyUInt, rect);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &plugin : std::as_const(plugins)) {
        m_availablePlugins.insert(plugin.fileName(),
                                  {plugin.name(), plugin.description(), plugin.iconName(), plugin.value(QStringLiteral("X-KDE-PlasmaCalendar-ConfigUi"))});
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Containment *containment : containments) {
        if (containment->screen() == screen && freeEdges.contains(containment->location())) {
            freeEdges.removeAll(containment->location());
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
                    transient = true;
                    if (deleteNotification) {
                        deleteNotification->close();
                    } else {
                        emit q->destroyedChanged(true);
                        cleanUpAndDelete();
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &theme : std::as_const(fallbackThemes)) {
            KSharedConfigPtr metadata = configForTheme(theme);
            processWallpaperSettings(metadata);
        }
```

#### AUTO 


```{c}
auto ungrabMouseHack = [this]() {
            QQuickItem *parentItem = this->parentItem();
            if (parentItem && parentItem->window() && parentItem->window()->mouseGrabberItem()) {
                parentItem->window()->mouseGrabberItem()->ungrabMouse();
            }
        };
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &appletName : appletNames) {
            qDebug() << "adding" << appletName;

            metaObject()->invokeMethod(this,
                                       "createApplet",
                                       Qt::QueuedConnection,
                                       Q_ARG(QString, appletName),
                                       Q_ARG(QVariantList, QVariantList()),
                                       Q_ARG(QRectF, QRectF(x, y, -1, -1)));
        }
```

#### AUTO 


```{c}
auto handler = handlerComponent.create();
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        m_status = DialogStatus::Closed;
        emit statusChanged();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &kcm) {
                                  return !KAuthorized::authorizeControlModule(kcm + QLatin1String(".desktop"));
                              }
```

#### AUTO 


```{c}
auto margin = frameSvgItem->fixedMargins();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Applet *applet : qAsConst(d->applets)) {
        KConfigGroup appletConfig(&applets, QString::number(applet->id()));
        applet->save(appletConfig);
    }
```

#### AUTO 


```{c}
auto filter = [&parentApp](const KPluginMetaData &md) -> bool {
        const QString pa = md.value(QStringLiteral("X-KDE-ParentApp"));
        return (parentApp.isEmpty() || pa == parentApp) //
            && !KPluginMetaData::readStringList(md.rawData(), QStringLiteral("X-Plasma-DropUrlPatterns")).isEmpty();
    };
```

#### AUTO 


```{c}
auto it = references.find(svg);
```

#### RANGE FOR STATEMENT 


```{c}
for (Containment *cont : qAsConst(d->containments)) {
        /* clang-format off */
        if (cont->lastScreen() == screen
            && (cont->activity().isEmpty() || cont->activity() == activity)
            && (cont->containmentType() == Plasma::Types::DesktopContainment
                || cont->containmentType() == Plasma::Types::CustomContainment)) { /* clang-format on */
            containment = cont;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](QQmlEngine *engine, QJSEngine*) -> QObject* {
        engine->setObjectOwnership(&Units::instance(), QQmlEngine::CppOwnership);
        return &Units::instance();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, mimetype, url](){
                    Plasma::Applet *applet = createApplet(QStringLiteral("org.kde.plasma.icon"), QVariantList(), QRect(m_dropMenu->dropPoint(), QSize(-1,-1)));
                    setAppletArgs(applet, mimetype, url.toString());
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &wp : qAsConst(d->structures)) {
        delete wp;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &source : qAsConst(m_connectedSources)) {
        if (!sources.contains(source)) {
            m_data->clear(source);
            sourcesChanged = true;
            if (m_dataEngine) {
                m_dataEngine->disconnectSource(source, this);
                Q_EMIT sourceDisconnected(source);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Plasma::Containment *cont : std::as_const(containments)) {
        QCOMPARE(cont->immutability(), Plasma::Types::UserImmutable);
        const auto lstApplets = cont->applets();
        for (Plasma::Applet *app : lstApplets) {
            QCOMPARE(app->immutability(), Plasma::Types::UserImmutable);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        if (!isVisible()) {
            stopRedirecting();
            releaseResources();
        } else if (isEnabled()) {
            startRedirecting();
            update();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QQuickWindow * window) {
        if (!window) {
            return;
        }
        // restart the redirection, it might not have been active yet
        stopRedirecting();
        startRedirecting();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=] (QObject *o) {
        d->loadingDesktops.remove(static_cast<Plasma::Containment *>(o));
    }
```

#### AUTO 


```{c}
const auto &info
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &kcm : qAsConst(kcms)) {
            // Only look for KCMs in the "kcms_" folder where new QML KCMs live
            // because we don't support loading QWidgets KCMs
            KPluginLoader loader(KPluginLoader::findPlugin(QLatin1String("kcms/") + kcm));
            KPluginMetaData md(loader.fileName());

            if (!md.isValid()) {
                qWarning() << "Could not find" << kcm
                           << "requested by X-Plasma-ConfigPlugins. Ensure that it exists, is a QML KCM, and lives in the 'kcms/' subdirectory.";
                continue;
            }

            configModel->appendCategory(md.iconName(), md.name(), QString(), loader.fileName());
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&parentApp, &excluded, visibleOnly](const KPluginMetaData &md) -> bool
    {
        const QString pa = md.value(QStringLiteral("X-KDE-ParentApp"));
        return (parentApp.isEmpty() || pa == parentApp)
            && (excluded.isEmpty() || excluded.contains(md.value(QStringLiteral("X-KDE-PluginInfo-Category"))))
            && (!visibleOnly || !md.isHidden());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
                    if (deleteNotification) {
                        deleteNotification->close();
                    }
                    transient = true;
                    emit q->destroyedChanged(true);
                    cleanUpAndDelete();
                }
```

#### AUTO 


```{c}
auto filter = [&name](const KPluginMetaData &md) -> bool
    {
        return md.pluginId() == name;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this, name] {
            executeAction(name);
        }
```

#### AUTO 


```{c}
const auto &i = m_lastModifiedTimes.constFind(filePath);
```

#### LAMBDA EXPRESSION 


```{c}
[&type, &category, &parentApp](const KPluginMetaData &md) -> bool {
        if (!md.serviceTypes().contains(QLatin1String("Plasma/Containment"))) {
            return false;
        }
        if (!parentApp.isEmpty() && md.value(QStringLiteral("X-KDE-ParentApp")) != parentApp) {
            return false;
        }

        if (!type.isEmpty() && md.value(QStringLiteral("X-Plasma-ContainmentType")) != type) {
            return false;
        }

        if (!category.isEmpty() && md.value(QStringLiteral("X-KDE-PluginInfo-Category")) != category) {
            return false;
        }

        return true;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[ = ]() {
        setExpanded(true);
        if (QQuickItem *i = qobject_cast<QQuickItem *>(fullRepresentationItem())) {
            i->setFocus(true, Qt::ShortcutFocusReason);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool uiReady) {
                if (uiReady && d->s_preloadPolicy >= AppletQuickItemPrivate::Adaptive) {
                    const int preloadWeight = d->preloadWeight();
                    qCDebug(LOG_PLASMAQUICK) << "New Applet " << d->applet->title() << "with a weight of" << preloadWeight;

                    //don't preload applets less then a certain weight
                    if (d->s_preloadPolicy >= AppletQuickItemPrivate::Aggressive || preloadWeight >= AppletQuickItemPrivate::DelayedPreloadWeight) {
                        //spread the creation over a random delay to make it look
                        //plasma started already, and load the popup in the background
                        //without big noticeable freezes, the bigger the weight the smaller is likely
                        //to be the delay, smaller minimum walue, smaller spread
                        const int min = (100 - preloadWeight) * 20;
                        const int max = (100 - preloadWeight) * 100;
                        const int delay = QRandomGenerator::global()->bounded((max + 1) - min) + min;
                        QTimer::singleShot(delay, this, [this, delay]() {
                            qCDebug(LOG_PLASMAQUICK) << "Delayed preload of " << d->applet->title() << "after" << (qreal)delay/1000 << "seconds";
                            d->preloadForExpansion();
                        });
                    }
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &source : qAsConst(m_connectedSources)) {
        if (!sources.contains(source)) {
            m_data->clear(source);
            sourcesChanged = true;
            if (m_dataEngine) {
                m_dataEngine->disconnectSource(source, this);
                emit sourceDisconnected(source);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Applet *applet : std::as_const(d->applets)) {
        applet->updateConstraints(Plasma::Types::LocationConstraint);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](){m_syncTimer->start();}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &theme : qAsConst(fallbackThemes)) {
            QString metadataPath(
                QStandardPaths::locate(QStandardPaths::GenericDataLocation,
                                       QStringLiteral(PLASMA_RELATIVE_DATA_INSTALL_DIR "/desktoptheme/") % theme % QStringLiteral("/metadata.desktop")));
            KConfig metadata(metadataPath, KConfig::SimpleConfig);
            processWallpaperSettings(&metadata);
        }
```

#### AUTO 


```{c}
const auto keyList =  cfg.keyList();
```

#### AUTO 


```{c}
const auto call = QDBusMessage::createMethodCall(QStringLiteral("org.kde.kded5"),
                                                     QStringLiteral("/kbuildsycoca"),
                                                     QStringLiteral("org.kde.kbuildsycoca"),
                                                     QStringLiteral("recreate"));
```

#### AUTO 


```{c}
auto priority = [] (QObject * handler)
                {
                    return handler->property("priority").toInt();
                };
```

#### LAMBDA EXPRESSION 


```{c}
[=]{resize(screen()->geometry().width(), screen()->geometry().height());}
```

#### AUTO 


```{c}
const auto dirList = dir.entryList(QDir::Dirs | QDir::NoDotAndDotDot);
```

#### RANGE FOR STATEMENT 


```{c}
for (QObject *child : lstChild) {
                // find for the needed property of Layout: minimum/maximum/preferred sizes and fillWidth/fillHeight
                if (child->property("minimumWidth").isValid() && child->property("minimumHeight").isValid() && child->property("preferredWidth").isValid()
                    && child->property("preferredHeight").isValid() && child->property("maximumWidth").isValid() && child->property("maximumHeight").isValid()
                    && child->property("fillWidth").isValid() && child->property("fillHeight").isValid()) {
                    layout = child;
                    break;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (Applet *applet : std::as_const(applets)) {
            applet->updateConstraints(appletConstraints);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &md : plugins) {
        auto pi = md.metaDataFileName().endsWith(QLatin1String(".json")) ? KPluginInfo(md) : KPluginInfo(KService::serviceByStorageId(md.metaDataFileName()));
        if (!pi.isValid()) {
            qCWarning(LOG_PLASMA) << "Could not load plugin info for plugin :" << md.pluginId() << "skipping plugin";
            continue;
        }
        list << pi;
    }
```

#### AUTO 


```{c}
auto fail = [](const QString &text) {
                            KNotification::event(QStringLiteral("plasmoidInstallationFailed"), i18n("Package Installation Failed"),
                                                 text, QStringLiteral("dialog-error"), nullptr, KNotification::CloseOnTimeout, QStringLiteral("plasma_workspace"));
                        };
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
            if (m_action->parent() != this) {
                m_action = new QAction(this);
                m_action->setVisible(false);
                Q_EMIT actionChanged();
            }
        }
```

#### AUTO 


```{c}
auto containments = m_corona->containments();
```

#### CONST EXPRESSION 


```{c}
constexpr int maxEventDisplayed = 5;
```

#### RANGE FOR STATEMENT 


```{c}
for (Applet *applet : Containment::applets()) {
        if (!applet->pluginInfo().isValid()) {
            applet->updateConstraints(Plasma::Types::UiReadyConstraint);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &prefix : qAsConst(m_prefixes)) {
        if (m_frameSvg->hasElementPrefix(prefix)) {
            m_frameSvg->setElementPrefix(prefix);
            found = true;
            break;
        }
    }
```

#### AUTO 


```{c}
auto data = QFINDTESTDATA("../src/desktoptheme/" + theme + "/metadata.json");
```

#### LAMBDA EXPRESSION 


```{c}
[=](QQmlEngine* engine, QJSEngine*) -> QObject* { return new Plasma::QuickTheme(engine); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &plugin : packagePlugins) {
        engines << plugin.pluginId();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &info : std::as_const(appletList)) {
                const QString actionText = i18nc("Add widget", "Add %1", info.name());
                QAction *action = new QAction(actionText, m_dropMenu);
                if (!info.iconName().isEmpty()) {
                    action->setIcon(QIcon::fromTheme(info.iconName()));
                }
                m_dropMenu->addAction(action);
                action->setData(info.pluginId());
                const QUrl url = tjob->url();
                connect(action, &QAction::triggered, this, [this, action, mimetype, url]() {
                    Plasma::Applet *applet = createApplet(action->data().toString(), QVariantList(), QRect(m_dropMenu->dropPoint(), QSize(-1, -1)));
                    setAppletArgs(applet, mimetype, url.toString());
                });
            }
```

#### LAMBDA EXPRESSION 


```{c}
[&parentApp, &excluded, visibleOnly](const KPluginMetaData &md) -> bool
    {
        const QString pa = md.value("X-KDE-ParentApp");
        return (pa.isEmpty() || pa == parentApp) && (excluded.isEmpty() || excluded.contains(md.value("X-KDE-PluginInfo-Category"))) && (!visibleOnly || !md.isHidden());
    }
```

#### AUTO 


```{c}
auto filter = [&language](const KPluginMetaData &md) -> bool
    {
        return md.value(QStringLiteral("X-Plasma-API")) == language;
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (auto md : KPackage::PackageLoader::self()->findPackages("Plasma/Applet", QString(), filter)) {
            auto pi = KPluginInfo(KService::serviceByStorageId(md.metaDataFileName()));
            if (!pi.isValid()) {
                qWarning() << "Could not load plugin info for plugin :" << md.pluginId() << "skipping plugin";
                continue;
            }
            list << pi;
        }
```

#### AUTO 


```{c}
const auto upper_left_x = m_panel->x();
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *a : qAsConst(listActions)) {
        if (a->objectName() == QLatin1String("lock widgets") || a->menu()) {
            //It is up to the Containment to decide if the user is allowed or not
            //to lock/unluck the widgets, so corona should not add one when there is none
            //(user is not allow) and it shouldn't add another one when there is already
            //one
            continue;
        }

        if (!actionOrder.contains(a->objectName())) {
            actions.insert(a->data().toInt()*100 + i, a);
        } else {
            orderedActions[a->objectName()] = a;
        }
        ++i;
    }
```

#### AUTO 


```{c}
const auto containments = this->containments();
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &metadata : metaDataList) {
                plugins.insert(metadata.pluginId(), metadata);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[ = ]() {
        m_status = DialogStatus::Closed;
        emit statusChanged();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[activity](Containment *cont) {
        return cont->activity() == activity //
            && (cont->containmentType() == Plasma::Types::DesktopContainment //
                || cont->containmentType() == Plasma::Types::CustomContainment);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](const QString &msg) {
                qDebug() << msg;
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool uiReady) {
                if (uiReady && d->s_preloadPolicy >= AppletQuickItemPrivate::Adaptive) {
                    const int preloadWeight = d->preloadWeight();
                    qCInfo(LOG_PLASMAQUICK) << "New Applet " << d->applet->title() << "with a weight of" << preloadWeight;

                    //don't preload applets less then a certain weight
                    if (d->s_preloadPolicy >= AppletQuickItemPrivate::Aggressive || preloadWeight >= AppletQuickItemPrivate::DelayedPreloadWeight) {
                        //spread the creation over a random delay to make it look
                        //plasma started already, and load the popup in the background
                        //without big noticeable freezes, the bigger the weight the smaller is likely
                        //to be the delay, smaller minimum walue, smaller spread
                        const int min = (100 - preloadWeight) * 20;
                        const int max = (100 - preloadWeight) * 100;
                        const int delay = qrand() % ((max + 1) - min) + min;
                        QTimer::singleShot(delay, this, [this, delay]() {
                            qCInfo(LOG_PLASMAQUICK) << "Delayed preload of " << d->applet->title() << "after" << (qreal)delay/1000 << "seconds";
                            d->preloadForExpansion();
                        });
                    }
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[&parentApp, &excluded, visibleOnly](const KPluginMetaData &md) -> bool {
        const QString pa = md.value(QStringLiteral("X-KDE-ParentApp"));
        return (parentApp.isEmpty() || pa == parentApp) //
            && (excluded.isEmpty() || excluded.contains(md.value(QStringLiteral("X-KDE-PluginInfo-Category")))) //
            && (!visibleOnly || !md.isHidden());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[excluded, parentApp](const KPluginMetaData &md) -> bool
        {
            const QString pa = md.value(QStringLiteral("X-KDE-ParentApp"));
            return (parentApp.isEmpty() || pa == parentApp) && !excluded.contains(md.category());
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=](QObject *obj) {
        auto containment = qobject_cast<Plasma::Containment*>(obj);
        d->desktopContainments[containment->activity()].remove(containment->lastScreen());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &type : theseTypes) {
            types.insert(type);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[configDlg, pluginInstance] () {
                pluginInstance->configurationAccepted();
                configDlg->deleteLater();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &pluginPath : qAsConst(pluginsList)) {
        loadPlugin(pluginPath);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QQmlError error : errors) {
                reason += error.toString() + QLatin1Char('\n');
            }
```

#### AUTO 


```{c}
const auto lst = m_containment->corona()->containments();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &plugin : plugins) {
        if (!filter(plugin))
            continue;
        const QStringList componentTypes = KPluginMetaData::readStringList(plugins.first().rawData(), QStringLiteral("X-Plasma-ComponentTypes"));
        if (((types & Types::AppletComponent)     && componentTypes.contains(QLatin1String("Applet")))
          ||((types & Types::DataEngineComponent) && componentTypes.contains(QLatin1String("DataEngine")))) {
            ret << plugin;
        }
    }
```

#### AUTO 


```{c}
const auto &plat
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : listActions) {
        if (action) {
            desktopMenu->addAction(action);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Applet *a : lstApplets)
            a->d->setDestroyed(destroyed);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &name : std::as_const(m_actions)) {
        QAction *action = a->actions()->action(name);

        if (action) {
            actions << action;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const CalendarEvents::EventData &a, const CalendarEvents::EventData &b) {
        return b.type() > a.type() || b.startDateTime() > a.startDateTime();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const KPluginMetaData &md) -> bool
    {
        return md.value("X-Plasma-API") == "declarativeappletscript" && md.value("X-Plasma-ComponentTypes").contains("Applet");
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
            if (q->containment()) {
                Q_EMIT q->containment()->appletAlternativesRequested(q);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &plat : platforms) {
                    if (md.formFactors().contains(plat)) {
                        found = true;
                        break;
                    }
                }
```

#### LAMBDA EXPRESSION 


```{c}
[](const KPluginMetaData &md) {
        return md.rawData().contains(QStringLiteral("KPlugin"));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
                 if (!d->applet->isContainment()) {
                     KConfigGroup cg = d->applet->config();
                     cg = KConfigGroup(&cg, "PopupApplet");
                     cg.writeEntry("DialogWidth", d->fullRepresentationItem.data()->property("width").toInt());
                     cg.writeEntry("DialogHeight", d->fullRepresentationItem.data()->property("height").toInt());
                 }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
            bool hasAlternatives = false;

            const QStringList provides = KPluginMetaData::readStringList(q->pluginMetaData().rawData(), QStringLiteral("X-Plasma-Provides"));
            if (!provides.isEmpty() && q->immutability() == Types::Mutable) {
                auto filter = [&provides](const KPluginMetaData &md) -> bool {
                    const QStringList provided = KPluginMetaData::readStringList(md.rawData(), QStringLiteral("X-Plasma-Provides"));
                    for (const QString &p : provides) {
                        if (provided.contains(p)) {
                            return true;
                        }
                    }
                    return false;
                };
                QList<KPluginMetaData> applets = KPackage::PackageLoader::self()->findPackages(QStringLiteral("Plasma/Applet"), QString(), filter);

                if (applets.count() > 1) {
                    hasAlternatives = true;
                }
            }
            a->setVisible(hasAlternatives);
        }
```

#### AUTO 


```{c}
auto filter = [&parentApp, &excluded, visibleOnly](const KPluginMetaData &md) -> bool
    {
        const QString pa = md.value("X-KDE-ParentApp");
        return (pa.isEmpty() || pa == parentApp) && (excluded.isEmpty() || excluded.contains(md.value("X-KDE-PluginInfo-Category"))) && (!visibleOnly || !md.isHidden());
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const QString &filePath, unsigned int lastModified) {
                if (d->lastModified != lastModified && filePath == d->path) {
                    d->lastModified = lastModified;
                    Q_EMIT repaintNeeded();
                }
            }
```

#### AUTO 


```{c}
auto filter = [&mimeType](const KPluginMetaData &md) -> bool
    {
        return KPluginMetaData::readStringList(md.rawData(), QStringLiteral("X-Plasma-DropMimeTypes")).contains(mimeType);
    };
```

#### AUTO 


```{c}
auto boundaryCorrection = [&pos, this, parentItem](int hDelta, int vDelta) {
        if (!parentItem->window()) {
            return;
        }
        QScreen *screen = parentItem->window()->screen();
        if (!screen) {
            return;
        }
        QRect geo = screen->geometry();
        pos = parentItem->window()->mapToGlobal(pos.toPoint());

        if (pos.x() < geo.x()) {
            pos.setX(pos.x() + hDelta);
        }
        if (pos.y() < geo.y()) {
            pos.setY(pos.y() + vDelta);
        }

        if (geo.x() + geo.width() < pos.x() + this->m_menu->width()) {
            pos.setX(pos.x() + hDelta);
        }
        if (geo.y() + geo.height() < pos.y() + this->m_menu->height()) {
            pos.setY(pos.y() + vDelta);
        }
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &name : std::as_const(actionOrder)) {
        QAction *a = orderedActions.value(name);
        if (a && !a->menu()) {
            actionList << a;
        }
        ++i;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](Plasma::Applet *a1,  Plasma::Applet *a2) {
                            return a1->id() < a2->id();
                        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Applet *applet : qAsConst(d->applets)) {
        applet->updateConstraints(Plasma::Types::LocationConstraint);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        m_models->clear(sourceName);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](QQuickView::Status status) {
        if (status == QQuickView::Ready) {
            d->mainItemLoaded();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](const QString &msg) {
                qWarning() << msg;
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this, url]() {
                        //set wallpapery stuff
                        if (m_wallpaperInterface && url.isValid()) {
                            m_wallpaperInterface->setUrl(url);
                        }
                    }
```

#### LAMBDA EXPRESSION 


```{c}
[=] () {
                transient = true;
                cleanUpAndDelete();
            }
```

#### AUTO 


```{c}
auto metadata = second.toMap().value(QStringLiteral("MetaData")).toMap();
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString element){bool ok; element.toLong(&ok); return ok;}
```

#### AUTO 


```{c}
auto filter = [&mimetype, &formFactor](const KPluginMetaData &md) -> bool {
        if (!formFactor.isEmpty() && !md.value(QStringLiteral("X-Plasma-FormFactors")).contains(formFactor)) {
            return false;
        }
        return KPluginMetaData::readStringList(md.rawData(), QStringLiteral("X-Plasma-DropMimeTypes")).contains(mimetype);
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (QMenuItem *item : qAsConst(m_items)) {
        if (item->section()) {
            if (!item->isVisible()) {
                continue;
            }

            m_menu->addSection(item->text());
        } else {
            m_menu->addAction(item->action());
            if (item->action()->menu()) {
                // This ensures existence of the QWindow
                m_menu->winId();
                item->action()->menu()->winId();
                item->action()->menu()->windowHandle()->setTransientParent(m_menu->windowHandle());
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &dir : dirs) {
            ret = KPluginLoader::findPluginsById(dir, pluginName);
            if (!ret.isEmpty()) {
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QSize &hint : elementSizeHints) {

                if (hint.width() >= s.width() * ratio && hint.height() >= s.height() * ratio &&
                        (!bestFit.isValid() ||
                         (bestFit.width() * bestFit.height()) > (hint.width() * hint.height()))) {
                    bestFit = hint;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &action : oldActionsList) {
        removeAction(action);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Containment *containment : qAsConst(containments)) {
        containmentsIds.insert(containment->id());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &name : names) {
            QAction *a = actions->action(name);
            actions->takeAction(a); // FIXME this is stupid, KActionCollection needs a takeAction(QString) method
            qactions << a;
        }
```

#### AUTO 


```{c}
const auto cs = ColorScopeAttached::s_attachedScopes.value(object);
```

#### LAMBDA EXPRESSION 


```{c}
[=] {
            if (m_svgIcon) {
                m_svgIcon->setColorGroup(iconItem->colorGroup());
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                m_svgElementsCache->sync();
            }
```

#### LAMBDA EXPRESSION 


```{c}
[&mimetype, &formFactor](const KPluginMetaData &md) -> bool
    {
        if (!formFactor.isEmpty() && !md.value("X-Plasma-FormFactors").contains(formFactor)) {
            return false;
        }
        return md.value("X-Plasma-DropMimeTypes").contains(mimetype);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& plugin : qAsConst(plugins)) {
        engines << plugin.pluginId();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](QQmlEngine* engine, QJSEngine*) -> QObject* { return new Plasma::QuickTheme(engine); }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
            m_status = DialogStatus::Closed;
            Q_EMIT statusChanged();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto plugin : packagePlugins) {
        engines << plugin.pluginId();
    }
```

#### AUTO 


```{c}
const auto screens = QGuiApplication::screens();
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *a : std::as_const(listActions)) {
        if (!actionOrder.contains(a->objectName())) {
            // FIXME QML visualizations don't support menus for now, *and* there is no way to
            // distinguish them on QML side
            if (!a->menu()) {
                actions.insert(a->data().toInt() * 100 + i, a);
                ++i;
            }
        } else {
            orderedActions[a->objectName()] = a;
        }
    }
```

#### AUTO 


```{c}
auto filter = [&parentApp](const KPluginMetaData &md) -> bool
    {
        return md.value(QStringLiteral("X-KDE-ParentApp")) == parentApp;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this, packagePath, structure, posi](KJob *job) {
                        auto fail = [job](const QString &text) {
                            KNotification::event(QStringLiteral("plasmoidInstallationFailed"), i18n("Package Installation Failed"),
                                                 text, QStringLiteral("dialog-error"), 0, KNotification::CloseOnTimeout, QStringLiteral("plasma_workspace"));
                        };

                        // if the applet is already installed, just add it to the containment
                        if (job->error() != KJob::NoError
                            && job->error() != Package::PackageAlreadyInstalledError
                            && job->error() != Package::NewerVersionAlreadyInstalledError) {
                            fail(job->errorText());
                            return;
                        }

                        using namespace KPackage;
                        Package package(structure);
                        // TODO how can I get the path of the actual package?
                        package.setPath(packagePath);

                        // TODO how can I get the plugin id? Package::metadata() is deprecated
                        if (!package.isValid() || !package.metadata().isValid()) {
                            fail(i18n("The package you just dropped is invalid."));
                            return;
                        }

                        createApplet(package.metadata().pluginId(), QVariantList(), QRect(posi, QSize(-1,-1)));
                    }
```

#### AUTO 


```{c}
auto filterParentApp = [&category, &parentApp](const KPluginMetaData &md) -> bool {
        return md.value(QStringLiteral("X-KDE-ParentApp")) == parentApp //
            && md.value(QStringLiteral("X-KDE-PluginInfo-Category")) == category;
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &info : std::as_const(wallpaperList)) {
                    const QString actionText = i18nc("Set wallpaper", "Set %1", info.name());
                    QAction *action = new QAction(actionText, m_dropMenu);
                    if (!info.iconName().isEmpty()) {
                        action->setIcon(QIcon::fromTheme(info.iconName()));
                    }
                    m_dropMenu->addAction(action);
                    actionsToWallpapers.insert(action, info.pluginId());
                    const QUrl url = tjob->url();
                    connect(action, &QAction::triggered, this, [this, info, url]() {
                        // Change wallpaper plugin if it's not the current one
                        if (containment()->wallpaper() != info.pluginId()) {
                            containment()->setWallpaper(info.pluginId());
                        }

                        // set wallpapery stuff
                        if (m_wallpaperInterface && url.isValid()) {
                            m_wallpaperInterface->setUrl(url);
                        }
                    });
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (Plasma::Applet *app : cont->applets()) {
            QCOMPARE(app->immutability(), Plasma::Types::SystemImmutable);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        m_dialogShown = true;
        QCOMPARE(dialog->type(), PlasmaQuick::Dialog::Notification);
        QCOMPARE(dialog->location(), Plasma::Types::TopEdge);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, packagePath, structure](KJob *job) {
                        auto fail = [](const QString &text) {
                            KNotification::event(QStringLiteral("plasmoidInstallationFailed"),
                                                 i18n("Package Installation Failed"),
                                                 text,
                                                 QStringLiteral("dialog-error"),
                                                 nullptr,
                                                 KNotification::CloseOnTimeout,
                                                 QStringLiteral("plasma_workspace"));
                        };

                        // if the applet is already installed, just add it to the containment
                        if (job->error() != KJob::NoError && job->error() != Package::PackageAlreadyInstalledError
                            && job->error() != Package::NewerVersionAlreadyInstalledError) {
                            fail(job->errorText());
                            return;
                        }

                        using namespace KPackage;
                        Package package(structure);
                        // TODO how can I get the path of the actual package?

                        package.setPath(packagePath);

                        // TODO how can I get the plugin id? Package::metadata() is deprecated
                        if (!package.isValid() || !package.metadata().isValid()) {
                            fail(i18n("The package you just dropped is invalid."));
                            return;
                        }

                        createApplet(package.metadata().pluginId(), QVariantList(), QRect(m_dropMenu->dropPoint(), QSize(-1, -1)));
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for (SignalRelay *relay : std::as_const(d->relays)) {
        relay->forceImmediateUpdate();
    }
```

#### AUTO 


```{c}
auto filter = [](const KPluginMetaData &md) -> bool
    {
        return md.value("X-Plasma-API") == "declarativeappletscript" && md.value("X-Plasma-ComponentTypes").contains("Applet");
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this, action, mimetype, url](){
                    Plasma::Applet *applet = createApplet(action->data().toString(), QVariantList(), QRect(m_dropMenu->dropPoint(), QSize(-1,-1)));
                    setAppletArgs(applet, mimetype, url.toString());
                }
```

#### LAMBDA EXPRESSION 


```{c}
[](const KPluginMetaData &md) -> bool
    {
        return md.value(QStringLiteral("X-Plasma-API")) == QLatin1String("declarativeappletscript")
            && md.value(QStringLiteral("X-Plasma-ComponentTypes")).contains(QLatin1String("Applet"));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&category, &parentApp](const KPluginMetaData &md) -> bool
    {
        return md.value(QStringLiteral("X-KDE-ParentApp")) == parentApp
            && md.value(QStringLiteral("X-KDE-PluginInfo-Category")) == category;
    }
```

#### AUTO 


```{c}
const auto lstChildren = item->children();
```

#### RANGE FOR STATEMENT 


```{c}
for (SignalRelay *relay : qAsConst(dc->d->relays)) {
                    times.append(QLatin1Char(' ') + QString::number(relay->m_interval));
                }
```

#### LAMBDA EXPRESSION 


```{c}
[](const KPluginMetaData &md) {
        return md.serviceTypes().contains(QLatin1String("PlasmaCalendar/Plugin"));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QObject *child : lstChildren) {
        // find for the needed property of Layout: minimum/maximum/preferred sizes and fillWidth/fillHeight
        /* clang-format off */
        if (child->property("minimumWidth").isValid()
            && child->property("minimumHeight").isValid()
            && child->property("preferredWidth").isValid()
            && child->property("preferredHeight").isValid()
            && child->property("maximumWidth").isValid()
            && child->property("maximumHeight").isValid()
            && child->property("fillWidth").isValid()
            && child->property("fillHeight").isValid()) { /* clang-format on */
            layout = child;
            break;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&pos, this, parentItem](int hDelta, int vDelta) {
        if (!parentItem->window()) {
            return;
        }
        QScreen *screen = parentItem->window()->screen();
        if (!screen) {
            return;
        }
        QRect geo = screen->geometry();
        pos = parentItem->window()->mapToGlobal(pos.toPoint());

        if (pos.x() < geo.x()) {
            pos.setX(pos.x() + hDelta);
        }
        if (pos.y() < geo.y()) {
            pos.setY(pos.y() + vDelta);
        }

        if (geo.x() + geo.width() < pos.x() + this->m_menu->width()) {
            pos.setX(pos.x() + hDelta);
        }
        if (geo.y() + geo.height() < pos.y() + this->m_menu->height()) {
            pos.setY(pos.y() + vDelta);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&provides](const KPluginMetaData &md) -> bool {
                    const QStringList provided = md.value(QStringLiteral("X-Plasma-Provides"), QStringList());
                    for (const QString &p : provides) {
                        if (provided.contains(p)) {
                            return true;
                        }
                    }
                    return false;
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &name : names) {
            QAction *a = actions->action(name);
            actions->takeAction(a); //FIXME this is stupid, KActionCollection needs a takeAction(QString) method
            qactions << a;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[ = ]() {
        // in case the applet doesn't want to get shrunk on reactivation,
        // we always expand it again (only in order to conform with legacy behaviour)
        bool activate = !( isExpanded() && isActivationTogglesExpanded() );

        setExpanded(activate);
        if (activate) {
            if (QQuickItem *i = qobject_cast<QQuickItem *>(fullRepresentationItem())) {
                // Bug 372476: never pull focus away from it, only setFocus(true)
                i->setFocus(true, Qt::ShortcutFocusReason);
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, action, mimetype, url]() {
                    Plasma::Applet *applet = createApplet(action->data().toString(), QVariantList(), QRect(m_dropMenu->dropPoint(), QSize(-1,-1)));
                    setAppletArgs(applet, mimetype, url.toString());
                }
```

#### LAMBDA EXPRESSION 


```{c}
[&type, &category, &parentApp](const KPluginMetaData &md) -> bool
    {
        if (!md.serviceTypes().contains(QStringLiteral("Plasma/Containment"))) {
            return false;
        }
        const QString pa = md.value(QStringLiteral("X-KDE-ParentApp"));
        if (!pa.isEmpty() && pa != parentApp) {
            return false;
        }

        if (!type.isEmpty() && md.value(QStringLiteral("X-Plasma-ContainmentType")) != type) {
            return false;
        }

        if (!category.isEmpty() && md.value(QStringLiteral("X-KDE-PluginInfo-Category")) != category) {
            return false;
        }

        return true;
    }
```

#### AUTO 


```{c}
auto it = searchJobs.begin();
```

#### AUTO 


```{c}
const auto metaDataList = KPluginMetaData::findPlugins(pluginNamespace);
```

#### AUTO 


```{c}
auto i = m_plugins.begin();
```

#### AUTO 


```{c}
auto filter = [&type, &category, &parentApp](const KPluginMetaData &md) -> bool {
        if (!md.serviceTypes().contains(QLatin1String("Plasma/Containment"))) {
            return false;
        }
        if (!parentApp.isEmpty() && md.value(QStringLiteral("X-KDE-ParentApp")) != parentApp) {
            return false;
        }

        if (!type.isEmpty() && md.value(QStringLiteral("X-Plasma-ContainmentType")) != type) {
            return false;
        }

        if (!category.isEmpty() && md.value(QStringLiteral("X-KDE-PluginInfo-Category")) != category) {
            return false;
        }

        return true;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[ = ]() {
                delete m_activityInfo;
                m_activityInfo = new KActivities::Info(m_containment->activity(), this);
                connect(m_activityInfo, &KActivities::Info::nameChanged,
                        this, &ContainmentInterface::activityNameChanged);
                Q_EMIT activityNameChanged();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &info : std::as_const(appletList)) {
                    sorted.insert(info.name(), info);
                }
```

#### AUTO 


```{c}
auto *quickCandidate = qobject_cast<QQuickItem *>(candidate);
```

#### AUTO 


```{c}
auto ownFilter = [filter](const KPluginMetaData &md) -> bool {
        if (!md.serviceTypes().contains(QLatin1String("Plasma/Containment"))) {
            return false;
        }

        return filter(md);
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this, packagePath, structure, posi](KJob *job) {
                        auto fail = [](const QString &text) {
                            KNotification::event(QStringLiteral("plasmoidInstallationFailed"), i18n("Package Installation Failed"),
                                                 text, QStringLiteral("dialog-error"), nullptr, KNotification::CloseOnTimeout, QStringLiteral("plasma_workspace"));
                        };

                        // if the applet is already installed, just add it to the containment
                        if (job->error() != KJob::NoError
                            && job->error() != Package::PackageAlreadyInstalledError
                            && job->error() != Package::NewerVersionAlreadyInstalledError) {
                            fail(job->errorText());
                            return;
                        }

                        using namespace KPackage;
                        Package package(structure);
                        // TODO how can I get the path of the actual package?

                        package.setPath(packagePath);

                        // TODO how can I get the plugin id? Package::metadata() is deprecated
                        if (!package.isValid() || !package.metadata().isValid()) {
                            fail(i18n("The package you just dropped is invalid."));
                            return;
                        }

                        createApplet(package.metadata().pluginId(), QVariantList(), QRect(posi, QSize(-1,-1)));
                    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            findParentScope();
            checkColorGroupChanged();
        }
```

#### AUTO 


```{c}
const auto pkg = corona->kPackage();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto c : containments()) {
        if (c->containmentType() == Plasma::Types::DesktopContainment) {
            //example of a shell without a wallpaper
            c->setWallpaper("null");
            m_view->setContainment(c);
            QAction *removeAction = c->actions()->action(QStringLiteral("remove"));
            if(removeAction) {
                removeAction->deleteLater();
            }
            break;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&parentApp](const KPluginMetaData &md) -> bool
    {
        const QString pa = md.value(QStringLiteral("X-KDE-ParentApp"));
        return (parentApp.isEmpty() || pa == parentApp) && !KPluginMetaData::readStringList(md.rawData(), QStringLiteral("X-Plasma-DropUrlPatterns")).isEmpty();
    }
```

#### AUTO 


```{c}
auto a
```

#### AUTO 


```{c}
const auto &dir
```

#### AUTO 


```{c}
auto c
```

#### LAMBDA EXPRESSION 


```{c}
[ = ]() {
        // in case the applet doesn't want to get shrinked on reactivation,
        // we always expand it again (only in order to conform with legacy behaviour)
        bool activate = !( isExpanded() && isActivationTogglesExpanded() );

        setExpanded(activate);
        if (QQuickItem *i = qobject_cast<QQuickItem *>(fullRepresentationItem())) {
            i->setFocus(activate, Qt::ShortcutFocusReason);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &kcm : qAsConst(kcms)) {
            // Only look for KCMs in the "kcms_" folder where new QML KCMs live
            // because we don't support loading QWidgets KCMs
            KPluginLoader loader(KPluginLoader::findPlugin(QLatin1String("kcms/") + kcm));
            KPluginMetaData md(loader.fileName());

            if (!md.isValid()) {
                qWarning() << "Could not find" << kcm << "requested by X-Plasma-ConfigPlugins. Ensure that it exists, is a QML KCM, and lives in the 'kcms/' subdirectory.";
                continue;
            }

            configModel->appendCategory(md.iconName(), md.name(), QString(), loader.fileName());
        }
```

#### AUTO 


```{c}
const auto upper_left_y = m_panel->y();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto md : KPackage::PackageLoader::self()->findPackages("Plasma/Applet", QString(), filter)) {
            list << KPluginInfo(KService::serviceByStorageId(md.metaDataFileName()));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginInfo &info : allInfo) {
        if (info.category().compare(category, Qt::CaseInsensitive) == 0) {
            matchingInfo << info;
        }
    }
```

#### AUTO 


```{c}
auto filter = [&excluded, &parentApp](const KPluginMetaData &md) -> bool
        {
            const QString pa = md.value(QStringLiteral("X-KDE-ParentApp"));
            return (pa.isEmpty() || pa == parentApp) && !excluded.contains(md.category());
        };
```

#### RANGE FOR STATEMENT 


```{c}
for (const QQmlError &error : errors) {
                reason += error.toString() + QLatin1Char('\n');
                errorList << error.toString();
            }
```

#### AUTO 


```{c}
const auto &token
```

#### AUTO 


```{c}
auto plugins = KPackage::PackageLoader::self()->findPackages(QStringLiteral("Plasma/Applet"), QString(), filter);
```

#### LAMBDA EXPRESSION 


```{c}
[&type, &category, &parentApp](const KPluginMetaData &md) -> bool
    {
        if (!md.serviceTypes().contains(QLatin1String("Plasma/Containment"))) {
            return false;
        }
        if (!parentApp.isEmpty() && md.value(QStringLiteral("X-KDE-ParentApp")) != parentApp) {
            return false;
        }

        if (!type.isEmpty() && md.value(QStringLiteral("X-Plasma-ContainmentType")) != type) {
            return false;
        }

        if (!category.isEmpty() && md.value(QStringLiteral("X-KDE-PluginInfo-Category")) != category) {
            return false;
        }

        return true;
    }
```

#### AUTO 


```{c}
auto cont
```

#### LAMBDA EXPRESSION 


```{c}
[ = ]() {
        delete m_activityInfo;
        m_activityInfo = new KActivities::Info(containment()->activity(), this);
        connect(m_activityInfo, &KActivities::Info::nameChanged,
                this, &ContainmentInterface::activityNameChanged);
        emit activityNameChanged();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        if (window() && window()->mouseGrabberItem()) {
            window()->mouseGrabberItem()->ungrabMouse();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[category, parentApp, platforms](const KPluginMetaData &md) -> bool {
            if (!platforms.isEmpty() && !md.formFactors().isEmpty()) {
                bool found = false;
                for (const auto &plat : platforms) {
                    if (md.formFactors().contains(plat)) {
                        found = true;
                        break;
                    }
                }

                if (!found) {
                    return false;
                }
            }

            const QString pa = md.value(QStringLiteral("X-KDE-ParentApp"));

            if (category == QLatin1String("Miscellaneous")) {
                return (parentApp.isEmpty() || pa == parentApp) && (md.category() == category || md.category().isEmpty());
            } else {
                return (parentApp.isEmpty() || pa == parentApp) && md.category() == category;
            }
        }
```

#### AUTO 


```{c}
const auto oldStatus = m_containment->status();
```

#### LAMBDA EXPRESSION 


```{c}
[this, applet](KJob *job) {
            if (job->error()) {
                qCWarning(LOG_PLASMA) << "couldn't run" << d->applicationNames.value(applet) << d->urlLists.value(applet) << job->errorString();
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&mimetype, &formFactor](const KPluginMetaData &md) -> bool {
        if (!formFactor.isEmpty() && !md.value(QStringLiteral("X-Plasma-FormFactors")).contains(formFactor)) {
            return false;
        }
        return md.value(QStringLiteral("X-Plasma-DropMimeTypes"), QStringList()).contains(mimetype);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto c : containments()) {
        if (c->containmentType() == Plasma::Types::DesktopContainment) {
            m_view->setContainment(c);
            QAction *removeAction = c->actions()->action(QStringLiteral("remove"));
            if(removeAction) {
                removeAction->deleteLater();
            }
            break;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[filter](const KPluginMetaData &md) -> bool {
        if (!md.serviceTypes().contains(QLatin1String("Plasma/Containment"))) {
            return false;
        }

        return filter(md);
    }
```

#### AUTO 


```{c}
auto fail = [job](const QString &text) {
                            KNotification::event(QStringLiteral("plasmoidInstallationFailed"), i18n("Package Installation Failed"),
                                                 text, QStringLiteral("dialog-error"), nullptr, KNotification::CloseOnTimeout, QStringLiteral("plasma_workspace"));
                        };
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
                if (!containment()) {
                    return;
                }
                disconnect(containment(), &Plasma::Containment::appletRemoved,
                this, &ContainmentInterface::appletRemovedForward);
        }
```

#### AUTO 


```{c}
const auto last = m_actualGroup;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &plugin : plugins) {
        if (!filter(plugin)) {
            continue;
        }
        const QStringList componentTypes = plugins.first().value(QStringLiteral("X-Plasma-ComponentTypes"), QStringList());
        if (((types & Types::AppletComponent) && componentTypes.contains(QLatin1String("Applet")))
            || ((types & Types::DataEngineComponent) && componentTypes.contains(QLatin1String("DataEngine")))) {
            ret << plugin;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QDate date : std::as_const(updatesList)) {
        const QModelIndex changedIndex = indexForDate(date);
        if (changedIndex.isValid()) {
            Q_EMIT dataChanged(changedIndex, changedIndex, {containsEventItems, containsMajorEventItems, containsMinorEventItems});
        }

        Q_EMIT agendaUpdated(date);
    }
```

#### AUTO 


```{c}
auto pi = KPluginInfo(KService::serviceByStorageId(md.metaDataFileName()));
```

#### AUTO 


```{c}
const auto containments = m_corona->containments();
```

#### AUTO 


```{c}
auto action
```

#### AUTO 


```{c}
const auto itemsList = loader.items();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto c : containments()) {
        if (c->containmentType() == Plasma::Types::DesktopContainment) {
            desktopFound = true;
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &source : qAsConst(m_connectedSources)) {
        m_dataEngine->connectSource(source, this, m_interval, m_intervalAlignment);
        Q_EMIT sourceConnected(source);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &key : lst) {
                if (!m_sourceFilter.isEmpty() && m_sourceFilterRE.isValid() && !m_sourceFilterRE.exactMatch(key)) {
                    continue;
                }
                QVariant value = m_dataSource->data()->value(key);
                if (value.isValid() && value.canConvert<Plasma::DataEngine::Data>()) {
                    Plasma::DataEngine::Data data = value.value<Plasma::DataEngine::Data>();
                    data[QStringLiteral("DataEngineSource")] = key;
                    list.append(data);
                }
            }
```

#### AUTO 


```{c}
auto res = KPluginFactory::instantiatePlugin<Plasma::ContainmentActions>(plugin, nullptr, {QVariant::fromValue(plugin)})
```

#### AUTO 


```{c}
const auto *iconTheme = KIconLoader::global()->theme();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto c : containments()) {
        if (c->containmentType() == Plasma::Types::DesktopContainment) {
            //example of a shell without a wallpaper
            c->setWallpaper(QStringLiteral("null"));
            m_view->setContainment(c);
            if (QAction *removeAction = c->actions()->action(QStringLiteral("remove"))) {
                removeAction->deleteLater();
            }
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Applet *a : qAsConst(applets)) {
            /*Why qMin?
             * the applets immutability() is the maximum between internal applet immutability
             * and the immutability of its containment.
             * so not set higher immutability in the internal member of Applet
             * or the applet will not be able to be unlocked properly
             */
            a->setImmutability(qMin(q->immutability(), a->d->immutability));
            a->updateConstraints(Types::ImmutableConstraint);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=](bool ready) {
                    if (!ready) {
                        return;
                    }

                    --containmentsStarting;
                    if (containmentsStarting <= 0) {
                        emit q->startupCompleted();
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (SignalRelay *relay : qAsConst(d->relays)) {
            relay->checkQueueing();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
            // If the timer still exists, it means the undo action was NOT triggered
            if (transient) {
                cleanUpAndDelete();
            }
            if (deleteNotificationTimer) {
                deleteNotificationTimer->stop();
                deleteNotificationTimer->deleteLater();
                deleteNotificationTimer = nullptr;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& dir : dirs) {
            ret = KPluginLoader::findPluginsById(dir, pluginName);
            if (!ret.isEmpty())
                break;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto data : d->internalPackage->requiredDirectories()) {
        dirs << data.constData();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, c] {
        const int row = categories.indexOf(c);
        if (row > -1) {
            QModelIndex modelIndex = q->index(row);
            emit q->dataChanged(modelIndex, modelIndex);
        }
    }
```

#### AUTO 


```{c}
auto filterParentApp = [&category, &parentApp](const KPluginMetaData &md) -> bool
    {
        return md.value("X-KDE-ParentApp") == parentApp && md.value("X-KDE-PluginInfo-Category") == category;
    };
```

#### AUTO 


```{c}
const auto oldActionsList = m_actions;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &key : keyList) {
                //qCDebug(LOG_PLASMA) << "loading" << key;
                setContainmentActions(key, cfg.readEntry(key, QString()));
            }
```

#### LAMBDA EXPRESSION 


```{c}
[screen](Containment *cont) { return cont->lastScreen() == screen &&
                     (cont->containmentType() == Plasma::Types::DesktopContainment ||
                      cont->containmentType() == Plasma::Types::CustomContainment);}
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {
        q->setEditMode(!q->isEditMode());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginInfo &containmentInfo : containmentInfos) {
        const QStringList theseTypes = containmentInfo.property(QStringLiteral("X-Plasma-ContainmentType")).toStringList();
        for (const QString &type : theseTypes) {
            types.insert(type);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
                    m_syncTimer->start(0);
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (KConfigSkeletonItem *item : itemsList) {
        d->operationsMap[item->group()][item->key()] = item->property();
    }
```

#### AUTO 


```{c}
auto ee = static_cast<QExposeEvent *>(event);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &source : sources) {
        if (!m_connectedSources.contains(source)) {
            sourcesChanged = true;
            if (m_dataEngine) {
                m_connectedSources.append(source);
                m_dataEngine->connectSource(source, this, m_interval, m_intervalAlignment);
                emit sourceConnected(source);
            }
        }
    }
```

#### AUTO 


```{c}
auto data
```

#### RANGE FOR STATEMENT 


```{c}
for (SignalRelay *relay : std::as_const(dc->d->relays)) {
                    times.append(QLatin1Char(' ') + QString::number(relay->m_interval));
                }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
                    //If the timer still exists, it means the undo action was NOT triggered
                    if (deleteNotificationTimer) {
                        transient = true;
                        emit q->destroyedChanged(true);
                        cleanUpAndDelete();
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto md : KPackage::PackageLoader::self()->findPackages("Plasma/Applet", QString(), filter)) {
            auto pi =  KPluginInfo(KService::serviceByStorageId(md.metaDataFileName()));
            if (!pi.isValid()) {
                qCWarning(LOG_PLASMA) << "Could not load plugin info for plugin :" << md.pluginId() << "skipping plugin";
                continue;
            }
            list << pi;
        }
```

#### AUTO 


```{c}
auto runJob = job.dynamicCast<FindMatchesJob>();
```

#### LAMBDA EXPRESSION 


```{c}
[configDlg] () {
                configDlg->deleteLater();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto a : containmentHash) {
        a->destroy();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](){m_syncTimer->start(150);}
```

#### RANGE FOR STATEMENT 


```{c}
for (SignalRelay *relay : qAsConst(d->relays)) {
        relay->forceImmediateUpdate();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&excluded, &parentApp](const KPluginMetaData &md) -> bool
        {
            const QString pa = md.value(QStringLiteral("X-KDE-ParentApp"));
            return (pa.isEmpty() || pa == parentApp) && !excluded.contains(md.category());
        }
```

#### AUTO 


```{c}
auto cacheId = CacheId{double(size.width()), double(size.height()), path, id, status, devicePixelRatio, scaleFactor, colorGroup, 0, lastModified};
```

#### LAMBDA EXPRESSION 


```{c}
[this, oldStatus] {
        m_containment->setStatus(oldStatus);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &info : std::as_const(seenPlugins)) {
                QAction *action;
                if (!info.iconName().isEmpty()) {
                    action = new QAction(QIcon::fromTheme(info.iconName()), info.name(), m_dropMenu);
                } else {
                    action = new QAction(info.name(), m_dropMenu);
                }
                m_dropMenu->addAction(action);
                action->setData(info.pluginId());
                connect(action, &QAction::triggered, this, [this, x, y, mimeData, action]() {
                    const QString selectedPlugin = action->data().toString();
                    Plasma::Applet *applet = createApplet(selectedPlugin, QVariantList(), QRect(x, y, -1, -1));
                    setAppletArgs(applet, selectedPlugin, QString::fromUtf8(mimeData->data(selectedPlugin)));
                });

                actionsToPlugins.insert(action, info.pluginId());
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &path : qAsConst(m_candidates)) {
        // qDebug() << "Searching for:" << path + path;
        if (m_possiblePaths.contains(path + key)) {
            resolved = *m_possiblePaths.object(path + key);
            if (!resolved.isEmpty()) {
                break;
            } else {
                continue;
            }
        }

        QDir tmpPath(m_basePath);

        if (tmpPath.isAbsolute()) {
            resolved = m_basePath + path + key;
        } else {

            resolved = QStandardPaths::locate(QStandardPaths::GenericDataLocation, m_basePath + QLatin1Char('/') + path + key);
        }

        m_possiblePaths.insert(path + key, new QString(resolved));
        if (!resolved.isEmpty()) {
            break;
        }
    }
```

#### AUTO 


```{c}
auto filter = [&mimetype, &formFactor](const KPluginMetaData &md) -> bool {
        if (!formFactor.isEmpty() && !md.value(QStringLiteral("X-Plasma-FormFactors")).contains(formFactor)) {
            return false;
        }
        return md.value(QStringLiteral("X-Plasma-DropMimeTypes"), QStringList()).contains(mimetype);
    };
```

#### AUTO 


```{c}
auto i = m_eventsData.begin();
```

#### AUTO 


```{c}
const auto plugins = KPackage::PackageLoader::self()->findPackages(QStringLiteral("Plasma/Applet"), QString(), filter);
```

#### AUTO 


```{c}
const auto &mo = Qt::staticMetaObject;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &prefix : m_prefixes) {
        if (m_frameSvg->hasElementPrefix(prefix)) {
            m_frameSvg->setElementPrefix(prefix);
            found = true;
            break;
        }
    }
```

#### AUTO 


```{c}
auto matchIt = idExpr.globalMatch(contentsAsString);
```

#### LAMBDA EXPRESSION 


```{c}
[packageFormat](const KPluginMetaData &md) -> bool {
            return md.value(QStringLiteral("X-KDE-PluginInfo-Name")) == packageFormat;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
                disconnect(containment(), &Plasma::Containment::appletRemoved,
                this, &ContainmentInterface::appletRemovedForward);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
                    //If the timer still exists, it means the undo action was NOT triggered
                    if (transient) {
                        cleanUpAndDelete();
                    }
                    if (deleteNotificationTimer) {
                        deleteNotificationTimer->stop();
                        deleteNotificationTimer->deleteLater();
                        deleteNotificationTimer = 0;
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &appletGroup : qAsConst(groups)) {
        //qCDebug(LOG_PLASMA) << "reading from applet group" << appletGroup;
        KConfigGroup appletConfig(&applets, appletGroup);
        appletConfigs.append(appletConfig);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &group : qAsConst(groups)) {
        KConfigGroup containmentConfig(&containmentsGroup, group);

        if (containmentConfig.entryMap().isEmpty()) {
            continue;
        }

        uint cid = group.toUInt();
        if (containmentsIds.contains(cid)) {
            cid = ++AppletPrivate::s_maxAppletId;
        } else if (cid > AppletPrivate::s_maxAppletId) {
            AppletPrivate::s_maxAppletId = cid;
        }

        if (mergeConfig) {
            KConfigGroup realConf(q->config(), "Containments");
            realConf = KConfigGroup(&realConf, QString::number(cid));
            // in case something was there before us
            realConf.deleteGroup();
            containmentConfig.copyTo(&realConf);
        }

        //qCDebug(LOG_PLASMA) << "got a containment in the config, trying to make a" << containmentConfig.readEntry("plugin", QString()) << "from" << group;
#ifndef NDEBUG
        // qCDebug(LOG_PLASMA) << "!!{} STARTUP TIME" << QTime().msecsTo(QTime::currentTime()) << "Adding Containment" << containmentConfig.readEntry("plugin", QString());
#endif
        Containment *c = addContainment(containmentConfig.readEntry("plugin", QString()), QVariantList(), cid, -1);
        if (!c) {
            continue;
        }

        newContainments.append(c);
        containmentsIds.insert(c->id());

#ifndef NDEBUG
//         qCDebug(LOG_PLASMA) << "!!{} STARTUP TIME" << QTime().msecsTo(QTime::currentTime()) << "Restored Containment" << c->pluginName();
#endif
    }
```

#### LAMBDA EXPRESSION 


```{c}
[excluded, parentApp, platforms](const KPluginMetaData &md) -> bool
        {
            if (!platforms.isEmpty() && !md.formFactors().isEmpty()) {
                bool found = false;
                for (const auto &plat : platforms) {
                    if (md.formFactors().contains(plat)) {
                        found = true;
                        break;
                    }
                }

                if (!found) {
                    return false;
                }
            }

            const QString pa = md.value(QStringLiteral("X-KDE-ParentApp"));
            return (parentApp.isEmpty() || pa == parentApp) && !excluded.contains(md.category());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &source : sources) {
        if (!m_connectedSources.contains(source)) {
            sourcesChanged = true;
            if (m_dataEngine) {
                m_connectedSources.append(source);
                m_dataEngine->connectSource(source, this, m_interval, m_intervalAlignment);
                Q_EMIT sourceConnected(source);
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](QObject *a, QObject *b) {
        return qobject_cast<EventDataDecorator*>(b)->startDateTime() > qobject_cast<EventDataDecorator*>(a)->startDateTime();
    }
```

#### AUTO 


```{c}
auto c = connect(dialog, &QWindow::visibleChanged, [=]() {
        m_dialogShown = true;
        QCOMPARE(dialog->type(), PlasmaQuick::Dialog::Notification);
        QCOMPARE(dialog->location(), Plasma::Types::TopEdge);
    });
```

#### AUTO 


```{c}
const auto files = cacheDir.entryInfoList();
```

#### AUTO 


```{c}
auto position =
                    std::lower_bound(q->containment()->d->applets.begin(), q->containment()->d->applets.end(), q, [](Plasma::Applet *a1, Plasma::Applet *a2) {
                        return a1->id() < a2->id();
                    });
```

#### AUTO 


```{c}
auto filter = [&mimeType](const KPluginMetaData &md) -> bool
    {
        return md.value("X-Plasma-DropMimeTypes").contains(mimeType);
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &overlay : std::as_const(m_overlays)) {
        if (!overlay.isEmpty()) {
            // There is at least one overlay, draw all overlays above m_pixmap
            // and cancel the check
            KIconLoader::global()->drawOverlays(m_overlays, result, KIconLoader::Desktop);
            break;
        }
    }
```

#### AUTO 


```{c}
auto filterNormal = [&category](const KPluginMetaData &md) -> bool {
        return md.value(QStringLiteral("X-KDE-PluginInfo-Category")) == category;
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (Plasma::Applet *app : lstApplets) {
            QCOMPARE(app->immutability(), Plasma::Types::Mutable);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &source : std::as_const(m_connectedSources)) {
        m_dataEngine->connectSource(source, this, m_interval, m_intervalAlignment);
        Q_EMIT sourceConnected(source);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[ = ]() {
        if (!d->applet->isContainment()) {
            KConfigGroup cg = d->applet->config();
            cg = KConfigGroup(&cg, "PopupApplet");
            cg.writeEntry("DialogWidth", d->fullRepresentationItem.data()->property("width").toInt());
            cg.writeEntry("DialogHeight", d->fullRepresentationItem.data()->property("height").toInt());
        }
    }
```

#### AUTO 


```{c}
auto md
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &e : allEngines) {
        Plasma::DataEngine *engine = Plasma::PluginLoader::self()->loadDataEngine(e);
        if (engine) {
            engine->connectSource(QStringLiteral("Europe/Amsterdam"), this);
            engine->connectSource(QStringLiteral("Battery"), this);
            engine->connectAllSources(this);
            qDebug() << "SOURCE: " << engine->sources();
            ok = true;
        }

    }
```

#### AUTO 


```{c}
auto plugins = KPluginMetaData::findPlugins(QStringLiteral("plasmacalendarplugins"), [](const KPluginMetaData &md) {
        return md.rawData().contains(QStringLiteral("KPlugin"));
    });
```

#### RANGE FOR STATEMENT 


```{c}
for (pswp wp : qAsConst(d->structures)) {
        delete wp.data();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &overlay : std::as_const(m_overlays)) {
        if (!overlay.isEmpty()) {
            // There is at least one overlay, draw all overlays above m_pixmap
            // and cancel the check
            m_iconLoader->drawOverlays(m_overlays, result, KIconLoader::Desktop);
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &key : lst) {
            const auto match = sizeHintedKeyExpr.match(key);
            if (match.hasMatch()) {
                QString baseElementId = match.captured(3);
                QSize sizeHint(match.capturedRef(1).toInt(),
                               match.capturedRef(2).toInt());
                if (sizeHint.isValid()) {
                    elementsWithSizeHints.insert(baseElementId, sizeHint);
                }
            }
        }
```

#### AUTO 


```{c}
auto filter = [&mimeType](const KPluginMetaData &md) -> bool
    {
        return md.value(QStringLiteral("X-Plasma-DropMimeTypes")).contains(mimeType);
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (Containment *containment : std::as_const(containments)) {
        containmentsIds.insert(containment->id());
    }
```

#### AUTO 


```{c}
auto fd = frame;
```

#### LAMBDA EXPRESSION 


```{c}
[this, delay]() {
                        qCDebug(LOG_PLASMAQUICK) << "Delayed preload of " << d->applet->title() << "after" << (qreal)delay / 1000 << "seconds";
                        d->preloadForExpansion();
                    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        if (!isEnabled()) {
            stopRedirecting();
            releaseResources();
        } else if (isVisible()) {
            startRedirecting();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool needsConfig, const QString &reason) {
                emit configurationRequiredChanged();
                emit configurationRequiredReasonChanged();
            }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
                KConfigGroup cg = d->applet->config();
                cg = KConfigGroup(&cg, "PopupApplet");
                cg.writeEntry("DialogWidth", d->fullRepresentationItem.data()->property("width").toInt());
                cg.writeEntry("DialogHeight", d->fullRepresentationItem.data()->property("height").toInt());
            }
```

#### LAMBDA EXPRESSION 


```{c}
[=] () {
            setExpanded(true);
            if (QQuickItem *i = qobject_cast<QQuickItem *>(fullRepresentationItem())) {
                i->forceActiveFocus(Qt::ShortcutFocusReason);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QObject *child : children) {
        //find for the needed property of Layout: minimum/maximum/preferred sizes and fillWidth/fillHeight
        if (child->property("minimumWidth").isValid() && child->property("minimumHeight").isValid() &&
                child->property("preferredWidth").isValid() && child->property("preferredHeight").isValid() &&
                child->property("maximumWidth").isValid() && child->property("maximumHeight").isValid() &&
                child->property("fillWidth").isValid() && child->property("fillHeight").isValid()
           ) {
            ownLayout = child;
            break;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](Plasma::Applet *a1,  Plasma::Applet *a2) {
        return a1->id() < a2->id();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
                delete m_activityInfo;
                m_activityInfo = new KActivities::Info(containment()->activity(), this);
                connect(m_activityInfo, &KActivities::Info::nameChanged,
                        this, &ContainmentInterface::activityNameChanged);
                emit activityNameChanged();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (Applet *applet : qAsConst(applets)) {
            if (applet->status() > appletStatus && applet->status() != Plasma::Types::HiddenStatus) {
                appletStatus = applet->status();
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[ = ]() {
        if (d->resizeOrigin == DialogPrivate::MainItem) {
            d->syncToMainItemSize();
        } else {
            d->syncMainItemToSize();
        }
        d->resizeOrigin = DialogPrivate::Undefined;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const KPluginMetaData &md) {
                return md.serviceTypes().contains(QLatin1String("PlasmaCalendar/Plugin"));
            }
```

#### LAMBDA EXPRESSION 


```{c}
[=] {
            if (m_svgIcon) {
                m_svgIcon->setStatus(iconItem->status());
            }
        }
```

#### AUTO 


```{c}
const auto newDevicePixelRation = qMax<qreal>(1.0, floor(window() ? window()->devicePixelRatio() : qApp->devicePixelRatio()));
```

#### AUTO 


```{c}
auto it = m_localRectCache.find(id);
```

#### RANGE FOR STATEMENT 


```{c}
for (Containment *cont : std::as_const(d->containments)) {
        /* clang-format off */
        if (cont->lastScreen() == screen
            && (cont->activity().isEmpty() || cont->activity() == activity)
            && (cont->containmentType() == Plasma::Types::DesktopContainment
                || cont->containmentType() == Plasma::Types::CustomContainment)) { /* clang-format on */
            containment = cont;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool ready) { containmentReady(ready); }
```

#### AUTO 


```{c}
auto margin = frameSvgItem->margins();
```

#### AUTO 


```{c}
auto i = d->views.begin();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto a : actions) {

            if (a->shortcut().isEmpty()) {
                continue;
            }

            //this will happen on a normal, non emacs shortcut
            if (seq.matches(a->shortcut()) == QKeySequence::ExactMatch) {
                event->accept();
                a->trigger();
                m_oldKeyboardShortcut = 0;
                return true;

            //first part of an emacs style shortcut?
            } else if (seq.matches(a->shortcut()) == QKeySequence::PartialMatch) {
                keySequenceUsed = true;
                m_oldKeyboardShortcut = ke->key()|ke->modifiers();

            //no match at all, but it can be the second part of an emacs style shortcut
            } else {
                QKeySequence seq(m_oldKeyboardShortcut, ke->key()|ke->modifiers());

                if (seq.matches(a->shortcut()) == QKeySequence::ExactMatch) {
                    event->accept();
                    a->trigger();

                    return true;
                }
            }
        }
```

#### AUTO 


```{c}
auto it = plugins.constFind(pluginName);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            scheduleThemeChangeNotification(PixmapCache|SvgElementsCache);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[ = ]() {
                m_status = DialogStatus::Closed;
                Q_EMIT statusChanged();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const KConfigGroup &group, const QByteArrayList &names) {
            if (group.name() == QLatin1String("KDE") && names.contains(QByteArrayLiteral("AnimationDurationFactor"))) {
                updateAnimationSpeed();
            }
    }
```

#### AUTO 


```{c}
auto filter = [&mimeType](const KPluginMetaData &md) -> bool
    {
        return md.serviceTypes().contains(QLatin1String("Plasma/Containment"))
            && KPluginMetaData::readStringList(md.rawData(), QStringLiteral("X-Plasma-DropMimeTypes")).contains(mimeType);
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (SignalRelay *relay : relays) {
            relay->checkQueueing();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=] {
                    if (q->containment()) {
                        emit q->containment()->appletAlternativesRequested(q);
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &source : std::as_const(m_connectedSources)) {
        if (!sources.contains(source)) {
            m_data->clear(source);
            sourcesChanged = true;
            if (m_dataEngine) {
                m_dataEngine->disconnectSource(source, this);
                Q_EMIT sourceDisconnected(source);
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool configurationRequired, const QString &reason) {
        Q_UNUSED(configurationRequired);
        Q_UNUSED(reason);
        Q_EMIT configurationRequiredChanged();
        Q_EMIT configurationRequiredReasonChanged();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        if (!isEnabled()) {
            stopRedirecting();
        } else if (isVisible()) {
            startRedirecting();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto cont : containments) {
        switch (cont->id()) {
        case 1:
            QCOMPARE(cont->applets().count(), 2);
            break;
        default:
            QCOMPARE(cont->applets().count(), 0);
            break;
        }
    }
```

#### AUTO 


```{c}
auto filter = [&language](const KPluginMetaData &md) -> bool
    {
        return md.value("X-Plasma-API") == language;
    };
```

#### AUTO 


```{c}
const auto& dir
```

#### RANGE FOR STATEMENT 


```{c}
for (auto plugin : allApplets) {
        if (plugin.category().isEmpty()) {
            if (!categories.contains(i18nc("misc category", "Miscellaneous"))) {
                categories << i18nc("misc category", "Miscellaneous");
            }
        } else {
            categories << plugin.category();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QFileInfo &file : files) {
                if (currentCacheFileName.isEmpty() ||
                        !file.absoluteFilePath().endsWith(currentCacheFileName)) {
                    QFile::remove(file.absoluteFilePath());
                }
            }
```

#### AUTO 


```{c}
auto match = matchIt.next();
```

#### AUTO 


```{c}
auto &elements = m_invalidElements[path];
```

#### RANGE FOR STATEMENT 


```{c}
for (QScreen *screen : QGuiApplication::screens()) {
        screenAdded(screen);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Plasma::Containment *cont : m_corona->containments()) {
        QCOMPARE(cont->immutability(), Plasma::Types::UserImmutable);
        for (Plasma::Applet *app : cont->applets()) {
            QCOMPARE(app->immutability(), Plasma::Types::UserImmutable);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, packagePath, structure, posi](KJob *job) {
                        auto fail = [job](const QString &text) {
                            KNotification::event(QStringLiteral("plasmoidInstallationFailed"), i18n("Package Installation Failed"),
                                                 text, QStringLiteral("dialog-error"), 0, KNotification::CloseOnTimeout, QStringLiteral("plasma_workspace"));
                        };

                        // if the applet is already installed, just add it to the containment
                        if (job->error() != KJob::NoError
                            && job->error() != Package::PackageAlreadyInstalledError
                            && job->error() != Package::NewerVersionAlreadyInstalledError) {
                            fail(job->errorText());
                            return;
                        }

                        using namespace KPackage;
                        Package package(structure);
                        // TODO how can I get the path of the actual package?

                        package.setPath(packagePath);

                        // TODO how can I get the plugin id? Package::metadata() is deprecated
                        if (!package.isValid() || !package.metadata().isValid()) {
                            fail(i18n("The package you just dropped is invalid."));
                            return;
                        }

                        createApplet(package.metadata().pluginId(), QVariantList(), QRect(posi, QSize(-1,-1)));
                    }
```

#### AUTO 


```{c}
const auto &eventDatas = data(index.parent(), Roles::Events).value<QList<CalendarEvents::EventData>>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVector<QVariant> &v : std::as_const(m_items)) {
        count += v.count();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            m_waylandShmPool->deleteLater();
        }
```

#### AUTO 


```{c}
auto filter = [&name](const KPluginMetaData &md) -> bool {
        return md.pluginId() == name;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[&mimeType](const KPluginMetaData &md) -> bool
    {
        return md.value("X-Plasma-DropMimeTypes").contains(mimeType);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[excluded, parentApp](const KPluginMetaData &md) -> bool
        {
            const QString pa = md.value(QStringLiteral("X-KDE-ParentApp"));
            return (pa.isEmpty() || pa == parentApp) && !excluded.contains(md.category());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &theme : qAsConst(fallbackThemes)) {
            QString metadataPath(QStandardPaths::locate(QStandardPaths::GenericDataLocation, QStringLiteral(PLASMA_RELATIVE_DATA_INSTALL_DIR "/desktoptheme/") % theme % QStringLiteral("/metadata.desktop")));
            KConfig metadata(metadataPath, KConfig::SimpleConfig);
            processWallpaperSettings(&metadata);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Applet *a : std::as_const(applets)) {
            /*Why qMin?
             * the applets immutability() is the maximum between internal applet immutability
             * and the immutability of its containment.
             * so not set higher immutability in the internal member of Applet
             * or the applet will not be able to be unlocked properly
             */
            a->setImmutability(qMin(q->immutability(), a->d->immutability));
            a->updateConstraints(Types::ImmutableConstraint);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Plasma::Containment *c : std::as_const(containments)) {
        c->save(dummy);
        c->config().reparent(&dest);

        // ensure the containment is unlocked
        // this is done directly because we have to bypass any Types::SystemImmutable checks
        c->Applet::d->immutability = Types::Mutable;
        const auto lstApplet = c->applets();
        for (Applet *a : lstApplet) {
            a->d->immutability = Types::Mutable;
        }

        c->destroy();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Plasma::Containment *cont : m_corona->containments()) {
        QCOMPARE(cont->immutability(), Plasma::Types::SystemImmutable);
        for (Plasma::Applet *app : cont->applets()) {
            QCOMPARE(app->immutability(), Plasma::Types::SystemImmutable);
        }
    }
```

#### AUTO 


```{c}
auto i = m_items.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &token : encoded) {
            const auto &parts = token.split(QLatin1Char('x'));
            if (parts.size() != 2) {
                continue;
            }
            QSize size = QSize(parts[0].toDouble(), parts[1].toDouble());
            if (!size.isEmpty()) {
                sizes << size;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &info : qAsConst(wallpaperList)) {
                    const QString actionText = i18nc("Set wallpaper", "Set %1", info.name());
                    QAction *action = new QAction(actionText, m_dropMenu);
                    if (!info.iconName().isEmpty()) {
                        action->setIcon(QIcon::fromTheme(info.iconName()));
                    }
                    m_dropMenu->addAction(action);
                    actionsToWallpapers.insert(action, info.pluginId());
                    const QUrl url = tjob->url();
                    connect(action, &QAction::triggered, this, [this, url]() {
                        //set wallpapery stuff
                        if (m_wallpaperInterface && url.isValid()) {
                            m_wallpaperInterface->setUrl(url);
                        }
                    });
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginInfo &p : qAsConst(list)) {
        knownPlugins.insert(p.pluginName());
    }
```

#### AUTO 


```{c}
auto filter = [&parentApp](const KPluginMetaData &md) -> bool
    {
        const QString pa = md.value(QStringLiteral("X-KDE-ParentApp"));
        return (pa.isEmpty() || pa == parentApp) && !KPluginMetaData::readStringList(md.rawData(), QStringLiteral("X-Plasma-DropUrlPatterns")).isEmpty();
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &pluginPath) {
            KPluginMetaData metadata(pluginPath);
            if (!metadata.isValid()) {
                qCDebug(LOG_PLASMA) << "invalid metadata" << pluginPath;
                return;
            }

            plugins[metadata.pluginId()].append(metadata);
        }
```

#### AUTO 


```{c}
auto filter = [&category, &parentApp](const KPluginMetaData &md) -> bool
        {
            const QString pa = md.value(QStringLiteral("X-KDE-ParentApp"));
            if (category == QLatin1String("Miscellaneous")) {
                return (pa.isEmpty() || pa == parentApp) && (md.category() == category || md.category().isEmpty());
            } else {
                return (pa.isEmpty() || pa == parentApp) && md.category() == category;
            }
        };
```

#### RANGE FOR STATEMENT 


```{c}
for (DataContainer *dc : lst) {
            out << "                * " << dc->objectName() << '\n';
            out << "                       Data count: " << dc->d->data.count() << '\n';
            out << "                       Stored: " << dc->isStorageEnabled() << " \n";
            const int directs = dc->receivers(SIGNAL(dataUpdated(QString, Plasma::DataEngine::Data)));
            if (directs > 0) {
                out << "                       Direction Connections: " << directs << " \n";
            }

            const int relays = dc->d->relays.count();
            if (relays > 0) {
                out << "                       Relays: " << dc->d->relays.count() << '\n';
                QString times;
                for (SignalRelay *relay : std::as_const(dc->d->relays)) {
                    times.append(QLatin1Char(' ') + QString::number(relay->m_interval));
                }
                out << "                       Relay Timeouts: " << times << " \n";
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&pluginName](const KPluginMetaData &data) {
                return data.pluginId() == pluginName;
            }
```

#### AUTO 


```{c}
const auto plugins = listAppletMetaData(category, parentApp);
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        requestSyncToMainItemSize(true);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QDate date : qAsConst(updatesList)) {
        const QModelIndex changedIndex = indexForDate(date);
        if (changedIndex.isValid()) {
            Q_EMIT dataChanged(changedIndex, changedIndex, {containsEventItems, containsMajorEventItems, containsMinorEventItems, EventColor});
        }
        Q_EMIT agendaUpdated(date);
    }
```

#### AUTO 


```{c}
auto emitChange = [this, c] {
        const int row = categories.indexOf(c);
        if (row > -1) {
            QModelIndex modelIndex = q->index(row);
            emit q->dataChanged(modelIndex, modelIndex);
        }
    };
```

#### AUTO 


```{c}
auto node = m_node;
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &text) {
                            KNotification::event(QStringLiteral("plasmoidInstallationFailed"), i18n("Package Installation Failed"),
                                                 text, QStringLiteral("dialog-error"), nullptr, KNotification::CloseOnTimeout, QStringLiteral("plasma_workspace"));
                        }
```

#### AUTO 


```{c}
auto filter = [packageFormat](const KPluginMetaData &md) -> bool {
            return md.value(QStringLiteral("X-KDE-PluginInfo-Name")) == packageFormat;
        };
```

#### RANGE FOR STATEMENT 


```{c}
for (QScreen *screen : screens) {
        //we check geometry() but then take availableGeometry()
        //to reliably check in which screen a position is, we need the full
        //geometry, including areas for panels
        if (screen->geometry().contains(pos)) {
            avail = screen->availableGeometry();
            break;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        setVisible(false);
    }
```

#### AUTO 


```{c}
const auto errors = d->qmlObject->mainComponent()->errors();
```

#### AUTO 


```{c}
auto item = qobject_cast<QQuickItem*>(oldGraphicObject)
```

#### RANGE FOR STATEMENT 


```{c}
for (auto c : containments()) {
        if (c->containmentType() == Plasma::Types::DesktopContainment) {
            // example of a shell without a wallpaper
            c->setWallpaper(QStringLiteral("null"));
            m_view->setContainment(c);
            if (QAction *removeAction = c->actions()->action(QStringLiteral("remove"))) {
                removeAction->deleteLater();
            }
            break;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=] () {
                restore();
                positionPanel();
            }
```

#### LAMBDA EXPRESSION 


```{c}
[&] {
        d->updateResizableEdges();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[action, desktopMenu] {
                if (action->menu()->windowHandle()) {
                    // Need to add the transient parent otherwise Qt will create a new toplevel
                    action->menu()->windowHandle()->setTransientParent(desktopMenu->windowHandle());
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[=] (Plasma::Applet *a) {
        if (Plasma::Applet *p = qobject_cast<Plasma::Applet *>(parent())) {
            Q_EMIT p->containment()->configureRequested(a);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        setVisible(false);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QFileInfo &file : files) {
            if (!file.absoluteFilePath().endsWith(svgElementsFileName)) {
                QFile::remove(file.absoluteFilePath());
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &name : qAsConst(m_actions)) {
        QAction *action = a->actions()->action(name);

        if (action) {
            actions << action;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto data : d->internalPackage->directories()) {
        dirs << data.constData();
    }
```

#### AUTO 


```{c}
const auto lstApplet = c->applets();
```

#### AUTO 


```{c}
auto appletParent = qobject_cast<Plasma::Applet *>(c->parent());
```

#### AUTO 


```{c}
auto filter = [&parentApp](const KPluginMetaData &md) -> bool
    {
        const QString pa = md.value(QStringLiteral("X-KDE-ParentApp"));
        return (pa.isEmpty() || pa == parentApp) && !md.value(QStringLiteral("X-Plasma-DropUrlPatterns")).isEmpty();
    };
```

#### AUTO 


```{c}
auto filter = [&provides](const KPluginMetaData &md) -> bool
                {
                    const QStringList provided = KPluginMetaData::readStringList(md.rawData(), QStringLiteral("X-Plasma-Provides"));
                    for (const QString &p : provides) {
                        if (provided.contains(p)) {
                            return true;
                        }
                    }
                    return false;
                };
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &group : groupList) {
        d->operationsMap[group][QStringLiteral("_name")] = group;
    }
```

#### AUTO 


```{c}
auto filter = [&pluginName](const KPluginMetaData &md) -> bool
    {
        return md.pluginId() == pluginName;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this](QObject *obj) {
        m_appletInterfaces.removeAll(obj);
    }
```

#### AUTO 


```{c}
auto fail = [](const QString &text) {
                            KNotification::event(QStringLiteral("plasmoidInstallationFailed"),
                                                 i18n("Package Installation Failed"),
                                                 text,
                                                 QStringLiteral("dialog-error"),
                                                 nullptr,
                                                 KNotification::CloseOnTimeout,
                                                 QStringLiteral("plasma_workspace"));
                        };
```

#### AUTO 


```{c}
const auto lst = engine->containerDict();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &format : formats) {
            const auto plugins = Plasma::PluginLoader::self()->listAppletMetaDataForMimeType(format);

            for (const auto &plugin : plugins) {
                if (seenPlugins.contains(plugin.pluginId())) {
                    continue;
                }

                seenPlugins.insert(plugin.pluginId(), plugin);
                pluginFormats.insert(plugin.pluginId(), format);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &dir : dirs)
            KPluginLoader::forEachPlugin(dir, insertIntoCache);
```

#### RANGE FOR STATEMENT 


```{c}
for (Containment *containment : qAsConst(containments)) {
        if (!containment->isUiReady() && containment->screen() >= 0) {
            ++containmentsStarting;
            QObject::connect(containment, &Plasma::Containment::uiReadyChanged, q, [this](bool ready) { containmentReady(ready); } );
        }
    }
```

#### AUTO 


```{c}
const auto keyList = cfg.keyList();
```

#### AUTO 


```{c}
auto it = m_sizeHintsForId.constFind(pathId);
```

#### AUTO 


```{c}
auto texture = m_frameSvg->window()->createTextureFromImage(image);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &plugin : plugins)
        languages << plugin.value(QStringLiteral("X-Plasma-API"));
```

#### AUTO 


```{c}
auto filter = [&parentApp](const KPluginMetaData &md) -> bool
    {
        const QString pa = md.value("X-KDE-ParentApp");
        return (pa.isEmpty() || pa == parentApp) && !md.value("X-Plasma-DropUrlPatterns").isEmpty();
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            m_waylandPlasmaShell->deleteLater();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto md : KPackage::PackageLoader::self()->findPackages("Plasma/Applet", QString(), filter)) {
            auto pi = KPluginInfo(KService::serviceByStorageId(md.metaDataFileName()));
            if (!pi.isValid()) {
                qCWarning(LOG_PLASMA) << "Could not load plugin info for plugin :" << md.pluginId() << "skipping plugin";
                continue;
            }
            list << pi;
        }
```

#### AUTO 


```{c}
const auto relays = d->relays;
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
                    setDestroyed(false);
                    if (!q->isContainment() && q->containment()) {
                        Plasma::Applet *containmentApplet = static_cast<Plasma::Applet *>(q->containment());
                        if (containmentApplet && containmentApplet->d->deleteNotificationTimer) {
                            Q_EMIT containmentApplet->destroyedChanged(false);
                            //when an applet gets transient, it's "systemimmutable"
                            Q_EMIT q->immutabilityChanged(q->immutability());
                            delete containmentApplet->d->deleteNotificationTimer;
                            containmentApplet->d->deleteNotificationTimer = nullptr;
                        }

                        //make sure the applets are sorted by id
                        auto position = std::lower_bound(q->containment()->d->applets.begin(), q->containment()->d->applets.end(), q, [](Plasma::Applet *a1,  Plasma::Applet *a2) {
                            return a1->id() < a2->id();
                        });
                        q->containment()->d->applets.insert(position, q);
                        Q_EMIT q->containment()->appletAdded(q);
                    }
                    if (deleteNotification) {
                        deleteNotification->close();
                    } else if (deleteNotificationTimer) {
                        deleteNotificationTimer->stop();
                        deleteNotificationTimer->deleteLater();
                        deleteNotificationTimer = nullptr;
                    }
                }
```

#### LAMBDA EXPRESSION 


```{c}
[ = ]() {
        //Tooltips always have all the borders
        // floating windows have all borders
        if (!(flags() & Qt::ToolTip) && d->location != Plasma::Types::Floating) {
            d->resizeOrigin = DialogPrivate::Window;
            d->requestSizeSync(true);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QDate date : qAsConst(updatesList)) {
        const QModelIndex changedIndex = indexForDate(date);
        if (changedIndex.isValid()) {
            Q_EMIT dataChanged(changedIndex, changedIndex,
                               {containsEventItems, containsMajorEventItems, containsMinorEventItems});
        }
        Q_EMIT agendaUpdated(date);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        d->slotWindowPositionChanged();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &filePath, unsigned int lastModified) {
        if (d->lastModified != lastModified && filePath == d->path) {
            d->lastModified = lastModified;
            Q_EMIT repaintNeeded();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &group : groupList) {
        KConfigGroup cg(&config, group);
        cg.deleteGroup();
    }
```

#### AUTO 


```{c}
const auto &key
```

#### AUTO 


```{c}
auto plugin = d->plasmoidCache.findPluginById(name, {PluginLoaderPrivate::s_plasmoidsPluginDir, {}});
```

#### AUTO 


```{c}
static const auto source = QStringLiteral("Europe/Sofia");
```

#### LAMBDA EXPRESSION 


```{c}
[this, posi, packagePath]() {
                    using namespace KPackage;
                    PackageStructure *structure = PackageLoader::self()->loadPackageStructure(QStringLiteral("Plasma/Applet"));
                    Package package(structure);

                    KJob *installJob = package.update(packagePath);
                    connect(installJob, &KJob::result, this, [this, packagePath, structure, posi](KJob *job) {
                        auto fail = [job](const QString &text) {
                            KNotification::event(QStringLiteral("plasmoidInstallationFailed"), i18n("Package Installation Failed"),
                                                 text, QStringLiteral("dialog-error"), nullptr, KNotification::CloseOnTimeout, QStringLiteral("plasma_workspace"));
                        };

                        // if the applet is already installed, just add it to the containment
                        if (job->error() != KJob::NoError
                            && job->error() != Package::PackageAlreadyInstalledError
                            && job->error() != Package::NewerVersionAlreadyInstalledError) {
                            fail(job->errorText());
                            return;
                        }

                        using namespace KPackage;
                        Package package(structure);
                        // TODO how can I get the path of the actual package?

                        package.setPath(packagePath);

                        // TODO how can I get the plugin id? Package::metadata() is deprecated
                        if (!package.isValid() || !package.metadata().isValid()) {
                            fail(i18n("The package you just dropped is invalid."));
                            return;
                        }

                        createApplet(package.metadata().pluginId(), QVariantList(), QRect(posi, QSize(-1,-1)));
                    });
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *a : qAsConst(listActions)) {
        if (!actionOrder.contains(a->objectName())) {
            //FIXME QML visualizations don't support menus for now, *and* there is no way to
            //distinguish them on QML side
            if (!a->menu()) {
                actions.insert(a->data().toInt()*100 + i, a);
                ++i;
            }
        } else {
            orderedActions[a->objectName()] = a;
        }
    }
```

#### AUTO 


```{c}
auto filter = [&type, &category, &parentApp](const KPluginMetaData &md) -> bool
    {
        if (!md.serviceTypes().contains(QLatin1String("Plasma/Containment"))) {
            return false;
        }
        if (!parentApp.isEmpty() && md.value(QStringLiteral("X-KDE-ParentApp")) != parentApp) {
            return false;
        }

        if (!type.isEmpty() && md.value(QStringLiteral("X-Plasma-ContainmentType")) != type) {
            return false;
        }

        if (!category.isEmpty() && md.value(QStringLiteral("X-KDE-PluginInfo-Category")) != category) {
            return false;
        }

        return true;
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVector<QVariant> &v : qAsConst(m_items)) {
        count += v.count();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, packagePath, structure, posi](KJob *job) {
                        auto fail = [job](const QString &text) {
                            KNotification::event(QStringLiteral("plasmoidInstallationFailed"), i18n("Package Installation Failed"),
                                                 text, QStringLiteral("dialog-error"), nullptr, KNotification::CloseOnTimeout, QStringLiteral("plasma_workspace"));
                        };

                        // if the applet is already installed, just add it to the containment
                        if (job->error() != KJob::NoError
                            && job->error() != Package::PackageAlreadyInstalledError
                            && job->error() != Package::NewerVersionAlreadyInstalledError) {
                            fail(job->errorText());
                            return;
                        }

                        using namespace KPackage;
                        Package package(structure);
                        // TODO how can I get the path of the actual package?

                        package.setPath(packagePath);

                        // TODO how can I get the plugin id? Package::metadata() is deprecated
                        if (!package.isValid() || !package.metadata().isValid()) {
                            fail(i18n("The package you just dropped is invalid."));
                            return;
                        }

                        createApplet(package.metadata().pluginId(), QVariantList(), QRect(posi, QSize(-1,-1)));
                    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
                    transient = false;
                    if (!q->isContainment() && q->containment()) {
                        Plasma::Applet *containmentApplet = static_cast<Plasma::Applet *>(q->containment());
                        if (containmentApplet && containmentApplet->d->deleteNotificationTimer) {
                            emit containmentApplet->destroyedChanged(false);
                            //when an applet gets transient, it's "systemimmutable"
                            emit q->immutabilityChanged(q->immutability());
                            delete containmentApplet->d->deleteNotificationTimer;
                            containmentApplet->d->deleteNotificationTimer = 0;
                        }

                        //make sure the applets are sorted by id
                        auto position = std::lower_bound(q->containment()->d->applets.begin(), q->containment()->d->applets.end(), q, [](Plasma::Applet *a1,  Plasma::Applet *a2) {
                            return a1->id() < a2->id();
                        });
                        q->containment()->d->applets.insert(position, q);
                        emit q->containment()->appletAdded(q);
                    }
                    emit q->destroyedChanged(false);
                    //when an applet gets transient, it's "systemimmutable"
                    emit q->immutabilityChanged(q->immutability());
                    if (deleteNotification) {
                        deleteNotification->close();
                    }
                    if (deleteNotificationTimer) {
                        delete deleteNotificationTimer;
                        deleteNotificationTimer = 0;
                    }
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this, x, y, mimeData, action]() {
                    const QString selectedPlugin = action->data().toString();
                    Plasma::Applet *applet = createApplet(selectedPlugin, QVariantList(), QRect(x, y, -1, -1));
                    setAppletArgs(applet, selectedPlugin, QString::fromUtf8(mimeData->data(selectedPlugin)));
                }
```

#### AUTO 


```{c}
auto filter = [&provides](const KPluginMetaData &md) -> bool
            {
                foreach (const QString &p, provides) {
                    if (md.value("X-Plasma-Provides").contains(p)) {
                        return true;
                    }
                }
                return false;
            };
```

#### LAMBDA EXPRESSION 


```{c}
[ = ]() {
                delete m_activityInfo;
                m_activityInfo = new KActivities::Info(m_containment->activity(), this);
                connect(m_activityInfo, &KActivities::Info::nameChanged,
                        this, &ContainmentInterface::activityNameChanged);
                emit activityNameChanged();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto plugin : plugins) {
        const QString componentTypes = plugin.value(QStringLiteral("X-Plasma-ComponentTypes"));
        if (((types & Types::AppletComponent)     && componentTypes == QLatin1String("Applet"))
          ||((types & Types::DataEngineComponent) && componentTypes == QLatin1String("DataEngine"))) {
            languages << plugin.value(QStringLiteral("X-Plasma-API"));
        }
    }
```

#### AUTO 


```{c}
const auto lstApplets = asContainment->applets();
```

#### RANGE FOR STATEMENT 


```{c}
for (Applet *a : lstApplets) {
            a->d->setDestroyed(destroyed);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        if (!isVisible()) {
            stopRedirecting();
        } else if (isEnabled()) {
            startRedirecting();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &kcm : qAsConst(kcms)) {
            // Only look for KCMs in the "kcms_" folder where new QML KCMs live
            // because we don't support loading QWidgets KCMs
            KPluginMetaData md(QLatin1String("kcms/") + kcm);

            if (!md.isValid()) {
                qWarning() << "Could not find" << kcm
                           << "requested by X-Plasma-ConfigPlugins. Ensure that it exists, is a QML KCM, and lives in the 'kcms/' subdirectory.";
                continue;
            }

            configModel->appendCategory(md.iconName(), md.name(), QString(), QLatin1String("kcms/") + kcm);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
                    setDestroyed(false);
                    if (!q->isContainment() && q->containment()) {
                        Plasma::Applet *containmentApplet = static_cast<Plasma::Applet *>(q->containment());
                        if (containmentApplet && containmentApplet->d->deleteNotificationTimer) {
                            emit containmentApplet->destroyedChanged(false);
                            //when an applet gets transient, it's "systemimmutable"
                            emit q->immutabilityChanged(q->immutability());
                            delete containmentApplet->d->deleteNotificationTimer;
                            containmentApplet->d->deleteNotificationTimer = 0;
                        }

                        //make sure the applets are sorted by id
                        auto position = std::lower_bound(q->containment()->d->applets.begin(), q->containment()->d->applets.end(), q, [](Plasma::Applet *a1,  Plasma::Applet *a2) {
                            return a1->id() < a2->id();
                        });
                        q->containment()->d->applets.insert(position, q);
                        emit q->containment()->appletAdded(q);
                    }
                    if (deleteNotification) {
                        deleteNotification->close();
                    } else if (deleteNotificationTimer) {
                        deleteNotificationTimer->stop();
                        deleteNotificationTimer->deleteLater();
                        deleteNotificationTimer = 0;
                    }
                }
```

#### AUTO 


```{c}
auto prefix = QStringLiteral("");
```

#### AUTO 


```{c}
auto *node = static_cast<WindowTextureNode*>(oldNode);
```

#### AUTO 


```{c}
auto *node = static_cast<WindowTextureNode *>(oldNode);
```

#### AUTO 


```{c}
auto filterNormal = [&category](const KPluginMetaData &md) -> bool
    {
        return md.value("X-KDE-PluginInfo-Category") == category;
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const CalendarEvents::EventData &event : std::as_const(events)) {
        m_qmlData << new EventDataDecorator(event, this);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &glob : urlPatterns) {
            QRegExp rx(glob);
            rx.setPatternSyntax(QRegExp::Wildcard);
            if (rx.exactMatch(url.toString())) {
                filtered << md;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        updateConstraints(Plasma::Types::UiReadyConstraint);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &d : dirList ) {
        QString dst_path = dst + QLatin1Char('/') + d;
        dir.mkpath(dst_path);
        copyPath(src + QLatin1Char('/') + d, dst_path);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto data : d->internalPackage->requiredFiles()) {
        files << data.constData();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Plasma::Containment *cont : std::as_const(containments)) {
        QCOMPARE(cont->immutability(), Plasma::Types::SystemImmutable);
        const auto lstApplets = cont->applets();
        for (Plasma::Applet *app : lstApplets) {
            QCOMPARE(app->immutability(), Plasma::Types::SystemImmutable);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &engine : std::as_const(d->loadedEngines)) {
        DataEngineManager::self()->unloadEngine(engine);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &md : allApplets) {
        const QStringList urlPatterns = KPluginMetaData::readStringList(md.rawData(), QStringLiteral("X-Plasma-DropUrlPatterns"));
        for (const QString &glob : urlPatterns) {
            QRegExp rx(glob);
            rx.setPatternSyntax(QRegExp::Wildcard);
            if (rx.exactMatch(url.toString())) {
#ifndef NDEBUG
                // qCDebug(LOG_PLASMA) << md.name() << "matches" << glob << url;
#endif
                filtered << md;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto a : d->desktopContainments) {
            QMutableHashIterator<int, Plasma::Containment *> it(a);
            while (it.hasNext()) {
                it.next();
                if (it.value() == containment) {
                    it.remove();
                    return;
                }
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        d->requestSyncToMainItemSize(true);
    }
```

#### AUTO 


```{c}
const auto directories = d->internalPackage->requiredDirectories();
```

#### LAMBDA EXPRESSION 


```{c}
[ = ]() {
        if (!d->applet->isContainment()) {
            KConfigGroup cg = d->applet->config();
            cg = KConfigGroup(&cg, "PopupApplet");
            cg.writeEntry("DialogWidth", d->fullRepresentationItem->width());
            cg.writeEntry("DialogHeight", d->fullRepresentationItem->height());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &dir : dirs) {
            const auto metaDataList = KPluginMetaData::findPlugins(dir);
            for (const KPluginMetaData &metadata : metaDataList) {
                plugins.insert(metadata.pluginId(), metadata);
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
                    transient = false;
                    emit q->destroyedChanged(false);
                    if (!q->isContainment() && q->containment()) {
                        //make sure the applets are sorted by id
                        auto position = std::lower_bound(q->containment()->d->applets.begin(), q->containment()->d->applets.end(), q, [](Plasma::Applet *a1,  Plasma::Applet *a2) {
                            return a1->id() < a2->id();
                        });
                        q->containment()->d->applets.insert(position, q);
                        emit q->containment()->appletAdded(q);
                    }
                    if (deleteNotification) {
                        deleteNotification->close();
                    }
                    if (deleteNotificationTimer) {
                        delete deleteNotificationTimer;
                        deleteNotificationTimer = 0;
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const qint64 id : lst) {
            m_model->m_childItems[destParent.internalId()][column].insert(d++, id);
        }
```

#### AUTO 


```{c}
auto filter = [&parentApp, &excluded, visibleOnly](const KPluginMetaData &md) -> bool
    {
        const QString pa = md.value(QStringLiteral("X-KDE-ParentApp"));
        return (parentApp.isEmpty() || pa == parentApp)
            && (excluded.isEmpty() || excluded.contains(md.value(QStringLiteral("X-KDE-PluginInfo-Category"))))
            && (!visibleOnly || !md.isHidden());
    };
```

#### LAMBDA EXPRESSION 


```{c}
[=] () {
                restore();
            }
```

#### LAMBDA EXPRESSION 


```{c}
[&mimetype, &formFactor](const KPluginMetaData &md) -> bool
    {
        if (!formFactor.isEmpty() && !md.value(QStringLiteral("X-Plasma-FormFactors")).contains(formFactor)) {
            return false;
        }
        return KPluginMetaData::readStringList(md.rawData(), QStringLiteral("X-Plasma-DropMimeTypes")).contains(mimetype);
    }
```

