#### LAMBDA EXPRESSION 


```{c}
[p]() {
        QWidget *desktop = QApplication::desktop();
        QPixmap pm = QPixmap::grabWindow(desktop->winId(), p.x(), p.y(), 1, 1);
        QImage i = pm.toImage();
        return i.pixel(0, 0);
    }
```

#### AUTO 


```{c}
auto it = d->_licenseList.constBegin();
```

#### AUTO 


```{c}
auto fallback = [p]() {
        QWidget *desktop = QApplication::desktop();
        QPixmap pm = QPixmap::grabWindow(desktop->winId(), p.x(), p.y(), 1, 1);
        QImage i = pm.toImage();
        return i.pixel(0, 0);
    };
```

