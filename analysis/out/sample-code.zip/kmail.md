#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Collection &col : qAsConst(mCollectionId)) {
                lst << col.id();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &attach : lst) {
                MessageComposer::ConvertSnippetVariablesJob *job = new MessageComposer::ConvertSnippetVariablesJob(this);
                job->setText(attach);
                MessageComposer::ComposerViewInterface *interface = new MessageComposer::ComposerViewInterface(mComposerBase);
                job->setComposerViewInterface(interface);
                connect(job, &MessageComposer::ConvertSnippetVariablesJob::textConverted, this, [this](const QString &str) {
                    if (!str.isEmpty()) {
                        const QUrl localUrl = QUrl::fromLocalFile(str);
                        AttachmentInfo info;
                        info.url = localUrl;
                        addAttachment(QVector<AttachmentInfo>() << info, false);
                    }
                });
                job->start();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &account : accountList) {
        KConfigGroup group = config.group(account);
        auto info = new FolderArchiveAccountInfo(group);
        if (info->enabled()) {
            mListAccountInfo.append(info);
        } else {
            delete info;
        }
    }
```

#### AUTO 


```{c}
const auto &mailboxIt
```

#### AUTO 


```{c}
auto subMenu = new QMenu;
```

#### AUTO 


```{c}
auto command = new KMReplyCommand(this, currentItem, strategy, text);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &boxIt : mBoxManager) {
        const auto &box = boxIt.second;
        Akonadi::Collection col;
        col.setName(box->id());
        col.setRemoteId(box->id());
        col.setParentCollection(topLevel);
        col.setContentMimeTypes({Common::MailMimeType});
        col.setRights(Akonadi::Collection::CanChangeItem | Akonadi::Collection::CanDeleteItem);
        col.setVirtual(true);
        auto displayAttr = col.attribute<Akonadi::EntityDisplayAttribute>(Akonadi::Collection::AddIfMissing);
        displayAttr->setDisplayName(box->name());
        displayAttr->setIconName(box->icon());
        collections.push_back(std::move(col));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : items) {
            QString attachmentName = QStringLiteral("attachment");
            if (item.hasPayload<KContacts::Addressee>()) {
                const KContacts::Addressee contact = item.payload<KContacts::Addressee>();
                attachmentName = contact.realName() + QLatin1String(".vcf");
                //Workaround about broken kaddressbook fields.
                QByteArray data = item.payloadData();
                KContacts::adaptIMAttributes(data);
                addAttachment(attachmentName, KMime::Headers::CEbase64, QString(), data, "text/x-vcard");
            } else if (item.hasPayload<KContacts::ContactGroup>()) {
                const KContacts::ContactGroup group = item.payload<KContacts::ContactGroup>();
                attachmentName = group.name() + QLatin1String(".vcf");
                auto *expandJob = new Akonadi::ContactGroupExpandJob(group, this);
                expandJob->setProperty("groupName", attachmentName);
                connect(expandJob, &KJob::result, this, &KMComposerWin::slotExpandGroupResult);
                expandJob->start();
            } else {
                addAttachment(attachmentName, KMime::Headers::CEbase64, QString(), item.payloadData(), item.mimeType().toLatin1());
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto a : std::as_const(mFilterFolderMenuActions)) {
        a->setEnabled(folderIsValid);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const UnifiedMailbox *box) {
                if (!box->collectionId()) {
                    qCWarning(agent_log) << "MailboxManager wants us to update Box but does not have its CollectionId!?";
                    return;
                }

                // Schedule collection sync for the box
                synchronizeCollection(box->collectionId().value());
            }
```

#### AUTO 


```{c}
auto *enabledByDefaultCB = findChild<QCheckBox *>(QStringLiteral("kcfg_autodetectLanguage"));
```

#### AUTO 


```{c}
auto action = new QAction(i18nc("View->", "C&ollapse All Threads"), this);
```

#### AUTO 


```{c}
auto duplicateExistingVCard = new QRadioButton(i18n("&Duplicate existing vCard"), this);
```

#### AUTO 


```{c}
auto info = new ArchiveMailInfo;
```

#### LAMBDA EXPRESSION 


```{c}
[](const KPluginMetaData &data) {
        return data.rawData().value(QStringLiteral("X-KDE-KontactPluginVersion")).toInt() == KONTACT_PLUGIN_VERSION;
    }
```

#### AUTO 


```{c}
const auto msg = item.payload<KMime::Message::Ptr>();
```

#### AUTO 


```{c}
const auto &srcRid
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Akonadi::Collection::List &list) {
                for (const auto &col : list) {
                    if (!isUnifiedMailbox(col) || col.parentCollection() == Akonadi::Collection::root()) {
                        continue;
                    }

                    mMailboxes.at(col.name())->setCollectionId(col.id());
                }
            }
```

#### AUTO 


```{c}
auto tab = qobject_cast<ConfigModuleTab *>(mTabWidget->widget(i));
```

#### AUTO 


```{c}
auto command = new KMReplyCommand(this, item, replyToAll ? MessageComposer::ReplyAll : MessageComposer::ReplyAuthor);
```

#### AUTO 


```{c}
const auto group = config()->group(myConfigGroupName);
```

#### RANGE FOR STATEMENT 


```{c}
for (MessageComposer::PluginEditorInterface *interface : qAsConst(mListPluginInterface)) {
            if (interface->plugin()->hasStatusBarSupport()) {
                mStatusBarWidget.append(interface->statusBarWidget());
            }
        }
```

#### AUTO 


```{c}
auto *subMenu = qobject_cast<KSelectAction *>(action);
```

#### RANGE FOR STATEMENT 


```{c}
for (FolderArchiveAccountInfo *info : qAsConst(mListAccountInfo)) {
        if (info->instanceName() == instanceName) {
            return info;
        }
    }
```

#### AUTO 


```{c}
auto ifj = new Akonadi::ItemFetchJob{
            Akonadi::Collection{
                id
            }, this
        };
```

#### AUTO 


```{c}
auto *listWidgetSearchLine = new KListWidgetSearchLine(this, mListTag);
```

#### AUTO 


```{c}
auto action = new QAction(i18n("Focus on First Folder"), this);
```

#### AUTO 


```{c}
auto *tageditgrid = new QVBoxLayout(mTagsGroupBox);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Collection &collection : kmkernel->allFolders()) {
                    KConfigGroup config(KMKernel::self()->config(), MailCommon::FolderSettings::configGroupName(collection));
                    //Old config
                    config.deleteEntry("htmlMailOverride");
                    config.deleteEntry("displayFormatOverride");
                    MailCommon::FolderSettings::resetHtmlFormat();
                }
```

#### AUTO 


```{c}
auto groupGridLayout = new QGridLayout();
```

#### AUTO 


```{c}
auto saveDraftJob = new SaveDraftJob(mMsg, mFolder);
```

#### AUTO 


```{c}
auto *ldapCompletionTab = new LdapCompetionTab();
```

#### AUTO 


```{c}
auto command = new KMSetStatusCommand(status, select, toggle);
```

#### AUTO 


```{c}
const auto col = sourceModel()->data(sourceIndex, Akonadi::EntityTreeModel::CollectionRole).value<Akonadi::Collection>();
```

#### RANGE FOR STATEMENT 


```{c}
for (MessageComposer::PluginEditor *plugin : lstPlugin) {
        if (plugin->isEnabled()) {
            MessageComposer::PluginEditorInterface *interface = static_cast<MessageComposer::PluginEditorInterface *>(plugin->createInterface(this));
            interface->setRichTextEditor(mRichTextEditor);
            interface->setParentWidget(mParentWidget);
            interface->createAction(mActionCollection);
            interface->setPlugin(plugin);
            connect(interface, &MessageComposer::PluginEditorInterface::emitPluginActivated, this, &KMailPluginEditorManagerInterface::slotPluginActivated);
            connect(interface, &MessageComposer::PluginEditorInterface::message, this, &KMailPluginEditorManagerInterface::message);
            connect(interface, &MessageComposer::PluginEditorInterface::insertText, this, &KMailPluginEditorManagerInterface::insertText);
            mListPluginInterface.append(interface);
        }
    }
```

#### AUTO 


```{c}
auto folderLabel = new QLabel(i18n("&Folder:"), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &srcRid : sourceRids) {
        const auto srcCol = collectionForRid(srcRid);
        AKVERIFY_RET(srcCol, {});
        mailbox->addSourceCollection(srcCol->id());
    }
```

#### AUTO 


```{c}
auto *act = new QAction(topMenu);
```

#### RANGE FOR STATEMENT 


```{c}
for (MessageComposer::PluginEditorConvertTextInterface *interface : std::as_const(mListPluginInterface)) {
        interface->setBeforeConvertingData(data);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const MailCommon::Tag::Ptr &tag : tags) {
                if (tag->id() == it.key()) {
                    label = tag->name();
                    break;
                }
            }
```

#### AUTO 


```{c}
auto job = new Akonadi::ItemCopyJob(mMsg, collection, this);
```

#### AUTO 


```{c}
const auto inbox = createUnifiedMailbox(Common::InboxBoxId, QStringLiteral("Inbox"),
                                            { QStringLiteral("res1_inbox"), QStringLiteral("res2_inbox") });
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : items) {
            QString attachmentName = QStringLiteral("attachment");
            if (item.hasPayload<KContacts::Addressee>()) {
                const KContacts::Addressee contact = item.payload<KContacts::Addressee>();
                attachmentName = contact.realName() + QLatin1String(".vcf");
                //Workaround about broken kaddressbook fields.
                QByteArray data = item.payloadData();
                KContacts::adaptIMAttributes(data);
                addAttachment(attachmentName, KMime::Headers::CEbase64, QString(), data, "text/x-vcard");
            } else if (item.hasPayload<KContacts::ContactGroup>()) {
                const KContacts::ContactGroup group = item.payload<KContacts::ContactGroup>();
                attachmentName = group.name() + QLatin1String(".vcf");
                auto expandJob = new Akonadi::ContactGroupExpandJob(group, this);
                expandJob->setProperty("groupName", attachmentName);
                connect(expandJob, &KJob::result, this, &KMComposerWin::slotExpandGroupResult);
                expandJob->start();
            } else {
                addAttachment(attachmentName, KMime::Headers::CEbase64, QString(), item.payloadData(), item.mimeType().toLatin1());
            }
        }
```

#### AUTO 


```{c}
auto job = new HandleClickedUrlJob;
```

#### AUTO 


```{c}
auto item = new QTreeWidgetItem(lv, QStringList(i18nc("@label", "TNEF Attributes")));
```

#### AUTO 


```{c}
auto wid = new QWidget;
```

#### AUTO 


```{c}
auto item = dynamic_cast<IdentityListViewItem *>(mIPage.mIdentityList->topLevelItem(i));
```

#### AUTO 


```{c}
const auto standardActions = {
        StandardActionManager::CreateCollection,
        StandardActionManager::CopyCollections,
        StandardActionManager::DeleteCollections,
        StandardActionManager::SynchronizeCollections,
        StandardActionManager::CollectionProperties,
        StandardActionManager::CopyItems,
        StandardActionManager::Paste,
        StandardActionManager::DeleteItems,
        StandardActionManager::ManageLocalSubscriptions,
        StandardActionManager::CopyCollectionToMenu,
        StandardActionManager::CopyItemToMenu,
        StandardActionManager::MoveItemToMenu,
        StandardActionManager::MoveCollectionToMenu,
        StandardActionManager::CutItems,
        StandardActionManager::CutCollections,
        StandardActionManager::CreateResource,
        StandardActionManager::DeleteResources,
        StandardActionManager::ResourceProperties,
        StandardActionManager::SynchronizeResources,
        StandardActionManager::ToggleWorkOffline,
        StandardActionManager::SynchronizeCollectionsRecursive,
    };
```

#### AUTO 


```{c}
auto actionGroup = new QActionGroup(menu);
```

#### AUTO 


```{c}
auto *mailItem = static_cast<ArchiveMailItem *>(mWidget.treeWidget->topLevelItem(i));
```

#### AUTO 


```{c}
auto *handle = new WinObjPatternBrushHandle;
```

#### AUTO 


```{c}
auto job = new CreateNewContactJob(this, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &group : filterGroups) {
        mConfig->deleteGroup(group);
    }
```

#### AUTO 


```{c}
auto *fontsTab = new FontsTab();
```

#### AUTO 


```{c}
auto *model = new Akonadi::ContactsTreeModel(changeRecorder, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &msg : msgList) {
            auto cacheIt = cache.find(msg.storageCollectionId());
            if (cacheIt == cache.end()) {
                cacheIt = cache.insert(msg.storageCollectionId(), findTrashFolder(CommonKernel->collectionFromId(msg.storageCollectionId())));
            }
            auto trashIt = mTrashFolders.find(*cacheIt);
            if (trashIt == mTrashFolders.end()) {
                trashIt = mTrashFolders.insert(*cacheIt, {});
            }
            trashIt->push_back(msg);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (MessageComposer::SendLaterInfo *info : std::as_const(mListSendLaterInfo)) {
            if (!infoStr.isEmpty()) {
                infoStr += QLatin1Char('\n');
            }
            infoStr += infoToStr(info);
        }
```

#### AUTO 


```{c}
auto layAttachment = new QHBoxLayout;
```

#### AUTO 


```{c}
auto searchJob = new Akonadi::SearchCreateJob(searchString, mQuery, this);
```

#### AUTO 


```{c}
const auto allFolders = kmkernel->allFolders();
```

#### RANGE FOR STATEMENT 


```{c}
for (MessageComposer::PluginEditorConvertTextInterface *interface : qAsConst(mListPluginInterface)) {
        switch (interface->convertTextToFormat(textPart)) {
        case MessageComposer::PluginEditorConvertTextInterface::ConvertTextStatus::NotConverted:
            if (status != MessageComposer::PluginEditorConvertTextInterface::ConvertTextStatus::Converted) {
                status = MessageComposer::PluginEditorConvertTextInterface::ConvertTextStatus::NotConverted;
            }
            break;
        case MessageComposer::PluginEditorConvertTextInterface::ConvertTextStatus::Converted:
            status = MessageComposer::PluginEditorConvertTextInterface::ConvertTextStatus::Converted;
            break;
        case MessageComposer::PluginEditorConvertTextInterface::ConvertTextStatus::Error:
            status = MessageComposer::PluginEditorConvertTextInterface::ConvertTextStatus::Error;
            return status;
        }
    }
```

#### AUTO 


```{c}
auto *listWidget = dlg.findChild<QListWidget *>(QStringLiteral("list_widget"));
```

#### AUTO 


```{c}
inline auto end() const
    {
        return mMailboxes.end();
    }
```

#### AUTO 


```{c}
auto group = new QGroupBox(i18n("Common Options"), this);
```

#### AUTO 


```{c}
auto const organization = new KMime::Headers::Organization;
```

#### AUTO 


```{c}
auto *searchLabel = dlg.findChild<QLabel *>(QStringLiteral("label"));
```

#### AUTO 


```{c}
auto *item = static_cast<FollowUpReminderInfoItem *>(treeWidget->topLevelItem(i));
```

#### AUTO 


```{c}
auto *layout = new QGridLayout(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : items) {
            QString attachmentName = QStringLiteral("attachment");
            if (item.hasPayload<KContacts::Addressee>()) {
                const KContacts::Addressee contact = item.payload<KContacts::Addressee>();
                attachmentName = contact.realName() + QLatin1String(".vcf");
                // Workaround about broken kaddressbook fields.
                QByteArray data = item.payloadData();
                KContacts::adaptIMAttributes(data);
                addAttachment(attachmentName, KMime::Headers::CEbase64, QString(), data, "text/x-vcard");
            } else if (item.hasPayload<KContacts::ContactGroup>()) {
                const KContacts::ContactGroup group = item.payload<KContacts::ContactGroup>();
                attachmentName = group.name() + QLatin1String(".vcf");
                auto expandJob = new Akonadi::ContactGroupExpandJob(group, this);
                expandJob->setProperty("groupName", attachmentName);
                connect(expandJob, &KJob::result, this, &KMComposerWin::slotExpandGroupResult);
                expandJob->start();
            } else {
                addAttachment(attachmentName, KMime::Headers::CEbase64, QString(), item.payloadData(), item.mimeType().toLatin1());
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Collection &collection : list) {
        if (collection.isValid()) {
            if(collection.rights() & Akonadi::Collection::CanDeleteItem) {
                lst.append(collection);
            }
        }
    }
```

#### AUTO 


```{c}
auto *listboxgrid = new QHBoxLayout();
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &metaData : availablePlugins) {
        addModule(metaData);
    }
```

#### AUTO 


```{c}
auto encryption = w->findChild<QLabel *>(QStringLiteral("encryptionindicator"));
```

#### AUTO 


```{c}
auto job = new KMComposerCreateNewComposerJob;
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &str) {
                    if (!str.isEmpty()) {
                        const QUrl localUrl = QUrl::fromLocalFile(str);
                        addAttachment(localUrl, QString());
                    }
                }
```

#### AUTO 


```{c}
auto command = new KMForwardAttachedCommand(
        this, selectedMessages, mCurrentFolderSettings->identity()
        );
```

#### LAMBDA EXPRESSION 


```{c}
[&rid](const Akonadi::Collection &col) {
        return col.remoteId() == rid;
    }
```

#### AUTO 


```{c}
auto *job = new KMComposerCreateNewComposerJob;
```

#### AUTO 


```{c}
auto bgHTTPProxy = new QButtonGroup(this);
```

#### AUTO 


```{c}
auto command = new KMForwardCommand(
        this, selectedMessages, mCurrentFolderSettings->identity(), QString(), text
        );
```

#### AUTO 


```{c}
auto *lspacer = new QSpacerItem(1, 10,
                                    QSizePolicy::MinimumExpanding,
                                    QSizePolicy::MinimumExpanding);
```

#### RANGE FOR STATEMENT 


```{c}
for (QTreeWidgetItem *item : mailItemLst) {
                auto mailItem = static_cast<FollowUpReminderInfoItem *>(item);
                mListRemoveId << mailItem->info()->uniqueIdentifier();
                delete mailItem;
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this](uint val) {
        if (currentIdentity() == val) {
            slotIdentityChanged(val);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (MailCommon::MailFilter *filter : std::as_const(mFilters)) {
            if (filter->identifier() == filterId) {
                wantedFilter = filter;
                break;
            }
        }
```

#### AUTO 


```{c}
auto job = new Akonadi::CollectionCreateJob(collection);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        auto mailbox = std::make_unique<UnifiedMailbox>();
        auto editor = new UnifiedMailboxEditor(mailbox.get(), mConfig, this);
        if (editor->exec()) {
            mailbox->setId(mailbox->name()); // assign ID
            addBox(mailbox.get());
            mBoxManager.insertBox(std::move(mailbox));
            mBoxManager.saveBoxes();
        }
        delete editor;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&id](const UnifiedMailboxManager::Entry &e) {
                                return e.second->id() == id;
                            }
```

#### AUTO 


```{c}
auto tnef = new KTNEFMain();
```

#### AUTO 


```{c}
auto radio = new QRadioButton(i18n("&With empty fields"), this);
```

#### AUTO 


```{c}
const auto mainWinAction = manager->action(Akonadi::StandardActionManager::CopyItemToMenu);
```

#### AUTO 


```{c}
auto *dlg = new KSieveUi::SieveDebugDialog(&provider);
```

#### AUTO 


```{c}
auto job = new RemoveDuplicateMailJob(mFolderTreeWidget->folderTreeView()->selectionModel(), this, this);
```

#### AUTO 


```{c}
auto hbox = new QHBoxLayout(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Akonadi::Item &item, const Akonadi::Collection &collection) {
                ReplayNextOnExit replayNext(mMonitor);

                qCDebug(UNIFIEDMAILBOXAGENT_LOG) << "Item" << item.id() << "added to collection" << collection.id();
                const auto box = unifiedMailboxForSource(collection.id());
                if (!box) {
                    qCWarning(UNIFIEDMAILBOXAGENT_LOG) << "Failed to find unified mailbox for source collection " << collection.id();
                    return;
                }

                if (!box->collectionId()) {
                    qCWarning(UNIFIEDMAILBOXAGENT_LOG) << "Missing box->collection mapping for unified mailbox" << box->id();
                    return;
                }

                new Akonadi::LinkJob(Akonadi::Collection{box->collectionId().value()}, {item}, this);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[&manager, &success](const QString &id, int numSources) {
            success = false;
            auto boxIt = std::find_if(manager.begin(), manager.end(),
                            [&id](const UnifiedMailboxManager::Entry &e) {
                                return e.second->id() == id;
                            });
            QVERIFY(boxIt != manager.end());
            const auto &box = boxIt->second;
            const auto sourceCollections = box->sourceCollections();
            QCOMPARE(sourceCollections.size(), numSources);
            for (auto source : sourceCollections) {
                auto col = collectionForId(source);
                QVERIFY(col);
                QVERIFY(col->hasAttribute<Akonadi::SpecialCollectionAttribute>());
                QCOMPARE(col->attribute<Akonadi::SpecialCollectionAttribute>()->collectionType(), id.toLatin1());
            }
            success = true;
        }
```

#### AUTO 


```{c}
auto *parser = new TemplateParser::TemplateParserJob(mMsg, TemplateParser::TemplateParserJob::NewMessage, this);
```

#### AUTO 


```{c}
const auto &boxIt
```

#### AUTO 


```{c}
const auto &source
```

#### AUTO 


```{c}
auto it = std::max_element(d->mFilters.constBegin(), d->mFilters.constEnd(),
            [id](MailCommon::MailFilter * lhs, MailCommon::MailFilter * rhs) {
                return lhs->requiredPart(id) < rhs->requiredPart(id);
            });
```

#### AUTO 


```{c}
auto action = new QAction(QIcon::fromTheme(QStringLiteral("contact-new")), i18n("New AddressBook Contact..."), this);
```

#### AUTO 


```{c}
const auto collection = etm->data(colIdx, Akonadi::EntityTreeModel::CollectionRole).value<Akonadi::Collection>();
```

#### AUTO 


```{c}
auto *item = job->property("ProgressItem").value<KPIM::ProgressItem *>();
```

#### AUTO 


```{c}
auto *hbox = new QHBoxLayout;
```

#### RANGE FOR STATEMENT 


```{c}
for (MessageComposer::PluginEditorConvertTextInterface *interface : qAsConst(mListPluginInterface)) {
        if (interface->convertTextToFormat(textPart)) {
            //TODO signal that it was reformating.
            //Stop it.?
        }
    }
```

#### AUTO 


```{c}
auto sourceBox = manager.unifiedMailboxFromCollection(sentBoxCol.value());
```

#### AUTO 


```{c}
auto *tab = qobject_cast<ConfigModuleTab *>(mTabWidget->currentWidget());
```

#### AUTO 


```{c}
const auto removeMailBox = [this, view]() {
        const auto indexes = view->selectionModel()->selectedIndexes();
        if (!indexes.isEmpty()) {
            auto item = mBoxModel->itemFromIndex(indexes[0]);
            const auto mailbox = item->data().value<UnifiedMailbox *>();
            if (KMessageBox::warningYesNo(this,
                                          i18n("Do you really want to remove unified mailbox <b>%1</b>?", mailbox->name()),
                                          i18n("Really Remove?"),
                                          KStandardGuiItem::remove(),
                                          KStandardGuiItem::cancel())
                == KMessageBox::Yes) {
                mBoxModel->removeRow(item->row());
                mBoxManager.removeBox(mailbox->id());
                mBoxManager.saveBoxes();
            }
        }
    };
```

#### AUTO 


```{c}
auto label = new QLabel(i18n("Recognize any sequence of the following prefixes (entries are case-insensitive regular expressions):"), group);
```

#### AUTO 


```{c}
auto box = std::find_if(mMailboxes.begin(), mMailboxes.end(),
                            [&id](const std::pair<const QString, std::unique_ptr<UnifiedMailbox>> &box) {
                                return box.second->id() == id;
                            });
```

#### RANGE FOR STATEMENT 


```{c}
for (Akonadi::Collection::Id col : lst) {
                    mCollectionId.append(Akonadi::Collection(col));
                }
```

#### AUTO 


```{c}
auto *itemFetchJob = new Akonadi::ItemFetchJob(items, this);
```

#### AUTO 


```{c}
auto *saveCommand = new KMSaveMsgCommand(this, selectedMessages);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : urlList) {
            if (!url.isLocalFile()) {
                allLocalURLs = false;
            }
            const Akonadi::Item item = Akonadi::Item::fromUrl(url);
            if (item.isValid()) {
                items << item;
            } else {
                const Akonadi::Collection collection = Akonadi::Collection::fromUrl(url);
                if (collection.isValid()) {
                    collections << collection;
                }
            }
        }
```

#### AUTO 


```{c}
auto uiDelegate = static_cast<KIO::Job *>(job)->uiDelegate()
```

#### AUTO 


```{c}
auto progressItem = job->property("progressItem").value<QPointer<KPIM::ProgressItem>>();
```

#### AUTO 


```{c}
auto warningTab = new WarningTab();
```

#### AUTO 


```{c}
auto scrollArea = new QScrollArea;
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Collection &col : searchCols) {
            QAbstractItemModel *etm = KMKernel::self()->collectionModel();
            const QModelIndex idx = Akonadi::EntityTreeModel::modelIndexForCollection(etm, col);
            const Akonadi::Collection modelCol = etm->data(idx, Akonadi::EntityTreeModel::CollectionRole).value<Akonadi::Collection>();
            // Only index offline IMAP collections
            if (PimCommon::Util::isImapResource(modelCol.resource()) && !modelCol.cachePolicy().localParts().contains(QLatin1String("RFC822"))) {
                continue;
            } else {
                cols.push_back(modelCol);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (MailFilter *filter : lstFilters) {
        if (!filter->isEmpty() && filter->configureShortcut() && filter->isEnabled()) {
            QString filterName = QStringLiteral("Filter %1").arg(filter->name());
            QString normalizedName = filterName.replace(QLatin1Char(' '), QLatin1Char('_'));
            if (action(normalizedName)) {
                continue;
            }

            if (!addedSeparator) {
                QAction *a = mApplyFilterActionsMenu->menu()->addSeparator();
                mFilterMenuActions.append(a);
                a = mApplyFilterFolderActionsMenu->menu()->addSeparator();
                mFilterFolderMenuActions.append(a);
                a = mApplyFilterFolderRecursiveActionsMenu->menu()->addSeparator();
                mFilterFolderMenuRecursiveActions.append(a);
                addedSeparator = true;
            }

            KMMetaFilterActionCommand *filterCommand = new KMMetaFilterActionCommand(filter->identifier(), this);
            mFilterCommands.append(filterCommand);

            auto filterAction = filterToAction(filter);
            actionCollection()->addAction(normalizedName, filterAction);
            connect(filterAction, &QAction::triggered,
                    filterCommand, &KMMetaFilterActionCommand::start);
            actionCollection()->setDefaultShortcut(filterAction, filter->shortcut());
            mApplyFilterActionsMenu->menu()->addAction(filterAction);
            mFilterMenuActions.append(filterAction);
            if (filter->configureToolbar()) {
                mFilterTBarActions.append(filterAction);
            }

            filterAction = filterToAction(filter);
            actionCollection()->addAction(normalizedName + QStringLiteral("___folder"), filterAction);
            connect(filterAction, &QAction::triggered,
                    this, [this] { slotApplyFilterOnFolder(/* recursive */ false);
                    });
            mApplyFilterFolderActionsMenu->menu()->addAction(filterAction);
            mFilterFolderMenuActions.append(filterAction);

            filterAction = filterToAction(filter);
            actionCollection()->addAction(normalizedName + QStringLiteral("___folder_recursive"), filterAction);
            connect(filterAction, &QAction::triggered,
                    this, [this] { slotApplyFilterOnFolder(/* recursive */ true);
                    });
            mApplyFilterFolderRecursiveActionsMenu->menu()->addAction(filterAction);
            mFilterFolderMenuRecursiveActions.append(filterAction);
        }
    }
```

#### AUTO 


```{c}
auto *item = dynamic_cast<IdentityListViewItem *>(currentItem());
```

#### LAMBDA EXPRESSION 


```{c}
[this, line]() {
        this->slotRecipientAdded(line);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QFileInfo &file : autoSaveFiles) {
        // Disregard the '.' and '..' folders
        const QString filename = file.fileName();
        if (filename == QLatin1Char('.')
            || filename == QLatin1String("..")
            || file.isDir()) {
            continue;
        }
        qCDebug(KMAIL_LOG) << "Opening autosave file:" << file.absoluteFilePath();
        QFile autoSaveFile(file.absoluteFilePath());
        if (autoSaveFile.open(QIODevice::ReadOnly)) {
            const KMime::Message::Ptr autoSaveMessage(new KMime::Message());
            const QByteArray msgData = autoSaveFile.readAll();
            autoSaveMessage->setContent(msgData);
            autoSaveMessage->parse();

            // Show the a new composer dialog for the message
            KMail::Composer *autoSaveWin = KMail::makeComposer();
            autoSaveWin->setMessage(autoSaveMessage, false, false, false);
            autoSaveWin->setAutoSaveFileName(filename);
            autoSaveWin->show();
            autoSaveFile.close();
        } else {
            KMessageBox::sorry(nullptr, i18n("Failed to open autosave file at %1.\nReason: %2",
                                             file.absoluteFilePath(), autoSaveFile.errorString()),
                               i18n("Opening Autosave File Failed"));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &s : offers) {
            QAction *act = createAppAction(s,
                                           // no submenu -> prefix single offer
                                           menu == topMenu,
                                           actionGroup,
                                           menu);
            menu->addAction(act);
        }
```

#### AUTO 


```{c}
auto button = new QPushButton(i18nc("@action:button Add new mime header field.", "Ne&w"), this);
```

#### AUTO 


```{c}
auto *job = new KIO::OpenUrlJob(url, mimename);
```

#### RANGE FOR STATEMENT 


```{c}
for (KMime::Content *attach : qAsConst(fwdMsg.second)) {
        mWin->addAttach(attach);
        delete attach;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &index : indexes) {
                    mMailbox->addSourceCollection(index.data(Akonadi::EntityTreeModel::CollectionIdRole).toLongLong());
                }
```

#### AUTO 


```{c}
auto delJob = new Akonadi::CollectionDeleteJob(inboxSourceCol.value(), this);
```

#### LAMBDA EXPRESSION 


```{c}
[&loadingDone]() {
            loadingDone = true;
        }
```

#### AUTO 


```{c}
auto mailbox = createUnifiedMailbox(QStringLiteral("Test1"), QStringLiteral("Test 1"), {QStringLiteral("res1_inbox")});
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : lstItems) {
        const KMime::Message::Ptr msg = MessageCore::Util::message(item);
        if (!msg) {
            return Failed;
        }
        MessageFactoryNG factory(msg, item.id(), MailCommon::Util::updatedCollection(item.parentCollection()));
        factory.setIdentityManager(KMKernel::self()->identityManager());
        factory.setFolderIdentity(MailCommon::Util::folderIdentity(item));

        if (transportId == -1) {
            const MailTransport::TransportAttribute *transportAttribute = item.attribute<MailTransport::TransportAttribute>();
            if (transportAttribute) {
                transportId = transportAttribute->transportId();
                const MailTransport::Transport *transport = MailTransport::TransportManager::self()->transportById(transportId);
                if (!transport) {
                    transportId = -1;
                }
            }
        }

        const MailTransport::SentBehaviourAttribute *sentAttribute = item.attribute<MailTransport::SentBehaviourAttribute>();
        QString fcc;
        if (sentAttribute && (sentAttribute->sentBehaviour() == MailTransport::SentBehaviourAttribute::MoveToCollection)) {
            fcc =  QString::number(sentAttribute->moveToCollection().id());
        }

        const KMime::Message::Ptr newMsg = factory.createRedirect(to, cc, bcc, transportId, fcc, identity);
        if (!newMsg) {
            return Failed;
        }

        MessageStatus status;
        status.setStatusFromFlags(item.flags());
        if (!status.isRead()) {
            FilterAction::sendMDN(item, KMime::MDN::Dispatched);
        }

        if (!kmkernel->msgSender()->send(newMsg, method)) {
            qCDebug(KMAIL_LOG) << "KMRedirectCommand: could not redirect message (sending failed)";
            return Failed; // error: couldn't send
        }
    }
```

#### AUTO 


```{c}
const auto sourceIndex = sourceModel()->index(source_row, 0, source_parent);
```

#### RANGE FOR STATEMENT 


```{c}
for (const MailCommon::MailFilter *filter : std::as_const(mFilters)) {
        if (filter->applyOnInbound() && filter->applyOnAccount(accountId)) {
            return true;
        }
    }
```

#### AUTO 


```{c}
auto formatLabel = new QLabel(i18n("Format:"), this);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &str) {
                mComposerBase->editor()->insertPlainText(str);
            }
```

#### AUTO 


```{c}
auto aggregationLabel = new QLabel(i18n("Default aggregation:"), group);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : list) {
        addMailingListAction(item, url);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &boxGroupName : boxGroups) {
        const auto boxGroup = group.group(boxGroupName);
        auto box = std::make_unique<UnifiedMailbox>();
        box->load(boxGroup);
        insertBox(std::move(box));
    }
```

#### AUTO 


```{c}
auto job = new SaveAsFileJob(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *wid : l) {
        QList<KMMainWidget *> l2 = wid->window()->findChildren<KMMainWidget *>();
        if (!l2.isEmpty() && l2.first()) {
            return l2.first();
        }
    }
```

#### AUTO 


```{c}
auto agent = Akonadi::AgentManager::self()->instance(QStringLiteral("akonadi_archivemail_agent"));
```

#### AUTO 


```{c}
auto *job = new FillComposerJob;
```

#### AUTO 


```{c}
auto sync = qobject_cast<Akonadi::CollectionAttributesSynchronizationJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const MailCommon::MailFilter *filter : qAsConst(d->mFilters)) {
            if (!filter->name().compare(uniqueName)) {
                found = true;
                ++counter;
                uniqueName = name;
                uniqueName += QLatin1String(" (") + QString::number(counter)
                              + QLatin1String(")");
                break;
            }
        }
```

#### AUTO 


```{c}
auto command = new KMReplyCommand(this, currentItem, MessageComposer::ReplySmart, mReaderWin->copyText(), false, tmpl);
```

#### RANGE FOR STATEMENT 


```{c}
for (QTreeWidgetItem *item : mailItemLst) {
                auto *mailItem = static_cast<FollowUpReminderInfoItem *>(item);
                mListRemoveId << mailItem->info()->uniqueIdentifier();
                delete mailItem;
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Collection &col : cols) {
        const QModelIndex colIdx = Akonadi::EntityTreeModel::modelIndexForCollection(etm, col);
        if (col.statistics().count() > -1) {
            if (col.cachePolicy().localParts().contains(QLatin1String("RFC822"))) {
                result.push_back(col);
            }
        } else {
            const Akonadi::Collection collection = etm->data(colIdx, Akonadi::EntityTreeModel::CollectionRole).value<Akonadi::Collection>();
            if (!collection.hasAttribute<Akonadi::EntityHiddenAttribute>() && collection.cachePolicy().localParts().contains(QLatin1String("RFC822"))) {
                result.push_back(collection);
            }
        }

        const int childrenCount = etm->rowCount(colIdx);
        if (childrenCount > 0) {
            Akonadi::Collection::List subCols;
            subCols.reserve(childrenCount);
            for (int i = 0; i < childrenCount; ++i) {
                const QModelIndex idx = etm->index(i, 0, colIdx);
                const Akonadi::Collection child = etm->data(idx, Akonadi::EntityTreeModel::CollectionRole).value<Akonadi::Collection>();
                if (child.cachePolicy().localParts().contains(QLatin1String("RFC822"))) {
                    subCols.push_back(child);
                }
            }

            result += searchCollectionsRecursive(subCols);
        }
    }
```

#### AUTO 


```{c}
auto hlay = new QHBoxLayout();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : lstItems) {
        const KMime::Message::Ptr msg = MessageComposer::Util::message(item);
        if (!msg) {
            return Failed;
        }
        MessageFactoryNG factory(msg, item.id(), MailCommon::Util::updatedCollection(item.parentCollection()));
        factory.setIdentityManager(KMKernel::self()->identityManager());
        factory.setFolderIdentity(MailCommon::Util::folderIdentity(item));

        if (transportId == -1) {
            const MailTransport::TransportAttribute *transportAttribute = item.attribute<MailTransport::TransportAttribute>();
            if (transportAttribute) {
                transportId = transportAttribute->transportId();
                const MailTransport::Transport *transport = MailTransport::TransportManager::self()->transportById(transportId);
                if (!transport) {
                    transportId = -1;
                }
            }
        }

        const MailTransport::SentBehaviourAttribute *sentAttribute = item.attribute<MailTransport::SentBehaviourAttribute>();
        QString fcc;
        if (sentAttribute && (sentAttribute->sentBehaviour() == MailTransport::SentBehaviourAttribute::MoveToCollection)) {
            fcc = QString::number(sentAttribute->moveToCollection().id());
        }

        const KMime::Message::Ptr newMsg = factory.createRedirect(to, cc, bcc, transportId, fcc, identity);
        if (!newMsg) {
            return Failed;
        }

        MessageStatus status;
        status.setStatusFromFlags(item.flags());
        if (!status.isRead()) {
            FilterAction::sendMDN(item, KMime::MDN::Dispatched);
        }

        if (!kmkernel->msgSender()->send(newMsg, method)) {
            qCDebug(KMAIL_LOG) << "KMRedirectCommand: could not redirect message (sending failed)";
            return Failed; // error: couldn't send
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QMimeData *mimeData) {
        insertFromMimeData(mimeData, false);
    }
```

#### AUTO 


```{c}
auto job = new Akonadi::OpenEmailAddressJob(emailString, mMainWindow, this);
```

#### AUTO 


```{c}
auto about = new KAboutData(QStringLiteral("kcmkmailsummary"),
                                       i18n("kcmkmailsummary"),
                                       QString(),
                                       i18n("Mail Summary Configuration Dialog"),
                                       KAboutLicense::GPL,
                                       i18n("Copyright � 2004�2010 Tobias Koenig"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : lstItems) {
        const KMime::Message::Ptr msg = MessageCore::Util::message(item);
        if (!msg) {
            return Failed;
        }

        MessageFactory factory(msg, item.id(), MailCommon::Util::updatedCollection(item.parentCollection()));
        factory.setIdentityManager(KMKernel::self()->identityManager());
        factory.setFolderIdentity(MailCommon::Util::folderIdentity(item));

        if (transportId == -1) {
            const MailTransport::TransportAttribute *transportAttribute = item.attribute<MailTransport::TransportAttribute>();
            if (transportAttribute) {
                transportId = transportAttribute->transportId();
                const MailTransport::Transport *transport = MailTransport::TransportManager::self()->transportById(transportId);
                if (!transport) {
                    transportId = -1;
                }
            }
        }

        const MailTransport::SentBehaviourAttribute *sentAttribute = item.attribute<MailTransport::SentBehaviourAttribute>();
        QString fcc;
        if (sentAttribute && (sentAttribute->sentBehaviour() == MailTransport::SentBehaviourAttribute::MoveToCollection)) {
            fcc =  QString::number(sentAttribute->moveToCollection().id());
        }

        const KMime::Message::Ptr newMsg = factory.createRedirect(to, cc, bcc, transportId, fcc, identity);
        if (!newMsg) {
            return Failed;
        }

        MessageStatus status;
        status.setStatusFromFlags(item.flags());
        if (!status.isRead()) {
            FilterAction::sendMDN(item, KMime::MDN::Dispatched);
        }

        if (!kmkernel->msgSender()->send(newMsg, method)) {
            qCDebug(KMAIL_LOG) << "KMRedirectCommand: could not redirect message (sending failed)";
            return Failed; // error: couldn't send
        }
    }
```

#### AUTO 


```{c}
const auto ident = mKernel->identityManager()->identityForUoid(uoid);
```

#### AUTO 


```{c}
const auto verifyBox = [&manager, &success](const QString &id, int numSources) {
                                   success = false;
                                   auto boxIt = std::find_if(manager.begin(), manager.end(),
                                                             [&id](const UnifiedMailboxManager::Entry &e) {
                return e.second->id() == id;
            });
                                   QVERIFY(boxIt != manager.end());
                                   const auto &box = boxIt->second;
                                   const auto sourceCollections = box->sourceCollections();
                                   QCOMPARE(sourceCollections.size(), numSources);
                                   for (auto source : sourceCollections) {
                                       auto col = collectionForId(source);
                                       QVERIFY(col.isValid());
                                       QVERIFY(col.hasAttribute<Akonadi::SpecialCollectionAttribute>());
                                       QCOMPARE(col.attribute<Akonadi::SpecialCollectionAttribute>()->collectionType(), id.toLatin1());
                                   }
                                   success = true;
                               };
```

#### RANGE FOR STATEMENT 


```{c}
for (auto a : qAsConst(mFilterFolderMenuActions)) {
        a->setEnabled(folderIsValid);
    }
```

#### AUTO 


```{c}
auto displayAttr = col.attribute<Akonadi::EntityDisplayAttribute>(Akonadi::Collection::AddIfMissing);
```

#### AUTO 


```{c}
auto *job = new RemoveDuplicateMessageInFolderAndSubFolderJob(this, this);
```

#### AUTO 


```{c}
auto tagItem = static_cast<TagListWidgetItem *>(item);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Akonadi::Item::List &items, const Akonadi::Collection &srcCollection, const Akonadi::Collection &dstCollection) {
                ReplayNextOnExit replayNext(mMonitor);

                if (const auto srcBox = unifiedMailboxForSource(srcCollection.id())) {
                    // Move source collection was our source, unlink the Item from a box
                    new Akonadi::UnlinkJob(Akonadi::Collection{srcBox->collectionId()}, items, this);
                }
                if (const auto dstBox = unifiedMailboxForSource(dstCollection.id())) {
                    // Move destination collection is our source, link the Item into a box
                    new Akonadi::LinkJob(Akonadi::Collection{dstBox->collectionId()}, items, this);
                }
            }
```

#### AUTO 


```{c}
auto info = new QLabel(i18n("The module is missing. Please verify your installation. This module is provided by Kleopatra."), this);
```

#### AUTO 


```{c}
auto *label = static_cast<KUrlLabel *>(obj);
```

#### AUTO 


```{c}
const auto dlgGroup = config->group(DialogGroup);
```

#### AUTO 


```{c}
auto job = new OpenComposerHiddenJob(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &custom : customs) {
            if (custom.contains(QLatin1String("MailPreferedFormatting"))) {
                const QString value = mSearchedAddress.custom(QStringLiteral("KADDRESSBOOK"), QStringLiteral("MailPreferedFormatting"));
                mViewAsHtml->setChecked(value == QLatin1String("HTML"));
            } else if (custom.contains(QLatin1String("MailAllowToRemoteContent"))) {
                const QString value = mSearchedAddress.custom(QStringLiteral("KADDRESSBOOK"), QStringLiteral("MailAllowToRemoteContent"));
                mLoadExternalReference->setChecked((value == QLatin1String("TRUE")));
            }
        }
```

#### AUTO 


```{c}
auto removeButton = new QPushButton(QIcon::fromTheme(QStringLiteral("list-remove-symbolic")), i18n("Remove"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Collection &collection : qAsConst(collectionList)) {
                    const Akonadi::Collection::Id collectionId = collection.id();
                    if (iface->targetCollection() == collectionId) {
                        // Use default inbox
                        iface->setTargetCollection(CommonKernel->inboxCollectionFolder().id());
                        iface->save();
                        break;
                    }
                }
```

#### AUTO 


```{c}
const auto modifyMailBox = [this, view]() {
        const auto indexes = view->selectionModel()->selectedIndexes();
        if (!indexes.isEmpty()) {
            auto item = mBoxModel->itemFromIndex(indexes[0]);
            auto mailbox = item->data().value<UnifiedMailbox *>();
            auto editor = new UnifiedMailboxEditor(mailbox, mConfig, this);
            if (editor->exec()) {
                item->setText(mailbox->name());
                item->setIcon(QIcon::fromTheme(mailbox->icon()));
            }
            delete editor;
            mBoxManager.saveBoxes();
        }
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (MessageComposer::PluginEditorInit *plugin : lstPlugin) {
        if (plugin->isEnabled()) {
            MessageComposer::PluginEditorInitInterface *interface = plugin->createInterface(this);
            interface->setParentWidget(mParentWidget);
            interface->setRichTextEditor(mRichTextEditor);
            interface->reloadConfig();
            if (!interface->exec()) {
                qCWarning(KMAIL_LOG) << "KMailPluginEditorInitManagerInterface::initializePlugins: error during execution of plugin:" << interface;
            }
        }
    }
```

#### AUTO 


```{c}
auto *command
            = new KMPrintCommand(this, commandInfo);
```

#### AUTO 


```{c}
const auto *mainWinAction = manager->action(Akonadi::StandardActionManager::MoveItemToMenu);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::AgentInstance &agent : agents) {
            const QString id = agent.identifier();

            auto it = std::max_element(d->mFilters.constBegin(), d->mFilters.constEnd(), [id](MailCommon::MailFilter *lhs, MailCommon::MailFilter *rhs) {
                return lhs->requiredPart(id) < rhs->requiredPart(id);
            });
            d->mRequiredParts[id] = (*it)->requiredPart(id);
            d->mRequiredPartsBasedOnAll = qMax(d->mRequiredPartsBasedOnAll, d->mRequiredParts[id]);
        }
```

#### AUTO 


```{c}
auto part = mView->model()->data(properItemClickedIndex, MessageComposer::AttachmentModel::AttachmentPartRole).value<AttachmentPart::Ptr>();
```

#### RANGE FOR STATEMENT 


```{c}
for (MessageComposer::PluginEditor *plugin : lstPlugin) {
        if (plugin->isEnabled()) {
            MessageComposer::PluginEditorInterface *interface = static_cast<MessageComposer::PluginEditorInterface *>(plugin->createInterface(this));
            interface->setRichTextEditor(mRichTextEditor);
            interface->setParentWidget(mParentWidget);
            interface->createAction(mActionCollection);
            interface->setPlugin(plugin);
            connect(interface, &MessageComposer::PluginEditorInterface::emitPluginActivated, this, &KMailPluginEditorManagerInterface::slotPluginActivated);
            connect(interface, &MessageComposer::PluginEditorInterface::message, this, &KMailPluginEditorManagerInterface::message);
            mListPluginInterface.append(interface);
        }
    }
```

#### AUTO 


```{c}
auto readerTab = new AppearancePageGeneralTab();
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Akonadi::Collection &col, const QSet<QByteArray> &parts) {
                ReplayNextOnExit replayNext(mMonitor);

                qCDebug(agent_log) << "Collection changed:" << parts;
                if (!parts.contains(Akonadi::SpecialCollectionAttribute().type())) {
                    return;
                }

                if (col.hasAttribute<Akonadi::SpecialCollectionAttribute>()) {
                    const auto srcBox = unregisterSpecialSourceCollection(col.id());
                    const auto dstBox = registerSpecialSourceCollection(col);
                    if (srcBox == dstBox) {
                        return;
                    }

                    saveBoxes();

                    if (srcBox && srcBox->sourceCollections().isEmpty()) {
                        removeBox(srcBox->id());
                        return;
                    }

                    if (srcBox) {
                        Q_EMIT updateBox(srcBox);
                    }
                    if (dstBox) {
                        Q_EMIT updateBox(dstBox);
                    }
                } else {
                    if (const auto box = unregisterSpecialSourceCollection(col.id())) {
                        saveBoxes();
                        if (box->sourceCollections().isEmpty()) {
                            removeBox(box->id());
                        } else {
                            Q_EMIT updateBox(box);
                        }
                    }
                }
            }
```

#### AUTO 


```{c}
const auto &groupName
```

#### AUTO 


```{c}
auto *job = new AddressValidationJob(recipients, this, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (MessageComposer::PluginEditorInterface *interface : qAsConst(mListPluginInterface)) {
            MessageComposer::ActionType actionType = interface->actionType();
            MessageComposer::ActionType::Type type = actionType.type();
            QList<QAction *> lst = mActionHash.value(type);
            if (!lst.isEmpty()) {
                QAction *act = new QAction(this);
                act->setSeparator(true);
                lst << act << actionType.action();
                mActionHash.insert(type, lst);
            } else {
                mActionHash.insert(type, QList<QAction *>() << actionType.action());
            }
            if (interface->plugin()->hasPopupMenuSupport()) {
                type = MessageComposer::ActionType::PopupMenu;
                QList<QAction *> lst = mActionHash.value(type);
                if (!lst.isEmpty()) {
                    QAction *act = new QAction(this);
                    act->setSeparator(true);
                    lst << act << actionType.action();
                    mActionHash.insert(type, lst);
                } else {
                    mActionHash.insert(type, QList<QAction *>() << actionType.action());
                }
            }
            if (interface->plugin()->hasToolBarSupport()) {
                type = MessageComposer::ActionType::ToolBar;
                QList<QAction *> lst = mActionHash.value(type);
                if (!lst.isEmpty()) {
                    QAction *act = new QAction(this);
                    act->setSeparator(true);
                    lst << act << actionType.action();
                    mActionHash.insert(type, lst);
                } else {
                    mActionHash.insert(type, QList<QAction *>() << actionType.action());
                }
            }
        }
```

#### AUTO 


```{c}
auto *statusBar = new KParts::StatusBarExtension(this);
```

#### AUTO 


```{c}
auto themeLabel = new QLabel(i18n("Default theme:"), group);
```

#### AUTO 


```{c}
auto *tagItem = static_cast<TagListWidgetItem *>(item);
```

#### AUTO 


```{c}
auto mailbox = std::make_unique<UnifiedMailbox>();
```

#### AUTO 


```{c}
auto *const organization = new KMime::Headers::Organization;
```

#### AUTO 


```{c}
auto h = new KMime::Headers::Generic("X-KMail-Identity");
```

#### AUTO 


```{c}
auto topWidget = new QWidget;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : urlList) {
        QString urlStr;
        if (url.scheme() == QLatin1String("mailto")) {
            urlStr = KEmailAddress::decodeMailtoUrl(url);
        } else {
            urlStr = url.toDisplayString();
            // Workaround #346370
            if (urlStr.isEmpty()) {
                urlStr = source->text();
            }
        }
        if (!urlAdded.contains(urlStr)) {
            mComposerBase->editor()->composerControler()->insertLink(urlStr);
            urlAdded.append(urlStr);
        }
    }
```

#### AUTO 


```{c}
auto colIt = std::find_if(cols.cbegin(), cols.cend(), [&rid](const Akonadi::Collection &col) {
        return col.remoteId() == rid;
    });
```

#### AUTO 


```{c}
auto dateDisplay
        = static_cast<DateFormatter::FormatType>(num);
```

#### AUTO 


```{c}
auto editor = new UnifiedMailboxEditor(mailbox, mConfig, this);
```

#### AUTO 


```{c}
auto attachmentModel = new MessageComposer::AttachmentModel(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        auto mailbox = std::make_unique<UnifiedMailbox>();
        auto editor = new UnifiedMailboxEditor(mailbox.get(), mConfig, this);
        if (editor->exec()) {
            mailbox->setId(mailbox->name());         // assign ID
            addBox(mailbox.get());
            mBoxManager.insertBox(std::move(mailbox));
            mBoxManager.saveBoxes();
        }
        delete editor;
    }
```

#### AUTO 


```{c}
auto *composer = qobject_cast< MessageComposer::Composer * >(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (KMainWindow *window : lst) {
        // Then look for a KMMainWidget.
        QList<KMMainWidget *> l = window->findChildren<KMMainWidget *>();
        if (!l.isEmpty() && l.first()) {
            mainWidget = l.first();
            if (window->isActiveWindow()) {
                break;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (MessageComposer::PluginEditorConvertTextInterface *interface : qAsConst(mListPluginInterface)) {
        interface->setMessage(newMsg);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto source : sourceCollections) {
                                       auto col = collectionForId(source);
                                       QVERIFY(col);
                                       QVERIFY(col->hasAttribute<Akonadi::SpecialCollectionAttribute>());
                                       QCOMPARE(col->attribute<Akonadi::SpecialCollectionAttribute>()->collectionType(), id.toLatin1());
                                   }
```

#### AUTO 


```{c}
auto header = new KMime::Headers::Generic("X-Face");
```

#### AUTO 


```{c}
auto saveCommand = new KMSaveMsgCommand(this, selectedMessages);
```

#### AUTO 


```{c}
auto *command = new KMForwardAttachedCommand(
        this, selectedMessages, mCurrentFolderSettings->identity()
        );
```

#### RANGE FOR STATEMENT 


```{c}
for (Akonadi::AgentInstance type : lst) {
        const QString identifier(type.identifier());
        if (PimCommon::Util::isImapResource(identifier) ||
                identifier.contains(POP3_RESOURCE_IDENTIFIER) ||
                identifier.contains(QStringLiteral("akonadi_maildispatcher_agent")) ||
                type.type().capabilities().contains(QStringLiteral("NeedsNetwork"))) {
            type.setIsOnline(goOnline);
        }
    }
```

#### AUTO 


```{c}
const auto group = item.payload<KContacts::ContactGroup>();
```

#### AUTO 


```{c}
auto *dictionaryCombo = new DictionaryComboBox(mHeadersArea);
```

#### RANGE FOR STATEMENT 


```{c}
for (const qlonglong &id : qAsConst(mMsgListId)) {
        int diff = msgCountToFilter - ++msgCount;
        if (diff < 10 || !(msgCount % 10) || msgCount <= 10) {
            progressItem->updateProgress();
            const QString statusMsg = i18n("Filtering message %1 of %2", msgCount, msgCountToFilter);
            PimCommon::BroadcastStatus::instance()->setStatusMsg(statusMsg);
            qApp->processEvents(QEventLoop::ExcludeUserInputEvents, 50);
        }

        MailCommon::FilterManager::instance()->filter(Akonadi::Item(id), mFilterId, QString());
        progressItem->incCompletedItems();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (MessageComposer::PluginEditorConvertTextInterface *interface : qAsConst(mListPluginInterface)) {
        if (interface->reformatText()) {
            //TODO signal that it was reformating.
            //Stop it.?
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Tag &tag : std::as_const(mCreatedTags)) {
                if (item.hasTag(tag)) {
                    item.clearTag(tag);
                } else {
                    item.setTag(tag);
                }
            }
```

#### AUTO 


```{c}
auto *prefereHtml = menu.findChild<KToggleAction *>(QStringLiteral("prefer-html-action"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::AgentType &type : lstAgent) {
        if (type.identifier() == service) {
            data.mExtraInfo << service;
            data.mExtraInfo << path;
            bool failed = false;
            const bool enabled = agentActivateState(interfaceName, path, failed);
            data.mEnableByDefault = enabled;
            data.mName = type.name();
            data.mDescription = type.description();
            data.mIdentifier = type.identifier();
            break;
        }
    }
```

#### AUTO 


```{c}
auto monitor = new Akonadi::Monitor();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Tag &akonadiTag : lstTags) {
        mTagList.append(MailCommon::Tag::fromAkonadi(akonadiTag));
    }
```

#### AUTO 


```{c}
auto box = manager.unifiedMailboxFromCollection(inboxBoxCol.value());
```

#### AUTO 


```{c}
auto *tlay = new QHBoxLayout();
```

#### AUTO 


```{c}
auto dateDisplay = static_cast<DateFormatter::FormatType>(num);
```

#### AUTO 


```{c}
auto const tagAction = new KToggleAction(QIcon::fromTheme(tag->iconName), cleanName, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (QTreeWidgetItem *item : listItems) {
        if (deleteMessage) {
            auto mailItem = static_cast<SendLaterItem *>(item);
            if (mailItem->info()) {
                Akonadi::Item::Id id = mailItem->info()->itemId();
                if (id != -1) {
                    mListMessagesToRemove << id;
                }
            }
        }
        delete item;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Collection &collection : allFolders) {
                    KConfigGroup config(KMKernel::self()->config(), MailCommon::FolderSettings::configGroupName(collection));
                    // Old config
                    config.deleteEntry("htmlMailOverride");
                    config.deleteEntry("displayFormatOverride");
                    MailCommon::FolderSettings::resetHtmlFormat();
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &server : std::as_const(mServerActive)) {
        auto lab = new ServerLabel(server);
        connect(lab, &ServerLabel::clicked, this, &VacationScriptIndicatorWidget::clicked);
        mBoxLayout->addWidget(lab);
    }
```

#### AUTO 


```{c}
const auto &uid
```

#### AUTO 


```{c}
auto maingrid = new QHBoxLayout(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const MessageComposer::PluginActionType &actionType : interface->actionTypes()) {
                MessageComposer::PluginActionType::Type type = actionType.type();
                QAction *currentAction = actionType.action();
                if (!currentAction) {
                    continue;
                }
                QList<QAction *> lst = mActionHash.value(type);
                if (!lst.isEmpty()) {
                    QAction *act = new QAction(this);
                    act->setSeparator(true);
                    lst << act << currentAction;
                    mActionHash.insert(type, lst);
                } else {
                    mActionHash.insert(type, QList<QAction *>() << currentAction);
                }
                if (interface->plugin()->hasPopupMenuSupport()) {
                    type = MessageComposer::PluginActionType::PopupMenu;
                    if (currentAction) {
                        lst = mActionHash.value(type);
                        if (!lst.isEmpty()) {
                            QAction *act = new QAction(this);
                            act->setSeparator(true);
                            lst << act << currentAction;
                            mActionHash.insert(type, lst);
                        } else {
                            mActionHash.insert(type, QList<QAction *>() << currentAction);
                        }
                    }
                }
                if (interface->plugin()->hasToolBarSupport()) {
                    type = MessageComposer::PluginActionType::ToolBar;
                    lst = mActionHash.value(type);
                    if (!lst.isEmpty()) {
                        QAction *act = new QAction(this);
                        act->setSeparator(true);
                        lst << act << currentAction;
                        mActionHash.insert(type, lst);
                    } else {
                        mActionHash.insert(type, QList<QAction *>() << currentAction);
                    }
                }
            }
```

#### AUTO 


```{c}
auto hbl = new QHBoxLayout();
```

#### RANGE FOR STATEMENT 


```{c}
for (StandardActionManager::Type standardAction : standardActions) {
        mAkonadiStandardActionManager->createAction(standardAction);
    }
```

#### AUTO 


```{c}
auto *me = static_cast<QMouseEvent *>(event);
```

#### AUTO 


```{c}
auto *header = new KMime::Headers::Generic("X-Face");
```

#### RANGE FOR STATEMENT 


```{c}
for (QTreeWidgetItem *selecteditem : selectedItems) {
            auto *identityItem = dynamic_cast<IdentityListViewItem *>(item);
            identityName = identityItem->identity().identityName();
            if (mIdentityManager->removeIdentity(identityName)) {
                delete selecteditem;
            }
            if (mIPage.mIdentityList->currentItem()) {
                mIPage.mIdentityList->currentItem()->setSelected(true);
            }
            refreshList();
            updateButtons();
        }
```

#### AUTO 


```{c}
auto job = new Akonadi::ItemMoveJob(info->items, info->srcFolder, this);
```

#### AUTO 


```{c}
auto hdr = msg->replyTo(false)
```

#### AUTO 


```{c}
auto listWidget = dlg.findChild<QListWidget *>(QStringLiteral("listtag"));
```

#### AUTO 


```{c}
const auto sentBox = createUnifiedMailbox(Common::SentBoxId, QStringLiteral("Sent"), {QStringLiteral("res1_sent"), QStringLiteral("res2_sent")});
```

#### AUTO 


```{c}
auto *job = new FolderArchiveAgentJob(this, info, items);
```

#### AUTO 


```{c}
auto item = new QListWidgetItem(mListWidget);
```

#### RANGE FOR STATEMENT 


```{c}
for (KToggleAction *action : std::as_const(mTagActions)) {
        mMessageActions->messageStatusMenu()->removeAction(action);

        // This removes and deletes the action at the same time
        mActionCollection->removeAction(action);
    }
```

#### AUTO 


```{c}
auto addressWidget = new QWidget(this);
```

#### AUTO 


```{c}
auto job = new FollowUpReminderFinishTaskJob(info->todoId(), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *a : std::as_const(mFilterMenuActions)) {
        actionCollection()->removeAction(a);
    }
```

#### AUTO 


```{c}
const auto sourceCol = mailbox->sourceCollections().toList().first();
```

#### AUTO 


```{c}
const auto srcCol = collectionForRid(srcRid);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &addr : lst) {
                if (!mComposerBase->recipientsEditor()->addRecipient(addr, MessageComposer::Recipient::To)) {
                    qCWarning(KMAIL_LOG) << "Impossible to add to entry";
                }
            }
```

#### AUTO 


```{c}
auto *glay = new QGridLayout();
```

#### AUTO 


```{c}
const auto im = KMKernel::self()->identityManager();
```

#### LAMBDA EXPRESSION 


```{c}
[this, c](const Akonadi::Item::List &items) {
                    Akonadi::Item::List toLink;
                    std::copy_if(items.cbegin(), items.cend(), std::back_inserter(toLink),
                        [&c](const Akonadi::Item &item) {
                            return !item.virtualReferences().contains(c);
                        });
                    if (!toLink.isEmpty()) {
                        new Akonadi::LinkJob(c, toLink, this);
                    }
                }
```

#### AUTO 


```{c}
auto label2 = new QLabel(i18n("Examples are available at <a "
                                  "href=\"https://ace.home.xs4all.nl/X-Faces/\">"
                                  "https://ace.home.xs4all.nl/X-Faces/</a>."),
                             page);
```

#### RANGE FOR STATEMENT 


```{c}
for (const qint64 id : tags) {
        if (mTagActions.contains(id)) {
            mTagActions[id]->setChecked(true);
        }
    }
```

#### AUTO 


```{c}
auto widgetStack = new QStackedWidget(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (MailCommon::MailFilter *filter : std::as_const(mFilters)) {
                if (filter->identifier() == filterId) {
                    listMailFilters << filter;
                    break;
                }
            }
```

#### AUTO 


```{c}
auto interface =
                static_cast<MessageComposer::PluginEditorGrammarCustomToolsViewInterface *>(plugin->createView(mActionCollection, mCustomToolsWidget));
```

#### AUTO 


```{c}
auto plugin
```

#### RANGE FOR STATEMENT 


```{c}
for (const MailCommon::Tag::Ptr &tag : qAsConst(mTagList)) {
        QListWidgetItem *item = new QListWidgetItem(QIcon::fromTheme(tag->iconName), tag->tagName, mListTag);
        item->setData(UrlTag, tag->tag().url().url());
        item->setFlags(Qt::ItemIsUserCheckable | Qt::ItemIsEnabled | Qt::ItemIsSelectable);
        item->setCheckState(Qt::Unchecked);
        mListTag->addItem(item);

        if (updatelist) {
            const bool select = mCurrentSelectedTags.contains(tag->tag());
            item->setCheckState(select ? Qt::Checked : Qt::Unchecked);
        } else {
            if (mNumberOfSelectedMessages == 1) {
                const bool hasTag = mSelectedItem.hasTag(tag->tag());
                item->setCheckState(hasTag ? Qt::Checked : Qt::Unchecked);
            } else {
                item->setCheckState(Qt::Unchecked);
            }
        }
    }
```

#### AUTO 


```{c}
auto sourceModel = ftv->model();
```

#### AUTO 


```{c}
auto *fetchJob = new Akonadi::TagFetchJob(this);
```

#### AUTO 


```{c}
auto col = collectionForId(source);
```

#### AUTO 


```{c}
auto job = new RemoveCollectionJob(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &index : indexes) {
            list << index.data(Akonadi::EntityTreeModel::CollectionIdRole).toLongLong();
        }
```

#### AUTO 


```{c}
auto topLayout = new QFormLayout(this);
```

#### AUTO 


```{c}
const auto item = job->items().at(0);
```

#### AUTO 


```{c}
auto *createJob = qobject_cast<Akonadi::CollectionCreateJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &item : lst) {
        QUrl url(item);

        if (url.isLocalFile()) {
            attachments << url.toLocalFile();
        } else {
            attachments << item;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (MessageComposer::PluginEditorInterface *interface : qAsConst(mListPluginInterface)) {
            const MessageComposer::PluginActionType actionType = interface->actionType();
            MessageComposer::PluginActionType::Type type = actionType.type();
            const bool needSelectedText = interface->needSelectedText();
            if (needSelectedText) {
                //Disable by default as we don't have selection by default.
                actionType.action()->setEnabled(false);
                connect(this, &KMailPluginEditorManagerInterface::textSelectionChanged, actionType.action(), &QAction::setEnabled);
            }
            QList<QAction *> lst = mActionHash.value(type);
            if (!lst.isEmpty()) {
                QAction *act = new QAction(this);
                act->setSeparator(true);
                lst << act << actionType.action();
                mActionHash.insert(type, lst);
            } else {
                mActionHash.insert(type, QList<QAction *>() << actionType.action());
            }
            if (interface->plugin()->hasPopupMenuSupport()) {
                type = MessageComposer::PluginActionType::PopupMenu;
                QList<QAction *> lst = mActionHash.value(type);
                if (!lst.isEmpty()) {
                    QAction *act = new QAction(this);
                    act->setSeparator(true);
                    lst << act << actionType.action();
                    mActionHash.insert(type, lst);
                } else {
                    mActionHash.insert(type, QList<QAction *>() << actionType.action());
                }
            }
            if (interface->plugin()->hasToolBarSupport()) {
                type = MessageComposer::PluginActionType::ToolBar;
                QList<QAction *> lst = mActionHash.value(type);
                if (!lst.isEmpty()) {
                    QAction *act = new QAction(this);
                    act->setSeparator(true);
                    lst << act << actionType.action();
                    mActionHash.insert(type, lst);
                } else {
                    mActionHash.insert(type, QList<QAction *>() << actionType.action());
                }
            }
        }
```

#### AUTO 


```{c}
auto job = KIO::stat(saveUrl, KIO::StatJob::DestinationSide, 0);
```

#### AUTO 


```{c}
auto dialog = new PimCommon::AnnotationEditDialog(mCurrentItem, mParent);
```

#### AUTO 


```{c}
auto *expandJob = new Akonadi::ContactGroupExpandJob(group, this);
```

#### AUTO 


```{c}
auto command = new KMCopyCommand(dest, selectMsg);
```

#### AUTO 


```{c}
const auto parentCol = collectionForRid(Common::AgentIdentifier);
```

#### AUTO 


```{c}
auto *w = dlg.findChild<PotentialPhishingDetailWidget *>(QStringLiteral("potentialphising_widget"));
```

#### AUTO 


```{c}
const auto draftsBoxCol = createCollection(Common::DraftsBoxId, parentCol, deleter);
```

#### LAMBDA EXPRESSION 


```{c}
[this, line]() {
                this->slotRecipientAdded(line);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Collection &col : std::as_const(mCollectionId)) {
            lst << col.id();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &str) {
        mComposerBase->editor()->insertPlainText(str);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *filterAction : std::as_const(mFilterMenuActions)) {
        filterAction->setEnabled(count > 0);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Akonadi::Collection &col) {
                ReplayNextOnExit replayNext(mMonitor);

                if (auto box = unifiedMailboxForSource(col.id())) {
                    box->removeSourceCollection(col.id());
                    mMonitor.setCollectionMonitored(col, false);
                    if (box->sourceCollections().isEmpty()) {
                        removeBox(box->id());
                    }
                    saveBoxes();
                    // No need to resync the box collection, the linked Items got removed by Akonadi
                } else {
                    qCWarning(UNIFIEDMAILBOXAGENT_LOG) << "Received notification about removal of Collection" << col.id() << "which we don't monitor";
                }
           }
```

#### AUTO 


```{c}
auto *encryption = w.findChild<QLabel *>(QStringLiteral("encryptionindicator"));
```

#### AUTO 


```{c}
auto job = new Akonadi::ItemDeleteJob(item);
```

#### RANGE FOR STATEMENT 


```{c}
for (MessageComposer::PluginEditorConvertTextInterface *interface : std::as_const(mListPluginInterface)) {
            const auto actionTypes = interface->actionTypes();
            for (const MessageComposer::PluginActionType &actionType : actionTypes) {
                MessageComposer::PluginActionType::Type type = actionType.type();
                QAction *currentAction = actionType.action();
                if (!currentAction) {
                    continue;
                }
                QList<QAction *> lst = mActionHash.value(type);
                if (!lst.isEmpty()) {
                    auto act = new QAction(this);
                    act->setSeparator(true);
                    lst << act << currentAction;
                    mActionHash.insert(type, lst);
                } else {
                    mActionHash.insert(type, QList<QAction *>() << currentAction);
                }
                if (interface->plugin()->hasPopupMenuSupport()) {
                    type = MessageComposer::PluginActionType::PopupMenu;
                    if (currentAction) {
                        lst = mActionHash.value(type);
                        if (!lst.isEmpty()) {
                            auto act = new QAction(this);
                            act->setSeparator(true);
                            lst << act << currentAction;
                            mActionHash.insert(type, lst);
                        } else {
                            mActionHash.insert(type, QList<QAction *>() << currentAction);
                        }
                    }
                }
                if (interface->plugin()->hasToolBarSupport()) {
                    type = MessageComposer::PluginActionType::ToolBar;
                    lst = mActionHash.value(type);
                    if (!lst.isEmpty()) {
                        auto act = new QAction(this);
                        act->setSeparator(true);
                        lst << act << currentAction;
                        mActionHash.insert(type, lst);
                    } else {
                        mActionHash.insert(type, QList<QAction *>() << currentAction);
                    }
                }
            }
        }
```

#### AUTO 


```{c}
const auto favoriteActions = {
            StandardActionManager::AddToFavoriteCollections,
            StandardActionManager::RemoveFromFavoriteCollections,
            StandardActionManager::RenameFavoriteCollection,
            StandardActionManager::SynchronizeFavoriteCollections,
        };
```

#### RANGE FOR STATEMENT 


```{c}
for (PimCommon::CustomToolsPlugin *plugin : lstPlugin) {
        if (plugin->isEnabled()) {
            MessageComposer::PluginEditorGrammarCustomToolsViewInterface *interface = static_cast<MessageComposer::PluginEditorGrammarCustomToolsViewInterface *>(plugin->createView(mActionCollection, mCustomToolsWidget));
            mCustomToolsWidget->addCustomToolViewInterface(interface);
            interface->setParentWidget(mParentWidget);
            interface->setRichTextEditor(mRichTextEditor);
        }
    }
```

#### AUTO 


```{c}
auto *job = new Akonadi::CollectionFetchJob(mCurrentCollection, Akonadi::CollectionFetchJob::FirstLevel, this);
```

#### AUTO 


```{c}
auto layout = new QVBoxLayout(this);
```

#### AUTO 


```{c}
auto *const addressBookJob
        = new Akonadi::CollectionFetchJob(Akonadi::Collection::root(),
                                          Akonadi::CollectionFetchJob::Recursive);
```

#### AUTO 


```{c}
auto boxGroup = group.group(boxIt.second->id());
```

#### AUTO 


```{c}
auto job = new Akonadi::RemoveDuplicatesJob(collections, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const MessageComposer::PluginActionType &actionType : interface->actionTypes()) {
                MessageComposer::PluginActionType::Type type = actionType.type();
                QAction *currentAction = actionType.action();
                if (!currentAction) {
                    continue;
                }
                QList<QAction *> lst = mActionHash.value(type);
                if (!lst.isEmpty()) {
                    QAction *act = new QAction(this);
                    act->setSeparator(true);
                    lst << act << currentAction;
                    mActionHash.insert(type, lst);
                } else {
                    mActionHash.insert(type, QList<QAction *>() << currentAction);
                }
                if (interface->plugin()->hasPopupMenuSupport()) {
                    type = MessageComposer::PluginActionType::PopupMenu;
                    if (currentAction) {
                        QList<QAction *> lst = mActionHash.value(type);
                        if (!lst.isEmpty()) {
                            QAction *act = new QAction(this);
                            act->setSeparator(true);
                            lst << act << currentAction;
                            mActionHash.insert(type, lst);
                        } else {
                            mActionHash.insert(type, QList<QAction *>() << currentAction);
                        }
                    }
                }
                if (interface->plugin()->hasToolBarSupport()) {
                    type = MessageComposer::PluginActionType::ToolBar;
                    QList<QAction *> lst = mActionHash.value(type);
                    if (!lst.isEmpty()) {
                        QAction *act = new QAction(this);
                        act->setSeparator(true);
                        lst << act << currentAction;
                        mActionHash.insert(type, lst);
                    } else {
                        mActionHash.insert(type, QList<QAction *>() << currentAction);
                    }
                }
            }
```

#### AUTO 


```{c}
auto mailItem = static_cast<FollowUpReminderInfoItem *>(mTreeWidget->topLevelItem(i));
```

#### AUTO 


```{c}
auto action = new KActionMenu(menu);
```

#### AUTO 


```{c}
auto *win = new KMReaderMainWin(content, MessageViewer::Viewer::Text, charsetStr);
```

#### AUTO 


```{c}
auto identity = new KIdentityManagement::IdentityCombo(kmkernel->identityManager(), mHeadersArea);
```

#### AUTO 


```{c}
auto charsetTab = new ComposerPageCharsetTab();
```

#### AUTO 


```{c}
auto *header = new KMime::Headers::Generic("X-KMail-FccDisabled");
```

#### AUTO 


```{c}
auto tageditgrid = new QVBoxLayout(mTagsGroupBox);
```

#### AUTO 


```{c}
const auto inbox = createUnifiedMailbox(Common::InboxBoxId, QStringLiteral("Inbox"),
                                                { QStringLiteral("res1_inbox"), QStringLiteral("res2_inbox") });
```

#### RANGE FOR STATEMENT 


```{c}
for (MessageComposer::PluginEditorConvertTextInterface *interface : qAsConst(mListPluginInterface)) {
            if (interface->plugin()->hasStatusBarSupport()) {
                mStatusBarWidget.append(interface->statusBarWidget());
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &str) {
                if (!str.isEmpty()) {
                    if (mComposerBase->subject().isEmpty()) { //Add subject only if we don't have subject
                        mEdtSubject->setText(str);
                    }
                }
            }
```

#### AUTO 


```{c}
auto job = new KIO::OpenUrlJob(q.toUrl());
```

#### AUTO 


```{c}
auto *r = mUi.mPatternEdit->findChild<KLineEdit *>(QStringLiteral("regExpLineEdit"));
```

#### AUTO 


```{c}
auto interface = static_cast<MessageViewer::MessageViewerCheckBeforeDeletingInterface *>(plugin->createInterface(this));
```

#### AUTO 


```{c}
auto *vlay = new QVBoxLayout(this);
```

#### AUTO 


```{c}
auto hdr = mMsg->headerByType("X-KMail-Dictionary")
```

#### RANGE FOR STATEMENT 


```{c}
for (MessageComposer::PluginEditorInterface *interface : qAsConst(mListPluginInterface)) {
            if (static_cast<MessageComposer::PluginEditor *>(interface->plugin())->canProcessKeyEvent()) {
                if (interface->processProcessKeyEvent(event)) {
                    return true;
                }
            }
        }
```

#### AUTO 


```{c}
auto customTemplatesTab = new CustomTemplatesTab();
```

#### AUTO 


```{c}
auto vbox = new QVBoxLayout(editorAndCryptoStateIndicators);
```

#### RANGE FOR STATEMENT 


```{c}
for (KMainWindow *window : lst) {
        if (::qobject_cast<KMMainWin *>(window) || ::qobject_cast<KMail::SecondaryWindow *>(window)) {
            // close and delete the window
            window->setAttribute(Qt::WA_DeleteOnClose);
            window->close();
        }
    }
```

#### AUTO 


```{c}
auto *flatProxy = new KDescendantsProxyModel(this);
```

#### AUTO 


```{c}
const auto &box = boxIt->second;
```

#### AUTO 


```{c}
auto identity = new KIdentityManagement::IdentityCombo(kmkernel->identityManager(),
                                                            mHeadersArea);
```

#### LAMBDA EXPRESSION 


```{c}
[this] { slotApplyFilterOnFolder(/* recursive */ true); }
```

#### AUTO 


```{c}
const auto sentBox = createUnifiedMailbox(Common::SentBoxId, QStringLiteral("Sent"),
                                            { QStringLiteral("res1_sent"), QStringLiteral("res2_sent") });
```

#### AUTO 


```{c}
auto *helpMenu = new KHelpMenu(this, aboutData, true);
```

#### AUTO 


```{c}
auto *jobCol = qobject_cast<Akonadi::CollectionFetchJob *>(job);
```

#### AUTO 


```{c}
auto mFromFileBtn = new QPushButton(i18n("Select File..."), page);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &arg : parser.positionalArguments()) {
            if (arg.startsWith(QStringLiteral("mailto:"), Qt::CaseInsensitive)) {
                const QUrl urlDecoded(QUrl::fromPercentEncoding(arg.toUtf8()));
                QMap<QString, QString> values = MessageCore::StringUtil::parseMailtoUrl(urlDecoded);
                QString str = values.value(QStringLiteral("to"));
                if (!str.isEmpty()) {
                    to += str + QStringLiteral(", ");
                }
                str = values.value(QStringLiteral("cc"));
                if (!str.isEmpty()) {
                    cc += str + QStringLiteral(", ");
                }
                str = values.value(QStringLiteral("bcc"));
                if (!str.isEmpty()) {
                    bcc += str + QStringLiteral(", ");
                }
                str = values.value(QStringLiteral("subject"));
                if (!str.isEmpty()) {
                    subj = str;
                }
                str = values.value(QStringLiteral("body"));
                if (!str.isEmpty()) {
                    body = str;
                }
                str = values.value(QStringLiteral("in-reply-to"));
                if (!str.isEmpty()) {
                    inReplyTo = str;
                }
                QString attach = values.value(QStringLiteral("attachment"));
                if (!attach.isEmpty()) {
                    attachURLs << makeAbsoluteUrl(attach, workingDir);
                }
                attach = values.value(QStringLiteral("attach"));
                if (!attach.isEmpty()) {
                    attachURLs << makeAbsoluteUrl(attach, workingDir);
                }
            } else {
                QUrl url(arg);
                if (url.isValid() && !url.scheme().isEmpty()) {
                    attachURLs += url;
                } else {
                    to += arg + QStringLiteral(", ");
                }
            }
            mailto = true;
        }
```

#### AUTO 


```{c}
auto fetch = qobject_cast<Akonadi::CollectionFetchJob *>(job);
```

#### LAMBDA EXPRESSION 


```{c}
[](const Akonadi::Collection::List &cols) {
        if (cols.count() != 1) {
            return;
        }
        Akonadi::SpecialMailCollections::self()->unregisterCollection(cols.first());
    }
```

#### AUTO 


```{c}
auto hdr = newMsg->headerByType("Disposition-Notification-To")
```

#### AUTO 


```{c}
auto source
```

#### AUTO 


```{c}
const auto modifyJob = qobject_cast<Akonadi::CollectionModifyJob *>(job)
```

#### AUTO 


```{c}
auto fontsTab = new FontsTab();
```

#### LAMBDA EXPRESSION 


```{c}
[this](int state) {
        if (state == Qt::Checked) {
            mSystemTrayCheck->setCheckState(Qt::Checked);
        }
        slotEmitChanged();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : selectedRows) {
        AttachmentPart::Ptr part = mView->model()->data(
            index, MessageComposer::AttachmentModel::AttachmentPartRole).value<AttachmentPart::Ptr>();
        selectedParts.append(part);
    }
```

#### AUTO 


```{c}
auto job = new AliasesExpandJob(mEmailAddresses, mDomainDefaultName, this);
```

#### AUTO 


```{c}
auto *buttonBox = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel | QDialogButtonBox::Help, this);
```

#### AUTO 


```{c}
auto composerCryptoTab = new ComposerCryptoTab();
```

#### AUTO 


```{c}
auto &ifs = changeRecorder()->itemFetchScope();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &str : prefCharsets) {
        QByteArray charset = str.toLatin1().toLower();

        if (charset == "locale") {
            charset = QTextCodec::codecForLocale()->name();

            // Special case for Japanese:
            // (Introduction to i18n, 6.6 Limit of Locale technology):
            // EUC-JP is the de-facto standard for UNIX systems, ISO 2022-JP
            // is the standard for Internet, and Shift-JIS is the encoding
            // for Windows and Macintosh.
            if (charset == "jisx0208.1983-0" || charset == "eucjp" || charset == "shift-jis") {
                charset = "iso-2022-jp";
                // TODO wtf is "jis7"?
            }

            // Special case for Korean:
            if (charset == "ksc5601.1987-0") {
                charset = "euc-kr";
            }
        }
        mPreferredCharsets << charset;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QTreeWidgetItem *item : listItems) {
        delete item;
    }
```

#### AUTO 


```{c}
auto command = new KMTrashMsgCommand(item.parentCollection(), item, -1);
```

#### AUTO 


```{c}
auto action = new QAction(i18n("Filter &Log Viewer..."), this);
```

#### AUTO 


```{c}
const auto &boxGroupName
```

#### AUTO 


```{c}
auto action = qobject_cast< QAction * >(sender());
```

#### AUTO 


```{c}
auto agent = Akonadi::AgentManager::self()->instance(QStringLiteral("akonadi_mailmerge_agent"));
```

#### AUTO 


```{c}
auto identityItem = dynamic_cast<IdentityListViewItem *>(item);
```

#### RANGE FOR STATEMENT 


```{c}
for (MessageComposer::PluginEditor *plugin : lstPlugin) {
        if (plugin->isEnabled()) {
            MessageComposer::PluginEditorInterface *interface = static_cast<MessageComposer::PluginEditorInterface *>(plugin->createInterface(this));
            interface->setRichTextEditor(mRichTextEditor);
            interface->setParentWidget(mParentWidget);
            interface->createAction(mActionCollection);
            MessageComposer::PluginComposerInterface *composerInterface = new MessageComposer::PluginComposerInterface;
            composerInterface->setComposerViewBase(mComposerInterface);
            interface->setComposerInterface(composerInterface);
            interface->setPlugin(plugin);
            connect(interface, &MessageComposer::PluginEditorInterface::emitPluginActivated, this, &KMailPluginEditorManagerInterface::slotPluginActivated);
            connect(interface, &MessageComposer::PluginEditorInterface::message, this, &KMailPluginEditorManagerInterface::message);
            connect(interface, &MessageComposer::PluginEditorInterface::insertText, this, &KMailPluginEditorManagerInterface::insertText);
            mListPluginInterface.append(interface);
        }
    }
```

#### AUTO 


```{c}
auto command = new KMReplyCommand(this, currentItem, MessageComposer::ReplyAll, mReaderWin->copyText(), false, tmpl);
```

#### AUTO 


```{c}
auto identityItem = dynamic_cast<IdentityListViewItem *>(selecteditem);
```

#### AUTO 


```{c}
const auto *modifyJob = qobject_cast<Akonadi::CollectionModifyJob *>(job)
```

#### AUTO 


```{c}
auto checkOnStartup = new QAction(i18n("Check mail on startup"), &menu);
```

#### AUTO 


```{c}
auto radio = new QRadioButton(i18n("&With empty fields"), page);
```

#### AUTO 


```{c}
const auto tags = TagMonitorManager::self()->tags();
```

#### AUTO 


```{c}
const auto child = etm->data(idx, Akonadi::EntityTreeModel::CollectionRole).value<Akonadi::Collection>();
```

#### AUTO 


```{c}
auto command = new KMForwardCommand(
        this, selectedMessages, mCurrentFolderSettings->identity(), tmpl, text
        );
```

#### AUTO 


```{c}
auto win = new KMReaderMainWin();
```

#### AUTO 


```{c}
auto job = new MarkAllMessagesAsReadInFolderAndSubFolderJob(this);
```

#### AUTO 


```{c}
auto icon = mModelProxy->data(child, Qt::DecorationRole).value<QIcon>();
```

#### AUTO 


```{c}
auto label = new QLabel(i18n("Mailing list description:"), mGroupWidget);
```

#### AUTO 


```{c}
auto hboxHBoxLayout = new QHBoxLayout(hbox);
```

#### AUTO 


```{c}
static constexpr auto SpecialCollectionInbox = "inbox";
```

#### AUTO 


```{c}
const auto srcCols = mailbox->sourceCollections().toList();
```

#### AUTO 


```{c}
auto *hboxHBoxLayout = new QHBoxLayout(hbox);
```

#### AUTO 


```{c}
auto hdr = mMsg->headerByType("X-KMail-EncryptActionEnabled")
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Akonadi::Collection::List &cols) {
                        for (const auto &col : cols) {
                            new Akonadi::CollectionDeleteJob(col, this);
                        }
                    }
```

#### AUTO 


```{c}
auto messagePtr = messageItem().payload<KMime::Message::Ptr>();
```

#### AUTO 


```{c}
auto job = new Akonadi::ItemMoveJob(mMsg, collection, this);
```

#### AUTO 


```{c}
auto instance = Akonadi::AgentManager::self()->instance(identifier);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Akonadi::Item::List &items, const Akonadi::Collection &srcCollection,
                         const Akonadi::Collection &dstCollection) {
        ReplayNextOnExit replayNext(mMonitor);

        if (const auto srcBox = unifiedMailboxForSource(srcCollection.id())) {
            // Move source collection was our source, unlink the Item from a box
            new Akonadi::UnlinkJob(Akonadi::Collection{srcBox->collectionId()}, items, this);
        }
        if (const auto dstBox = unifiedMailboxForSource(dstCollection.id())) {
            // Move destination collection is our source, link the Item into a box
            new Akonadi::LinkJob(Akonadi::Collection{dstBox->collectionId()}, items, this);
        }
    }
```

#### AUTO 


```{c}
auto item = dynamic_cast<IdentityListViewItem *>(currentItem());
```

#### AUTO 


```{c}
auto *job = new CreateForwardMessageJob;
```

#### AUTO 


```{c}
auto l = new QLabel(i18n("Send &messages in outbox folder:"), group);
```

#### AUTO 


```{c}
auto *edit = qobject_cast<QLineEdit *>(editor);
```

#### AUTO 


```{c}
auto job = new KIO::OpenUrlJob(url, mimename);
```

#### AUTO 


```{c}
auto action = new QAction(QIcon::fromTheme(QStringLiteral("mail-attachment")), i18n("&Attach file"), this);
```

#### AUTO 


```{c}
const auto mailActions = {
        StandardMailActionManager::MarkAllMailAsRead,
        StandardMailActionManager::MoveToTrash,
        StandardMailActionManager::MoveAllToTrash,
        StandardMailActionManager::RemoveDuplicates,
        StandardMailActionManager::EmptyAllTrash,
        StandardMailActionManager::MarkMailAsRead,
        StandardMailActionManager::MarkMailAsUnread,
        StandardMailActionManager::MarkMailAsImportant,
        StandardMailActionManager::MarkMailAsActionItem
    };
```

#### AUTO 


```{c}
auto nameEdit = new QLineEdit(mMailbox->name());
```

#### AUTO 


```{c}
auto job = new Akonadi::ItemFetchJob(mItem);
```

#### AUTO 


```{c}
auto encryption = w.findChild<QLabel *>(QStringLiteral("encryptionindicator"));
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &service) {
        Q_UNUSED(service)
        mUnityServiceAvailable = false;
    }
```

#### AUTO 


```{c}
auto job = new KIO::OpenUrlJob(url);
```

#### AUTO 


```{c}
auto manager = new KColorSchemeManager(this);
```

#### AUTO 


```{c}
auto subjectTab = new SubjectTab();
```

#### AUTO 


```{c}
auto hbox = new QWidget(this);
```

#### AUTO 


```{c}
auto *job = new RemoveDuplicateMailJob(mFolderTreeWidget->folderTreeView()->selectionModel(), this, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &attach : lst) {
                auto job = new MessageComposer::ConvertSnippetVariablesJob(this);
                job->setText(attach);
                auto interface = new MessageComposer::ComposerViewInterface(mComposerBase);
                job->setComposerViewInterface(interface);
                connect(job, &MessageComposer::ConvertSnippetVariablesJob::textConverted, this, [this](const QString &str) {
                    if (!str.isEmpty()) {
                        const QUrl localUrl = QUrl::fromLocalFile(str);
                        AttachmentInfo info;
                        info.url = localUrl;
                        addAttachment(QVector<AttachmentInfo>() << info, false);
                    }
                });
                job->start();
            }
```

#### AUTO 


```{c}
const auto addMailBox = [this]() {
        auto mailbox = std::make_unique<UnifiedMailbox>();
        auto editor = new UnifiedMailboxEditor(mailbox.get(), mConfig, this);
        if (editor->exec()) {
            mailbox->setId(mailbox->name()); // assign ID
            addBox(mailbox.get());
            mBoxManager.insertBox(std::move(mailbox));
            mBoxManager.saveBoxes();
        }
        delete editor;
    };
```

#### AUTO 


```{c}
auto switchOffline = new QAction(i18nc("Label to a checkbox, so is either checked/unchecked", "Switch offline on KMail Shutdown"), &menu);
```

#### LAMBDA EXPRESSION 


```{c}
[this] { slotApplyFiltersOnFolder(/* recursive */ true); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Akonadi::Item::List &items, const Akonadi::Collection &srcCollection,
                         const Akonadi::Collection &dstCollection) {
        ReplayNextOnExit replayNext(mMonitor);

        if (const auto srcBox = unifiedMailboxForSource(srcCollection.id())) {
            // Move source collection was our source, unlink the Item from a box
            new Akonadi::UnlinkJob(Akonadi::Collection {srcBox->collectionId()}, items, this);
        }
        if (const auto dstBox = unifiedMailboxForSource(dstCollection.id())) {
            // Move destination collection is our source, link the Item into a box
            new Akonadi::LinkJob(Akonadi::Collection {dstBox->collectionId()}, items, this);
        }
    }
```

#### AUTO 


```{c}
auto formatHelp = new QLabel(
                i18n("<qt><a href=\"whatsthis1\">Custom format information...</a></qt>"), hbox);
```

#### AUTO 


```{c}
const auto *searchJob = qobject_cast<Akonadi::SearchCreateJob *>(job)
```

#### AUTO 


```{c}
auto *job = new NewMessageJob(this);
```

#### AUTO 


```{c}
auto hrd = mMsg->headerByType("X-KMail-Transport")
```

#### AUTO 


```{c}
auto editButton = new QPushButton(QIcon::fromTheme(QStringLiteral("entry-edit")), i18n("Modify"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto source : qAsConst(mSources)) {
                manager->mMonitor.setCollectionMonitored(Akonadi::Collection {source});
                manager->mSourceToBoxMap.insert({ source, this });
            }
```

#### AUTO 


```{c}
auto edit = qobject_cast<MessageComposer::RecipientLineNG *>(line);
```

#### AUTO 


```{c}
auto mainLayout = new QGridLayout(mainWidget);
```

#### RANGE FOR STATEMENT 


```{c}
for (const MailCommon::MailFilter *filter : std::as_const(d->mFilters)) {
            if (!filter->name().compare(uniqueName)) {
                found = true;
                ++counter;
                uniqueName = name;
                uniqueName += QLatin1String(" (") + QString::number(counter) + QLatin1String(")");
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &str : folderList) {
        KConfigGroup oldGroup = settingsrc->group(str);
        cleanupFolderSettings(oldGroup);
    }
```

#### AUTO 


```{c}
auto *job = new RemoveCollectionJob(this);
```

#### AUTO 


```{c}
auto hrd = msg->headerByType("X-KMail-Transport")
```

#### AUTO 


```{c}
auto saveCommand = new KMSaveAttachmentsCommand(this, selectedMessages(), nullptr);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        // boxes loaded, let's sync up
        synchronize();
    }
```

#### AUTO 


```{c}
auto themeConfigButton = new ThemeConfigButton(this, mThemeComboBox);
```

#### AUTO 


```{c}
auto *pageVBoxLayout = new QVBoxLayout;
```

#### AUTO 


```{c}
auto identityTab = new KMail::IdentityPage();
```

#### AUTO 


```{c}
auto interface = static_cast<MessageComposer::PluginEditorGrammarCustomToolsViewInterface *>(plugin->createView(mActionCollection, mCustomToolsWidget));
```

#### AUTO 


```{c}
auto collectionMonitor = new Akonadi::Monitor(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &str) {
                    if (!str.isEmpty()) {
                        const QUrl localUrl = QUrl::fromLocalFile(str);
                        AttachmentInfo info;
                        info.url = localUrl;
                        addAttachment(QVector<AttachmentInfo>() << info, false);
                    }
                }
```

#### AUTO 


```{c}
auto *btns = new QHBoxLayout();
```

#### AUTO 


```{c}
auto action = new QAction(QIcon::fromTheme(QStringLiteral("preferences-desktop-notification")), i18n("Configure &Notifications..."), this);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Akonadi::Item &item, const Akonadi::Collection &collection) {
        ReplayNextOnExit replayNext(mMonitor);

        qCDebug(UNIFIEDMAILBOXAGENT_LOG) << "Item" << item.id() << "added to collection" << collection.id();
        const auto box = unifiedMailboxForSource(collection.id());
        if (!box) {
            qCWarning(UNIFIEDMAILBOXAGENT_LOG) << "Failed to find unified mailbox for source collection " << collection.id();
            return;
        }

        if (box->collectionId() <= -1) {
            qCWarning(UNIFIEDMAILBOXAGENT_LOG) << "Missing box->collection mapping for unified mailbox" << box->id();
            return;
        }

        new Akonadi::LinkJob(Akonadi::Collection{box->collectionId()}, {item}, this);
    }
```

#### AUTO 


```{c}
auto copyParm = new short[ num + 1 ];
```

#### AUTO 


```{c}
auto generalTab = new GeneralTab();
```

#### AUTO 


```{c}
auto *job = new Akonadi::ItemCreateJob(mMsg, collection, this);
```

#### AUTO 


```{c}
auto openCommand = new KMOpenMsgCommand(this, url, overrideEncoding(), this);
```

#### AUTO 


```{c}
auto job = new KIO::ApplicationLauncherJob(service);
```

#### RANGE FOR STATEMENT 


```{c}
for (qint64 id : colIds) {
        auto ifj = new Akonadi::ItemFetchJob{
            Akonadi::Collection{
                id
            }, this
        };
        ifj->setDeliveryOption(Akonadi::ItemFetchJob::EmitItemsInBatches);
        connect(ifj, &Akonadi::ItemFetchJob::itemsReceived,
                this, [=](const Akonadi::Item::List &items) {
            m_filterManager->applySpecificFilters(items, requires, listFilters);
        });
    }
```

#### AUTO 


```{c}
auto mainLayout = new QVBoxLayout(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this, line]() {
        this->slotRecipientFocusLost(line);
    }
```

#### AUTO 


```{c}
auto label = new QLabel(i18nc("%1: number of unread messages "
                                              "%2: total number of messages",
                                              "%1 / %2",
                                              stats.unreadCount(),
                                              stats.count()),
                                        this);
```

#### AUTO 


```{c}
auto *header = new KMime::Headers::Generic("X-KMail-Transport");
```

#### AUTO 


```{c}
auto fetch = new Akonadi::CollectionFetchJob(mCollection,
                                                      Akonadi::CollectionFetchJob::Base);
```

#### AUTO 


```{c}
auto createJob = qobject_cast<Akonadi::CollectionCreateJob *>(job);
```

#### AUTO 


```{c}
auto item = mBoxModel->itemFromIndex(indexes[0]);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Akonadi::Item &item, const Akonadi::Collection &collection) {
        ReplayNextOnExit replayNext(mMonitor);

        qCDebug(UNIFIEDMAILBOXAGENT_LOG) << "Item" << item.id() << "added to collection" << collection.id();
        const auto box = unifiedMailboxForSource(collection.id());
        if (!box) {
            qCWarning(UNIFIEDMAILBOXAGENT_LOG) << "Failed to find unified mailbox for source collection " << collection.id();
            return;
        }

        if (box->collectionId() <= -1) {
            qCWarning(UNIFIEDMAILBOXAGENT_LOG) << "Missing box->collection mapping for unified mailbox" << box->id();
            return;
        }

        new Akonadi::LinkJob(Akonadi::Collection {box->collectionId()}, {item}, this);
    }
```

#### AUTO 


```{c}
auto action = new QAction(i18n("Select Folder with Focus"), this);
```

#### AUTO 


```{c}
auto action = new QAction(QIcon::fromTheme(QStringLiteral("pgp-keys")), i18n("Certificate Manager"), this);
```

#### AUTO 


```{c}
auto btns = new QHBoxLayout();
```

#### RANGE FOR STATEMENT 


```{c}
for (MessageComposer::PluginEditorInterface *interface : qAsConst(mListPluginInterface)) {
            if (auto w = interface->statusBarWidget()) {
                w->setEnabled((interface->applyOnFieldTypes() & type));
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) {
            if (job->error()) {
                qCWarning(KMAIL_LOG) << job->errorString();
                slotFetchCollectionFailed();
            } else {
                auto fetch = static_cast<Akonadi::CollectionFetchJob *>(job);
                slotFetchCollectionDone(fetch->collections());
            }
        }
```

#### AUTO 


```{c}
auto move = new Akonadi::ItemMoveJob(item, draftsSourceCol, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &str : folderList) {
        KConfigGroup oldGroup = settingsrc->group(str);
        cleanupFolderSettings(oldGroup);
        if (oldGroup.keyList().isEmpty()) {
            oldGroup.deleteGroup();
        }
    }
```

#### AUTO 


```{c}
auto openCommand = new KMOpenMsgCommand(this, QUrl(), overrideEncoding(), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (QTreeWidgetItem *item : listItems) {
        if (removeMessage) {
            auto *mailItem = static_cast<SendLaterItem *>(item);
            if (mailItem->info()) {
                Akonadi::Item::Id id = mailItem->info()->itemId();
                if (id != -1) {
                    mListMessagesToRemove << id;
                }
            }
        }
        delete item;
    }
```

#### AUTO 


```{c}
auto ifj = new Akonadi::ItemFetchJob{ Akonadi::Collection{ id }, this };
```

#### AUTO 


```{c}
auto *job = new UndoSendCreateJob(this);
```

#### AUTO 


```{c}
const auto lastSeenEvent = QDateTime::fromSecsSinceEpoch(c.remoteRevision().toLongLong());
```

#### AUTO 


```{c}
auto *job = new Akonadi::ItemFetchJob(item, this);
```

#### AUTO 


```{c}
auto job = new CreateReplyMessageJob;
```

#### AUTO 


```{c}
auto *label = new QLabel(i18n("Select the plugin summaries to show on the summary page."), this);
```

#### AUTO 


```{c}
auto *generalTab = new ReadingTab();
```

#### AUTO 


```{c}
auto readerTab = new ReaderTab();
```

#### AUTO 


```{c}
auto rspacer = new QSpacerItem(1, 10, QSizePolicy::MinimumExpanding, QSizePolicy::MinimumExpanding);
```

#### AUTO 


```{c}
auto edit = qobject_cast<QLineEdit *>(editor);
```

#### AUTO 


```{c}
auto *action = qobject_cast< QAction * >(sender());
```

#### RANGE FOR STATEMENT 


```{c}
for (const MailCommon::TagPtr &tag : std::as_const(msgTagList)) {
        mOriginalMsgTagList.append(MailCommon::TagPtr(new MailCommon::Tag(*tag)));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Akonadi::AgentInstance type : lst) {
        const QString identifier = type.identifier();
        if (identifier.startsWith(QLatin1String("akonadi_pop3_resource"))) {
            numberOfPop3++;
        } else if (identifier.startsWith(QLatin1String("akonadi_imap_resource"))) {
            numberOfImap++;
        } else if (identifier.startsWith(QLatin1String("akonadi_kolab_resource"))) {
            numberOfKolab++;
        } else if (identifier.startsWith(QLatin1String("akonadi_ews_resource"))) {
            numberOfEws++;
        }
        //TODO add more
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : actList) {
        action->setShortcutContext(Qt::WidgetWithChildrenShortcut);
    }
```

#### AUTO 


```{c}
auto *templatesTab = new TemplatesTab();
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Akonadi::Collection::List &list) {
        for (const auto &col : list) {
            if (isUnifiedMailbox(col)) {
                continue;
            }

            try {
                switch (Akonadi::SpecialMailCollections::self()->specialCollectionType(col)) {
                case Akonadi::SpecialMailCollections::Inbox:
                    mMailboxes.at(Common::InboxBoxId)->addSourceCollection(col.id());
                    break;
                case Akonadi::SpecialMailCollections::SentMail:
                    mMailboxes.at(Common::SentBoxId)->addSourceCollection(col.id());
                    break;
                case Akonadi::SpecialMailCollections::Drafts:
                    mMailboxes.at(Common::DraftsBoxId)->addSourceCollection(col.id());
                    break;
                default:
                    continue;
                }
            } catch (const std::out_of_range &) {
                qCWarning(UNIFIEDMAILBOXAGENT_LOG) << "Failed to find a special unified mailbox for source collection" << col.id();
                continue;
            }
        }
    }
```

#### AUTO 


```{c}
auto inboxBox = manager.unifiedMailboxFromCollection(inboxBoxCol.value());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &acc : qAsConst(menuItems)) {
            mSyncAction->addAction(acc);
        }
```

#### AUTO 


```{c}
auto attachmentsTab = new ComposerPageAttachmentsTab();
```

#### AUTO 


```{c}
auto *actionGroup = new QActionGroup(this);
```

#### AUTO 


```{c}
auto *win = static_cast<KMMainWin *>(ktmw);
```

#### AUTO 


```{c}
const auto collection = index.data(Akonadi::EntityTreeModel::CollectionRole).value<Akonadi::Collection>();
```

#### LAMBDA EXPRESSION 


```{c}
[id](MailCommon::MailFilter * lhs, MailCommon::MailFilter * rhs) {
                return lhs->requiredPart(id) < rhs->requiredPart(id);
            }
```

#### AUTO 


```{c}
auto layout = new QVBoxLayout(wrapper);
```

#### LAMBDA EXPRESSION 


```{c}
[type](const Akonadi::Collection::List &cols) {
                if (cols.count() != 1) {
                    qCWarning(UNIFIEDMAILBOXAGENT_LOG) << "Identity special collection retrieval did not find a valid collection";
                    return;
                }
                Akonadi::SpecialMailCollections::self()->registerCollection(type, cols.first());
            }
```

#### AUTO 


```{c}
auto command = new KMSetTagCommand(lst, selectedMessages, KMSetTagCommand::CleanExistingAndAddNew);
```

#### LAMBDA EXPRESSION 


```{c}
[&c](const Akonadi::Item &item) {
                return !item.virtualReferences().contains(c);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::AgentInstance &agent : agents) {
            const QString id = agent.identifier();

            auto it = std::max_element(d->mFilters.constBegin(), d->mFilters.constEnd(),
            [id](MailCommon::MailFilter * lhs, MailCommon::MailFilter * rhs) {
                return lhs->requiredPart(id) < rhs->requiredPart(id);
            });
            d->mRequiredParts[id] = (*it)->requiredPart(id);
            d->mRequiredPartsBasedOnAll = qMax(d->mRequiredPartsBasedOnAll, d->mRequiredParts[id]);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &arg : parser.positionalArguments()) {
            if (arg.startsWith(QStringLiteral("mailto:"), Qt::CaseInsensitive)) {
                const QUrl urlDecoded(QUrl::fromPercentEncoding(arg.toUtf8()));
                QMap<QString, QString> values = MessageCore::StringUtil::parseMailtoUrl(urlDecoded);
                if (!values.value(QStringLiteral("to")).isEmpty()) {
                    to += values.value(QStringLiteral("to")) + QStringLiteral(", ");
                }
                if (!values.value(QStringLiteral("cc")).isEmpty()) {
                    cc += values.value(QStringLiteral("cc")) + QStringLiteral(", ");
                }
                if (!values.value(QStringLiteral("bcc")).isEmpty()) {
                    bcc += values.value(QStringLiteral("bcc")) + QStringLiteral(", ");
                }
                if (!values.value(QStringLiteral("subject")).isEmpty()) {
                    subj = values.value(QStringLiteral("subject"));
                }
                if (!values.value(QStringLiteral("body")).isEmpty()) {
                    body = values.value(QStringLiteral("body"));
                }
                if (!values.value(QStringLiteral("in-reply-to")).isEmpty()) {
                    inReplyTo = values.value(QStringLiteral("in-reply-to"));
                }
                QString attach = values.value(QStringLiteral("attachment"));
                if (!attach.isEmpty()) {
                    attachURLs << makeAbsoluteUrl(attach, workingDir);
                }
                attach = values.value(QStringLiteral("attach"));
                if (!attach.isEmpty()) {
                    attachURLs << makeAbsoluteUrl(attach, workingDir);
                }

            } else {
                QUrl url(arg);
                if (url.isValid() && !url.scheme().isEmpty()) {
                    attachURLs += url;
                } else {
                    to += arg + QStringLiteral(", ");
                }
            }
            mailto = true;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &col : list) {
            if (!isUnifiedMailbox(col) || col.parentCollection() == Akonadi::Collection::root()) {
                continue;
            }

            mMailboxes.at(col.name())->setCollectionId(col.id());
        }
```

#### AUTO 


```{c}
const auto srcCols = mailbox->sourceCollections().values();
```

#### AUTO 


```{c}
auto attachmentController = new KMail::AttachmentController(attachmentModel, attachmentView, this);
```

#### AUTO 


```{c}
auto *job = qobject_cast<ReadPasswordJob *>(baseJob);
```

#### AUTO 


```{c}
auto aggregationConfigButton = new AggregationConfigButton(group, mAggregationComboBox);
```

#### AUTO 


```{c}
auto *mimeProxy = new Akonadi::EntityMimeTypeFilterModel(this);
```

#### AUTO 


```{c}
auto action = new QAction(i18n("Edit \"Out of Office\" Replies..."), this);
```

#### AUTO 


```{c}
auto *dictionaryComboBox = findChild<Sonnet::DictionaryComboBox *>(QStringLiteral("m_langCombo"));
```

#### AUTO 


```{c}
auto *info = SendLaterUtil::readSendLaterInfo(group);
```

#### AUTO 


```{c}
auto line = qobject_cast<MessageComposer::RecipientLineNG *>(line_);
```

#### AUTO 


```{c}
auto page = new SecurityPage(parent);
```

#### AUTO 


```{c}
auto *hbl = new QHBoxLayout();
```

#### AUTO 


```{c}
auto hline = new QFrame(mMainWidget);
```

#### AUTO 


```{c}
auto job = new Akonadi::CollectionFetchJob(Akonadi::Collection::root(), Akonadi::CollectionFetchJob::Recursive, this);
```

#### AUTO 


```{c}
auto maxCountlabel = new QLabel(i18n("Maximum number of archive:"), this);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Akonadi::Item::List &items) {
                ReplayNextOnExit replayNext(mMonitor);

                // Monitor did the heavy lifting for us and already figured out that
                // we only monitor the source collection of the Items and translated
                // it into REMOVE change.

                // This relies on Akonadi never mixing Items from different sources or
                // destination during batch-moves.
                const auto parentId = items.first().parentCollection().id();
                const auto box = unifiedMailboxForSource(parentId);
                if (!box) {
                    qCWarning(agent_log) << "Received Remove notification for Items belonging to" << parentId << "which we don't monitor";
                    return;
                }
                if (!box->collectionId()) {
                    qCWarning(agent_log) << "Missing box->collection mapping for unified mailbox" << box->id();
                    return;
                }

                new Akonadi::UnlinkJob(Akonadi::Collection{box->collectionId().value()}, items, this);
            }
```

#### AUTO 


```{c}
auto *command
                = new KMPrintCommand(mParent, commandInfo);
```

#### AUTO 


```{c}
auto inboxSourceCol = collectionForRid(QStringLiteral("res1_inbox"));
```

#### RANGE FOR STATEMENT 


```{c}
for (qint64 id : colIds) {
        auto ifj = new Akonadi::ItemFetchJob{
            Akonadi::Collection{
                id
            }, this
        };
        ifj->setDeliveryOption(Akonadi::ItemFetchJob::EmitItemsInBatches);
        connect(ifj, &Akonadi::ItemFetchJob::itemsReceived,
                this, [=](const Akonadi::Item::List &items) {
            m_filterManager->applySpecificFilters(items, requires, listFilters, static_cast<FilterManager::FilterSet>(filterSet));
        });
    }
```

#### AUTO 


```{c}
auto *printerWin = new KMReaderWin(nullptr, parentWidget(), nullptr);
```

#### AUTO 


```{c}
auto it = mMailboxes.emplace(std::make_pair(box->id(), std::move(box)));
```

#### RANGE FOR STATEMENT 


```{c}
for (FolderArchiveAccountInfo *info : std::as_const(mListAccountInfo)) {
        if (info->instanceName() == instanceName) {
            mListAccountInfo.removeAll(info);
            removeInfo(instanceName);
            break;
        }
    }
```

#### AUTO 


```{c}
auto modifyJob = new Akonadi::ItemModifyJob(itemsToModify, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto source : mSources) {
                manager->mMonitor.setCollectionMonitored(Akonadi::Collection{source});
                manager->mSourceToBoxMap.insert({ source, this });
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto source  : sources) {
        auto fetch = new Akonadi::ItemFetchJob(Akonadi::Collection(source), this);
        fetch->setDeliveryOption(Akonadi::ItemFetchJob::EmitItemsInBatches);
        fetch->fetchScope().setFetchVirtualReferences(true);
        fetch->fetchScope().setCacheOnly(true);
        connect(fetch, &Akonadi::ItemFetchJob::itemsReceived,
                this, [this, c](const Akonadi::Item::List &items) {
            Akonadi::Item::List toLink;
            std::copy_if(items.cbegin(), items.cend(), std::back_inserter(toLink),
                         [&c](const Akonadi::Item &item) {
                return !item.virtualReferences().contains(c);
            });
            if (!toLink.isEmpty()) {
                new Akonadi::LinkJob(c, toLink, this);
            }
        });
    }
```

#### AUTO 


```{c}
auto *itemFetchJob = new Akonadi::ItemFetchJob(selectedMessages, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::AgentInstance &type : lst) {
        const QString identifier = type.identifier();
        if (identifier.startsWith(QLatin1String("akonadi_pop3_resource"))) {
            numberOfPop3++;
        } else if (identifier.startsWith(QLatin1String("akonadi_imap_resource"))) {
            numberOfImap++;
        } else if (identifier.startsWith(QLatin1String("akonadi_kolab_resource"))) {
            numberOfKolab++;
        } else if (identifier.startsWith(QLatin1String("akonadi_ews_resource"))) {
            numberOfEws++;
        } else if (identifier.startsWith(QLatin1String("akonadi_maildir_resource"))) {
            numberOfMaildir++;
        }
        // TODO add more
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : lstItems) {
        const KMime::Message::Ptr msg = MessageCore::Util::message(item);
        if (!msg) {
            return Failed;
        }
        MessageFactoryNG factory(msg, item.id(), MailCommon::Util::updatedCollection(item.parentCollection()));
        factory.setIdentityManager(KMKernel::self()->identityManager());
        factory.setFolderIdentity(MailCommon::Util::folderIdentity(item));

        if (transportId == -1) {
            const MailTransport::TransportAttribute *transportAttribute = item.attribute<MailTransport::TransportAttribute>();
            if (transportAttribute) {
                transportId = transportAttribute->transportId();
                const MailTransport::Transport *transport = MailTransport::TransportManager::self()->transportById(transportId);
                if (!transport) {
                    transportId = -1;
                }
            }
        }

        const MailTransport::SentBehaviourAttribute *sentAttribute = item.attribute<MailTransport::SentBehaviourAttribute>();
        QString fcc;
        if (sentAttribute && (sentAttribute->sentBehaviour() == MailTransport::SentBehaviourAttribute::MoveToCollection)) {
            fcc = QString::number(sentAttribute->moveToCollection().id());
        }

        const KMime::Message::Ptr newMsg = factory.createRedirect(to, cc, bcc, transportId, fcc, identity);
        if (!newMsg) {
            return Failed;
        }

        MessageStatus status;
        status.setStatusFromFlags(item.flags());
        if (!status.isRead()) {
            FilterAction::sendMDN(item, KMime::MDN::Dispatched);
        }

        if (!kmkernel->msgSender()->send(newMsg, method)) {
            qCDebug(KMAIL_LOG) << "KMRedirectCommand: could not redirect message (sending failed)";
            return Failed; // error: couldn't send
        }
    }
```

#### AUTO 


```{c}
static const auto SentBoxId = QStringLiteral("sent-mail");
```

#### AUTO 


```{c}
auto line = qobject_cast<MessageComposer::RecipientLineNG*>(line_);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                         if (!KMailSettings::self()->askEnableUnifiedMailboxes()) {
                             return;
                         }

                         if (kmkernel->accounts().count() <= 1) {
                             return;
                         }

                         KMailSettings::self()->setAskEnableUnifiedMailboxes(false);

                         const auto service = Akonadi::ServerManager::self()->agentServiceName(Akonadi::ServerManager::Agent, QStringLiteral("akonadi_unifiedmailbox_agent"));
                         QDBusInterface iface(service, QStringLiteral("/"), QStringLiteral("org.freedesktop.Akonadi.UnifiedMailboxAgent"),
                                              QDBusConnection::sessionBus(), this);
                         if (!iface.isValid()) {
                             return;
                         }

                         QDBusReply<bool> reply = iface.call(QStringLiteral("enabledAgent"));
                         if (!reply.isValid() || bool(reply)) {
                             return;
                         }

                         const auto answer = KMessageBox::questionYesNo(
                             this, i18n("You have more than one email account set up.\nDo you want to enable the Unified Mailbox feature to "
                                        "show unified content of your inbox, sent and drafts folders?\n"
                                        "You can configure unified mailboxes, create custom ones or\ndisable the feature completely in KMail's Plugin settings."),
                             i18n("Enable Unified Mailboxes?"),
                             KGuiItem(i18n("Enable Unified Mailboxes"), QStringLiteral("dialog-ok")),
                             KGuiItem(i18n("Cancel"), QStringLiteral("dialog-cancel")));
                         if (answer == KMessageBox::Yes) {
                             iface.call(QStringLiteral("setEnableAgent"), true);
                         }
                     }
```

#### AUTO 


```{c}
auto *fjob = qobject_cast<Akonadi::ItemFetchJob *>(job);
```

#### AUTO 


```{c}
auto *proxy = new SearchCollectionProxyModel(unindexedCollections, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const MailCommon::Tag::Ptr &tag : std::as_const(msgTagList)) {
        auto newItem = new TagListWidgetItem(QIcon::fromTheme(tag->iconName), tag->tagName, mTagListBox);
        newItem->setKMailTag(tag);
        if (tag->priority == -1) {
            tag->priority = mTagListBox->count() - 1;
        }
    }
```

#### AUTO 


```{c}
auto box = new QDialogButtonBox(QDialogButtonBox::Yes | QDialogButtonBox::No | QDialogButtonBox::Cancel | QDialogButtonBox::Ok, parent);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &attach : lst) {
                auto *job = new MessageComposer::ConvertSnippetVariablesJob(this);
                job->setText(attach);
                auto *interface = new MessageComposer::ComposerViewInterface(mComposerBase);
                job->setComposerViewInterface(interface);
                connect(job, &MessageComposer::ConvertSnippetVariablesJob::textConverted, this, [this](const QString &str) {
                    if (!str.isEmpty()) {
                        const QUrl localUrl = QUrl::fromLocalFile(str);
                        AttachmentInfo info;
                        info.url = localUrl;
                        addAttachment(QVector<AttachmentInfo>() << info, false);
                    }
                });
                job->start();
            }
```

#### AUTO 


```{c}
auto *act = new QAction(parent);
```

#### AUTO 


```{c}
auto label = new QLabel(i18n("Please close KMail/Kontact before using it."));
```

#### AUTO 


```{c}
auto composer = qobject_cast<MessageComposer::Composer *>(job);
```

#### AUTO 


```{c}
auto *themeLayout = new QHBoxLayout();
```

#### RANGE FOR STATEMENT 


```{c}
for (FollowUpReminder::FollowUpReminderInfo *info : std::as_const(mFollowUpReminderInfoList)) {
            if (!infoStr.isEmpty()) {
                infoStr += QLatin1Char('\n');
            }
            infoStr += infoToStr(info);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) { d->itemFetchJobForFilterDone(job); }
```

#### AUTO 


```{c}
auto *changeRecorder = new Akonadi::ChangeRecorder(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (MailFilter *filter : lstFilters) {
        if (!filter->isEmpty() && filter->configureShortcut() && filter->isEnabled()) {
            QString filterName = QStringLiteral("Filter %1").arg(filter->name());
            QString normalizedName = filterName.replace(QLatin1Char(' '), QLatin1Char('_'));
            if (action(normalizedName)) {
                continue;
            }

            if (!addedSeparator) {
                QAction *a = mApplyFilterActionsMenu->menu()->addSeparator();
                mFilterMenuActions.append(a);
                a = mApplyFilterFolderActionsMenu->menu()->addSeparator();
                mFilterFolderMenuActions.append(a);
                a = mApplyFilterFolderRecursiveActionsMenu->menu()->addSeparator();
                mFilterFolderMenuRecursiveActions.append(a);
                addedSeparator = true;
            }

            KMMetaFilterActionCommand *filterCommand = new KMMetaFilterActionCommand(filter->identifier(), this);
            mFilterCommands.append(filterCommand);

            auto filterAction = filterToAction(filter);
            actionCollection()->addAction(normalizedName, filterAction);
            connect(filterAction, &QAction::triggered,
                    filterCommand, &KMMetaFilterActionCommand::start);
            actionCollection()->setDefaultShortcut(filterAction, filter->shortcut());
            mApplyFilterActionsMenu->menu()->addAction(filterAction);
            mFilterMenuActions.append(filterAction);
            if (filter->configureToolbar()) {
                mFilterTBarActions.append(filterAction);
            }

            filterAction = filterToAction(filter);
            actionCollection()->addAction(normalizedName + QStringLiteral("___folder"), filterAction);
            connect(filterAction, &QAction::triggered,
                    this, [this] { slotApplyFilterOnFolder(/* recursive */ false); });
            mApplyFilterFolderActionsMenu->menu()->addAction(filterAction);
            mFilterFolderMenuActions.append(filterAction);

            filterAction = filterToAction(filter);
            actionCollection()->addAction(normalizedName + QStringLiteral("___folder_recursive"), filterAction);
            connect(filterAction, &QAction::triggered,
                    this, [this] { slotApplyFilterOnFolder(/* recursive */ true); });
            mApplyFilterFolderRecursiveActionsMenu->menu()->addAction(filterAction);
            mFilterFolderMenuRecursiveActions.append(filterAction);
        }
    }
```

#### AUTO 


```{c}
auto *info = new FollowUpReminder::FollowUpReminderInfo();
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Akonadi::Item::List &items) {
                ReplayNextOnExit replayNext(mMonitor);

                // Monitor did the heavy lifting for us and already figured out that
                // we only monitor the source collection of the Items and translated
                // it into REMOVE change.

                // This relies on Akonadi never mixing Items from different sources or
                // destination during batch-moves.
                const auto parentId = items.first().parentCollection().id();
                const auto box = unifiedMailboxForSource(parentId);
                if (!box) {
                    qCWarning(UNIFIEDMAILBOXAGENT_LOG) << "Received Remove notification for Items belonging to" << parentId << "which we don't monitor";
                    return;
                }
                if (!box->collectionId()) {
                    qCWarning(UNIFIEDMAILBOXAGENT_LOG) << "Missing box->collection mapping for unified mailbox" << box->id();
                    return;
                }

                new Akonadi::UnlinkJob(Akonadi::Collection{box->collectionId().value()}, items, this);
            }
```

#### AUTO 


```{c}
auto *attachmentsTab = new AttachmentsTab();
```

#### AUTO 


```{c}
auto *dlg = new KSieveUi::ManageSieveScriptsDialog(&provider);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : lstRepo) {
        QDir tempDir(QDir::tempPath() + QLatin1Char('/') + file);
        if (!tempDir.removeRecursively()) {
            fprintf(stderr, "%s was not removed .\n", qPrintable(tempDir.path()));
        } else {
            fprintf(stderr, "%s was removed .\n", qPrintable(tempDir.path()));
        }
    }
```

#### AUTO 


```{c}
auto *listWidgetSearchLine = dlg.findChild<KListWidgetSearchLine *>(QStringLiteral("searchline"));
```

#### AUTO 


```{c}
auto action = new QAction(i18n("&Previous Message"), this);
```

#### AUTO 


```{c}
auto filterAction = new QAction(QIcon::fromTheme(icon), displayText, actionCollection());
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
            slotApplyFiltersOnFolder(/* recursive */ false);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (MessageViewer::MessageViewerCheckBeforeDeletingPlugin *plugin : lstPlugin) {
        if (plugin->isEnabled()) {
            auto interface = static_cast<MessageViewer::MessageViewerCheckBeforeDeletingInterface *>(plugin->createInterface(this));
            interface->setParentWidget(mParentWidget);
            interface->createActions(mActionCollection);
            mActions.append(interface->actions());
            mListPluginInterface.append(interface);
        }
    }
```

#### AUTO 


```{c}
auto task = new ScheduledArchiveTask(this, info, Akonadi::Collection(info->saveCollectionId()), true /*immediat*/);
```

#### AUTO 


```{c}
auto job = new Akonadi::RemoveDuplicatesJob(lst, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &acc : qAsConst(menuItems)) {
        mSyncAction->addAction(acc);
    }
```

#### AUTO 


```{c}
auto topLayout = new QVBoxLayout(canvas);
```

#### AUTO 


```{c}
auto *mainLayout = new QHBoxLayout(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto source : qAsConst(mSources)) {
                manager->mMonitor.setCollectionMonitored(Akonadi::Collection{source});
                manager->mSourceToBoxMap.insert({ source, this });
            }
```

#### AUTO 


```{c}
auto *job = new Akonadi::ItemFetchJob(mCurrentItem);
```

#### AUTO 


```{c}
auto list = new Akonadi::CollectionFetchJob(Akonadi::Collection::root(), Akonadi::CollectionFetchJob::Recursive, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &server : qAsConst(mServerActive)) {
        auto *lab = new ServerLabel(server);
        connect(lab, &ServerLabel::clicked, this, &VacationScriptIndicatorWidget::clicked);
        mBoxLayout->addWidget(lab);
    }
```

#### AUTO 


```{c}
auto *attachmentView = new KMail::AttachmentView(attachmentModel, mSplitter);
```

#### AUTO 


```{c}
auto charsetTab = new CharsetTab();
```

#### LAMBDA EXPRESSION 


```{c}
[&rid](const Akonadi::Collection &col) {
            return col.remoteId() == rid;
        }
```

#### AUTO 


```{c}
auto *lay = new QHBoxLayout(mTagSettingGroupBox);
```

#### AUTO 


```{c}
auto lab = new ServerLabel(server);
```

#### RANGE FOR STATEMENT 


```{c}
for (const MailCommon::Tag::Ptr &tag : qAsConst(mTags)) {
                if (tag->id() == it.key()) {
                    label = tag->name();
                    break;
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this, tagName] {
        onSignalMapped(tagName);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &metaData : metaDataList) {
        dlg->addModule(metaData);
    }
```

#### AUTO 


```{c}
auto item = new PluginItem(plugin, mPluginView);
```

#### AUTO 


```{c}
const auto sourceCollections = box->sourceCollections();
```

#### AUTO 


```{c}
auto *widgetStack = new QStackedWidget(this);
```

#### AUTO 


```{c}
auto topLayout = new QVBoxLayout(this);
```

#### AUTO 


```{c}
auto composer = qobject_cast< ::MessageComposer::Composer * >(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &arg : parser.positionalArguments()) {
            if (arg.startsWith(QLatin1String("mailto:"), Qt::CaseInsensitive)) {
                const QUrl urlDecoded(QUrl::fromPercentEncoding(arg.toUtf8()));
                QMap<QString, QString> values = MessageCore::StringUtil::parseMailtoUrl(urlDecoded);
                for (auto it = values.cbegin(), end = values.cend(); it != end; ++it) {
                    const QString key = it.key();
                    if (key == QLatin1Literal("to")) {
                        if (!it->isEmpty()) {
                            to += *it + QStringLiteral(", ");
                        }
                    } else if (key == QLatin1Literal("cc")) {
                        if (!it->isEmpty()) {
                            cc += *it + QStringLiteral(", ");
                        }
                    } else if (key == QLatin1Literal("bcc")) {
                        if (!it->isEmpty()) {
                            bcc += *it + QStringLiteral(", ");
                        }
                    } else if (key == QLatin1Literal("subject")) {
                        subj = it.value();
                    } else if (key == QLatin1Literal("body")) {
                        body = it.value();
                    } else if (key == QLatin1Literal("in-reply-to")) {
                        inReplyTo = it.value();
                    } else if (key == QLatin1Literal("attachment") || key == QLatin1Literal("attach")) {
                        if (!it->isEmpty()) {
                            attachURLs << makeAbsoluteUrl(*it, workingDir);
                        }
                    }
                }
            } else {
                QUrl url(arg);
                if (url.isValid() && !url.scheme().isEmpty()) {
                    attachURLs += url;
                } else {
                    to += arg + QStringLiteral(", ");
                }
            }
            mailto = true;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const AttachmentPart::Ptr &part : std::as_const(toRemove)) {
            mModel->removeAttachment(part);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, view]() {
        const auto indexes = view->selectionModel()->selectedIndexes();
        if (!indexes.isEmpty()) {
            auto item = mBoxModel->itemFromIndex(indexes[0]);
            auto mailbox = item->data().value<UnifiedMailbox *>();
            auto editor = new UnifiedMailboxEditor(mailbox, mConfig, this);
            if (editor->exec()) {
                item->setText(mailbox->name());
                item->setIcon(QIcon::fromTheme(mailbox->icon()));
            }
        }
    }
```

#### AUTO 


```{c}
const auto linkedItems = itemLinkedSignalSpy.at(0).at(0).value<Akonadi::Item::List>();
```

#### AUTO 


```{c}
auto gvlay = new QVBoxLayout(group);
```

#### AUTO 


```{c}
auto groupLayout = new QGridLayout(mGroupWidget);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Tag &tag : std::as_const(mTags)) {
        if (!tag.isValid()) {
            auto createJob = new Akonadi::TagCreateJob(tag, this);
            connect(createJob, &Akonadi::TagCreateJob::result, this, &KMSetTagCommand::slotModifyItemDone);
        } else {
            mCreatedTags << tag;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const MailCommon::MailFilter *filter : qAsConst(d->mFilters)) {
            if (!filter->name().compare(uniqueName)) {
                found = true;
                ++counter;
                uniqueName = name;
                uniqueName += QLatin1String(" (") + QString::number(counter) + QLatin1String(")");
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const MailCommon::MailFilter *filter : std::as_const(mFilters)) {
        if (filter->applyOnAccount(accountId)) {
            return true;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, finishedCb = std::move(finishedCb)]() {
        qCDebug(UNIFIEDMAILBOXAGENT_LOG) << "Finished callback: enabling change recorder";
        // Only now start processing changes from change recorder
        connect(&mMonitor, &Akonadi::ChangeRecorder::changesAdded, &mMonitor, &Akonadi::ChangeRecorder::replayNext, Qt::QueuedConnection);
        // And start replaying any potentially pending notification
        QTimer::singleShot(0, &mMonitor, &Akonadi::ChangeRecorder::replayNext);

        if (finishedCb) {
            finishedCb();
        }
    }
```

#### AUTO 


```{c}
auto searchWidget = new QWidget(this);
```

#### AUTO 


```{c}
auto action = new QAction(i18n("Filter on &Subject..."), this);
```

#### AUTO 


```{c}
auto action = new QAction(i18n("Filter on &Cc..."), this);
```

#### AUTO 


```{c}
auto *backupJob = new MailCommon::BackupJob();
```

#### AUTO 


```{c}
auto *mailItem = static_cast<SendLaterItem *>(mWidget->treeWidget->topLevelItem(i));
```

#### AUTO 


```{c}
auto *printingTab = new MiscPagePrintingTab();
```

#### AUTO 


```{c}
auto mailbox = createUnifiedMailbox(QStringLiteral("Test1"), QStringLiteral("Test 1"),
                                            { QStringLiteral("res1_inbox") });
```

#### AUTO 


```{c}
auto hrd = mMsg->headerByType("X-KMail-Link-Message")
```

#### RANGE FOR STATEMENT 


```{c}
for (StandardActionManager::Type favoriteAction : favoriteActions) {
            mAkonadiStandardActionManager->createAction(favoriteAction);
        }
```

#### AUTO 


```{c}
auto *job = new Akonadi::ContactSearchJob(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : urlList) {
                        if (url.isValid()) {
                            AttachmentInfo info;
                            info.url = url;
                            infoList.append(info);
                        }
                    }
```

#### AUTO 


```{c}
auto *attribute = collection.attribute<Akonadi::EntityDisplayAttribute>(Akonadi::Collection::AddIfMissing);
```

#### LAMBDA EXPRESSION 


```{c}
[this, finishedCb = std::move(finishedCb)]() {
        saveBoxes();
        if (finishedCb) {
            finishedCb();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (MessageComposer::PluginEditorConvertText *plugin : lstPlugin) {
        if (plugin->isEnabled()) {
            MessageComposer::PluginEditorConvertTextInterface *interface = static_cast<MessageComposer::PluginEditorConvertTextInterface *>(plugin->createInterface(mActionCollection, this));
            interface->setRichTextEditor(mRichTextEditor);
            interface->setParentWidget(mParentWidget);
            interface->setPlugin(plugin);
            mListPluginInterface.append(interface);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &message) {
        PimCommon::BroadcastStatus::instance()->setStatusMsg(message);
    }
```

#### AUTO 


```{c}
const auto pop3ResourceMap = MailCommon::Kernel::pop3ResourceTargetCollection();
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Akonadi::Collection::List &list) {
        for (const auto &col : list) {
            if (!isUnifiedMailbox(col) || col.parentCollection() == Akonadi::Collection::root()) {
                continue;
            }

            mMailboxes.at(col.name())->setCollectionId(col.id());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto pop3ColId : pop3ResourceMap) {
                if (collection.id() == pop3ColId) {
                    changeRecorder()->setCollectionMonitored(collection, true);
                    break;
                }
            }
```

#### AUTO 


```{c}
const auto fetchJob = qobject_cast<Akonadi::CollectionFetchJob *>(job);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        if (!KMailSettings::self()->askEnableUnifiedMailboxes()) {
            return;
        }

        if (kmkernel->accounts().count() <= 1) {
            return;
        }

        const auto service = Akonadi::ServerManager::self()->agentServiceName(Akonadi::ServerManager::Agent, QStringLiteral("akonadi_unifiedmailbox_agent"));
        QDBusInterface iface(service, QStringLiteral("/"), QStringLiteral("org.freedesktop.Akonadi.UnifiedMailboxAgent"),
                             QDBusConnection::sessionBus(), this);
        if (!iface.isValid()) {
            return;
        }

        QDBusReply<bool> reply = iface.call(QStringLiteral("enabledAgent"));
        if (!reply.isValid() || bool(reply)) {
            return;
        }

        const auto answer = KMessageBox::questionYesNo(
            this, i18n("You have more than one email account set up. Do you want to enable the Unified Mailbox feature to "
                        "show unified content of your inbox, sent and drafts folders?\n"
                        "You can configure unified mailboxes, create custom ones or disable the feature completely in KMail's Plugin settings."),
            i18n("Enable Unified Mailboxes?"),
            KGuiItem(i18n("Enable Unified Mailboxes"), QStringLiteral("dialog-ok")),
            KGuiItem(i18n("Cancel"), QStringLiteral("dialog-cancel")));
        if (answer == KMessageBox::Yes) {
            iface.call(QStringLiteral("setEnableAgent"), true);
        }

        KMailSettings::self()->setAskEnableUnifiedMailboxes(false);
    }
```

#### AUTO 


```{c}
const auto col = CommonKernel->collectionFromId(mSettings.mItem.parentCollection().id());
```

#### AUTO 


```{c}
const auto modelCol = etm->data(idx, Akonadi::EntityTreeModel::CollectionRole).value<Akonadi::Collection>();
```

#### RANGE FOR STATEMENT 


```{c}
for (qint64 id: collections) {
        auto ifj = new Akonadi::ItemFetchJob{ Akonadi::Collection{ id }, this };
        ifj->setDeliveryOption(Akonadi::ItemFetchJob::EmitItemsInBatches);
        connect(ifj, &Akonadi::ItemFetchJob::itemsReceived,
                this, [=](const Akonadi::Item::List &items) {
                    m_filterManager->applyFilters(items, static_cast<FilterManager::FilterSet>(filterSet));
                });
    }
```

#### AUTO 


```{c}
auto *groupGridLayout = new QGridLayout();
```

#### RANGE FOR STATEMENT 


```{c}
for (const MailCommon::Tag::Ptr &tag : qAsConst(mTags)) {
        if (tag->id() == akonadiTag.id()) {
            mTags.removeAll(tag);
            break;
        }
    }
```

#### AUTO 


```{c}
auto w = new searchdbustest;
```

#### LAMBDA EXPRESSION 


```{c}
[this] { slotApplyFilterOnFolder(/* recursive */ false); }
```

#### AUTO 


```{c}
auto modifyJob = new Akonadi::ItemModifyJob(item, this);
```

#### AUTO 


```{c}
auto page = new QFrame(this);
```

#### AUTO 


```{c}
auto about = new KAboutData(QStringLiteral("kontactsummary"),
                                i18n("kontactsummary"),
                                QString(),
                                i18n("KDE Kontact Summary"),
                                KAboutLicense::GPL,
                                i18n("(c), 2004 Tobias Koenig"));
```

#### AUTO 


```{c}
auto *composer = qobject_cast< ::MessageComposer::Composer * >(job);
```

#### AUTO 


```{c}
auto initKeyCache()
{
    using namespace Kleo;

    // set up automatic update of the key cache on changes in the key ring
    const auto keyCache = KeyCache::mutableInstance();
    auto watcher = std::make_shared<FileSystemWatcher>();
    watcher->whitelistFiles(gnupgFileWhitelist());
    watcher->addPath(gnupgHomeDirectory());
    watcher->setDelay(1000);
    keyCache->addFileSystemWatcher(watcher);

    return KeyCache::instance();
}
```

#### AUTO 


```{c}
auto enabledByDefaultCB = findChild<QCheckBox *>(QStringLiteral("kcfg_autodetectLanguage"));
```

#### AUTO 


```{c}
auto job = new Akonadi::ItemMoveJob(*trashIt, trash, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Collection &col : std::as_const(mCollectionId)) {
                lst << col.id();
            }
```

#### AUTO 


```{c}
auto prefereText = menu.findChild<KToggleAction *>(QStringLiteral("prefer-text-action"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : lstItems) {
        const KMime::Message::Ptr msg = MessageComposer::Util::message(item);
        if (!msg) {
            return Failed;
        }
        MessageFactoryNG factory(msg, item.id(), CommonKernel->collectionFromId(item.parentCollection().id()));
        factory.setIdentityManager(KMKernel::self()->identityManager());
        factory.setFolderIdentity(MailCommon::Util::folderIdentity(item));

        if (transportId == -1) {
            const auto transportAttribute = item.attribute<MailTransport::TransportAttribute>();
            if (transportAttribute) {
                transportId = transportAttribute->transportId();
                const MailTransport::Transport *transport = MailTransport::TransportManager::self()->transportById(transportId);
                if (!transport) {
                    transportId = -1;
                }
            }
        }

        const auto sentAttribute = item.attribute<MailTransport::SentBehaviourAttribute>();
        QString fcc;
        if (sentAttribute && (sentAttribute->sentBehaviour() == MailTransport::SentBehaviourAttribute::MoveToCollection)) {
            fcc = QString::number(sentAttribute->moveToCollection().id());
        }

        const KMime::Message::Ptr newMsg = factory.createRedirect(to, cc, bcc, transportId, fcc, identity);
        if (!newMsg) {
            return Failed;
        }

        MessageStatus status;
        status.setStatusFromFlags(item.flags());
        if (!status.isRead()) {
            FilterAction::sendMDN(item, KMime::MDN::Dispatched);
        }

        if (!kmkernel->msgSender()->send(newMsg, method)) {
            qCDebug(KMAIL_LOG) << "KMRedirectCommand: could not redirect message (sending failed)";
            return Failed; // error: couldn't send
        }
    }
```

#### AUTO 


```{c}
auto searchDescription = mFolder.attribute<Akonadi::SearchDescriptionAttribute>(Akonadi::Collection::AddIfMissing);
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) {
                d->modifyJobResult(job);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &arg : parser.positionalArguments()) {
            if (arg.startsWith(QStringLiteral("mailto:"), Qt::CaseInsensitive)) {
                const QUrl urlDecoded(QUrl::fromPercentEncoding(arg.toUtf8()));
                QMap<QString, QString> values = MessageCore::StringUtil::parseMailtoUrl(urlDecoded);
                QString str = values.value(QStringLiteral("to"));
                if (!str.isEmpty()) {
                    to += str + QStringLiteral(", ");
                }
                str = values.value(QStringLiteral("cc"));
                if (!str.isEmpty()) {
                    cc += str + QStringLiteral(", ");
                }
                str = values.value(QStringLiteral("bcc"));
                if (!str.isEmpty()) {
                    bcc += str + QStringLiteral(", ");
                }
                str = values.value(QStringLiteral("subject"));
                if (!str.isEmpty()) {
                    subj = str;
                }
                str = values.value(QStringLiteral("body"));
                if (!str.isEmpty()) {
                    body = str;
                }
                str = values.value(QStringLiteral("in-reply-to"));
                if (!str.isEmpty()) {
                    inReplyTo = str;
                }
                QString attach = values.value(QStringLiteral("attachment"));
                if (!attach.isEmpty()) {
                    attachURLs << makeAbsoluteUrl(attach, workingDir);
                }
                attach = values.value(QStringLiteral("attach"));
                if (!attach.isEmpty()) {
                    attachURLs << makeAbsoluteUrl(attach, workingDir);
                }

            } else {
                QUrl url(arg);
                if (url.isValid() && !url.scheme().isEmpty()) {
                    attachURLs += url;
                } else {
                    to += arg + QStringLiteral(", ");
                }
            }
            mailto = true;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &server : qAsConst(mServerActive)) {
        ServerLabel *lab = new ServerLabel(server);
        connect(lab, &ServerLabel::clicked, this, &VacationScriptIndicatorWidget::clicked);
        mBoxLayout->addWidget(lab);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Akonadi::Item::List &lst) {d->slotItemsFetchedForFilter(lst); }
```

#### LAMBDA EXPRESSION 


```{c}
[=](const Akonadi::Item::List &items) {
                    m_filterManager->applySpecificFilters(items, requires, listFilters);
                }
```

#### LAMBDA EXPRESSION 


```{c}
[=](const Akonadi::Item::List &items) {
                    m_filterManager->applyFilters(items, static_cast<FilterManager::FilterSet>(filterSet));
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &alias : aliases) {
        if (alias.trimmed().isEmpty()) {
            continue;
        }
        if (!KEmailAddress::isValidSimpleAddress(alias)) {
            const QString errorMsg(KEmailAddress::simpleEmailAddressErrorMsg());
            KMessageBox::sorry(this, errorMsg, i18n("Invalid Email Alias \"%1\"", alias));
            return;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &filterId : listFilters) {
            foreach (MailCommon::MailFilter *filter, mFilters) {
                if (filter->identifier() == filterId) {
                    listMailFilters << filter;
                    break;
                }
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Akonadi::Item::List &lst) {
        d->slotItemsFetchedForFilter(lst);
    }
```

#### AUTO 


```{c}
auto fetchJob = static_cast<Akonadi::CollectionFetchJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &it : lstItems) {
        if (mInvertMark) {
            //qCDebug(KMAIL_LOG)<<" item ::"<<tmpItem;
            if (it.isValid()) {
                bool myStatus;
                MessageStatus itemStatus;
                itemStatus.setStatusFromFlags(it.flags());
                if (itemStatus & mStatus) {
                    myStatus = true;
                } else {
                    myStatus = false;
                }
                if (myStatus != parentStatus) {
                    continue;
                }
            }
        }
        Akonadi::Item item(it);
        const Akonadi::Item::Flag flag = *(mStatus.statusFlags().constBegin());
        if (mInvertMark) {
            if (item.hasFlag(flag)) {
                item.clearFlag(flag);
                itemsToModify.push_back(item);
            } else {
                item.setFlag(flag);
                itemsToModify.push_back(item);
            }
        } else {
            if (!item.hasFlag(flag)) {
                item.setFlag(flag);
                itemsToModify.push_back(item);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (ArchiveMailInfo *oldInfo : std::as_const(mListArchiveInfo)) {
                if (oldInfo->saveCollectionId() == info->saveCollectionId()) {
                    // already in jobscheduler
                    delete info;
                    info = nullptr;
                    break;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &arg : parser.positionalArguments()) {
            if (arg.startsWith(QLatin1String("mailto:"), Qt::CaseInsensitive)) {
                const QUrl urlDecoded(QUrl::fromPercentEncoding(arg.toUtf8()));
                const QList<QPair<QString, QString> > values = MessageCore::StringUtil::parseMailtoUrl(urlDecoded);
                QString previousKey;
                for (int i = 0; i < values.count(); ++i) {
                    const QPair<QString, QString> element = values.at(i);
                    const QString key = element.first.toLower();
                    if (key == QLatin1String("to")) {
                        if (!element.second.isEmpty()) {
                            to += element.second + QStringLiteral(", ");
                        }
                        previousKey.clear();
                    } else if (key == QLatin1String("cc")) {
                        if (!element.second.isEmpty()) {
                            cc += element.second + QStringLiteral(", ");
                        }
                        previousKey.clear();
                    } else if (key == QLatin1String("bcc")) {
                        if (!element.second.isEmpty()) {
                            bcc += element.second + QStringLiteral(", ");
                        }
                        previousKey.clear();
                    } else if (key == QLatin1String("subject")) {
                        subj = element.second;
                        previousKey.clear();
                    } else if (key == QLatin1String("body")) {
                        body = element.second;
                        previousKey = key;
                    } else if (key == QLatin1String("in-reply-to")) {
                        inReplyTo = element.second;
                        previousKey.clear();
                    } else if (key == QLatin1String("attachment") || key == QLatin1String("attach")) {
                        if (!element.second.isEmpty()) {
                            attachURLs << makeAbsoluteUrl(element.second, workingDir);
                        }
                        previousKey.clear();
                    } else {
                        qCWarning(KMAIL_LOG) << "unknown key" << key;
                        //Workaround: https://bugs.kde.org/show_bug.cgi?id=390939
                        //QMap<QString, QString> parseMailtoUrl(const QUrl &url) parses correctly url
                        //But if we have a "&" unknown key we lost it.
                        if (previousKey == QLatin1String("body")) {
                            body += QLatin1Char('&') + key + QLatin1Char('=') + element.second;
                        }
                        //Don't clear previous key.
                    }
                }
            } else {
                QUrl url(arg);
                if (url.isValid() && !url.scheme().isEmpty()) {
                    attachURLs += url;
                } else {
                    to += arg + QStringLiteral(", ");
                }
            }
            mailto = true;
        }
```

#### AUTO 


```{c}
auto mainLayout = new QGridLayout;
```

#### AUTO 


```{c}
auto textLabel = findChild<QLabel *>(QStringLiteral("textLabel1"));
```

#### AUTO 


```{c}
auto job = new Akonadi::ItemFetchJob(mCurrentItem);
```

#### AUTO 


```{c}
const auto ask = [this]() {
        if (!KMailSettings::self()->askEnableUnifiedMailboxes()) {
            return;
        }

        if (kmkernel->accounts().count() <= 1) {
            return;
        }

        const auto service = Akonadi::ServerManager::self()->agentServiceName(Akonadi::ServerManager::Agent, QStringLiteral("akonadi_unifiedmailbox_agent"));
        QDBusInterface iface(service, QStringLiteral("/"), QStringLiteral("org.freedesktop.Akonadi.UnifiedMailboxAgent"),
                             QDBusConnection::sessionBus(), this);
        if (!iface.isValid()) {
            return;
        }

        QDBusReply<bool> reply = iface.call(QStringLiteral("enabledAgent"));
        if (!reply.isValid() || bool(reply)) {
            return;
        }

        const auto answer = KMessageBox::questionYesNo(
            this, i18n("You have more than one email account set up. Do you want to enable the Unified Mailbox feature to "
                        "show unified content of your inbox, sent and drafts folders?\n"
                        "You can configure unified mailboxes, create custom ones or disable the feature completely in KMail's Plugin settings."),
            i18n("Enable Unified Mailboxes?"),
            KGuiItem(i18n("Enable Unified Mailboxes"), QStringLiteral("dialog-ok")),
            KGuiItem(i18n("Cancel"), QStringLiteral("dialog-cancel")));
        if (answer == KMessageBox::Yes) {
            iface.call(QStringLiteral("setEnableAgent"), true);
        }

        KMailSettings::self()->setAskEnableUnifiedMailboxes(false);
    };
```

#### AUTO 


```{c}
auto *infowidget = dlg.findChild<SendLaterWidget *>(QStringLiteral("sendlaterwidget"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const MessageComposer::PluginActionType &actionType : actionTypes) {
                MessageComposer::PluginActionType::Type type = actionType.type();
                QAction *currentAction = actionType.action();
                if (!currentAction) {
                    continue;
                }
                QList<QAction *> lst = mActionHash.value(type);
                if (!lst.isEmpty()) {
                    auto act = new QAction(this);
                    act->setSeparator(true);
                    lst << act << currentAction;
                    mActionHash.insert(type, lst);
                } else {
                    mActionHash.insert(type, QList<QAction *>() << currentAction);
                }
                if (interface->plugin()->hasPopupMenuSupport()) {
                    type = MessageComposer::PluginActionType::PopupMenu;
                    if (currentAction) {
                        lst = mActionHash.value(type);
                        if (!lst.isEmpty()) {
                            auto act = new QAction(this);
                            act->setSeparator(true);
                            lst << act << currentAction;
                            mActionHash.insert(type, lst);
                        } else {
                            mActionHash.insert(type, QList<QAction *>() << currentAction);
                        }
                    }
                }
                if (interface->plugin()->hasToolBarSupport()) {
                    type = MessageComposer::PluginActionType::ToolBar;
                    lst = mActionHash.value(type);
                    if (!lst.isEmpty()) {
                        auto act = new QAction(this);
                        act->setSeparator(true);
                        lst << act << currentAction;
                        mActionHash.insert(type, lst);
                    } else {
                        mActionHash.insert(type, QList<QAction *>() << currentAction);
                    }
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto source : sourceCollections) {
                                       auto col = collectionForId(source);
                                       QVERIFY(col.isValid());
                                       QVERIFY(col.hasAttribute<Akonadi::SpecialCollectionAttribute>());
                                       QCOMPARE(col.attribute<Akonadi::SpecialCollectionAttribute>()->collectionType(), id.toLatin1());
                                   }
```

#### AUTO 


```{c}
auto *hboxHBoxLayout = new QHBoxLayout;
```

#### AUTO 


```{c}
auto *folderCBHLayout = new QHBoxLayout;
```

#### AUTO 


```{c}
auto *job = new Akonadi::ItemDeleteJob(*trashIt, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &mime : mimeTypes) {
        filter += QString::fromLatin1(mime);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::AgentInstance &type : lst) {
        const QString identifier = type.identifier();
        if (identifier.startsWith(QLatin1String("akonadi_pop3_resource"))) {
            numberOfPop3++;
        } else if (identifier.startsWith(QLatin1String("akonadi_imap_resource"))) {
            numberOfImap++;
        } else if (identifier.startsWith(QLatin1String("akonadi_kolab_resource"))) {
            numberOfKolab++;
        } else if (identifier.startsWith(QLatin1String("akonadi_ews_resource"))) {
            numberOfEws++;
        }
        //TODO add more
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const MailCommon::Tag::Ptr &tag : std::as_const(mTagList)) {
        auto item = new QListWidgetItem(QIcon::fromTheme(tag->iconName), tag->tagName, mListTag);
        item->setData(UrlTag, tag->tag().url().url());
        item->setFlags(Qt::ItemIsUserCheckable | Qt::ItemIsEnabled | Qt::ItemIsSelectable);
        item->setCheckState(Qt::Unchecked);
        mListTag->addItem(item);

        if (updatelist) {
            const bool select = mCurrentSelectedTags.contains(tag->tag());
            item->setCheckState(select ? Qt::Checked : Qt::Unchecked);
        } else {
            if (mNumberOfSelectedMessages == 1) {
                const bool hasTag = mSelectedItem.hasTag(tag->tag());
                item->setCheckState(hasTag ? Qt::Checked : Qt::Unchecked);
            } else {
                item->setCheckState(Qt::Unchecked);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Tag &createdTag : qAsConst(mCreatedTags)) {
            const QString url = createdTag.url().url();
            if (!lst.contains(url)) {
                lst.append(url);
            }
        }
```

#### AUTO 


```{c}
const auto service = Akonadi::ServerManager::self()->agentServiceName(Akonadi::ServerManager::Agent, QStringLiteral("akonadi_unifiedmailbox_agent"));
```

#### AUTO 


```{c}
const auto items = retrievedMsgs();
```

#### RANGE FOR STATEMENT 


```{c}
for (PimCommon::CustomToolsPlugin *plugin : lstPlugin) {
        if (plugin->isEnabled()) {
            auto interface =
                static_cast<MessageComposer::PluginEditorGrammarCustomToolsViewInterface *>(plugin->createView(mActionCollection, mCustomToolsWidget));
            mCustomToolsWidget->addCustomToolViewInterface(interface);
            interface->setParentWidget(mParentWidget);
            interface->setRichTextEditor(mRichTextEditor);
        }
    }
```

#### AUTO 


```{c}
auto fetch = new Akonadi::CollectionFetchJob(Akonadi::Collection(colId), Akonadi::CollectionFetchJob::Base, this);
```

#### AUTO 


```{c}
auto *job = new Akonadi::ItemFetchJob(mMessageItem, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KMime::Types::Mailbox &mbox : mailboxes) {
        to->addAddress(mbox);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : qAsConst(mMsgList)) {
        if (!item.isValid()) {
            Q_EMIT messagesTransfered(Failed);
            return;
        }
    }
```

#### AUTO 


```{c}
const auto &box = boxIt.second;
```

#### AUTO 


```{c}
auto job = new ComposeNewMessageJob;
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Collection &collection : std::as_const(collectionList)) {
                    const Akonadi::Collection::Id collectionId = collection.id();
                    if (iface->targetCollection() == collectionId) {
                        // Use default inbox
                        iface->setTargetCollection(CommonKernel->inboxCollectionFolder().id());
                        iface->save();
                        break;
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const MessageCore::AttachmentPart::Ptr &part : list) {
        size += part->size();
    }
```

#### AUTO 


```{c}
auto trashIt = mTrashFolders.find(*cacheIt);
```

#### AUTO 


```{c}
auto layout = new QVBoxLayout;
```

#### AUTO 


```{c}
auto label = new QLabel(i18n("Recognize any sequence of the following prefixes\n"
                                 "(entries are case-insensitive regular expressions):"),
                            group);
```

#### AUTO 


```{c}
auto item = static_cast<FollowUpReminderInfoItem *>(treeWidget->topLevelItem(i));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &attach : lst) {
                MessageComposer::ConvertSnippetVariablesJob *job = new MessageComposer::ConvertSnippetVariablesJob(this);
                job->setText(attach);
                MessageComposer::ComposerViewInterface *interface = new MessageComposer::ComposerViewInterface(mComposerBase);
                job->setComposerViewInterface(interface);
                connect(job, &MessageComposer::ConvertSnippetVariablesJob::textConverted, this, [this](const QString &str) {
                    if (!str.isEmpty()) {
                        const QUrl localUrl = QUrl::fromLocalFile(str);
                        AttachmentInfo info;
                        info.url = localUrl;
                        addAttachment(QList<AttachmentInfo>() << info, false);
                    }
                });
                job->start();
            }
```

#### AUTO 


```{c}
auto *job = new FollowUpReminderJob(this);
```

#### AUTO 


```{c}
auto message = item.payload<KMime::Message::Ptr>();
```

#### LAMBDA EXPRESSION 


```{c}
[&manager, &success](const QString &id, int numSources) {
            success = false;
            auto boxIt = std::find_if(manager.begin(), manager.end(), [&id](const UnifiedMailboxManager::Entry &e) {
                return e.second->id() == id;
            });
            QVERIFY(boxIt != manager.end());
            const auto &box = boxIt->second;
            const auto sourceCollections = box->sourceCollections();
            QCOMPARE(sourceCollections.size(), numSources);
            for (auto source : sourceCollections) {
                auto col = collectionForId(source);
                QVERIFY(col.isValid());
                QVERIFY(col.hasAttribute<Akonadi::SpecialCollectionAttribute>());
                QCOMPARE(col.attribute<Akonadi::SpecialCollectionAttribute>()->collectionType(), id.toLatin1());
            }
            success = true;
        }
```

#### AUTO 


```{c}
auto *createJob = new Akonadi::TagCreateJob(tag, this);
```

#### AUTO 


```{c}
auto win = new KMReaderMainWin(content, MessageViewer::Viewer::Text, charsetStr);
```

#### AUTO 


```{c}
auto checkable = new KCheckableProxyModel(this);
```

#### AUTO 


```{c}
auto *treeWidget = infowidget->findChild<QTreeWidget *>(QStringLiteral("treewidget"));
```

#### LAMBDA EXPRESSION 


```{c}
[id](MailCommon::MailFilter *lhs, MailCommon::MailFilter *rhs) {
                return lhs->requiredPart(id) < rhs->requiredPart(id);
            }
```

#### AUTO 


```{c}
auto *identityItem = dynamic_cast<IdentityListViewItem *>(item);
```

#### AUTO 


```{c}
const auto iconName = KIconDialog::getIcon();
```

#### AUTO 


```{c}
auto sourceBox = manager.unifiedMailboxFromCollection(sentBoxCol);
```

#### AUTO 


```{c}
auto *job = new Akonadi::ItemModifyJob(updateItem);
```

#### AUTO 


```{c}
auto fontsTab = new AppearancePageFontsTab();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &str : prefCharsets) {
        QByteArray charset = str.toLatin1().toLower();

        if (charset == "locale") {
            charset = QTextCodec::codecForLocale()->name();

            // Special case for Japanese:
            // (Introduction to i18n, 6.6 Limit of Locale technology):
            // EUC-JP is the de-facto standard for UNIX systems, ISO 2022-JP
            // is the standard for Internet, and Shift-JIS is the encoding
            // for Windows and Macintosh.
            if (charset == "jisx0208.1983-0" ||
                    charset == "eucjp" ||
                    charset == "shift-jis") {
                charset = "iso-2022-jp";
                // TODO wtf is "jis7"?
            }

            // Special case for Korean:
            if (charset == "ksc5601.1987-0") {
                charset = "euc-kr";
            }
        }
        d->preferredCharsets << charset;
    }
```

#### AUTO 


```{c}
auto info = new FollowUpReminder::FollowUpReminderInfo();
```

#### AUTO 


```{c}
auto filterCommand = new KMMetaFilterActionCommand(filter->identifier(), this);
```

#### AUTO 


```{c}
auto *maingrid = new QHBoxLayout(this);
```

#### AUTO 


```{c}
auto *saver = new ETMViewStateSaver;
```

#### RANGE FOR STATEMENT 


```{c}
for (auto line : lst) {
            slotRecipientAdded(qobject_cast<MessageComposer::RecipientLineNG *>(line));
        }
```

#### AUTO 


```{c}
auto button = new QPushButton(i18n("Clean"), this);
```

#### AUTO 


```{c}
auto *command = new KMPrintCommand(mParent, commandInfo);
```

#### AUTO 


```{c}
const auto msg = job->property("msg").value<Akonadi::Item>();
```

#### AUTO 


```{c}
auto action = new QAction(QIcon::fromTheme(QStringLiteral("mail-send")), i18n("&Send Mail"), this);
```

#### AUTO 


```{c}
auto folderTab = new FolderTab();
```

#### AUTO 


```{c}
auto command = new KMForwardCommand(this, currentItem, 0, tmpl, mReaderWin->copyText());
```

#### AUTO 


```{c}
auto *win = ::qobject_cast<KMail::Composer *>(window)
```

#### AUTO 


```{c}
auto *collectionMonitor = new Akonadi::Monitor(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &attach : lst) {
                MessageComposer::ConvertSnippetVariablesJob *job = new MessageComposer::ConvertSnippetVariablesJob(this);
                job->setText(attach);
                MessageComposer::ComposerViewInterface *interface = new MessageComposer::ComposerViewInterface(mComposerBase);
                job->setComposerViewInterface(interface);
                connect(job, &MessageComposer::ConvertSnippetVariablesJob::textConverted, this, [this](const QString &str) {
                    if (!str.isEmpty()) {
                        const QUrl localUrl = QUrl::fromLocalFile(str);
                        addAttachment(localUrl, QString());
                    }
                });
                job->start();
            }
```

#### AUTO 


```{c}
auto *a = static_cast<Attachment *>(*it);
```

#### RANGE FOR STATEMENT 


```{c}
for (MailFilter *filter : lstFilters) {
        if (!filter->isEmpty() && filter->configureShortcut() && filter->isEnabled()) {
            QString filterName = QStringLiteral("Filter %1").arg(filter->name());
            QString normalizedName = filterName.replace(QLatin1Char(' '), QLatin1Char('_'));
            if (action(normalizedName)) {
                continue;
            }

            if (!addedSeparator) {
                QAction *a = mApplyFilterActionsMenu->menu()->addSeparator();
                mFilterMenuActions.append(a);
                a = mApplyFilterFolderActionsMenu->menu()->addSeparator();
                mFilterFolderMenuActions.append(a);
                a = mApplyFilterFolderRecursiveActionsMenu->menu()->addSeparator();
                mFilterFolderMenuRecursiveActions.append(a);
                addedSeparator = true;
            }

            KMMetaFilterActionCommand *filterCommand = new KMMetaFilterActionCommand(filter->identifier(), this);
            mFilterCommands.append(filterCommand);

            auto filterAction = filterToAction(filter);
            actionCollection()->addAction(normalizedName, filterAction);
            connect(filterAction, &QAction::triggered,
                    filterCommand, &KMMetaFilterActionCommand::start);
            actionCollection()->setDefaultShortcut(filterAction, filter->shortcut());
            mApplyFilterActionsMenu->menu()->addAction(filterAction);
            mFilterMenuActions.append(filterAction);
            if (filter->configureToolbar()) {
                mFilterTBarActions.append(filterAction);
            }

            filterAction = filterToAction(filter);
            actionCollection()->addAction(normalizedName + QStringLiteral("___folder"), filterAction);
            connect(filterAction, &QAction::triggered,
                    this, [this] {
                slotApplyFilterOnFolder(/* recursive */ false);
            });
            mApplyFilterFolderActionsMenu->menu()->addAction(filterAction);
            mFilterFolderMenuActions.append(filterAction);

            filterAction = filterToAction(filter);
            actionCollection()->addAction(normalizedName + QStringLiteral("___folder_recursive"), filterAction);
            connect(filterAction, &QAction::triggered,
                    this, [this] {
                slotApplyFilterOnFolder(/* recursive */ true);
            });
            mApplyFilterFolderRecursiveActionsMenu->menu()->addAction(filterAction);
            mFilterFolderMenuRecursiveActions.append(filterAction);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Tag &tag : qAsConst(mTags)) {
        if (!tag.isValid()) {
            auto *createJob = new Akonadi::TagCreateJob(tag, this);
            connect(createJob, &Akonadi::TagCreateJob::result, this, &KMSetTagCommand::slotModifyItemDone);
        } else {
            mCreatedTags << tag;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &account : accountList) {
        KConfigGroup group = config.group(account);
        FolderArchiveAccountInfo *info = new FolderArchiveAccountInfo(group);
        if (info->enabled()) {
            mListAccountInfo.append(info);
        } else {
            delete info;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Collection &collection : qAsConst(collectionList)) {
                    const Akonadi::Collection::Id collectionId = collection.id();
                    if (iface->targetCollection() == collectionId) {
                        //Use default inbox
                        iface->setTargetCollection(CommonKernel->inboxCollectionFolder().id());
                        iface->save();
                        break;
                    }
                }
```

#### AUTO 


```{c}
auto cmd = new KMFetchMessageCommand(this, msg, win ? win->viewer() : mMsgView->viewer(), win);
```

#### AUTO 


```{c}
const auto requires = MailCommon::SearchRule::CompleteMessage;
```

#### LAMBDA EXPRESSION 


```{c}
[box](const QString &name) {
                box->button(QDialogButtonBox::Ok)->setEnabled(!name.trimmed().isEmpty());
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (MessageComposer::PluginEditor *plugin : lstPlugin) {
        if (plugin->isEnabled()) {
            auto *interface = static_cast<MessageComposer::PluginEditorInterface *>(plugin->createInterface(this));
            auto *composerInterface = new MessageComposer::PluginComposerInterface;
            composerInterface->setComposerViewBase(mComposerInterface);
            interface->setComposerInterface(composerInterface);
            interface->setRichTextEditor(mRichTextEditor);
            interface->setParentWidget(mParentWidget);
            interface->createAction(mActionCollection);
            interface->setPlugin(plugin);
            connect(interface, &MessageComposer::PluginEditorInterface::emitPluginActivated, this, &KMailPluginEditorManagerInterface::slotPluginActivated);
            connect(interface, &MessageComposer::PluginEditorInterface::message, this, &KMailPluginEditorManagerInterface::message);
            connect(interface, &MessageComposer::PluginEditorInterface::insertText, this, &KMailPluginEditorManagerInterface::insertText);
            mListPluginInterface.append(interface);
        }
    }
```

#### AUTO 


```{c}
const auto *sentAttribute = item.attribute<MailTransport::SentBehaviourAttribute>();
```

#### AUTO 


```{c}
auto job
```

#### AUTO 


```{c}
auto action = new QAction(i18n("Select Message with Focus"), this);
```

#### AUTO 


```{c}
auto *info = new FolderArchiveAccountInfo(group);
```

#### AUTO 


```{c}
auto lay = new QHBoxLayout(mTagSettingGroupBox);
```

#### AUTO 


```{c}
auto job = KIO::storedGet(url);
```

#### AUTO 


```{c}
auto command = new KMRedirectCommand(this, selectedMessages);
```

#### AUTO 


```{c}
auto mKMailKernel = new KMKernel();
```

#### AUTO 


```{c}
auto label = new QLabel(i18n("Obtain pic&ture from:"), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KontactInterface::Plugin *i : pluginList) {
        // execute all sync actions but our own
        Q_FOREACH (QAction *j, i->syncActions()) {
            if (j != mSyncAction) {
                j->trigger();
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (qint64 id : colIds) {
        auto ifj = new Akonadi::ItemFetchJob{Akonadi::Collection{id}, this};
        ifj->setDeliveryOption(Akonadi::ItemFetchJob::EmitItemsInBatches);
        connect(ifj, &Akonadi::ItemFetchJob::itemsReceived, this, [=](const Akonadi::Item::List &items) {
            m_filterManager->applySpecificFilters(items, requiresParts, listFilters, static_cast<FilterManager::FilterSet>(filterSet));
        });
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (MessageComposer::PluginEditorConvertText *plugin : lstPlugin) {
        if (plugin->isEnabled()) {
            MessageComposer::PluginEditorConvertTextInterface *interface = static_cast<MessageComposer::PluginEditorConvertTextInterface *>(plugin->createInterface(this));
            interface->setRichTextEditor(mRichTextEditor);
            interface->setParentWidget(mParentWidget);
            interface->createAction(mActionCollection);
            interface->setPlugin(plugin);
            mListPluginInterface.append(interface);
        }
    }
```

#### AUTO 


```{c}
auto job = new Akonadi::AgentInstanceCreateJob(agentType, this);
```

#### AUTO 


```{c}
auto sendingTab = new SendingTab();
```

#### AUTO 


```{c}
auto *vlay = new QVBoxLayout(mainWidget);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &uid : uids) {
        QString em = QString::fromUtf8(uid.email() ? uid.email() : uid.id());
        if (em.isEmpty()) {
            continue;
        }
        if (em[0] == QLatin1Char('<')) {
            em = em.mid(1, em.length() - 2);
        }
        if (em.toLower() == email) {
            return true;
        }
    }
```

#### AUTO 


```{c}
auto *job = new Akonadi::CollectionFetchJob(col, Akonadi::CollectionFetchJob::FirstLevel);
```

#### AUTO 


```{c}
auto composerEditorNg = new KMComposerEditorNg(this, mCryptoStateIndicatorWidget);
```

#### AUTO 


```{c}
const auto item = action->data().value<Akonadi::Item>();
```

#### AUTO 


```{c}
auto innerLayout = qobject_cast<QFormLayout *>(mCollectionViewWidget->layout());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &col : cols) {
                            new Akonadi::CollectionDeleteJob(col, this);
                        }
```

#### AUTO 


```{c}
auto *drag = new QDrag(viewport());
```

#### AUTO 


```{c}
auto *prefereText = menu.findChild<KToggleAction *>(QStringLiteral("prefer-text-action"));
```

#### LAMBDA EXPRESSION 


```{c}
[this] { slotApplyFiltersOnFolder(/* recursive */ false); }
```

#### AUTO 


```{c}
auto *fetchJob = static_cast<Akonadi::TagFetchJob *>(job);
```

#### AUTO 


```{c}
auto *interface = static_cast<MessageComposer::PluginEditorGrammarCustomToolsViewInterface *>(plugin->createView(mActionCollection, mCustomToolsWidget));
```

#### RANGE FOR STATEMENT 


```{c}
for (MessageComposer::PluginEditorInterface *interface : std::as_const(mListPluginInterface)) {
            if (interface->plugin()->hasStatusBarSupport()) {
                mStatusBarWidget.append(interface->statusBarWidget());
            }
        }
```

#### AUTO 


```{c}
auto job = new FolderArchiveAgentJob(this, info, items);
```

#### AUTO 


```{c}
auto command = new KMTrashMsgCommand(mCurrentCollection, select, ref);
```

#### AUTO 


```{c}
auto button = new QPushButton(QStringLiteral("reindex collections"), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (FollowUpReminder::FollowUpReminderInfo *info : qAsConst(mFollowUpReminderInfoList)) {
            if (!infoStr.isEmpty()) {
                infoStr += QLatin1Char('\n');
            }
            infoStr += infoToStr(info);
        }
```

#### AUTO 


```{c}
auto action = new QAction(i18n("Filter on &From..."), this);
```

#### AUTO 


```{c}
auto *sortproxy = new QSortFilterProxyModel(mResultModel);
```

#### AUTO 


```{c}
auto *page = new ComposerPage(parent);
```

#### AUTO 


```{c}
auto helpMenu = new KHelpMenu(this, KAboutData::applicationData(), true);
```

#### AUTO 


```{c}
auto composer = new MessageComposer::Composer();
```

#### AUTO 


```{c}
const auto mailbox = item->data().value<UnifiedMailbox*>();
```

#### AUTO 


```{c}
const auto contact = item.payload<KContacts::Addressee>();
```

#### AUTO 


```{c}
auto it = std::max_element(d->mFilters.constBegin(), d->mFilters.constEnd(),
                                       [id](MailCommon::MailFilter *lhs, MailCommon::MailFilter *rhs) {
                return lhs->requiredPart(id) < rhs->requiredPart(id);
            });
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
                slotApplyFilterOnFolder(/* recursive */ false);
            }
```

#### AUTO 


```{c}
auto addremovegrid = new QHBoxLayout();
```

#### AUTO 


```{c}
const auto requiresParts = MailCommon::SearchRule::CompleteMessage;
```

#### AUTO 


```{c}
auto job = new MessageComposer::ConvertSnippetVariablesJob(this);
```

#### AUTO 


```{c}
auto configureCompletionButton = new QPushButton(i18n("Configure Completion..."), this);
```

#### AUTO 


```{c}
auto boxIt = std::find_if(manager.begin(), manager.end(),
                                                             [&id](const UnifiedMailboxManager::Entry &e) {
                return e.second->id() == id;
            });
```

#### AUTO 


```{c}
auto hlayout = new QHBoxLayout;
```

#### AUTO 


```{c}
auto signature = composer->findChild<QLabel *>(QStringLiteral("signatureindicator"));
```

#### AUTO 


```{c}
auto trashIt = mTrashFolders.begin(), end = mTrashFolders.end();
```

#### AUTO 


```{c}
auto session = new Akonadi::Session("MailFilter Kernel ETM", this);
```

#### AUTO 


```{c}
auto action = new QAction(i18n("Send Now"), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *a : qAsConst(oldActions)) {
            addAction(a);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&id](const std::pair<const QString, std::unique_ptr<UnifiedMailbox> > &box) {
        return box.second->id() == id;
    }
```

#### AUTO 


```{c}
auto radio = new QRadioButton(buttonLabel, hbox);
```

#### AUTO 


```{c}
auto saveCommand = new KMSaveMsgCommand(this, selectedMessages());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &acc : menuItems) {
        mSyncAction->addAction(acc);
    }
```

#### AUTO 


```{c}
auto *job = new Akonadi::ItemFetchJob(mTemplateFolder);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::AgentInstance &type : lst) {
        const QString identifier = type.identifier();
        if (identifier.startsWith(QLatin1String("akonadi_pop3_resource"))) {
            numberOfPop3++;
        } else if (identifier.startsWith(QLatin1String("akonadi_imap_resource"))) {
            numberOfImap++;
        } else if (identifier.startsWith(QLatin1String("akonadi_kolab_resource"))) {
            numberOfKolab++;
        } else if (identifier.startsWith(QLatin1String("akonadi_ews_resource"))) {
            numberOfEws++;
        } else if (identifier.startsWith(QLatin1String("akonadi_maildir_resource"))) {
            numberOfMaildir++;
        }
        //TODO add more
    }
```

#### AUTO 


```{c}
auto modify = new Akonadi::CollectionModifyJob(sentSourceCol.value(), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (Akonadi::AgentInstance type : lst) {
        KConfigGroup group(KMKernel::config(), resourceGroupPattern.arg(type.identifier()));
        if (group.readEntry("CheckOnStartup", false)) {
            if (!type.isOnline()) {
                type.setIsOnline(true);
            }
            type.synchronize();
        }

        // "false" is also hardcoded in ConfigureDialog, don't forget to change there.
        if (group.readEntry("OfflineOnShutdown", false)) {
            if (!type.isOnline()) {
                type.setIsOnline(true);
            }
        }
    }
```

#### AUTO 


```{c}
auto propsIface = new OrgFreedesktopDBusPropertiesInterface(
            QString::fromLatin1(s_fdo_notifications_service),
            QString::fromLatin1(s_fdo_notifications_path),
            dbusConn, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : std::as_const(items)) {
        ++mCurrentProgressCount;

        if ((mTotalProgressCount > 0) && (mCurrentProgressCount != mTotalProgressCount)) {
            const QString statusMsg = i18n("Filtering message %1 of %2", mCurrentProgressCount, mTotalProgressCount);
            Q_EMIT q->progressMessage(statusMsg);
            Q_EMIT q->percent(mCurrentProgressCount * 100 / mTotalProgressCount);
        } else {
            Q_EMIT q->percent(0);
        }

        const bool filterResult = q->process(listMailFilters, item, needsFullPayload, filterSet);

        if (mCurrentProgressCount == mTotalProgressCount) {
            mTotalProgressCount = 0;
            mCurrentProgressCount = 0;
        }

        if (!filterResult) {
            Q_EMIT q->filteringFailed(item);
            // something went horribly wrong (out of space?)
            // CommonKernel->emergencyExit( i18n( "Unable to process messages: " ) + QString::fromLocal8Bit( strerror( errno ) ) );
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : lst) {
        QFile tempFile(QDir::tempPath() + QLatin1Char('/') + file);
        if (!tempFile.remove()) {
            fprintf(stderr, "%s was not removed .\n", qPrintable(tempFile.fileName()));
        } else {
            fprintf(stderr, "%s was removed .\n", qPrintable(tempFile.fileName()));
        }
    }
```

#### AUTO 


```{c}
auto statusBar = new KParts::StatusBarExtension(this);
```

#### AUTO 


```{c}
auto *act
        = new QAction(i18nc("%1 is a 'Contact Owner' or similar action. %2 is a protocol normally web or email though could be irc/ftp or other url variant", "%1 (%2)", item, protocol), this);
```

#### AUTO 


```{c}
auto box = std::find_if(mMailboxes.begin(), mMailboxes.end(), [&id](const std::pair<const QString, std::unique_ptr<UnifiedMailbox>> &box) {
        return box.second->id() == id;
    });
```

#### LAMBDA EXPRESSION 


```{c}
[this](uint val) {slotIdentityChanged(val);}
```

#### AUTO 


```{c}
auto *messageTagTab = new MessageTagTab();
```

#### RANGE FOR STATEMENT 


```{c}
for (Akonadi::StandardMailActionManager::Type mailAction : mailActions) {
        QAction *act = mAkonadiStandardActionManager->createAction(mailAction);
        mAkonadiStandardActionManager->interceptAction(mailAction);
        connect(act, &QAction::triggered, this, &KMReaderMainWin::slotMarkMailAs);
    }
```

#### AUTO 


```{c}
auto session = new Akonadi::Session("Archive Mail Kernel ETM", this);
```

#### AUTO 


```{c}
auto job = new Akonadi::ItemModifyJob(updateItem);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : selectedIndexes) {
            auto part = model()->data(index, MessageComposer::AttachmentModel::AttachmentPartRole).value<AttachmentPart::Ptr>();
            toRemove.append(part);
        }
```

#### AUTO 


```{c}
auto composerInterface = new MessageComposer::PluginComposerInterface;
```

#### AUTO 


```{c}
auto fetchJob = static_cast<Akonadi::TagFetchJob *>(job);
```

#### AUTO 


```{c}
auto saver = new ETMViewStateSaver;
```

#### AUTO 


```{c}
auto fetch = new Akonadi::CollectionFetchJob(Akonadi::Collection(id), Akonadi::CollectionFetchJob::Base);
```

#### AUTO 


```{c}
auto *mKMailKernel = new KMKernel();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &s : list) {
        new Attachment(this, s);
    }
```

#### AUTO 


```{c}
auto inviteTab = new MiscPageInviteTab();
```

#### AUTO 


```{c}
auto layout = new QHBoxLayout(mFrame);
```

#### AUTO 


```{c}
auto command = new KMForwardCommand(this, selectedMessages, mCurrentFolderSettings->identity(), tmpl, text);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::AgentType &type : lstAgent) {
        if (type.identifier() == agentIdentifier) {
            data.mExtraInfo << agentIdentifier;
            data.mExtraInfo << path;
            const bool enabled = agentActivateState(agentIdentifier, path);
            data.mEnableByDefault = enabled;
            data.mName = type.name();
            data.mDescription = type.description();
            data.mIdentifier = type.identifier();
            break;
        }
    }
```

#### AUTO 


```{c}
auto *treeWidget = parent.findChild<QTreeWidget *>(QStringLiteral("treewidget"));
```

#### AUTO 


```{c}
auto mailItem = static_cast<ArchiveMailItem *>(mWidget.treeWidget->topLevelItem(i));
```

#### AUTO 


```{c}
auto model = new Akonadi::ContactsTreeModel(changeRecorder, this);
```

#### AUTO 


```{c}
auto recipient = edit->data().dynamicCast<MessageComposer::Recipient>();
```

#### AUTO 


```{c}
const auto protocol = QGpgME::openpgp();
```

#### AUTO 


```{c}
auto job = new Akonadi::ItemMoveJob(retrievedList, mDestFolder, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *act : actList) {
        MessageViewer::Viewer::DisplayFormatMessage format = static_cast<MessageViewer::Viewer::DisplayFormatMessage>(act->data().toInt());
        if (format == mDisplayMessageFormat) {
            act->setChecked(true);
            break;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&id](const std::pair<const QString, std::unique_ptr<UnifiedMailbox>> &box) {
                                return box.second->id() == id;
                            }
```

#### AUTO 


```{c}
auto *job = new PimCommon::ManageServerSideSubscriptionJob(this);
```

#### AUTO 


```{c}
auto job = new KMComposerUpdateTemplateJob;
```

#### RANGE FOR STATEMENT 


```{c}
for (MessageComposer::PluginEditorCheckBeforeSendInterface *interface : qAsConst(mListPluginInterface)) {
        if (!interface->exec(params)) {
            return false;
        }
    }
```

#### AUTO 


```{c}
auto recipient = job->property("recipient").value<MessageComposer::Recipient::Ptr>();
```

#### AUTO 


```{c}
const auto boxGroups = group.groupList();
```

#### LAMBDA EXPRESSION 


```{c}
[this] { slotApplyFiltersOnFolder(/* recursive */ false);
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (MessageComposer::PluginEditorInterface *interface : std::as_const(mListPluginInterface)) {
            if (static_cast<MessageComposer::PluginEditor *>(interface->plugin())->canProcessKeyEvent()) {
                if (interface->processProcessKeyEvent(event)) {
                    return true;
                }
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) {
        d->itemsFetchJobForFilterDone(job);
    }
```

#### AUTO 


```{c}
auto warningTab = new SecurityPageWarningTab();
```

#### RANGE FOR STATEMENT 


```{c}
for (MailFilter *filter : lstFilters) {
        if (!filter->isEmpty() && filter->configureShortcut() && filter->isEnabled()) {
            QString filterName = QStringLiteral("Filter %1").arg(filter->name());
            filterName.replace(QLatin1Char(' '), QLatin1Char('_'));
            if (action(filterName)) {
                continue;
            }

            if (!addedSeparator) {
                QAction *a = mApplyFilterActionsMenu->menu()->addSeparator();
                mFilterMenuActions.append(a);
                a = mApplyFilterFolderActionsMenu->menu()->addSeparator();
                mFilterFolderMenuActions.append(a);
                a = mApplyFilterFolderRecursiveActionsMenu->menu()->addSeparator();
                mFilterFolderMenuRecursiveActions.append(a);
                addedSeparator = true;
            }

            KMMetaFilterActionCommand *filterCommand = new KMMetaFilterActionCommand(filter->identifier(), this);
            mFilterCommands.append(filterCommand);

            auto filterAction = filterToAction(filter);
            actionCollection()->addAction(filterName, filterAction);
            connect(filterAction, &QAction::triggered,
                    filterCommand, &KMMetaFilterActionCommand::start);
            actionCollection()->setDefaultShortcut(filterAction, filter->shortcut());
            mApplyFilterActionsMenu->menu()->addAction(filterAction);
            mFilterMenuActions.append(filterAction);
            if (filter->configureToolbar()) {
                mFilterTBarActions.append(filterAction);
            }

            filterAction = filterToAction(filter);
            actionCollection()->addAction(filterName + QStringLiteral("___folder"), filterAction);
            connect(filterAction, &QAction::triggered,
                    this, [this] {
                slotApplyFilterOnFolder(/* recursive */ false);
            });
            mApplyFilterFolderActionsMenu->menu()->addAction(filterAction);
            mFilterFolderMenuActions.append(filterAction);

            filterAction = filterToAction(filter);
            actionCollection()->addAction(filterName + QStringLiteral("___folder_recursive"), filterAction);
            connect(filterAction, &QAction::triggered,
                    this, [this] {
                slotApplyFilterOnFolder(/* recursive */ true);
            });
            mApplyFilterFolderRecursiveActionsMenu->menu()->addAction(filterAction);
            mFilterFolderMenuRecursiveActions.append(filterAction);
        }
    }
```

#### AUTO 


```{c}
auto tmpFile = new QTemporaryFile(QStandardPaths::writableLocation(QStandardPaths::TempLocation) + QLatin1String("/ktnef/") + QLatin1String("ktnef_XXXXXX.rtf"));
```

#### AUTO 


```{c}
auto job = new Akonadi::ItemDeleteJob(retrievedList, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const AttachmentPart::Ptr &part : qAsConst(toRemove)) {
            d->model->removeAttachment(part);
        }
```

#### AUTO 


```{c}
const auto lst = KMainWindow::memberList();
```

#### AUTO 


```{c}
auto job = new KIO::CommandLauncherJob(QStringLiteral("kaddressbook"), {}, this);
```

#### AUTO 


```{c}
auto *act = w.findChild<QAction *>(QStringLiteral("sendnow"));
```

#### AUTO 


```{c}
auto label = new QLabel(i18n("Recognize any of the following key words as "
                                    "intention to attach a file:"), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Collection &collection : lstCols) {
        if (isFilterableCollection(collection)) {
            changeRecorder()->setCollectionMonitored(collection, true);
        } else {
            QMap<QString, Akonadi::Collection::Id>::const_iterator i = pop3ResourceMap.constBegin();
            const QMap<QString, Akonadi::Collection::Id>::const_iterator end = pop3ResourceMap.constEnd();
            while (i != end) {
                if (collection.id() == i.value()) {
                    changeRecorder()->setCollectionMonitored(collection, true);
                    break;
                }
                i++;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &mail : lst) {
        if (!emailsAdded.contains(mail)) {
            QListWidgetItem *item = new QListWidgetItem(mListWidget);
            item->setCheckState(Qt::Unchecked);
            item->setText(mail);
            emailsAdded << mail;
        }
    }
```

#### AUTO 


```{c}
auto *info = new FollowUpReminderInfo(group);
```

#### AUTO 


```{c}
auto layoutTab = new LayoutTab();
```

#### AUTO 


```{c}
auto const addressBookJob = new Akonadi::CollectionFetchJob(Akonadi::Collection::root(), Akonadi::CollectionFetchJob::Recursive);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &identity : *KIdentityManagement::IdentityManager::self()) {
        if (!identity.disabledFcc()) {
            fixSpecialCollection(identity.fcc(), Akonadi::SpecialMailCollections::SentMail);
        }
        fixSpecialCollection(identity.drafts(), Akonadi::SpecialMailCollections::Drafts);
        fixSpecialCollection(identity.templates(), Akonadi::SpecialMailCollections::Templates);
    }
```

#### AUTO 


```{c}
auto *listItem = new QTreeWidgetItem(mHeaderList);
```

#### AUTO 


```{c}
auto job = new Kleo::DefaultKeyGenerationJob(this);
```

#### AUTO 


```{c}
const auto sentBox = createUnifiedMailbox(Common::SentBoxId, QStringLiteral("Sent"),
                                                  { QStringLiteral("res1_sent"), QStringLiteral("res2_sent") });
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Akonadi::Collection &col, const QSet<QByteArray> &parts) {
                ReplayNextOnExit replayNext(mMonitor);

                qCDebug(UNIFIEDMAILBOXAGENT_LOG) << "Collection changed:" << parts;
                if (!parts.contains(Akonadi::SpecialCollectionAttribute().type())) {
                    return;
                }

                if (col.hasAttribute<Akonadi::SpecialCollectionAttribute>()) {
                    const auto srcBox = unregisterSpecialSourceCollection(col.id());
                    const auto dstBox = registerSpecialSourceCollection(col);
                    if (srcBox == dstBox) {
                        return;
                    }

                    saveBoxes();

                    if (srcBox && srcBox->sourceCollections().isEmpty()) {
                        removeBox(srcBox->id());
                        return;
                    }

                    if (srcBox) {
                        Q_EMIT updateBox(srcBox);
                    }
                    if (dstBox) {
                        Q_EMIT updateBox(dstBox);
                    }
                } else {
                    if (const auto box = unregisterSpecialSourceCollection(col.id())) {
                        saveBoxes();
                        if (box->sourceCollections().isEmpty()) {
                            removeBox(box->id());
                        } else {
                            Q_EMIT updateBox(box);
                        }
                    }
                }
            }
```

#### AUTO 


```{c}
auto *page = new SecurityPage(parent);
```

#### AUTO 


```{c}
auto *fetch = qobject_cast<Akonadi::CollectionFetchJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (Akonadi::AgentInstance type : lst) {
        const QString identifier = type.identifier();
        KConfigGroup group(KMKernel::config(), resourceGroupPattern.arg(identifier));

        // Keep sync in ConfigureDialog, don't forget to change there.
        if (group.readEntry("OfflineOnShutdown", identifier.startsWith(QLatin1String("akonadi_pop3_resource")) ? true : false)) {
            type.setIsOnline(false);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *filterAction : qAsConst(mFilterMenuActions)) {
        filterAction->setEnabled(count > 0);
    }
```

#### AUTO 


```{c}
auto encryption = composer->findChild<QLabel *>(QStringLiteral("encryptionindicator"));
```

#### AUTO 


```{c}
auto *interface = new MessageComposer::ComposerViewInterface(mComposerBase);
```

#### AUTO 


```{c}
auto *info = new ArchiveMailInfo(group);
```

#### AUTO 


```{c}
auto label = new QLabel(i18n("&Your name:"), tab);
```

#### AUTO 


```{c}
auto command = new KMCopyDecryptedCommand(collection, mMessagePane->selectionAsMessageItemList());
```

#### RANGE FOR STATEMENT 


```{c}
for (FollowUpReminderInfo *info : qAsConst(mFollowUpReminderInfoList)) {
        qCDebug(FOLLOWUPREMINDERAGENT_LOG) << "FollowUpReminderManager::slotCheckFollowUpFinished info:" << info;
        if (!info) {
            continue;
        }
        if (info->messageId() == messageId) {
            info->setAnswerMessageItemId(id);
            info->setAnswerWasReceived(true);
            answerReceived(info->to());
            if (info->todoId() != -1) {
                auto *job = new FollowUpReminderFinishTaskJob(info->todoId(), this);
                connect(job, &FollowUpReminderFinishTaskJob::finishTaskDone, this, &FollowUpReminderManager::slotFinishTaskDone);
                connect(job, &FollowUpReminderFinishTaskJob::finishTaskFailed, this, &FollowUpReminderManager::slotFinishTaskFailed);
                job->start();
            }
            //Save item
            FollowUpReminder::FollowUpReminderUtil::writeFollowupReminderInfo(FollowUpReminder::FollowUpReminderUtil::defaultConfig(), info, true);
            break;
        }
    }
```

#### AUTO 


```{c}
auto iconButton = new QPushButton(QIcon::fromTheme(mMailbox->icon(), QIcon::fromTheme(QStringLiteral("folder-mail"))),
                                                           i18n("Pick icon..."));
```

#### AUTO 


```{c}
auto command = new KMReplyCommand(this,
                                                 currentItem,
                                                 MessageComposer::ReplySmart,
                                                 mReaderWin->copyText(),
                                                 false, tmpl);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : qAsConst(items)) {
        ++mCurrentProgressCount;

        if ((mTotalProgressCount > 0) && (mCurrentProgressCount != mTotalProgressCount)) {
            const QString statusMsg =
                i18n("Filtering message %1 of %2", mCurrentProgressCount, mTotalProgressCount);
            Q_EMIT q->progressMessage(statusMsg);
            Q_EMIT q->percent(mCurrentProgressCount * 100 / mTotalProgressCount);
        } else {
            Q_EMIT q->percent(0);
        }

        const bool filterResult = q->process(listMailFilters, item, needsFullPayload, filterSet);

        if (mCurrentProgressCount == mTotalProgressCount) {
            mTotalProgressCount = 0;
            mCurrentProgressCount = 0;
        }

        if (!filterResult) {
            Q_EMIT q->filteringFailed(item);
            // something went horribly wrong (out of space?)
            //CommonKernel->emergencyExit( i18n( "Unable to process messages: " ) + QString::fromLocal8Bit( strerror( errno ) ) );
        }
    }
```

#### AUTO 


```{c}
auto sentSourceCol = collectionForRid(QStringLiteral("res1_sent"));
```

#### LAMBDA EXPRESSION 


```{c}
[this, c](const Akonadi::Item::List &items) {
            Akonadi::Item::List toLink;
            std::copy_if(items.cbegin(), items.cend(), std::back_inserter(toLink),
                         [&c](const Akonadi::Item &item) {
                return !item.virtualReferences().contains(c);
            });
            if (!toLink.isEmpty()) {
                new Akonadi::LinkJob(c, toLink, this);
            }
        }
```

#### AUTO 


```{c}
auto *mimeData = new QMimeData;
```

#### AUTO 


```{c}
const auto group = mConfig->group("UnifiedMailboxes");
```

#### AUTO 


```{c}
auto *lvItem = dynamic_cast<IdentityListViewItem *>(item);
```

#### AUTO 


```{c}
auto act = new QAction(parent);
```

#### AUTO 


```{c}
auto *buttonBox = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel, this);
```

#### AUTO 


```{c}
auto boxIt = std::find_if(manager.begin(), manager.end(), [&id](const UnifiedMailboxManager::Entry &e) {
                return e.second->id() == id;
            });
```

#### AUTO 


```{c}
auto page = new AppearancePage(parent);
```

#### AUTO 


```{c}
auto manualMailCheck = new QAction(i18nc("Label to a checkbox, so is either checked/unchecked", "Include in Manual Mail Check"), &menu);
```

#### AUTO 


```{c}
auto *item = new QTreeWidgetItem(lv, QStringList(i18nc("@label", "TNEF Attributes")));
```

#### AUTO 


```{c}
auto *mainLayout = new QGridLayout(mainWidget);
```

#### RANGE FOR STATEMENT 


```{c}
for (MessageComposer::PluginEditorConvertTextInterface *interface : std::as_const(mListPluginInterface)) {
            if (interface->plugin()->hasStatusBarSupport()) {
                mStatusBarWidget.append(interface->statusBarWidget());
            }
        }
```

#### AUTO 


```{c}
auto config = KConfig(QStringLiteral("akonadi_indexing_agent"));
```

#### AUTO 


```{c}
auto *readerBoxLayout = new QVBoxLayout(readerBox);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &message) {
         PimCommon::BroadcastStatus::instance()->setStatusMsg(message);
    }
```

#### AUTO 


```{c}
auto job = new Akonadi::ItemFetchJob(mCurrentCollection, this);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            updateHamburgerMenu();
            // Immediately disconnect. We only need to run this once, but on demand.
            // NOTE: The nullptr at the end disconnects all connections between
            // q and mHamburgerMenu's aboutToShowMenu signal.
            disconnect(mHamburgerMenu, &KHamburgerMenu::aboutToShowMenu, this, nullptr);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QFileInfo &file : autoSaveFiles) {
        // Disregard the '.' and '..' folders
        const QString filename = file.fileName();
        if (filename == QLatin1String(".") ||
                filename == QLatin1String("..")
                || file.isDir()) {
            continue;
        }
        qCDebug(KMAIL_LOG) << "Opening autosave file:" << file.absoluteFilePath();
        QFile autoSaveFile(file.absoluteFilePath());
        if (autoSaveFile.open(QIODevice::ReadOnly)) {
            const KMime::Message::Ptr autoSaveMessage(new KMime::Message());
            const QByteArray msgData = autoSaveFile.readAll();
            autoSaveMessage->setContent(msgData);
            autoSaveMessage->parse();

            // Show the a new composer dialog for the message
            KMail::Composer *autoSaveWin = KMail::makeComposer();
            autoSaveWin->setMessage(autoSaveMessage, false, false, false);
            autoSaveWin->setAutoSaveFileName(filename);
            autoSaveWin->show();
            autoSaveFile.close();
        } else {
            KMessageBox::sorry(nullptr, i18n("Failed to open autosave file at %1.\nReason: %2",
                                               file.absoluteFilePath(), autoSaveFile.errorString()),
                               i18n("Opening Autosave File Failed"));
        }
    }
```

#### AUTO 


```{c}
const auto editorGroup = config->group(EditorGroup);
```

#### AUTO 


```{c}
auto dlg = new KSieveUi::SieveDebugDialog(&provider);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &metaData : availablePlugins) {
#if KCMUTILS_VERSION >= QT_VERSION_CHECK(5, 84, 0)
        addModule(metaData);
#else
        addModule(metaData.pluginId());
#endif
    }
```

#### AUTO 


```{c}
auto *const addressBookJob = new Akonadi::CollectionFetchJob(Akonadi::Collection::root(), Akonadi::CollectionFetchJob::Recursive);
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : lstActs) {
        auto subMenu = qobject_cast<KSelectAction *>(action);
        if (subMenu) {
            const QString codecNameToSet = selectCharset(subMenu, encoding);
            if (!codecNameToSet.isEmpty()) {
                return codecNameToSet;
            }
        } else {
            const QString fixedActionText = MimeTreeParser::NodeHelper::fixEncoding(action->text());
            if (KCharsets::charsets()->codecForName(KCharsets::charsets()->encodingForName(fixedActionText)) == KCharsets::charsets()->codecForName(encoding)) {
                return action->text();
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const MessageComposer::PluginActionType &actionType : interface->actionTypes()) {
                MessageComposer::PluginActionType::Type type = actionType.type();
                QAction *currentAction = actionType.action();
                if (!currentAction) {
                    continue;
                }
                QList<QAction *> lst = mActionHash.value(type);
                if (!lst.isEmpty()) {
                    auto *act = new QAction(this);
                    act->setSeparator(true);
                    lst << act << currentAction;
                    mActionHash.insert(type, lst);
                } else {
                    mActionHash.insert(type, QList<QAction *>() << currentAction);
                }
                if (interface->plugin()->hasPopupMenuSupport()) {
                    type = MessageComposer::PluginActionType::PopupMenu;
                    if (currentAction) {
                        lst = mActionHash.value(type);
                        if (!lst.isEmpty()) {
                            auto *act = new QAction(this);
                            act->setSeparator(true);
                            lst << act << currentAction;
                            mActionHash.insert(type, lst);
                        } else {
                            mActionHash.insert(type, QList<QAction *>() << currentAction);
                        }
                    }
                }
                if (interface->plugin()->hasToolBarSupport()) {
                    type = MessageComposer::PluginActionType::ToolBar;
                    lst = mActionHash.value(type);
                    if (!lst.isEmpty()) {
                        auto *act = new QAction(this);
                        act->setSeparator(true);
                        lst << act << currentAction;
                        mActionHash.insert(type, lst);
                    } else {
                        mActionHash.insert(type, QList<QAction *>() << currentAction);
                    }
                }
            }
```

#### AUTO 


```{c}
auto *job = new Akonadi::AgentInstanceCreateJob(agentType, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto a : qAsConst(mFilterFolderMenuRecursiveActions)) {
        a->setEnabled(folderIsValid);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Collection &collection : list) {
        if (collection.isValid()) {
            if (collection.rights() & Akonadi::Collection::CanDeleteItem) {
                lst.append(collection);
            }
        }
    }
```

#### AUTO 


```{c}
auto page = new AccountsPage(parent);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &addr : lst) {
                mComposerBase->recipientsEditor()->addRecipient(addr, MessageComposer::Recipient::Cc);
            }
```

#### AUTO 


```{c}
auto header = new KMime::Headers::Generic("X-KMail-Transport");
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &notify : lstNotify) {
        const QString fullPath = QStandardPaths::locate(QStandardPaths::GenericDataLocation, QLatin1String("knotifications5/") + notify);

        if (!fullPath.isEmpty()) {
            const int slash = fullPath.lastIndexOf(QLatin1Char('/'));
            QString appname = fullPath.right(fullPath.length() - slash - 1);
            appname.remove(QStringLiteral(".notifyrc"));
            if (!appname.isEmpty()) {
                KConfig config(fullPath, KConfig::NoGlobals, QStandardPaths::AppLocalDataLocation);
                KConfigGroup globalConfig(&config, QStringLiteral("Global"));
                const QString icon = globalConfig.readEntry(QStringLiteral("IconName"), QStringLiteral("misc"));
                const QString description = globalConfig.readEntry(QStringLiteral("Comment"), appname);
                m_comboNotify->addItem(QIcon::fromTheme(icon), description, appname);
            }
        }
    }
```

#### AUTO 


```{c}
auto *updowngrid = new QHBoxLayout();
```

#### AUTO 


```{c}
const auto it = changedProperties.find(QStringLiteral("Inhibited"));
```

#### AUTO 


```{c}
auto action = new QAction(i18n("&Expire All Folders"), this);
```

#### AUTO 


```{c}
auto groupBox = new QGroupBox(i18nc("@title:group", "Signature"));
```

#### AUTO 


```{c}
auto *headersTab = new HeadersTab();
```

#### AUTO 


```{c}
auto handle = new WinObjFontHandle;
```

#### AUTO 


```{c}
auto *job = new Akonadi::ItemFetchJob(item);
```

#### AUTO 


```{c}
auto view = new QListView(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        this->updateHamburgerMenu();
        // Immediately disconnect. We only need to run this once, but on demand.
        // NOTE: The nullptr at the end disconnects all connections between
        // q and mHamburgerMenu's aboutToShowMenu signal.
        disconnect(mHamburgerMenu, &KHamburgerMenu::aboutToShowMenu, this, nullptr);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto job : qAsConst(mPendingMoves)) {
            job->kill();
        }
```

#### AUTO 


```{c}
auto menu = new QMenu(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this](QDBusPendingCallWatcher *watcher) {
        QDBusPendingReply<QStringList> reply = *watcher;
        watcher->deleteLater();

        if (reply.isError()) {
            qCWarning(KMAIL_LOG) << "DBus reported an error " << reply.error().message();
            return;
        }

        const QStringList &services = reply.value();

        mUnityServiceAvailable = services.contains(QLatin1String("com.canonical.Unity"));
        if (mUnityServiceAvailable) {
            updateCount();
        }
    }
```

#### AUTO 


```{c}
auto *fetchjob = qobject_cast<Akonadi::ItemFetchJob *>(job);
```

#### AUTO 


```{c}
auto job = new Akonadi::CollectionFetchJob(Akonadi::Collection::root(),
                                                                       Akonadi::CollectionFetchJob::Recursive,
                                                                       this);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        itemsRetrievedIncremental({}, {}); // fake incremental retrieval
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &addr : qAsConst(mEmails)) {
        if (!mEmailWhiteList.contains(addr.trimmed())) {
            QString tname, temail;
            KEmailAddress::extractEmailAddressAndName(addr, temail, tname);    // ignore return value
            // which is always false
            if (tname.startsWith(QLatin1Char('@'))) { //Special case when name is just @foo <...> it mustn't recognize as a valid email
                continue;
            }
            if (tname.contains(QLatin1Char('@'))) { //Potential address
                if (tname.startsWith(QLatin1Char('<')) && tname.endsWith(QLatin1Char('>'))) {
                    tname = tname.mid(1, tname.length() - 2);
                }
                if (tname.startsWith(QLatin1Char('\'')) && tname.endsWith(QLatin1Char('\''))) {
                    tname = tname.mid(1, tname.length() - 2);
                }
                if (temail.toLower() != tname.toLower()) {
                    const QString str = QStringLiteral("(%1)").arg(temail);
                    if (!tname.contains(str, Qt::CaseInsensitive)) {
                        const QStringList lst = tname.trimmed().split(QLatin1Char(' '));
                        if (lst.count() > 1) {
                            const QString firstName = lst.at(0);

                            for (const QString &n : lst) {
                                if (n != firstName) {
                                    mPotentialPhisingEmails.append(addr);
                                    break;
                                }
                            }
                        } else {
                            mPotentialPhisingEmails.append(addr);
                        }
                    }
                }
            }
        }
    }
```

#### AUTO 


```{c}
static const auto MailMimeType = QStringLiteral("message/rfc822");
```

#### AUTO 


```{c}
auto *job = new MarkAllMessagesAsReadInFolderAndSubFolderJob(this);
```

#### AUTO 


```{c}
auto listWidget = dlg.findChild<QListWidget *>(QStringLiteral("list_widget"));
```

#### AUTO 


```{c}
auto hboxHBoxLayout = new QHBoxLayout;
```

#### AUTO 


```{c}
auto *sendingTab = new SendingTab();
```

#### AUTO 


```{c}
auto attribute = new Akonadi::PersistentSearchAttribute();
```

#### AUTO 


```{c}
auto msg = item.payload<KMime::Message::Ptr>();
```

#### AUTO 


```{c}
auto *command = new KMForwardCommand(
        this, selectedMessages, mCurrentFolderSettings->identity(), tmpl, text
        );
```

#### LAMBDA EXPRESSION 


```{c}
[this, urlLabel]() {
                    selectFolder(urlLabel->url());
                }
```

#### AUTO 


```{c}
auto item = new QStandardItem(QIcon::fromTheme(box->icon()), box->name());
```

#### AUTO 


```{c}
const auto data = line->data().dynamicCast<MessageComposer::Recipient>();
```

#### RANGE FOR STATEMENT 


```{c}
for (MessageComposer::SendLaterInfo *info : qAsConst(mListSendLaterInfo)) {
        if (info->itemId() == id) {
            return info;
        }
    }
```

#### AUTO 


```{c}
auto box = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel, this);
```

#### AUTO 


```{c}
auto flatProxy = new KDescendantsProxyModel(this);
```

#### AUTO 


```{c}
auto formLayout = new QFormLayout(this);
```

#### AUTO 


```{c}
auto job = new OpenComposerJob(this);
```

#### AUTO 


```{c}
auto *box = new QDialogButtonBox(QDialogButtonBox::Yes | QDialogButtonBox::No | QDialogButtonBox::Cancel | QDialogButtonBox::Ok, parent);
```

#### AUTO 


```{c}
auto sortModel = new QSortFilterProxyModel(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &addr : lst) {
                mComposerBase->recipientsEditor()->addRecipient(addr, MessageComposer::Recipient::To);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : lst) {
        QDir tempDir(QDir::tempPath() + QLatin1Char('/') + file);
        if (!tempDir.removeRecursively()) {
            fprintf(stderr, "%s was not removed .\n", qPrintable(tempDir.absolutePath()));
        } else {
            fprintf(stderr, "%s was removed .\n", qPrintable(tempDir.absolutePath()));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto t : list) {
        rv.insert(std::move(t));
    }
```

#### AUTO 


```{c}
auto sourceCombo = new QComboBox(this);
```

#### AUTO 


```{c}
const auto &col
```

#### AUTO 


```{c}
auto action = new QAction(QIcon::fromTheme(QStringLiteral("mail-receive")), i18n("Check &Mail"), this);
```

#### AUTO 


```{c}
auto recipient = line->data().dynamicCast<MessageComposer::Recipient>();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            setEnabled(true);
        }
```

#### AUTO 


```{c}
auto tagsettinggrid = new QVBoxLayout();
```

#### AUTO 


```{c}
auto label = new QLabel(i18n("Apply &to:"), this);
```

#### AUTO 


```{c}
const auto &s
```

#### AUTO 


```{c}
auto *job = new Akonadi::CollectionModifyJob(mFolder, this);
```

#### AUTO 


```{c}
auto rspacer = new QSpacerItem(1, 10,
                                    QSizePolicy::MinimumExpanding,
                                    QSizePolicy::MinimumExpanding);
```

#### AUTO 


```{c}
auto buttonBox = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel, this);
```

#### AUTO 


```{c}
auto dialog = new MessageComposer::SendLaterDialog(nullptr);
```

#### AUTO 


```{c}
auto decMsg = MailCommon::CryptoUtils::decryptMessage(msg, wasEncrypted);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const UnifiedMailbox *box) {
                if (!box->collectionId()) {
                    qCWarning(UNIFIEDMAILBOXAGENT_LOG) << "MailboxManager wants us to update Box but does not have its CollectionId!?";
                    return;
                }

                // Schedule collection sync for the box
                synchronizeCollection(box->collectionId().value());
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (MessageViewer::MessageViewerCheckBeforeDeletingInterface *interface : std::as_const(mListPluginInterface)) {
        currentList = interface->exec(currentList);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Akonadi::AgentInstance type : lst) {
        const QString identifier(type.identifier());
        if (PimCommon::Util::isImapResource(identifier) || identifier.contains(POP3_RESOURCE_IDENTIFIER)
            || identifier.contains(QLatin1String("akonadi_maildispatcher_agent")) || type.type().capabilities().contains(QLatin1String("NeedsNetwork"))) {
            type.setIsOnline(goOnline);
        }
    }
```

#### AUTO 


```{c}
auto boxGroup = boxesGroup.group(inbox->id());
```

#### AUTO 


```{c}
auto tagItem = static_cast<TagListWidgetItem *>(mTagListBox->item(i));
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QItemSelection &selected, const QItemSelection &deselected) {
                auto indexes = selected.indexes();
                for (const auto &index : indexes) {
                    mMailbox->addSourceCollection(index.data(Akonadi::EntityTreeModel::CollectionIdRole).toLongLong());
                }
                indexes = deselected.indexes();
                for (const auto &index : indexes) {
                    mMailbox->removeSourceCollection(index.data(Akonadi::EntityTreeModel::CollectionIdRole).toLongLong());
                }
            }
```

#### AUTO 


```{c}
auto infowidget = dlg.findChild<SendLaterWidget *>(QStringLiteral("sendlaterwidget"));
```

#### AUTO 


```{c}
auto act = ::qobject_cast<KToggleAction *>(sender());
```

#### AUTO 


```{c}
auto *themeConfigButton = new ThemeConfigButton(group, mThemeComboBox);
```

#### AUTO 


```{c}
auto w = new QWidget(parent);
```

#### RANGE FOR STATEMENT 


```{c}
for (QTreeWidgetItem *selecteditem : selectedItems) {
            auto identityItem = dynamic_cast<IdentityListViewItem *>(selecteditem);
            identityName = identityItem->identity().identityName();
            if (mIdentityManager->removeIdentity(identityName)) {
                delete selecteditem;
            }
            if (mIPage.mIdentityList->currentItem()) {
                mIPage.mIdentityList->currentItem()->setSelected(true);
            }
            refreshList();
            updateButtons();
        }
```

#### AUTO 


```{c}
auto kcfg = KSharedConfig::openConfig(QString::fromUtf8(QTest::currentTestFunction()));
```

#### AUTO 


```{c}
auto mailbox = item->data().value<UnifiedMailbox*>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &arg : parser.positionalArguments()) {
            if (arg.startsWith(QLatin1String("mailto:"), Qt::CaseInsensitive)) {
                const QUrl urlDecoded(QUrl::fromPercentEncoding(arg.toUtf8()));
                const QList<QPair<QString, QString> > values = MessageCore::StringUtil::parseMailtoUrl(urlDecoded);
                QString previousKey;
                for (int i = 0; i < values.count(); ++i) {
                    const QPair<QString, QString> element = values.at(i);
                    const QString key = element.first.toLower();
                    if (key == QLatin1Literal("to")) {
                        if (!element.second.isEmpty()) {
                            to += element.second + QStringLiteral(", ");
                        }
                        previousKey.clear();
                    } else if (key == QLatin1Literal("cc")) {
                        if (!element.second.isEmpty()) {
                            cc += element.second + QStringLiteral(", ");
                        }
                        previousKey.clear();
                    } else if (key == QLatin1Literal("bcc")) {
                        if (!element.second.isEmpty()) {
                            bcc += element.second + QStringLiteral(", ");
                        }
                        previousKey.clear();
                    } else if (key == QLatin1Literal("subject")) {
                        subj = element.second;
                        previousKey.clear();
                    } else if (key == QLatin1Literal("body")) {
                        body = element.second;
                        previousKey = key;
                    } else if (key == QLatin1Literal("in-reply-to")) {
                        inReplyTo = element.second;
                        previousKey.clear();
                    } else if (key == QLatin1Literal("attachment") || key == QLatin1Literal("attach")) {
                        if (!element.second.isEmpty()) {
                            attachURLs << makeAbsoluteUrl(element.second, workingDir);
                        }
                        previousKey.clear();
                    } else {
                        qCWarning(KMAIL_LOG) << "unknown key" << key;
                        //Workaround: https://bugs.kde.org/show_bug.cgi?id=390939
                        //QMap<QString, QString> parseMailtoUrl(const QUrl &url) parses correctly url
                        //But if we have a "&" unknown key we lost it.
                        if (previousKey == QLatin1Literal("body")) {
                            body += QLatin1Char('&') + key + QLatin1Char('=') + element.second;
                        }
                        //Don't clear previous key.
                    }
                }
            } else {
                QUrl url(arg);
                if (url.isValid() && !url.scheme().isEmpty()) {
                    attachURLs += url;
                } else {
                    to += arg + QStringLiteral(", ");
                }
            }
            mailto = true;
        }
```

#### AUTO 


```{c}
auto emailValidator1 = new PimCommon::EmailValidator(this);
```

#### AUTO 


```{c}
auto *act = ::qobject_cast<KToggleAction *>(sender());
```

#### RANGE FOR STATEMENT 


```{c}
for (MessageComposer::PluginEditorCheckBeforeSendInterface *interface : std::as_const(mListPluginInterface)) {
        if (!interface->exec(params)) {
            return false;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (MessageComposer::PluginEditorInterface *interface : qAsConst(mListPluginInterface)) {
            const MessageComposer::PluginActionType actionType = interface->actionType();
            MessageComposer::PluginActionType::Type type = actionType.type();
            const bool needSelectedText = interface->needSelectedText();
            if (needSelectedText) {
                //Disable by default as we don't have selection by default.
                actionType.action()->setEnabled(false);
                connect(this, &KMailPluginEditorManagerInterface::textSelectionChanged, actionType.action(), &QAction::setEnabled);
            }
            QList<QAction *> lst = mActionHash.value(type);
            if (!lst.isEmpty()) {
                auto act = new QAction(this);
                act->setSeparator(true);
                lst << act << actionType.action();
                mActionHash.insert(type, lst);
            } else {
                mActionHash.insert(type, QList<QAction *>() << actionType.action());
            }
            if (interface->plugin()->hasPopupMenuSupport()) {
                type = MessageComposer::PluginActionType::PopupMenu;
                lst = mActionHash.value(type);
                if (!lst.isEmpty()) {
                    auto act = new QAction(this);
                    act->setSeparator(true);
                    lst << act << actionType.action();
                    mActionHash.insert(type, lst);
                } else {
                    mActionHash.insert(type, QList<QAction *>() << actionType.action());
                }
            }
            if (interface->plugin()->hasToolBarSupport()) {
                type = MessageComposer::PluginActionType::ToolBar;
                lst = mActionHash.value(type);
                if (!lst.isEmpty()) {
                    auto act = new QAction(this);
                    act->setSeparator(true);
                    lst << act << actionType.action();
                    mActionHash.insert(type, lst);
                } else {
                    mActionHash.insert(type, QList<QAction *>() << actionType.action());
                }
            }
        }
```

#### AUTO 


```{c}
auto job = new Akonadi::ItemCopyJob(listItem, Akonadi::Collection(mDestFolder.id()), this);
```

#### AUTO 


```{c}
auto *configDelegate = new ConfigAgentDelegate(mAccountsReceiving.mAccountsReceiving->view());
```

#### AUTO 


```{c}
auto deleteJob = new Akonadi::ItemDeleteJob(context.item(), this);
```

#### AUTO 


```{c}
auto moveJob = new Akonadi::ItemMoveJob(context.item(), context.moveTargetCollection(), this);
```

#### AUTO 


```{c}
auto action = new QAction(i18n("Previous Unread &Message"), this);
```

#### AUTO 


```{c}
auto about = new KAboutData(QStringLiteral("kontactsummary"),
                                       i18n("kontactsummary"),
                                       QString(),
                                       i18n("KDE Kontact Summary"),
                                       KAboutLicense::GPL,
                                       i18n("(c), 2004 Tobias Koenig"));
```

#### AUTO 


```{c}
auto *mainlayout = new QVBoxLayout(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : lstItems) {
        if (item.hasPayload<KMime::Message::Ptr>()) {
            contentsToSave += item.payload<KMime::Message::Ptr>()->attachments();
        } else {
            qCWarning(KMAIL_LOG) << "Retrieved item has no payload? Ignoring for saving the attachments";
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &filterId : listFilters) {
            for (MailCommon::MailFilter *filter : qAsConst(mFilters)) {
                if (filter->identifier() == filterId) {
                    listMailFilters << filter;
                    break;
                }
            }
        }
```

#### AUTO 


```{c}
auto action = new QAction(i18n("&Configure Automatic Archiving..."), this);
```

#### AUTO 


```{c}
auto vline = new QFrame(mFrame);
```

#### AUTO 


```{c}
auto w = dlg.findChild<PotentialPhishingDetailWidget *>(QStringLiteral("potentialphising_widget"));
```

#### AUTO 


```{c}
auto *customTemplatesTab = new CustomTemplatesTab();
```

#### AUTO 


```{c}
auto page = new QWidget(widgetStack);
```

#### AUTO 


```{c}
const auto mailActions = {Akonadi::StandardMailActionManager::MarkAllMailAsRead,
                              Akonadi::StandardMailActionManager::MarkMailAsRead,
                              Akonadi::StandardMailActionManager::MarkMailAsUnread,
                              Akonadi::StandardMailActionManager::MarkMailAsImportant,
                              Akonadi::StandardMailActionManager::MarkMailAsActionItem};
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : lstActs) {
        KSelectAction *subMenu = qobject_cast<KSelectAction *>(action);
        if (subMenu) {
            const QString codecNameToSet = selectCharset(subMenu, encoding);
            if (!codecNameToSet.isEmpty()) {
                return codecNameToSet;
            }
        } else {
            const QString fixedActionText = MimeTreeParser::NodeHelper::fixEncoding(action->text());
            if (KCharsets::charsets()->codecForName(
                        KCharsets::charsets()->encodingForName(fixedActionText))
                    == KCharsets::charsets()->codecForName(encoding)) {
                return action->text();
            }
        }
    }
```

#### AUTO 


```{c}
auto vbox = new QVBoxLayout;
```

#### AUTO 


```{c}
auto *job = new ComposeNewMessageJob;
```

#### AUTO 


```{c}
auto groupBoxWrapper = new QWidget;
```

#### AUTO 


```{c}
auto wordWrapWrapperLayout = new QHBoxLayout(wordWrapWrapper);
```

#### RANGE FOR STATEMENT 


```{c}
for (const PimCommon::PluginUtilData &data : qAsConst(mPluginUtilDataList)) {
                if (data.mIdentifier == identifier) {
                    const QString service = Akonadi::ServerManager::agentServiceName(Akonadi::ServerManager::Agent, data.mExtraInfo.at(0));
                    QDBusInterface interface(service, data.mExtraInfo.at(1));
                    if (interface.isValid()) {
                        interface.call(QStringLiteral("showConfigureDialog"), static_cast<qlonglong>(winId()));
                    } else {
                        qCDebug(KMAIL_LOG) << " interface does not exist when trying to configure the plugin";
                    }
                    break;
                }
            }
```

#### AUTO 


```{c}
auto *searchDescription = mFolder.attribute<Akonadi::SearchDescriptionAttribute>(Akonadi::Collection::AddIfMissing);
```

#### AUTO 


```{c}
auto command = new KMMailtoReplyCommand(mMainWindow, urlClicked(), messageItem(), copyText());
```

#### AUTO 


```{c}
auto sMimeTab = new SecurityPageSMimeTab();
```

#### LAMBDA EXPRESSION 


```{c}
[box](const QString &name) {
        box->button(QDialogButtonBox::Ok)->setEnabled(!name.trimmed().isEmpty());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KToggleAction *act : customToolsWidgetActionList) {
            QList<QAction *> lst;
            lst << act;
            if (hashActions.contains(actionlistname)) {
                lst = hashActions.value(actionlistname) + lst;
                hashActions.remove(actionlistname);
            }
            hashActions.insert(actionlistname, lst);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &col : list) {
                    if (isUnifiedMailbox(col)) {
                        continue;
                    }

                    try {
                        switch (Akonadi::SpecialMailCollections::self()->specialCollectionType(col)) {
                        case Akonadi::SpecialMailCollections::Inbox:
                            mMailboxes.at(Common::InboxBoxId)->addSourceCollection(col.id());
                            break;
                        case Akonadi::SpecialMailCollections::SentMail:
                            mMailboxes.at(Common::SentBoxId)->addSourceCollection(col.id());
                            break;
                        case Akonadi::SpecialMailCollections::Drafts:
                            mMailboxes.at(Common::DraftsBoxId)->addSourceCollection(col.id());
                            break;
                        default:
                            continue;
                        }
                    } catch (const std::out_of_range &) {
                        qCWarning(agent_log) << "Failed to find a special unified mailbox for source collection" << col.id();
                        continue;
                    }
                }
```

#### AUTO 


```{c}
auto action = qobject_cast<QAction *>(sender());
```

#### RANGE FOR STATEMENT 


```{c}
for (const MailCommon::Tag::Ptr &tag : qAsConst(msgTagList)) {
        auto newItem = new TagListWidgetItem(QIcon::fromTheme(tag->iconName), tag->tagName, mTagListBox);
        newItem->setKMailTag(tag);
        if (tag->priority == -1) {
            tag->priority = mTagListBox->count() - 1;
        }
    }
```

#### AUTO 


```{c}
auto itemFetchJob = new Akonadi::ItemFetchJob(items, this);
```

#### AUTO 


```{c}
auto *sendlaterremovejob = new SendLaterRemoveMessageJob(listMessage, this);
```

#### AUTO 


```{c}
auto me = static_cast<QMouseEvent *>(event);
```

#### AUTO 


```{c}
auto label = static_cast<KUrlLabel *>(obj);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto source : sources) {
        addSourceCollection(source);
    }
```

#### AUTO 


```{c}
auto folderLabel = new QLabel(i18n("&Folder:"), mainWidget);
```

#### AUTO 


```{c}
auto createJob = new Akonadi::TagCreateJob(tag, this);
```

#### AUTO 


```{c}
auto *sortModel = new QSortFilterProxyModel(this);
```

#### AUTO 


```{c}
auto *receivingTab = new ReceivingTab();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &addr : lst) {
                if (!mComposerBase->recipientsEditor()->addRecipient(addr, MessageComposer::Recipient::Cc)) {
                    qCWarning(KMAIL_LOG) << "Impossible to add cc entry";
                }
            }
```

#### AUTO 


```{c}
auto iter = mgr.modifyBegin(), end = mgr.modifyEnd();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Collection &col : lstCol) {
        if (col.name() == mUi.mSearchFolderEdt->text()) {
            mFolder = col;
        }
    }
```

#### AUTO 


```{c}
auto *hlay = new QHBoxLayout();
```

#### AUTO 


```{c}
auto updowngrid = new QHBoxLayout();
```

#### AUTO 


```{c}
const auto inboxSourceCol = collectionForRid(QStringLiteral("res1_inbox"));
```

#### AUTO 


```{c}
const auto msg(createItem(ident));
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {emitProgress();}
```

#### LAMBDA EXPRESSION 


```{c}
[view, editButton, removeButton]() {
                const bool hasSelection = view->selectionModel()->hasSelection();
                editButton->setEnabled(hasSelection);
                removeButton->setEnabled(hasSelection);
            }
```

#### AUTO 


```{c}
const auto metaDataList = KPluginMetaData::findPlugins(QStringLiteral("pim/kcms/summary/"));
```

#### AUTO 


```{c}
auto session = new Akonadi::Session("KMail Kernel ETM", this);
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *j : actList ) {
            if (j != mSyncAction) {
                j->trigger();
            }
        }
```

#### AUTO 


```{c}
auto composer = KMail::makeComposer(msg);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &str : prefCharsets) {
        QByteArray charset = str.toLatin1().toLower();

        if (charset == "locale") {
            charset = QTextCodec::codecForLocale()->name();

            // Special case for Japanese:
            // (Introduction to i18n, 6.6 Limit of Locale technology):
            // EUC-JP is the de-facto standard for UNIX systems, ISO 2022-JP
            // is the standard for Internet, and Shift-JIS is the encoding
            // for Windows and Macintosh.
            if (charset == "jisx0208.1983-0"
                || charset == "eucjp"
                || charset == "shift-jis") {
                charset = "iso-2022-jp";
                // TODO wtf is "jis7"?
            }

            // Special case for Korean:
            if (charset == "ksc5601.1987-0") {
                charset = "euc-kr";
            }
        }
        mPreferredCharsets << charset;
    }
```

#### AUTO 


```{c}
const auto indexes = view->selectionModel()->selectedIndexes();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &argument : qAsConst(args)) {
        if (argument == QLatin1String("--attach")) {
            addAttachmentAttribute = true;
        } else {
            if (argument.startsWith(QLatin1String("--"))) {
                addAttachmentAttribute = false;
            }
            if (argument.contains(QLatin1Char('@')) || argument.startsWith(QLatin1String("mailto:"))) { // address mustn't be trade as a attachment
                addAttachmentAttribute = false;
            }
            if (addAttachmentAttribute) {
                newargs.append(QStringLiteral("--attach"));
                newargs.append(argument);
            } else {
                newargs.append(argument);
            }
        }
    }
```

#### AUTO 


```{c}
auto label = new QLabel(i18n("&vCard path:"), this);
```

#### AUTO 


```{c}
auto job = new PotentialPhishingEmailJob;
```

#### AUTO 


```{c}
const auto *transportAttribute = item.attribute<MailTransport::TransportAttribute>();
```

#### AUTO 


```{c}
auto fetch = new Akonadi::ItemDeleteJob(mItem, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &str : dialogListName) {
        KConfigGroup oldGroup = settingsrc->group(str);
        cleanupFolderSettings(oldGroup);
    }
```

#### AUTO 


```{c}
auto sortproxy = new QSortFilterProxyModel(mResultModel);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &arg : parser.positionalArguments()) {
            if (arg.startsWith(QStringLiteral("mailto:"), Qt::CaseInsensitive)) {
                const QUrl urlDecoded(QUrl::fromPercentEncoding(arg.toUtf8()));
                QMap<QString, QString> values = MessageCore::StringUtil::parseMailtoUrl(urlDecoded);
                for (auto it = values.cbegin(), end = values.cend(); it != end; ++it) {
                    const QString key = it.key();
                    if (key == QLatin1Literal("to")) {
                        if (!it->isEmpty()) {
                            to += *it + QStringLiteral(", ");
                        }
                    } else if (key == QLatin1Literal("cc")) {
                        if (!it->isEmpty()) {
                            cc += *it + QStringLiteral(", ");
                        }
                    } else if (key == QLatin1Literal("bcc")) {
                        if (!it->isEmpty()) {
                            bcc += *it + QStringLiteral(", ");
                        }
                    } else if (key == QLatin1Literal("subject")) {
                        subj = it.value();
                    } else if (key == QLatin1Literal("body")) {
                        body = it.value();
                    } else if (key == QLatin1Literal("in-reply-to")) {
                        inReplyTo = it.value();
                    } else if (key == QLatin1Literal("attachment") || key == QLatin1Literal("attach")) {
                        if (!it->isEmpty()) {
                            attachURLs << makeAbsoluteUrl(*it, workingDir);
                        }
                    }
                }
            } else {
                QUrl url(arg);
                if (url.isValid() && !url.scheme().isEmpty()) {
                    attachURLs += url;
                } else {
                    to += arg + QStringLiteral(", ");
                }
            }
            mailto = true;
        }
```

#### AUTO 


```{c}
auto fetchJob = static_cast<Akonadi::ItemFetchJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &groupName : currentGroups) {
        group.deleteGroup(groupName);
    }
```

#### AUTO 


```{c}
auto *job = new KIO::ApplicationLauncherJob();
```

#### AUTO 


```{c}
auto label1 = new QLabel(i18n("<qt>KMail can send a small (48x48 pixels), low-quality, "
                                  "monochrome picture with every message. "
                                  "For example, this could be a picture of you or a glyph. "
                                  "It is shown in the recipient's mail client (if supported).</qt>"),
                             page);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::AgentType &type : lstAgent) {
        if (type.identifier() == service) {
            data.mExtraInfo << service;
            data.mExtraInfo << path;
            const bool enabled = agentActivateState(interfaceName, path);
            data.mEnableByDefault = enabled;
            data.mName = type.name();
            data.mDescription = type.description();
            data.mIdentifier = type.identifier();
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const AttachmentInfo &info : infos) {
        if (showWarning) {
            lst.append(info.url.toDisplayString());
        }
        mComposerBase->addAttachment(info.url, info.comment, false);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const UnifiedMailbox *box) {
        if (!box->collectionId()) {
            qCWarning(UNIFIEDMAILBOXAGENT_LOG) << "MailboxManager wants us to update Box but does not have its CollectionId!?";
            return;
        }

        // Schedule collection sync for the box
        synchronizeCollection(box->collectionId().value());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&unifiedBox](const Akonadi::Item &item) {
                        return !unifiedBox->sourceCollections().contains(item.storageCollectionId());
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &group : filterGroups) {
        config->deleteGroup(group);
    }
```

#### AUTO 


```{c}
auto action = new QAction(i18n("Manage &Sieve Scripts..."), this);
```

#### LAMBDA EXPRESSION 


```{c}
[iconButton, this]() {
                const auto iconName = KIconDialog::getIcon();
                if (!iconName.isEmpty()) {
                    mMailbox->setIcon(iconName);
                    iconButton->setIcon(QIcon::fromTheme(iconName));
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto job : qAsConst(mPendingDeletes)) {
            job->kill();
        }
```

#### AUTO 


```{c}
auto *sep = new QAction(menu);
```

#### LAMBDA EXPRESSION 


```{c}
[this, unifiedBox, c](const Akonadi::Item::List &items) {
                Akonadi::Item::List toUnlink;
                std::copy_if(items.cbegin(), items.cend(), std::back_inserter(toUnlink),
                    [&unifiedBox](const Akonadi::Item &item) {
                        return !unifiedBox->sourceCollections().contains(item.storageCollectionId());
                    });
                if (!toUnlink.isEmpty()) {
                    new Akonadi::UnlinkJob(c, toUnlink, this);
                }
            }
```

#### AUTO 


```{c}
auto lvItem = dynamic_cast<IdentityListViewItem *>(item);
```

#### AUTO 


```{c}
const auto result = job->property("webhitresult").value<WebEngineViewer::WebHitTestResult>();
```

#### AUTO 


```{c}
auto *subMenu = new QMenu;
```

#### AUTO 


```{c}
auto *cmd(new KMMailtoReplyCommand(nullptr, QUrl(QStringLiteral("mailto:test@example.com")), item, QString()));
```

#### RANGE FOR STATEMENT 


```{c}
for (PimCommon::CustomToolsPlugin *plugin : lstPlugin) {
        if (plugin->isEnabled()) {
            MessageComposer::PluginEditorGrammarCustomToolsViewInterface *interface = static_cast<MessageComposer::PluginEditorGrammarCustomToolsViewInterface*>(plugin->createView(mActionCollection, mCustomToolsWidget));
            mCustomToolsWidget->addCustomToolViewInterface(interface);
            interface->setParentWidget(mParentWidget);
            interface->setRichTextEditor(mRichTextEditor);
//            interface->reloadConfig();
//            if (!interface->exec()) {
//                qCWarning(KMAIL_LOG) << "KMailPluginGrammarEditorManagerInterface::initializePlugins: error during execution of plugin:" << interface;
//            }
        }
    }
```

#### AUTO 


```{c}
auto r = mUi.mPatternEdit->findChild<KLineEdit *>(QStringLiteral("regExpLineEdit"));
```

#### AUTO 


```{c}
auto drag = new QDrag(viewport());
```

#### AUTO 


```{c}
auto colorsTab = new ColorsTab();
```

#### AUTO 


```{c}
auto lspacer = new QSpacerItem(1, 10,
                                    QSizePolicy::MinimumExpanding,
                                    QSizePolicy::MinimumExpanding);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : selectedRows) {
        AttachmentPart::Ptr part = mView->model()->data(index, MessageComposer::AttachmentModel::AttachmentPartRole).value<AttachmentPart::Ptr>();
        selectedParts.append(part);
    }
```

#### AUTO 


```{c}
auto *orderProxy = new MailCommon::FavoriteCollectionOrderProxyModel(this);
```

#### AUTO 


```{c}
const auto lst = guiFactory()->clients();
```

#### AUTO 


```{c}
auto *combo = qobject_cast<KeySelectionCombo *>(parent());
```

#### AUTO 


```{c}
const auto box = unregisterSpecialSourceCollection(col.id())
```

#### AUTO 


```{c}
auto *fetchJob = qobject_cast<Akonadi::ItemFetchJob *>(job);
```

#### AUTO 


```{c}
auto layout = new QHBoxLayout(wid);
```

#### AUTO 


```{c}
auto page_vlay = new QVBoxLayout(page);
```

#### AUTO 


```{c}
const auto protocol = Kleo::CryptoBackendFactory::instance()->openpgp();
```

#### RANGE FOR STATEMENT 


```{c}
for (const PimCommon::PluginUtilData &data : qAsConst(mPluginUtilDataList)) {
                if (data.mIdentifier == identifier) {
                    auto instance = Akonadi::AgentManager::self()->instance(identifier);
                    if (instance.isValid()) {
                        instance.configure(this);
                    }
                    break;
                }
            }
```

#### AUTO 


```{c}
auto generalTab = new ComposerPageGeneralTab();
```

#### AUTO 


```{c}
auto selectionModel = ftw->selectionModel();
```

#### AUTO 


```{c}
auto lab = new QLabel(i18n("You still wait an answer about this mail:"), this);
```

#### AUTO 


```{c}
auto ifj = new Akonadi::ItemFetchJob{Akonadi::Collection{id}, this};
```

#### AUTO 


```{c}
const auto lstCols = fetchJob->collections();
```

#### AUTO 


```{c}
auto *handle = new WinObjFontHandle;
```

#### AUTO 


```{c}
auto job = new Akonadi::CollectionDeleteJob(col);
```

#### AUTO 


```{c}
auto mimeData = new QMimeData;
```

#### AUTO 


```{c}
auto *buttonGroup = dlg.findChild<QButtonGroup *>(QStringLiteral("buttongroup"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Tag &tag : qAsConst(mTags)) {
        if (!tag.isValid()) {
            Akonadi::TagCreateJob *createJob = new Akonadi::TagCreateJob(tag, this);
            connect(createJob, &Akonadi::TagCreateJob::result, this, &KMSetTagCommand::slotModifyItemDone);
        } else {
            mCreatedTags << tag;
        }
    }
```

#### AUTO 


```{c}
auto config = FollowUpReminder::FollowUpReminderUtil::defaultConfig();
```

#### AUTO 


```{c}
auto fetch = new Akonadi::ItemFetchJob(Akonadi::Collection(source), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (MessageComposer::PluginEditorConvertTextInterface *interface : qAsConst(mListPluginInterface)) {
            const auto actionTypes = interface->actionTypes();
            for (const MessageComposer::PluginActionType &actionType : actionTypes) {
                MessageComposer::PluginActionType::Type type = actionType.type();
                QAction *currentAction = actionType.action();
                if (!currentAction) {
                    continue;
                }
                QList<QAction *> lst = mActionHash.value(type);
                if (!lst.isEmpty()) {
                    auto act = new QAction(this);
                    act->setSeparator(true);
                    lst << act << currentAction;
                    mActionHash.insert(type, lst);
                } else {
                    mActionHash.insert(type, QList<QAction *>() << currentAction);
                }
                if (interface->plugin()->hasPopupMenuSupport()) {
                    type = MessageComposer::PluginActionType::PopupMenu;
                    if (currentAction) {
                        lst = mActionHash.value(type);
                        if (!lst.isEmpty()) {
                            auto act = new QAction(this);
                            act->setSeparator(true);
                            lst << act << currentAction;
                            mActionHash.insert(type, lst);
                        } else {
                            mActionHash.insert(type, QList<QAction *>() << currentAction);
                        }
                    }
                }
                if (interface->plugin()->hasToolBarSupport()) {
                    type = MessageComposer::PluginActionType::ToolBar;
                    lst = mActionHash.value(type);
                    if (!lst.isEmpty()) {
                        auto act = new QAction(this);
                        act->setSeparator(true);
                        lst << act << currentAction;
                        mActionHash.insert(type, lst);
                    } else {
                        mActionHash.insert(type, QList<QAction *>() << currentAction);
                    }
                }
            }
        }
```

#### AUTO 


```{c}
auto fetch = new Akonadi::CollectionFetchJob(mMainWidget->currentCollection(),
                                                                         Akonadi::CollectionFetchJob::Base);
```

#### AUTO 


```{c}
const auto unlinkedCol = itemUnlinkedSignalSpy.at(0).at(1).value<Akonadi::Collection>();
```

#### AUTO 


```{c}
auto headersTab = new HeadersTab();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Tag &tag : qAsConst(mCreatedTags)) {
            const QString url = tag.url().url();
            if (!lst.contains(url)) {
                lst.append(url);
            }
        }
```

#### AUTO 


```{c}
auto buttonCode
        = static_cast<PimCommon::SimpleStringListEditor::ButtonCode>(PimCommon::SimpleStringListEditor::Add | PimCommon::SimpleStringListEditor::Remove | PimCommon::SimpleStringListEditor::Modify);
```

#### AUTO 


```{c}
auto fetchJob = new Akonadi::TagFetchJob(this);
```

#### AUTO 


```{c}
auto *item = new PluginItem(*it, mPluginView);
```

#### AUTO 


```{c}
auto interface = new MessageComposer::ComposerViewInterface(mComposerBase);
```

#### AUTO 


```{c}
auto jobCol = new Akonadi::CollectionFetchJob(Akonadi::Collection(items.first().parentCollection().id()), Akonadi::CollectionFetchJob::Base, this);
```

#### AUTO 


```{c}
auto *fetchCmd = qobject_cast<KMFetchMessageCommand *>(command);
```

#### RANGE FOR STATEMENT 


```{c}
for (const MailCommon::Tag::Ptr &tag : tags) {
        if (i < s_numberMaxTag) {
            createTagAction(tag, true);
        } else {
            if (tag->inToolbar || !tag->shortcut.isEmpty()) {
                createTagAction(tag, false);
            }

            if (i == s_numberMaxTag && i < numberOfTag) {
                needToAddMoreAction = true;
            }
        }
        ++i;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KontactInterface::Plugin *i : pluginList) {
        // execute all sync actions but our own
        const QList<QAction *> actList = i->syncActions();
        for (QAction *j : actList ) {
            if (j != mSyncAction) {
                j->trigger();
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                setEnabled(true);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &attach : lst) {
                const QUrl localUrl = QUrl::fromLocalFile(attach);
                addAttachment(localUrl, QString());
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (KMainWindow *window : lst) {
        if (auto *win = ::qobject_cast<KMail::Composer *>(window)) {
            win->autoSaveMessage(true);

            while (win->isComposing()) {
                qCWarning(KMAIL_LOG) << "Danger, using an event loop, this should no longer be happening!";
                qApp->processEvents();
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : qAsConst(items)) {
        ++mCurrentProgressCount;

        if ((mTotalProgressCount > 0) && (mCurrentProgressCount != mTotalProgressCount)) {
            const QString statusMsg
                = i18n("Filtering message %1 of %2", mCurrentProgressCount, mTotalProgressCount);
            Q_EMIT q->progressMessage(statusMsg);
            Q_EMIT q->percent(mCurrentProgressCount * 100 / mTotalProgressCount);
        } else {
            Q_EMIT q->percent(0);
        }

        const bool filterResult = q->process(listMailFilters, item, needsFullPayload, filterSet);

        if (mCurrentProgressCount == mTotalProgressCount) {
            mTotalProgressCount = 0;
            mCurrentProgressCount = 0;
        }

        if (!filterResult) {
            Q_EMIT q->filteringFailed(item);
            // something went horribly wrong (out of space?)
            //CommonKernel->emergencyExit( i18n( "Unable to process messages: " ) + QString::fromLocal8Bit( strerror( errno ) ) );
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &addr : lst) {
                mComposerBase->recipientsEditor()->addRecipient(addr, MessageComposer::Recipient::Bcc);
            }
```

#### AUTO 


```{c}
auto openWithAct = new QAction(menu);
```

#### AUTO 


```{c}
auto page = new ConfigurePluginPage(parent);
```

#### AUTO 


```{c}
auto action = new QAction(QIcon::fromTheme(QStringLiteral("bookmark-new")), i18n("Add Favorite Folder..."), this);
```

#### AUTO 


```{c}
auto msg = new KMime::Message;
```

#### AUTO 


```{c}
auto cmd(new KMMailtoReplyCommand(nullptr, QUrl(QStringLiteral("mailto:test@example.com")), item, QString()));
```

#### AUTO 


```{c}
const auto cb = [this, finishedCb = std::move(finishedCb)]() {
        qCDebug(agent_log) << "Finished callback: enabling change recorder";
        // Only now start processing changes from change recorder
        connect(&mMonitor, &Akonadi::ChangeRecorder::changesAdded, &mMonitor, &Akonadi::ChangeRecorder::replayNext, Qt::QueuedConnection);
        // And start replaying any potentially pending notification
        QTimer::singleShot(0, &mMonitor, &Akonadi::ChangeRecorder::replayNext);

        if (finishedCb) {
            finishedCb();
        }
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (MessageComposer::PluginEditorInterface *interface : std::as_const(mListPluginInterface)) {
            if (auto w = interface->statusBarWidget()) {
                w->setEnabled((interface->applyOnFieldTypes() & type));
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const qlonglong &id : std::as_const(mMsgListId)) {
        int diff = msgCountToFilter - ++msgCount;
        if (diff < 10 || !(msgCount % 10) || msgCount <= 10) {
            progressItem->updateProgress();
            const QString statusMsg = i18n("Filtering message %1 of %2", msgCount, msgCountToFilter);
            PimCommon::BroadcastStatus::instance()->setStatusMsg(statusMsg);
            qApp->processEvents(QEventLoop::ExcludeUserInputEvents, 50);
        }

        MailCommon::FilterManager::instance()->filter(Akonadi::Item(id), mFilterId, QString());
        progressItem->incCompletedItems();
    }
```

#### AUTO 


```{c}
const auto *mainWinAction = manager->action(Akonadi::StandardActionManager::CopyItemToMenu);
```

#### AUTO 


```{c}
auto *hlayout = new QHBoxLayout;
```

#### AUTO 


```{c}
auto combo = qobject_cast<KeySelectionCombo *>(parent());
```

#### AUTO 


```{c}
auto address = mItem.payload<KContacts::Addressee>();
```

#### AUTO 


```{c}
const auto inboxBoxCol = createCollection(Common::InboxBoxId, parentCol.value(), deleter);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Collection &col : cols) {
        const QModelIndex colIdx = Akonadi::EntityTreeModel::modelIndexForCollection(etm, col);
        if (col.statistics().count() > -1) {
            if (col.cachePolicy().localParts().contains(QStringLiteral("RFC822"))) {
                result.push_back(col);
            }
        } else {
            const Akonadi::Collection collection = etm->data(colIdx, Akonadi::EntityTreeModel::CollectionRole).value<Akonadi::Collection>();
            if (!collection.hasAttribute<Akonadi::EntityHiddenAttribute>()
                    && collection.cachePolicy().localParts().contains(QStringLiteral("RFC822"))) {
                result.push_back(collection);
            }
        }

        const int childrenCount = etm->rowCount(colIdx);
        if (childrenCount > 0) {
            Akonadi::Collection::List subCols;
            subCols.reserve(childrenCount);
            for (int i = 0; i < childrenCount; ++i) {
                const QModelIndex idx = etm->index(i, 0, colIdx);
                const Akonadi::Collection child = etm->data(idx, Akonadi::EntityTreeModel::CollectionRole).value<Akonadi::Collection>();
                if (child.cachePolicy().localParts().contains(QStringLiteral("RFC822"))) {
                    subCols.push_back(child);
                }
            }

            result += searchCollectionsRecursive(subCols);
        }
    }
```

#### AUTO 


```{c}
auto *job = new FollowUpReminderFinishTaskJob(info->todoId(), this);
```

#### AUTO 


```{c}
auto action = new QAction(i18n("Extend Selection to Previous Message"), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (QTreeWidgetItem *item : listItems) {
        if (removeMessage) {
            auto mailItem = static_cast<SendLaterItem *>(item);
            if (mailItem->info()) {
                Akonadi::Item::Id id = mailItem->info()->itemId();
                if (id != -1) {
                    mListMessagesToRemove << id;
                }
            }
        }
        delete item;
    }
```

#### AUTO 


```{c}
auto *tmw = new TransportManagementWidget(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &mail : lst) {
        if (!emailsAdded.contains(mail)) {
            auto *item = new QListWidgetItem(mListWidget);
            item->setCheckState(Qt::Unchecked);
            item->setText(mail);
            emailsAdded << mail;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KMainWindow *window : lst) {
        if (KMail::Composer *win = ::qobject_cast<KMail::Composer *>(window)) {
            win->autoSaveMessage(true);

            while (win->isComposing()) {
                qCWarning(KMAIL_LOG) << "Danger, using an event loop, this should no longer be happening!";
                qApp->processEvents();
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (FollowUpReminderInfo *info : qAsConst(mFollowUpReminderInfoList)) {
        qCDebug(FOLLOWUPREMINDERAGENT_LOG) << "FollowUpReminderManager::slotCheckFollowUpFinished info:" << info;
        if (!info) {
            continue;
        }
        if (info->messageId() == messageId) {
            info->setAnswerMessageItemId(id);
            info->setAnswerWasReceived(true);
            answerReceived(info->to());
            if (info->todoId() != -1) {
                auto job = new FollowUpReminderFinishTaskJob(info->todoId(), this);
                connect(job, &FollowUpReminderFinishTaskJob::finishTaskDone, this, &FollowUpReminderManager::slotFinishTaskDone);
                connect(job, &FollowUpReminderFinishTaskJob::finishTaskFailed, this, &FollowUpReminderManager::slotFinishTaskFailed);
                job->start();
            }
            //Save item
            FollowUpReminder::FollowUpReminderUtil::writeFollowupReminderInfo(FollowUpReminder::FollowUpReminderUtil::defaultConfig(), info, true);
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto job : std::as_const(mPendingMoves)) {
            job->kill();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &service) {
        Q_UNUSED(service);
        mUnityServiceAvailable = false;
    }
```

#### AUTO 


```{c}
auto label = new QLabel(i18n("No unread messages in your monitored folders"), this);
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) {d->moveJobResult(job); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &col : list) {
                    if (isUnifiedMailbox(col)) {
                        continue;
                    }

                    try {
                        switch (Akonadi::SpecialMailCollections::self()->specialCollectionType(col)) {
                        case Akonadi::SpecialMailCollections::Inbox:
                            mMailboxes.at(Common::InboxBoxId)->addSourceCollection(col.id());
                            break;
                        case Akonadi::SpecialMailCollections::SentMail:
                            mMailboxes.at(Common::SentBoxId)->addSourceCollection(col.id());
                            break;
                        case Akonadi::SpecialMailCollections::Drafts:
                            mMailboxes.at(Common::DraftsBoxId)->addSourceCollection(col.id());
                            break;
                        default:
                            continue;
                        }
                    } catch (const std::out_of_range &) {
                        qCWarning(UNIFIEDMAILBOXAGENT_LOG) << "Failed to find a special unified mailbox for source collection" << col.id();
                        continue;
                    }
                }
```

#### AUTO 


```{c}
auto *job = new Akonadi::CollectionDeleteJob(col);
```

#### AUTO 


```{c}
auto *mainLayout = new QGridLayout;
```

#### AUTO 


```{c}
auto w = mKernel->mainWin();
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool state) {
        mUndoSendComboBox->setEnabled(state);
        Q_EMIT slotEmitChanged();
    }
```

#### AUTO 


```{c}
auto *header = new KMime::Headers::Generic("X-KMail-Templates");
```

#### AUTO 


```{c}
auto *command = new FolderShortcutCommand(mParent, col);
```

#### LAMBDA EXPRESSION 


```{c}
[this](uint val) {
        slotIdentityChanged(val);
    }
```

#### AUTO 


```{c}
const auto verifyBox = [&manager, &success](const QString &id, int numSources) {
            success = false;
            auto boxIt = std::find_if(manager.begin(), manager.end(),
                            [&id](const UnifiedMailboxManager::Entry &e) {
                                return e.second->id() == id;
                            });
            QVERIFY(boxIt != manager.end());
            const auto &box = boxIt->second;
            const auto sourceCollections = box->sourceCollections();
            QCOMPARE(sourceCollections.size(), numSources);
            for (auto source : sourceCollections) {
                auto col = collectionForId(source);
                QVERIFY(col);
                QVERIFY(col->hasAttribute<Akonadi::SpecialCollectionAttribute>());
                QCOMPARE(col->attribute<Akonadi::SpecialCollectionAttribute>()->collectionType(), id.toLatin1());
            }
            success = true;
        };
```

#### AUTO 


```{c}
auto hbox = new QHBoxLayout();
```

#### AUTO 


```{c}
auto *radio = new QRadioButton(buttonLabel, mDateDisplayBox);
```

#### AUTO 


```{c}
auto tmpFile =
            new QTemporaryFile(QStandardPaths::writableLocation(QStandardPaths::TempLocation) + QLatin1String("/ktnef/") + QLatin1String("ktnef_XXXXXX.rtf"));
```

#### AUTO 


```{c}
auto *composer = new ::MessageComposer::Composer;
```

#### AUTO 


```{c}
auto dialog = new QDialog(parent);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &it : lst) {
        //qCDebug(KMAIL_LOG)<<" item ::"<<tmpItem;
        if (it.isValid()) {
            bool myStatus;
            Akonadi::MessageStatus itemStatus;
            itemStatus.setStatusFromFlags(it.flags());
            if (itemStatus & Akonadi::MessageStatus::statusToAct()) {
                myStatus = true;
            } else {
                myStatus = false;
            }
            if (myStatus != parentStatus) {
                continue;
            }
        }
        Akonadi::Item item(it);
        const Akonadi::Item::Flag flag = *(Akonadi::MessageStatus::statusToAct().statusFlags().begin());
        if (item.hasFlag(flag)) {
            item.clearFlag(flag);
            itemsToModify.push_back(item);
            if (item.hasAttribute<TaskAttribute>()) {
                //Change todo as done.
                item.removeAttribute<TaskAttribute>();
            }
        } else {
            item.setFlag(flag);
            itemsToModify.push_back(item);
            //TODO add TaskAttribute();
        }
    }
```

#### AUTO 


```{c}
auto *job = new Akonadi::ItemFetchJob(mListItem, this);
```

#### AUTO 


```{c}
auto logSizeLab = new QLabel(i18n("Log size limit:"), hbox);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : lst) {
        const Akonadi::Item item = index.data(Akonadi::EntityTreeModel::ItemRole).value<Akonadi::Item>();
        if (item.isValid()) {
            messages.append(item);
        }
    }
```

#### AUTO 


```{c}
auto info = new MessageComposer::SendLaterInfo;
```

#### AUTO 


```{c}
auto openCommand = new KMOpenMsgCommand(nullptr, QUrl::fromLocalFile(messageFile));
```

#### LAMBDA EXPRESSION 


```{c}
[](const Akonadi::Item & lhs, const Akonadi::Item & rhs) {
                return lhs.storageCollectionId() < rhs.storageCollectionId();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Tag &createdTag : std::as_const(mCreatedTags)) {
            const QString url = createdTag.url().url();
            if (!lst.contains(url)) {
                lst.append(url);
            }
        }
```

#### CONST EXPRESSION 


```{c}
static constexpr const char *DialogGroup = "UnifiedMailboxSettingsDialog";
```

#### RANGE FOR STATEMENT 


```{c}
for (SendLater::SendLaterInfo *info : qAsConst(mListSendLaterInfo)) {
        if (info->itemId() == id) {
            return info;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (PimCommon::CustomToolsPlugin *plugin : lstPlugin) {
        if (plugin->isEnabled()) {
            auto interface = static_cast<MessageComposer::PluginEditorGrammarCustomToolsViewInterface *>(plugin->createView(mActionCollection, mCustomToolsWidget));
            mCustomToolsWidget->addCustomToolViewInterface(interface);
            interface->setParentWidget(mParentWidget);
            interface->setRichTextEditor(mRichTextEditor);
        }
    }
```

#### AUTO 


```{c}
auto createJob = new Akonadi::ItemCreateJob(item, mCollection);
```

#### AUTO 


```{c}
auto pageVBoxLayout = new QVBoxLayout;
```

#### AUTO 


```{c}
auto action = new QAction(i18n("Select Last Message"), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::AgentInstance &agent : agents) {
            const QString id = agent.identifier();

            auto it = std::max_element(d->mFilters.constBegin(), d->mFilters.constEnd(),
                                       [id](MailCommon::MailFilter *lhs, MailCommon::MailFilter *rhs) {
                return lhs->requiredPart(id) < rhs->requiredPart(id);
            });
            d->mRequiredParts[id] = (*it)->requiredPart(id);
            d->mRequiredPartsBasedOnAll = qMax(d->mRequiredPartsBasedOnAll, d->mRequiredParts[id]);
        }
```

#### AUTO 


```{c}
auto *purposeMenu = new MailfilterPurposeMenuWidget(this, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::AgentInstance &instance : allInstances) {
        KSieveUi::SieveImapInstance sieveInstance;
        sieveInstance.setCapabilities(instance.type().capabilities());
        sieveInstance.setIdentifier(instance.identifier());
        sieveInstance.setMimeTypes(instance.type().mimeTypes());
        sieveInstance.setName(instance.name());
        switch(instance.status()) {
        case Akonadi::AgentInstance::Idle:
            sieveInstance.setStatus(KSieveUi::SieveImapInstance::Idle);
            break;
        case Akonadi::AgentInstance::Running:
            sieveInstance.setStatus(KSieveUi::SieveImapInstance::Running);
            break;
        case Akonadi::AgentInstance::Broken:
            sieveInstance.setStatus(KSieveUi::SieveImapInstance::Broken);
            break;
        case Akonadi::AgentInstance::NotConfigured:
            sieveInstance.setStatus(KSieveUi::SieveImapInstance::NotConfigured);
            break;
        }
        listInstance.append(sieveInstance);
    }
```

#### AUTO 


```{c}
auto signature = w.findChild<QLabel *>(QStringLiteral("signatureindicator"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &mail : lst) {
        if (!emailsAdded.contains(mail)) {
            auto item = new QListWidgetItem(mListWidget);
            item->setCheckState(Qt::Unchecked);
            item->setText(mail);
            emailsAdded << mail;
        }
    }
```

#### AUTO 


```{c}
auto listWidgetSearchLine = new KListWidgetSearchLine(this, mListTag);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Tag &tag : lstTags) {
                item.clearTag(tag);
            }
```

#### AUTO 


```{c}
auto job = new Akonadi::ItemCreateJob(decItem, mDestFolder, this);
```

#### AUTO 


```{c}
auto box = std::find_if(mMailboxes.begin(), mMailboxes.end(),
                            [&id](const std::pair<const QString, std::unique_ptr<UnifiedMailbox> > &box) {
        return box.second->id() == id;
    });
```

#### RANGE FOR STATEMENT 


```{c}
for (MessageComposer::PluginEditorConvertTextInterface *interface : qAsConst(mListPluginInterface)) {
            for (const MessageComposer::PluginActionType &actionType : interface->actionTypes()) {
                MessageComposer::PluginActionType::Type type = actionType.type();
                QAction *currentAction = actionType.action();
                if (!currentAction) {
                    continue;
                }
                QList<QAction *> lst = mActionHash.value(type);
                if (!lst.isEmpty()) {
                    auto *act = new QAction(this);
                    act->setSeparator(true);
                    lst << act << currentAction;
                    mActionHash.insert(type, lst);
                } else {
                    mActionHash.insert(type, QList<QAction *>() << currentAction);
                }
                if (interface->plugin()->hasPopupMenuSupport()) {
                    type = MessageComposer::PluginActionType::PopupMenu;
                    if (currentAction) {
                        lst = mActionHash.value(type);
                        if (!lst.isEmpty()) {
                            auto *act = new QAction(this);
                            act->setSeparator(true);
                            lst << act << currentAction;
                            mActionHash.insert(type, lst);
                        } else {
                            mActionHash.insert(type, QList<QAction *>() << currentAction);
                        }
                    }
                }
                if (interface->plugin()->hasToolBarSupport()) {
                    type = MessageComposer::PluginActionType::ToolBar;
                    lst = mActionHash.value(type);
                    if (!lst.isEmpty()) {
                        auto *act = new QAction(this);
                        act->setSeparator(true);
                        lst << act << currentAction;
                        mActionHash.insert(type, lst);
                    } else {
                        mActionHash.insert(type, QList<QAction *>() << currentAction);
                    }
                }
            }
        }
```

#### AUTO 


```{c}
auto *job = new OpenComposerHiddenJob(this);
```

#### AUTO 


```{c}
auto restoreDefaultDomainName = new QToolButton;
```

#### AUTO 


```{c}
auto composer = qobject_cast<::MessageComposer::Composer *>(job);
```

#### AUTO 


```{c}
auto hrd = mMsg->headerByType("X-KMail-Transport-Name")
```

#### AUTO 


```{c}
auto page = new QWidget(this);
```

#### AUTO 


```{c}
auto *messageIdSuffixValidator = new QRegularExpressionValidator(QRegularExpression(QStringLiteral("[a-zA-Z0-9+-]+(?:\\.[a-zA-Z0-9+-]+)*")), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &addr : std::as_const(mEmails)) {
        if (!mEmailWhiteList.contains(addr.trimmed())) {
            QString tname;
            QString temail;
            KEmailAddress::extractEmailAddressAndName(addr, temail, tname); // ignore return value
            // which is always false
            if (tname.startsWith(QLatin1Char('@'))) { // Special case when name is just @foo <...> it mustn't recognize as a valid email
                continue;
            }
            if (tname.contains(QLatin1Char('@'))) { // Potential address
                if (tname.startsWith(QLatin1Char('<')) && tname.endsWith(QLatin1Char('>'))) {
                    tname = tname.mid(1, tname.length() - 2);
                }
                if (tname.startsWith(QLatin1Char('\'')) && tname.endsWith(QLatin1Char('\''))) {
                    tname = tname.mid(1, tname.length() - 2);
                }
                if (temail.toLower() != tname.toLower()) {
                    const QString str = QStringLiteral("(%1)").arg(temail);
                    if (!tname.contains(str, Qt::CaseInsensitive)) {
                        const QStringList lst = tname.trimmed().split(QLatin1Char(' '));
                        if (lst.count() > 1) {
                            const QString firstName = lst.at(0);

                            for (const QString &n : lst) {
                                if (n != firstName) {
                                    mPotentialPhisingEmails.append(addr);
                                    break;
                                }
                            }
                        } else {
                            mPotentialPhisingEmails.append(addr);
                        }
                    }
                }
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
                slotApplyFilterOnFolder(/* recursive */ true);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (qint64 id : itemIds) {
        items << Akonadi::Item(id);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const MailCommon::Tag::Ptr &tag : qAsConst(mTagList)) {
        auto item = new QListWidgetItem(QIcon::fromTheme(tag->iconName), tag->tagName, mListTag);
        item->setData(UrlTag, tag->tag().url().url());
        item->setFlags(Qt::ItemIsUserCheckable | Qt::ItemIsEnabled | Qt::ItemIsSelectable);
        item->setCheckState(Qt::Unchecked);
        mListTag->addItem(item);

        if (updatelist) {
            const bool select = mCurrentSelectedTags.contains(tag->tag());
            item->setCheckState(select ? Qt::Checked : Qt::Unchecked);
        } else {
            if (mNumberOfSelectedMessages == 1) {
                const bool hasTag = mSelectedItem.hasTag(tag->tag());
                item->setCheckState(hasTag ? Qt::Checked : Qt::Unchecked);
            } else {
                item->setCheckState(Qt::Unchecked);
            }
        }
    }
```

#### AUTO 


```{c}
auto createItem = new Akonadi::ItemCreateJob(item, inboxSourceCol, this);
```

#### AUTO 


```{c}
auto vlay = new QVBoxLayout(this);
```

#### AUTO 


```{c}
auto *saveDraftJob = new SaveDraftJob(mMsg, mFolder);
```

#### AUTO 


```{c}
auto command = new KMReplyCommand(this, msg, MessageComposer::ReplyAll, text, false, tmpl);
```

#### AUTO 


```{c}
auto *job = new CreateFollowupReminderOnExistingMessageJob(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Akonadi::Item &item, const Akonadi::Collection &collection) {
                ReplayNextOnExit replayNext(mMonitor);

                qCDebug(agent_log) << "Item" << item.id() << "added to collection" << collection.id();
                const auto box = unifiedMailboxForSource(collection.id());
                if (!box) {
                    qCWarning(agent_log) << "Failed to find unified mailbox for source collection " << collection.id();
                    return;
                }

                if (!box->collectionId()) {
                    qCWarning(agent_log) << "Missing box->collection mapping for unified mailbox" << box->id();
                    return;
                }

                new Akonadi::LinkJob(Akonadi::Collection{box->collectionId().value()}, {item}, this);
            }
```

#### AUTO 


```{c}
const auto boxesGroup = kcfg->group("UnifiedMailboxes");
```

#### RANGE FOR STATEMENT 


```{c}
for (const MailCommon::Tag::Ptr &tag : std::as_const(mTags)) {
        if (tag->id() == akonadiTag.id()) {
            mTags.removeAll(tag);
            break;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, view]() {
                const auto indexes = view->selectionModel()->selectedIndexes();
                if (!indexes.isEmpty()) {
                    auto item = mBoxModel->itemFromIndex(indexes[0]);
                    auto mailbox = item->data().value<UnifiedMailbox*>();
                    auto editor = new UnifiedMailboxEditor(mailbox, mConfig, this);
                    if (editor->exec()) {
                        item->setText(mailbox->name());
                        item->setIcon(QIcon::fromTheme(mailbox->icon()));
                    }
                }
            }
```

#### AUTO 


```{c}
auto *layout = new QHBoxLayout(wid);
```

#### AUTO 


```{c}
const auto ask = [this]() {
                         if (!KMailSettings::self()->askEnableUnifiedMailboxes()) {
                             return;
                         }

                         if (kmkernel->accounts().count() <= 1) {
                             return;
                         }

                         const auto service = Akonadi::ServerManager::self()->agentServiceName(Akonadi::ServerManager::Agent, QStringLiteral("akonadi_unifiedmailbox_agent"));
                         QDBusInterface iface(service, QStringLiteral("/"), QStringLiteral("org.freedesktop.Akonadi.UnifiedMailboxAgent"),
                                              QDBusConnection::sessionBus(), this);
                         if (!iface.isValid()) {
                             return;
                         }

                         QDBusReply<bool> reply = iface.call(QStringLiteral("enabledAgent"));
                         if (!reply.isValid() || bool(reply)) {
                             return;
                         }

                         const auto answer = KMessageBox::questionYesNo(
                             this, i18n("You have more than one email account set up. Do you want to enable the Unified Mailbox feature to "
                                        "show unified content of your inbox, sent and drafts folders?\n"
                                        "You can configure unified mailboxes, create custom ones or disable the feature completely in KMail's Plugin settings."),
                             i18n("Enable Unified Mailboxes?"),
                             KGuiItem(i18n("Enable Unified Mailboxes"), QStringLiteral("dialog-ok")),
                             KGuiItem(i18n("Cancel"), QStringLiteral("dialog-cancel")));
                         if (answer == KMessageBox::Yes) {
                             iface.call(QStringLiteral("setEnableAgent"), true);
                         }

                         KMailSettings::self()->setAskEnableUnifiedMailboxes(false);
                     };
```

#### AUTO 


```{c}
auto customTemplatesTab = new ComposerPageCustomTemplatesTab();
```

#### RANGE FOR STATEMENT 


```{c}
for (const PimCommon::PluginUtilData &data : std::as_const(mPluginUtilDataList)) {
            if (item->mIdentifier == data.mIdentifier) {
                changeAgentActiveState(data.mExtraInfo.at(0), data.mExtraInfo.at(1), item->checkState(0) == Qt::Checked);
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::AgentInstance &type : lst) {
        if (type.status() == Akonadi::AgentInstance::Broken) {
            continue;
        }
        const QString typeIdentifier(type.identifier());
        if (PimCommon::Util::isImapResource(typeIdentifier)) {
            OrgKdeAkonadiImapSettingsInterface *iface = PimCommon::Util::createImapSettingsInterface(typeIdentifier);
            if (iface && iface->isValid()) {
                const Akonadi::Collection::Id imapTrashId = iface->trashCollection();
                for (const Akonadi::Collection &collection : collectionList) {
                    const Akonadi::Collection::Id collectionId = collection.id();
                    if (imapTrashId == collectionId) {
                        // Use default trash
                        iface->setTrashCollection(CommonKernel->trashCollectionFolder().id());
                        iface->save();
                        break;
                    }
                }
            }
            delete iface;
        } else if (typeIdentifier.contains(POP3_RESOURCE_IDENTIFIER)) {
            OrgKdeAkonadiPOP3SettingsInterface *iface = MailCommon::Util::createPop3SettingsInterface(typeIdentifier);
            if (iface->isValid()) {
                for (const Akonadi::Collection &collection : qAsConst(collectionList)) {
                    const Akonadi::Collection::Id collectionId = collection.id();
                    if (iface->targetCollection() == collectionId) {
                        // Use default inbox
                        iface->setTargetCollection(CommonKernel->inboxCollectionFolder().id());
                        iface->save();
                        break;
                    }
                }
            }
            delete iface;
        }
    }
```

#### AUTO 


```{c}
auto action = new QAction(i18n("Focus on Last Folder"), this);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QItemSelection &selected, const QItemSelection &deselected) {
        auto indexes = selected.indexes();
        for (const auto &index : indexes) {
            mMailbox->addSourceCollection(index.data(Akonadi::EntityTreeModel::CollectionIdRole).toLongLong());
        }
        indexes = deselected.indexes();
        for (const auto &index : indexes) {
            mMailbox->removeSourceCollection(index.data(Akonadi::EntityTreeModel::CollectionIdRole).toLongLong());
        }
    }
```

#### AUTO 


```{c}
auto job = new Akonadi::ItemFetchJob(mMessageItem, this);
```

#### AUTO 


```{c}
auto *linkDir = new QTemporaryDir(tmpPath);
```

#### AUTO 


```{c}
auto *fetchJob = static_cast<Akonadi::ItemFetchJob *>(job);
```

#### AUTO 


```{c}
auto folderToolTipsAlwaysRadio = new QRadioButton(i18n("Always"), mFolderToolTipsGroupBox);
```

#### AUTO 


```{c}
auto command = new KMReplyCommand(this,
                                       msg,
                                       MessageComposer::ReplyAll,
                                       text,
                                       false,
                                       tmpl
                                       );
```

#### RANGE FOR STATEMENT 


```{c}
for (const AttachmentPart::Ptr &part : qAsConst(toRemove)) {
            mModel->removeAttachment(part);
        }
```

#### AUTO 


```{c}
auto glay = new QGridLayout();
```

#### AUTO 


```{c}
inline auto begin() const
    {
        return mMailboxes.begin();
    }
```

#### AUTO 


```{c}
auto &changeRecorder = manager.changeRecorder();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &attach : attachList) {
            if (!attach.isEmpty()) {
                attachURLs.append(makeAbsoluteUrl(attach, workingDir));
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&c](const Akonadi::Item &item) {
                            return !item.virtualReferences().contains(c);
                        }
```

#### AUTO 


```{c}
auto group = mConfig->group("UnifiedMailboxes");
```

#### AUTO 


```{c}
auto copyParm = new short[num + 1];
```

#### RANGE FOR STATEMENT 


```{c}
for (const MailCommon::MailFilter *filter : qAsConst(mFilters)) {
        if (filter->applyOnAccount(accountId)) {
            return true;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, c](const Akonadi::Item::List &items) {
            Akonadi::Item::List toLink;
            std::copy_if(items.cbegin(), items.cend(), std::back_inserter(toLink), [&c](const Akonadi::Item &item) {
                return !item.virtualReferences().contains(c);
            });
            if (!toLink.isEmpty()) {
                new Akonadi::LinkJob(c, toLink, this);
            }
        }
```

#### AUTO 


```{c}
auto tmw = new TransportManagementWidget(this);
```

#### AUTO 


```{c}
auto command = new KMTrashMsgCommand(parentCollection(), mMsg, -1);
```

#### AUTO 


```{c}
auto *sigController = new MessageComposer::SignatureController(this);
```

#### AUTO 


```{c}
auto command = new KMForwardCommand(this,
                                                     currentItem,
                                                     0, tmpl, mReaderWin->copyText());
```

#### AUTO 


```{c}
auto wordWrapWrapper = new QWidget;
```

#### AUTO 


```{c}
auto *vbox = new QVBoxLayout(editorAndCryptoStateIndicators);
```

#### RANGE FOR STATEMENT 


```{c}
for (const MailCommon::TagPtr &tag : qAsConst(msgTagList)) {
        mOriginalMsgTagList.append(MailCommon::TagPtr(new MailCommon::Tag(*tag)));
    }
```

#### AUTO 


```{c}
auto *job = new Akonadi::ItemCopyJob(mMsg, collection, this);
```

#### AUTO 


```{c}
const auto gossipKey = rec->gossipKey();
```

#### RANGE FOR STATEMENT 


```{c}
for (FolderArchiveAccountInfo *info : std::as_const(mListAccountInfo)) {
        if (info->archiveTopLevel() == collection.id()) {
            info->setArchiveTopLevel(-1);
            KConfigGroup group = config.group(FolderArchive::FolderArchiveUtil::groupConfigPattern() + info->instanceName());
            info->writeConfig(group);
        }
    }
```

#### AUTO 


```{c}
auto fetchCollectionJob = static_cast<Akonadi::CollectionFetchJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Collection &collection : lstCols) {
        if (isFilterableCollection(collection)) {
            changeRecorder()->setCollectionMonitored(collection, true);
        } else {
            QMap<QString, Akonadi::Collection::Id>::const_iterator i = pop3ResourceMap.constBegin();
            const QMap<QString, Akonadi::Collection::Id>::const_iterator end = pop3ResourceMap.constEnd();
            while (i != end) {
                if (collection.id() == i.value()) {
                    changeRecorder()->setCollectionMonitored(collection, true);
                    break;
                }
                ++i;
            }
        }
    }
```

#### AUTO 


```{c}
auto *encryption = w->findChild<QLabel *>(QStringLiteral("encryptionindicator"));
```

#### AUTO 


```{c}
auto command = new KMForwardAttachedCommand(this, selectedMessages, mCurrentFolderSettings->identity());
```

#### RANGE FOR STATEMENT 


```{c}
for (KXMLGUIClient *client : lst) {
                client->unplugActionList(i.key());
                client->plugActionList(i.key(), i.value());
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        if (!KMailSettings::self()->askEnableUnifiedMailboxes()) {
            return;
        }

        if (kmkernel->accounts().count() <= 1) {
            return;
        }

        KMailSettings::self()->setAskEnableUnifiedMailboxes(false);

        const auto service = Akonadi::ServerManager::self()->agentServiceName(Akonadi::ServerManager::Agent, QStringLiteral("akonadi_unifiedmailbox_agent"));
        QDBusInterface iface(service, QStringLiteral("/"), QStringLiteral("org.freedesktop.Akonadi.UnifiedMailboxAgent"), QDBusConnection::sessionBus(), this);
        if (!iface.isValid()) {
            return;
        }

        QDBusReply<bool> reply = iface.call(QStringLiteral("enabledAgent"));
        if (!reply.isValid() || bool(reply)) {
            return;
        }

        const auto answer = KMessageBox::questionYesNo(
            this,
            i18n("You have more than one email account set up.\nDo you want to enable the Unified Mailbox feature to "
                 "show unified content of your inbox, sent and drafts folders?\n"
                 "You can configure unified mailboxes, create custom ones or\ndisable the feature completely in KMail's Plugin settings."),
            i18n("Enable Unified Mailboxes?"),
            KGuiItem(i18n("Enable Unified Mailboxes"), QStringLiteral("dialog-ok")),
            KGuiItem(i18n("Cancel"), QStringLiteral("dialog-cancel")));
        if (answer == KMessageBox::Yes) {
            iface.call(QStringLiteral("setEnableAgent"), true);
        }
    }
```

#### AUTO 


```{c}
auto fetch = new Akonadi::CollectionFetchJob(mMainWidget->currentCollection(), Akonadi::CollectionFetchJob::Base);
```

#### AUTO 


```{c}
auto *layout = new QVBoxLayout;
```

#### AUTO 


```{c}
const auto verifyBox = [&manager, &success](const QString &id, int numSources) {
                                   success = false;
                                   auto boxIt = std::find_if(manager.begin(), manager.end(),
                                                             [&id](const UnifiedMailboxManager::Entry &e) {
                return e.second->id() == id;
            });
                                   QVERIFY(boxIt != manager.end());
                                   const auto &box = boxIt->second;
                                   const auto sourceCollections = box->sourceCollections();
                                   QCOMPARE(sourceCollections.size(), numSources);
                                   for (auto source : sourceCollections) {
                                       auto col = collectionForId(source);
                                       QVERIFY(col);
                                       QVERIFY(col->hasAttribute<Akonadi::SpecialCollectionAttribute>());
                                       QCOMPARE(col->attribute<Akonadi::SpecialCollectionAttribute>()->collectionType(), id.toLatin1());
                                   }
                                   success = true;
                               };
```

#### AUTO 


```{c}
auto todo = item.payload<KCalendarCore::Todo::Ptr>();
```

#### AUTO 


```{c}
auto advancedMainLayout = new QVBoxLayout(tab);
```

#### AUTO 


```{c}
auto *part = new KMime::Content;
```

#### AUTO 


```{c}
auto attr = col.attribute<Akonadi::SpecialCollectionAttribute>();
```

#### AUTO 


```{c}
auto selfFilter = new SelfFilterProxyModel(this);
```

#### AUTO 


```{c}
auto lab = new QLabel(i18n("Usage:"), this);
```

#### AUTO 


```{c}
auto *job = new KIO::OpenUrlJob(url);
```

#### AUTO 


```{c}
const auto keyCache = KeyCache::mutableInstance();
```

#### AUTO 


```{c}
auto fileNameLabel = new QLabel(i18n("&Archive File:"), mainWidget);
```

#### AUTO 


```{c}
const auto currentGroups = group.groupList();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Collection &collection : kmkernel->allFolders()) {
                    KConfigGroup config(KMKernel::self()->config(), MailCommon::FolderCollection::configGroupName(collection));
                    //Old config
                    config.deleteEntry("htmlMailOverride");
                    config.deleteEntry("displayFormatOverride");
                    MailCommon::FolderCollection::resetHtmlFormat();
                }
```

#### AUTO 


```{c}
auto *emailValidator = new PimCommon::EmailValidator(this);
```

#### AUTO 


```{c}
const auto answer = KMessageBox::warningContinueCancel(
            this,
            i18np("Do you want to delete this selected item?", "Do you want to delete these %1 selected items?", mailItemLst.count()),
            i18nc("@title:window", "Delete Items"),
            KStandardGuiItem::del());
```

#### AUTO 


```{c}
auto drafts = std::make_unique<UnifiedMailbox>();
```

#### AUTO 


```{c}
auto part = model()->data(index, MessageComposer::AttachmentModel::AttachmentPartRole).value<AttachmentPart::Ptr>();
```

#### AUTO 


```{c}
auto job = new Akonadi::ItemFetchJob(item);
```

#### AUTO 


```{c}
auto *item
        = new QTreeWidgetItem(lv,
                              QStringList(i18nc("@label", "TNEF Attributes")));
```

#### AUTO 


```{c}
auto indexes = selected.indexes();
```

#### RANGE FOR STATEMENT 


```{c}
for (FollowUpReminderInfo *info : qAsConst(mFollowUpReminderInfoList)) {
        qCDebug(FOLLOWUPREMINDERAGENT_LOG) << "FollowUpReminderManager::slotCheckFollowUpFinished info:" << info;
        if (!info) {
            continue;
        }
        if (info->messageId() == messageId) {
            info->setAnswerMessageItemId(id);
            info->setAnswerWasReceived(true);
            answerReceived(info->to());
            if (info->todoId() != -1) {
                auto job = new FollowUpReminderFinishTaskJob(info->todoId(), this);
                connect(job, &FollowUpReminderFinishTaskJob::finishTaskDone, this, &FollowUpReminderManager::slotFinishTaskDone);
                connect(job, &FollowUpReminderFinishTaskJob::finishTaskFailed, this, &FollowUpReminderManager::slotFinishTaskFailed);
                job->start();
            }
            // Save item
            FollowUpReminder::FollowUpReminderUtil::writeFollowupReminderInfo(FollowUpReminder::FollowUpReminderUtil::defaultConfig(), info, true);
            break;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                itemsRetrievedIncremental({}, {}); // fake incremental retrieval
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : indexes) {
        const auto collection = index.data(Akonadi::EntityTreeModel::CollectionRole).value<Akonadi::Collection>();
        if (collection.isValid()) {
            collections << collection;
        }
    }
```

#### AUTO 


```{c}
auto action = new QAction(i18n("Previous Unread F&older"), this);
```

#### AUTO 


```{c}
auto createItem = new Akonadi::ItemCreateJob(item, inboxSourceCol.value(), this);
```

#### AUTO 


```{c}
auto job = new FollowUpReminderJob(this);
```

#### AUTO 


```{c}
auto sendlaterremovejob = new SendLaterRemoveMessageJob(listMessage, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto source : mSources) {
                mManager->mMonitor.setCollectionMonitored(Akonadi::Collection{source}, false);
                mManager->mSourceToBoxMap.erase(source);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (KMainWindow *window : lst) {
        if (::qobject_cast<KMMainWin *>(window)) {
            ktmw = window;
            break;
        }
    }
```

#### AUTO 


```{c}
auto tab = new QWidget(mTabWidget);
```

#### AUTO 


```{c}
auto *hbox = new QHBoxLayout();
```

#### AUTO 


```{c}
auto mailItem = static_cast<SendLaterItem *>(item);
```

#### AUTO 


```{c}
auto collection = model->data(child, Akonadi::EntityTreeModel::CollectionRole).value<Akonadi::Collection>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::StandardMailActionManager::Type mailAction : mailActions) {
        QAction *act = mAkonadiStandardActionManager->createAction(mailAction);
        mAkonadiStandardActionManager->interceptAction(mailAction);
        connect(act, &QAction::triggered, this, &KMReaderMainWin::slotMarkMailAs);
    }
```

#### AUTO 


```{c}
auto buttonBox = new QDialogButtonBox(QDialogButtonBox::Close, this);
```

#### AUTO 


```{c}
const auto cb = [this, finishedCb = std::move(finishedCb)]() {
        qCDebug(UNIFIEDMAILBOXAGENT_LOG) << "Finished callback: enabling change recorder";
        // Only now start processing changes from change recorder
        connect(&mMonitor, &Akonadi::ChangeRecorder::changesAdded, &mMonitor, &Akonadi::ChangeRecorder::replayNext, Qt::QueuedConnection);
        // And start replaying any potentially pending notification
        QTimer::singleShot(0, &mMonitor, &Akonadi::ChangeRecorder::replayNext);

        if (finishedCb) {
            finishedCb();
        }
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this] { slotApplyFiltersOnFolder(/* recursive */ true);
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &arg : parser.positionalArguments()) {
            if (arg.startsWith(QLatin1String("mailto:"), Qt::CaseInsensitive)) {
                const QUrl urlDecoded(QUrl::fromPercentEncoding(arg.toUtf8()));
                const QVector<QPair<QString, QString> > values = MessageCore::StringUtil::parseMailtoUrl(urlDecoded);
                QString previousKey;
                for (int i = 0; i < values.count(); ++i) {
                    const QPair<QString, QString> element = values.at(i);
                    const QString key = element.first.toLower();
                    if (key == QLatin1String("to")) {
                        if (!element.second.isEmpty()) {
                            to += element.second + QStringLiteral(", ");
                        }
                        previousKey.clear();
                    } else if (key == QLatin1String("cc")) {
                        if (!element.second.isEmpty()) {
                            cc += element.second + QStringLiteral(", ");
                        }
                        previousKey.clear();
                    } else if (key == QLatin1String("bcc")) {
                        if (!element.second.isEmpty()) {
                            bcc += element.second + QStringLiteral(", ");
                        }
                        previousKey.clear();
                    } else if (key == QLatin1String("subject")) {
                        subj = element.second;
                        previousKey.clear();
                    } else if (key == QLatin1String("body")) {
                        body = element.second;
                        previousKey = key;
                    } else if (key == QLatin1String("in-reply-to")) {
                        inReplyTo = element.second;
                        previousKey.clear();
                    } else if (key == QLatin1String("attachment") || key == QLatin1String("attach")) {
                        if (!element.second.isEmpty()) {
                            attachURLs << makeAbsoluteUrl(element.second, workingDir);
                        }
                        previousKey.clear();
                    } else {
                        qCWarning(KMAIL_LOG) << "unknown key" << key;
                        //Workaround: https://bugs.kde.org/show_bug.cgi?id=390939
                        //QMap<QString, QString> parseMailtoUrl(const QUrl &url) parses correctly url
                        //But if we have a "&" unknown key we lost it.
                        if (previousKey == QLatin1String("body")) {
                            body += QLatin1Char('&') + key + QLatin1Char('=') + element.second;
                        }
                        //Don't clear previous key.
                    }
                }
            } else {
                QUrl url(arg);
                if (url.isValid() && !url.scheme().isEmpty()) {
                    attachURLs += url;
                } else {
                    to += arg + QStringLiteral(", ");
                }
            }
            mailto = true;
        }
```

#### AUTO 


```{c}
auto *job = new MessageComposer::ConvertSnippetVariablesJob(this);
```

#### AUTO 


```{c}
auto emailValidator = new PimCommon::EmailValidator(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &index : indexes) {
            mMailbox->removeSourceCollection(index.data(Akonadi::EntityTreeModel::CollectionIdRole).toLongLong());
        }
```

#### AUTO 


```{c}
auto action = new QAction(i18n("Filter on &To..."), this);
```

#### AUTO 


```{c}
auto prefereHtml = menu.findChild<KToggleAction *>(QStringLiteral("prefer-html-action"));
```

#### AUTO 


```{c}
auto mainLayout = new QHBoxLayout(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const PimCommon::PluginUtilData &data : std::as_const(mPluginUtilDataList)) {
                if (data.mIdentifier == identifier) {
                    auto instance = Akonadi::AgentManager::self()->instance(identifier);
                    if (instance.isValid()) {
                        QPointer<Akonadi::AgentConfigurationDialog> dlg = new Akonadi::AgentConfigurationDialog(instance, this);
                        dlg->exec();
                        delete dlg;
                    }
                    break;
                }
            }
```

#### AUTO 


```{c}
const auto &item
```

#### AUTO 


```{c}
auto label2 = new QLabel(i18n("Examples are available at <a "
                                     "href=\"https://ace.home.xs4all.nl/X-Faces/\">"
                                     "https://ace.home.xs4all.nl/X-Faces/</a>."), page);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Tag &akonadiTag : tagList) {
        MailCommon::Tag::Ptr tag = MailCommon::Tag::fromAkonadi(akonadiTag);
        msgTagList.append(tag);
    }
```

#### AUTO 


```{c}
auto *autoCorrectionTab = new AutoCorrectionTab();
```

#### AUTO 


```{c}
const auto answer = KMessageBox::questionYesNo(
            this,
            i18n("You have more than one email account set up.\nDo you want to enable the Unified Mailbox feature to "
                 "show unified content of your inbox, sent and drafts folders?\n"
                 "You can configure unified mailboxes, create custom ones or\ndisable the feature completely in KMail's Plugin settings."),
            i18n("Enable Unified Mailboxes?"),
            KGuiItem(i18n("Enable Unified Mailboxes"), QStringLiteral("dialog-ok")),
            KGuiItem(i18n("Cancel"), QStringLiteral("dialog-cancel")));
```

#### AUTO 


```{c}
auto job = new Akonadi::ItemFetchJob(mListItem, this);
```

#### AUTO 


```{c}
auto action = new QAction(i18n("Followup Reminder Messages..."), this);
```

#### AUTO 


```{c}
auto header = new KMime::Headers::Generic("Face");
```

#### AUTO 


```{c}
auto systrayBoxlayout = new QVBoxLayout(systrayBox);
```

#### AUTO 


```{c}
auto session = new Akonadi::Session("UnifiedMailbox Kernel ETM", this);
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool state) {
        mUndoSendComboBox->setEnabled(state);
        slotEmitChanged();
    }
```

#### AUTO 


```{c}
const auto indexes = checkable->selectionModel()->selectedIndexes();
```

#### AUTO 


```{c}
auto *job = new KIO::ApplicationLauncherJob(offer);
```

#### AUTO 


```{c}
auto *job = new AliasesExpandJob(mEmailAddresses, mDomainDefaultName, this);
```

#### AUTO 


```{c}
const auto plugin = KPluginMetaData::findPluginById(QStringLiteral("pim/kcms/kleopatra"), QStringLiteral("kleopatra_config_gnupgsystem"));
```

#### AUTO 


```{c}
const auto ident = im->identityForUoid(identityStr.toUInt());
```

#### AUTO 


```{c}
const auto sentBoxCol = createCollection(Common::SentBoxId, parentCol, deleter);
```

#### AUTO 


```{c}
auto action = new QAction(QIcon::fromTheme(QStringLiteral("kontact")), i18n("Import/Export KMail Data..."), this);
```

#### AUTO 


```{c}
auto modify = new Akonadi::CollectionModifyJob(sentSourceCol, this);
```

#### AUTO 


```{c}
auto *rspacer = new QSpacerItem(1, 10,
                                    QSizePolicy::MinimumExpanding,
                                    QSizePolicy::MinimumExpanding);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : selectedRows) {
        auto part = mView->model()->data(index, MessageComposer::AttachmentModel::AttachmentPartRole).value<AttachmentPart::Ptr>();
        selectedParts.append(part);
    }
```

#### AUTO 


```{c}
auto *transport = new MailTransport::TransportComboBox(mHeadersArea);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &addr : qAsConst(mEmails)) {
        if (!mEmailWhiteList.contains(addr.trimmed())) {
            QString tname, temail;
            KEmailAddress::extractEmailAddressAndName(addr, temail, tname); // ignore return value
            // which is always false
            if (tname.startsWith(QLatin1Char('@'))) { // Special case when name is just @foo <...> it mustn't recognize as a valid email
                continue;
            }
            if (tname.contains(QLatin1Char('@'))) { // Potential address
                if (tname.startsWith(QLatin1Char('<')) && tname.endsWith(QLatin1Char('>'))) {
                    tname = tname.mid(1, tname.length() - 2);
                }
                if (tname.startsWith(QLatin1Char('\'')) && tname.endsWith(QLatin1Char('\''))) {
                    tname = tname.mid(1, tname.length() - 2);
                }
                if (temail.toLower() != tname.toLower()) {
                    const QString str = QStringLiteral("(%1)").arg(temail);
                    if (!tname.contains(str, Qt::CaseInsensitive)) {
                        const QStringList lst = tname.trimmed().split(QLatin1Char(' '));
                        if (lst.count() > 1) {
                            const QString firstName = lst.at(0);

                            for (const QString &n : lst) {
                                if (n != firstName) {
                                    mPotentialPhisingEmails.append(addr);
                                    break;
                                }
                            }
                        } else {
                            mPotentialPhisingEmails.append(addr);
                        }
                    }
                }
            }
        }
    }
```

#### AUTO 


```{c}
auto *composerEditorNg = new KMComposerEditorNg(this, mCryptoStateIndicatorWidget);
```

#### AUTO 


```{c}
auto linkDir = new QTemporaryDir(tmpPath);
```

#### AUTO 


```{c}
auto themeLayout = new QHBoxLayout();
```

#### AUTO 


```{c}
const auto unifiedBox = mBoxManager.unifiedMailboxFromCollection(c);
```

#### RANGE FOR STATEMENT 


```{c}
for (MessageComposer::PluginEditorConvertTextInterface *interface : qAsConst(mListPluginInterface)) {
        interface->enableDisablePluginActions(richText);
    }
```

#### AUTO 


```{c}
auto *grid = new QGridLayout(this);
```

#### AUTO 


```{c}
auto *page
        = new AppearancePage(parent);
```

#### AUTO 


```{c}
auto a = static_cast<Attachment *>(*it);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &group : filterGroups) {
        config()->deleteGroup(group);
    }
```

#### AUTO 


```{c}
auto action = new QAction(QIcon::fromTheme(QStringLiteral("mail-message-new")), i18n("&New Message..."), this);
```

#### AUTO 


```{c}
auto *signature = w.findChild<QLabel *>(QStringLiteral("signatureindicator"));
```

#### AUTO 


```{c}
auto *actionGroup = new QActionGroup(menu);
```

#### AUTO 


```{c}
auto command = new KMSetStatusCommand(clear, Akonadi::Item::List() << item, true);
```

#### AUTO 


```{c}
auto job = new Akonadi::ItemFetchJob(items, this);
```

#### AUTO 


```{c}
auto purposeMenu = new MailfilterPurposeMenuWidget(this, this);
```

#### AUTO 


```{c}
auto job = new NewMessageJob(this);
```

#### AUTO 


```{c}
const auto index = Akonadi::EntityTreeModel::modelIndexForCollection(selectionModel->model(), Akonadi::Collection(source));
```

#### AUTO 


```{c}
const auto ask = [this]() {
                         if (!KMailSettings::self()->askEnableUnifiedMailboxes()) {
                             return;
                         }

                         if (kmkernel->accounts().count() <= 1) {
                             return;
                         }

                         KMailSettings::self()->setAskEnableUnifiedMailboxes(false);

                         const auto service = Akonadi::ServerManager::self()->agentServiceName(Akonadi::ServerManager::Agent, QStringLiteral("akonadi_unifiedmailbox_agent"));
                         QDBusInterface iface(service, QStringLiteral("/"), QStringLiteral("org.freedesktop.Akonadi.UnifiedMailboxAgent"),
                                              QDBusConnection::sessionBus(), this);
                         if (!iface.isValid()) {
                             return;
                         }

                         QDBusReply<bool> reply = iface.call(QStringLiteral("enabledAgent"));
                         if (!reply.isValid() || bool(reply)) {
                             return;
                         }

                         const auto answer = KMessageBox::questionYesNo(
                             this, i18n("You have more than one email account set up.\nDo you want to enable the Unified Mailbox feature to "
                                        "show unified content of your inbox, sent and drafts folders?\n"
                                        "You can configure unified mailboxes, create custom ones or\ndisable the feature completely in KMail's Plugin settings."),
                             i18n("Enable Unified Mailboxes?"),
                             KGuiItem(i18n("Enable Unified Mailboxes"), QStringLiteral("dialog-ok")),
                             KGuiItem(i18n("Cancel"), QStringLiteral("dialog-cancel")));
                         if (answer == KMessageBox::Yes) {
                             iface.call(QStringLiteral("setEnableAgent"), true);
                         }
                     };
```

#### AUTO 


```{c}
auto *readerTab = new ReaderTab();
```

#### AUTO 


```{c}
auto jobCol = qobject_cast<Akonadi::CollectionFetchJob *>(job);
```

#### LAMBDA EXPRESSION 


```{c}
[=](const QPoint &pos) {
        Q_UNUSED(pos);
        const auto mboxSelected = view->selectionModel()->selectedIndexes();
        QMenu menu(this);
        QAction *addAction = menu.addAction(QIcon::fromTheme(QStringLiteral("list-add-symbolic")), i18n("Add"));
        QAction *removeAction = nullptr;
        QAction *editAction = nullptr;
        if (!mboxSelected.isEmpty()) {
            editAction = menu.addAction(QIcon::fromTheme(QStringLiteral("entry-edit")), i18n("Modify"));
            menu.addSeparator();
            removeAction = menu.addAction(QIcon::fromTheme(QStringLiteral("list-remove-symbolic")), i18n("Remove"));
        }
        QAction *result = menu.exec(QCursor::pos());
        if (result) {
            if (result == addAction) {
                addMailBox();
            } else if (result == removeAction) {
                removeMailBox();
            } else if (result == editAction) {
                modifyMailBox();
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        emitProgress();
    }
```

#### AUTO 


```{c}
auto hrd = msg->headerByType("X-KMail-Identity")
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &name) {
        mMailbox->setName(name.trimmed());
    }
```

#### AUTO 


```{c}
auto iconButton = new QPushButton(QIcon::fromTheme(mMailbox->icon(), QIcon::fromTheme(QStringLiteral("folder-mail"))), i18n("Pick icon..."));
```

#### RANGE FOR STATEMENT 


```{c}
for (Akonadi::AgentInstance type : lst) {
        const QString identifier = type.identifier();
        KConfigGroup group(KMKernel::config(), resourceGroupPattern.arg(identifier));

        // Keep sync in ConfigureDialog, don't forget to change there.
        if (group.readEntry("OfflineOnShutdown", identifier.startsWith(QStringLiteral("akonadi_pop3_resource")) ? true : false)) {
            type.setIsOnline(false);
        }
    }
```

#### AUTO 


```{c}
auto identityComboBox = dlg.findChild<QComboBox *>(QStringLiteral("identity_combobox"));
```

#### CONST EXPRESSION 


```{c}
static constexpr const char s_fdo_notifications_service[] = "org.freedesktop.Notifications";
```

#### AUTO 


```{c}
auto *page = new ConfigurePluginPage(parent);
```

#### AUTO 


```{c}
auto *label
        = new QLabel(i18n("Select the plugin summaries to show on the summary page."), this);
```

#### AUTO 


```{c}
auto act = w.findChild<QAction *>(QStringLiteral("sendnow"));
```

#### AUTO 


```{c}
auto *mailItem = static_cast<SendLaterItem *>(listItems.first());
```

#### AUTO 


```{c}
auto ct = msgPart->contentType();
```

#### RANGE FOR STATEMENT 


```{c}
for (MessageComposer::PluginEditorConvertTextInterface *interface : qAsConst(mListPluginInterface)) {
        interface->setInitialData(data);
    }
```

#### AUTO 


```{c}
auto action = new QAction(i18n("Focus on Previous Folder"), this);
```

#### AUTO 


```{c}
auto *job = new Akonadi::CollectionCreateJob(collection);
```

#### AUTO 


```{c}
auto menuCustom = mMsgActions->customTemplatesMenu()
```

#### RANGE FOR STATEMENT 


```{c}
for (KPIM::MultiplyingLine *line : lstLines) {
        slotRecipientEditorLineAdded(line);
    }
```

#### AUTO 


```{c}
auto col = Akonadi::EntityTreeModel::updatedCollection(MailCommon::Kernel::self()->kernelIf()->collectionModel(), context.item().parentCollection());
```

#### AUTO 


```{c}
auto subjectTab = new ComposerPageSubjectTab();
```

#### AUTO 


```{c}
auto recipientsEditor = new MessageComposer::RecipientsEditor(mHeadersArea);
```

#### AUTO 


```{c}
const auto inbox = createUnifiedMailbox(Common::InboxBoxId, QStringLiteral("Inbox"), {QStringLiteral("res1_inbox"), QStringLiteral("res2_inbox")});
```

#### AUTO 


```{c}
auto *l = new QHBoxLayout(this);
```

#### AUTO 


```{c}
auto createAgentJob = new Akonadi::AgentInstanceCreateJob(agentType, this);
```

#### AUTO 


```{c}
auto *backupJob = new MailCommon::BackupJob(mParentWidget);
```

#### LAMBDA EXPRESSION 


```{c}
[this](QDBusPendingCallWatcher *watcher) {
        QDBusPendingReply<QStringList> reply = *watcher;
        watcher->deleteLater();

        if (reply.isError()) {
            return;
        }

        const QStringList &services = reply.value();

        mUnityServiceAvailable = services.contains(QLatin1String("com.canonical.Unity"));
        if (mUnityServiceAvailable) {
            updateCount();
        }
    }
```

#### AUTO 


```{c}
auto *signature = w->findChild<QLabel *>(QStringLiteral("signatureindicator"));
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &service) {
        Q_UNUSED(service);
        mUnityServiceAvailable = true;
        updateCount();
    }
```

#### AUTO 


```{c}
auto item = new QListWidgetItem(QIcon::fromTheme(tag->iconName), tag->tagName, mListTag);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto line_ : lst) {
        auto line = qobject_cast<MessageComposer::RecipientLineNG *>(line_);

        // There's still a lookup job running, so wait, slotKeyForMailBoxResult()
        // will call us if the job returns empty key
        if (line->property("keyLookupJob").isValid()) {
            return;
        }

        const auto keyStatus = static_cast<CryptoKeyState>(line->property("keyStatus").toInt());
        if (keyStatus == NoState) {
            continue;
        }

        if (!line->recipient()->isEmpty() && keyStatus != KeyOk) {
            setEncryption(false, false);
            return;
        }

        encrypt = true;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto plugin : std::as_const(pluginMetaDatas)) {
        QVariant var = plugin.value(QStringLiteral("X-KDE-KontactPluginHasSummary"), false);
        if (var.isValid() && var.toBool() == true) {
            auto item = new PluginItem(plugin, mPluginView);

            if (activeSummaries.contains(plugin.pluginId())) {
                item->setCheckState(0, Qt::Checked);
            } else {
                item->setCheckState(0, Qt::Unchecked);
            }
        }
    }
```

#### AUTO 


```{c}
auto sa = new QScrollArea(core);
```

#### AUTO 


```{c}
auto action = new QAction(i18nc("View->", "&Collapse Thread / Group"), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (Akonadi::AgentInstance type : lst) {
        const QString identifier(type.identifier());
        if (PimCommon::Util::isImapResource(identifier)
            || identifier.contains(POP3_RESOURCE_IDENTIFIER)
            || identifier.contains(QStringLiteral("akonadi_maildispatcher_agent"))
            || type.type().capabilities().contains(QStringLiteral("NeedsNetwork"))) {
            type.setIsOnline(goOnline);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Akonadi::Item::List &items, const Akonadi::Collection &srcCollection,
                         const Akonadi::Collection &dstCollection) {
        ReplayNextOnExit replayNext(mMonitor);

        if (const auto srcBox = unifiedMailboxForSource(srcCollection.id())) {
            // Move source collection was our source, unlink the Item from a box
            new Akonadi::UnlinkJob(Akonadi::Collection{srcBox->collectionId().value()}, items, this);
        }
        if (const auto dstBox = unifiedMailboxForSource(dstCollection.id())) {
            // Move destination collection is our source, link the Item into a box
            new Akonadi::LinkJob(Akonadi::Collection{dstBox->collectionId().value()}, items, this);
        }
    }
```

#### AUTO 


```{c}
const auto mainWinAction = manager->action(Akonadi::StandardActionManager::MoveItemToMenu);
```

#### AUTO 


```{c}
auto dlgGroup = mConfig->group(DialogGroup);
```

#### AUTO 


```{c}
auto item = new QTreeWidgetItem(QStringList() << text);
```

#### AUTO 


```{c}
auto *mainLayout = new QVBoxLayout(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &index : indexes) {
                    mMailbox->removeSourceCollection(index.data(Akonadi::EntityTreeModel::CollectionIdRole).toLongLong());
                }
```

#### AUTO 


```{c}
auto ftw = new MailCommon::FolderTreeWidget(nullptr, nullptr,
                                                MailCommon::FolderTreeWidget::TreeViewOptions(MailCommon::FolderTreeWidget::UseDistinctSelectionModel
                                                                                              |MailCommon::FolderTreeWidget::HideStatistics
                                                                                              |MailCommon::FolderTreeWidget::HideHeaderViewMenu));
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::AgentInstance &type : lst) {
        // Explicitly make a copy, as we're not changing values of the list but only
        // the local copy which is passed to action.
        accountLst << type.identifier();
    }
```

#### AUTO 


```{c}
auto treeWidget = infowidget->findChild<QTreeWidget *>(QStringLiteral("treewidget"));
```

#### AUTO 


```{c}
auto messageTagTab = new MessageTagTab();
```

#### AUTO 


```{c}
auto listItem = new QTreeWidgetItem(mHeaderList);
```

#### AUTO 


```{c}
const auto dstBox = unifiedMailboxForSource(dstCollection.id())
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto source : std::as_const(mSources)) {
                manager->mMonitor.setCollectionMonitored(Akonadi::Collection{source});
                manager->mSourceToBoxMap.insert({source, this});
            }
```

#### AUTO 


```{c}
const auto mailItem = static_cast<FollowUpReminderInfoItem *>(item);
```

#### AUTO 


```{c}
auto action = new QAction(i18n("Copy Message to Folder"), this);
```

#### AUTO 


```{c}
const auto collection = model->data(index, Akonadi::EntityTreeModel::CollectionRole).value<Akonadi::Collection>();
```

#### AUTO 


```{c}
auto im = KMKernel::self()->identityManager();
```

#### AUTO 


```{c}
auto actionGroup = new QActionGroup(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) { d->modifyJobResult(job);}
```

#### CONST EXPRESSION 


```{c}
static constexpr auto SpecialCollectionInbox = "inbox";
```

#### AUTO 


```{c}
auto label1 = new QLabel(i18n("<qt>KMail can send a small (48x48 pixels), low-quality, "
                                     "monochrome picture with every message. "
                                     "For example, this could be a picture of you or a glyph. "
                                     "It is shown in the recipient's mail client (if supported).</qt>"), page);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &configName: configNameFiles) {
        initCleanupFolderSettings(configName);
        initCleanupFiltersSettings(configName);
        initCleanDialogSettings(configName);
        removeTipOfDay(configName);
    }
```

#### AUTO 


```{c}
auto nameEdit = new QLineEdit(mailBoxName);
```

#### AUTO 


```{c}
auto mailItem = static_cast<SendLaterItem *>(listItems.first());
```

#### RANGE FOR STATEMENT 


```{c}
for (MessageComposer::PluginEditorInterface *interface : qAsConst(mListPluginInterface)) {
            const MessageComposer::PluginActionType actionType = interface->actionType();
            MessageComposer::PluginActionType::Type type = actionType.type();
            const bool needSelectedText = interface->needSelectedText();
            if (needSelectedText) {
                //Disable by default as we don't have selection by default.
                actionType.action()->setEnabled(false);
                connect(this, &KMailPluginEditorManagerInterface::textSelectionChanged, actionType.action(), &QAction::setEnabled);
            }
            QList<QAction *> lst = mActionHash.value(type);
            if (!lst.isEmpty()) {
                auto *act = new QAction(this);
                act->setSeparator(true);
                lst << act << actionType.action();
                mActionHash.insert(type, lst);
            } else {
                mActionHash.insert(type, QList<QAction *>() << actionType.action());
            }
            if (interface->plugin()->hasPopupMenuSupport()) {
                type = MessageComposer::PluginActionType::PopupMenu;
                lst = mActionHash.value(type);
                if (!lst.isEmpty()) {
                    auto *act = new QAction(this);
                    act->setSeparator(true);
                    lst << act << actionType.action();
                    mActionHash.insert(type, lst);
                } else {
                    mActionHash.insert(type, QList<QAction *>() << actionType.action());
                }
            }
            if (interface->plugin()->hasToolBarSupport()) {
                type = MessageComposer::PluginActionType::ToolBar;
                lst = mActionHash.value(type);
                if (!lst.isEmpty()) {
                    auto *act = new QAction(this);
                    act->setSeparator(true);
                    lst << act << actionType.action();
                    mActionHash.insert(type, lst);
                } else {
                    mActionHash.insert(type, QList<QAction *>() << actionType.action());
                }
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) {
                    d->moveJobResult(job);
                }
```

#### AUTO 


```{c}
auto interface = static_cast<MessageComposer::PluginEditorInterface *>(plugin->createInterface(this));
```

#### AUTO 


```{c}
auto command = new KMSetTagCommand(Akonadi::Tag::List() << tag, select, KMSetTagCommand::Toggle);
```

#### AUTO 


```{c}
const auto uids = key.userIDs();
```

#### AUTO 


```{c}
auto *item = dynamic_cast<IdentityListViewItem *>(mIPage.mIdentityList->topLevelItem(i));
```

#### RANGE FOR STATEMENT 


```{c}
for (MessageComposer::PluginEditorConvertTextInterface *interface : std::as_const(mListPluginInterface)) {
        if (interface->reformatText()) {
            // TODO signal that it was reformating.
            // Stop it.?
        }
    }
```

#### AUTO 


```{c}
auto *job = new Akonadi::AddEmailDisplayJob(emailString, mMainWindow, this);
```

#### AUTO 


```{c}
auto identCombo = composer->findChild<KIdentityManagement::IdentityCombo *>(QStringLiteral("identitycombo"));
```

#### AUTO 


```{c}
auto *item = static_cast<PluginItem *>(*it);
```

#### AUTO 


```{c}
auto *layAttachment = new QHBoxLayout;
```

#### RANGE FOR STATEMENT 


```{c}
for (auto line : lst) {
            if (encrypt) {
                // Encryption was enabled, update encryption status of all recipients
                slotRecipientAdded(qobject_cast<MessageComposer::RecipientLineNG *>(line));
            } else {
                // Encryption was disabled, remove the encryption indicator
                auto edit = qobject_cast<MessageComposer::RecipientLineNG *>(line);
                edit->setIcon(QIcon());
                auto recipient = edit->data().dynamicCast<MessageComposer::Recipient>();
                recipient->setEncryptionAction(Kleo::Impossible);
                recipient->setKey(GpgME::Key());
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Collection &collection : lstCols) {
        if (isFilterableCollection(collection)) {
            changeRecorder()->setCollectionMonitored(collection, true);
        } else {
            for (auto pop3ColId : pop3ResourceMap) {
                if (collection.id() == pop3ColId) {
                    changeRecorder()->setCollectionMonitored(collection, true);
                    break;
                }
            }
        }
    }
```

#### AUTO 


```{c}
auto orderProxy = new MailCommon::FavoriteCollectionOrderProxyModel(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (FollowUpReminderInfo *info : qAsConst(mFollowUpReminderInfoList)) {
        qCDebug(FOLLOWUPREMINDERAGENT_LOG) << "FollowUpReminderManager::slotCheckFollowUpFinished info:" << info;
        if (!info) {
            continue;
        }
        if (info->messageId() == messageId) {
            info->setAnswerMessageItemId(id);
            info->setAnswerWasReceived(true);
            answerReceived(info->to());
            if (info->todoId() != -1) {
                FollowUpReminderFinishTaskJob *job = new FollowUpReminderFinishTaskJob(info->todoId(), this);
                connect(job, &FollowUpReminderFinishTaskJob::finishTaskDone, this, &FollowUpReminderManager::slotFinishTaskDone);
                connect(job, &FollowUpReminderFinishTaskJob::finishTaskFailed, this, &FollowUpReminderManager::slotFinishTaskFailed);
                job->start();
            }
            //Save item
            FollowUpReminder::FollowUpReminderUtil::writeFollowupReminderInfo(FollowUpReminder::FollowUpReminderUtil::defaultConfig(), info, true);
            break;
        }
    }
```

#### AUTO 


```{c}
auto label = new QLabel(i18n("This list is checked for every outgoing message "
                                 "from the top to the bottom for a charset that "
                                 "contains all required characters."),
                            this);
```

#### AUTO 


```{c}
auto job = new Akonadi::ItemFetchJob(mTemplateFolder);
```

#### AUTO 


```{c}
auto msg = mMessageItem.payload<KMime::Message::Ptr>();
```

#### AUTO 


```{c}
const auto sources = unifiedBox->sourceCollections();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &acc : std::as_const(menuItems)) {
            mSyncAction->addAction(acc);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (MessageComposer::PluginEditorConvertText *plugin : lstPlugin) {
        if (plugin->isEnabled()) {
            MessageComposer::PluginEditorConvertTextInterface *interface = static_cast<MessageComposer::PluginEditorConvertTextInterface *>(plugin->createInterface(mActionCollection, this));
            interface->setRichTextEditor(mRichTextEditor);
            interface->setParentWidget(mParentWidget);
            mListPluginInterface.append(interface);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Akonadi::Collection &col, const QSet<QByteArray> &parts) {
        ReplayNextOnExit replayNext(mMonitor);

        qCDebug(UNIFIEDMAILBOXAGENT_LOG) << "Collection changed:" << parts;
        if (!parts.contains(Akonadi::SpecialCollectionAttribute().type())) {
            return;
        }

        if (col.hasAttribute<Akonadi::SpecialCollectionAttribute>()) {
            const auto srcBox = unregisterSpecialSourceCollection(col.id());
            const auto dstBox = registerSpecialSourceCollection(col);
            if (srcBox == dstBox) {
                return;
            }

            saveBoxes();

            if (srcBox && srcBox->sourceCollections().isEmpty()) {
                removeBox(srcBox->id());
                return;
            }

            if (srcBox) {
                Q_EMIT updateBox(srcBox);
            }
            if (dstBox) {
                Q_EMIT updateBox(dstBox);
            }
        } else {
            if (const auto box = unregisterSpecialSourceCollection(col.id())) {
                saveBoxes();
                if (box->sourceCollections().isEmpty()) {
                    removeBox(box->id());
                } else {
                    Q_EMIT updateBox(box);
                }
            }
        }
    }
```

#### AUTO 


```{c}
auto favoriteFoldersViewListRadio = new QRadioButton(i18n("As list"), mFavoriteFoldersViewGroupBox);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::AgentInstance &instance : allInstances) {
        KSieveUi::SieveImapInstance sieveInstance;
        sieveInstance.setCapabilities(instance.type().capabilities());
        sieveInstance.setIdentifier(instance.identifier());
        sieveInstance.setMimeTypes(instance.type().mimeTypes());
        sieveInstance.setName(instance.name());
        switch (instance.status()) {
        case Akonadi::AgentInstance::Idle:
            sieveInstance.setStatus(KSieveUi::SieveImapInstance::Idle);
            break;
        case Akonadi::AgentInstance::Running:
            sieveInstance.setStatus(KSieveUi::SieveImapInstance::Running);
            break;
        case Akonadi::AgentInstance::Broken:
            sieveInstance.setStatus(KSieveUi::SieveImapInstance::Broken);
            break;
        case Akonadi::AgentInstance::NotConfigured:
            sieveInstance.setStatus(KSieveUi::SieveImapInstance::NotConfigured);
            break;
        }
        listInstance.append(sieveInstance);
    }
```

#### AUTO 


```{c}
auto printerWin = new KMReaderWin(nullptr, parentWidget(), nullptr);
```

#### AUTO 


```{c}
auto act = new KToggleAction(i18n("Prefer &HTML to Plain Text"), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &addr : std::as_const(mEmails)) {
        if (!mEmailWhiteList.contains(addr.trimmed())) {
            QString tname, temail;
            KEmailAddress::extractEmailAddressAndName(addr, temail, tname); // ignore return value
            // which is always false
            if (tname.startsWith(QLatin1Char('@'))) { // Special case when name is just @foo <...> it mustn't recognize as a valid email
                continue;
            }
            if (tname.contains(QLatin1Char('@'))) { // Potential address
                if (tname.startsWith(QLatin1Char('<')) && tname.endsWith(QLatin1Char('>'))) {
                    tname = tname.mid(1, tname.length() - 2);
                }
                if (tname.startsWith(QLatin1Char('\'')) && tname.endsWith(QLatin1Char('\''))) {
                    tname = tname.mid(1, tname.length() - 2);
                }
                if (temail.toLower() != tname.toLower()) {
                    const QString str = QStringLiteral("(%1)").arg(temail);
                    if (!tname.contains(str, Qt::CaseInsensitive)) {
                        const QStringList lst = tname.trimmed().split(QLatin1Char(' '));
                        if (lst.count() > 1) {
                            const QString firstName = lst.at(0);

                            for (const QString &n : lst) {
                                if (n != firstName) {
                                    mPotentialPhisingEmails.append(addr);
                                    break;
                                }
                            }
                        } else {
                            mPotentialPhisingEmails.append(addr);
                        }
                    }
                }
            }
        }
    }
```

#### AUTO 


```{c}
auto wrapper = new QWidget;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &alias : aliases) {
        const QString aliasTrimmed = alias.trimmed();
        if (aliasTrimmed.isEmpty()) {
            continue;
        }
        if (aliasTrimmed == email) {
            continue;
        }
        result.append(alias);
    }
```

#### AUTO 


```{c}
auto generalTab = new SecurityPageGeneralTab();
```

#### RANGE FOR STATEMENT 


```{c}
for (MessageComposer::PluginEditorConvertTextInterface *interface : qAsConst(mListPluginInterface)) {
            for (const MessageComposer::PluginActionType &actionType : interface->actionTypes()) {
                MessageComposer::PluginActionType::Type type = actionType.type();
                QAction *currentAction = actionType.action();
                if (!currentAction) {
                    continue;
                }
                QList<QAction *> lst = mActionHash.value(type);
                if (!lst.isEmpty()) {
                    QAction *act = new QAction(this);
                    act->setSeparator(true);
                    lst << act << currentAction;
                    mActionHash.insert(type, lst);
                } else {
                    mActionHash.insert(type, QList<QAction *>() << currentAction);
                }
                if (interface->plugin()->hasPopupMenuSupport()) {
                    type = MessageComposer::PluginActionType::PopupMenu;
                    if (currentAction) {
                        lst = mActionHash.value(type);
                        if (!lst.isEmpty()) {
                            QAction *act = new QAction(this);
                            act->setSeparator(true);
                            lst << act << currentAction;
                            mActionHash.insert(type, lst);
                        } else {
                            mActionHash.insert(type, QList<QAction *>() << currentAction);
                        }
                    }
                }
                if (interface->plugin()->hasToolBarSupport()) {
                    type = MessageComposer::PluginActionType::ToolBar;
                    lst = mActionHash.value(type);
                    if (!lst.isEmpty()) {
                        QAction *act = new QAction(this);
                        act->setSeparator(true);
                        lst << act << currentAction;
                        mActionHash.insert(type, lst);
                    } else {
                        mActionHash.insert(type, QList<QAction *>() << currentAction);
                    }
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : urlList) {
                    addAttachment(url, QString());
                }
```

#### AUTO 


```{c}
auto handle = new WinObjPenHandle;
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *a : std::as_const(mFilterFolderMenuRecursiveActions)) {
        actionCollection()->removeAction(a);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (FollowUpReminder::FollowUpReminderInfo *info : infoList) {
        if (info->isValid()) {
            createOrUpdateItem(info);
        } else {
            delete info;
        }
    }
```

#### AUTO 


```{c}
const auto item = index.data(Akonadi::EntityTreeModel::ItemRole).value<Akonadi::Item>();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        updateHamburgerMenu();
        // Immediately disconnect. We only need to run this once, but on demand.
        // NOTE: The nullptr at the end disconnects all connections between
        // q and mHamburgerMenu's aboutToShowMenu signal.
        disconnect(mHamburgerMenu, &KHamburgerMenu::aboutToShowMenu, this, nullptr);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *j : actList) {
            if (j != mSyncAction) {
                j->trigger();
            }
        }
```

#### AUTO 


```{c}
auto *job = new SaveAsFileJob(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                         if (!KMailSettings::self()->askEnableUnifiedMailboxes()) {
                             return;
                         }

                         if (kmkernel->accounts().count() <= 1) {
                             return;
                         }

                         const auto service = Akonadi::ServerManager::self()->agentServiceName(Akonadi::ServerManager::Agent, QStringLiteral("akonadi_unifiedmailbox_agent"));
                         QDBusInterface iface(service, QStringLiteral("/"), QStringLiteral("org.freedesktop.Akonadi.UnifiedMailboxAgent"),
                                              QDBusConnection::sessionBus(), this);
                         if (!iface.isValid()) {
                             return;
                         }

                         QDBusReply<bool> reply = iface.call(QStringLiteral("enabledAgent"));
                         if (!reply.isValid() || bool(reply)) {
                             return;
                         }

                         const auto answer = KMessageBox::questionYesNo(
                             this, i18n("You have more than one email account set up. Do you want to enable the Unified Mailbox feature to "
                                        "show unified content of your inbox, sent and drafts folders?\n"
                                        "You can configure unified mailboxes, create custom ones or disable the feature completely in KMail's Plugin settings."),
                             i18n("Enable Unified Mailboxes?"),
                             KGuiItem(i18n("Enable Unified Mailboxes"), QStringLiteral("dialog-ok")),
                             KGuiItem(i18n("Cancel"), QStringLiteral("dialog-cancel")));
                         if (answer == KMessageBox::Yes) {
                             iface.call(QStringLiteral("setEnableAgent"), true);
                         }

                         KMailSettings::self()->setAskEnableUnifiedMailboxes(false);
                     }
```

#### AUTO 


```{c}
auto *warningTab = new WarningTab();
```

#### AUTO 


```{c}
const auto sentBoxCol = createCollection(Common::SentBoxId, parentCol.value(), deleter);
```

#### AUTO 


```{c}
auto fetch = new Akonadi::CollectionFetchJob(Akonadi::Collection::root(), Akonadi::CollectionFetchJob::Recursive);
```

#### AUTO 


```{c}
auto job = new MessageComposer::SendLaterRemoveJob(mAkonadiIndex, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Collection &col : qAsConst(mCollectionId)) {
            lst << col.id();
        }
```

#### AUTO 


```{c}
const auto transportAttribute = item.attribute<MailTransport::TransportAttribute>();
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *a : qAsConst(mFilterFolderMenuRecursiveActions)) {
        actionCollection()->removeAction(a);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::AgentInstance &type : lst) {
            // Explicitly make a copy, as we're not changing values of the list but only
            // the local copy which is passed to action.
            const QString identifierName = type.identifier();
            const int index = mOrderIdentifier.indexOf(identifierName);
            const AgentIdentifier id(identifierName, QString(type.name()).replace(QLatin1Char('&'), QStringLiteral("&&")), index);
            agentIdentifierList << id;
        }
```

#### AUTO 


```{c}
auto a
```

#### AUTO 


```{c}
auto col = Akonadi::EntityTreeModel::updatedCollection(MailCommon::Kernel::self()->kernelIf()->collectionModel(),
                                                           context.item().parentCollection());
```

#### LAMBDA EXPRESSION 


```{c}
[type](const Akonadi::Collection::List &cols) {
                if (cols.count() != 1) {
                    qCWarning(agent_log) << "Identity special collection retrieval did not find a valid collection";
                    return;
                }
                Akonadi::SpecialMailCollections::self()->registerCollection(type, cols.first());
            }
```

#### AUTO 


```{c}
const auto runningJob = line->property("keyLookupJob").value<QPointer<QGpgME::KeyForMailboxJob> >();
```

#### RANGE FOR STATEMENT 


```{c}
for (Akonadi::AgentInstance type : lst) {
        const QString id = type.identifier();
        KConfigGroup group(KMKernel::config(), resourceGroupPattern.arg(id));
        if (group.readEntry("IncludeInManualChecks", true)) {
            if (!type.isOnline()) {
                type.setIsOnline(true);
            }
            if (mResourcesBeingChecked.isEmpty()) {
                qCDebug(KMAIL_LOG) << "Starting manual mail check";
                Q_EMIT startCheckMail();
            }

            if (!mResourcesBeingChecked.contains(id)) {
                mResourcesBeingChecked.append(id);
            }
            type.synchronize();
        }
    }
```

#### AUTO 


```{c}
auto *fetch = new Akonadi::CollectionFetchJob(mFolder, Akonadi::CollectionFetchJob::Base, this);
```

#### AUTO 


```{c}
auto act = new QAction(i18n("Previous Selected Folder"), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Collection &col : cols) {
        const QModelIndex colIdx = Akonadi::EntityTreeModel::modelIndexForCollection(etm, col);
        if (col.statistics().count() > -1) {
            if (col.cachePolicy().localParts().contains(QStringLiteral("RFC822"))) {
                result.push_back(col);
            }
        } else {
            const Akonadi::Collection collection = etm->data(colIdx, Akonadi::EntityTreeModel::CollectionRole).value<Akonadi::Collection>();
            if (!collection.hasAttribute<Akonadi::EntityHiddenAttribute>()
                && collection.cachePolicy().localParts().contains(QStringLiteral("RFC822"))) {
                result.push_back(collection);
            }
        }

        const int childrenCount = etm->rowCount(colIdx);
        if (childrenCount > 0) {
            Akonadi::Collection::List subCols;
            subCols.reserve(childrenCount);
            for (int i = 0; i < childrenCount; ++i) {
                const QModelIndex idx = etm->index(i, 0, colIdx);
                const Akonadi::Collection child = etm->data(idx, Akonadi::EntityTreeModel::CollectionRole).value<Akonadi::Collection>();
                if (child.cachePolicy().localParts().contains(QStringLiteral("RFC822"))) {
                    subCols.push_back(child);
                }
            }

            result += searchCollectionsRecursive(subCols);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Collection &collection : lstAddressCollection ) {
        if (Akonadi::Collection::CanCreateItem & collection.rights()) {
            canCreateItemCollections.append(collection);
        }
    }
```

#### AUTO 


```{c}
auto *drag = new QDrag(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &account : accountList) {
        KConfigGroup group = config.group(account);
        auto *info = new FolderArchiveAccountInfo(group);
        if (info->enabled()) {
            mListAccountInfo.append(info);
        } else {
            delete info;
        }
    }
```

#### AUTO 


```{c}
const auto service = Akonadi::ServerManager::self()->agentServiceName(Akonadi::ServerManager::Agent, QStringLiteral("akonadi_newmailnotifier_agent"));
```

#### LAMBDA EXPRESSION 


```{c}
[this, view]() {
        const auto indexes = view->selectionModel()->selectedIndexes();
        if (!indexes.isEmpty()) {
            auto item = mBoxModel->itemFromIndex(indexes[0]);
            const auto mailbox = item->data().value<UnifiedMailbox *>();
            if (KMessageBox::warningYesNo(this,
                                          i18n("Do you really want to remove unified mailbox <b>%1</b>?", mailbox->name()),
                                          i18n("Really Remove?"),
                                          KStandardGuiItem::remove(),
                                          KStandardGuiItem::cancel())
                == KMessageBox::Yes) {
                mBoxModel->removeRow(item->row());
                mBoxManager.removeBox(mailbox->id());
                mBoxManager.saveBoxes();
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &it : lstItems) {
        if (mInvertMark) {
            // qCDebug(KMAIL_LOG)<<" item ::"<<tmpItem;
            if (it.isValid()) {
                bool myStatus;
                MessageStatus itemStatus;
                itemStatus.setStatusFromFlags(it.flags());
                if (itemStatus & mStatus) {
                    myStatus = true;
                } else {
                    myStatus = false;
                }
                if (myStatus != parentStatus) {
                    continue;
                }
            }
        }
        Akonadi::Item item(it);
        const Akonadi::Item::Flag flag = *(mStatus.statusFlags().constBegin());
        if (mInvertMark) {
            if (item.hasFlag(flag)) {
                item.clearFlag(flag);
                itemsToModify.push_back(item);
            } else {
                item.setFlag(flag);
                itemsToModify.push_back(item);
            }
        } else {
            if (!item.hasFlag(flag)) {
                item.setFlag(flag);
                itemsToModify.push_back(item);
            }
        }
    }
```

#### AUTO 


```{c}
auto *attribute = new Akonadi::PersistentSearchAttribute();
```

#### AUTO 


```{c}
auto action = new QAction(i18nc("Go->", "Next Unread &Text"), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (MessageComposer::PluginEditorConvertTextInterface *interface : qAsConst(mListPluginInterface)) {
        if (interface->reformatText()) {
            // TODO signal that it was reformating.
            // Stop it.?
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const qlonglong &id : qAsConst(mMsgListId)) {
        int diff = msgCountToFilter - ++msgCount;
        if (diff < 10 || !(msgCount % 10) || msgCount <= 10) {
            progressItem->updateProgress();
            const QString statusMsg = i18n("Filtering message %1 of %2",
                                           msgCount, msgCountToFilter);
            KPIM::BroadcastStatus::instance()->setStatusMsg(statusMsg);
            qApp->processEvents(QEventLoop::ExcludeUserInputEvents, 50);
        }

        MailCommon::FilterManager::instance()->filter(Akonadi::Item(id), mFilterId, QString());
        progressItem->incCompletedItems();
    }
```

#### AUTO 


```{c}
const auto box = mMailboxes.find(col.name());
```

#### AUTO 


```{c}
auto command = new FolderShortcutCommand(mParent, col);
```

#### AUTO 


```{c}
auto action = new QAction(i18n("Extend Selection to Next Message"), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : items) {
        mManager->itemRemoved(item.id());
    }
```

#### AUTO 


```{c}
auto win = new KMReaderMainWin(MessageViewer::Viewer::UseGlobalSetting, false);
```

#### AUTO 


```{c}
auto action = new QAction(i.key(), this);
```

#### AUTO 


```{c}
auto act =
        new QAction(i18nc("%1 is a 'Contact Owner' or similar action. %2 is a protocol normally web or email though could be irc/ftp or other url variant",
                          "%1 (%2)",
                          item,
                          protocol),
                    this);
```

#### CONST EXPRESSION 


```{c}
static constexpr const char *EditorGroup = "UnifiedMailboxEditorDialog";
```

#### LAMBDA EXPRESSION 


```{c}
[iconButton, this]() {
        const auto iconName = KIconDialog::getIcon();
        if (!iconName.isEmpty()) {
            mMailbox->setIcon(iconName);
            iconButton->setIcon(QIcon::fromTheme(iconName));
        }
    }
```

#### AUTO 


```{c}
auto *win
            = new KMReaderMainWin(content, MessageViewer::Viewer::Text, charsetStr);
```

#### AUTO 


```{c}
auto pathLabel = new QLabel(i18n("Path:"), this);
```

#### LAMBDA EXPRESSION 


```{c}
[this, line]() {
                this->slotRecipientFocusLost(line);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto a : std::as_const(mFilterFolderMenuRecursiveActions)) {
        a->setEnabled(folderIsValid);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (MessageComposer::PluginEditorInterface *interface : qAsConst(mListPluginInterface)) {
            const MessageComposer::PluginActionType actionType = interface->actionType();
            MessageComposer::PluginActionType::Type type = actionType.type();
            const bool needSelectedText = interface->needSelectedText();
            if (needSelectedText) {
                //Disable by default as we don't have selection by default.
                actionType.action()->setEnabled(false);
                connect(this, &KMailPluginEditorManagerInterface::textSelectionChanged, actionType.action(), &QAction::setEnabled);
            }
            QList<QAction *> lst = mActionHash.value(type);
            if (!lst.isEmpty()) {
                QAction *act = new QAction(this);
                act->setSeparator(true);
                lst << act << actionType.action();
                mActionHash.insert(type, lst);
            } else {
                mActionHash.insert(type, QList<QAction *>() << actionType.action());
            }
            if (interface->plugin()->hasPopupMenuSupport()) {
                type = MessageComposer::PluginActionType::PopupMenu;
                lst = mActionHash.value(type);
                if (!lst.isEmpty()) {
                    QAction *act = new QAction(this);
                    act->setSeparator(true);
                    lst << act << actionType.action();
                    mActionHash.insert(type, lst);
                } else {
                    mActionHash.insert(type, QList<QAction *>() << actionType.action());
                }
            }
            if (interface->plugin()->hasToolBarSupport()) {
                type = MessageComposer::PluginActionType::ToolBar;
                lst = mActionHash.value(type);
                if (!lst.isEmpty()) {
                    QAction *act = new QAction(this);
                    act->setSeparator(true);
                    lst << act << actionType.action();
                    mActionHash.insert(type, lst);
                } else {
                    mActionHash.insert(type, QList<QAction *>() << actionType.action());
                }
            }
        }
```

#### AUTO 


```{c}
auto *job = new Akonadi::ItemMoveJob(info->items, info->srcFolder, this);
```

#### AUTO 


```{c}
auto addButton = new QPushButton(QIcon::fromTheme(QStringLiteral("list-add-symbolic")), i18n("Add"));
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &str) {
                    if (!str.isEmpty()) {
                        const QUrl localUrl = QUrl::fromLocalFile(str);
                        AttachmentInfo info;
                        info.url = localUrl;
                        addAttachment(QList<AttachmentInfo>() << info, false);
                    }
                }
```

#### AUTO 


```{c}
auto mainWidget = new QWidget(this);
```

#### LAMBDA EXPRESSION 


```{c}
[&loadingDone]() { loadingDone = true; }
```

#### AUTO 


```{c}
auto ftw = new MailCommon::FolderTreeWidget(nullptr, nullptr,
                                                MailCommon::FolderTreeWidget::TreeViewOptions(MailCommon::FolderTreeWidget::UseDistinctSelectionModel
                                                                                              |MailCommon::FolderTreeWidget::HideStatistics));
```

#### AUTO 


```{c}
auto info = new FolderArchiveAccountInfo(group);
```

#### AUTO 


```{c}
auto *sync
            = qobject_cast<Akonadi::CollectionAttributesSynchronizationJob *>(job);
```

#### LAMBDA EXPRESSION 


```{c}
[&unifiedBox](const Akonadi::Item &item) {
            return !unifiedBox->sourceCollections().contains(item.storageCollectionId());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::AgentInstance &type : lst) {
        if (type.status() == Akonadi::AgentInstance::Broken) {
            continue;
        }
        const QString typeIdentifier(type.identifier());
        if (PimCommon::Util::isImapResource(typeIdentifier)) {
            OrgKdeAkonadiImapSettingsInterface *iface = PimCommon::Util::createImapSettingsInterface(typeIdentifier);
            if (iface && iface->isValid()) {
                const Akonadi::Collection::Id imapTrashId = iface->trashCollection();
                for (const Akonadi::Collection &collection : collectionList) {
                    const Akonadi::Collection::Id collectionId = collection.id();
                    if (imapTrashId == collectionId) {
                        // Use default trash
                        iface->setTrashCollection(CommonKernel->trashCollectionFolder().id());
                        iface->save();
                        break;
                    }
                }
            }
            delete iface;
        } else if (typeIdentifier.contains(POP3_RESOURCE_IDENTIFIER)) {
            OrgKdeAkonadiPOP3SettingsInterface *iface = MailCommon::Util::createPop3SettingsInterface(typeIdentifier);
            if (iface->isValid()) {
                for (const Akonadi::Collection &collection : std::as_const(collectionList)) {
                    const Akonadi::Collection::Id collectionId = collection.id();
                    if (iface->targetCollection() == collectionId) {
                        // Use default inbox
                        iface->setTargetCollection(CommonKernel->inboxCollectionFolder().id());
                        iface->save();
                        break;
                    }
                }
            }
            delete iface;
        }
    }
```

#### AUTO 


```{c}
auto i = d->mFilters.cbegin(), e = d->mFilters.cend();
```

#### AUTO 


```{c}
auto *encryption = composer->findChild<QLabel *>(QStringLiteral("encryptionindicator"));
```

#### AUTO 


```{c}
auto win = new KMReaderMainWin(msgPart, format, encoding);
```

#### AUTO 


```{c}
auto pop3ColId
```

#### AUTO 


```{c}
auto action = new QAction(i18n("Next &Unread Message"), this);
```

#### LAMBDA EXPRESSION 


```{c}
[checkable, this]() {
        const auto indexes = checkable->selectionModel()->selectedIndexes();
        QSet<qint64> list;
        list.reserve(indexes.count());
        for (const auto &index : indexes) {
            list << index.data(Akonadi::EntityTreeModel::CollectionIdRole).toLongLong();
        }
        mMailbox->setSourceCollections(list);
        accept();
    }
```

#### AUTO 


```{c}
auto fetch = new Akonadi::CollectionFetchJob(mCollection, Akonadi::CollectionFetchJob::Base);
```

#### AUTO 


```{c}
auto fetch = new Akonadi::ItemFetchJob(c, this);
```

#### AUTO 


```{c}
const auto &metaData
```

#### AUTO 


```{c}
auto *info = new ArchiveMailInfo(collectionGroup);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : urlList) {
                        if (url.isValid()) {
                            addAttachment(url, QString());
                        }
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : std::as_const(retrievedList)) {
                if (item.storageCollectionId() <= 0) {
                    continue;
                }
                if (parent.id() != item.storageCollectionId()) {
                    parent = Akonadi::Collection(item.storageCollectionId());
                    undoId = kmkernel->undoStack()->newUndoAction(parent, mDestFolder);
                }
                kmkernel->undoStack()->addMsgToAction(undoId, item);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (MessageComposer::PluginEditor *plugin : lstPlugin) {
        if (plugin->isEnabled()) {
            MessageComposer::PluginEditorInterface *interface = static_cast<MessageComposer::PluginEditorInterface *>(plugin->createInterface(mActionCollection, this));
            interface->setRichTextEditor(mRichTextEditor);
            interface->setParentWidget(mParentWidget);
            interface->setPlugin(plugin);
            connect(interface, &MessageComposer::PluginEditorInterface::emitPluginActivated, this, &KMailPluginEditorManagerInterface::slotPluginActivated);
            connect(interface, &MessageComposer::PluginEditorInterface::message, this, &KMailPluginEditorManagerInterface::message);
            mListPluginInterface.append(interface);
        }
    }
```

#### AUTO 


```{c}
auto t
```

#### AUTO 


```{c}
auto buttonBox = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel | QDialogButtonBox::Help, this);
```

#### AUTO 


```{c}
const auto idx = collectionModel()->match({}, Akonadi::EntityTreeModel::CollectionRole, QVariant::fromValue(col), 1, Qt::MatchExactly);
```

#### RANGE FOR STATEMENT 


```{c}
for (MailFilter *filter : lstFilters) {
        if (!filter->isEmpty() && filter->configureShortcut() && filter->isEnabled()) {
            QString filterName = QStringLiteral("Filter %1").arg(filter->name());
            QString normalizedName = filterName.replace(QLatin1Char(' '), QLatin1Char('_'));
            if (action(normalizedName)) {
                continue;
            }
            KMMetaFilterActionCommand *filterCommand = new KMMetaFilterActionCommand(filter->identifier(), this);
            mFilterCommands.append(filterCommand);
            QString displayText = i18n("Filter %1", filter->name());
            QString icon = filter->icon();
            if (icon.isEmpty()) {
                icon = QStringLiteral("system-run");
            }
            QAction *filterAction = new QAction(QIcon::fromTheme(icon), displayText, actionCollection());
            filterAction->setIconText(filter->toolbarName());

            // The shortcut configuration is done in the filter dialog.
            // The shortcut set in the shortcut dialog would not be saved back to
            // the filter settings correctly.
            actionCollection()->setShortcutsConfigurable(filterAction, false);
            actionCollection()->addAction(normalizedName,
                                          filterAction);
            connect(filterAction, &QAction::triggered,
                    filterCommand, &KMMetaFilterActionCommand::start);
            actionCollection()->setDefaultShortcut(filterAction, filter->shortcut());
            if (!addedSeparator) {
                QAction *a = mApplyFilterActionsMenu->menu()->addSeparator();
                mFilterMenuActions.append(a);
                addedSeparator = true;
            }
            mApplyFilterActionsMenu->menu()->addAction(filterAction);
            mFilterMenuActions.append(filterAction);
            if (filter->configureToolbar()) {
                mFilterTBarActions.append(filterAction);
            }
        }
    }
```

#### AUTO 


```{c}
const auto box = unifiedMailboxForSource(collection.id());
```

#### AUTO 


```{c}
auto win = new KMMainWin;
```

#### AUTO 


```{c}
auto part = mView->model()->data(index, MessageComposer::AttachmentModel::AttachmentPartRole).value<AttachmentPart::Ptr>();
```

#### AUTO 


```{c}
auto *reloadListTimer = new QTimer(this);
```

#### AUTO 


```{c}
auto *job = new OpenComposerJob(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Collection &collection : cols) {
        if (collection.name() == folderName) {
            Q_EMIT collectionIdFound(collection);
            return;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Akonadi::Collection::List &list) {
                for (const auto &col : list) {
                    if (isUnifiedMailbox(col)) {
                        continue;
                    }

                    try {
                        switch (Akonadi::SpecialMailCollections::self()->specialCollectionType(col)) {
                        case Akonadi::SpecialMailCollections::Inbox:
                            mMailboxes.at(Common::InboxBoxId)->addSourceCollection(col.id());
                            break;
                        case Akonadi::SpecialMailCollections::SentMail:
                            mMailboxes.at(Common::SentBoxId)->addSourceCollection(col.id());
                            break;
                        case Akonadi::SpecialMailCollections::Drafts:
                            mMailboxes.at(Common::DraftsBoxId)->addSourceCollection(col.id());
                            break;
                        default:
                            continue;
                        }
                    } catch (const std::out_of_range &) {
                        qCWarning(UNIFIEDMAILBOXAGENT_LOG) << "Failed to find a special unified mailbox for source collection" << col.id();
                        continue;
                    }
                }
            }
```

#### AUTO 


```{c}
auto *fetch = new Akonadi::ItemDeleteJob(mItem, this);
```

#### AUTO 


```{c}
auto *info = new UndoInfo;
```

#### AUTO 


```{c}
auto mimeProxy = new Akonadi::EntityMimeTypeFilterModel(this);
```

#### AUTO 


```{c}
const auto linkedCol = itemLinkedSignalSpy.at(0).at(1).value<Akonadi::Collection>();
```

#### AUTO 


```{c}
auto attribute = collection.attribute<Akonadi::EntityDisplayAttribute>(Akonadi::Collection::AddIfMissing);
```

#### AUTO 


```{c}
auto action = new QAction(QIcon::fromTheme(QStringLiteral("go-jump")), i18n("Jump to Folder..."), this);
```

#### AUTO 


```{c}
auto backupJob = new MailCommon::BackupJob();
```

#### AUTO 


```{c}
auto *handle = new WinObjPenHandle;
```

#### RANGE FOR STATEMENT 


```{c}
for (const MessageComposer::PluginActionType &actionType : interface->actionTypes()) {
                MessageComposer::PluginActionType::Type type = actionType.type();
                QAction *currentAction = actionType.action();
                if (!currentAction) {
                    continue;
                }
                QList<QAction *> lst = mActionHash.value(type);
                if (!lst.isEmpty()) {
                    auto act = new QAction(this);
                    act->setSeparator(true);
                    lst << act << currentAction;
                    mActionHash.insert(type, lst);
                } else {
                    mActionHash.insert(type, QList<QAction *>() << currentAction);
                }
                if (interface->plugin()->hasPopupMenuSupport()) {
                    type = MessageComposer::PluginActionType::PopupMenu;
                    if (currentAction) {
                        lst = mActionHash.value(type);
                        if (!lst.isEmpty()) {
                            auto act = new QAction(this);
                            act->setSeparator(true);
                            lst << act << currentAction;
                            mActionHash.insert(type, lst);
                        } else {
                            mActionHash.insert(type, QList<QAction *>() << currentAction);
                        }
                    }
                }
                if (interface->plugin()->hasToolBarSupport()) {
                    type = MessageComposer::PluginActionType::ToolBar;
                    lst = mActionHash.value(type);
                    if (!lst.isEmpty()) {
                        auto act = new QAction(this);
                        act->setSeparator(true);
                        lst << act << currentAction;
                        mActionHash.insert(type, lst);
                    } else {
                        mActionHash.insert(type, QList<QAction *>() << currentAction);
                    }
                }
            }
```

#### AUTO 


```{c}
const auto key = rec->gpgKey();
```

#### AUTO 


```{c}
auto headersTab = new AppearancePageHeadersTab();
```

#### AUTO 


```{c}
auto *deleteJob = new Akonadi::ItemDeleteJob(context.item(), this);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Akonadi::Collection::List &list) {
        for (const auto &col : list) {
            if (!isUnifiedMailbox(col) || col.parentCollection() == Akonadi::Collection::root()) {
                continue;
            }
            const auto it = mMailboxes.find(col.name());
            if (it == mMailboxes.end()) {
                qCWarning(UNIFIEDMAILBOXAGENT_LOG) << "Failed to find an unified mailbox for source collection" << col.id();
            } else {
                it->second->setCollectionId(col.id());
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &n : lst) {
                                if (n != firstName) {
                                    mPotentialPhisingEmails.append(addr);
                                    break;
                                }
                            }
```

#### AUTO 


```{c}
auto templatesTab = new ComposerPageTemplatesTab();
```

#### AUTO 


```{c}
const auto instance = Akonadi::AgentManager::self()->instance(QStringLiteral("akonadi_newmailnotifier_agent"));
```

#### AUTO 


```{c}
auto msgContent = new KMime::Content;
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Akonadi::Collection &col) {
                ReplayNextOnExit replayNext(mMonitor);

                if (auto box = unifiedMailboxForSource(col.id())) {
                    box->removeSourceCollection(col.id());
                    mMonitor.setCollectionMonitored(col, false);
                    if (box->sourceCollections().isEmpty()) {
                        removeBox(box->id());
                    }
                    saveBoxes();
                    // No need to resync the box collection, the linked Items got removed by Akonadi
                } else {
                    qCWarning(agent_log) << "Received notification about removal of Collection" << col.id() << "which we don't monitor";
                }
           }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : selectedIndexes) {
            AttachmentPart::Ptr part = model()->data(
                                           index, MessageComposer::AttachmentModel::AttachmentPartRole).value<AttachmentPart::Ptr>();
            toRemove.append(part);
        }
```

#### AUTO 


```{c}
auto job = item->property("RemoveDuplicatesJob").value<Akonadi::Job *>();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        itemsRetrievedIncremental({}, {});         // fake incremental retrieval
    }
```

#### AUTO 


```{c}
auto readJob = new ReadPasswordJob(QStringLiteral("imap"), this);
```

#### AUTO 


```{c}
auto part = new KMime::Content;
```

#### AUTO 


```{c}
auto *job = new CreateReplyMessageJob;
```

#### AUTO 


```{c}
auto hrd = mMsg->headerByType("X-KMail-QuotePrefix")
```

#### RANGE FOR STATEMENT 


```{c}
for (MessageComposer::PluginEditorConvertText *plugin : lstPlugin) {
        if (plugin->isEnabled()) {
            MessageComposer::PluginEditorConvertTextInterface *interface = plugin->createInterface(this);
            interface->setRichTextEditor(mRichTextEditor);
            interface->setParentWidget(mParentWidget);
            interface->createAction(mActionCollection);
            interface->setPlugin(plugin);
            mListPluginInterface.append(interface);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&manager, &success](const QString &id, int numSources) {
                                   success = false;
                                   auto boxIt = std::find_if(manager.begin(), manager.end(),
                                                             [&id](const UnifiedMailboxManager::Entry &e) {
                return e.second->id() == id;
            });
                                   QVERIFY(boxIt != manager.end());
                                   const auto &box = boxIt->second;
                                   const auto sourceCollections = box->sourceCollections();
                                   QCOMPARE(sourceCollections.size(), numSources);
                                   for (auto source : sourceCollections) {
                                       auto col = collectionForId(source);
                                       QVERIFY(col);
                                       QVERIFY(col->hasAttribute<Akonadi::SpecialCollectionAttribute>());
                                       QCOMPARE(col->attribute<Akonadi::SpecialCollectionAttribute>()->collectionType(), id.toLatin1());
                                   }
                                   success = true;
                               }
```

#### AUTO 


```{c}
const auto metaDataList = KPluginLoader::findPlugins(QStringLiteral("pim/kcms/summary/"));
```

#### AUTO 


```{c}
auto groupVBoxLayout = new QVBoxLayout();
```

#### AUTO 


```{c}
auto *action = new KActionMenu(menu);
```

#### RANGE FOR STATEMENT 


```{c}
for (KToggleAction *action : qAsConst(mTagActions)) {
        mMessageActions->messageStatusMenu()->removeAction(action);

        // This removes and deletes the action at the same time
        mActionCollection->removeAction(action);
    }
```

#### AUTO 


```{c}
auto action = new QAction(QIcon::fromTheme(QStringLiteral("document-save")), i18n("Save as &Draft"), this);
```

#### AUTO 


```{c}
auto hrd = newMsg->headerByType("X-KMail-Identity-Name")
```

#### AUTO 


```{c}
const auto lst = mComposerBase->recipientsEditor()->lines();
```

#### AUTO 


```{c}
auto autoImageResizeTab = new ComposerPageAutoImageResizeTab();
```

#### AUTO 


```{c}
const auto srcBox = unifiedMailboxForSource(srcCollection.id())
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : qAsConst(items)) {
        ++mCurrentProgressCount;

        if ((mTotalProgressCount > 0) && (mCurrentProgressCount != mTotalProgressCount)) {
            const QString statusMsg = i18n("Filtering message %1 of %2", mCurrentProgressCount, mTotalProgressCount);
            Q_EMIT q->progressMessage(statusMsg);
            Q_EMIT q->percent(mCurrentProgressCount * 100 / mTotalProgressCount);
        } else {
            Q_EMIT q->percent(0);
        }

        const bool filterResult = q->process(listMailFilters, item, needsFullPayload, filterSet);

        if (mCurrentProgressCount == mTotalProgressCount) {
            mTotalProgressCount = 0;
            mCurrentProgressCount = 0;
        }

        if (!filterResult) {
            Q_EMIT q->filteringFailed(item);
            // something went horribly wrong (out of space?)
            // CommonKernel->emergencyExit( i18n( "Unable to process messages: " ) + QString::fromLocal8Bit( strerror( errno ) ) );
        }
    }
```

#### AUTO 


```{c}
auto *groupVBoxLayout = new QVBoxLayout();
```

#### AUTO 


```{c}
auto *job = new CreateNewContactJob(this, this);
```

#### AUTO 


```{c}
auto archiveItem = static_cast<ArchiveMailItem *>(item);
```

#### AUTO 


```{c}
auto urlRequester = dlg.findChild<KUrlRequester *>(QStringLiteral("kurlrequester_vcardpath"));
```

#### AUTO 


```{c}
const auto icon = idx.data(Qt::DecorationRole).value<QIcon>();
```

#### LAMBDA EXPRESSION 


```{c}
[&manager, &success](const QString &id, int numSources) {
                                   success = false;
                                   auto boxIt = std::find_if(manager.begin(), manager.end(),
                                                             [&id](const UnifiedMailboxManager::Entry &e) {
                return e.second->id() == id;
            });
                                   QVERIFY(boxIt != manager.end());
                                   const auto &box = boxIt->second;
                                   const auto sourceCollections = box->sourceCollections();
                                   QCOMPARE(sourceCollections.size(), numSources);
                                   for (auto source : sourceCollections) {
                                       auto col = collectionForId(source);
                                       QVERIFY(col.isValid());
                                       QVERIFY(col.hasAttribute<Akonadi::SpecialCollectionAttribute>());
                                       QCOMPARE(col.attribute<Akonadi::SpecialCollectionAttribute>()->collectionType(), id.toLatin1());
                                   }
                                   success = true;
                               }
```

#### AUTO 


```{c}
auto action = new QAction(QIcon::fromTheme(QStringLiteral("edit-find")), i18n("&Find in Message..."), this);
```

#### AUTO 


```{c}
auto helpMenu = new KHelpMenu(this, aboutData, true);
```

#### AUTO 


```{c}
auto composer = qobject_cast< MessageComposer::Composer * >(job);
```

#### AUTO 


```{c}
auto interface = static_cast<PimCommon::GenericPluginInterface *>(abstractInterface);
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *a : qAsConst(mFilterFolderMenuActions)) {
        actionCollection()->removeAction(a);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { setEnabled(true); }
```

#### AUTO 


```{c}
auto it = std::max_element(d->mFilters.constBegin(), d->mFilters.constEnd(), [id](MailCommon::MailFilter *lhs, MailCommon::MailFilter *rhs) {
                return lhs->requiredPart(id) < rhs->requiredPart(id);
            });
```

#### LAMBDA EXPRESSION 


```{c}
[this, line]() {
        this->slotRecipientLineIconClicked(line);
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr const char s_fdo_notifications_path[] = "/org/freedesktop/Notifications";
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : selectedIndexes) {
            AttachmentPart::Ptr part = model()->data(index, MessageComposer::AttachmentModel::AttachmentPartRole).value<AttachmentPart::Ptr>();
            toRemove.append(part);
        }
```

#### AUTO 


```{c}
const auto verifyBox = [&manager, &success](const QString &id, int numSources) {
            success = false;
            auto boxIt = std::find_if(manager.begin(), manager.end(), [&id](const UnifiedMailboxManager::Entry &e) {
                return e.second->id() == id;
            });
            QVERIFY(boxIt != manager.end());
            const auto &box = boxIt->second;
            const auto sourceCollections = box->sourceCollections();
            QCOMPARE(sourceCollections.size(), numSources);
            for (auto source : sourceCollections) {
                auto col = collectionForId(source);
                QVERIFY(col.isValid());
                QVERIFY(col.hasAttribute<Akonadi::SpecialCollectionAttribute>());
                QCOMPARE(col.attribute<Akonadi::SpecialCollectionAttribute>()->collectionType(), id.toLatin1());
            }
            success = true;
        };
```

#### AUTO 


```{c}
auto mainWin = qobject_cast<KMainWindow *>(window());
```

#### RANGE FOR STATEMENT 


```{c}
for (KMime::Content *attach : std::as_const(fwdMsg.second)) {
        mWin->addAttach(attach);
        delete attach;
    }
```

#### AUTO 


```{c}
auto l = new QHBoxLayout(this);
```

#### LAMBDA EXPRESSION 


```{c}
[=](const Akonadi::Item::List &items) {
            m_filterManager->applyFilters(items, static_cast<FilterManager::FilterSet>(filterSet));
        }
```

#### AUTO 


```{c}
auto *messageIdSuffixValidator
        = new QRegularExpressionValidator(QRegularExpression(QStringLiteral("[a-zA-Z0-9+-]+(?:\\.[a-zA-Z0-9+-]+)*")), this);
```

#### AUTO 


```{c}
auto *expandJob = qobject_cast<Akonadi::ContactGroupExpandJob *>(job);
```

#### AUTO 


```{c}
auto Status = new QLabel(i18n("Status:"), this);
```

#### AUTO 


```{c}
auto *act = new QAction(this);
```

#### AUTO 


```{c}
const auto col = CommonKernel->collectionFromId(CommonKernel->outboxCollectionFolder().id());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &index : indexes) {
            mMailbox->addSourceCollection(index.data(Akonadi::EntityTreeModel::CollectionIdRole).toLongLong());
        }
```

#### AUTO 


```{c}
auto *msg = new KMime::Message;
```

#### AUTO 


```{c}
auto messageTagTab = new AppearancePageMessageTagTab();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Collection &collection : collectionList) {
                    const Akonadi::Collection::Id collectionId = collection.id();
                    if (imapTrashId == collectionId) {
                        //Use default trash
                        iface->setTrashCollection(CommonKernel->trashCollectionFolder().id());
                        iface->save();
                        break;
                    }
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &str) {
                if (!str.isEmpty()) {
                    if (mComposerBase->subject().isEmpty()) { // Add subject only if we don't have subject
                        mEdtSubject->setText(str);
                    }
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Akonadi::Item &item, const Akonadi::Collection &collection) {
        ReplayNextOnExit replayNext(mMonitor);

        qCDebug(UNIFIEDMAILBOXAGENT_LOG) << "Item" << item.id() << "added to collection" << collection.id();
        const auto box = unifiedMailboxForSource(collection.id());
        if (!box) {
            qCWarning(UNIFIEDMAILBOXAGENT_LOG) << "Failed to find unified mailbox for source collection " << collection.id();
            return;
        }

        if (!box->collectionId()) {
            qCWarning(UNIFIEDMAILBOXAGENT_LOG) << "Missing box->collection mapping for unified mailbox" << box->id();
            return;
        }

        new Akonadi::LinkJob(Akonadi::Collection{box->collectionId().value()}, {item}, this);
    }
```

#### AUTO 


```{c}
auto action = new QAction(QIcon::fromTheme(QStringLiteral("dialog-filters")), i18n("Configure &Filters..."), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (KToggleAction *act : customToolsWidgetActionList) {
            QList<QAction *> lst{act};
            if (hashActions.contains(actionlistname)) {
                lst = hashActions.value(actionlistname) + lst;
                hashActions.remove(actionlistname);
            }
            hashActions.insert(actionlistname, lst);
        }
```

#### AUTO 


```{c}
auto *useGlobalSetting = menu.findChild<KToggleAction *>(QStringLiteral("use-global-setting-action"));
```

#### AUTO 


```{c}
auto *systrayBoxlayout = new QVBoxLayout(systrayBox);
```

#### AUTO 


```{c}
auto buttonGroup = dlg.findChild<QButtonGroup *>(QStringLiteral("buttongroup"));
```

#### AUTO 


```{c}
auto newItem = new TagListWidgetItem(QIcon::fromTheme(tag->iconName), tag->tagName, mTagListBox);
```

#### AUTO 


```{c}
auto *generalTab = new GeneralTab();
```

#### AUTO 


```{c}
auto createCol = new Akonadi::CollectionCreateJob(col);
```

#### AUTO 


```{c}
const auto mailbox = item->data().value<UnifiedMailbox *>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &serNumStr : serNums) {
                items << Akonadi::Item(serNumStr.toLongLong());
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) { d->itemsFetchJobForFilterDone(job); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : selectedIndexes) {
            AttachmentPart::Ptr part = model()->data(
                index, MessageComposer::AttachmentModel::AttachmentPartRole).value<AttachmentPart::Ptr>();
            toRemove.append(part);
        }
```

#### AUTO 


```{c}
auto button = new QRadioButton(i18n("Always show KMail in system tray"), mSystemTrayGroupBox);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : selectedRows) {
        AttachmentPart::Ptr part = mView->model()->data(
                                       index, MessageComposer::AttachmentModel::AttachmentPartRole).value<AttachmentPart::Ptr>();
        selectedParts.append(part);
    }
```

#### AUTO 


```{c}
auto expandJob = qobject_cast<Akonadi::ContactGroupExpandJob *>(job);
```

#### AUTO 


```{c}
auto mailbox = createUnifiedMailbox(QStringLiteral("Test1"), QStringLiteral("Test 1"), {QStringLiteral("res1_foo"), QStringLiteral("res2_foo")});
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &custom : customs) {
            if (custom.contains(QStringLiteral("MailPreferedFormatting"))) {
                const QString value = mSearchedAddress.custom(QStringLiteral("KADDRESSBOOK"), QStringLiteral("MailPreferedFormatting"));
                mViewAsHtml->setChecked(value == QLatin1String("HTML"));
            } else if (custom.contains(QStringLiteral("MailAllowToRemoteContent"))) {
                const QString value = mSearchedAddress.custom(QStringLiteral("KADDRESSBOOK"), QStringLiteral("MailAllowToRemoteContent"));
                mLoadExternalReference->setChecked((value == QLatin1String("TRUE")));
            }
        }
```

#### AUTO 


```{c}
const auto service = Akonadi::ServerManager::agentServiceName(Akonadi::ServerManager::Resource, identifier());
```

#### RANGE FOR STATEMENT 


```{c}
for (KMainWindow *window : lst) {
        if (::qobject_cast<KMMainWin *>(window)
            || ::qobject_cast<KMail::SecondaryWindow *>(window)) {
            // close and delete the window
            window->setAttribute(Qt::WA_DeleteOnClose);
            window->close();
        }
    }
```

#### AUTO 


```{c}
auto *job = new Akonadi::RemoveDuplicatesJob(collections, this);
```

#### AUTO 


```{c}
auto *textLabel = findChild<QLabel *>(QStringLiteral("textLabel1"));
```

#### AUTO 


```{c}
auto *command = new KMPrintCommand(this, commandInfo);
```

#### AUTO 


```{c}
auto job = new CreateForwardMessageJob;
```

#### AUTO 


```{c}
auto layout = new QVBoxLayout(group);
```

#### AUTO 


```{c}
auto propsIface = new OrgFreedesktopDBusPropertiesInterface(QString::fromLatin1(s_fdo_notifications_service),
                                                                    QString::fromLatin1(s_fdo_notifications_path),
                                                                    dbusConn,
                                                                    this);
```

#### AUTO 


```{c}
const auto modifyMailBox = [this, view]() {
                                   const auto indexes = view->selectionModel()->selectedIndexes();
                                   if (!indexes.isEmpty()) {
                                       auto item = mBoxModel->itemFromIndex(indexes[0]);
                                       auto mailbox = item->data().value<UnifiedMailbox *>();
                                       auto editor = new UnifiedMailboxEditor(mailbox, mConfig, this);
                                       if (editor->exec()) {
                                           item->setText(mailbox->name());
                                           item->setIcon(QIcon::fromTheme(mailbox->icon()));
                                       }
                                       delete editor;
                                       mBoxManager.saveBoxes();
                                   }
                               };
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &name) {
                mMailbox->setName(name.trimmed());
            }
```

#### AUTO 


```{c}
auto hbox = new QHBoxLayout;
```

#### AUTO 


```{c}
auto *layout = new QVBoxLayout(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::AgentInstance &type : lst) {
        const QString identifier = type.identifier();
        if (identifier.startsWith(QLatin1String("akonadi_pop3_resource"))) {
            numberOfPop3++;
        } else if (identifier.startsWith(QLatin1String("akonadi_imap_resource"))) {
            numberOfImap++;
        } else if (identifier.startsWith(QLatin1String("akonadi_kolab_resource"))) {
            numberOfKolab++;
        } else if (identifier.startsWith(QLatin1String("akonadi_ews_resource"))) {
            numberOfEws++;
        } else if (identifier.startsWith(QLatin1String("akonadi_maildir_resource"))) {
            numberOfMaildir++;
        } else if (identifier.startsWith(QLatin1String("akonadi_mbox_resource"))) {
            numberOfMbox++;
        }
        // TODO add more
    }
```

#### AUTO 


```{c}
auto configDelegate = new ConfigAgentDelegate(mAccountsReceiving.mAccountsReceiving->view());
```

#### AUTO 


```{c}
const auto id = colId.toLongLong();
```

#### AUTO 


```{c}
auto layoutTab = new AppearancePageLayoutTab();
```

#### LAMBDA EXPRESSION 


```{c}
[this, view]() {
                const auto indexes = view->selectionModel()->selectedIndexes();
                if (!indexes.isEmpty()) {
                    auto item = mBoxModel->itemFromIndex(indexes[0]);
                    const auto mailbox = item->data().value<UnifiedMailbox*>();
                    if (KMessageBox::warningYesNo(
                            this, i18n("Do you really want to remove unified mailbox <b>%1</b>?", mailbox->name()),
                            i18n("Really Remove?"), KStandardGuiItem::remove(), KStandardGuiItem::cancel()) == KMessageBox::Yes)
                    {
                        mBoxModel->removeRow(item->row());
                        mBoxManager.removeBox(mailbox->id());
                    }
                }
            }
```

#### AUTO 


```{c}
auto *attachmentModel = new MessageComposer::AttachmentModel(this);
```

#### AUTO 


```{c}
auto *inviteTab = new InviteTab();
```

#### AUTO 


```{c}
auto fetchCmd = qobject_cast<KMFetchMessageCommand *>(command);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &filterId : listFilters) {
            for (MailCommon::MailFilter *filter : std::as_const(mFilters)) {
                if (filter->identifier() == filterId) {
                    listMailFilters << filter;
                    break;
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto source : qAsConst(mSources)) {
                manager->mMonitor.setCollectionMonitored(Akonadi::Collection{source});
                manager->mSourceToBoxMap.insert({source, this});
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) {
        d->itemFetchJobForFilterDone(job);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : qAsConst(retrievedList)) {
                if (item.storageCollectionId() <= 0) {
                    continue;
                }
                if (parent.id() != item.storageCollectionId()) {
                    parent = Akonadi::Collection(item.storageCollectionId());
                    undoId = kmkernel->undoStack()->newUndoAction(parent, mDestFolder);
                }
                kmkernel->undoStack()->addMsgToAction(undoId, item);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (FolderArchiveAccountInfo *info : qAsConst(mListAccountInfo)) {
        if (info->archiveTopLevel() == collection.id()) {
            info->setArchiveTopLevel(-1);
            KConfigGroup group = config.group(FolderArchive::FolderArchiveUtil::groupConfigPattern() + info->instanceName());
            info->writeConfig(group);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : lst) {
        const Akonadi::Item item = index.data(Akonadi::ItemModel::ItemRole).value<Akonadi::Item>();
        if (item.isValid()) {
            messages.append(item);
        }
    }
```

#### AUTO 


```{c}
auto *h = new KMime::Headers::Generic("X-KMail-Identity");
```

#### AUTO 


```{c}
auto *job = new Akonadi::ItemModifyJob(mItem);
```

#### AUTO 


```{c}
auto job = new Akonadi::CollectionFetchJob(mCurrentCollection, Akonadi::CollectionFetchJob::FirstLevel, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &metaData : metaDataList) {
#if KCMUTILS_VERSION >= QT_VERSION_CHECK(5, 84, 0)
        dlg->addModule(metaData);
#else
        dlg->addModule(metaData.pluginId());
#endif
    }
```

#### AUTO 


```{c}
auto *tnef = new KTNEFMain();
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *a : std::as_const(oldActions)) {
            addAction(a);
        }
```

#### AUTO 


```{c}
auto command = new KMUseTemplateCommand(this, msg);
```

#### RANGE FOR STATEMENT 


```{c}
for (MailCommon::MailFilter *filter : qAsConst(mFilters)) {
                if (filter->identifier() == filterId) {
                    listMailFilters << filter;
                    break;
                }
            }
```

#### AUTO 


```{c}
auto job = new PotentialPhishingEmailJob(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const PimCommon::PluginUtilData &data : qAsConst(mPluginUtilDataList)) {
                if (data.mIdentifier == identifier) {
                    QDBusInterface interface(QLatin1String("org.freedesktop.Akonadi.Agent.") + data.mExtraInfo.at(0), data.mExtraInfo.at(1));
                    if (interface.isValid()) {
                        interface.call(QStringLiteral("showConfigureDialog"), (qlonglong)winId());
                    } else {
                        qCDebug(KMAIL_LOG) << " interface does not exist ";
                    }
                    break;
                }
            }
```

#### CONST EXPRESSION 


```{c}
static constexpr auto SpecialCollectionDrafts = "drafts";
```

#### AUTO 


```{c}
auto *createJob = new Akonadi::ItemCreateJob(item, mCollection);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : std::as_const(*trashIt)) {
                if (item.storageCollectionId() <= 0) {
                    continue;
                }
                if (parent.id() != item.storageCollectionId()) {
                    parent = Akonadi::Collection(item.storageCollectionId());
                    undoId = kmkernel->undoStack()->newUndoAction(parent, trash);
                }
                kmkernel->undoStack()->addMsgToAction(undoId, item);
            }
```

#### AUTO 


```{c}
auto *page = new MiscPage(parent);
```

#### AUTO 


```{c}
auto *menuCustom = mMsgActions->customTemplatesMenu()
```

#### AUTO 


```{c}
auto *radio = new QRadioButton(buttonLabel, hbox);
```

#### AUTO 


```{c}
auto *autoImageResizeTab = new AutoImageResizeTab();
```

#### AUTO 


```{c}
auto action = new QAction(QIcon::fromTheme(QStringLiteral("document-import")), i18n("&Import Messages..."), this);
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
            slotApplyFiltersOnFolder(/* recursive */ true);
        }
```

#### AUTO 


```{c}
const auto sourceCol = mailbox->sourceCollections().values().first();
```

#### AUTO 


```{c}
auto job = new Akonadi::ItemCreateJob(mMsg, collection, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *a : lstAct) {
        menu->addSeparator();
        menu->addAction(a);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &source : qAsConst(mSources)) {
                mManager->mMonitor.setCollectionMonitored(Akonadi::Collection {source}, false);
                mManager->mSourceToBoxMap.erase(source);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        auto mailbox = std::make_unique<UnifiedMailbox>();
        auto editor = new UnifiedMailboxEditor(mailbox.get(), mConfig, this);
        if (editor->exec()) {
            mailbox->setId(mailbox->name());         // assign ID
            addBox(mailbox.get());
            mBoxManager.insertBox(std::move(mailbox));
        }
    }
```

#### AUTO 


```{c}
auto *groupLayout = new QGridLayout(mGroupWidget);
```

#### AUTO 


```{c}
const auto mailActions = {
        Akonadi::StandardMailActionManager::MarkAllMailAsRead,
        Akonadi::StandardMailActionManager::MarkMailAsRead,
        Akonadi::StandardMailActionManager::MarkMailAsUnread,
        Akonadi::StandardMailActionManager::MarkMailAsImportant,
        Akonadi::StandardMailActionManager::MarkMailAsActionItem
    };
```

#### AUTO 


```{c}
auto *command = new KMMoveCommand(col, mListItem, -1);
```

#### AUTO 


```{c}
auto win = ::qobject_cast<KMail::Composer *>(window)
```

#### AUTO 


```{c}
auto fjob = qobject_cast<Akonadi::ItemFetchJob *>(job);
```

#### AUTO 


```{c}
auto *job = new Akonadi::RemoveDuplicatesJob(lst, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : std::as_const(mMsgList)) {
        if (!item.isValid()) {
            Q_EMIT messagesTransfered(Failed);
            return;
        }
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr auto SpecialCollectionSentMail = "send-mail";
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &s : list) {
            new Attachment(this, s);
        }
```

#### AUTO 


```{c}
auto hrd = mSettings.msg->headerByType("X-KMail-Identity")
```

#### AUTO 


```{c}
auto agent = Akonadi::AgentManager::self()->instance(QStringLiteral("akonadi_sendlater_agent"));
```

#### AUTO 


```{c}
auto *modifyJob = new Akonadi::ItemModifyJob(item, this);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Akonadi::Collection::List &cols) {
                for (const auto &col : cols) {
                    new Akonadi::CollectionDeleteJob(col, this);
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (MessageComposer::PluginEditorConvertTextInterface *interface : qAsConst(mListPluginInterface)) {
            for (const MessageComposer::PluginActionType &actionType : interface->actionTypes()) {
                MessageComposer::PluginActionType::Type type = actionType.type();
                QAction *currentAction = actionType.action();
                if (!currentAction) {
                    continue;
                }
                QList<QAction *> lst = mActionHash.value(type);
                if (!lst.isEmpty()) {
                    QAction *act = new QAction(this);
                    act->setSeparator(true);
                    lst << act << currentAction;
                    mActionHash.insert(type, lst);
                } else {
                    mActionHash.insert(type, QList<QAction *>() << currentAction);
                }
                if (interface->plugin()->hasPopupMenuSupport()) {
                    type = MessageComposer::PluginActionType::PopupMenu;
                    if (currentAction) {
                        QList<QAction *> lst = mActionHash.value(type);
                        if (!lst.isEmpty()) {
                            QAction *act = new QAction(this);
                            act->setSeparator(true);
                            lst << act << currentAction;
                            mActionHash.insert(type, lst);
                        } else {
                            mActionHash.insert(type, QList<QAction *>() << currentAction);
                        }
                    }
                }
                if (interface->plugin()->hasToolBarSupport()) {
                    type = MessageComposer::PluginActionType::ToolBar;
                    QList<QAction *> lst = mActionHash.value(type);
                    if (!lst.isEmpty()) {
                        QAction *act = new QAction(this);
                        act->setSeparator(true);
                        lst << act << currentAction;
                        mActionHash.insert(type, lst);
                    } else {
                        mActionHash.insert(type, QList<QAction *>() << currentAction);
                    }
                }
            }
        }
```

#### CONST EXPRESSION 


```{c}
static constexpr const char DialogGroup[] = "FollowUpReminderNoAnswerDialog";
```

#### AUTO 


```{c}
const auto msg = context.item().payload<KMime::Message::Ptr>();
```

#### AUTO 


```{c}
auto image = qvariant_cast<QImage>(source->imageData());
```

#### AUTO 


```{c}
const auto ident = identity();
```

#### AUTO 


```{c}
auto generalTab = new ReadingTab();
```

#### AUTO 


```{c}
auto favoriteFoldersViewIconsRadio = new QRadioButton(i18n("As icons"), mFavoriteFoldersViewGroupBox);
```

#### AUTO 


```{c}
auto *action = qobject_cast<QAction *>(sender());
```

#### AUTO 


```{c}
auto header = new KMime::Headers::Generic("X-KMail-Templates");
```

#### AUTO 


```{c}
auto *folderTab = new FolderTab();
```

#### RANGE FOR STATEMENT 


```{c}
for (KMainWindow *window : lst) {
        if (::qobject_cast<KMMainWin *>(window)) {
            return window;
        }
    }
```

#### AUTO 


```{c}
auto command = new KMTrashMsgCommand(mCurrentCollection, messageView()->viewer()->messageItem(), -1);
```

#### AUTO 


```{c}
auto *sync
                = new Akonadi::CollectionAttributesSynchronizationJob(col);
```

#### AUTO 


```{c}
auto job = new CheckIndexingJob(mIndexedItems, this);
```

#### AUTO 


```{c}
auto job = new Akonadi::CollectionModifyJob(mFolder, this);
```

#### LAMBDA EXPRESSION 


```{c}
[this, view]() {
                                   const auto indexes = view->selectionModel()->selectedIndexes();
                                   if (!indexes.isEmpty()) {
                                       auto item = mBoxModel->itemFromIndex(indexes[0]);
                                       auto mailbox = item->data().value<UnifiedMailbox *>();
                                       auto editor = new UnifiedMailboxEditor(mailbox, mConfig, this);
                                       if (editor->exec()) {
                                           item->setText(mailbox->name());
                                           item->setIcon(QIcon::fromTheme(mailbox->icon()));
                                       }
                                       delete editor;
                                       mBoxManager.saveBoxes();
                                   }
                               }
```

#### AUTO 


```{c}
const auto col = CommonKernel->collectionFromId(item.parentCollection().id());
```

#### AUTO 


```{c}
auto fetch = new Akonadi::CollectionFetchJob(Akonadi::Collection::root(), Akonadi::CollectionFetchJob::Recursive, this);
```

#### AUTO 


```{c}
auto *colorsTab = new ColorsTab();
```

#### AUTO 


```{c}
auto job = new RemoveDuplicateMessageInFolderAndSubFolderJob(this, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &arg : lstPositionalArguments) {
            if (arg.startsWith(QLatin1String("mailto:"), Qt::CaseInsensitive)) {
                const QUrl urlDecoded(QUrl::fromPercentEncoding(arg.toUtf8()));
                const QVector<QPair<QString, QString>> values = MessageCore::StringUtil::parseMailtoUrl(urlDecoded);
                QString previousKey;
                for (int i = 0; i < values.count(); ++i) {
                    const QPair<QString, QString> element = values.at(i);
                    const QString key = element.first.toLower();
                    if (key == QLatin1String("to")) {
                        if (!element.second.isEmpty()) {
                            to += element.second + QStringLiteral(", ");
                        }
                        previousKey.clear();
                    } else if (key == QLatin1String("cc")) {
                        if (!element.second.isEmpty()) {
                            cc += element.second + QStringLiteral(", ");
                        }
                        previousKey.clear();
                    } else if (key == QLatin1String("bcc")) {
                        if (!element.second.isEmpty()) {
                            bcc += element.second + QStringLiteral(", ");
                        }
                        previousKey.clear();
                    } else if (key == QLatin1String("subject")) {
                        subj = element.second;
                        previousKey.clear();
                    } else if (key == QLatin1String("body")) {
                        body = element.second;
                        previousKey = key;
                    } else if (key == QLatin1String("in-reply-to")) {
                        inReplyTo = element.second;
                        previousKey.clear();
                    } else if (key == QLatin1String("attachment") || key == QLatin1String("attach")) {
                        if (!element.second.isEmpty()) {
                            attachURLs << makeAbsoluteUrl(element.second, workingDir);
                        }
                        previousKey.clear();
                    } else {
                        qCWarning(KMAIL_LOG) << "unknown key" << key;
                        // Workaround: https://bugs.kde.org/show_bug.cgi?id=390939
                        // QMap<QString, QString> parseMailtoUrl(const QUrl &url) parses correctly url
                        // But if we have a "&" unknown key we lost it.
                        if (previousKey == QLatin1String("body")) {
                            body += QLatin1Char('&') + key + QLatin1Char('=') + element.second;
                        }
                        // Don't clear previous key.
                    }
                }
            } else {
                QUrl url(arg);
                if (url.isValid() && !url.scheme().isEmpty()) {
                    attachURLs += url;
                } else {
                    to += arg + QStringLiteral(", ");
                }
            }
            mailto = true;
        }
```

#### AUTO 


```{c}
auto composer = new ::MessageComposer::Composer;
```

#### AUTO 


```{c}
auto info = new FollowUpReminderInfo(group);
```

#### AUTO 


```{c}
auto backupJob = new MailCommon::BackupJob(mParentWidget);
```

#### AUTO 


```{c}
auto info = new ArchiveMailInfo(collectionGroup);
```

#### AUTO 


```{c}
auto job = new Akonadi::ItemDeleteJob(Akonadi::Item(mListItems.at(mIndex)), this);
```

#### AUTO 


```{c}
auto tab = qobject_cast<ConfigModuleTab *>(mTabWidget->currentWidget());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &str : dialogList) {
        settingsrc->deleteGroup(str);
    }
```

#### AUTO 


```{c}
auto parser = new TemplateParser::TemplateParserJob(mMsg, TemplateParser::TemplateParserJob::NewMessage, this);
```

#### AUTO 


```{c}
auto systrayBox = new QGroupBox(i18n("System Tray"), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : lst) {
        const auto item = index.data(Akonadi::EntityTreeModel::ItemRole).value<Akonadi::Item>();
        if (item.isValid()) {
            messages.append(item);
        }
    }
```

#### AUTO 


```{c}
auto *callWatcher = new QDBusPendingCallWatcher(listNamesCall, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &argument : std::as_const(args)) {
        if (argument == QLatin1String("--attach")) {
            addAttachmentAttribute = true;
        } else {
            if (argument.startsWith(QLatin1String("--"))) {
                addAttachmentAttribute = false;
            }
            if (argument.contains(QLatin1Char('@')) || argument.startsWith(QLatin1String("mailto:"))) { // address mustn't be trade as a attachment
                addAttachmentAttribute = false;
            }
            if (addAttachmentAttribute) {
                newargs.append(QStringLiteral("--attach"));
                newargs.append(argument);
            } else {
                newargs.append(argument);
            }
        }
    }
```

#### AUTO 


```{c}
auto *job = new CheckIndexingJob(mIndexedItems, this);
```

#### AUTO 


```{c}
const auto draftsBoxCol = createCollection(Common::DraftsBoxId, parentCol.value(), deleter);
```

#### AUTO 


```{c}
auto group = new QGroupBox(i18n("Repl&y Subject Prefixes"), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (MessageStatus status : statusList) {
            if (status.hasAttachment()) {
                pattern.append(SearchRule::createInstance(searchStringVal, SearchRule::FuncHasAttachment, searchString));
                status.setHasAttachment(false);
            }
            if (!status.isOfUnknownStatus()) {
                pattern.append(SearchRule::Ptr(new SearchRuleStatus(status)));
            }
        }
```

#### AUTO 


```{c}
auto session = new Akonadi::Session("AddEmailToExistingContactDialog", this);
```

#### AUTO 


```{c}
auto groupGridLayout = new QGridLayout(groupBoxWrapper);
```

#### AUTO 


```{c}
const auto service = Akonadi::ServerManager::self()->agentServiceName(Akonadi::ServerManager::Agent, QStringLiteral("akonadi_mailfilter_agent"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : urlList) {
                    AttachmentInfo info;
                    info.url = url;
                    infoList.append(info);
                }
```

#### AUTO 


```{c}
auto fetchJob = new Akonadi::CollectionFetchJob(mTopLevelCollection, Akonadi::CollectionFetchJob::Recursive, this);
```

#### AUTO 


```{c}
auto *lay = new QHBoxLayout(mWidget);
```

#### AUTO 


```{c}
auto *job = new MessageComposer::InsertTextFileJob(mComposerBase->editor(), u);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Tag &tag : qAsConst(mTags)) {
        if (!tag.isValid()) {
            auto createJob = new Akonadi::TagCreateJob(tag, this);
            connect(createJob, &Akonadi::TagCreateJob::result, this, &KMSetTagCommand::slotModifyItemDone);
        } else {
            mCreatedTags << tag;
        }
    }
```

#### AUTO 


```{c}
const auto im = mKernel->identityManager();
```

#### AUTO 


```{c}
auto *layoutTab = new LayoutTab();
```

#### AUTO 


```{c}
auto *urlRequester = dlg.findChild<KUrlRequester *>(QStringLiteral("kurlrequester_vcardpath"));
```

#### AUTO 


```{c}
auto boxIt = std::find_if(manager.begin(), manager.end(),
                            [&id](const UnifiedMailboxManager::Entry &e) {
                                return e.second->id() == id;
                            });
```

#### AUTO 


```{c}
auto *infowidget = dlg.findChild<FollowUpReminderInfoWidget *>(QStringLiteral("FollowUpReminderInfoWidget"));
```

#### AUTO 


```{c}
auto command = new KMRedirectCommand(this, currentItem);
```

#### AUTO 


```{c}
auto tlay = new QHBoxLayout();
```

#### AUTO 


```{c}
auto h = new QHBoxLayout;
```

#### LAMBDA EXPRESSION 


```{c}
[this, unifiedBox, c](const Akonadi::Item::List &items) {
        Akonadi::Item::List toUnlink;
        std::copy_if(items.cbegin(), items.cend(), std::back_inserter(toUnlink),
                     [&unifiedBox](const Akonadi::Item &item) {
            return !unifiedBox->sourceCollections().contains(item.storageCollectionId());
        });
        if (!toUnlink.isEmpty()) {
            new Akonadi::UnlinkJob(c, toUnlink, this);
        }
    }
```

#### AUTO 


```{c}
auto *lab = new ServerLabel(server);
```

#### AUTO 


```{c}
auto *job = new KMComposerUpdateTemplateJob;
```

#### AUTO 


```{c}
auto *iconHLayout = new QHBoxLayout();
```

#### RANGE FOR STATEMENT 


```{c}
for (PluginItem *item : qAsConst(mAgentPluginsItems)) {
        for (const PimCommon::PluginUtilData &data : qAsConst(mPluginUtilDataList)) {
            if (item->mIdentifier == data.mIdentifier) {
                changeAgentActiveState(data.mExtraInfo.at(0), data.mExtraInfo.at(1), item->checkState(0) == Qt::Checked);
                break;
            }
        }
    }
```

#### AUTO 


```{c}
auto job = new CreateFollowupReminderOnExistingMessageJob(this);
```

#### AUTO 


```{c}
auto readerBoxLayout = new QVBoxLayout(readerBox);
```

#### AUTO 


```{c}
auto v = new QVBoxLayout;
```

#### AUTO 


```{c}
auto item = new PluginItem(*it, mPluginView);
```

#### RANGE FOR STATEMENT 


```{c}
for (MessageComposer::SendLaterInfo *info : std::as_const(mListSendLaterInfo)) {
        if (info->itemId() == id) {
            return info;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) { d->itemFetchJobForFilterDone(job);}
```

#### AUTO 


```{c}
auto *topLayout = new QVBoxLayout(canvas);
```

#### AUTO 


```{c}
auto job = new UndoSendCreateJob(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QFileInfo &file : autoSaveFiles) {
        // Disregard the '.' and '..' folders
        const QString filename = file.fileName();
        if (filename == QLatin1String(".")
            || filename == QLatin1String("..")
            || file.isDir()) {
            continue;
        }
        qCDebug(KMAIL_LOG) << "Opening autosave file:" << file.absoluteFilePath();
        QFile autoSaveFile(file.absoluteFilePath());
        if (autoSaveFile.open(QIODevice::ReadOnly)) {
            const KMime::Message::Ptr autoSaveMessage(new KMime::Message());
            const QByteArray msgData = autoSaveFile.readAll();
            autoSaveMessage->setContent(msgData);
            autoSaveMessage->parse();

            // Show the a new composer dialog for the message
            KMail::Composer *autoSaveWin = KMail::makeComposer();
            autoSaveWin->setMessage(autoSaveMessage, false, false, false);
            autoSaveWin->setAutoSaveFileName(filename);
            autoSaveWin->show();
            autoSaveFile.close();
        } else {
            KMessageBox::sorry(nullptr, i18n("Failed to open autosave file at %1.\nReason: %2",
                                             file.absoluteFilePath(), autoSaveFile.errorString()),
                               i18n("Opening Autosave File Failed"));
        }
    }
```

#### AUTO 


```{c}
auto listboxgrid = new QHBoxLayout();
```

#### AUTO 


```{c}
auto fetchJob = qobject_cast<Akonadi::CollectionFetchJob *>(job);
```

#### AUTO 


```{c}
auto sent = std::make_unique<UnifiedMailbox>();
```

#### AUTO 


```{c}
const auto draftsSourceCol = collectionForRid(QStringLiteral("res1_drafts"));
```

#### AUTO 


```{c}
const auto actionTypes = interface->actionTypes();
```

#### AUTO 


```{c}
auto folderTab = new MiscPageFolderTab();
```

#### AUTO 


```{c}
const auto id = act->data().value<Akonadi::Collection::Id>();
```

#### AUTO 


```{c}
auto notify = new KNotification(QStringLiteral("mailfilterlogenabled"));
```

#### RANGE FOR STATEMENT 


```{c}
for (MessageComposer::SendLaterInfo *info : qAsConst(mListSendLaterInfo)) {
            if (!infoStr.isEmpty()) {
                infoStr += QLatin1Char('\n');
            }
            infoStr += infoToStr(info);
        }
```

#### AUTO 


```{c}
auto *job = new DndFromArkJob(this);
```

#### AUTO 


```{c}
auto *topLayout = new QVBoxLayout(this);
```

#### AUTO 


```{c}
auto *interface = static_cast<MessageComposer::PluginEditorInterface *>(plugin->createInterface(this));
```

#### AUTO 


```{c}
auto *fetch = new Akonadi::ItemFetchJob(item, this);
```

#### AUTO 


```{c}
auto *job = new Akonadi::ItemMoveJob(*trashIt, trash, this);
```

#### AUTO 


```{c}
auto *command = new KMTrashMsgCommand(mCurrentCollection, select, ref);
```

#### AUTO 


```{c}
auto ftw = new MailCommon::FolderTreeWidget(nullptr, nullptr,
            MailCommon::FolderTreeWidget::TreeViewOptions(MailCommon::FolderTreeWidget::UseDistinctSelectionModel |
                                                          MailCommon::FolderTreeWidget::HideStatistics));
```

#### AUTO 


```{c}
auto lab = new QLabel(i18n("Select email to put in whitelist:"), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Collection &collection : collectionList) {
                    const Akonadi::Collection::Id collectionId = collection.id();
                    if (imapTrashId == collectionId) {
                        // Use default trash
                        iface->setTrashCollection(CommonKernel->trashCollectionFolder().id());
                        iface->save();
                        break;
                    }
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this, unifiedBox, c](const Akonadi::Item::List &items) {
        Akonadi::Item::List toUnlink;
        std::copy_if(items.cbegin(), items.cend(), std::back_inserter(toUnlink), [&unifiedBox](const Akonadi::Item &item) {
            return !unifiedBox->sourceCollections().contains(item.storageCollectionId());
        });
        if (!toUnlink.isEmpty()) {
            new Akonadi::UnlinkJob(c, toUnlink, this);
        }
    }
```

#### AUTO 


```{c}
auto move = new Akonadi::ItemMoveJob(item, destinationCol.value(), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &col : list) {
            if (!isUnifiedMailbox(col) || col.parentCollection() == Akonadi::Collection::root()) {
                continue;
            }
            const auto it = mMailboxes.find(col.name());
            if (it == mMailboxes.end()) {
                qCWarning(UNIFIEDMAILBOXAGENT_LOG) << "Failed to find an unified mailbox for source collection" << col.id();
            } else {
                it->second->setCollectionId(col.id());
            }
        }
```

#### AUTO 


```{c}
const auto cb = [this, finishedCb = std::move(finishedCb)]() {
                        qCDebug(UNIFIEDMAILBOXAGENT_LOG) << "Finished callback: enabling change recorder";
                        // Only now start processing changes from change recorder
                        connect(&mMonitor, &Akonadi::ChangeRecorder::changesAdded, &mMonitor, &Akonadi::ChangeRecorder::replayNext, Qt::QueuedConnection);
                        // And start replaying any potentially pending notification
                        QTimer::singleShot(0, &mMonitor, &Akonadi::ChangeRecorder::replayNext);

                        if (finishedCb) {
                            finishedCb();
                        }
                    };
```

#### AUTO 


```{c}
const auto destinationCol = collectionForRid(QStringLiteral("res1_foo"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : items) {
        if (!mCustomTemplate.isEmpty()) {
            parser.process(mCustomTemplate, MessageCore::Util::message(item));
        } else {
            parser.processWithIdentity(uoid, MessageCore::Util::message(item));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (PluginItem *item : std::as_const(mAgentPluginsItems)) {
        for (const PimCommon::PluginUtilData &data : std::as_const(mPluginUtilDataList)) {
            if (item->mIdentifier == data.mIdentifier) {
                changeAgentActiveState(data.mExtraInfo.at(0), data.mExtraInfo.at(1), item->checkState(0) == Qt::Checked);
                break;
            }
        }
    }
```

#### AUTO 


```{c}
auto md = new QMimeData;
```

#### RANGE FOR STATEMENT 


```{c}
for (MessageComposer::PluginEditorCheckBeforeSend *plugin : lstPlugin) {
        if (plugin->isEnabled()) {
            MessageComposer::PluginEditorCheckBeforeSendInterface *interface = plugin->createInterface(this);
            interface->setParentWidget(mParentWidget);
            interface->reloadConfig();
            mListPluginInterface.append(interface);
        }
    }
```

#### AUTO 


```{c}
auto vlay = new QVBoxLayout(page);
```

#### LAMBDA EXPRESSION 


```{c}
[this](uint val) {
        if (mComposerBase->identityCombo()->currentIdentity() == val) {
            slotIdentityChanged(val);
        }
    }
```

#### AUTO 


```{c}
auto dlg = new KSieveUi::ManageSieveScriptsDialog(&provider);
```

#### AUTO 


```{c}
auto *info = new ArchiveMailInfo;
```

#### RANGE FOR STATEMENT 


```{c}
for (MessageComposer::PluginEditorConvertTextInterface *interface : qAsConst(mListPluginInterface)) {
            const MessageComposer::PluginActionType actionType = interface->actionType();
            MessageComposer::PluginActionType::Type type = actionType.type();
            QList<QAction *> lst = mActionHash.value(type);
            if (!lst.isEmpty()) {
                QAction *act = new QAction(this);
                act->setSeparator(true);
                lst << act << actionType.action();
                mActionHash.insert(type, lst);
            } else {
                mActionHash.insert(type, QList<QAction *>() << actionType.action());
            }
            /*
            if (interface->plugin()->hasPopupMenuSupport()) {
                type = MessageComposer::PluginActionType::PopupMenu;
                QList<QAction *> lst = mActionHash.value(type);
                if (!lst.isEmpty()) {
                    QAction *act = new QAction(this);
                    act->setSeparator(true);
                    lst << act << actionType.action();
                    mActionHash.insert(type, lst);
                } else {
                    mActionHash.insert(type, QList<QAction *>() << actionType.action());
                }
            }
            if (interface->plugin()->hasToolBarSupport()) {
                type = MessageComposer::PluginActionType::ToolBar;
                QList<QAction *> lst = mActionHash.value(type);
                if (!lst.isEmpty()) {
                    QAction *act = new QAction(this);
                    act->setSeparator(true);
                    lst << act << actionType.action();
                    mActionHash.insert(type, lst);
                } else {
                    mActionHash.insert(type, QList<QAction *>() << actionType.action());
                }
            }
            */
        }
```

#### AUTO 


```{c}
auto *subjectTab = new SubjectTab();
```

#### AUTO 


```{c}
auto *cmd(new KMReplyCommand(nullptr, item, MessageComposer::ReplyAll));
```

#### RANGE FOR STATEMENT 


```{c}
for (auto job : mPendingMoves) {
            job->kill();
        }
```

#### AUTO 


```{c}
auto command = new KMSetStatusCommand(set, Akonadi::Item::List() << item, false);
```

#### AUTO 


```{c}
auto b = new QToolButton(mb);
```

#### AUTO 


```{c}
auto job = new KIO::ApplicationLauncherJob();
```

#### AUTO 


```{c}
auto job = new Akonadi::ItemFetchJob(Akonadi::Item(itemId), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &boxIt : mMailboxes) {
        auto boxGroup = group.group(boxIt.second->id());
        boxIt.second->save(boxGroup);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](int state) {
        if (state == Qt::Unchecked) {
            mStartInTrayCheck->setCheckState(Qt::Unchecked);
        }
        slotEmitChanged();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &i : qAsConst(mItem)) {
        Akonadi::Item item(i);
        if (mMode == CleanExistingAndAddNew) {
            // WorkAround. ClearTags doesn't work.
            const Akonadi::Tag::List lstTags = item.tags();
            for (const Akonadi::Tag &tag : lstTags) {
                item.clearTag(tag);
            }
            // item.clearTags();
        }

        if (mMode == KMSetTagCommand::Toggle) {
            for (const Akonadi::Tag &tag : qAsConst(mCreatedTags)) {
                if (item.hasTag(tag)) {
                    item.clearTag(tag);
                } else {
                    item.setTag(tag);
                }
            }
        } else {
            if (!mCreatedTags.isEmpty()) {
                item.setTags(mCreatedTags);
            }
        }
        itemsToModify << item;
    }
```

#### AUTO 


```{c}
auto dictionaryCombo = new DictionaryComboBox(mHeadersArea);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Akonadi::Item::List &items) {
        ReplayNextOnExit replayNext(mMonitor);

        // Monitor did the heavy lifting for us and already figured out that
        // we only monitor the source collection of the Items and translated
        // it into REMOVE change.

        // This relies on Akonadi never mixing Items from different sources or
        // destination during batch-moves.
        const auto parentId = items.first().parentCollection().id();
        const auto box = unifiedMailboxForSource(parentId);
        if (!box) {
            qCWarning(UNIFIEDMAILBOXAGENT_LOG) << "Received Remove notification for Items belonging to" << parentId << "which we don't monitor";
            return;
        }
        if (box->collectionId() <= -1) {
            qCWarning(UNIFIEDMAILBOXAGENT_LOG) << "Missing box->collection mapping for unified mailbox" << box->id();
            return;
        }

        new Akonadi::UnlinkJob(Akonadi::Collection {box->collectionId()}, items, this);
    }
```

#### AUTO 


```{c}
auto label = new QLabel(i18n("Recognize any sequence of the following prefixes\n"
                                    "(entries are case-insensitive regular expressions):"), group);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Collection &collection : collections) {
            if (!printDebugCollection.isEmpty()) {
                printDebugCollection += QLatin1Char('\n');
            }
            printDebugCollection += QStringLiteral("Collection name: %1\n").arg(collection.name());
            printDebugCollection += QStringLiteral("Collection id: %1\n").arg(collection.id());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &server : qAsConst(mServerActive)) {
        auto lab = new ServerLabel(server);
        connect(lab, &ServerLabel::clicked, this, &VacationScriptIndicatorWidget::clicked);
        mBoxLayout->addWidget(lab);
    }
```

#### AUTO 


```{c}
auto dateLabel = new QLabel(i18n("Backup each:"), this);
```

#### AUTO 


```{c}
auto *aggregationLayout = new QHBoxLayout();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QFileInfo &file : autoSaveFiles) {
        // Disregard the '.' and '..' folders
        const QString filename = file.fileName();
        if (filename == QLatin1Char('.') || filename == QLatin1String("..") || file.isDir()) {
            continue;
        }
        qCDebug(KMAIL_LOG) << "Opening autosave file:" << file.absoluteFilePath();
        QFile autoSaveFile(file.absoluteFilePath());
        if (autoSaveFile.open(QIODevice::ReadOnly)) {
            const KMime::Message::Ptr autoSaveMessage(new KMime::Message());
            const QByteArray msgData = autoSaveFile.readAll();
            autoSaveMessage->setContent(msgData);
            autoSaveMessage->parse();

            // Show the a new composer dialog for the message
            KMail::Composer *autoSaveWin = KMail::makeComposer();
            autoSaveWin->setMessage(autoSaveMessage, false, false, false);
            autoSaveWin->setAutoSaveFileName(filename);
            autoSaveWin->show();
            autoSaveFile.close();
        } else {
            KMessageBox::sorry(nullptr,
                               i18n("Failed to open autosave file at %1.\nReason: %2", file.absoluteFilePath(), autoSaveFile.errorString()),
                               i18n("Opening Autosave File Failed"));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KontactInterface::Plugin *i : pluginList) {
        // execute all sync actions but our own
        const QList<QAction *> actList = i->syncActions();
        for (QAction *j : actList) {
            if (j != mSyncAction) {
                j->trigger();
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto job : mPendingDeletes) {
            job->kill();
        }
```

#### AUTO 


```{c}
auto formatHelp = new QLabel(i18n("<qt><a href=\"whatsthis1\">Custom format information...</a></qt>"), hbox);
```

#### AUTO 


```{c}
auto formatLabel = new QLabel(i18n("F&ormat:"), mainWidget);
```

#### AUTO 


```{c}
auto *bgHTTPProxy = new QButtonGroup(this);
```

#### AUTO 


```{c}
const auto &index
```

#### AUTO 


```{c}
auto win = new SecondaryWindow();
```

#### AUTO 


```{c}
auto *checkCol = new FolderArchiveAgentCheckCollection(mInfo, this);
```

#### AUTO 


```{c}
auto label = new QLabel(i18n("Recognize any of the following key words as "
                                 "intention to attach a file:"),
                            this);
```

#### AUTO 


```{c}
auto *job = new Akonadi::ItemDeleteJob(retrievedList, this);
```

#### AUTO 


```{c}
auto command = new KMForwardCommand(this, selectedMessages, mCurrentFolderSettings->identity(), QString(), text);
```

#### AUTO 


```{c}
auto ftw = new MailCommon::FolderTreeWidget(nullptr,
                                                nullptr,
                                                MailCommon::FolderTreeWidget::TreeViewOptions(MailCommon::FolderTreeWidget::UseDistinctSelectionModel
                                                                                              | MailCommon::FolderTreeWidget::HideStatistics
                                                                                              | MailCommon::FolderTreeWidget::HideHeaderViewMenu));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &addr : qAsConst(mEmails)) {
        if (!mEmailWhiteList.contains(addr.trimmed())) {
            QString tname, temail;
            KEmailAddress::extractEmailAddressAndName(addr, temail, tname);    // ignore return value
            // which is always false
            if (tname.contains(QStringLiteral("@"))) { //Potential address
                if (tname.startsWith(QLatin1Char('<')) && tname.endsWith(QLatin1Char('>'))) {
                    tname = tname.mid(1, tname.length() - 2);
                }
                if (tname.startsWith(QLatin1Char('\'')) && tname.endsWith(QLatin1Char('\''))) {
                    tname = tname.mid(1, tname.length() - 2);
                }
                if (temail.toLower() != tname.toLower()) {
                    const QString str = QStringLiteral("(%1)").arg(temail);
                    if (!tname.contains(str, Qt::CaseInsensitive)) {
                        const QStringList lst = tname.trimmed().split(QLatin1Char(' '));
                        if (lst.count() > 1) {
                            const QString firstName = lst.at(0);

                            for (const QString &n : lst) {
                                if (n != firstName) {
                                    mPotentialPhisingEmails.append(addr);
                                    break;
                                }
                            }
                        } else {
                            mPotentialPhisingEmails.append(addr);
                        }
                    }
                }
            }
        }
    }
```

#### AUTO 


```{c}
auto glay = new QGridLayout(tab);
```

#### AUTO 


```{c}
auto *cmd = new KMFetchMessageCommand(this, msg, win ? win->viewer() : mMsgView->viewer(), win);
```

#### AUTO 


```{c}
auto lay = new QVBoxLayout(topWidget);
```

#### AUTO 


```{c}
auto *fetchCollectionJob = static_cast<Akonadi::CollectionFetchJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &source : std::as_const(mSources)) {
                mManager->mMonitor.setCollectionMonitored(Akonadi::Collection{source}, false);
                mManager->mSourceToBoxMap.erase(source);
            }
```

#### AUTO 


```{c}
auto expandJob = new Akonadi::ContactGroupExpandJob(group, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &group : filterGroups) {
            if (group == groupName) {
                config->deleteGroup(group);
                --value;
                needSaveConfig = true;
            }
        }
```

#### AUTO 


```{c}
auto checkCol = new FolderArchiveAgentCheckCollection(mInfo, this);
```

#### AUTO 


```{c}
auto u = insertFile();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto source : qAsConst(mSources)) {
                mManager->mMonitor.setCollectionMonitored(Akonadi::Collection{source}, false);
                mManager->mSourceToBoxMap.erase(source);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this, tagName] { onSignalMapped(tagName);}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &notify : lstNotify) {
        const QString fullPath = QStandardPaths::locate(QStandardPaths::GenericDataLocation, QStringLiteral("knotifications5/") + notify);

        if (!fullPath.isEmpty()) {
            const int slash = fullPath.lastIndexOf(QLatin1Char('/'));
            QString appname = fullPath.right(fullPath.length() - slash - 1);
            appname.remove(QStringLiteral(".notifyrc"));
            if (!appname.isEmpty()) {
                KConfig config(fullPath, KConfig::NoGlobals, QStandardPaths::AppLocalDataLocation);
                KConfigGroup globalConfig(&config, QStringLiteral("Global"));
                const QString icon = globalConfig.readEntry(QStringLiteral("IconName"), QStringLiteral("misc"));
                const QString description = globalConfig.readEntry(QStringLiteral("Comment"), appname);
                m_comboNotify->addItem(QIcon::fromTheme(icon), description, appname);
            }
        }
    }
```

#### AUTO 


```{c}
auto *tab = qobject_cast<ConfigModuleTab *>(mTabWidget->widget(i));
```

#### AUTO 


```{c}
auto readerBox = new QGroupBox(i18n("Message Window"), this);
```

#### AUTO 


```{c}
auto autoCorrectionTab = new AutoCorrectionTab();
```

#### AUTO 


```{c}
auto page = new ComposerPage(parent);
```

#### AUTO 


```{c}
auto move = new Akonadi::ItemMoveJob(item, destinationCol, this);
```

#### AUTO 


```{c}
auto label = new QLabel(i18n("Custom message-&id suffix:"), this);
```

#### AUTO 


```{c}
auto job = new DndFromArkJob(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Collection &collection : collections) {
        changeRecorder()->setCollectionMonitored(collection, false);
    }
```

#### AUTO 


```{c}
static const auto AgentIdentifier = QStringLiteral("akonadi_unifiedmailbox_agent");
```

#### RANGE FOR STATEMENT 


```{c}
for (const MailCommon::MailFilter *filter : qAsConst(mFilters)) {
        if (filter->applyOnInbound() && filter->applyOnAccount(accountId)) {
            return true;
        }
    }
```

#### AUTO 


```{c}
auto info = dialog->info();
```

#### AUTO 


```{c}
auto watcher = std::make_shared<FileSystemWatcher>();
```

#### AUTO 


```{c}
auto info = new FollowUpReminder::FollowUpReminderInfo(group);
```

#### AUTO 


```{c}
auto *job = new Akonadi::AddEmailAddressJob(emailString, mMainWindow, this);
```

#### AUTO 


```{c}
auto action = new QAction(i18n("Focus on Next Message"), this);
```

#### AUTO 


```{c}
auto cmd(new KMReplyCommand(nullptr, item, MessageComposer::ReplyAll));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &str : prefCharsets) {
        QByteArray charset = str.toLatin1().toLower();

        if (charset == "locale") {
            charset = QTextCodec::codecForLocale()->name();

            // Special case for Japanese:
            // (Introduction to i18n, 6.6 Limit of Locale technology):
            // EUC-JP is the de-facto standard for UNIX systems, ISO 2022-JP
            // is the standard for Internet, and Shift-JIS is the encoding
            // for Windows and Macintosh.
            if (charset == "jisx0208.1983-0"
                || charset == "eucjp"
                || charset == "shift-jis") {
                charset = "iso-2022-jp";
                // TODO wtf is "jis7"?
            }

            // Special case for Korean:
            if (charset == "ksc5601.1987-0") {
                charset = "euc-kr";
            }
        }
        d->preferredCharsets << charset;
    }
```

#### AUTO 


```{c}
auto sMimeTab = new SMimeTab();
```

#### RANGE FOR STATEMENT 


```{c}
for (QTreeWidgetItem *item : mailItemLst) {
                FollowUpReminderInfoItem *mailItem = static_cast<FollowUpReminderInfoItem *>(item);
                mListRemoveId << mailItem->info()->uniqueIdentifier();
                delete mailItem;
            }
```

#### AUTO 


```{c}
auto *job = new AddEmailToExistingContactJob(item, emailString, this);
```

#### AUTO 


```{c}
const auto *searchDescription = collection.attribute<Akonadi::SearchDescriptionAttribute>();
```

#### LAMBDA EXPRESSION 


```{c}
[this] { slotApplyFilterOnFolder(/* recursive */ true);
                    }
```

#### AUTO 


```{c}
auto *sync = qobject_cast<Akonadi::CollectionAttributesSynchronizationJob *>(job);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &service) {
        Q_UNUSED(service)
        mUnityServiceAvailable = true;
        updateCount();
    }
```

#### AUTO 


```{c}
auto markAsReadAllJob = new Akonadi::MarkAsCommand(messageStatus, list);
```

#### AUTO 


```{c}
auto info = new ArchiveMailInfo(group);
```

#### AUTO 


```{c}
auto grid = new QGridLayout(this);
```

#### AUTO 


```{c}
auto treeWidget = parent.findChild<QTreeWidget *>(QStringLiteral("treewidget"));
```

#### AUTO 


```{c}
auto action = new QAction(i18n("Abort Current Operation"), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &configName: configNameFiles) {
        initCleanupFolderSettings(configName);
        initCleanupFiltersSettings(configName);
        initCleanDialogSettings(configName);
        initCleanupDialogSettings(configName);
        removeTipOfDay(configName);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const MailCommon::MailFilter *filter : std::as_const(d->mFilters)) {
        qCDebug(MAILFILTERAGENT_LOG) << filter->asString();
    }
```

#### AUTO 


```{c}
const auto &msg
```

#### AUTO 


```{c}
auto editor = new UnifiedMailboxEditor(mailbox.get(), mConfig, this);
```

#### AUTO 


```{c}
auto *reminderJob = new MessageComposer::FollowupReminderCreateJob(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (MessageComposer::PluginEditorInterface *interface : std::as_const(mListPluginInterface)) {
            const MessageComposer::PluginActionType actionType = interface->actionType();
            MessageComposer::PluginActionType::Type type = actionType.type();
            const bool needSelectedText = interface->needSelectedText();
            if (needSelectedText) {
                // Disable by default as we don't have selection by default.
                actionType.action()->setEnabled(false);
                connect(this, &KMailPluginEditorManagerInterface::textSelectionChanged, actionType.action(), &QAction::setEnabled);
            }
            QList<QAction *> lst = mActionHash.value(type);
            if (!lst.isEmpty()) {
                auto act = new QAction(this);
                act->setSeparator(true);
                lst << act << actionType.action();
                mActionHash.insert(type, lst);
            } else {
                mActionHash.insert(type, QList<QAction *>() << actionType.action());
            }
            if (interface->plugin()->hasPopupMenuSupport()) {
                type = MessageComposer::PluginActionType::PopupMenu;
                lst = mActionHash.value(type);
                if (!lst.isEmpty()) {
                    auto act = new QAction(this);
                    act->setSeparator(true);
                    lst << act << actionType.action();
                    mActionHash.insert(type, lst);
                } else {
                    mActionHash.insert(type, QList<QAction *>() << actionType.action());
                }
            }
            if (interface->plugin()->hasToolBarSupport()) {
                type = MessageComposer::PluginActionType::ToolBar;
                lst = mActionHash.value(type);
                if (!lst.isEmpty()) {
                    auto act = new QAction(this);
                    act->setSeparator(true);
                    lst << act << actionType.action();
                    mActionHash.insert(type, lst);
                } else {
                    mActionHash.insert(type, QList<QAction *>() << actionType.action());
                }
            }
        }
```

#### AUTO 


```{c}
const auto answer = KMessageBox::questionYesNo(
            this, i18n("You have more than one email account set up. Do you want to enable the Unified Mailbox feature to "
                        "show unified content of your inbox, sent and drafts folders?\n"
                        "You can configure unified mailboxes, create custom ones or disable the feature completely in KMail's Plugin settings."),
            i18n("Enable Unified Mailboxes?"),
            KGuiItem(i18n("Enable Unified Mailboxes"), QStringLiteral("dialog-ok")),
            KGuiItem(i18n("Cancel"), QStringLiteral("dialog-cancel")));
```

#### AUTO 


```{c}
auto *glay = new QGridLayout(tab);
```

#### AUTO 


```{c}
auto aggregationConfigButton = new AggregationConfigButton(this, mAggregationComboBox);
```

#### AUTO 


```{c}
auto sep = new QAction(menu);
```

#### RANGE FOR STATEMENT 


```{c}
for (ArchiveMailInfo *oldInfo : qAsConst(mListArchiveInfo)) {
                if (oldInfo->saveCollectionId() == info->saveCollectionId()) {
                    // already in jobscheduler
                    delete info;
                    info = nullptr;
                    break;
                }
            }
```

#### AUTO 


```{c}
const auto col = data(index, Akonadi::EntityTreeModel::CollectionRole).value<Akonadi::Collection>();
```

#### RANGE FOR STATEMENT 


```{c}
for (MailCommon::MailFilter *filter : qAsConst(mFilters)) {
            if (filter->identifier() == filterId) {
                wantedFilter = filter;
                break;
            }
        }
```

#### AUTO 


```{c}
auto line = job->property("line").value<QPointer<MessageComposer::RecipientLineNG>>();
```

#### RANGE FOR STATEMENT 


```{c}
for (Akonadi::AgentInstance type : lst) {
        const QString identifier(type.identifier());
        if (PimCommon::Util::isImapResource(identifier)
            || identifier.contains(POP3_RESOURCE_IDENTIFIER)
            || identifier.contains(QLatin1String("akonadi_maildispatcher_agent"))
            || type.type().capabilities().contains(QLatin1String("NeedsNetwork"))) {
            type.setIsOnline(goOnline);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &i : std::as_const(mItem)) {
        Akonadi::Item item(i);
        if (mMode == CleanExistingAndAddNew) {
            // WorkAround. ClearTags doesn't work.
            const Akonadi::Tag::List lstTags = item.tags();
            for (const Akonadi::Tag &tag : lstTags) {
                item.clearTag(tag);
            }
            // item.clearTags();
        }

        if (mMode == KMSetTagCommand::Toggle) {
            for (const Akonadi::Tag &tag : std::as_const(mCreatedTags)) {
                if (item.hasTag(tag)) {
                    item.clearTag(tag);
                } else {
                    item.setTag(tag);
                }
            }
        } else {
            if (!mCreatedTags.isEmpty()) {
                item.setTags(mCreatedTags);
            }
        }
        itemsToModify << item;
    }
```

#### AUTO 


```{c}
auto *identityTab = new KMail::IdentityPage();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &mailboxIt : mBoxManager) {
        addBox(mailboxIt.second.get());
    }
```

#### AUTO 


```{c}
auto box = unifiedMailboxForSource(colId);
```

#### AUTO 


```{c}
auto l = new QLabel(i18n("Close to quota threshold:"), this);
```

#### AUTO 


```{c}
auto headersTab = new ComposerPageHeadersTab();
```

#### AUTO 


```{c}
auto hrd = mSettings.mMsg->headerByType("X-KMail-Identity")
```

#### AUTO 


```{c}
auto *command = new KMMoveCommand(dest, selectMsg, ref);
```

#### RANGE FOR STATEMENT 


```{c}
for (MessageComposer::PluginEditorConvertTextInterface *interface : qAsConst(mListPluginInterface)) {
        switch(interface->convertTextToFormat(textPart)) {
        case MessageComposer::PluginEditorConvertTextInterface::ConvertTextStatus::NotConverted:
            status = MessageComposer::PluginEditorConvertTextInterface::ConvertTextStatus::NotConverted;
            break;
        case MessageComposer::PluginEditorConvertTextInterface::ConvertTextStatus::Converted:
            status = MessageComposer::PluginEditorConvertTextInterface::ConvertTextStatus::Converted;
            break;
        case MessageComposer::PluginEditorConvertTextInterface::ConvertTextStatus::Error:
            status = MessageComposer::PluginEditorConvertTextInterface::ConvertTextStatus::Error;
            return status;
        }
    }
```

#### AUTO 


```{c}
auto *mainWidget = new QWidget(this);
```

#### AUTO 


```{c}
auto subMenu = qobject_cast<KSelectAction *>(action);
```

#### AUTO 


```{c}
auto box = std::make_unique<UnifiedMailbox>();
```

#### AUTO 


```{c}
auto *job = item->property("RemoveDuplicatesJob").value<Akonadi::Job *>();
```

#### RANGE FOR STATEMENT 


```{c}
for (FollowUpReminder::FollowUpReminderInfo *info : infoList) {
        if (info->isValid()) {
            createOrUpdateItem(info);
        }
    }
```

#### AUTO 


```{c}
auto const tagAction = new KToggleAction(QIcon::fromTheme(tag->iconName),
                                                       cleanName, this);
```

#### AUTO 


```{c}
auto job = new KIO::OpenUrlJob(QUrl::fromLocalFile(tmpFile->fileName()), QStringLiteral("text/rtf"));
```

#### LAMBDA EXPRESSION 


```{c}
[this](uint val) {
            slotIdentityChanged(val);
    }
```

#### AUTO 


```{c}
const auto source
```

#### RANGE FOR STATEMENT 


```{c}
for (ArchiveMailInfo *info : qAsConst(mListArchiveInfo)) {
            if (!infoStr.isEmpty()) {
                infoStr += QLatin1Char('\n');
            }
            infoStr += infoToStr(info);
        }
```

#### AUTO 


```{c}
auto *charsetTab = new CharsetTab();
```

#### AUTO 


```{c}
const auto index = action->data().toModelIndex();
```

#### LAMBDA EXPRESSION 


```{c}
[=](const Akonadi::Item::List &items) {
            m_filterManager->applySpecificFilters(items, requires, listFilters, static_cast<FilterManager::FilterSet>(filterSet));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : items) {
            QString attachmentName = QStringLiteral("attachment");
            if (item.hasPayload<KContacts::Addressee>()) {
                const auto contact = item.payload<KContacts::Addressee>();
                attachmentName = contact.realName() + QLatin1String(".vcf");
                // Workaround about broken kaddressbook fields.
                QByteArray data = item.payloadData();
                KContacts::adaptIMAttributes(data);
                addAttachment(attachmentName, KMime::Headers::CEbase64, QString(), data, "text/x-vcard");
            } else if (item.hasPayload<KContacts::ContactGroup>()) {
                const auto group = item.payload<KContacts::ContactGroup>();
                attachmentName = group.name() + QLatin1String(".vcf");
                auto expandJob = new Akonadi::ContactGroupExpandJob(group, this);
                expandJob->setProperty("groupName", attachmentName);
                connect(expandJob, &KJob::result, this, &KMComposerWin::slotExpandGroupResult);
                expandJob->start();
            } else {
                addAttachment(attachmentName, KMime::Headers::CEbase64, QString(), item.payloadData(), item.mimeType().toLatin1());
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                auto mailbox = std::make_unique<UnifiedMailbox>();
                auto editor = new UnifiedMailboxEditor(mailbox.get(), mConfig, this);
                if (editor->exec()) {
                    mailbox->setId(mailbox->name()); // assign ID
                    addBox(mailbox.get());
                    mBoxManager.insertBox(std::move(mailbox));
                }
            }
```

#### AUTO 


```{c}
auto msgPtr = KMime::Message::Ptr(new KMime::Message());
```

#### LAMBDA EXPRESSION 


```{c}
[view, editButton, removeButton]() {
        const bool hasSelection = view->selectionModel()->hasSelection();
        editButton->setEnabled(hasSelection);
        removeButton->setEnabled(hasSelection);
    }
```

#### AUTO 


```{c}
auto job = new MessageComposer::InsertTextFileJob(mComposerBase->editor(), u);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Collection &col : cols) {
        const QModelIndex colIdx = Akonadi::EntityTreeModel::modelIndexForCollection(etm, col);
        if (col.statistics().count() > -1) {
            if (col.cachePolicy().localParts().contains(QLatin1String("RFC822"))) {
                result.push_back(col);
            }
        } else {
            const Akonadi::Collection collection = etm->data(colIdx, Akonadi::EntityTreeModel::CollectionRole).value<Akonadi::Collection>();
            if (!collection.hasAttribute<Akonadi::EntityHiddenAttribute>()
                    && collection.cachePolicy().localParts().contains(QLatin1String("RFC822"))) {
                result.push_back(collection);
            }
        }

        const int childrenCount = etm->rowCount(colIdx);
        if (childrenCount > 0) {
            Akonadi::Collection::List subCols;
            subCols.reserve(childrenCount);
            for (int i = 0; i < childrenCount; ++i) {
                const QModelIndex idx = etm->index(i, 0, colIdx);
                const Akonadi::Collection child = etm->data(idx, Akonadi::EntityTreeModel::CollectionRole).value<Akonadi::Collection>();
                if (child.cachePolicy().localParts().contains(QLatin1String("RFC822"))) {
                    subCols.push_back(child);
                }
            }

            result += searchCollectionsRecursive(subCols);
        }
    }
```

#### AUTO 


```{c}
auto *emailValidator1 = new PimCommon::EmailValidator(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) {
                d->deleteJobResult(job);
            }
```

#### AUTO 


```{c}
auto *accountMenu = new QMenu(this);
```

#### AUTO 


```{c}
auto *job = new PotentialPhishingEmailJob(this);
```

#### AUTO 


```{c}
static const auto InboxBoxId = QStringLiteral("inbox");
```

#### AUTO 


```{c}
auto parser = new TemplateParser::TemplateParserJob(mMsg, TemplateParser::TemplateParserJob::NewMessage);
```

#### AUTO 


```{c}
auto searchJob = new Akonadi::SearchCreateJob(mUi.mSearchFolderEdt->text(), mQuery, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &serNumStr : serNums) {
            items << Akonadi::Item(serNumStr.toLongLong());
        }
```

#### AUTO 


```{c}
auto hbox = new QWidget(page);
```

#### AUTO 


```{c}
static constexpr auto SpecialCollectionSentMail = "send-mail";
```

#### RANGE FOR STATEMENT 


```{c}
for (auto source  : sources) {
        auto fetch = new Akonadi::ItemFetchJob(Akonadi::Collection(source), this);
        fetch->setDeliveryOption(Akonadi::ItemFetchJob::EmitItemsInBatches);
        fetch->fetchScope().setFetchVirtualReferences(true);
        fetch->fetchScope().setCacheOnly(true);
        connect(fetch, &Akonadi::ItemFetchJob::itemsReceived,
                this, [this, c](const Akonadi::Item::List &items) {
                    Akonadi::Item::List toLink;
                    std::copy_if(items.cbegin(), items.cend(), std::back_inserter(toLink),
                        [&c](const Akonadi::Item &item) {
                            return !item.virtualReferences().contains(c);
                        });
                    if (!toLink.isEmpty()) {
                        new Akonadi::LinkJob(c, toLink, this);
                    }
                });
    }
```

#### AUTO 


```{c}
auto kiojob = qobject_cast<KIO::Job *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto source : sourceCollections) {
                auto col = collectionForId(source);
                QVERIFY(col.isValid());
                QVERIFY(col.hasAttribute<Akonadi::SpecialCollectionAttribute>());
                QCOMPARE(col.attribute<Akonadi::SpecialCollectionAttribute>()->collectionType(), id.toLatin1());
            }
```

#### AUTO 


```{c}
auto buttonCode = static_cast<PimCommon::SimpleStringListEditor::ButtonCode>(
        PimCommon::SimpleStringListEditor::Add | PimCommon::SimpleStringListEditor::Remove | PimCommon::SimpleStringListEditor::Modify);
```

#### AUTO 


```{c}
auto label = new QLabel(i18nc("%1: number of unread messages "
                                                 "%2: total number of messages",
                                                 "%1 / %2", stats.unreadCount(), stats.count()), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto job : std::as_const(mPendingDeletes)) {
            job->kill();
        }
```

#### AUTO 


```{c}
auto act = new QAction(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &s : std::as_const(list)) {
            to.append(s.fullEmail());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : items) {
            QString attachmentName = QStringLiteral("attachment");
            if (item.hasPayload<KContacts::Addressee>()) {
                const KContacts::Addressee contact = item.payload<KContacts::Addressee>();
                attachmentName = contact.realName() + QLatin1String(".vcf");
                //Workaround about broken kaddressbook fields.
                QByteArray data = item.payloadData();
                KContacts::adaptIMAttributes(data);
                addAttachment(attachmentName, KMime::Headers::CEbase64, QString(), data, "text/x-vcard");
            } else if (item.hasPayload<KContacts::ContactGroup>()) {
                const KContacts::ContactGroup group = item.payload<KContacts::ContactGroup>();
                attachmentName = group.name() + QLatin1String(".vcf");
                Akonadi::ContactGroupExpandJob *expandJob = new Akonadi::ContactGroupExpandJob(group, this);
                expandJob->setProperty("groupName", attachmentName);
                connect(expandJob, &KJob::result, this, &KMComposerWin::slotExpandGroupResult);
                expandJob->start();
            } else {
                addAttachment(attachmentName, KMime::Headers::CEbase64, QString(), item.payloadData(), item.mimeType().toLatin1());
            }
        }
```

#### AUTO 


```{c}
auto *bg = new QButtonGroup(this);
```

#### AUTO 


```{c}
auto receivingTab = new AccountsPageReceivingTab();
```

#### RANGE FOR STATEMENT 


```{c}
for (QTreeWidgetItem *selecteditem : selectedItems) {
            IdentityListViewItem *identityItem = dynamic_cast<IdentityListViewItem *>(item);
            identityName = identityItem->identity().identityName();
            if (mIdentityManager->removeIdentity(identityName)) {
                delete selecteditem;
            }
            if (mIPage.mIdentityList->currentItem()) {
                mIPage.mIdentityList->currentItem()->setSelected(true);
            }
            refreshList();
            updateButtons();
        }
```

#### AUTO 


```{c}
auto label = new QLabel(i18n("<qt>To choose a key or a combination "
                                    "of keys which select the current folder, "
                                    "click the button below and then press the key(s) "
                                    "you wish to associate with this folder.</qt>"), this);
```

#### AUTO 


```{c}
auto handleButton = new QPushButton(i18n("Invoke Handler"), mGroupWidget);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &col : list) {
                    if (!isUnifiedMailbox(col) || col.parentCollection() == Akonadi::Collection::root()) {
                        continue;
                    }

                    mMailboxes.at(col.name())->setCollectionId(col.id());
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this, view]() {
        const auto indexes = view->selectionModel()->selectedIndexes();
        if (!indexes.isEmpty()) {
            auto item = mBoxModel->itemFromIndex(indexes[0]);
            auto mailbox = item->data().value<UnifiedMailbox *>();
            auto editor = new UnifiedMailboxEditor(mailbox, mConfig, this);
            if (editor->exec()) {
                item->setText(mailbox->name());
                item->setIcon(QIcon::fromTheme(mailbox->icon()));
            }
            delete editor;
            mBoxManager.saveBoxes();
        }
    }
```

#### AUTO 


```{c}
auto formLayout = new QFormLayout(tab);
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : lstActs) {
        KSelectAction *subMenu = qobject_cast<KSelectAction *>(action);
        if (subMenu) {
            const QString codecNameToSet = selectCharset(subMenu, encoding);
            if (!codecNameToSet.isEmpty()) {
                return codecNameToSet;
            }
        } else {
            const QString fixedActionText = MimeTreeParser::NodeHelper::fixEncoding(action->text());
            if (KCharsets::charsets()->codecForName(
                    KCharsets::charsets()->encodingForName(fixedActionText))
                == KCharsets::charsets()->codecForName(encoding)) {
                return action->text();
            }
        }
    }
```

#### AUTO 


```{c}
auto *composerInterface = new MessageComposer::PluginComposerInterface;
```

#### RANGE FOR STATEMENT 


```{c}
for (MessageComposer::PluginEditor *plugin : lstPlugin) {
        if (plugin->isEnabled()) {
            auto interface = static_cast<MessageComposer::PluginEditorInterface *>(plugin->createInterface(this));
            auto composerInterface = new MessageComposer::PluginComposerInterface;
            composerInterface->setComposerViewBase(mComposerInterface);
            interface->setComposerInterface(composerInterface);
            interface->setRichTextEditor(mRichTextEditor);
            interface->setParentWidget(mParentWidget);
            interface->createAction(mActionCollection);
            interface->setPlugin(plugin);
            connect(interface, &MessageComposer::PluginEditorInterface::emitPluginActivated, this, &KMailPluginEditorManagerInterface::slotPluginActivated);
            connect(interface, &MessageComposer::PluginEditorInterface::message, this, &KMailPluginEditorManagerInterface::message);
            connect(interface, &MessageComposer::PluginEditorInterface::insertText, this, &KMailPluginEditorManagerInterface::insertText);
            mListPluginInterface.append(interface);
        }
    }
```

#### AUTO 


```{c}
auto *listWidget = dlg.findChild<QListWidget *>(QStringLiteral("listtag"));
```

#### AUTO 


```{c}
auto line
```

#### AUTO 


```{c}
const auto searchDescription = collection.attribute<Akonadi::SearchDescriptionAttribute>();
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *a : qAsConst(mFilterMenuActions)) {
        actionCollection()->removeAction(a);
    }
```

#### AUTO 


```{c}
auto inboxBox = manager.unifiedMailboxFromCollection(inboxBoxCol);
```

#### RANGE FOR STATEMENT 


```{c}
for (MessageComposer::PluginEditorConvertTextInterface *interface : std::as_const(mListPluginInterface)) {
        switch (interface->convertTextToFormat(textPart)) {
        case MessageComposer::PluginEditorConvertTextInterface::ConvertTextStatus::NotConverted:
            if (status != MessageComposer::PluginEditorConvertTextInterface::ConvertTextStatus::Converted) {
                status = MessageComposer::PluginEditorConvertTextInterface::ConvertTextStatus::NotConverted;
            }
            break;
        case MessageComposer::PluginEditorConvertTextInterface::ConvertTextStatus::Converted:
            status = MessageComposer::PluginEditorConvertTextInterface::ConvertTextStatus::Converted;
            break;
        case MessageComposer::PluginEditorConvertTextInterface::ConvertTextStatus::Error:
            status = MessageComposer::PluginEditorConvertTextInterface::ConvertTextStatus::Error;
            return status;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (MailTransport::Transport *transport : transports) {
            const QString name = transport->name().replace(QLatin1Char('&'), QStringLiteral("&&"));
            menuTransportLst.insert(name, transport->id());
        }
```

#### AUTO 


```{c}
auto *buttonBox = new QDialogButtonBox(QDialogButtonBox::Close, this);
```

#### AUTO 


```{c}
auto user1Button = new QPushButton;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &arg : parser.positionalArguments()) {
            if (arg.startsWith(QStringLiteral("mailto:"), Qt::CaseInsensitive)) {
                QMap<QString, QString> values = MessageCore::StringUtil::parseMailtoUrl(QUrl::fromUserInput(arg));
                if (!values.value(QStringLiteral("to")).isEmpty()) {
                    to += values.value(QStringLiteral("to")) + QStringLiteral(", ");
                }
                if (!values.value(QStringLiteral("cc")).isEmpty()) {
                    cc += values.value(QStringLiteral("cc")) + QStringLiteral(", ");
                }
                if (!values.value(QStringLiteral("subject")).isEmpty()) {
                    subj = values.value(QStringLiteral("subject"));
                }
                if (!values.value(QStringLiteral("body")).isEmpty()) {
                    body = values.value(QStringLiteral("body"));
                }
                if (!values.value(QStringLiteral("in-reply-to")).isEmpty()) {
                    inReplyTo = values.value(QStringLiteral("in-reply-to"));
                }
                const QString attach = values.value(QStringLiteral("attachment"));
                if (!attach.isEmpty()) {
                    attachURLs << makeAbsoluteUrl(attach, workingDir);
                }
            } else {
                QUrl url(arg);
                if (url.isValid() && !url.scheme().isEmpty()) {
                    attachURLs += url;
                } else {
                    to += arg + QStringLiteral(", ");
                }
            }
            mailto = true;
        }
```

#### AUTO 


```{c}
auto *hbHBoxLayout = new QHBoxLayout;
```

#### AUTO 


```{c}
const auto runningJob = line->property("keyLookupJob").value<QPointer<Kleo::KeyForMailboxJob>>();
```

#### AUTO 


```{c}
auto label = new QLabel(i18n("<qt>To choose a key or a combination "
                                 "of keys which select the current folder, "
                                 "click the button below and then press the key(s) "
                                 "you wish to associate with this folder.</qt>"),
                            this);
```

#### AUTO 


```{c}
auto box = unifiedMailboxForSource(col.id())
```

#### AUTO 


```{c}
auto *act =
        new QAction(i18nc("%1 is a 'Contact Owner' or similar action. %2 is a protocol normally web or email though could be irc/ftp or other url variant",
                          "%1 (%2)",
                          item,
                          protocol),
                    this);
```

#### AUTO 


```{c}
auto *interface = static_cast<PimCommon::GenericPluginInterface *>(abstractInterface);
```

#### AUTO 


```{c}
auto fetchjob = qobject_cast<Akonadi::ItemFetchJob *>(job);
```

#### AUTO 


```{c}
auto lspacer = new QSpacerItem(1, 10, QSizePolicy::MinimumExpanding, QSizePolicy::MinimumExpanding);
```

#### AUTO 


```{c}
auto *job = new Akonadi::ItemFetchJob(mCurrentCollection, this);
```

#### AUTO 


```{c}
auto action = new QAction(i18nc("View->", "&Expand Thread / Group"), this);
```

#### AUTO 


```{c}
auto *noAnswerInfo = new FollowUpReminderInfo(*info);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &arg : parser.positionalArguments()) {
            if (arg.startsWith(QStringLiteral("mailto:"), Qt::CaseInsensitive)) {
                QMap<QString, QString> values = MessageCore::StringUtil::parseMailtoUrl(QUrl::fromUserInput(arg));
                if (!values.value(QStringLiteral("to")).isEmpty()) {
                    to += values.value(QStringLiteral("to")) + QStringLiteral(", ");
                }
                if (!values.value(QStringLiteral("cc")).isEmpty()) {
                    cc += values.value(QStringLiteral("cc")) + QStringLiteral(", ");
                }
                if (!values.value(QStringLiteral("bcc")).isEmpty()) {
                    bcc += values.value(QStringLiteral("bcc")) + QStringLiteral(", ");
                }
                if (!values.value(QStringLiteral("subject")).isEmpty()) {
                    subj = values.value(QStringLiteral("subject"));
                }
                if (!values.value(QStringLiteral("body")).isEmpty()) {
                    body = values.value(QStringLiteral("body"));
                }
                if (!values.value(QStringLiteral("in-reply-to")).isEmpty()) {
                    inReplyTo = values.value(QStringLiteral("in-reply-to"));
                }
                QString attach = values.value(QStringLiteral("attachment"));
                if (!attach.isEmpty()) {
                    attachURLs << makeAbsoluteUrl(attach, workingDir);
                }
                attach = values.value(QStringLiteral("attach"));
                if (!attach.isEmpty()) {
                    attachURLs << makeAbsoluteUrl(attach, workingDir);
                }

            } else {
                QUrl url(arg);
                if (url.isValid() && !url.scheme().isEmpty()) {
                    attachURLs += url;
                } else {
                    to += arg + QStringLiteral(", ");
                }
            }
            mailto = true;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (FolderArchiveAccountInfo *info : std::as_const(mListAccountInfo)) {
        if (info->instanceName() == instanceName) {
            return info;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Collection &col : std::as_const(cols)) {
        const qlonglong num = KMKernel::self()->indexedItems()->indexedItems((qlonglong)col.id());
        if (col.statistics().count() != num) {
            results.push_back(col.id());
        }
    }
```

#### AUTO 


```{c}
auto reminderJob = new MessageComposer::FollowupReminderCreateJob(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { initializeFilterActions(true); }
```

#### RANGE FOR STATEMENT 


```{c}
for (MessageComposer::PluginEditorConvertTextInterface *interface : qAsConst(mListPluginInterface)) {
            for (const MessageComposer::PluginActionType &actionType : interface->actionTypes()) {
                MessageComposer::PluginActionType::Type type = actionType.type();
                QAction *currentAction = actionType.action();
                if (!currentAction) {
                    continue;
                }
                QList<QAction *> lst = mActionHash.value(type);
                if (!lst.isEmpty()) {
                    auto act = new QAction(this);
                    act->setSeparator(true);
                    lst << act << currentAction;
                    mActionHash.insert(type, lst);
                } else {
                    mActionHash.insert(type, QList<QAction *>() << currentAction);
                }
                if (interface->plugin()->hasPopupMenuSupport()) {
                    type = MessageComposer::PluginActionType::PopupMenu;
                    if (currentAction) {
                        lst = mActionHash.value(type);
                        if (!lst.isEmpty()) {
                            auto act = new QAction(this);
                            act->setSeparator(true);
                            lst << act << currentAction;
                            mActionHash.insert(type, lst);
                        } else {
                            mActionHash.insert(type, QList<QAction *>() << currentAction);
                        }
                    }
                }
                if (interface->plugin()->hasToolBarSupport()) {
                    type = MessageComposer::PluginActionType::ToolBar;
                    lst = mActionHash.value(type);
                    if (!lst.isEmpty()) {
                        auto act = new QAction(this);
                        act->setSeparator(true);
                        lst << act << currentAction;
                        mActionHash.insert(type, lst);
                    } else {
                        mActionHash.insert(type, QList<QAction *>() << currentAction);
                    }
                }
            }
        }
```

#### AUTO 


```{c}
auto folderCBHLayout = new QHBoxLayout;
```

#### AUTO 


```{c}
auto *restoreDefaultDomainName = new QToolButton;
```

#### RANGE FOR STATEMENT 


```{c}
for (auto source : sources) {
        auto fetch = new Akonadi::ItemFetchJob(Akonadi::Collection(source), this);
        fetch->setDeliveryOption(Akonadi::ItemFetchJob::EmitItemsInBatches);
        fetch->fetchScope().setFetchVirtualReferences(true);
        fetch->fetchScope().setCacheOnly(true);
        connect(fetch, &Akonadi::ItemFetchJob::itemsReceived, this, [this, c](const Akonadi::Item::List &items) {
            Akonadi::Item::List toLink;
            std::copy_if(items.cbegin(), items.cend(), std::back_inserter(toLink), [&c](const Akonadi::Item &item) {
                return !item.virtualReferences().contains(c);
            });
            if (!toLink.isEmpty()) {
                new Akonadi::LinkJob(c, toLink, this);
            }
        });
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &arg : parser.positionalArguments()) {
            if (arg.startsWith(QLatin1String("mailto:"), Qt::CaseInsensitive)) {
                const QUrl urlDecoded(QUrl::fromPercentEncoding(arg.toUtf8()));
                QMap<QString, QString> values = MessageCore::StringUtil::parseMailtoUrl(urlDecoded);
                QString previousKey;
                for (auto it = values.cbegin(), end = values.cend(); it != end; ++it) {
                    const QString key = it.key();
                    if (key == QLatin1Literal("to")) {
                        if (!it->isEmpty()) {
                            to += *it + QStringLiteral(", ");
                        }
                        previousKey.clear();
                    } else if (key == QLatin1Literal("cc")) {
                        if (!it->isEmpty()) {
                            cc += *it + QStringLiteral(", ");
                        }
                        previousKey.clear();
                    } else if (key == QLatin1Literal("bcc")) {
                        if (!it->isEmpty()) {
                            bcc += *it + QStringLiteral(", ");
                        }
                        previousKey.clear();
                    } else if (key == QLatin1Literal("subject")) {
                        subj = it.value();
                        previousKey.clear();
                    } else if (key == QLatin1Literal("body")) {
                        body = it.value();
                        previousKey = key;
                    } else if (key == QLatin1Literal("in-reply-to")) {
                        inReplyTo = it.value();
                        previousKey.clear();
                    } else if (key == QLatin1Literal("attachment") || key == QLatin1Literal("attach")) {
                        if (!it->isEmpty()) {
                            attachURLs << makeAbsoluteUrl(*it, workingDir);
                        }
                        previousKey.clear();
                    } else {
                        qCWarning(KMAIL_LOG) << "unknown key" << key;
                        //Workaround: https://bugs.kde.org/show_bug.cgi?id=390939
                        //QMap<QString, QString> parseMailtoUrl(const QUrl &url) parses correctly url
                        //But if we have a "&" unknown key we lost it.
                        if (previousKey == QLatin1Literal("body")) {
                            body += QLatin1Char('&') + key + QLatin1Char('=') + it.value();
                        }
                        previousKey.clear();
                    }
                }
            } else {
                QUrl url(arg);
                if (url.isValid() && !url.scheme().isEmpty()) {
                    attachURLs += url;
                } else {
                    to += arg + QStringLiteral(", ");
                }
            }
            mailto = true;
        }
```

#### AUTO 


```{c}
auto action = new QAction(QIcon::fromTheme(QStringLiteral("list-resource-add")), i18n("&Add Account..."), this);
```

#### AUTO 


```{c}
auto *layout = new QHBoxLayout(mFrame);
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) { d->deleteJobResult(job); }
```

#### AUTO 


```{c}
auto *mailItem = static_cast<FollowUpReminderInfoItem *>(mTreeWidget->topLevelItem(i));
```

#### AUTO 


```{c}
auto cacheIt = cache.find(msg.storageCollectionId());
```

#### AUTO 


```{c}
auto task = new ScheduledArchiveTask(this, info, Akonadi::Collection(info->saveCollectionId()), /*immediate*/ false);
```

#### AUTO 


```{c}
auto *keyEvent = static_cast<QKeyEvent *>(event);
```

#### AUTO 


```{c}
auto box = manager.unifiedMailboxFromCollection(inboxBoxCol);
```

#### AUTO 


```{c}
auto *folderLabel = new QLabel(i18n("&Folder:"), mainWidget);
```

#### AUTO 


```{c}
auto page = new MiscPage(parent);
```

#### AUTO 


```{c}
auto line_
```

#### AUTO 


```{c}
auto *md = new QMimeData;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &url : urls) {
        mRecentAction->addUrl(QUrl(url));
    }
```

#### AUTO 


```{c}
auto lay = new QHBoxLayout(mWidget);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Collection &collection : lstAddressCollection) {
        if (Akonadi::Collection::CanCreateItem & collection.rights()) {
            canCreateItemCollections.append(collection);
        }
    }
```

#### AUTO 


```{c}
auto *msgContent = new KMime::Content;
```

#### LAMBDA EXPRESSION 


```{c}
[this, finishedCb = std::move(finishedCb)]() {
                saveBoxes();
                if (finishedCb) {
                    finishedCb();
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::AgentInstance &type : lst) {
        if (type.status() == Akonadi::AgentInstance::Broken) {
            continue;
        }
        const QString typeIdentifier(type.identifier());
        if (PimCommon::Util::isImapResource(typeIdentifier)) {
            OrgKdeAkonadiImapSettingsInterface *iface = PimCommon::Util::createImapSettingsInterface(typeIdentifier);
            if (iface && iface->isValid()) {
                const Akonadi::Collection::Id imapTrashId = iface->trashCollection();
                for (const Akonadi::Collection &collection : collectionList) {
                    const Akonadi::Collection::Id collectionId = collection.id();
                    if (imapTrashId == collectionId) {
                        //Use default trash
                        iface->setTrashCollection(CommonKernel->trashCollectionFolder().id());
                        iface->save();
                        break;
                    }
                }
            }
            delete iface;
        } else if (typeIdentifier.contains(POP3_RESOURCE_IDENTIFIER)) {
            OrgKdeAkonadiPOP3SettingsInterface *iface = MailCommon::Util::createPop3SettingsInterface(typeIdentifier);
            if (iface->isValid()) {
                for (const Akonadi::Collection &collection : qAsConst(collectionList)) {
                    const Akonadi::Collection::Id collectionId = collection.id();
                    if (iface->targetCollection() == collectionId) {
                        //Use default inbox
                        iface->setTargetCollection(CommonKernel->inboxCollectionFolder().id());
                        iface->save();
                        break;
                    }
                }
            }
            delete iface;
        }
    }
```

#### AUTO 


```{c}
auto action = new QAction(i18n("Focus on Next Folder"), this);
```

#### AUTO 


```{c}
auto action = new QAction(i18n("Focus on Previous Message"), this);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Akonadi::Item::List &items) {
        ReplayNextOnExit replayNext(mMonitor);

        // Monitor did the heavy lifting for us and already figured out that
        // we only monitor the source collection of the Items and translated
        // it into REMOVE change.

        // This relies on Akonadi never mixing Items from different sources or
        // destination during batch-moves.
        const auto parentId = items.first().parentCollection().id();
        const auto box = unifiedMailboxForSource(parentId);
        if (!box) {
            qCWarning(UNIFIEDMAILBOXAGENT_LOG) << "Received Remove notification for Items belonging to" << parentId << "which we don't monitor";
            return;
        }
        if (box->collectionId() <= -1) {
            qCWarning(UNIFIEDMAILBOXAGENT_LOG) << "Missing box->collection mapping for unified mailbox" << box->id();
            return;
        }

        new Akonadi::UnlinkJob(Akonadi::Collection{box->collectionId()}, items, this);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (MessageViewer::MessageViewerCheckBeforeDeletingPlugin *plugin : lstPlugin) {
        if (plugin->isEnabled()) {
            auto interface = static_cast<MessageViewer::MessageViewerCheckBeforeDeletingInterface *>(plugin->createInterface(this));
            interface->setParentWidget(mParentWidget);
            mListPluginInterface.append(interface);
        }
    }
```

#### AUTO 


```{c}
auto *identity = new KIdentityManagement::IdentityCombo(kmkernel->identityManager(),
                                                            mHeadersArea);
```

#### AUTO 


```{c}
auto itemFetchJob = new Akonadi::ItemFetchJob(selectedMessages, this);
```

#### AUTO 


```{c}
auto l = new QVBoxLayout(this);
```

#### LAMBDA EXPRESSION 


```{c}
[=](const Akonadi::Item::List &items) {
            m_filterManager->applySpecificFilters(items, requires, listFilters);
        }
```

#### AUTO 


```{c}
auto *hbox = new QHBoxLayout(this);
```

#### AUTO 


```{c}
auto *page = new AppearancePage(parent);
```

#### LAMBDA EXPRESSION 


```{c}
[type](const Akonadi::Collection::List &cols) {
        if (cols.count() != 1) {
            qCWarning(UNIFIEDMAILBOXAGENT_LOG) << "Identity special collection retrieval did not find a valid collection";
            return;
        }
        Akonadi::SpecialMailCollections::self()->registerCollection(type, cols.first());
    }
```

#### AUTO 


```{c}
auto action = new QAction(QIcon::fromTheme(QStringLiteral("preferences-desktop-notification")),
                                      i18n("Configure &Notifications..."), this);
```

#### AUTO 


```{c}
auto v = new QVBoxLayout(mMainWidget);
```

#### AUTO 


```{c}
auto mShareButton = new QPushButton(i18n("Share..."), this);
```

#### AUTO 


```{c}
auto action = new QAction(i18nc("View->", "Ex&pand All Threads"), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (KMainWindow *window : lst) {
        if (auto win = ::qobject_cast<KMail::Composer *>(window)) {
            win->autoSaveMessage(true);

            while (win->isComposing()) {
                qCWarning(KMAIL_LOG) << "Danger, using an event loop, this should no longer be happening!";
                qApp->processEvents();
            }
        }
    }
```

#### AUTO 


```{c}
auto action = new QAction(i18n("Select First Message"), this);
```

#### AUTO 


```{c}
auto *handle = new WinObjBrushHandle;
```

#### AUTO 


```{c}
auto *w = new searchdbustest;
```

#### RANGE FOR STATEMENT 


```{c}
for (qint64 id : colIds) {
        auto ifj = new Akonadi::ItemFetchJob{ Akonadi::Collection{ id }, this };
        ifj->setDeliveryOption(Akonadi::ItemFetchJob::EmitItemsInBatches);
        connect(ifj, &Akonadi::ItemFetchJob::itemsReceived,
                this, [=](const Akonadi::Item::List &items) {
                    m_filterManager->applySpecificFilters(items, requires, listFilters);
                });
    }
```

#### AUTO 


```{c}
const auto listItems = mTreeWidget->selectedItems();
```

#### AUTO 


```{c}
auto openCommand = new KMOpenMsgCommand(nullptr, url);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Collection &collection : allFolders) {
                    KConfigGroup config(KMKernel::self()->config(), MailCommon::FolderSettings::configGroupName(collection));
                    //Old config
                    config.deleteEntry("htmlMailOverride");
                    config.deleteEntry("displayFormatOverride");
                    MailCommon::FolderSettings::resetHtmlFormat();
                }
```

#### AUTO 


```{c}
const auto &identity
```

#### RANGE FOR STATEMENT 


```{c}
for (const PimCommon::PluginUtilData &data : std::as_const(mPluginUtilDataList)) {
                if (data.mIdentifier == identifier) {
                    auto instance = Akonadi::AgentManager::self()->instance(identifier);
                    if (instance.isValid()) {
                        instance.configure(this);
                    }
                    break;
                }
            }
```

#### AUTO 


```{c}
auto *user1Button = new QPushButton;
```

#### AUTO 


```{c}
const auto sentAttribute = item.attribute<MailTransport::SentBehaviourAttribute>();
```

#### LAMBDA EXPRESSION 


```{c}
[](const Akonadi::Item &lhs, const Akonadi::Item &rhs) {
                return lhs.storageCollectionId() < rhs.storageCollectionId();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (MessageComposer::PluginEditorInterface *interface : qAsConst(mListPluginInterface)) {
            const MessageComposer::ActionType actionType = interface->actionType();
            MessageComposer::ActionType::Type type = actionType.type();
            const bool needSelectedText = interface->needSelectedText();
            if (needSelectedText) {
                //Disable by default as we don't have selection by default.
                actionType.action()->setEnabled(false);
                connect(this, &KMailPluginEditorManagerInterface::textSelectionChanged, actionType.action(), &QAction::setEnabled);
            }
            QList<QAction *> lst = mActionHash.value(type);
            if (!lst.isEmpty()) {
                QAction *act = new QAction(this);
                act->setSeparator(true);
                lst << act << actionType.action();
                mActionHash.insert(type, lst);
            } else {
                mActionHash.insert(type, QList<QAction *>() << actionType.action());
            }
            if (interface->plugin()->hasPopupMenuSupport()) {
                type = MessageComposer::ActionType::PopupMenu;
                QList<QAction *> lst = mActionHash.value(type);
                if (!lst.isEmpty()) {
                    QAction *act = new QAction(this);
                    act->setSeparator(true);
                    lst << act << actionType.action();
                    mActionHash.insert(type, lst);
                } else {
                    mActionHash.insert(type, QList<QAction *>() << actionType.action());
                }
            }
            if (interface->plugin()->hasToolBarSupport()) {
                type = MessageComposer::ActionType::ToolBar;
                QList<QAction *> lst = mActionHash.value(type);
                if (!lst.isEmpty()) {
                    QAction *act = new QAction(this);
                    act->setSeparator(true);
                    lst << act << actionType.action();
                    mActionHash.insert(type, lst);
                } else {
                    mActionHash.insert(type, QList<QAction *>() << actionType.action());
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (FollowUpReminderInfo *info : std::as_const(mFollowUpReminderInfoList)) {
        qCDebug(FOLLOWUPREMINDERAGENT_LOG) << "FollowUpReminderManager::slotCheckFollowUpFinished info:" << info;
        if (!info) {
            continue;
        }
        if (info->messageId() == messageId) {
            info->setAnswerMessageItemId(id);
            info->setAnswerWasReceived(true);
            answerReceived(info->to());
            if (info->todoId() != -1) {
                auto job = new FollowUpReminderFinishTaskJob(info->todoId(), this);
                connect(job, &FollowUpReminderFinishTaskJob::finishTaskDone, this, &FollowUpReminderManager::slotFinishTaskDone);
                connect(job, &FollowUpReminderFinishTaskJob::finishTaskFailed, this, &FollowUpReminderManager::slotFinishTaskFailed);
                job->start();
            }
            // Save item
            FollowUpReminder::FollowUpReminderUtil::writeFollowupReminderInfo(FollowUpReminder::FollowUpReminderUtil::defaultConfig(), info, true);
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (FolderArchiveAccountInfo *info : qAsConst(mListAccountInfo)) {
        if (info->instanceName() == instanceName) {
            mListAccountInfo.removeAll(info);
            removeInfo(instanceName);
            break;
        }
    }
```

#### AUTO 


```{c}
auto *kiojob = qobject_cast<KIO::Job *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Collection &collection : lstAddressCollection) {
        if (Akonadi::Collection::CanCreateItem &collection.rights()) {
            canCreateItemCollections.append(collection);
        }
    }
```

#### AUTO 


```{c}
auto act = new QAction(topMenu);
```

#### AUTO 


```{c}
auto *archiveItem = static_cast<ArchiveMailItem *>(item);
```

#### RANGE FOR STATEMENT 


```{c}
for (StandardMailActionManager::Type mailAction : mailActions) {
        mAkonadiStandardActionManager->createAction(mailAction);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &col : cols) {
                    new Akonadi::CollectionDeleteJob(col, this);
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Collection &col : qAsConst(cols)) {
        const qlonglong num = KMKernel::self()->indexedItems()->indexedItems((qlonglong)col.id());
        if (col.statistics().count() != num) {
            results.push_back(col.id());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (ArchiveMailInfo *info : lst) {
            if (info->saveCollectionId() == id) {
                mListArchiveInfo.removeAll(info);
            }
        }
```

#### AUTO 


```{c}
const auto searchJob = qobject_cast<Akonadi::SearchCreateJob *>(job)
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        initializeFilterActions(true);
    }
```

#### AUTO 


```{c}
auto callWatcher = new QDBusPendingCallWatcher(listNamesCall, this);
```

#### AUTO 


```{c}
auto templatesTab = new TemplatesTab();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &alias : aliases) {
        if (alias.trimmed().isEmpty()) {
            continue;
        }
        if (alias == email) {
            continue;
        }
        result.append(alias);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Tag &tag : qAsConst(mCreatedTags)) {
                if (item.hasTag(tag)) {
                    item.clearTag(tag);
                } else {
                    item.setTag(tag);
                }
            }
```

#### AUTO 


```{c}
auto win = static_cast<KMMainWin *>(ktmw);
```

#### AUTO 


```{c}
auto *page_vlay = new QVBoxLayout(page);
```

#### AUTO 


```{c}
auto info = new UndoInfo;
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Collection &col : cols) {
        const QModelIndex colIdx = Akonadi::EntityTreeModel::modelIndexForCollection(etm, col);
        if (col.statistics().count() > -1) {
            if (col.cachePolicy().localParts().contains(QLatin1String("RFC822"))) {
                result.push_back(col);
            }
        } else {
            const auto collection = etm->data(colIdx, Akonadi::EntityTreeModel::CollectionRole).value<Akonadi::Collection>();
            if (!collection.hasAttribute<Akonadi::EntityHiddenAttribute>() && collection.cachePolicy().localParts().contains(QLatin1String("RFC822"))) {
                result.push_back(collection);
            }
        }

        const int childrenCount = etm->rowCount(colIdx);
        if (childrenCount > 0) {
            Akonadi::Collection::List subCols;
            subCols.reserve(childrenCount);
            for (int i = 0; i < childrenCount; ++i) {
                const QModelIndex idx = etm->index(i, 0, colIdx);
                const auto child = etm->data(idx, Akonadi::EntityTreeModel::CollectionRole).value<Akonadi::Collection>();
                if (child.cachePolicy().localParts().contains(QLatin1String("RFC822"))) {
                    subCols.push_back(child);
                }
            }

            result += searchCollectionsRecursive(subCols);
        }
    }
```

#### AUTO 


```{c}
auto filterAction = filterToAction(filter);
```

#### AUTO 


```{c}
auto hrd = newMsg->headerByType("X-KMail-Identity")
```

#### AUTO 


```{c}
auto sendingTab = new AccountsPageSendingTab();
```

#### AUTO 


```{c}
auto canvas = new QWidget(parentWidget);
```

#### AUTO 


```{c}
const auto answer = KMessageBox::questionYesNo(
                             this, i18n("You have more than one email account set up. Do you want to enable the Unified Mailbox feature to "
                                        "show unified content of your inbox, sent and drafts folders?\n"
                                        "You can configure unified mailboxes, create custom ones or disable the feature completely in KMail's Plugin settings."),
                             i18n("Enable Unified Mailboxes?"),
                             KGuiItem(i18n("Enable Unified Mailboxes"), QStringLiteral("dialog-ok")),
                             KGuiItem(i18n("Cancel"), QStringLiteral("dialog-cancel")));
```

#### AUTO 


```{c}
auto action = new QAction(QIcon::fromTheme(QStringLiteral("mail-queue")), i18n("Send &Later"), this);
```

#### AUTO 


```{c}
auto hdr = mMsg->headerByType("X-KMail-SignatureActionEnabled")
```

#### AUTO 


```{c}
auto aggregationLayout = new QHBoxLayout();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &addr : lst) {
                if (!mComposerBase->recipientsEditor()->addRecipient(addr, MessageComposer::Recipient::Bcc)) {
                    qCWarning(KMAIL_LOG) << "Impossible to add bcc entry";
                }
            }
```

#### AUTO 


```{c}
auto mailbox = createUnifiedMailbox(QStringLiteral("Test1"), QStringLiteral("Test 1"),
                                            { QStringLiteral("res1_foo"), QStringLiteral("res2_foo") });
```

#### AUTO 


```{c}
auto delJob = new Akonadi::CollectionDeleteJob(inboxSourceCol, this);
```

#### AUTO 


```{c}
auto command = new KMMoveCommand(col, mListItem, -1);
```

#### AUTO 


```{c}
auto f = new QFormLayout;
```

#### AUTO 


```{c}
auto *advancedMainLayout = new QVBoxLayout(tab);
```

#### AUTO 


```{c}
auto *action = new QAction(i.key(), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (ArchiveMailInfo *oldInfo : qAsConst(mListArchiveInfo)) {
                if (oldInfo->saveCollectionId() == info->saveCollectionId()) {
                    //already in jobscheduler
                    delete info;
                    info = nullptr;
                    break;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : lstItems) {
        const KMime::Message::Ptr msg = MessageComposer::Util::message(item);
        if (!msg) {
            return Failed;
        }
        MessageFactoryNG factory(msg, item.id(), CommonKernel->collectionFromId(item.parentCollection().id()));
        factory.setIdentityManager(KMKernel::self()->identityManager());
        factory.setFolderIdentity(MailCommon::Util::folderIdentity(item));

        if (transportId == -1) {
            const MailTransport::TransportAttribute *transportAttribute = item.attribute<MailTransport::TransportAttribute>();
            if (transportAttribute) {
                transportId = transportAttribute->transportId();
                const MailTransport::Transport *transport = MailTransport::TransportManager::self()->transportById(transportId);
                if (!transport) {
                    transportId = -1;
                }
            }
        }

        const MailTransport::SentBehaviourAttribute *sentAttribute = item.attribute<MailTransport::SentBehaviourAttribute>();
        QString fcc;
        if (sentAttribute && (sentAttribute->sentBehaviour() == MailTransport::SentBehaviourAttribute::MoveToCollection)) {
            fcc = QString::number(sentAttribute->moveToCollection().id());
        }

        const KMime::Message::Ptr newMsg = factory.createRedirect(to, cc, bcc, transportId, fcc, identity);
        if (!newMsg) {
            return Failed;
        }

        MessageStatus status;
        status.setStatusFromFlags(item.flags());
        if (!status.isRead()) {
            FilterAction::sendMDN(item, KMime::MDN::Dispatched);
        }

        if (!kmkernel->msgSender()->send(newMsg, method)) {
            qCDebug(KMAIL_LOG) << "KMRedirectCommand: could not redirect message (sending failed)";
            return Failed; // error: couldn't send
        }
    }
```

#### AUTO 


```{c}
auto *job = new PotentialPhishingEmailJob;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &arg : parser.positionalArguments()) {
            if (arg.startsWith(QLatin1String("mailto:"), Qt::CaseInsensitive)) {
                const QUrl urlDecoded(QUrl::fromPercentEncoding(arg.toUtf8()));
                QMap<QString, QString> values = MessageCore::StringUtil::parseMailtoUrl(urlDecoded);
                QString previousKey;
                for (auto it = values.cbegin(), end = values.cend(); it != end; ++it) {
                    const QString key = it.key().toLower();
                    if (key == QLatin1Literal("to")) {
                        if (!it->isEmpty()) {
                            to += *it + QStringLiteral(", ");
                        }
                        previousKey.clear();
                    } else if (key == QLatin1Literal("cc")) {
                        if (!it->isEmpty()) {
                            cc += *it + QStringLiteral(", ");
                        }
                        previousKey.clear();
                    } else if (key == QLatin1Literal("bcc")) {
                        if (!it->isEmpty()) {
                            bcc += *it + QStringLiteral(", ");
                        }
                        previousKey.clear();
                    } else if (key == QLatin1Literal("subject")) {
                        subj = it.value();
                        previousKey.clear();
                    } else if (key == QLatin1Literal("body")) {
                        body = it.value();
                        previousKey = key;
                    } else if (key == QLatin1Literal("in-reply-to")) {
                        inReplyTo = it.value();
                        previousKey.clear();
                    } else if (key == QLatin1Literal("attachment") || key == QLatin1Literal("attach")) {
                        if (!it->isEmpty()) {
                            attachURLs << makeAbsoluteUrl(*it, workingDir);
                        }
                        previousKey.clear();
                    } else {
                        qCWarning(KMAIL_LOG) << "unknown key" << key;
                        //Workaround: https://bugs.kde.org/show_bug.cgi?id=390939
                        //QMap<QString, QString> parseMailtoUrl(const QUrl &url) parses correctly url
                        //But if we have a "&" unknown key we lost it.
                        if (previousKey == QLatin1Literal("body")) {
                            body += QLatin1Char('&') + key + QLatin1Char('=') + it.value();
                        }
                        previousKey.clear();
                    }
                }
            } else {
                QUrl url(arg);
                if (url.isValid() && !url.scheme().isEmpty()) {
                    attachURLs += url;
                } else {
                    to += arg + QStringLiteral(", ");
                }
            }
            mailto = true;
        }
```

#### AUTO 


```{c}
const auto parentId = items.first().parentCollection().id();
```

#### AUTO 


```{c}
auto *modifyJob = new Akonadi::ItemModifyJob(itemsToModify, this);
```

#### AUTO 


```{c}
auto job = new Akonadi::ItemFetchJob(item, this);
```

#### AUTO 


```{c}
auto radio = new QRadioButton(buttonLabel, mDateDisplayBox);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto source : sources) {
        const auto index = Akonadi::EntityTreeModel::modelIndexForCollection(selectionModel->model(), Akonadi::Collection(source));
        selectionModel->select(index, QItemSelectionModel::Select);
    }
```

#### AUTO 


```{c}
auto *openWithAct = new QAction(menu);
```

#### AUTO 


```{c}
auto agent = Akonadi::AgentManager::self()->instance(QStringLiteral("akonadi_followupreminder_agent"));
```

#### AUTO 


```{c}
const auto inboxBoxCol = createCollection(Common::InboxBoxId, parentCol, deleter);
```

#### AUTO 


```{c}
auto group = config()->group(myConfigGroupName);
```

#### AUTO 


```{c}
const auto col = CommonKernel->collectionFromId(mSettings.item.parentCollection().id());
```

#### AUTO 


```{c}
auto *addremovegrid = new QHBoxLayout();
```

#### AUTO 


```{c}
auto fetchJob = qobject_cast<Akonadi::ItemFetchJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &it : lst) {
        // qCDebug(KMAIL_LOG)<<" item ::"<<tmpItem;
        if (it.isValid()) {
            bool myStatus;
            Akonadi::MessageStatus itemStatus;
            itemStatus.setStatusFromFlags(it.flags());
            if (itemStatus & Akonadi::MessageStatus::statusToAct()) {
                myStatus = true;
            } else {
                myStatus = false;
            }
            if (myStatus != parentStatus) {
                continue;
            }
        }
        Akonadi::Item item(it);
        const Akonadi::Item::Flag flag = *(Akonadi::MessageStatus::statusToAct().statusFlags().begin());
        if (item.hasFlag(flag)) {
            item.clearFlag(flag);
            itemsToModify.push_back(item);
            if (item.hasAttribute<TaskAttribute>()) {
                // Change todo as done.
                item.removeAttribute<TaskAttribute>();
            }
        } else {
            item.setFlag(flag);
            itemsToModify.push_back(item);
            // TODO add TaskAttribute();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *a : std::as_const(mFilterFolderMenuActions)) {
        actionCollection()->removeAction(a);
    }
```

#### AUTO 


```{c}
auto iconHLayout = new QHBoxLayout();
```

#### AUTO 


```{c}
auto transport = new MailTransport::TransportComboBox(mHeadersArea);
```

#### AUTO 


```{c}
auto drag = new QDrag(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Akonadi::Item::List &items) {
        ReplayNextOnExit replayNext(mMonitor);

        // Monitor did the heavy lifting for us and already figured out that
        // we only monitor the source collection of the Items and translated
        // it into REMOVE change.

        // This relies on Akonadi never mixing Items from different sources or
        // destination during batch-moves.
        const auto parentId = items.first().parentCollection().id();
        const auto box = unifiedMailboxForSource(parentId);
        if (!box) {
            qCWarning(UNIFIEDMAILBOXAGENT_LOG) << "Received Remove notification for Items belonging to" << parentId << "which we don't monitor";
            return;
        }
        if (!box->collectionId()) {
            qCWarning(UNIFIEDMAILBOXAGENT_LOG) << "Missing box->collection mapping for unified mailbox" << box->id();
            return;
        }

        new Akonadi::UnlinkJob(Akonadi::Collection{box->collectionId().value()}, items, this);
    }
```

#### AUTO 


```{c}
auto attachmentsTab = new AttachmentsTab();
```

#### AUTO 


```{c}
auto bg = new QButtonGroup(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : indexes) {
        const Akonadi::Collection collection = index.data(Akonadi::EntityTreeModel::CollectionRole).value<Akonadi::Collection>();
        if (collection.isValid()) {
            collections << collection;
        }
    }
```

#### AUTO 


```{c}
auto group = new QGroupBox(i18nc("General options for the message list.", "General"), this);
```

#### AUTO 


```{c}
auto action = new QAction(i18n("&Import from another Email Client..."), this);
```

#### AUTO 


```{c}
auto keyEvent = static_cast<QKeyEvent *>(event);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Akonadi::Item::List &items, const Akonadi::Collection &srcCollection,
                         const Akonadi::Collection &dstCollection) {
                ReplayNextOnExit replayNext(mMonitor);

                if (const auto srcBox = unifiedMailboxForSource(srcCollection.id())) {
                    // Move source collection was our source, unlink the Item from a box
                    new Akonadi::UnlinkJob(Akonadi::Collection{srcBox->collectionId().value()}, items, this);
                }
                if (const auto dstBox = unifiedMailboxForSource(dstCollection.id())) {
                    // Move destination collection is our source, link the Item into a box
                    new Akonadi::LinkJob(Akonadi::Collection{dstBox->collectionId().value()}, items, this);
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Akonadi::Collection &col) {
        ReplayNextOnExit replayNext(mMonitor);

        if (auto box = unifiedMailboxForSource(col.id())) {
            box->removeSourceCollection(col.id());
            mMonitor.setCollectionMonitored(col, false);
            if (box->sourceCollections().isEmpty()) {
                removeBox(box->id());
            }
            saveBoxes();
            // No need to resync the box collection, the linked Items got removed by Akonadi
        } else {
            qCWarning(UNIFIEDMAILBOXAGENT_LOG) << "Received notification about removal of Collection" << col.id() << "which we don't monitor";
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (MailFilter *filter : lstFilters) {
        if (!filter->isEmpty() && filter->configureShortcut() && filter->isEnabled()) {
            QString filterName = QStringLiteral("Filter %1").arg(filter->name());
            filterName.replace(QLatin1Char(' '), QLatin1Char('_'));
            if (action(filterName)) {
                continue;
            }

            if (!addedSeparator) {
                QAction *a = mApplyFilterActionsMenu->menu()->addSeparator();
                mFilterMenuActions.append(a);
                a = mApplyFilterFolderActionsMenu->menu()->addSeparator();
                mFilterFolderMenuActions.append(a);
                a = mApplyFilterFolderRecursiveActionsMenu->menu()->addSeparator();
                mFilterFolderMenuRecursiveActions.append(a);
                addedSeparator = true;
            }

            auto filterCommand = new KMMetaFilterActionCommand(filter->identifier(), this);
            mFilterCommands.append(filterCommand);

            auto filterAction = filterToAction(filter);
            actionCollection()->addAction(filterName, filterAction);
            connect(filterAction, &QAction::triggered, filterCommand, &KMMetaFilterActionCommand::start);
            actionCollection()->setDefaultShortcut(filterAction, filter->shortcut());
            mApplyFilterActionsMenu->menu()->addAction(filterAction);
            mFilterMenuActions.append(filterAction);
            if (filter->configureToolbar()) {
                mFilterTBarActions.append(filterAction);
            }

            filterAction = filterToAction(filter);
            actionCollection()->addAction(filterName + QStringLiteral("___folder"), filterAction);
            connect(filterAction, &QAction::triggered, this, [this] {
                slotApplyFilterOnFolder(/* recursive */ false);
            });
            mApplyFilterFolderActionsMenu->menu()->addAction(filterAction);
            mFilterFolderMenuActions.append(filterAction);

            filterAction = filterToAction(filter);
            actionCollection()->addAction(filterName + QStringLiteral("___folder_recursive"), filterAction);
            connect(filterAction, &QAction::triggered, this, [this] {
                slotApplyFilterOnFolder(/* recursive */ true);
            });
            mApplyFilterFolderRecursiveActionsMenu->menu()->addAction(filterAction);
            mFilterFolderMenuRecursiveActions.append(filterAction);
        }
    }
```

#### AUTO 


```{c}
auto *vbox = new QVBoxLayout;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &arg : parser.positionalArguments()) {
            if (arg.startsWith(QStringLiteral("mailto:"), Qt::CaseInsensitive)) {
                QMap<QString, QString> values = MessageCore::StringUtil::parseMailtoUrl(QUrl::fromUserInput(arg));
                if (!values.value(QStringLiteral("to")).isEmpty()) {
                    to += values.value(QStringLiteral("to")) + QStringLiteral(", ");
                }
                if (!values.value(QStringLiteral("cc")).isEmpty()) {
                    cc += values.value(QStringLiteral("cc")) + QStringLiteral(", ");
                }
                if (!values.value(QStringLiteral("subject")).isEmpty()) {
                    subj = values.value(QStringLiteral("subject"));
                }
                if (!values.value(QStringLiteral("body")).isEmpty()) {
                    body = values.value(QStringLiteral("body"));
                }
                if (!values.value(QStringLiteral("in-reply-to")).isEmpty()) {
                    inReplyTo = values.value(QStringLiteral("in-reply-to"));
                }
                const QString attach = values.value(QStringLiteral("attachment"));
                if (!attach.isEmpty()) {
                    attachURLs << makeAbsoluteUrl(attach);
                }
            } else {
                KUrl url(arg);
                if (url.isValid() && !url.scheme().isEmpty()) {
                    attachURLs += url;
                } else {
                    to += arg + QStringLiteral(", ");
                }
            }
            mailto = true;
        }
```

#### AUTO 


```{c}
auto job = new Akonadi::CollectionFetchJob(col, Akonadi::CollectionFetchJob::FirstLevel);
```

#### RANGE FOR STATEMENT 


```{c}
for (SendLater::SendLaterInfo *info : qAsConst(mListSendLaterInfo)) {
            if (!infoStr.isEmpty()) {
                infoStr += QLatin1Char('\n');
            }
            infoStr += infoToStr(info);
        }
```

#### AUTO 


```{c}
auto handle = new WinObjBrushHandle;
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Collection &col : searchCols) {
            QAbstractItemModel *etm = KMKernel::self()->collectionModel();
            const QModelIndex idx = Akonadi::EntityTreeModel::modelIndexForCollection(etm, col);
            const auto modelCol = etm->data(idx, Akonadi::EntityTreeModel::CollectionRole).value<Akonadi::Collection>();
            // Only index offline IMAP collections
            if (PimCommon::Util::isImapResource(modelCol.resource()) && !modelCol.cachePolicy().localParts().contains(QLatin1String("RFC822"))) {
                continue;
            } else {
                cols.push_back(modelCol);
            }
        }
```

#### AUTO 


```{c}
const auto it = mMailboxes.find(col.name());
```

#### AUTO 


```{c}
auto dukeOfMonmoth = new QAction(i18n("&Display Message"), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : items) {
        if (mManager->itemRemoved(item.id())) {
            needToReload = true;
        }
    }
```

#### AUTO 


```{c}
auto hdr = mMsg->headerByType("X-KMail-QuotePrefix")
```

#### AUTO 


```{c}
auto folderToolTipsNeverRadio = new QRadioButton(i18n("Never"), mFolderToolTipsGroupBox);
```

#### RANGE FOR STATEMENT 


```{c}
for (qint64 col : unindexedCollections) {
            mFilterCollections.insert(col, true);
        }
```

#### AUTO 


```{c}
auto *job = new Akonadi::ItemFetchJob(mItem);
```

#### AUTO 


```{c}
auto it = values.cbegin(), end = values.cend();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &i : qAsConst(mItem)) {
        Akonadi::Item item(i);
        if (mMode == CleanExistingAndAddNew) {
            //WorkAround. ClearTags doesn't work.
            const Akonadi::Tag::List lstTags = item.tags();
            for (const Akonadi::Tag &tag : lstTags) {
                item.clearTag(tag);
            }
            //item.clearTags();
        }

        if (mMode == KMSetTagCommand::Toggle) {
            for (const Akonadi::Tag &tag : qAsConst(mCreatedTags)) {
                if (item.hasTag(tag)) {
                    item.clearTag(tag);
                } else {
                    item.setTag(tag);
                }
            }
        } else {
            if (!mCreatedTags.isEmpty()) {
                item.setTags(mCreatedTags);
            }
        }
        itemsToModify << item;
    }
```

#### AUTO 


```{c}
auto *job = new Akonadi::OpenEmailAddressJob(emailString, mMainWindow, this);
```

#### AUTO 


```{c}
auto action = new QAction(i18n("&Debug Sieve..."), this);
```

#### AUTO 


```{c}
auto notify = new KNotification(QStringLiteral("mailfilterjoberror"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Collection &col : qAsConst(mCollectionId)) {
            searchCollections << col;
        }
```

#### AUTO 


```{c}
auto *layout = new QHBoxLayout;
```

#### RANGE FOR STATEMENT 


```{c}
for (const PimCommon::PluginUtilData &data : qAsConst(mPluginUtilDataList)) {
                if (data.mIdentifier == identifier) {
                    const QString service = Akonadi::ServerManager::agentServiceName(Akonadi::ServerManager::Agent, data.mExtraInfo.at(0));
                    QDBusInterface interface(service, data.mExtraInfo.at(1));
                    if (interface.isValid()) {
                        interface.call(QStringLiteral("showConfigureDialog"), (qlonglong)winId());
                    } else {
                        qCDebug(KMAIL_LOG) << " interface does not exist when trying to configure the plugin";
                    }
                    break;
                }
            }
```

#### AUTO 


```{c}
auto inviteTab = new InviteTab();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::AgentType &type : lstAgent) {
        if (type.identifier() == interfaceName) {
            data.mExtraInfo << interfaceName;
            data.mExtraInfo << path;
            bool failed = false;
            const bool enabled = agentActivateState(interfaceName, path, failed);
            data.mEnableByDefault = enabled;
            data.mName = type.name();
            data.mDescription = type.description();
            data.mIdentifier = type.identifier();
            break;
        }
    }
```

#### AUTO 


```{c}
auto noAnswerInfo = new FollowUpReminderInfo(*info);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &i : qAsConst(mItem)) {
        Akonadi::Item item(i);
        if (mMode == CleanExistingAndAddNew) {
            //WorkAround. ClearTags doesn't work.
            Q_FOREACH (const Akonadi::Tag &tag, item.tags()) {
                item.clearTag(tag);
            }
            //item.clearTags();
        }

        if (mMode == KMSetTagCommand::Toggle) {
            Q_FOREACH (const Akonadi::Tag &tag, mCreatedTags) {
                if (item.hasTag(tag)) {
                    item.clearTag(tag);
                } else {
                    item.setTag(tag);
                }
            }
        } else {
            if (!mCreatedTags.isEmpty()) {
                item.setTags(mCreatedTags);
            }
        }
        itemsToModify << item;
    }
```

#### AUTO 


```{c}
auto about = new KAboutData(QStringLiteral("kcmkmailsummary"),
                                i18n("kcmkmailsummary"),
                                QString(),
                                i18n("Mail Summary Configuration Dialog"),
                                KAboutLicense::GPL,
                                i18n("Copyright � 2004�2010 Tobias Koenig"));
```

#### RANGE FOR STATEMENT 


```{c}
for (MessageComposer::PluginEditorConvertTextInterface *interface : std::as_const(mListPluginInterface)) {
        interface->enableDisablePluginActions(richText);
    }
```

#### AUTO 


```{c}
static const auto DraftsBoxId = QStringLiteral("drafts");
```

#### AUTO 


```{c}
auto inbox = std::make_unique<UnifiedMailbox>();
```

#### AUTO 


```{c}
auto job = new Akonadi::AddEmailAddressJob(emailString, mMainWindow, this);
```

#### AUTO 


```{c}
auto label = new QLabel(i18n("This list is checked for every outgoing message "
                                    "from the top to the bottom for a charset that "
                                    "contains all required characters."), this);
```

#### AUTO 


```{c}
const auto mboxSelected = view->selectionModel()->selectedIndexes();
```

#### AUTO 


```{c}
auto label = new QLabel(i18n("&Existing identities:"), page);
```

#### AUTO 


```{c}
auto displayAttr = topLevel.attribute<Akonadi::EntityDisplayAttribute>(Akonadi::Collection::AddIfMissing);
```

#### AUTO 


```{c}
auto *document = new QTextDocument(nullptr);
```

#### AUTO 


```{c}
auto printingTab = new MiscPagePrintingTab();
```

#### AUTO 


```{c}
auto *mailItem = static_cast<FollowUpReminderInfoItem *>(item);
```

#### RANGE FOR STATEMENT 


```{c}
for (const MailCommon::Tag::Ptr &tag : qAsConst(msgTagList)) {
        TagListWidgetItem *newItem = new TagListWidgetItem(QIcon::fromTheme(tag->iconName), tag->tagName, mTagListBox);
        newItem->setKMailTag(tag);
        if (tag->priority == -1) {
            tag->priority = mTagListBox->count() - 1;
        }
    }
```

#### AUTO 


```{c}
auto command = new KMPrintCommand(this, commandInfo);
```

#### AUTO 


```{c}
auto fetchCollection = new Akonadi::CollectionFetchJob(Akonadi::Collection(id), Akonadi::CollectionFetchJob::Base);
```

#### AUTO 


```{c}
auto job = qobject_cast<ReadPasswordJob *>(baseJob);
```

#### AUTO 


```{c}
auto job = new FollowUpReminderShowMessageJob(id);
```

#### AUTO 


```{c}
auto *composerCryptoTab = new ComposerCryptoTab();
```

#### AUTO 


```{c}
const auto rec = storage->getRecipient(addrSpec.toUtf8());
```

#### AUTO 


```{c}
auto *tagItem = static_cast<TagListWidgetItem *>(mTagListBox->item(i));
```

#### AUTO 


```{c}
auto command = new KMMailtoReplyCommand(mMainWindow, urlClicked(),
                                                             messageItem(), copyText());
```

#### AUTO 


```{c}
auto *sourceCombo = new QComboBox(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (KMime::Content *attach : qAsConst(fwdMsg.second)) {
        mWin->addAttach(attach);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Akonadi::Collection::List &cols) {
            if (cols.count() != 1) {
                return;
            }
            Akonadi::SpecialMailCollections::self()->unregisterCollection(cols.first());
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](const Akonadi::Collection::List &cols) {
            if (cols.count() != 1) {
                return;
            }
            Akonadi::SpecialMailCollections::self()->unregisterCollection(cols.first());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &arg : parser.positionalArguments()) {
            if (arg.startsWith(QStringLiteral("mailto:"), Qt::CaseInsensitive)) {
                QMap<QString, QString> values = MessageCore::StringUtil::parseMailtoUrl(QUrl::fromUserInput(arg));
                if (!values.value(QStringLiteral("to")).isEmpty()) {
                    to += values.value(QStringLiteral("to")) + QStringLiteral(", ");
                }
                if (!values.value(QStringLiteral("cc")).isEmpty()) {
                    cc += values.value(QStringLiteral("cc")) + QStringLiteral(", ");
                }
                if (!values.value(QStringLiteral("subject")).isEmpty()) {
                    subj = values.value(QStringLiteral("subject"));
                }
                if (!values.value(QStringLiteral("body")).isEmpty()) {
                    body = values.value(QStringLiteral("body"));
                }
                if (!values.value(QStringLiteral("in-reply-to")).isEmpty()) {
                    inReplyTo = values.value(QStringLiteral("in-reply-to"));
                }
                const QString attach = values.value(QStringLiteral("attachment"));
                if (!attach.isEmpty()) {
                    attachURLs << makeAbsoluteUrl(attach);
                }
            } else {
                QUrl url(arg);
                if (url.isValid() && !url.scheme().isEmpty()) {
                    attachURLs += url;
                } else {
                    to += arg + QStringLiteral(", ");
                }
            }
            mailto = true;
        }
```

#### AUTO 


```{c}
auto action = new QAction(i18n("Next Unread &Folder"), this);
```

#### AUTO 


```{c}
auto job = new PimCommon::ManageServerSideSubscriptionJob(this);
```

#### AUTO 


```{c}
const auto keyStatus = static_cast<CryptoKeyState>(line->property("keyStatus").toInt());
```

#### AUTO 


```{c}
auto attachmentView = new KMail::AttachmentView(attachmentModel, mSplitter);
```

#### AUTO 


```{c}
auto *fetchJob = qobject_cast<Akonadi::CollectionFetchJob *>(job);
```

#### AUTO 


```{c}
auto ident = im->defaultIdentity();
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &str) {mComposerBase->editor()->insertPlainText(str);}
```

#### AUTO 


```{c}
auto *folderLabel = new QLabel(i18n("&Folder:"), this);
```

#### AUTO 


```{c}
auto *lay = new QVBoxLayout(topWidget);
```

#### AUTO 


```{c}
auto message = messageItem.payload<KMime::Message::Ptr>();
```

#### AUTO 


```{c}
const auto box = unifiedMailboxForSource(parentId);
```

#### AUTO 


```{c}
auto autoImageResizeTab = new AutoImageResizeTab();
```

#### AUTO 


```{c}
auto app = act->data().value<KService::Ptr>();
```

#### AUTO 


```{c}
auto reloadListTimer = new QTimer(this);
```

#### AUTO 


```{c}
const auto dstBox = registerSpecialSourceCollection(col);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &alias : aliases) {
        if (!KEmailAddress::isValidSimpleAddress(alias)) {
            const QString errorMsg(KEmailAddress::simpleEmailAddressErrorMsg());
            KMessageBox::sorry(this, errorMsg, i18n("Invalid Email Alias \"%1\"", alias));
            return;
        }
    }
```

#### AUTO 


```{c}
auto hbHBoxLayout = new QHBoxLayout;
```

#### AUTO 


```{c}
auto searchLabel = dlg.findChild<QLabel *>(QStringLiteral("label"));
```

#### AUTO 


```{c}
auto *vlay = new QVBoxLayout(page);
```

#### AUTO 


```{c}
auto *sync = new Akonadi::CollectionAttributesSynchronizationJob(col);
```

#### AUTO 


```{c}
auto l = new QLabel(i18n("&New identity:"), page);
```

#### AUTO 


```{c}
auto *win = new KMMainWin;
```

#### AUTO 


```{c}
auto instance = Akonadi::AgentManager::self()->instance(mCurrentCollection.resource());
```

#### AUTO 


```{c}
auto *job = new Akonadi::ItemFetchJob(items, this);
```

#### AUTO 


```{c}
auto fetch = static_cast<Akonadi::CollectionFetchJob *>(job);
```

#### AUTO 


```{c}
auto *item = new QListWidgetItem(mListWidget);
```

#### AUTO 


```{c}
auto layout = new QGridLayout(this);
```

#### AUTO 


```{c}
const auto storage = MessageCore::AutocryptStorage::self();
```

#### AUTO 


```{c}
auto command = new KMReplyCommand(this,
                                                 currentItem,
                                                 MessageComposer::ReplyAll,
                                                 mReaderWin->copyText(),
                                                 false, tmpl);
```

#### AUTO 


```{c}
auto command = new KMReplyCommand(mParent, mCurrentItem, MessageComposer::ReplySmart, QString(), true);
```

#### AUTO 


```{c}
auto command = new KMMoveCommand(dest, selectMsg, ref);
```

#### AUTO 


```{c}
auto job = new FillComposerJob;
```

#### LAMBDA EXPRESSION 


```{c}
[&id](const std::pair<const QString, std::unique_ptr<UnifiedMailbox>> &box) {
        return box.second->id() == id;
    }
```

#### AUTO 


```{c}
auto job = new KIO::ApplicationLauncherJob(offer);
```

#### AUTO 


```{c}
auto hdr = newMsg->headerByType("Return-Receipt-To")
```

#### AUTO 


```{c}
const auto id = im->modifyIdentityForName(identityStrName);
```

#### AUTO 


```{c}
auto signature = w->findChild<QLabel *>(QStringLiteral("signatureindicator"));
```

#### RANGE FOR STATEMENT 


```{c}
for (qint64 id : colIds) {
        auto ifj = new Akonadi::ItemFetchJob{
            Akonadi::Collection{
                id
            }, this
        };
        ifj->setDeliveryOption(Akonadi::ItemFetchJob::EmitItemsInBatches);
        connect(ifj, &Akonadi::ItemFetchJob::itemsReceived,
                this, [=](const Akonadi::Item::List &items) {
            m_filterManager->applySpecificFilters(items, requiresParts, listFilters, static_cast<FilterManager::FilterSet>(filterSet));
        });
    }
```

#### AUTO 


```{c}
const auto box = mSourceToBoxMap.find(source);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::AgentInstance &type : lst) {
        if (type.status() == Akonadi::AgentInstance::Broken) {
            continue;
        }
        const QString typeIdentifier(type.identifier());
        if (PimCommon::Util::isImapResource(typeIdentifier)) {
            OrgKdeAkonadiImapSettingsInterface *iface = PimCommon::Util::createImapSettingsInterface(typeIdentifier);
            if (iface && iface->isValid()) {
                const Akonadi::Collection::Id imapTrashId = iface->trashCollection();
                for (const Akonadi::Collection &collection : collectionList) {
                    const Akonadi::Collection::Id collectionId = collection.id();
                    if (imapTrashId == collectionId) {
                        //Use default trash
                        iface->setTrashCollection(CommonKernel->trashCollectionFolder().id());
                        iface->save();
                        break;
                    }
                }
            }
            delete iface;
        } else if (typeIdentifier.contains(POP3_RESOURCE_IDENTIFIER)) {
            OrgKdeAkonadiPOP3SettingsInterface *iface = MailCommon::Util::createPop3SettingsInterface(typeIdentifier);
            if (iface->isValid()) {
                foreach (const Akonadi::Collection &collection, collectionList) {
                    const Akonadi::Collection::Id collectionId = collection.id();
                    if (iface->targetCollection() == collectionId) {
                        //Use default inbox
                        iface->setTargetCollection(CommonKernel->inboxCollectionFolder().id());
                        iface->save();
                        break;
                    }
                }
            }
            delete iface;
        }
    }
```

#### AUTO 


```{c}
const auto col = mModelProxy->data(child, Akonadi::EntityTreeModel::CollectionRole).value<Akonadi::Collection>();
```

#### AUTO 


```{c}
auto groupHBoxLayout = new QHBoxLayout(groupBox);
```

#### AUTO 


```{c}
auto job = new Akonadi::ContactSearchJob(this);
```

#### AUTO 


```{c}
auto messageIdSuffixValidator = new QRegularExpressionValidator(QRegularExpression(QStringLiteral("[a-zA-Z0-9+-]+(?:\\.[a-zA-Z0-9+-]+)*")), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &configName : configNameFiles) {
        initCleanupFolderSettings(configName);
        initCleanupFiltersSettings(configName);
        initCleanDialogSettings(configName);
        initCleanupDialogSettings(configName);
        removeTipOfDay(configName);
    }
```

#### AUTO 


```{c}
auto info = SendLaterUtil::readSendLaterInfo(group);
```

#### AUTO 


```{c}
auto *job = new FollowUpReminderShowMessageJob(id);
```

#### LAMBDA EXPRESSION 


```{c}
[this] { slotApplyFilterOnFolder(/* recursive */ false);
                    }
```

#### AUTO 


```{c}
auto ftv = ftw->folderTreeView();
```

#### AUTO 


```{c}
auto job = new Akonadi::AddEmailDisplayJob(emailString, mMainWindow, this);
```

#### AUTO 


```{c}
const auto answer = KMessageBox::questionYesNo(
                             this, i18n("You have more than one email account set up.\nDo you want to enable the Unified Mailbox feature to "
                                        "show unified content of your inbox, sent and drafts folders?\n"
                                        "You can configure unified mailboxes, create custom ones or\ndisable the feature completely in KMail's Plugin settings."),
                             i18n("Enable Unified Mailboxes?"),
                             KGuiItem(i18n("Enable Unified Mailboxes"), QStringLiteral("dialog-ok")),
                             KGuiItem(i18n("Cancel"), QStringLiteral("dialog-cancel")));
```

#### RANGE FOR STATEMENT 


```{c}
for (MessageComposer::PluginEditor *plugin : lstPlugin) {
        if (plugin->isEnabled()) {
            MessageComposer::PluginEditorInterface *interface = static_cast<MessageComposer::PluginEditorInterface *>(plugin->createInterface(this));
            MessageComposer::PluginComposerInterface *composerInterface = new MessageComposer::PluginComposerInterface;
            composerInterface->setComposerViewBase(mComposerInterface);
            interface->setComposerInterface(composerInterface);
            interface->setRichTextEditor(mRichTextEditor);
            interface->setParentWidget(mParentWidget);
            interface->createAction(mActionCollection);
            interface->setPlugin(plugin);
            connect(interface, &MessageComposer::PluginEditorInterface::emitPluginActivated, this, &KMailPluginEditorManagerInterface::slotPluginActivated);
            connect(interface, &MessageComposer::PluginEditorInterface::message, this, &KMailPluginEditorManagerInterface::message);
            connect(interface, &MessageComposer::PluginEditorInterface::insertText, this, &KMailPluginEditorManagerInterface::insertText);
            mListPluginInterface.append(interface);
        }
    }
```

#### AUTO 


```{c}
auto *dialog = new MessageComposer::SendLaterDialog(nullptr);
```

#### AUTO 


```{c}
auto action = new QAction(QIcon::fromTheme(QStringLiteral("x-office-address-book")), i18n("&Address Book"), this);
```

#### AUTO 


```{c}
const auto cols = fetch->collections();
```

#### AUTO 


```{c}
auto dlg = new Kleo::ProgressDialog(job, i18n("Generating new key pair..."), parentWidget());
```

#### RANGE FOR STATEMENT 


```{c}
for (const MailCommon::MailFilter *filter : qAsConst(d->mFilters)) {
        qCDebug(MAILFILTERAGENT_LOG) << filter->asString();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &str : filterList) {
        settingsrc->deleteGroup(str);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const UnifiedMailbox *box) {
        if (box->collectionId() <= -1) {
            qCWarning(UNIFIEDMAILBOXAGENT_LOG) << "MailboxManager wants us to update Box but does not have its CollectionId!?";
            return;
        }

        // Schedule collection sync for the box
        synchronizeCollection(box->collectionId());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &item : items) {
        // Decrypt
        if (!item.hasPayload<KMime::Message::Ptr>()) {
            continue;
        }
        const auto msg = item.payload<KMime::Message::Ptr>();
        bool wasEncrypted;
        auto decMsg = MailCommon::CryptoUtils::decryptMessage(msg, wasEncrypted);
        if (!wasEncrypted) {
            decMsg = msg;
        }

        Akonadi::Item decItem;
        decItem.setMimeType(KMime::Message::mimeType());
        decItem.setPayload(decMsg);

        auto job = new Akonadi::ItemCreateJob(decItem, mDestFolder, this);
        connect(job, &Akonadi::Job::result, this, &KMCopyDecryptedCommand::slotAppendResult);
        mPendingJobs << job;
    }
```

#### AUTO 


```{c}
const auto srcBox = unregisterSpecialSourceCollection(col.id());
```

#### AUTO 


```{c}
auto colorsTab = new AppearancePageColorsTab();
```

#### AUTO 


```{c}
auto newItem = new TagListWidgetItem(QIcon::fromTheme(tag->iconName), newTagName, mTagListBox);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &arg : lstPositionalArguments) {
            if (arg.startsWith(QLatin1String("mailto:"), Qt::CaseInsensitive)) {
                const QUrl urlDecoded(QUrl::fromPercentEncoding(arg.toUtf8()));
                const QVector<QPair<QString, QString> > values = MessageCore::StringUtil::parseMailtoUrl(urlDecoded);
                QString previousKey;
                for (int i = 0; i < values.count(); ++i) {
                    const QPair<QString, QString> element = values.at(i);
                    const QString key = element.first.toLower();
                    if (key == QLatin1String("to")) {
                        if (!element.second.isEmpty()) {
                            to += element.second + QStringLiteral(", ");
                        }
                        previousKey.clear();
                    } else if (key == QLatin1String("cc")) {
                        if (!element.second.isEmpty()) {
                            cc += element.second + QStringLiteral(", ");
                        }
                        previousKey.clear();
                    } else if (key == QLatin1String("bcc")) {
                        if (!element.second.isEmpty()) {
                            bcc += element.second + QStringLiteral(", ");
                        }
                        previousKey.clear();
                    } else if (key == QLatin1String("subject")) {
                        subj = element.second;
                        previousKey.clear();
                    } else if (key == QLatin1String("body")) {
                        body = element.second;
                        previousKey = key;
                    } else if (key == QLatin1String("in-reply-to")) {
                        inReplyTo = element.second;
                        previousKey.clear();
                    } else if (key == QLatin1String("attachment") || key == QLatin1String("attach")) {
                        if (!element.second.isEmpty()) {
                            attachURLs << makeAbsoluteUrl(element.second, workingDir);
                        }
                        previousKey.clear();
                    } else {
                        qCWarning(KMAIL_LOG) << "unknown key" << key;
                        //Workaround: https://bugs.kde.org/show_bug.cgi?id=390939
                        //QMap<QString, QString> parseMailtoUrl(const QUrl &url) parses correctly url
                        //But if we have a "&" unknown key we lost it.
                        if (previousKey == QLatin1String("body")) {
                            body += QLatin1Char('&') + key + QLatin1Char('=') + element.second;
                        }
                        //Don't clear previous key.
                    }
                }
            } else {
                QUrl url(arg);
                if (url.isValid() && !url.scheme().isEmpty()) {
                    attachURLs += url;
                } else {
                    to += arg + QStringLiteral(", ");
                }
            }
            mailto = true;
        }
```

#### AUTO 


```{c}
auto receivingTab = new ReceivingTab();
```

#### AUTO 


```{c}
const auto idx = stack.pop();
```

#### AUTO 


```{c}
auto *sa = new QScrollArea(core);
```

#### AUTO 


```{c}
auto colIt = std::find_if(cols.cbegin(), cols.cend(), [&rid](const Akonadi::Collection &col) {
            return col.remoteId() == rid;
        });
```

#### AUTO 


```{c}
auto *identityComboBox = dlg.findChild<QComboBox *>(QStringLiteral("identity_combobox"));
```

#### AUTO 


```{c}
auto *attachmentController = new KMail::AttachmentController(attachmentModel, attachmentView, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const qlonglong &id : qAsConst(mMsgListId)) {
        int diff = msgCountToFilter - ++msgCount;
        if (diff < 10 || !(msgCount % 10) || msgCount <= 10) {
            progressItem->updateProgress();
            const QString statusMsg = i18n("Filtering message %1 of %2",
                                           msgCount, msgCountToFilter);
            PimCommon::BroadcastStatus::instance()->setStatusMsg(statusMsg);
            qApp->processEvents(QEventLoop::ExcludeUserInputEvents, 50);
        }

        MailCommon::FilterManager::instance()->filter(Akonadi::Item(id), mFilterId, QString());
        progressItem->incCompletedItems();
    }
```

#### AUTO 


```{c}
auto handle = new WinObjPatternBrushHandle;
```

#### AUTO 


```{c}
auto editorGrp = mConfig->group(EditorGroup);
```

#### AUTO 


```{c}
const auto lst = mListArchiveInfo;
```

#### AUTO 


```{c}
auto command = new KMPrintCommand(mParent, commandInfo);
```

#### AUTO 


```{c}
auto topLevelDisplayAttr = topLevel.attribute<Akonadi::EntityDisplayAttribute>(Akonadi::Collection::AddIfMissing);
```

#### RANGE FOR STATEMENT 


```{c}
for (qint32 identifier : listRemove) {
        const QString groupName = FollowUpReminder::FollowUpReminderUtil::followUpReminderPattern().arg(identifier);
        const QStringList filterGroups = config->groupList();
        for (const QString &group : filterGroups) {
            if (group == groupName) {
                config->deleteGroup(group);
                --value;
                needSaveConfig = true;
            }
        }
    }
```

#### AUTO 


```{c}
auto job = new Akonadi::ItemFetchJob(Akonadi::Item(serialNumber), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &str : folderList) {
        KConfigGroup oldGroup = kmailrc->group(str);
        cleanupFolderSettings(oldGroup);
    }
```

#### AUTO 


```{c}
auto job = new AddressValidationJob(recipients.join(QLatin1String(", ")), this, this);
```

#### AUTO 


```{c}
const auto im =  mKernel->identityManager();
```

#### AUTO 


```{c}
static constexpr auto SpecialCollectionDrafts = "drafts";
```

#### AUTO 


```{c}
auto *fetchJob = static_cast<Akonadi::CollectionFetchJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &str : logEntries) {
        mTextEdit->editor()->appendHtml(str);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](const Akonadi::Item::List &items) {
            m_filterManager->applySpecificFilters(items, requiresParts, listFilters, static_cast<FilterManager::FilterSet>(filterSet));
        }
```

#### AUTO 


```{c}
auto *signature = composer->findChild<QLabel *>(QStringLiteral("signatureindicator"));
```

#### AUTO 


```{c}
auto mailItem = static_cast<FollowUpReminderInfoItem *>(item);
```

#### RANGE FOR STATEMENT 


```{c}
for (KToggleAction *ta : lstTa) {
        menu->addAction(ta);
    }
```

#### AUTO 


```{c}
auto mailItem = static_cast<SendLaterItem *>(mWidget->treeWidget->topLevelItem(i));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &source : qAsConst(mSources)) {
                mManager->mMonitor.setCollectionMonitored(Akonadi::Collection{source}, false);
                mManager->mSourceToBoxMap.erase(source);
            }
```

#### AUTO 


```{c}
auto templatesTab = new ComposerPageGeneralTab();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &group : filterGroups) {
        if (group == groupName) {
            config->deleteGroup(group);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : qAsConst(*trashIt)) {
                if (item.storageCollectionId() <= 0) {
                    continue;
                }
                if (parent.id() != item.storageCollectionId()) {
                    parent = Akonadi::Collection(item.storageCollectionId());
                    undoId = kmkernel->undoStack()->newUndoAction(parent, trash);
                }
                kmkernel->undoStack()->addMsgToAction(undoId, item);
            }
```

#### AUTO 


```{c}
auto autoCorrectionTab = new ComposerPageAutoCorrectionTab();
```

#### AUTO 


```{c}
auto w = new QWidget(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const PimCommon::PluginUtilData &data : qAsConst(mPluginUtilDataList)) {
            if (item->mIdentifier == data.mIdentifier) {
                changeAgentActiveState(data.mExtraInfo.at(0), data.mExtraInfo.at(1), item->checkState(0) == Qt::Checked);
                break;
            }
        }
```

#### AUTO 


```{c}
auto email = mCurrentItem.payload<KMime::Message::Ptr>();
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Akonadi::Collection::List &list) {
                for (const auto &col : list) {
                    if (isUnifiedMailbox(col)) {
                        continue;
                    }

                    try {
                        switch (Akonadi::SpecialMailCollections::self()->specialCollectionType(col)) {
                        case Akonadi::SpecialMailCollections::Inbox:
                            mMailboxes.at(Common::InboxBoxId)->addSourceCollection(col.id());
                            break;
                        case Akonadi::SpecialMailCollections::SentMail:
                            mMailboxes.at(Common::SentBoxId)->addSourceCollection(col.id());
                            break;
                        case Akonadi::SpecialMailCollections::Drafts:
                            mMailboxes.at(Common::DraftsBoxId)->addSourceCollection(col.id());
                            break;
                        default:
                            continue;
                        }
                    } catch (const std::out_of_range &) {
                        qCWarning(agent_log) << "Failed to find a special unified mailbox for source collection" << col.id();
                        continue;
                    }
                }
            }
```

#### AUTO 


```{c}
auto dictionaryComboBox = findChild<Sonnet::DictionaryComboBox *>(QStringLiteral("m_langCombo"));
```

#### AUTO 


```{c}
auto sync = new Akonadi::CollectionAttributesSynchronizationJob(col);
```

#### AUTO 


```{c}
auto header = new KMime::Headers::Generic("X-KMail-FccDisabled");
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &it : lstItems) {
        if (mInvertMark) {
            //qCDebug(KMAIL_LOG)<<" item ::"<<tmpItem;
            if (it.isValid()) {
                bool myStatus;
                MessageStatus itemStatus;
                itemStatus.setStatusFromFlags(it.flags());
                if (itemStatus & mStatus) {
                    myStatus = true;
                } else {
                    myStatus = false;
                }
                if (myStatus != parentStatus) {
                    continue;
                }
            }
        }
        Akonadi::Item item(it);
        const Akonadi::Item::Flag flag = *(mStatus.statusFlags().begin());
        if (mInvertMark) {
            if (item.hasFlag(flag)) {
                item.clearFlag(flag);
                itemsToModify.push_back(item);
            } else {
                item.setFlag(flag);
                itemsToModify.push_back(item);
            }
        } else {
            if (!item.hasFlag(flag)) {
                item.setFlag(flag);
                itemsToModify.push_back(item);
            }
        }
    }
```

#### AUTO 


```{c}
auto *v = new QVBoxLayout(mMainWidget);
```

#### AUTO 


```{c}
auto *recipientsEditor = new MessageComposer::RecipientsEditor(mHeadersArea);
```

#### AUTO 


```{c}
auto item = static_cast<PluginItem *>(*it);
```

#### AUTO 


```{c}
auto fetchJob = new Akonadi::CollectionFetchJob(Akonadi::Collection(1), Akonadi::CollectionFetchJob::FirstLevel);
```

#### AUTO 


```{c}
const auto ask = [this]() {
        if (!KMailSettings::self()->askEnableUnifiedMailboxes()) {
            return;
        }

        if (kmkernel->accounts().count() <= 1) {
            return;
        }

        KMailSettings::self()->setAskEnableUnifiedMailboxes(false);

        const auto service = Akonadi::ServerManager::self()->agentServiceName(Akonadi::ServerManager::Agent, QStringLiteral("akonadi_unifiedmailbox_agent"));
        QDBusInterface iface(service, QStringLiteral("/"), QStringLiteral("org.freedesktop.Akonadi.UnifiedMailboxAgent"), QDBusConnection::sessionBus(), this);
        if (!iface.isValid()) {
            return;
        }

        QDBusReply<bool> reply = iface.call(QStringLiteral("enabledAgent"));
        if (!reply.isValid() || bool(reply)) {
            return;
        }

        const auto answer = KMessageBox::questionYesNo(
            this,
            i18n("You have more than one email account set up.\nDo you want to enable the Unified Mailbox feature to "
                 "show unified content of your inbox, sent and drafts folders?\n"
                 "You can configure unified mailboxes, create custom ones or\ndisable the feature completely in KMail's Plugin settings."),
            i18n("Enable Unified Mailboxes?"),
            KGuiItem(i18n("Enable Unified Mailboxes"), QStringLiteral("dialog-ok")),
            KGuiItem(i18n("Cancel"), QStringLiteral("dialog-cancel")));
        if (answer == KMessageBox::Yes) {
            iface.call(QStringLiteral("setEnableAgent"), true);
        }
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this, view]() {
        const auto indexes = view->selectionModel()->selectedIndexes();
        if (!indexes.isEmpty()) {
            auto item = mBoxModel->itemFromIndex(indexes[0]);
            const auto mailbox = item->data().value<UnifiedMailbox *>();
            if (KMessageBox::warningYesNo(
                    this, i18n("Do you really want to remove unified mailbox <b>%1</b>?", mailbox->name()),
                    i18n("Really Remove?"), KStandardGuiItem::remove(), KStandardGuiItem::cancel()) == KMessageBox::Yes) {
                mBoxModel->removeRow(item->row());
                mBoxManager.removeBox(mailbox->id());
                mBoxManager.saveBoxes();
            }
        }
    }
```

#### AUTO 


```{c}
auto *job = new Akonadi::ItemMoveJob(retrievedList, mDestFolder, this);
```

#### AUTO 


```{c}
const auto &ident = identity();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &col : list) {
            if (isUnifiedMailbox(col)) {
                continue;
            }

            try {
                switch (Akonadi::SpecialMailCollections::self()->specialCollectionType(col)) {
                case Akonadi::SpecialMailCollections::Inbox:
                    mMailboxes.at(Common::InboxBoxId)->addSourceCollection(col.id());
                    break;
                case Akonadi::SpecialMailCollections::SentMail:
                    mMailboxes.at(Common::SentBoxId)->addSourceCollection(col.id());
                    break;
                case Akonadi::SpecialMailCollections::Drafts:
                    mMailboxes.at(Common::DraftsBoxId)->addSourceCollection(col.id());
                    break;
                default:
                    continue;
                }
            } catch (const std::out_of_range &) {
                qCWarning(UNIFIEDMAILBOXAGENT_LOG) << "Failed to find a special unified mailbox for source collection" << col.id();
                continue;
            }
        }
```

#### AUTO 


```{c}
auto *gvlay = new QVBoxLayout(group);
```

#### AUTO 


```{c}
auto favoriteFoldersViewHiddenRadio = new QRadioButton(i18n("Never"), mFavoriteFoldersViewGroupBox);
```

#### AUTO 


```{c}
const auto trash = trashIt.key();
```

#### AUTO 


```{c}
auto *job = new HandleClickedUrlJob;
```

#### AUTO 


```{c}
auto themeConfigButton = new ThemeConfigButton(group, mThemeComboBox);
```

#### AUTO 


```{c}
auto addressTypeLayout = new QHBoxLayout(addressWidget);
```

#### AUTO 


```{c}
const auto unlinkedItems = itemUnlinkedSignalSpy.at(0).at(0).value<Akonadi::Item::List>();
```

#### RANGE FOR STATEMENT 


```{c}
for (ArchiveMailInfo *info : std::as_const(mListArchiveInfo)) {
            if (!infoStr.isEmpty()) {
                infoStr += QLatin1Char('\n');
            }
            infoStr += infoToStr(info);
        }
```

#### AUTO 


```{c}
const auto sources = mMailbox->sourceCollections();
```

#### AUTO 


```{c}
auto mFromAddrbkBtn = new QPushButton(i18n("Set From Address Book"), page);
```

#### AUTO 


```{c}
auto command = new KMReplyCommand(this, msg, MessageComposer::ReplySmart, text, false, tmpl);
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : lstActs) {
        auto *subMenu = qobject_cast<KSelectAction *>(action);
        if (subMenu) {
            const QString codecNameToSet = selectCharset(subMenu, encoding);
            if (!codecNameToSet.isEmpty()) {
                return codecNameToSet;
            }
        } else {
            const QString fixedActionText = MimeTreeParser::NodeHelper::fixEncoding(action->text());
            if (KCharsets::charsets()->codecForName(
                    KCharsets::charsets()->encodingForName(fixedActionText))
                == KCharsets::charsets()->codecForName(encoding)) {
                return action->text();
            }
        }
    }
```

#### AUTO 


```{c}
auto fetch = new Akonadi::CollectionFetchJob(mFolder, Akonadi::CollectionFetchJob::Base, this);
```

#### AUTO 


```{c}
const auto idx = collectionModel()->match({}, Akonadi::EntityTreeModel::CollectionRole,
                                              QVariant::fromValue(col), 1, Qt::MatchExactly);
```

#### AUTO 


```{c}
auto line = job->property("line").value<QPointer<MessageComposer::RecipientLineNG> >();
```

#### AUTO 


```{c}
auto hdr = mMsg->headerByType("X-KMail-CryptoMessageFormat")
```

#### AUTO 


```{c}
auto *command = new KMRedirectCommand(this, currentItem);
```

#### AUTO 


```{c}
const auto boxGroup = group.group(boxGroupName);
```

#### AUTO 


```{c}
auto *job = new Akonadi::ItemMoveJob(mMsg, collection, this);
```

#### AUTO 


```{c}
auto w = interface->statusBarWidget()
```

#### AUTO 


```{c}
auto accountMenu = new QMenu(this);
```

#### AUTO 


```{c}
auto mailbox = item->data().value<UnifiedMailbox *>();
```

#### AUTO 


```{c}
auto ldapCompletionTab = new LdapCompetionTab();
```

#### RANGE FOR STATEMENT 


```{c}
for (MessageComposer::PluginEditorConvertTextInterface *interface : std::as_const(mListPluginInterface)) {
        interface->setInitialData(data);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Tag &result : lstTags) {
        mTags.append(MailCommon::Tag::fromAkonadi(result));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (MessageComposer::PluginEditorConvertTextInterface *interface : qAsConst(mListPluginInterface)) {
        interface->setBeforeConvertingData(data);
    }
```

#### AUTO 


```{c}
auto infowidget = dlg.findChild<FollowUpReminderInfoWidget *>(QStringLiteral("FollowUpReminderInfoWidget"));
```

#### AUTO 


```{c}
auto *copyParm = new short[ num + 1 ];
```

#### AUTO 


```{c}
auto fetch = new Akonadi::ItemFetchJob(item, this);
```

#### AUTO 


```{c}
auto group = boxesGroup.group(mailbox->id());
```

#### AUTO 


```{c}
auto job = new Akonadi::ItemModifyJob(mItem);
```

#### AUTO 


```{c}
auto hLayout = new QHBoxLayout;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &ba : supportedImage) {
        if (!filter.isEmpty()) {
            filter += QLatin1Char(' ');
        }
        filter += QLatin1String("*.") + QString::fromLatin1(ba);
    }
```

#### AUTO 


```{c}
const auto mailActions = {StandardMailActionManager::MarkAllMailAsRead,
                              StandardMailActionManager::MoveToTrash,
                              StandardMailActionManager::MoveAllToTrash,
                              StandardMailActionManager::RemoveDuplicates,
                              StandardMailActionManager::EmptyAllTrash,
                              StandardMailActionManager::MarkMailAsRead,
                              StandardMailActionManager::MarkMailAsUnread,
                              StandardMailActionManager::MarkMailAsImportant,
                              StandardMailActionManager::MarkMailAsActionItem};
```

#### AUTO 


```{c}
const auto runningJob = line->property("keyLookupJob").value<QPointer<QGpgME::KeyForMailboxJob>>();
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : lstActs) {
        auto subMenu = qobject_cast<KSelectAction *>(action);
        if (subMenu) {
            const QString codecNameToSet = selectCharset(subMenu, encoding);
            if (!codecNameToSet.isEmpty()) {
                return codecNameToSet;
            }
        } else {
            const QString fixedActionText = MimeTreeParser::NodeHelper::fixEncoding(action->text());
            if (KCharsets::charsets()->codecForName(
                    KCharsets::charsets()->encodingForName(fixedActionText))
                == KCharsets::charsets()->codecForName(encoding)) {
                return action->text();
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (MailFilter *filter : lstFilters) {
        if (!filter->isEmpty() && filter->configureShortcut() && filter->isEnabled()) {
            QString filterName = QStringLiteral("Filter %1").arg(filter->name());
            filterName.replace(QLatin1Char(' '), QLatin1Char('_'));
            if (action(filterName)) {
                continue;
            }

            if (!addedSeparator) {
                QAction *a = mApplyFilterActionsMenu->menu()->addSeparator();
                mFilterMenuActions.append(a);
                a = mApplyFilterFolderActionsMenu->menu()->addSeparator();
                mFilterFolderMenuActions.append(a);
                a = mApplyFilterFolderRecursiveActionsMenu->menu()->addSeparator();
                mFilterFolderMenuRecursiveActions.append(a);
                addedSeparator = true;
            }

            auto filterCommand = new KMMetaFilterActionCommand(filter->identifier(), this);
            mFilterCommands.append(filterCommand);

            auto filterAction = filterToAction(filter);
            actionCollection()->addAction(filterName, filterAction);
            connect(filterAction, &QAction::triggered,
                    filterCommand, &KMMetaFilterActionCommand::start);
            actionCollection()->setDefaultShortcut(filterAction, filter->shortcut());
            mApplyFilterActionsMenu->menu()->addAction(filterAction);
            mFilterMenuActions.append(filterAction);
            if (filter->configureToolbar()) {
                mFilterTBarActions.append(filterAction);
            }

            filterAction = filterToAction(filter);
            actionCollection()->addAction(filterName + QStringLiteral("___folder"), filterAction);
            connect(filterAction, &QAction::triggered,
                    this, [this] {
                slotApplyFilterOnFolder(/* recursive */ false);
            });
            mApplyFilterFolderActionsMenu->menu()->addAction(filterAction);
            mFilterFolderMenuActions.append(filterAction);

            filterAction = filterToAction(filter);
            actionCollection()->addAction(filterName + QStringLiteral("___folder_recursive"), filterAction);
            connect(filterAction, &QAction::triggered,
                    this, [this] {
                slotApplyFilterOnFolder(/* recursive */ true);
            });
            mApplyFilterFolderRecursiveActionsMenu->menu()->addAction(filterAction);
            mFilterFolderMenuRecursiveActions.append(filterAction);
        }
    }
```

#### AUTO 


```{c}
auto proxy = new SearchCollectionProxyModel(unindexedCollections, this);
```

#### AUTO 


```{c}
auto composerCryptoTab = new SecurityPageComposerCryptoTab();
```

#### AUTO 


```{c}
auto label = new QLabel(i18n("Select the plugin summaries to show on the summary page."), this);
```

#### AUTO 


```{c}
auto hbox = new QWidget(mDateDisplayBox);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Akonadi::Collection::List &cols) {
                if (cols.count() != 1) {
                    return;
                }
                Akonadi::SpecialMailCollections::self()->unregisterCollection(cols.first());
            }
```

#### AUTO 


```{c}
auto *markAsReadAllJob = new Akonadi::MarkAsCommand(messageStatus, list);
```

#### AUTO 


```{c}
auto fromExistingVCard = new QRadioButton(i18n("&From existing vCard"), this);
```

#### AUTO 


```{c}
auto editorAndCryptoStateIndicators = new QWidget(mSplitter);
```

#### AUTO 


```{c}
auto *tagsettinggrid = new QVBoxLayout();
```

#### AUTO 


```{c}
auto layout = new QHBoxLayout;
```

#### AUTO 


```{c}
auto job = new AddEmailToExistingContactJob(item, emailString, this);
```

#### AUTO 


```{c}
auto document = new QTextDocument(nullptr);
```

#### LAMBDA EXPRESSION 


```{c}
[this, finishedCb = std::move(finishedCb)]() {
        qCDebug(agent_log) << "Finished callback: enabling change recorder";
        // Only now start processing changes from change recorder
        connect(&mMonitor, &Akonadi::ChangeRecorder::changesAdded, &mMonitor, &Akonadi::ChangeRecorder::replayNext, Qt::QueuedConnection);
        // And start replaying any potentially pending notification
        QTimer::singleShot(0, &mMonitor, &Akonadi::ChangeRecorder::replayNext);

        if (finishedCb) {
            finishedCb();
        }
    }
```

#### AUTO 


```{c}
auto job = new Akonadi::ItemDeleteJob(*trashIt, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (MessageComposer::PluginEditor *plugin : lstPlugin) {
        if (plugin->isEnabled()) {
            MessageComposer::PluginEditorInterface *interface = static_cast<MessageComposer::PluginEditorInterface *>(plugin->createInterface(mActionCollection, this));
            interface->setRichTextEditor(mRichTextEditor);
            interface->setParentWidget(mParentWidget);
            interface->setPlugin(plugin);
            connect(interface, &MessageComposer::PluginEditorInterface::emitPluginActivated, this, &KMailPluginEditorManagerInterface::slotPluginActivated);
            mListPluginInterface.append(interface);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &message) {
        PimCommon::BroadcastStatus::instance()->setStatusMsg(message);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &addr : qAsConst(mEmails)) {
        if (!mEmailWhiteList.contains(addr.trimmed())) {
            QString tname, temail;
            KEmailAddress::extractEmailAddressAndName(addr, temail, tname);    // ignore return value
            // which is always false
            if (tname.contains(QLatin1Char('@'))) { //Potential address
                if (tname.startsWith(QLatin1Char('<')) && tname.endsWith(QLatin1Char('>'))) {
                    tname = tname.mid(1, tname.length() - 2);
                }
                if (tname.startsWith(QLatin1Char('\'')) && tname.endsWith(QLatin1Char('\''))) {
                    tname = tname.mid(1, tname.length() - 2);
                }
                if (temail.toLower() != tname.toLower()) {
                    const QString str = QStringLiteral("(%1)").arg(temail);
                    if (!tname.contains(str, Qt::CaseInsensitive)) {
                        const QStringList lst = tname.trimmed().split(QLatin1Char(' '));
                        if (lst.count() > 1) {
                            const QString firstName = lst.at(0);

                            for (const QString &n : lst) {
                                if (n != firstName) {
                                    mPotentialPhisingEmails.append(addr);
                                    break;
                                }
                            }
                        } else {
                            mPotentialPhisingEmails.append(addr);
                        }
                    }
                }
            }
        }
    }
```

#### AUTO 


```{c}
auto action = new QAction(QIcon::fromTheme(QStringLiteral("configure")), i18n("&Configure KMail..."), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Collection &col : cols) {
        const QModelIndex colIdx = Akonadi::EntityTreeModel::modelIndexForCollection(etm, col);
        if (col.statistics().count() > -1) {
            if (col.cachePolicy().localParts().contains(QLatin1String("RFC822"))) {
                result.push_back(col);
            }
        } else {
            const Akonadi::Collection collection = etm->data(colIdx, Akonadi::EntityTreeModel::CollectionRole).value<Akonadi::Collection>();
            if (!collection.hasAttribute<Akonadi::EntityHiddenAttribute>()
                && collection.cachePolicy().localParts().contains(QLatin1String("RFC822"))) {
                result.push_back(collection);
            }
        }

        const int childrenCount = etm->rowCount(colIdx);
        if (childrenCount > 0) {
            Akonadi::Collection::List subCols;
            subCols.reserve(childrenCount);
            for (int i = 0; i < childrenCount; ++i) {
                const QModelIndex idx = etm->index(i, 0, colIdx);
                const Akonadi::Collection child = etm->data(idx, Akonadi::EntityTreeModel::CollectionRole).value<Akonadi::Collection>();
                if (child.cachePolicy().localParts().contains(QLatin1String("RFC822"))) {
                    subCols.push_back(child);
                }
            }

            result += searchCollectionsRecursive(subCols);
        }
    }
```

#### AUTO 


```{c}
auto job = new AddressValidationJob(recipients, this, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : lstItems) {
        const KMime::Message::Ptr msg = MessageComposer::Util::message(item);
        if (!msg) {
            return Failed;
        }
        MessageFactoryNG factory(msg, item.id(), CommonKernel->collectionFromId(item.parentCollection().id()));
        factory.setIdentityManager(KMKernel::self()->identityManager());
        factory.setFolderIdentity(MailCommon::Util::folderIdentity(item));

        if (transportId == -1) {
            const auto *transportAttribute = item.attribute<MailTransport::TransportAttribute>();
            if (transportAttribute) {
                transportId = transportAttribute->transportId();
                const MailTransport::Transport *transport = MailTransport::TransportManager::self()->transportById(transportId);
                if (!transport) {
                    transportId = -1;
                }
            }
        }

        const auto *sentAttribute = item.attribute<MailTransport::SentBehaviourAttribute>();
        QString fcc;
        if (sentAttribute && (sentAttribute->sentBehaviour() == MailTransport::SentBehaviourAttribute::MoveToCollection)) {
            fcc = QString::number(sentAttribute->moveToCollection().id());
        }

        const KMime::Message::Ptr newMsg = factory.createRedirect(to, cc, bcc, transportId, fcc, identity);
        if (!newMsg) {
            return Failed;
        }

        MessageStatus status;
        status.setStatusFromFlags(item.flags());
        if (!status.isRead()) {
            FilterAction::sendMDN(item, KMime::MDN::Dispatched);
        }

        if (!kmkernel->msgSender()->send(newMsg, method)) {
            qCDebug(KMAIL_LOG) << "KMRedirectCommand: could not redirect message (sending failed)";
            return Failed; // error: couldn't send
        }
    }
```

#### AUTO 


```{c}
auto useGlobalSetting = menu.findChild<KToggleAction *>(QStringLiteral("use-global-setting-action"));
```

#### RANGE FOR STATEMENT 


```{c}
for (qint64 id : collections) {
        auto ifj = new Akonadi::ItemFetchJob{Akonadi::Collection{id}, this};
        ifj->setDeliveryOption(Akonadi::ItemFetchJob::EmitItemsInBatches);
        connect(ifj, &Akonadi::ItemFetchJob::itemsReceived, this, [=](const Akonadi::Item::List &items) {
            m_filterManager->applyFilters(items, static_cast<FilterManager::FilterSet>(filterSet));
        });
    }
```

#### AUTO 


```{c}
auto hdr = mMsg->headerByType("X-KMail-Fcc")
```

#### RANGE FOR STATEMENT 


```{c}
for (QTreeWidgetItem *item : selectedItems) {
            IdentityListViewItem *identityItem = dynamic_cast<IdentityListViewItem *>(item);
            identityName = identityItem->identity().identityName();
            if (mIdentityManager->removeIdentity(identityName)) {
                delete item;
            }
            if (mIPage.mIdentityList->currentItem()) {
                mIPage.mIdentityList->currentItem()->setSelected(true);
            }
            refreshList();
            updateButtons();
        }
```

#### AUTO 


```{c}
auto *parser = new TemplateParser::TemplateParserJob(mMsg, TemplateParser::TemplateParserJob::NewMessage);
```

#### AUTO 


```{c}
auto action = new QAction(i18n("&Next Message"), this);
```

#### AUTO 


```{c}
auto listWidgetSearchLine = dlg.findChild<KListWidgetSearchLine *>(QStringLiteral("searchline"));
```

#### AUTO 


```{c}
auto *fetch = new Akonadi::CollectionFetchJob(mCollection,
                                                      Akonadi::CollectionFetchJob::Base);
```

#### LAMBDA EXPRESSION 


```{c}
[](const Akonadi::Item &lhs, const Akonadi::Item &rhs) {
                          return lhs.storageCollectionId() < rhs.storageCollectionId();
                      }
```

#### AUTO 


```{c}
auto item = job->property("ProgressItem").value<KPIM::ProgressItem *>();
```

#### LAMBDA EXPRESSION 


```{c}
[this, line]() {
                this->slotRecipientLineIconClicked(line);
            }
```

#### AUTO 


```{c}
auto command = new KMReplyCommand(mParent, mCurrentItem, strategy, text);
```

#### RANGE FOR STATEMENT 


```{c}
for (QTreeWidgetItem *selecteditem : selectedItems) {
            auto identityItem = dynamic_cast<IdentityListViewItem *>(item);
            identityName = identityItem->identity().identityName();
            if (mIdentityManager->removeIdentity(identityName)) {
                delete selecteditem;
            }
            if (mIPage.mIdentityList->currentItem()) {
                mIPage.mIdentityList->currentItem()->setSelected(true);
            }
            refreshList();
            updateButtons();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&id](const UnifiedMailboxManager::Entry &e) {
                return e.second->id() == id;
            }
```

#### AUTO 


```{c}
auto *sMimeTab = new SMimeTab();
```

#### RANGE FOR STATEMENT 


```{c}
for (PimCommon::CustomToolsPlugin *plugin : lstPlugin) {
        if (plugin->isEnabled()) {
            auto *interface = static_cast<MessageComposer::PluginEditorGrammarCustomToolsViewInterface *>(plugin->createView(mActionCollection, mCustomToolsWidget));
            mCustomToolsWidget->addCustomToolViewInterface(interface);
            interface->setParentWidget(mParentWidget);
            interface->setRichTextEditor(mRichTextEditor);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QTreeWidgetItem *item : listItems) {
        if (removeMessage) {
            SendLaterItem *mailItem = static_cast<SendLaterItem *>(item);
            if (mailItem->info()) {
                Akonadi::Item::Id id = mailItem->info()->itemId();
                if (id != -1) {
                    mListMessagesToRemove << id;
                }
            }
        }
        delete item;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &configName: configNameFiles) {
        initCleanupFolderSettings(configName);
        initCleanupFiltersSettings(configName);
        initCleanDialogSettings(configName);
    }
```

#### AUTO 


```{c}
auto *page = new AccountsPage(parent);
```

#### AUTO 


```{c}
auto *job = new Akonadi::ItemDeleteJob(item);
```

#### AUTO 


```{c}
auto *aggregationConfigButton = new AggregationConfigButton(group, mAggregationComboBox);
```

#### AUTO 


```{c}
auto vlay = new QVBoxLayout(mainWidget);
```

#### AUTO 


```{c}
auto iconButton = new QPushButton(QIcon::fromTheme(mMailbox->icon(), QIcon::fromTheme(QStringLiteral("folder-mail"))),
                                      i18n("Pick icon..."));
```

#### AUTO 


```{c}
auto boxesGroup = kcfg->group("UnifiedMailboxes");
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &att : list) {
        urlList << QUrl::fromLocalFile(extractTemp(att));
    }
```

#### AUTO 


```{c}
auto job = new KeyGenerationJob(mName, mEmail, this);
```

#### AUTO 


```{c}
auto sigController = new MessageComposer::SignatureController(this);
```

#### AUTO 


```{c}
const auto answerMessageItemId = mailItem->info()->answerMessageItemId();
```

#### AUTO 


```{c}
auto action = new QAction(i18n("Delayed Messages..."), this);
```

#### AUTO 


```{c}
auto box = new QDialogButtonBox(QDialogButtonBox::Close, this);
```

#### AUTO 


```{c}
const auto col = CommonKernel->collectionFromId(id);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &srcRid : sourceRids) {
        const auto srcCol = collectionForRid(srcRid);
        AKVERIFY_RET(srcCol.isValid(), {});
        mailbox->addSourceCollection(srcCol.id());
    }
```

#### AUTO 


```{c}
auto mainlayout = new QVBoxLayout(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (qint64 id: collections) {
        auto ifj = new Akonadi::ItemFetchJob{
            Akonadi::Collection{
                id
            }, this
        };
        ifj->setDeliveryOption(Akonadi::ItemFetchJob::EmitItemsInBatches);
        connect(ifj, &Akonadi::ItemFetchJob::itemsReceived,
                this, [=](const Akonadi::Item::List &items) {
            m_filterManager->applyFilters(items, static_cast<FilterManager::FilterSet>(filterSet));
        });
    }
```

#### AUTO 


```{c}
auto move = new Akonadi::ItemMoveJob(item, draftsSourceCol.value(), this);
```

#### AUTO 


```{c}
auto *mailItem = static_cast<SendLaterItem *>(item);
```

#### AUTO 


```{c}
const auto &att
```

#### AUTO 


```{c}
auto fetchCollection = new Akonadi::CollectionFetchJob(Akonadi::Collection(mInfo->archiveTopLevel()), Akonadi::CollectionFetchJob::Base);
```

#### LAMBDA EXPRESSION 


```{c}
[this, finishedCb = std::move(finishedCb)]() {
                        qCDebug(UNIFIEDMAILBOXAGENT_LOG) << "Finished callback: enabling change recorder";
                        // Only now start processing changes from change recorder
                        connect(&mMonitor, &Akonadi::ChangeRecorder::changesAdded, &mMonitor, &Akonadi::ChangeRecorder::replayNext, Qt::QueuedConnection);
                        // And start replaying any potentially pending notification
                        QTimer::singleShot(0, &mMonitor, &Akonadi::ChangeRecorder::replayNext);

                        if (finishedCb) {
                            finishedCb();
                        }
                    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, view]() {
        const auto indexes = view->selectionModel()->selectedIndexes();
        if (!indexes.isEmpty()) {
            auto item = mBoxModel->itemFromIndex(indexes[0]);
            const auto mailbox = item->data().value<UnifiedMailbox *>();
            if (KMessageBox::warningYesNo(
                    this, i18n("Do you really want to remove unified mailbox <b>%1</b>?", mailbox->name()),
                    i18n("Really Remove?"), KStandardGuiItem::remove(), KStandardGuiItem::cancel()) == KMessageBox::Yes) {
                mBoxModel->removeRow(item->row());
                mBoxManager.removeBox(mailbox->id());
            }
        }
    }
```

#### AUTO 


```{c}
auto changeRecorder = new Akonadi::ChangeRecorder(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &argument : qAsConst(args)) {
        if (argument == QLatin1String("--attach")) {
            addAttachmentAttribute = true;
        } else {
            if (argument.startsWith(QLatin1String("--"))) {
                addAttachmentAttribute = false;
            }
            if (argument.contains(QLatin1Char('@')) || argument.startsWith(QLatin1String("mailto:"))) { //address mustn't be trade as a attachment
                addAttachmentAttribute = false;
            }
            if (addAttachmentAttribute) {
                newargs.append(QStringLiteral("--attach"));
                newargs.append(argument);
            } else {
                newargs.append(argument);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Akonadi::StandardMailActionManager::Type mailAction : mailActions) {
        mAkonadiStandardActionManager->createAction(mailAction);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto source : sourceCollections) {
                auto col = collectionForId(source);
                QVERIFY(col);
                QVERIFY(col->hasAttribute<Akonadi::SpecialCollectionAttribute>());
                QCOMPARE(col->attribute<Akonadi::SpecialCollectionAttribute>()->collectionType(), id.toLatin1());
            }
```

#### AUTO 


```{c}
auto *info = new FollowUpReminder::FollowUpReminderInfo(group);
```

#### AUTO 


```{c}
auto *command = new KMReplyCommand(this,
                                       msg,
                                       MessageComposer::ReplyAll,
                                       text,
                                       false,
                                       tmpl
                                       );
```

#### RANGE FOR STATEMENT 


```{c}
for (MessageComposer::PluginEditorInterface *interface : qAsConst(mListPluginInterface)) {
            const MessageComposer::PluginActionType actionType = interface->actionType();
            MessageComposer::PluginActionType::Type type = actionType.type();
            const bool needSelectedText = interface->needSelectedText();
            if (needSelectedText) {
                // Disable by default as we don't have selection by default.
                actionType.action()->setEnabled(false);
                connect(this, &KMailPluginEditorManagerInterface::textSelectionChanged, actionType.action(), &QAction::setEnabled);
            }
            QList<QAction *> lst = mActionHash.value(type);
            if (!lst.isEmpty()) {
                auto act = new QAction(this);
                act->setSeparator(true);
                lst << act << actionType.action();
                mActionHash.insert(type, lst);
            } else {
                mActionHash.insert(type, QList<QAction *>() << actionType.action());
            }
            if (interface->plugin()->hasPopupMenuSupport()) {
                type = MessageComposer::PluginActionType::PopupMenu;
                lst = mActionHash.value(type);
                if (!lst.isEmpty()) {
                    auto act = new QAction(this);
                    act->setSeparator(true);
                    lst << act << actionType.action();
                    mActionHash.insert(type, lst);
                } else {
                    mActionHash.insert(type, QList<QAction *>() << actionType.action());
                }
            }
            if (interface->plugin()->hasToolBarSupport()) {
                type = MessageComposer::PluginActionType::ToolBar;
                lst = mActionHash.value(type);
                if (!lst.isEmpty()) {
                    auto act = new QAction(this);
                    act->setSeparator(true);
                    lst << act << actionType.action();
                    mActionHash.insert(type, lst);
                } else {
                    mActionHash.insert(type, QList<QAction *>() << actionType.action());
                }
            }
        }
```

