#### AUTO 


```{c}
auto path = grp.readEntry( ExecuteBrowserPlugin::pathEntry, "" );
```

