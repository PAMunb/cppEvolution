#### LAMBDA EXPRESSION 


```{c}
[fetchItemJob, job, this] {
        if (fetchItemJob->kjob()->error() != KJob::NoError)
            return;

        Q_ASSERT(fetchItemJob->items().size() == 1);
        auto childItem = fetchItemJob->items().at(0);
        childItem.clearTags();

        auto updateJob = m_storage->updateItem(childItem);
        job->addSubjob(updateJob);
        updateJob->start();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Akonadi::Collection &collection) {
            return collection.isValid()
                && collection.parentCollection() == Akonadi::Collection::root();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[storage, collection] (const Domain::LiveQueryInput<Akonadi::Item>::AddFunction &add) {
            auto job = storage->fetchItems(collection, nullptr);
            Utils::JobHandler::install(job->kjob(), [add, job] {
                foreach (const auto &item, job->items()) {
                    add(item);
                }
            });
        }
```

#### AUTO 


```{c}
auto job = createStorage()->fetchCollections(collection, Akonadi::StorageInterface::Base, nullptr);
```

#### AUTO 


```{c}
const auto isDone = task ? task->isDone() : false;
```

#### AUTO 


```{c}
auto expectedIds = QVector<Akonadi::Item::Id>() << 44;
```

#### AUTO 


```{c}
auto fetch = m_helpers->fetchAllCollections();
```

#### AUTO 


```{c}
const auto &collection
```

#### AUTO 


```{c}
auto predicate = [this] (const Akonadi::Item &item) {
        const bool excluded = !m_serializer->relatedUidFromItem(item).isEmpty()
                           || (!m_serializer->isTaskItem(item) && !m_serializer->isNoteItem(item))
                           || (m_serializer->isTaskItem(item) && m_serializer->hasContextTags(item))
                           || m_serializer->hasAkonadiTags(item);

        return !excluded;
    };
```

#### AUTO 


```{c}
auto parentItem = m_serializer->createItemFromTask(parent);
```

#### AUTO 


```{c}
auto tmp = m_model;
```

#### AUTO 


```{c}
auto availableSources = m_appModel->property("availableSources").value<QObject*>();
```

#### AUTO 


```{c}
const auto parent = entity.parentCollection();
```

#### AUTO 


```{c}
auto note = provider->data().at(i);
```

#### AUTO 


```{c}
auto note = deserializeNote(item);
```

#### LAMBDA EXPRESSION 


```{c}
[storage, parent] (const Domain::LiveQueryInput<Collection>::AddFunction &add) {
        auto job = storage->fetchCollections(Collection::root(), StorageInterface::Recursive, parent);
        Utils::JobHandler::install(job->kjob(), [job, add] {
            if (job->kjob()->error())
                return;

            foreach (const auto &collection, job->collections())
                add(collection);
        });
    }
```

#### LAMBDA EXPRESSION 


```{c}
[types] (const Akonadi::Collection &col) {
                         const auto mime = col.contentMimeTypes();
                         return ((types & Akonadi::StorageInterface::Tasks) && mime.contains(KCalCore::Todo::todoMimeType()))
                             || ((types & Akonadi::StorageInterface::Notes) && mime.contains(Akonadi::NoteUtils::noteMimeType()));
                     }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QObjectPtr &object, const QVariant &value, int role) {
        if (role != Qt::EditRole) {
            return false;
        }

        if (object == m_inboxObject
         || object == m_workdayObject
         || object == m_projectsObject
         || object == m_contextsObject) {
            return false;
        }

        if (auto project = object.objectCast<Domain::Project>()) {
            const auto currentName = project->name();
            project->setName(value.toString());
            const auto job = m_projectRepository->update(project);
            installHandler(job, tr("Cannot modify project %1").arg(currentName));
        } else if (auto context = object.objectCast<Domain::Context>()) {
            const auto currentName = context->name();
            context->setName(value.toString());
            const auto job = m_contextRepository->update(context);
            installHandler(job, tr("Cannot modify context %1").arg(currentName));
        } else {
            Q_ASSERT(false);
        }

        return true;
    }
```

#### AUTO 


```{c}
auto parentTask = Domain::Task::Ptr::create();
```

#### LAMBDA EXPRESSION 


```{c}
[this, root] (const Collection &collection) {
        return collection.isValid()
            && collection.parentCollection() == root
            && m_serializer->isListedCollection(collection);
    }
```

#### AUTO 


```{c}
auto job = new AkonadiFakeItemFetchJob;
```

#### AUTO 


```{c}
auto notifiedItem = spy.takeFirst().takeFirst().value<Akonadi::Item>();
```

#### LAMBDA EXPRESSION 


```{c}
[this, &afterReset] (const Domain::LiveQuery<QObject*, QString>::AddFunction &add) {
            Utils::JobHandler::install(new FakeJob, [this, &afterReset, add] {
                add(createObject(0, QStringLiteral("0A")));
                add(createObject(1, QStringLiteral("1A")));
                add(createObject(2, QStringLiteral("2A")));
                add(createObject(3, QStringLiteral("0B")));
                add(createObject(4, QStringLiteral("1B")));
                add(createObject(5, QStringLiteral("2B")));

                if (afterReset) {
                    add(createObject(6, QStringLiteral("0C")));
                    add(createObject(7, QStringLiteral("1C")));
                    add(createObject(8, QStringLiteral("2C")));
                }
            });
        }
```

#### LAMBDA EXPRESSION 


```{c}
[storage, contentTypes, root] (const Domain::LiveQueryInput<Collection>::AddFunction &add) {
        auto job = storage->fetchCollections(root, StorageInterface::Recursive, contentTypes);
        Utils::JobHandler::install(job->kjob(), [root, job, add] {
            if (job->kjob()->error())
                return;

            auto directChildren = QHash<Collection::Id, Collection>();
            foreach (const auto &collection, job->collections()) {
                auto directChild = collection;
                while (directChild.parentCollection() != root)
                    directChild = directChild.parentCollection();
                if (!directChildren.contains(directChild.id()))
                    directChildren[directChild.id()] = directChild;
            }

            foreach (const auto &directChild, directChildren)
                add(directChild);
        });
    }
```

#### AUTO 


```{c}
auto job = storage->fetchCollections(root, StorageInterface::Recursive, parent);
```

#### AUTO 


```{c}
const auto collection2 = Akonadi::Collection(GenCollection().withRootAsParent()
                                                                    .withId(2)
                                                                    .withName("tasks2")
                                                                    .withTaskContent());
```

#### AUTO 


```{c}
auto opt = QStyleOptionViewItemV4(option);
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const QMimeData *mimeData, Qt::DropAction, const Domain::Task::Ptr &parentTask) {
        if (!mimeData->hasFormat("application/x-zanshin-object"))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                        [](const Domain::Artifact::Ptr &droppedArtifact) {
                            return !droppedArtifact.objectCast<Domain::Task>();
                        })) {
            return false;
        }

        foreach(const Domain::Artifact::Ptr &droppedArtifact, droppedArtifacts) {
            auto childTask = droppedArtifact.objectCast<Domain::Task>();
            const auto job = taskRepository()->associate(parentTask, childTask);
            installHandler(job, tr("Cannot move task %1 as sub-task of %2").arg(childTask->title()).arg(parentTask->title()));
        }

        return true;
    }
```

#### AUTO 


```{c}
auto filterWidget = page.findChild<Widgets::FilterWidget*>(QStringLiteral("filterWidget"));
```

#### AUTO 


```{c}
auto c2 = Akonadi::Collection(43);
```

#### AUTO 


```{c}
auto iconName = collection.attribute<Akonadi::EntityDisplayAttribute>()->iconName();
```

#### AUTO 


```{c}
auto inQuery = Domain::LiveQueryOutput<Domain::Note::Ptr>::Ptr();
```

#### AUTO 


```{c}
auto job = storage->fetchCollections(root, StorageInterface::Recursive);
```

#### AUTO 


```{c}
const auto colorGroup = (isEnabled && !isActive) ? QPalette::Inactive
                          : isEnabled ? QPalette::Normal
                          : QPalette::Disabled;
```

#### LAMBDA EXPRESSION 


```{c}
[](const Domain::Task::List &tasks) -> QMimeData* {
        if (tasks.isEmpty())
            return nullptr;

        auto data = new QMimeData;
        data->setData(QStringLiteral("application/x-zanshin-object"), "object");
        data->setProperty("objects", QVariant::fromValue(tasks));
        return data;
    }
```

#### AUTO 


```{c}
const auto item1 = Akonadi::Item(GenTodo().withId(1).withParent(1).withContexts({"ctx-1"}).withTitle("item1"));
```

#### AUTO 


```{c}
auto treeFlags = [](const Domain::Task::Ptr &) {
        return Qt::ItemIsSelectable
             | Qt::ItemIsEnabled
             | Qt::ItemIsEditable
             | Qt::ItemIsUserCheckable;
    };
```

#### AUTO 


```{c}
auto project11 = Domain::Project::Ptr::create();
```

#### AUTO 


```{c}
auto context = serializer->createContextFromTag(data.tag(42));
```

#### LAMBDA EXPRESSION 


```{c}
[] (const Domain::LiveRelationshipQuery<QObject*, QString>::AddFunction &) {
            Utils::JobHandler::install(new FakeJob, [] {});
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (Utils::DependencyManager *deps) {
            return new Akonadi::CachingStorage(deps->create<Akonadi::Cache>(),
                                               Akonadi::StorageInterface::Ptr(m_data.createStorage()));
        }
```

#### AUTO 


```{c}
auto defaultAction = qobject_cast<QWidgetAction*>(actions.at(0));
```

#### AUTO 


```{c}
auto result = queries->findTopLevel();
```

#### AUTO 


```{c}
auto task1 = stubPageModel.addTaskItem(QStringLiteral("Task1"));
```

#### LAMBDA EXPRESSION 


```{c}
[](const Akonadi::Collection::List &collections) {
            auto res = QStringList();
            res.reserve(collections.size());
            std::transform(collections.cbegin(), collections.cend(),
                           std::back_inserter(res),
                           std::mem_fn(&Akonadi::Collection::name));
            res.sort();
            return res;
        }
```

#### AUTO 


```{c}
const auto summaryText = taskDelegate.isValid() ? i18n("(%1) %2", taskDelegate.display(), opt.text) : opt.text;
```

#### AUTO 


```{c}
const auto taskItem = m_findContextsItem[taskItemId];
```

#### LAMBDA EXPRESSION 


```{c}
[&replaceHandlerCalled](const Domain::DataSource::Ptr &, int) {
                                          replaceHandlerCalled = true;
                                      }
```

#### AUTO 


```{c}
auto job = storage->searchCollections(*searchTerm, contentTypes);
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const DataSourceQuery::AddFunction &add) {
            CollectionFetchJobInterface *job = m_storage->fetchCollections(Akonadi::Collection::root(),
                                                                           StorageInterface::Recursive,
                                                                           StorageInterface::Tasks | StorageInterface::Notes);
            Utils::JobHandler::install(job->kjob(), [this, job, add] {
                if (job->kjob()->error())
                    return;

                QHash<Collection::Id, Collection> topLevels;
                foreach (const auto &collection, job->collections()) {
                    auto topLevel = collection;
                    while (topLevel.parentCollection() != Collection::root())
                        topLevel = topLevel.parentCollection();
                    if (!topLevels.contains(topLevel.id()))
                        topLevels[topLevel.id()] = topLevel;
                }

                foreach (const auto &topLevel, topLevels.values())
                    add(topLevel);
            });
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Akonadi::Tag &tag, Domain::Context::Ptr &context) {
            m_serializer->updateContextFromTag(context, tag);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QObjectPtr &object) -> Domain::QueryResultInterface<QObjectPtr>::Ptr {
        if (!object)
            return Domain::QueryResult<QObjectPtr>::create(m_rootsProvider);
        else if (object == m_projectsObject)
            return Domain::QueryResult<Domain::Project::Ptr, QObjectPtr>::copy(m_projectQueries->findAll());
        else if (object == m_contextsObject)
            return Domain::QueryResult<Domain::Context::Ptr, QObjectPtr>::copy(m_contextQueries->findAll());
        else
            return Domain::QueryResult<QObjectPtr>::Ptr();
    }
```

#### AUTO 


```{c}
auto artifact = serializer.createArtifactFromItem(item).dynamicCast<Domain::Note>();
```

#### AUTO 


```{c}
auto actions = QList<DataSourceDelegate::Action>();
```

#### AUTO 


```{c}
auto noteResult = Domain::QueryResult<Domain::Note::Ptr>::create(noteProvider);
```

#### AUTO 


```{c}
auto data = [](const Domain::Note::Ptr &note, int role) -> QVariant {
        if (role == Qt::DisplayRole || role == Qt::EditRole) {
            return note->title();
        } else {
            return QVariant();
        }
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this, akonadiTag] (const ArtifactQuery::AddFunction &add) {
            CollectionFetchJobInterface *job = m_storage->fetchCollections(Akonadi::Collection::root(),
                                                                           StorageInterface::Recursive,
                                                                           StorageInterface::Tasks | StorageInterface::Notes);
            Utils::JobHandler::install(job->kjob(), [this, job, add] {
                if (job->kjob()->error() != KJob::NoError)
                    return;

                for (auto collection : job->collections()) {
                    ItemFetchJobInterface *job = m_storage->fetchItems(collection);
                    Utils::JobHandler::install(job->kjob(), [this, job, add] {
                        if (job->kjob()->error() != KJob::NoError)
                            return;

                        for (auto item : job->items())
                            add(item);
                    });
                }
            });
        }
```

#### AUTO 


```{c}
auto pagesDock = new QDockWidget;
```

#### AUTO 


```{c}
auto futureViewAction = new QAction(this);
```

#### AUTO 


```{c}
auto predicate = [] (const Akonadi::Collection &collection) {
            return collection.name().endsWith(QLatin1String("-in"));
        };
```

#### AUTO 


```{c}
const auto newContexts = extractContextUids(item);
```

#### AUTO 


```{c}
auto flags = [] (const Domain::DataSource::Ptr &source) {
        Q_UNUSED(source)
        return Qt::ItemIsSelectable | Qt::ItemIsEnabled;
    };
```

#### AUTO 


```{c}
auto drop = [this](const QMimeData *mimeData, Qt::DropAction, const QObjectPtr &object) {
        if (!mimeData->hasFormat(QStringLiteral("application/x-zanshin-object")))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (auto project = object.objectCast<Domain::Project>()) {
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                const auto job = m_projectRepository->associate(project, droppedArtifact);
                installHandler(job, i18n("Cannot add %1 to project %2", droppedArtifact->title(), project->name()));
            }
            return true;
        } else if (auto context = object.objectCast<Domain::Context>()) {
            if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                            [](const Domain::Artifact::Ptr &droppedArtifact) {
                                return !droppedArtifact.objectCast<Domain::Task>();
                            })) {
                return false;
            }
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                auto task = droppedArtifact.staticCast<Domain::Task>();
                const auto job = m_contextRepository->associate(context, task);
                installHandler(job, i18n("Cannot add %1 to context %2", task->title(), context->name()));
            }
            return true;
        } else if (object == m_inboxObject) {
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                const auto job = m_projectRepository->dissociate(droppedArtifact);
                installHandler(job, i18n("Cannot move %1 to Inbox", droppedArtifact->title()));

                if (auto task = droppedArtifact.objectCast<Domain::Task>()) {
                    Utils::JobHandler::install(job, [this, task] {
                        const auto dissociateJob = m_taskRepository->dissociateAll(task);
                        installHandler(dissociateJob, i18n("Cannot move task %1 to Inbox", task->title()));
                    });
                }
            }
            return true;
        } else if (object == m_workdayObject) {
            foreach (const auto &droppedArtifact, droppedArtifacts) {

                if (auto task = droppedArtifact.objectCast<Domain::Task>()) {

                    task->setStartDate(Utils::DateTime::currentDate());
                    const auto job = m_taskRepository->update(task);

                    installHandler(job, i18n("Cannot update task %1 to Workday", task->title()));
                }
            }
            return true;
        }

        return false;
    };
```

#### AUTO 


```{c}
const auto job = m_noteRepository->create(note);
```

#### AUTO 


```{c}
auto removeAction = available.findChild<QAction*>("removeAction");
```

#### AUTO 


```{c}
auto defaultSource = serializer->createDataSourceFromCollection(data.collection(defaultId), Akonadi::SerializerInterface::BaseName);
```

#### AUTO 


```{c}
auto data = [](const Domain::Task::Ptr &task, int role, const TaskExtraDataPtr &info) -> QVariant {
        return dataForTaskWithProject(task, role, info);
    };
```

#### AUTO 


```{c}
auto exPredicate = [] (const Akonadi::Collection &collection) {
            return collection.name().endsWith(QLatin1String("-ex"));
        };
```

#### AUTO 


```{c}
auto job = new AkonadiFakeCollectionFetchJob(parent);
```

#### AUTO 


```{c}
auto dragFunction = [] (const QColor &color) {
            auto mimeData = new QMimeData;
            mimeData->setColorData(QVariant::fromValue(color));
            return mimeData;
        };
```

#### AUTO 


```{c}
auto drop = [this](const QMimeData *mimeData, Qt::DropAction, const QObjectPtr &object) {
        if (!mimeData->hasFormat("application/x-zanshin-object"))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (auto project = object.objectCast<Domain::Project>()) {
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                const auto job = m_projectRepository->associate(project, droppedArtifact);
                installHandler(job, tr("Cannot add %1 to project %2").arg(droppedArtifact->title()).arg(project->name()));
            }
            return true;
        } else if (auto context = object.objectCast<Domain::Context>()) {
            if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                            [](const Domain::Artifact::Ptr &droppedArtifact) {
                                return !droppedArtifact.objectCast<Domain::Task>();
                            })) {
                return false;
            }
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                auto task = droppedArtifact.staticCast<Domain::Task>();
                const auto job = m_contextRepository->associate(context, task);
                installHandler(job, tr("Cannot add %1 to context %2").arg(task->title()).arg(context->name()));
            }
            return true;
        } else if (auto tag = object.objectCast<Domain::Tag>()) {
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                const auto job = m_tagRepository->associate(tag, droppedArtifact);
                installHandler(job, tr("Cannot tag %1 with %2").arg(droppedArtifact->title()).arg(tag->name()));
            }
            return true;
        } else if (object == m_inboxObject) {
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                const auto job = m_projectRepository->dissociate(droppedArtifact);
                installHandler(job, tr("Cannot move %1 to Inbox").arg(droppedArtifact->title()));

                if (auto task = droppedArtifact.objectCast<Domain::Task>()) {
                    Utils::JobHandler::install(job, [this, task] {
                        const auto dissociateJob = m_taskRepository->dissociate(task);
                        installHandler(dissociateJob, tr("Cannot move task %1 to Inbox").arg(task->title()));
                    });
                }
            }
            return true;
        }

        return false;
    };
```

#### AUTO 


```{c}
const auto parentIndex = inbox.centralListModel()->index(0, 0);
```

#### AUTO 


```{c}
auto collections = collectionsJob->collections();
```

#### AUTO 


```{c}
const auto style = widget ? widget->style() : QApplication::style();
```

#### AUTO 


```{c}
const auto &taskName
```

#### AUTO 


```{c}
auto dragFunction = [] (const QList<QColor> &) {
            return Q_NULLPTR;
        };
```

#### AUTO 


```{c}
auto query = [this](const Domain::Task::Ptr &task) -> Domain::QueryResultInterface<Domain::Task::Ptr>::Ptr {
        if (!task)
            return m_taskQueries->findInboxTopLevel();
        else
            return m_taskQueries->findChildren(task);
    };
```

#### LAMBDA EXPRESSION 


```{c}
[persistentIndex](const Domain::DataSource::Ptr &, int) {
                // When a datasource was found (inserted into the result), update the rendering of the item
                auto model = const_cast<QAbstractItemModel *>(persistentIndex.model());
                model->dataChanged(persistentIndex, persistentIndex);
            }
```

#### AUTO 


```{c}
const auto &col
```

#### AUTO 


```{c}
auto fetch = m_helpers->fetchCollections(Collection::root(), const_cast<DataSourceQueries*>(this));
```

#### AUTO 


```{c}
auto sourcesDelegate = available.findChild<Widgets::DataSourceDelegate*>();
```

#### AUTO 


```{c}
auto drag = [] (const Domain::Task::List &tasks) -> QMimeData* {
        if (tasks.isEmpty())
            return 0;

        auto draggedArtifacts = Domain::Artifact::List();
        foreach (const Domain::Task::Ptr &task, tasks) {
            draggedArtifacts.append(task.objectCast<Domain::Artifact>());
        }

        QMimeData *data = new QMimeData();
        data->setData("application/x-zanshin-object", "object");
        data->setProperty("objects", QVariant::fromValue(draggedArtifacts));
        return data;
    };
```

#### AUTO 


```{c}
auto clone = std::unique_ptr<Akonadi::TimestampAttribute>(attr.clone());
```

#### AUTO 


```{c}
auto job = storage.removeItems(list);
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Akonadi::Collection &collection) {
        return m_serializer->isTaskCollection(collection);
    }
```

#### AUTO 


```{c}
auto secondLevelProvider = Domain::QueryResultProvider<QString>::Ptr::create();
```

#### AUTO 


```{c}
const auto items = m_cache->items(item.parentCollection());
```

#### AUTO 


```{c}
const auto rightTask = rightArtifact.objectCast<Domain::Task>();
```

#### AUTO 


```{c}
const auto toItemIds = [](const Akonadi::Item::List &items) {
            auto res = QVector<Akonadi::Item::Id>();
            res.reserve(items.size());
            std::transform(items.cbegin(), items.cend(),
                           std::back_inserter(res),
                           std::mem_fn(&Akonadi::Item::id));
            std::sort(res.begin(), res.end());
            return res;
        };
```

#### AUTO 


```{c}
const auto taskNote = Akonadi::Collection(GenCollection(none).withNoteContent().withTaskContent());
```

#### AUTO 


```{c}
const auto summaryText = hasDelegate ? tr("(%1) %2").arg(task->delegate().display(), opt.text) : opt.text;
```

#### LAMBDA EXPRESSION 


```{c}
[] (const Akonadi::Item &contextItem) {
            auto todo = contextItem.payload<KCalCore::Todo::Ptr>();
            return todo->summary().endsWith(QLatin1String("-in"));
        }
```

#### LAMBDA EXPRESSION 


```{c}
[] (const QColor &, int) {
            return QVariant();
        }
```

#### AUTO 


```{c}
auto fetch = helpers->fetchSiblings(item, nullptr);
```

#### AUTO 


```{c}
const auto tagCachedNames = toTagNames(tags);
```

#### LAMBDA EXPRESSION 


```{c}
[storage, tag] (const Domain::LiveQueryInput<Item>::AddFunction &add) {
        auto job = storage->fetchTagItems(tag);
        Utils::JobHandler::install(job->kjob(), [job, add] {
            if (job->kjob()->error() != KJob::NoError)
                return;

            foreach (const auto &item, job->items())
                add(item);
        });
    }
```

#### AUTO 


```{c}
auto indexHasChildren = [](QModelIndex index) {
        if (const QAbstractProxyModel *proxy = qobject_cast<const QAbstractProxyModel *>(index.model())) {
            index = proxy->mapToSource(index);
        }
        return index.model()->rowCount(index) > 0;
    };
```

#### AUTO 


```{c}
auto page = new FakePageModel(this);
```

#### AUTO 


```{c}
auto associate = std::function<KJob*(Domain::Task::Ptr)>();
```

#### LAMBDA EXPRESSION 


```{c}
[&](const Domain::Task::Ptr &task, const QVariant &value, int role) {
            if (role != Qt::EditRole && role != Qt::CheckStateRole) {
                return false;
            }

            if (role == Qt::EditRole) {
                task->setTitle(value.toString());
            } else {
                task->setDone(value.toInt() == Qt::Checked);
            }

            repositoryMock.getInstance().save(task);
            return true;
        }
```

#### AUTO 


```{c}
const auto stuffCollection = Akonadi::Collection(GenCollection().withRootAsParent()
                                                                        .withId(4)
                                                                        .withName("stuff"));
```

#### AUTO 


```{c}
auto job = new Akonadi::ItemDeleteJob(item);
```

#### AUTO 


```{c}
auto filterAdd = [tag, add] (const Item &item) {
            if (item.tags().contains(tag))
                add(item);
        };
```

#### AUTO 


```{c}
auto source = app.defaultTaskDataSource();
```

#### LAMBDA EXPRESSION 


```{c}
[fetchCollectionJob, item, job, this] {
            if (fetchCollectionJob->kjob()->error() != KJob::NoError)
                return;

            Q_ASSERT(fetchCollectionJob->collections().size() > 0);
            const Akonadi::Collection::List collections = fetchCollectionJob->collections();
            auto it = std::find_if(collections.constBegin(), collections.constEnd(),
                                   [] (const Akonadi::Collection &c) {
                return (c.rights() & Akonadi::Collection::CanCreateItem)
                    && (c.rights() & Akonadi::Collection::CanChangeItem)
                    && (c.rights() & Akonadi::Collection::CanDeleteItem);
            });
            if (it == collections.constEnd()) {
                job->emitError(i18n("Could not find a collection to store the note into!"));
            } else {
                auto col = *it;
                Q_ASSERT(col.isValid());
                auto createJob = m_storage->createItem(item, col);
                job->addSubjob(createJob);
                createJob->start();
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[provider, job, this] {
                for (auto item : job->items()) {
                    auto task = deserializeTask(item);
                    if (task)
                        provider->append(task);
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Item &item) {
        m_findTopLevel.remove(item.id());
    }
```

#### AUTO 


```{c}
auto fetch = m_helpers->fetchItems(StorageInterface::Tasks|StorageInterface::Notes);
```

#### AUTO 


```{c}
auto dataSource = serializer.createDataSourceFromCollection(originalCollection, Akonadi::SerializerInterface::BaseName);
```

#### AUTO 


```{c}
auto startDateEdit = editor.findChild<KPIM::KDateEdit*>(QStringLiteral("startDateEdit"));
```

#### AUTO 


```{c}
const auto &suffix
```

#### LAMBDA EXPRESSION 


```{c}
[&removeHandlerCalled](const Domain::Task::Ptr &, int) {
                                          removeHandlerCalled = true;
                                      }
```

#### AUTO 


```{c}
auto message = item.payload<KMime::Message::Ptr>();
```

#### AUTO 


```{c}
const auto &type
```

#### LAMBDA EXPRESSION 


```{c}
[](const QMimeData *, Qt::DropAction, const Domain::Artifact::Ptr &) {
        return false;
    }
```

#### AUTO 


```{c}
auto predicate = [] (const Akonadi::Item &) {
            return true;
        };
```

#### AUTO 


```{c}
auto attr = new Akonadi::ApplicationSelectedAttribute;
```

#### AUTO 


```{c}
auto completeCollection = std::bind(&AkonadiFakeData::reconstructAncestors,
                                            m_data, _1, collection);
```

#### LAMBDA EXPRESSION 


```{c}
[&](const Domain::Task::Ptr &task) {
            if (!task)
                return Domain::QueryResult<Domain::Task::Ptr>::create(provider);
            else
                return Domain::QueryResult<Domain::Task::Ptr>::Ptr();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[collectionsMap, &reconstructAncestors] (const Collection &collection) {
            Q_ASSERT(collection.isValid());
            auto parent = collection.parentCollection();
            if (parent == Akonadi::Collection::root())
                return collection;

            auto reconstructedParent = reconstructAncestors(collectionsMap[parent.id()]);

            auto result = collection;
            result.setParentCollection(reconstructedParent);
            return result;
        }
```

#### AUTO 


```{c}
auto result = queries->findNotes(tag);
```

#### LAMBDA EXPRESSION 


```{c}
[&] (const QColor &) {
            return Domain::QueryResult<QColor>::Ptr();
        }
```

#### AUTO 


```{c}
auto collection = job->collections().at(0);
```

#### AUTO 


```{c}
const auto allTypes = taskType | noteType;
```

#### AUTO 


```{c}
auto data = [this](const QObjectPtr &object, int role) -> QVariant {
        if (role != Qt::DisplayRole
         && role != Qt::EditRole
         && role != Qt::DecorationRole
         && role != QueryTreeModelBase::IconNameRole) {
            return QVariant();
        }

        if (role == Qt::EditRole
         && (object == m_inboxObject
          || object == m_workdayObject
          || object == m_projectsObject
          || object == m_contextsObject
          || object == m_tagsObject)) {
            return QVariant();
        }

        if (role == Qt::DisplayRole || role == Qt::EditRole) {
            return object->property("name").toString();
        } else if (role == Qt::DecorationRole || role == QueryTreeModelBase::IconNameRole) {
            const QString iconName = object == m_inboxObject ? "mail-folder-inbox"
                                   : (object == m_workdayObject)  ? "go-jump-today"
                                   : (object == m_projectsObject) ? "folder"
                                   : (object == m_contextsObject) ? "folder"
                                   : (object == m_tagsObject)     ? "folder"
                                   : "view-pim-tasks";

            if (role == Qt::DecorationRole)
                return QVariant::fromValue(QIcon::fromTheme(iconName));
            else
                return iconName;
        } else {
            return QVariant();
        }
    };
```

#### AUTO 


```{c}
auto job = storage.createTag(tag);
```

#### AUTO 


```{c}
auto savedArtifact = Domain::Artifact::Ptr();
```

#### AUTO 


```{c}
auto fetch = m_helpers->fetchItemCollection(item);
```

#### AUTO 


```{c}
auto gradient = QLinearGradient(extraTextRect.topLeft(), extraTextRect.bottomLeft());
```

#### AUTO 


```{c}
auto vbox = new QVBoxLayout;
```

#### AUTO 


```{c}
auto fetchItemsInAllCollectionsFunction(Akonadi::StorageInterface::Ptr storage) {
        return [storage] (const Domain::LiveQueryInput<Akonadi::Item>::AddFunction &add) {
            auto job = storage->fetchCollections(Akonadi::Collection::root(), Akonadi::Storage::Recursive);
            Utils::JobHandler::install(job->kjob(), [add, job, storage] {
                foreach (const auto &col, job->collections()) {
                    auto itemJob = storage->fetchItems(col);
                    Utils::JobHandler::install(itemJob->kjob(), [add, itemJob] {
                        foreach (const auto &item, itemJob->items())
                            add(item);
                    });
                }
            });
        };
    }
```

#### AUTO 


```{c}
const auto oldContexts = extractContextUids(m_items[item.id()]);
```

#### LAMBDA EXPRESSION 


```{c}
[this, project] (const Akonadi::Item &item) {
        return m_serializer->isProjectChild(project, item);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[storage, searchTerm, root] (const Domain::LiveQueryInput<Collection>::AddFunction &add) {
        if (searchTerm->isEmpty())
            return;

        auto job = storage->searchCollections(*searchTerm);
        Utils::JobHandler::install(job->kjob(), [root, job, add] {
            if (job->kjob()->error())
                return;

            auto directChildren = QHash<Collection::Id, Collection>();
            foreach (const auto &collection, job->collections()) {
                auto directChild = collection;
                while (directChild.parentCollection() != root && directChild.parentCollection().isValid())
                    directChild = directChild.parentCollection();
                if (directChild.parentCollection() != root)
                    continue;
                if (!directChildren.contains(directChild.id()))
                    directChildren[directChild.id()] = directChild;
            }

            foreach (const auto &directChild, directChildren.values())
                add(directChild);
        });
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto provider : providers) {
        if (!provider)
            continue;
        for (int i = 0; i < provider->data().size(); i++) {
            auto dataSource = provider->data().at(i);
            if (m_serializer->representsCollection(dataSource, collection)) {
                m_serializer->updateDataSourceFromCollection(dataSource, collection);
                provider->replace(i, dataSource);
            }
        }
    }
```

#### AUTO 


```{c}
auto task = Domain::Task::Ptr::create();
```

#### LAMBDA EXPRESSION 


```{c}
[] {}
```

#### AUTO 


```{c}
auto sourceA = Domain::DataSource::Ptr::create();
```

#### LAMBDA EXPRESSION 


```{c}
[this] (FakeJob *job) {
                                      return job->parent() != this;
                                 }
```

#### AUTO 


```{c}
const auto tag2 = Akonadi::Tag(GenTag().withId(2).withName("tag2"));
```

#### AUTO 


```{c}
auto exQuery = Domain::LiveQueryOutput<Domain::Task::Ptr>::Ptr();
```

#### AUTO 


```{c}
const auto todayDate = QDate::currentDate();
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Akonadi::Tag &tag) {
            return tag.type() == Akonadi::Serializer::contextTagType();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[storage, item] (const Domain::LiveQueryInput<Item>::AddFunction &add) {
        auto job = storage->fetchItem(item);
        Utils::JobHandler::install(job->kjob(), [storage, job, add] {
            if (job->kjob()->error() != KJob::NoError)
                return;

            Q_ASSERT(job->items().size() == 1);
            auto item = job->items()[0];
            Q_ASSERT(item.parentCollection().isValid());
            auto job = storage->fetchItems(item.parentCollection());
            Utils::JobHandler::install(job->kjob(), [job, add] {
                if (job->kjob()->error() != KJob::NoError)
                    return;

                foreach (const auto &item, job->items())
                    add(item);
            });
        });
    }
```

#### AUTO 


```{c}
auto parentUid = m_serializer->relatedUidFromItem(currentItem);
```

#### AUTO 


```{c}
auto predicate = [this] (const Akonadi::Tag &tag) {
        return tag.type() == Akonadi::SerializerInterface::contextTagType();
    };
```

#### AUTO 


```{c}
const auto currentTitle = m_artifact->title();
```

#### AUTO 


```{c}
auto delegateFunction = [this, &delegatedTask, &delegate] (const Domain::Task::Ptr &task, const Domain::Task::Delegate &d) {
            delegatedTask = task;
            delegate = d;
            return new FakeJob(this);
        };
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const DataSourceQuery::AddFunction &add) {
            CollectionFetchJobInterface *job = m_storage->fetchCollections(Akonadi::Collection::root(), StorageInterface::Recursive, StorageInterface::Tasks);
            Utils::JobHandler::install(job->kjob(), [this, job, add] {
                for (auto collection : job->collections())
                    add(collection);
            });
        }
```

#### LAMBDA EXPRESSION 


```{c}
[storage] (const Domain::LiveQueryInput<Akonadi::Item>::AddFunction &add) {
            auto job = storage->fetchCollections(Akonadi::Collection::root(), Akonadi::Storage::Recursive);
            Utils::JobHandler::install(job->kjob(), [add, job, storage] {
                foreach (const auto &col, job->collections()) {
                    auto itemJob = storage->fetchItems(col, nullptr);
                    Utils::JobHandler::install(itemJob->kjob(), [add, itemJob] {
                        foreach (const auto &item, itemJob->items())
                            add(item);
                    });
                }
            });
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Domain::Task::Ptr &task) -> Domain::QueryResultInterface<Domain::Task::Ptr>::Ptr {
        if (!task)
            return m_contextQueries->findTopLevelTasks(m_context); //FIXME : for now returns all tasks associated, not only top level ones
        else
            return Domain::QueryResult<Domain::Task::Ptr>::Ptr();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QMimeData *mimeData, Qt::DropAction, const QObjectPtr &object) {
        if (!mimeData->hasFormat("application/x-zanshin-object"))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        auto project = object.objectCast<Domain::Project>();
        if (project) {
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                m_projectRepository->associate(project, droppedArtifact);
            }
            return true;
        } else if (object == m_inboxObject) {
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                auto job = m_projectRepository->dissociate(droppedArtifact);
                if (auto task = droppedArtifact.objectCast<Domain::Task>()) {
                    Utils::JobHandler::install(job, [this, task] {
                        m_taskRepository->dissociate(task);
                    });
                }
            }
            return true;
        }

        return false;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[] (const Domain::Artifact::List &artifacts) -> QMimeData* {
        if (artifacts.isEmpty())
            return 0;

        QMimeData *data = new QMimeData;
        data->setData("application/x-zanshin-object", "object");
        data->setProperty("objects", QVariant::fromValue(artifacts));
        return data;
    }
```

#### AUTO 


```{c}
auto dataSource1 = serializer.createDataSourceFromCollection(collection, Akonadi::SerializerInterface::FullPath);
```

#### LAMBDA EXPRESSION 


```{c}
[suffixes](const QString &entry) {
                        for (const auto &suffix : suffixes) {
                            if (entry.endsWith(suffix))
                                return true;
                        }
                        return false;
                     }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &item : items) {
        m_items.insert(item.id(), item);
        if (!ids.contains(item.id()))
            ids << item.id();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Domain::Task::Ptr &task, const QVariant &value, int role) {
        if (role != Qt::EditRole && role != Qt::CheckStateRole)
            return false;

        if (role == Qt::EditRole)
            task->setTitle(value.toString());
        else
            task->setDone(value.toInt() == Qt::Checked);

        taskRepository()->update(task);
        return true;
    }
```

#### AUTO 


```{c}
auto sourceCollection = m_serializer->createCollectionFromDataSource(source);
```

#### AUTO 


```{c}
auto sourceProvider = Domain::QueryResultProvider<Domain::DataSource::Ptr>::Ptr::create();
```

#### LAMBDA EXPRESSION 


```{c}
[](const QObjectPtr &) -> QMimeData* {
        return 0;
    }
```

#### AUTO 


```{c}
const auto object = current.data(QueryTreeModelBase::ObjectRole).value<QObjectPtr>();
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Domain::Artifact::Ptr &artifact, const QVariant &value, int role) {
        Q_UNUSED(artifact);
        Q_UNUSED(value);
        Q_UNUSED(role);
        qFatal("Not implemented yet");
        return false;
    }
```

#### AUTO 


```{c}
auto searchEdit = available.findChild<QLineEdit*>(QStringLiteral("searchEdit"));
```

#### LAMBDA EXPRESSION 


```{c}
[] (const QString &s) {
            bool ok = false;
            const int id = s.toInt(&ok);
            if (ok) {
                auto object = QObjectPtr::create();
                object->setProperty("id", id);
                return object;
            } else {
                return QObjectPtr();
            }
        }
```

#### AUTO 


```{c}
auto predicate = [this, context] (const Akonadi::Item &item) {
        if (!m_serializer->isContextChild(context, item))
            return false;

        const auto items = m_cache->items(item.parentCollection());
        auto currentItem = item;
        auto parentUid = m_serializer->relatedUidFromItem(currentItem);
        while (!parentUid.isEmpty()) {
            const auto parent = std::find_if(items.cbegin(), items.cend(),
                                             [this, parentUid] (const Akonadi::Item &item) {
                                                 return m_serializer->itemUid(item) == parentUid;
                                             });
            if (parent == items.cend())
                break;

            if (m_serializer->isContextChild(context, *parent))
                return false;

            currentItem = *parent;
            parentUid = m_serializer->relatedUidFromItem(currentItem);
        }

        return true;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[storage] (const Domain::LiveQueryInput<Akonadi::Collection>::AddFunction &add) {
            auto job = storage->fetchCollections(Akonadi::Collection::root(), Akonadi::Storage::Recursive);
            Utils::JobHandler::install(job->kjob(), [add, job] {
                foreach (const auto &col, job->collections()) {
                    add(col);
                }
            });
        }
```

#### AUTO 


```{c}
auto provider
```

#### AUTO 


```{c}
auto inboxResult = Domain::QueryResult<Domain::Task::Ptr>::create(inboxProvider);
```

#### AUTO 


```{c}
const auto gid = tag.gid();
```

#### AUTO 


```{c}
auto childItem = fetchItemJob->items().at(0);
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString &value, int pos)
            {
                postRemoves << value;
                postRemovesPos << pos;
            }
```

#### AUTO 


```{c}
auto job = storage.fetchCollections(rootCollection, fetchDepth);
```

#### LAMBDA EXPRESSION 


```{c}
[&](const Domain::Task::Ptr &task, const QVariant &value, int role) {
            if (role != Qt::EditRole && role != Qt::CheckStateRole) {
                return false;
            }

            if (role == Qt::EditRole) {
                task->setTitle(value.toString());
            } else {
                task->setDone(value.toInt() == Qt::Checked);
            }

            repositoryMock.getInstance()->update(task);
            return true;
        }
```

#### AUTO 


```{c}
auto drop = [this](const QMimeData *mimeData, Qt::DropAction, const Domain::Artifact::Ptr &artifact) {
        auto parentTask = artifact.objectCast<Domain::Task>();
        if (!parentTask)
            return false;

        if (!mimeData->hasFormat("application/x-zanshin-object"))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                        [](const Domain::Artifact::Ptr &droppedArtifact) {
                            return !droppedArtifact.objectCast<Domain::Task>();
                        })) {
            return false;
        }

        foreach(const Domain::Artifact::Ptr &droppedArtifact, droppedArtifacts) {
            auto childTask = droppedArtifact.objectCast<Domain::Task>();
            const auto job = m_taskRepository->associate(parentTask, childTask);
            installHandler(job, tr("Cannot move task %1 as a sub-task of %2").arg(childTask->title()).arg(parentTask->title()));
        }

        return true;
    };
```

#### AUTO 


```{c}
const auto parentTask = parentArtifact.objectCast<Domain::Task>();
```

#### LAMBDA EXPRESSION 


```{c}
[](const Domain::Task::Ptr &) {
            return Qt::NoItemFlags;
        }
```

#### AUTO 


```{c}
auto result = QueryResult<QString>::create(provider);
```

#### LAMBDA EXPRESSION 


```{c}
[storage, contentTypes] (const Domain::LiveQueryInput<Collection>::AddFunction &add) {
        auto job = storage->fetchCollections(Collection::root(), StorageInterface::Recursive, contentTypes);
        Utils::JobHandler::install(job->kjob(), [job, add] {
            if (job->kjob()->error())
                return;

            foreach (const auto &collection, job->collections())
                add(collection);
        });
    }
```

#### LAMBDA EXPRESSION 


```{c}
[ancestorItem, todo](Akonadi::Item currentItem) {
                                          return (!currentItem.hasPayload<KCalCore::Todo::Ptr>()
                                               || currentItem == ancestorItem
                                               || currentItem.payload<KCalCore::Todo::Ptr>()->relatedTo() != todo->uid());
                                      }
```

#### AUTO 


```{c}
auto fetch = m_helpers->fetchItems(StorageInterface::Tasks);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &row : data.rows) {
        VERIFY_OR_DUMP(usedRoles.size() == row.size());

        QStandardItem *item = new QStandardItem;
        for (int i = 0; i < row.size(); ++i) {
            const auto role = usedRoles.at(i);
            const auto value = row.at(i);
            item->setData(value, role);
        }
        inputModel.appendRow(item);
    }
```

#### AUTO 


```{c}
auto isWorkdayItem = [this] (const Akonadi::Item &item) {
        if (!m_serializer->isTaskItem(item))
            return false;

        const Domain::Task::Ptr task = m_serializer->createTaskFromItem(item);

        const QDate doneDate = task->doneDate();
        const QDate startDate = task->startDate();
        const QDate dueDate = task->dueDate();
        const QDate today = Utils::DateTime::currentDate();

        const bool pastStartDate = startDate.isValid() && startDate <= today;
        const bool pastDueDate = dueDate.isValid() && dueDate <= today;
        const bool todayDoneDate = doneDate == today;

        if (task->isDone())
            return todayDoneDate;
        else
            return pastStartDate || pastDueDate;
    };
```

#### AUTO 


```{c}
auto dragFunction = [] (const QList<QColor> &colors) {
            auto mimeData = new QMimeData;
            mimeData->setColorData(QVariant::fromValue(colors));
            return mimeData;
        };
```

#### AUTO 


```{c}
auto exPredicate = [] (const Akonadi::Tag &tag) {
            return tag.name().endsWith(QLatin1String("-ex"));
        };
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QObjectPtr &object) {
        const Qt::ItemFlags defaultFlags = Qt::ItemIsSelectable
                                         | Qt::ItemIsEnabled
                                         | Qt::ItemIsEditable
                                         | Qt::ItemIsDropEnabled;
        const Qt::ItemFlags immutableNodeFlags = Qt::ItemIsSelectable
                                               | Qt::ItemIsEnabled
                                               | Qt::ItemIsDropEnabled;
        const Qt::ItemFlags structureNodeFlags = Qt::NoItemFlags;

        return object.objectCast<Domain::Project>() ? defaultFlags
             : object == m_inboxObject ? immutableNodeFlags
             : structureNodeFlags;
    }
```

#### AUTO 


```{c}
auto model = Utils::DependencyManager::globalInstance().create<EditorModel>();
```

#### AUTO 


```{c}
auto childTask4 = Domain::Task::Ptr::create();
```

#### AUTO 


```{c}
auto queryGenerator = [&] (const QString &string) {
            if (string.isEmpty())
                return Domain::QueryResult<QString>::create(topProvider);
            else if (string == QLatin1String("2"))
                return Domain::QueryResult<QString>::create(firstLevelProvider);
            else if (string == QLatin1String("2.1"))
                return Domain::QueryResult<QString>::create(secondLevelProvider);
            else
                return Domain::QueryResult<QString>::Ptr();
        };
```

#### AUTO 


```{c}
auto expectedTotoNames = QStringList();
```

#### AUTO 


```{c}
auto term = QString();
```

#### AUTO 


```{c}
const auto message = item.payload<KMime::Message::Ptr>();
```

#### LAMBDA EXPRESSION 


```{c}
[](const Domain::Artifact::List &artifacts) -> QMimeData* {
        if (artifacts.isEmpty())
            return 0;

        QMimeData *data = new QMimeData;
        data->setData("application/x-zanshin-object", "object");
        data->setProperty("objects", QVariant::fromValue(artifacts));
        return data;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=] () mutable {
            collection.setId(m_data->maxCollectionId() + 1);
            m_data->createCollection(collection);
        }
```

#### AUTO 


```{c}
const auto isDefault = index.data(Presentation::QueryTreeModel<Domain::DataSource::Ptr>::IsDefaultRole).toBool();
```

#### AUTO 


```{c}
auto collectionsJob = m_storage.fetchCollections(Akonadi::Collection::root(), Akonadi::Storage::Recursive, Akonadi::StorageInterface::Tasks);
```

#### AUTO 


```{c}
auto job = new CollectionSearchJob(collectionName);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto id : idList(max)) {
            list << Collection(id);
        }
```

#### AUTO 


```{c}
auto it = newItemList.constBegin();
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QMimeData *mimeData, Qt::DropAction, const Domain::Task::Ptr &task) {
        auto parentTask = task.objectCast<Domain::Task>();

        if (!mimeData->hasFormat("application/x-zanshin-object"))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                        [](const Domain::Artifact::Ptr &droppedArtifact) {
                            return !droppedArtifact.objectCast<Domain::Task>();
                        })) {
            return false;
        }

        foreach(const auto &droppedArtifact, droppedArtifacts) {
            auto childTask = droppedArtifact.objectCast<Domain::Task>();

            if (parentTask) {
                const auto job = m_taskRepository->associate(parentTask, childTask);
                installHandler(job, tr("Cannot move task %1 as sub-task of %2").arg(childTask->title()).arg(parentTask->title()));
            } else {
                const auto job = m_taskRepository->dissociate(childTask);
                installHandler(job, tr("Cannot deparent task %1 from its parent").arg(childTask->title()));
            }
        }

        return true;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[allowedMimeTypes] (const Collection &collection) {
                                            auto mimeTypes = collection.contentMimeTypes().toSet();
                                            return mimeTypes.intersect(allowedMimeTypes).isEmpty();
                                         }
```

#### AUTO 


```{c}
auto job = storage->fetchItem(item1, nullptr);
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Domain::Task::Ptr &task, const QVariant &value, int role) {
        if (role != Qt::EditRole && role != Qt::CheckStateRole)
            return false;

        const auto currentTitle = task->title();
        if (role == Qt::EditRole)
            task->setTitle(value.toString());
        else
            task->setDone(value.toInt() == Qt::Checked);

        const auto job = m_taskRepository->update(task);
        installHandler(job, i18n("Cannot modify task %1 in context %2", currentTitle, m_context->name()));
        return true;
    }
```

#### AUTO 


```{c}
auto it = std::find_if(items.constBegin(), items.constEnd(),
                                       [relatedUid, this] (const Akonadi::Item &item) {
                    return m_serializer->itemUid(item) == relatedUid;
                });
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &item : items) {
            itemRemoteIds << item.remoteId();
            QVERIFY(item.loadedPayloadParts().contains(Akonadi::Item::FullPayload));
            QVERIFY(!item.attributes().isEmpty());
            QVERIFY(item.modificationTime().isValid());
            QVERIFY(!item.flags().isEmpty());

            Akonadi::Tag::List tags = item.tags();
            QVERIFY(!item.tags().isEmpty());
            for (const auto &tag : tags) {
                QVERIFY(tag.isValid());
                QVERIFY(!tag.name().isEmpty());
                QVERIFY(!tag.type().isEmpty());
            }

            auto parent = item.parentCollection();
            while (parent != Akonadi::Collection::root()) {
                QVERIFY(parent.isValid());
                parent = parent.parentCollection();
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Domain::Note::Ptr &note) -> Domain::QueryResultInterface<Domain::Note::Ptr>::Ptr {
        if (!note)
            return m_tagQueries->findNotes(m_tag);
        else
            return Domain::QueryResult<Domain::Note::Ptr>::Ptr();
    }
```

#### AUTO 


```{c}
auto context = provider->data().at(i);
```

#### AUTO 


```{c}
auto originalDelegate = task->delegate();
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Domain::Task::Ptr &task, const QVariant &value, int role) {
        if (role != Qt::EditRole && role != Qt::CheckStateRole)
            return false;

        const auto currentTitle = task->title();
        if (role == Qt::EditRole)
            task->setTitle(value.toString());
        else
            task->setDone(value.toInt() == Qt::Checked);

        const auto job = taskRepository()->update(task);
        if (!errorHandler())
            return true;

        errorHandler()->installHandler(job, tr("Cannot modify task %1 in context %2").arg(currentTitle).arg(m_context->name()));
        return true;
    }
```

#### AUTO 


```{c}
auto result = Result::create(provider);
```

#### AUTO 


```{c}
auto description = new QLabel(this);
```

#### AUTO 


```{c}
auto itemJob = new Akonadi::ItemFetchJob(col);
```

#### AUTO 


```{c}
auto task = childProvider->data().at(i);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QMimeData *mimeData, Qt::DropAction, const QObjectPtr &object) {
        if (!mimeData->hasFormat(QStringLiteral("application/x-zanshin-object")))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                        [](const Domain::Artifact::Ptr &droppedArtifact) {
                            return !droppedArtifact.objectCast<Domain::Note>();
                        })) {
            return false;
        }

        if (auto tag = object.objectCast<Domain::Tag>()) {
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                auto note = droppedArtifact.staticCast<Domain::Note>();
                const auto job = m_tagRepository->associate(tag, note);
                installHandler(job, i18n("Cannot tag %1 with %2", note->title(), tag->name()));
            }
            return true;
        } else if (object == m_inboxObject) {
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                auto note = droppedArtifact.staticCast<Domain::Note>();
                const auto job = m_tagRepository->dissociateAll(note);
                installHandler(job, i18n("Cannot move %1 to Inbox", note->title()));
            }
            return true;
        }

        return false;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[storage, item] (const Domain::LiveQueryInput<Item>::AddFunction &add) {
        auto job = storage->fetchItem(item);
        Utils::JobHandler::install(job->kjob(), [storage, job, add] {
            if (job->kjob()->error() != KJob::NoError)
                return;

            Q_ASSERT(job->items().size() == 1);
            auto item = job->items().at(0);
            Q_ASSERT(item.parentCollection().isValid());
            auto job = storage->fetchItems(item.parentCollection());
            Utils::JobHandler::install(job->kjob(), [job, add] {
                if (job->kjob()->error() != KJob::NoError)
                    return;

                foreach (const auto &item, job->items())
                    add(item);
            });
        });
    }
```

#### AUTO 


```{c}
auto sourceModel = createSourceModel();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto collection : job->collections()) {
            ItemFetchJobInterface *job = m_storage->fetchItems(collection);
            Utils::JobHandler::install(job->kjob(), [provider, job, project, this] {
                if (job->kjob()->error() != KJob::NoError)
                    return;

                for (auto item : job->items()) {
                    if (m_serializer->isProjectChild(project, item)) {
                        auto artifact = deserializeArtifact(item);
                        if (artifact)
                            provider->append(artifact);
                    }
                }
            });
        }
```

#### AUTO 


```{c}
auto item = job->items().first();
```

#### LAMBDA EXPRESSION 


```{c}
[storage, job, add] {
            if (job->kjob()->error() != KJob::NoError)
                return;

            Q_ASSERT(job->items().size() == 1);
            auto item = job->items()[0];
            Q_ASSERT(item.parentCollection().isValid());
            auto job = storage->fetchItems(item.parentCollection());
            Utils::JobHandler::install(job->kjob(), [job, add] {
                if (job->kjob()->error() != KJob::NoError)
                    return;

                foreach (const auto &item, job->items())
                    add(item);
            });
        }
```

#### LAMBDA EXPRESSION 


```{c}
[fetchCollectionJob, item, job, this] {
            if (fetchCollectionJob->kjob()->error() != KJob::NoError)
                return;

            Q_ASSERT(fetchCollectionJob->collections().size() > 0);
            const Akonadi::Collection::List collections = fetchCollectionJob->collections();
            auto it = std::find_if(collections.constBegin(), collections.constEnd(),
                                   [] (const Akonadi::Collection &c) {
                return (c.rights() & Akonadi::Collection::CanCreateItem)
                    && (c.rights() & Akonadi::Collection::CanChangeItem)
                    && (c.rights() & Akonadi::Collection::CanDeleteItem);
            });
            if (it == collections.constEnd()) {
                job->emitError(i18n("Could not find a collection to store the task into!"));
            } else {
                auto col = *it;
                Q_ASSERT(col.isValid());
                auto createJob = m_storage->createItem(item, col);
                job->addSubjob(createJob);
                createJob->start();
            }
        }
```

#### AUTO 


```{c}
auto job = new AkonadiFakeItemFetchJob(parent);
```

#### AUTO 


```{c}
const auto tagFetchNames = [job, toTagNames]{
                return toTagNames(job->tags());
            }();
```

#### AUTO 


```{c}
const auto source = object.objectCast<Domain::DataSource>()
```

#### AUTO 


```{c}
auto itemB = new QStandardItem(QStringLiteral("B"));
```

#### RANGE FOR STATEMENT 


```{c}
for (auto collection : job->collections()) {
            ItemFetchJobInterface *job = m_storage->fetchItems(collection);
            Utils::JobHandler::install(job->kjob(), [provider, job, this] {
                for (auto item : job->items()) {
                    auto note = deserializeNote(item);
                    if (note)
                        provider->append(note);
                }
            });
        }
```

#### LAMBDA EXPRESSION 


```{c}
[] (const Akonadi::Collection &collection) {
            return collection.name().endsWith(QLatin1String("-in"));
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Domain::LiveRelationshipQuery<QObject*, QString>::AddFunction &add) {
            Utils::JobHandler::install(new FakeJob, [this, add] {
                add(createObject(1, QStringLiteral("ItemA")));
                add(createObject(2, QStringLiteral("ProjectA"))); // parent promoted to project
            });
        }
```

#### AUTO 


```{c}
const auto job = m_noteRepository->remove(note);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto task : childrenTasks)
            childrenProvider->append(task);
```

#### LAMBDA EXPRESSION 


```{c}
[this, &savedTask] (const Domain::Task::Ptr &task) {
            savedTask = task;
            return new FakeJob(this);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[] (const Akonadi::Tag &tag) {
            return tag.name().endsWith("-in");
        }
```

#### AUTO 


```{c}
auto data = [this](const QObjectPtr &object, int role, int) -> QVariant {
        if (role != Qt::DisplayRole
         && role != Qt::EditRole
         && role != Qt::DecorationRole
         && role != QueryTreeModelBase::IconNameRole) {
            return QVariant();
        }

        if (role == Qt::EditRole
         && (object == m_inboxObject
          || object == m_tagsObject)) {
            return QVariant();
        }

        if (role == Qt::DisplayRole || role == Qt::EditRole) {
            return object->property("name").toString();
        } else if (role == Qt::DecorationRole || role == QueryTreeModelBase::IconNameRole) {
            const QString iconName = (object == m_inboxObject) ? QStringLiteral("mail-folder-inbox")
                                   : (object == m_tagsObject)  ? QStringLiteral("folder")
                                   : QStringLiteral("view-pim-tasks");

            if (role == Qt::DecorationRole)
                return QVariant::fromValue(QIcon::fromTheme(iconName));
            else
                return iconName;
        } else {
            return QVariant();
        }
    };
```

#### AUTO 


```{c}
auto flags = [](const Domain::Note::Ptr &) {
        return Qt::ItemIsSelectable
             | Qt::ItemIsEnabled
             | Qt::ItemIsEditable
             | Qt::ItemIsDragEnabled;
    };
```

#### AUTO 


```{c}
auto topLevelNote = Domain::Note::Ptr::create();
```

#### AUTO 


```{c}
auto fetch = [storage] (const Domain::LiveQueryInput<Akonadi::Tag>::AddFunction &add) {
            auto job = storage->fetchTags();
            Utils::JobHandler::install(job->kjob(), [add, job] {
                foreach (const auto &tag, job->tags()) {
                    add(tag);
                }
            });
        };
```

#### AUTO 


```{c}
auto addFunction = [this, provider] (const InputType &input) {
            if (m_predicate(input))
                provider->append(m_convert(input));
        };
```

#### AUTO 


```{c}
auto taskRepository = Domain::TaskRepository ::Ptr();
```

#### LAMBDA EXPRESSION 


```{c}
[fetchItemJob, context, job, this] {
        if (fetchItemJob->kjob()->error() != KJob::NoError)
            return;

        Q_ASSERT(fetchItemJob->items().size() == 1);
        auto childItem = fetchItemJob->items().at(0);
        m_serializer->addContextToTask(context, childItem);

        auto updateJob = m_storage->updateItem(childItem, this);
        job->addSubjob(updateJob);
        updateJob->start();
    }
```

#### AUTO 


```{c}
auto item = Akonadi::Item();
```

#### LAMBDA EXPRESSION 


```{c}
[childId] (const Akonadi::Item &item) {
                                                 return childId == item.id();
                                             }
```

#### LAMBDA EXPRESSION 


```{c}
[persistentIndex](const Domain::Context::Ptr &, int) {
                // When a project was found (inserted into the result), update the rendering of the item
                auto model = const_cast<QAbstractItemModel *>(persistentIndex.model());
                model->dataChanged(persistentIndex, persistentIndex);
            }
```

#### AUTO 


```{c}
auto fetch = helpers->fetchSiblings(item);
```

#### AUTO 


```{c}
auto result = QStringList();
```

#### AUTO 


```{c}
auto job = storage->fetchCollections(Akonadi::Collection::root(),
                                         Akonadi::Storage::Recursive);
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Domain::Artifact::Ptr &artifact) -> Domain::QueryResultInterface<Domain::Artifact::Ptr>::Ptr {
        if (!artifact)
            return m_tagQueries->findTopLevelArtifacts(m_tag);
        else if (auto task = artifact.dynamicCast<Domain::Task>())
            return Domain::QueryResult<Domain::Task::Ptr, Domain::Artifact::Ptr>::copy(taskQueries()->findChildren(task));
        else
            return Domain::QueryResult<Domain::Artifact::Ptr>::Ptr();
    }
```

#### AUTO 


```{c}
const auto toCollectionNames = [](const Akonadi::Collection::List &collections) {
            auto res = QStringList();
            std::transform(collections.cbegin(), collections.cend(),
                           std::back_inserter(res),
                           std::mem_fn(&Akonadi::Collection::name));
            res.sort();
            return res;
        };
```

#### AUTO 


```{c}
auto task1 = model->data(task1Index, Presentation::QueryTreeModelBase::ObjectRole).value<Domain::Task::Ptr>();
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
            FakeJob *job2 = new FakeJob(this);
            QObject::connect(job2, SIGNAL(result(KJob*)), this, SLOT(handleJobResult(KJob*)));
            compositeJob->addSubjob(job2);
            job2->start();
        }
```

#### AUTO 


```{c}
auto result = item;
```

#### AUTO 


```{c}
auto result2 = queries->findTopLevelArtifacts(project2);
```

#### LAMBDA EXPRESSION 


```{c}
[this] (Utils::DependencyManager *) -> Akonadi::MessagingInterface* {
            return Q_NULLPTR;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, job, add] {
                if (job->kjob()->error() != KJob::NoError)
                    return;

                Q_ASSERT(job->items().size() == 1);
                auto item = job->items()[0];
                Q_ASSERT(item.parentCollection().isValid());
                ItemFetchJobInterface *job = m_storage->fetchItems(item.parentCollection());
                Utils::JobHandler::install(job->kjob(), [this, job, add] {
                    if (job->kjob()->error() != KJob::NoError)
                        return;

                    for (auto item : job->items())
                        add(item);
                });
            }
```

#### AUTO 


```{c}
const auto parentId = findParentId(item);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Domain::Note::Ptr &note, const QVariant &value, int role) {
        if (role != Qt::EditRole) {
            return false;
        }

        const auto currentTitle = note->title();
        note->setTitle(value.toString());
        const auto job = m_noteRepository->update(note);
        installHandler(job, tr("Cannot modify note %1 in Inbox").arg(currentTitle));
        return true;
    }
```

#### AUTO 


```{c}
auto setData = [this](const QObjectPtr &object, const QVariant &value, int role) {
        if (role != Qt::EditRole) {
            return false;
        }

        if (object == m_inboxObject
         || object == m_workdayObject
         || object == m_projectsObject
         || object == m_contextsObject
         || object.objectCast<Domain::DataSource>()) {
            return false;
        }

        if (auto project = object.objectCast<Domain::Project>()) {
            const auto currentName = project->name();
            project->setName(value.toString());
            const auto job = m_projectRepository->update(project);
            installHandler(job, i18n("Cannot modify project %1", currentName));
        } else if (auto context = object.objectCast<Domain::Context>()) {
            const auto currentName = context->name();
            context->setName(value.toString());
            const auto job = m_contextRepository->update(context);
            installHandler(job, i18n("Cannot modify context %1", currentName));
        } else {
            Q_ASSERT(false);
        }

        return true;
    };
```

#### AUTO 


```{c}
auto currentPage = new QObject(model.data());
```

#### AUTO 


```{c}
auto task = page.addTask(title);
```

#### AUTO 


```{c}
auto goToAction = new QAction(this);
```

#### AUTO 


```{c}
auto drop = [this](const QMimeData *mimeData, Qt::DropAction, const Domain::Task::Ptr &parentTask) {
        if (!mimeData->hasFormat("application/x-zanshin-object"))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                        [](const Domain::Artifact::Ptr &droppedArtifact) {
                            return !droppedArtifact.objectCast<Domain::Task>();
                        })) {
            return false;
        }

        using namespace std::placeholders;
        auto associate = std::function<KJob*(Domain::Task::Ptr)>();
        auto parentTitle = QString();

        if (parentTask) {
            associate = std::bind(&Domain::TaskRepository::associate, m_taskRepository, parentTask, _1);
            parentTitle = parentTask->title();
        } else {
            associate = std::bind(&Domain::ProjectRepository::associate, m_projectRepository, m_project, _1);
            parentTitle = m_project->name();
        }

        foreach(const Domain::Artifact::Ptr &droppedArtifact, droppedArtifacts) {
            auto childTask = droppedArtifact.objectCast<Domain::Task>();
            const auto job = associate(childTask);
            installHandler(job, tr("Cannot move task %1 as a sub-task of %2").arg(childTask->title(), parentTitle));
        }

        return true;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QMimeData *mimeData, Qt::DropAction, const QObjectPtr &object) {
        if (!mimeData->hasFormat(QStringLiteral("application/x-zanshin-object")))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                        [](const Domain::Artifact::Ptr &droppedArtifact) {
                            return !droppedArtifact.objectCast<Domain::Note>();
                        })) {
            return false;
        }

        if (auto tag = object.objectCast<Domain::Tag>()) {
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                auto note = droppedArtifact.staticCast<Domain::Note>();
                const auto job = m_tagRepository->associate(tag, note);
                installHandler(job, tr("Cannot tag %1 with %2").arg(note->title(), tag->name()));
            }
            return true;
        } else if (object == m_inboxObject) {
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                auto note = droppedArtifact.staticCast<Domain::Note>();
                const auto job = m_tagRepository->dissociateAll(note);
                installHandler(job, tr("Cannot move %1 to Inbox").arg(note->title()));
            }
            return true;
        }

        return false;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, job, add] {
                        if (job->kjob()->error() != KJob::NoError)
                            return;

                        for (auto item : job->items())
                            add(item);
                    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &) {
            return Domain::QueryResult<QString>::Ptr();
        }
```

#### AUTO 


```{c}
const auto indexes = QModelIndexList() << model.index(0, 0)
                                               << model.index(1, 0)
                                               << model.index(1, 0, model.index(1, 0));
```

#### AUTO 


```{c}
const auto tagCachedNames = [cache, toTagNames]{
                const auto tags = cache->tags();
                return toTagNames(tags);
            }();
```

#### LAMBDA EXPRESSION 


```{c}
[&removeHandlerCalled](const Domain::Artifact::Ptr &, int) {
                                          removeHandlerCalled = true;
                                      }
```

#### AUTO 


```{c}
const auto parentId = findParentId(newCollection);
```

#### AUTO 


```{c}
auto fetch = m_helpers->fetchAllCollections(StorageInterface::Tasks);
```

#### LAMBDA EXPRESSION 


```{c}
[provider, job, task, this] {
            for (auto item : job->items()) {
                if (m_serializer->isTaskChild(task, item)) {
                    auto task = deserializeTask(item);
                    if (task)
                        provider->append(task);
                }
            }
        }
```

#### AUTO 


```{c}
auto task1 = serializer->createTaskFromItem(data.item(42));
```

#### AUTO 


```{c}
const auto source = sourceForIndex(index);
```

#### AUTO 


```{c}
auto editorView = new EditorView(m_parent);
```

#### LAMBDA EXPRESSION 


```{c}
[fetchItemJob, parent, job, this] {
        if (fetchItemJob->kjob()->error() != KJob::NoError)
            return;

        Q_ASSERT(fetchItemJob->items().size() == 1);
        auto childItem = fetchItemJob->items().first();
        auto tag = m_serializer->createAkonadiTagFromTag(parent);
        Q_ASSERT(tag.isValid());
        childItem.clearTag(tag);

        auto updateJob = m_storage->updateItem(childItem);
        job->addSubjob(updateJob);
        updateJob->start();
    }
```

#### AUTO 


```{c}
auto treeSetData = [&](const Domain::Task::Ptr &task, const QVariant &value, int role) {
        if (role != Qt::EditRole && role != Qt::CheckStateRole) {
            return false;
        }

        if (role == Qt::EditRole) {
            task->setTitle(value.toString());
        } else {
            task->setDone(value.toInt() == Qt::Checked);
        }

        repository->update(task);
        return true;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Akonadi::Collection &collection) {
            return m_serializer->createDataSourceFromCollection(collection, SerializerInterface::FullPath);
        }
```

#### AUTO 


```{c}
auto source3Result = Domain::QueryResult<Domain::DataSource::Ptr>::create(source3Provider);
```

#### AUTO 


```{c}
auto removeAction = new QAction(this);
```

#### AUTO 


```{c}
auto res = QStringList();
```

#### AUTO 


```{c}
auto summaryRect = textRect.adjusted(0, 0, -dueDateWidth, 0);
```

#### AUTO 


```{c}
const auto result = m_migrator.fetchAllItems(WhichItems::TasksToConvert);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &attachment : task->attachments()) {
#if KCALCORE_VERSION >= QT_VERSION_CHECK(5, 11, 80)
        KCalCore::Attachment attach(QByteArray{});
        if (attachment.isUri())
            attach.setUri(attachment.uri().toString());
        else
            attach.setDecodedData(attachment.data());
        attach.setMimeType(attachment.mimeType());
        attach.setLabel(attachment.label());
#else
        KCalCore::Attachment::Ptr attach(new KCalCore::Attachment(QByteArray()));
        if (attachment.isUri())
            attach->setUri(attachment.uri().toString());
        else
            attach->setDecodedData(attachment.data());
        attach->setMimeType(attachment.mimeType());
        attach->setLabel(attachment.label());
#endif
        todo->addAttachment(attach);
    }
```

#### AUTO 


```{c}
auto predicate = createFetchPredicate(root);
```

#### AUTO 


```{c}
const auto onDueDate = dueDate.isValid() && dueDate.date() == QDate::currentDate();
```

#### AUTO 


```{c}
auto job = storage->fetchItems(item.parentCollection(), parent);
```

#### AUTO 


```{c}
auto job = new CompositeJob();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &item : items) {
        m_serializer.clearItem(&item);
        const auto allTags = item.tags();
        for (const auto &tag : allTags) {
            if (tag.type() == s_contextTagType) {
                auto context = Domain::Context::Ptr::create();
                context->setName(tag.name());
                const auto tagUid = m_tagUids.value(tag.id());
                if (tagUid.isEmpty())
                    qWarning() << "Item" << item.id() << "uses unknown tag" << tag.id() << tag.name();
                context->setProperty("todoUid", tagUid);
                m_serializer.addContextToTask(context, item);
                auto job = new Akonadi::ItemModifyJob(item);
                if (job->exec()) {
                    item = job->item();
                    ++count;
                } else {
                    qWarning() << "Failure to associate context" << tag.name() << "to task:" << job->errorString();
                }
            }
        }
        // While we're here, port from "Project" to "ISPROJECT"
        auto todo = item.payload<KCalCore::Todo::Ptr>();
        if (!todo->customProperty("Zanshin", "Project").isEmpty()) {
            todo->setCustomProperty(Serializer::customPropertyAppName(), Serializer::customPropertyIsProject(), QStringLiteral("1"));
            auto job = new Akonadi::ItemModifyJob(item);
            job->exec();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &oldTag : oldTags) {
        if (!newTags.contains(oldTag) && m_tagItems.contains(oldTag.id())) {
            m_tagItems[oldTag.id()].removeAll(oldTag.id());
        }
    }
```

#### AUTO 


```{c}
auto drop = [this](const QMimeData *mimeData, Qt::DropAction, const QObjectPtr &object) {
        if (!mimeData->hasFormat(QStringLiteral("application/x-zanshin-object")))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (auto project = object.objectCast<Domain::Project>()) {
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                const auto job = m_projectRepository->associate(project, droppedArtifact);
                installHandler(job, tr("Cannot add %1 to project %2").arg(droppedArtifact->title(), project->name()));
            }
            return true;
        } else if (auto context = object.objectCast<Domain::Context>()) {
            if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                            [](const Domain::Artifact::Ptr &droppedArtifact) {
                                return !droppedArtifact.objectCast<Domain::Task>();
                            })) {
                return false;
            }
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                auto task = droppedArtifact.staticCast<Domain::Task>();
                const auto job = m_contextRepository->associate(context, task);
                installHandler(job, tr("Cannot add %1 to context %2").arg(task->title(), context->name()));
            }
            return true;
        } else if (object == m_inboxObject) {
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                const auto job = m_projectRepository->dissociate(droppedArtifact);
                installHandler(job, tr("Cannot move %1 to Inbox").arg(droppedArtifact->title()));

                if (auto task = droppedArtifact.objectCast<Domain::Task>()) {
                    Utils::JobHandler::install(job, [this, task] {
                        const auto dissociateJob = m_taskRepository->dissociateAll(task);
                        installHandler(dissociateJob, tr("Cannot move task %1 to Inbox").arg(task->title()));
                    });
                }
            }
            return true;
        } else if (object == m_workdayObject) {
            foreach (const auto &droppedArtifact, droppedArtifacts) {

                if (auto task = droppedArtifact.objectCast<Domain::Task>()) {

                    task->setStartDate(Utils::DateTime::currentDateTime());
                    const auto job = m_taskRepository->update(task);

                    installHandler(job, tr("Cannot update task %1 to Workday").arg(task->title()));
                }
            }
            return true;
        }

        return false;
    };
```

#### AUTO 


```{c}
auto contextPageModel = new ContextPageModel(context,
                                                     m_contextQueries,
                                                     m_taskQueries,
                                                     m_taskRepository,
                                                     m_noteRepository,
                                                     this);
```

#### AUTO 


```{c}
auto job = storage.updateTag(tag);
```

#### AUTO 


```{c}
auto context = serializer->createContextFromItem(data.item(1));
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Domain::LiveRelationshipQuery<QObject*, QString>::AddFunction &add) {
            Utils::JobHandler::install(new FakeJob, [this, add] {
                add(createObject(0, QStringLiteral("ProjectA")));
                add(createObject(1, QStringLiteral("ItemA")));
                add(createObject(2, QStringLiteral("ParentA")));
                add(createObject(3, QStringLiteral("ProjectB-Renamed")));
                add(createObject(4, QStringLiteral("ItemB")));
                add(createObject(5, QStringLiteral("ParentB")));
                add(createObject(6, QStringLiteral("ProjectC")));
                add(createObject(7, QStringLiteral("ItemC")));
                add(createObject(8, QStringLiteral("ParentC")));
            });
        }
```

#### AUTO 


```{c}
const auto artifact = index.data(QueryTreeModelBase::ObjectRole).value<Domain::Artifact::Ptr>();
```

#### AUTO 


```{c}
auto source3 = Domain::DataSource::Ptr::create();
```

#### LAMBDA EXPRESSION 


```{c}
[&](const Base::Ptr &value, int pos)
            {
                preInserts << value;
                preInsertsPos << pos;
            }
```

#### AUTO 


```{c}
auto save = [this, &savedArtifact] (const Domain::Artifact::Ptr &artifact) {
            savedArtifact = artifact;
            return new FakeJob(this);
        };
```

#### AUTO 


```{c}
auto relatedHeader = message->headerByType("X-Zanshin-RelatedProjectUid")
```

#### AUTO 


```{c}
auto itemB = new QStandardItem("B");
```

#### AUTO 


```{c}
auto updateJob = m_storage->updateItem(childItem, this);
```

#### AUTO 


```{c}
auto centralView = page.findChild<QTreeView*>("centralView");
```

#### LAMBDA EXPRESSION 


```{c}
[this] (Utils::DependencyManager *) {
            return m_data.createMonitor();
        }
```

#### AUTO 


```{c}
auto sourceIndices = QModelIndexList();
```

#### LAMBDA EXPRESSION 


```{c}
[this, &afterReset] (const Domain::LiveRelationshipQuery<QObject*, QString>::AddFunction &add) {
            Utils::JobHandler::install(new FakeJob, [this, &afterReset, add] {
                add(createObject(0, QStringLiteral("ProjectA")));
                add(createObject(1, QStringLiteral("ItemA")));
                add(createObject(2, QStringLiteral("ParentA")));
                add(createObject(3, QStringLiteral("ProjectB")));
                add(createObject(4, QStringLiteral("ItemB")));
                add(createObject(5, QStringLiteral("ParentB")));

                if (afterReset) {
                    add(createObject(6, QStringLiteral("ProjectC")));
                    add(createObject(7, QStringLiteral("ItemC")));
                    add(createObject(8, QStringLiteral("ParentC")));
                }
            });
        }
```

#### AUTO 


```{c}
auto note = child.objectCast<Domain::Note>()
```

#### AUTO 


```{c}
const auto job = m_contextRepository->update(context);
```

#### AUTO 


```{c}
auto query = [this](const Domain::Task::Ptr &task) -> Domain::QueryResultInterface<Domain::Task::Ptr>::Ptr {
        if (!task)
            return m_projectQueries->findTopLevel(m_project);
        else
            return m_taskQueries->findChildren(task);
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Domain::Task::Ptr &task, const QVariant &value, int role) {
        if (role != Qt::EditRole && role != Qt::CheckStateRole)
            return false;

        const auto currentTitle = task->title();
        if (role == Qt::EditRole)
            task->setTitle(value.toString());
        else
            task->setDone(value.toInt() == Qt::Checked);

        const auto job = taskRepository()->update(task);
        installHandler(job, tr("Cannot modify task %1 in context %2").arg(currentTitle).arg(m_context->name()));
        return true;
    }
```

#### AUTO 


```{c}
auto relatedUid = m_serializer->relatedUidFromItem(item);
```

#### AUTO 


```{c}
auto today = Utils::DateTime::currentDateTime();
```

#### AUTO 


```{c}
auto res = QVector<Akonadi::Item::Id>();
```

#### AUTO 


```{c}
auto selectedIndex = QPersistentModelIndex(model.index(1));
```

#### AUTO 


```{c}
auto result2 = queries->findTopLevel(project2);
```

#### AUTO 


```{c}
auto data = [](const Domain::Note::Ptr &note, int role, int) -> QVariant {
        if (role != Qt::DisplayRole
         && role != Qt::EditRole) {
            return QVariant();
        }

        if (role == Qt::DisplayRole || role == Qt::EditRole) {
            return note->title();
        } else {
            return QVariant();
        }
    };
```

#### LAMBDA EXPRESSION 


```{c}
[repository] (const Domain::Task::Ptr &task) {
            Q_ASSERT(task);
            return repository->update(task);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=] {
            m_data->removeItem(item);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[fetchItemJob, parent, child, job, this] {
        if (fetchItemJob->kjob()->error() != KJob::NoError)
           return;

        Q_ASSERT(fetchItemJob->items().size() == 1);
        auto childItem = fetchItemJob->items().at(0);
        m_serializer->updateItemProject(childItem, parent);

        // Check collections to know if we need to move child
        auto parentItem = m_serializer->createItemFromProject(parent);
        ItemFetchJobInterface *fetchParentItemJob = m_storage->fetchItem(parentItem, this);
        job->install(fetchParentItemJob->kjob(), [fetchParentItemJob, child, childItem, job, this] {
            if (fetchParentItemJob->kjob()->error() != KJob::NoError)
                return;

            Q_ASSERT(fetchParentItemJob->items().size() == 1);
            auto parentItem = fetchParentItemJob->items().at(0);

            const int itemCollectionId = childItem.parentCollection().id();
            const int parentCollectionId = parentItem.parentCollection().id();

            if (itemCollectionId != parentCollectionId) {
                ItemFetchJobInterface *fetchChildrenItemJob = m_storage->fetchItems(childItem.parentCollection(), this);
                job->install(fetchChildrenItemJob->kjob(), [fetchChildrenItemJob, childItem, parentItem, job, this] {
                    if (fetchChildrenItemJob->kjob()->error() != KJob::NoError)
                        return;

                    Item::List childItems = m_serializer->filterDescendantItems(fetchChildrenItemJob->items(), childItem);

                    auto transaction = m_storage->createTransaction();
                    m_storage->updateItem(childItem, transaction);
                    childItems.push_front(childItem);
                    m_storage->moveItems(childItems, parentItem.parentCollection(), transaction);
                    job->addSubjob(transaction);
                    transaction->start();
                });
            } else {
                auto updateJob = m_storage->updateItem(childItem);
                job->addSubjob(updateJob);
                updateJob->start();
            }
        });
    }
```

#### AUTO 


```{c}
auto tasks = app.dataSourcesModel();
```

#### LAMBDA EXPRESSION 


```{c}
[provider, job, this] {
        for (auto collection : job->collections()) {
            ItemFetchJobInterface *job = m_storage->fetchItems(collection);
            registerJobHandler(job->kjob(), [provider, job, this] {
                for (auto item : job->items()) {
                    provider->append(deserializeTask(item));
                }
            });
        }
    }
```

#### AUTO 


```{c}
const auto parent = std::find_if(items.cbegin(), items.cend(),
                                             [this, parentUid] (const Akonadi::Item &item) {
                                                 return m_serializer->itemUid(item) == parentUid;
                                             });
```

#### AUTO 


```{c}
auto id = minId;
```

#### LAMBDA EXPRESSION 


```{c}
[job, add] {
            if (job->kjob()->error() != KJob::NoError)
                return;

            foreach (const auto &item, job->items())
                add(item);
        }
```

#### AUTO 


```{c}
auto note = m_serializer->createNoteFromItem(item);
```

#### AUTO 


```{c}
auto flags = [](const Domain::Artifact::Ptr &artifact) {
        const auto defaultFlags = Qt::ItemIsSelectable
                                | Qt::ItemIsEnabled
                                | Qt::ItemIsEditable
                                | Qt::ItemIsDragEnabled;

        const auto taskFlag = defaultFlags
                            | Qt::ItemIsUserCheckable
                            | Qt::ItemIsDropEnabled;

        return artifact.dynamicCast<Domain::Task>() ? taskFlag : defaultFlags;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[fetchItemJob, job, this] {
        if (fetchItemJob->kjob()->error() != KJob::NoError)
            return;

        Q_ASSERT(fetchItemJob->items().size() == 1);
        auto childItem = fetchItemJob->items().at(0);

        m_serializer->removeItemParent(childItem);

        auto updateJob = m_storage->updateItem(childItem, this);
        job->addSubjob(updateJob);
        updateJob->start();
    }
```

#### AUTO 


```{c}
const auto job = m_tagRepository->remove(tag);
```

#### LAMBDA EXPRESSION 


```{c}
[] (QWidget *parent) {
        return DialogPtr(new NewProjectDialog(parent));
    }
```

#### AUTO 


```{c}
auto index = model.index(i, 0);
```

#### AUTO 


```{c}
auto drop = [this](const QMimeData *mimeData, Qt::DropAction, const Domain::Artifact::Ptr &artifact) {
        auto parentTask = artifact.objectCast<Domain::Task>();

        if (!mimeData->hasFormat(QStringLiteral("application/x-zanshin-object")))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                        [](const Domain::Artifact::Ptr &droppedArtifact) {
                            return !droppedArtifact.objectCast<Domain::Task>();
                        })) {
            return false;
        }

        foreach(const auto &droppedArtifact, droppedArtifacts) {
            auto childTask = droppedArtifact.objectCast<Domain::Task>();

            if (parentTask) {
                const auto job = m_taskRepository->associate(parentTask, childTask);
                installHandler(job, i18n("Cannot move task %1 as sub-task of %2", childTask->title(), parentTask->title()));
            } else {
                childTask->setStartDate(Utils::DateTime::currentDateTime());

                auto job = m_taskRepository->update(childTask);
                installHandler(job, i18n("Cannot update task %1", childTask->title()));

                job = m_taskRepository->dissociate(childTask);
                installHandler(job, i18n("Cannot deparent task %1 from its parent", childTask->title()));
            }
        }

        return true;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Domain::LiveQuery<QObject*, QString>::AddFunction &add) {
            Utils::JobHandler::install(new FakeJob, [this, add] {
                add(createObject(0, "0A"));
                add(createObject(1, "1A"));
                add(createObject(2, "2A"));
            });
        }
```

#### AUTO 


```{c}
auto predicate = [this] (const Akonadi::Collection &collection) {
        return collection.isValid() && m_serializer->isSelectedCollection(collection);
    };
```

#### AUTO 


```{c}
auto notifiedTag = spy.takeFirst().at(0).value<Akonadi::Tag>();
```

#### AUTO 


```{c}
auto cancelAddItemAction = new QAction(this);
```

#### AUTO 


```{c}
const auto listed = Domain::DataSource::Listed;
```

#### AUTO 


```{c}
auto predicate = [this] (const Akonadi::Tag &akonadiTag) {
        return akonadiTag.type() == Akonadi::Tag::PLAIN;
    };
```

#### AUTO 


```{c}
auto drop = [] (const QMimeData *, Qt::DropAction, const Domain::Note::Ptr &) {
        return false;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[fetchParentItemJob, child, childItem, job, this] {
            if (fetchParentItemJob->kjob()->error() != KJob::NoError)
                return;

            Q_ASSERT(fetchParentItemJob->items().size() == 1);
            auto parentItem = fetchParentItemJob->items().at(0);

            const int itemCollectionId = childItem.parentCollection().id();
            const int parentCollectionId = parentItem.parentCollection().id();

            if (itemCollectionId != parentCollectionId) {
                ItemFetchJobInterface *fetchChildrenItemJob = m_storage->fetchItems(childItem.parentCollection(), this);
                job->install(fetchChildrenItemJob->kjob(), [fetchChildrenItemJob, childItem, parentItem, job, this] {
                    if (fetchChildrenItemJob->kjob()->error() != KJob::NoError)
                        return;

                    Item::List childItems = m_serializer->filterDescendantItems(fetchChildrenItemJob->items(), childItem);

                    auto transaction = m_storage->createTransaction(this);
                    m_storage->updateItem(childItem, transaction);
                    childItems.push_front(childItem);
                    m_storage->moveItems(childItems, parentItem.parentCollection(), transaction);
                    job->addSubjob(transaction);
                    transaction->start();
                });
            } else {
                auto updateJob = m_storage->updateItem(childItem, this);
                job->addSubjob(updateJob);
                updateJob->start();
            }
        }
```

#### AUTO 


```{c}
const auto relatedHeader = message->headerByType("X-Zanshin-RelatedProjectUid");
```

#### AUTO 


```{c}
auto &ids = m_tagItems[tag.id()];
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QObjectPtr &object, int role) -> QVariant {
        if (role != Qt::DisplayRole
         && role != Qt::EditRole
         && role != Qt::DecorationRole
         && role != QueryTreeModelBase::IconNameRole) {
            return QVariant();
        }

        if (role == Qt::EditRole
         && (object == m_inboxObject
          || object == m_tagsObject)) {
            return QVariant();
        }

        if (role == Qt::DisplayRole || role == Qt::EditRole) {
            return object->property("name").toString();
        } else if (role == Qt::DecorationRole || role == QueryTreeModelBase::IconNameRole) {
            const QString iconName = (object == m_inboxObject) ? "mail-folder-inbox"
                                   : (object == m_tagsObject)  ? "folder"
                                   : "view-pim-tasks";

            if (role == Qt::DecorationRole)
                return QVariant::fromValue(QIcon::fromTheme(iconName));
            else
                return iconName;
        } else {
            return QVariant();
        }
    }
```

#### AUTO 


```{c}
auto job = new AkonadiFakeCollectionFetchJob;
```

#### AUTO 


```{c}
auto drop = [this](const QMimeData *mimeData, Qt::DropAction, const Domain::Artifact::Ptr &artifact) {
        auto parentTask = artifact.objectCast<Domain::Task>();

        if (!mimeData->hasFormat("application/x-zanshin-object"))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                        [](const Domain::Artifact::Ptr &droppedArtifact) {
                            return !droppedArtifact.objectCast<Domain::Task>();
                        })) {
            return false;
        }

        foreach(const auto &droppedArtifact, droppedArtifacts) {
            auto childTask = droppedArtifact.objectCast<Domain::Task>();

            if (parentTask) {
                const auto job = m_taskRepository->associate(parentTask, childTask);
                installHandler(job, tr("Cannot move task %1 as sub-task of %2").arg(childTask->title()).arg(parentTask->title()));
            } else {
                childTask->setStartDate(Utils::DateTime::currentDateTime());

                auto job = m_taskRepository->update(childTask);
                installHandler(job, tr("Cannot update task %1").arg(childTask->title()));

                job = m_taskRepository->dissociate(childTask);
                installHandler(job, tr("Cannot deparent task %1 from its parent").arg(childTask->title()));
            }
        }

        return true;
    };
```

#### AUTO 


```{c}
const auto tag1 = Akonadi::Tag(GenTag().withId(1).asPlain().withName("tag1"));
```

#### LAMBDA EXPRESSION 


```{c}
[fetchItemJob, job, this] {
        if (fetchItemJob->kjob()->error() != KJob::NoError)
            return;

        Q_ASSERT(fetchItemJob->items().size() == 1);
        auto childItem = fetchItemJob->items().first();

        m_serializer->removeItemParent(childItem);

        auto updateJob = m_storage->updateItem(childItem);
        job->addSubjob(updateJob);
        updateJob->start();
    }
```

#### AUTO 


```{c}
const auto parentIndex = model->index(0, 0);
```

#### AUTO 


```{c}
const auto source = ui->sourceCombo->itemData(ui->sourceCombo->currentIndex(),
                                                  Presentation::QueryTreeModelBase::ObjectRole)
                                       .value<Domain::DataSource::Ptr>();
```

#### LAMBDA EXPRESSION 


```{c}
[] { qFatal("Shouldn't happen"); }
```

#### AUTO 


```{c}
auto setData = [this] (const Domain::Artifact::Ptr &artifact, const QVariant &value, int role) {
        if (role != Qt::EditRole && role != Qt::CheckStateRole) {
            return false;
        }

        if (auto task = artifact.dynamicCast<Domain::Task>()) {
            const auto currentTitle = task->title();
            if (role == Qt::EditRole)
                task->setTitle(value.toString());
            else
                task->setDone(value.toInt() == Qt::Checked);

            const auto job = taskRepository()->update(task);
            if (!errorHandler())
                return true;

            errorHandler()->installHandler(job, tr("Cannot modify task %1 in tag %2").arg(currentTitle).arg(m_tag->name()));
            return true;

        } else if (auto note = artifact.dynamicCast<Domain::Note>()) {
            if (role != Qt::EditRole)
                return false;

            const auto currentTitle = note->title();
            note->setTitle(value.toString());
            const auto job = noteRepository()->save(note);
            if (!errorHandler())
                return true;

            errorHandler()->installHandler(job, tr("Cannot modify note %1 in tag %2").arg(currentTitle).arg(m_tag->name()));
            return true;

        }

        return false;
    };
```

#### AUTO 


```{c}
auto predicate = [this] (const Akonadi::Item &item) {
        // Tasks with no parent, or whose parent is a project (not a task)
        if (!m_serializer->isTaskItem(item))
            return false;

        const auto items = m_cache->items(item.parentCollection());
        auto currentItem = item;
        auto parentUid = m_serializer->relatedUidFromItem(currentItem);
        while (!parentUid.isEmpty()) {
            const auto parent = std::find_if(items.cbegin(), items.cend(),
                                             [this, parentUid] (const Akonadi::Item &item) {
                                                 return m_serializer->itemUid(item) == parentUid;
                                             });
            if (parent == items.cend())
                break;

            if (m_serializer->isTaskItem(*parent))
                return false;

            currentItem = *parent;
            parentUid = m_serializer->relatedUidFromItem(currentItem);
        }
        return true;
    };
```

#### AUTO 


```{c}
auto delegateEdit = editor.findChild<QWidget*>(QStringLiteral("delegateEdit"));
```

#### AUTO 


```{c}
auto settingsAction = available.findChild<QAction*>("settingsAction");
```

#### RANGE FOR STATEMENT 


```{c}
for (auto item : job->items()) {
                    if (m_serializer->relatedUidFromItem(item).isEmpty()) {
                        auto task = deserializeTask(item);
                        if (task)
                            provider->append(task);
                    }
                }
```

#### AUTO 


```{c}
auto predicate = [this] (const Akonadi::Collection &collection) {
        return m_serializer->isTaskCollection(collection);
    };
```

#### AUTO 


```{c}
auto fetchItemsInSelectedCollectionsFunction(Akonadi::StorageInterface::Ptr storage, Akonadi::SerializerInterface::Ptr serializer)
    {
        return [storage, serializer] (const Domain::LiveQueryInput<Akonadi::Item>::AddFunction &add) {
            auto job = storage->fetchCollections(Akonadi::Collection::root(), Akonadi::Storage::Recursive, Akonadi::Storage::AllContent);
            Utils::JobHandler::install(job->kjob(), [add, job, storage, serializer] {
                foreach (const auto &col, job->collections()) {
                    if (!serializer->isSelectedCollection(col))
                        continue;

                    auto itemJob = storage->fetchItems(col);
                    Utils::JobHandler::install(itemJob->kjob(), [add, itemJob] {
                        foreach (const auto &item, itemJob->items())
                            add(item);
                    });
                }
            });
        };
    }
```

#### AUTO 


```{c}
auto query = Domain::LiveQuery<QString, QObjectPtr>();
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QObjectPtr &object, int role) -> QVariant {
        if (role != Qt::DisplayRole
         && role != Qt::EditRole
         && role != Qt::DecorationRole
         && role != QueryTreeModelBase::IconNameRole) {
            return QVariant();
        }

        if (role == Qt::EditRole
         && (object == m_inboxObject
          || object == m_workdayObject
          || object == m_projectsObject
          || object == m_contextsObject)) {
            return QVariant();
        }

        if (role == Qt::DisplayRole || role == Qt::EditRole) {
            return object->property("name").toString();
        } else if (role == Qt::DecorationRole || role == QueryTreeModelBase::IconNameRole) {
            const QString iconName = object == m_inboxObject ? "mail-folder-inbox"
                                   : (object == m_workdayObject)  ? "go-jump-today"
                                   : (object == m_projectsObject) ? "folder"
                                   : (object == m_contextsObject) ? "folder"
                                   : "view-pim-tasks";

            if (role == Qt::DecorationRole)
                return QVariant::fromValue(QIcon::fromTheme(iconName));
            else
                return iconName;
        } else {
            return QVariant();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &type : types) {
        if (isContentTypesPopulated(type) && matchCollection(type, collection)) {
            m_collections << collection;
            return;
        }
    }
```

#### AUTO 


```{c}
auto monitor = new AkonadiFakeMonitor;
```

#### AUTO 


```{c}
const auto currentName = context->name();
```

#### AUTO 


```{c}
auto i2 = Akonadi::Item(43);
```

#### LAMBDA EXPRESSION 


```{c}
[&](const Domain::Task::Ptr &task) {
            if (!task)
                return Domain::QueryResult<Domain::Task::Ptr>::create(provider);
            else
                return queryMock.getInstance()->findChildren(task);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, contentTypes, root] (const Domain::LiveQueryInput<Collection>::AddFunction &add) {
        auto job = m_storage->fetchCollections(root, StorageInterface::Recursive, contentTypes);
        Utils::JobHandler::install(job->kjob(), [root, job, add] {
            if (job->kjob()->error())
                return;

            auto directChildren = QHash<Collection::Id, Collection>();
            foreach (const auto &collection, job->collections()) {
                auto directChild = collection;
                while (directChild.parentCollection() != root)
                    directChild = directChild.parentCollection();
                if (!directChildren.contains(directChild.id()))
                    directChildren[directChild.id()] = directChild;
            }

            foreach (const auto &directChild, directChildren.values())
                add(directChild);
        });
    }
```

#### AUTO 


```{c}
auto contextUid = context->property("todoUid").toString();
```

#### AUTO 


```{c}
auto addTagAction = available.findChild<QAction*>(QStringLiteral("addTagAction"));
```

#### AUTO 


```{c}
auto job = storage.updateCollection(collection);
```

#### AUTO 


```{c}
auto dragFunction = [] (const QStringList &strings) -> QMimeData* {
            auto data = new QMimeData;
            data->setData("application/x-zanshin-object", "object");
            data->setProperty("objects", QVariant::fromValue(strings));
            return data;
        };
```

#### LAMBDA EXPRESSION 


```{c}
[&removedId] (const Akonadi::Tag &tag) {
            removedId = tag.id();
        }
```

#### AUTO 


```{c}
auto flags = [](const Domain::Artifact::Ptr &artifact) {
        const Qt::ItemFlags defaultFlags = Qt::ItemIsSelectable
                                         | Qt::ItemIsEnabled
                                         | Qt::ItemIsEditable
                                         | Qt::ItemIsDragEnabled;

        return artifact.dynamicCast<Domain::Task>() ? (defaultFlags | Qt::ItemIsUserCheckable | Qt::ItemIsDropEnabled) : defaultFlags;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[fetchItemJob, child, parent, job, this] {
        if (fetchItemJob->kjob()->error() != KJob::NoError)
           return;

        Q_ASSERT(fetchItemJob->items().size() == 1);
        auto childItem = fetchItemJob->items().at(0);
        m_serializer->updateItemParent(childItem, parent);

        // Check collections to know if we need to move child
        auto partialParentItem = m_serializer->createItemFromTask(parent);
        ItemFetchJobInterface *fetchParentItemJob = m_storage->fetchItems(partialParentItem.parentCollection());
        job->install(fetchParentItemJob->kjob(), [child, parent, fetchParentItemJob, partialParentItem, childItem, job, this] {
            if (fetchParentItemJob->kjob()->error() != KJob::NoError)
                return;

            const auto items = fetchParentItemJob->items();
            const auto parentIndex = items.indexOf(partialParentItem);
            Q_ASSERT(parentIndex >= 0);
            const auto parentItem = items.at(parentIndex);

            // TODO Qt5: This is a bit wasteful, add an itemUid on the serializer
            const auto childUid = m_serializer->objectUid(m_serializer->createTaskFromItem(childItem));
            auto relatedUid = m_serializer->relatedUidFromItem(parentItem);
            while (!relatedUid.isEmpty()) {
                if (relatedUid == childUid) {
                    job->emitError(tr("Could not associate '%1', it is an ancestor of '%2'")
                                   .arg(child->title(), parent->title()));
                    return;
                }

                auto it = std::find_if(items.constBegin(), items.constEnd(),
                                       [relatedUid, this] (const Akonadi::Item &item) {
                    // TODO Qt5: This is a bit wasteful, add an itemUid on the serializer
                    auto task = m_serializer->createTaskFromItem(item);
                    return task && m_serializer->objectUid(task) == relatedUid;
                });
                if (it == items.end())
                    break;

                relatedUid = m_serializer->relatedUidFromItem(*it);
            }

            const int itemCollectionId = childItem.parentCollection().id();
            const int parentCollectionId = parentItem.parentCollection().id();

            if (itemCollectionId != parentCollectionId) {
                ItemFetchJobInterface *fetchChildrenItemJob = m_storage->fetchItems(childItem.parentCollection());
                job->install(fetchChildrenItemJob->kjob(), [fetchChildrenItemJob, childItem, parentItem, job, this] {
                    if (fetchChildrenItemJob->kjob()->error() != KJob::NoError)
                        return;

                    Item::List childItems = m_serializer->filterDescendantItems(fetchChildrenItemJob->items(), childItem);

                    auto transaction = m_storage->createTransaction();
                    m_storage->updateItem(childItem, transaction);
                    childItems.push_front(childItem);
                    m_storage->moveItems(childItems, parentItem.parentCollection(), transaction);
                    job->addSubjob(transaction);
                    transaction->start();
                });
            } else {
                auto updateJob = m_storage->updateItem(childItem);
                job->addSubjob(updateJob);
                updateJob->start();
            }
        });
    }
```

#### AUTO 


```{c}
auto otherResult = QueryResult<QString>::copy(result);
```

#### AUTO 


```{c}
const auto projectInfo = index.data(Presentation::QueryTreeModelBase::ProjectRole);
```

#### AUTO 


```{c}
auto data = [](const Domain::Note::Ptr &note, int role) -> QVariant {
        if (role != Qt::DisplayRole
         && role != Qt::EditRole) {
            return QVariant();
        }

        if (role == Qt::DisplayRole || role == Qt::EditRole) {
            return note->title();
        } else {
            return QVariant();
        }
    };
```

#### AUTO 


```{c}
auto dataFunction = [](const Domain::Task::Ptr &task, int role) -> QVariant {
            if (role != Qt::DisplayRole && role != Qt::CheckStateRole) {
                return QVariant();
            }

            if (role == Qt::DisplayRole)
                return task->title();
            else
                return task->isDone() ? Qt::Checked : Qt::Unchecked;
        };
```

#### LAMBDA EXPRESSION 


```{c}
[add, job] {
                foreach (const auto &item, job->items()) {
                    add(item);
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[=] () mutable {
            item.setParentCollection(collection);
            // Force payload detach
            item.setPayloadFromData(item.payloadData());
            m_data->modifyItem(item);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const QMimeData *mimeData, Qt::DropAction, const Domain::Artifact::Ptr &artifact) {
        auto parentTask = artifact.objectCast<Domain::Task>();
        if (!parentTask)
            return false;

        if (!mimeData->hasFormat("application/x-zanshin-object"))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                        [](const Domain::Artifact::Ptr &droppedArtifact) {
                            return !droppedArtifact.objectCast<Domain::Task>();
                        })) {
            return false;
        }

        foreach(const Domain::Artifact::Ptr &droppedArtifact, droppedArtifacts) {
            auto childTask = droppedArtifact.objectCast<Domain::Task>();
            const auto job = taskRepository()->associate(parentTask, childTask);
            if (!errorHandler())
                continue;

            errorHandler()->installHandler(job, tr("Cannot move task %1 as sub-task of %2").arg(childTask->title()).arg(parentTask->title()));
        }

        return true;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const Domain::Note::Ptr &note, int role) -> QVariant {
        if (role != Qt::DisplayRole
         && role != Qt::EditRole) {
            return QVariant();
        }

        if (role == Qt::DisplayRole || role == Qt::EditRole) {
            return note->title();
        } else {
            return QVariant();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, model, queryGenerator](const ItemType &item, int index) {
            QueryTreeNodeBase *node = new QueryTreeNode<ItemType>(item, this,
                                                                  model, queryGenerator,
                                                                  m_flagsFunction,
                                                                  m_dataFunction, m_setDataFunction,
                                                                  m_dropFunction);
            insertChild(index, node);
            endInsertRows();
        }
```

#### AUTO 


```{c}
auto combo = new DataSourceComboBox(m_parent);
```

#### AUTO 


```{c}
auto drag = [](const Domain::Task::List &tasks) -> QMimeData* {
        if (tasks.isEmpty())
            return Q_NULLPTR;

        auto draggedArtifacts = Domain::Artifact::List();
        draggedArtifacts.reserve(tasks.size());
        foreach (const Domain::Task::Ptr &task, tasks) {
            draggedArtifacts.append(task.objectCast<Domain::Artifact>());
        }

        auto data = new QMimeData;
        data->setData(QStringLiteral("application/x-zanshin-object"), "object");
        data->setProperty("objects", QVariant::fromValue(draggedArtifacts));
        return data;
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto itemId : m_collectionItems.value(collection.id())) {
        m_items.remove(itemId);

        for (auto &itemList : m_tagItems)
            itemList.removeAll(itemId);
    }
```

#### AUTO 


```{c}
const auto tag3 = Akonadi::Tag(GenTag().withId(3).withName("tag3"));
```

#### AUTO 


```{c}
auto data = [this](const QObjectPtr &object, int role) -> QVariant {
        if (role != Qt::DisplayRole
         && role != Qt::EditRole
         && role != Qt::DecorationRole
         && role != QueryTreeModelBase::IconNameRole) {
            return QVariant();
        }

        if (role == Qt::EditRole
         && (object == m_inboxObject
          || object == m_workdayObject
          || object == m_projectsObject
          || object == m_contextsObject
          || object.objectCast<Domain::DataSource>())) {
            return QVariant();
        }

        if (role == Qt::DisplayRole || role == Qt::EditRole) {
            return object->property("name").toString();
        } else if (role == Qt::DecorationRole || role == QueryTreeModelBase::IconNameRole) {
            const QString iconName = object == m_inboxObject ? QStringLiteral("mail-folder-inbox")
                                   : (object == m_workdayObject)  ? QStringLiteral("go-jump-today")
                                   : (object == m_projectsObject) ? QStringLiteral("folder")
                                   : (object == m_contextsObject) ? QStringLiteral("folder")
                                   : object.objectCast<Domain::DataSource>() ? QStringLiteral("folder")
                                   : object.objectCast<Domain::Context>() ? QStringLiteral("view-pim-notes")
                                   : QStringLiteral("view-pim-tasks");

            if (role == Qt::DecorationRole)
                return QVariant::fromValue(QIcon::fromTheme(iconName));
            else
                return iconName;
        } else {
            return QVariant();
        }
    };
```

#### AUTO 


```{c}
const auto dataSource = dataSourceForIndex(index);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Domain::DataSource::Ptr &, int index) {
                                        beginRemoveRows(QModelIndex(), index, index);
                                    }
```

#### AUTO 


```{c}
const auto parentTask = parentData.value<Domain::Task::Ptr>();
```

#### AUTO 


```{c}
auto project = object.objectCast<Domain::Project>();
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &, int, int) {
            return QVariant();
        }
```

#### AUTO 


```{c}
auto editorModel = new EditorModelStub(model.data());
```

#### AUTO 


```{c}
auto job = new Utils::CompositeJob();
```

#### LAMBDA EXPRESSION 


```{c}
[] (const QString &) {
            return Qt::NoItemFlags;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&input, this](const InputType &existing) {
                                           return m_compare(input, existing);
                                       }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const ProjectQuery::AddFunction &add) {
            CollectionFetchJobInterface *job = m_storage->fetchCollections(Akonadi::Collection::root(),
                                                                           StorageInterface::Recursive,
                                                                           StorageInterface::Tasks);
            Utils::JobHandler::install(job->kjob(), [this, job, add] {
                if (job->kjob()->error() != KJob::NoError)
                    return;

                for (auto collection : job->collections()) {
                    ItemFetchJobInterface *job = m_storage->fetchItems(collection);
                    Utils::JobHandler::install(job->kjob(), [this, job, add] {
                        if (job->kjob()->error() != KJob::NoError)
                            return;

                        for (auto item : job->items()) {
                            add(item);
                        }
                    });
                }
            });
        }
```

#### AUTO 


```{c}
auto job = m_storage->fetchTags();
```

#### AUTO 


```{c}
auto itemModifyJob = new MockAkonadiJob(this);
```

#### LAMBDA EXPRESSION 


```{c}
[fetchCollectionJob, item, job, this] {
            if (fetchCollectionJob->kjob()->error() != KJob::NoError)
                return;

            Q_ASSERT(fetchCollectionJob->collections().size() > 0);
            const Akonadi::Collection::List collections = fetchCollectionJob->collections();
            auto it = std::find_if(collections.constBegin(), collections.constEnd(),
                                   [] (const Akonadi::Collection &c) {
                return (c.rights() & Akonadi::Collection::CanCreateItem)
                    && (c.rights() & Akonadi::Collection::CanChangeItem)
                    && (c.rights() & Akonadi::Collection::CanDeleteItem);
            });
            if (it == collections.constEnd()) {
                job->emitError(tr("Could not find a collection to store the task into!"));
            } else {
                auto col = *it;
                Q_ASSERT(col.isValid());
                auto createJob = m_storage->createItem(item, col);
                job->addSubjob(createJob);
                createJob->start();
            }
        }
```

#### AUTO 


```{c}
const auto additionalInfoRect = QRect(textRect.x(), summaryRect.bottom(), textRect.width(), textRect.height() - summaryRect.height());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &suffix : suffixes) {
                            if (entry.endsWith(suffix))
                                return true;
                        }
```

#### AUTO 


```{c}
auto job = storage->searchCollections(name, Akonadi::StorageInterface::FetchContentType(contentType));
```

#### AUTO 


```{c}
auto job = storage.fetchItems(calendar2());
```

#### AUTO 


```{c}
auto dataFunction = [](const Domain::Task::Ptr &, int, int) {
            return QVariant();
        };
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QObjectPtr &object) {
        const Qt::ItemFlags defaultFlags = Qt::ItemIsSelectable
                                         | Qt::ItemIsEnabled
                                         | Qt::ItemIsEditable
                                         | Qt::ItemIsDropEnabled;
        const Qt::ItemFlags immutableNodeFlags = Qt::ItemIsSelectable
                                               | Qt::ItemIsEnabled
                                               | Qt::ItemIsDropEnabled;
        const Qt::ItemFlags structureNodeFlags = Qt::NoItemFlags;

        return object.objectCast<Domain::Project>() ? defaultFlags
             : object.objectCast<Domain::Context>() ? defaultFlags
             : object.objectCast<Domain::Tag>() ? defaultFlags
             : object == m_inboxObject ? immutableNodeFlags
             : structureNodeFlags;
    }
```

#### AUTO 


```{c}
auto result2 = queries->findTopLevelTasks(context2);
```

#### AUTO 


```{c}
auto context = m_serializer->createContextFromItem(contextItem);
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Akonadi::Tag &tag) {
            return tag.type() == Akonadi::SerializerInterface::contextTagType();
        }
```

#### AUTO 


```{c}
auto grandChildTask = model->data(model->index(0, 0, childTaskIndex), Presentation::QueryTreeModelBase::ObjectRole).value<Domain::Task::Ptr>();
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const ArtifactQuery::AddFunction &add) {
            CollectionFetchJobInterface *job = m_storage->fetchCollections(Akonadi::Collection::root(),
                                                                           StorageInterface::Recursive,
                                                                           StorageInterface::Tasks|StorageInterface::Notes);
            Utils::JobHandler::install(job->kjob(), [this, job, add] {
                if (job->kjob()->error() != KJob::NoError)
                    return;

                for (auto collection : job->collections()) {
                    if (!m_serializer->isSelectedCollection(collection))
                        continue;

                    ItemFetchJobInterface *job = m_storage->fetchItems(collection);
                    Utils::JobHandler::install(job->kjob(), [this, job, add] {
                        if (job->kjob()->error() != KJob::NoError)
                            return;

                        for (auto item : job->items()) {
                            add(item);
                        }
                    });
                }
            });
        }
```

#### LAMBDA EXPRESSION 


```{c}
[] (const Akonadi::Item &item) {
            return titleFromItem(item).endsWith("-ex");
        }
```

#### AUTO 


```{c}
auto inQuery = Domain::LiveQueryOutput<Domain::Task::Ptr>::Ptr();
```

#### AUTO 


```{c}
auto transaction = m_storage->createTransaction();
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Domain::Artifact::Ptr &artifact, const QVariant &value, int role) {
        if (role != Qt::EditRole && role != Qt::CheckStateRole) {
            return false;
        }

        if (auto task = artifact.dynamicCast<Domain::Task>()) {
            const auto currentTitle = task->title();
            if (role == Qt::EditRole)
                task->setTitle(value.toString());
            else
                task->setDone(value.toInt() == Qt::Checked);

            const auto job = taskRepository()->update(task);
            installHandler(job, tr("Cannot modify task %1 in Inbox").arg(currentTitle));
            return true;

        } else if (auto note = artifact.dynamicCast<Domain::Note>()) {
            if (role != Qt::EditRole)
                return false;

            const auto currentTitle = note->title();
            note->setTitle(value.toString());
            const auto job = noteRepository()->save(note);
            installHandler(job, tr("Cannot modify note %1 in Inbox").arg(currentTitle));
            return true;

        }

        return false;
    }
```

#### AUTO 


```{c}
auto data = [this](const QObjectPtr &object, int role) -> QVariant {
        if (role != Qt::DisplayRole
         && role != Qt::EditRole
         && role != Qt::DecorationRole
         && role != QueryTreeModelBase::IconNameRole) {
            return QVariant();
        }

        if (role == Qt::EditRole
         && (object == m_inboxObject || object == m_projectsObject)) {
            return QVariant();
        }

        if (role == Qt::DisplayRole || role == Qt::EditRole) {
            return object->property("name").toString();
        } else if (role == Qt::DecorationRole || role == QueryTreeModelBase::IconNameRole) {
            const QString iconName = object == m_inboxObject ? "mail-folder-inbox"
                                   : object == m_projectsObject ? "folder"
                                   : "view-pim-tasks";

            if (role == Qt::DecorationRole)
                return QVariant::fromValue(QIcon::fromTheme(iconName));
            else
                return iconName;
        } else {
            return QVariant();
        }
    };
```

#### AUTO 


```{c}
auto taskProvider = Domain::QueryResultProvider<Domain::Task::Ptr>::Ptr::create();
```

#### AUTO 


```{c}
auto project2Provider = Domain::QueryResultProvider<Domain::Project::Ptr>::Ptr::create();
```

#### AUTO 


```{c}
auto job = storage.moveItems(list, calendar1());
```

#### LAMBDA EXPRESSION 


```{c}
[job, toTagNames]{
                return toTagNames(job->tags());
            }
```

#### AUTO 


```{c}
auto availablePages = m_appModel->property("availablePages").value<QObject*>();
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &) {
            return Qt::NoItemFlags;
        }
```

#### AUTO 


```{c}
auto task = createTaskFromItem(item);
```

#### AUTO 


```{c}
auto source = app.defaultDataSource();
```

#### AUTO 


```{c}
auto drop = [this](const QMimeData *mimeData, Qt::DropAction, const QObjectPtr &object) {
        if (!mimeData->hasFormat("application/x-zanshin-object"))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        auto project = object.objectCast<Domain::Project>();
        if (project) {
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                m_projectRepository->associate(project, droppedArtifact);
            }
            return true;
        } else if (auto context = object.objectCast<Domain::Context>()) {
            if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                            [](const Domain::Artifact::Ptr &droppedArtifact) {
                                return !droppedArtifact.objectCast<Domain::Task>();
                            })) {
                return false;
            }

            foreach (const auto &droppedArtifact, droppedArtifacts) {
                auto task = droppedArtifact.staticCast<Domain::Task>();
                m_contextRepository->associate(context, task);
            }
            return true;
        } else if (object == m_inboxObject) {
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                auto job = m_projectRepository->dissociate(droppedArtifact);
                if (auto task = droppedArtifact.objectCast<Domain::Task>()) {
                    Utils::JobHandler::install(job, [this, task] {
                        m_taskRepository->dissociate(task);
                    });
                }
            }
            return true;
        }

        return false;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[context, fetchFunction, serializer] (const Domain::LiveQueryInput<Item>::AddFunction &add) {
        auto filterAdd = [context, add, serializer] (const Item &item) {
            if (serializer->isContextChild(context, item))
                add(item);
        };
        fetchFunction(filterAdd);
    }
```

#### AUTO 


```{c}
auto drop = [this](const QMimeData *mimeData, Qt::DropAction, const Domain::Task::Ptr &parentTask) {
        if (!mimeData->hasFormat(QStringLiteral("application/x-zanshin-object")))
            return false;

        auto droppedTasks = mimeData->property("objects").value<Domain::Task::List>();
        if (droppedTasks.isEmpty())
            return false;

        foreach(const auto &childTask, droppedTasks) {
            if (parentTask) {
                const auto job = m_taskRepository->associate(parentTask, childTask);
                installHandler(job, i18n("Cannot move task %1 as sub-task of %2", childTask->title(), parentTask->title()));
            } else {
                childTask->setStartDate(Utils::DateTime::currentDate());

                auto job = m_taskRepository->dissociate(childTask);
                installHandler(job, i18n("Cannot deparent task %1 from its parent", childTask->title()));
            }
        }

        return true;
    };
```

#### AUTO 


```{c}
auto newResult = m_migrator.fetchAllItems(WhichItems::AllTasks);
```

#### AUTO 


```{c}
auto predicate = [this, task] (const Akonadi::Item &item) {
        return m_serializer->isTaskChild(task, item);
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &itemList : m_tagItems)
            itemList.removeAll(itemId);
```

#### LAMBDA EXPRESSION 


```{c}
[] (const QModelIndex &index) {
                           return index.data().toString();
                       }
```

#### AUTO 


```{c}
auto dataFunction = [] (const QString &, int) {
            return QVariant();
        };
```

#### AUTO 


```{c}
auto removeAction = available.findChild<QAction*>(QStringLiteral("removeAction"));
```

#### AUTO 


```{c}
const auto pastDueDate = dueDate.isValid() && dueDate < currentDate;
```

#### AUTO 


```{c}
auto attr = m_collection.attribute<Akonadi::EntityDisplayAttribute>(Akonadi::Collection::AddIfMissing);
```

#### AUTO 


```{c}
auto artifact = T::Ptr::create();
```

#### LAMBDA EXPRESSION 


```{c}
[job, toCollectionNames]{
                return toCollectionNames(job->collections());
            }
```

#### AUTO 


```{c}
auto attachments = m_model->property("attachmentModel").value<QAbstractItemModel*>();
```

#### LAMBDA EXPRESSION 


```{c}
[job, add, serializer, childId] {
            if (job->kjob()->error() != KJob::NoError)
                return;

            const auto items = job->items();
            // The item itself is part of the result, we need that in findProject, to react on changes of the item itself
            // To return a correct child item in case it got updated, we can't use childItem, we need to find it in the list.
            const auto myself = std::find_if(items.cbegin(), items.cend(),
                                             [childId] (const Akonadi::Item &item) {
                                                 return childId == item.id();
                                             });
            if (myself == items.cend()) {
                qWarning() << "Did not find item in the listing for its parent collection. Item ID:" << childId;
                return;
            }
            add(*myself);
            auto parentUid = serializer->relatedUidFromItem(*myself);
            while (!parentUid.isEmpty()) {
                const auto parent = std::find_if(items.cbegin(), items.cend(),
                                                 [serializer, parentUid] (const Akonadi::Item &item) {
                                                     return serializer->itemUid(item) == parentUid;
                                                 });
                if (parent == items.cend()) {
                    break;
                }
                add(*parent);
                parentUid = serializer->relatedUidFromItem(*parent);
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&mimeDb] (const KCalCore::Attachment &attach) {
                       Domain::Task::Attachment attachment;
                       if (attach.isUri())
                           attachment.setUri(QUrl(attach.uri()));
                       else
                           attachment.setData(attach.decodedData());
                       attachment.setLabel(attach.label());
                       attachment.setMimeType(attach.mimeType());
                       attachment.setIconName(mimeDb.mimeTypeForName(attach.mimeType()).iconName());
                       return attachment;
                   }
```

#### AUTO 


```{c}
auto drop = [this] (const QMimeData *mimeData, Qt::DropAction, const Domain::Task::Ptr &parentTask) {
        if (!mimeData->hasFormat("application/x-zanshin-object"))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                        [](const Domain::Artifact::Ptr &droppedArtifact) {
                            return !droppedArtifact.objectCast<Domain::Task>();
                        })) {
            return false;
        }

        foreach(const Domain::Artifact::Ptr &droppedArtifact, droppedArtifacts) {
            auto childTask = droppedArtifact.objectCast<Domain::Task>();
            const auto job = taskRepository()->associate(parentTask, childTask);
            installHandler(job, tr("Cannot move task %1 as sub-task of %2").arg(childTask->title()).arg(parentTask->title()));
        }

        return true;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Domain::Task::Ptr &task, int) {
            if (task->isRunning()) {
                setRunningTask(task);
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Domain::Artifact::Ptr &artifact, const QVariant &value, int role) {
        if (role != Qt::EditRole && role != Qt::CheckStateRole) {
            return false;
        }

        if (auto task = artifact.dynamicCast<Domain::Task>()) {
            const auto currentTitle = task->title();
            if (role == Qt::EditRole)
                task->setTitle(value.toString());
            else
                task->setDone(value.toInt() == Qt::Checked);

            const auto job = taskRepository()->update(task);
            if (!errorHandler())
                return true;

            errorHandler()->installHandler(job, tr("Cannot modify task %1 in tag %2").arg(currentTitle).arg(m_tag->name()));
            return true;

        } else if (auto note = artifact.dynamicCast<Domain::Note>()) {
            if (role != Qt::EditRole)
                return false;

            const auto currentTitle = note->title();
            note->setTitle(value.toString());
            const auto job = noteRepository()->save(note);
            if (!errorHandler())
                return true;

            errorHandler()->installHandler(job, tr("Cannot modify note %1 in tag %2").arg(currentTitle).arg(m_tag->name()));
            return true;

        }

        return false;
    }
```

#### AUTO 


```{c}
auto inPredicate = [] (const Akonadi::Collection &collection) {
            return collection.name().endsWith(QLatin1String("-in"));
        };
```

#### AUTO 


```{c}
auto drag = [] (const Domain::Note::List &notes) -> QMimeData* {
        if (notes.isEmpty())
            return Q_NULLPTR;

        auto draggedArtifacts = Domain::Artifact::List();
        draggedArtifacts.reserve(notes.count());
        std::copy(notes.constBegin(), notes.constEnd(),
                  std::back_inserter(draggedArtifacts));

        auto data = new QMimeData;
        data->setData(QStringLiteral("application/x-zanshin-object"), "object");
        data->setProperty("objects", QVariant::fromValue(draggedArtifacts));
        return data;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[&allValid] (const QPersistentModelIndex &index) {
                        allValid &= index.isValid();
                        return index;
                   }
```

#### AUTO 


```{c}
auto query = [this](const Domain::Artifact::Ptr &artifact) -> Domain::QueryResultInterface<Domain::Artifact::Ptr>::Ptr {
        if (!artifact)
            return Domain::QueryResult<Domain::Task::Ptr, Domain::Artifact::Ptr>::copy(taskQueries()->findWorkdayTopLevel());
        else if (auto task = artifact.dynamicCast<Domain::Task>())
            return Domain::QueryResult<Domain::Task::Ptr, Domain::Artifact::Ptr>::copy(taskQueries()->findChildren(task));
        else
            return Domain::QueryResult<Domain::Artifact::Ptr>::Ptr();
    };
```

#### AUTO 


```{c}
const auto topLevelIndex = model->index(0, 0);
```

#### AUTO 


```{c}
const auto index = m_tags.indexOf(Tag(id));
```

#### LAMBDA EXPRESSION 


```{c}
[&replaceHandlerCalled](const QPair<int, QString> &, int) {
                                          replaceHandlerCalled = true;
                                      }
```

#### AUTO 


```{c}
auto list = m_agentInstanceWidget->selectedAgentInstances();
```

#### LAMBDA EXPRESSION 


```{c}
[storage, serializer, parent] (const Domain::LiveQueryInput<Akonadi::Item>::AddFunction &add) {
            auto job = storage->fetchCollections(Akonadi::Collection::root(), Akonadi::Storage::Recursive, parent);
            Utils::JobHandler::install(job->kjob(), [add, job, storage, serializer] {
                foreach (const auto &col, job->collections()) {
                    if (!serializer->isSelectedCollection(col))
                        continue;

                    auto itemJob = storage->fetchItems(col, nullptr);
                    Utils::JobHandler::install(itemJob->kjob(), [add, itemJob] {
                        foreach (const auto &item, itemJob->items())
                            add(item);
                    });
                }
            });
        }
```

#### AUTO 


```{c}
auto dropFunction = [] (const QMimeData *, Qt::DropAction, const QColor &) {
            return false;
        };
```

#### AUTO 


```{c}
auto context1 = serializer->createContextFromItem(data.item(1));
```

#### AUTO 


```{c}
auto taskList = queries.findTopLevel();
```

#### AUTO 


```{c}
auto predicate = [this] (const Akonadi::Item &item) {
        // Tasks without a parent (neither task nor project)
        return m_serializer->isTaskItem(item) && m_serializer->relatedUidFromItem(item).isEmpty();
    };
```

#### AUTO 


```{c}
auto childResult = Domain::QueryResult<Domain::Task::Ptr>::create(childProvider);
```

#### AUTO 


```{c}
auto drop = [this](const QMimeData *mimeData, Qt::DropAction, const Domain::Artifact::Ptr &artifact) {
        auto parentTask = artifact.objectCast<Domain::Task>();

        if (!mimeData->hasFormat(QStringLiteral("application/x-zanshin-object")))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                        [](const Domain::Artifact::Ptr &droppedArtifact) {
                            return !droppedArtifact.objectCast<Domain::Task>();
                        })) {
            return false;
        }

        foreach(const auto &droppedArtifact, droppedArtifacts) {
            auto childTask = droppedArtifact.objectCast<Domain::Task>();

            if (parentTask) {
                const auto job = m_taskRepository->associate(parentTask, childTask);
                installHandler(job, i18n("Cannot move task %1 as sub-task of %2", childTask->title(), parentTask->title()));
            } else {
                childTask->setStartDate(Utils::DateTime::currentDate());

                auto job = m_taskRepository->dissociate(childTask);
                installHandler(job, i18n("Cannot deparent task %1 from its parent", childTask->title()));
            }
        }

        return true;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[] (const Domain::DataSource::Ptr &source) {
        Q_UNUSED(source)
        return Qt::ItemIsSelectable | Qt::ItemIsEnabled;
    }
```

#### AUTO 


```{c}
auto contextQueries = Domain::ContextQueries::Ptr();
```

#### LAMBDA EXPRESSION 


```{c}
[] (const Domain::Task::List &tasks) -> QMimeData* {
        if (tasks.isEmpty())
            return 0;

        QMimeData *data = new QMimeData();
        data->setData("application/x-zanshin-object", "objects");
        data->setProperty("objects", QVariant::fromValue(tasks));
        return data;
    }
```

#### AUTO 


```{c}
auto childTask = Domain::Task::Ptr::create();
```

#### LAMBDA EXPRESSION 


```{c}
[] (QObject *object, QPair<int, QString> &output) {
            output.second = object->objectName();
        }
```

#### AUTO 


```{c}
auto job = storage->fetchItems(item.parentCollection());
```

#### AUTO 


```{c}
auto mem_fn(PTMorPTMF const& ptm) -> decltype(std::mem_fn(ptm)) {
        return std::mem_fn(ptm);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&](const Domain::Task::Ptr &artifact) {
            if (!artifact)
                return Domain::QueryResult<Domain::Task::Ptr>::create(provider);
            else
                return Domain::QueryResult<Domain::Task::Ptr>::Ptr();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[allowedMimeTypes] (const Collection &collection) {
                                                auto mimeTypes = collection.contentMimeTypes().toSet();
                                                return mimeTypes.intersect(allowedMimeTypes).isEmpty();
                                             }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QObjectPtr &object, int role) -> QVariant {
        if (role != Qt::DisplayRole
         && role != Qt::EditRole
         && role != Qt::DecorationRole
         && role != QueryTreeModelBase::IconNameRole) {
            return QVariant();
        }

        if (role == Qt::EditRole
         && (object == m_inboxObject
          || object == m_projectsObject
          || object == m_contextsObject
          || object == m_tagsObject)) {
            return QVariant();
        }

        if (role == Qt::DisplayRole || role == Qt::EditRole) {
            return object->property("name").toString();
        } else if (role == Qt::DecorationRole || role == QueryTreeModelBase::IconNameRole) {
            const QString iconName = object == m_inboxObject ? "mail-folder-inbox"
                                   : (object == m_projectsObject) ? "folder"
                                   : (object == m_contextsObject) ? "folder"
                                   : (object == m_tagsObject)     ? "folder"
                                   : "view-pim-tasks";

            if (role == Qt::DecorationRole)
                return QVariant::fromValue(QIcon::fromTheme(iconName));
            else
                return iconName;
        } else {
            return QVariant();
        }
    }
```

#### AUTO 


```{c}
auto data = std::make_unique<QMimeData>();
```

#### AUTO 


```{c}
const auto item1 = Akonadi::Item(GenTodo().withId(1).withParent(1).withTags({1}).withTitle("item1"));
```

#### LAMBDA EXPRESSION 


```{c}
[provider, job, this] {
                if (job->kjob()->error() != KJob::NoError)
                    return;

                for (auto item : job->items()) {
                    if (!isInboxItem(item))
                        continue;

                    auto artifact = deserializeArtifact(item);
                    if (artifact)
                        provider->append(artifact);
                }
            }
```

#### AUTO 


```{c}
auto sourceQueries = Domain::DataSourceQueries::Ptr();
```

#### AUTO 


```{c}
const auto screenGeometry = qApp->desktop()->availableGeometry(this);
```

#### LAMBDA EXPRESSION 


```{c}
[storage, collection] (const Domain::LiveQueryInput<Item>::AddFunction &add) {
        auto job = storage->fetchItems(collection);
        Utils::JobHandler::install(job->kjob(), [job, add] {
            if (job->kjob()->error() != KJob::NoError)
                return;

            foreach (const auto &item, job->items())
                add(item);
        });
    }
```

#### AUTO 


```{c}
const auto text = ui->nameEdit->text();
```

#### AUTO 


```{c}
auto fetch = m_helpers->fetchSiblings(item, const_cast<TaskQueries*>(this));
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QModelIndex &index, const Domain::Task::Ptr &task) -> AdditionalInfo {
        if (index.parent().isValid()) // children are in the same collection as their parent, so the same project
            return nullptr;

        AdditionalInfo projectQueryResult = m_taskQueries->findProject(task);
        if (projectQueryResult) {
            QPersistentModelIndex persistentIndex(index);
            projectQueryResult->addPostInsertHandler([persistentIndex](const Domain::Project::Ptr &, int) {
                // When a project was found (inserted into the result), update the rendering of the item
                auto model = const_cast<QAbstractItemModel *>(persistentIndex.model());
                model->dataChanged(persistentIndex, persistentIndex);
            });
        }
        return projectQueryResult;
    }
```

#### AUTO 


```{c}
const auto collectionFetchNames = toCollectionNames(job->collections());
```

#### AUTO 


```{c}
auto query = Domain::LiveQueryOutput<Domain::Tag::Ptr>::Ptr();
```

#### LAMBDA EXPRESSION 


```{c}
[] (const Domain::LiveQueryInput<QString>::AddFunction &add) {
            Utils::JobHandler::install(new FakeJob, [add] {
                add(QStringLiteral("0"));
                add(QStringLiteral("1"));
                add(QString());
                add(QStringLiteral("a"));
                add(QStringLiteral("2"));
            });
        }
```

#### AUTO 


```{c}
const auto taskDelegate = task ? task->delegate() : Domain::Task::Delegate();
```

#### AUTO 


```{c}
const auto summaryRect = style->subElementRect(QStyle::SE_ItemViewItemText, &opt, widget)
                             .adjusted(textMargin, 0, -dueDateWidth - textMargin, 0);
```

#### AUTO 


```{c}
auto button = widget.findChild<QAbstractButton *>("stopButton");
```

#### LAMBDA EXPRESSION 


```{c}
[serializer, storage, job, add] {
            if (job->kjob()->error() != KJob::NoError)
                return;

            foreach (const auto &collection, job->collections()) {
                if (!serializer->isSelectedCollection(collection))
                    continue;

                auto job = storage->fetchItems(collection);
                Utils::JobHandler::install(job->kjob(), [job, add] {
                    if (job->kjob()->error() != KJob::NoError)
                        return;

                    foreach (const auto &item, job->items())
                        add(item);
                });
            }
        }
```

#### AUTO 


```{c}
const auto ids = m_tagItems.value(tagId);
```

#### AUTO 


```{c}
auto project21 = Domain::Project::Ptr::create();
```

#### AUTO 


```{c}
auto contextRepository = Domain::ContextRepository::Ptr();
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Domain::Artifact::Ptr &artifact, const QVariant &value, int role) {
        if (role != Qt::EditRole && role != Qt::CheckStateRole) {
            return false;
        }

        if (auto task = artifact.dynamicCast<Domain::Task>()) {
            const auto currentTitle = task->title();
            if (role == Qt::EditRole)
                task->setTitle(value.toString());
            else
                task->setDone(value.toInt() == Qt::Checked);

            const auto job = taskRepository()->update(task);
            installHandler(job, tr("Cannot modify task %1 in project %2").arg(currentTitle).arg(m_project->name()));
            return true;

        } else if (auto note = artifact.dynamicCast<Domain::Note>()) {
            if (role != Qt::EditRole)
                return false;

            const auto currentTitle = note->title();
            note->setTitle(value.toString());
            const auto job = noteRepository()->save(note);
            installHandler(job, tr("Cannot modify note %1 in project %2").arg(currentTitle).arg(m_project->name()));
            return true;

        }

        return false;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const QMimeData *mimeData, Qt::DropAction, const Domain::Task::Ptr &parentTask) {
        if (!mimeData->hasFormat("application/x-zanshin-object"))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                        [](const Domain::Artifact::Ptr &droppedArtifact) {
                            return !droppedArtifact.objectCast<Domain::Task>();
                        })) {
            return false;
        }

        foreach(const Domain::Artifact::Ptr &droppedArtifact, droppedArtifacts) {
            auto childTask = droppedArtifact.objectCast<Domain::Task>();
            const auto job = m_taskRepository->associate(parentTask, childTask);
            installHandler(job, tr("Cannot move task %1 as sub-task of %2").arg(childTask->title()).arg(parentTask->title()));
        }

        return true;
    }
```

#### AUTO 


```{c}
auto pagesDock = new QDockWidget(i18n("Pages"));
```

#### LAMBDA EXPRESSION 


```{c}
[] (const Domain::Task::List &tasks) -> QMimeData* {
        if (tasks.isEmpty())
            return Q_NULLPTR;

        auto draggedArtifacts = Domain::Artifact::List();
        foreach (const Domain::Task::Ptr &task, tasks) {
            draggedArtifacts.append(task.objectCast<Domain::Artifact>());
        }

        auto data = new QMimeData();
        data->setData("application/x-zanshin-object", "object");
        data->setProperty("objects", QVariant::fromValue(draggedArtifacts));
        return data;
    }
```

#### AUTO 


```{c}
auto fetchAdditionalInfo = [this](const QModelIndex &index, const Domain::Task::Ptr &task) -> AdditionalInfo {
        if (index.parent().isValid()) // children are in the same collection as their parent, so the same datasource
            return nullptr;

        AdditionalInfo datasourceQueryResult = m_taskQueries->findDataSource(task);
        if (datasourceQueryResult) {
            QPersistentModelIndex persistentIndex(index);
            datasourceQueryResult->addPostInsertHandler([persistentIndex](const Domain::DataSource::Ptr &, int) {
                // When a datasource was found (inserted into the result), update the rendering of the item
                auto model = const_cast<QAbstractItemModel *>(persistentIndex.model());
                model->dataChanged(persistentIndex, persistentIndex);
            });
        }
        return datasourceQueryResult;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[isInputCollection] (const Collection &collection) {
                                    auto parent = collection.parentCollection();
                                    while (parent.isValid() && !isInputCollection(parent))
                                        parent = parent.parentCollection();
                                    return !isInputCollection(parent);
                                }
```

#### AUTO 


```{c}
auto job = storage.fetchItem(findItem);
```

#### AUTO 


```{c}
const auto delegateText = m_model->property("delegateText").toString();
```

#### AUTO 


```{c}
auto result = m_data->reconstructItemDependencies(item);
```

#### LAMBDA EXPRESSION 


```{c}
[=] () mutable {
            if (!job->error()) {
                item.setId(m_data->maxItemId() + 1);
                item.setParentCollection(collection);
                // Force payload detach
                item.setPayloadFromData(item.payloadData());
                m_data->createItem(item);
            }
        }
```

#### AUTO 


```{c}
auto akonadiTag = m_serializer->createAkonadiTagFromTag(tag);
```

#### AUTO 


```{c}
auto dataFunction = [](const QColor &, int, int) {
            return QVariant();
        };
```

#### LAMBDA EXPRESSION 


```{c}
[gid] (const Akonadi::Tag &tag) {
                                   return tag.gid() == gid;
                               }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Domain::LiveQuery<QObject*, QString>::AddFunction &add) {
            Utils::JobHandler::install(new FakeJob, [this, add] {
                add(createObject(0, "0A"));
                add(createObject(1, "1A"));
                add(createObject(2, "2A"));
                add(createObject(3, "0B"));
                add(createObject(4, "1B"));
                add(createObject(5, "2B"));
                add(createObject(6, "0C"));
                add(createObject(7, "1C"));
                add(createObject(8, "2C"));
            });
        }
```

#### AUTO 


```{c}
auto flags = [this](const QObjectPtr &object) {
        const Qt::ItemFlags defaultFlags = Qt::ItemIsSelectable
                                         | Qt::ItemIsEnabled
                                         | Qt::ItemIsEditable;
        const Qt::ItemFlags immutableNodeFlags = Qt::ItemIsSelectable
                                               | Qt::ItemIsEnabled;
        const Qt::ItemFlags structureNodeFlags = Qt::NoItemFlags;


        return object.objectCast<Domain::Project>() ? defaultFlags
             : object == m_inboxObject ? immutableNodeFlags
             : structureNodeFlags;
    };
```

#### AUTO 


```{c}
auto artifact = currentArtifact();
```

#### LAMBDA EXPRESSION 


```{c}
[configGroup] (bool checked) mutable {
                configGroup.writeEntry("ShowDone", checked);
            }
```

#### AUTO 


```{c}
auto index = stubPageModel.itemModel.index(1, 0);
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Akonadi::Item &item, Domain::Note::Ptr &note) {
            m_serializer->updateNoteFromItem(note, item);
        }
```

#### AUTO 


```{c}
auto artifactResult = Domain::QueryResult<Domain::Artifact::Ptr>::create(artifactProvider);
```

#### AUTO 


```{c}
auto task2 = model->data(model->index(1, 0), Presentation::QueryTreeModelBase::ObjectRole).value<Domain::Task::Ptr>();
```

#### AUTO 


```{c}
auto task2 = stubPageModel.addTaskItem(QStringLiteral("Task2"));
```

#### AUTO 


```{c}
const auto remoteId = item.remoteId();
```

#### AUTO 


```{c}
auto exResult = exQuery->result();
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Domain::Task::Ptr &task) -> Domain::QueryResultInterface<Domain::Task::Ptr>::Ptr {
        if (!task)
            return m_taskQueries->findInboxTopLevel();
        else
            return m_taskQueries->findChildren(task);
    }
```

#### AUTO 


```{c}
auto attachment = m_task->attachments().at(index.row());
```

#### AUTO 


```{c}
auto res = Collection::List();
```

#### AUTO 


```{c}
auto pageListModel = m_availablePagesView->model()->property("pageListModel").value<QAbstractItemModel*>();
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Domain::DataSource::Ptr &source, int role, int) -> QVariant {
        if (role != Qt::DisplayRole
         && role != Qt::EditRole
         && role != Qt::DecorationRole
         && role != Qt::CheckStateRole
         && role != QueryTreeModelBase::IconNameRole
         && role != QueryTreeModelBase::IsDefaultRole) {
            return QVariant();
        }

        if (role == Qt::DisplayRole || role == Qt::EditRole) {
            return source->name();
        } else if (role == Qt::DecorationRole || role == QueryTreeModelBase::IconNameRole) {
            const QString iconName = source->iconName().isEmpty() ? QStringLiteral("folder") : source->iconName();

            if (role == Qt::DecorationRole)
                return QVariant::fromValue(QIcon::fromTheme(iconName));
            else
                return iconName;
        } else if (role == Qt::CheckStateRole) {
            if (source->contentTypes() != Domain::DataSource::NoContent)
                return source->isSelected() ? Qt::Checked : Qt::Unchecked;
            else
                return QVariant();
        } else if (role == QueryTreeModelBase::IsDefaultRole) {
            return m_dataSourceQueries->isDefaultSource(source);
        } else {
            return QVariant();
        }
    }
```

#### AUTO 


```{c}
auto mimeTypes = m_collection.contentMimeTypes();
```

#### AUTO 


```{c}
auto job = storage->searchCollections("Calendar3");
```

#### LAMBDA EXPRESSION 


```{c}
[this, root] (const DataSourceQuery::AddFunction &add) {
            CollectionFetchJobInterface *job = m_storage->fetchCollections(root,
                                                                           StorageInterface::Recursive,
                                                                           StorageInterface::Tasks | StorageInterface::Notes);
            Utils::JobHandler::install(job->kjob(), [this, root, job, add] {
                if (job->kjob()->error())
                    return;

                QHash<Collection::Id, Collection> children;
                foreach (const auto &collection, job->collections()) {
                    auto child = collection;
                    while (child.parentCollection() != root)
                        child = child.parentCollection();
                    if (!children.contains(child.id()))
                        children[child.id()] = child;
                }

                foreach (const auto &topLevel, children.values())
                    add(topLevel);
            });
        }
```

#### AUTO 


```{c}
auto task = topLevelProvider->data().at(i);
```

#### AUTO 


```{c}
auto exQuery = Domain::LiveQueryOutput<Domain::Note::Ptr>::Ptr();
```

#### AUTO 


```{c}
const auto onDueDate = dueDate.isValid() && dueDate == currentDate;
```

#### AUTO 


```{c}
auto exQuery = Domain::LiveQueryOutput<Domain::Context::Ptr>::Ptr();
```

#### AUTO 


```{c}
const auto leftTask = left.data(QueryTreeModelBase::ObjectRole).value<Domain::Task::Ptr>();
```

#### LAMBDA EXPRESSION 


```{c}
[storage, item, parent] (const Domain::LiveQueryInput<Item>::AddFunction &add) {
        auto job = storage->fetchItem(item, parent);
        Utils::JobHandler::install(job->kjob(), [storage, job, add, parent] {
            if (job->kjob()->error() != KJob::NoError)
                return;

            Q_ASSERT(job->items().size() == 1);
            auto item = job->items().at(0);
            Q_ASSERT(item.parentCollection().isValid());
            auto job = storage->fetchItems(item.parentCollection(), parent);
            Utils::JobHandler::install(job->kjob(), [job, add] {
                if (job->kjob()->error() != KJob::NoError)
                    return;

                foreach (const auto &item, job->items())
                    add(item);
            });
        });
    }
```

#### AUTO 


```{c}
const auto job = m_tagRepository->create(tag);
```

#### AUTO 


```{c}
auto doneViewAction = new QAction(this);
```

#### AUTO 


```{c}
const auto fullText = QString(title + '\n' + text);
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Akonadi::Tag &tag, const Domain::Context::Ptr &context) {
            return m_serializer->isContextTag(context, tag);
        }
```

#### AUTO 


```{c}
const auto checkRect = style->subElementRect(QStyle::SE_ItemViewItemCheckIndicator, &opt, widget);
```

#### AUTO 


```{c}
auto fileName = temporaryFile.fileName().mid(QDir::tempPath().size() + 1);
```

#### AUTO 


```{c}
auto drop = [this](const QMimeData *mimeData, Qt::DropAction, const Domain::Task::Ptr &parentTask) {
        if (!mimeData->hasFormat(QStringLiteral("application/x-zanshin-object")))
            return false;

        auto droppedTasks = mimeData->property("objects").value<Domain::Task::List>();
        if (droppedTasks.isEmpty())
            return false;

        foreach(const auto &childTask, droppedTasks) {
            if (parentTask) {
                const auto job = m_taskRepository->associate(parentTask, childTask);
                installHandler(job, i18n("Cannot move task %1 as sub-task of %2", childTask->title(), parentTask->title()));
            } else {
                childTask->setStartDate(Utils::DateTime::currentDate());
                // TODO something like m_taskRepository->update(childTask) is missing here
                // It was removed in commit c97a99bf because it led to a LLCONFLICT in akonadi (due to dissociate below).
                // The removal broke tests-features-workday-workdaydraganddropfeature (date not changed).

                auto job = m_taskRepository->dissociate(childTask);
                installHandler(job, i18n("Cannot deparent task %1 from its parent", childTask->title()));
            }
        }

        return true;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString &value, int pos)
            {
                postInserts << value;
                postInsertsPos << pos;
            }
```

#### LAMBDA EXPRESSION 


```{c}
[] (const QString &s) {
            return !s.isEmpty();
        }
```

#### AUTO 


```{c}
auto job = new ItemJob(item);
```

#### AUTO 


```{c}
const auto createdTask = inbox.addItem(title, parentIndex).objectCast<Domain::Task>();
```

#### LAMBDA EXPRESSION 


```{c}
[fetchItemJob, context, job, this] {
        if (fetchItemJob->kjob()->error() != KJob::NoError)
            return;

        Q_ASSERT(fetchItemJob->items().size() == 1);
        auto childItem = fetchItemJob->items().at(0);
        m_serializer->removeContextFromTask(context, childItem);

        auto updateJob = m_storage->updateItem(childItem, this);
        job->addSubjob(updateJob);
        updateJob->start();
    }
```

#### AUTO 


```{c}
auto setDataFunction = [](const Domain::Task::Ptr &, const QVariant &, int) {
            return false;
        };
```

#### LAMBDA EXPRESSION 


```{c}
[fetchParentItemJob, child, childItem, job, this] {
            if (fetchParentItemJob->kjob()->error() != KJob::NoError)
                return;

            Q_ASSERT(fetchParentItemJob->items().size() == 1);
            auto parentItem = fetchParentItemJob->items().first();

            const int itemCollectionId = childItem.parentCollection().id();
            const int parentCollectionId = parentItem.parentCollection().id();

            if (child.objectCast<Domain::Task>()
             && itemCollectionId != parentCollectionId) {
                ItemFetchJobInterface *fetchChildrenItemJob = m_storage->fetchItems(childItem.parentCollection());
                job->install(fetchChildrenItemJob->kjob(), [fetchChildrenItemJob, childItem, parentItem, job, this] {
                    if (fetchChildrenItemJob->kjob()->error() != KJob::NoError)
                        return;

                    Item::List childItems = m_serializer->filterDescendantItems(fetchChildrenItemJob->items(), childItem);

                    auto transaction = m_storage->createTransaction();
                    m_storage->updateItem(childItem, transaction);
                    childItems.push_front(childItem);
                    m_storage->moveItems(childItems, parentItem.parentCollection(), transaction);
                    job->addSubjob(transaction);
                    transaction->start();
                });
            } else {
                auto updateJob = m_storage->updateItem(childItem);
                job->addSubjob(updateJob);
                updateJob->start();
            }
        }
```

#### AUTO 


```{c}
auto setData = [this] (const Domain::Task::Ptr &task, const QVariant &value, int role) {
        if (role != Qt::EditRole && role != Qt::CheckStateRole)
            return false;

        const auto currentTitle = task->title();
        if (role == Qt::EditRole)
            task->setTitle(value.toString());
        else
            task->setDone(value.toInt() == Qt::Checked);

        const auto job = m_taskRepository->update(task);
        installHandler(job, i18n("Cannot modify task %1 in context %2", currentTitle, m_context->name()));
        return true;
    };
```

#### AUTO 


```{c}
auto setData = [this](const Domain::Artifact::Ptr &artifact, const QVariant &value, int role) {
        if (role != Qt::EditRole && role != Qt::CheckStateRole) {
            return false;
        }

        if (auto task = artifact.dynamicCast<Domain::Task>()) {
            const auto currentTitle = task->title();
            if (role == Qt::EditRole)
                task->setTitle(value.toString());
            else
                task->setDone(value.toInt() == Qt::Checked);

            const auto job = m_taskRepository->update(task);
            installHandler(job, i18n("Cannot modify task %1 in Workday", currentTitle));
            return true;
        }

        return false;
    };
```

#### AUTO 


```{c}
auto job = taskRepository()->create(task);
```

#### LAMBDA EXPRESSION 


```{c}
[=] () mutable {
            tag.setId(m_data->maxTagId() + 1);
            m_data->createTag(tag);
        }
```

#### AUTO 


```{c}
auto emptyProvider = Domain::QueryResultProvider<Domain::Task::Ptr>::Ptr::create();
```

#### AUTO 


```{c}
auto job = new Akonadi::ItemCreateJob(item, calendar2());
```

#### AUTO 


```{c}
auto lastRelatedUid = m_idToRelatedUidCache.value(item.id());
```

#### AUTO 


```{c}
const auto title = m_model->property("title").toString();
```

#### AUTO 


```{c}
auto task3 = model->data(model->index(2, 0), Presentation::QueryTreeModelBase::ObjectRole).value<Domain::Task::Ptr>();
```

#### AUTO 


```{c}
auto drop = [this](const QMimeData *mimeData, Qt::DropAction, const Domain::Artifact::Ptr &artifact) {
        auto parentTask = artifact.objectCast<Domain::Task>();

        if (!mimeData->hasFormat("application/x-zanshin-object"))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                        [](const Domain::Artifact::Ptr &droppedArtifact) {
                            return !droppedArtifact.objectCast<Domain::Task>();
                        })) {
            return false;
        }

        foreach(const auto &droppedArtifact, droppedArtifacts) {
            auto childTask = droppedArtifact.objectCast<Domain::Task>();

            if (parentTask) {
                if (parentTask == childTask)
                    return false;

                const auto job = taskRepository()->associate(parentTask, childTask);
                installHandler(job, tr("Cannot move task %1 as sub-task of %2").arg(childTask->title()).arg(parentTask->title()));
            } else {
                const auto job = taskRepository()->dissociate(childTask);
                installHandler(job, tr("Cannot deparent task %1 from its parent").arg(childTask->title()));
            }
        }

        return true;
    };
```

#### AUTO 


```{c}
auto goPreviousAction = available.findChild<QAction*>(QStringLiteral("goPreviousAction"));
```

#### AUTO 


```{c}
auto task = currentTask();
```

#### AUTO 


```{c}
const auto job = m_projectRepository->update(project);
```

#### AUTO 


```{c}
const auto startDate = task ? task->startDate() : QDateTime();
```

#### AUTO 


```{c}
const auto sources = result->data();
```

#### AUTO 


```{c}
auto c3 = Akonadi::Collection(44);
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Domain::DataSource::Ptr &source) {
                                   return m_taskRepository->isDefaultSource(source);
                               }
```

#### AUTO 


```{c}
auto relatedHeader1 = new KMime::Headers::Generic("X-Zanshin-RelatedProjectUid");
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QMimeData *mimeData, Qt::DropAction, const Domain::Artifact::Ptr &artifact) {
        Q_UNUSED(mimeData);
        Q_UNUSED(artifact);
        qFatal("Not implemented yet");
        return false;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Akonadi::Item &item) {
        const bool excluded = !m_serializer->relatedUidFromItem(item).isEmpty()
                           || (!m_serializer->isTaskItem(item) && !m_serializer->isNoteItem(item))
                           || (m_serializer->isTaskItem(item) && m_serializer->hasContextTags(item))
                           || m_serializer->hasAkonadiTags(item);

        return !excluded;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &collection : collections) {
            auto parent = collection.parentCollection();
            while (parent != Akonadi::Collection::root()) {
                QVERIFY(parent.isValid());
                parent = parent.parentCollection();
            }
        }
```

#### AUTO 


```{c}
auto tagRepository = Domain::TagRepository::Ptr();
```

#### AUTO 


```{c}
auto parentId = m_uidtoIdCache.value(lastRelatedUid);
```

#### AUTO 


```{c}
auto addAction = page.findChild<QAction*>("addItemAction");
```

#### AUTO 


```{c}
auto m = availableSources->property("sourceListModel").value<QAbstractItemModel*>();
```

#### AUTO 


```{c}
auto notifiedCollection= spy.takeFirst().at(0).value<Akonadi::Collection>();
```

#### AUTO 


```{c}
auto fetchAdditionalInfo = [this](const QModelIndex &index, const Domain::Task::Ptr &task) {
        return fetchTaskExtraData(m_taskQueries, TaskExtraPart::DataSource, index, task);
    };
```

#### AUTO 


```{c}
auto attr = new TimestampAttribute();
```

#### AUTO 


```{c}
auto inPredicate = [] (const Akonadi::Item &item) {
            return titleFromItem(item).endsWith(QLatin1String("-in"));
        };
```

#### AUTO 


```{c}
const auto summaryText = opt.text;
```

#### AUTO 


```{c}
auto baseResult = QueryResult<Derived::Ptr, Base::Ptr>::copy(derivedResult);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QModelIndex &index, const Domain::Artifact::Ptr &artifact) -> AdditionalInfo {
        if (index.parent().isValid()) // children are in the same collection as their parent, so the same datasource
            return nullptr;
        if (auto task = artifact.dynamicCast<Domain::Task>()) {
            AdditionalInfo datasourceQueryResult = m_taskQueries->findDataSource(task);
            if (datasourceQueryResult) {
                QPersistentModelIndex persistentIndex(index);
                datasourceQueryResult->addPostInsertHandler([persistentIndex](const Domain::DataSource::Ptr &, int) {
                    // When a datasource was found (inserted into the result), update the rendering of the item
                    auto model = const_cast<QAbstractItemModel *>(persistentIndex.model());
                    model->dataChanged(persistentIndex, persistentIndex);
                });
            }
            return datasourceQueryResult;
        }
        return nullptr;

    }
```

#### LAMBDA EXPRESSION 


```{c}
[fetchChildrenItemJob, childItem, parentItem, job, this] {
                    if (fetchChildrenItemJob->kjob()->error() != KJob::NoError)
                        return;

                    Item::List childItems = m_serializer->filterDescendantItems(fetchChildrenItemJob->items(), childItem);

                    auto transaction = m_storage->createTransaction();
                    m_storage->updateItem(childItem, transaction);
                    childItems.push_front(childItem);
                    m_storage->moveItems(childItems, parentItem.parentCollection(), transaction);
                    job->addSubjob(transaction);
                    transaction->start();
                }
```

#### AUTO 


```{c}
auto centralListModel = droppedItems.first().model();
```

#### LAMBDA EXPRESSION 


```{c}
[fetchItemJob, compositeJob, this] {
        if (fetchItemJob->kjob()->error() != KJob::NoError)
           return;

        Q_ASSERT(fetchItemJob->items().size() == 1);
        auto item = fetchItemJob->items().at(0);

        ItemFetchJobInterface *fetchCollectionItemsJob = m_storage->fetchItems(item.parentCollection(), this);
        compositeJob->install(fetchCollectionItemsJob->kjob(), [fetchCollectionItemsJob, item, compositeJob, this] {
            if (fetchCollectionItemsJob->kjob()->error() != KJob::NoError)
                return;

            Item::List childItems = m_serializer->filterDescendantItems(fetchCollectionItemsJob->items(), item);
            childItems << item;

            auto removeJob = m_storage->removeItems(childItems, this);
            compositeJob->addSubjob(removeJob);
            removeJob->start();
        });
    }
```

#### AUTO 


```{c}
auto item = serializer.createItemFromTask(task);
```

#### AUTO 


```{c}
const auto &current = m_pagesView->currentIndex();
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Akonadi::Collection &collection, const Domain::DataSource::Ptr &source) {
            return m_serializer->representsCollection(source, collection);
        }
```

#### AUTO 


```{c}
const auto noteMimeTypes = QStringList() << "text/x-vnd.akonadi.note";
```

#### AUTO 


```{c}
auto data = std::unique_ptr<QMimeData>(model.mimeData(QList<QModelIndex>() << model.index(1, 0) << model.index(2, 0)));
```

#### LAMBDA EXPRESSION 


```{c}
[] (const Domain::Note::List &notes) -> QMimeData* {
        if (notes.isEmpty())
            return Q_NULLPTR;

        auto draggedArtifacts = Domain::Artifact::List();
        std::copy(notes.constBegin(), notes.constEnd(),
                  std::back_inserter(draggedArtifacts));

        auto data = new QMimeData;
        data->setData(QStringLiteral("application/x-zanshin-object"), "object");
        data->setProperty("objects", QVariant::fromValue(draggedArtifacts));
        return data;
    }
```

#### AUTO 


```{c}
const auto &roleName
```

#### LAMBDA EXPRESSION 


```{c}
[this, job, add] {
                if (job->kjob()->error() != KJob::NoError)
                    return;

                for (auto collection : job->collections()) {
                    ItemFetchJobInterface *job = m_storage->fetchItems(collection);
                    Utils::JobHandler::install(job->kjob(), [this, job, add] {
                        if (job->kjob()->error() != KJob::NoError)
                            return;

                        for (auto item : job->items()) {
                            add(item);
                        }
                    });
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const DataSourceQuery::AddFunction &add) {
            if (m_searchTerm.isEmpty())
                return;

            CollectionSearchJobInterface *job = m_storage->searchCollections(m_searchTerm);
            Utils::JobHandler::install(job->kjob(), [this, job, add] {
                if (job->kjob()->error())
                    return;

                QHash<Collection::Id, Collection> topLevels;
                foreach (const auto &collection, job->collections()) {
                    auto topLevel = collection;
                    while (topLevel.parentCollection() != Collection::root())
                        topLevel = topLevel.parentCollection();
                    if (!topLevels.contains(topLevel.id()))
                        topLevels[topLevel.id()] = topLevel;
                }

                foreach (const auto &topLevel, topLevels.values())
                    add(topLevel);

            });
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, &afterReset] (const Domain::LiveQuery<QObject*, QString>::AddFunction &add) {
            Utils::JobHandler::install(new FakeJob, [this, &afterReset, add] {
                add(createObject(0, "0A"));
                add(createObject(1, "1A"));
                add(createObject(2, "2A"));
                add(createObject(3, "0B"));
                add(createObject(4, "1B"));
                add(createObject(5, "2B"));

                if (afterReset) {
                    add(createObject(6, "0C"));
                    add(createObject(7, "1C"));
                    add(createObject(8, "2C"));
                }
            });
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, &afterReset, add] {
                add(createObject(0, "0A"));
                add(createObject(1, "1A"));
                add(createObject(2, "2A"));
                add(createObject(3, "0B"));
                add(createObject(4, "1B"));
                add(createObject(5, "2B"));

                if (afterReset) {
                    add(createObject(6, "0C"));
                    add(createObject(7, "1C"));
                    add(createObject(8, "2C"));
                }
            }
```

#### AUTO 


```{c}
auto exQuery = Domain::LiveQueryOutput<Domain::Artifact::Ptr>::Ptr();
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QModelIndex &index) {
                               return static_cast<QueryTreeNode<ItemType>*>(nodeFromIndex(index))->item();
                           }
```

#### LAMBDA EXPRESSION 


```{c}
[this, add] {
                add(createObject(0, "0A"));
                add(createObject(1, "1A"));
                add(createObject(2, "2A"));
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Akonadi::Item &item) {
            const bool excluded = !m_serializer->relatedUidFromItem(item).isEmpty()
                               || (!m_serializer->isTaskItem(item) && !m_serializer->isNoteItem(item))
                               || (m_serializer->isTaskItem(item) && m_serializer->hasContextTags(item))
                               || m_serializer->hasPlainTags(item);

            return !excluded;
        }
```

#### AUTO 


```{c}
auto query = Domain::LiveQuery<InputType, OutputType>::Ptr::create();
```

#### AUTO 


```{c}
auto item = m_serializer->createItemFromTask(task);
```

#### AUTO 


```{c}
const auto noteTaskCollection = Akonadi::Collection(GenCollection().withRootAsParent()
                                                                           .withId(3)
                                                                           .withName("tasks+notes")
                                                                           .withTaskContent()
                                                                           .withNoteContent());
```

#### AUTO 


```{c}
auto sourcesView = available.findChild<QTreeView*>(QStringLiteral("sourcesView"));
```

#### AUTO 


```{c}
auto fetch = m_helpers->searchCollections(root, &m_searchTerm);
```

#### AUTO 


```{c}
auto setDataFunction = [&](const Domain::Task::Ptr &task, const QVariant &value, int role) {
            if (role != Qt::EditRole && role != Qt::CheckStateRole) {
                return false;
            }

            if (role == Qt::EditRole) {
                task->setTitle(value.toString());
            } else {
                task->setDone(value.toInt() == Qt::Checked);
            }

            repositoryMock.getInstance().update(task);
            return true;
        };
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Akonadi::Tag &akonadiTag, Domain::Tag::Ptr &tag) {
            m_serializer->updateTagFromAkonadiTag(tag, akonadiTag);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, &savedTask] (const Domain::Task::Ptr &task) {
            savedTask = task;
            auto job = new FakeJob(this);
            job->setExpectedError(KJob::KilledJobError, QStringLiteral("Foo"));
            return job;
        }
```

#### AUTO 


```{c}
auto filterEdit = filter->findChild<QLineEdit*>();
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QMimeData *mimeData, Qt::DropAction, const Domain::Artifact::Ptr &artifact) {
        auto parentTask = artifact.objectCast<Domain::Task>();

        if (!mimeData->hasFormat(QStringLiteral("application/x-zanshin-object")))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                        [](const Domain::Artifact::Ptr &droppedArtifact) {
                            return !droppedArtifact.objectCast<Domain::Task>();
                        })) {
            return false;
        }

        foreach(const auto &droppedArtifact, droppedArtifacts) {
            auto childTask = droppedArtifact.objectCast<Domain::Task>();

            if (parentTask) {
                const auto job = m_taskRepository->associate(parentTask, childTask);
                installHandler(job, tr("Cannot move task %1 as sub-task of %2").arg(childTask->title(), parentTask->title()));
            } else {
                childTask->setStartDate(Utils::DateTime::currentDateTime());

                auto job = m_taskRepository->update(childTask);
                installHandler(job, tr("Cannot update task %1").arg(childTask->title()));

                job = m_taskRepository->dissociate(childTask);
                installHandler(job, tr("Cannot deparent task %1 from its parent").arg(childTask->title()));
            }
        }

        return true;
    }
```

#### AUTO 


```{c}
auto tagResult = Domain::QueryResult<Domain::Tag::Ptr>::create(tagProvider);
```

#### AUTO 


```{c}
auto collection1 = GenCollection().withId(42).withRootAsParent().withTaskContent();
```

#### LAMBDA EXPRESSION 


```{c}
[=] {
            m_data->modifyCollection(collection);
        }
```

#### AUTO 


```{c}
const auto oldTag = m_tags.take(tag.id());
```

#### LAMBDA EXPRESSION 


```{c}
[provider, job, project, this] {
        if (job->kjob()->error() != KJob::NoError)
            return;

        for (auto collection : job->collections()) {
            ItemFetchJobInterface *job = m_storage->fetchItems(collection);
            Utils::JobHandler::install(job->kjob(), [provider, job, project, this] {
                if (job->kjob()->error() != KJob::NoError)
                    return;

                for (auto item : job->items()) {
                    if (m_serializer->isProjectChild(project, item)) {
                        auto artifact = deserializeArtifact(item);
                        if (artifact)
                            provider->append(artifact);
                    }
                }
            });
        }
    }
```

#### AUTO 


```{c}
auto note2 = Domain::Note::Ptr::create();
```

#### AUTO 


```{c}
auto projectResult = m_taskQueries->findProject(task);
```

#### LAMBDA EXPRESSION 


```{c}
[] (const Domain::Task::Ptr &task) {
        Q_UNUSED(task);
        return Qt::ItemIsSelectable
             | Qt::ItemIsEnabled
             | Qt::ItemIsEditable
             | Qt::ItemIsDragEnabled
             | Qt::ItemIsUserCheckable
             | Qt::ItemIsDropEnabled;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[persistentIndex](const Domain::Project::Ptr &, int) {
                    // When a project was found (inserted into the result), update the rendering of the item
                    auto model = const_cast<QAbstractItemModel *>(persistentIndex.model());
                    model->dataChanged(persistentIndex, persistentIndex);
                }
```

#### AUTO 


```{c}
auto defaultSource = Domain::DataSource::Ptr::create();
```

#### AUTO 


```{c}
auto project1Provider = Domain::QueryResultProvider<Domain::Project::Ptr>::Ptr::create();
```

#### AUTO 


```{c}
auto filter = m_filterProxyModel->filterRegExp().pattern();
```

#### AUTO 


```{c}
auto todo = contextItem.payload<KCalCore::Todo::Ptr>();
```

#### AUTO 


```{c}
auto fetch = helpers->fetchItems(tag);
```

#### AUTO 


```{c}
auto job = storage->fetchCollections(Akonadi::Collection::root(), Akonadi::Storage::Recursive, Akonadi::Storage::AllContent);
```

#### AUTO 


```{c}
auto children = Akonadi::Collection::List();
```

#### AUTO 


```{c}
auto artifact = topLevelProvider->data().at(i);
```

#### AUTO 


```{c}
auto object2 = deps.create<Interface0>();
```

#### AUTO 


```{c}
auto &query = m_findChildren[root.id()];
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &attachment : task->attachments()) {
        KCalCore::Attachment attach(QByteArray{});
        if (attachment.isUri())
            attach.setUri(attachment.uri().toString());
        else
            attach.setDecodedData(attachment.data());
        attach.setMimeType(attachment.mimeType());
        attach.setLabel(attachment.label());
        todo->addAttachment(attach);
    }
```

#### AUTO 


```{c}
auto pageTypeCombo = dialog.findChild<QComboBox*>("typeCombo");
```

#### AUTO 


```{c}
const auto it = m_tagItems.find(tag.id());
```

#### AUTO 


```{c}
auto layout = new QVBoxLayout;
```

#### AUTO 


```{c}
auto tag = Akonadi::Tag();
```

#### AUTO 


```{c}
auto messageWidget = page.findChild<KMessageWidget*>(QStringLiteral("messageWidget"));
```

#### LAMBDA EXPRESSION 


```{c}
[this, &savedArtifact] (const Domain::Artifact::Ptr &artifact) {
            savedArtifact = artifact;
            auto job = new FakeJob(this);
            job->setExpectedError(KJob::KilledJobError, QStringLiteral("Foo"));
            return job;
        }
```

#### AUTO 


```{c}
auto tagIds = QList<Akonadi::Tag::Id>();
```

#### AUTO 


```{c}
auto drop = [this] (const QMimeData *mimeData, Qt::DropAction, const Domain::Artifact::Ptr &artifact) {
        auto parentTask = artifact.objectCast<Domain::Task>();
        if (!parentTask)
            return false;

        if (!mimeData->hasFormat("application/x-zanshin-object"))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                        [](const Domain::Artifact::Ptr &droppedArtifact) {
                            return !droppedArtifact.objectCast<Domain::Task>();
                        })) {
            return false;
        }

        foreach(const Domain::Artifact::Ptr &droppedArtifact, droppedArtifacts) {
            auto childTask = droppedArtifact.objectCast<Domain::Task>();
            const auto job = taskRepository()->associate(parentTask, childTask);
            if (!errorHandler())
                continue;

            errorHandler()->installHandler(job, tr("Cannot move task %1 as sub-task of %2").arg(childTask->title()).arg(parentTask->title()));
        }

        return true;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this, model](const Domain::Task::Ptr &, int) {
                                        model->endInsertRows();
                                    }
```

#### AUTO 


```{c}
const auto item2 = Akonadi::Item(GenTodo().withId(2).withParent(2).withContexts({"ctx-2"}).withTitle("item2"));
```

#### AUTO 


```{c}
const auto dueDateWidth = dueDate.isValid() ? (summaryMetrics.horizontalAdvance(dueDateText) + 2 * textMargin) : 0;
```

#### AUTO 


```{c}
auto repository = deps->create<Domain::TaskRepository>();
```

#### AUTO 


```{c}
auto job = m_projectRepository->dissociate(artifact);
```

#### AUTO 


```{c}
auto predicate = [this, childItem] (const Akonadi::Item &item) {
        return m_serializer->isProjectItem(item);
    };
```

#### AUTO 


```{c}
auto data = [] (const Domain::Task::Ptr &task, int role, int) -> QVariant {
        if (role != Qt::DisplayRole
         && role != Qt::EditRole
         && role != Qt::CheckStateRole) {
            return QVariant();
        }

        if (role == Qt::DisplayRole || role == Qt::EditRole) {
            return task->title();
        } else if (role == Qt::CheckStateRole){
            return task->isDone() ? Qt::Checked : Qt::Unchecked;
        } else {
            return QVariant();
        }
    };
```

#### AUTO 


```{c}
const auto job = parentTask ? m_taskRepository->createChild(task, parentTask)
                   : m_taskRepository->createInContext(task, m_context);
```

#### AUTO 


```{c}
auto artifactProvider = Domain::QueryResultProvider<Domain::Artifact::Ptr>::Ptr::create();
```

#### AUTO 


```{c}
auto expression = QStringLiteral("41+1");
```

#### LAMBDA EXPRESSION 


```{c}
[](const Domain::Task::Ptr &task, int role, const TaskExtraDataPtr &info) -> QVariant {
        return defaultTaskData(task, role, info);
    }
```

#### AUTO 


```{c}
auto selectedAttribute = collection.attribute<Akonadi::ApplicationSelectedAttribute>(Akonadi::Collection::AddIfMissing);
```

#### AUTO 


```{c}
const auto job = m_taskRepository->create(task);
```

#### AUTO 


```{c}
auto fetch = m_helpers->fetchItems(StorageInterface::Tasks | StorageInterface::Notes);
```

#### AUTO 


```{c}
auto textEdit = editor.findChild<QPlainTextEdit*>("textEdit");
```

#### AUTO 


```{c}
auto itemFetchJob2 = new MockItemFetchJob(this);
```

#### AUTO 


```{c}
auto childItem = fetchItemJob->items().first();
```

#### AUTO 


```{c}
const auto recurrence = m_model->property("recurrence").value<Domain::Task::Recurrence>();
```

#### AUTO 


```{c}
auto exPredicate = [] (const Akonadi::Item &item) {
            return titleFromItem(item).endsWith("-ex");
        };
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &collection : collections) {
            auto parent = collection.parentCollection();
            while (parent != Akonadi::Collection::root()) {
                QVERIFY(parent.isValid());
                QVERIFY(!parent.displayName().isEmpty());
                parent = parent.parentCollection();
            }
        }
```

#### AUTO 


```{c}
auto item = fetchJob->items().first();
```

#### AUTO 


```{c}
const auto item3 = Akonadi::Item(GenTodo().withId(3).withParent(1).withTags({1}).withTitle("item3"));
```

#### AUTO 


```{c}
auto expectedText = tr("Delegated to: <b>%1</b>").arg(QStringLiteral("John Doe"));
```

#### AUTO 


```{c}
auto removeAttachmentButton = editor.findChild<QToolButton*>(QStringLiteral("removeAttachmentButton"));
```

#### AUTO 


```{c}
auto job = storage.moveItem(item, calendar1());
```

#### AUTO 


```{c}
auto query = [this](const QObjectPtr &object) -> Domain::QueryResultInterface<QObjectPtr>::Ptr {
        if (!object)
            return Domain::QueryResult<QObjectPtr>::create(m_rootsProvider);
        else if (object == m_tagsObject)
            return Domain::QueryResult<Domain::Tag::Ptr, QObjectPtr>::copy(m_tagQueries->findAll());
        else
            return Domain::QueryResult<QObjectPtr>::Ptr();
    };
```

#### LAMBDA EXPRESSION 


```{c}
[] (const Akonadi::Item &item1, const Akonadi::Item &item2) {
        return item1.id() == item2.id();
    }
```

#### AUTO 


```{c}
auto item = new QStandardItem;
```

#### LAMBDA EXPRESSION 


```{c}
[&] (const QMimeData *, Qt::DropAction, const QString &) {
            dropCalled = true;
            return false;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const QMimeData *mimeData, Qt::DropAction, const Domain::Task::Ptr &parentTask) {
        if (!mimeData->hasFormat("application/x-zanshin-object"))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                        [](const Domain::Artifact::Ptr &droppedArtifact) {
                            return !droppedArtifact.objectCast<Domain::Task>();
                        })) {
            return false;
        }

        using namespace std::placeholders;
        auto associate = std::function<KJob*(Domain::Task::Ptr)>();
        auto dissociate = std::function<KJob*(Domain::Task::Ptr)>();
        auto parentTitle = QString();

        if (parentTask) {
            associate = std::bind(&Domain::TaskRepository::associate, m_taskRepository, parentTask, _1);
            dissociate = [] (Domain::Task::Ptr) -> KJob* { return Q_NULLPTR; };
            parentTitle = parentTask->title();
        } else {
            associate = std::bind(&Domain::ContextRepository::associate, m_contextRepository, m_context, _1);
            dissociate = std::bind(&Domain::TaskRepository::dissociate, m_taskRepository, _1);
            parentTitle = m_context->name();
        }

        foreach(const Domain::Artifact::Ptr &droppedArtifact, droppedArtifacts) {
            auto childTask = droppedArtifact.objectCast<Domain::Task>();
            auto job = associate(childTask);
            installHandler(job, tr("Cannot move task %1 as sub-task of %2").arg(childTask->title(), parentTitle));
            job = dissociate(childTask);
            if (job)
                installHandler(job, tr("Cannot dissociate task %1 from its parent").arg(childTask->title()));
        }

        return true;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Domain::DataSource::Ptr &, int) {
                                         endRemoveRows();
                                     }
```

#### AUTO 


```{c}
auto drop = [this](const QMimeData *mimeData, Qt::DropAction, const QObjectPtr &object) {
        if (!mimeData->hasFormat("application/x-zanshin-object"))
            return false;

        auto artifact = mimeData->property("object").value<Domain::Artifact::Ptr>();
        if (!artifact)
            return false;

        auto project = object.objectCast<Domain::Project>();
        if (project) {
            m_projectRepository->associate(project, artifact);
            return true;
        } else if (object == m_inboxObject) {
            auto job = m_projectRepository->dissociate(artifact);
            if (auto task = artifact.objectCast<Domain::Task>()) {
                Utils::JobHandler::install(job, [this, task] {
                    m_taskRepository->dissociate(task);
                });
            }
            return true;
        }

        return false;
    };
```

#### AUTO 


```{c}
auto result = TaskResult::create(provider);
```

#### LAMBDA EXPRESSION 


```{c}
[fetchItemJob, job, this] {
        if (fetchItemJob->kjob()->error() != KJob::NoError)
            return;

        Q_ASSERT(fetchItemJob->items().size() == 1);
        auto childItem = fetchItemJob->items().at(0);

        m_serializer->removeItemParent(childItem);
        m_serializer->clearItem(&childItem);

        auto updateJob = m_storage->updateItem(childItem);
        job->addSubjob(updateJob);
        updateJob->start();
    }
```

#### AUTO 


```{c}
auto setData = [this](const QObjectPtr &object, const QVariant &value, int role) {
        if (role != Qt::EditRole) {
            return false;
        }

        if (object == m_inboxObject
         || object == m_projectsObject
         || object == m_contextsObject
         || object == m_tagsObject) {
            return false;
        }

        if (auto project = object.objectCast<Domain::Project>()) {
            project->setName(value.toString());
            m_projectRepository->update(project);
        } else if (auto context = object.objectCast<Domain::Context>()) {
            context->setName(value.toString());
            m_contextRepository->update(context);
        } else if (object.objectCast<Domain::Tag>()) {
            return false; // Tag renaming is NOT allowed
        } else {
            Q_ASSERT(false);
        }

        return true;
    };
```

#### AUTO 


```{c}
auto it = actions.constBegin();
```

#### AUTO 


```{c}
auto *fetchJob = storage->fetchItems(collection, nullptr);
```

#### AUTO 


```{c}
auto availablePages = new QObject(model.data());
```

#### AUTO 


```{c}
auto expectedColNames = QStringList();
```

#### AUTO 


```{c}
auto repository = Utils::DependencyManager::globalInstance().create<Domain::TaskRepository>();
```

#### AUTO 


```{c}
auto sources = result->data();
```

#### AUTO 


```{c}
auto item = fetchItemJob->items().at(0);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto item : job->items()) {
                    auto task = deserializeTask(item);
                    if (task)
                        provider->append(task);
                }
```

#### AUTO 


```{c}
auto setData = [this] (const Domain::Note::Ptr &note, const QVariant &value, int role) {
        if (role != Qt::EditRole) {
            return false;
        }

        const auto currentTitle = note->title();
        note->setTitle(value.toString());
        const auto job = m_noteRepository->update(note);
        installHandler(job, i18n("Cannot modify note %1 in tag %2", currentTitle, m_tag->name()));
        return true;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[&called](const QString&, QWidget*) { called = true; return QMessageBox::Yes;}
```

#### LAMBDA EXPRESSION 


```{c}
[this, job, add] {
                if (job->kjob()->error())
                    return;

                QHash<Collection::Id, Collection> topLevels;
                foreach (const auto &collection, job->collections()) {
                    auto topLevel = collection;
                    while (topLevel.parentCollection() != Collection::root())
                        topLevel = topLevel.parentCollection();
                    if (!topLevels.contains(topLevel.id()))
                        topLevels[topLevel.id()] = topLevel;
                }

                foreach (const auto &topLevel, topLevels.values())
                    add(topLevel);

            }
```

#### AUTO 


```{c}
auto source3Provider = Domain::QueryResultProvider<Domain::DataSource::Ptr>::Ptr::create();
```

#### AUTO 


```{c}
auto job = storage->fetchItems(calendar2());
```

#### AUTO 


```{c}
auto displayedIndex2 = displayedModel->index(2, 0);
```

#### LAMBDA EXPRESSION 


```{c}
[] (const QString &, const QVariant &, int) {
            return false;
        }
```

#### AUTO 


```{c}
auto job = createStorage()->fetchCollections(collection, Akonadi::StorageInterface::Base);
```

#### AUTO 


```{c}
auto droppedArtifact = mimeData->property("object").value<Domain::Artifact::Ptr>();
```

#### AUTO 


```{c}
auto appModel = new ApplicationModel(new Akonadi::ArtifactQueries(this),
                                             new Akonadi::ProjectQueries(this),
                                             new Akonadi::ProjectRepository(this),
                                             new Akonadi::ContextQueries(this),
                                             new Akonadi::ContextRepository(this),
                                             new Akonadi::DataSourceQueries(this),
                                             new Akonadi::DataSourceRepository(this),
                                             new Akonadi::TaskQueries(this),
                                             new Akonadi::TaskRepository(this),
                                             new Akonadi::NoteRepository(this),
                                             new Akonadi::TagQueries(this),
                                             new Akonadi::TagRepository(this),
                                             this);
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const TaskQuery::AddFunction &add) {
            CollectionFetchJobInterface *job = m_storage->fetchCollections(Akonadi::Collection::root(),
                                                                           StorageInterface::Recursive,
                                                                           StorageInterface::Tasks);
            Utils::JobHandler::install(job->kjob(), [this, job, add] {
                if (job->kjob()->error() != KJob::NoError)
                    return;

                for (auto collection : job->collections()) {
                    ItemFetchJobInterface *job = m_storage->fetchItems(collection);
                    Utils::JobHandler::install(job->kjob(), [this, job, add] {
                        if (job->kjob()->error() != KJob::NoError)
                            return;

                        for (auto item : job->items()) {
                            add(item);
                        }
                    });
                }
            });
        }
```

#### LAMBDA EXPRESSION 


```{c}
[child, parent, fetchParentItemJob, partialParentItem, childItem, job, this] {
            if (fetchParentItemJob->kjob()->error() != KJob::NoError)
                return;

            const auto items = fetchParentItemJob->items();
            const auto parentIndex = items.indexOf(partialParentItem);
            Q_ASSERT(parentIndex >= 0);
            const auto parentItem = items.at(parentIndex);

            const auto childUid = m_serializer->itemUid(childItem);
            auto relatedUid = m_serializer->relatedUidFromItem(parentItem);
            while (!relatedUid.isEmpty()) {
                if (relatedUid == childUid) {
                    job->emitError(i18n("Could not associate '%1', it is an ancestor of '%2'",
                                        child->title(),
                                        parent->title()));
                    return;
                }

                auto it = std::find_if(items.constBegin(), items.constEnd(),
                                       [relatedUid, this] (const Akonadi::Item &item) {
                    return m_serializer->itemUid(item) == relatedUid;
                });
                if (it == items.end())
                    break;

                relatedUid = m_serializer->relatedUidFromItem(*it);
            }

            const int itemCollectionId = childItem.parentCollection().id();
            const int parentCollectionId = parentItem.parentCollection().id();

            if (itemCollectionId != parentCollectionId) {
                ItemFetchJobInterface *fetchChildrenItemJob = m_storage->fetchItems(childItem.parentCollection(), this);
                job->install(fetchChildrenItemJob->kjob(), [fetchChildrenItemJob, childItem, parentItem, job, this] {
                    if (fetchChildrenItemJob->kjob()->error() != KJob::NoError)
                        return;

                    Item::List childItems = m_serializer->filterDescendantItems(fetchChildrenItemJob->items(), childItem);

                    auto transaction = m_storage->createTransaction();
                    m_storage->updateItem(childItem, transaction);
                    childItems.push_front(childItem);
                    m_storage->moveItems(childItems, parentItem.parentCollection(), transaction);
                    job->addSubjob(transaction);
                    transaction->start();
                });
            } else {
                auto updateJob = m_storage->updateItem(childItem);
                job->addSubjob(updateJob);
                updateJob->start();
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Akonadi::Collection &collection, Domain::DataSource::Ptr &source) {
            m_serializer->updateDataSourceFromCollection(source, collection, SerializerInterface::FullPath);
        }
```

#### AUTO 


```{c}
auto fetch = m_helpers->searchCollections(root, &m_searchTerm, m_contentTypes);
```

#### AUTO 


```{c}
auto result = isDone() ? m_collections : Akonadi::Collection::List();
```

#### AUTO 


```{c}
const auto remoteId = collection.remoteId();
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Akonadi::Item &item) {
        // Tasks without a parent (neither task nor project)
        return m_serializer->isTaskItem(item) && m_serializer->relatedUidFromItem(item).isEmpty();
    }
```

#### AUTO 


```{c}
auto updateJob = m_storage->updateItem(childItem);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QMimeData *mimeData, Qt::DropAction, const Domain::Artifact::Ptr &artifact) {
        auto parentTask = artifact.objectCast<Domain::Task>();
        if (!parentTask)
            return false;

        if (!mimeData->hasFormat("application/x-zanshin-object"))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                        [](const Domain::Artifact::Ptr &droppedArtifact) {
                            return !droppedArtifact.objectCast<Domain::Task>();
                        })) {
            return false;
        }

        foreach(const Domain::Artifact::Ptr &droppedArtifact, droppedArtifacts) {
            auto childTask = droppedArtifact.objectCast<Domain::Task>();
            const auto job = taskRepository()->associate(parentTask, childTask);
            installHandler(job, tr("Cannot move task %1 as a sub-task of %2").arg(childTask->title()).arg(parentTask->title()));
        }

        return true;
    }
```

#### AUTO 


```{c}
auto indexChild4 = rootTaskIndex.child(1,0);
```

#### AUTO 


```{c}
auto queryGenerator = [&](const QColor &color) {
            if (!color.isValid())
                return Domain::QueryResult<QColor>::create(provider);
            else
                return Domain::QueryResult<QColor>::Ptr();
        };
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Domain::Task::Ptr &task, const QVariant &value, int role) {
        if (role != Qt::EditRole && role != Qt::CheckStateRole) {
            return false;
        }

        const auto currentTitle = task->title();
        if (role == Qt::EditRole)
            task->setTitle(value.toString());
        else
            task->setDone(value.toInt() == Qt::Checked);

        const auto job = m_taskRepository->update(task);
        installHandler(job, tr("Cannot modify task %1 in project %2").arg(currentTitle, m_project->name()));
        return true;
    }
```

#### AUTO 


```{c}
auto source = std::find_if(sources.begin(), sources.end(),
                               [this] (const Domain::DataSource::Ptr &source) {
                                   return m_noteRepository->isDefaultSource(source);
                               });
```

#### AUTO 


```{c}
auto noteProvider = Domain::QueryResultProvider<Domain::Note::Ptr>::Ptr::create();
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QModelIndex &index) {
                               return itemAtIndex(index);
                           }
```

#### AUTO 


```{c}
auto collections = job->collections();
```

#### AUTO 


```{c}
auto context = serializer->createContextFromItem(data.item(40));
```

#### AUTO 


```{c}
auto monitor = Testlib::AkonadiFakeMonitor::Ptr::create();
```

#### AUTO 


```{c}
const auto id = dataSource->property("collectionId").value<Collection::Id>();
```

#### AUTO 


```{c}
const auto xmlFile = QString::fromLocal8Bit(ZANSHIN_USER_XMLDATA);
```

#### LAMBDA EXPRESSION 


```{c}
[fetchCollectionJob, item, job, this] {
            if (fetchCollectionJob->kjob()->error() != KJob::NoError)
                return;

            Q_ASSERT(fetchCollectionJob->collections().size() > 0);
            const Akonadi::Collection::List collections = fetchCollectionJob->collections();
            auto it = std::find_if(collections.constBegin(), collections.constEnd(),
                                   [] (const Akonadi::Collection &c) {
                return (c.rights() & Akonadi::Collection::CanCreateItem)
                    && (c.rights() & Akonadi::Collection::CanChangeItem)
                    && (c.rights() & Akonadi::Collection::CanDeleteItem);
            });
            if (it == collections.constEnd()) {
                job->emitError(tr("Could not find a collection to store the note into!"));
            } else {
                auto col = *it;
                Q_ASSERT(col.isValid());
                auto createJob = m_storage->createItem(item, col);
                job->addSubjob(createJob);
                createJob->start();
            }
        }
```

#### AUTO 


```{c}
auto project1 = serializer->createProjectFromItem(data.item(42));
```

#### AUTO 


```{c}
const auto contextList = extractContexts(todo);
```

#### AUTO 


```{c}
auto query = DataSourceQuery::Ptr::create();
```

#### AUTO 


```{c}
auto app = new Presentation::ApplicationModel;
```

#### AUTO 


```{c}
auto task3 = Domain::Task::Ptr::create();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &tag : notifiedTags) {
        QVERIFY(tag.isValid());
        QVERIFY(!tag.name().isEmpty());
        QVERIFY(!tag.type().isEmpty());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const QMimeData *mimeData, Qt::DropAction, const Domain::Task::Ptr &parentTask) {
        if (!mimeData->hasFormat(QStringLiteral("application/x-zanshin-object")))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                        [](const Domain::Artifact::Ptr &droppedArtifact) {
                            return !droppedArtifact.objectCast<Domain::Task>();
                        })) {
            return false;
        }

        using namespace std::placeholders;
        auto associate = std::function<KJob*(Domain::Task::Ptr)>();
        auto dissociate = std::function<KJob*(Domain::Task::Ptr)>();
        auto parentTitle = QString();

        if (parentTask) {
            associate = std::bind(&Domain::TaskRepository::associate, m_taskRepository, parentTask, _1);
            dissociate = [] (Domain::Task::Ptr) -> KJob* { return Q_NULLPTR; };
            parentTitle = parentTask->title();
        } else {
            associate = std::bind(&Domain::ContextRepository::associate, m_contextRepository, m_context, _1);
            dissociate = std::bind(&Domain::TaskRepository::dissociate, m_taskRepository, _1);
            parentTitle = m_context->name();
        }

        foreach(const Domain::Artifact::Ptr &droppedArtifact, droppedArtifacts) {
            auto childTask = droppedArtifact.objectCast<Domain::Task>();
            auto job = associate(childTask);
            installHandler(job, i18n("Cannot move task %1 as sub-task of %2", childTask->title(), parentTitle));
            job = dissociate(childTask);
            if (job)
                installHandler(job, i18n("Cannot dissociate task %1 from its parent", childTask->title()));
        }

        return true;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const ItemType &, int idx) {
            const QModelIndex parentIndex = parent() ? createIndex(row(), 0, this) : QModelIndex();
            const QModelIndex dataIndex = index(idx, 0, parentIndex);
            emitDataChanged(dataIndex, dataIndex);
        }
```

#### AUTO 


```{c}
auto item = serializer.createItemFromNote(note);
```

#### AUTO 


```{c}
auto fetch = helpers->fetchCollections(root);
```

#### AUTO 


```{c}
const auto parentId = findParentId(collection);
```

#### AUTO 


```{c}
auto noteRepository = Domain::NoteRepository::Ptr();
```

#### AUTO 


```{c}
auto item = job->items()[0];
```

#### AUTO 


```{c}
auto tasks = createTasks();
```

#### AUTO 


```{c}
auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
```

#### AUTO 


```{c}
auto drop = [this](const QMimeData *mimeData, Qt::DropAction, const QObjectPtr &object) {
        if (!mimeData->hasFormat(QStringLiteral("application/x-zanshin-object")))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (auto project = object.objectCast<Domain::Project>()) {
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                const auto job = m_projectRepository->associate(project, droppedArtifact);
                installHandler(job, i18n("Cannot add %1 to project %2", droppedArtifact->title(), project->name()));
            }
            return true;
        } else if (auto context = object.objectCast<Domain::Context>()) {
            if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                            [](const Domain::Artifact::Ptr &droppedArtifact) {
                                return !droppedArtifact.objectCast<Domain::Task>();
                            })) {
                return false;
            }
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                auto task = droppedArtifact.staticCast<Domain::Task>();
                const auto job = m_contextRepository->associate(context, task);
                installHandler(job, i18n("Cannot add %1 to context %2", task->title(), context->name()));
            }
            return true;
        } else if (object == m_inboxObject) {
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                const auto job = m_projectRepository->dissociate(droppedArtifact);
                installHandler(job, i18n("Cannot move %1 to Inbox", droppedArtifact->title()));

                if (auto task = droppedArtifact.objectCast<Domain::Task>()) {
                    Utils::JobHandler::install(job, [this, task] {
                        const auto dissociateJob = m_taskRepository->dissociateAll(task);
                        installHandler(dissociateJob, i18n("Cannot move task %1 to Inbox", task->title()));
                    });
                }
            }
            return true;
        } else if (object == m_workdayObject) {
            foreach (const auto &droppedArtifact, droppedArtifacts) {

                if (auto task = droppedArtifact.objectCast<Domain::Task>()) {

                    task->setStartDate(Utils::DateTime::currentDateTime());
                    const auto job = m_taskRepository->update(task);

                    installHandler(job, i18n("Cannot update task %1 to Workday", task->title()));
                }
            }
            return true;
        }

        return false;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[allowedMimeTypes] (const Collection &collection) {
                                                auto mimeTypes = listToSet(collection.contentMimeTypes());
                                                return !mimeTypes.intersects(allowedMimeTypes);
                                             }
```

#### AUTO 


```{c}
const auto childUid = m_serializer->objectUid(m_serializer->createTaskFromItem(childItem));
```

#### AUTO 


```{c}
auto job = storage.createItem(item, calendar2());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto itemId : m_collectionItems.value(collection.id())) {
        m_items.remove(itemId);
    }
```

#### AUTO 


```{c}
const auto col = m_collections.take(collection.id());
```

#### AUTO 


```{c}
const auto oldParentId = findParentId(m_collections[collection.id()]);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto child : m_children->data()) {
            QueryTreeNodeBase *node = new QueryTreeNode<ItemType>(child, this, model, queryGenerator, m_flagsFunction, m_dataFunction, m_setDataFunction);
            appendChild(node);
        }
```

#### AUTO 


```{c}
auto configureAction = new QAction(this);
```

#### AUTO 


```{c}
auto it = std::max_element(m_tags.constBegin(), m_tags.constEnd(),
                               idLessThan<Akonadi::Tag>);
```

#### AUTO 


```{c}
auto drag = [](const Domain::DataSource::List &) -> QMimeData* {
        return 0;
    };
```

#### AUTO 


```{c}
auto queryGenerator = [&] (const QColor &color) {
            if (!color.isValid())
                return Domain::QueryResult<QColor>::create(provider);
            else
                return Domain::QueryResult<QColor>::Ptr();
        };
```

#### AUTO 


```{c}
auto drop = [this](const QMimeData *mimeData, Qt::DropAction, const Domain::Task::Ptr &parentTask) {
        if (!parentTask)
            return false;

        if (!mimeData->hasFormat("application/x-zanshin-object"))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                        [](const Domain::Artifact::Ptr &droppedArtifact) {
                            return !droppedArtifact.objectCast<Domain::Task>();
                        })) {
            return false;
        }

        foreach(const Domain::Artifact::Ptr &droppedArtifact, droppedArtifacts) {
            auto childTask = droppedArtifact.objectCast<Domain::Task>();
            const auto job = m_taskRepository->associate(parentTask, childTask);
            installHandler(job, tr("Cannot move task %1 as a sub-task of %2").arg(childTask->title()).arg(parentTask->title()));
        }

        return true;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Akonadi::Item &item, const Domain::Task::Ptr &task) {
            return m_serializer->representsItem(task, item);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QColor &) {
            return Qt::NoItemFlags;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const InputType &input) {
            onAdded(input);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Domain::DataSource::Ptr &source) {
                                   return isDefaultSource(source);
                               }
```

#### AUTO 


```{c}
auto theNode = node(index);
```

#### LAMBDA EXPRESSION 


```{c}
[fetchItemJob, compositeJob, this] {
        if (fetchItemJob->kjob()->error() != KJob::NoError)
           return;

        Q_ASSERT(fetchItemJob->items().size() == 1);
        auto item = fetchItemJob->items().at(0);

        ItemFetchJobInterface *fetchCollectionItemsJob = m_storage->fetchItems(item.parentCollection(), this);
        compositeJob->install(fetchCollectionItemsJob->kjob(), [fetchCollectionItemsJob, item, compositeJob, this] {
            if (fetchCollectionItemsJob->kjob()->error() != KJob::NoError)
                return;

            Item::List childItems = m_serializer->filterDescendantItems(fetchCollectionItemsJob->items(), item);
            childItems << item;

            auto removeJob = m_storage->removeItems(childItems);
            compositeJob->addSubjob(removeJob);
            removeJob->start();
        });
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QModelIndex &index, const Domain::Artifact::Ptr &artifact) -> AdditionalInfo {
        if (index.parent().isValid()) // children are in the same collection as their parent, so the same project
            return nullptr;
        if (auto task = artifact.dynamicCast<Domain::Task>()) {
            AdditionalInfo projectQueryResult = m_taskQueries->findProject(task);
            if (projectQueryResult) {
                QPersistentModelIndex persistentIndex(index);
                projectQueryResult->addPostInsertHandler([persistentIndex](const Domain::Project::Ptr &, int) {
                    // When a project was found (inserted into the result), update the rendering of the item
                    auto model = const_cast<QAbstractItemModel *>(persistentIndex.model());
                    model->dataChanged(persistentIndex, persistentIndex);
                });
            }
            return projectQueryResult;
        }
        return nullptr;
    }
```

#### AUTO 


```{c}
auto transaction = storage->createTransaction(nullptr);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Domain::Task::Ptr &, int index) {
                                        beginRemoveRows(QModelIndex(), index, index);
                                    }
```

#### LAMBDA EXPRESSION 


```{c}
[&replaceHandlerCalled](const Domain::Artifact::Ptr &, int) {
                                          replaceHandlerCalled = true;
                                      }
```

#### AUTO 


```{c}
auto result = DataSourceResult::create(provider);
```

#### AUTO 


```{c}
auto result = ProjectResult::create(provider);
```

#### LAMBDA EXPRESSION 


```{c}
[fetchItemJob, compositeJob, this] {
        if (fetchItemJob->kjob()->error() != KJob::NoError)
           return;

        Q_ASSERT(fetchItemJob->items().size() == 1);
        auto item = fetchItemJob->items().first();

        ItemFetchJobInterface *fetchCollectionItemsJob = m_storage->fetchItems(item.parentCollection());
        compositeJob->install(fetchCollectionItemsJob->kjob(), [fetchCollectionItemsJob, item, compositeJob, this] {
            if (fetchCollectionItemsJob->kjob()->error() != KJob::NoError)
                return;

            Item::List childItems = m_serializer->filterDescendantItems(fetchCollectionItemsJob->items(), item);
            childItems << item;

            auto removeJob = m_storage->removeItems(childItems);
            compositeJob->addSubjob(removeJob);
            removeJob->start();
        });
    }
```

#### AUTO 


```{c}
auto buttonBox = dialog.findChild<QDialogButtonBox*>("buttonBox");
```

#### AUTO 


```{c}
auto item = createSourceItem(name, parent);
```

#### AUTO 


```{c}
const auto firstButtonLeft = createButtonRect(option.rect, position - 1).left();
```

#### AUTO 


```{c}
auto ac = window->actionCollection();
```

#### LAMBDA EXPRESSION 


```{c}
[&](const Domain::Task::Ptr &task, const QVariant &value, int role) {
            if (role != Qt::EditRole && role != Qt::CheckStateRole) {
                return false;
            }

            if (role == Qt::EditRole) {
                task->setTitle(value.toString());
            } else {
                task->setDone(value.toInt() == Qt::Checked);
            }

            repositoryMock.getInstance().update(task);
            return true;
        }
```

#### AUTO 


```{c}
const auto attendees = todo->attendees();
```

#### AUTO 


```{c}
auto &query = m_findProject[childItem.id()];
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &col : collections) {
        ids << col.id();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Item &item) {
        m_findChildren.remove(item.id());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, job, add] {
            if (job->kjob()->error() != KJob::NoError)
                return;

            Q_ASSERT(job->items().size() == 1);
            auto item = job->items()[0];
            Q_ASSERT(item.parentCollection().isValid());
            auto job = m_storage->fetchItems(item.parentCollection());
            Utils::JobHandler::install(job->kjob(), [this, job, add] {
                if (job->kjob()->error() != KJob::NoError)
                    return;

                foreach (const auto &item, job->items())
                    add(item);
            });
        }
```

#### AUTO 


```{c}
auto dataFunction = [](const Domain::Task::Ptr &, int) {
            return QVariant();
        };
```

#### AUTO 


```{c}
auto roles = QAbstractItemModel::roleNames();
```

#### AUTO 


```{c}
auto items = m_data->tagItems(findId(tag));
```

#### AUTO 


```{c}
const auto oldAttribute = oldCollection.attribute<Akonadi::ApplicationSelectedAttribute>();
```

#### AUTO 


```{c}
auto drag = [](const Domain::Artifact::List &artifacts) -> QMimeData* {
        if (artifacts.isEmpty())
            return Q_NULLPTR;

        auto data = new QMimeData;
        data->setData(QStringLiteral("application/x-zanshin-object"), "object");
        data->setProperty("objects", QVariant::fromValue(artifacts));
        return data;
    };
```

#### AUTO 


```{c}
const auto none = Akonadi::Collection(GenCollection().withRootAsParent()
                                                             .withId(2)
                                                             .withName("collection"));
```

#### AUTO 


```{c}
const auto item2 = Akonadi::Item(GenTodo().withId(2).withParent(2).withTags({2}).withTitle("item2"));
```

#### AUTO 


```{c}
const auto job = m_taskRepository->remove(task);
```

#### LAMBDA EXPRESSION 


```{c}
[storage, root] (const Domain::LiveQueryInput<Collection>::AddFunction &add) {
        auto job = storage->fetchCollections(root, StorageInterface::Recursive);
        Utils::JobHandler::install(job->kjob(), [root, job, add] {
            if (job->kjob()->error())
                return;

            auto directChildren = QHash<Collection::Id, Collection>();
            foreach (const auto &collection, job->collections()) {
                auto directChild = collection;
                while (directChild.parentCollection() != root)
                    directChild = directChild.parentCollection();
                if (!directChildren.contains(directChild.id()))
                    directChildren[directChild.id()] = directChild;
            }

            foreach (const auto &directChild, directChildren)
                add(directChild);
        });
    }
```

#### AUTO 


```{c}
auto title = QStringLiteral("New note");
```

#### AUTO 


```{c}
auto text = artifact ? artifact->text() : QString();
```

#### AUTO 


```{c}
auto mimeData = std::unique_ptr<QMimeData>(model->mimeData(QModelIndexList() << childTaskIndex));
```

#### AUTO 


```{c}
auto predicate = createSearchPredicate(root);
```

#### AUTO 


```{c}
auto roles = roleNames();
```

#### AUTO 


```{c}
auto data = model.mimeData(QList<QModelIndex>() << model.index(1, 0));
```

#### AUTO 


```{c}
auto dueDateEdit = editor.findChild<KPIM::KDateEdit*>("dueDateEdit");
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QMimeData *mimeData, Qt::DropAction, const Domain::Artifact::Ptr &artifact) {
        auto parentTask = artifact.objectCast<Domain::Task>();
        if (!parentTask)
            return false;

        if (!mimeData->hasFormat("application/x-zanshin-object"))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                        [](const Domain::Artifact::Ptr &droppedArtifact) {
                            return !droppedArtifact.objectCast<Domain::Task>();
                        })) {
            return false;
        }

        foreach(const auto &droppedArtifact, droppedArtifacts) {
            auto childTask = droppedArtifact.objectCast<Domain::Task>();
            const auto job = taskRepository()->associate(parentTask, childTask);
            installHandler(job, tr("Cannot move task %1 as sub-task of %2").arg(childTask->title()).arg(parentTask->title()));
        }

        return true;
    }
```

#### AUTO 


```{c}
auto itemTagged = job->items().first();
```

#### AUTO 


```{c}
auto job = new Akonadi::ItemModifyJob(item);
```

#### LAMBDA EXPRESSION 


```{c}
[fetchItemJob, job, this] {
        if (fetchItemJob->kjob()->error() != KJob::NoError)
            return;

        Q_ASSERT(fetchItemJob->items().size() == 1);
        auto childItem = fetchItemJob->items().at(0);

        m_serializer->removeItemParent(childItem);
        m_serializer->clearItem(&childItem);

        auto updateJob = m_storage->updateItem(childItem, this);
        job->addSubjob(updateJob);
        updateJob->start();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Akonadi::Tag tag : job->tags()) {
            auto context = m_serializer->createContextFromTag(tag);
            if (context) {
                provider->append(context);
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[] (const QList<QColor> &) {
            return nullptr;
        }
```

#### AUTO 


```{c}
auto addProjectAction = available.findChild<QAction*>(QStringLiteral("addProjectAction"));
```

#### AUTO 


```{c}
const auto editTopLeft = m_quickAddEdit->geometry().topLeft();
```

#### AUTO 


```{c}
auto itemC = new QStandardItem(QStringLiteral("C"));
```

#### AUTO 


```{c}
const auto items = Akonadi::Item::List() << Akonadi::Item(GenTodo().withId(1).withTitle("item1"))
                                                  << Akonadi::Item(GenTodo().withId(2).withTitle("item2"));
```

#### AUTO 


```{c}
const auto items = cache->items(Akonadi::Collection(42));
```

#### AUTO 


```{c}
auto job = new AkonadiFakeTransaction;
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Akonadi::Collection &collection) {
        return collection.isValid() && m_serializer->isSelectedCollection(collection);
    }
```

#### AUTO 


```{c}
auto item = serializer.createItemFromProject(project);
```

#### AUTO 


```{c}
auto source = item->data(Presentation::QueryTreeModelBase::ObjectRole).value<Domain::DataSource::Ptr>();
```

#### AUTO 


```{c}
auto model = new Presentation::EditorModel;
```

#### AUTO 


```{c}
auto buttons = new QDialogButtonBox(this);
```

#### AUTO 


```{c}
auto deps = std::make_unique<Utils::DependencyManager>();
```

#### AUTO 


```{c}
auto data = [this](const QObjectPtr &object, int role) -> QVariant {
        if (role != Qt::DisplayRole
         && role != Qt::EditRole
         && role != Qt::DecorationRole
         && role != QueryTreeModelBase::IconNameRole) {
            return QVariant();
        }

        if (role == Qt::EditRole
         && (object == m_inboxObject
          || object == m_tagsObject)) {
            return QVariant();
        }

        if (role == Qt::DisplayRole || role == Qt::EditRole) {
            return object->property("name").toString();
        } else if (role == Qt::DecorationRole || role == QueryTreeModelBase::IconNameRole) {
            const QString iconName = (object == m_inboxObject) ? QStringLiteral("mail-folder-inbox")
                                   : (object == m_tagsObject)  ? QStringLiteral("folder")
                                   : QStringLiteral("view-pim-tasks");

            if (role == Qt::DecorationRole)
                return QVariant::fromValue(QIcon::fromTheme(iconName));
            else
                return iconName;
        } else {
            return QVariant();
        }
    };
```

#### LAMBDA EXPRESSION 


```{c}
[add, job] {
                foreach (const auto &tag, job->tags()) {
                    add(tag);
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[&] (const QString &string) {
            if (string.isEmpty())
                return Domain::QueryResult<QString>::create(topProvider);
            else if (string == "2")
                return Domain::QueryResult<QString>::create(firstLevelProvider);
            else if (string == "2.1")
                return Domain::QueryResult<QString>::create(secondLevelProvider);
            else
                return Domain::QueryResult<QString>::Ptr();
        }
```

#### AUTO 


```{c}
auto jobUpdate = storage->updateItem(item);
```

#### AUTO 


```{c}
const auto job = m_taskRepository->createInTag(task, m_tag);
```

#### LAMBDA EXPRESSION 


```{c}
[] (const Akonadi::Collection &c) {
                                                            return c.rights() == Akonadi::Collection::AllRights;
                                                        }
```

#### AUTO 


```{c}
auto moveItemAction = new QAction(this);
```

#### LAMBDA EXPRESSION 


```{c}
[](const Domain::DataSource::List &) -> QMimeData* {
        return 0;
    }
```

#### AUTO 


```{c}
auto topLevelProvider = Domain::QueryResultProvider<Domain::DataSource::Ptr>::Ptr::create();
```

#### AUTO 


```{c}
auto output = m_convert(input);
```

#### AUTO 


```{c}
auto dataSource = Domain::DataSource::Ptr::create();
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const DataSourceQuery::AddFunction &add) {
            CollectionFetchJobInterface *job = m_storage->fetchCollections(Akonadi::Collection::root(), StorageInterface::Recursive, StorageInterface::Notes);
            Utils::JobHandler::install(job->kjob(), [this, job, add] {
                for (auto collection : job->collections())
                    add(collection);
            });
        }
```

#### AUTO 


```{c}
const auto role = usedRoles.at(i);
```

#### LAMBDA EXPRESSION 


```{c}
[&] (const QMimeData *data, Qt::DropAction, const QColor &color) {
            dropCalled = true;
            droppedData = data;
            colorSeen = color;
            return false;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](const Domain::Artifact::Ptr &artifact) {
        const Qt::ItemFlags defaultFlags = Qt::ItemIsSelectable
                                         | Qt::ItemIsEnabled
                                         | Qt::ItemIsEditable
                                         | Qt::ItemIsDragEnabled;

        return artifact.dynamicCast<Domain::Task>() ? (defaultFlags | Qt::ItemIsUserCheckable | Qt::ItemIsDropEnabled) : defaultFlags;
    }
```

#### AUTO 


```{c}
auto job = storage->fetchCollections(Akonadi::Collection::root(),
                                         Akonadi::Storage::Recursive,
                                         Akonadi::Storage::Tasks|Akonadi::Storage::Notes);
```

#### AUTO 


```{c}
auto job = storage.fetchTagItems(tag);
```

#### AUTO 


```{c}
auto pagesView = availablePagesView->findChild<QTreeView*>("pagesView");
```

#### AUTO 


```{c}
const auto expectedText = text.endsWith('\n') ? (text.chop(1), text) : text;
```

#### AUTO 


```{c}
auto filterWidget = page.findChild<Widgets::FilterWidget*>("filterWidget");
```

#### AUTO 


```{c}
auto object = Akonadi::Serializer::QObjectPtr::create();
```

#### AUTO 


```{c}
auto task = artifact.objectCast<Domain::Task>();
```

#### LAMBDA EXPRESSION 


```{c}
[] (Utils::DependencyManager *) {
                return new Presentation::RunningTaskModel(Domain::TaskQueries::Ptr(),
                                                         Domain::TaskRepository::Ptr());
        }
```

#### AUTO 


```{c}
const auto childUid = m_serializer->itemUid(childItem);
```

#### LAMBDA EXPRESSION 


```{c}
[] (const QString &, int, int) {
            return QVariant();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[fetchParentItemJob, child, job, this] {
        if (fetchParentItemJob->kjob()->error() != KJob::NoError)
            return;

        Q_ASSERT(fetchParentItemJob->items().size() == 1);
        auto parentItem = fetchParentItemJob->items().first();

        Q_ASSERT(m_serializer->isTaskChild(child, parentItem));

        auto childItem = m_serializer->createItemFromTask(child);
        ItemFetchJobInterface *fetchItemJob = m_storage->fetchItem(childItem);
        job->install(fetchItemJob->kjob(), [fetchItemJob, job, this] {
            if (fetchItemJob->kjob()->error() != KJob::NoError)
                return;

            Q_ASSERT(fetchItemJob->items().size() == 1);
            auto childItem = fetchItemJob->items().first();

            m_serializer->removeItemParent(childItem);

            auto updateJob = m_storage->updateItem(childItem);
            job->addSubjob(updateJob);
            updateJob->start();
        });
    }
```

#### AUTO 


```{c}
auto delegateEdit = editor.findChild<KLineEdit*>(QStringLiteral("delegateEdit"));
```

#### AUTO 


```{c}
auto searchCollection = Akonadi::Collection(1);
```

#### AUTO 


```{c}
auto model = new Presentation::ArtifactEditorModel;
```

#### AUTO 


```{c}
auto tagFetchScope = m_monitor->tagFetchScope();
```

#### AUTO 


```{c}
auto setData = [this](const Domain::Task::Ptr &task, const QVariant &value, int role) {
        if (role != Qt::EditRole && role != Qt::CheckStateRole) {
            return false;
        }

        const auto currentTitle = task->title();
        if (role == Qt::EditRole)
            task->setTitle(value.toString());
        else
            task->setDone(value.toInt() == Qt::Checked);

        const auto job = m_taskRepository->update(task);
        installHandler(job, i18n("Cannot modify task %1 in project %2", currentTitle, m_project->name()));
        return true;
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (auto collection : job->collections()) {
            ItemFetchJobInterface *job = m_storage->fetchItems(collection);
            Utils::JobHandler::install(job->kjob(), [provider, job, this] {
                if (job->kjob()->error() != KJob::NoError)
                    return;

                for (auto item : job->items()) {
                    if (!isInboxItem(item))
                        continue;

                    auto artifact = deserializeArtifact(item);
                    if (artifact)
                        provider->append(artifact);
                }
            });
        }
```

#### AUTO 


```{c}
const auto index = m_sourceListModel->index(row, 0, root);
```

#### AUTO 


```{c}
const auto contextListInfo = index.data(Presentation::QueryTreeModelBase::ContextListRole);
```

#### AUTO 


```{c}
auto predicate = [] (const Akonadi::Item &item) {
            return titleFromItem(item).endsWith(QLatin1String("-in"));
        };
```

#### AUTO 


```{c}
auto newCollection = collection;
```

#### AUTO 


```{c}
auto object = new QObject(this);
```

#### LAMBDA EXPRESSION 


```{c}
[serializer, storage] (const Domain::LiveQueryInput<Item>::AddFunction &add) {
        auto job = storage->fetchCollections(Akonadi::Collection::root(),
                                             StorageInterface::Recursive);
        Utils::JobHandler::install(job->kjob(), [serializer, storage, job, add] {
            if (job->kjob()->error() != KJob::NoError)
                return;

            foreach (const auto &collection, job->collections()) {
                if (!serializer->isSelectedCollection(collection))
                    continue;

                auto job = storage->fetchItems(collection);
                Utils::JobHandler::install(job->kjob(), [job, add] {
                    if (job->kjob()->error() != KJob::NoError)
                        return;

                    foreach (const auto &item, job->items())
                        add(item);
                });
            }
        });
    }
```

#### AUTO 


```{c}
auto query = [this] (const Domain::Note::Ptr &note) -> Domain::QueryResultInterface<Domain::Note::Ptr>::Ptr {
        if (!note)
            return m_tagQueries->findNotes(m_tag);
        else
            return Domain::QueryResult<Domain::Note::Ptr>::Ptr();
    };
```

#### AUTO 


```{c}
auto fetch = m_helpers->fetchTaskAndAncestors(task);
```

#### AUTO 


```{c}
auto exPredicate = [] (const Akonadi::Item &contextItem) {
            auto todo = contextItem.payload<KCalCore::Todo::Ptr>();
            return todo->summary().endsWith(QLatin1String("-ex"));
        };
```

#### AUTO 


```{c}
const auto noteMimeTypes = QStringList() << QStringLiteral("text/x-vnd.akonadi.note");
```

#### AUTO 


```{c}
const auto defaultFlags = Qt::ItemIsSelectable
                                | Qt::ItemIsEnabled
                                | Qt::ItemIsEditable
                                | Qt::ItemIsDragEnabled;
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Akonadi::Item &item, Domain::Project::Ptr &project) {
            m_serializer->updateProjectFromItem(project, item);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](const Domain::Artifact::Ptr &artifact, int role) -> QVariant {
        if (role != Qt::DisplayRole
         && role != Qt::EditRole
         && role != Qt::CheckStateRole) {
            return QVariant();
        }

        if (role == Qt::DisplayRole || role == Qt::EditRole) {
            return artifact->title();
        } else if (auto task = artifact.dynamicCast<Domain::Task>()) {
            return task->isDone() ? Qt::Checked : Qt::Unchecked;
        } else {
            return QVariant();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (Utils::DependencyManager *) -> Akonadi::MessagingInterface* {
                            return Q_NULLPTR;
                         }
```

#### AUTO 


```{c}
const auto currentTitle = note->title();
```

#### LAMBDA EXPRESSION 


```{c}
[] (const Akonadi::Collection &) { return true; }
```

#### AUTO 


```{c}
auto artifacts = Domain::Artifact::List();
```

#### LAMBDA EXPRESSION 


```{c}
[](const Akonadi::Tag &tag) { return tag.type() == s_contextTagType; }
```

#### LAMBDA EXPRESSION 


```{c}
[this, &delegatedTask, &delegate] (const Domain::Task::Ptr &task, const Domain::Task::Delegate &d) {
            delegatedTask = task;
            delegate = d;
            return new FakeJob(this);
        }
```

#### AUTO 


```{c}
auto dragFunction = [] (const QStringList &strings) -> QMimeData* {
            auto data = new QMimeData;
            data->setData(QStringLiteral("application/x-zanshin-object"), "object");
            data->setProperty("objects", QVariant::fromValue(strings));
            return data;
        };
```

#### AUTO 


```{c}
auto job = storage->removeCollection(collection);
```

#### LAMBDA EXPRESSION 


```{c}
[] (QWidget *parent) {
        return DialogPtr(new NewPageDialog(parent));
    }
```

#### AUTO 


```{c}
auto resultHandler = std::function<void()>(std::bind(std::mem_fn(&ErrorHandler::displayMessage),
                                               this, job, message));
```

#### LAMBDA EXPRESSION 


```{c}
[=] {
            if (!job->error()) {
                m_data->modifyCollection(collection);
            }
        }
```

#### AUTO 


```{c}
auto job = new Akonadi::TagCreateJob(tag);
```

#### AUTO 


```{c}
auto flags = [](const Domain::Task::Ptr &) {
        return Qt::ItemIsSelectable
             | Qt::ItemIsEnabled
             | Qt::ItemIsEditable
             | Qt::ItemIsDragEnabled
             | Qt::ItemIsUserCheckable
             | Qt::ItemIsDropEnabled;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[&mimeDb] (const KCalCore::Attachment::Ptr &attach) {
                       Domain::Task::Attachment attachment;
                       if (attach->isUri())
                           attachment.setUri(attach->uri());
                       else
                           attachment.setData(attach->decodedData());
                       attachment.setLabel(attach->label());
                       attachment.setMimeType(attach->mimeType());
                       attachment.setIconName(mimeDb.mimeTypeForName(attach->mimeType()).iconName());
                       return attachment;
                   }
```

#### AUTO 


```{c}
auto context1 = serializer->createContextFromTag(data.tag(42));
```

#### AUTO 


```{c}
auto fetch = fetchItemsInAllCollectionsFunction(storage);
```

#### LAMBDA EXPRESSION 


```{c}
[=] () mutable {
            // Force payload detach
            item.setPayloadFromData(item.payloadData());
            m_data->modifyItem(item);
        }
```

#### AUTO 


```{c}
const auto selectedIndexes = m_sourcesView->selectionModel()->selectedIndexes();
```

#### AUTO 


```{c}
auto result = m_migrator.fetchAllItems(WhichItems::TasksToConvert);
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const QMimeData *mimeData, Qt::DropAction, const Domain::Task::Ptr &parentTask) {
        if (!mimeData->hasFormat("application/x-zanshin-object"))
            return false;

        auto droppedTasks = mimeData->property("objects").value<Domain::Task::List>();
        if (droppedTasks.isEmpty())
            return false;

        foreach(const Domain::Task::Ptr &childTask, droppedTasks) {
            taskRepository()->associate(parentTask, childTask);
        }

        return true;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QObjectPtr &object) {
        const Qt::ItemFlags defaultFlags = Qt::ItemIsSelectable
                                         | Qt::ItemIsEnabled
                                         | Qt::ItemIsEditable;
        const Qt::ItemFlags immutableNodeFlags = Qt::ItemIsSelectable
                                               | Qt::ItemIsEnabled;
        const Qt::ItemFlags structureNodeFlags = Qt::NoItemFlags;


        return object.objectCast<Domain::Project>() ? defaultFlags
             : object == m_inboxObject ? immutableNodeFlags
             : structureNodeFlags;
    }
```

#### AUTO 


```{c}
auto drop = [this](const QMimeData *mimeData, Qt::DropAction, const QObjectPtr &object) {
        if (!mimeData->hasFormat("application/x-zanshin-object"))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (auto project = object.objectCast<Domain::Project>()) {
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                const auto job = m_projectRepository->associate(project, droppedArtifact);
                installHandler(job, tr("Cannot add %1 to project %2").arg(droppedArtifact->title()).arg(project->name()));
            }
            return true;
        } else if (auto context = object.objectCast<Domain::Context>()) {
            if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                            [](const Domain::Artifact::Ptr &droppedArtifact) {
                                return !droppedArtifact.objectCast<Domain::Task>();
                            })) {
                return false;
            }
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                auto task = droppedArtifact.staticCast<Domain::Task>();
                const auto job = m_contextRepository->associate(context, task);
                installHandler(job, tr("Cannot add %1 to context %2").arg(task->title()).arg(context->name()));
            }
            return true;
        } else if (object == m_inboxObject) {
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                const auto job = m_projectRepository->dissociate(droppedArtifact);
                installHandler(job, tr("Cannot move %1 to Inbox").arg(droppedArtifact->title()));

                if (auto task = droppedArtifact.objectCast<Domain::Task>()) {
                    Utils::JobHandler::install(job, [this, task] {
                        const auto dissociateJob = m_taskRepository->dissociateAll(task);
                        installHandler(dissociateJob, tr("Cannot move task %1 to Inbox").arg(task->title()));
                    });
                }
            }
            return true;
        } else if (object == m_workdayObject) {
            foreach (const auto &droppedArtifact, droppedArtifacts) {

                if (auto task = droppedArtifact.objectCast<Domain::Task>()) {

                    task->setStartDate(Utils::DateTime::currentDateTime());
                    const auto job = m_taskRepository->update(task);

                    installHandler(job, tr("Cannot update task %1 to Workday").arg(task->title()));
                }
            }
            return true;
        }

        return false;
    };
```

#### AUTO 


```{c}
auto childTask = model->data(childTaskIndex, Presentation::QueryTreeModelBase::ObjectRole).value<Domain::Task::Ptr>();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto provider : providers) {
        if (!provider)
            continue;

        for (int i = 0; i < provider->data().size(); i++) {
            auto dataSource = provider->data().at(i);
            if (isDataSourceCollection(dataSource, collection)) {
                provider->removeAt(i);
                i--;
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](QModelIndex index) {
        if (const QAbstractProxyModel *proxy = qobject_cast<const QAbstractProxyModel *>(index.model())) {
            index = proxy->mapToSource(index);
        }
        return index.model()->rowCount(index) > 0;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QObjectPtr &object) {
        const Qt::ItemFlags defaultFlags = Qt::ItemIsSelectable
                                         | Qt::ItemIsEnabled
                                         | Qt::ItemIsEditable
                                         | Qt::ItemIsDropEnabled;
        const Qt::ItemFlags immutableNodeFlags = Qt::ItemIsSelectable
                                               | Qt::ItemIsEnabled;
        const Qt::ItemFlags structureNodeFlags = Qt::NoItemFlags;


        return object.objectCast<Domain::Project>() ? defaultFlags
             : object == m_inboxObject ? immutableNodeFlags
             : structureNodeFlags;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[] (const Domain::DataSource::Ptr &source, const QVariant &value, int role) {
        Q_UNUSED(source)
        Q_UNUSED(value)
        Q_UNUSED(role)
        return false;
    }
```

#### AUTO 


```{c}
auto dueDateEdit = editor.findChild<KPIM::KDateEdit*>(QStringLiteral("dueDateEdit"));
```

#### AUTO 


```{c}
auto data = [this](const QObjectPtr &object, int role, int) -> QVariant {
        if (role != Qt::DisplayRole
         && role != Qt::EditRole
         && role != Qt::DecorationRole
         && role != QueryTreeModelBase::IconNameRole) {
            return QVariant();
        }

        if (role == Qt::EditRole
         && (object == m_inboxObject
          || object == m_workdayObject
          || object == m_projectsObject
          || object == m_contextsObject
          || object == m_allTasksObject
          || object.objectCast<Domain::DataSource>())) {
            return QVariant();
        }

        if (role == Qt::DisplayRole || role == Qt::EditRole) {
            return object->property("name").toString();
        } else if (role == Qt::DecorationRole || role == QueryTreeModelBase::IconNameRole) {
            const QString iconName = object == m_inboxObject ? QStringLiteral("mail-folder-inbox")
                                   : (object == m_workdayObject)  ? QStringLiteral("go-jump-today")
                                   : (object == m_projectsObject) ? QStringLiteral("folder")
                                   : (object == m_contextsObject) ? QStringLiteral("folder")
                                   : (object == m_allTasksObject)  ? QStringLiteral("view-pim-tasks")
                                   : object.objectCast<Domain::DataSource>() ? QStringLiteral("folder")
                                   : object.objectCast<Domain::Context>() ? QStringLiteral("view-pim-notes")
                                   : QStringLiteral("view-pim-tasks");

            if (role == Qt::DecorationRole)
                return QVariant::fromValue(QIcon::fromTheme(iconName));
            else
                return iconName;
        } else {
            return QVariant();
        }
    };
```

#### AUTO 


```{c}
auto itemTagged = job->items().at(0);
```

#### AUTO 


```{c}
auto drop = [this](const QMimeData *mimeData, Qt::DropAction, const Domain::Task::Ptr &task) {
        auto parentTask = task.objectCast<Domain::Task>();

        if (!mimeData->hasFormat(QStringLiteral("application/x-zanshin-object")))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                        [](const Domain::Artifact::Ptr &droppedArtifact) {
                            return !droppedArtifact.objectCast<Domain::Task>();
                        })) {
            return false;
        }

        foreach(const auto &droppedArtifact, droppedArtifacts) {
            auto childTask = droppedArtifact.objectCast<Domain::Task>();

            if (parentTask) {
                const auto job = m_taskRepository->associate(parentTask, childTask);
                installHandler(job, i18n("Cannot move task %1 as sub-task of %2", childTask->title(), parentTask->title()));
            } else {
                const auto job = m_taskRepository->dissociate(childTask);
                installHandler(job, i18n("Cannot deparent task %1 from its parent", childTask->title()));
            }
        }

        return true;
    };
```

#### AUTO 


```{c}
auto clone = std::unique_ptr<Akonadi::ApplicationSelectedAttribute>(attr.clone());
```

#### AUTO 


```{c}
auto artifact = m_model->property("artifact").value<Domain::Artifact::Ptr>();
```

#### LAMBDA EXPRESSION 


```{c}
[this, childItem] (const Akonadi::Item &item) {
        return m_serializer->isProjectItem(item);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=] () mutable {
            if (!job->error()) {
                std::transform(items.constBegin(), items.constEnd(),
                               items.begin(),
                               [=] (const Akonadi::Item &item) {
                    auto result = item;
                    result.setParentCollection(collection);
                    // Force payload detach
                    result.setPayloadFromData(result.payloadData());
                    return result;
                });

                foreach (const Akonadi::Item &item, items) {
                    m_data->modifyItem(item);
                }
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QMimeData *mimeData, Qt::DropAction, const Domain::Task::Ptr &parentTask) {
        if (!mimeData->hasFormat(QStringLiteral("application/x-zanshin-object")))
            return false;

        auto droppedTasks = mimeData->property("objects").value<Domain::Task::List>();
        if (droppedTasks.isEmpty())
            return false;

        foreach(const auto &childTask, droppedTasks) {
            if (parentTask) {
                const auto job = m_taskRepository->associate(parentTask, childTask);
                installHandler(job, i18n("Cannot move task %1 as sub-task of %2", childTask->title(), parentTask->title()));
            } else {
                const auto job = m_taskRepository->dissociate(childTask);
                installHandler(job, i18n("Cannot deparent task %1 from its parent", childTask->title()));
            }
        }

        return true;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, model, queryGenerator](const ItemType &item, int index) {
            QueryTreeNodeBase *node = new QueryTreeNode<ItemType>(item, this,
                                                                  model, queryGenerator,
                                                                  m_flagsFunction,
                                                                  m_dataFunction, m_setDataFunction,
                                                                  m_dropFunction, m_dragFunction);
            insertChild(index, node);
            endInsertRows();
        }
```

#### AUTO 


```{c}
auto result = queries->findTopLevelArtifacts(project);
```

#### AUTO 


```{c}
auto setData = [this] (const Domain::Task::Ptr &task, const QVariant &value, int role) {
        if (role != Qt::EditRole && role != Qt::CheckStateRole)
            return false;

        const auto currentTitle = task->title();
        if (role == Qt::EditRole)
            task->setTitle(value.toString());
        else
            task->setDone(value.toInt() == Qt::Checked);

        const auto job = taskRepository()->update(task);
        if (!errorHandler())
            return true;

        errorHandler()->installHandler(job, tr("Cannot modify task %1 in context %2").arg(currentTitle).arg(m_context->name()));
        return true;
    };
```

#### AUTO 


```{c}
auto fetchFunction = fetchItems(StorageInterface::Tasks | StorageInterface::Notes);
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Item &item) {
        return m_serializer->isNoteItem(item)
            && !m_serializer->hasAkonadiTags(item);
    }
```

#### AUTO 


```{c}
const auto ids = m_tagItems.value(tag.id());
```

#### LAMBDA EXPRESSION 


```{c}
[&parent](const QModelIndex &index) { return index == parent; }
```

#### AUTO 


```{c}
auto query = ArtifactQuery::Ptr::create();
```

#### AUTO 


```{c}
auto dataString = data->property("objects").value<QStringList>();
```

#### AUTO 


```{c}
const auto ids = m_childItems.value(parentId);
```

#### AUTO 


```{c}
auto job = m_storage->fetchCollections(root, StorageInterface::Recursive, contentTypes);
```

#### AUTO 


```{c}
auto note = serializer.createNoteFromItem(item);
```

#### AUTO 


```{c}
auto notifiedItem = spyItemChanged.takeFirst().at(0).value<Akonadi::Item>();
```

#### AUTO 


```{c}
const auto tagbis = Akonadi::Tag(GenTag().withId(1).asPlain().withName("tagbis"));
```

#### AUTO 


```{c}
auto job = storage->fetchTagItems(tag);
```

#### AUTO 


```{c}
auto projectResult = Domain::QueryResult<Domain::Project::Ptr>::create(projectProvider);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QObjectPtr &object, int role) -> QVariant {
        if (role != Qt::DisplayRole
         && role != Qt::EditRole
         && role != Qt::DecorationRole
         && role != QueryTreeModelBase::IconNameRole) {
            return QVariant();
        }

        if (role == Qt::EditRole
         && (object == m_inboxObject || object == m_projectsObject)) {
            return QVariant();
        }

        if (role == Qt::DisplayRole || role == Qt::EditRole) {
            return object->property("name").toString();
        } else if (role == Qt::DecorationRole || role == QueryTreeModelBase::IconNameRole) {
            const QString iconName = object == m_inboxObject ? "mail-folder-inbox"
                                   : object == m_projectsObject ? "folder"
                                   : "view-pim-tasks";

            if (role == Qt::DecorationRole)
                return QVariant::fromValue(QIcon::fromTheme(iconName));
            else
                return iconName;
        } else {
            return QVariant();
        }
    }
```

#### AUTO 


```{c}
auto drop = [this](const QMimeData *mimeData, Qt::DropAction, const Domain::Artifact::Ptr &artifact) {
        auto parentTask = artifact.objectCast<Domain::Task>();
        if (!parentTask)
            return false;

        if (!mimeData->hasFormat("application/x-zanshin-object"))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                        [](const Domain::Artifact::Ptr &droppedArtifact) {
                            return !droppedArtifact.objectCast<Domain::Task>();
                        })) {
            return false;
        }

        foreach(const Domain::Artifact::Ptr &droppedArtifact, droppedArtifacts) {
            auto childTask = droppedArtifact.objectCast<Domain::Task>();
            const auto job = taskRepository()->associate(parentTask, childTask);
            if (!errorHandler())
                continue;

            errorHandler()->installHandler(job, tr("Cannot move task %1 as a sub-task of %2").arg(childTask->title()).arg(parentTask->title()));
        }

        return true;
    };
```

#### AUTO 


```{c}
const auto delegate = std::find_if(attendees.begin(), attendees.end(),
                                           [] (const KCalCore::Attendee::Ptr &attendee) {
                                               return attendee->status() == KCalCore::Attendee::Accepted;
                                           });
```

#### AUTO 


```{c}
auto dataSource3 = serializer.createDataSourceFromCollection(collection, Akonadi::SerializerInterface::FullPath);
```

#### AUTO 


```{c}
auto pageType = Widgets::NewPageDialogInterface::Project;
```

#### AUTO 


```{c}
auto data = [] (const Domain::Task::Ptr &task, int role) -> QVariant {
        if (role != Qt::DisplayRole
         && role != Qt::EditRole
         && role != Qt::CheckStateRole) {
            return QVariant();
        }

        if (role == Qt::DisplayRole || role == Qt::EditRole) {
            return task->title();
        } else if (role == Qt::CheckStateRole){
            return task->isDone() ? Qt::Checked : Qt::Unchecked;
        } else {
            return QVariant();
        }
    };
```

#### AUTO 


```{c}
const auto selection = m_centralView->selectionModel()->selectedIndexes();
```

#### AUTO 


```{c}
auto setData = [this](const Domain::Artifact::Ptr &artifact, const QVariant &value, int role) {
        if (role != Qt::EditRole && role != Qt::CheckStateRole) {
            return false;
        }

        if (auto task = artifact.dynamicCast<Domain::Task>()) {
            const auto currentTitle = task->title();
            if (role == Qt::EditRole)
                task->setTitle(value.toString());
            else
                task->setDone(value.toInt() == Qt::Checked);

            const auto job = taskRepository()->update(task);
            if (!errorHandler())
                return true;

            errorHandler()->installHandler(job, tr("Cannot modify task %1 in project %2").arg(currentTitle).arg(m_project->name()));
            return true;

        } else if (auto note = artifact.dynamicCast<Domain::Note>()) {
            if (role != Qt::EditRole)
                return false;

            const auto currentTitle = note->title();
            note->setTitle(value.toString());
            const auto job = noteRepository()->save(note);
            if (!errorHandler())
                return true;

            errorHandler()->installHandler(job, tr("Cannot modify note %1 in project %2").arg(currentTitle).arg(m_project->name()));
            return true;

        }

        return false;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[](const Domain::Task::Ptr &, int, int) {
            return QVariant();
        }
```

#### AUTO 


```{c}
auto source = inbox.defaultTaskDataSource();
```

#### AUTO 


```{c}
const auto labelText = delegateText.isEmpty() ? QString()
                         : tr("Delegated to: <b>%1</b>").arg(delegateText);
```

#### LAMBDA EXPRESSION 


```{c}
[] (Utils::DependencyManager *deps) {
        auto model = new Presentation::ArtifactEditorModel;
        auto repository = deps->create<Domain::NoteRepository>();
        model->setSaveFunction([repository] (const Domain::Artifact::Ptr &artifact) {
            auto note = artifact.objectCast<Domain::Note>();
            Q_ASSERT(note);
            return repository->update(note);
        });
        return model;
    }
```

#### AUTO 


```{c}
auto provider = QueryResultProvider<Derived::Ptr>::Ptr::create();
```

#### LAMBDA EXPRESSION 


```{c}
[] (const Akonadi::Collection &collection) {
            return collection.name().endsWith("-ex");
        }
```

#### AUTO 


```{c}
auto todo = taskItem.payload<KCalCore::Todo::Ptr>();
```

#### AUTO 


```{c}
auto akqueries = new Akonadi::TaskQueries(Akonadi::StorageInterface::Ptr(data.createStorage()),
                                                      Akonadi::Serializer::Ptr(new Akonadi::Serializer),
                                                      Akonadi::MonitorInterface::Ptr(data.createMonitor()));
```

#### LAMBDA EXPRESSION 


```{c}
[this](const ItemType &, int index) {
            removeChildAt(index);
            endRemoveRows();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[storage, item] (const Domain::LiveQueryInput<Collection>::AddFunction &add) {
        auto job = storage->fetchCollections(item.parentCollection(), StorageInterface::Base, StorageInterface::AllContent);
        Utils::JobHandler::install(job->kjob(), [storage, job, add] {
            if (job->kjob()->error() != KJob::NoError)
                return;
            auto collection = job->collections().at(0);
            add(collection);
        });
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Item &item) {
        const auto it = m_findContexts.find(item.id());
        if (it == m_findContexts.end())
            return;

        m_findContextsItem[item.id()] = item;
        (*it)->reset();
    }
```

#### AUTO 


```{c}
const auto note = child.objectCast<Domain::Note>();
```

#### AUTO 


```{c}
const auto dueDateText = dueDate.isValid() ? QLocale().toString(dueDate, QLocale::ShortFormat)
                                               : QString();
```

#### AUTO 


```{c}
auto popup = new PassivePopup(m_quickAddEdit);
```

#### AUTO 


```{c}
auto source = serializer->createDataSourceFromCollection(data.collection(id), Akonadi::SerializerInterface::BaseName);
```

#### AUTO 


```{c}
const auto labelText = delegateText.isEmpty() ? QString()
                         : i18n("Delegated to: <b>%1</b>", delegateText);
```

#### AUTO 


```{c}
auto childTask12 = model->data(childTask12Index, Presentation::QueryTreeModelBase::ObjectRole).value<Domain::Task::Ptr>();
```

#### LAMBDA EXPRESSION 


```{c}
[fetchItemJob, child, parent, job, this] {
        if (fetchItemJob->kjob()->error() != KJob::NoError)
           return;

        Q_ASSERT(fetchItemJob->items().size() == 1);
        auto childItem = fetchItemJob->items().at(0);
        m_serializer->updateItemParent(childItem, parent);

        // Check collections to know if we need to move child
        auto partialParentItem = m_serializer->createItemFromTask(parent);
        ItemFetchJobInterface *fetchParentItemJob = m_storage->fetchItems(partialParentItem.parentCollection(), this);
        job->install(fetchParentItemJob->kjob(), [child, parent, fetchParentItemJob, partialParentItem, childItem, job, this] {
            if (fetchParentItemJob->kjob()->error() != KJob::NoError)
                return;

            const auto items = fetchParentItemJob->items();
            const auto parentIndex = items.indexOf(partialParentItem);
            Q_ASSERT(parentIndex >= 0);
            const auto parentItem = items.at(parentIndex);

            const auto childUid = m_serializer->itemUid(childItem);
            auto relatedUid = m_serializer->relatedUidFromItem(parentItem);
            while (!relatedUid.isEmpty()) {
                if (relatedUid == childUid) {
                    job->emitError(i18n("Could not associate '%1', it is an ancestor of '%2'",
                                        child->title(),
                                        parent->title()));
                    return;
                }

                auto it = std::find_if(items.constBegin(), items.constEnd(),
                                       [relatedUid, this] (const Akonadi::Item &item) {
                    return m_serializer->itemUid(item) == relatedUid;
                });
                if (it == items.end())
                    break;

                relatedUid = m_serializer->relatedUidFromItem(*it);
            }

            const int itemCollectionId = childItem.parentCollection().id();
            const int parentCollectionId = parentItem.parentCollection().id();

            if (itemCollectionId != parentCollectionId) {
                ItemFetchJobInterface *fetchChildrenItemJob = m_storage->fetchItems(childItem.parentCollection(), this);
                job->install(fetchChildrenItemJob->kjob(), [fetchChildrenItemJob, childItem, parentItem, job, this] {
                    if (fetchChildrenItemJob->kjob()->error() != KJob::NoError)
                        return;

                    Item::List childItems = m_serializer->filterDescendantItems(fetchChildrenItemJob->items(), childItem);

                    auto transaction = m_storage->createTransaction(this);
                    m_storage->updateItem(childItem, transaction);
                    childItems.push_front(childItem);
                    m_storage->moveItems(childItems, parentItem.parentCollection(), transaction);
                    job->addSubjob(transaction);
                    transaction->start();
                });
            } else {
                auto updateJob = m_storage->updateItem(childItem, this);
                job->addSubjob(updateJob);
                updateJob->start();
            }
        });
    }
```

#### AUTO 


```{c}
auto itemC = new QStandardItem("C");
```

#### AUTO 


```{c}
auto job = storage.fetchTagItems(Akonadi::Tag(43));
```

#### AUTO 


```{c}
auto data = [this](const Domain::Artifact::Ptr &artifact, int role) -> QVariant {
        switch (role) {
            case Qt::DisplayRole:
            case Qt::EditRole:
                return artifact->title();
            case Qt::CheckStateRole:
                if (auto task = artifact.dynamicCast<Domain::Task>()) {
                    return task->isDone() ? Qt::Checked : Qt::Unchecked;
                }
                break;
            case ProjectRole:
            case Qt::ToolTipRole:
                if (auto task = artifact.dynamicCast<Domain::Task>()) {
                    static Domain::QueryResult<Domain::Project::Ptr>::Ptr lastProjectResult;
                    auto projectResult = m_taskQueries->findProject(task);
                    if (projectResult) {
                        // keep a refcount to it, for next time we get here...
                        lastProjectResult = projectResult;
                        if (!projectResult->data().isEmpty()) {
                            Domain::Project::Ptr project = projectResult->data().at(0);
                            return i18n("Project: %1", project->name());
                        }
                    }
                    return i18n("Inbox");
                }
                break;
            default:
                break;
        }
        return QVariant();
    };
```

#### AUTO 


```{c}
auto items = m_data->childItems(findId(collection));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &attachment : task->attachments()) {
        KCalCore::Attachment::Ptr attach(new KCalCore::Attachment(QByteArray()));
        if (attachment.isUri())
            attach->setUri(attachment.uri().toString());
        else
            attach->setDecodedData(attachment.data());
        attach->setMimeType(attachment.mimeType());
        attach->setLabel(attachment.label());
        todo->addAttachment(attach);
    }
```

#### AUTO 


```{c}
auto index = m_indices.at(row);
```

#### AUTO 


```{c}
const auto input = m_delegateEdit->text();
```

#### AUTO 


```{c}
const auto task = currentTask();
```

#### AUTO 


```{c}
const auto parentIndex = items.indexOf(partialParentItem);
```

#### AUTO 


```{c}
auto tagJob = new Akonadi::TagFetchJob;
```

#### AUTO 


```{c}
auto drag = [](const Domain::Note::List &notes) -> QMimeData* {
        if (notes.isEmpty())
            return Q_NULLPTR;

        auto artifacts = Domain::Artifact::List();
        artifacts.reserve(notes.size());
        std::copy(notes.constBegin(), notes.constEnd(),
                  std::back_inserter(artifacts));

        auto data = new QMimeData;
        data->setData("application/x-zanshin-object", "object");
        data->setProperty("objects", QVariant::fromValue(artifacts));
        return data;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[] (Domain::Task::Ptr) -> KJob* { return nullptr; }
```

#### AUTO 


```{c}
auto setData = [this] (const Domain::Artifact::Ptr &artifact, const QVariant &value, int role) {
        if (role != Qt::EditRole && role != Qt::CheckStateRole) {
            return false;
        }

        if (auto task = artifact.dynamicCast<Domain::Task>()) {
            const auto currentTitle = task->title();
            if (role == Qt::EditRole)
                task->setTitle(value.toString());
            else
                task->setDone(value.toInt() == Qt::Checked);

            const auto job = m_taskRepository->update(task);
            installHandler(job, tr("Cannot modify task %1 in tag %2").arg(currentTitle).arg(m_tag->name()));
            return true;

        } else if (auto note = artifact.dynamicCast<Domain::Note>()) {
            if (role != Qt::EditRole)
                return false;

            const auto currentTitle = note->title();
            note->setTitle(value.toString());
            const auto job = m_noteRepository->update(note);
            installHandler(job, tr("Cannot modify note %1 in tag %2").arg(currentTitle).arg(m_tag->name()));
            return true;

        }

        return false;
    };
```

#### AUTO 


```{c}
const auto job = parentTask ? m_taskRepository->createChild(task, parentTask)
                   : m_taskRepository->create(task);
```

#### AUTO 


```{c}
auto attachmentList = editor.findChild<QListView*>(QStringLiteral("attachmentList"));
```

#### AUTO 


```{c}
auto predicate = [] (const Akonadi::Item &item) {
            return titleFromItem(item).endsWith("-in");
        };
```

#### LAMBDA EXPRESSION 


```{c}
[this, &afterReset, add] {
                add(createObject(0, QStringLiteral("ProjectA")));
                add(createObject(1, QStringLiteral("ItemA")));
                add(createObject(2, QStringLiteral("ParentA")));
                add(createObject(3, QStringLiteral("ProjectB")));
                add(createObject(4, QStringLiteral("ItemB")));
                add(createObject(5, QStringLiteral("ParentB")));

                if (afterReset) {
                    add(createObject(6, QStringLiteral("ProjectC")));
                    add(createObject(7, QStringLiteral("ItemC")));
                    add(createObject(8, QStringLiteral("ParentC")));
                }
            }
```

#### AUTO 


```{c}
auto taskList = queries->findAll();
```

#### LAMBDA EXPRESSION 


```{c}
[](const Domain::Artifact::Ptr &artifact, int role, const AdditionalInfo &projectQueryResult) -> QVariant {
        switch (role) {
            case Qt::DisplayRole:
            case Qt::EditRole:
                return artifact->title();
            case Qt::CheckStateRole:
                if (auto task = artifact.dynamicCast<Domain::Task>()) {
                    return task->isDone() ? Qt::Checked : Qt::Unchecked;
                }
                break;
            case Presentation::QueryTreeModelBase::AdditionalInfoRole:
                if (projectQueryResult && !projectQueryResult->data().isEmpty()) {
                    Domain::Project::Ptr project = projectQueryResult->data().at(0);
                    return i18n("Project: %1", project->name());
                }
                return i18n("Inbox"); // TODO add source name
            default:
                break;
        }
        return QVariant();
    }
```

#### AUTO 


```{c}
const auto childTask2 = model->data(model->index(1, 0, topLevelIndex), Presentation::QueryTreeModelBase::ObjectRole).value<Domain::Task::Ptr>();
```

#### AUTO 


```{c}
auto it = availableGlobalActions.cbegin();
```

#### AUTO 


```{c}
auto project1Result = Domain::QueryResult<Domain::Project::Ptr>::create(project1Provider);
```

#### AUTO 


```{c}
auto query = Domain::LiveRelationshipQuery<QString, QObject*>();
```

#### AUTO 


```{c}
const auto item = *it;
```

#### AUTO 


```{c}
auto attachment = todo->attachments().at(i);
```

#### AUTO 


```{c}
auto &query = m_findTopLevel[akonadiTag.id()];
```

#### AUTO 


```{c}
const auto item3 = Akonadi::Item(GenTodo().withId(3).withParent(1).withContexts({"ctx-1"}).withTitle("item3"));
```

#### AUTO 


```{c}
const auto mime = col.contentMimeTypes();
```

#### AUTO 


```{c}
auto data = [] (const Domain::Task::Ptr &task, int role, const AdditionalInfo &projectQueryResult) -> QVariant {
        switch (role) {
            case Qt::DisplayRole:
            case Qt::EditRole:
                return task->title();
            case Qt::CheckStateRole:
                return task->isDone() ? Qt::Checked : Qt::Unchecked;
            case Presentation::QueryTreeModelBase::AdditionalInfoRole:
                if (projectQueryResult && !projectQueryResult->data().isEmpty()) {
                    Domain::Project::Ptr project = projectQueryResult->data().at(0);
                    return i18n("Project: %1", project->name());
                 }
                return i18n("Inbox");
            default:
                break;
        }
        return QVariant();
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QMimeData *mimeData, Qt::DropAction, const Domain::Artifact::Ptr &artifact) {
        auto parentTask = artifact.objectCast<Domain::Task>();

        if (!mimeData->hasFormat("application/x-zanshin-object"))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                        [](const Domain::Artifact::Ptr &droppedArtifact) {
                            return !droppedArtifact.objectCast<Domain::Task>();
                        })) {
            return false;
        }

        foreach(const auto &droppedArtifact, droppedArtifacts) {
            auto childTask = droppedArtifact.objectCast<Domain::Task>();

            if (parentTask) {
                if (parentTask == childTask)
                    return false;

                const auto job = taskRepository()->associate(parentTask, childTask);
                installHandler(job, tr("Cannot move task %1 as sub-task of %2").arg(childTask->title()).arg(parentTask->title()));
            } else {
                const auto job = taskRepository()->dissociate(childTask);
                installHandler(job, tr("Cannot deparent task %1 from its parent").arg(childTask->title()));
            }
        }

        return true;
    }
```

#### AUTO 


```{c}
auto setDataFunction = [] (const QColor &, const QVariant &, int) {
            return false;
        };
```

#### AUTO 


```{c}
auto parentItem = fetchParentItemJob->items().at(0);
```

#### AUTO 


```{c}
auto fetch = helpers->fetchItemsForContext(context);
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Akonadi::Item &item) {
            return m_serializer->createTaskFromItem(item);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[provider, job, this] {
        for (auto collection : job->collections()) {
            auto dataSource = deserializeDataSource(collection);
            if (dataSource)
                provider->append(dataSource);
        }
    }
```

#### AUTO 


```{c}
auto task = pageModel.addItem(title);
```

#### AUTO 


```{c}
const auto it = m_findContexts.find(item.id());
```

#### AUTO 


```{c}
auto data = [this](const QObjectPtr &object, int role, int) -> QVariant {
        if (role != Qt::DisplayRole
         && role != Qt::EditRole
         && role != Qt::DecorationRole
         && role != QueryTreeModelBase::IconNameRole) {
            return QVariant();
        }

        if (role == Qt::EditRole
         && (object == m_inboxObject
          || object == m_workdayObject
          || object == m_projectsObject
          || object == m_contextsObject
          || object.objectCast<Domain::DataSource>())) {
            return QVariant();
        }

        if (role == Qt::DisplayRole || role == Qt::EditRole) {
            return object->property("name").toString();
        } else if (role == Qt::DecorationRole || role == QueryTreeModelBase::IconNameRole) {
            const QString iconName = object == m_inboxObject ? QStringLiteral("mail-folder-inbox")
                                   : (object == m_workdayObject)  ? QStringLiteral("go-jump-today")
                                   : (object == m_projectsObject) ? QStringLiteral("folder")
                                   : (object == m_contextsObject) ? QStringLiteral("folder")
                                   : object.objectCast<Domain::DataSource>() ? QStringLiteral("folder")
                                   : object.objectCast<Domain::Context>() ? QStringLiteral("view-pim-notes")
                                   : QStringLiteral("view-pim-tasks");

            if (role == Qt::DecorationRole)
                return QVariant::fromValue(QIcon::fromTheme(iconName));
            else
                return iconName;
        } else {
            return QVariant();
        }
    };
```

#### AUTO 


```{c}
auto note = page.addItem(title).objectCast<Domain::Note>();
```

#### AUTO 


```{c}
auto collectionScope = m_monitor->collectionFetchScope();
```

#### AUTO 


```{c}
auto associateJob = repository->associate(parent, child);
```

#### AUTO 


```{c}
const auto isDefault = index.data(Presentation::QueryTreeModelBase::IsDefaultRole).toBool();
```

#### AUTO 


```{c}
const auto isCurrent = (m_currentIndex == index);
```

#### LAMBDA EXPRESSION 


```{c}
[fetchItemJob, parent, job, this] {
        if (fetchItemJob->kjob()->error() != KJob::NoError)
            return;

        Q_ASSERT(fetchItemJob->items().size() == 1);
        auto childItem = fetchItemJob->items().at(0);
        auto tag = m_serializer->createAkonadiTagFromTag(parent);
        Q_ASSERT(tag.isValid());
        childItem.clearTag(tag);

        auto updateJob = m_storage->updateItem(childItem);
        job->addSubjob(updateJob);
        updateJob->start();
    }
```

#### AUTO 


```{c}
auto expectedSource = sourceModel->item(0)
                                         ->child(2)
                                         ->data(Presentation::QueryTreeModelBase::ObjectRole)
                                         .value<Domain::DataSource::Ptr>();
```

#### AUTO 


```{c}
auto item
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Domain::LiveRelationshipQuery<QObject*, QString>::AddFunction &add) {
            Utils::JobHandler::install(new FakeJob, [this, add] {
                add(createObject(0, QStringLiteral("ProjectA")));
                add(createObject(1, QStringLiteral("ItemA")));
                add(createObject(2, QStringLiteral("ParentA")));
                add(createObject(3, QStringLiteral("ProjectB")));
                add(createObject(4, QStringLiteral("ItemB")));
                add(createObject(5, QStringLiteral("ParentB")));
                add(createObject(6, QStringLiteral("ProjectC")));
                add(createObject(7, QStringLiteral("ItemC")));
                add(createObject(8, QStringLiteral("ParentC")));
            });
        }
```

#### AUTO 


```{c}
auto tagProvider = Domain::QueryResultProvider<Domain::Tag::Ptr>::Ptr::create();
```

#### AUTO 


```{c}
auto expectedNames = QStringList() << "42Plain" << "43Context" << "44Plain";
```

#### AUTO 


```{c}
auto job2 = new FakeJob(this);
```

#### AUTO 


```{c}
auto data = [] (const Domain::DataSource::Ptr &source, int role) -> QVariant {
        if (role != Qt::DisplayRole
         && role != Qt::EditRole
         && role != Qt::DecorationRole
         && role != QueryTreeModelBase::IconNameRole) {
            return QVariant();
        }

        if (role == Qt::DisplayRole || role == Qt::EditRole) {
            return source->name();
        } else if (role == Qt::DecorationRole || role == QueryTreeModelBase::IconNameRole) {
            const QString iconName = source->iconName().isEmpty() ? "folder" : source->iconName();

            if (role == Qt::DecorationRole)
                return QVariant::fromValue(QIcon::fromTheme(iconName));
            else
                return iconName;
        } else {
            return QVariant();
        }
    };
```

#### AUTO 


```{c}
const auto itemSet = QSet<Akonadi::Item>() << i1 << i2;
```

#### AUTO 


```{c}
auto job = m_storage->fetchItems(m_collection);
```

#### AUTO 


```{c}
auto result = queries->findProject(task);
```

#### LAMBDA EXPRESSION 


```{c}
[&replaceHandlerCalled](const Domain::Project::Ptr &, int) {
                                          replaceHandlerCalled = true;
                                      }
```

#### AUTO 


```{c}
auto addContextAction = available.findChild<QAction*>("addContextAction");
```

#### AUTO 


```{c}
auto query = [this] (const Domain::Artifact::Ptr &artifact) -> Domain::QueryResultInterface<Domain::Artifact::Ptr>::Ptr {
        if (!artifact)
            return m_tagQueries->findTopLevelArtifacts(m_tag);
        else if (auto task = artifact.dynamicCast<Domain::Task>())
            return Domain::QueryResult<Domain::Task::Ptr, Domain::Artifact::Ptr>::copy(m_taskQueries->findChildren(task));
        else
            return Domain::QueryResult<Domain::Artifact::Ptr>::Ptr();
    };
```

#### AUTO 


```{c}
auto opt = QStyleOptionViewItem(option);
```

#### AUTO 


```{c}
auto cache = Akonadi::Cache::Ptr::create(Akonadi::SerializerInterface::Ptr(new Akonadi::Serializer),
                                                 Akonadi::MonitorInterface::Ptr(data.createMonitor()));
```

#### AUTO 


```{c}
auto predicate = [] (const Akonadi::Collection &) { return true; };
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QMimeData *mimeData, Qt::DropAction, const Domain::Artifact::Ptr &artifact) {
        auto parentTask = artifact.objectCast<Domain::Task>();

        if (!mimeData->hasFormat(QStringLiteral("application/x-zanshin-object")))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                        [](const Domain::Artifact::Ptr &droppedArtifact) {
                            return !droppedArtifact.objectCast<Domain::Task>();
                        })) {
            return false;
        }

        foreach(const auto &droppedArtifact, droppedArtifacts) {
            auto childTask = droppedArtifact.objectCast<Domain::Task>();

            if (parentTask) {
                const auto job = m_taskRepository->associate(parentTask, childTask);
                installHandler(job, i18n("Cannot move task %1 as sub-task of %2", childTask->title(), parentTask->title()));
            } else {
                childTask->setStartDate(Utils::DateTime::currentDate());

                auto job = m_taskRepository->dissociate(childTask);
                installHandler(job, i18n("Cannot deparent task %1 from its parent", childTask->title()));
            }
        }

        return true;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Akonadi::Item &item, Domain::Artifact::Ptr &artifact) {
            if (auto task = artifact.dynamicCast<Domain::Task>()) {
                m_serializer->updateTaskFromItem(task, item);
            } else if (auto note = artifact.dynamicCast<Domain::Note>()) {
                m_serializer->updateNoteFromItem(note, item);
            }
        }
```

#### AUTO 


```{c}
auto notes = app.dataSourcesModel();
```

#### AUTO 


```{c}
auto predicate = [this] (const Akonadi::Item &item) {
        return m_serializer->isProjectItem(item);
    };
```

#### AUTO 


```{c}
auto index = m_pagesView->indexAbove(m_pagesView->currentIndex());
```

#### AUTO 


```{c}
auto flags = [] (const Domain::DataSource::Ptr &source) {
        Q_UNUSED(source)
        return Qt::ItemIsSelectable
             | Qt::ItemIsEnabled;
    };
```

#### AUTO 


```{c}
const auto note = Akonadi::NoteUtils::NoteMessageWrapper(message);
```

#### AUTO 


```{c}
auto contentMimeTypes = QSet<QString>();
```

#### AUTO 


```{c}
auto root2 = createSourceItem("Root 2");
```

#### LAMBDA EXPRESSION 


```{c}
[&collections] (const Akonadi::Collection &collection) {
            collections.append(collection);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, contentTypes] (const Domain::LiveQueryInput<Collection>::AddFunction &add) {
        auto job = m_storage->fetchCollections(Collection::root(), StorageInterface::Recursive, contentTypes);
        Utils::JobHandler::install(job->kjob(), [job, add] {
            if (job->kjob()->error())
                return;

            foreach (const auto &collection, job->collections())
                add(collection);
        });
    }
```

#### AUTO 


```{c}
const auto toTagNames = [](const Akonadi::Tag::List &tags) {
            auto res = QStringList();
            res.reserve(tags.size());
            std::transform(tags.cbegin(), tags.cend(),
                           std::back_inserter(res),
                           std::mem_fn(&Akonadi::Tag::name));
            res.sort();
            return res;
        };
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Domain::Artifact::Ptr &artifact) -> Domain::QueryResultInterface<Domain::Artifact::Ptr>::Ptr {
        if (!artifact)
            return m_artifactQueries->findInboxTopLevel();
        else if (auto task = artifact.dynamicCast<Domain::Task>())
            return Domain::QueryResult<Domain::Task::Ptr, Domain::Artifact::Ptr>::copy(taskQueries()->findChildren(task));
        else
            return Domain::QueryResult<Domain::Artifact::Ptr>::Ptr();
    }
```

#### AUTO 


```{c}
auto childItem = m_serializer->createItemFromTask(child);
```

#### AUTO 


```{c}
auto job = new ItemJob(tag);
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Domain::Note::Ptr &note, const QVariant &value, int role) {
        if (role != Qt::EditRole) {
            return false;
        }

        const auto currentTitle = note->title();
        note->setTitle(value.toString());
        const auto job = m_noteRepository->update(note);
        installHandler(job, tr("Cannot modify note %1 in tag %2").arg(currentTitle).arg(m_tag->name()));
        return true;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &tag : item.tags()) {
        const auto it = m_tagItems.find(tag.id());
        if (it != m_tagItems.end()) {
            *it << item.id();
            needsInsert = true;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &tag : tags) {
                QVERIFY(tag.isValid());
                QVERIFY(!tag.name().isEmpty());
                QVERIFY(!tag.type().isEmpty());
            }
```

#### AUTO 


```{c}
const auto &attachment
```

#### AUTO 


```{c}
auto &query = m_findSearchChildren[root.id()];
```

#### AUTO 


```{c}
auto fetch = helpers->fetchCollections(root, nullptr);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QObjectPtr &object) {
        const Qt::ItemFlags defaultFlags = Qt::ItemIsSelectable
                                         | Qt::ItemIsEnabled
                                         | Qt::ItemIsEditable
                                         | Qt::ItemIsDropEnabled;
        const Qt::ItemFlags immutableNodeFlags = Qt::ItemIsSelectable
                                               | Qt::ItemIsEnabled
                                               | Qt::ItemIsDropEnabled;
        const Qt::ItemFlags structureNodeFlags = Qt::NoItemFlags;

        return object.objectCast<Domain::Project>() ? defaultFlags
             : object.objectCast<Domain::Context>() ? defaultFlags
             : object.objectCast<Domain::Tag>() ? defaultFlags
             : object == m_inboxObject ? immutableNodeFlags
             : object == m_workdayObject ? immutableNodeFlags
             : structureNodeFlags;
    }
```

#### AUTO 


```{c}
auto childTask1 = Domain::Task::Ptr::create();
```

#### AUTO 


```{c}
const auto toCollectionNames = [](const Akonadi::Collection::List &collections) {
            auto res = QStringList();
            res.reserve(collections.size());
            std::transform(collections.cbegin(), collections.cend(),
                           std::back_inserter(res),
                           std::mem_fn(&Akonadi::Collection::name));
            res.sort();
            return res;
        };
```

#### AUTO 


```{c}
auto contextPageModel = new ContextPageModel(context,
                                                     m_contextQueries,
                                                     m_contextRepository,
                                                     m_taskRepository,
                                                     this);
```

#### AUTO 


```{c}
auto list = Domain::QueryResultProvider<Domain::Task::Ptr>::createResult(provider);
```

#### AUTO 


```{c}
const auto selectionModel = ui->attachmentList->selectionModel();
```

#### AUTO 


```{c}
auto appModel = Utils::DependencyManager::globalInstance().create<ApplicationModel>();
```

#### AUTO 


```{c}
auto result2 = queries->findChildren(task2);
```

#### LAMBDA EXPRESSION 


```{c}
[] (const Domain::Task::List &tasks) -> QMimeData* {
        if (tasks.isEmpty())
            return 0;

        auto draggedArtifacts = Domain::Artifact::List();
        foreach (const Domain::Task::Ptr &task, tasks) {
            draggedArtifacts.append(task.objectCast<Domain::Artifact>());
        }

        QMimeData *data = new QMimeData();
        data->setData("application/x-zanshin-object", "object");
        data->setProperty("objects", QVariant::fromValue(draggedArtifacts));
        return data;
    }
```

#### AUTO 


```{c}
auto job = storage->moveItem(item, calendar1());
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const QMimeData *mimeData, Qt::DropAction, const Domain::Task::Ptr &parentTask) {
        if (!mimeData->hasFormat("application/x-zanshin-object"))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                        [](const Domain::Artifact::Ptr &droppedArtifact) {
                            return !droppedArtifact.objectCast<Domain::Task>();
                        })) {
            return false;
        }

        foreach(const Domain::Artifact::Ptr &droppedArtifact, droppedArtifacts) {
            auto childTask = droppedArtifact.objectCast<Domain::Task>();
            const auto job = taskRepository()->associate(parentTask, childTask);
            if (!errorHandler())
                continue;

            errorHandler()->installHandler(job, tr("Cannot move task %1 as sub-task of %2").arg(childTask->title()).arg(parentTask->title()));
        }

        return true;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[] (const Domain::DataSource::Ptr &source) { return source->name(); }
```

#### LAMBDA EXPRESSION 


```{c}
[] (const Domain::DataSource::Ptr &source, int role) -> QVariant {
        if (role != Qt::DisplayRole
         && role != Qt::EditRole
         && role != Qt::DecorationRole
         && role != QueryTreeModelBase::IconNameRole) {
            return QVariant();
        }

        if (role == Qt::DisplayRole || role == Qt::EditRole) {
            return source->name();
        } else if (role == Qt::DecorationRole || role == QueryTreeModelBase::IconNameRole) {
            const QString iconName = source->iconName().isEmpty() ? QStringLiteral("folder") : source->iconName();

            if (role == Qt::DecorationRole)
                return QVariant::fromValue(QIcon::fromTheme(iconName));
            else
                return iconName;
        } else {
            return QVariant();
        }
    }
```

#### AUTO 


```{c}
auto collection = m_serializer->createCollectionFromDataSource(source);
```

#### AUTO 


```{c}
auto artifact = serializer.createArtifactFromItem(originalItem);
```

#### LAMBDA EXPRESSION 


```{c}
[=] () mutable {
            if (!job->error()) {
                // Force payload detach
                item.setPayloadFromData(item.payloadData());
                m_data->modifyItem(item);
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Akonadi::Tag &tag) {
            return m_serializer->createContextFromTag(tag);
        }
```

#### AUTO 


```{c}
const auto pos = mapToGlobal(editTopLeft);
```

#### LAMBDA EXPRESSION 


```{c}
[fetchItemJob, parent, job, this] {
        if (fetchItemJob->kjob()->error() != KJob::NoError)
            return;

        Q_ASSERT(fetchItemJob->items().size() == 1);
        auto childItem = fetchItemJob->items().at(0);
        auto tag = m_serializer->createTagFromContext(parent);
        Q_ASSERT(tag.isValid());
        childItem.clearTag(tag);

        auto updateJob = m_storage->updateItem(childItem);
        job->addSubjob(updateJob);
        updateJob->start();
    }
```

#### AUTO 


```{c}
auto drag = [](const Domain::Artifact::List &artifacts) -> QMimeData* {
        if (artifacts.isEmpty())
            return 0;

        QMimeData *data = new QMimeData;
        data->setData("application/x-zanshin-object", "object");
        data->setProperty("objects", QVariant::fromValue(artifacts));
        return data;
    };
```

#### AUTO 


```{c}
const auto &item = items[0];
```

#### AUTO 


```{c}
auto t2 = Akonadi::Tag(43);
```

#### LAMBDA EXPRESSION 


```{c}
[] (const Domain::DataSource::Ptr &source, int role) -> QVariant {
              switch (role) {
              case Qt::DisplayRole:
                  return source->name();
              case Qt::DecorationRole:
                  return QIcon::fromTheme(source->iconName().isEmpty() ? "folder" : source->iconName());
              case IconNameRole:
                  return source->iconName().isEmpty() ? "folder" : source->iconName();
              default:
                  return QVariant();
              }
          }
```

#### AUTO 


```{c}
auto clone = attr.clone();
```

#### AUTO 


```{c}
auto colJob = storage->fetchCollections(Akonadi::Collection::root(),
                                            Akonadi::StorageInterface::Recursive);
```

#### AUTO 


```{c}
auto data = [this] (const Domain::DataSource::Ptr &source, int role, int) -> QVariant {
        if (role != Qt::DisplayRole
         && role != Qt::EditRole
         && role != Qt::DecorationRole
         && role != Qt::CheckStateRole
         && role != QueryTreeModelBase::IconNameRole
         && role != QueryTreeModelBase::IsDefaultRole) {
            return QVariant();
        }

        if (role == Qt::DisplayRole || role == Qt::EditRole) {
            return source->name();
        } else if (role == Qt::DecorationRole || role == QueryTreeModelBase::IconNameRole) {
            const QString iconName = source->iconName().isEmpty() ? QStringLiteral("folder") : source->iconName();

            if (role == Qt::DecorationRole)
                return QVariant::fromValue(QIcon::fromTheme(iconName));
            else
                return iconName;
        } else if (role == Qt::CheckStateRole) {
            if (source->contentTypes() != Domain::DataSource::NoContent)
                return source->isSelected() ? Qt::Checked : Qt::Unchecked;
            else
                return QVariant();
        } else if (role == QueryTreeModelBase::IsDefaultRole) {
            return m_dataSourceQueries->isDefaultSource(source);
        } else {
            return QVariant();
        }
    };
```

#### AUTO 


```{c}
auto query = [this] (const Domain::Task::Ptr &task) -> Domain::QueryResultInterface<Domain::Task::Ptr>::Ptr {
        if (!task)
            return m_contextQueries->findTopLevelTasks(m_context);
        else
            return m_taskQueries->findChildren(task);
    };
```

#### AUTO 


```{c}
auto provider = Domain::QueryResultProvider<Domain::DataSource::Ptr>::Ptr::create();
```

#### LAMBDA EXPRESSION 


```{c}
[](const Domain::Artifact::List &artifacts) -> QMimeData* {
        if (artifacts.isEmpty())
            return Q_NULLPTR;

        auto data = new QMimeData;
        data->setData("application/x-zanshin-object", "object");
        data->setProperty("objects", QVariant::fromValue(artifacts));
        return data;
    }
```

#### AUTO 


```{c}
const auto collection = Akonadi::Collection(GenCollection().withRootAsParent()
                                                                   .withId(1)
                                                                   .withName("collection")
                                                                   .withTaskContent());
```

#### AUTO 


```{c}
auto drag = [] (const Domain::Task::List &tasks) -> QMimeData* {
        if (tasks.isEmpty())
            return nullptr;

        auto data = new QMimeData();
        data->setData(QStringLiteral("application/x-zanshin-object"), "object");
        data->setProperty("objects", QVariant::fromValue(tasks));
        return data;
    };
```

#### AUTO 


```{c}
auto selectedSources = Domain::DataSource::List();
```

#### AUTO 


```{c}
auto flags = [this](const QObjectPtr &object) {
        const Qt::ItemFlags defaultFlags = Qt::ItemIsSelectable
                                         | Qt::ItemIsEnabled
                                         | Qt::ItemIsEditable
                                         | Qt::ItemIsDropEnabled;
        const Qt::ItemFlags immutableNodeFlags = Qt::ItemIsSelectable
                                               | Qt::ItemIsEnabled
                                               | Qt::ItemIsDropEnabled;
        const Qt::ItemFlags structureNodeFlags = Qt::NoItemFlags;

        return object.objectCast<Domain::Project>() ? defaultFlags
             : object == m_inboxObject ? immutableNodeFlags
             : structureNodeFlags;
    };
```

#### AUTO 


```{c}
auto dueDateRect = textRect.adjusted(textRect.width() - dueDateWidth, 0, 0, 0);
```

#### LAMBDA EXPRESSION 


```{c}
[provider, job, task, this] {
        if (job->kjob()->error() != KJob::NoError)
            return;

        Q_ASSERT(job->items().size() == 1);
        auto item = job->items()[0];
        Q_ASSERT(item.parentCollection().isValid());
        ItemFetchJobInterface *job = m_storage->fetchItems(item.parentCollection());
        Utils::JobHandler::install(job->kjob(), [provider, job, task, this] {
            if (job->kjob()->error() != KJob::NoError)
                return;

            for (auto item : job->items()) {
                if (m_serializer->isTaskChild(task, item)) {
                    auto task = deserializeTask(item);
                    if (task)
                        provider->append(task);
                }
            }
        });
    }
```

#### AUTO 


```{c}
auto job = dynamic_cast<ItemFetchJobInterface*>(kjob);
```

#### AUTO 


```{c}
auto &query = m_findContexts[taskItemId];
```

#### AUTO 


```{c}
auto task = inbox.addItem(title);
```

#### AUTO 


```{c}
auto setData = [this](const Domain::Task::Ptr &task, const QVariant &value, int role) {
        if (role != Qt::EditRole && role != Qt::CheckStateRole) {
            return false;
        }

        const auto currentTitle = task->title();
        if (role == Qt::EditRole)
            task->setTitle(value.toString());
        else
            task->setDone(value.toInt() == Qt::Checked);

        const auto job = m_taskRepository->update(task);
        installHandler(job, i18n("Cannot modify task %1", currentTitle));
        return true;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QMimeData *mimeData, Qt::DropAction, const QObjectPtr &object) {
        if (!mimeData->hasFormat("application/x-zanshin-object"))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (auto project = object.objectCast<Domain::Project>()) {
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                m_projectRepository->associate(project, droppedArtifact);
            }
            return true;
        } else if (auto context = object.objectCast<Domain::Context>()) {
            if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                            [](const Domain::Artifact::Ptr &droppedArtifact) {
                                return !droppedArtifact.objectCast<Domain::Task>();
                            })) {
                return false;
            }

            foreach (const auto &droppedArtifact, droppedArtifacts) {
                auto task = droppedArtifact.staticCast<Domain::Task>();
                m_contextRepository->associate(context, task);
            }
            return true;
        } else if (object == m_inboxObject) {
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                auto job = m_projectRepository->dissociate(droppedArtifact);
                if (auto task = droppedArtifact.objectCast<Domain::Task>()) {
                    Utils::JobHandler::install(job, [this, task] {
                        m_taskRepository->dissociate(task);
                    });
                }
            }
            return true;
        }

        return false;
    }
```

#### AUTO 


```{c}
const auto textMargin = style->pixelMetric(QStyle::PM_FocusFrameHMargin, nullptr, widget) + 1;
```

#### AUTO 


```{c}
auto fetch = helpers->fetchItems(collection, nullptr);
```

#### AUTO 


```{c}
auto goNextAction = available.findChild<QAction*>(QStringLiteral("goNextAction"));
```

#### LAMBDA EXPRESSION 


```{c}
[this, tag] (const Akonadi::Item &item) {
            return m_serializer->isTagChild(tag, item);
        }
```

#### AUTO 


```{c}
auto invalidProject = Domain::Project::Ptr::create();
```

#### AUTO 


```{c}
const auto newTags = item.tags();
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Akonadi::Tag &akonadiTag) {
            return akonadiTag.type() == Akonadi::Tag::PLAIN;
        }
```

#### AUTO 


```{c}
const auto childItem = m_serializer->createItemFromTask(child);
```

#### AUTO 


```{c}
auto col = *it;
```

#### AUTO 


```{c}
auto contextProvider = Domain::QueryResultProvider<Domain::Context::Ptr>::Ptr::create();
```

#### AUTO 


```{c}
auto gotMatch = false;
```

#### LAMBDA EXPRESSION 


```{c}
[=] {
            m_data->removeCollection(collection);
        }
```

#### AUTO 


```{c}
const auto behavior = m_data->storageBehavior().fetchTagItemsBehavior(tag.id());
```

#### LAMBDA EXPRESSION 


```{c}
[provider, job, this] {
                if (job->kjob()->error() != KJob::NoError)
                    return;

                for (auto item : job->items()) {
                    auto task = deserializeTask(item);
                    if (task)
                        provider->append(task);
                }
            }
```

#### AUTO 


```{c}
auto result = QueryResult<Derived::Ptr>::create(provider);
```

#### AUTO 


```{c}
auto setData = [this](const Domain::Artifact::Ptr &artifact, const QVariant &value, int role) {
        if (role != Qt::EditRole && role != Qt::CheckStateRole) {
            return false;
        }

        if (auto task = artifact.dynamicCast<Domain::Task>()) {
            const auto currentTitle = task->title();
            if (role == Qt::EditRole)
                task->setTitle(value.toString());
            else
                task->setDone(value.toInt() == Qt::Checked);

            const auto job = taskRepository()->update(task);
            if (!errorHandler())
                return true;

            errorHandler()->installHandler(job, tr("Cannot modify task %1 in Inbox").arg(currentTitle));
            return true;

        } else if (auto note = artifact.dynamicCast<Domain::Note>()) {
            if (role != Qt::EditRole)
                return false;

            const auto currentTitle = note->title();
            note->setTitle(value.toString());
            const auto job = noteRepository()->save(note);
            if (!errorHandler())
                return true;

            errorHandler()->installHandler(job, tr("Cannot modify note %1 in Inbox").arg(currentTitle));
            return true;

        }

        return false;
    };
```

#### AUTO 


```{c}
auto childProvider = Domain::QueryResultProvider<Domain::Task::Ptr>::Ptr::create();
```

#### AUTO 


```{c}
auto transaction = storage.createTransaction();
```

#### AUTO 


```{c}
auto drop = [this] (const QMimeData *mimeData, Qt::DropAction, const Domain::Artifact::Ptr &artifact) {
        auto parentTask = artifact.objectCast<Domain::Task>();
        if (!parentTask)
            return false;

        if (!mimeData->hasFormat("application/x-zanshin-object"))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                        [](const Domain::Artifact::Ptr &droppedArtifact) {
                            return !droppedArtifact.objectCast<Domain::Task>();
                        })) {
            return false;
        }

        foreach(const Domain::Artifact::Ptr &droppedArtifact, droppedArtifacts) {
            auto childTask = droppedArtifact.objectCast<Domain::Task>();
            const auto job = taskRepository()->associate(parentTask, childTask);
            installHandler(job, tr("Cannot move task %1 as sub-task of %2").arg(childTask->title()).arg(parentTask->title()));
        }

        return true;
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &taskName : taskNames) {
        QModelIndex index = Zanshin::findIndex(model(), taskName);
        VERIFY_OR_DO(index.isValid(), Zanshin::dumpIndices(m_dragIndices));
        m_dragIndices << index;
    }
```

#### AUTO 


```{c}
auto note = Domain::Note::Ptr::create();
```

#### AUTO 


```{c}
auto job = m_storage->fetchTagItems(m_tag);
```

#### AUTO 


```{c}
auto job = storage->fetchItems(collection, nullptr);
```

#### AUTO 


```{c}
auto fetch = m_helpers->fetchItemCollection(item, const_cast<TaskQueries*>(this));
```

#### AUTO 


```{c}
auto it = collections.begin();
```

#### AUTO 


```{c}
auto reconstructCollection = std::bind(&AkonadiFakeData::reconstructAncestors,
                                           m_data, _1, Akonadi::Collection::root());
```

#### AUTO 


```{c}
const auto job = m_dataSourceRepository->update(source);
```

#### LAMBDA EXPRESSION 


```{c}
[this, job, add] {
                        if (job->kjob()->error() != KJob::NoError)
                            return;

                        for (auto item : job->items()) {
                            add(item);
                        }
                    }
```

#### AUTO 


```{c}
const auto item2 = data.item(i2.id());
```

#### AUTO 


```{c}
auto data = current.data(Presentation::QueryTreeModelBase::ObjectRole);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Domain::Artifact::Ptr &artifact, const QVariant &value, int role) {
        if (role != Qt::EditRole && role != Qt::CheckStateRole) {
            return false;
        }

        if (auto task = artifact.dynamicCast<Domain::Task>()) {
            const auto currentTitle = task->title();
            if (role == Qt::EditRole)
                task->setTitle(value.toString());
            else
                task->setDone(value.toInt() == Qt::Checked);

            const auto job = taskRepository()->update(task);
            installHandler(job, tr("Cannot modify task %1 in Workday").arg(currentTitle));
            return true;
        }

        return false;
    }
```

#### AUTO 


```{c}
auto fetch = m_helpers->fetchItems(StorageInterface::Notes);
```

#### AUTO 


```{c}
auto settingsAction = new QAction(this);
```

#### AUTO 


```{c}
const auto textRect = style->subElementRect(QStyle::SE_ItemViewItemText, &opt, widget);
```

#### AUTO 


```{c}
auto reconstructedParent = reconstructAncestors(collectionsMap[parent.id()]);
```

#### AUTO 


```{c}
auto dataSource = deserializeDataSource(collection);
```

#### LAMBDA EXPRESSION 


```{c}
[storage] (const Domain::LiveQueryInput<Akonadi::Tag>::AddFunction &add) {
            auto job = storage->fetchTags();
            Utils::JobHandler::install(job->kjob(), [add, job] {
                foreach (const auto &tag, job->tags()) {
                    add(tag);
                }
            });
        }
```

#### AUTO 


```{c}
auto sourceLabel = dialog.findChild<QLabel*>("sourceLabel");
```

#### AUTO 


```{c}
auto source2 = Domain::DataSource::Ptr::create();
```

#### AUTO 


```{c}
auto project2 = serializer->createProjectFromItem(data.item(43));
```

#### LAMBDA EXPRESSION 


```{c}
[&](KJob *job) {
            callCount++;
            seenJobs << job;
        }
```

#### AUTO 


```{c}
auto source2Provider = Domain::QueryResultProvider<Domain::DataSource::Ptr>::Ptr::create();
```

#### AUTO 


```{c}
auto job = storage->updateCollection(collection, nullptr);
```

#### AUTO 


```{c}
const auto widget = opt.widget;
```

#### AUTO 


```{c}
const auto collectionFetchNames = [job, toCollectionNames]{
                return toCollectionNames(job->collections());
            }();
```

#### AUTO 


```{c}
auto result = std::find_if(collections.constBegin(), collections.constEnd(),
                               [remoteId] (const Akonadi::Collection &collection) {
                                   return collection.remoteId() == remoteId;
                               });
```

#### AUTO 


```{c}
auto collection = serializer.createCollectionFromDataSource(source);
```

#### AUTO 


```{c}
auto drag = [] (const Domain::Artifact::List &artifacts) -> QMimeData* {
        if (artifacts.isEmpty())
            return 0;

        QMimeData *data = new QMimeData;
        data->setData("application/x-zanshin-object", "object");
        data->setProperty("objects", QVariant::fromValue(artifacts));
        return data;
    };
```

#### AUTO 


```{c}
auto components = new Widgets::ApplicationComponents(widget);
```

#### LAMBDA EXPRESSION 


```{c}
[storage, job, add, parent] {
            if (job->kjob()->error() != KJob::NoError)
                return;

            Q_ASSERT(job->items().size() == 1);
            auto item = job->items().at(0);
            Q_ASSERT(item.parentCollection().isValid());
            auto job = storage->fetchItems(item.parentCollection(), parent);
            Utils::JobHandler::install(job->kjob(), [job, add] {
                if (job->kjob()->error() != KJob::NoError)
                    return;

                foreach (const auto &item, job->items())
                    add(item);
            });
        }
```

#### AUTO 


```{c}
auto query = [this] (const Domain::DataSource::Ptr &source) {
        if (!source)
            return m_dataSourceQueries->findSearchTopLevel();
        else
            return m_dataSourceQueries->findSearchChildren(source);
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (auto item : job->items()) {
                    provider->append(deserializeTask(item));
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Akonadi::Collection &collection) {
            return collection.isValid()
                && collection.parentCollection() == Akonadi::Collection::root()
                && m_serializer->isListedCollection(collection);
        }
```

#### AUTO 


```{c}
const auto leftTask = leftArtifact.objectCast<Domain::Task>();
```

#### AUTO 


```{c}
const auto agentType = dlg->agentType();
```

#### AUTO 


```{c}
auto availableSources = m_model->property("availableSources").value<QObject*>();
```

#### AUTO 


```{c}
const auto baseFont = opt.font;
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &, int) {
            return QVariant();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[fetchItemJob, job, this] {
        if (fetchItemJob->kjob()->error() != KJob::NoError)
            return;

        Q_ASSERT(fetchItemJob->items().size() == 1);
        auto childItem = fetchItemJob->items().first();
        childItem.clearTags();

        auto updateJob = m_storage->updateItem(childItem);
        job->addSubjob(updateJob);
        updateJob->start();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Akonadi::Item &item, const Domain::Project::Ptr &project) {
            return m_serializer->representsItem(project, item);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto provider : providers) {
        if (!provider)
            continue;
        for (int i = 0; i < provider->data().size(); i++) {
            auto dataSource = provider->data().at(i);
            if (isDataSourceCollection(dataSource, collection)) {
                m_serializer->updateDataSourceFromCollection(dataSource, collection);
                provider->replace(i, dataSource);
            }
        }
    }
```

#### AUTO 


```{c}
auto drag = [] (const Domain::Task::List &tasks) -> QMimeData* {
        if (tasks.isEmpty())
            return Q_NULLPTR;

        auto draggedArtifacts = Domain::Artifact::List();
        draggedArtifacts.reserve(tasks.size());
        foreach (const Domain::Task::Ptr &task, tasks) {
            draggedArtifacts.append(task.objectCast<Domain::Artifact>());
        }

        auto data = new QMimeData();
        data->setData(QStringLiteral("application/x-zanshin-object"), "object");
        data->setProperty("objects", QVariant::fromValue(draggedArtifacts));
        return data;
    };
```

#### AUTO 


```{c}
const auto parentId = findParentId(m_items[item.id()]);
```

#### LAMBDA EXPRESSION 


```{c}
[provider, job, this] {
        for (Akonadi::Tag tag : job->tags()) {
            auto context = m_serializer->createContextFromTag(tag);
            if (context) {
                provider->append(context);
            }
        }
    }
```

#### AUTO 


```{c}
auto predicate = [this] (const Akonadi::Item &item) {
        return m_serializer->relatedUidFromItem(item).isEmpty() && m_serializer->isTaskItem(item);
    };
```

#### AUTO 


```{c}
auto expectedIds = QVector<Akonadi::Item::Id>() << 45 << 48 << 50 << 52;
```

#### AUTO 


```{c}
auto fetch = m_helpers->fetchCollections(root, StorageInterface::Tasks | StorageInterface::Notes);
```

#### AUTO 


```{c}
auto result = NoteResult::create(provider);
```

#### AUTO 


```{c}
auto exQuery = Domain::LiveQueryOutput<Domain::DataSource::Ptr>::Ptr();
```

#### AUTO 


```{c}
const auto job = m_noteRepository->update(note);
```

#### AUTO 


```{c}
auto appModel = ApplicationModel::Ptr::create();
```

#### AUTO 


```{c}
auto job = storage->removeItems(list, nullptr);
```

#### LAMBDA EXPRESSION 


```{c}
[] (const Domain::DataSource::Ptr &source) {
        const Qt::ItemFlags defaultFlags = Qt::ItemIsSelectable
                                         | Qt::ItemIsEnabled;
        if (source->contentTypes() != Domain::DataSource::NoContent)
            return defaultFlags | Qt::ItemIsUserCheckable;
        else
            return defaultFlags;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto collection : job->collections()) {
            ItemFetchJobInterface *job = m_storage->fetchItems(collection);
            registerJobHandler(job->kjob(), [provider, job, this] {
                for (auto item : job->items()) {
                    auto task = deserializeTask(item);
                    if (task)
                        provider->append(task);
                }
            });
        }
```

#### AUTO 


```{c}
auto result1 = queries->findTopLevelTasks(context1);
```

#### AUTO 


```{c}
const auto parentIndex = page.centralListModel()->index(0, 0);
```

#### AUTO 


```{c}
auto task = m_artifact.objectCast<Domain::Task>()
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Item::Id &id) { return m_items.value(id); }
```

#### LAMBDA EXPRESSION 


```{c}
[](const Domain::Note::Ptr &note, int role, int) -> QVariant {
        if (role != Qt::DisplayRole
         && role != Qt::EditRole) {
            return QVariant();
        }

        if (role == Qt::DisplayRole || role == Qt::EditRole) {
            return note->title();
        } else {
            return QVariant();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const Akonadi::Tag::List &tags) {
            auto res = QStringList();
            res.reserve(tags.size());
            std::transform(tags.cbegin(), tags.cend(),
                           std::back_inserter(res),
                           std::mem_fn(&Akonadi::Tag::name));
            res.sort();
            return res;
        }
```

#### AUTO 


```{c}
auto itemScope = m_monitor->itemFetchScope();
```

#### LAMBDA EXPRESSION 


```{c}
[storage] (const Domain::LiveQueryInput<Akonadi::Item>::AddFunction &add) {
            auto job = storage->fetchCollections(Akonadi::Collection::root(), Akonadi::Storage::Recursive);
            Utils::JobHandler::install(job->kjob(), [add, job, storage] {
                foreach (const auto &col, job->collections()) {
                    auto itemJob = storage->fetchItems(col);
                    Utils::JobHandler::install(itemJob->kjob(), [add, itemJob] {
                        foreach (const auto &item, itemJob->items())
                            add(item);
                    });
                }
            });
        }
```

#### AUTO 


```{c}
const auto behavior = m_data->storageBehavior().searchCollectionsBehavior(collectionName);
```

#### LAMBDA EXPRESSION 


```{c}
[fetchItemJob, child, parent, job, this] {
        if (fetchItemJob->kjob()->error() != KJob::NoError)
           return;

        Q_ASSERT(fetchItemJob->items().size() == 1);
        auto childItem = fetchItemJob->items().at(0);
        m_serializer->updateItemParent(childItem, parent);

        // Check collections to know if we need to move child
        auto partialParentItem = m_serializer->createItemFromTask(parent);
        ItemFetchJobInterface *fetchParentItemJob = m_storage->fetchItems(partialParentItem.parentCollection(), this);
        job->install(fetchParentItemJob->kjob(), [child, parent, fetchParentItemJob, partialParentItem, childItem, job, this] {
            if (fetchParentItemJob->kjob()->error() != KJob::NoError)
                return;

            const auto items = fetchParentItemJob->items();
            const auto parentIndex = items.indexOf(partialParentItem);
            Q_ASSERT(parentIndex >= 0);
            const auto parentItem = items.at(parentIndex);

            const auto childUid = m_serializer->itemUid(childItem);
            auto relatedUid = m_serializer->relatedUidFromItem(parentItem);
            while (!relatedUid.isEmpty()) {
                if (relatedUid == childUid) {
                    job->emitError(i18n("Could not associate '%1', it is an ancestor of '%2'",
                                        child->title(),
                                        parent->title()));
                    return;
                }

                auto it = std::find_if(items.constBegin(), items.constEnd(),
                                       [relatedUid, this] (const Akonadi::Item &item) {
                    return m_serializer->itemUid(item) == relatedUid;
                });
                if (it == items.end())
                    break;

                relatedUid = m_serializer->relatedUidFromItem(*it);
            }

            const int itemCollectionId = childItem.parentCollection().id();
            const int parentCollectionId = parentItem.parentCollection().id();

            if (itemCollectionId != parentCollectionId) {
                ItemFetchJobInterface *fetchChildrenItemJob = m_storage->fetchItems(childItem.parentCollection(), this);
                job->install(fetchChildrenItemJob->kjob(), [fetchChildrenItemJob, childItem, parentItem, job, this] {
                    if (fetchChildrenItemJob->kjob()->error() != KJob::NoError)
                        return;

                    Item::List childItems = m_serializer->filterDescendantItems(fetchChildrenItemJob->items(), childItem);

                    auto transaction = m_storage->createTransaction();
                    m_storage->updateItem(childItem, transaction);
                    childItems.push_front(childItem);
                    m_storage->moveItems(childItems, parentItem.parentCollection(), transaction);
                    job->addSubjob(transaction);
                    transaction->start();
                });
            } else {
                auto updateJob = m_storage->updateItem(childItem);
                job->addSubjob(updateJob);
                updateJob->start();
            }
        });
    }
```

#### AUTO 


```{c}
const auto behavior = m_data->storageBehavior().fetchTagsBehavior();
```

#### AUTO 


```{c}
auto predicate = [this, root] (const Akonadi::Item &item) {
        return root == item.parentCollection()
            && m_serializer->isProjectItem(item);
    };
```

#### AUTO 


```{c}
auto task = provider->data().at(i);
```

#### AUTO 


```{c}
auto fetchAdditionalInfo = [this](const QModelIndex &index, const Domain::Artifact::Ptr &artifact) -> AdditionalInfo {
        if (index.parent().isValid()) // children are in the same collection as their parent, so the same project
            return nullptr;
        if (auto task = artifact.dynamicCast<Domain::Task>()) {
            AdditionalInfo projectQueryResult = m_taskQueries->findProject(task);
            if (projectQueryResult) {
                QPersistentModelIndex persistentIndex(index);
                projectQueryResult->addPostInsertHandler([persistentIndex](const Domain::Project::Ptr &, int) {
                    // When a project was found (inserted into the result), update the rendering of the item
                    auto model = const_cast<QAbstractItemModel *>(persistentIndex.model());
                    model->dataChanged(persistentIndex, persistentIndex);
                });
            }
            return projectQueryResult;
        }
        return nullptr;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Domain::Artifact::Ptr &artifact) -> Domain::QueryResultInterface<Domain::Artifact::Ptr>::Ptr {
        if (!artifact)
            return m_tagQueries->findTopLevelArtifacts(m_tag);
        else if (auto task = artifact.dynamicCast<Domain::Task>())
            return Domain::QueryResult<Domain::Task::Ptr, Domain::Artifact::Ptr>::copy(m_taskQueries->findChildren(task));
        else
            return Domain::QueryResult<Domain::Artifact::Ptr>::Ptr();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Item &item) {
        m_findChildren.remove(item.id());
        m_findContexts.remove(item.id());
    }
```

#### AUTO 


```{c}
auto object2 = deps2.create<Interface0>();
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Domain::Artifact::Ptr &artifact, const QVariant &value, int role) {
        if (role != Qt::EditRole && role != Qt::CheckStateRole) {
            return false;
        }

        if (auto task = artifact.dynamicCast<Domain::Task>()) {
            if (role == Qt::EditRole)
                task->setTitle(value.toString());
            else
                task->setDone(value.toInt() == Qt::Checked);

            taskRepository()->save(task);
            return true;

        } else if (auto note = artifact.dynamicCast<Domain::Note>()) {
            if (role != Qt::EditRole)
                return false;

            note->setTitle(value.toString());
            noteRepository()->save(note);
            return true;

        }

        return false;
    }
```

#### AUTO 


```{c}
auto it = jobs.cbegin();
```

#### LAMBDA EXPRESSION 


```{c}
[this, job, add] {
                for (auto collection : job->collections())
                    add(collection);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
            FakeJob *job2 = new FakeJob(this);
            QObject::connect(job2, &KJob::result, this, &CompositeJobTest::handleJobResult);
            compositeJob->addSubjob(job2);
            job2->start();
        }
```

#### AUTO 


```{c}
const auto bogusMimeTypes = QStringList() << "foo/bar";
```

#### LAMBDA EXPRESSION 


```{c}
[this](const ItemType &, int idx) {
            QModelIndex parentIndex = parent() ? createIndex(row(), 0, this) : QModelIndex();
            emitDataChanged(index(idx, 0, parentIndex), index(idx, 0, parentIndex));
        }
```

#### AUTO 


```{c}
const auto parent = std::find_if(items.cbegin(), items.cend(),
                                                 [serializer, parentUid] (const Akonadi::Item &item) {
                                                     return serializer->itemUid(item) == parentUid;
                                                 });
```

#### LAMBDA EXPRESSION 


```{c}
[] (Utils::DependencyManager *) {
                return new Presentation::EditorModel;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, contentTypes] (const Collection &collection) {
                     return matchCollection(contentTypes, collection);
                 }
```

#### AUTO 


```{c}
auto provider = QueryResultInputImpl<InputType>::m_provider;
```

#### AUTO 


```{c}
const auto &row
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Domain::Artifact::Ptr &artifact) -> Domain::QueryResultInterface<Domain::Artifact::Ptr>::Ptr {
        if (!artifact)
            return m_projectQueries->findTopLevelArtifacts(m_project);
        else if (auto task = artifact.dynamicCast<Domain::Task>())
            return Domain::QueryResult<Domain::Task::Ptr, Domain::Artifact::Ptr>::copy(taskQueries()->findChildren(task));
        else
            return Domain::QueryResult<Domain::Artifact::Ptr>::Ptr();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, job, add] {
            if (job->kjob()->error() != KJob::NoError)
                return;

            foreach (const auto &item, job->items())
                add(item);
        }
```

#### AUTO 


```{c}
const auto title = QString("New task");
```

#### AUTO 


```{c}
auto job = storage->removeCollection(collection, nullptr);
```

#### AUTO 


```{c}
auto result1 = queries->findChildren(task1);
```

#### AUTO 


```{c}
auto searchEdit = available.findChild<QLineEdit*>("searchEdit");
```

#### AUTO 


```{c}
auto agent = m_agentInstanceWidget->currentAgentInstance();
```

#### AUTO 


```{c}
auto setData = [this] (const Domain::Artifact::Ptr &artifact, const QVariant &value, int role) {
        if (role != Qt::EditRole && role != Qt::CheckStateRole) {
            return false;
        }

        if (auto task = artifact.dynamicCast<Domain::Task>()) {
            const auto currentTitle = task->title();
            if (role == Qt::EditRole)
                task->setTitle(value.toString());
            else
                task->setDone(value.toInt() == Qt::Checked);

            const auto job = taskRepository()->update(task);
            installHandler(job, tr("Cannot modify task %1 in tag %2").arg(currentTitle).arg(m_tag->name()));
            return true;

        } else if (auto note = artifact.dynamicCast<Domain::Note>()) {
            if (role != Qt::EditRole)
                return false;

            const auto currentTitle = note->title();
            note->setTitle(value.toString());
            const auto job = noteRepository()->save(note);
            installHandler(job, tr("Cannot modify note %1 in tag %2").arg(currentTitle).arg(m_tag->name()));
            return true;

        }

        return false;
    };
```

#### AUTO 


```{c}
auto parentItem = m_serializer->createItemFromProject(parent);
```

#### LAMBDA EXPRESSION 


```{c}
[] (const QList<QColor> &colors) {
            auto mimeData = new QMimeData;
            mimeData->setColorData(QVariant::fromValue(colors));
            return mimeData;
        }
```

#### AUTO 


```{c}
auto childrenTasks = createChildrenTasks();
```

#### AUTO 


```{c}
auto query = [this] (const Domain::Artifact::Ptr &artifact) -> Domain::QueryResultInterface<Domain::Artifact::Ptr>::Ptr {
        if (!artifact)
            return m_tagQueries->findTopLevelArtifacts(m_tag);
        else if (auto task = artifact.dynamicCast<Domain::Task>())
            return Domain::QueryResult<Domain::Task::Ptr, Domain::Artifact::Ptr>::copy(taskQueries()->findChildren(task));
        else
            return Domain::QueryResult<Domain::Artifact::Ptr>::Ptr();
    };
```

#### LAMBDA EXPRESSION 


```{c}
[repository] (const Domain::Task::Ptr &task, const Domain::Task::Delegate &delegate) {
            return repository->delegate(task, delegate);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](const Domain::Note::Ptr &) {
        return Qt::ItemIsSelectable
             | Qt::ItemIsEnabled
             | Qt::ItemIsEditable
             | Qt::ItemIsDragEnabled;
    }
```

#### AUTO 


```{c}
auto artifact = deserializeArtifact(item);
```

#### AUTO 


```{c}
auto tag = serializer->createTagFromAkonadiTag(data.tag(42));
```

#### LAMBDA EXPRESSION 


```{c}
[=] {
        auto font = baseFont;
        font.setStrikeOut(isDone);
        font.setBold(!isDone && (onStartDate || onDueDate || pastDueDate));
        return font;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, job, add] {
            foreach (const auto &tag, job->tags())
                add(tag);
        }
```

#### AUTO 


```{c}
const auto oldPropertyValue = artifact->property(propertyName);
```

#### AUTO 


```{c}
auto filterAdd = [context, add, serializer] (const Item &item) {
            if (serializer->isContextChild(context, item))
                add(item);
        };
```

#### LAMBDA EXPRESSION 


```{c}
[akonadiTag, fetchItemJob, parent, job, this] {
        if (fetchItemJob->kjob()->error() != KJob::NoError)
            return;

        Q_ASSERT(fetchItemJob->items().size() == 1);
        auto childItem = fetchItemJob->items().first();
        childItem.setTag(akonadiTag);

        auto updateJob = m_storage->updateItem(childItem);
        job->addSubjob(updateJob);
        updateJob->start();
    }
```

#### AUTO 


```{c}
const auto task = child.objectCast<Domain::Task>();
```

#### AUTO 


```{c}
auto attr = new Akonadi::EntityDisplayAttribute;
```

#### AUTO 


```{c}
const auto newAttribute = newCollection.attribute<Akonadi::ApplicationSelectedAttribute>();
```

#### AUTO 


```{c}
auto aboutData = App::getAboutData();
```

#### AUTO 


```{c}
const auto selectedIndexes = selectionModel->selectedIndexes();
```

#### LAMBDA EXPRESSION 


```{c}
[this] (Utils::DependencyManager *) {
                             return m_data.createMonitor();
                         }
```

#### AUTO 


```{c}
const auto index = model.index(taskPos);
```

#### LAMBDA EXPRESSION 


```{c}
[this, tag] (const Domain::LiveQueryInput<Item>::AddFunction &add) {
        auto job = m_storage->fetchTagItems(tag);
        Utils::JobHandler::install(job->kjob(), [this, job, add] {
            if (job->kjob()->error() != KJob::NoError)
                return;

            foreach (const auto &item, job->items())
                add(item);
        });
    }
```

#### AUTO 


```{c}
auto collection = GenCollection().withId(42).withRootAsParent().withTaskContent();
```

#### AUTO 


```{c}
auto &query = m_findDataSource[item.id()];
```

#### LAMBDA EXPRESSION 


```{c}
[context, add, serializer] (const Item &item) {
            if (serializer->isContextChild(context, item))
                add(item);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[fetchItemJob, parent, child, job, this] {
        if (fetchItemJob->kjob()->error() != KJob::NoError)
           return;

        Q_ASSERT(fetchItemJob->items().size() == 1);
        auto childItem = fetchItemJob->items().at(0);
        m_serializer->updateItemProject(childItem, parent);

        // Check collections to know if we need to move child
        auto parentItem = m_serializer->createItemFromProject(parent);
        ItemFetchJobInterface *fetchParentItemJob = m_storage->fetchItem(parentItem, this);
        job->install(fetchParentItemJob->kjob(), [fetchParentItemJob, child, childItem, job, this] {
            if (fetchParentItemJob->kjob()->error() != KJob::NoError)
                return;

            Q_ASSERT(fetchParentItemJob->items().size() == 1);
            auto parentItem = fetchParentItemJob->items().at(0);

            const int itemCollectionId = childItem.parentCollection().id();
            const int parentCollectionId = parentItem.parentCollection().id();

            if (itemCollectionId != parentCollectionId) {
                ItemFetchJobInterface *fetchChildrenItemJob = m_storage->fetchItems(childItem.parentCollection(), this);
                job->install(fetchChildrenItemJob->kjob(), [fetchChildrenItemJob, childItem, parentItem, job, this] {
                    if (fetchChildrenItemJob->kjob()->error() != KJob::NoError)
                        return;

                    Item::List childItems = m_serializer->filterDescendantItems(fetchChildrenItemJob->items(), childItem);

                    auto transaction = m_storage->createTransaction(this);
                    m_storage->updateItem(childItem, transaction);
                    childItems.push_front(childItem);
                    m_storage->moveItems(childItems, parentItem.parentCollection(), transaction);
                    job->addSubjob(transaction);
                    transaction->start();
                });
            } else {
                auto updateJob = m_storage->updateItem(childItem, this);
                job->addSubjob(updateJob);
                updateJob->start();
            }
        });
    }
```

#### AUTO 


```{c}
auto selectedAttribute = new Akonadi::ApplicationSelectedAttribute;
```

#### AUTO 


```{c}
auto query = [this](const Domain::Artifact::Ptr &artifact) -> Domain::QueryResultInterface<Domain::Artifact::Ptr>::Ptr {
        if (!artifact)
            return m_projectQueries->findTopLevelArtifacts(m_project);
        else if (auto task = artifact.dynamicCast<Domain::Task>())
            return Domain::QueryResult<Domain::Task::Ptr, Domain::Artifact::Ptr>::copy(m_taskQueries->findChildren(task));
        else
            return Domain::QueryResult<Domain::Artifact::Ptr>::Ptr();
    };
```

#### LAMBDA EXPRESSION 


```{c}
[persistentIndex](const Domain::DataSource::Ptr &, int) {
                    // When a datasource was found (inserted into the result), update the rendering of the item
                    auto model = const_cast<QAbstractItemModel *>(persistentIndex.model());
                    model->dataChanged(persistentIndex, persistentIndex);
                }
```

#### AUTO 


```{c}
auto job = m_storage->fetchItem(item);
```

#### AUTO 


```{c}
auto setData = [this] (const Domain::Task::Ptr &task, const QVariant &value, int role) {
        if (role != Qt::EditRole && role != Qt::CheckStateRole)
            return false;

        const auto currentTitle = task->title();
        if (role == Qt::EditRole)
            task->setTitle(value.toString());
        else
            task->setDone(value.toInt() == Qt::Checked);

        const auto job = m_taskRepository->update(task);
        installHandler(job, tr("Cannot modify task %1 in context %2").arg(currentTitle).arg(m_context->name()));
        return true;
    };
```

#### AUTO 


```{c}
auto appModelStub = QObjectPtr::create();
```

#### LAMBDA EXPRESSION 


```{c}
[&depth, &collectionByRid] (const Akonadi::Collection &c) {
                  if (c.parentCollection().remoteId().isEmpty()) {
                      return 0;
                  }

                  auto parent = collectionByRid.value(c.parentCollection().remoteId());
                  return depth(parent) + 1;
              }
```

#### LAMBDA EXPRESSION 


```{c}
[=] {
        auto font = baseFont;
        font.setStrikeOut(isDone);
        font.setBold(!isDone && (onStartDate || onDueDate || pastDueDate));
        font.setItalic(taskDelegate.isValid());
        return font;
    }
```

#### AUTO 


```{c}
auto fetch = m_helpers->fetchItemsForContext(context, const_cast<ContextQueries*>(this));
```

#### LAMBDA EXPRESSION 


```{c}
[] (const Domain::Task::Ptr &task, int role, int) -> QVariant {
        if (role != Qt::DisplayRole
         && role != Qt::EditRole
         && role != Qt::CheckStateRole) {
            return QVariant();
        }

        if (role == Qt::DisplayRole || role == Qt::EditRole) {
            return task->title();
        } else if (role == Qt::CheckStateRole){
            return task->isDone() ? Qt::Checked : Qt::Unchecked;
        } else {
            return QVariant();
        }
    }
```

#### AUTO 


```{c}
const auto todo = seenItem.item().payload<KCalCore::Todo::Ptr>();
```

#### AUTO 


```{c}
auto projectPageModel = new ProjectPageModel(project,
                                                     m_projectQueries,
                                                     m_projectRepository,
                                                     m_taskQueries,
                                                     m_taskRepository,
                                                     this);
```

#### AUTO 


```{c}
auto createJob = m_storage->createItem(item, col);
```

#### AUTO 


```{c}
auto fetch = helpers->fetchItems();
```

#### AUTO 


```{c}
auto job = storage->fetchCollections(Akonadi::Collection::root(),
                                             StorageInterface::Recursive,
                                             contentTypes);
```

#### LAMBDA EXPRESSION 


```{c}
[fetchCollectionItemsJob, item, compositeJob, this] {
            if (fetchCollectionItemsJob->kjob()->error() != KJob::NoError)
                return;

            Item::List childItems = m_serializer->filterDescendantItems(fetchCollectionItemsJob->items(), item);
            childItems << item;

            auto removeJob = m_storage->removeItems(childItems, this);
            compositeJob->addSubjob(removeJob);
            removeJob->start();
        }
```

#### AUTO 


```{c}
auto job = storage.fetchCollections(Akonadi::Collection::root(), Akonadi::Storage::Recursive,
                                            Akonadi::StorageInterface::FetchContentTypes(contentTypes));
```

#### AUTO 


```{c}
auto object1 = deps1.create<Interface0>();
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QObjectPtr &object, int role) -> QVariant {
        if (role != Qt::DisplayRole
         && role != Qt::EditRole
         && role != Qt::DecorationRole
         && role != QueryTreeModelBase::IconNameRole) {
            return QVariant();
        }

        if (role == Qt::EditRole
         && (object == m_inboxObject
          || object == m_workdayObject
          || object == m_projectsObject
          || object == m_contextsObject
          || object == m_tagsObject)) {
            return QVariant();
        }

        if (role == Qt::DisplayRole || role == Qt::EditRole) {
            return object->property("name").toString();
        } else if (role == Qt::DecorationRole || role == QueryTreeModelBase::IconNameRole) {
            const QString iconName = object == m_inboxObject ? "mail-folder-inbox"
                                   : (object == m_workdayObject)  ? "go-jump-today"
                                   : (object == m_projectsObject) ? "folder"
                                   : (object == m_contextsObject) ? "folder"
                                   : (object == m_tagsObject)     ? "folder"
                                   : "view-pim-tasks";

            if (role == Qt::DecorationRole)
                return QVariant::fromValue(QIcon::fromTheme(iconName));
            else
                return iconName;
        } else {
            return QVariant();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&tags] (const Akonadi::Tag &tag) {
            tags.append(tag);
        }
```

#### AUTO 


```{c}
auto destModel = availablePages->property("pageListModel").value<QAbstractItemModel*>();
```

#### AUTO 


```{c}
auto mimeData = std::unique_ptr<QMimeData>(model->mimeData(QModelIndexList() << childTask12Index));
```

#### AUTO 


```{c}
auto data = [this](const QObjectPtr &object, int role) -> QVariant {
        if (role != Qt::DisplayRole
         && role != Qt::EditRole
         && role != Qt::DecorationRole
         && role != QueryTreeModelBase::IconNameRole) {
            return QVariant();
        }

        if (role == Qt::EditRole
         && (object == m_inboxObject
          || object == m_projectsObject
          || object == m_contextsObject
          || object == m_tagsObject)) {
            return QVariant();
        }

        if (role == Qt::DisplayRole || role == Qt::EditRole) {
            return object->property("name").toString();
        } else if (role == Qt::DecorationRole || role == QueryTreeModelBase::IconNameRole) {
            const QString iconName = object == m_inboxObject ? "mail-folder-inbox"
                                   : (object == m_projectsObject) ? "folder"
                                   : (object == m_contextsObject) ? "folder"
                                   : (object == m_tagsObject)     ? "folder"
                                   : "view-pim-tasks";

            if (role == Qt::DecorationRole)
                return QVariant::fromValue(QIcon::fromTheme(iconName));
            else
                return iconName;
        } else {
            return QVariant();
        }
    };
```

#### LAMBDA EXPRESSION 


```{c}
[](const Domain::Task::Ptr &task, int role) -> QVariant {
        if (role != Qt::DisplayRole
         && role != Qt::EditRole
         && role != Qt::CheckStateRole) {
            return QVariant();
        }

        if (role == Qt::DisplayRole || role == Qt::EditRole) {
            return task->title();
        } else {
            return task->isDone() ? Qt::Checked : Qt::Unchecked;
        }
    }
```

#### AUTO 


```{c}
auto scriptHandler = QObjectPtr::create();
```

#### AUTO 


```{c}
auto task = currentArtifact().objectCast<Domain::Task>();
```

#### LAMBDA EXPRESSION 


```{c}
[fetchItemJob, job, this] {
        if (fetchItemJob->kjob()->error() != KJob::NoError)
            return;

        Q_ASSERT(fetchItemJob->items().size() == 1);
        auto childItem = fetchItemJob->items().first();
        foreach (const Tag &tag, childItem.tags())
            childItem.clearTag(tag);

        auto updateJob = m_storage->updateItem(childItem);
        job->addSubjob(updateJob);
        updateJob->start();
    }
```

#### AUTO 


```{c}
auto firstLevelProvider = Domain::QueryResultProvider<QString>::Ptr::create();
```

#### AUTO 


```{c}
auto sourceB = Domain::DataSource::Ptr::create();
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QMimeData *mimeData, Qt::DropAction, const Domain::Task::Ptr &task) {
        auto parentTask = task.objectCast<Domain::Task>();

        if (!mimeData->hasFormat(QStringLiteral("application/x-zanshin-object")))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                        [](const Domain::Artifact::Ptr &droppedArtifact) {
                            return !droppedArtifact.objectCast<Domain::Task>();
                        })) {
            return false;
        }

        foreach(const auto &droppedArtifact, droppedArtifacts) {
            auto childTask = droppedArtifact.objectCast<Domain::Task>();

            if (parentTask) {
                const auto job = m_taskRepository->associate(parentTask, childTask);
                installHandler(job, tr("Cannot move task %1 as sub-task of %2").arg(childTask->title(), parentTask->title()));
            } else {
                const auto job = m_taskRepository->dissociate(childTask);
                installHandler(job, tr("Cannot deparent task %1 from its parent").arg(childTask->title()));
            }
        }

        return true;
    }
```

#### AUTO 


```{c}
auto tagJob = storage->fetchTags();
```

#### AUTO 


```{c}
auto runningTaskWidget = components.runningTaskWidget();
```

#### AUTO 


```{c}
auto source = index.data(QueryTreeModelBase::ObjectRole).value<Domain::DataSource::Ptr>();
```

#### AUTO 


```{c}
auto result2 = queries->findProjects(dataSource2);
```

#### AUTO 


```{c}
auto checkOption = opt;
```

#### AUTO 


```{c}
const auto index = m_tags.indexOf(tag);
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Item &item) {
        const auto it = m_findContexts.find(item.id());
        if (it == m_findContexts.cend())
            return;

        m_findContextsItem[item.id()] = item;
        (*it)->reset();
    }
```

#### AUTO 


```{c}
auto displayAttribute = new Akonadi::EntityDisplayAttribute;
```

#### AUTO 


```{c}
auto query = [this](const QObjectPtr &object) -> Domain::QueryResultInterface<QObjectPtr>::Ptr {
        if (!object)
            return Domain::QueryResult<QObjectPtr>::create(m_rootsProvider);
        else if (object == m_projectsObject)
            return Domain::QueryResult<Domain::Project::Ptr, QObjectPtr>::copy(m_projectQueries->findAll());
        else if (object == m_contextsObject)
            return Domain::QueryResult<Domain::Context::Ptr, QObjectPtr>::copy(m_contextQueries->findAll());
        else if (object == m_tagsObject)
            return Domain::QueryResult<Domain::Tag::Ptr, QObjectPtr>::copy(m_tagQueries->findAll());
        else
            return Domain::QueryResult<QObjectPtr>::Ptr();
    };
```

#### AUTO 


```{c}
auto setData = [this](const Domain::Note::Ptr &note, const QVariant &value, int role) {
        if (role != Qt::EditRole) {
            return false;
        }

        const auto currentTitle = note->title();
        note->setTitle(value.toString());
        const auto job = m_noteRepository->update(note);
        installHandler(job, i18n("Cannot modify note %1 in Inbox", currentTitle));
        return true;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[storage, parent] (const Domain::LiveQueryInput<Akonadi::Item>::AddFunction &add) {
            auto job = storage->fetchCollections(Akonadi::Collection::root(), Akonadi::Storage::Recursive, parent);
            Utils::JobHandler::install(job->kjob(), [add, job, storage] {
                foreach (const auto &col, job->collections()) {
                    auto itemJob = storage->fetchItems(col, nullptr);
                    Utils::JobHandler::install(itemJob->kjob(), [add, itemJob] {
                        foreach (const auto &item, itemJob->items())
                            add(item);
                    });
                }
            });
        }
```

#### AUTO 


```{c}
const auto currentTitle = task->title();
```

#### AUTO 


```{c}
const auto tag = Akonadi::Tag(GenTag().withId(1).asPlain().withName("tag"));
```

#### AUTO 


```{c}
const auto contextUid = context->property("todoUid").toString();
```

#### LAMBDA EXPRESSION 


```{c}
[storage] (const Domain::LiveQueryInput<Tag>::AddFunction &add) {
        auto job = storage->fetchTags();
        Utils::JobHandler::install(job->kjob(), [job, add] {
            foreach (const auto &tag, job->tags())
                add(tag);
        });
    }
```

#### AUTO 


```{c}
const auto contentTypes = Akonadi::StorageInterface::FetchContentTypes(contentTypesInt);
```

#### AUTO 


```{c}
auto setData = [this](const QObjectPtr &object, const QVariant &, int role) {
        if (role != Qt::EditRole) {
            return false;
        }

        if (object == m_inboxObject
         || object == m_tagsObject) {
            return false;
        }

        if (object.objectCast<Domain::Tag>()) {
            return false; // Tag renaming is NOT allowed
        } else {
            Q_ASSERT(false);
        }

        return true;
    };
```

#### AUTO 


```{c}
auto parentTask = artifact.objectCast<Domain::Task>();
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QModelIndex &index, const Domain::Task::Ptr &task) {
        return fetchTaskExtraData(m_taskQueries, TaskExtraPart::DataSource, index, task);
    }
```

#### AUTO 


```{c}
auto storage = Akonadi::StorageInterface::Ptr(data.createStorage());
```

#### LAMBDA EXPRESSION 


```{c}
[&removeHandlerCallCount](const QPair<int, QString> &, int) {
                                         removeHandlerCallCount++;
                                     }
```

#### LAMBDA EXPRESSION 


```{c}
[&](const Domain::Task::Ptr &task, const QVariant &value, int role) {
        if (role != Qt::EditRole && role != Qt::CheckStateRole) {
            return false;
        }

        if (role == Qt::EditRole) {
            task->setTitle(value.toString());
        } else {
            task->setDone(value.toInt() == Qt::Checked);
        }

        repository.save(task);
        return true;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[] (Akonadi::Tag::Id id) {
                       return Akonadi::Tag(id);
                   }
```

#### AUTO 


```{c}
auto drag = [](const QObjectPtrList &) -> QMimeData* {
        return nullptr;
    };
```

#### AUTO 


```{c}
const auto agentType = dlg.agentType();
```

#### AUTO 


```{c}
auto runTaskAction = page.findChild<QAction*>(QStringLiteral("runTaskAction"));
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QModelIndex &index, const Domain::Task::Ptr &task) -> AdditionalInfo {
        AdditionalInfo projectQueryResult = m_taskQueries->findProject(task);
        if (projectQueryResult) {
            QPersistentModelIndex persistentIndex(index);
            projectQueryResult->addPostInsertHandler([persistentIndex](const Domain::Project::Ptr &, int) {
                // When a project was found (inserted into the result), update the rendering of the item
                auto model = const_cast<QAbstractItemModel *>(persistentIndex.model());
                model->dataChanged(persistentIndex, persistentIndex);
            });
        }
        return projectQueryResult;
    }
```

#### AUTO 


```{c}
const auto collectionCachedNames = toCollectionNames(collections);
```

#### AUTO 


```{c}
auto setData = [this](const QObjectPtr &object, const QVariant &value, int role) {
        if (role != Qt::EditRole) {
            return false;
        }

        if (object == m_inboxObject || object == m_projectsObject) {
            return false;
        }

        auto project = object.objectCast<Domain::Project>();
        Q_ASSERT(project);
        project->setName(value.toString());
        m_projectRepository->update(project);
        return true;
    };
```

#### AUTO 


```{c}
const auto leftArtifact = left.data(QueryTreeModelBase::ObjectRole).value<Domain::Artifact::Ptr>();
```

#### AUTO 


```{c}
auto data = Testlib::AkonadiFakeData();
```

#### AUTO 


```{c}
auto childTask = droppedArtifact.objectCast<Domain::Task>();
```

#### LAMBDA EXPRESSION 


```{c}
[persistentIndex](const Domain::DataSource::Ptr &, int) {
                // When a data source was found (inserted into the result), update the rendering of the item
                auto model = const_cast<QAbstractItemModel *>(persistentIndex.model());
                model->dataChanged(persistentIndex, persistentIndex);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QColor &color) {
            if (!color.isValid())
                return Domain::QueryResult<QColor>::create(provider);
            else
                return Domain::QueryResult<QColor>::Ptr();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const QMimeData *mimeData, Qt::DropAction, const Domain::Artifact::Ptr &artifact) {
        auto parentTask = artifact.objectCast<Domain::Task>();
        if (!parentTask)
            return false;

        if (!mimeData->hasFormat("application/x-zanshin-object"))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                        [](const Domain::Artifact::Ptr &droppedArtifact) {
                            return !droppedArtifact.objectCast<Domain::Task>();
                        })) {
            return false;
        }

        foreach(const Domain::Artifact::Ptr &droppedArtifact, droppedArtifacts) {
            auto childTask = droppedArtifact.objectCast<Domain::Task>();
            taskRepository()->associate(parentTask, childTask);
        }

        return true;
    }
```

#### AUTO 


```{c}
auto index2 = stubPageModel.itemModel.index(2, 0);
```

#### AUTO 


```{c}
auto task = serializer->createTaskFromItem(data.item(1));
```

#### AUTO 


```{c}
auto *fetchJob = storage->fetchItems(collection1, nullptr);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Domain::Task::Ptr &, int idx) {
                                        emit dataChanged(index(idx, 0), index(idx, 0));
                                    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto handler : m_handlersWithJob)
    {
        handler(job);
    }
```

#### AUTO 


```{c}
auto editorModel = m_model->property("editor").value<QObject*>();
```

#### AUTO 


```{c}
auto configureMenu = new QMenu(widget);
```

#### LAMBDA EXPRESSION 


```{c}
[this, provider] (const InputType &input) {
            if (m_predicate(input))
                provider->append(m_convert(input));
        }
```

#### AUTO 


```{c}
auto context = Domain::Context::Ptr::create();
```

#### AUTO 


```{c}
auto drag = [](const QObjectPtrList &) -> QMimeData* {
        return Q_NULLPTR;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Domain::Artifact::Ptr &artifact, const QVariant &value, int role) {
        if (role != Qt::EditRole && role != Qt::CheckStateRole) {
            return false;
        }

        if (auto task = artifact.dynamicCast<Domain::Task>()) {
            const auto currentTitle = task->title();
            if (role == Qt::EditRole)
                task->setTitle(value.toString());
            else
                task->setDone(value.toInt() == Qt::Checked);

            const auto job = m_taskRepository->update(task);
            installHandler(job, tr("Cannot modify task %1 in project %2").arg(currentTitle).arg(m_project->name()));
            return true;

        } else if (auto note = artifact.dynamicCast<Domain::Note>()) {
            if (role != Qt::EditRole)
                return false;

            const auto currentTitle = note->title();
            note->setTitle(value.toString());
            const auto job = m_noteRepository->update(note);
            installHandler(job, tr("Cannot modify note %1 in project %2").arg(currentTitle).arg(m_project->name()));
            return true;

        }

        return false;
    }
```

#### AUTO 


```{c}
auto predicate = [this, project] (const Akonadi::Item &item) {
        return m_serializer->isProjectChild(project, item);
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QMimeData *mimeData, Qt::DropAction, const Domain::Artifact::Ptr &artifact) {
        auto parentTask = artifact.objectCast<Domain::Task>();
        if (!parentTask)
            return false;

        if (!mimeData->hasFormat("application/x-zanshin-object"))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                        [](const Domain::Artifact::Ptr &droppedArtifact) {
                            return !droppedArtifact.objectCast<Domain::Task>();
                        })) {
            return false;
        }

        foreach(const Domain::Artifact::Ptr &droppedArtifact, droppedArtifacts) {
            auto childTask = droppedArtifact.objectCast<Domain::Task>();
            const auto job = taskRepository()->associate(parentTask, childTask);
            if (!errorHandler())
                continue;

            errorHandler()->installHandler(job, tr("Cannot move task %1 as a sub-task of %2").arg(childTask->title()).arg(parentTask->title()));
        }

        return true;
    }
```

#### AUTO 


```{c}
auto foundCollections = Akonadi::Collection::List();
```

#### AUTO 


```{c}
const auto taskMimeTypes = QStringList() << QStringLiteral("application/x-vnd.akonadi.calendar.todo");
```

#### LAMBDA EXPRESSION 


```{c}
[this, add] {
                add(createObject(1, QStringLiteral("ItemA")));
                add(createObject(2, QStringLiteral("ProjectA"))); // parent promoted to project
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this, searchTerm, root] (const Domain::LiveQueryInput<Collection>::AddFunction &add) {
        if (searchTerm->isEmpty())
            return;

        auto job = m_storage->searchCollections(*searchTerm);
        Utils::JobHandler::install(job->kjob(), [root, job, add] {
            if (job->kjob()->error())
                return;

            auto directChildren = QHash<Collection::Id, Collection>();
            foreach (const auto &collection, job->collections()) {
                auto directChild = collection;
                while (directChild.parentCollection() != root && directChild.parentCollection().isValid())
                    directChild = directChild.parentCollection();
                if (directChild.parentCollection() != root)
                    continue;
                if (!directChildren.contains(directChild.id()))
                    directChildren[directChild.id()] = directChild;
            }

            foreach (const auto &directChild, directChildren.values())
                add(directChild);
        });
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &itemList : m_tagItems)
        itemList.removeAll(item.id());
```

#### AUTO 


```{c}
const auto collection2 = Akonadi::Collection(GenCollection().withRootAsParent()
                                                     .withId(2)
                                                     .withName("tasks2")
                                                     .withTaskContent());
```

#### AUTO 


```{c}
auto pageGlobalActions = page->globalActions();
```

#### AUTO 


```{c}
auto source4Result = Domain::QueryResult<Domain::DataSource::Ptr>::create(source4Provider);
```

#### AUTO 


```{c}
auto context2 = serializer->createContextFromItem(data.item(2));
```

#### AUTO 


```{c}
auto query = Domain::LiveQueryOutput<Domain::Project::Ptr>::Ptr();
```

#### AUTO 


```{c}
auto job = static_cast<KJob*>(o);
```

#### LAMBDA EXPRESSION 


```{c}
[this, add] {
                add(createObject(0, "0A"));
                add(createObject(1, "1A"));
                add(createObject(2, "2A"));
                add(createObject(3, "0B"));
                add(createObject(4, "1B"));
                add(createObject(5, "2B"));
                add(createObject(6, "0C"));
                add(createObject(7, "1C"));
                add(createObject(8, "2C"));
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this, job, add] {
                if (job->kjob()->error() != KJob::NoError)
                    return;

                foreach (const auto &item, job->items())
                    add(item);
            }
```

#### AUTO 


```{c}
const auto task = tasks[taskPos];
```

#### AUTO 


```{c}
auto displayedIndex = displayedModel->index(0, 0);
```

#### LAMBDA EXPRESSION 


```{c}
[this, job, add] {
                if (job->kjob()->error() != KJob::NoError)
                    return;

                for (auto collection : job->collections()) {
                    ItemFetchJobInterface *job = m_storage->fetchItems(collection);
                    Utils::JobHandler::install(job->kjob(), [this, job, add] {
                        if (job->kjob()->error() != KJob::NoError)
                            return;

                        for (auto item : job->items())
                            add(item);
                    });
                }
            }
```

#### AUTO 


```{c}
auto job = storage->fetchItem(item, parent);
```

#### LAMBDA EXPRESSION 


```{c}
[this, add] {
                add(createObject(0, QStringLiteral("0A")));
                add(createObject(1, QStringLiteral("1A")));
                add(createObject(2, QStringLiteral("2A")));
            }
```

#### AUTO 


```{c}
auto filterWidget = pageView->findChild<Widgets::FilterWidget*>(QStringLiteral("filterWidget"));
```

#### AUTO 


```{c}
const auto taskCollection2 = Akonadi::Collection(GenCollection().withRootAsParent()
                                                                        .withId(2)
                                                                        .withName("tasks2")
                                                                        .withTaskContent());
```

#### AUTO 


```{c}
auto job = storage->fetchCollections(Collection::root(), StorageInterface::Recursive);
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const QString &s) {
            bool ok = false;
            const int id = s.toInt(&ok);
            if (ok) {
                auto object = QObjectPtr::create();
                object->setProperty("id", id);
                return object;
            } else {
                return QObjectPtr();
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&removedId] (const Akonadi::Item &item) {
            removedId = item.id();
        }
```

#### AUTO 


```{c}
const auto job = m_contextRepository->create(context);
```

#### AUTO 


```{c}
auto itemFetchJob3 = new Testlib::AkonadiFakeItemFetchJob(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Domain::Task::Ptr &task, const QVariant &value, int role) {
        if (role != Qt::EditRole && role != Qt::CheckStateRole) {
            return false;
        }

        const auto currentTitle = task->title();
        if (role == Qt::EditRole)
            task->setTitle(value.toString());
        else
            task->setDone(value.toInt() == Qt::Checked);

        const auto job = m_taskRepository->update(task);
        installHandler(job, i18n("Cannot modify task %1 in Workday", currentTitle));
        return true;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[dialogStub] (QWidget *parent) {
            dialogStub->parent = parent;
            return dialogStub;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[storage, root, parent] (const Domain::LiveQueryInput<Collection>::AddFunction &add) {
        auto job = storage->fetchCollections(root, StorageInterface::Recursive, parent);
        Utils::JobHandler::install(job->kjob(), [root, job, add] {
            if (job->kjob()->error())
                return;

            auto directChildren = QHash<Collection::Id, Collection>();
            foreach (const auto &collection, job->collections()) {
                auto directChild = collection;
                while (directChild.parentCollection() != root)
                    directChild = directChild.parentCollection();
                if (!directChildren.contains(directChild.id()))
                    directChildren[directChild.id()] = directChild;
            }

            foreach (const auto &directChild, directChildren)
                add(directChild);
        });
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const Domain::Task::Ptr &task, int role, int) -> QVariant {
        if (role != Qt::DisplayRole && role != Qt::CheckStateRole) {
            return QVariant();
        }

        if (role == Qt::DisplayRole)
            return task->title();
        else
            return task->isDone() ? Qt::Checked : Qt::Unchecked;
    }
```

#### AUTO 


```{c}
const auto attendees = item.payload<KCalCore::Todo::Ptr>()->attendees();
```

#### AUTO 


```{c}
auto add = [&items] (const Akonadi::Item &item) {
            items.append(item);
        };
```

#### AUTO 


```{c}
auto i1 = Akonadi::Item(42);
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Collection &collection) {
        m_findChildren.remove(collection.id());
        m_findSearchChildren.remove(collection.id());
    }
```

#### AUTO 


```{c}
auto setData = [this](const QObjectPtr &object, const QVariant &value, int role) {
        if (role != Qt::EditRole) {
            return false;
        }

        if (object == m_inboxObject
         || object == m_workdayObject
         || object == m_projectsObject
         || object == m_contextsObject) {
            return false;
        }

        if (auto project = object.objectCast<Domain::Project>()) {
            const auto currentName = project->name();
            project->setName(value.toString());
            const auto job = m_projectRepository->update(project);
            installHandler(job, tr("Cannot modify project %1").arg(currentName));
        } else if (auto context = object.objectCast<Domain::Context>()) {
            const auto currentName = context->name();
            context->setName(value.toString());
            const auto job = m_contextRepository->update(context);
            installHandler(job, tr("Cannot modify context %1").arg(currentName));
        } else {
            Q_ASSERT(false);
        }

        return true;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[storage, contentTypes, root] (const Domain::LiveQueryInput<Collection>::AddFunction &add) {
        auto job = storage->fetchCollections(root, StorageInterface::Recursive, contentTypes);
        Utils::JobHandler::install(job->kjob(), [root, job, add] {
            if (job->kjob()->error())
                return;

            auto directChildren = QHash<Collection::Id, Collection>();
            foreach (const auto &collection, job->collections()) {
                auto directChild = collection;
                while (directChild.parentCollection() != root)
                    directChild = directChild.parentCollection();
                if (!directChildren.contains(directChild.id()))
                    directChildren[directChild.id()] = directChild;
            }

            foreach (const auto &directChild, directChildren.values())
                add(directChild);
        });
    }
```

#### AUTO 


```{c}
auto setData = [this](const Domain::Artifact::Ptr &artifact, const QVariant &value, int role) {
        Q_UNUSED(artifact);
        Q_UNUSED(value);
        Q_UNUSED(role);
        qFatal("Not implemented yet");
        return false;
    };
```

#### AUTO 


```{c}
auto provider = QueryResultProvider<QString>::Ptr::create();
```

#### AUTO 


```{c}
auto expectedSource = model.item(userInput.sourceComboIndex)
                                   ->data(Presentation::QueryTreeModelBase::ObjectRole)
                                   .value<Domain::DataSource::Ptr>();
```

#### LAMBDA EXPRESSION 


```{c}
[this, root] (const DataSourceQuery::AddFunction &add) {
            if (m_searchTerm.isEmpty())
                return;

            CollectionSearchJobInterface *job = m_storage->searchCollections(m_searchTerm);
            Utils::JobHandler::install(job->kjob(), [this, root, job, add] {
                if (job->kjob()->error())
                    return;

                QHash<Collection::Id, Collection> children;
                foreach (const auto &collection, job->collections()) {
                    auto child = collection;
                    while (child.parentCollection() != root && child.parentCollection().isValid())
                        child = child.parentCollection();
                    if (!children.contains(child.id()))
                        children[child.id()] = child;
                }

                foreach (const auto &topLevel, children.values())
                    add(topLevel);
            });
        }
```

#### AUTO 


```{c}
auto rootTask = Domain::Task::Ptr::create();
```

#### AUTO 


```{c}
auto data = [this] (const Domain::DataSource::Ptr &source, int role) -> QVariant {
        if (role != Qt::DisplayRole
         && role != Qt::EditRole
         && role != Qt::DecorationRole
         && role != Qt::CheckStateRole
         && role != QueryTreeModelBase::IconNameRole
         && role != QueryTreeModelBase::IsDefaultRole) {
            return QVariant();
        }

        if (role == Qt::DisplayRole || role == Qt::EditRole) {
            return source->name();
        } else if (role == Qt::DecorationRole || role == QueryTreeModelBase::IconNameRole) {
            const QString iconName = source->iconName().isEmpty() ? QStringLiteral("folder") : source->iconName();

            if (role == Qt::DecorationRole)
                return QVariant::fromValue(QIcon::fromTheme(iconName));
            else
                return iconName;
        } else if (role == Qt::CheckStateRole) {
            if (source->contentTypes() != Domain::DataSource::NoContent)
                return source->isSelected() ? Qt::Checked : Qt::Unchecked;
            else
                return QVariant();
        } else if (role == QueryTreeModelBase::IsDefaultRole) {
            return m_dataSourceQueries->isDefaultSource(source);
        } else {
            return QVariant();
        }
    };
```

#### AUTO 


```{c}
auto dropFunction = [&] (const QMimeData *data, Qt::DropAction, const QColor &color) {
            dropCalled = true;
            droppedData = data;
            colorSeen = color;
            return false;
        };
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &collection : job->collections()) {
            auto parent = collection.parentCollection();
            while (parent.isValid() && parent != Akonadi::Collection::root()) {
                if (!cachedCollections.contains(parent)) {
                    cachedCollections.append(parent);
                }
                parent = parent.parentCollection();
            }
        }
```

#### AUTO 


```{c}
auto job = storage.removeItem(item);
```

#### LAMBDA EXPRESSION 


```{c}
[this, add] {
                add(QStringLiteral("0"));
                add(QStringLiteral("1"));
                add(QString());
                add(QStringLiteral("a"));
                add(QStringLiteral("2"));
            }
```

#### AUTO 


```{c}
const auto noteCollection = Akonadi::Collection(GenCollection().withRootAsParent()
                                                                       .withId(1)
                                                                       .withName("notes")
                                                                       .withNoteContent());
```

#### AUTO 


```{c}
auto fetchItemsInSelectedCollectionsFunction(Akonadi::StorageInterface::Ptr storage, Akonadi::SerializerInterface::Ptr serializer, QObject *parent)
    {
        return [storage, serializer, parent] (const Domain::LiveQueryInput<Akonadi::Item>::AddFunction &add) {
            auto job = storage->fetchCollections(Akonadi::Collection::root(), Akonadi::Storage::Recursive, parent);
            Utils::JobHandler::install(job->kjob(), [add, job, storage, serializer] {
                foreach (const auto &col, job->collections()) {
                    if (!serializer->isSelectedCollection(col))
                        continue;

                    auto itemJob = storage->fetchItems(col, nullptr);
                    Utils::JobHandler::install(itemJob->kjob(), [add, itemJob] {
                        foreach (const auto &item, itemJob->items())
                            add(item);
                    });
                }
            });
        };
    }
```

#### AUTO 


```{c}
auto unrelatedTodo = KCalCore::Todo::Ptr::create();
```

#### AUTO 


```{c}
auto fetchItemsInAllCollectionsFunction(Akonadi::StorageInterface::Ptr storage, QObject *parent) {
        return [storage, parent] (const Domain::LiveQueryInput<Akonadi::Item>::AddFunction &add) {
            auto job = storage->fetchCollections(Akonadi::Collection::root(), Akonadi::Storage::Recursive, parent);
            Utils::JobHandler::install(job->kjob(), [add, job, storage] {
                foreach (const auto &col, job->collections()) {
                    auto itemJob = storage->fetchItems(col, nullptr);
                    Utils::JobHandler::install(itemJob->kjob(), [add, itemJob] {
                        foreach (const auto &item, itemJob->items())
                            add(item);
                    });
                }
            });
        };
    }
```

#### AUTO 


```{c}
auto source = index.data(Presentation::QueryTreeModelBase::ObjectRole)
                       .value<Domain::DataSource::Ptr>();
```

#### AUTO 


```{c}
auto loader = Testlib::AkonadiFakeDataXmlLoader(&m_data);
```

#### LAMBDA EXPRESSION 


```{c}
[child, parent, fetchParentItemJob, partialParentItem, childItem, job, this] {
            if (fetchParentItemJob->kjob()->error() != KJob::NoError)
                return;

            const auto items = fetchParentItemJob->items();
            const auto parentIndex = items.indexOf(partialParentItem);
            Q_ASSERT(parentIndex >= 0);
            const auto parentItem = items.at(parentIndex);

            const auto childUid = m_serializer->itemUid(childItem);
            auto relatedUid = m_serializer->relatedUidFromItem(parentItem);
            while (!relatedUid.isEmpty()) {
                if (relatedUid == childUid) {
                    job->emitError(i18n("Could not associate '%1', it is an ancestor of '%2'",
                                        child->title(),
                                        parent->title()));
                    return;
                }

                auto it = std::find_if(items.constBegin(), items.constEnd(),
                                       [relatedUid, this] (const Akonadi::Item &item) {
                    return m_serializer->itemUid(item) == relatedUid;
                });
                if (it == items.end())
                    break;

                relatedUid = m_serializer->relatedUidFromItem(*it);
            }

            const int itemCollectionId = childItem.parentCollection().id();
            const int parentCollectionId = parentItem.parentCollection().id();

            if (itemCollectionId != parentCollectionId) {
                ItemFetchJobInterface *fetchChildrenItemJob = m_storage->fetchItems(childItem.parentCollection(), this);
                job->install(fetchChildrenItemJob->kjob(), [fetchChildrenItemJob, childItem, parentItem, job, this] {
                    if (fetchChildrenItemJob->kjob()->error() != KJob::NoError)
                        return;

                    Item::List childItems = m_serializer->filterDescendantItems(fetchChildrenItemJob->items(), childItem);

                    auto transaction = m_storage->createTransaction(this);
                    m_storage->updateItem(childItem, transaction);
                    childItems.push_front(childItem);
                    m_storage->moveItems(childItems, parentItem.parentCollection(), transaction);
                    job->addSubjob(transaction);
                    transaction->start();
                });
            } else {
                auto updateJob = m_storage->updateItem(childItem, this);
                job->addSubjob(updateJob);
                updateJob->start();
            }
        }
```

#### AUTO 


```{c}
auto data = [this](const QObjectPtr &object, int role) -> QVariant {
        if (role != Qt::DisplayRole
         && role != Qt::EditRole
         && role != Qt::DecorationRole
         && role != QueryTreeModelBase::IconNameRole) {
            return QVariant();
        }

        if (role == Qt::EditRole
         && (object == m_inboxObject
          || object == m_workdayObject
          || object == m_projectsObject
          || object == m_contextsObject)) {
            return QVariant();
        }

        if (role == Qt::DisplayRole || role == Qt::EditRole) {
            return object->property("name").toString();
        } else if (role == Qt::DecorationRole || role == QueryTreeModelBase::IconNameRole) {
            const QString iconName = object == m_inboxObject ? "mail-folder-inbox"
                                   : (object == m_workdayObject)  ? "go-jump-today"
                                   : (object == m_projectsObject) ? "folder"
                                   : (object == m_contextsObject) ? "folder"
                                   : object.objectCast<Domain::Context>() ? "view-pim-notes"
                                   : "view-pim-tasks";

            if (role == Qt::DecorationRole)
                return QVariant::fromValue(QIcon::fromTheme(iconName));
            else
                return iconName;
        } else {
            return QVariant();
        }
    };
```

#### AUTO 


```{c}
auto result = std::find_if(tags.constBegin(), tags.constEnd(),
                               [gid] (const Akonadi::Tag &tag) {
                                   return tag.gid() == gid;
                               });
```

#### AUTO 


```{c}
auto job = new Akonadi::CollectionCreateJob(collection);
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Akonadi::Item &item) {
            return m_serializer->relatedUidFromItem(item).isEmpty();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[] (Utils::DependencyManager *deps) {
        return new Akonadi::DataSourceQueries(Akonadi::StorageInterface::Notes,
                                              deps->create<Akonadi::StorageInterface>(),
                                              deps->create<Akonadi::SerializerInterface>(),
                                              deps->create<Akonadi::MonitorInterface>());
    }
```

#### AUTO 


```{c}
auto fetch = m_helpers->fetchItems(root);
```

#### AUTO 


```{c}
auto output = provider->data().at(i);
```

#### AUTO 


```{c}
auto projectProvider = Domain::QueryResultProvider<Domain::Project::Ptr>::Ptr::create();
```

#### LAMBDA EXPRESSION 


```{c}
[this, &afterReset, add] {
                add(createObject(0, QStringLiteral("0A")));
                add(createObject(1, QStringLiteral("1A")));
                add(createObject(2, QStringLiteral("2A")));
                add(createObject(3, QStringLiteral("0B")));
                add(createObject(4, QStringLiteral("1B")));
                add(createObject(5, QStringLiteral("2B")));

                if (afterReset) {
                    add(createObject(6, QStringLiteral("0C")));
                    add(createObject(7, QStringLiteral("1C")));
                    add(createObject(8, QStringLiteral("2C")));
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[storage, item] (const Domain::LiveQueryInput<Collection>::AddFunction &add) {
        auto job = storage->fetchCollections(item.parentCollection(), StorageInterface::Base);
        Utils::JobHandler::install(job->kjob(), [storage, job, add] {
            if (job->kjob()->error() != KJob::NoError)
                return;
            auto collection = job->collections().at(0);
            add(collection);
        });
    }
```

#### AUTO 


```{c}
auto source4 = Domain::DataSource::Ptr::create();
```

#### LAMBDA EXPRESSION 


```{c}
[provider, job, this] {
        if (job->kjob()->error() != KJob::NoError)
            return;

        for (auto collection : job->collections()) {
            ItemFetchJobInterface *job = m_storage->fetchItems(collection);
            Utils::JobHandler::install(job->kjob(), [provider, job, this] {
                if (job->kjob()->error() != KJob::NoError)
                    return;

                for (auto item : job->items()) {
                    auto task = deserializeTask(item);
                    if (task)
                        provider->append(task);
                }
            });
        }
    }
```

#### AUTO 


```{c}
auto buttonOk = dialog.findChild<QDialogButtonBox*>(QStringLiteral("buttonBox"))->button(QDialogButtonBox::Ok);
```

#### LAMBDA EXPRESSION 


```{c}
[](const Domain::Task::Ptr &) {
            return Qt::ItemIsSelectable
                 | Qt::ItemIsEnabled
                 | Qt::ItemIsEditable
                 | Qt::ItemIsUserCheckable;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[] (const Akonadi::Tag &tag) {
            return tag.name().endsWith(QLatin1String("-ex"));
        }
```

#### AUTO 


```{c}
auto model = new AvailablePagesModel(m_artifactQueries,
                                             m_projectQueries,
                                             m_projectRepository,
                                             m_contextQueries,
                                             m_contextRepository,
                                             m_taskQueries,
                                             m_taskRepository,
                                             m_noteRepository,
                                             m_tagQueries,
                                             m_tagRepository,
                                             this);
```

#### AUTO 


```{c}
auto self = const_cast<CollectionJob*>(this);
```

#### AUTO 


```{c}
auto monitor = Akonadi::MonitorInterface::Ptr(data.createMonitor());
```

#### AUTO 


```{c}
auto predicate = [this, isWorkdayItem] (const Akonadi::Item &item) {
        if (!isWorkdayItem(item))
            return false;

        const auto items = m_cache->items(item.parentCollection());
        auto currentItem = item;
        auto parentUid = m_serializer->relatedUidFromItem(currentItem);
        while (!parentUid.isEmpty()) {
            const auto parent = std::find_if(items.cbegin(), items.cend(),
                                             [this, parentUid] (const Akonadi::Item &item) {
                                                 return m_serializer->itemUid(item) == parentUid;
                                             });
            if (parent == items.cend())
                break;

            if (isWorkdayItem(*parent))
                return false;

            currentItem = *parent;
            parentUid = m_serializer->relatedUidFromItem(currentItem);
        }

        return true;
    };
```

#### AUTO 


```{c}
auto artifact = serializer.createNoteFromItem(item);
```

#### AUTO 


```{c}
auto parentId = task->property("parentCollectionId").value<Akonadi::Collection::Id>();
```

#### AUTO 


```{c}
const auto uid = m_serializer->contextUid(contextItem);
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Domain::DataSource::Ptr &source, const QVariant &value, int role) {
        if (role != Qt::CheckStateRole)
            return false;
        if (source->contentTypes() == Domain::DataSource::NoContent)
            return false;

        source->setSelected(value.toInt() == Qt::Checked);
        const auto job = m_dataSourceRepository->update(source);
        if (m_errorHandler)
            m_errorHandler->installHandler(job, tr("Cannot modify source %1").arg(source->name()));
        return true;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[] (const Akonadi::Collection &collection) {
            return collection.name().endsWith("-in");
        }
```

#### AUTO 


```{c}
auto sourcesDock = new QDockWidget(QObject::tr("Sources"));
```

#### AUTO 


```{c}
auto object = deps.create<Interface0>();
```

#### AUTO 


```{c}
auto index = proxy->index(row, 0);
```

#### AUTO 


```{c}
auto cache = Akonadi::Cache::Ptr::create(Akonadi::Serializer::Ptr(new Akonadi::Serializer), monitor);
```

#### AUTO 


```{c}
auto childTask11 = model->data(childTask11Index, Presentation::QueryTreeModelBase::ObjectRole).value<Domain::Task::Ptr>();
```

#### AUTO 


```{c}
auto query = m_findChildren.take(item.id());
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Akonadi::Collection &collection) {
            return m_serializer->isTaskCollection(collection);
        }
```

#### AUTO 


```{c}
auto goNextAction = available.findChild<QAction*>("goNextAction");
```

#### AUTO 


```{c}
auto data = [this](const QObjectPtr &object, int role) -> QVariant {
        if (role != Qt::DisplayRole
         && role != Qt::EditRole
         && role != Qt::DecorationRole
         && role != QueryTreeModelBase::IconNameRole) {
            return QVariant();
        }

        if (role == Qt::EditRole
         && (object == m_inboxObject
          || object == m_workdayObject
          || object == m_projectsObject
          || object == m_contextsObject)) {
            return QVariant();
        }

        if (role == Qt::DisplayRole || role == Qt::EditRole) {
            return object->property("name").toString();
        } else if (role == Qt::DecorationRole || role == QueryTreeModelBase::IconNameRole) {
            const QString iconName = object == m_inboxObject ? "mail-folder-inbox"
                                   : (object == m_workdayObject)  ? "go-jump-today"
                                   : (object == m_projectsObject) ? "folder"
                                   : (object == m_contextsObject) ? "folder"
                                   : "view-pim-tasks";

            if (role == Qt::DecorationRole)
                return QVariant::fromValue(QIcon::fromTheme(iconName));
            else
                return iconName;
        } else {
            return QVariant();
        }
    };
```

#### AUTO 


```{c}
const auto oldItem = m_items.take(item.id());
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QObjectPtr &object, int role, int) -> QVariant {
        if (role != Qt::DisplayRole
         && role != Qt::EditRole
         && role != Qt::DecorationRole
         && role != QueryTreeModelBase::IconNameRole) {
            return QVariant();
        }

        if (role == Qt::EditRole
         && (object == m_inboxObject
          || object == m_tagsObject)) {
            return QVariant();
        }

        if (role == Qt::DisplayRole || role == Qt::EditRole) {
            return object->property("name").toString();
        } else if (role == Qt::DecorationRole || role == QueryTreeModelBase::IconNameRole) {
            const QString iconName = (object == m_inboxObject) ? QStringLiteral("mail-folder-inbox")
                                   : (object == m_tagsObject)  ? QStringLiteral("folder")
                                   : QStringLiteral("view-pim-tasks");

            if (role == Qt::DecorationRole)
                return QVariant::fromValue(QIcon::fromTheme(iconName));
            else
                return iconName;
        } else {
            return QVariant();
        }
    }
```

#### AUTO 


```{c}
auto source = inbox.defaultNoteDataSource();
```

#### AUTO 


```{c}
auto flags = [this](const QObjectPtr &object) {
        const Qt::ItemFlags defaultFlags = Qt::ItemIsSelectable
                                         | Qt::ItemIsEnabled
                                         | Qt::ItemIsEditable
                                         | Qt::ItemIsDropEnabled;
        const Qt::ItemFlags immutableNodeFlags = Qt::ItemIsSelectable
                                               | Qt::ItemIsEnabled
                                               | Qt::ItemIsDropEnabled;
        const Qt::ItemFlags structureNodeFlags = Qt::NoItemFlags;

        return object.objectCast<Domain::Tag>() ? defaultFlags
             : object == m_inboxObject ? immutableNodeFlags
             : structureNodeFlags;
    };
```

#### AUTO 


```{c}
auto flags = [this](const QObjectPtr &object) {
        const Qt::ItemFlags defaultFlags = Qt::ItemIsSelectable
                                         | Qt::ItemIsEnabled
                                         | Qt::ItemIsEditable
                                         | Qt::ItemIsDropEnabled;
        const Qt::ItemFlags immutableNodeFlags = Qt::ItemIsSelectable
                                               | Qt::ItemIsEnabled
                                               | Qt::ItemIsDropEnabled;
        const Qt::ItemFlags structureNodeFlags = Qt::NoItemFlags;

        return object.objectCast<Domain::Project>() ? defaultFlags
             : object.objectCast<Domain::Context>() ? defaultFlags
             : object.objectCast<Domain::Tag>() ? defaultFlags
             : object == m_inboxObject ? immutableNodeFlags
             : structureNodeFlags;
    };
```

#### AUTO 


```{c}
auto job = storage->fetchCollections(collection, depth);
```

#### LAMBDA EXPRESSION 


```{c}
[](const Domain::Task::Ptr &task, int role, const TaskExtraDataPtr &info) {
        return dataForTaskWithProject(task, role, info);
    }
```

#### AUTO 


```{c}
auto fetch = m_helpers->fetchCollections(root, const_cast<DataSourceQueries*>(this));
```

#### AUTO 


```{c}
auto itemFetchJob4 = new Testlib::AkonadiFakeItemFetchJob(this);
```

#### AUTO 


```{c}
auto drop = [this](const QMimeData *mimeData, Qt::DropAction, const Domain::Task::Ptr &parentTask) {
        if (!mimeData->hasFormat(QStringLiteral("application/x-zanshin-object")))
            return false;

        auto droppedTasks = mimeData->property("objects").value<Domain::Task::List>();
        if (droppedTasks.isEmpty())
            return false;

        foreach(const auto &childTask, droppedTasks) {
            if (parentTask) {
                const auto job = m_taskRepository->associate(parentTask, childTask);
                installHandler(job, i18n("Cannot move task %1 as sub-task of %2", childTask->title(), parentTask->title()));
            } else {
                const auto job = m_taskRepository->dissociate(childTask);
                installHandler(job, i18n("Cannot deparent task %1 from its parent", childTask->title()));
            }
        }

        return true;
    };
```

#### AUTO 


```{c}
auto handler = m_jobHandlers.take(job);
```

#### AUTO 


```{c}
const auto types = std::initializer_list<StorageInterface::FetchContentTypes>{
            StorageInterface::AllContent,
            StorageInterface::Tasks,
            StorageInterface::Notes,
            (StorageInterface::Tasks|StorageInterface::Notes)
    };
```

#### AUTO 


```{c}
auto job = new ItemJob(item, parent);
```

#### AUTO 


```{c}
auto childrenList = Domain::QueryResultProvider<Domain::Task::Ptr>::createResult(childrenProvider);
```

#### AUTO 


```{c}
auto result = ArtifactResult::create(provider);
```

#### AUTO 


```{c}
auto query = Domain::LiveQueryOutput<Domain::Task::Ptr>::Ptr();
```

#### AUTO 


```{c}
const auto createdTask = pageModel.addItem(title, parentIndex);
```

#### AUTO 


```{c}
auto project22 = Domain::Project::Ptr::create();
```

#### AUTO 


```{c}
auto data = [](const Domain::Artifact::Ptr &artifact, int role, const AdditionalInfo &projectQueryResult) -> QVariant {
        switch (role) {
            case Qt::DisplayRole:
            case Qt::EditRole:
                return artifact->title();
            case Qt::CheckStateRole:
                if (auto task = artifact.dynamicCast<Domain::Task>()) {
                    return task->isDone() ? Qt::Checked : Qt::Unchecked;
                }
                break;
            case Presentation::QueryTreeModelBase::AdditionalInfoRole:
                if (projectQueryResult && !projectQueryResult->data().isEmpty()) {
                    Domain::Project::Ptr project = projectQueryResult->data().at(0);
                    return i18n("Project: %1", project->name());
                }
                return i18n("Inbox"); // TODO add source name
            default:
                break;
        }
        return QVariant();
    };
```

#### AUTO 


```{c}
auto job = storage->fetchItems(collection);
```

#### LAMBDA EXPRESSION 


```{c}
[] (const Akonadi::Collection &c) {
                return c.rights() == Akonadi::Collection::AllRights;
            }
```

#### AUTO 


```{c}
auto result = queries->findContexts(task);
```

#### AUTO 


```{c}
auto predicate = [] (const Akonadi::Tag &tag) {
            return tag.name().endsWith("-in");
        };
```

#### AUTO 


```{c}
auto model = new QStringListModel(page);
```

#### AUTO 


```{c}
const auto &item
```

#### AUTO 


```{c}
auto notifiedCollection = spy.takeFirst().takeFirst().value<Akonadi::Collection>();
```

#### AUTO 


```{c}
auto job = storage->updateItem(item, nullptr);
```

#### AUTO 


```{c}
auto fetchFunction = fetchItems(parent);
```

#### LAMBDA EXPRESSION 


```{c}
[](const QObjectPtrList &) -> QMimeData* {
        return 0;
    }
```

#### AUTO 


```{c}
auto result = query.result();
```

#### AUTO 


```{c}
const auto email = QInputDialog::getItem(window,
                                             i18n("Choose an identity"),
                                             i18n("Choose the identity to use for the groupware message"),
                                             emails,
                                             defaultIndex,
                                             false);
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Domain::LiveQueryInput<QString>::AddFunction &add) {
            Utils::JobHandler::install(new FakeJob, [this, add] {
                add(QStringLiteral("0"));
                add(QStringLiteral("1"));
                add(QString());
                add(QStringLiteral("a"));
                add(QStringLiteral("2"));
            });
        }
```

#### AUTO 


```{c}
auto query = [this](const Domain::Artifact::Ptr &artifact) -> Domain::QueryResultInterface<Domain::Artifact::Ptr>::Ptr {
        if (!artifact)
            return m_artifactQueries->findInboxTopLevel();
        else if (auto task = artifact.dynamicCast<Domain::Task>())
            return Domain::QueryResult<Domain::Task::Ptr, Domain::Artifact::Ptr>::copy(m_taskQueries->findChildren(task));
        else
            return Domain::QueryResult<Domain::Artifact::Ptr>::Ptr();
    };
```

#### AUTO 


```{c}
auto setData = [this](const Domain::Artifact::Ptr &artifact, const QVariant &value, int role) {
        if (role != Qt::EditRole && role != Qt::CheckStateRole) {
            return false;
        }

        if (auto task = artifact.dynamicCast<Domain::Task>()) {
            if (role == Qt::EditRole)
                task->setTitle(value.toString());
            else
                task->setDone(value.toInt() == Qt::Checked);

            taskRepository()->save(task);
            return true;

        } else if (auto note = artifact.dynamicCast<Domain::Note>()) {
            if (role != Qt::EditRole)
                return false;

            note->setTitle(value.toString());
            noteRepository()->save(note);
            return true;

        }

        return false;
    };
```

#### AUTO 


```{c}
auto job = storage.fetchCollections(Akonadi::Collection::root(),
                                            Akonadi::Storage::Recursive,
                                            Akonadi::Storage::Tasks|Akonadi::Storage::Notes);
```

#### LAMBDA EXPRESSION 


```{c}
[storage, serializer, childItem, childId, parent] (const Domain::LiveQueryInput<Item>::AddFunction &add) {
        auto job = storage->fetchItems(childItem.parentCollection(), parent);
        Utils::JobHandler::install(job->kjob(), [job, add, serializer, childId] {
            if (job->kjob()->error() != KJob::NoError)
                return;

            const auto items = job->items();
            // The item itself is part of the result, we need that in findProject, to react on changes of the item itself
            // To return a correct child item in case it got updated, we can't use childItem, we need to find it in the list.
            const auto myself = std::find_if(items.cbegin(), items.cend(),
                                             [childId] (const Akonadi::Item &item) {
                                                 return childId == item.id();
                                             });
            if (myself == items.cend()) {
                qWarning() << "Did not find item in the listing for its parent collection. Item ID:" << childId;
                return;
            }
            add(*myself);
            auto parentUid = serializer->relatedUidFromItem(*myself);
            while (!parentUid.isEmpty()) {
                const auto parent = std::find_if(items.cbegin(), items.cend(),
                                                 [serializer, parentUid] (const Akonadi::Item &item) {
                                                     return serializer->itemUid(item) == parentUid;
                                                 });
                if (parent == items.cend()) {
                    break;
                }
                add(*parent);
                parentUid = serializer->relatedUidFromItem(*parent);
            }
        });
    }
```

#### AUTO 


```{c}
auto fetch = m_helpers->fetchCollections(root, m_contentTypes);
```

#### AUTO 


```{c}
auto fetchItemsInAllCollectionsFunction(Akonadi::StorageInterface::Ptr storage) {
        return [storage] (const Domain::LiveQueryInput<Akonadi::Item>::AddFunction &add) {
            auto job = storage->fetchCollections(Akonadi::Collection::root(), Akonadi::Storage::Recursive);
            Utils::JobHandler::install(job->kjob(), [add, job, storage] {
                foreach (const auto &col, job->collections()) {
                    auto itemJob = storage->fetchItems(col, nullptr);
                    Utils::JobHandler::install(itemJob->kjob(), [add, itemJob] {
                        foreach (const auto &item, itemJob->items())
                            add(item);
                    });
                }
            });
        };
    }
```

#### AUTO 


```{c}
auto noteQueries = Domain::NoteQueries::Ptr();
```

#### AUTO 


```{c}
auto repo = deps.create<Domain::DataSourceRepository>();
```

#### AUTO 


```{c}
auto fetchItemsInSelectedCollectionsFunction(Akonadi::StorageInterface::Ptr storage, Akonadi::SerializerInterface::Ptr serializer)
    {
        return [storage, serializer] (const Domain::LiveQueryInput<Akonadi::Item>::AddFunction &add) {
            auto job = storage->fetchCollections(Akonadi::Collection::root(), Akonadi::Storage::Recursive);
            Utils::JobHandler::install(job->kjob(), [add, job, storage, serializer] {
                foreach (const auto &col, job->collections()) {
                    if (!serializer->isSelectedCollection(col))
                        continue;

                    auto itemJob = storage->fetchItems(col);
                    Utils::JobHandler::install(itemJob->kjob(), [add, itemJob] {
                        foreach (const auto &item, itemJob->items())
                            add(item);
                    });
                }
            });
        };
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
            compositeJob->emitError(QStringLiteral("Error reached"));
        }
```

#### AUTO 


```{c}
auto movedItem = spyMoved.takeFirst().at(0).value<Akonadi::Item>();
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Akonadi::Item &item) {
        return m_serializer->isTaskItem(item);
    }
```

#### AUTO 


```{c}
auto sourceListModel = availableSources->property("sourceListModel").value<QAbstractItemModel*>();
```

#### AUTO 


```{c}
auto sourceC = Domain::DataSource::Ptr::create();
```

#### LAMBDA EXPRESSION 


```{c}
[this] { return dataSources(); }
```

#### AUTO 


```{c}
auto drag = [] (const Domain::Note::List &notes) -> QMimeData* {
        if (notes.isEmpty())
            return Q_NULLPTR;

        auto draggedArtifacts = Domain::Artifact::List();
        std::copy(notes.constBegin(), notes.constEnd(),
                  std::back_inserter(draggedArtifacts));

        auto data = new QMimeData;
        data->setData("application/x-zanshin-object", "object");
        data->setProperty("objects", QVariant::fromValue(draggedArtifacts));
        return data;
    };
```

#### AUTO 


```{c}
auto parent = collection.parentCollection();
```

#### AUTO 


```{c}
auto margins = layout->contentsMargins();
```

#### LAMBDA EXPRESSION 


```{c}
[fetchParentItemJob, child, childItem, job, this] {
            if (fetchParentItemJob->kjob()->error() != KJob::NoError)
                return;

            Q_ASSERT(fetchParentItemJob->items().size() == 1);
            auto parentItem = fetchParentItemJob->items().at(0);

            const int itemCollectionId = childItem.parentCollection().id();
            const int parentCollectionId = parentItem.parentCollection().id();

            if (itemCollectionId != parentCollectionId) {
                ItemFetchJobInterface *fetchChildrenItemJob = m_storage->fetchItems(childItem.parentCollection());
                job->install(fetchChildrenItemJob->kjob(), [fetchChildrenItemJob, childItem, parentItem, job, this] {
                    if (fetchChildrenItemJob->kjob()->error() != KJob::NoError)
                        return;

                    Item::List childItems = m_serializer->filterDescendantItems(fetchChildrenItemJob->items(), childItem);

                    auto transaction = m_storage->createTransaction();
                    m_storage->updateItem(childItem, transaction);
                    childItems.push_front(childItem);
                    m_storage->moveItems(childItems, parentItem.parentCollection(), transaction);
                    job->addSubjob(transaction);
                    transaction->start();
                });
            } else {
                auto updateJob = m_storage->updateItem(childItem);
                job->addSubjob(updateJob);
                updateJob->start();
            }
        }
```

#### AUTO 


```{c}
const auto itemId
```

#### AUTO 


```{c}
auto selectedIndexes = page.selectedIndexes();
```

#### AUTO 


```{c}
auto tagId = context->property("tagId").value<Akonadi::Tag::Id>();
```

#### AUTO 


```{c}
auto depthLessThan = [&depth] (const Akonadi::Collection &left, const Akonadi::Collection &right) {
        return depth(left) < depth(right);
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (auto task : taskList->data()) {
        Node *node = new Node(task, 0, m_queries, this);
        m_rootNodes.append(node);
    }
```

#### AUTO 


```{c}
auto childrenProvider = Domain::QueryResultProvider<Domain::Task::Ptr>::Ptr::create();
```

#### AUTO 


```{c}
auto note = data.value<Domain::Note::Ptr>();
```

#### AUTO 


```{c}
auto actions = actionsForSource(source, true);
```

#### LAMBDA EXPRESSION 


```{c}
[&](const Domain::Task::Ptr &task, const QVariant &value, int role) {
        if (role != Qt::EditRole && role != Qt::CheckStateRole) {
            return false;
        }

        if (role == Qt::EditRole) {
            task->setTitle(value.toString());
        } else {
            task->setDone(value.toInt() == Qt::Checked);
        }

        repository->update(task);
        return true;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto collection : job->collections()) {
            ItemFetchJobInterface *job = m_storage->fetchItems(collection);
            Utils::JobHandler::install(job->kjob(), [provider, job, this] {
                if (job->kjob()->error() != KJob::NoError)
                    return;

                for (auto item : job->items()) {
                    auto task = deserializeTask(item);
                    if (task)
                        provider->append(task);
                }
            });
        }
```

#### AUTO 


```{c}
const auto summaryMetrics = QFontMetrics(summaryFont);
```

#### AUTO 


```{c}
auto dragFunction = [] (const QList<QColor> &) -> QMimeData* {
            return 0;
        };
```

#### AUTO 


```{c}
auto source1Result = Domain::QueryResult<Domain::DataSource::Ptr>::create(source1Provider);
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Item &contextItem) {
        const auto uid = m_serializer->contextUid(contextItem);
        if (!uid.isEmpty())
            m_findToplevel.remove(uid);
    }
```

#### AUTO 


```{c}
auto attachments = task->attachments();
```

#### AUTO 


```{c}
auto todo = serializer->createTaskFromItem(cache->item(items.at(0).id()));
```

#### AUTO 


```{c}
const auto allTags = job.tags();
```

#### AUTO 


```{c}
const auto currentName = project->name();
```

#### AUTO 


```{c}
auto addContextAction = available.findChild<QAction*>(QStringLiteral("addContextAction"));
```

#### AUTO 


```{c}
auto sourcesDock = new QDockWidget(i18n("Sources"));
```

#### AUTO 


```{c}
auto model = new Presentation::ArtifactEditorModel(&taskRepositoryMock.getInstance(),
                                                           &noteRepositoryMock.getInstance());
```

#### AUTO 


```{c}
const auto tags = cache->tags();
```

#### LAMBDA EXPRESSION 


```{c}
[provider, job, this] {
                if (job->kjob()->error() != KJob::NoError)
                    return;

                for (auto item : job->items()) {
                    if (m_serializer->relatedUidFromItem(item).isEmpty()) {
                        auto task = deserializeTask(item);
                        if (task)
                            provider->append(task);
                    }
                }
            }
```

#### AUTO 


```{c}
auto fetch = m_helpers->fetchItems(const_cast<ContextQueries*>(this));
```

#### AUTO 


```{c}
auto setData = [this](const QObjectPtr &object, const QVariant &value, int role) {
        if (role != Qt::EditRole) {
            return false;
        }

        if (object == m_inboxObject
         || object == m_projectsObject
         || object == m_contextsObject
         || object == m_tagsObject) {
            return false;
        }

        if (auto project = object.objectCast<Domain::Project>()) {
            const auto currentName = project->name();
            project->setName(value.toString());
            const auto job = m_projectRepository->update(project);
            installHandler(job, tr("Cannot modify project %1").arg(currentName));
        } else if (auto context = object.objectCast<Domain::Context>()) {
            const auto currentName = context->name();
            context->setName(value.toString());
            const auto job = m_contextRepository->update(context);
            installHandler(job, tr("Cannot modify context %1").arg(currentName));
        } else if (object.objectCast<Domain::Tag>()) {
            return false; // Tag renaming is NOT allowed
        } else {
            Q_ASSERT(false);
        }

        return true;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Collection &collection) {
                     return m_serializer->isTaskCollection(collection);
                 }
```

#### AUTO 


```{c}
const auto defaultIndex = emails.indexOf(identities.defaultIdentity().fullEmailAddr());
```

#### LAMBDA EXPRESSION 


```{c}
[=] (const Akonadi::Item &item) {
                                         return m_data->item(item.id()).isValid();
                                     }
```

#### AUTO 


```{c}
auto taskResult = Domain::QueryResult<Domain::Task::Ptr>::create(taskProvider);
```

#### AUTO 


```{c}
auto handler = [&]() {
            callCount++;
        };
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Tag &tag : tags) {
            if (tag.gid() == gid)
                return tag;
        }
```

#### AUTO 


```{c}
auto rootTask = model->data(index, Presentation::QueryTreeModelBase::ObjectRole).value<Domain::Task::Ptr>();
```

#### AUTO 


```{c}
auto job = m_storage->fetchCollections(Akonadi::Collection::root(),
                                                   Akonadi::StorageInterface::Recursive);
```

#### LAMBDA EXPRESSION 


```{c}
[] (const Akonadi::Tag &tag) {
            return tag.name().endsWith("-ex");
        }
```

#### AUTO 


```{c}
auto flagsFunction = [](const QColor &) {
            return Qt::NoItemFlags;
        };
```

#### AUTO 


```{c}
auto task = m_serializer->createTaskFromItem(item);
```

#### LAMBDA EXPRESSION 


```{c}
[collectionName, types] (const Akonadi::Collection &col) {
                     const auto mime = col.contentMimeTypes().toSet();
                     auto contentMimeTypes = QSet<QString>();
                     if (types & Notes)
                         contentMimeTypes << Akonadi::NoteUtils::noteMimeType();
                     if (types & Tasks)
                         contentMimeTypes << KCalCore::Todo::todoMimeType();

                     const bool supportedType = contentMimeTypes.isEmpty()
                                             || !(mime & contentMimeTypes).isEmpty();
                     return supportedType && col.displayName().contains(collectionName, Qt::CaseInsensitive);
                 }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &cleanupFunction : qAsConst(m_cleanupFunctions)) {
        cleanupFunction(this);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QMimeData *mimeData, Qt::DropAction, const Domain::Artifact::Ptr &artifact) {
        auto parentTask = artifact.objectCast<Domain::Task>();

        if (!mimeData->hasFormat(QStringLiteral("application/x-zanshin-object")))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                        [](const Domain::Artifact::Ptr &droppedArtifact) {
                            return !droppedArtifact.objectCast<Domain::Task>();
                        })) {
            return false;
        }

        foreach(const auto &droppedArtifact, droppedArtifacts) {
            auto childTask = droppedArtifact.objectCast<Domain::Task>();

            if (parentTask) {
                const auto job = m_taskRepository->associate(parentTask, childTask);
                installHandler(job, i18n("Cannot move task %1 as sub-task of %2", childTask->title(), parentTask->title()));
            } else {
                childTask->setStartDate(Utils::DateTime::currentDateTime());

                auto job = m_taskRepository->update(childTask);
                installHandler(job, i18n("Cannot update task %1", childTask->title()));

                job = m_taskRepository->dissociate(childTask);
                installHandler(job, i18n("Cannot deparent task %1 from its parent", childTask->title()));
            }
        }

        return true;
    }
```

#### AUTO 


```{c}
auto taskQueries = Domain::TaskQueries::Ptr();
```

#### AUTO 


```{c}
auto inQuery = Domain::LiveQueryOutput<Domain::Project::Ptr>::Ptr();
```

#### AUTO 


```{c}
auto filterAction = page.findChild<QAction*>("filterViewAction");
```

#### LAMBDA EXPRESSION 


```{c}
[] (const QList<QColor> &) -> QMimeData* {
            return 0;
        }
```

#### AUTO 


```{c}
auto notifiedTag = spy.takeFirst().takeFirst().value<Akonadi::Tag>();
```

#### LAMBDA EXPRESSION 


```{c}
[] (const QColor &, int, int) {
            return QVariant();
        }
```

#### AUTO 


```{c}
auto fetch = m_helpers->fetchSiblings(item, const_cast<ProjectQueries*>(this));
```

#### AUTO 


```{c}
auto monitor = Utils::DependencyManager::globalInstance().create<Akonadi::MonitorInterface>();
```

#### RANGE FOR STATEMENT 


```{c}
for (Akonadi::Tag tag : job->tags())
                    add(tag);
```

#### AUTO 


```{c}
auto note1 = Domain::Note::Ptr::create();
```

#### AUTO 


```{c}
auto task = m_artifact.objectCast<Domain::Task>();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto item : job->items())
                            add(item);
```

#### LAMBDA EXPRESSION 


```{c}
[this] { return taskSources(); }
```

#### AUTO 


```{c}
const auto newSelected = newAttribute ? newAttribute->isSelected() : true;
```

#### AUTO 


```{c}
auto artifact = serializer.createArtifactFromItem(item).dynamicCast<Domain::Task>();
```

#### AUTO 


```{c}
auto collection = GenCollection().withId(colId).withRootAsParent().withTaskContent();
```

#### LAMBDA EXPRESSION 


```{c}
[storage] (const Domain::LiveQueryInput<Akonadi::Item>::AddFunction &add) {
            auto job = storage->fetchCollections(Akonadi::Collection::root(), Akonadi::Storage::Recursive, Akonadi::Storage::AllContent);
            Utils::JobHandler::install(job->kjob(), [add, job, storage] {
                foreach (const auto &col, job->collections()) {
                    auto itemJob = storage->fetchItems(col);
                    Utils::JobHandler::install(itemJob->kjob(), [add, itemJob] {
                        foreach (const auto &item, itemJob->items())
                            add(item);
                    });
                }
            });
        }
```

#### AUTO 


```{c}
auto runningTaskView = new RunningTaskWidget(m_parent);
```

#### AUTO 


```{c}
auto proxyModel = qobject_cast<Presentation::ArtifactFilterProxyModel*>(centralView->model());
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QMimeData *mimeData, Qt::DropAction, const Domain::Artifact::Ptr &artifact) {
        auto parentTask = artifact.objectCast<Domain::Task>();

        if (!mimeData->hasFormat("application/x-zanshin-object"))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                        [](const Domain::Artifact::Ptr &droppedArtifact) {
                            return !droppedArtifact.objectCast<Domain::Task>();
                        })) {
            return false;
        }

        foreach(const auto &droppedArtifact, droppedArtifacts) {
            auto childTask = droppedArtifact.objectCast<Domain::Task>();

            if (parentTask) {
                const auto job = taskRepository()->associate(parentTask, childTask);
                installHandler(job, tr("Cannot move task %1 as sub-task of %2").arg(childTask->title()).arg(parentTask->title()));
            } else {
                const auto job = taskRepository()->dissociate(childTask);
                installHandler(job, tr("Cannot deparent task %1 from its parent").arg(childTask->title()));
            }
        }

        return true;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](QWidget*) { return "/tmp/foobar"; }
```

#### AUTO 


```{c}
auto drop = [this](const QMimeData *mimeData, Qt::DropAction, const Domain::Artifact::Ptr &artifact) {
        auto parentTask = artifact.objectCast<Domain::Task>();
        if (!parentTask)
            return false;

        if (!mimeData->hasFormat("application/x-zanshin-object"))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                        [](const Domain::Artifact::Ptr &droppedArtifact) {
                            return !droppedArtifact.objectCast<Domain::Task>();
                        })) {
            return false;
        }

        foreach(const auto &droppedArtifact, droppedArtifacts) {
            auto childTask = droppedArtifact.objectCast<Domain::Task>();
            taskRepository()->associate(parentTask, childTask);
        }

        return true;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[](const Domain::Note::Ptr &note, int role) -> QVariant {
        if (role == Qt::DisplayRole || role == Qt::EditRole) {
            return note->title();
        } else {
            return QVariant();
        }
    }
```

#### AUTO 


```{c}
auto derivedResult = QueryResult<Derived::Ptr>::create(provider);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Domain::Task::Ptr &, int) {
                                         endRemoveRows();
                                     }
```

#### AUTO 


```{c}
auto fetch = m_helpers->fetchItems(const_cast<ProjectQueries*>(this));
```

#### AUTO 


```{c}
auto query = TaskQuery::Ptr::create();
```

#### AUTO 


```{c}
auto dragFunction = [] (const QColor &) -> QMimeData* {
            return 0;
        };
```

#### AUTO 


```{c}
auto dataSource = serializer.createDataSourceFromCollection(collection);
```

#### AUTO 


```{c}
auto expectedText = tr("Delegated to: <b>%1</b>").arg(model.property("delegateText").toString());
```

#### AUTO 


```{c}
auto exPredicate = [] (const Akonadi::Tag &tag) {
            return tag.name().endsWith("-ex");
        };
```

#### AUTO 


```{c}
auto query = [this](const QObjectPtr &object) -> Domain::QueryResultInterface<QObjectPtr>::Ptr {
        if (!object)
            return Domain::QueryResult<QObjectPtr>::create(m_rootsProvider);
        else if (object == m_projectsObject)
            return Domain::QueryResult<Domain::Project::Ptr, QObjectPtr>::copy(m_projectQueries->findAll());
        else
            return Domain::QueryResult<QObjectPtr>::Ptr();
    };
```

#### LAMBDA EXPRESSION 


```{c}
[&afterReset] (QObject *object) {
            if (afterReset)
                return object->objectName().startsWith(QLatin1String("Item"));
            else
                return object->objectName().startsWith(QLatin1String("Project"));
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QMimeData *mimeData, Qt::DropAction, const Domain::Artifact::Ptr &artifact) {
        auto parentTask = artifact.objectCast<Domain::Task>();

        if (!mimeData->hasFormat("application/x-zanshin-object"))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                        [](const Domain::Artifact::Ptr &droppedArtifact) {
                            return !droppedArtifact.objectCast<Domain::Task>();
                        })) {
            return false;
        }

        foreach(const auto &droppedArtifact, droppedArtifacts) {
            auto childTask = droppedArtifact.objectCast<Domain::Task>();

            if (parentTask) {
                const auto job = m_taskRepository->associate(parentTask, childTask);
                installHandler(job, tr("Cannot move task %1 as sub-task of %2").arg(childTask->title()).arg(parentTask->title()));
            } else {
                const auto job = m_taskRepository->dissociate(childTask);
                installHandler(job, tr("Cannot deparent task %1 from its parent").arg(childTask->title()));
            }
        }

        return true;
    }
```

#### AUTO 


```{c}
auto job = storage->fetchItem(item1);
```

#### AUTO 


```{c}
auto relatedUid = m_serializer->relatedUidFromItem(parentItem);
```

#### AUTO 


```{c}
auto job = m_storage->fetchItem(m_item, this);
```

#### AUTO 


```{c}
auto job = m_storage->fetchCollections(Akonadi::Collection::root(),
                                               StorageInterface::Recursive,
                                               contentTypes);
```

#### AUTO 


```{c}
const auto contextUids = todo->customProperty(Serializer::customPropertyAppName(), Serializer::customPropertyContextList()).split(',', QString::SkipEmptyParts);
```

#### AUTO 


```{c}
auto tags = item.tags();
```

#### LAMBDA EXPRESSION 


```{c}
[&items] (const Akonadi::Item &item) {
            items.append(item);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[] (const QMimeData *mimeData, Qt::DropAction, const Domain::DataSource::Ptr &source) {
        Q_UNUSED(mimeData)
        Q_UNUSED(source)
        return false;
    }
```

#### AUTO 


```{c}
auto appModel = new ApplicationModel(new Akonadi::ArtifactQueries(this),
                                             new Akonadi::DataSourceQueries(this),
                                             new Akonadi::TaskQueries(this),
                                             new Akonadi::TaskRepository(this),
                                             new Akonadi::NoteRepository(this),
                                             this);
```

#### AUTO 


```{c}
auto task = childProvider->takeFirst();
```

#### AUTO 


```{c}
auto drag = [](const QObjectPtr &) -> QMimeData* {
        return 0;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[=] {
            m_data->modifyTag(tag);
        }
```

#### AUTO 


```{c}
auto source1Provider = Domain::QueryResultProvider<Domain::DataSource::Ptr>::Ptr::create();
```

#### AUTO 


```{c}
auto setDataFunction = [] (const QString &, const QVariant &, int) {
            return false;
        };
```

#### AUTO 


```{c}
auto fetch = helpers->searchCollections(root, &term, Akonadi::StorageInterface::Tasks | Akonadi::StorageInterface::Notes);
```

#### AUTO 


```{c}
auto topLevelProvider = Domain::QueryResultProvider<Domain::Task::Ptr>::Ptr::create();
```

#### AUTO 


```{c}
auto job = createStorage()->fetchItem(item);
```

#### AUTO 


```{c}
const auto index = m_collections.indexOf(collection);
```

#### LAMBDA EXPRESSION 


```{c}
[root, job, add] {
            if (job->kjob()->error())
                return;

            auto directChildren = QHash<Collection::Id, Collection>();
            foreach (const auto &collection, job->collections()) {
                auto directChild = collection;
                while (directChild.parentCollection() != root && directChild.parentCollection().isValid())
                    directChild = directChild.parentCollection();
                if (directChild.parentCollection() != root)
                    continue;
                if (!directChildren.contains(directChild.id()))
                    directChildren[directChild.id()] = directChild;
            }

            foreach (const auto &directChild, directChildren)
                add(directChild);
        }
```

#### AUTO 


```{c}
auto tagQueries = Domain::TagQueries::Ptr();
```

#### AUTO 


```{c}
auto impl = object.dynamicCast<AnotherSecondImplementation>();
```

#### AUTO 


```{c}
auto expectedIds = QVector<Akonadi::Item::Id>() << 42 << 45 << 52;
```

#### LAMBDA EXPRESSION 


```{c}
[&](const Domain::Task::Ptr &task) {
        if (!task)
            return queries.findTopLevel();
        else
            return queries.findChildren(task);
    }
```

#### AUTO 


```{c}
auto drag = [](const Domain::Artifact::List &artifacts) -> QMimeData* {
        Q_UNUSED(artifacts);
        qFatal("Not implemented yet");
        return Q_NULLPTR;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[storage, collection] (const Domain::LiveQueryInput<Akonadi::Item>::AddFunction &add) {
            auto job = storage->fetchItems(collection);
            Utils::JobHandler::install(job->kjob(), [add, job] {
                foreach (const auto &item, job->items()) {
                    add(item);
                }
            });
        }
```

#### AUTO 


```{c}
auto jobType = CollectionJob::Base;
```

#### AUTO 


```{c}
auto data = [](const Domain::Artifact::Ptr &artifact, int role) -> QVariant {
        if (role != Qt::DisplayRole
         && role != Qt::EditRole
         && role != Qt::CheckStateRole) {
            return QVariant();
        }

        if (role == Qt::DisplayRole || role == Qt::EditRole) {
            return artifact->title();
        } else if (auto task = artifact.dynamicCast<Domain::Task>()) {
            return task->isDone() ? Qt::Checked : Qt::Unchecked;
        } else {
            return QVariant();
        }
    };
```

#### AUTO 


```{c}
const auto items = cache->items(Akonadi::Tag(43));
```

#### AUTO 


```{c}
auto akqueries = new Akonadi::TaskQueries(createCachingStorage(data, cache),
                                                      Akonadi::Serializer::Ptr(new Akonadi::Serializer),
                                                      Akonadi::MonitorInterface::Ptr(data.createMonitor()),
                                                      cache);
```

#### AUTO 


```{c}
auto fetchAdditionalInfo = [this](const QModelIndex &index, const Domain::Artifact::Ptr &artifact) -> AdditionalInfo {
        if (auto task = artifact.dynamicCast<Domain::Task>()) {
            AdditionalInfo projectQueryResult = m_taskQueries->findProject(task);
            if (projectQueryResult) {
                QPersistentModelIndex persistentIndex(index);
                projectQueryResult->addPostInsertHandler([persistentIndex](const Domain::Project::Ptr &, int) {
                    // When a project was found (inserted into the result), update the rendering of the item
                    auto model = const_cast<QAbstractItemModel *>(persistentIndex.model());
                    model->dataChanged(persistentIndex, persistentIndex);
                });
            }
            return projectQueryResult;
        }
        return nullptr;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Domain::Task::Ptr &, int) {
                                         endInsertRows();
                                     }
```

#### AUTO 


```{c}
auto job = storage->fetchItems(calendar2(), nullptr);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Domain::Task::Ptr &task) -> Domain::QueryResultInterface<Domain::Task::Ptr>::Ptr {
        if (!task)
            return m_taskQueries->findTopLevel();
        else
            return m_taskQueries->findChildren(task);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[repository] (const Domain::Artifact::Ptr &artifact) {
            auto note = artifact.objectCast<Domain::Note>();
            Q_ASSERT(note);
            return repository->update(note);
        }
```

#### AUTO 


```{c}
auto itemA = new QStandardItem(QStringLiteral("A"));
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QMimeData *mimeData, Qt::DropAction, const QObjectPtr &object) {
        if (!mimeData->hasFormat("application/x-zanshin-object"))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (auto project = object.objectCast<Domain::Project>()) {
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                const auto job = m_projectRepository->associate(project, droppedArtifact);
                installHandler(job, tr("Cannot add %1 to project %2").arg(droppedArtifact->title()).arg(project->name()));
            }
            return true;
        } else if (auto context = object.objectCast<Domain::Context>()) {
            if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                            [](const Domain::Artifact::Ptr &droppedArtifact) {
                                return !droppedArtifact.objectCast<Domain::Task>();
                            })) {
                return false;
            }
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                auto task = droppedArtifact.staticCast<Domain::Task>();
                const auto job = m_contextRepository->associate(context, task);
                installHandler(job, tr("Cannot add %1 to context %2").arg(task->title()).arg(context->name()));
            }
            return true;
        } else if (object == m_inboxObject) {
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                const auto job = m_projectRepository->dissociate(droppedArtifact);
                installHandler(job, tr("Cannot move %1 to Inbox").arg(droppedArtifact->title()));

                if (auto task = droppedArtifact.objectCast<Domain::Task>()) {
                    Utils::JobHandler::install(job, [this, task] {
                        const auto dissociateJob = m_taskRepository->dissociateAll(task);
                        installHandler(dissociateJob, tr("Cannot move task %1 to Inbox").arg(task->title()));
                    });
                }
            }
            return true;
        } else if (object == m_workdayObject) {
            foreach (const auto &droppedArtifact, droppedArtifacts) {

                if (auto task = droppedArtifact.objectCast<Domain::Task>()) {

                    task->setStartDate(Utils::DateTime::currentDateTime());
                    const auto job = m_taskRepository->update(task);

                    installHandler(job, tr("Cannot update task %1 to Workday").arg(task->title()));
                }
            }
            return true;
        }

        return false;
    }
```

#### AUTO 


```{c}
const auto itemFetchIds = [job, toItemIds]{
                return toItemIds(job->items());
            }();
```

#### AUTO 


```{c}
auto data = [](const Domain::Task::Ptr &task, int role, const TaskExtraDataPtr &info) -> QVariant {
        return defaultTaskData(task, role, info);
    };
```

#### AUTO 


```{c}
auto setData = [this](const QObjectPtr &object, const QVariant &value, int role) {
        if (role != Qt::EditRole) {
            return false;
        }

        if (object == m_inboxObject
         || object == m_projectsObject
         || object == m_contextsObject
         || object == m_tagsObject) {
            return false;
        }

        if (auto project = object.objectCast<Domain::Project>()) {
            const auto currentName = project->name();
            project->setName(value.toString());
            const auto job = m_projectRepository->update(project);
            if (!errorHandler())
                return true;

            errorHandler()->installHandler(job, tr("Cannot modify project %1").arg(currentName));
        } else if (auto context = object.objectCast<Domain::Context>()) {
            const auto currentName = context->name();
            context->setName(value.toString());
            const auto job = m_contextRepository->update(context);
            if (!errorHandler())
                return true;

            errorHandler()->installHandler(job, tr("Cannot modify context %1").arg(currentName));
        } else if (object.objectCast<Domain::Tag>()) {
            return false; // Tag renaming is NOT allowed
        } else {
            Q_ASSERT(false);
        }

        return true;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this] (Akonadi::Collection::Id id) {
                       Q_ASSERT(m_collections.contains(id));
                       return m_collections.value(id);
                   }
```

#### AUTO 


```{c}
auto predicate = [this] (const Item &item) {
        return m_serializer->isNoteItem(item);
    };
```

#### AUTO 


```{c}
const auto additionalInfo = projectInfo.isValid() && !projectInfo.toString().isEmpty() ? i18n("Project: %1", projectInfo.toString())
                                  : dataSourceInfo.isValid() ? dataSourceInfo.toString()
                                  : i18n("Inbox");
```

#### AUTO 


```{c}
auto task = page.addItem(title);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &item : items) {
            itemRemoteIds << item.remoteId();

            QVERIFY(item.loadedPayloadParts().contains(Akonadi::Item::FullPayload));
            QVERIFY(!item.attributes().isEmpty());
            QVERIFY(item.modificationTime().isValid());
            QVERIFY(!item.flags().isEmpty());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &item : itemJob->items()) {
            QString summary;
            if (item.hasPayload<KCalCore::Todo::Ptr>())
                summary = item.payload<KCalCore::Todo::Ptr>()->summary();
            qDebug() << "\tITEM:" << item.id() << item.remoteId() << summary;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Akonadi::Item &item) {
        const bool excluded = !m_serializer->isTaskItem(item)
                           || !m_serializer->relatedUidFromItem(item).isEmpty()
                           || m_serializer->hasContextTags(item);

        return !excluded;
    }
```

#### AUTO 


```{c}
const auto &tag
```

#### AUTO 


```{c}
auto task = data.value<Domain::Task::Ptr>();
```

#### LAMBDA EXPRESSION 


```{c}
[](const Domain::Note::Ptr &note, int role, int) -> QVariant {
        if (role == Qt::DisplayRole || role == Qt::EditRole) {
            return note->title();
        } else {
            return QVariant();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto collection : job->collections()) {
            ItemFetchJobInterface *job = m_storage->fetchItems(collection);
            Utils::JobHandler::install(job->kjob(), [provider, job, this] {
                for (auto item : job->items()) {
                    auto task = deserializeTask(item);
                    if (task)
                        provider->append(task);
                }
            });
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, add] {
                add(createObject(0, QStringLiteral("ProjectA")));
                add(createObject(1, QStringLiteral("ItemA")));
                add(createObject(2, QStringLiteral("ParentA")));
                add(createObject(3, QStringLiteral("ProjectB")));
                add(createObject(4, QStringLiteral("ItemB")));
                add(createObject(5, QStringLiteral("ParentB")));
                add(createObject(6, QStringLiteral("ProjectC")));
                add(createObject(7, QStringLiteral("ItemC")));
                add(createObject(8, QStringLiteral("ParentC")));
            }
```

#### LAMBDA EXPRESSION 


```{c}
[cache, toTagNames]{
                const auto tags = cache->tags();
                return toTagNames(tags);
            }
```

#### AUTO 


```{c}
auto job = new CollectionJob(collection, jobTypeFromDepth(depth), parent);
```

#### AUTO 


```{c}
auto notifiedCollection= spy.takeFirst().takeFirst().value<Akonadi::Collection>();
```

#### AUTO 


```{c}
auto task = childrenTasks.at(i);
```

#### LAMBDA EXPRESSION 


```{c}
[provider, job, this] {
        if (job->kjob()->error() != KJob::NoError)
            return;

        for (auto collection : job->collections()) {
            ItemFetchJobInterface *job = m_storage->fetchItems(collection);
            Utils::JobHandler::install(job->kjob(), [provider, job, this] {
                if (job->kjob()->error() != KJob::NoError)
                    return;

                for (auto item : job->items()) {
                    if (!isInboxItem(item))
                        continue;

                    auto artifact = deserializeArtifact(item);
                    if (artifact)
                        provider->append(artifact);
                }
            });
        }
    }
```

#### AUTO 


```{c}
const auto itemCachedIds = [cache, toItemIds]{
                const auto items = cache->items(Akonadi::Collection(42));
                return toItemIds(items);
            }();
```

#### AUTO 


```{c}
const auto recurrence = ui->recurrenceCombo->itemData(index).value<Domain::Task::Recurrence>();
```

#### AUTO 


```{c}
const auto job = m_contextRepository->remove(context);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Tag &tag : tags) {
        tagGids << tag.gid();
        QVERIFY(!tag.name().isEmpty());
        QVERIFY(!tag.type().isEmpty());
    }
```

#### AUTO 


```{c}
auto delegate = Domain::Task::Delegate();
```

#### AUTO 


```{c}
auto task = inbox.addTask(title);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QObjectPtr &object, const QVariant &value, int role) {
        if (role != Qt::EditRole) {
            return false;
        }

        if (object == m_inboxObject
         || object == m_workdayObject
         || object == m_projectsObject
         || object == m_contextsObject
         || object == m_tagsObject) {
            return false;
        }

        if (auto project = object.objectCast<Domain::Project>()) {
            const auto currentName = project->name();
            project->setName(value.toString());
            const auto job = m_projectRepository->update(project);
            installHandler(job, tr("Cannot modify project %1").arg(currentName));
        } else if (auto context = object.objectCast<Domain::Context>()) {
            const auto currentName = context->name();
            context->setName(value.toString());
            const auto job = m_contextRepository->update(context);
            installHandler(job, tr("Cannot modify context %1").arg(currentName));
        } else if (object.objectCast<Domain::Tag>()) {
            return false; // Tag renaming is NOT allowed
        } else {
            Q_ASSERT(false);
        }

        return true;
    }
```

#### AUTO 


```{c}
auto job = storage->fetchTags();
```

#### AUTO 


```{c}
const auto data = centralListModel->mimeData(droppedItems);
```

#### AUTO 


```{c}
const auto itemCachedIds = toItemIds(items);
```

#### AUTO 


```{c}
auto attribute = new Akonadi::EntityDisplayAttribute;
```

#### AUTO 


```{c}
auto result = Akonadi::Item::List();
```

#### AUTO 


```{c}
const auto &oldTag
```

#### AUTO 


```{c}
auto query = Domain::LiveQuery<QString, QObject*>();
```

#### LAMBDA EXPRESSION 


```{c}
[this, root, job, add] {
                if (job->kjob()->error())
                    return;

                QHash<Collection::Id, Collection> children;
                foreach (const auto &collection, job->collections()) {
                    auto child = collection;
                    while (child.parentCollection() != root && child.parentCollection().isValid())
                        child = child.parentCollection();
                    if (!children.contains(child.id()))
                        children[child.id()] = child;
                }

                foreach (const auto &topLevel, children.values())
                    add(topLevel);
            }
```

#### AUTO 


```{c}
auto it = std::find_if(items.constBegin(), items.constEnd(),
                                       [relatedUid, this] (const Akonadi::Item &item) {
                    // TODO Qt5: This is a bit wasteful, add an itemUid on the serializer
                    auto task = m_serializer->createTaskFromItem(item);
                    return task && m_serializer->objectUid(task) == relatedUid;
                });
```

#### LAMBDA EXPRESSION 


```{c}
[collectionsMap, &reconstructAncestors, this] (const Collection &collection) {
            Q_ASSERT(collection.isValid());

            if (collection == Akonadi::Collection::root())
                return collection;

            auto parent = collection.parentCollection();
            auto reconstructedParent = reconstructAncestors(collectionsMap[parent.id()]);

            auto result = collection;
            result.setParentCollection(reconstructedParent);
            return result;
        }
```

#### AUTO 


```{c}
auto serializer = Akonadi::Serializer::Ptr(new Akonadi::Serializer);
```

#### LAMBDA EXPRESSION 


```{c}
[&depth] (const Akonadi::Collection &left, const Akonadi::Collection &right) {
        return depth(left) < depth(right);
    }
```

#### AUTO 


```{c}
auto item = createTaskSourceItem(name, parent);
```

#### LAMBDA EXPRESSION 


```{c}
[cache, toItemIds]{
                const auto items = cache->items(Akonadi::Collection(42));
                return toItemIds(items);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QMimeData *mimeData, Qt::DropAction, const QObjectPtr &object) {
        if (!mimeData->hasFormat("application/x-zanshin-object"))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (auto project = object.objectCast<Domain::Project>()) {
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                const auto job = m_projectRepository->associate(project, droppedArtifact);
                installHandler(job, tr("Cannot add %1 to project %2").arg(droppedArtifact->title()).arg(project->name()));
            }
            return true;
        } else if (auto context = object.objectCast<Domain::Context>()) {
            if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                            [](const Domain::Artifact::Ptr &droppedArtifact) {
                                return !droppedArtifact.objectCast<Domain::Task>();
                            })) {
                return false;
            }
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                auto task = droppedArtifact.staticCast<Domain::Task>();
                const auto job = m_contextRepository->associate(context, task);
                installHandler(job, tr("Cannot add %1 to context %2").arg(task->title()).arg(context->name()));
            }
            return true;
        } else if (auto tag = object.objectCast<Domain::Tag>()) {
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                const auto job = m_tagRepository->associate(tag, droppedArtifact);
                installHandler(job, tr("Cannot tag %1 with %2").arg(droppedArtifact->title()).arg(tag->name()));
            }
            return true;
        } else if (object == m_inboxObject) {
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                const auto job = m_projectRepository->dissociate(droppedArtifact);
                installHandler(job, tr("Cannot move %1 to Inbox").arg(droppedArtifact->title()));

                if (auto task = droppedArtifact.objectCast<Domain::Task>()) {
                    Utils::JobHandler::install(job, [this, task] {
                        const auto dissociateJob = m_taskRepository->dissociate(task);
                        installHandler(dissociateJob, tr("Cannot move task %1 to Inbox").arg(task->title()));
                    });
                }
            }
            return true;
        } else if (object == m_workdayObject) {
            foreach (const auto &droppedArtifact, droppedArtifacts) {

                if (auto task = droppedArtifact.objectCast<Domain::Task>()) {

                    task->setStartDate(Utils::DateTime::currentDateTime());
                    const auto job = m_taskRepository->update(task);

                    installHandler(job, tr("Cannot update task %1 to Workday").arg(task->title()));
                }
            }
            return true;
        }

        return false;
    }
```

#### AUTO 


```{c}
const auto onStartDate = startDate.isValid() && startDate <= currentDate;
```

#### AUTO 


```{c}
auto relatedHeader = new KMime::Headers::Generic("X-Zanshin-RelatedProjectUid");
```

#### AUTO 


```{c}
auto job = m_storage->fetchItems(item.parentCollection());
```

#### AUTO 


```{c}
auto job = storage->searchCollections(searchTerm, Akonadi::StorageInterface::FetchContentType(contentType));
```

#### AUTO 


```{c}
auto job = storage->fetchCollections(item.parentCollection(), StorageInterface::Base, StorageInterface::AllContent);
```

#### AUTO 


```{c}
auto handler
```

#### LAMBDA EXPRESSION 


```{c}
[child, parent, fetchParentItemJob, partialParentItem, childItem, job, this] {
            if (fetchParentItemJob->kjob()->error() != KJob::NoError)
                return;

            const auto items = fetchParentItemJob->items();
            const auto parentIndex = items.indexOf(partialParentItem);
            Q_ASSERT(parentIndex >= 0);
            const auto parentItem = items.at(parentIndex);

            // TODO Qt5: This is a bit wasteful, add an itemUid on the serializer
            const auto childUid = m_serializer->objectUid(m_serializer->createTaskFromItem(childItem));
            auto relatedUid = m_serializer->relatedUidFromItem(parentItem);
            while (!relatedUid.isEmpty()) {
                if (relatedUid == childUid) {
                    job->emitError(i18n("Could not associate '%1', it is an ancestor of '%2'",
                                        child->title(),
                                        parent->title()));
                    return;
                }

                auto it = std::find_if(items.constBegin(), items.constEnd(),
                                       [relatedUid, this] (const Akonadi::Item &item) {
                    // TODO Qt5: This is a bit wasteful, add an itemUid on the serializer
                    auto task = m_serializer->createTaskFromItem(item);
                    return task && m_serializer->objectUid(task) == relatedUid;
                });
                if (it == items.end())
                    break;

                relatedUid = m_serializer->relatedUidFromItem(*it);
            }

            const int itemCollectionId = childItem.parentCollection().id();
            const int parentCollectionId = parentItem.parentCollection().id();

            if (itemCollectionId != parentCollectionId) {
                ItemFetchJobInterface *fetchChildrenItemJob = m_storage->fetchItems(childItem.parentCollection());
                job->install(fetchChildrenItemJob->kjob(), [fetchChildrenItemJob, childItem, parentItem, job, this] {
                    if (fetchChildrenItemJob->kjob()->error() != KJob::NoError)
                        return;

                    Item::List childItems = m_serializer->filterDescendantItems(fetchChildrenItemJob->items(), childItem);

                    auto transaction = m_storage->createTransaction();
                    m_storage->updateItem(childItem, transaction);
                    childItems.push_front(childItem);
                    m_storage->moveItems(childItems, parentItem.parentCollection(), transaction);
                    job->addSubjob(transaction);
                    transaction->start();
                });
            } else {
                auto updateJob = m_storage->updateItem(childItem);
                job->addSubjob(updateJob);
                updateJob->start();
            }
        }
```

#### AUTO 


```{c}
const auto &cleanupFunction
```

#### AUTO 


```{c}
auto flagsFunction = [](const Domain::Task::Ptr &) {
            return Qt::ItemIsSelectable
                 | Qt::ItemIsEnabled
                 | Qt::ItemIsEditable
                 | Qt::ItemIsUserCheckable;
        };
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Domain::Note::Ptr &note, const QVariant &value, int role) {
        if (role != Qt::EditRole) {
            return false;
        }

        const auto currentTitle = note->title();
        note->setTitle(value.toString());
        const auto job = m_noteRepository->update(note);
        installHandler(job, i18n("Cannot modify note %1 in tag %2", currentTitle, m_tag->name()));
        return true;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Akonadi::Item &item) {
        return m_serializer->isContext(item);
    }
```

#### AUTO 


```{c}
auto sourceResult = Domain::QueryResultProvider<Domain::DataSource::Ptr>::createResult(provider);
```

#### AUTO 


```{c}
auto contextPageModel = new ContextPageModel(context,
                                                     m_contextQueries,
                                                     m_contextRepository,
                                                     m_taskQueries,
                                                     m_taskRepository,
                                                     m_noteRepository,
                                                     this);
```

#### AUTO 


```{c}
auto fetch = m_helpers->fetchItems(tag);
```

#### AUTO 


```{c}
auto types = Domain::DataSource::ContentTypes();
```

#### AUTO 


```{c}
auto setData = [this] (const Domain::DataSource::Ptr &source, const QVariant &value, int role) {
        if (role != Qt::CheckStateRole)
            return false;
        if (source->contentTypes() == Domain::DataSource::NoContent)
            return false;

        source->setSelected(value.toInt() == Qt::Checked);
        const auto job = m_dataSourceRepository->update(source);
        if (m_errorHandler)
            m_errorHandler->installHandler(job, tr("Cannot modify source %1").arg(source->name()));
        return true;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this, &listingDone] (const Domain::LiveRelationshipQuery<QObject*, QString>::AddFunction &add) {
            Utils::JobHandler::install(new FakeJob, [this, add, &listingDone] {
                add(createObject(1, QStringLiteral("ItemA")));
                add(createObject(2, QStringLiteral("ParentA")));
                listingDone = true;
            });
        }
```

#### AUTO 


```{c}
const auto behavior = m_data->storageBehavior().fetchItemBehavior(item.id());
```

#### AUTO 


```{c}
const auto i = m_items.take(item.id());
```

#### AUTO 


```{c}
auto fetch = fetchItemsInSelectedCollectionsFunction(storage, serializer);
```

#### AUTO 


```{c}
auto setData = [this](const Domain::Task::Ptr &task, const QVariant &value, int role) {
        if (role != Qt::EditRole && role != Qt::CheckStateRole) {
            return false;
        }

        const auto currentTitle = task->title();
        if (role == Qt::EditRole)
            task->setTitle(value.toString());
        else
            task->setDone(value.toInt() == Qt::Checked);

        const auto job = m_taskRepository->update(task);
        installHandler(job, i18n("Cannot modify task %1 in Inbox", currentTitle));
        return true;
    };
```

#### AUTO 


```{c}
auto message = m_item.payload<KMime::Message::Ptr>();
```

#### AUTO 


```{c}
auto provider = Domain::QueryResultProvider<Domain::Task::Ptr>::Ptr::create();
```

#### AUTO 


```{c}
auto task2 = Domain::Task::Ptr::create();
```

#### LAMBDA EXPRESSION 


```{c}
[] (const KCalCore::Attendee::Ptr &attendee) {
                                               return attendee->status() == KCalCore::Attendee::Delegated;
                                           }
```

#### AUTO 


```{c}
const auto isHovered = bool(opt.state & QStyle::State_MouseOver);
```

#### AUTO 


```{c}
auto toolBarLayout = new QHBoxLayout;
```

#### AUTO 


```{c}
auto scripthandler = new Scripting::ScriptHandler(taskRepositoryMock.getInstance());
```

#### AUTO 


```{c}
auto tags = fetchAllTags();
```

#### AUTO 


```{c}
auto predicate = [this] (const Akonadi::Collection &collection) {
        return m_serializer->isNoteCollection(collection);
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Domain::Task::Ptr &task, const QVariant &value, int role) {
        if (role != Qt::EditRole && role != Qt::CheckStateRole) {
            return false;
        }

        const auto currentTitle = task->title();
        if (role == Qt::EditRole)
            task->setTitle(value.toString());
        else
            task->setDone(value.toInt() == Qt::Checked);

        const auto job = m_taskRepository->update(task);
        installHandler(job, tr("Cannot modify task %1 in Inbox").arg(currentTitle));
        return true;
    }
```

#### AUTO 


```{c}
auto flagsFunction = [](const QString &) {
            return Qt::NoItemFlags;
        };
```

#### LAMBDA EXPRESSION 


```{c}
[] (QWidget *parent) {
        return QuickSelectDialogPtr(new QuickSelectDialog(parent));
    }
```

#### AUTO 


```{c}
auto result1 = queries->findProjects(dataSource1);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QMimeData *mimeData, Qt::DropAction, const Domain::Artifact::Ptr &artifact) {
        auto parentTask = artifact.objectCast<Domain::Task>();
        if (!parentTask)
            return false;

        if (!mimeData->hasFormat("application/x-zanshin-object"))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                        [](const Domain::Artifact::Ptr &droppedArtifact) {
                            return !droppedArtifact.objectCast<Domain::Task>();
                        })) {
            return false;
        }

        foreach(const auto &droppedArtifact, droppedArtifacts) {
            auto childTask = droppedArtifact.objectCast<Domain::Task>();
            const auto job = taskRepository()->associate(parentTask, childTask);
            if (!errorHandler())
                continue;

            errorHandler()->installHandler(job, tr("Cannot move task %1 as sub-task of %2").arg(childTask->title()).arg(parentTask->title()));
        }

        return true;
    }
```

#### AUTO 


```{c}
auto data = [](const Domain::Task::Ptr &task, int role, const AdditionalInfo &projectQueryResult) -> QVariant {
        switch (role) {
        case Qt::DisplayRole:
        case Qt::EditRole:
            return task->title();
        case Qt::CheckStateRole:
            return task->isDone() ? Qt::Checked : Qt::Unchecked;
        case Presentation::QueryTreeModelBase::AdditionalInfoRole:
            if (projectQueryResult && !projectQueryResult->data().isEmpty()) {
                Domain::Project::Ptr project = projectQueryResult->data().at(0);
                return i18n("Project: %1", project->name());
            }
            return i18n("Inbox"); // TODO add source name
        default:
            break;
        }
        return QVariant();
    };
```

#### AUTO 


```{c}
auto it = std::max_element(m_collections.constBegin(), m_collections.constEnd(),
                               idLessThan<Akonadi::Collection>);
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const QMimeData *mimeData, Qt::DropAction, const Domain::Task::Ptr &parentTask) {
        Q_UNUSED(mimeData);
        Q_UNUSED(parentTask);
        qFatal("Drop Not implemented yet");
        return true;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, add] {
                add("0");
                add("1");
                add(QString());
                add("a");
                add("2");
            }
```

#### AUTO 


```{c}
auto expectedSource = Domain::DataSource::Ptr::create();
```

#### AUTO 


```{c}
auto centralView = pageView->findChild<QTreeView*>("centralView");
```

#### AUTO 


```{c}
auto project = m_serializer->createProjectFromItem(item);
```

#### AUTO 


```{c}
const auto summaryColor = isDone ? baseColor
                            : pastDueDate ? QColor(Qt::red)
                            : onDueDate ? QColor("orange")
                            : baseColor;
```

#### LAMBDA EXPRESSION 


```{c}
[fetchParentItemJob, child, childItem, job, this] {
            if (fetchParentItemJob->kjob()->error() != KJob::NoError)
                return;

            Q_ASSERT(fetchParentItemJob->items().size() == 1);
            auto parentItem = fetchParentItemJob->items().at(0);

            const int itemCollectionId = childItem.parentCollection().id();
            const int parentCollectionId = parentItem.parentCollection().id();

            if (child.objectCast<Domain::Task>()
             && itemCollectionId != parentCollectionId) {
                ItemFetchJobInterface *fetchChildrenItemJob = m_storage->fetchItems(childItem.parentCollection());
                job->install(fetchChildrenItemJob->kjob(), [fetchChildrenItemJob, childItem, parentItem, job, this] {
                    if (fetchChildrenItemJob->kjob()->error() != KJob::NoError)
                        return;

                    Item::List childItems = m_serializer->filterDescendantItems(fetchChildrenItemJob->items(), childItem);

                    auto transaction = m_storage->createTransaction();
                    m_storage->updateItem(childItem, transaction);
                    childItems.push_front(childItem);
                    m_storage->moveItems(childItems, parentItem.parentCollection(), transaction);
                    job->addSubjob(transaction);
                    transaction->start();
                });
            } else {
                auto updateJob = m_storage->updateItem(childItem);
                job->addSubjob(updateJob);
                updateJob->start();
            }
        }
```

#### AUTO 


```{c}
auto model = new QStandardItemModel(this);
```

#### AUTO 


```{c}
auto fetch = m_helpers->fetchTaskAndAncestors(task, const_cast<TaskQueries*>(this));
```

#### AUTO 


```{c}
auto page = static_cast<Presentation::PageModel*>(app.currentPage());
```

#### RANGE FOR STATEMENT 


```{c}
for (auto item : job->items()) {
                    auto project = m_serializer->createProjectFromItem(item);
                    if (project)
                        provider->append(project);
                }
```

#### AUTO 


```{c}
auto result = queries->findInboxTopLevel();
```

#### AUTO 


```{c}
auto fetch = helpers->fetchItems(nullptr);
```

#### AUTO 


```{c}
auto doneButton = editor.findChild<QAbstractButton*>(QStringLiteral("doneButton"));
```

#### AUTO 


```{c}
auto itemRemoveJob = new MockAkonadiJob(this);
```

#### LAMBDA EXPRESSION 


```{c}
[] (const QString &, int) {
            return QVariant();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[] (QWidget *parent) {
        return NewProjectDialogPtr(new NewProjectDialog(parent));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Akonadi::Tag &akonadiTag) {
        return akonadiTag.type() == Akonadi::Tag::PLAIN;
    }
```

#### AUTO 


```{c}
auto predicate = [this] (const Item &item) {
        return m_serializer->isNoteItem(item)
            && !m_serializer->hasAkonadiTags(item);
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Domain::DataSource::Ptr &source, const QVariant &value, int role) {
        if (role != Qt::CheckStateRole)
            return false;
        if (source->contentTypes() == Domain::DataSource::NoContent)
            return false;

        source->setSelected(value.toInt() == Qt::Checked);
        const auto job = m_dataSourceRepository->update(source);
        installHandler(job, tr("Cannot modify source %1").arg(source->name()));
        return true;
    }
```

#### AUTO 


```{c}
auto inPredicate = [] (const Akonadi::Tag &tag) {
            return tag.name().endsWith("-in");
        };
```

#### AUTO 


```{c}
auto job = dynamic_cast<CollectionFetchJobInterface*>(kjob);
```

#### AUTO 


```{c}
auto items = Item::List();
```

#### LAMBDA EXPRESSION 


```{c}
[&replaceHandlerCalled](const Domain::Note::Ptr &, int) {
                                          replaceHandlerCalled = true;
                                      }
```

#### AUTO 


```{c}
auto setData = [this](const QObjectPtr &object, const QVariant &value, int role) {
        if (role != Qt::EditRole) {
            return false;
        }

        if (object == m_inboxObject
         || object == m_workdayObject
         || object == m_projectsObject
         || object == m_contextsObject
         || object == m_tagsObject) {
            return false;
        }

        if (auto project = object.objectCast<Domain::Project>()) {
            const auto currentName = project->name();
            project->setName(value.toString());
            const auto job = m_projectRepository->update(project);
            installHandler(job, tr("Cannot modify project %1").arg(currentName));
        } else if (auto context = object.objectCast<Domain::Context>()) {
            const auto currentName = context->name();
            context->setName(value.toString());
            const auto job = m_contextRepository->update(context);
            installHandler(job, tr("Cannot modify context %1").arg(currentName));
        } else if (object.objectCast<Domain::Tag>()) {
            return false; // Tag renaming is NOT allowed
        } else {
            Q_ASSERT(false);
        }

        return true;
    };
```

#### AUTO 


```{c}
auto dialogStub = NameAndDataSourceDialogStub::Ptr::create();
```

#### AUTO 


```{c}
auto inPredicate = [] (const Akonadi::Collection &collection) {
            return collection.name().endsWith("-in");
        };
```

#### AUTO 


```{c}
auto artifactQueries = Domain::ArtifactQueries::Ptr();
```

#### AUTO 


```{c}
auto shortcut = it.value()->shortcut();
```

#### AUTO 


```{c}
const auto dueDate = task ? task->dueDate() : QDate();
```

#### AUTO 


```{c}
const auto ids = m_contextItems[uid];
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Domain::Task::Ptr &task) -> Domain::QueryResultInterface<Domain::Task::Ptr>::Ptr {
        if (!task)
            return m_contextQueries->findTopLevelTasks(m_context);
        else
            return taskQueries()->findChildren(task);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Akonadi::Item &item) {
            return m_serializer->relatedUidFromItem(item).isEmpty() && m_serializer->isTaskItem(item);
        }
```

#### AUTO 


```{c}
auto projectQueries = Domain::ProjectQueries::Ptr();
```

#### AUTO 


```{c}
const auto noteMime = QString("text/x-vnd.akonadi.note");
```

#### AUTO 


```{c}
auto job = storage->searchCollections(*searchTerm);
```

#### AUTO 


```{c}
auto source = sourceIndex.data(Presentation::QueryTreeModelBase::ObjectRole)
                                 .value<Domain::DataSource::Ptr>();
```

#### AUTO 


```{c}
auto nameEdit = dialog.findChild<QLineEdit*>("nameEdit");
```

#### LAMBDA EXPRESSION 


```{c}
[serializer, parentUid] (const Akonadi::Item &item) {
                                                     return serializer->itemUid(item) == parentUid;
                                                 }
```

#### AUTO 


```{c}
auto buttonOk = ui->buttonBox->button(QDialogButtonBox::Ok);
```

#### AUTO 


```{c}
auto emptyList = Domain::QueryResultProvider<Domain::Task::Ptr>::createResult(emptyProvider);
```

#### LAMBDA EXPRESSION 


```{c}
[] (const Domain::Task::Ptr &task, int role) -> QVariant {
        if (role != Qt::DisplayRole
         && role != Qt::EditRole
         && role != Qt::CheckStateRole) {
            return QVariant();
        }

        if (role == Qt::DisplayRole || role == Qt::EditRole) {
            return task->title();
        } else if (role == Qt::CheckStateRole){
            return task->isDone() ? Qt::Checked : Qt::Unchecked;
        } else {
            return QVariant();
        }
    }
```

#### AUTO 


```{c}
auto root1 = createSourceItem("Root 1");
```

#### AUTO 


```{c}
auto emails = QStringList();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto item : job->items()) {
                            add(item);
                        }
```

#### AUTO 


```{c}
const auto oldSelected = oldAttribute ? oldAttribute->isSelected() : true;
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QModelIndex &index, const Domain::Task::Ptr &task) {
        return fetchTaskExtraData(m_taskQueries, TaskExtraPart::Project, index, task);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Domain::Artifact::Ptr &artifact, const QVariant &value, int role) {
        if (role != Qt::EditRole && role != Qt::CheckStateRole) {
            return false;
        }

        if (auto task = artifact.dynamicCast<Domain::Task>()) {
            if (role == Qt::EditRole)
                task->setTitle(value.toString());
            else
                task->setDone(value.toInt() == Qt::Checked);

            taskRepository()->update(task);
            return true;

        } else if (auto note = artifact.dynamicCast<Domain::Note>()) {
            if (role != Qt::EditRole)
                return false;

            note->setTitle(value.toString());
            noteRepository()->save(note);
            return true;

        }

        return false;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Collection &collection) {
            return collection.id() == m_collection.id()
                || (!m_collection.remoteId().isEmpty() && collection.remoteId() == m_collection.remoteId());
        }
```

#### LAMBDA EXPRESSION 


```{c}
[fetchItemJob, child, parent, job, this] {
        if (fetchItemJob->kjob()->error() != KJob::NoError)
           return;

        Q_ASSERT(fetchItemJob->items().size() == 1);
        auto childItem = fetchItemJob->items().first();
        m_serializer->updateItemParent(childItem, parent);

        // Check collections to know if we need to move child
        auto partialParentItem = m_serializer->createItemFromTask(parent);
        ItemFetchJobInterface *fetchParentItemJob = m_storage->fetchItems(partialParentItem.parentCollection());
        job->install(fetchParentItemJob->kjob(), [child, parent, fetchParentItemJob, partialParentItem, childItem, job, this] {
            if (fetchParentItemJob->kjob()->error() != KJob::NoError)
                return;

            const auto items = fetchParentItemJob->items();
            const auto parentIndex = items.indexOf(partialParentItem);
            Q_ASSERT(parentIndex >= 0);
            const auto parentItem = items.at(parentIndex);

            // TODO Qt5: This is a bit wasteful, add an itemUid on the serializer
            const auto childUid = m_serializer->objectUid(m_serializer->createTaskFromItem(childItem));
            auto relatedUid = m_serializer->relatedUidFromItem(parentItem);
            while (!relatedUid.isEmpty()) {
                if (relatedUid == childUid) {
                    job->emitError(tr("Could not associate '%1', it is an ancestor of '%2'")
                                   .arg(child->title(), parent->title()));
                    return;
                }

                auto it = std::find_if(items.constBegin(), items.constEnd(),
                                       [relatedUid, this] (const Akonadi::Item &item) {
                    // TODO Qt5: This is a bit wasteful, add an itemUid on the serializer
                    auto task = m_serializer->createTaskFromItem(item);
                    return task && m_serializer->objectUid(task) == relatedUid;
                });
                if (it == items.end())
                    break;

                relatedUid = m_serializer->relatedUidFromItem(*it);
            }

            const int itemCollectionId = childItem.parentCollection().id();
            const int parentCollectionId = parentItem.parentCollection().id();

            if (itemCollectionId != parentCollectionId) {
                ItemFetchJobInterface *fetchChildrenItemJob = m_storage->fetchItems(childItem.parentCollection());
                job->install(fetchChildrenItemJob->kjob(), [fetchChildrenItemJob, childItem, parentItem, job, this] {
                    if (fetchChildrenItemJob->kjob()->error() != KJob::NoError)
                        return;

                    Item::List childItems = m_serializer->filterDescendantItems(fetchChildrenItemJob->items(), childItem);

                    auto transaction = m_storage->createTransaction();
                    m_storage->updateItem(childItem, transaction);
                    childItems.push_front(childItem);
                    m_storage->moveItems(childItems, parentItem.parentCollection(), transaction);
                    job->addSubjob(transaction);
                    transaction->start();
                });
            } else {
                auto updateJob = m_storage->updateItem(childItem);
                job->addSubjob(updateJob);
                updateJob->start();
            }
        });
    }
```

#### AUTO 


```{c}
auto availablePagesView = new AvailablePagesView(m_parent);
```

#### AUTO 


```{c}
auto project = serializer->createProjectFromItem(data.item(42));
```

#### AUTO 


```{c}
auto fetch = m_helpers->fetchItems(const_cast<TaskQueries*>(this));
```

#### AUTO 


```{c}
auto updateJob = m_storage->updateItem(item);
```

#### AUTO 


```{c}
const auto maxId = qint64(44);
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString &value, int pos)
            {
                preInserts << value;
                preInsertsPos << pos;
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QObjectPtr &object) -> Domain::QueryResultInterface<QObjectPtr>::Ptr {
        if (!object)
            return Domain::QueryResult<QObjectPtr>::create(m_rootsProvider);
        else if (object == m_projectsObject)
            return Domain::QueryResult<Domain::DataSource::Ptr, QObjectPtr>::copy(m_dataSourceQueries->findAllSelected());
        else if (object == m_contextsObject)
            return Domain::QueryResult<Domain::Context::Ptr, QObjectPtr>::copy(m_contextQueries->findAll());
        else if (const auto source = object.objectCast<Domain::DataSource>())
            return Domain::QueryResult<Domain::Project::Ptr, QObjectPtr>::copy(m_dataSourceQueries->findProjects(source));
        else
            return Domain::QueryResult<QObjectPtr>::Ptr();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QMimeData *mimeData, Qt::DropAction, const Domain::Artifact::Ptr &artifact) {
        auto parentTask = artifact.objectCast<Domain::Task>();

        if (!mimeData->hasFormat(QStringLiteral("application/x-zanshin-object")))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                        [](const Domain::Artifact::Ptr &droppedArtifact) {
                            return !droppedArtifact.objectCast<Domain::Task>();
                        })) {
            return false;
        }

        foreach(const auto &droppedArtifact, droppedArtifacts) {
            auto childTask = droppedArtifact.objectCast<Domain::Task>();

            if (parentTask) {
                const auto job = m_taskRepository->associate(parentTask, childTask);
                installHandler(job, i18n("Cannot move task %1 as sub-task of %2", childTask->title(), parentTask->title()));
            } else {
                childTask->setStartDate(Utils::DateTime::currentDateTime());

                auto job = m_taskRepository->dissociate(childTask);
                installHandler(job, i18n("Cannot deparent task %1 from its parent", childTask->title()));
            }
        }

        return true;
    }
```

#### AUTO 


```{c}
auto predicate = [this] (const Akonadi::Item &item) {
        return m_serializer->isTaskItem(item);
    };
```

#### AUTO 


```{c}
auto flags = [](const Domain::Task::Ptr &task) {
        const Qt::ItemFlags defaultFlags = Qt::ItemIsSelectable
                                         | Qt::ItemIsEnabled
                                         | Qt::ItemIsEditable
                                         | Qt::ItemIsDragEnabled;

        return task ? (defaultFlags | Qt::ItemIsUserCheckable | Qt::ItemIsDropEnabled) : defaultFlags;
    };
```

#### AUTO 


```{c}
auto item = new QStandardItem(fileName);
```

#### AUTO 


```{c}
auto collectionFetchJob1 = new Testlib::AkonadiFakeCollectionFetchJob(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QMimeData *mimeData, Qt::DropAction, const QObjectPtr &object) {
        if (!mimeData->hasFormat(QStringLiteral("application/x-zanshin-object")))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (auto project = object.objectCast<Domain::Project>()) {
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                const auto job = m_projectRepository->associate(project, droppedArtifact);
                installHandler(job, tr("Cannot add %1 to project %2").arg(droppedArtifact->title(), project->name()));
            }
            return true;
        } else if (auto context = object.objectCast<Domain::Context>()) {
            if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                            [](const Domain::Artifact::Ptr &droppedArtifact) {
                                return !droppedArtifact.objectCast<Domain::Task>();
                            })) {
                return false;
            }
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                auto task = droppedArtifact.staticCast<Domain::Task>();
                const auto job = m_contextRepository->associate(context, task);
                installHandler(job, tr("Cannot add %1 to context %2").arg(task->title(), context->name()));
            }
            return true;
        } else if (object == m_inboxObject) {
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                const auto job = m_projectRepository->dissociate(droppedArtifact);
                installHandler(job, tr("Cannot move %1 to Inbox").arg(droppedArtifact->title()));

                if (auto task = droppedArtifact.objectCast<Domain::Task>()) {
                    Utils::JobHandler::install(job, [this, task] {
                        const auto dissociateJob = m_taskRepository->dissociateAll(task);
                        installHandler(dissociateJob, tr("Cannot move task %1 to Inbox").arg(task->title()));
                    });
                }
            }
            return true;
        } else if (object == m_workdayObject) {
            foreach (const auto &droppedArtifact, droppedArtifacts) {

                if (auto task = droppedArtifact.objectCast<Domain::Task>()) {

                    task->setStartDate(Utils::DateTime::currentDateTime());
                    const auto job = m_taskRepository->update(task);

                    installHandler(job, tr("Cannot update task %1 to Workday").arg(task->title()));
                }
            }
            return true;
        }

        return false;
    }
```

#### AUTO 


```{c}
auto about = App::getAboutData();
```

#### AUTO 


```{c}
auto selectedIndex = QPersistentModelIndex(model.index(1, 0));
```

#### LAMBDA EXPRESSION 


```{c}
[this, root, job, add] {
                if (job->kjob()->error())
                    return;

                QHash<Collection::Id, Collection> children;
                foreach (const auto &collection, job->collections()) {
                    auto child = collection;
                    while (child.parentCollection() != root)
                        child = child.parentCollection();
                    if (!children.contains(child.id()))
                        children[child.id()] = child;
                }

                foreach (const auto &topLevel, children.values())
                    add(topLevel);
            }
```

#### AUTO 


```{c}
const auto parentArtifact = parentData.value<Domain::Artifact::Ptr>();
```

#### AUTO 


```{c}
auto add = [&tags] (const Akonadi::Tag &tag) {
            tags.append(tag);
        };
```

#### AUTO 


```{c}
auto self = const_cast<ApplicationComponents*>(this);
```

#### AUTO 


```{c}
auto data = [](const Domain::Task::Ptr &task, int role, int) -> QVariant {
        if (role != Qt::DisplayRole
         && role != Qt::EditRole
         && role != Qt::CheckStateRole) {
            return QVariant();
        }

        if (role == Qt::DisplayRole || role == Qt::EditRole) {
            return task->title();
        } else {
            return task->isDone() ? Qt::Checked : Qt::Unchecked;
        }
    };
```

#### AUTO 


```{c}
auto predicate = [this] (const Akonadi::Item &item) {
        if (!m_serializer->isTaskItem(item))
            return false;

        const Domain::Task::Ptr task = m_serializer->createTaskFromItem(item);

        const QDate doneDate = task->doneDate().date();
        const QDate startDate = task->startDate().date();
        const QDate dueDate = task->dueDate().date();
        const QDate today = Utils::DateTime::currentDateTime().date();

        const bool pastStartDate = startDate.isValid() && startDate <= today;
        const bool pastDueDate = dueDate.isValid() && dueDate <= today;
        const bool todayDoneDate = doneDate == today;

        if (task->isDone())
            return todayDoneDate;
        else
            return pastStartDate || pastDueDate;
    };
```

#### AUTO 


```{c}
auto dragFunction = [] (const QList<QColor> &) -> QMimeData* {
            return Q_NULLPTR;
        };
```

#### AUTO 


```{c}
auto source = std::find_if(sources.begin(), sources.end(),
                               [this] (const Domain::DataSource::Ptr &source) {
                                   return m_taskRepository->isDefaultSource(source);
                               });
```

#### AUTO 


```{c}
auto drag = [](const QObjectPtrList &) -> QMimeData* {
        return 0;
    };
```

#### AUTO 


```{c}
auto expected = QStringList({"42", "43"});
```

#### AUTO 


```{c}
auto invalidTag = Domain::Tag::Ptr::create();
```

#### AUTO 


```{c}
const auto summaryFont = [=] {
        auto font = baseFont;
        font.setStrikeOut(isDone);
        font.setBold(!isDone && (onStartDate || onDueDate || pastDueDate));
        return font;
    }();
```

#### LAMBDA EXPRESSION 


```{c}
[](QWidget *parent) {
        return QFileDialog::getOpenFileName(parent, i18n("Add Attachment"));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const NoteQuery::AddFunction &add) {
            CollectionFetchJobInterface *job = m_storage->fetchCollections(Akonadi::Collection::root(),
                                                                           StorageInterface::Recursive,
                                                                           StorageInterface::Notes);
            Utils::JobHandler::install(job->kjob(), [this, job, add] {
                if (job->kjob()->error() != KJob::NoError)
                    return;

                for (auto collection : job->collections()) {
                    ItemFetchJobInterface *job = m_storage->fetchItems(collection);
                    Utils::JobHandler::install(job->kjob(), [this, job, add] {
                        if (job->kjob()->error() != KJob::NoError)
                            return;

                        for (auto item : job->items()) {
                            add(item);
                        }
                    });
                }
            });
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QObjectPtr &object) {
        const Qt::ItemFlags defaultFlags = Qt::ItemIsSelectable
                                         | Qt::ItemIsEnabled
                                         | Qt::ItemIsEditable
                                         | Qt::ItemIsDropEnabled;
        const Qt::ItemFlags immutableNodeFlags = Qt::ItemIsSelectable
                                               | Qt::ItemIsEnabled
                                               | Qt::ItemIsDropEnabled;
        const Qt::ItemFlags structureNodeFlags = Qt::NoItemFlags;

        return object.objectCast<Domain::Tag>() ? defaultFlags
             : object == m_inboxObject ? immutableNodeFlags
             : structureNodeFlags;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QObjectPtr &object, const QVariant &, int role) {
        if (role != Qt::EditRole) {
            return false;
        }

        if (object == m_inboxObject
         || object == m_tagsObject) {
            return false;
        }

        if (object.objectCast<Domain::Tag>()) {
            return false; // Tag renaming is NOT allowed
        } else {
            Q_ASSERT(false);
        }

        return true;
    }
```

#### AUTO 


```{c}
auto &query = m_findProjects[root.id()];
```

#### LAMBDA EXPRESSION 


```{c}
[=] {
            if (!job->error()) {
                foreach (const Akonadi::Item &item, items) {
                    m_data->removeItem(item);
                }
            }
        }
```

#### AUTO 


```{c}
const auto items = Akonadi::Item::List() << Akonadi::Item(GenTodo().withId(1).withParent(1).withTags({1}).withTitle("item1"))
                                                 << Akonadi::Item(GenTodo().withId(2).withParent(1).withTags({1}).withTitle("item2"));
```

#### LAMBDA EXPRESSION 


```{c}
[&afterReset] (QObject *object) {
            if (afterReset)
                return object->objectName().startsWith('1');
            else
                return object->objectName().startsWith('0');
        }
```

#### AUTO 


```{c}
auto fetch = helpers->fetchAllCollections(contentTypes);
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const QMimeData *mimeData, Qt::DropAction, const Domain::Task::Ptr &parentTask) {
        if (!mimeData->hasFormat("application/x-zanshin-object"))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                        [](const Domain::Artifact::Ptr &droppedArtifact) {
                            return !droppedArtifact.objectCast<Domain::Task>();
                        })) {
            return false;
        }

        foreach(const Domain::Artifact::Ptr &droppedArtifact, droppedArtifacts) {
            auto childTask = droppedArtifact.objectCast<Domain::Task>();
            taskRepository()->associate(parentTask, childTask);
        }

        return true;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[isInputCollection] (const Collection &collection) {
                                    return !isInputCollection(collection.parentCollection());
                                }
```

#### AUTO 


```{c}
auto sourceList = availableSources->property("sourceListModel").value<QAbstractItemModel*>();
```

#### AUTO 


```{c}
auto item = Akonadi::Item(15);
```

#### AUTO 


```{c}
auto queryGenerator = [](const QString &) {
            return Domain::QueryResult<QString>::Ptr();
        };
```

#### AUTO 


```{c}
auto job = storage->fetchCollections(collection, depth, nullptr);
```

#### AUTO 


```{c}
auto drop = [this](const QMimeData *mimeData, Qt::DropAction, const QObjectPtr &object) {
        if (!mimeData->hasFormat("application/x-zanshin-object"))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                        [](const Domain::Artifact::Ptr &droppedArtifact) {
                            return !droppedArtifact.objectCast<Domain::Note>();
                        })) {
            return false;
        }

        if (auto tag = object.objectCast<Domain::Tag>()) {
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                auto note = droppedArtifact.staticCast<Domain::Note>();
                const auto job = m_tagRepository->associate(tag, note);
                installHandler(job, tr("Cannot tag %1 with %2").arg(note->title()).arg(tag->name()));
            }
            return true;
        } else if (object == m_inboxObject) {
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                auto note = droppedArtifact.staticCast<Domain::Note>();
                const auto job = m_tagRepository->dissociateAll(note);
                installHandler(job, tr("Cannot move %1 to Inbox").arg(note->title()));
            }
            return true;
        }

        return false;
    };
```

#### AUTO 


```{c}
auto job = new Akonadi::TagFetchJob();
```

#### AUTO 


```{c}
auto removeJob = m_storage->removeItems(childItems, this);
```

#### AUTO 


```{c}
auto filter = m_filterProxyModel->filterRegularExpression().pattern();
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Domain::Task::Ptr &, int) {
                                        endInsertRows();
                                    }
```

#### AUTO 


```{c}
const auto hasDelegate = task && task->delegate().isValid();
```

#### AUTO 


```{c}
auto attachment = Domain::Task::Attachment();
```

#### AUTO 


```{c}
auto exPredicate = [] (const Akonadi::Item &item) {
            return titleFromItem(item).endsWith(QLatin1String("-ex"));
        };
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QObjectPtr &object, int role) -> QVariant {
        if (role != Qt::DisplayRole
         && role != Qt::EditRole
         && role != Qt::DecorationRole
         && role != QueryTreeModelBase::IconNameRole) {
            return QVariant();
        }

        if (role == Qt::EditRole
         && (object == m_inboxObject
          || object == m_workdayObject
          || object == m_projectsObject
          || object == m_contextsObject)) {
            return QVariant();
        }

        if (role == Qt::DisplayRole || role == Qt::EditRole) {
            return object->property("name").toString();
        } else if (role == Qt::DecorationRole || role == QueryTreeModelBase::IconNameRole) {
            const QString iconName = object == m_inboxObject ? QStringLiteral("mail-folder-inbox")
                                   : (object == m_workdayObject)  ? QStringLiteral("go-jump-today")
                                   : (object == m_projectsObject) ? QStringLiteral("folder")
                                   : (object == m_contextsObject) ? QStringLiteral("folder")
                                   : object.objectCast<Domain::Context>() ? QStringLiteral("view-pim-notes")
                                   : QStringLiteral("view-pim-tasks");

            if (role == Qt::DecorationRole)
                return QVariant::fromValue(QIcon::fromTheme(iconName));
            else
                return iconName;
        } else {
            return QVariant();
        }
    }
```

#### AUTO 


```{c}
auto exPredicate = [] (const Akonadi::Collection &collection) {
            return collection.name().endsWith("-ex");
        };
```

#### AUTO 


```{c}
const auto job = m_saveFunction(m_artifact);
```

#### AUTO 


```{c}
const auto childItem = task ? m_serializer->createItemFromTask(task)
                         : note ? m_serializer->createItemFromNote(note)
                         : Akonadi::Item();
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Domain::Task::Ptr &task) -> Domain::QueryResultInterface<Domain::Task::Ptr>::Ptr {
        if (!task)
            return m_projectQueries->findTopLevel(m_project);
        else
            return m_taskQueries->findChildren(task);
    }
```

#### AUTO 


```{c}
auto tasks = app.taskSourcesModel();
```

#### LAMBDA EXPRESSION 


```{c}
[this, model, queryGenerator](const ItemType &item, int index) {
            QueryTreeNodeBase *node = new QueryTreeNode<ItemType, AdditionalInfo>(item, this,
                                                                  model, queryGenerator,
                                                                  m_flagsFunction,
                                                                  m_dataFunction, m_setDataFunction,
                                                                  m_dropFunction);
            insertChild(index, node);
            endInsertRows();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[] (const Akonadi::Item &item) {
            return titleFromItem(item).endsWith("-in");
        }
```

#### AUTO 


```{c}
auto projects = new QStandardItem("Projects");
```

#### LAMBDA EXPRESSION 


```{c}
[dialogStub] (QWidget *parent) {
            dialogStub->parent = parent;
            dialogStub->setPageType(Widgets::NewPageDialogInterface::Tag);
            return dialogStub;
        }
```

#### AUTO 


```{c}
auto project = serializer.createProjectFromItem(originalItem);
```

#### AUTO 


```{c}
auto mimeTypes = listToSet(collection.contentMimeTypes());
```

#### AUTO 


```{c}
auto job = new Akonadi::CollectionModifyJob(collection);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QMimeData *, Qt::DropAction, const Domain::Artifact::Ptr &) {
        return false;
    }
```

#### AUTO 


```{c}
auto predicate = [this, tag] (const Akonadi::Item &item) {
        return m_serializer->isTagChild(tag, item);
    };
```

#### AUTO 


```{c}
auto collectionsJob = m_storage.fetchCollections(Akonadi::Collection::root(), Akonadi::Storage::Recursive, nullptr);
```

#### AUTO 


```{c}
auto provider = QueryResultInputImpl<InputType>::retrieveProvider(other);
```

#### AUTO 


```{c}
auto drag = [] (const Domain::Note::List &notes) -> QMimeData* {
        if (notes.isEmpty())
            return Q_NULLPTR;

        auto draggedArtifacts = Domain::Artifact::List();
        std::copy(notes.constBegin(), notes.constEnd(),
                  std::back_inserter(draggedArtifacts));

        auto data = new QMimeData;
        data->setData(QStringLiteral("application/x-zanshin-object"), "object");
        data->setProperty("objects", QVariant::fromValue(draggedArtifacts));
        return data;
    };
```

#### AUTO 


```{c}
auto project2 = Domain::Project::Ptr::create();
```

#### AUTO 


```{c}
auto setData = [this](const Domain::Task::Ptr &task, const QVariant &value, int role) {
        if (role != Qt::EditRole && role != Qt::CheckStateRole) {
            return false;
        }

        const auto currentTitle = task->title();
        if (role == Qt::EditRole)
            task->setTitle(value.toString());
        else
            task->setDone(value.toInt() == Qt::Checked);

        const auto job = m_taskRepository->update(task);
        installHandler(job, tr("Cannot modify task %1 in project %2").arg(currentTitle, m_project->name()));
        return true;
    };
```

#### AUTO 


```{c}
auto task = artifact.objectCast<Domain::Task>()
```

#### AUTO 


```{c}
const auto summaryText = taskDelegate.isValid() ? tr("(%1) %2").arg(taskDelegate.display(), opt.text) : opt.text;
```

#### AUTO 


```{c}
auto query = Domain::LiveQueryOutput<Domain::DataSource::Ptr>::Ptr();
```

#### LAMBDA EXPRESSION 


```{c}
[fetchJob, job, this] {
        if (fetchJob->kjob()->error() != KJob::NoError)
           return;

        Q_ASSERT(fetchJob->items().size() == 1);
        auto item = fetchJob->items().at(0);
        m_serializer->promoteItemToProject(item);

        auto updateJob = m_storage->updateItem(item, this);
        job->addSubjob(updateJob);
        updateJob->start();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Akonadi::Item &item) {
            return m_serializer->createNoteFromItem(item);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto weakResult : m_results)
        {
            auto result = weakResult.toStrongRef();
            if (!result) continue;
            for (auto handler : handlerGetter(result))
            {
                handler(item, index);
            }
        }
```

#### AUTO 


```{c}
auto i2 = serializer.createItemFromTask(task1);
```

#### AUTO 


```{c}
auto t2 = serializer.createItemFromContext(context2);
```

#### AUTO 


```{c}
auto query = [this](const Domain::Artifact::Ptr &artifact) -> Domain::QueryResultInterface<Domain::Artifact::Ptr>::Ptr {
        if (!artifact)
            return Domain::QueryResult<Domain::Task::Ptr, Domain::Artifact::Ptr>::copy(m_taskQueries->findWorkdayTopLevel());
        else if (auto task = artifact.dynamicCast<Domain::Task>())
            return Domain::QueryResult<Domain::Task::Ptr, Domain::Artifact::Ptr>::copy(m_taskQueries->findChildren(task));
        else
            return Domain::QueryResult<Domain::Artifact::Ptr>::Ptr();
    };
```

#### LAMBDA EXPRESSION 


```{c}
[] (const QModelIndex &index) {
                       return index.data(Presentation::QueryTreeModelBase::ObjectRole)
                                   .value<Domain::DataSource::Ptr>();
                   }
```

#### AUTO 


```{c}
auto editorDock = new QDockWidget;
```

#### AUTO 


```{c}
auto today = Utils::DateTime::currentDate();
```

#### AUTO 


```{c}
auto delegateLabel = editor.findChild<QLabel*>(QStringLiteral("delegateLabel"));
```

#### AUTO 


```{c}
auto availablePagesModel = const_cast<QAbstractItemModel*>(destination.model());
```

#### AUTO 


```{c}
const auto index = m_sortProxy->mapToSource(currentIndex);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Domain::Artifact::Ptr &artifact, const QVariant &value, int role) {
        if (role != Qt::EditRole && role != Qt::CheckStateRole) {
            return false;
        }

        if (auto task = artifact.dynamicCast<Domain::Task>()) {
            if (role == Qt::EditRole)
                task->setTitle(value.toString());
            else
                task->setDone(value.toInt() == Qt::Checked);

            m_taskRepository->save(task);
            return true;

        } else if (auto note = artifact.dynamicCast<Domain::Note>()) {
            if (role != Qt::EditRole)
                return false;

            note->setTitle(value.toString());
            m_noteRepository->save(note);
            return true;

        }

        return false;
    }
```

#### AUTO 


```{c}
auto query = Domain::LiveRelationshipQuery<QString, QObjectPtr>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &tag : tagJob->tags()) {
        qDebug() << "TAG:" << tag.id() << tag.name();
    }
```

#### AUTO 


```{c}
const auto job = m_taskRepository->createInProject(task, m_project);
```

#### AUTO 


```{c}
auto answer = QMessageBox::question(this,
                                            tr("Multiple Agent Deletion"),
                                            tr("Do you really want to delete the selected agent instances?"),
                                            QMessageBox::Yes | QMessageBox::No,
                                            QMessageBox::No);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QModelIndex &index, const Domain::Task::Ptr &task) {
        return fetchTaskExtraData(m_taskQueries, index, task);
    }
```

#### AUTO 


```{c}
auto availableGlobalActions = available->globalActions();
```

#### AUTO 


```{c}
auto filterWidget = pageView->findChild<Widgets::FilterWidget*>("filterWidget");
```

#### AUTO 


```{c}
auto exQuery = Domain::LiveQueryOutput<Domain::Tag::Ptr>::Ptr();
```

#### LAMBDA EXPRESSION 


```{c}
[] (const Akonadi::Collection &collection) {
            return collection.name().endsWith(QLatin1String("-ex"));
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Domain::Note::Ptr &note) -> Domain::QueryResultInterface<Domain::Note::Ptr>::Ptr {
        if (!note)
            return m_noteQueries->findInbox();
        else
            return Domain::QueryResult<Domain::Note::Ptr>::Ptr();
    }
```

#### AUTO 


```{c}
auto setData = [] (const Domain::DataSource::Ptr &source, const QVariant &value, int role) {
        Q_UNUSED(source)
        Q_UNUSED(value)
        Q_UNUSED(role)
        return false;
    };
```

#### AUTO 


```{c}
auto addAction = new QAction(this);
```

#### AUTO 


```{c}
const auto job = taskRepository()->createInTag(task, m_tag);
```

#### LAMBDA EXPRESSION 


```{c}
[allowedMimeTypes, this] (const Collection &collection) {
                                            auto mimeTypes = collection.contentMimeTypes().toSet();
                                            return mimeTypes.intersect(allowedMimeTypes).isEmpty()
                                                || !collection.displayName().contains(m_collectionName, Qt::CaseInsensitive);
                                         }
```

#### AUTO 


```{c}
const auto bookmarked = Domain::DataSource::Bookmarked;
```

#### LAMBDA EXPRESSION 


```{c}
[fetchItemJob, job, this] {
            if (fetchItemJob->kjob()->error() != KJob::NoError)
                return;

            Q_ASSERT(fetchItemJob->items().size() == 1);
            auto childItem = fetchItemJob->items().first();

            m_serializer->removeItemParent(childItem);

            auto updateJob = m_storage->updateItem(childItem);
            job->addSubjob(updateJob);
            updateJob->start();
        }
```

#### AUTO 


```{c}
const auto createdTask = inbox.addItem(title, parentIndex);
```

#### LAMBDA EXPRESSION 


```{c}
[provider, job, task, this] {
            if (job->kjob()->error() != KJob::NoError)
                return;

            for (auto item : job->items()) {
                if (m_serializer->isTaskChild(task, item)) {
                    auto task = deserializeTask(item);
                    if (task)
                        provider->append(task);
                }
            }
        }
```

#### AUTO 


```{c}
auto allTasksPageModel = new AllTasksPageModel(m_taskQueries,
                                                       m_taskRepository,
                                                       this);
```

#### AUTO 


```{c}
const auto index = model.index(taskPos, 0);
```

#### AUTO 


```{c}
auto cancelAddAction = page.findChild<QAction*>(QStringLiteral("cancelAddItemAction"));
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Akonadi::Collection &collection) {
            return m_serializer->createDataSourceFromCollection(collection, SerializerInterface::BaseName);
        }
```

#### AUTO 


```{c}
auto drop = [this](const QMimeData *mimeData, Qt::DropAction, const Domain::Task::Ptr &task) {
        auto parentTask = task.objectCast<Domain::Task>();

        if (!mimeData->hasFormat("application/x-zanshin-object"))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                        [](const Domain::Artifact::Ptr &droppedArtifact) {
                            return !droppedArtifact.objectCast<Domain::Task>();
                        })) {
            return false;
        }

        foreach(const auto &droppedArtifact, droppedArtifacts) {
            auto childTask = droppedArtifact.objectCast<Domain::Task>();

            if (parentTask) {
                const auto job = m_taskRepository->associate(parentTask, childTask);
                installHandler(job, tr("Cannot move task %1 as sub-task of %2").arg(childTask->title()).arg(parentTask->title()));
            } else {
                const auto job = m_taskRepository->dissociate(childTask);
                installHandler(job, tr("Cannot deparent task %1 from its parent").arg(childTask->title()));
            }
        }

        return true;
    };
```

#### AUTO 


```{c}
const auto textMargin = style->pixelMetric(QStyle::PM_FocusFrameHMargin, 0, widget) + 1;
```

#### AUTO 


```{c}
auto editor = static_cast<Presentation::ArtifactEditorModel*>(app.editor());
```

#### LAMBDA EXPRESSION 


```{c}
[this, tag] (const TaskQuery::AddFunction &add) {
            ItemFetchJobInterface *job = m_storage->fetchTagItems(tag);
            Utils::JobHandler::install(job->kjob(), [this, job, add] {
                if (job->kjob()->error() != KJob::NoError)
                    return;

                for (auto item : job->items())
                    add(item);
            });

        }
```

#### LAMBDA EXPRESSION 


```{c}
[] (const QColor &) -> QMimeData* {
            return 0;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[storage, item, parent] (const Domain::LiveQueryInput<Collection>::AddFunction &add) {
        auto job = storage->fetchCollections(item.parentCollection(), StorageInterface::Base, parent);
        Utils::JobHandler::install(job->kjob(), [storage, job, add] {
            if (job->kjob()->error() != KJob::NoError)
                return;
            auto collection = job->collections().at(0);
            add(collection);
        });
    }
```

#### AUTO 


```{c}
auto projectPageModel = new ProjectPageModel(project,
                                                     m_projectQueries,
                                                     m_taskQueries, m_taskRepository,
                                                     m_noteRepository,
                                                     this);
```

#### AUTO 


```{c}
auto drop = [this](const QMimeData *mimeData, Qt::DropAction, const Domain::Task::Ptr &parentTask) {
        if (!mimeData->hasFormat(QStringLiteral("application/x-zanshin-object")))
            return false;

        auto droppedTasks = mimeData->property("objects").value<Domain::Task::List>();
        if (droppedTasks.isEmpty())
            return false;

        foreach(const auto &childTask, droppedTasks) {
            if (parentTask) {
                const auto job = m_taskRepository->associate(parentTask, childTask);
                installHandler(job, i18n("Cannot move task %1 as sub-task of %2", childTask->title(), parentTask->title()));
            } else {
                auto job = m_taskRepository->dissociate(childTask);
                installHandler(job, i18n("Cannot deparent task %1 from its parent", childTask->title()));
            }
        }

        return true;
    };
```

#### AUTO 


```{c}
auto comboAction = new QWidgetAction(m_parent);
```

#### AUTO 


```{c}
auto job = storage->moveItem(item, calendar1(), nullptr);
```

#### AUTO 


```{c}
const auto contextUids = todo->customProperty(Serializer::customPropertyAppName(), Serializer::customPropertyContextList()).split(',', Qt::SkipEmptyParts);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QMimeData *mimeData, Qt::DropAction, const QObjectPtr &object) {
        if (!mimeData->hasFormat("application/x-zanshin-object"))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        auto project = object.objectCast<Domain::Project>();
        if (project) {
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                m_projectRepository->associate(project, droppedArtifact);
            }
            return true;
        } else if (auto context = object.objectCast<Domain::Context>()) {
            if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                            [](const Domain::Artifact::Ptr &droppedArtifact) {
                                return !droppedArtifact.objectCast<Domain::Task>();
                            })) {
                return false;
            }

            foreach (const auto &droppedArtifact, droppedArtifacts) {
                auto task = droppedArtifact.staticCast<Domain::Task>();
                m_contextRepository->associate(context, task);
            }
            return true;
        } else if (object == m_inboxObject) {
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                auto job = m_projectRepository->dissociate(droppedArtifact);
                if (auto task = droppedArtifact.objectCast<Domain::Task>()) {
                    Utils::JobHandler::install(job, [this, task] {
                        m_taskRepository->dissociate(task);
                    });
                }
            }
            return true;
        }

        return false;
    }
```

#### AUTO 


```{c}
auto save = [this, &savedTask] (const Domain::Task::Ptr &task) {
            savedTask = task;
            return new FakeJob(this);
        };
```

#### AUTO 


```{c}
const auto noType = Domain::DataSource::ContentTypes(Domain::DataSource::NoContent);
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Domain::Artifact::Ptr &artifact, const QVariant &value, int role) {
        if (role != Qt::EditRole && role != Qt::CheckStateRole) {
            return false;
        }

        if (auto task = artifact.dynamicCast<Domain::Task>()) {
            if (role == Qt::EditRole)
                task->setTitle(value.toString());
            else
                task->setDone(value.toInt() == Qt::Checked);

            taskRepository()->update(task);
            return true;

        } else if (auto note = artifact.dynamicCast<Domain::Note>()) {
            if (role != Qt::EditRole)
                return false;

            note->setTitle(value.toString());
            noteRepository()->save(note);
            return true;

        }

        return false;
    }
```

#### AUTO 


```{c}
auto setData = [this] (const Domain::Task::Ptr &task, const QVariant &value, int role) {
        if (role != Qt::EditRole && role != Qt::CheckStateRole)
            return false;

        const auto currentTitle = task->title();
        if (role == Qt::EditRole)
            task->setTitle(value.toString());
        else
            task->setDone(value.toInt() == Qt::Checked);

        const auto job = taskRepository()->update(task);
        installHandler(job, tr("Cannot modify task %1 in context %2").arg(currentTitle).arg(m_context->name()));
        return true;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[] (Utils::DependencyManager *) {
                return new Presentation::AvailablePagesModel(Domain::DataSourceQueries::Ptr(),
                                                             Domain::ProjectQueries::Ptr(),
                                                             Domain::ProjectRepository::Ptr(),
                                                             Domain::ContextQueries::Ptr(),
                                                             Domain::ContextRepository::Ptr(),
                                                             Domain::TaskQueries::Ptr(),
                                                             Domain::TaskRepository::Ptr());
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](const Domain::Artifact::List &artifacts) -> QMimeData* {
        Q_UNUSED(artifacts);
        qFatal("Not implemented yet");
        return Q_NULLPTR;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Item &item) {
        return m_serializer->isNoteItem(item);
    }
```

#### AUTO 


```{c}
auto *fetchJob = storage->fetchItems(collection1);
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Domain::DataSource::Ptr &source) {
        if (!source)
            return m_dataSourceQueries->findTopLevel();
        else
            return m_dataSourceQueries->findChildren(source);
    }
```

#### AUTO 


```{c}
auto childTask2 = Domain::Task::Ptr::create();
```

#### LAMBDA EXPRESSION 


```{c}
[this, task] (const Akonadi::Item &childItem) {
        return m_serializer->isTaskChild(task, childItem);
    }
```

#### AUTO 


```{c}
auto newDate = Utils::DateTime::currentDateTime().date();
```

#### AUTO 


```{c}
auto model = const_cast<QAbstractItemModel *>(persistentIndex.model());
```

#### AUTO 


```{c}
auto proxy = qobject_cast<QSortFilterProxyModel*>(sourcesView->model());
```

#### AUTO 


```{c}
auto todo = m_item.payload<KCalCore::Todo::Ptr>();
```

#### AUTO 


```{c}
auto dataFunction = [](const QString &, int) {
            return QVariant();
        };
```

#### LAMBDA EXPRESSION 


```{c}
[] (Utils::DependencyManager *) {
                return new Presentation::ArtifactEditorModel;
        }
```

#### AUTO 


```{c}
auto job = storage->fetchItems(childItem.parentCollection(), parent);
```

#### AUTO 


```{c}
auto transaction = m_storage->createTransaction(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Domain::DataSource::Ptr &source, const QVariant &value, int role) {
        Q_UNUSED(source)
        Q_UNUSED(value)
        Q_UNUSED(role)
        return false;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, &savedArtifact] (const Domain::Artifact::Ptr &artifact) {
            savedArtifact = artifact;
            return new FakeJob(this);
        }
```

#### AUTO 


```{c}
const auto minId = qint64(42);
```

#### AUTO 


```{c}
auto notifiedItem = spy[i].takeFirst().value<Akonadi::Item>();
```

#### AUTO 


```{c}
auto moveAction = components.findChild<QAction*>(QStringLiteral("moveItemAction"));
```

#### LAMBDA EXPRESSION 


```{c}
[](const Akonadi::Item::List &items) {
            auto res = QVector<Akonadi::Item::Id>();
            res.reserve(items.size());
            std::transform(items.cbegin(), items.cend(),
                           std::back_inserter(res),
                           std::mem_fn(&Akonadi::Item::id));
            std::sort(res.begin(), res.end());
            return res;
        }
```

#### AUTO 


```{c}
const auto value = row.at(i);
```

#### AUTO 


```{c}
const auto parentIndex = workday.centralListModel()->index(0, 0);
```

#### AUTO 


```{c}
const auto tagSet = QSet<Akonadi::Tag>();
```

#### LAMBDA EXPRESSION 


```{c}
[remoteId] (const Akonadi::Item &item) {
                                   return item.remoteId() == remoteId;
                               }
```

#### AUTO 


```{c}
auto buttonOk = dialog.findChild<QDialogButtonBox*>("buttonBox")->button(QDialogButtonBox::Ok);
```

#### AUTO 


```{c}
auto job = m_storage->fetchItems(m_collection, this);
```

#### LAMBDA EXPRESSION 


```{c}
[artifact] {
        auto text = artifact ? artifact->text() : QString();
        while (text.startsWith('\n'))
            text.remove(0, 1);
        return text;
    }
```

#### AUTO 


```{c}
auto job = storage->fetchCollections(Akonadi::Collection::root(), Akonadi::Storage::Recursive);
```

#### LAMBDA EXPRESSION 


```{c}
[this] (Utils::DependencyManager *) {
                             return m_data.createStorage();
                         }
```

#### AUTO 


```{c}
auto itemA = new QStandardItem("A");
```

#### AUTO 


```{c}
auto drop = [this](const QMimeData *mimeData, Qt::DropAction, const QObjectPtr &object) {
        if (!mimeData->hasFormat("application/x-zanshin-object"))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        auto project = object.objectCast<Domain::Project>();
        if (project) {
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                m_projectRepository->associate(project, droppedArtifact);
            }
            return true;
        } else if (object == m_inboxObject) {
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                auto job = m_projectRepository->dissociate(droppedArtifact);
                if (auto task = droppedArtifact.objectCast<Domain::Task>()) {
                    Utils::JobHandler::install(job, [this, task] {
                        m_taskRepository->dissociate(task);
                    });
                }
            }
            return true;
        }

        return false;
    };
```

#### AUTO 


```{c}
const auto allContent = Akonadi::StorageInterface::FetchContentTypes(Akonadi::StorageInterface::AllContent);
```

#### AUTO 


```{c}
auto email = QString();
```

#### AUTO 


```{c}
auto treeSetData = [&](const Domain::Task::Ptr &task, const QVariant &value, int role) {
        if (role != Qt::EditRole && role != Qt::CheckStateRole) {
            return false;
        }

        if (role == Qt::EditRole) {
            task->setTitle(value.toString());
        } else {
            task->setDone(value.toInt() == Qt::Checked);
        }

        repository.save(task);
        return true;
    };
```

#### AUTO 


```{c}
auto recurrenceCombo = editor.findChild<QComboBox*>(QStringLiteral("recurrenceCombo"));
```

#### LAMBDA EXPRESSION 


```{c}
[fetchItemJob, child, parent, job, this] {
        if (fetchItemJob->kjob()->error() != KJob::NoError)
           return;

        Q_ASSERT(fetchItemJob->items().size() == 1);
        auto childItem = fetchItemJob->items().at(0);
        m_serializer->updateItemParent(childItem, parent);

        // Check collections to know if we need to move child
        auto partialParentItem = m_serializer->createItemFromTask(parent);
        ItemFetchJobInterface *fetchParentItemJob = m_storage->fetchItems(partialParentItem.parentCollection());
        job->install(fetchParentItemJob->kjob(), [child, parent, fetchParentItemJob, partialParentItem, childItem, job, this] {
            if (fetchParentItemJob->kjob()->error() != KJob::NoError)
                return;

            const auto items = fetchParentItemJob->items();
            const auto parentIndex = items.indexOf(partialParentItem);
            Q_ASSERT(parentIndex >= 0);
            const auto parentItem = items.at(parentIndex);

            const auto childUid = m_serializer->itemUid(childItem);
            auto relatedUid = m_serializer->relatedUidFromItem(parentItem);
            while (!relatedUid.isEmpty()) {
                if (relatedUid == childUid) {
                    job->emitError(i18n("Could not associate '%1', it is an ancestor of '%2'",
                                        child->title(),
                                        parent->title()));
                    return;
                }

                auto it = std::find_if(items.constBegin(), items.constEnd(),
                                       [relatedUid, this] (const Akonadi::Item &item) {
                    return m_serializer->itemUid(item) == relatedUid;
                });
                if (it == items.end())
                    break;

                relatedUid = m_serializer->relatedUidFromItem(*it);
            }

            const int itemCollectionId = childItem.parentCollection().id();
            const int parentCollectionId = parentItem.parentCollection().id();

            if (itemCollectionId != parentCollectionId) {
                ItemFetchJobInterface *fetchChildrenItemJob = m_storage->fetchItems(childItem.parentCollection());
                job->install(fetchChildrenItemJob->kjob(), [fetchChildrenItemJob, childItem, parentItem, job, this] {
                    if (fetchChildrenItemJob->kjob()->error() != KJob::NoError)
                        return;

                    Item::List childItems = m_serializer->filterDescendantItems(fetchChildrenItemJob->items(), childItem);

                    auto transaction = m_storage->createTransaction();
                    m_storage->updateItem(childItem, transaction);
                    childItems.push_front(childItem);
                    m_storage->moveItems(childItems, parentItem.parentCollection(), transaction);
                    job->addSubjob(transaction);
                    transaction->start();
                });
            } else {
                auto updateJob = m_storage->updateItem(childItem);
                job->addSubjob(updateJob);
                updateJob->start();
            }
        });
    }
```

#### AUTO 


```{c}
auto flags = [] (const Domain::Task::Ptr &task) {
        Q_UNUSED(task);
        return Qt::ItemIsSelectable
             | Qt::ItemIsEnabled
             | Qt::ItemIsEditable
             | Qt::ItemIsDragEnabled
             | Qt::ItemIsUserCheckable
             | Qt::ItemIsDropEnabled;
    };
```

#### AUTO 


```{c}
auto invalidContext = Domain::Context::Ptr::create();
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Domain::Task::Ptr &task, const QVariant &value, int role) {
        if (role != Qt::EditRole && role != Qt::CheckStateRole) {
            return false;
        }

        const auto currentTitle = task->title();
        if (role == Qt::EditRole)
            task->setTitle(value.toString());
        else
            task->setDone(value.toInt() == Qt::Checked);

        const auto job = m_taskRepository->update(task);
        installHandler(job, i18n("Cannot modify task %1 in project %2", currentTitle, m_project->name()));
        return true;
    }
```

#### AUTO 


```{c}
auto dlg = QPointer<AgentTypeDialog>(new AgentTypeDialog(this));
```

#### LAMBDA EXPRESSION 


```{c}
[] (const QMimeData *, Qt::DropAction, const Domain::Note::Ptr &) {
        return false;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Domain::Artifact::Ptr &artifact, const QVariant &value, int role) {
        if (role != Qt::EditRole && role != Qt::CheckStateRole) {
            return false;
        }

        if (auto task = artifact.dynamicCast<Domain::Task>()) {
            const auto currentTitle = task->title();
            if (role == Qt::EditRole)
                task->setTitle(value.toString());
            else
                task->setDone(value.toInt() == Qt::Checked);

            const auto job = taskRepository()->update(task);
            if (!errorHandler())
                return true;

            errorHandler()->installHandler(job, tr("Cannot modify task %1 in Inbox").arg(currentTitle));
            return true;

        } else if (auto note = artifact.dynamicCast<Domain::Note>()) {
            if (role != Qt::EditRole)
                return false;

            const auto currentTitle = note->title();
            note->setTitle(value.toString());
            const auto job = noteRepository()->save(note);
            if (!errorHandler())
                return true;

            errorHandler()->installHandler(job, tr("Cannot modify note %1 in Inbox").arg(currentTitle));
            return true;

        }

        return false;
    }
```

#### AUTO 


```{c}
auto promoteAction = page.findChild<QAction*>(QStringLiteral("promoteItemAction"));
```

#### AUTO 


```{c}
const auto ids = m_contextItems.value(contextUid);
```

#### AUTO 


```{c}
const auto hasAdditionalInfo = projectInfo.isValid() || dataSourceInfo.isValid() || contextListInfo.isValid();
```

#### AUTO 


```{c}
auto colJob = new Akonadi::CollectionFetchJob(Akonadi::Collection::root(),
                                                  Akonadi::CollectionFetchJob::Recursive);
```

#### AUTO 


```{c}
const auto emittedItem2 = itemSpy.first().at(0).value<Akonadi::Item>();
```

#### AUTO 


```{c}
auto setData = [this] (const Domain::Task::Ptr &task, const QVariant &value, int role) {
        if (role != Qt::EditRole && role != Qt::CheckStateRole)
            return false;

        if (role == Qt::EditRole)
            task->setTitle(value.toString());
        else
            task->setDone(value.toInt() == Qt::Checked);

        taskRepository()->update(task);
        return true;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Tag &tag) {
        m_findToplevel.remove(tag.id());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[] (const Domain::DataSource::Ptr &source, int role) -> QVariant {
        if (role != Qt::DisplayRole
         && role != Qt::EditRole
         && role != Qt::DecorationRole
         && role != Qt::CheckStateRole
         && role != QueryTreeModelBase::IconNameRole) {
            return QVariant();
        }

        if (role == Qt::DisplayRole || role == Qt::EditRole) {
            return source->name();
        } else if (role == Qt::DecorationRole || role == QueryTreeModelBase::IconNameRole) {
            const QString iconName = source->iconName().isEmpty() ? "folder" : source->iconName();

            if (role == Qt::DecorationRole)
                return QVariant::fromValue(QIcon::fromTheme(iconName));
            else
                return iconName;
        } else if (role == Qt::CheckStateRole) {
            if (source->contentTypes() != Domain::DataSource::NoContent)
                return source->isSelected() ? Qt::Checked : Qt::Unchecked;
            else
                return QVariant();
        } else {
            return QVariant();
        }
    }
```

#### AUTO 


```{c}
auto topLevelResult = Domain::QueryResult<Domain::DataSource::Ptr>::create(topLevelProvider);
```

#### AUTO 


```{c}
auto job = createStorage()->fetchTags();
```

#### AUTO 


```{c}
auto result1 = queries->findTopLevelArtifacts(project1);
```

#### AUTO 


```{c}
auto transactionJob = new MockAkonadiJob(this);
```

#### AUTO 


```{c}
auto itemsMoveJob = new MockAkonadiJob(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const QString &s) -> QObject* {
            bool ok = false;
            const int id = s.toInt(&ok);
            if (ok) {
                auto object = new QObject(this);
                object->setProperty("id", id);
                return object;
            } else {
                return nullptr;
            }
        }
```

#### AUTO 


```{c}
auto data = AkonadiFakeData();
```

#### LAMBDA EXPRESSION 


```{c}
[fetchItemJob, job, this] {
        if (fetchItemJob->kjob()->error() != KJob::NoError)
            return;

        Q_ASSERT(fetchItemJob->items().size() == 1);
        auto childItem = fetchItemJob->items().at(0);
        childItem.clearTags();

        auto updateJob = m_storage->updateItem(childItem, this);
        job->addSubjob(updateJob);
        updateJob->start();
    }
```

#### AUTO 


```{c}
auto save = [this, &savedArtifact] (const Domain::Artifact::Ptr &artifact) {
            savedArtifact = artifact;
            auto job = new FakeJob(this);
            job->setExpectedError(KJob::KilledJobError, "Foo");
            return job;
        };
```

#### AUTO 


```{c}
auto queryGenerator = [&](const Domain::Task::Ptr &task) {
            if (!task)
                return Domain::QueryResult<Domain::Task::Ptr>::create(provider);
            else
                return queryMock.getInstance()->findChildren(task);
        };
```

#### AUTO 


```{c}
auto query = Domain::LiveQueryOutput<Domain::Context::Ptr>::Ptr();
```

#### AUTO 


```{c}
auto monitor = AkonadiFakeMonitor::Ptr::create();
```

#### AUTO 


```{c}
const auto taskMimeTypes = QStringList() << "application/x-vnd.akonadi.calendar.todo";
```

#### AUTO 


```{c}
auto drop = [this](const QMimeData *mimeData, Qt::DropAction, const Domain::Artifact::Ptr &artifact) {
        auto parentTask = artifact.objectCast<Domain::Task>();
        if (!parentTask)
            return false;

        if (!mimeData->hasFormat("application/x-zanshin-object"))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                        [](const Domain::Artifact::Ptr &droppedArtifact) {
                            return !droppedArtifact.objectCast<Domain::Task>();
                        })) {
            return false;
        }

        foreach(const Domain::Artifact::Ptr &droppedArtifact, droppedArtifacts) {
            auto childTask = droppedArtifact.objectCast<Domain::Task>();
            const auto job = taskRepository()->associate(parentTask, childTask);
            installHandler(job, tr("Cannot move task %1 as a sub-task of %2").arg(childTask->title()).arg(parentTask->title()));
        }

        return true;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Akonadi::Item &item) {
        if (!m_serializer->isTaskItem(item))
            return false;

        const Domain::Task::Ptr task = m_serializer->createTaskFromItem(item);

        const QDate doneDate = task->doneDate().date();
        const QDate startDate = task->startDate().date();
        const QDate dueDate = task->dueDate().date();
        const QDate today = Utils::DateTime::currentDateTime().date();

        const bool pastStartDate = startDate.isValid() && startDate <= today;
        const bool pastDueDate = dueDate.isValid() && dueDate <= today;
        const bool todayDoneDate = doneDate == today;

        if (task->isDone())
            return todayDoneDate;
        else
            return pastStartDate || pastDueDate;
    }
```

#### AUTO 


```{c}
const auto todo = item.payload<KCalCore::Todo::Ptr>();
```

#### AUTO 


```{c}
auto job = storage->createCollection(collection, nullptr);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QMimeData *mimeData, Qt::DropAction, const Domain::Artifact::Ptr &artifact) {
        auto parentTask = artifact.objectCast<Domain::Task>();

        if (!mimeData->hasFormat("application/x-zanshin-object"))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                        [](const Domain::Artifact::Ptr &droppedArtifact) {
                            return !droppedArtifact.objectCast<Domain::Task>();
                        })) {
            return false;
        }

        foreach(const auto &droppedArtifact, droppedArtifacts) {
            auto childTask = droppedArtifact.objectCast<Domain::Task>();

            if (parentTask) {
                const auto job = m_taskRepository->associate(parentTask, childTask);
                installHandler(job, tr("Cannot move task %1 as sub-task of %2").arg(childTask->title()).arg(parentTask->title()));
            } else {
                childTask->setStartDate(Utils::DateTime::currentDateTime());

                auto job = m_taskRepository->update(childTask);
                installHandler(job, tr("Cannot update task %1").arg(childTask->title()));

                job = m_taskRepository->dissociate(childTask);
                installHandler(job, tr("Cannot deparent task %1 from its parent").arg(childTask->title()));
            }
        }

        return true;
    }
```

#### AUTO 


```{c}
const auto today = Utils::DateTime::currentDateTime();
```

#### AUTO 


```{c}
const auto createdTask = workday.addItem(title, parentIndex).objectCast<Domain::Task>();
```

#### LAMBDA EXPRESSION 


```{c}
[](const Domain::Artifact::Ptr &artifact) {
        const Qt::ItemFlags defaultFlags = Qt::ItemIsSelectable
                                         | Qt::ItemIsEnabled
                                         | Qt::ItemIsEditable;

        return artifact.dynamicCast<Domain::Task>() ? (defaultFlags | Qt::ItemIsUserCheckable) : defaultFlags;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[] (QObject *object, const QPair<int, QString> &output) {
            return object->property("objectId").toInt() == output.first;
        }
```

#### AUTO 


```{c}
auto drag = [](const Domain::DataSource::List &) -> QMimeData* {
        return nullptr;
    };
```

#### AUTO 


```{c}
auto runningTask = static_cast<Presentation::RunningTaskModel*>(app.runningTaskModel());
```

#### AUTO 


```{c}
auto job = storage.fetchItems(Akonadi::Collection(42), nullptr);
```

#### AUTO 


```{c}
auto fetchJob = m_storage->fetchItem(item, this);
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Akonadi::Item &item) {
            return m_serializer->isTaskItem(item);
        }
```

#### AUTO 


```{c}
auto task = artifact.dynamicCast<Domain::Task>()
```

#### AUTO 


```{c}
const auto oldTags = m_items[item.id()].tags();
```

#### AUTO 


```{c}
const auto extraText = [artifact] {
        auto text = artifact ? artifact->text() : QString();
        while (text.startsWith('\n'))
            text.remove(0, 1);
        return text;
    }();
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Domain::LiveRelationshipQuery<QObject*, QString>::AddFunction &add) {
            Utils::JobHandler::install(new FakeJob, [this, add] {
                add(createObject(0, QStringLiteral("ProjectA")));
                add(createObject(1, QStringLiteral("ItemA")));
                add(createObject(2, QStringLiteral("ParentA")));
            });
        }
```

#### AUTO 


```{c}
auto parentItem = fetchParentItemJob->items().first();
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QObjectPtr &object, const QVariant &value, int role) {
        if (role != Qt::EditRole) {
            return false;
        }

        if (object == m_inboxObject
         || object == m_workdayObject
         || object == m_projectsObject
         || object == m_contextsObject
         || object.objectCast<Domain::DataSource>()) {
            return false;
        }

        if (auto project = object.objectCast<Domain::Project>()) {
            const auto currentName = project->name();
            project->setName(value.toString());
            const auto job = m_projectRepository->update(project);
            installHandler(job, i18n("Cannot modify project %1", currentName));
        } else if (auto context = object.objectCast<Domain::Context>()) {
            const auto currentName = context->name();
            context->setName(value.toString());
            const auto job = m_contextRepository->update(context);
            installHandler(job, i18n("Cannot modify context %1", currentName));
        } else {
            Q_ASSERT(false);
        }

        return true;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QMimeData *mimeData, Qt::DropAction, const QObjectPtr &object) {
        auto project = object.objectCast<Domain::Project>();
        if (!project)
            return false;

        if (!mimeData->hasFormat("application/x-zanshin-object"))
            return false;

        auto artifact = mimeData->property("object").value<Domain::Artifact::Ptr>();
        if (!artifact)
            return false;

        m_projectRepository->associate(project, artifact);
        return true;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[fetchParentItemJob, childItem, job, this] {
            if (fetchParentItemJob->kjob()->error() != KJob::NoError)
                return;

            Q_ASSERT(fetchParentItemJob->items().size() == 1);
            auto parentItem = fetchParentItemJob->items().first();

            const int itemCollectionId = childItem.parentCollection().id();
            const int parentCollectionId = parentItem.parentCollection().id();

            if (itemCollectionId != parentCollectionId) {
                ItemFetchJobInterface *fetchChildrenItemJob = m_storage->fetchItems(childItem.parentCollection());
                job->install(fetchChildrenItemJob->kjob(), [fetchChildrenItemJob, childItem, parentItem, job, this] {
                    if (fetchChildrenItemJob->kjob()->error() != KJob::NoError)
                        return;

                    Item::List childItems = m_serializer->filterDescendantItems(fetchChildrenItemJob->items(), childItem);

                    auto transaction = m_storage->createTransaction();
                    m_storage->updateItem(childItem, transaction);
                    childItems.push_front(childItem);
                    m_storage->moveItems(childItems, parentItem.parentCollection(), transaction);
                    job->addSubjob(transaction);
                    transaction->start();
                });
            } else {
                auto updateJob = m_storage->updateItem(childItem);
                job->addSubjob(updateJob);
                updateJob->start();
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[fetchItemJob, job, this] {
        if (fetchItemJob->kjob()->error() != KJob::NoError)
            return;

        Q_ASSERT(fetchItemJob->items().size() == 1);
        auto childItem = fetchItemJob->items().at(0);

        m_serializer->removeItemParent(childItem);

        auto updateJob = m_storage->updateItem(childItem);
        job->addSubjob(updateJob);
        updateJob->start();
    }
```

#### AUTO 


```{c}
auto attr = m_collection.attribute<Akonadi::ApplicationSelectedAttribute>(Akonadi::Collection::AddIfMissing);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto collection : job->collections())
                    add(collection);
```

#### AUTO 


```{c}
auto pagesView = available.findChild<QTreeView*>(QStringLiteral("pagesView"));
```

#### AUTO 


```{c}
auto jobDelete = new Akonadi::TagDeleteJob(tag);
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Akonadi::Tag &tag) {
            return m_serializer->createTagFromAkonadiTag(tag);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (Utils::DependencyManager *) {
            return m_data.createStorage();
        }
```

#### AUTO 


```{c}
auto task = workday.addItem(title);
```

#### LAMBDA EXPRESSION 


```{c}
[remoteId] (const Akonadi::Collection &collection) {
                                   return collection.remoteId() == remoteId;
                               }
```

#### AUTO 


```{c}
auto task = serializer->createTaskFromItem(data.item(44));
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Domain::LiveQuery<QObject*, QString>::AddFunction &add) {
            Utils::JobHandler::install(new FakeJob, [this, add] {
                add(createObject(0, QStringLiteral("0A")));
                add(createObject(1, QStringLiteral("1A")));
                add(createObject(2, QStringLiteral("2A")));
                add(createObject(3, QStringLiteral("0B")));
                add(createObject(4, QStringLiteral("1B")));
                add(createObject(5, QStringLiteral("2B")));
                add(createObject(6, QStringLiteral("0C")));
                add(createObject(7, QStringLiteral("1C")));
                add(createObject(8, QStringLiteral("2C")));
            });
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : items) {
            if (item.hasPayload<KCalCore::Todo::Ptr>()) {
                auto todo = item.payload<KCalCore::Todo::Ptr>();
                hash.insert(todo->uid(), SeenItem(item));
            }
        }
```

#### AUTO 


```{c}
auto isWorkdayItem = [this] (const Akonadi::Item &item) {
        if (!m_serializer->isTaskItem(item))
            return false;

        const Domain::Task::Ptr task = m_serializer->createTaskFromItem(item);

        const QDate doneDate = task->doneDate().date();
        const QDate startDate = task->startDate().date();
        const QDate dueDate = task->dueDate().date();
        const QDate today = Utils::DateTime::currentDateTime().date();

        const bool pastStartDate = startDate.isValid() && startDate <= today;
        const bool pastDueDate = dueDate.isValid() && dueDate <= today;
        const bool todayDoneDate = doneDate == today;

        if (task->isDone())
            return todayDoneDate;
        else
            return pastStartDate || pastDueDate;
    };
```

#### AUTO 


```{c}
auto newDate = Utils::DateTime::currentDate();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto collection : job->collections()) {
            ItemFetchJobInterface *job = m_storage->fetchItems(collection);
            Utils::JobHandler::install(job->kjob(), [provider, job, this] {
                for (auto item : job->items()) {
                    if (m_serializer->relatedUidFromItem(item).isEmpty()) {
                        auto task = deserializeTask(item);
                        if (task)
                            provider->append(task);
                    }
                }
            });
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, root] (const Akonadi::Collection &collection) {
            return collection.isValid() && collection.parentCollection() == root;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[fetchItemJob, context, job, this] {
        if (fetchItemJob->kjob()->error() != KJob::NoError)
            return;

        Q_ASSERT(fetchItemJob->items().size() == 1);
        auto childItem = fetchItemJob->items().at(0);
        m_serializer->removeContextFromTask(context, childItem);

        auto updateJob = m_storage->updateItem(childItem);
        job->addSubjob(updateJob);
        updateJob->start();
    }
```

#### AUTO 


```{c}
auto parentId = context->property("parentCollectionId").value<Akonadi::Collection::Id>();
```

#### LAMBDA EXPRESSION 


```{c}
[root, job, add] {
            if (job->kjob()->error())
                return;

            auto directChildren = QHash<Collection::Id, Collection>();
            foreach (const auto &collection, job->collections()) {
                auto directChild = collection;
                while (directChild.parentCollection() != root)
                    directChild = directChild.parentCollection();
                if (!directChildren.contains(directChild.id()))
                    directChildren[directChild.id()] = directChild;
            }

            foreach (const auto &directChild, directChildren)
                add(directChild);
        }
```

#### AUTO 


```{c}
auto inboxPageModel = new TaskInboxPageModel(m_taskQueries,
                                                     m_taskRepository,
                                                     this);
```

#### AUTO 


```{c}
const auto currentDate = Utils::DateTime::currentDate();
```

#### AUTO 


```{c}
auto drop = [this](const QMimeData *mimeData, Qt::DropAction, const Domain::Artifact::Ptr &artifact) {
        auto parentTask = artifact.objectCast<Domain::Task>();

        if (!mimeData->hasFormat(QStringLiteral("application/x-zanshin-object")))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                        [](const Domain::Artifact::Ptr &droppedArtifact) {
                            return !droppedArtifact.objectCast<Domain::Task>();
                        })) {
            return false;
        }

        foreach(const auto &droppedArtifact, droppedArtifacts) {
            auto childTask = droppedArtifact.objectCast<Domain::Task>();

            if (parentTask) {
                const auto job = m_taskRepository->associate(parentTask, childTask);
                installHandler(job, tr("Cannot move task %1 as sub-task of %2").arg(childTask->title(), parentTask->title()));
            } else {
                childTask->setStartDate(Utils::DateTime::currentDateTime());

                auto job = m_taskRepository->update(childTask);
                installHandler(job, tr("Cannot update task %1").arg(childTask->title()));

                job = m_taskRepository->dissociate(childTask);
                installHandler(job, tr("Cannot deparent task %1 from its parent").arg(childTask->title()));
            }
        }

        return true;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[relatedUid, this] (const Akonadi::Item &item) {
                    return m_serializer->itemUid(item) == relatedUid;
                }
```

#### AUTO 


```{c}
auto dataFunction = [] (const QColor &, int) {
            return QVariant();
        };
```

#### AUTO 


```{c}
const auto job = m_tagRepository->dissociate(m_tag, artifact);
```

#### AUTO 


```{c}
auto setData = [this](const Domain::Artifact::Ptr &artifact, const QVariant &value, int role) {
        if (role != Qt::EditRole && role != Qt::CheckStateRole) {
            return false;
        }

        if (auto task = artifact.dynamicCast<Domain::Task>()) {
            const auto currentTitle = task->title();
            if (role == Qt::EditRole)
                task->setTitle(value.toString());
            else
                task->setDone(value.toInt() == Qt::Checked);

            const auto job = m_taskRepository->update(task);
            installHandler(job, tr("Cannot modify task %1 in Workday").arg(currentTitle));
            return true;
        }

        return false;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[] (const QList<QColor> &) {
            return Q_NULLPTR;
        }
```

#### AUTO 


```{c}
auto drop = [this](const QMimeData *mimeData, Qt::DropAction, const Domain::Artifact::Ptr &artifact) {
        auto parentTask = artifact.objectCast<Domain::Task>();
        if (!parentTask)
            return false;

        if (!mimeData->hasFormat("application/x-zanshin-object"))
            return false;

        auto droppedArtifact = mimeData->property("object").value<Domain::Artifact::Ptr>();
        if (!droppedArtifact)
            return false;

        auto childTask = droppedArtifact.objectCast<Domain::Task>();
        if (!childTask)
            return false;

        taskRepository()->associate(parentTask, childTask);
        return true;
    };
```

#### AUTO 


```{c}
auto drop = [this](const QMimeData *mimeData, Qt::DropAction, const QObjectPtr &object) {
        if (!mimeData->hasFormat("application/x-zanshin-object"))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (auto project = object.objectCast<Domain::Project>()) {
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                m_projectRepository->associate(project, droppedArtifact);
            }
            return true;
        } else if (auto context = object.objectCast<Domain::Context>()) {
            if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                            [](const Domain::Artifact::Ptr &droppedArtifact) {
                                return !droppedArtifact.objectCast<Domain::Task>();
                            })) {
                return false;
            }
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                auto task = droppedArtifact.staticCast<Domain::Task>();
                m_contextRepository->associate(context, task);
            }
            return true;
        } else if (auto tag = object.objectCast<Domain::Tag>()) {
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                m_tagRepository->associate(tag, droppedArtifact);
            }
            return true;
        } else if (object == m_inboxObject) {
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                auto job = m_projectRepository->dissociate(droppedArtifact);
                if (auto task = droppedArtifact.objectCast<Domain::Task>()) {
                    Utils::JobHandler::install(job, [this, task] {
                        m_taskRepository->dissociate(task);
                    });
                }
            }
            return true;
        }

        return false;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Akonadi::Tag &akonadiTag, const Domain::Tag::Ptr &tag) {
            return m_serializer->representsAkonadiTag(tag, akonadiTag);
        }
```

#### AUTO 


```{c}
auto fetch = helpers->fetchTags();
```

#### AUTO 


```{c}
auto currentItem = item;
```

#### LAMBDA EXPRESSION 


```{c}
[this, root] (const Collection &collection) {
        return collection.isValid()
            && collection.parentCollection() == root;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const Domain::Task::Ptr &, int) {
            return QVariant();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](const Akonadi::Collection::List &collections) {
            auto res = QStringList();
            std::transform(collections.cbegin(), collections.cend(),
                           std::back_inserter(res),
                           std::mem_fn(&Akonadi::Collection::name));
            res.sort();
            return res;
        }
```

#### AUTO 


```{c}
auto query = Domain::LiveRelationshipQuery<InputType, OutputType>::Ptr::create();
```

#### AUTO 


```{c}
auto drag = [](const Domain::DataSource::List &) -> QMimeData* {
        return Q_NULLPTR;
    };
```

#### AUTO 


```{c}
auto result = queries->findProjects(dataSource);
```

#### AUTO 


```{c}
auto setData = [this](const Domain::Artifact::Ptr &artifact, const QVariant &value, int role) {
        if (role != Qt::EditRole && role != Qt::CheckStateRole) {
            return false;
        }

        if (auto task = artifact.dynamicCast<Domain::Task>()) {
            const auto currentTitle = task->title();
            if (role == Qt::EditRole)
                task->setTitle(value.toString());
            else
                task->setDone(value.toInt() == Qt::Checked);

            const auto job = m_taskRepository->update(task);
            installHandler(job, tr("Cannot modify task %1 in project %2").arg(currentTitle).arg(m_project->name()));
            return true;

        } else if (auto note = artifact.dynamicCast<Domain::Note>()) {
            if (role != Qt::EditRole)
                return false;

            const auto currentTitle = note->title();
            note->setTitle(value.toString());
            const auto job = m_noteRepository->update(note);
            installHandler(job, tr("Cannot modify note %1 in project %2").arg(currentTitle).arg(m_project->name()));
            return true;

        }

        return false;
    };
```

#### AUTO 


```{c}
auto deps = data.createDependencies();
```

#### AUTO 


```{c}
const auto childTask = model->data(model->index(0, 0, topLevelIndex), Presentation::QueryTreeModelBase::ObjectRole).value<Domain::Task::Ptr>();
```

#### LAMBDA EXPRESSION 


```{c}
[this, tag] (const Akonadi::Item &item) {
        return m_serializer->isTagChild(tag, item);
    }
```

#### AUTO 


```{c}
auto appModel = new ApplicationModel(new Akonadi::ArtifactQueries(this),
                                             new Akonadi::ProjectQueries(this),
                                             new Akonadi::ProjectRepository(this),
                                             new Akonadi::DataSourceQueries(this),
                                             new Akonadi::TaskQueries(this),
                                             new Akonadi::TaskRepository(this),
                                             new Akonadi::NoteRepository(this),
                                             this);
```

#### AUTO 


```{c}
auto drag = [](const Domain::Note::List &notes) -> QMimeData* {
        if (notes.isEmpty())
            return Q_NULLPTR;

        auto artifacts = Domain::Artifact::List();
        artifacts.reserve(notes.size());
        std::copy(notes.constBegin(), notes.constEnd(),
                  std::back_inserter(artifacts));

        auto data = new QMimeData;
        data->setData(QStringLiteral("application/x-zanshin-object"), "object");
        data->setProperty("objects", QVariant::fromValue(artifacts));
        return data;
    };
```

#### AUTO 


```{c}
auto projectPageModel = new ProjectPageModel(project,
                                                     m_projectQueries,
                                                     m_taskQueries,
                                                     m_taskRepository,
                                                     this);
```

#### LAMBDA EXPRESSION 


```{c}
[storage, contentTypes, searchTerm, root] (const Domain::LiveQueryInput<Collection>::AddFunction &add) {
        if (searchTerm->isEmpty())
            return;

        auto job = storage->searchCollections(*searchTerm, contentTypes);
        Utils::JobHandler::install(job->kjob(), [root, job, add] {
            if (job->kjob()->error())
                return;

            auto directChildren = QHash<Collection::Id, Collection>();
            foreach (const auto &collection, job->collections()) {
                auto directChild = collection;
                while (directChild.parentCollection() != root && directChild.parentCollection().isValid())
                    directChild = directChild.parentCollection();
                if (directChild.parentCollection() != root)
                    continue;
                if (!directChildren.contains(directChild.id()))
                    directChildren[directChild.id()] = directChild;
            }

            foreach (const auto &directChild, directChildren)
                add(directChild);
        });
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, context] (const Akonadi::Item &item) {
        return m_serializer->isContextChild(context, item);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=] {
            if (!job->error()) {
                m_data->removeItem(item);
            }
        }
```

#### AUTO 


```{c}
auto drop = [this](const QMimeData *mimeData, Qt::DropAction, const Domain::Artifact::Ptr &artifact) {
        auto parentTask = artifact.objectCast<Domain::Task>();
        if (!parentTask)
            return false;

        if (!mimeData->hasFormat("application/x-zanshin-object"))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                        [](const Domain::Artifact::Ptr &droppedArtifact) {
                            return !droppedArtifact.objectCast<Domain::Task>();
                        })) {
            return false;
        }

        foreach(const auto &droppedArtifact, droppedArtifacts) {
            auto childTask = droppedArtifact.objectCast<Domain::Task>();
            const auto job = taskRepository()->associate(parentTask, childTask);
            installHandler(job, tr("Cannot move task %1 as sub-task of %2").arg(childTask->title()).arg(parentTask->title()));
        }

        return true;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this, add, &listingDone] {
                add(createObject(1, QStringLiteral("ItemA")));
                add(createObject(2, QStringLiteral("ParentA")));
                listingDone = true;
            }
```

#### AUTO 


```{c}
auto item = job->items().at(0);
```

#### AUTO 


```{c}
auto expectedDelegate = Domain::Task::Delegate("John Doe", "john@doe.com");
```

#### LAMBDA EXPRESSION 


```{c}
[this, contentTypes] (const Domain::LiveQueryInput<Item>::AddFunction &add) {
        auto job = m_storage->fetchCollections(Akonadi::Collection::root(),
                                               StorageInterface::Recursive,
                                               contentTypes);
        Utils::JobHandler::install(job->kjob(), [this, job, add] {
            if (job->kjob()->error() != KJob::NoError)
                return;

            foreach (const auto &collection, job->collections()) {
                if (!m_serializer->isSelectedCollection(collection))
                    continue;

                auto job = m_storage->fetchItems(collection);
                Utils::JobHandler::install(job->kjob(), [this, job, add] {
                    if (job->kjob()->error() != KJob::NoError)
                        return;

                    foreach (const auto &item, job->items())
                        add(item);
                });
            }
        });
    }
```

#### AUTO 


```{c}
auto fetch = m_helpers->fetchCollections(Collection::root(), m_contentTypes);
```

#### LAMBDA EXPRESSION 


```{c}
[provider, job, this] {
                if (job->kjob()->error() != KJob::NoError)
                    return;

                for (auto item : job->items()) {
                    auto project = m_serializer->createProjectFromItem(item);
                    if (project)
                        provider->append(project);
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[](const Domain::Note::List &notes) -> QMimeData* {
        if (notes.isEmpty())
            return Q_NULLPTR;

        auto artifacts = Domain::Artifact::List();
        artifacts.reserve(notes.size());
        std::copy(notes.constBegin(), notes.constEnd(),
                  std::back_inserter(artifacts));

        auto data = new QMimeData;
        data->setData("application/x-zanshin-object", "object");
        data->setProperty("objects", QVariant::fromValue(artifacts));
        return data;
    }
```

#### AUTO 


```{c}
auto inQuery = Domain::LiveQueryOutput<Domain::Artifact::Ptr>::Ptr();
```

#### AUTO 


```{c}
auto drag = [] (const Domain::Task::List &tasks) -> QMimeData* {
        Q_UNUSED(tasks);
        qFatal("Drag Not implemented yet");
        return new QMimeData;
    };
```

#### AUTO 


```{c}
auto predicate = createSearchPredicate(Collection::root());
```

#### AUTO 


```{c}
auto &query = m_findChildren[item.id()];
```

#### AUTO 


```{c}
auto query = NoteQueries::NoteQuery::Ptr::create();
```

#### LAMBDA EXPRESSION 


```{c}
[job, add] {
            foreach (const auto &tag, job->tags())
                add(tag);
        }
```

#### AUTO 


```{c}
auto dataFunction = [](const QColor &, int) {
            return QVariant();
        };
```

#### AUTO 


```{c}
auto query = [this](const Domain::Note::Ptr &note) -> Domain::QueryResultInterface<Domain::Note::Ptr>::Ptr {
        if (!note)
            return m_noteQueries->findInbox();
        else
            return Domain::QueryResult<Domain::Note::Ptr>::Ptr();
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this, add] {
                add(createObject(0, QStringLiteral("ProjectA")));
                add(createObject(1, QStringLiteral("ItemA")));
                add(createObject(2, QStringLiteral("ParentA")));
            }
```

#### AUTO 


```{c}
const auto attachmentsInput = todo->attachments();
```

#### AUTO 


```{c}
auto setDataFunction = [&](const Domain::Task::Ptr &task, const QVariant &value, int role) {
            if (role != Qt::EditRole && role != Qt::CheckStateRole) {
                return false;
            }

            if (role == Qt::EditRole) {
                task->setTitle(value.toString());
            } else {
                task->setDone(value.toInt() == Qt::Checked);
            }

            repositoryMock.getInstance()->update(task);
            return true;
        };
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &collection : collections) {
        auto job = m_storage.fetchItems(collection);
        job->kjob()->exec();
        auto items = job->items();
        for (const Akonadi::Item &item : items) {
            if (item.hasPayload<KCalCore::Todo::Ptr>()) {
                auto todo = item.payload<KCalCore::Todo::Ptr>();
                hash.insert(todo->uid(), SeenItem(item));
            }
        }
    }
```

#### AUTO 


```{c}
auto childTask4 = model->data(model->index(4, 0), Presentation::QueryTreeModelBase::ObjectRole).value<Domain::Task::Ptr>();
```

#### AUTO 


```{c}
auto taskList = queries.findAll();
```

#### AUTO 


```{c}
auto data = model.mimeData(indexes);
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Akonadi::Collection &collection, Domain::DataSource::Ptr &source) {
            m_serializer->updateDataSourceFromCollection(source, collection, SerializerInterface::BaseName);
        }
```

#### AUTO 


```{c}
const auto defaultId = qint64(43);
```

#### AUTO 


```{c}
auto fetchAdditionalInfo = [this](const QModelIndex &index, const Domain::Task::Ptr &task) {
        return fetchTaskExtraData(m_taskQueries, TaskExtraPart::Project, index, task);
    };
```

#### AUTO 


```{c}
auto parentTask = task.objectCast<Domain::Task>();
```

#### LAMBDA EXPRESSION 


```{c}
[&] (const QColor &color) {
            if (!color.isValid())
                return Domain::QueryResult<QColor>::create(provider);
            else
                return Domain::QueryResult<QColor>::Ptr();
        }
```

#### AUTO 


```{c}
auto today = (QDateTime::currentDateTime());
```

#### LAMBDA EXPRESSION 


```{c}
[] (Utils::DependencyManager *deps) {
        auto model = new Presentation::ArtifactEditorModel;
        auto repository = deps->create<Domain::TaskRepository>();
        model->setSaveFunction([repository] (const Domain::Artifact::Ptr &artifact) {
            auto task = artifact.objectCast<Domain::Task>();
            Q_ASSERT(task);
            return repository->update(task);
        });
        model->setDelegateFunction([repository] (const Domain::Task::Ptr &task, const Domain::Task::Delegate &delegate) {
            return repository->delegate(task, delegate);
        });
        return model;
    }
```

#### AUTO 


```{c}
const auto noteType = Domain::DataSource::ContentTypes(Domain::DataSource::Notes);
```

#### AUTO 


```{c}
auto collections = m_collections;
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QModelIndex &index, const Domain::Artifact::Ptr &artifact) -> AdditionalInfo {
        if (auto task = artifact.dynamicCast<Domain::Task>()) {
            AdditionalInfo projectQueryResult = m_taskQueries->findProject(task);
            if (projectQueryResult) {
                QPersistentModelIndex persistentIndex(index);
                projectQueryResult->addPostInsertHandler([persistentIndex](const Domain::Project::Ptr &, int) {
                    // When a project was found (inserted into the result), update the rendering of the item
                    auto model = const_cast<QAbstractItemModel *>(persistentIndex.model());
                    model->dataChanged(persistentIndex, persistentIndex);
                });
            }
            return projectQueryResult;
        }
        return nullptr;
    }
```

#### AUTO 


```{c}
const auto item = m_cache->item(m_item.id());
```

#### AUTO 


```{c}
auto promoteAction = page.findChild<QAction*>("promoteItemAction");
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QObjectPtr &object, int role) -> QVariant {
        if (role != Qt::DisplayRole
         && role != Qt::EditRole
         && role != Qt::DecorationRole
         && role != QueryTreeModelBase::IconNameRole) {
            return QVariant();
        }

        if (role == Qt::EditRole
         && (object == m_inboxObject
          || object == m_workdayObject
          || object == m_projectsObject
          || object == m_contextsObject)) {
            return QVariant();
        }

        if (role == Qt::DisplayRole || role == Qt::EditRole) {
            return object->property("name").toString();
        } else if (role == Qt::DecorationRole || role == QueryTreeModelBase::IconNameRole) {
            const QString iconName = object == m_inboxObject ? "mail-folder-inbox"
                                   : (object == m_workdayObject)  ? "go-jump-today"
                                   : (object == m_projectsObject) ? "folder"
                                   : (object == m_contextsObject) ? "folder"
                                   : object.objectCast<Domain::Context>() ? "view-pim-notes"
                                   : "view-pim-tasks";

            if (role == Qt::DecorationRole)
                return QVariant::fromValue(QIcon::fromTheme(iconName));
            else
                return iconName;
        } else {
            return QVariant();
        }
    }
```

#### AUTO 


```{c}
const auto defaultSource = data.value<Domain::DataSource::Ptr>();
```

#### AUTO 


```{c}
auto delegate = Domain::Task::Delegate(name, email);
```

#### LAMBDA EXPRESSION 


```{c}
[this] (Utils::DependencyManager *deps) {
        Q_UNUSED(deps)
        return createMonitor();
    }
```

#### AUTO 


```{c}
auto weakResult
```

#### LAMBDA EXPRESSION 


```{c}
[] (Utils::DependencyManager *deps) {
        return new Akonadi::DataSourceRepository(Akonadi::StorageInterface::Tasks,
                                                 deps->create<Akonadi::StorageInterface>(),
                                                 deps->create<Akonadi::SerializerInterface>());
    }
```

#### AUTO 


```{c}
const auto parentIndex = pageModel.centralListModel()->index(0, 0);
```

#### AUTO 


```{c}
auto job = storage.fetchItem(Akonadi::Item(44), nullptr);
```

#### AUTO 


```{c}
auto addAttachmentButton = editor.findChild<QToolButton*>(QStringLiteral("addAttachmentButton"));
```

#### AUTO 


```{c}
auto it = availableSourcesGlobalActions.cbegin();
```

#### LAMBDA EXPRESSION 


```{c}
[add, job, storage] {
                foreach (const auto &col, job->collections()) {
                    auto itemJob = storage->fetchItems(col);
                    Utils::JobHandler::install(itemJob->kjob(), [add, itemJob] {
                        foreach (const auto &item, itemJob->items())
                            add(item);
                    });
                }
            }
```

#### AUTO 


```{c}
auto tag = m_serializer->createTagFromContext(context);
```

#### AUTO 


```{c}
auto attachments = m_task->attachments();
```

#### AUTO 


```{c}
auto actions = actionsForSource(source, true, m_actionsEnabled);
```

#### AUTO 


```{c}
auto drop = [this] (const QMimeData *mimeData, Qt::DropAction, const Domain::Task::Ptr &parentTask) {
        if (!mimeData->hasFormat("application/x-zanshin-object"))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                        [](const Domain::Artifact::Ptr &droppedArtifact) {
                            return !droppedArtifact.objectCast<Domain::Task>();
                        })) {
            return false;
        }

        using namespace std::placeholders;
        auto associate = std::function<KJob*(Domain::Task::Ptr)>();
        auto dissociate = std::function<KJob*(Domain::Task::Ptr)>();
        auto parentTitle = QString();

        if (parentTask) {
            associate = std::bind(&Domain::TaskRepository::associate, m_taskRepository, parentTask, _1);
            dissociate = [] (Domain::Task::Ptr) -> KJob* { return Q_NULLPTR; };
            parentTitle = parentTask->title();
        } else {
            associate = std::bind(&Domain::ContextRepository::associate, m_contextRepository, m_context, _1);
            dissociate = std::bind(&Domain::TaskRepository::dissociate, m_taskRepository, _1);
            parentTitle = m_context->name();
        }

        foreach(const Domain::Artifact::Ptr &droppedArtifact, droppedArtifacts) {
            auto childTask = droppedArtifact.objectCast<Domain::Task>();
            auto job = associate(childTask);
            installHandler(job, tr("Cannot move task %1 as sub-task of %2").arg(childTask->title(), parentTitle));
            job = dissociate(childTask);
            if (job)
                installHandler(job, tr("Cannot dissociate task %1 from its parent").arg(childTask->title()));
        }

        return true;
    };
```

#### AUTO 


```{c}
auto notifiedCollection = changeSpy.takeFirst().at(0).value<Akonadi::Collection>();
```

#### AUTO 


```{c}
auto job = new Akonadi::TagDeleteJob(tag);
```

#### AUTO 


```{c}
auto tag1 = Domain::Tag::Ptr::create();
```

#### AUTO 


```{c}
auto job = m_storage->fetchTagItems(tag);
```

#### LAMBDA EXPRESSION 


```{c}
[fetchItemJob, job, this] {
        if (fetchItemJob->kjob()->error() != KJob::NoError)
            return;

        Q_ASSERT(fetchItemJob->items().size() == 1);
        auto childItem = fetchItemJob->items().at(0);
        foreach (const Tag &tag, childItem.tags())
            childItem.clearTag(tag);

        auto updateJob = m_storage->updateItem(childItem);
        job->addSubjob(updateJob);
        updateJob->start();
    }
```

#### AUTO 


```{c}
auto item = fetchItemJob->items().first();
```

#### AUTO 


```{c}
const auto job = m_projectRepository->create(project, source);
```

#### AUTO 


```{c}
const auto job = taskRepository()->update(task);
```

#### AUTO 


```{c}
auto addAction = available.findChild<QAction*>("addAction");
```

#### AUTO 


```{c}
const auto tagProperty = tag->property("tagId");
```

#### LAMBDA EXPRESSION 


```{c}
[](const Domain::Task::Ptr &, const QVariant &, int) {
            return false;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[fetchChildrenItemJob, childItem, parentItem, job, this] {
                    if (fetchChildrenItemJob->kjob()->error() != KJob::NoError)
                        return;

                    Item::List childItems = m_serializer->filterDescendantItems(fetchChildrenItemJob->items(), childItem);

                    auto transaction = m_storage->createTransaction(this);
                    m_storage->updateItem(childItem, transaction);
                    childItems.push_front(childItem);
                    m_storage->moveItems(childItems, parentItem.parentCollection(), transaction);
                    job->addSubjob(transaction);
                    transaction->start();
                }
```

#### AUTO 


```{c}
auto job = storage->fetchItem(findItem);
```

#### AUTO 


```{c}
const auto dueDateRect = opt.rect.adjusted(opt.rect.width() - dueDateWidth, 0, 0, 0);
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QModelIndex &currentIndex) {
            return currentIndex.isValid() && indexHasChildren(currentIndex); }
```

#### AUTO 


```{c}
auto query = [this] (const Domain::DataSource::Ptr &source) {
        if (!source)
            return m_dataSourceQueries->findTopLevel();
        else
            return m_dataSourceQueries->findChildren(source);
    };
```

#### AUTO 


```{c}
const auto collection = Akonadi::Collection(GenCollection().withRootAsParent()
                                                                   .withId(1)
                                                                   .withName("tasks")
                                                                   .withTaskContent());
```

#### AUTO 


```{c}
auto msgbox = MessageBoxStub::Ptr::create();
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Domain::DataSource::Ptr &source, int role) -> QVariant {
        if (role != Qt::DisplayRole
         && role != Qt::EditRole
         && role != Qt::DecorationRole
         && role != Qt::CheckStateRole
         && role != QueryTreeModelBase::IconNameRole
         && role != QueryTreeModelBase::IsDefaultRole) {
            return QVariant();
        }

        if (role == Qt::DisplayRole || role == Qt::EditRole) {
            return source->name();
        } else if (role == Qt::DecorationRole || role == QueryTreeModelBase::IconNameRole) {
            const QString iconName = source->iconName().isEmpty() ? QStringLiteral("folder") : source->iconName();

            if (role == Qt::DecorationRole)
                return QVariant::fromValue(QIcon::fromTheme(iconName));
            else
                return iconName;
        } else if (role == Qt::CheckStateRole) {
            if (source->contentTypes() != Domain::DataSource::NoContent)
                return source->isSelected() ? Qt::Checked : Qt::Unchecked;
            else
                return QVariant();
        } else if (role == QueryTreeModelBase::IsDefaultRole) {
            return m_dataSourceQueries->isDefaultSource(source);
        } else {
            return QVariant();
        }
    }
```

#### AUTO 


```{c}
auto inPredicate = [] (const Akonadi::Item &item) {
            return titleFromItem(item).endsWith("-in");
        };
```

#### AUTO 


```{c}
auto setData = [this](const Domain::Note::Ptr &note, const QVariant &value, int role) {
        if (role != Qt::EditRole) {
            return false;
        }

        const auto currentTitle = note->title();
        note->setTitle(value.toString());
        const auto job = m_noteRepository->update(note);
        installHandler(job, tr("Cannot modify note %1 in Inbox").arg(currentTitle));
        return true;
    };
```

#### AUTO 


```{c}
auto notes = app.noteSourcesModel();
```

#### LAMBDA EXPRESSION 


```{c}
[storage] (const Domain::LiveQueryInput<Akonadi::Collection>::AddFunction &add) {
            auto job = storage->fetchCollections(Akonadi::Collection::root(), Akonadi::Storage::Recursive, Akonadi::Storage::AllContent);
            Utils::JobHandler::install(job->kjob(), [add, job] {
                foreach (const auto &col, job->collections()) {
                    add(col);
                }
            });
        }
```

#### LAMBDA EXPRESSION 


```{c}
[storage, parent] (const Domain::LiveQueryInput<Akonadi::Collection>::AddFunction &add) {
            auto job = storage->fetchCollections(Akonadi::Collection::root(), Akonadi::Storage::Recursive, parent);
            Utils::JobHandler::install(job->kjob(), [add, job] {
                foreach (const auto &col, job->collections()) {
                    add(col);
                }
            });
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Tag &tag : tags) {
            tagGids << tag.gid();
            QVERIFY(!tag.name().isEmpty());
            QVERIFY(!tag.type().isEmpty());
        }
```

#### AUTO 


```{c}
auto treeData = [](const Domain::Task::Ptr &task, int role, int) -> QVariant {
        if (role != Qt::DisplayRole && role != Qt::CheckStateRole) {
            return QVariant();
        }

        if (role == Qt::DisplayRole)
            return task->title();
        else
            return task->isDone() ? Qt::Checked : Qt::Unchecked;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QMimeData *mimeData, Qt::DropAction, const QObjectPtr &object) {
        if (!mimeData->hasFormat(QStringLiteral("application/x-zanshin-object")))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (auto project = object.objectCast<Domain::Project>()) {
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                const auto job = m_projectRepository->associate(project, droppedArtifact);
                installHandler(job, i18n("Cannot add %1 to project %2", droppedArtifact->title(), project->name()));
            }
            return true;
        } else if (auto context = object.objectCast<Domain::Context>()) {
            if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                            [](const Domain::Artifact::Ptr &droppedArtifact) {
                                return !droppedArtifact.objectCast<Domain::Task>();
                            })) {
                return false;
            }
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                auto task = droppedArtifact.staticCast<Domain::Task>();
                const auto job = m_contextRepository->associate(context, task);
                installHandler(job, i18n("Cannot add %1 to context %2", task->title(), context->name()));
            }
            return true;
        } else if (object == m_inboxObject) {
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                const auto job = m_projectRepository->dissociate(droppedArtifact);
                installHandler(job, i18n("Cannot move %1 to Inbox", droppedArtifact->title()));

                if (auto task = droppedArtifact.objectCast<Domain::Task>()) {
                    Utils::JobHandler::install(job, [this, task] {
                        const auto dissociateJob = m_taskRepository->dissociateAll(task);
                        installHandler(dissociateJob, i18n("Cannot move task %1 to Inbox", task->title()));
                    });
                }
            }
            return true;
        } else if (object == m_workdayObject) {
            foreach (const auto &droppedArtifact, droppedArtifacts) {

                if (auto task = droppedArtifact.objectCast<Domain::Task>()) {

                    task->setStartDate(Utils::DateTime::currentDateTime());
                    const auto job = m_taskRepository->update(task);

                    installHandler(job, i18n("Cannot update task %1 to Workday", task->title()));
                }
            }
            return true;
        }

        return false;
    }
```

#### AUTO 


```{c}
auto todo2 = KCalCore::Todo::Ptr::create();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto handler : handlerGetter(result))
            {
                handler(item, index);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[&insertHandlerCalled](const Domain::Artifact::Ptr &, int) {
                                          insertHandlerCalled = true;
                                      }
```

#### AUTO 


```{c}
auto drop = [this] (const QMimeData *mimeData, Qt::DropAction, const Domain::Artifact::Ptr &artifact) {
        auto parentTask = artifact.objectCast<Domain::Task>();
        if (!parentTask)
            return false;

        if (!mimeData->hasFormat("application/x-zanshin-object"))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                        [](const Domain::Artifact::Ptr &droppedArtifact) {
                            return !droppedArtifact.objectCast<Domain::Task>();
                        })) {
            return false;
        }

        foreach(const Domain::Artifact::Ptr &droppedArtifact, droppedArtifacts) {
            auto childTask = droppedArtifact.objectCast<Domain::Task>();
            const auto job = m_taskRepository->associate(parentTask, childTask);
            installHandler(job, tr("Cannot move task %1 as sub-task of %2").arg(childTask->title()).arg(parentTask->title()));
        }

        return true;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[add, job, storage] {
                foreach (const auto &col, job->collections()) {
                    auto itemJob = storage->fetchItems(col, nullptr);
                    Utils::JobHandler::install(itemJob->kjob(), [add, itemJob] {
                        foreach (const auto &item, itemJob->items())
                            add(item);
                    });
                }
            }
```

#### AUTO 


```{c}
auto query = [this] (const Domain::Task::Ptr &task) -> Domain::QueryResultInterface<Domain::Task::Ptr>::Ptr {
        if (!task)
            return m_contextQueries->findTopLevelTasks(m_context);
        else
            return taskQueries()->findChildren(task);
    };
```

#### LAMBDA EXPRESSION 


```{c}
[] (const QColor &, const QVariant &, int) {
            return false;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Akonadi::Item &item) {
            return m_serializer->isProjectItem(item);
        }
```

#### AUTO 


```{c}
auto result = fetchAllItems(WhichItems::TasksToConvert);
```

#### AUTO 


```{c}
auto name = QString();
```

#### AUTO 


```{c}
auto job = dynamic_cast<TagFetchJobInterface*>(kjob);
```

#### AUTO 


```{c}
auto drop = [this] (const QMimeData *mimeData, Qt::DropAction, const Domain::Task::Ptr &parentTask) {
        if (!mimeData->hasFormat("application/x-zanshin-object"))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                        [](const Domain::Artifact::Ptr &droppedArtifact) {
                            return !droppedArtifact.objectCast<Domain::Task>();
                        })) {
            return false;
        }

        foreach(const Domain::Artifact::Ptr &droppedArtifact, droppedArtifacts) {
            auto childTask = droppedArtifact.objectCast<Domain::Task>();
            const auto job = m_taskRepository->associate(parentTask, childTask);
            installHandler(job, tr("Cannot move task %1 as sub-task of %2").arg(childTask->title()).arg(parentTask->title()));
        }

        return true;
    };
```

#### AUTO 


```{c}
const auto taskType = Domain::DataSource::ContentTypes(Domain::DataSource::Tasks);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &tag : allTags) {
            if (tag.type() == s_contextTagType) {
                auto context = Domain::Context::Ptr::create();
                context->setName(tag.name());
                const auto tagUid = m_tagUids.value(tag.id());
                if (tagUid.isEmpty())
                    qWarning() << "Item" << item.id() << "uses unknown tag" << tag.id() << tag.name();
                context->setProperty("todoUid", tagUid);
                m_serializer.addContextToTask(context, item);
                auto job = new Akonadi::ItemModifyJob(item);
                if (job->exec()) {
                    item = job->item();
                    ++count;
                } else {
                    qWarning() << "Failure to associate context" << tag.name() << "to task:" << job->errorString();
                }
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[provider, job, this] {
        for (auto collection : job->collections()) {
            ItemFetchJobInterface *job = m_storage->fetchItems(collection);
            Utils::JobHandler::install(job->kjob(), [provider, job, this] {
                for (auto item : job->items()) {
                    auto note = deserializeNote(item);
                    if (note)
                        provider->append(note);
                }
            });
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Domain::Artifact::Ptr &artifact) -> Domain::QueryResultInterface<Domain::Artifact::Ptr>::Ptr {
        if (!artifact)
            return m_projectQueries->findTopLevelArtifacts(m_project);
        else if (auto task = artifact.dynamicCast<Domain::Task>())
            return Domain::QueryResult<Domain::Task::Ptr, Domain::Artifact::Ptr>::copy(m_taskQueries->findChildren(task));
        else
            return Domain::QueryResult<Domain::Artifact::Ptr>::Ptr();
    }
```

#### AUTO 


```{c}
auto sourceResult = Domain::QueryResult<Domain::DataSource::Ptr>::create(sourceProvider);
```

#### AUTO 


```{c}
auto item = m_serializer->createItemFromProject(project);
```

#### AUTO 


```{c}
auto delegateHBox = new QHBoxLayout;
```

#### AUTO 


```{c}
auto project = object.objectCast<Domain::Project>()
```

#### LAMBDA EXPRESSION 


```{c}
[](const Domain::Artifact::Ptr &artifact) {
        const auto defaultFlags = Qt::ItemIsSelectable
                                | Qt::ItemIsEnabled
                                | Qt::ItemIsEditable
                                | Qt::ItemIsDragEnabled;

        const auto taskFlag = defaultFlags
                            | Qt::ItemIsUserCheckable
                            | Qt::ItemIsDropEnabled;

        return artifact.dynamicCast<Domain::Task>() ? taskFlag : defaultFlags;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[fetchItemJob, parent, child, job, this] {
        if (fetchItemJob->kjob()->error() != KJob::NoError)
           return;

        Q_ASSERT(fetchItemJob->items().size() == 1);
        auto childItem = fetchItemJob->items().at(0);
        m_serializer->updateItemProject(childItem, parent);

        // Check collections to know if we need to move child
        auto parentItem = m_serializer->createItemFromProject(parent);
        ItemFetchJobInterface *fetchParentItemJob = m_storage->fetchItem(parentItem);
        job->install(fetchParentItemJob->kjob(), [fetchParentItemJob, child, childItem, job, this] {
            if (fetchParentItemJob->kjob()->error() != KJob::NoError)
                return;

            Q_ASSERT(fetchParentItemJob->items().size() == 1);
            auto parentItem = fetchParentItemJob->items().at(0);

            const int itemCollectionId = childItem.parentCollection().id();
            const int parentCollectionId = parentItem.parentCollection().id();

            if (child.objectCast<Domain::Task>()
             && itemCollectionId != parentCollectionId) {
                ItemFetchJobInterface *fetchChildrenItemJob = m_storage->fetchItems(childItem.parentCollection());
                job->install(fetchChildrenItemJob->kjob(), [fetchChildrenItemJob, childItem, parentItem, job, this] {
                    if (fetchChildrenItemJob->kjob()->error() != KJob::NoError)
                        return;

                    Item::List childItems = m_serializer->filterDescendantItems(fetchChildrenItemJob->items(), childItem);

                    auto transaction = m_storage->createTransaction();
                    m_storage->updateItem(childItem, transaction);
                    childItems.push_front(childItem);
                    m_storage->moveItems(childItems, parentItem.parentCollection(), transaction);
                    job->addSubjob(transaction);
                    transaction->start();
                });
            } else {
                auto updateJob = m_storage->updateItem(childItem);
                job->addSubjob(updateJob);
                updateJob->start();
            }
        });
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, item] (const TaskQuery::AddFunction &add) {
            ItemFetchJobInterface *job = m_storage->fetchItem(item);
            Utils::JobHandler::install(job->kjob(), [this, job, add] {
                if (job->kjob()->error() != KJob::NoError)
                    return;

                Q_ASSERT(job->items().size() == 1);
                auto item = job->items()[0];
                Q_ASSERT(item.parentCollection().isValid());
                ItemFetchJobInterface *job = m_storage->fetchItems(item.parentCollection());
                Utils::JobHandler::install(job->kjob(), [this, job, add] {
                    if (job->kjob()->error() != KJob::NoError)
                        return;

                    for (auto item : job->items())
                        add(item);
                });
            });
        }
```

#### AUTO 


```{c}
auto collections = Akonadi::Collection::List();
```

#### AUTO 


```{c}
auto drag = [] (const Domain::Task::List &tasks) -> QMimeData* {
        if (tasks.isEmpty())
            return Q_NULLPTR;

        auto draggedArtifacts = Domain::Artifact::List();
        foreach (const Domain::Task::Ptr &task, tasks) {
            draggedArtifacts.append(task.objectCast<Domain::Artifact>());
        }

        auto data = new QMimeData();
        data->setData("application/x-zanshin-object", "object");
        data->setProperty("objects", QVariant::fromValue(draggedArtifacts));
        return data;
    };
```

#### AUTO 


```{c}
const auto tag2 = Akonadi::Tag(GenTag().withId(2).asContext().withName("tag2"));
```

#### AUTO 


```{c}
const auto taskFlag = defaultFlags
                            | Qt::ItemIsUserCheckable
                            | Qt::ItemIsDropEnabled;
```

#### AUTO 


```{c}
auto job = storage->fetchItems(childItem.parentCollection());
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QObjectPtr &object) {
        const Qt::ItemFlags defaultFlags = Qt::ItemIsSelectable
                                         | Qt::ItemIsEnabled
                                         | Qt::ItemIsEditable
                                         | Qt::ItemIsDropEnabled;
        const Qt::ItemFlags immutableNodeFlags = Qt::ItemIsSelectable
                                               | Qt::ItemIsEnabled
                                               | Qt::ItemIsDropEnabled;
        const Qt::ItemFlags nonDroppableNodeFlags = Qt::ItemIsSelectable
                                                  | Qt::ItemIsEnabled;
        const Qt::ItemFlags structureNodeFlags = Qt::NoItemFlags;

        return object.objectCast<Domain::Project>() ? defaultFlags
             : object.objectCast<Domain::Context>() ? defaultFlags
             : object == m_inboxObject ? immutableNodeFlags
             : object == m_workdayObject ? immutableNodeFlags
             : object == m_allTasksObject ? nonDroppableNodeFlags
             : structureNodeFlags;
    }
```

#### AUTO 


```{c}
auto predicate = [] (const Akonadi::Collection &collection) {
            return collection.name().endsWith("-in");
        };
```

#### AUTO 


```{c}
const auto xmlFile = QString::fromLocal8Bit(qgetenv("ZANSHIN_USER_XMLDATA"));
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Domain::Task::Ptr &task) -> Domain::QueryResultInterface<Domain::Task::Ptr>::Ptr {
        if (!task)
            return m_contextQueries->findTopLevelTasks(m_context);
        else
            return m_taskQueries->findChildren(task);
    }
```

#### AUTO 


```{c}
auto context1 = Domain::Context::Ptr::create();
```

#### AUTO 


```{c}
auto contextUids = QStringList();
```

#### AUTO 


```{c}
const auto &newTag
```

#### AUTO 


```{c}
auto emptyResult = Domain::QueryResult<Domain::Task::Ptr>::create(emptyProvider);
```

#### AUTO 


```{c}
auto handler = [&]() {
            compositeJob->emitError("Error reached");
        };
```

#### AUTO 


```{c}
auto root2 = createSourceItem(QStringLiteral("Root 2"));
```

#### AUTO 


```{c}
auto data = [](const Domain::Note::Ptr &note, int role, int) -> QVariant {
        if (role == Qt::DisplayRole || role == Qt::EditRole) {
            return note->title();
        } else {
            return QVariant();
        }
    };
```

#### AUTO 


```{c}
auto startDateEdit = editor.findChild<KPIM::KDateEdit*>("startDateEdit");
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const QMimeData *mimeData, Qt::DropAction, const Domain::Artifact::Ptr &artifact) {
        auto parentTask = artifact.objectCast<Domain::Task>();
        if (!parentTask)
            return false;

        if (!mimeData->hasFormat("application/x-zanshin-object"))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                        [](const Domain::Artifact::Ptr &droppedArtifact) {
                            return !droppedArtifact.objectCast<Domain::Task>();
                        })) {
            return false;
        }

        foreach(const Domain::Artifact::Ptr &droppedArtifact, droppedArtifacts) {
            auto childTask = droppedArtifact.objectCast<Domain::Task>();
            const auto job = m_taskRepository->associate(parentTask, childTask);
            installHandler(job, tr("Cannot move task %1 as sub-task of %2").arg(childTask->title()).arg(parentTask->title()));
        }

        return true;
    }
```

#### AUTO 


```{c}
auto update = new Akonadi::CollectionModifyJob(cal1);
```

#### LAMBDA EXPRESSION 


```{c}
[](const Domain::Task::List &tasks) -> QMimeData* {
        if (tasks.isEmpty())
            return Q_NULLPTR;

        auto draggedArtifacts = Domain::Artifact::List();
        draggedArtifacts.reserve(tasks.size());
        foreach (const Domain::Task::Ptr &task, tasks) {
            draggedArtifacts.append(task.objectCast<Domain::Artifact>());
        }

        auto data = new QMimeData;
        data->setData(QStringLiteral("application/x-zanshin-object"), "object");
        data->setProperty("objects", QVariant::fromValue(draggedArtifacts));
        return data;
    }
```

#### AUTO 


```{c}
auto storage = createCachingStorage(data, cache);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QObjectPtr &object, const QVariant &value, int role) {
        if (role != Qt::EditRole) {
            return false;
        }

        if (object == m_inboxObject || object == m_projectsObject) {
            return false;
        }

        auto project = object.objectCast<Domain::Project>();
        Q_ASSERT(project);
        project->setName(value.toString());
        m_projectRepository->update(project);
        return true;
    }
```

#### AUTO 


```{c}
const auto data = index.data(Presentation::QueryTreeModel<Domain::DataSource::Ptr>::ObjectRole);
```

#### AUTO 


```{c}
auto defaultAction = available.findChild<QAction*>(QStringLiteral("defaultAction"));
```

#### AUTO 


```{c}
auto parent = Domain::Project::Ptr::create();
```

#### AUTO 


```{c}
auto task
```

#### AUTO 


```{c}
auto result = queries->findChildren(task);
```

#### AUTO 


```{c}
const auto source = data.value<Domain::DataSource::Ptr>();
```

#### LAMBDA EXPRESSION 


```{c}
[&](const Base::Ptr &value, int pos)
            {
                postInserts << value;
                postInsertsPos << pos;
            }
```

#### AUTO 


```{c}
const auto currentIndex = m_sourcesView->currentIndex();
```

#### AUTO 


```{c}
auto itemDeleteJob = new MockAkonadiJob(this);
```

#### AUTO 


```{c}
auto predicate = [this] (const Akonadi::Item &item) {
        const bool excluded = !m_serializer->isTaskItem(item)
                           || !m_serializer->relatedUidFromItem(item).isEmpty();

        return !excluded;
    };
```

#### AUTO 


```{c}
auto data = model.mimeData(QList<QModelIndex>() << model.index(1, 0) << model.index(2, 0));
```

#### AUTO 


```{c}
const auto parent = model.index(1, 0, model.index(0, 0, model.index(1, 0)));
```

#### AUTO 


```{c}
auto proxy = ui->sourceCombo->model();
```

#### AUTO 


```{c}
auto drop = [this](const QMimeData *mimeData, Qt::DropAction, const QObjectPtr &object) {
        auto project = object.objectCast<Domain::Project>();
        if (!project)
            return false;

        if (!mimeData->hasFormat("application/x-zanshin-object"))
            return false;

        auto artifact = mimeData->property("object").value<Domain::Artifact::Ptr>();
        if (!artifact)
            return false;

        m_projectRepository->associate(project, artifact);
        return true;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[fetchItemJob, child, parent, job, this] {
        if (fetchItemJob->kjob()->error() != KJob::NoError)
           return;

        Q_ASSERT(fetchItemJob->items().size() == 1);
        auto childItem = fetchItemJob->items().at(0);
        m_serializer->updateItemParent(childItem, parent);

        // Check collections to know if we need to move child
        auto partialParentItem = m_serializer->createItemFromTask(parent);
        ItemFetchJobInterface *fetchParentItemJob = m_storage->fetchItems(partialParentItem.parentCollection());
        job->install(fetchParentItemJob->kjob(), [child, parent, fetchParentItemJob, partialParentItem, childItem, job, this] {
            if (fetchParentItemJob->kjob()->error() != KJob::NoError)
                return;

            const auto items = fetchParentItemJob->items();
            const auto parentIndex = items.indexOf(partialParentItem);
            Q_ASSERT(parentIndex >= 0);
            const auto parentItem = items.at(parentIndex);

            // TODO Qt5: This is a bit wasteful, add an itemUid on the serializer
            const auto childUid = m_serializer->objectUid(m_serializer->createTaskFromItem(childItem));
            auto relatedUid = m_serializer->relatedUidFromItem(parentItem);
            while (!relatedUid.isEmpty()) {
                if (relatedUid == childUid) {
                    job->emitError(i18n("Could not associate '%1', it is an ancestor of '%2'",
                                        child->title(),
                                        parent->title()));
                    return;
                }

                auto it = std::find_if(items.constBegin(), items.constEnd(),
                                       [relatedUid, this] (const Akonadi::Item &item) {
                    // TODO Qt5: This is a bit wasteful, add an itemUid on the serializer
                    auto task = m_serializer->createTaskFromItem(item);
                    return task && m_serializer->objectUid(task) == relatedUid;
                });
                if (it == items.end())
                    break;

                relatedUid = m_serializer->relatedUidFromItem(*it);
            }

            const int itemCollectionId = childItem.parentCollection().id();
            const int parentCollectionId = parentItem.parentCollection().id();

            if (itemCollectionId != parentCollectionId) {
                ItemFetchJobInterface *fetchChildrenItemJob = m_storage->fetchItems(childItem.parentCollection());
                job->install(fetchChildrenItemJob->kjob(), [fetchChildrenItemJob, childItem, parentItem, job, this] {
                    if (fetchChildrenItemJob->kjob()->error() != KJob::NoError)
                        return;

                    Item::List childItems = m_serializer->filterDescendantItems(fetchChildrenItemJob->items(), childItem);

                    auto transaction = m_storage->createTransaction();
                    m_storage->updateItem(childItem, transaction);
                    childItems.push_front(childItem);
                    m_storage->moveItems(childItems, parentItem.parentCollection(), transaction);
                    job->addSubjob(transaction);
                    transaction->start();
                });
            } else {
                auto updateJob = m_storage->updateItem(childItem);
                job->addSubjob(updateJob);
                updateJob->start();
            }
        });
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Akonadi::Item &item) {
            const bool excluded = !m_serializer->relatedUidFromItem(item).isEmpty()
                               || (!m_serializer->isTaskItem(item) && !m_serializer->isNoteItem(item))
                               || (m_serializer->isTaskItem(item) && m_serializer->hasContextTags(item))
                               || m_serializer->hasAkonadiTags(item);

            return !excluded;
        }
```

#### AUTO 


```{c}
auto job = storage->fetchCollections(Akonadi::Collection::root(),
                                         Akonadi::Storage::Recursive,
                                         nullptr);
```

#### AUTO 


```{c}
auto item = new QStandardItem(name);
```

#### AUTO 


```{c}
auto &query = m_findTopLevel[item.id()];
```

#### AUTO 


```{c}
auto context = object.objectCast<Domain::Context>()
```

#### AUTO 


```{c}
const auto toItemIds = [](const Akonadi::Item::List &items) {
            auto res = QVector<Akonadi::Item::Id>();
            std::transform(items.cbegin(), items.cend(),
                           std::back_inserter(res),
                           std::mem_fn(&Akonadi::Item::id));
            std::sort(res.begin(), res.end());
            return res;
        };
```

#### AUTO 


```{c}
auto hbox = new QHBoxLayout;
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
            compositeJob->emitError("Error reached");
        }
```

#### AUTO 


```{c}
auto index = model.index(i, 0, model.index(0, 0));
```

#### AUTO 


```{c}
const auto contextUids = todo->customProperty(Serializer::customPropertyAppName(),
                                                  Serializer::customPropertyContextList()).split(',', Qt::SkipEmptyParts);
```

#### AUTO 


```{c}
auto closeButton = messageWidget->findChildren<QToolButton*>().first();
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Domain::LiveQueryInput<Tag>::AddFunction &add) {
        auto job = m_storage->fetchTags();
        Utils::JobHandler::install(job->kjob(), [this, job, add] {
            foreach (const auto &tag, job->tags())
                add(tag);
        });
    }
```

#### AUTO 


```{c}
auto fetch = helpers->fetchItemsForContext(context, nullptr);
```

#### AUTO 


```{c}
auto expectedSource = model.item(userInput.comboIndex)
                                   ->data(Presentation::QueryTreeModelBase::ObjectRole)
                                   .value<Domain::DataSource::Ptr>();
```

#### LAMBDA EXPRESSION 


```{c}
[fetchItemJob, parent, job, this] {
        if (fetchItemJob->kjob()->error() != KJob::NoError)
            return;

        Q_ASSERT(fetchItemJob->items().size() == 1);
        auto childItem = fetchItemJob->items().first();
        auto tag = m_serializer->createTagFromContext(parent);
        Q_ASSERT(tag.isValid());
        childItem.setTag(tag);

        auto updateJob = m_storage->updateItem(childItem);
        job->addSubjob(updateJob);
        updateJob->start();
    }
```

#### AUTO 


```{c}
auto drop = [this](const QMimeData *mimeData, Qt::DropAction, const Domain::Artifact::Ptr &artifact) {
        auto parentTask = artifact.objectCast<Domain::Task>();

        if (!mimeData->hasFormat("application/x-zanshin-object"))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                        [](const Domain::Artifact::Ptr &droppedArtifact) {
                            return !droppedArtifact.objectCast<Domain::Task>();
                        })) {
            return false;
        }

        foreach(const auto &droppedArtifact, droppedArtifacts) {
            auto childTask = droppedArtifact.objectCast<Domain::Task>();

            if (!childTask)
                return false;

            childTask->setStartDate(Utils::DateTime::currentDateTime());
            const auto job = taskRepository()->update(childTask);
            installHandler(job, tr("Cannot update task %1 to Workday").arg(childTask->title()));

            if (parentTask) {
                const auto job = taskRepository()->associate(parentTask, childTask);
                installHandler(job, tr("Cannot move task %1 as sub-task of %2").arg(childTask->title()).arg(parentTask->title()));
            } else {
                const auto job = taskRepository()->dissociate(childTask);
                installHandler(job, tr("Cannot deparent task %1 from its parent").arg(childTask->title()));
            }
        }

        return true;
    };
```

#### AUTO 


```{c}
const auto job = index.parent().isValid() ? m_taskRepository->dissociate(task)
                   : m_contextRepository->dissociate(m_context, task);
```

#### AUTO 


```{c}
const auto today = Utils::DateTime::currentDate();
```

#### AUTO 


```{c}
auto setData = [this](const Domain::Artifact::Ptr &artifact, const QVariant &value, int role) {
        if (role != Qt::EditRole && role != Qt::CheckStateRole) {
            return false;
        }

        if (auto task = artifact.dynamicCast<Domain::Task>()) {
            if (role == Qt::EditRole)
                task->setTitle(value.toString());
            else
                task->setDone(value.toInt() == Qt::Checked);

            taskRepository()->update(task);
            return true;

        } else if (auto note = artifact.dynamicCast<Domain::Note>()) {
            if (role != Qt::EditRole)
                return false;

            note->setTitle(value.toString());
            noteRepository()->save(note);
            return true;

        }

        return false;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[](const Domain::Artifact::List &artifacts) -> QMimeData* {
        if (artifacts.isEmpty())
            return Q_NULLPTR;

        auto data = new QMimeData;
        data->setData(QStringLiteral("application/x-zanshin-object"), "object");
        data->setProperty("objects", QVariant::fromValue(artifacts));
        return data;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Domain::DataSource::Ptr &source) {
        if (!source)
            return m_dataSourceQueries->findSearchTopLevel();
        else
            return m_dataSourceQueries->findSearchChildren(source);
    }
```

#### AUTO 


```{c}
auto expression = QString("41+1");
```

#### LAMBDA EXPRESSION 


```{c}
[] (const QMimeData *, Qt::DropAction, const QColor &) {
            return false;
        }
```

#### AUTO 


```{c}
auto fetch = m_helpers->fetchCollections(root);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto collection : job->collections()) {
            ItemFetchJobInterface *job = m_storage->fetchItems(collection);
            Utils::JobHandler::install(job->kjob(), [provider, job, this] {
                if (job->kjob()->error() != KJob::NoError)
                    return;

                for (auto item : job->items()) {
                    auto project = m_serializer->createProjectFromItem(item);
                    if (project)
                        provider->append(project);
                }
            });
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Akonadi::Item &item) {
        return m_serializer->relatedUidFromItem(item).isEmpty() && m_serializer->isTaskItem(item);
    }
```

#### AUTO 


```{c}
auto result = queries->findAll();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto collection : job->collections()) {
            ItemFetchJobInterface *job = m_storage->fetchItems(collection);
            Utils::JobHandler::install(job->kjob(), [provider, job, this] {
                if (job->kjob()->error() != KJob::NoError)
                    return;

                for (auto item : job->items()) {
                    if (m_serializer->relatedUidFromItem(item).isEmpty()) {
                        auto task = deserializeTask(item);
                        if (task)
                            provider->append(task);
                    }
                }
            });
        }
```

#### AUTO 


```{c}
const auto collections = cache->allCollections();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto collection : job->collections()) {
                    ItemFetchJobInterface *job = m_storage->fetchItems(collection);
                    Utils::JobHandler::install(job->kjob(), [this, job, add] {
                        if (job->kjob()->error() != KJob::NoError)
                            return;

                        for (auto item : job->items())
                            add(item);
                    });
                }
```

#### AUTO 


```{c}
auto queries = Utils::DependencyManager::globalInstance().create<Domain::TaskQueries>();
```

#### AUTO 


```{c}
auto fetchCollectionsFunction(Akonadi::StorageInterface::Ptr storage) {
        return [storage] (const Domain::LiveQueryInput<Akonadi::Collection>::AddFunction &add) {
            auto job = storage->fetchCollections(Akonadi::Collection::root(), Akonadi::Storage::Recursive, Akonadi::Storage::AllContent);
            Utils::JobHandler::install(job->kjob(), [add, job] {
                foreach (const auto &col, job->collections()) {
                    add(col);
                }
            });
        };
    }
```

#### AUTO 


```{c}
auto sequence = new Akonadi::TransactionSequence;
```

#### AUTO 


```{c}
auto data = new QMimeData();
```

#### AUTO 


```{c}
auto treeQuery = [&](const Domain::Task::Ptr &task) {
        if (!task)
            return queries.findTopLevel();
        else
            return queries.findChildren(task);
    };
```

#### AUTO 


```{c}
auto newTag = tag;
```

#### AUTO 


```{c}
auto parentTitle = QString();
```

#### AUTO 


```{c}
auto context = m_serializer->createContextFromTag(tag);
```

#### AUTO 


```{c}
auto settingsAction = available.findChild<QAction*>(QStringLiteral("settingsAction"));
```

#### LAMBDA EXPRESSION 


```{c}
[] (const Akonadi::Item &item) {
            return titleFromItem(item).endsWith(QLatin1String("-in"));
        }
```

#### AUTO 


```{c}
auto setData = [this](const Domain::Artifact::Ptr &artifact, const QVariant &value, int role) {
        if (role != Qt::EditRole && role != Qt::CheckStateRole) {
            return false;
        }

        if (auto task = artifact.dynamicCast<Domain::Task>()) {
            const auto currentTitle = task->title();
            if (role == Qt::EditRole)
                task->setTitle(value.toString());
            else
                task->setDone(value.toInt() == Qt::Checked);

            const auto job = m_taskRepository->update(task);
            installHandler(job, tr("Cannot modify task %1 in Inbox").arg(currentTitle));
            return true;

        } else if (auto note = artifact.dynamicCast<Domain::Note>()) {
            if (role != Qt::EditRole)
                return false;

            const auto currentTitle = note->title();
            note->setTitle(value.toString());
            const auto job = m_noteRepository->update(note);
            installHandler(job, tr("Cannot modify note %1 in Inbox").arg(currentTitle));
            return true;

        }

        return false;
    };
```

#### AUTO 


```{c}
auto job = storage.updateItem(item);
```

#### AUTO 


```{c}
auto am = model.attachmentModel();
```

#### AUTO 


```{c}
const auto relatedHeader = note->headerByType("X-Zanshin-RelatedProjectUid");
```

#### LAMBDA EXPRESSION 


```{c}
[provider, job, this] {
                for (auto item : job->items()) {
                    if (m_serializer->relatedUidFromItem(item).isEmpty()) {
                        auto task = deserializeTask(item);
                        if (task)
                            provider->append(task);
                    }
                }
            }
```

#### AUTO 


```{c}
auto predicate = [this] (const Akonadi::Item &item) {
        const bool excluded = !m_serializer->isTaskItem(item)
                           || !m_serializer->relatedUidFromItem(item).isEmpty()
                           || m_serializer->hasContextTags(item);

        return !excluded;
    };
```

#### AUTO 


```{c}
const auto dueDateWidth = dueDate.isValid() ? (summaryMetrics.width(dueDateText) + 2 * textMargin) : 0;
```

#### LAMBDA EXPRESSION 


```{c}
[this, job, add] {
                for (Akonadi::Tag tag : job->tags())
                    add(tag);
            }
```

#### AUTO 


```{c}
const auto contextUids = todo->customProperty(Serializer::customPropertyAppName(),
                                                  Serializer::customPropertyContextList()).split(',', QString::SkipEmptyParts);
```

#### AUTO 


```{c}
auto answer = QMessageBox::question(this,
                                            tr("Multiple Agent Deletion"),
                                            tr("Do you really want to delect the selected agent instances?"),
                                            QMessageBox::Yes | QMessageBox::No,
                                            QMessageBox::No);
```

#### LAMBDA EXPRESSION 


```{c}
[storage, serializer] (const Domain::LiveQueryInput<Akonadi::Item>::AddFunction &add) {
            auto job = storage->fetchCollections(Akonadi::Collection::root(), Akonadi::Storage::Recursive);
            Utils::JobHandler::install(job->kjob(), [add, job, storage, serializer] {
                foreach (const auto &col, job->collections()) {
                    if (!serializer->isSelectedCollection(col))
                        continue;

                    auto itemJob = storage->fetchItems(col, nullptr);
                    Utils::JobHandler::install(itemJob->kjob(), [add, itemJob] {
                        foreach (const auto &item, itemJob->items())
                            add(item);
                    });
                }
            });
        }
```

#### AUTO 


```{c}
auto itemFetchJob2 = new Testlib::AkonadiFakeItemFetchJob(this);
```

#### AUTO 


```{c}
auto integrator = createIntegrator(data);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QObjectPtr &object, const QVariant &value, int role) {
        if (role != Qt::EditRole) {
            return false;
        }

        if (object == m_inboxObject
         || object == m_workdayObject
         || object == m_projectsObject
         || object == m_contextsObject
         || object == m_allTasksObject
         || object.objectCast<Domain::DataSource>()) {
            return false;
        }

        if (auto project = object.objectCast<Domain::Project>()) {
            const auto currentName = project->name();
            project->setName(value.toString());
            const auto job = m_projectRepository->update(project);
            installHandler(job, i18n("Cannot modify project %1", currentName));
        } else if (auto context = object.objectCast<Domain::Context>()) {
            const auto currentName = context->name();
            context->setName(value.toString());
            const auto job = m_contextRepository->update(context);
            installHandler(job, i18n("Cannot modify context %1", currentName));
        } else {
            Q_ASSERT(false);
        }

        return true;
    }
```

#### AUTO 


```{c}
auto fetch = fetchCollectionsFunction(storage, nullptr);
```

#### AUTO 


```{c}
auto defaultRole = model()->roleNames().key("default", -1);
```

#### LAMBDA EXPRESSION 


```{c}
[provider, job, this] {
                for (auto item : job->items()) {
                    provider->append(deserializeTask(item));
                }
            }
```

#### AUTO 


```{c}
auto model = Utils::DependencyManager::globalInstance().create<AvailablePagesModel>();
```

#### AUTO 


```{c}
const auto job = taskRepository()->createInContext(task, m_context);
```

#### LAMBDA EXPRESSION 


```{c}
[this, item] {
                retrieveFromCache(item);
            }
```

#### AUTO 


```{c}
auto queryGenerator = [&] (const QString &string) {
            if (string.isEmpty())
                return Domain::QueryResult<QString>::create(topProvider);
            else if (string == "2")
                return Domain::QueryResult<QString>::create(firstLevelProvider);
            else if (string == "2.1")
                return Domain::QueryResult<QString>::create(secondLevelProvider);
            else
                return Domain::QueryResult<QString>::Ptr();
        };
```

#### AUTO 


```{c}
auto title = QStringLiteral("New task");
```

#### AUTO 


```{c}
auto pagesDock = new QDockWidget(QObject::tr("Pages"));
```

#### AUTO 


```{c}
auto drop = [this](const QMimeData *mimeData, Qt::DropAction, const QObjectPtr &object) {
        if (!mimeData->hasFormat("application/x-zanshin-object"))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (auto tag = object.objectCast<Domain::Tag>()) {
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                const auto job = m_tagRepository->associate(tag, droppedArtifact);
                installHandler(job, tr("Cannot tag %1 with %2").arg(droppedArtifact->title()).arg(tag->name()));
            }
            return true;
        } else if (object == m_inboxObject) {
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                const auto job = m_tagRepository->dissociateAll(droppedArtifact.objectCast<Domain::Note>());
                installHandler(job, tr("Cannot move %1 to Inbox").arg(droppedArtifact->title()));
            }
            return true;
        }

        return false;
    };
```

#### AUTO 


```{c}
auto fetch = [storage, serializer] (const Domain::LiveQueryInput<Akonadi::Item>::AddFunction &add) {
            auto job = storage->fetchCollections(Akonadi::Collection::root(), Akonadi::Storage::Recursive, Akonadi::Storage::AllContent);
            Utils::JobHandler::install(job->kjob(), [add, job, storage, serializer] {
                foreach (const auto &col, job->collections()) {
                    if (!serializer->isSelectedCollection(col))
                        continue;

                    auto itemJob = storage->fetchItems(col);
                    Utils::JobHandler::install(itemJob->kjob(), [add, itemJob] {
                        foreach (const auto &item, itemJob->items())
                            add(item);
                    });
                }
            });
        };
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QObjectPtr &object, int role, int) -> QVariant {
        if (role != Qt::DisplayRole
         && role != Qt::EditRole
         && role != Qt::DecorationRole
         && role != QueryTreeModelBase::IconNameRole) {
            return QVariant();
        }

        if (role == Qt::EditRole
         && (object == m_inboxObject
          || object == m_workdayObject
          || object == m_projectsObject
          || object == m_contextsObject
          || object == m_allTasksObject
          || object.objectCast<Domain::DataSource>())) {
            return QVariant();
        }

        if (role == Qt::DisplayRole || role == Qt::EditRole) {
            return object->property("name").toString();
        } else if (role == Qt::DecorationRole || role == QueryTreeModelBase::IconNameRole) {
            const QString iconName = object == m_inboxObject ? QStringLiteral("mail-folder-inbox")
                                   : (object == m_workdayObject)  ? QStringLiteral("go-jump-today")
                                   : (object == m_projectsObject) ? QStringLiteral("folder")
                                   : (object == m_contextsObject) ? QStringLiteral("folder")
                                   : (object == m_allTasksObject)  ? QStringLiteral("view-pim-tasks")
                                   : object.objectCast<Domain::DataSource>() ? QStringLiteral("folder")
                                   : object.objectCast<Domain::Context>() ? QStringLiteral("view-pim-notes")
                                   : QStringLiteral("view-pim-tasks");

            if (role == Qt::DecorationRole)
                return QVariant::fromValue(QIcon::fromTheme(iconName));
            else
                return iconName;
        } else {
            return QVariant();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &tag : notifiedTags) {
            QVERIFY(tag.isValid());
            QVERIFY(!tag.name().isEmpty());
            QVERIFY(!tag.type().isEmpty());
        }
```

#### AUTO 


```{c}
auto job = storage.removeTag(tag);
```

#### AUTO 


```{c}
auto tagId = tag->property("tagId").value<Akonadi::Tag::Id>();
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QObjectPtr &object, const QVariant &value, int role) {
        if (role != Qt::EditRole) {
            return false;
        }

        if (object == m_inboxObject
         || object == m_projectsObject
         || object == m_contextsObject
         || object == m_tagsObject) {
            return false;
        }

        if (auto project = object.objectCast<Domain::Project>()) {
            project->setName(value.toString());
            m_projectRepository->update(project);
        } else if (auto context = object.objectCast<Domain::Context>()) {
            context->setName(value.toString());
            m_contextRepository->update(context);
        } else if (object.objectCast<Domain::Tag>()) {
            return false; // Tag renaming is NOT allowed
        } else {
            Q_ASSERT(false);
        }

        return true;
    }
```

#### AUTO 


```{c}
auto actions = components.globalActions();
```

#### LAMBDA EXPRESSION 


```{c}
[fetchItemJob, parent, job, this] {
        if (fetchItemJob->kjob()->error() != KJob::NoError)
            return;

        Q_ASSERT(fetchItemJob->items().size() == 1);
        auto childItem = fetchItemJob->items().at(0);
        auto tag = m_serializer->createTagFromContext(parent);
        Q_ASSERT(tag.isValid());
        childItem.setTag(tag);

        auto updateJob = m_storage->updateItem(childItem);
        job->addSubjob(updateJob);
        updateJob->start();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[fetchItemJob, parent, child, job, this] {
        if (fetchItemJob->kjob()->error() != KJob::NoError)
           return;

        Q_ASSERT(fetchItemJob->items().size() == 1);
        auto childItem = fetchItemJob->items().first();
        m_serializer->updateItemProject(childItem, parent);

        // Check collections to know if we need to move child
        auto parentItem = m_serializer->createItemFromProject(parent);
        ItemFetchJobInterface *fetchParentItemJob = m_storage->fetchItem(parentItem);
        job->install(fetchParentItemJob->kjob(), [fetchParentItemJob, child, childItem, job, this] {
            if (fetchParentItemJob->kjob()->error() != KJob::NoError)
                return;

            Q_ASSERT(fetchParentItemJob->items().size() == 1);
            auto parentItem = fetchParentItemJob->items().first();

            const int itemCollectionId = childItem.parentCollection().id();
            const int parentCollectionId = parentItem.parentCollection().id();

            if (child.objectCast<Domain::Task>()
             && itemCollectionId != parentCollectionId) {
                ItemFetchJobInterface *fetchChildrenItemJob = m_storage->fetchItems(childItem.parentCollection());
                job->install(fetchChildrenItemJob->kjob(), [fetchChildrenItemJob, childItem, parentItem, job, this] {
                    if (fetchChildrenItemJob->kjob()->error() != KJob::NoError)
                        return;

                    Item::List childItems = m_serializer->filterDescendantItems(fetchChildrenItemJob->items(), childItem);

                    auto transaction = m_storage->createTransaction();
                    m_storage->updateItem(childItem, transaction);
                    childItems.push_front(childItem);
                    m_storage->moveItems(childItems, parentItem.parentCollection(), transaction);
                    job->addSubjob(transaction);
                    transaction->start();
                });
            } else {
                auto updateJob = m_storage->updateItem(childItem);
                job->addSubjob(updateJob);
                updateJob->start();
            }
        });
    }
```

#### AUTO 


```{c}
const auto oldTags = oldItem.tags();
```

#### AUTO 


```{c}
auto expectedDelegate = Domain::Task::Delegate(QStringLiteral("John Doe"), QStringLiteral("john@doe.com"));
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Domain::Artifact::Ptr &artifact, int role) -> QVariant {
        switch (role) {
            case Qt::DisplayRole:
            case Qt::EditRole:
                return artifact->title();
            case Qt::CheckStateRole:
                if (auto task = artifact.dynamicCast<Domain::Task>()) {
                    return task->isDone() ? Qt::Checked : Qt::Unchecked;
                }
                break;
            case ProjectRole:
            case Qt::ToolTipRole:
                if (auto task = artifact.dynamicCast<Domain::Task>()) {
                    static Domain::QueryResult<Domain::Project::Ptr>::Ptr lastProjectResult;
                    auto projectResult = m_taskQueries->findProject(task);
                    if (projectResult) {
                        // keep a refcount to it, for next time we get here...
                        lastProjectResult = projectResult;
                        if (!projectResult->data().isEmpty()) {
                            Domain::Project::Ptr project = projectResult->data().at(0);
                            return i18n("Project: %1", project->name());
                        }
                    }
                    return i18n("Inbox");
                }
                break;
            default:
                break;
        }
        return QVariant();
    }
```

#### AUTO 


```{c}
auto childTask3 = model->data(model->index(3, 0), Presentation::QueryTreeModelBase::ObjectRole).value<Domain::Task::Ptr>();
```

#### AUTO 


```{c}
auto query = ProjectQueries::ProjectQuery::Ptr::create();
```

#### AUTO 


```{c}
auto drop = [this](const QMimeData *mimeData, Qt::DropAction, const QObjectPtr &object) {
        if (!mimeData->hasFormat(QStringLiteral("application/x-zanshin-object")))
            return false;

        auto droppedTasks = mimeData->property("objects").value<Domain::Task::List>();
        if (droppedTasks.isEmpty())
            return false;

        if (auto project = object.objectCast<Domain::Project>()) {
            foreach (const auto &task, droppedTasks) {
                const auto job = m_projectRepository->associate(project, task);
                installHandler(job, i18n("Cannot add %1 to project %2", task->title(), project->name()));
            }
            return true;
        } else if (auto context = object.objectCast<Domain::Context>()) {
            foreach (const auto &task, droppedTasks) {
                const auto job = m_contextRepository->associate(context, task);
                installHandler(job, i18n("Cannot add %1 to context %2", task->title(), context->name()));
            }
            return true;
        } else if (object == m_inboxObject) {
            foreach (const auto &task, droppedTasks) {
                const auto job = m_projectRepository->dissociate(task);
                installHandler(job, i18n("Cannot move %1 to Inbox", task->title()));

                Utils::JobHandler::install(job, [this, task] {
                    const auto dissociateJob = m_taskRepository->dissociateAll(task);
                    installHandler(dissociateJob, i18n("Cannot move task %1 to Inbox", task->title()));
                });
            }
            return true;
        } else if (object == m_workdayObject) {
            foreach (const auto &task, droppedTasks) {
                task->setStartDate(Utils::DateTime::currentDate());
                const auto job = m_taskRepository->update(task);

                installHandler(job, i18n("Cannot update task %1 to Workday", task->title()));
            }
            return true;
        }

        return false;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[](const Domain::Note::List &notes) -> QMimeData* {
        if (notes.isEmpty())
            return Q_NULLPTR;

        auto artifacts = Domain::Artifact::List();
        artifacts.reserve(notes.size());
        std::copy(notes.constBegin(), notes.constEnd(),
                  std::back_inserter(artifacts));

        auto data = new QMimeData;
        data->setData(QStringLiteral("application/x-zanshin-object"), "object");
        data->setProperty("objects", QVariant::fromValue(artifacts));
        return data;
    }
```

#### AUTO 


```{c}
auto newItem = contextItem;
```

#### AUTO 


```{c}
const auto indexes = data->property("indexes").value<QModelIndexList>();
```

#### AUTO 


```{c}
auto setData = [this] (const Domain::Task::Ptr &task, const QVariant &value, int role) {
        if (role != Qt::EditRole && role != Qt::CheckStateRole)
            return false;

        const auto currentTitle = task->title();
        if (role == Qt::EditRole)
            task->setTitle(value.toString());
        else
            task->setDone(value.toInt() == Qt::Checked);

        const auto job = m_taskRepository->update(task);
        installHandler(job, tr("Cannot modify task %1 in context %2").arg(currentTitle, m_context->name()));
        return true;
    };
```

#### AUTO 


```{c}
auto task = taskForIndex(index);
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Akonadi::Item &item) {
        // Tasks with no parent, or whose parent is a project (not a task)
        if (!m_serializer->isTaskItem(item))
            return false;

        const auto items = m_cache->items(item.parentCollection());
        auto currentItem = item;
        auto parentUid = m_serializer->relatedUidFromItem(currentItem);
        while (!parentUid.isEmpty()) {
            const auto parent = std::find_if(items.cbegin(), items.cend(),
                                             [this, parentUid] (const Akonadi::Item &item) {
                                                 return m_serializer->itemUid(item) == parentUid;
                                             });
            if (parent == items.cend())
                break;

            if (m_serializer->isTaskItem(*parent))
                return false;

            currentItem = *parent;
            parentUid = m_serializer->relatedUidFromItem(currentItem);
        }
        return true;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Domain::DataSource::Ptr &, int index) {
                                        beginInsertRows(QModelIndex(), index, index);
                                    }
```

#### AUTO 


```{c}
auto bottomHBox = new QHBoxLayout;
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Domain::Artifact::Ptr &artifact, const QVariant &value, int role) {
        if (role != Qt::EditRole && role != Qt::CheckStateRole) {
            return false;
        }

        if (auto task = artifact.dynamicCast<Domain::Task>()) {
            const auto currentTitle = task->title();
            if (role == Qt::EditRole)
                task->setTitle(value.toString());
            else
                task->setDone(value.toInt() == Qt::Checked);

            const auto job = taskRepository()->update(task);
            if (!errorHandler())
                return true;

            errorHandler()->installHandler(job, tr("Cannot modify task %1 in project %2").arg(currentTitle).arg(m_project->name()));
            return true;

        } else if (auto note = artifact.dynamicCast<Domain::Note>()) {
            if (role != Qt::EditRole)
                return false;

            const auto currentTitle = note->title();
            note->setTitle(value.toString());
            const auto job = noteRepository()->save(note);
            if (!errorHandler())
                return true;

            errorHandler()->installHandler(job, tr("Cannot modify note %1 in project %2").arg(currentTitle).arg(m_project->name()));
            return true;

        }

        return false;
    }
```

#### AUTO 


```{c}
auto delegate = new DataSourceDelegate(m_sourcesView);
```

#### AUTO 


```{c}
const auto task = artifact.objectCast<Domain::Task>();
```

#### AUTO 


```{c}
auto i2 = serializer.createItemFromTask(task2);
```

#### AUTO 


```{c}
const auto allowedMimeTypes = self->fetchScope().contentMimeTypes().toSet();
```

#### AUTO 


```{c}
auto button = widget.findChild<QAbstractButton *>("doneButton");
```

#### AUTO 


```{c}
auto drag = [] (const Domain::Task::List &tasks) -> QMimeData* {
        if (tasks.isEmpty())
            return 0;

        QMimeData *data = new QMimeData();
        data->setData("application/x-zanshin-object", "objects");
        data->setProperty("objects", QVariant::fromValue(tasks));
        return data;
    };
```

#### AUTO 


```{c}
auto parentIt = items.find(parentUid);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &collection : collections) {
            QCOMPARE(collection.name(), expectedResults[i]);
            ++i;
        }
```

#### AUTO 


```{c}
auto otherResult = QueryResult<Derived::Ptr, Base::Ptr>::copy(result);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Domain::Task::Ptr &task, const QVariant &value, int role) {
        if (role != Qt::EditRole && role != Qt::CheckStateRole) {
            return false;
        }

        const auto currentTitle = task->title();
        if (role == Qt::EditRole)
            task->setTitle(value.toString());
        else
            task->setDone(value.toInt() == Qt::Checked);

        const auto job = m_taskRepository->update(task);
        installHandler(job, i18n("Cannot modify task %1", currentTitle));
        return true;
    }
```

#### AUTO 


```{c}
auto predicate = [this, context] (const Akonadi::Item &item) {
        return m_serializer->isContextChild(context, item);
    };
```

#### LAMBDA EXPRESSION 


```{c}
[] (const QColor &) {
            return Qt::NoItemFlags;
        }
```

#### AUTO 


```{c}
const auto job = m_projectRepository->remove(project);
```

#### LAMBDA EXPRESSION 


```{c}
[](const Domain::DataSource::List &) -> QMimeData* {
        return Q_NULLPTR;
    }
```

#### AUTO 


```{c}
auto note = m_artifact.objectCast<Domain::Note>();
```

#### AUTO 


```{c}
auto goPreviousAction = available.findChild<QAction*>("goPreviousAction");
```

#### LAMBDA EXPRESSION 


```{c}
[this, provider] (const InputType &input) {
            if (m_predicate(input))
                addToProvider(provider, input);
        }
```

#### AUTO 


```{c}
const auto extraTextRect = opt.rect.adjusted(summaryRect.left(),
                                                     opt.rect.height() / SELECTED_FACTOR,
                                                     0, 0);
```

#### AUTO 


```{c}
auto addFunction = [this, provider] (const InputType &input) {
            if (m_predicate(input))
                addToProvider(provider, input);
        };
```

#### RANGE FOR STATEMENT 


```{c}
for (auto task : m_taskChildren->data()) {
            Node *node = new Node(task, this, queries, model);
            m_childNode.append(node);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, root] (const Akonadi::Collection &collection) {
            return collection.isValid()
                && collection.parentCollection() == root
                && m_serializer->isListedCollection(collection);
        }
```

#### AUTO 


```{c}
auto pagesView = available.findChild<QTreeView*>("pagesView");
```

#### LAMBDA EXPRESSION 


```{c}
[=] () mutable {
            if (!job->error()) {
                collection.setId(m_data->maxCollectionId() + 1);
                m_data->createCollection(collection);
            }
        }
```

#### AUTO 


```{c}
auto predicate = [this, task] (const Akonadi::Item &childItem) {
        return m_serializer->isTaskChild(task, childItem);
    };
```

#### AUTO 


```{c}
auto colJob = storage->fetchCollections(Akonadi::Collection::root(),
                                            Akonadi::StorageInterface::Recursive,
                                            Akonadi::StorageInterface::AllContent);
```

#### AUTO 


```{c}
auto t1 = Akonadi::Tag(42);
```

#### AUTO 


```{c}
auto flags = [](const Domain::Artifact::Ptr &artifact) {
        const Qt::ItemFlags defaultFlags = Qt::ItemIsSelectable
                                         | Qt::ItemIsEnabled
                                         | Qt::ItemIsEditable;

        return artifact.dynamicCast<Domain::Task>() ? (defaultFlags | Qt::ItemIsUserCheckable) : defaultFlags;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[provider, job, project, this] {
                if (job->kjob()->error() != KJob::NoError)
                    return;

                for (auto item : job->items()) {
                    if (m_serializer->isProjectChild(project, item)) {
                        auto artifact = deserializeArtifact(item);
                        if (artifact)
                            provider->append(artifact);
                    }
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[] (const Domain::Task::Ptr &task, int role, const AdditionalInfo &projectQueryResult) -> QVariant {
        switch (role) {
            case Qt::DisplayRole:
            case Qt::EditRole:
                return task->title();
            case Qt::CheckStateRole:
                return task->isDone() ? Qt::Checked : Qt::Unchecked;
            case Presentation::QueryTreeModelBase::AdditionalInfoRole:
                if (projectQueryResult && !projectQueryResult->data().isEmpty()) {
                    Domain::Project::Ptr project = projectQueryResult->data().at(0);
                    return i18n("Project: %1", project->name());
                 }
                return i18n("Inbox");
            default:
                break;
        }
        return QVariant();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (Utils::DependencyManager *deps) {
        return new Akonadi::CachingStorage(deps->create<Akonadi::Cache>(),
                                           Akonadi::StorageInterface::Ptr(createStorage()));
    }
```

#### AUTO 


```{c}
auto helpers = createHelpers(data);
```

#### AUTO 


```{c}
const auto mimeTypes = collection.contentMimeTypes();
```

#### LAMBDA EXPRESSION 


```{c}
[storage, collection, parent] (const Domain::LiveQueryInput<Item>::AddFunction &add) {
        auto job = storage->fetchItems(collection, parent);
        Utils::JobHandler::install(job->kjob(), [job, add] {
            if (job->kjob()->error() != KJob::NoError)
                return;

            foreach (const auto &item, job->items())
                add(item);
        });
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Akonadi::Item &item) {
            return m_serializer->createProjectFromItem(item);
        }
```

#### AUTO 


```{c}
auto job = storage->fetchCollections(Akonadi::Collection::root(),
                                             StorageInterface::Recursive);
```

#### AUTO 


```{c}
auto data = [this](const QObjectPtr &object, int role) -> QVariant {
        if (role != Qt::DisplayRole
         && role != Qt::EditRole
         && role != Qt::DecorationRole
         && role != QueryTreeModelBase::IconNameRole) {
            return QVariant();
        }

        if (role == Qt::EditRole
         && (object == m_inboxObject
          || object == m_tagsObject)) {
            return QVariant();
        }

        if (role == Qt::DisplayRole || role == Qt::EditRole) {
            return object->property("name").toString();
        } else if (role == Qt::DecorationRole || role == QueryTreeModelBase::IconNameRole) {
            const QString iconName = (object == m_inboxObject) ? "mail-folder-inbox"
                                   : (object == m_tagsObject)  ? "folder"
                                   : "view-pim-tasks";

            if (role == Qt::DecorationRole)
                return QVariant::fromValue(QIcon::fromTheme(iconName));
            else
                return iconName;
        } else {
            return QVariant();
        }
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this, model](const Domain::Task::Ptr &, int index) {
                                         m_childNode.removeAt(index);
                                         model->endRemoveRows();
                                    }
```

#### AUTO 


```{c}
auto job = storage->removeItem(item);
```

#### AUTO 


```{c}
auto task3 = model->data(model->index(1, 0), Presentation::QueryTreeModelBase::ObjectRole).value<Domain::Task::Ptr>();
```

#### AUTO 


```{c}
auto drop = [this] (const QMimeData *mimeData, Qt::DropAction, const Domain::Task::Ptr &parentTask) {
        if (!mimeData->hasFormat(QStringLiteral("application/x-zanshin-object")))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                        [](const Domain::Artifact::Ptr &droppedArtifact) {
                            return !droppedArtifact.objectCast<Domain::Task>();
                        })) {
            return false;
        }

        using namespace std::placeholders;
        auto associate = std::function<KJob*(Domain::Task::Ptr)>();
        auto dissociate = std::function<KJob*(Domain::Task::Ptr)>();
        auto parentTitle = QString();

        if (parentTask) {
            associate = std::bind(&Domain::TaskRepository::associate, m_taskRepository, parentTask, _1);
            dissociate = [] (Domain::Task::Ptr) -> KJob* { return Q_NULLPTR; };
            parentTitle = parentTask->title();
        } else {
            associate = std::bind(&Domain::ContextRepository::associate, m_contextRepository, m_context, _1);
            dissociate = std::bind(&Domain::TaskRepository::dissociate, m_taskRepository, _1);
            parentTitle = m_context->name();
        }

        foreach(const Domain::Artifact::Ptr &droppedArtifact, droppedArtifacts) {
            auto childTask = droppedArtifact.objectCast<Domain::Task>();
            auto job = associate(childTask);
            installHandler(job, tr("Cannot move task %1 as sub-task of %2").arg(childTask->title(), parentTitle));
            job = dissociate(childTask);
            if (job)
                installHandler(job, tr("Cannot dissociate task %1 from its parent").arg(childTask->title()));
        }

        return true;
    };
```

#### AUTO 


```{c}
auto fetch = fetchItemsInAllCollectionsFunction(storage, nullptr);
```

#### AUTO 


```{c}
auto fetch = m_helpers->fetchCollections(Collection::root());
```

#### AUTO 


```{c}
auto impl = object.dynamicCast<AnotherFirstImplementation>();
```

#### LAMBDA EXPRESSION 


```{c}
[persistentIndex](const Domain::Project::Ptr &, int) {
                // When a project was found (inserted into the result), update the rendering of the item
                auto model = const_cast<QAbstractItemModel *>(persistentIndex.model());
                model->dataChanged(persistentIndex, persistentIndex);
            }
```

#### AUTO 


```{c}
auto tempFile = new QTemporaryFile(QDir::tempPath() + QStringLiteral("/zanshin_attachment_XXXXXX"), this);
```

#### AUTO 


```{c}
auto dialogStub = NewProjectDialogStub::Ptr::create();
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QModelIndex &index, const Domain::Task::Ptr &task) -> AdditionalInfo {
        if (index.parent().isValid()) // children are in the same collection as their parent, so the same datasource
            return nullptr;

        AdditionalInfo datasourceQueryResult = m_taskQueries->findDataSource(task);
        if (datasourceQueryResult) {
            QPersistentModelIndex persistentIndex(index);
            datasourceQueryResult->addPostInsertHandler([persistentIndex](const Domain::DataSource::Ptr &, int) {
                // When a datasource was found (inserted into the result), update the rendering of the item
                auto model = const_cast<QAbstractItemModel *>(persistentIndex.model());
                model->dataChanged(persistentIndex, persistentIndex);
            });
        }
        return datasourceQueryResult;
    }
```

#### AUTO 


```{c}
auto drop = [this](const QMimeData *mimeData, Qt::DropAction, const Domain::Artifact::Ptr &artifact) {
        auto parentTask = artifact.objectCast<Domain::Task>();
        if (!parentTask)
            return false;

        if (!mimeData->hasFormat("application/x-zanshin-object"))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                        [](const Domain::Artifact::Ptr &droppedArtifact) {
                            return !droppedArtifact.objectCast<Domain::Task>();
                        })) {
            return false;
        }

        foreach(const Domain::Artifact::Ptr &droppedArtifact, droppedArtifacts) {
            auto childTask = droppedArtifact.objectCast<Domain::Task>();
            taskRepository()->associate(parentTask, childTask);
        }

        return true;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[add] {
                add(QStringLiteral("0"));
                add(QStringLiteral("1"));
                add(QString());
                add(QStringLiteral("a"));
                add(QStringLiteral("2"));
            }
```

#### AUTO 


```{c}
auto drop = [this](const QMimeData *mimeData, Qt::DropAction, const Domain::Task::Ptr &task) {
        auto parentTask = task.objectCast<Domain::Task>();

        if (!mimeData->hasFormat(QStringLiteral("application/x-zanshin-object")))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                        [](const Domain::Artifact::Ptr &droppedArtifact) {
                            return !droppedArtifact.objectCast<Domain::Task>();
                        })) {
            return false;
        }

        foreach(const auto &droppedArtifact, droppedArtifacts) {
            auto childTask = droppedArtifact.objectCast<Domain::Task>();

            if (parentTask) {
                const auto job = m_taskRepository->associate(parentTask, childTask);
                installHandler(job, tr("Cannot move task %1 as sub-task of %2").arg(childTask->title(), parentTask->title()));
            } else {
                const auto job = m_taskRepository->dissociate(childTask);
                installHandler(job, tr("Cannot deparent task %1 from its parent").arg(childTask->title()));
            }
        }

        return true;
    };
```

#### AUTO 


```{c}
auto updateJob = m_storage->updateItem(item, this);
```

#### AUTO 


```{c}
auto model = ApplicationModelStub::Ptr::create();
```

#### AUTO 


```{c}
auto inboxPageModel = new InboxPageModel(m_artifactQueries,
                                                 m_taskQueries, m_taskRepository,
                                                 m_noteRepository,
                                                 this);
```

#### LAMBDA EXPRESSION 


```{c}
[](const Akonadi::Tag &tag) { return tag.type() == "Zanshin-Context"; }
```

#### LAMBDA EXPRESSION 


```{c}
[](const Domain::Task::Ptr &task, int role, int) -> QVariant {
        if (role != Qt::DisplayRole
         && role != Qt::EditRole
         && role != Qt::CheckStateRole) {
            return QVariant();
        }

        if (role == Qt::DisplayRole || role == Qt::EditRole) {
            return task->title();
        } else {
            return task->isDone() ? Qt::Checked : Qt::Unchecked;
        }
    }
```

#### AUTO 


```{c}
auto query = new Domain::LiveQuery<QObject*, QPair<int, QString>>;
```

#### AUTO 


```{c}
auto rootTask = model->data(rootTaskIndex, Presentation::QueryTreeModelBase::ObjectRole).value<Domain::Task::Ptr>();
```

#### AUTO 


```{c}
auto showFutureCheck = filter.findChild<QCheckBox*>(QStringLiteral("showFutureCheck"));
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QMimeData *mimeData, Qt::DropAction, const QObjectPtr &object) {
        if (!mimeData->hasFormat("application/x-zanshin-object"))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                        [](const Domain::Artifact::Ptr &droppedArtifact) {
                            return !droppedArtifact.objectCast<Domain::Note>();
                        })) {
            return false;
        }

        if (auto tag = object.objectCast<Domain::Tag>()) {
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                auto note = droppedArtifact.staticCast<Domain::Note>();
                const auto job = m_tagRepository->associate(tag, note);
                installHandler(job, tr("Cannot tag %1 with %2").arg(note->title()).arg(tag->name()));
            }
            return true;
        } else if (object == m_inboxObject) {
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                auto note = droppedArtifact.staticCast<Domain::Note>();
                const auto job = m_tagRepository->dissociateAll(note);
                installHandler(job, tr("Cannot move %1 to Inbox").arg(note->title()));
            }
            return true;
        }

        return false;
    }
```

#### AUTO 


```{c}
const auto timestamp = QDateTime::currentMSecsSinceEpoch();
```

#### AUTO 


```{c}
const auto bound = std::partition(itemsToProcess.begin(), itemsToProcess.end(),
                                      [ancestorItem, todo](Akonadi::Item currentItem) {
                                          return (!currentItem.hasPayload<KCalCore::Todo::Ptr>()
                                               || currentItem == ancestorItem
                                               || currentItem.payload<KCalCore::Todo::Ptr>()->relatedTo() != todo->uid());
                                      });
```

#### AUTO 


```{c}
auto projects = new QStandardItem(QStringLiteral("Projects"));
```

#### AUTO 


```{c}
auto noteToDrop = Domain::Note::Ptr::create();
```

#### AUTO 


```{c}
auto collections = children;
```

#### AUTO 


```{c}
auto drop = [this](const QMimeData *mimeData, Qt::DropAction, const Domain::Task::Ptr &parentTask) {
        if (!mimeData->hasFormat(QStringLiteral("application/x-zanshin-object")))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                        [](const Domain::Artifact::Ptr &droppedArtifact) {
                            return !droppedArtifact.objectCast<Domain::Task>();
                        })) {
            return false;
        }

        using namespace std::placeholders;
        auto associate = std::function<KJob*(Domain::Task::Ptr)>();
        auto parentTitle = QString();

        if (parentTask) {
            associate = std::bind(&Domain::TaskRepository::associate, m_taskRepository, parentTask, _1);
            parentTitle = parentTask->title();
        } else {
            associate = std::bind(&Domain::ProjectRepository::associate, m_projectRepository, m_project, _1);
            parentTitle = m_project->name();
        }

        foreach(const Domain::Artifact::Ptr &droppedArtifact, droppedArtifacts) {
            auto childTask = droppedArtifact.objectCast<Domain::Task>();
            const auto job = associate(childTask);
            installHandler(job, tr("Cannot move task %1 as a sub-task of %2").arg(childTask->title(), parentTitle));
        }

        return true;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[fetchCollectionItemsJob, item, compositeJob, this] {
            if (fetchCollectionItemsJob->kjob()->error() != KJob::NoError)
                return;

            Item::List childItems = m_serializer->filterDescendantItems(fetchCollectionItemsJob->items(), item);
            childItems << item;

            auto removeJob = m_storage->removeItems(childItems);
            compositeJob->addSubjob(removeJob);
            removeJob->start();
        }
```

#### AUTO 


```{c}
auto configGroup = KConfigGroup(KSharedConfig::openConfig(), "General");
```

#### LAMBDA EXPRESSION 


```{c}
[this, task] (const Akonadi::Item &item) {
            return m_serializer->isTaskChild(task, item);
        }
```

#### AUTO 


```{c}
auto setDataFunction = [](const QColor &, const QVariant &, int) {
            return false;
        };
```

#### AUTO 


```{c}
auto queryGenerator = [&](const Domain::Task::Ptr &artifact) {
            if (!artifact)
                return Domain::QueryResult<Domain::Task::Ptr>::create(provider);
            else
                return Domain::QueryResult<Domain::Task::Ptr>::Ptr();
        };
```

#### AUTO 


```{c}
auto collection2 = GenCollection().withId(43).withRootAsParent().withTaskContent();
```

#### AUTO 


```{c}
auto dataFunction = [](const QString &, int, int) {
            return QVariant();
        };
```

#### AUTO 


```{c}
auto treeSetData = [&](const Domain::Task::Ptr &task, const QVariant &value, int role) {
        if (role != Qt::EditRole && role != Qt::CheckStateRole) {
            return false;
        }

        if (role == Qt::EditRole) {
            task->setTitle(value.toString());
        } else {
            task->setDone(value.toInt() == Qt::Checked);
        }

        repository.update(task);
        return true;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[storage, serializer, childItem, childId] (const Domain::LiveQueryInput<Item>::AddFunction &add) {
        auto job = storage->fetchItems(childItem.parentCollection());
        Utils::JobHandler::install(job->kjob(), [job, add, serializer, childId] {
            if (job->kjob()->error() != KJob::NoError)
                return;

            const auto items = job->items();
            // The item itself is part of the result, we need that in findProject, to react on changes of the item itself
            // To return a correct child item in case it got updated, we can't use childItem, we need to find it in the list.
            const auto myself = std::find_if(items.cbegin(), items.cend(),
                                             [childId] (const Akonadi::Item &item) {
                                                 return childId == item.id();
                                             });
            if (myself == items.cend()) {
                qWarning() << "Did not find item in the listing for its parent collection. Item ID:" << childId;
                return;
            }
            add(*myself);
            auto parentUid = serializer->relatedUidFromItem(*myself);
            while (!parentUid.isEmpty()) {
                const auto parent = std::find_if(items.cbegin(), items.cend(),
                                                 [serializer, parentUid] (const Akonadi::Item &item) {
                                                     return serializer->itemUid(item) == parentUid;
                                                 });
                if (parent == items.cend()) {
                    break;
                }
                add(*parent);
                parentUid = serializer->relatedUidFromItem(*parent);
            }
        });
    }
```

#### AUTO 


```{c}
auto parent = collectionByRid.value(c.parentCollection().remoteId());
```

#### AUTO 


```{c}
const auto mime = col.contentMimeTypes().toSet();
```

#### AUTO 


```{c}
const auto job = m_taskRepository->createInContext(task, m_context);
```

#### AUTO 


```{c}
auto childTask2 = model->data(model->index(3, 0), Presentation::QueryTreeModelBase::ObjectRole).value<Domain::Task::Ptr>();
```

#### AUTO 


```{c}
auto storage = createStorage();
```

#### AUTO 


```{c}
const auto items = fetchParentItemJob->items();
```

#### AUTO 


```{c}
auto promoteItemAction = new QAction(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Tag &tag : tags) {
        if (tag.gid() == gid)
            return tag;
    }
```

#### AUTO 


```{c}
auto resultHandler = std::function<void()>(std::bind(Utils::mem_fn(&ErrorHandler::displayMessage),
                                               this, job, message));
```

#### AUTO 


```{c}
auto job = storage->removeItem(item, nullptr);
```

#### AUTO 


```{c}
auto sourceCombo = dialog.findChild<Widgets::DataSourceComboBox*>("sourceCombo");
```

#### AUTO 


```{c}
auto timestamp = QDateTime::currentMSecsSinceEpoch();
```

#### AUTO 


```{c}
auto predicate = createFetchPredicate(Collection::root());
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Akonadi::Item &item, const Domain::Artifact::Ptr &artifact) {
            return m_serializer->representsItem(artifact, item);
        }
```

#### AUTO 


```{c}
auto handlerWithJob = [&](KJob *job) {
            callCount++;
            seenJobs << job;
        };
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const ProjectQuery::AddFunction &add) {
            CollectionFetchJobInterface *job = m_storage->fetchCollections(Akonadi::Collection::root(),
                                                                           StorageInterface::Recursive,
                                                                           StorageInterface::Tasks);
            Utils::JobHandler::install(job->kjob(), [this, job, add] {
                if (job->kjob()->error() != KJob::NoError)
                    return;

                for (auto collection : job->collections()) {
                    if (!m_serializer->isSelectedCollection(collection))
                        continue;

                    ItemFetchJobInterface *job = m_storage->fetchItems(collection);
                    Utils::JobHandler::install(job->kjob(), [this, job, add] {
                        if (job->kjob()->error() != KJob::NoError)
                            return;

                        for (auto item : job->items()) {
                            add(item);
                        }
                    });
                }
            });
        }
```

#### AUTO 


```{c}
auto drop = [this] (const QMimeData *mimeData, Qt::DropAction, const Domain::Task::Ptr &parentTask) {
        if (!mimeData->hasFormat(QStringLiteral("application/x-zanshin-object")))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                        [](const Domain::Artifact::Ptr &droppedArtifact) {
                            return !droppedArtifact.objectCast<Domain::Task>();
                        })) {
            return false;
        }

        using namespace std::placeholders;
        auto associate = std::function<KJob*(Domain::Task::Ptr)>();
        auto dissociate = std::function<KJob*(Domain::Task::Ptr)>();
        auto parentTitle = QString();

        if (parentTask) {
            associate = std::bind(&Domain::TaskRepository::associate, m_taskRepository, parentTask, _1);
            dissociate = [] (Domain::Task::Ptr) -> KJob* { return Q_NULLPTR; };
            parentTitle = parentTask->title();
        } else {
            associate = std::bind(&Domain::ContextRepository::associate, m_contextRepository, m_context, _1);
            dissociate = std::bind(&Domain::TaskRepository::dissociate, m_taskRepository, _1);
            parentTitle = m_context->name();
        }

        foreach(const Domain::Artifact::Ptr &droppedArtifact, droppedArtifacts) {
            auto childTask = droppedArtifact.objectCast<Domain::Task>();
            auto job = associate(childTask);
            installHandler(job, i18n("Cannot move task %1 as sub-task of %2", childTask->title(), parentTitle));
            job = dissociate(childTask);
            if (job)
                installHandler(job, i18n("Cannot dissociate task %1 from its parent", childTask->title()));
        }

        return true;
    };
```

#### AUTO 


```{c}
auto job = new AkonadiFakeTransaction(parent);
```

#### AUTO 


```{c}
const auto rightTask = right.data(QueryTreeModelBase::ObjectRole).value<Domain::Task::Ptr>();
```

#### AUTO 


```{c}
auto collectionNames = QStringList();
```

#### AUTO 


```{c}
auto job = storage->fetchCollections(root, StorageInterface::Recursive, contentTypes);
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString &value, int pos)
            {
                preReplaces << value;
                preReplacesPos << pos;
            }
```

#### AUTO 


```{c}
auto job = new FakeJob(this);
```

#### LAMBDA EXPRESSION 


```{c}
[provider, job, this] {
        for (auto collection : job->collections()) {
            ItemFetchJobInterface *job = m_storage->fetchItems(collection);
            Utils::JobHandler::install(job->kjob(), [provider, job, this] {
                for (auto item : job->items()) {
                    if (m_serializer->relatedUidFromItem(item).isEmpty()) {
                        auto task = deserializeTask(item);
                        if (task)
                            provider->append(task);
                    }
                }
            });
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QMimeData *mimeData, Qt::DropAction, const Domain::Artifact::Ptr &artifact) {
        auto parentTask = artifact.objectCast<Domain::Task>();
        if (!parentTask)
            return false;

        if (!mimeData->hasFormat("application/x-zanshin-object"))
            return false;

        auto droppedArtifact = mimeData->property("object").value<Domain::Artifact::Ptr>();
        if (!droppedArtifact)
            return false;

        auto childTask = droppedArtifact.objectCast<Domain::Task>();
        if (!childTask)
            return false;

        taskRepository()->associate(parentTask, childTask);
        return true;
    }
```

#### AUTO 


```{c}
auto childrenList = Domain::QueryResult<Domain::Task::Ptr>::create(childrenProvider);
```

#### AUTO 


```{c}
auto query = [this] (const Domain::Task::Ptr &task) -> Domain::QueryResultInterface<Domain::Task::Ptr>::Ptr {
        if (!task)
            return m_contextQueries->findTasks(m_context);
        else
            return taskQueries()->findChildren(task);
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QMimeData *mimeData, Qt::DropAction, const QObjectPtr &object) {
        if (!mimeData->hasFormat("application/x-zanshin-object"))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (auto project = object.objectCast<Domain::Project>()) {
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                const auto job = m_projectRepository->associate(project, droppedArtifact);
                installHandler(job, tr("Cannot add %1 to project %2").arg(droppedArtifact->title()).arg(project->name()));
            }
            return true;
        } else if (auto context = object.objectCast<Domain::Context>()) {
            if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                            [](const Domain::Artifact::Ptr &droppedArtifact) {
                                return !droppedArtifact.objectCast<Domain::Task>();
                            })) {
                return false;
            }
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                auto task = droppedArtifact.staticCast<Domain::Task>();
                const auto job = m_contextRepository->associate(context, task);
                installHandler(job, tr("Cannot add %1 to context %2").arg(task->title()).arg(context->name()));
            }
            return true;
        } else if (auto tag = object.objectCast<Domain::Tag>()) {
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                const auto job = m_tagRepository->associate(tag, droppedArtifact);
                installHandler(job, tr("Cannot tag %1 with %2").arg(droppedArtifact->title()).arg(tag->name()));
            }
            return true;
        } else if (object == m_inboxObject) {
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                const auto job = m_projectRepository->dissociate(droppedArtifact);
                installHandler(job, tr("Cannot move %1 to Inbox").arg(droppedArtifact->title()));

                if (auto task = droppedArtifact.objectCast<Domain::Task>()) {
                    Utils::JobHandler::install(job, [this, task] {
                        const auto dissociateJob = m_taskRepository->dissociate(task);
                        installHandler(dissociateJob, tr("Cannot move task %1 to Inbox").arg(task->title()));
                    });
                }
            }
            return true;
        }

        return false;
    }
```

#### AUTO 


```{c}
const auto behavior = m_data->storageBehavior().fetchItemsBehavior(collection.id());
```

#### AUTO 


```{c}
auto id
```

#### AUTO 


```{c}
auto task1 = Domain::Task::Ptr::create();
```

#### AUTO 


```{c}
auto itemFetchJob3 = new MockItemFetchJob(this);
```

#### LAMBDA EXPRESSION 


```{c}
[=] () mutable {
            item.setId(m_data->maxItemId() + 1);
            item.setParentCollection(collection);
            // Force payload detach
            item.setPayloadFromData(item.payloadData());
            m_data->createItem(item);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[] (Utils::DependencyManager *deps) {
        auto model = new Presentation::EditorModel;
        auto repository = deps->create<Domain::TaskRepository>();
        model->setSaveFunction([repository] (const Domain::Task::Ptr &task) {
            Q_ASSERT(task);
            return repository->update(task);
        });
        return model;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] { return noteSources(); }
```

#### AUTO 


```{c}
auto job = m_storage->fetchItem(m_item);
```

#### AUTO 


```{c}
auto task = page.addItem(title).objectCast<Domain::Task>();
```

#### AUTO 


```{c}
auto compare = [] (const Akonadi::Item &item1, const Akonadi::Item &item2) {
        return item1.id() == item2.id();
    };
```

#### LAMBDA EXPRESSION 


```{c}
[collectionName] (const Akonadi::Collection &col) {
                     const auto mime = col.contentMimeTypes();
                     const bool supportedType = mime.contains(KCalCore::Todo::todoMimeType())
                                             || mime.contains(Akonadi::NoteUtils::noteMimeType());
                     return supportedType && col.displayName().contains(collectionName, Qt::CaseInsensitive);
                 }
```

#### AUTO 


```{c}
auto artifact = data.value<Domain::Artifact::Ptr>();
```

#### LAMBDA EXPRESSION 


```{c}
[fetchItemJob, context, job, this] {
        if (fetchItemJob->kjob()->error() != KJob::NoError)
            return;

        Q_ASSERT(fetchItemJob->items().size() == 1);
        auto childItem = fetchItemJob->items().at(0);
        m_serializer->addContextToTask(context, childItem);

        auto updateJob = m_storage->updateItem(childItem);
        job->addSubjob(updateJob);
        updateJob->start();
    }
```

#### AUTO 


```{c}
auto setData = [this](const QObjectPtr &object, const QVariant &value, int role) {
        if (role != Qt::EditRole) {
            return false;
        }

        if (object == m_inboxObject
         || object == m_workdayObject
         || object == m_projectsObject
         || object == m_contextsObject) {
            return false;
        }

        if (auto project = object.objectCast<Domain::Project>()) {
            const auto currentName = project->name();
            project->setName(value.toString());
            const auto job = m_projectRepository->update(project);
            installHandler(job, i18n("Cannot modify project %1", currentName));
        } else if (auto context = object.objectCast<Domain::Context>()) {
            const auto currentName = context->name();
            context->setName(value.toString());
            const auto job = m_contextRepository->update(context);
            installHandler(job, i18n("Cannot modify context %1", currentName));
        } else {
            Q_ASSERT(false);
        }

        return true;
    };
```

#### AUTO 


```{c}
auto model = new Presentation::ArtifactEditorModel(taskRepositoryMock.getInstance(),
                                                           noteRepositoryMock.getInstance());
```

#### AUTO 


```{c}
auto source1 = Domain::DataSource::Ptr::create();
```

#### AUTO 


```{c}
auto dropFunction = [&] (const QMimeData *, Qt::DropAction, const QString &) {
            dropCalled = true;
            return false;
        };
```

#### AUTO 


```{c}
auto drop = [this] (const QMimeData *mimeData, Qt::DropAction, const Domain::Task::Ptr &parentTask) {
        if (!mimeData->hasFormat("application/x-zanshin-object"))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                        [](const Domain::Artifact::Ptr &droppedArtifact) {
                            return !droppedArtifact.objectCast<Domain::Task>();
                        })) {
            return false;
        }

        foreach(const Domain::Artifact::Ptr &droppedArtifact, droppedArtifacts) {
            auto childTask = droppedArtifact.objectCast<Domain::Task>();
            taskRepository()->associate(parentTask, childTask);
        }

        return true;
    };
```

#### AUTO 


```{c}
auto job = new Akonadi::AgentInstanceCreateJob(agentType, this);
```

#### LAMBDA EXPRESSION 


```{c}
[=] {
            m_data->removeTag(tag);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QObjectPtr &object, int role) -> QVariant {
        if (role != Qt::DisplayRole
         && role != Qt::EditRole
         && role != Qt::DecorationRole
         && role != QueryTreeModelBase::IconNameRole) {
            return QVariant();
        }

        if (role == Qt::EditRole
         && (object == m_inboxObject
          || object == m_tagsObject)) {
            return QVariant();
        }

        if (role == Qt::DisplayRole || role == Qt::EditRole) {
            return object->property("name").toString();
        } else if (role == Qt::DecorationRole || role == QueryTreeModelBase::IconNameRole) {
            const QString iconName = (object == m_inboxObject) ? QStringLiteral("mail-folder-inbox")
                                   : (object == m_tagsObject)  ? QStringLiteral("folder")
                                   : QStringLiteral("view-pim-tasks");

            if (role == Qt::DecorationRole)
                return QVariant::fromValue(QIcon::fromTheme(iconName));
            else
                return iconName;
        } else {
            return QVariant();
        }
    }
```

#### AUTO 


```{c}
const auto colSet = QSet<Akonadi::Collection>() << c1 << c2;
```

#### AUTO 


```{c}
auto query = Domain::LiveQueryOutput<Domain::Artifact::Ptr>::Ptr();
```

#### AUTO 


```{c}
auto fetchJob = m_storage->fetchItem(item);
```

#### AUTO 


```{c}
auto actionBarLayout = new QHBoxLayout;
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Domain::DataSource::Ptr &source, int role) -> QVariant {
        if (role != Qt::DisplayRole
         && role != Qt::EditRole
         && role != Qt::DecorationRole
         && role != Qt::CheckStateRole
         && role != QueryTreeModelBase::IconNameRole
         && role != QueryTreeModelBase::IsDefaultRole) {
            return QVariant();
        }

        if (role == Qt::DisplayRole || role == Qt::EditRole) {
            return source->name();
        } else if (role == Qt::DecorationRole || role == QueryTreeModelBase::IconNameRole) {
            const QString iconName = source->iconName().isEmpty() ? "folder" : source->iconName();

            if (role == Qt::DecorationRole)
                return QVariant::fromValue(QIcon::fromTheme(iconName));
            else
                return iconName;
        } else if (role == Qt::CheckStateRole) {
            if (source->contentTypes() != Domain::DataSource::NoContent)
                return source->isSelected() ? Qt::Checked : Qt::Unchecked;
            else
                return QVariant();
        } else if (role == QueryTreeModelBase::IsDefaultRole) {
            return m_dataSourceQueries->isDefaultSource(source);
        } else {
            return QVariant();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[child, parent, fetchParentItemJob, partialParentItem, childItem, job, this] {
            if (fetchParentItemJob->kjob()->error() != KJob::NoError)
                return;

            const auto items = fetchParentItemJob->items();
            const auto parentIndex = items.indexOf(partialParentItem);
            Q_ASSERT(parentIndex >= 0);
            const auto parentItem = items.at(parentIndex);

            const auto childUid = m_serializer->itemUid(childItem);
            auto relatedUid = m_serializer->relatedUidFromItem(parentItem);
            while (!relatedUid.isEmpty()) {
                if (relatedUid == childUid) {
                    job->emitError(i18n("Could not associate '%1', it is an ancestor of '%2'",
                                        child->title(),
                                        parent->title()));
                    return;
                }

                auto it = std::find_if(items.constBegin(), items.constEnd(),
                                       [relatedUid, this] (const Akonadi::Item &item) {
                    return m_serializer->itemUid(item) == relatedUid;
                });
                if (it == items.end())
                    break;

                relatedUid = m_serializer->relatedUidFromItem(*it);
            }

            const int itemCollectionId = childItem.parentCollection().id();
            const int parentCollectionId = parentItem.parentCollection().id();

            if (itemCollectionId != parentCollectionId) {
                ItemFetchJobInterface *fetchChildrenItemJob = m_storage->fetchItems(childItem.parentCollection());
                job->install(fetchChildrenItemJob->kjob(), [fetchChildrenItemJob, childItem, parentItem, job, this] {
                    if (fetchChildrenItemJob->kjob()->error() != KJob::NoError)
                        return;

                    Item::List childItems = m_serializer->filterDescendantItems(fetchChildrenItemJob->items(), childItem);

                    auto transaction = m_storage->createTransaction();
                    m_storage->updateItem(childItem, transaction);
                    childItems.push_front(childItem);
                    m_storage->moveItems(childItems, parentItem.parentCollection(), transaction);
                    job->addSubjob(transaction);
                    transaction->start();
                });
            } else {
                auto updateJob = m_storage->updateItem(childItem);
                job->addSubjob(updateJob);
                updateJob->start();
            }
        }
```

#### AUTO 


```{c}
auto addFunction = [this] (const InputType &input) {
            onAdded(input);
        };
```

#### AUTO 


```{c}
const auto oldContextItem = m_contexts.take(uid);
```

#### AUTO 


```{c}
auto parentUid = serializer->relatedUidFromItem(*myself);
```

#### AUTO 


```{c}
const auto dueDate = task ? task->dueDate() : QDateTime();
```

#### AUTO 


```{c}
const auto dueDateText = dueDate.isValid() ? QLocale().toString(dueDate.date(), QLocale::ShortFormat)
                                               : QString();
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Akonadi::Collection &collection) {
            return collection.isValid();
        }
```

#### AUTO 


```{c}
const auto current = m_centralView->selectionModel()->currentIndex();
```

#### LAMBDA EXPRESSION 


```{c}
[fetchCollectionJob, item, job, this] {
            if (fetchCollectionJob->kjob()->error() != KJob::NoError)
                return;

            Q_ASSERT(fetchCollectionJob->collections().size() > 0);
            const Akonadi::Collection::List collections = fetchCollectionJob->collections();
            Akonadi::Collection col = *std::find_if(collections.constBegin(), collections.constEnd(),
                                                    [] (const Akonadi::Collection &c) {
                return c.rights() == Akonadi::Collection::AllRights;
            });
            Q_ASSERT(col.isValid());
            auto createJob = m_storage->createItem(item, col);
            job->addSubjob(createJob);
            createJob->start();
        }
```

#### AUTO 


```{c}
auto cachedCollections = job->collections();
```

#### AUTO 


```{c}
const auto collection = Akonadi::Collection(GenCollection().withRootAsParent()
                                                                   .withId(2)
                                                                   .withName("tasks")
                                                                   .withTaskContent());
```

#### AUTO 


```{c}
auto rootNote = Domain::Note::Ptr::create();
```

#### AUTO 


```{c}
auto mainLayout = new QVBoxLayout(this);
```

#### AUTO 


```{c}
auto newItem = item;
```

#### AUTO 


```{c}
auto dataSource = m_serializer->createDataSourceFromCollection(collection);
```

#### LAMBDA EXPRESSION 


```{c}
[](const Domain::Task::Ptr &task, int role, const TaskExtraDataPtr &info) {
        return defaultTaskData(task, role, info);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto collection : job->collections()) {
            auto dataSource = deserializeDataSource(collection);
            if (dataSource)
                provider->append(dataSource);
        }
```

#### AUTO 


```{c}
const auto attachment = task->attachments().at(i);
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Akonadi::Collection &collection) {
            return m_serializer->isNoteCollection(collection);
        }
```

#### AUTO 


```{c}
const auto delegate = std::find_if(attendees.begin(), attendees.end(),
                                           [] (const KCalCore::Attendee::Ptr &attendee) {
                                               return attendee->status() == KCalCore::Attendee::Delegated;
                                           });
```

#### AUTO 


```{c}
const auto contextList = task->property("contextList").toString();
```

#### AUTO 


```{c}
auto drop = [this](const QMimeData *mimeData, Qt::DropAction, const Domain::Artifact::Ptr &artifact) {
        auto parentTask = artifact.objectCast<Domain::Task>();

        if (!mimeData->hasFormat("application/x-zanshin-object"))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                        [](const Domain::Artifact::Ptr &droppedArtifact) {
                            return !droppedArtifact.objectCast<Domain::Task>();
                        })) {
            return false;
        }

        foreach(const auto &droppedArtifact, droppedArtifacts) {
            auto childTask = droppedArtifact.objectCast<Domain::Task>();

            if (parentTask) {
                const auto job = m_taskRepository->associate(parentTask, childTask);
                installHandler(job, tr("Cannot move task %1 as sub-task of %2").arg(childTask->title()).arg(parentTask->title()));
            } else {
                const auto job = m_taskRepository->dissociate(childTask);
                installHandler(job, tr("Cannot deparent task %1 from its parent").arg(childTask->title()));
            }
        }

        return true;
    };
```

#### AUTO 


```{c}
auto proxyModel = qobject_cast<Presentation::TaskFilterProxyModel*>(centralView->model());
```

#### AUTO 


```{c}
auto scope = job->fetchScope();
```

#### AUTO 


```{c}
auto setDataFunction = [&](const Domain::Task::Ptr &task, const QVariant &value, int role) {
            if (role != Qt::EditRole && role != Qt::CheckStateRole) {
                return false;
            }

            if (role == Qt::EditRole) {
                task->setTitle(value.toString());
            } else {
                task->setDone(value.toInt() == Qt::Checked);
            }

            repositoryMock.getInstance().save(task);
            return true;
        };
```

#### AUTO 


```{c}
const auto inPopulatedTag = std::any_of(newTags.cbegin(), newTags.cend(),
                                            [this](const Tag &tag) { return m_tagItems.contains(tag.id()); });
```

#### LAMBDA EXPRESSION 


```{c}
[this, &listingDone] (const Domain::LiveRelationshipQuery<QObject*, QString>::AddFunction &add) {
            Q_UNUSED(add);
            Utils::JobHandler::install(new FakeJob, [&listingDone] {
                listingDone = true;
            });
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (Utils::DependencyManager *deps) {
        return new Akonadi::CachingStorage(deps->create<Akonadi::Cache>(),
                                           Akonadi::StorageInterface::Ptr(m_data.createStorage()));
    }
```

#### AUTO 


```{c}
auto task3 = model->data(task3Index, Presentation::QueryTreeModelBase::ObjectRole).value<Domain::Task::Ptr>();
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QMimeData *mimeData, Qt::DropAction, const Domain::Task::Ptr &parentTask) {
        if (!mimeData->hasFormat(QStringLiteral("application/x-zanshin-object")))
            return false;

        auto droppedTasks = mimeData->property("objects").value<Domain::Task::List>();
        if (droppedTasks.isEmpty())
            return false;

        foreach(const auto &childTask, droppedTasks) {
            if (parentTask) {
                const auto job = m_taskRepository->associate(parentTask, childTask);
                installHandler(job, i18n("Cannot move task %1 as sub-task of %2", childTask->title(), parentTask->title()));
            } else {
                childTask->setStartDate(Utils::DateTime::currentDate());

                auto job = m_taskRepository->dissociate(childTask);
                installHandler(job, i18n("Cannot deparent task %1 from its parent", childTask->title()));
            }
        }

        return true;
    }
```

#### AUTO 


```{c}
auto calendar = new ETMCalendar(QStringList() << KCalCore::Todo::todoMimeType());
```

#### AUTO 


```{c}
auto displayedIndex = displayedModel->index(1, 0);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QObjectPtr &object, const QVariant &value, int role) {
        if (role != Qt::EditRole) {
            return false;
        }

        if (object == m_inboxObject
         || object == m_projectsObject
         || object == m_contextsObject
         || object == m_tagsObject) {
            return false;
        }

        if (auto project = object.objectCast<Domain::Project>()) {
            const auto currentName = project->name();
            project->setName(value.toString());
            const auto job = m_projectRepository->update(project);
            if (!errorHandler())
                return true;

            errorHandler()->installHandler(job, tr("Cannot modify project %1").arg(currentName));
        } else if (auto context = object.objectCast<Domain::Context>()) {
            const auto currentName = context->name();
            context->setName(value.toString());
            const auto job = m_contextRepository->update(context);
            if (!errorHandler())
                return true;

            errorHandler()->installHandler(job, tr("Cannot modify context %1").arg(currentName));
        } else if (object.objectCast<Domain::Tag>()) {
            return false; // Tag renaming is NOT allowed
        } else {
            Q_ASSERT(false);
        }

        return true;
    }
```

#### AUTO 


```{c}
auto cancelAddAction = page.findChild<QAction*>("cancelAddItemAction");
```

#### AUTO 


```{c}
auto result = ContextResult::create(provider);
```

#### AUTO 


```{c}
auto task = child.objectCast<Domain::Task>()
```

#### AUTO 


```{c}
const auto parentItem = items.at(parentIndex);
```

#### AUTO 


```{c}
auto drop = [this](const QMimeData *mimeData, Qt::DropAction, const QObjectPtr &object) {
        if (!mimeData->hasFormat(QStringLiteral("application/x-zanshin-object")))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                        [](const Domain::Artifact::Ptr &droppedArtifact) {
                            return !droppedArtifact.objectCast<Domain::Note>();
                        })) {
            return false;
        }

        if (auto tag = object.objectCast<Domain::Tag>()) {
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                auto note = droppedArtifact.staticCast<Domain::Note>();
                const auto job = m_tagRepository->associate(tag, note);
                installHandler(job, tr("Cannot tag %1 with %2").arg(note->title(), tag->name()));
            }
            return true;
        } else if (object == m_inboxObject) {
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                auto note = droppedArtifact.staticCast<Domain::Note>();
                const auto job = m_tagRepository->dissociateAll(note);
                installHandler(job, tr("Cannot move %1 to Inbox").arg(note->title()));
            }
            return true;
        }

        return false;
    };
```

#### AUTO 


```{c}
auto newItemList = m_migrator.fetchAllItems(WhichItems::OnlyContexts).items;
```

#### LAMBDA EXPRESSION 


```{c}
[fetchItemJob, parent, job, this] {
        if (fetchItemJob->kjob()->error() != KJob::NoError)
            return;

        Q_ASSERT(fetchItemJob->items().size() == 1);
        auto childItem = fetchItemJob->items().first();
        auto tag = m_serializer->createTagFromContext(parent);
        Q_ASSERT(tag.isValid());
        childItem.clearTag(tag);

        auto updateJob = m_storage->updateItem(childItem);
        job->addSubjob(updateJob);
        updateJob->start();
    }
```

#### AUTO 


```{c}
auto widget = new QWidget;
```

#### AUTO 


```{c}
auto availablePages = static_cast<FakeAvailablePagesModel*>(app.availablePages());
```

#### AUTO 


```{c}
auto source = Domain::DataSource::Ptr::create();
```

#### AUTO 


```{c}
auto fetch = [storage, collection] (const Domain::LiveQueryInput<Akonadi::Item>::AddFunction &add) {
            auto job = storage->fetchItems(collection);
            Utils::JobHandler::install(job->kjob(), [add, job] {
                foreach (const auto &item, job->items()) {
                    add(item);
                }
            });
        };
```

#### AUTO 


```{c}
auto job = storage->removeTag(tag);
```

#### AUTO 


```{c}
auto artifact = serializer.createArtifactFromItem(item);
```

#### AUTO 


```{c}
auto &itemList
```

#### AUTO 


```{c}
auto sourceIndex = sourceModel()->index(sourceRow, 0);
```

#### AUTO 


```{c}
auto drop = [this](const QMimeData *mimeData, Qt::DropAction, const Domain::Artifact::Ptr &artifact) {
        auto parentTask = artifact.objectCast<Domain::Task>();

        if (!mimeData->hasFormat("application/x-zanshin-object"))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                        [](const Domain::Artifact::Ptr &droppedArtifact) {
                            return !droppedArtifact.objectCast<Domain::Task>();
                        })) {
            return false;
        }

        foreach(const auto &droppedArtifact, droppedArtifacts) {
            auto childTask = droppedArtifact.objectCast<Domain::Task>();

            if (parentTask) {
                const auto job = taskRepository()->associate(parentTask, childTask);
                installHandler(job, tr("Cannot move task %1 as sub-task of %2").arg(childTask->title()).arg(parentTask->title()));
            } else {
                const auto job = taskRepository()->dissociate(childTask);
                installHandler(job, tr("Cannot deparent task %1 from its parent").arg(childTask->title()));
            }
        }

        return true;
    };
```

#### AUTO 


```{c}
auto job = storage.fetchCollections(rootCollection, fetchDepth, nullptr);
```

#### AUTO 


```{c}
auto taskResult = Domain::QueryResult<Domain::Task::Ptr>::create(m_taskProvider);
```

#### AUTO 


```{c}
auto attachment = task->attachments().at(index.row());
```

#### AUTO 


```{c}
auto data = new QMimeData;
```

#### AUTO 


```{c}
auto availablePagesTreeView = availablePageView->findChild<QTreeView*>(QStringLiteral("pagesView"));
```

#### AUTO 


```{c}
auto result = queries->findWorkdayTopLevel();
```

#### AUTO 


```{c}
auto addProjectAction = available.findChild<QAction*>("addProjectAction");
```

#### AUTO 


```{c}
const auto taskCollection = Akonadi::Collection(GenCollection().withRootAsParent()
                                                                       .withId(2)
                                                                       .withName("tasks")
                                                                       .withTaskContent());
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QMimeData *mimeData, Qt::DropAction, const QObjectPtr &object) {
        if (!mimeData->hasFormat(QStringLiteral("application/x-zanshin-object")))
            return false;

        auto droppedTasks = mimeData->property("objects").value<Domain::Task::List>();
        if (droppedTasks.isEmpty())
            return false;

        if (auto project = object.objectCast<Domain::Project>()) {
            foreach (const auto &task, droppedTasks) {
                const auto job = m_projectRepository->associate(project, task);
                installHandler(job, i18n("Cannot add %1 to project %2", task->title(), project->name()));
            }
            return true;
        } else if (auto context = object.objectCast<Domain::Context>()) {
            foreach (const auto &task, droppedTasks) {
                const auto job = m_contextRepository->associate(context, task);
                installHandler(job, i18n("Cannot add %1 to context %2", task->title(), context->name()));
            }
            return true;
        } else if (object == m_inboxObject) {
            foreach (const auto &task, droppedTasks) {
                const auto job = m_projectRepository->dissociate(task);
                installHandler(job, i18n("Cannot move %1 to Inbox", task->title()));

                Utils::JobHandler::install(job, [this, task] {
                    const auto dissociateJob = m_taskRepository->dissociateAll(task);
                    installHandler(dissociateJob, i18n("Cannot move task %1 to Inbox", task->title()));
                });
            }
            return true;
        } else if (object == m_workdayObject) {
            foreach (const auto &task, droppedTasks) {
                task->setStartDate(Utils::DateTime::currentDate());
                const auto job = m_taskRepository->update(task);

                installHandler(job, i18n("Cannot update task %1 to Workday", task->title()));
            }
            return true;
        }

        return false;
    }
```

#### AUTO 


```{c}
auto itemFetchJob = new MockItemFetchJob(this);
```

#### LAMBDA EXPRESSION 


```{c}
[] (const Domain::Note::List &notes) -> QMimeData* {
        if (notes.isEmpty())
            return Q_NULLPTR;

        auto draggedArtifacts = Domain::Artifact::List();
        std::copy(notes.constBegin(), notes.constEnd(),
                  std::back_inserter(draggedArtifacts));

        auto data = new QMimeData;
        data->setData("application/x-zanshin-object", "object");
        data->setProperty("objects", QVariant::fromValue(draggedArtifacts));
        return data;
    }
```

#### AUTO 


```{c}
auto appModel = new ApplicationModel(Akonadi::ArtifactQueries::Ptr::create(),
                                             Akonadi::ProjectQueries::Ptr::create(),
                                             Akonadi::ProjectRepository::Ptr::create(),
                                             Akonadi::ContextQueries::Ptr::create(),
                                             Akonadi::ContextRepository::Ptr::create(),
                                             Akonadi::DataSourceQueries::Ptr::create(),
                                             Akonadi::DataSourceRepository::Ptr::create(),
                                             Akonadi::TaskQueries::Ptr::create(),
                                             Akonadi::TaskRepository::Ptr::create(),
                                             Akonadi::NoteRepository::Ptr::create(),
                                             Akonadi::TagQueries::Ptr::create(),
                                             Akonadi::TagRepository::Ptr::create(),
                                             this);
```

#### AUTO 


```{c}
const auto tag = Akonadi::Tag(GenTag().withId(1).withName("tag"));
```

#### AUTO 


```{c}
auto serializer = deps->create<Akonadi::SerializerInterface>();
```

#### AUTO 


```{c}
auto doneButton = editor.findChild<QAbstractButton*>("doneButton");
```

#### AUTO 


```{c}
auto topLevelTask = Domain::Task::Ptr::create();
```

#### LAMBDA EXPRESSION 


```{c}
[this, add] {}
```

#### AUTO 


```{c}
auto exQuery = Domain::LiveQueryOutput<Domain::Project::Ptr>::Ptr();
```

#### AUTO 


```{c}
auto centralView = pageView->findChild<QTreeView*>(QStringLiteral("centralView"));
```

#### AUTO 


```{c}
const auto taskIndex = page.centralListModel()->index(0, 0);
```

#### AUTO 


```{c}
auto todo = item->payload<KCalCore::Todo::Ptr>();
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Akonadi::Item &item) {
            if (!m_serializer->isTaskItem(item))
                return false;

            const Domain::Task::Ptr task = m_serializer->createTaskFromItem(item);

            const QDate doneDate = task->doneDate().date();
            const QDate startDate = task->startDate().date();
            const QDate dueDate = task->dueDate().date();
            const QDate today = Utils::DateTime::currentDateTime().date();

            const bool pastStartDate = startDate.isValid() && startDate <= today;
            const bool pastDueDate = dueDate.isValid() && dueDate <= today;
            const bool todayDoneDate = doneDate == today;

            if (task->isDone())
                return todayDoneDate;
            else
                return pastStartDate || pastDueDate;

        }
```

#### AUTO 


```{c}
auto title = QString("New note");
```

#### AUTO 


```{c}
auto page = components.pageView();
```

#### AUTO 


```{c}
auto contextTodo = contextItem.payload<KCalCore::Todo::Ptr>();
```

#### AUTO 


```{c}
auto flags = [this](const QObjectPtr &object) {
        const Qt::ItemFlags defaultFlags = Qt::ItemIsSelectable
                                         | Qt::ItemIsEnabled
                                         | Qt::ItemIsEditable
                                         | Qt::ItemIsDropEnabled;
        const Qt::ItemFlags immutableNodeFlags = Qt::ItemIsSelectable
                                               | Qt::ItemIsEnabled
                                               | Qt::ItemIsDropEnabled;
        const Qt::ItemFlags structureNodeFlags = Qt::NoItemFlags;

        return object.objectCast<Domain::Project>() ? defaultFlags
             : object.objectCast<Domain::Context>() ? defaultFlags
             : object == m_inboxObject ? immutableNodeFlags
             : object == m_workdayObject ? immutableNodeFlags
             : structureNodeFlags;
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (auto item : job->items()) {
                if (m_serializer->isTaskChild(task, item)) {
                    auto task = deserializeTask(item);
                    if (task)
                        provider->append(task);
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Domain::Artifact::Ptr &artifact, const QVariant &value, int role) {
        if (role != Qt::EditRole && role != Qt::CheckStateRole) {
            return false;
        }

        if (auto task = artifact.dynamicCast<Domain::Task>()) {
            const auto currentTitle = task->title();
            if (role == Qt::EditRole)
                task->setTitle(value.toString());
            else
                task->setDone(value.toInt() == Qt::Checked);

            const auto job = m_taskRepository->update(task);
            installHandler(job, tr("Cannot modify task %1 in Inbox").arg(currentTitle));
            return true;

        } else if (auto note = artifact.dynamicCast<Domain::Note>()) {
            if (role != Qt::EditRole)
                return false;

            const auto currentTitle = note->title();
            note->setTitle(value.toString());
            const auto job = m_noteRepository->update(note);
            installHandler(job, tr("Cannot modify note %1 in Inbox").arg(currentTitle));
            return true;

        }

        return false;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QMimeData *mimeData, Qt::DropAction, const Domain::Task::Ptr &parentTask) {
        if (!parentTask)
            return false;

        if (!mimeData->hasFormat("application/x-zanshin-object"))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                        [](const Domain::Artifact::Ptr &droppedArtifact) {
                            return !droppedArtifact.objectCast<Domain::Task>();
                        })) {
            return false;
        }

        foreach(const Domain::Artifact::Ptr &droppedArtifact, droppedArtifacts) {
            auto childTask = droppedArtifact.objectCast<Domain::Task>();
            const auto job = m_taskRepository->associate(parentTask, childTask);
            installHandler(job, tr("Cannot move task %1 as a sub-task of %2").arg(childTask->title()).arg(parentTask->title()));
        }

        return true;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &newTag : newTags) {
        if (!oldItem.tags().contains(newTag) && m_tagItems.contains(newTag.id())) {
            m_tagItems[newTag.id()].append(item.id());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &itemList : m_collectionItems)
        itemList.removeAll(item.id());
```

#### AUTO 


```{c}
auto filter = page.findChild<Widgets::FilterWidget*>("filterWidget");
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &item : items) {
        itemRemoteIds << item.remoteId();

        QVERIFY(item.loadedPayloadParts().contains(Akonadi::Item::FullPayload));
        QVERIFY(!item.attributes().isEmpty());
        QVERIFY(item.modificationTime().isValid());
        QVERIFY(!item.flags().isEmpty());

        auto parent = item.parentCollection();
        while (parent != Akonadi::Collection::root()) {
            QVERIFY(parent.isValid());
            parent = parent.parentCollection();
        }

    }
```

#### AUTO 


```{c}
auto job = new Akonadi::TagModifyJob(tag);
```

#### LAMBDA EXPRESSION 


```{c}
[tag, add] (const Item &item) {
            if (item.tags().contains(tag))
                add(item);
        }
```

#### AUTO 


```{c}
auto model = Utils::DependencyManager::globalInstance().create<RunningTaskModel>();
```

#### LAMBDA EXPRESSION 


```{c}
[this] (Utils::DependencyManager *) {
        return m_data.createMonitor();
    }
```

#### AUTO 


```{c}
auto filter = page.findChild<Widgets::FilterWidget*>(QStringLiteral("filterWidget"));
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Domain::Task::Ptr &task) -> Domain::QueryResultInterface<Domain::Task::Ptr>::Ptr {
        if (!task)
            return m_taskQueries->findWorkdayTopLevel();
        else
            return m_taskQueries->findChildren(task);
    }
```

#### AUTO 


```{c}
auto drop = [this](const QMimeData *mimeData, Qt::DropAction, const QObjectPtr &object) {
        if (!mimeData->hasFormat("application/x-zanshin-object"))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (auto project = object.objectCast<Domain::Project>()) {
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                const auto job = m_projectRepository->associate(project, droppedArtifact);
                installHandler(job, tr("Cannot add %1 to project %2").arg(droppedArtifact->title()).arg(project->name()));
            }
            return true;
        } else if (auto context = object.objectCast<Domain::Context>()) {
            if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                            [](const Domain::Artifact::Ptr &droppedArtifact) {
                                return !droppedArtifact.objectCast<Domain::Task>();
                            })) {
                return false;
            }
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                auto task = droppedArtifact.staticCast<Domain::Task>();
                const auto job = m_contextRepository->associate(context, task);
                installHandler(job, tr("Cannot add %1 to context %2").arg(task->title()).arg(context->name()));
            }
            return true;
        } else if (auto tag = object.objectCast<Domain::Tag>()) {
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                const auto job = m_tagRepository->associate(tag, droppedArtifact);
                installHandler(job, tr("Cannot tag %1 with %2").arg(droppedArtifact->title()).arg(tag->name()));
            }
            return true;
        } else if (object == m_inboxObject) {
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                const auto job = m_projectRepository->dissociate(droppedArtifact);
                installHandler(job, tr("Cannot move %1 to Inbox").arg(droppedArtifact->title()));

                if (auto task = droppedArtifact.objectCast<Domain::Task>()) {
                    Utils::JobHandler::install(job, [this, task] {
                        const auto dissociateJob = m_taskRepository->dissociateAll(task);
                        installHandler(dissociateJob, tr("Cannot move task %1 to Inbox").arg(task->title()));
                    });
                }
            }
            return true;
        } else if (object == m_workdayObject) {
            foreach (const auto &droppedArtifact, droppedArtifacts) {

                if (auto task = droppedArtifact.objectCast<Domain::Task>()) {

                    task->setStartDate(Utils::DateTime::currentDateTime());
                    const auto job = m_taskRepository->update(task);

                    installHandler(job, tr("Cannot update task %1 to Workday").arg(task->title()));
                }
            }
            return true;
        }

        return false;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this, context] (const Akonadi::Item &item) {
            return m_serializer->isContextChild(context, item);
        }
```

#### AUTO 


```{c}
const auto allMimeTypes = taskMimeTypes + bogusMimeTypes;
```

#### LAMBDA EXPRESSION 


```{c}
[provider, job, this] {
        for (auto collection : job->collections()) {
            ItemFetchJobInterface *job = m_storage->fetchItems(collection);
            registerJobHandler(job->kjob(), [provider, job, this] {
                for (auto item : job->items()) {
                    auto task = deserializeTask(item);
                    if (task)
                        provider->append(task);
                }
            });
        }
    }
```

#### AUTO 


```{c}
auto drop = [this] (const QMimeData *mimeData, Qt::DropAction, const Domain::Task::Ptr &parentTask) {
        Q_UNUSED(mimeData);
        Q_UNUSED(parentTask);
        qFatal("Drop Not implemented yet");
        return true;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Akonadi::Item &item, Domain::Task::Ptr &task) {
            m_serializer->updateTaskFromItem(task, item);
        }
```

#### AUTO 


```{c}
auto flags = [] (const Domain::DataSource::Ptr &source) {
        const Qt::ItemFlags defaultFlags = Qt::ItemIsSelectable
                                         | Qt::ItemIsEnabled;
        if (source->contentTypes() != Domain::DataSource::NoContent)
            return defaultFlags | Qt::ItemIsUserCheckable;
        else
            return defaultFlags;
    };
```

#### AUTO 


```{c}
auto akonadiTag = m_serializer->createAkonadiTagFromTag(parent);
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Domain::LiveQuery<QObject*, QString>::AddFunction &add) {
            Utils::JobHandler::install(new FakeJob, [this, add] {
                add(createObject(0, QStringLiteral("0A")));
                add(createObject(1, QStringLiteral("1A")));
                add(createObject(2, QStringLiteral("2A")));
            });
        }
```

#### AUTO 


```{c}
auto pageView = new PageView(m_parent);
```

#### LAMBDA EXPRESSION 


```{c}
[] (const Domain::Artifact::List &artifacts) -> QMimeData* {
        if (artifacts.isEmpty())
            return Q_NULLPTR;

        auto data = new QMimeData;
        data->setData("application/x-zanshin-object", "object");
        data->setProperty("objects", QVariant::fromValue(artifacts));
        return data;
    }
```

#### AUTO 


```{c}
auto parent = notifiedItem.parentCollection();
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QMimeData *mimeData, Qt::DropAction, const Domain::Task::Ptr &parentTask) {
        if (!mimeData->hasFormat(QStringLiteral("application/x-zanshin-object")))
            return false;

        auto droppedTasks = mimeData->property("objects").value<Domain::Task::List>();
        if (droppedTasks.isEmpty())
            return false;

        foreach(const auto &childTask, droppedTasks) {
            if (parentTask) {
                const auto job = m_taskRepository->associate(parentTask, childTask);
                installHandler(job, i18n("Cannot move task %1 as sub-task of %2", childTask->title(), parentTask->title()));
            } else {
                childTask->setStartDate(Utils::DateTime::currentDate());
                // TODO something like m_taskRepository->update(childTask) is missing here
                // It was removed in commit c97a99bf because it led to a LLCONFLICT in akonadi (due to dissociate below).
                // The removal broke tests-features-workday-workdaydraganddropfeature (date not changed).

                auto job = m_taskRepository->dissociate(childTask);
                installHandler(job, i18n("Cannot deparent task %1 from its parent", childTask->title()));
            }
        }

        return true;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[add, job, storage, serializer] {
                foreach (const auto &col, job->collections()) {
                    if (!serializer->isSelectedCollection(col))
                        continue;

                    auto itemJob = storage->fetchItems(col);
                    Utils::JobHandler::install(itemJob->kjob(), [add, itemJob] {
                        foreach (const auto &item, itemJob->items())
                            add(item);
                    });
                }
            }
```

#### AUTO 


```{c}
auto list = Domain::QueryResult<Domain::Task::Ptr>::create(provider);
```

#### AUTO 


```{c}
auto delegate = qobject_cast<ItemDelegate*>(m_centralView->itemDelegate());
```

#### AUTO 


```{c}
auto drag = [](const Domain::Task::List &tasks) -> QMimeData* {
        if (tasks.isEmpty())
            return nullptr;

        auto data = new QMimeData;
        data->setData(QStringLiteral("application/x-zanshin-object"), "object");
        data->setProperty("objects", QVariant::fromValue(tasks));
        return data;
    };
```

#### AUTO 


```{c}
auto emptyList = Domain::QueryResult<Domain::Task::Ptr>::create(emptyProvider);
```

#### LAMBDA EXPRESSION 


```{c}
[](const Domain::Artifact::Ptr &artifact) -> QMimeData* {
        if (!artifact)
            return 0;

        QMimeData *data = new QMimeData;
        data->setData("application/x-zanshin-object", "object");
        data->setProperty("object", QVariant::fromValue(artifact));
        return data;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString &value, int pos)
            {
                preRemoves << value;
                preRemovesPos << pos;
            }
```

#### AUTO 


```{c}
auto query = [this](const Domain::Artifact::Ptr &artifact) -> Domain::QueryResultInterface<Domain::Artifact::Ptr>::Ptr {
        if (!artifact)
            return m_artifactQueries->findInboxTopLevel();
        else if (auto task = artifact.dynamicCast<Domain::Task>())
            return Domain::QueryResult<Domain::Task::Ptr, Domain::Artifact::Ptr>::copy(taskQueries()->findChildren(task));
        else
            return Domain::QueryResult<Domain::Artifact::Ptr>::Ptr();
    };
```

#### AUTO 


```{c}
const auto allTags = item.tags();
```

#### AUTO 


```{c}
auto dragFunction = [] (const QList<QColor> &) {
            return nullptr;
        };
```

#### LAMBDA EXPRESSION 


```{c}
[add, job] {
                foreach (const auto &col, job->collections()) {
                    add(col);
                }
            }
```

#### AUTO 


```{c}
auto itemJob = storage->fetchItems(col);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &uid) { return m_contextTodos.value(uid); }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Domain::LiveQueryInput<QString>::AddFunction &add) {
            Utils::JobHandler::install(new FakeJob, [this, add] {
                add("0");
                add("1");
                add(QString());
                add("a");
                add("2");
            });
        }
```

#### LAMBDA EXPRESSION 


```{c}
[] (QObject *object) {
            return QPair<int, QString>(object->property("objectId").toInt(), object->objectName());
        }
```

#### LAMBDA EXPRESSION 


```{c}
[] (const Domain::Task::List &tasks) -> QMimeData* {
        Q_UNUSED(tasks);
        qFatal("Drag Not implemented yet");
        return new QMimeData;
    }
```

#### AUTO 


```{c}
auto job = storage.fetchItem(item1);
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Domain::Note::Ptr &note, const QVariant &value, int role) {
        if (role != Qt::EditRole) {
            return false;
        }

        const auto currentTitle = note->title();
        note->setTitle(value.toString());
        const auto job = m_noteRepository->update(note);
        installHandler(job, tr("Cannot modify note %1 in tag %2").arg(currentTitle, m_tag->name()));
        return true;
    }
```

#### AUTO 


```{c}
const auto parentData = parentIndex.data(QueryTreeModel<Domain::Task::Ptr>::ObjectRole);
```

#### AUTO 


```{c}
auto taskInModel = model->data(model->index(0, 0), Presentation::QueryTreeModelBase::ObjectRole).value<Domain::Task::Ptr>();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto collection : job->collections()) {
                    if (!m_serializer->isSelectedCollection(collection))
                        continue;

                    ItemFetchJobInterface *job = m_storage->fetchItems(collection);
                    Utils::JobHandler::install(job->kjob(), [this, job, add] {
                        if (job->kjob()->error() != KJob::NoError)
                            return;

                        for (auto item : job->items()) {
                            add(item);
                        }
                    });
                }
```

#### AUTO 


```{c}
auto filterViewAction = new QAction(this);
```

#### LAMBDA EXPRESSION 


```{c}
[root, job, add] {
            if (job->kjob()->error())
                return;

            auto directChildren = QHash<Collection::Id, Collection>();
            foreach (const auto &collection, job->collections()) {
                auto directChild = collection;
                while (directChild.parentCollection() != root && directChild.parentCollection().isValid())
                    directChild = directChild.parentCollection();
                if (directChild.parentCollection() != root)
                    continue;
                if (!directChildren.contains(directChild.id()))
                    directChildren[directChild.id()] = directChild;
            }

            foreach (const auto &directChild, directChildren.values())
                add(directChild);
        }
```

#### AUTO 


```{c}
auto fetch = m_helpers->fetchAllCollections(StorageInterface::Notes);
```

#### LAMBDA EXPRESSION 


```{c}
[root, job, add] {
            if (job->kjob()->error())
                return;

            auto directChildren = QHash<Collection::Id, Collection>();
            foreach (const auto &collection, job->collections()) {
                auto directChild = collection;
                while (directChild.parentCollection() != root)
                    directChild = directChild.parentCollection();
                if (!directChildren.contains(directChild.id()))
                    directChildren[directChild.id()] = directChild;
            }

            foreach (const auto &directChild, directChildren.values())
                add(directChild);
        }
```

#### AUTO 


```{c}
auto drag = [](const Domain::Task::List &tasks) -> QMimeData* {
        if (tasks.isEmpty())
            return Q_NULLPTR;

        auto draggedArtifacts = Domain::Artifact::List();
        foreach (const Domain::Task::Ptr &task, tasks) {
            draggedArtifacts.append(task.objectCast<Domain::Artifact>());
        }

        auto data = new QMimeData;
        data->setData("application/x-zanshin-object", "object");
        data->setProperty("objects", QVariant::fromValue(draggedArtifacts));
        return data;
    };
```

#### AUTO 


```{c}
auto query = [this](const QObjectPtr &object) -> Domain::QueryResultInterface<QObjectPtr>::Ptr {
        if (!object)
            return Domain::QueryResult<QObjectPtr>::create(m_rootsProvider);
        else if (object == m_projectsObject)
            return Domain::QueryResult<Domain::Project::Ptr, QObjectPtr>::copy(m_projectQueries->findAll());
        else if (object == m_contextsObject)
            return Domain::QueryResult<Domain::Context::Ptr, QObjectPtr>::copy(m_contextQueries->findAll());
        else
            return Domain::QueryResult<QObjectPtr>::Ptr();
    };
```

#### LAMBDA EXPRESSION 


```{c}
[](const Domain::Artifact::Ptr &droppedArtifact) {
                            return !droppedArtifact.objectCast<Domain::Note>();
                        }
```

#### LAMBDA EXPRESSION 


```{c}
[](const Akonadi::Tag &tag) { return tag.name(); }
```

#### AUTO 


```{c}
auto job = storage.fetchItem(Akonadi::Item(44));
```

#### AUTO 


```{c}
auto setData = [this](const Domain::Task::Ptr &task, const QVariant &value, int role) {
        if (role != Qt::EditRole && role != Qt::CheckStateRole) {
            return false;
        }

        const auto currentTitle = task->title();
        if (role == Qt::EditRole)
            task->setTitle(value.toString());
        else
            task->setDone(value.toInt() == Qt::Checked);

        const auto job = m_taskRepository->update(task);
        installHandler(job, i18n("Cannot modify task %1 in Workday", currentTitle));
        return true;
    };
```

#### AUTO 


```{c}
auto data = [](const Domain::Task::Ptr &task, int role, const TaskExtraDataPtr &info) {
        return defaultTaskData(task, role, info);
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const QMimeData *mimeData, Qt::DropAction, const Domain::Task::Ptr &parentTask) {
        if (!mimeData->hasFormat(QStringLiteral("application/x-zanshin-object")))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                        [](const Domain::Artifact::Ptr &droppedArtifact) {
                            return !droppedArtifact.objectCast<Domain::Task>();
                        })) {
            return false;
        }

        using namespace std::placeholders;
        auto associate = std::function<KJob*(Domain::Task::Ptr)>();
        auto dissociate = std::function<KJob*(Domain::Task::Ptr)>();
        auto parentTitle = QString();

        if (parentTask) {
            associate = std::bind(&Domain::TaskRepository::associate, m_taskRepository, parentTask, _1);
            dissociate = [] (Domain::Task::Ptr) -> KJob* { return Q_NULLPTR; };
            parentTitle = parentTask->title();
        } else {
            associate = std::bind(&Domain::ContextRepository::associate, m_contextRepository, m_context, _1);
            dissociate = std::bind(&Domain::TaskRepository::dissociate, m_taskRepository, _1);
            parentTitle = m_context->name();
        }

        foreach(const Domain::Artifact::Ptr &droppedArtifact, droppedArtifacts) {
            auto childTask = droppedArtifact.objectCast<Domain::Task>();
            auto job = associate(childTask);
            installHandler(job, tr("Cannot move task %1 as sub-task of %2").arg(childTask->title(), parentTitle));
            job = dissociate(childTask);
            if (job)
                installHandler(job, tr("Cannot dissociate task %1 from its parent").arg(childTask->title()));
        }

        return true;
    }
```

#### AUTO 


```{c}
const auto taskNoteContent = Akonadi::StorageInterface::FetchContentTypes(Akonadi::StorageInterface::Notes
                                                                                | Akonadi::StorageInterface::Tasks);
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const ArtifactQuery::AddFunction &add) {
            CollectionFetchJobInterface *job = m_storage->fetchCollections(Akonadi::Collection::root(),
                                                                           StorageInterface::Recursive,
                                                                           StorageInterface::Tasks|StorageInterface::Notes);
            Utils::JobHandler::install(job->kjob(), [this, job, add] {
                if (job->kjob()->error() != KJob::NoError)
                    return;

                for (auto collection : job->collections()) {
                    ItemFetchJobInterface *job = m_storage->fetchItems(collection);
                    Utils::JobHandler::install(job->kjob(), [this, job, add] {
                        if (job->kjob()->error() != KJob::NoError)
                            return;

                        for (auto item : job->items()) {
                            add(item);
                        }
                    });
                }
            });
        }
```

#### AUTO 


```{c}
auto query = Domain::LiveQueryOutput<Domain::Note::Ptr>::Ptr();
```

#### AUTO 


```{c}
const auto isSelected = (opt.state & QStyle::State_Selected);
```

#### AUTO 


```{c}
auto item = m_serializer->createItemFromNote(note);
```

#### LAMBDA EXPRESSION 


```{c}
[](const Domain::Artifact::Ptr &droppedArtifact) {
                            return !droppedArtifact.objectCast<Domain::Task>();
                        }
```

#### AUTO 


```{c}
auto fetchAdditionalInfo = [this](const QModelIndex &index, const Domain::Task::Ptr &task) {
        return fetchTaskExtraData(m_taskQueries, index, task);
    };
```

#### AUTO 


```{c}
const auto data = std::unique_ptr<QMimeData>(centralListModel->mimeData(droppedItems));
```

#### AUTO 


```{c}
auto itemFetchJob = new Testlib::AkonadiFakeItemFetchJob(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Akonadi::Tag &tag) {
        return tag.type() == Akonadi::SerializerInterface::contextTagType();
    }
```

#### AUTO 


```{c}
const auto contexts = info->contextQueryResult->data();
```

#### AUTO 


```{c}
auto setDataFunction = [](const QString &, const QVariant &, int) {
            return false;
        };
```

#### AUTO 


```{c}
auto note = artifact.objectCast<Domain::Note>();
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString &value, int pos)
            {
                postReplaces << value;
                postReplacesPos << pos;
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Akonadi::Collection &collection) {
        return m_serializer->isNoteCollection(collection);
    }
```

#### AUTO 


```{c}
auto dataSource2 = serializer.createDataSourceFromCollection(collection, Akonadi::SerializerInterface::BaseName);
```

#### AUTO 


```{c}
auto model = createAvailablePagesModel();
```

#### AUTO 


```{c}
auto fetch = m_helpers->fetchAllCollections(m_contentTypes);
```

#### AUTO 


```{c}
const auto itemFetchIds = toItemIds(job->items());
```

#### AUTO 


```{c}
auto job = storage->fetchCollections(Collection::root(), StorageInterface::Recursive, contentTypes);
```

#### AUTO 


```{c}
auto job = storage->fetchCollections(Collection::root(), StorageInterface::Recursive, parent);
```

#### AUTO 


```{c}
const auto myself = std::find_if(items.cbegin(), items.cend(),
                                             [childId] (const Akonadi::Item &item) {
                                                 return childId == item.id();
                                             });
```

#### AUTO 


```{c}
auto it = std::remove_if(result.begin(), result.end(),
                                 [] (const Akonadi::Collection &col) {
                                     const auto mime = col.contentMimeTypes();
                                     return !mime.contains(KCalCore::Todo::todoMimeType());
                                 });
```

#### AUTO 


```{c}
auto serializer = Akonadi::SerializerInterface::Ptr(new Akonadi::Serializer);
```

#### AUTO 


```{c}
auto job = storage->moveItems(list, calendar1(), nullptr);
```

#### AUTO 


```{c}
auto uid = m_serializer->relatedUidFromItem(item);
```

#### LAMBDA EXPRESSION 


```{c}
[] (const Domain::Task::List &tasks) -> QMimeData* {
        if (tasks.isEmpty())
            return Q_NULLPTR;

        auto draggedArtifacts = Domain::Artifact::List();
        draggedArtifacts.reserve(tasks.size());
        foreach (const Domain::Task::Ptr &task, tasks) {
            draggedArtifacts.append(task.objectCast<Domain::Artifact>());
        }

        auto data = new QMimeData();
        data->setData(QStringLiteral("application/x-zanshin-object"), "object");
        data->setProperty("objects", QVariant::fromValue(draggedArtifacts));
        return data;
    }
```

#### AUTO 


```{c}
const auto items1 = Akonadi::Item::List() << Akonadi::Item(GenTodo().withId(1).withTitle("item1"))
                                                  << Akonadi::Item(GenTodo().withId(2).withTitle("item2"));
```

#### AUTO 


```{c}
auto sourceResult = Domain::QueryResult<Domain::DataSource::Ptr>::create(provider);
```

#### LAMBDA EXPRESSION 


```{c}
[] (const Domain::Note::List &notes) -> QMimeData* {
        if (notes.isEmpty())
            return Q_NULLPTR;

        auto draggedArtifacts = Domain::Artifact::List();
        draggedArtifacts.reserve(notes.count());
        std::copy(notes.constBegin(), notes.constEnd(),
                  std::back_inserter(draggedArtifacts));

        auto data = new QMimeData;
        data->setData(QStringLiteral("application/x-zanshin-object"), "object");
        data->setProperty("objects", QVariant::fromValue(draggedArtifacts));
        return data;
    }
```

#### AUTO 


```{c}
auto setData = [this](const Domain::Artifact::Ptr &artifact, const QVariant &value, int role) {
        if (role != Qt::EditRole && role != Qt::CheckStateRole) {
            return false;
        }

        if (auto task = artifact.dynamicCast<Domain::Task>()) {
            const auto currentTitle = task->title();
            if (role == Qt::EditRole)
                task->setTitle(value.toString());
            else
                task->setDone(value.toInt() == Qt::Checked);

            const auto job = taskRepository()->update(task);
            installHandler(job, tr("Cannot modify task %1 in Workday").arg(currentTitle));
            return true;
        }

        return false;
    };
```

#### AUTO 


```{c}
auto drop = [this](const QMimeData *mimeData, Qt::DropAction, const QObjectPtr &object) {
        if (!mimeData->hasFormat("application/x-zanshin-object"))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (auto project = object.objectCast<Domain::Project>()) {
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                const auto job = m_projectRepository->associate(project, droppedArtifact);
                if (!errorHandler())
                    continue;

                errorHandler()->installHandler(job, tr("Cannot add %1 to project %2").arg(droppedArtifact->title()).arg(project->name()));
            }
            return true;
        } else if (auto context = object.objectCast<Domain::Context>()) {
            if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                            [](const Domain::Artifact::Ptr &droppedArtifact) {
                                return !droppedArtifact.objectCast<Domain::Task>();
                            })) {
                return false;
            }
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                auto task = droppedArtifact.staticCast<Domain::Task>();
                const auto job = m_contextRepository->associate(context, task);
                if (!errorHandler())
                    continue;

                errorHandler()->installHandler(job, tr("Cannot add %1 to context %2").arg(task->title()).arg(context->name()));
            }
            return true;
        } else if (auto tag = object.objectCast<Domain::Tag>()) {
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                const auto job = m_tagRepository->associate(tag, droppedArtifact);
                if (!errorHandler())
                    continue;

                errorHandler()->installHandler(job, tr("Cannot tag %1 with %2").arg(droppedArtifact->title()).arg(tag->name()));
            }
            return true;
        } else if (object == m_inboxObject) {
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                const auto job = m_projectRepository->dissociate(droppedArtifact);
                if (errorHandler())
                    errorHandler()->installHandler(job, tr("Cannot move %1 to Inbox").arg(droppedArtifact->title()));

                if (auto task = droppedArtifact.objectCast<Domain::Task>()) {
                    Utils::JobHandler::install(job, [this, task] {
                        const auto dissociateJob = m_taskRepository->dissociate(task);
                        if (errorHandler())
                            errorHandler()->installHandler(dissociateJob, tr("Cannot move task %1 to Inbox").arg(task->title()));
                    });
                }
            }
            return true;
        }

        return false;
    };
```

#### AUTO 


```{c}
auto availableSourcesGlobalActions = availableSources->globalActions();
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Domain::Task::Ptr &task) -> Domain::QueryResultInterface<Domain::Task::Ptr>::Ptr {
        if (!task)
            return m_contextQueries->findTasks(m_context);
        else
            return taskQueries()->findChildren(task);
    }
```

#### AUTO 


```{c}
auto fetch = fetchItemsInSelectedCollectionsFunction(storage, serializer, nullptr);
```

#### AUTO 


```{c}
auto monitor = createMonitor();
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Domain::Task::Ptr &task, const QVariant &value, int role) {
        if (role != Qt::EditRole && role != Qt::CheckStateRole)
            return false;

        const auto currentTitle = task->title();
        if (role == Qt::EditRole)
            task->setTitle(value.toString());
        else
            task->setDone(value.toInt() == Qt::Checked);

        const auto job = m_taskRepository->update(task);
        installHandler(job, tr("Cannot modify task %1 in context %2").arg(currentTitle, m_context->name()));
        return true;
    }
```

#### AUTO 


```{c}
auto items = Akonadi::Item::List();
```

#### LAMBDA EXPRESSION 


```{c}
[](const Domain::DataSource::List &) -> QMimeData* {
        return nullptr;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &collection : collections) {
        const auto index = m_collections.indexOf(collection);
        if (index >= 0)
            m_collections[index] = collection;
        else
            m_collections.append(collection);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, isWorkdayItem] (const Akonadi::Item &item) {
        if (!isWorkdayItem(item))
            return false;

        const auto items = m_cache->items(item.parentCollection());
        auto currentItem = item;
        auto parentUid = m_serializer->relatedUidFromItem(currentItem);
        while (!parentUid.isEmpty()) {
            const auto parent = std::find_if(items.cbegin(), items.cend(),
                                             [this, parentUid] (const Akonadi::Item &item) {
                                                 return m_serializer->itemUid(item) == parentUid;
                                             });
            if (parent == items.cend())
                break;

            if (isWorkdayItem(*parent))
                return false;

            currentItem = *parent;
            parentUid = m_serializer->relatedUidFromItem(currentItem);
        }

        return true;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto task : tasks)
            provider->append(task);
```

#### LAMBDA EXPRESSION 


```{c}
[cache, toItemIds]{
                const auto items = cache->items(Akonadi::Tag(43));
                return toItemIds(items);
            }
```

#### AUTO 


```{c}
auto available = components.availablePagesView();
```

#### AUTO 


```{c}
auto collection = Collection(id);
```

#### LAMBDA EXPRESSION 


```{c}
[fetchItemJob, job, this] {
        if (fetchItemJob->kjob()->error() != KJob::NoError)
            return;

        Q_ASSERT(fetchItemJob->items().size() == 1);
        auto childItem = fetchItemJob->items().first();

        m_serializer->removeItemParent(childItem);
        m_serializer->clearItem(&childItem);

        auto updateJob = m_storage->updateItem(childItem);
        job->addSubjob(updateJob);
        updateJob->start();
    }
```

#### AUTO 


```{c}
auto dialogStub = QuickSelectDialogStub::Ptr::create();
```

#### AUTO 


```{c}
auto todo = item.payload<KCalCore::Todo::Ptr>();
```

#### AUTO 


```{c}
auto removeItemAction = new QAction(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this, model](const Domain::Task::Ptr &, int index) {
                                        model->beginRemoveRows(model->createIndex(row(), 0, this), index, index);
                                    }
```

#### AUTO 


```{c}
const auto oldCollection = m_collections.take(collection.id());
```

#### AUTO 


```{c}
auto fetch = m_helpers->fetchItems(root, const_cast<DataSourceQueries*>(this));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &tag : tags) {
            QVERIFY(tag.isValid());
            QVERIFY(!tag.name().isEmpty());
            QVERIFY(!tag.type().isEmpty());
        }
```

#### AUTO 


```{c}
auto task2 = serializer->createTaskFromItem(data.item(43));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &roleName : data.roles) {
        const int role = roleNames.key(roleName, -1);
        VERIFY_OR_DUMP(role != -1 && !usedRoles.contains(role));
        usedRoles << role;
    }
```

#### AUTO 


```{c}
auto tagPageModel = new TagPageModel(tag,
                                             m_tagQueries,
                                             m_tagRepository,
                                             m_taskQueries,
                                             m_taskRepository,
                                             m_noteRepository,
                                             this);
```

#### AUTO 


```{c}
const auto fullText = title + '\n' + text;
```

#### LAMBDA EXPRESSION 


```{c}
[] (const Akonadi::Item &item) {
            return titleFromItem(item).endsWith(QLatin1String("-ex"));
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, model, queryGenerator](const ItemType &item, int index) {
            QueryTreeNodeBase *node = new QueryTreeNode<ItemType>(item, this, model, queryGenerator, m_flagsFunction, m_dataFunction, m_setDataFunction);
            insertChild(index, node);
            endInsertRows();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[] (Utils::DependencyManager *) {
                return new Presentation::AvailableSourcesModel(Domain::DataSourceQueries::Ptr(),
                                                               Domain::DataSourceRepository::Ptr());
        }
```

#### AUTO 


```{c}
auto pageView = components.pageView();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto handler : m_handlers)
    {
        handler();
    }
```

#### AUTO 


```{c}
auto colJob = storage->fetchCollections(Akonadi::Collection::root(),
                                            Akonadi::StorageInterface::Recursive,
                                            nullptr);
```

#### AUTO 


```{c}
auto tag = m_serializer->createTagFromContext(parent);
```

#### AUTO 


```{c}
auto data = [](const Domain::Task::Ptr &task, int role, int) -> QVariant {
        return defaultTaskData(task, role, TaskExtraDataPtr());
    };
```

#### AUTO 


```{c}
auto result = queries->findInbox();
```

#### LAMBDA EXPRESSION 


```{c}
[collectionsMap, &reconstructAncestors, this] (const Collection &collection) {
            Q_ASSERT(collection.isValid());

            if (collection == m_collection)
                return collection;

            auto parent = collection.parentCollection();
            auto reconstructedParent = reconstructAncestors(collectionsMap[parent.id()]);

            auto result = collection;
            result.setParentCollection(reconstructedParent);
            return result;
        }
```

#### AUTO 


```{c}
auto attr = new ApplicationSelectedAttribute();
```

#### AUTO 


```{c}
auto job = storage.fetchTags();
```

#### AUTO 


```{c}
auto page = QPointer<QObject>(new FakePageModel(this));
```

#### LAMBDA EXPRESSION 


```{c}
[provider, job, this] {
                for (auto item : job->items()) {
                    auto note = deserializeNote(item);
                    if (note)
                        provider->append(note);
                }
            }
```

#### AUTO 


```{c}
const auto items = job->items();
```

#### LAMBDA EXPRESSION 


```{c}
[](const Domain::Task::Ptr &task, int role, const AdditionalInfo &dataSourceQueryResult) -> QVariant {
        switch (role) {
            case Qt::DisplayRole:
            case Qt::EditRole:
                return task->title();
            case Qt::CheckStateRole:
                return task->isDone() ? Qt::Checked : Qt::Unchecked;
            case Presentation::QueryTreeModelBase::AdditionalInfoRole:
                if (dataSourceQueryResult && !dataSourceQueryResult->data().isEmpty()) {
                    Domain::DataSource::Ptr dataSource = dataSourceQueryResult->data().at(0);
                    return dataSource->name();
                }
                return QString();
            default:
                break;
        }
        return QVariant();
    }
```

#### AUTO 


```{c}
const auto task = Akonadi::Collection(GenCollection(none).withTaskContent());
```

#### LAMBDA EXPRESSION 


```{c}
[](const Domain::Task::List &tasks) -> QMimeData* {
        if (tasks.isEmpty())
            return Q_NULLPTR;

        auto draggedArtifacts = Domain::Artifact::List();
        foreach (const Domain::Task::Ptr &task, tasks) {
            draggedArtifacts.append(task.objectCast<Domain::Artifact>());
        }

        auto data = new QMimeData;
        data->setData("application/x-zanshin-object", "object");
        data->setProperty("objects", QVariant::fromValue(draggedArtifacts));
        return data;
    }
```

#### AUTO 


```{c}
auto inPredicate = [] (const Akonadi::Item &contextItem) {
            auto todo = contextItem.payload<KCalCore::Todo::Ptr>();
            return todo->summary().endsWith(QLatin1String("-in"));
        };
```

#### AUTO 


```{c}
const auto job = taskRepository()->create(task);
```

#### AUTO 


```{c}
const auto job = taskRepository()->createInProject(task, m_project);
```

#### LAMBDA EXPRESSION 


```{c}
[job, toItemIds]{
                return toItemIds(job->items());
            }
```

#### AUTO 


```{c}
auto searchEdit = new KLineEdit(this);
```

#### AUTO 


```{c}
auto fetch = m_helpers->searchCollections(Collection::root(), &m_searchTerm, m_contentTypes);
```

#### AUTO 


```{c}
auto job = new ItemJob(collection, parent);
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Domain::DataSource::Ptr &source) {
                                   return m_noteRepository->isDefaultSource(source);
                               }
```

#### AUTO 


```{c}
auto &query = m_findToplevel[contextUid];
```

#### AUTO 


```{c}
auto job = new ItemJob(collection);
```

#### AUTO 


```{c}
auto availableSources = components.availableSourcesView();
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QMimeData *mimeData, Qt::DropAction, const Domain::Task::Ptr &parentTask) {
        if (!mimeData->hasFormat("application/x-zanshin-object"))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                        [](const Domain::Artifact::Ptr &droppedArtifact) {
                            return !droppedArtifact.objectCast<Domain::Task>();
                        })) {
            return false;
        }

        using namespace std::placeholders;
        auto associate = std::function<KJob*(Domain::Task::Ptr)>();
        auto parentTitle = QString();

        if (parentTask) {
            associate = std::bind(&Domain::TaskRepository::associate, m_taskRepository, parentTask, _1);
            parentTitle = parentTask->title();
        } else {
            associate = std::bind(&Domain::ProjectRepository::associate, m_projectRepository, m_project, _1);
            parentTitle = m_project->name();
        }

        foreach(const Domain::Artifact::Ptr &droppedArtifact, droppedArtifacts) {
            auto childTask = droppedArtifact.objectCast<Domain::Task>();
            const auto job = associate(childTask);
            installHandler(job, tr("Cannot move task %1 as a sub-task of %2").arg(childTask->title(), parentTitle));
        }

        return true;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[] (QObject *object) {
            return object->objectName().startsWith('0');
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](const Domain::Task::Ptr &) {
        return Qt::ItemIsSelectable
             | Qt::ItemIsEnabled
             | Qt::ItemIsEditable
             | Qt::ItemIsDragEnabled
             | Qt::ItemIsUserCheckable
             | Qt::ItemIsDropEnabled;
    }
```

#### AUTO 


```{c}
auto source = dataSourceFromName(parentSourceName);
```

#### AUTO 


```{c}
auto mimeType = mimeDb.mimeTypeForFile(fileName);
```

#### AUTO 


```{c}
auto result = queries->findChildren(task1);
```

#### AUTO 


```{c}
auto scripthandler = new Scripting::ScriptHandler(taskRepositoryMock.getInstance(), this);
```

#### AUTO 


```{c}
auto drop = [this](const QMimeData *mimeData, Qt::DropAction, const Domain::Artifact::Ptr &artifact) {
        Q_UNUSED(mimeData);
        Q_UNUSED(artifact);
        qFatal("Not implemented yet");
        return false;
    };
```

#### AUTO 


```{c}
auto contextPageModel = new ContextPageModel(context,
                                                     m_contextQueries,
                                                     m_contextRepository,
                                                     m_taskQueries,
                                                     m_taskRepository,
                                                     this);
```

#### AUTO 


```{c}
auto pagesView = availablePagesView->findChild<QTreeView*>(QStringLiteral("pagesView"));
```

#### LAMBDA EXPRESSION 


```{c}
[](const Domain::Task::Ptr &task, int role, const AdditionalInfo &projectQueryResult) -> QVariant {
        switch (role) {
        case Qt::DisplayRole:
        case Qt::EditRole:
            return task->title();
        case Qt::CheckStateRole:
            return task->isDone() ? Qt::Checked : Qt::Unchecked;
        case Presentation::QueryTreeModelBase::AdditionalInfoRole:
            if (projectQueryResult && !projectQueryResult->data().isEmpty()) {
                Domain::Project::Ptr project = projectQueryResult->data().at(0);
                return i18n("Project: %1", project->name());
            }
            return i18n("Inbox"); // TODO add source name
        default:
            break;
        }
        return QVariant();
    }
```

#### AUTO 


```{c}
auto fetch = m_helpers->fetchSiblings(item);
```

#### AUTO 


```{c}
auto mimeTypes = collection.contentMimeTypes().toSet();
```

#### LAMBDA EXPRESSION 


```{c}
[] (const Domain::DataSource::Ptr &source, int role) -> QVariant {
        if (role != Qt::DisplayRole
         && role != Qt::EditRole
         && role != Qt::DecorationRole
         && role != QueryTreeModelBase::IconNameRole) {
            return QVariant();
        }

        if (role == Qt::DisplayRole || role == Qt::EditRole) {
            return source->name();
        } else if (role == Qt::DecorationRole || role == QueryTreeModelBase::IconNameRole) {
            const QString iconName = source->iconName().isEmpty() ? "folder" : source->iconName();

            if (role == Qt::DecorationRole)
                return QVariant::fromValue(QIcon::fromTheme(iconName));
            else
                return iconName;
        } else {
            return QVariant();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Domain::Artifact::Ptr &artifact) -> Domain::QueryResultInterface<Domain::Artifact::Ptr>::Ptr {
        if (!artifact)
            return Domain::QueryResult<Domain::Task::Ptr, Domain::Artifact::Ptr>::copy(taskQueries()->findWorkdayTopLevel());
        else if (auto task = artifact.dynamicCast<Domain::Task>())
            return Domain::QueryResult<Domain::Task::Ptr, Domain::Artifact::Ptr>::copy(taskQueries()->findChildren(task));
        else
            return Domain::QueryResult<Domain::Artifact::Ptr>::Ptr();
    }
```

#### AUTO 


```{c}
auto pageListModel = availablePages->property("pageListModel").value<QAbstractItemModel*>();
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QMimeData *mimeData, Qt::DropAction, const Domain::Task::Ptr &parentTask) {
        if (!mimeData->hasFormat(QStringLiteral("application/x-zanshin-object")))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                        [](const Domain::Artifact::Ptr &droppedArtifact) {
                            return !droppedArtifact.objectCast<Domain::Task>();
                        })) {
            return false;
        }

        using namespace std::placeholders;
        auto associate = std::function<KJob*(Domain::Task::Ptr)>();
        auto parentTitle = QString();

        if (parentTask) {
            associate = std::bind(&Domain::TaskRepository::associate, m_taskRepository, parentTask, _1);
            parentTitle = parentTask->title();
        } else {
            associate = std::bind(&Domain::ProjectRepository::associate, m_projectRepository, m_project, _1);
            parentTitle = m_project->name();
        }

        foreach(const Domain::Artifact::Ptr &droppedArtifact, droppedArtifacts) {
            auto childTask = droppedArtifact.objectCast<Domain::Task>();
            const auto job = associate(childTask);
            installHandler(job, tr("Cannot move task %1 as a sub-task of %2").arg(childTask->title(), parentTitle));
        }

        return true;
    }
```

#### AUTO 


```{c}
auto displayedModel = filterWidget->proxyModel();
```

#### AUTO 


```{c}
auto resultChild = queries->findChildren(result->data().at(1));
```

#### AUTO 


```{c}
auto availableSource = static_cast<Presentation::AvailableSourcesModel*>(app.availableSources());
```

#### LAMBDA EXPRESSION 


```{c}
[](const Domain::Task::Ptr &task) {
        const Qt::ItemFlags defaultFlags = Qt::ItemIsSelectable
                                         | Qt::ItemIsEnabled
                                         | Qt::ItemIsEditable
                                         | Qt::ItemIsDragEnabled;

        return task ? (defaultFlags | Qt::ItemIsUserCheckable | Qt::ItemIsDropEnabled) : defaultFlags;
    }
```

#### AUTO 


```{c}
auto todo = item1.payload<KCalCore::Todo::Ptr>();
```

#### LAMBDA EXPRESSION 


```{c}
[] (QWidget *parent) {
        return NameAndDataSourceDialogPtr(new NameAndDataSourceDialog(parent));
    }
```

#### AUTO 


```{c}
const auto textRect = style->subElementRect(QStyle::SE_ItemViewItemText, &opt, widget)
                             .adjusted(textMargin, 0, - textMargin, 0);
```

#### AUTO 


```{c}
auto cache = Akonadi::Cache::Ptr::create(serializer, monitor);
```

#### AUTO 


```{c}
auto setData = [this](const Domain::Artifact::Ptr &artifact, const QVariant &value, int role) {
        if (role != Qt::EditRole && role != Qt::CheckStateRole) {
            return false;
        }

        if (auto task = artifact.dynamicCast<Domain::Task>()) {
            if (role == Qt::EditRole)
                task->setTitle(value.toString());
            else
                task->setDone(value.toInt() == Qt::Checked);

            m_taskRepository->save(task);
            return true;

        } else if (auto note = artifact.dynamicCast<Domain::Note>()) {
            if (role != Qt::EditRole)
                return false;

            note->setTitle(value.toString());
            m_noteRepository->save(note);
            return true;

        }

        return false;
    };
```

#### AUTO 


```{c}
auto flags = [] (const Domain::DataSource::Ptr &source) -> Qt::ItemFlags {
        const Qt::ItemFlags defaultFlags = Qt::ItemIsSelectable
                                         | Qt::ItemIsEnabled;
        if (source->contentTypes() != Domain::DataSource::NoContent)
            return defaultFlags | Qt::ItemIsUserCheckable;
        else
            return defaultFlags;
    };
```

#### AUTO 


```{c}
auto fetch = fetchCollectionsFunction(storage);
```

#### AUTO 


```{c}
auto result = queries->findTopLevelArtifacts(tag);
```

#### LAMBDA EXPRESSION 


```{c}
[] (const QList<QColor> &) -> QMimeData* {
            return Q_NULLPTR;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const TagQuery::AddFunction &add) {
            TagFetchJobInterface *job = m_storage->fetchTags();
            Utils::JobHandler::install(job->kjob(), [this, job, add] {
                for (Akonadi::Tag tag : job->tags())
                    add(tag);
            });
        }
```

#### LAMBDA EXPRESSION 


```{c}
[fetchJob, job, this] {
        if (fetchJob->kjob()->error() != KJob::NoError)
           return;

        Q_ASSERT(fetchJob->items().size() == 1);
        auto item = fetchJob->items().first();
        m_serializer->promoteItemToProject(item);

        auto updateJob = m_storage->updateItem(item);
        job->addSubjob(updateJob);
        updateJob->start();
    }
```

#### AUTO 


```{c}
const auto job = m_saveFunction(m_task);
```

#### AUTO 


```{c}
auto project1 = Domain::Project::Ptr::create();
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QObjectPtr &object) {
        const Qt::ItemFlags defaultFlags = Qt::ItemIsSelectable
                                         | Qt::ItemIsEnabled
                                         | Qt::ItemIsEditable
                                         | Qt::ItemIsDropEnabled;
        const Qt::ItemFlags immutableNodeFlags = Qt::ItemIsSelectable
                                               | Qt::ItemIsEnabled
                                               | Qt::ItemIsDropEnabled;
        const Qt::ItemFlags structureNodeFlags = Qt::NoItemFlags;

        return object.objectCast<Domain::Project>() ? defaultFlags
             : object.objectCast<Domain::Context>() ? defaultFlags
             : object == m_inboxObject ? immutableNodeFlags
             : object == m_workdayObject ? immutableNodeFlags
             : structureNodeFlags;
    }
```

#### AUTO 


```{c}
auto queryGenerator = [&] (const QColor &) {
            return Domain::QueryResult<QColor>::Ptr();
        };
```

#### LAMBDA EXPRESSION 


```{c}
[] (const Akonadi::Tag &tag) {
            return tag.name().endsWith(QLatin1String("-in"));
        }
```

#### AUTO 


```{c}
auto query = [this] (const Domain::Task::Ptr &task) -> Domain::QueryResultInterface<Domain::Task::Ptr>::Ptr {
        if (!task)
            return m_contextQueries->findTopLevelTasks(m_context); //FIXME : for now returns all tasks associated, not only top level ones
        else
            return Domain::QueryResult<Domain::Task::Ptr>::Ptr();
    };
```

#### AUTO 


```{c}
const auto startDate = task ? task->startDate() : QDate();
```

#### AUTO 


```{c}
auto source2Result = Domain::QueryResult<Domain::DataSource::Ptr>::create(source2Provider);
```

#### AUTO 


```{c}
auto dataFunction = [] (const QColor &, int, int) {
            return QVariant();
        };
```

#### AUTO 


```{c}
auto drop = [this](const QMimeData *mimeData, Qt::DropAction, const Domain::Task::Ptr &parentTask) {
        if (!mimeData->hasFormat(QStringLiteral("application/x-zanshin-object")))
            return false;

        auto droppedTasks = mimeData->property("objects").value<Domain::Task::List>();
        if (droppedTasks.isEmpty())
            return false;

        using namespace std::placeholders;
        auto associate = std::function<KJob*(Domain::Task::Ptr)>();
        auto parentTitle = QString();

        if (parentTask) {
            associate = std::bind(&Domain::TaskRepository::associate, m_taskRepository, parentTask, _1);
            parentTitle = parentTask->title();
        } else {
            associate = std::bind(&Domain::ProjectRepository::associate, m_projectRepository, m_project, _1);
            parentTitle = m_project->name();
        }

        foreach(const Domain::Task::Ptr &childTask, droppedTasks) {
            const auto job = associate(childTask);
            installHandler(job, i18n("Cannot move task %1 as a sub-task of %2", childTask->title(), parentTitle));
        }

        return true;
    };
```

#### AUTO 


```{c}
auto it = std::find_if(collections.constBegin(), collections.constEnd(),
                                   [] (const Akonadi::Collection &c) {
                return (c.rights() & Akonadi::Collection::CanCreateItem)
                    && (c.rights() & Akonadi::Collection::CanChangeItem)
                    && (c.rights() & Akonadi::Collection::CanDeleteItem);
            });
```

#### AUTO 


```{c}
auto fetch = [storage, collection] (const Domain::LiveQueryInput<Akonadi::Item>::AddFunction &add) {
            auto job = storage->fetchItems(collection, nullptr);
            Utils::JobHandler::install(job->kjob(), [add, job] {
                foreach (const auto &item, job->items()) {
                    add(item);
                }
            });
        };
```

#### AUTO 


```{c}
auto query = new Domain::LiveRelationshipQuery<QObject*, QPair<int, QString>>;
```

#### AUTO 


```{c}
auto job = storage.fetchCollections(Akonadi::Collection::root(), Akonadi::Storage::Recursive);
```

#### AUTO 


```{c}
auto doneAction = page.findChild<QAction*>(QStringLiteral("doneViewAction"));
```

#### AUTO 


```{c}
auto result = query->result();
```

#### LAMBDA EXPRESSION 


```{c}
[] (const Domain::DataSource::Ptr &, const QVariant &, int) {
              return false;
          }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &item : items) {
        itemRemoteIds << item.remoteId();
        QVERIFY(item.loadedPayloadParts().contains(Akonadi::Item::FullPayload));
        QVERIFY(!item.attributes().isEmpty());
        QVERIFY(item.modificationTime().isValid());
        QVERIFY(!item.flags().isEmpty());

        Akonadi::Tag::List tags = item.tags();
        QVERIFY(!item.tags().isEmpty());
        for (const auto &tag : tags) {
            QVERIFY(tag.isValid());
            QVERIFY(!tag.name().isEmpty());
            QVERIFY(!tag.type().isEmpty());
        }

        auto parent = item.parentCollection();
        while (parent != Akonadi::Collection::root()) {
            QVERIFY(parent.isValid());
            parent = parent.parentCollection();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[] (const Akonadi::Collection &c) {
                return (c.rights() & Akonadi::Collection::CanCreateItem)
                    && (c.rights() & Akonadi::Collection::CanChangeItem)
                    && (c.rights() & Akonadi::Collection::CanDeleteItem);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[](const Domain::Task::Ptr &task, int role) -> QVariant {
            if (role != Qt::DisplayRole && role != Qt::CheckStateRole) {
                return QVariant();
            }

            if (role == Qt::DisplayRole)
                return task->title();
            else
                return task->isDone() ? Qt::Checked : Qt::Unchecked;
        }
```

#### AUTO 


```{c}
const auto ids = m_tagItems[tag.id()];
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &item : items) {
            itemRemoteIds << item.remoteId();
            QVERIFY(item.loadedPayloadParts().contains(Akonadi::Item::FullPayload));
            QVERIFY(!item.attributes().isEmpty());
            QVERIFY(item.modificationTime().isValid());
            QVERIFY(!item.flags().isEmpty());

            auto parent = item.parentCollection();
            while (parent != Akonadi::Collection::root()) {
                QVERIFY(parent.isValid());
                parent = parent.parentCollection();
            }
        }
```

#### AUTO 


```{c}
auto actions = components->globalActions();
```

#### AUTO 


```{c}
auto removeJob = m_storage->removeItems(childItems);
```

#### AUTO 


```{c}
auto flags = [this](const QObjectPtr &object) {
        const Qt::ItemFlags defaultFlags = Qt::ItemIsSelectable
                                         | Qt::ItemIsEnabled
                                         | Qt::ItemIsEditable
                                         | Qt::ItemIsDropEnabled;
        const Qt::ItemFlags immutableNodeFlags = Qt::ItemIsSelectable
                                               | Qt::ItemIsEnabled
                                               | Qt::ItemIsDropEnabled;
        const Qt::ItemFlags nonDroppableNodeFlags = Qt::ItemIsSelectable
                                                  | Qt::ItemIsEnabled;
        const Qt::ItemFlags structureNodeFlags = Qt::NoItemFlags;

        return object.objectCast<Domain::Project>() ? defaultFlags
             : object.objectCast<Domain::Context>() ? defaultFlags
             : object == m_inboxObject ? immutableNodeFlags
             : object == m_workdayObject ? immutableNodeFlags
             : object == m_allTasksObject ? nonDroppableNodeFlags
             : structureNodeFlags;
    };
```

#### AUTO 


```{c}
auto task = inbox.addItem(title).objectCast<Domain::Task>();
```

#### AUTO 


```{c}
auto expectedText = i18n("Delegated to: <b>%1</b>", model.property("delegateText").toString());
```

#### LAMBDA EXPRESSION 


```{c}
[configGroup] (bool checked) mutable {
                configGroup.writeEntry("ShowFuture", checked);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Domain::Task::Ptr &, int index) {
                                        Node *node = m_rootNodes.at(index);
                                        m_rootNodes.removeAt(index);
                                        delete node;
                                        endRemoveRows();
                                    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Domain::Task::Ptr &, int idx) {
                                         emit dataChanged(index(idx), index(idx));
                                     }
```

#### AUTO 


```{c}
const auto childTaskIndex = page.centralListModel()->index(0, 0, taskIndex);
```

#### AUTO 


```{c}
auto c1 = Akonadi::Collection(43);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : items) {
            auto todo = item.payload<KCalCore::Todo::Ptr>();
            itemHash.insert(todo->uid(), item);
        }
```

#### AUTO 


```{c}
auto drop = [](const QMimeData *, Qt::DropAction, const Domain::Artifact::Ptr &) {
        return false;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this](const ItemType &, int index) {
            QModelIndex parentIndex = parent() ? createIndex(row(), 0, this) : QModelIndex();
            beginInsertRows(parentIndex, index, index);
        }
```

#### AUTO 


```{c}
auto job = storage->fetchItem(findItem, nullptr);
```

#### LAMBDA EXPRESSION 


```{c}
[](const QColor &, const QVariant &, int) {
            return false;
        }
```

#### AUTO 


```{c}
auto relatedHeader2 = new KMime::Headers::Generic("X-Zanshin-RelatedProjectUid");
```

#### AUTO 


```{c}
auto notifiedItem = spy.takeFirst().at(0).value<Akonadi::Item>();
```

#### LAMBDA EXPRESSION 


```{c}
[fetchParentItemJob, child, childItem, job, this] {
            if (fetchParentItemJob->kjob()->error() != KJob::NoError)
                return;

            Q_ASSERT(fetchParentItemJob->items().size() == 1);
            auto parentItem = fetchParentItemJob->items().at(0);

            const int itemCollectionId = childItem.parentCollection().id();
            const int parentCollectionId = parentItem.parentCollection().id();

            if (itemCollectionId != parentCollectionId) {
                ItemFetchJobInterface *fetchChildrenItemJob = m_storage->fetchItems(childItem.parentCollection(), this);
                job->install(fetchChildrenItemJob->kjob(), [fetchChildrenItemJob, childItem, parentItem, job, this] {
                    if (fetchChildrenItemJob->kjob()->error() != KJob::NoError)
                        return;

                    Item::List childItems = m_serializer->filterDescendantItems(fetchChildrenItemJob->items(), childItem);

                    auto transaction = m_storage->createTransaction();
                    m_storage->updateItem(childItem, transaction);
                    childItems.push_front(childItem);
                    m_storage->moveItems(childItems, parentItem.parentCollection(), transaction);
                    job->addSubjob(transaction);
                    transaction->start();
                });
            } else {
                auto updateJob = m_storage->updateItem(childItem);
                job->addSubjob(updateJob);
                updateJob->start();
            }
        }
```

#### AUTO 


```{c}
auto collectionsByDepth = doc.collections();
```

#### AUTO 


```{c}
auto model = Utils::DependencyManager::globalInstance().create<AvailablePagesModelInterface>();
```

#### LAMBDA EXPRESSION 


```{c}
[child, parent, fetchParentItemJob, partialParentItem, childItem, job, this] {
            if (fetchParentItemJob->kjob()->error() != KJob::NoError)
                return;

            const auto items = fetchParentItemJob->items();
            const auto parentIndex = items.indexOf(partialParentItem);
            Q_ASSERT(parentIndex >= 0);
            const auto parentItem = items.at(parentIndex);

            // TODO Qt5: This is a bit wasteful, add an itemUid on the serializer
            const auto childUid = m_serializer->objectUid(m_serializer->createTaskFromItem(childItem));
            auto relatedUid = m_serializer->relatedUidFromItem(parentItem);
            while (!relatedUid.isEmpty()) {
                if (relatedUid == childUid) {
                    job->emitError(tr("Could not associate '%1', it is an ancestor of '%2'")
                                   .arg(child->title(), parent->title()));
                    return;
                }

                auto it = std::find_if(items.constBegin(), items.constEnd(),
                                       [relatedUid, this] (const Akonadi::Item &item) {
                    // TODO Qt5: This is a bit wasteful, add an itemUid on the serializer
                    auto task = m_serializer->createTaskFromItem(item);
                    return task && m_serializer->objectUid(task) == relatedUid;
                });
                if (it == items.end())
                    break;

                relatedUid = m_serializer->relatedUidFromItem(*it);
            }

            const int itemCollectionId = childItem.parentCollection().id();
            const int parentCollectionId = parentItem.parentCollection().id();

            if (itemCollectionId != parentCollectionId) {
                ItemFetchJobInterface *fetchChildrenItemJob = m_storage->fetchItems(childItem.parentCollection());
                job->install(fetchChildrenItemJob->kjob(), [fetchChildrenItemJob, childItem, parentItem, job, this] {
                    if (fetchChildrenItemJob->kjob()->error() != KJob::NoError)
                        return;

                    Item::List childItems = m_serializer->filterDescendantItems(fetchChildrenItemJob->items(), childItem);

                    auto transaction = m_storage->createTransaction();
                    m_storage->updateItem(childItem, transaction);
                    childItems.push_front(childItem);
                    m_storage->moveItems(childItems, parentItem.parentCollection(), transaction);
                    job->addSubjob(transaction);
                    transaction->start();
                });
            } else {
                auto updateJob = m_storage->updateItem(childItem);
                job->addSubjob(updateJob);
                updateJob->start();
            }
        }
```

#### AUTO 


```{c}
auto sourcesView = available.findChild<QTreeView*>("sourcesView");
```

#### AUTO 


```{c}
auto collection
```

#### AUTO 


```{c}
auto setData = [this](const Domain::Artifact::Ptr &artifact, const QVariant &value, int role) {
        if (role != Qt::EditRole && role != Qt::CheckStateRole) {
            return false;
        }

        if (auto task = artifact.dynamicCast<Domain::Task>()) {
            const auto currentTitle = task->title();
            if (role == Qt::EditRole)
                task->setTitle(value.toString());
            else
                task->setDone(value.toInt() == Qt::Checked);

            const auto job = taskRepository()->update(task);
            installHandler(job, tr("Cannot modify task %1 in project %2").arg(currentTitle).arg(m_project->name()));
            return true;

        } else if (auto note = artifact.dynamicCast<Domain::Note>()) {
            if (role != Qt::EditRole)
                return false;

            const auto currentTitle = note->title();
            note->setTitle(value.toString());
            const auto job = noteRepository()->save(note);
            installHandler(job, tr("Cannot modify note %1 in project %2").arg(currentTitle).arg(m_project->name()));
            return true;

        }

        return false;
    };
```

#### AUTO 


```{c}
auto job = storage->fetchCollections(item.parentCollection(), StorageInterface::Base, parent);
```

#### AUTO 


```{c}
auto item = m_serializer->createItemFromContext(context);
```

#### LAMBDA EXPRESSION 


```{c}
[storage, job, add] {
            if (job->kjob()->error() != KJob::NoError)
                return;
            auto collection = job->collections().at(0);
            add(collection);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (Akonadi::Item::Id id) {
                       Q_ASSERT(m_items.contains(id));
                       return m_items.value(id);
                   }
```

#### AUTO 


```{c}
auto drop = [this] (const QMimeData *, Qt::DropAction, const Domain::Note::Ptr &) {
        return false;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[&](const Domain::Task::Ptr &task) {
        if (!task)
            return queries->findTopLevel();
        else
            return queries->findChildren(task);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Domain::Note::Ptr &note, const QVariant &value, int role) {
        if (role != Qt::EditRole) {
            return false;
        }

        const auto currentTitle = note->title();
        note->setTitle(value.toString());
        const auto job = m_noteRepository->update(note);
        installHandler(job, i18n("Cannot modify note %1 in Inbox", currentTitle));
        return true;
    }
```

#### AUTO 


```{c}
const auto collectionCachedNames = [cache, toCollectionNames]{
                const auto collections = cache->collections(Akonadi::StorageInterface::AllContent);
                return toCollectionNames(collections);
            }();
```

#### LAMBDA EXPRESSION 


```{c}
[](const QColor &, int, int) {
            return QVariant();
        }
```

#### AUTO 


```{c}
auto job = storage.fetchItems(Akonadi::Collection(42));
```

#### AUTO 


```{c}
auto object1 = deps.create<Interface0>();
```

#### AUTO 


```{c}
auto childTask3 = Domain::Task::Ptr::create();
```

#### AUTO 


```{c}
auto availablePages = static_cast<Presentation::AvailablePagesModel*>(app.availablePages());
```

#### AUTO 


```{c}
auto it = m_collectionItems.find(oldItem.parentCollection().id());
```

#### AUTO 


```{c}
const auto behavior = m_data->storageBehavior().fetchCollectionsBehavior(collection.id());
```

#### LAMBDA EXPRESSION 


```{c}
[] (const Domain::DataSource::Ptr &source) -> Qt::ItemFlags {
        const Qt::ItemFlags defaultFlags = Qt::ItemIsSelectable
                                         | Qt::ItemIsEnabled;
        if (source->contentTypes() != Domain::DataSource::NoContent)
            return defaultFlags | Qt::ItemIsUserCheckable;
        else
            return defaultFlags;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[job, add] {
            if (job->kjob()->error())
                return;

            foreach (const auto &collection, job->collections())
                add(collection);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QMimeData *mimeData, Qt::DropAction, const QObjectPtr &object) {
        if (!mimeData->hasFormat("application/x-zanshin-object"))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (auto project = object.objectCast<Domain::Project>()) {
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                const auto job = m_projectRepository->associate(project, droppedArtifact);
                if (!errorHandler())
                    continue;

                errorHandler()->installHandler(job, tr("Cannot add %1 to project %2").arg(droppedArtifact->title()).arg(project->name()));
            }
            return true;
        } else if (auto context = object.objectCast<Domain::Context>()) {
            if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                            [](const Domain::Artifact::Ptr &droppedArtifact) {
                                return !droppedArtifact.objectCast<Domain::Task>();
                            })) {
                return false;
            }
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                auto task = droppedArtifact.staticCast<Domain::Task>();
                const auto job = m_contextRepository->associate(context, task);
                if (!errorHandler())
                    continue;

                errorHandler()->installHandler(job, tr("Cannot add %1 to context %2").arg(task->title()).arg(context->name()));
            }
            return true;
        } else if (auto tag = object.objectCast<Domain::Tag>()) {
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                const auto job = m_tagRepository->associate(tag, droppedArtifact);
                if (!errorHandler())
                    continue;

                errorHandler()->installHandler(job, tr("Cannot tag %1 with %2").arg(droppedArtifact->title()).arg(tag->name()));
            }
            return true;
        } else if (object == m_inboxObject) {
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                const auto job = m_projectRepository->dissociate(droppedArtifact);
                if (errorHandler())
                    errorHandler()->installHandler(job, tr("Cannot move %1 to Inbox").arg(droppedArtifact->title()));

                if (auto task = droppedArtifact.objectCast<Domain::Task>()) {
                    Utils::JobHandler::install(job, [this, task] {
                        const auto dissociateJob = m_taskRepository->dissociate(task);
                        if (errorHandler())
                            errorHandler()->installHandler(dissociateJob, tr("Cannot move task %1 to Inbox").arg(task->title()));
                    });
                }
            }
            return true;
        }

        return false;
    }
```

#### AUTO 


```{c}
auto sourceCombo = dialog.findChild<QComboBox*>("sourceCombo");
```

#### AUTO 


```{c}
const auto isEditing = (opt.state & QStyle::State_Editing);
```

#### AUTO 


```{c}
auto attendee = todo->attendeeByMail(delegate.email());
```

#### AUTO 


```{c}
auto item = Akonadi::Item(43);
```

#### AUTO 


```{c}
auto task = m_model->property("task").value<Domain::Task::Ptr>();
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Akonadi::Item &item) {
            if (!m_serializer->isTaskItem(item))
                return false;

            const Domain::Task::Ptr task = m_serializer->createTaskFromItem(item);
            const QDateTime startDate = task->startDate();
            const QDateTime dueDate = task->dueDate();
            const QDateTime today = QDateTime::currentDateTime();

            const bool pastStartDate = startDate.isValid() && startDate <= today;
            const bool pastDueDate = dueDate.isValid() && dueDate <= today;

            return ((pastStartDate || pastDueDate) && !task->isDone());
        }
```

#### LAMBDA EXPRESSION 


```{c}
[akonadiTag, fetchItemJob, parent, job, this] {
        if (fetchItemJob->kjob()->error() != KJob::NoError)
            return;

        Q_ASSERT(fetchItemJob->items().size() == 1);
        auto childItem = fetchItemJob->items().at(0);
        childItem.setTag(akonadiTag);

        auto updateJob = m_storage->updateItem(childItem);
        job->addSubjob(updateJob);
        updateJob->start();
    }
```

#### AUTO 


```{c}
auto expectedText = i18n("Delegated to: <b>%1</b>", QStringLiteral("John Doe"));
```

#### AUTO 


```{c}
const auto rowCount = m_sourceListModel->rowCount(root);
```

#### AUTO 


```{c}
auto model = QObjectPtr::create();
```

#### LAMBDA EXPRESSION 


```{c}
[fetchItemJob, parent, job, this] {
        if (fetchItemJob->kjob()->error() != KJob::NoError)
           return;

        Q_ASSERT(fetchItemJob->items().size() == 1);
        auto childItem = fetchItemJob->items().first();
        m_serializer->updateItemParent(childItem, parent);

        // Check collections to know if we need to move child
        auto parentItem = m_serializer->createItemFromTask(parent);
        ItemFetchJobInterface *fetchParentItemJob = m_storage->fetchItem(parentItem);
        job->install(fetchParentItemJob->kjob(), [fetchParentItemJob, childItem, job, this] {
            if (fetchParentItemJob->kjob()->error() != KJob::NoError)
                return;

            Q_ASSERT(fetchParentItemJob->items().size() == 1);
            auto parentItem = fetchParentItemJob->items().first();

            const int itemCollectionId = childItem.parentCollection().id();
            const int parentCollectionId = parentItem.parentCollection().id();

            if (itemCollectionId != parentCollectionId) {
                ItemFetchJobInterface *fetchChildrenItemJob = m_storage->fetchItems(childItem.parentCollection());
                job->install(fetchChildrenItemJob->kjob(), [fetchChildrenItemJob, childItem, parentItem, job, this] {
                    if (fetchChildrenItemJob->kjob()->error() != KJob::NoError)
                        return;

                    Item::List childItems = m_serializer->filterDescendantItems(fetchChildrenItemJob->items(), childItem);

                    auto transaction = m_storage->createTransaction();
                    m_storage->updateItem(childItem, transaction);
                    childItems.push_front(childItem);
                    m_storage->moveItems(childItems, parentItem.parentCollection(), transaction);
                    job->addSubjob(transaction);
                    transaction->start();
                });
            } else {
                auto updateJob = m_storage->updateItem(childItem);
                job->addSubjob(updateJob);
                updateJob->start();
            }
        });
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Domain::LiveRelationshipQuery<QObject*, QString>::AddFunction &add) {
            Utils::JobHandler::install(new FakeJob, [this, add] {});
        }
```

#### AUTO 


```{c}
auto job = storage->createCollection(collection);
```

#### AUTO 


```{c}
auto goNextAction = new QAction(this);
```

#### AUTO 


```{c}
const auto task = index.data(QueryTreeModelBase::ObjectRole).value<Domain::Task::Ptr>();
```

#### AUTO 


```{c}
auto quickAddEdit = page.findChild<QLineEdit*>(QStringLiteral("quickAddEdit"));
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QObjectPtr &object) -> Domain::QueryResultInterface<QObjectPtr>::Ptr {
        if (!object)
            return Domain::QueryResult<QObjectPtr>::create(m_rootsProvider);
        else if (object == m_projectsObject)
            return Domain::QueryResult<Domain::Project::Ptr, QObjectPtr>::copy(m_projectQueries->findAll());
        else
            return Domain::QueryResult<QObjectPtr>::Ptr();
    }
```

#### AUTO 


```{c}
const auto collection1 = Akonadi::Collection(GenCollection().withRootAsParent()
                                                                    .withId(1)
                                                                    .withName("tasks1")
                                                                    .withTaskContent());
```

#### AUTO 


```{c}
auto droppedTasks = mimeData->property("objects").value<Domain::Task::List>();
```

#### AUTO 


```{c}
auto query = ContextQuery::Ptr::create();
```

#### AUTO 


```{c}
auto fetchCollectionsFunction(Akonadi::StorageInterface::Ptr storage) {
        return [storage] (const Domain::LiveQueryInput<Akonadi::Collection>::AddFunction &add) {
            auto job = storage->fetchCollections(Akonadi::Collection::root(), Akonadi::Storage::Recursive);
            Utils::JobHandler::install(job->kjob(), [add, job] {
                foreach (const auto &col, job->collections()) {
                    add(col);
                }
            });
        };
    }
```

#### AUTO 


```{c}
auto task4 = model->data(model->index(2, 0), Presentation::QueryTreeModelBase::ObjectRole).value<Domain::Task::Ptr>();
```

#### LAMBDA EXPRESSION 


```{c}
[this, job, add] {
                if (job->kjob()->error())
                    return;

                QHash<Collection::Id, Collection> topLevels;
                foreach (const auto &collection, job->collections()) {
                    auto topLevel = collection;
                    while (topLevel.parentCollection() != Collection::root())
                        topLevel = topLevel.parentCollection();
                    if (!topLevels.contains(topLevel.id()))
                        topLevels[topLevel.id()] = topLevel;
                }

                foreach (const auto &topLevel, topLevels.values())
                    add(topLevel);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Akonadi::Item &item, const Domain::Note::Ptr &note) {
            return m_serializer->representsItem(note, item);
        }
```

#### AUTO 


```{c}
auto pageView = ApplicationComponents::pageView();
```

#### AUTO 


```{c}
auto availablePageView = components.availablePagesView();
```

#### AUTO 


```{c}
auto job = new CollectionJob(collection, jobTypeFromDepth(depth));
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QMimeData *mimeData, Qt::DropAction, const Domain::Artifact::Ptr &artifact) {
        auto parentTask = artifact.objectCast<Domain::Task>();

        if (!mimeData->hasFormat("application/x-zanshin-object"))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                        [](const Domain::Artifact::Ptr &droppedArtifact) {
                            return !droppedArtifact.objectCast<Domain::Task>();
                        })) {
            return false;
        }

        foreach(const auto &droppedArtifact, droppedArtifacts) {
            auto childTask = droppedArtifact.objectCast<Domain::Task>();

            if (!childTask)
                return false;

            childTask->setStartDate(Utils::DateTime::currentDateTime());
            const auto job = taskRepository()->update(childTask);
            installHandler(job, tr("Cannot update task %1 to Workday").arg(childTask->title()));

            if (parentTask) {
                const auto job = taskRepository()->associate(parentTask, childTask);
                installHandler(job, tr("Cannot move task %1 as sub-task of %2").arg(childTask->title()).arg(parentTask->title()));
            } else {
                const auto job = taskRepository()->dissociate(childTask);
                installHandler(job, tr("Cannot deparent task %1 from its parent").arg(childTask->title()));
            }
        }

        return true;
    }
```

#### AUTO 


```{c}
auto save = [this, &savedTask] (const Domain::Task::Ptr &task) {
            savedTask = task;
            auto job = new FakeJob(this);
            job->setExpectedError(KJob::KilledJobError, QStringLiteral("Foo"));
            return job;
        };
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Akonadi::Item &item) {
        if (!m_serializer->isTaskItem(item))
            return false;

        const Domain::Task::Ptr task = m_serializer->createTaskFromItem(item);

        const QDate doneDate = task->doneDate();
        const QDate startDate = task->startDate();
        const QDate dueDate = task->dueDate();
        const QDate today = Utils::DateTime::currentDate();

        const bool pastStartDate = startDate.isValid() && startDate <= today;
        const bool pastDueDate = dueDate.isValid() && dueDate <= today;
        const bool todayDoneDate = doneDate == today;

        if (task->isDone())
            return todayDoneDate;
        else
            return pastStartDate || pastDueDate;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&replaceHandlerCalled](const Domain::Task::Ptr &, int) {
                                          replaceHandlerCalled = true;
                                      }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QObjectPtr &object, int role) -> QVariant {
        if (role != Qt::DisplayRole
         && role != Qt::EditRole
         && role != Qt::DecorationRole
         && role != QueryTreeModelBase::IconNameRole) {
            return QVariant();
        }

        if (role == Qt::EditRole
         && (object == m_inboxObject
          || object == m_workdayObject
          || object == m_projectsObject
          || object == m_contextsObject
          || object.objectCast<Domain::DataSource>())) {
            return QVariant();
        }

        if (role == Qt::DisplayRole || role == Qt::EditRole) {
            return object->property("name").toString();
        } else if (role == Qt::DecorationRole || role == QueryTreeModelBase::IconNameRole) {
            const QString iconName = object == m_inboxObject ? QStringLiteral("mail-folder-inbox")
                                   : (object == m_workdayObject)  ? QStringLiteral("go-jump-today")
                                   : (object == m_projectsObject) ? QStringLiteral("folder")
                                   : (object == m_contextsObject) ? QStringLiteral("folder")
                                   : object.objectCast<Domain::DataSource>() ? QStringLiteral("folder")
                                   : object.objectCast<Domain::Context>() ? QStringLiteral("view-pim-notes")
                                   : QStringLiteral("view-pim-tasks");

            if (role == Qt::DecorationRole)
                return QVariant::fromValue(QIcon::fromTheme(iconName));
            else
                return iconName;
        } else {
            return QVariant();
        }
    }
```

#### AUTO 


```{c}
const auto isActive = (opt.state & QStyle::State_Active);
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
            callCount++;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[] (const QStringList &strings) -> QMimeData* {
            auto data = new QMimeData;
            data->setData(QStringLiteral("application/x-zanshin-object"), "object");
            data->setProperty("objects", QVariant::fromValue(strings));
            return data;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto item : job->items()) {
                    if (m_serializer->isProjectChild(project, item)) {
                        auto artifact = deserializeArtifact(item);
                        if (artifact)
                            provider->append(artifact);
                    }
                }
```

#### LAMBDA EXPRESSION 


```{c}
[] (Utils::DependencyManager *deps) {
        return new Akonadi::DataSourceRepository(Akonadi::StorageInterface::Notes,
                                                 deps->create<Akonadi::StorageInterface>(),
                                                 deps->create<Akonadi::SerializerInterface>());
    }
```

#### AUTO 


```{c}
const auto task = taskForIndex(index);
```

#### AUTO 


```{c}
auto goToAction = available.findChild<QAction*>(QStringLiteral("goToAction"));
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QObjectPtr &object, int role, int) -> QVariant {
        if (role != Qt::DisplayRole
         && role != Qt::EditRole
         && role != Qt::DecorationRole
         && role != QueryTreeModelBase::IconNameRole) {
            return QVariant();
        }

        if (role == Qt::EditRole
         && (object == m_inboxObject
          || object == m_workdayObject
          || object == m_projectsObject
          || object == m_contextsObject
          || object.objectCast<Domain::DataSource>())) {
            return QVariant();
        }

        if (role == Qt::DisplayRole || role == Qt::EditRole) {
            return object->property("name").toString();
        } else if (role == Qt::DecorationRole || role == QueryTreeModelBase::IconNameRole) {
            const QString iconName = object == m_inboxObject ? QStringLiteral("mail-folder-inbox")
                                   : (object == m_workdayObject)  ? QStringLiteral("go-jump-today")
                                   : (object == m_projectsObject) ? QStringLiteral("folder")
                                   : (object == m_contextsObject) ? QStringLiteral("folder")
                                   : object.objectCast<Domain::DataSource>() ? QStringLiteral("folder")
                                   : object.objectCast<Domain::Context>() ? QStringLiteral("view-pim-notes")
                                   : QStringLiteral("view-pim-tasks");

            if (role == Qt::DecorationRole)
                return QVariant::fromValue(QIcon::fromTheme(iconName));
            else
                return iconName;
        } else {
            return QVariant();
        }
    }
```

#### AUTO 


```{c}
auto notifiedItem = spyItemChanged.takeFirst().takeFirst().value<Akonadi::Item>();
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const QMimeData *mimeData, Qt::DropAction, const Domain::Task::Ptr &parentTask) {
        if (!mimeData->hasFormat(QStringLiteral("application/x-zanshin-object")))
            return false;

        auto droppedTasks = mimeData->property("objects").value<Domain::Task::List>();
        if (droppedTasks.isEmpty())
            return false;

        using namespace std::placeholders;
        auto associate = std::function<KJob*(Domain::Task::Ptr)>();
        auto dissociate = std::function<KJob*(Domain::Task::Ptr)>();
        auto parentTitle = QString();

        if (parentTask) {
            associate = std::bind(&Domain::TaskRepository::associate, m_taskRepository, parentTask, _1);
            dissociate = [] (Domain::Task::Ptr) -> KJob* { return nullptr; };
            parentTitle = parentTask->title();
        } else {
            associate = std::bind(&Domain::ContextRepository::associate, m_contextRepository, m_context, _1);
            dissociate = std::bind(&Domain::TaskRepository::dissociate, m_taskRepository, _1);
            parentTitle = m_context->name();
        }

        foreach(const Domain::Task::Ptr &childTask, droppedTasks) {
            auto job = associate(childTask);
            installHandler(job, i18n("Cannot move task %1 as sub-task of %2", childTask->title(), parentTitle));
            job = dissociate(childTask);
            if (job)
                installHandler(job, i18n("Cannot dissociate task %1 from its parent", childTask->title()));
        }

        return true;
    }
```

#### AUTO 


```{c}
auto c1 = Akonadi::Collection(42);
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Akonadi::Item &item) {
                       auto collection = m_data->reconstructAncestors(item.parentCollection());
                       auto result = item;
                       result.setParentCollection(collection);
                       // Force payload detach
                       result.setPayloadFromData(result.payloadData());
                       return result;
                   }
```

#### LAMBDA EXPRESSION 


```{c}
[provider, job, this] {
        if (job->kjob()->error() != KJob::NoError)
            return;

        for (auto collection : job->collections()) {
            ItemFetchJobInterface *job = m_storage->fetchItems(collection);
            Utils::JobHandler::install(job->kjob(), [provider, job, this] {
                if (job->kjob()->error() != KJob::NoError)
                    return;

                for (auto item : job->items()) {
                    auto project = m_serializer->createProjectFromItem(item);
                    if (project)
                        provider->append(project);
                }
            });
        }
    }
```

#### AUTO 


```{c}
auto itemFetchJob1 = new Testlib::AkonadiFakeItemFetchJob(this);
```

#### AUTO 


```{c}
auto setData = [this] (const Domain::Note::Ptr &note, const QVariant &value, int role) {
        if (role != Qt::EditRole) {
            return false;
        }

        const auto currentTitle = note->title();
        note->setTitle(value.toString());
        const auto job = m_noteRepository->update(note);
        installHandler(job, tr("Cannot modify note %1 in tag %2").arg(currentTitle).arg(m_tag->name()));
        return true;
    };
```

#### AUTO 


```{c}
auto t1 = serializer.createItemFromContext(context1);
```

#### AUTO 


```{c}
auto typeCombo = dialog.findChild<QComboBox*>("typeCombo");
```

#### AUTO 


```{c}
auto add = [&collections] (const Akonadi::Collection &collection) {
            collections.append(collection);
        };
```

#### AUTO 


```{c}
auto task = tasks.at(i);
```

#### AUTO 


```{c}
auto predicate = [this, taskItemId] (const Akonadi::Item &contextItem) {
        auto context = m_serializer->createContextFromItem(contextItem);
        if (!context)
            return false;

        const auto taskItem = m_findContextsItem[taskItemId];
        return m_serializer->isContextChild(context, taskItem);
    };
```

#### AUTO 


```{c}
auto job = storage->fetchItems(collection, parent);
```

#### AUTO 


```{c}
const auto job = m_contextRepository->create(context, source);
```

#### AUTO 


```{c}
auto data = [] (const Domain::DataSource::Ptr &source, int role) -> QVariant {
        if (role != Qt::DisplayRole
         && role != Qt::EditRole
         && role != Qt::DecorationRole
         && role != QueryTreeModelBase::IconNameRole) {
            return QVariant();
        }

        if (role == Qt::DisplayRole || role == Qt::EditRole) {
            return source->name();
        } else if (role == Qt::DecorationRole || role == QueryTreeModelBase::IconNameRole) {
            const QString iconName = source->iconName().isEmpty() ? QStringLiteral("folder") : source->iconName();

            if (role == Qt::DecorationRole)
                return QVariant::fromValue(QIcon::fromTheme(iconName));
            else
                return iconName;
        } else {
            return QVariant();
        }
    };
```

#### AUTO 


```{c}
auto update = storage->updateCollection(cal1);
```

#### AUTO 


```{c}
auto setData = [this] (const Domain::DataSource::Ptr &source, const QVariant &value, int role) {
        if (role != Qt::CheckStateRole)
            return false;
        if (source->contentTypes() == Domain::DataSource::NoContent)
            return false;

        source->setSelected(value.toInt() == Qt::Checked);
        m_dataSourceRepository->update(source);
        return true;
    };
```

#### AUTO 


```{c}
const auto noteContent = Akonadi::StorageInterface::FetchContentTypes(Akonadi::StorageInterface::Notes);
```

#### AUTO 


```{c}
const auto job = m_noteRepository->save(note);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto child : m_children->data()) {
            QueryTreeNodeBase *node = new QueryTreeNode<ItemType>(child, this,
                                                                  model, queryGenerator,
                                                                  m_flagsFunction,
                                                                  m_dataFunction, m_setDataFunction,
                                                                  m_dropFunction);
            appendChild(node);
        }
```

#### AUTO 


```{c}
auto notifiedCollection = changeSpy.takeFirst().takeFirst().value<Akonadi::Collection>();
```

#### LAMBDA EXPRESSION 


```{c}
[storage, serializer] (const Domain::LiveQueryInput<Akonadi::Item>::AddFunction &add) {
            auto job = storage->fetchCollections(Akonadi::Collection::root(), Akonadi::Storage::Recursive);
            Utils::JobHandler::install(job->kjob(), [add, job, storage, serializer] {
                foreach (const auto &col, job->collections()) {
                    if (!serializer->isSelectedCollection(col))
                        continue;

                    auto itemJob = storage->fetchItems(col);
                    Utils::JobHandler::install(itemJob->kjob(), [add, itemJob] {
                        foreach (const auto &item, itemJob->items())
                            add(item);
                    });
                }
            });
        }
```

#### AUTO 


```{c}
auto setData = [this] (const Domain::DataSource::Ptr &source, const QVariant &value, int role) {
        Q_UNUSED(source)
        Q_UNUSED(value)
        Q_UNUSED(role)
        return false;
    };
```

#### AUTO 


```{c}
auto result = collection;
```

#### AUTO 


```{c}
auto childTodo = KCalCore::Todo::Ptr::create();
```

#### AUTO 


```{c}
auto uri = attachment.uri();
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Akonadi::Item &item) {
        const bool excluded = !m_serializer->isTaskItem(item)
                           || !m_serializer->relatedUidFromItem(item).isEmpty();

        return !excluded;
    }
```

#### AUTO 


```{c}
auto expectedNames = QStringList();
```

#### AUTO 


```{c}
auto delegatedTask = Domain::Task::Ptr();
```

#### AUTO 


```{c}
auto sourcesView = new QTreeView(this);
```

#### AUTO 


```{c}
auto drop = [this](const QMimeData *mimeData, Qt::DropAction, const Domain::Artifact::Ptr &artifact) {
        auto parentTask = artifact.objectCast<Domain::Task>();

        if (!mimeData->hasFormat(QStringLiteral("application/x-zanshin-object")))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                        [](const Domain::Artifact::Ptr &droppedArtifact) {
                            return !droppedArtifact.objectCast<Domain::Task>();
                        })) {
            return false;
        }

        foreach(const auto &droppedArtifact, droppedArtifacts) {
            auto childTask = droppedArtifact.objectCast<Domain::Task>();

            if (parentTask) {
                const auto job = m_taskRepository->associate(parentTask, childTask);
                installHandler(job, i18n("Cannot move task %1 as sub-task of %2", childTask->title(), parentTask->title()));
            } else {
                childTask->setStartDate(Utils::DateTime::currentDateTime());

                auto job = m_taskRepository->dissociate(childTask);
                installHandler(job, i18n("Cannot deparent task %1 from its parent", childTask->title()));
            }
        }

        return true;
    };
```

#### AUTO 


```{c}
auto data = [](const Domain::Task::Ptr &task, int role, const TaskExtraDataPtr &info) {
        return dataForTaskWithProject(task, role, info);
    };
```

#### AUTO 


```{c}
auto source4Provider = Domain::QueryResultProvider<Domain::DataSource::Ptr>::Ptr::create();
```

#### AUTO 


```{c}
const auto createdTask = workday.addItem(title, parentIndex);
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Collection &collection) {
        m_findChildren.remove(collection.id());
    }
```

#### AUTO 


```{c}
auto handler = [&]() {
            FakeJob *job2 = new FakeJob(this);
            QObject::connect(job2, SIGNAL(result(KJob*)), this, SLOT(handleJobResult(KJob*)));
            compositeJob->addSubjob(job2);
            job2->start();
        };
```

#### LAMBDA EXPRESSION 


```{c}
[&](const Domain::Task::Ptr &task, const QVariant &value, int role) {
        if (role != Qt::EditRole && role != Qt::CheckStateRole) {
            return false;
        }

        if (role == Qt::EditRole) {
            task->setTitle(value.toString());
        } else {
            task->setDone(value.toInt() == Qt::Checked);
        }

        repository.update(task);
        return true;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Domain::DataSource::Ptr &, int) {
                                         endInsertRows();
                                     }
```

#### AUTO 


```{c}
auto drop = [this](const QMimeData *, Qt::DropAction, const Domain::Artifact::Ptr &) {
        return false;
    };
```

#### AUTO 


```{c}
auto inQuery = Domain::LiveQueryOutput<Domain::Tag::Ptr>::Ptr();
```

#### AUTO 


```{c}
auto col = GenCollection().withId(id).withName(QString::number(id)).withRootAsParent();
```

#### AUTO 


```{c}
auto job = storage.fetchItems(collection);
```

#### AUTO 


```{c}
auto queryGenerator = [&](const Domain::Task::Ptr &task) {
            if (!task)
                return Domain::QueryResult<Domain::Task::Ptr>::create(provider);
            else
                return queryMock.getInstance().findChildren(task);
        };
```

#### AUTO 


```{c}
auto dataSource = provider->data().at(i);
```

#### AUTO 


```{c}
auto availableSources = new QObject(model.data());
```

#### LAMBDA EXPRESSION 


```{c}
[dialogStub] (QWidget *parent) {
            dialogStub->parent = parent;
            dialogStub->setPageType(Widgets::NewPageDialogInterface::Context);
            return dialogStub;
        }
```

#### AUTO 


```{c}
auto job = storage.fetchCollections(collection, depth,
                                            Akonadi::StorageInterface::FetchContentTypes(contentTypes));
```

#### LAMBDA EXPRESSION 


```{c}
[fetchItemJob, parent, child, job, this] {
        if (fetchItemJob->kjob()->error() != KJob::NoError)
           return;

        Q_ASSERT(fetchItemJob->items().size() == 1);
        auto childItem = fetchItemJob->items().at(0);
        m_serializer->updateItemProject(childItem, parent);

        // Check collections to know if we need to move child
        auto parentItem = m_serializer->createItemFromProject(parent);
        ItemFetchJobInterface *fetchParentItemJob = m_storage->fetchItem(parentItem);
        job->install(fetchParentItemJob->kjob(), [fetchParentItemJob, child, childItem, job, this] {
            if (fetchParentItemJob->kjob()->error() != KJob::NoError)
                return;

            Q_ASSERT(fetchParentItemJob->items().size() == 1);
            auto parentItem = fetchParentItemJob->items().at(0);

            const int itemCollectionId = childItem.parentCollection().id();
            const int parentCollectionId = parentItem.parentCollection().id();

            if (itemCollectionId != parentCollectionId) {
                ItemFetchJobInterface *fetchChildrenItemJob = m_storage->fetchItems(childItem.parentCollection());
                job->install(fetchChildrenItemJob->kjob(), [fetchChildrenItemJob, childItem, parentItem, job, this] {
                    if (fetchChildrenItemJob->kjob()->error() != KJob::NoError)
                        return;

                    Item::List childItems = m_serializer->filterDescendantItems(fetchChildrenItemJob->items(), childItem);

                    auto transaction = m_storage->createTransaction();
                    m_storage->updateItem(childItem, transaction);
                    childItems.push_front(childItem);
                    m_storage->moveItems(childItems, parentItem.parentCollection(), transaction);
                    job->addSubjob(transaction);
                    transaction->start();
                });
            } else {
                auto updateJob = m_storage->updateItem(childItem);
                job->addSubjob(updateJob);
                updateJob->start();
            }
        });
    }
```

#### AUTO 


```{c}
auto job = storage->moveItems(list, calendar1());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &col : colJob->collections()) {
        qDebug() << "COL:" << col.id() << col.name() << col.remoteId();
        auto itemJob = storage->fetchItems(col);
        itemJob->kjob()->exec();
        for (const auto &item : itemJob->items()) {
            QString summary;
            if (item.hasPayload<KCalCore::Todo::Ptr>())
                summary = item.payload<KCalCore::Todo::Ptr>()->summary();
            qDebug() << "\tITEM:" << item.id() << item.remoteId() << summary;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QMimeData *mimeData, Qt::DropAction, const Domain::Artifact::Ptr &artifact) {
        auto parentTask = artifact.objectCast<Domain::Task>();
        if (!parentTask)
            return false;

        if (!mimeData->hasFormat("application/x-zanshin-object"))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                        [](const Domain::Artifact::Ptr &droppedArtifact) {
                            return !droppedArtifact.objectCast<Domain::Task>();
                        })) {
            return false;
        }

        foreach(const auto &droppedArtifact, droppedArtifacts) {
            auto childTask = droppedArtifact.objectCast<Domain::Task>();
            taskRepository()->associate(parentTask, childTask);
        }

        return true;
    }
```

#### AUTO 


```{c}
auto workdayPageModel = new WorkdayPageModel(m_taskQueries,
                                                     m_taskRepository,
                                                     this);
```

#### LAMBDA EXPRESSION 


```{c}
[this, job, add] {
                    if (job->kjob()->error() != KJob::NoError)
                        return;

                    for (auto item : job->items())
                        add(item);
                }
```

#### AUTO 


```{c}
auto indexChild3 = rootTaskIndex.child(0,0);
```

#### AUTO 


```{c}
auto predicate = [] (const Akonadi::Tag &tag) {
            return tag.name().endsWith(QLatin1String("-in"));
        };
```

#### AUTO 


```{c}
auto page = new QObject(this);
```

#### LAMBDA EXPRESSION 


```{c}
[job, add] {
                if (job->kjob()->error() != KJob::NoError)
                    return;

                foreach (const auto &item, job->items())
                    add(item);
            }
```

#### AUTO 


```{c}
auto job = storage->fetchCollections(Akonadi::Collection::root(), Akonadi::Storage::Recursive, parent);
```

#### AUTO 


```{c}
auto editorDock = new QDockWidget(QObject::tr("Editor"));
```

#### AUTO 


```{c}
const auto tagFetchNames = toTagNames(job->tags());
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Domain::Task::Ptr &task, const QVariant &value, int role) {
        if (role != Qt::EditRole && role != Qt::CheckStateRole) {
            return false;
        }

        const auto currentTitle = task->title();
        if (role == Qt::EditRole)
            task->setTitle(value.toString());
        else
            task->setDone(value.toInt() == Qt::Checked);

        const auto job = m_taskRepository->update(task);
        installHandler(job, tr("Cannot modify task %1 in project %2").arg(currentTitle).arg(m_project->name()));
        return true;
    }
```

#### AUTO 


```{c}
auto treeData = [](const Domain::Task::Ptr &task, int role) -> QVariant {
        if (role != Qt::DisplayRole && role != Qt::CheckStateRole) {
            return QVariant();
        }

        if (role == Qt::DisplayRole)
            return task->title();
        else
            return task->isDone() ? Qt::Checked : Qt::Unchecked;
    };
```

#### AUTO 


```{c}
auto tag = object.objectCast<Domain::Tag>()
```

#### AUTO 


```{c}
auto fetch = helpers->fetchItems(collection);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QMimeData *mimeData, Qt::DropAction, const Domain::Artifact::Ptr &artifact) {
        auto parentTask = artifact.objectCast<Domain::Task>();
        if (!parentTask)
            return false;

        if (!mimeData->hasFormat("application/x-zanshin-object"))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                        [](const Domain::Artifact::Ptr &droppedArtifact) {
                            return !droppedArtifact.objectCast<Domain::Task>();
                        })) {
            return false;
        }

        foreach(const Domain::Artifact::Ptr &droppedArtifact, droppedArtifacts) {
            auto childTask = droppedArtifact.objectCast<Domain::Task>();
            taskRepository()->associate(parentTask, childTask);
        }

        return true;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[root] (const Collection &collection) {
        return collection.isValid()
            && collection.parentCollection() == root;
    }
```

#### AUTO 


```{c}
auto fetch = m_helpers->fetchItems(akonadiTag);
```

#### AUTO 


```{c}
const auto taskContent = Akonadi::StorageInterface::FetchContentTypes(Akonadi::StorageInterface::Tasks);
```

#### LAMBDA EXPRESSION 


```{c}
[] (const InputType &input) { return OutputType(input); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QObjectPtr &object) -> Domain::QueryResultInterface<QObjectPtr>::Ptr {
        if (!object)
            return Domain::QueryResult<QObjectPtr>::create(m_rootsProvider);
        else if (object == m_projectsObject)
            return Domain::QueryResult<Domain::Project::Ptr, QObjectPtr>::copy(m_projectQueries->findAll());
        else if (object == m_contextsObject)
            return Domain::QueryResult<Domain::Context::Ptr, QObjectPtr>::copy(m_contextQueries->findAll());
        else if (object == m_tagsObject)
            return Domain::QueryResult<Domain::Tag::Ptr, QObjectPtr>::copy(m_tagQueries->findAll());
        else
            return Domain::QueryResult<QObjectPtr>::Ptr();
    }
```

#### AUTO 


```{c}
const auto createdTask = page.addItem(title, parentIndex).objectCast<Domain::Task>();
```

#### LAMBDA EXPRESSION 


```{c}
[this](const ItemType &, int index) {
            QModelIndex parentIndex = parent() ? createIndex(row(), 0, this) : QModelIndex();
            beginRemoveRows(parentIndex, index, index);
        }
```

#### AUTO 


```{c}
auto model = new AvailableSourcesModel(m_sourceQueries,
                                               m_sourceRepository,
                                               this);
```

#### AUTO 


```{c}
const auto tagUid = m_tagUids.value(tag.id());
```

#### LAMBDA EXPRESSION 


```{c}
[this, item] (const Domain::LiveQueryInput<Item>::AddFunction &add) {
        auto job = m_storage->fetchItem(item);
        Utils::JobHandler::install(job->kjob(), [this, job, add] {
            if (job->kjob()->error() != KJob::NoError)
                return;

            Q_ASSERT(job->items().size() == 1);
            auto item = job->items()[0];
            Q_ASSERT(item.parentCollection().isValid());
            auto job = m_storage->fetchItems(item.parentCollection());
            Utils::JobHandler::install(job->kjob(), [this, job, add] {
                if (job->kjob()->error() != KJob::NoError)
                    return;

                foreach (const auto &item, job->items())
                    add(item);
            });
        });
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto item : job->items())
                        add(item);
```

#### AUTO 


```{c}
auto job = new Akonadi::ItemCreateJob(item, collection);
```

#### AUTO 


```{c}
auto defaultAction = available.findChild<QAction*>("defaultAction");
```

#### AUTO 


```{c}
auto result = queries->findTopLevel(project);
```

#### AUTO 


```{c}
auto drop = [this] (const QMimeData *mimeData, Qt::DropAction, const Domain::Task::Ptr &parentTask) {
        if (!mimeData->hasFormat(QStringLiteral("application/x-zanshin-object")))
            return false;

        auto droppedTasks = mimeData->property("objects").value<Domain::Task::List>();
        if (droppedTasks.isEmpty())
            return false;

        using namespace std::placeholders;
        auto associate = std::function<KJob*(Domain::Task::Ptr)>();
        auto dissociate = std::function<KJob*(Domain::Task::Ptr)>();
        auto parentTitle = QString();

        if (parentTask) {
            associate = std::bind(&Domain::TaskRepository::associate, m_taskRepository, parentTask, _1);
            dissociate = [] (Domain::Task::Ptr) -> KJob* { return nullptr; };
            parentTitle = parentTask->title();
        } else {
            associate = std::bind(&Domain::ContextRepository::associate, m_contextRepository, m_context, _1);
            dissociate = std::bind(&Domain::TaskRepository::dissociate, m_taskRepository, _1);
            parentTitle = m_context->name();
        }

        foreach(const Domain::Task::Ptr &childTask, droppedTasks) {
            auto job = associate(childTask);
            installHandler(job, i18n("Cannot move task %1 as sub-task of %2", childTask->title(), parentTitle));
            job = dissociate(childTask);
            if (job)
                installHandler(job, i18n("Cannot dissociate task %1 from its parent", childTask->title()));
        }

        return true;
    };
```

#### AUTO 


```{c}
const auto childCollections = m_childCollections[collection.id()];
```

#### AUTO 


```{c}
auto parent = item.parentCollection();
```

#### AUTO 


```{c}
auto invalidParent = Domain::Project::Ptr::create();
```

#### AUTO 


```{c}
auto treeQuery = [&](const Domain::Task::Ptr &task) {
        if (!task)
            return queries->findTopLevel();
        else
            return queries->findChildren(task);
    };
```

#### AUTO 


```{c}
auto drop = [this] (const QMimeData *mimeData, Qt::DropAction, const Domain::Task::Ptr &parentTask) {
        if (!mimeData->hasFormat("application/x-zanshin-object"))
            return false;

        auto droppedTasks = mimeData->property("objects").value<Domain::Task::List>();
        if (droppedTasks.isEmpty())
            return false;

        foreach(const Domain::Task::Ptr &childTask, droppedTasks) {
            taskRepository()->associate(parentTask, childTask);
        }

        return true;
    };
```

#### AUTO 


```{c}
auto title = QString("New task");
```

#### AUTO 


```{c}
auto repository = deps->create<Domain::NoteRepository>();
```

#### AUTO 


```{c}
auto fetchAdditionalInfo = [this](const QModelIndex &index, const Domain::Artifact::Ptr &artifact) -> AdditionalInfo {
        if (index.parent().isValid()) // children are in the same collection as their parent, so the same datasource
            return nullptr;
        if (auto task = artifact.dynamicCast<Domain::Task>()) {
            AdditionalInfo datasourceQueryResult = m_taskQueries->findDataSource(task);
            if (datasourceQueryResult) {
                QPersistentModelIndex persistentIndex(index);
                datasourceQueryResult->addPostInsertHandler([persistentIndex](const Domain::DataSource::Ptr &, int) {
                    // When a datasource was found (inserted into the result), update the rendering of the item
                    auto model = const_cast<QAbstractItemModel *>(persistentIndex.model());
                    model->dataChanged(persistentIndex, persistentIndex);
                });
            }
            return datasourceQueryResult;
        }
        return nullptr;

    };
```

#### AUTO 


```{c}
auto dataSource2 = serializer.createDataSourceFromCollection(collection);
```

#### AUTO 


```{c}
auto data = [this](const QObjectPtr &object, int role) -> QVariant {
        if (role != Qt::DisplayRole
         && role != Qt::EditRole
         && role != Qt::DecorationRole
         && role != QueryTreeModelBase::IconNameRole) {
            return QVariant();
        }

        if (role == Qt::EditRole
         && (object == m_inboxObject
          || object == m_workdayObject
          || object == m_projectsObject
          || object == m_contextsObject)) {
            return QVariant();
        }

        if (role == Qt::DisplayRole || role == Qt::EditRole) {
            return object->property("name").toString();
        } else if (role == Qt::DecorationRole || role == QueryTreeModelBase::IconNameRole) {
            const QString iconName = object == m_inboxObject ? QStringLiteral("mail-folder-inbox")
                                   : (object == m_workdayObject)  ? QStringLiteral("go-jump-today")
                                   : (object == m_projectsObject) ? QStringLiteral("folder")
                                   : (object == m_contextsObject) ? QStringLiteral("folder")
                                   : object.objectCast<Domain::Context>() ? QStringLiteral("view-pim-notes")
                                   : QStringLiteral("view-pim-tasks");

            if (role == Qt::DecorationRole)
                return QVariant::fromValue(QIcon::fromTheme(iconName));
            else
                return iconName;
        } else {
            return QVariant();
        }
    };
```

#### AUTO 


```{c}
auto dataSource = serializer.createDataSourceFromCollection(collection, Akonadi::SerializerInterface::BaseName);
```

#### AUTO 


```{c}
auto c2 = Akonadi::Collection(c1.id());
```

#### AUTO 


```{c}
auto data = createMimeData(indexes);
```

#### AUTO 


```{c}
auto items = job->items();
```

#### AUTO 


```{c}
auto  provider = Domain::QueryResultProvider<Domain::Task::Ptr>::Ptr::create();
```

#### LAMBDA EXPRESSION 


```{c}
[this, job, add] {
                if (job->kjob()->error() != KJob::NoError)
                    return;

                for (auto collection : job->collections()) {
                    if (!m_serializer->isSelectedCollection(collection))
                        continue;

                    ItemFetchJobInterface *job = m_storage->fetchItems(collection);
                    Utils::JobHandler::install(job->kjob(), [this, job, add] {
                        if (job->kjob()->error() != KJob::NoError)
                            return;

                        for (auto item : job->items()) {
                            add(item);
                        }
                    });
                }
            }
```

#### AUTO 


```{c}
auto job = new Akonadi::CollectionDeleteJob(collection);
```

#### AUTO 


```{c}
auto job = storage->fetchCollections(Akonadi::Collection::root(),
                                             StorageInterface::Recursive,
                                             parent);
```

#### AUTO 


```{c}
auto event = static_cast<QKeyEvent*>(ev);
```

#### AUTO 


```{c}
auto &ids = m_collectionItems[collection.id()];
```

#### AUTO 


```{c}
auto directChildren = QHash<Collection::Id, Collection>();
```

#### LAMBDA EXPRESSION 


```{c}
[](const Domain::Task::Ptr &task, int role, const TaskExtraDataPtr &info) -> QVariant {
        return dataForTaskWithProject(task, role, info);
    }
```

#### AUTO 


```{c}
auto serializer = createSerializer();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto child : m_children->data()) {
            QueryTreeNodeBase *node = new QueryTreeNode<ItemType, AdditionalInfo>(child, this,
                                                                  model, queryGenerator,
                                                                  m_flagsFunction,
                                                                  m_dataFunction, m_setDataFunction,
                                                                  m_dropFunction);
            appendChild(node);
        }
```

#### AUTO 


```{c}
auto dragFunction = [] (const QList<QColor> &) -> QMimeData* {
            return nullptr;
        };
```

#### AUTO 


```{c}
auto root = Akonadi::Collection(42);
```

#### AUTO 


```{c}
auto &deps = Utils::DependencyManager::globalInstance();
```

#### AUTO 


```{c}
const auto job = m_taskRepository->promoteToProject(task);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &col : colJob->collections()) {
        qDebug() << "COL:" << col.id() << col.name() << col.remoteId();
        auto itemJob = new Akonadi::ItemFetchJob(col);
        itemJob->fetchScope().fetchFullPayload();
        itemJob->exec();
        for (const auto &item : itemJob->items()) {
            QString summary;
            if (item.hasPayload<KCalCore::Todo::Ptr>())
                summary = item.payload<KCalCore::Todo::Ptr>()->summary();
            qDebug() << "\tITEM:" << item.id() << item.remoteId() << summary;
        }
    }
```

#### AUTO 


```{c}
auto result = Akonadi::Collection::List();
```

#### LAMBDA EXPRESSION 


```{c}
[](const Domain::Task::Ptr &task, int role, int) -> QVariant {
        return defaultTaskData(task, role, TaskExtraDataPtr());
    }
```

#### AUTO 


```{c}
auto result = std::find_if(items.constBegin(), items.constEnd(),
                               [remoteId] (const Akonadi::Item &item) {
                                   return item.remoteId() == remoteId;
                               });
```

#### AUTO 


```{c}
auto &query = m_findToplevel[tag.id()];
```

#### AUTO 


```{c}
auto runningTaskModel = new RunningTaskModelStub(model.data());
```

#### AUTO 


```{c}
auto tag = Domain::Tag::Ptr::create();
```

#### AUTO 


```{c}
auto data = [](const Domain::Task::Ptr &task, int role) -> QVariant {
        if (role != Qt::DisplayRole
         && role != Qt::EditRole
         && role != Qt::CheckStateRole) {
            return QVariant();
        }

        if (role == Qt::DisplayRole || role == Qt::EditRole) {
            return task->title();
        } else {
            return task->isDone() ? Qt::Checked : Qt::Unchecked;
        }
    };
```

#### AUTO 


```{c}
auto setData = [this] (const Domain::Note::Ptr &note, const QVariant &value, int role) {
        if (role != Qt::EditRole) {
            return false;
        }

        const auto currentTitle = note->title();
        note->setTitle(value.toString());
        const auto job = m_noteRepository->update(note);
        installHandler(job, tr("Cannot modify note %1 in tag %2").arg(currentTitle, m_tag->name()));
        return true;
    };
```

#### AUTO 


```{c}
const auto oldPropertyValue = task->property(propertyName);
```

#### AUTO 


```{c}
auto setData = [this] (const Domain::DataSource::Ptr &source, const QVariant &value, int role) {
        if (role != Qt::CheckStateRole)
            return false;
        if (source->contentTypes() == Domain::DataSource::NoContent)
            return false;

        source->setSelected(value.toInt() == Qt::Checked);
        const auto job = m_dataSourceRepository->update(source);
        installHandler(job, tr("Cannot modify source %1").arg(source->name()));
        return true;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[] (const KCalCore::Attendee::Ptr &attendee) {
                                               return attendee->status() == KCalCore::Attendee::Accepted;
                                           }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Domain::Task::Ptr &task, const QVariant &value, int role) {
        if (role != Qt::EditRole && role != Qt::CheckStateRole)
            return false;

        const auto currentTitle = task->title();
        if (role == Qt::EditRole)
            task->setTitle(value.toString());
        else
            task->setDone(value.toInt() == Qt::Checked);

        const auto job = m_taskRepository->update(task);
        installHandler(job, tr("Cannot modify task %1 in context %2").arg(currentTitle).arg(m_context->name()));
        return true;
    }
```

#### AUTO 


```{c}
auto fetchAdditionalInfo = [this](const QModelIndex &index, const Domain::Task::Ptr &task) -> AdditionalInfo {
        if (index.parent().isValid()) // children are in the same collection as their parent, so the same project
            return nullptr;

        AdditionalInfo projectQueryResult = m_taskQueries->findProject(task);
        if (projectQueryResult) {
            QPersistentModelIndex persistentIndex(index);
            projectQueryResult->addPostInsertHandler([persistentIndex](const Domain::Project::Ptr &, int) {
                // When a project was found (inserted into the result), update the rendering of the item
                auto model = const_cast<QAbstractItemModel *>(persistentIndex.model());
                model->dataChanged(persistentIndex, persistentIndex);
            });
        }
        return projectQueryResult;
    };
```

#### AUTO 


```{c}
auto query = [this](const Domain::Task::Ptr &task) -> Domain::QueryResultInterface<Domain::Task::Ptr>::Ptr {
        if (!task)
            return m_taskQueries->findWorkdayTopLevel();
        else
            return m_taskQueries->findChildren(task);
    };
```

#### AUTO 


```{c}
auto collectionFetchJob2 = new Testlib::AkonadiFakeCollectionFetchJob(this);
```

#### LAMBDA EXPRESSION 


```{c}
[storage] (const Domain::LiveQueryInput<Collection>::AddFunction &add) {
        auto job = storage->fetchCollections(Collection::root(), StorageInterface::Recursive);
        Utils::JobHandler::install(job->kjob(), [job, add] {
            if (job->kjob()->error())
                return;

            foreach (const auto &collection, job->collections())
                add(collection);
        });
    }
```

#### AUTO 


```{c}
auto query = ProjectQueries::ArtifactQuery::Ptr::create();
```

#### AUTO 


```{c}
const auto job = taskRepository()->remove(task);
```

#### AUTO 


```{c}
auto storage = createStorage(data);
```

#### AUTO 


```{c}
const auto allMimeTypes = noteMimeTypes + taskMimeTypes + bogusMimeTypes;
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Domain::Artifact::Ptr &artifact, const QVariant &value, int role) {
        if (role != Qt::EditRole && role != Qt::CheckStateRole) {
            return false;
        }

        if (auto task = artifact.dynamicCast<Domain::Task>()) {
            const auto currentTitle = task->title();
            if (role == Qt::EditRole)
                task->setTitle(value.toString());
            else
                task->setDone(value.toInt() == Qt::Checked);

            const auto job = m_taskRepository->update(task);
            installHandler(job, tr("Cannot modify task %1 in Workday").arg(currentTitle));
            return true;
        }

        return false;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &tag : contextTags) {

        auto context = Domain::Context::Ptr::create();
        context->setName(tag.name());
        Akonadi::Item item = m_serializer.createItemFromContext(context);
        item.setParentCollection(collection);
        auto job = new Akonadi::ItemCreateJob(item, collection);
        if (job->exec()) {
            ++count;
            m_tagUids.insert(tag.id(), job->item().payload<KCalCore::Todo::Ptr>()->uid());
        } else {
            qWarning() << "Failure to create context:" << job->errorString();
        }
    }
```

#### AUTO 


```{c}
auto inResult = inQuery->result();
```

#### AUTO 


```{c}
auto mimeData = new QMimeData;
```

#### LAMBDA EXPRESSION 


```{c}
[add, job, storage, serializer] {
                foreach (const auto &col, job->collections()) {
                    if (!serializer->isSelectedCollection(col))
                        continue;

                    auto itemJob = storage->fetchItems(col, nullptr);
                    Utils::JobHandler::install(itemJob->kjob(), [add, itemJob] {
                        foreach (const auto &item, itemJob->items())
                            add(item);
                    });
                }
            }
```

#### AUTO 


```{c}
const auto itemTags = tagNames(tags);
```

#### AUTO 


```{c}
auto setData = [this](const Domain::Artifact::Ptr &artifact, const QVariant &value, int role) {
        if (role != Qt::EditRole && role != Qt::CheckStateRole) {
            return false;
        }

        if (auto task = artifact.dynamicCast<Domain::Task>()) {
            const auto currentTitle = task->title();
            if (role == Qt::EditRole)
                task->setTitle(value.toString());
            else
                task->setDone(value.toInt() == Qt::Checked);

            const auto job = taskRepository()->update(task);
            installHandler(job, tr("Cannot modify task %1 in Inbox").arg(currentTitle));
            return true;

        } else if (auto note = artifact.dynamicCast<Domain::Note>()) {
            if (role != Qt::EditRole)
                return false;

            const auto currentTitle = note->title();
            note->setTitle(value.toString());
            const auto job = noteRepository()->save(note);
            installHandler(job, tr("Cannot modify note %1 in Inbox").arg(currentTitle));
            return true;

        }

        return false;
    };
```

#### AUTO 


```{c}
auto job = storage->fetchCollections(collection, depth,
                                         Akonadi::StorageInterface::FetchContentTypes(contentTypes));
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QMimeData *mimeData, Qt::DropAction, const Domain::Artifact::Ptr &artifact) {
        auto parentTask = artifact.objectCast<Domain::Task>();
        if (!parentTask)
            return false;

        if (!mimeData->hasFormat("application/x-zanshin-object"))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                        [](const Domain::Artifact::Ptr &droppedArtifact) {
                            return !droppedArtifact.objectCast<Domain::Task>();
                        })) {
            return false;
        }

        foreach(const Domain::Artifact::Ptr &droppedArtifact, droppedArtifacts) {
            auto childTask = droppedArtifact.objectCast<Domain::Task>();
            const auto job = m_taskRepository->associate(parentTask, childTask);
            installHandler(job, tr("Cannot move task %1 as a sub-task of %2").arg(childTask->title()).arg(parentTask->title()));
        }

        return true;
    }
```

#### AUTO 


```{c}
auto fullItem = m_data->item(findId(item));
```

#### AUTO 


```{c}
auto collections = m_data->collections();
```

#### AUTO 


```{c}
auto fetch = [storage] (const Domain::LiveQueryInput<Akonadi::Collection>::AddFunction &add) {
            auto job = storage->fetchCollections(Akonadi::Collection::root(), Akonadi::Storage::Recursive, Akonadi::Storage::AllContent);
            Utils::JobHandler::install(job->kjob(), [add, job] {
                foreach (const auto &col, job->collections()) {
                    add(col);
                }
            });
        };
```

#### AUTO 


```{c}
auto flagsFunction = [](const Domain::Task::Ptr &) {
            return Qt::NoItemFlags;
        };
```

#### LAMBDA EXPRESSION 


```{c}
[this, parentUid] (const Akonadi::Item &item) {
                                                 return m_serializer->itemUid(item) == parentUid;
                                             }
```

#### AUTO 


```{c}
auto flags = [this](const QObjectPtr &object) {
        const Qt::ItemFlags defaultFlags = Qt::ItemIsSelectable
                                         | Qt::ItemIsEnabled
                                         | Qt::ItemIsEditable
                                         | Qt::ItemIsDropEnabled;
        const Qt::ItemFlags immutableNodeFlags = Qt::ItemIsSelectable
                                               | Qt::ItemIsEnabled;
        const Qt::ItemFlags structureNodeFlags = Qt::NoItemFlags;


        return object.objectCast<Domain::Project>() ? defaultFlags
             : object == m_inboxObject ? immutableNodeFlags
             : structureNodeFlags;
    };
```

#### AUTO 


```{c}
const auto newItem = serializer.createItemFromTask(task);
```

#### AUTO 


```{c}
auto source = std::find_if(sources.begin(), sources.end(),
                               [this] (const Domain::DataSource::Ptr &source) {
                                   return isDefaultSource(source);
                               });
```

#### AUTO 


```{c}
auto quickAddEdit = page.findChild<QLineEdit*>("quickAddEdit");
```

#### AUTO 


```{c}
auto toolBar = new QToolBar(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QMimeData *mimeData, Qt::DropAction, const QObjectPtr &object) {
        if (!mimeData->hasFormat("application/x-zanshin-object"))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (auto tag = object.objectCast<Domain::Tag>()) {
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                const auto job = m_tagRepository->associate(tag, droppedArtifact);
                installHandler(job, tr("Cannot tag %1 with %2").arg(droppedArtifact->title()).arg(tag->name()));
            }
            return true;
        } else if (object == m_inboxObject) {
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                const auto job = m_tagRepository->dissociateAll(droppedArtifact.objectCast<Domain::Note>());
                installHandler(job, tr("Cannot move %1 to Inbox").arg(droppedArtifact->title()));
            }
            return true;
        }

        return false;
    }
```

#### AUTO 


```{c}
auto result1 = queries->findTopLevel(project1);
```

#### AUTO 


```{c}
auto handler = [&]() {
            FakeJob *job2 = new FakeJob(this);
            QObject::connect(job2, &KJob::result, this, &CompositeJobTest::handleJobResult);
            compositeJob->addSubjob(job2);
            job2->start();
        };
```

#### AUTO 


```{c}
auto model = page.centralListModel();
```

#### AUTO 


```{c}
auto itemFetchJob1 = new MockItemFetchJob(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this, model](const Domain::Task::Ptr &, int idx) {
                                         QModelIndex parentIndex = model->createIndex(row(), 0, this);
                                         emit model->dataChanged(model->index(idx, 0, parentIndex), model->index(idx, 0, parentIndex));
                                    }
```

#### AUTO 


```{c}
auto isSelected = collection.attribute<Akonadi::ApplicationSelectedAttribute>()->isSelected();
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Domain::Artifact::Ptr &artifact) -> Domain::QueryResultInterface<Domain::Artifact::Ptr>::Ptr {
        if (!artifact)
            return m_artifactQueries->findInboxTopLevel();
        else if (auto task = artifact.dynamicCast<Domain::Task>())
            return Domain::QueryResult<Domain::Task::Ptr, Domain::Artifact::Ptr>::copy(m_taskQueries->findChildren(task));
        else
            return Domain::QueryResult<Domain::Artifact::Ptr>::Ptr();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Domain::Task::Ptr &task, int index) {
                                        Node *node = new Node(task, 0, m_queries, this);
                                        m_rootNodes.insert(index, node);
                                        beginInsertRows(QModelIndex(), index, index);
                                    }
```

#### LAMBDA EXPRESSION 


```{c}
[&listingDone] {
                listingDone = true;
            }
```

#### LAMBDA EXPRESSION 


```{c}
[&](const Domain::Task::Ptr &task) {
            if (!task)
                return Domain::QueryResult<Domain::Task::Ptr>::create(provider);
            else
                return queryMock.getInstance().findChildren(task);
        }
```

#### AUTO 


```{c}
auto tag = m_serializer->createAkonadiTagFromTag(parent);
```

#### AUTO 


```{c}
auto fetch = m_helpers->fetchCollections(Collection::root(), StorageInterface::Tasks | StorageInterface::Notes);
```

#### LAMBDA EXPRESSION 


```{c}
[serializer, storage, parent] (const Domain::LiveQueryInput<Item>::AddFunction &add) {
        auto job = storage->fetchCollections(Akonadi::Collection::root(),
                                             StorageInterface::Recursive,
                                             parent);
        Utils::JobHandler::install(job->kjob(), [serializer, storage, job, add, parent] {
            if (job->kjob()->error() != KJob::NoError)
                return;

            foreach (const auto &collection, job->collections()) {
                if (!serializer->isSelectedCollection(collection))
                    continue;

                auto job = storage->fetchItems(collection, parent);
                Utils::JobHandler::install(job->kjob(), [job, add] {
                    if (job->kjob()->error() != KJob::NoError)
                        return;

                    foreach (const auto &item, job->items())
                        add(item);
                });
            }
        });
    }
```

#### AUTO 


```{c}
auto editorDock = new QDockWidget(i18n("Editor"));
```

#### AUTO 


```{c}
auto window = new KMainWindow;
```

#### AUTO 


```{c}
auto inQuery = Domain::LiveQueryOutput<Domain::Context::Ptr>::Ptr();
```

#### AUTO 


```{c}
auto fetch = m_helpers->searchCollections(Collection::root(), &m_searchTerm);
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const QMimeData *, Qt::DropAction, const Domain::Note::Ptr &) {
        return false;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QMimeData *mimeData, Qt::DropAction, const Domain::Task::Ptr &parentTask) {
        if (!mimeData->hasFormat(QStringLiteral("application/x-zanshin-object")))
            return false;

        auto droppedTasks = mimeData->property("objects").value<Domain::Task::List>();
        if (droppedTasks.isEmpty())
            return false;

        foreach(const auto &childTask, droppedTasks) {
            if (parentTask) {
                const auto job = m_taskRepository->associate(parentTask, childTask);
                installHandler(job, i18n("Cannot move task %1 as sub-task of %2", childTask->title(), parentTask->title()));
            } else {
                auto job = m_taskRepository->dissociate(childTask);
                installHandler(job, i18n("Cannot deparent task %1 from its parent", childTask->title()));
            }
        }

        return true;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Domain::Artifact::Ptr &artifact, const QVariant &value, int role) {
        if (role != Qt::EditRole && role != Qt::CheckStateRole) {
            return false;
        }

        if (auto task = artifact.dynamicCast<Domain::Task>()) {
            const auto currentTitle = task->title();
            if (role == Qt::EditRole)
                task->setTitle(value.toString());
            else
                task->setDone(value.toInt() == Qt::Checked);

            const auto job = taskRepository()->update(task);
            installHandler(job, tr("Cannot modify task %1 in tag %2").arg(currentTitle).arg(m_tag->name()));
            return true;

        } else if (auto note = artifact.dynamicCast<Domain::Note>()) {
            if (role != Qt::EditRole)
                return false;

            const auto currentTitle = note->title();
            note->setTitle(value.toString());
            const auto job = noteRepository()->save(note);
            installHandler(job, tr("Cannot modify note %1 in tag %2").arg(currentTitle).arg(m_tag->name()));
            return true;

        }

        return false;
    }
```

#### AUTO 


```{c}
auto job = new FakeJob;
```

#### AUTO 


```{c}
auto collectionsJob = m_storage.fetchCollections(Akonadi::Collection::root(), Akonadi::Storage::Recursive);
```

#### AUTO 


```{c}
auto job = m_storage->searchCollections(*searchTerm);
```

#### AUTO 


```{c}
auto noteAction = qobject_cast<QWidgetAction*>(actions.at(1));
```

#### AUTO 


```{c}
auto fetchItemsInAllCollectionsFunction(Akonadi::StorageInterface::Ptr storage) {
        return [storage] (const Domain::LiveQueryInput<Akonadi::Item>::AddFunction &add) {
            auto job = storage->fetchCollections(Akonadi::Collection::root(), Akonadi::Storage::Recursive, Akonadi::Storage::AllContent);
            Utils::JobHandler::install(job->kjob(), [add, job, storage] {
                foreach (const auto &col, job->collections()) {
                    auto itemJob = storage->fetchItems(col);
                    Utils::JobHandler::install(itemJob->kjob(), [add, itemJob] {
                        foreach (const auto &item, itemJob->items())
                            add(item);
                    });
                }
            });
        };
    }
```

#### AUTO 


```{c}
const auto allCollections = m_data->collections();
```

#### AUTO 


```{c}
const auto isInputCollection = [this] (const Collection &collection) {
            return collection.id() == m_collection.id()
                || (!m_collection.remoteId().isEmpty() && collection.remoteId() == m_collection.remoteId());
        };
```

#### AUTO 


```{c}
auto tag2 = Domain::Tag::Ptr::create();
```

#### LAMBDA EXPRESSION 


```{c}
[&] (const QString &string) {
            if (string.isEmpty())
                return Domain::QueryResult<QString>::create(topProvider);
            else if (string == QLatin1String("2"))
                return Domain::QueryResult<QString>::create(firstLevelProvider);
            else if (string == QLatin1String("2.1"))
                return Domain::QueryResult<QString>::create(secondLevelProvider);
            else
                return Domain::QueryResult<QString>::Ptr();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QObjectPtr &object, const QVariant &value, int role) {
        if (role != Qt::EditRole) {
            return false;
        }

        if (object == m_inboxObject
         || object == m_projectsObject
         || object == m_contextsObject
         || object == m_tagsObject) {
            return false;
        }

        if (auto project = object.objectCast<Domain::Project>()) {
            const auto currentName = project->name();
            project->setName(value.toString());
            const auto job = m_projectRepository->update(project);
            installHandler(job, tr("Cannot modify project %1").arg(currentName));
        } else if (auto context = object.objectCast<Domain::Context>()) {
            const auto currentName = context->name();
            context->setName(value.toString());
            const auto job = m_contextRepository->update(context);
            installHandler(job, tr("Cannot modify context %1").arg(currentName));
        } else if (object.objectCast<Domain::Tag>()) {
            return false; // Tag renaming is NOT allowed
        } else {
            Q_ASSERT(false);
        }

        return true;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QMimeData *mimeData, Qt::DropAction, const Domain::Task::Ptr &task) {
        auto parentTask = task.objectCast<Domain::Task>();

        if (!mimeData->hasFormat(QStringLiteral("application/x-zanshin-object")))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                        [](const Domain::Artifact::Ptr &droppedArtifact) {
                            return !droppedArtifact.objectCast<Domain::Task>();
                        })) {
            return false;
        }

        foreach(const auto &droppedArtifact, droppedArtifacts) {
            auto childTask = droppedArtifact.objectCast<Domain::Task>();

            if (parentTask) {
                const auto job = m_taskRepository->associate(parentTask, childTask);
                installHandler(job, i18n("Cannot move task %1 as sub-task of %2", childTask->title(), parentTask->title()));
            } else {
                const auto job = m_taskRepository->dissociate(childTask);
                installHandler(job, i18n("Cannot deparent task %1 from its parent", childTask->title()));
            }
        }

        return true;
    }
```

#### AUTO 


```{c}
auto components = new Widgets::TaskApplicationComponents(widget);
```

#### AUTO 


```{c}
auto font = baseFont;
```

#### AUTO 


```{c}
auto notifiedItem = spy.takeAt(1).takeFirst().value<Akonadi::Item>();
```

#### AUTO 


```{c}
auto fetch = helpers->searchCollections(root, &term);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QObjectPtr &object) -> Domain::QueryResultInterface<QObjectPtr>::Ptr {
        if (!object)
            return Domain::QueryResult<QObjectPtr>::create(m_rootsProvider);
        else if (object == m_tagsObject)
            return Domain::QueryResult<Domain::Tag::Ptr, QObjectPtr>::copy(m_tagQueries->findAll());
        else
            return Domain::QueryResult<QObjectPtr>::Ptr();
    }
```

#### AUTO 


```{c}
auto project = Domain::Project::Ptr::create();
```

#### AUTO 


```{c}
auto job = storage->fetchCollections(item.parentCollection(), StorageInterface::Base);
```

#### AUTO 


```{c}
auto inQuery = Domain::LiveQueryOutput<Domain::DataSource::Ptr>::Ptr();
```

#### LAMBDA EXPRESSION 


```{c}
[repository] (const Domain::Artifact::Ptr &artifact) {
            auto task = artifact.objectCast<Domain::Task>();
            Q_ASSERT(task);
            return repository->update(task);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Domain::Task::Ptr &, int index) {
                                        beginInsertRows(QModelIndex(), index, index);
                                    }
```

#### AUTO 


```{c}
const auto it = m_collectionItems.find(item.parentCollection().id());
```

#### AUTO 


```{c}
auto contextList = extractContexts(todo);
```

#### AUTO 


```{c}
auto predicate = [this] (const Akonadi::Item &item) {
        return m_serializer->isContext(item);
    };
```

#### AUTO 


```{c}
auto dataSource = serializer.createDataSourceFromCollection(originalCollection);
```

#### AUTO 


```{c}
auto query = [this](const Domain::Task::Ptr &task) -> Domain::QueryResultInterface<Domain::Task::Ptr>::Ptr {
        if (!task)
            return m_taskQueries->findTopLevel();
        else
            return m_taskQueries->findChildren(task);
    };
```

#### LAMBDA EXPRESSION 


```{c}
[=] (const Akonadi::Tag &t) {
                       return tag(t.id());
                   }
```

#### AUTO 


```{c}
auto note = inbox.addItem(title).objectCast<Domain::Note>();
```

#### LAMBDA EXPRESSION 


```{c}
[serializer, storage, contentTypes] (const Domain::LiveQueryInput<Item>::AddFunction &add) {
        auto job = storage->fetchCollections(Akonadi::Collection::root(),
                                             StorageInterface::Recursive,
                                             contentTypes);
        Utils::JobHandler::install(job->kjob(), [serializer, storage, job, add] {
            if (job->kjob()->error() != KJob::NoError)
                return;

            foreach (const auto &collection, job->collections()) {
                if (!serializer->isSelectedCollection(collection))
                    continue;

                auto job = storage->fetchItems(collection);
                Utils::JobHandler::install(job->kjob(), [job, add] {
                    if (job->kjob()->error() != KJob::NoError)
                        return;

                    foreach (const auto &item, job->items())
                        add(item);
                });
            }
        });
    }
```

#### AUTO 


```{c}
auto inboxProvider = Domain::QueryResultProvider<Domain::Task::Ptr>::Ptr::create();
```

#### AUTO 


```{c}
auto drop = [this](const QMimeData *mimeData, Qt::DropAction, const QObjectPtr &object) {
        if (!mimeData->hasFormat(QStringLiteral("application/x-zanshin-object")))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                        [](const Domain::Artifact::Ptr &droppedArtifact) {
                            return !droppedArtifact.objectCast<Domain::Note>();
                        })) {
            return false;
        }

        if (auto tag = object.objectCast<Domain::Tag>()) {
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                auto note = droppedArtifact.staticCast<Domain::Note>();
                const auto job = m_tagRepository->associate(tag, note);
                installHandler(job, i18n("Cannot tag %1 with %2", note->title(), tag->name()));
            }
            return true;
        } else if (object == m_inboxObject) {
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                auto note = droppedArtifact.staticCast<Domain::Note>();
                const auto job = m_tagRepository->dissociateAll(note);
                installHandler(job, i18n("Cannot move %1 to Inbox", note->title()));
            }
            return true;
        }

        return false;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[] (const QColor &color) {
            auto mimeData = new QMimeData;
            mimeData->setColorData(QVariant::fromValue(color));
            return mimeData;
        }
```

#### AUTO 


```{c}
auto pageModel = m_currentPage.staticCast<PageModel>();
```

#### AUTO 


```{c}
const auto additionalInfo = index.data(Presentation::QueryTreeModelBase::AdditionalInfoRole).toString();
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QMimeData *mimeData, Qt::DropAction, const Domain::Task::Ptr &parentTask) {
        if (!mimeData->hasFormat(QStringLiteral("application/x-zanshin-object")))
            return false;

        auto droppedTasks = mimeData->property("objects").value<Domain::Task::List>();
        if (droppedTasks.isEmpty())
            return false;

        using namespace std::placeholders;
        auto associate = std::function<KJob*(Domain::Task::Ptr)>();
        auto parentTitle = QString();

        if (parentTask) {
            associate = std::bind(&Domain::TaskRepository::associate, m_taskRepository, parentTask, _1);
            parentTitle = parentTask->title();
        } else {
            associate = std::bind(&Domain::ProjectRepository::associate, m_projectRepository, m_project, _1);
            parentTitle = m_project->name();
        }

        foreach(const Domain::Task::Ptr &childTask, droppedTasks) {
            const auto job = associate(childTask);
            installHandler(job, i18n("Cannot move task %1 as a sub-task of %2", childTask->title(), parentTitle));
        }

        return true;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QMimeData *mimeData, Qt::DropAction, const QObjectPtr &object) {
        if (!mimeData->hasFormat("application/x-zanshin-object"))
            return false;

        auto artifact = mimeData->property("object").value<Domain::Artifact::Ptr>();
        if (!artifact)
            return false;

        auto project = object.objectCast<Domain::Project>();
        if (project) {
            m_projectRepository->associate(project, artifact);
            return true;
        } else if (object == m_inboxObject) {
            auto job = m_projectRepository->dissociate(artifact);
            if (auto task = artifact.objectCast<Domain::Task>()) {
                Utils::JobHandler::install(job, [this, task] {
                    m_taskRepository->dissociate(task);
                });
            }
            return true;
        }

        return false;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, task] (const Akonadi::Item &item) {
        return m_serializer->isTaskChild(task, item);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, task] {
                    m_taskRepository->dissociate(task);
                }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QObjectPtrList &) -> QMimeData* {
        return Q_NULLPTR;
    }
```

#### AUTO 


```{c}
auto goToAction = available.findChild<QAction*>("goToAction");
```

#### AUTO 


```{c}
auto queryGenerator = [&](const Domain::Task::Ptr &task) {
            if (!task)
                return Domain::QueryResult<Domain::Task::Ptr>::create(provider);
            else
                return Domain::QueryResult<Domain::Task::Ptr>::Ptr();
        };
```

#### AUTO 


```{c}
auto collection = m_data->reconstructAncestors(item.parentCollection());
```

#### AUTO 


```{c}
auto artifact = provider->data().at(i);
```

#### AUTO 


```{c}
const auto pastDueDate = dueDate.isValid() && dueDate.date() < QDate::currentDate();
```

#### AUTO 


```{c}
auto fetchFunction = fetchItems();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto item : job->items())
                    add(item);
```

#### AUTO 


```{c}
const auto onStartDate = startDate.isValid() && startDate.date() <= QDate::currentDate();
```

#### AUTO 


```{c}
auto todo3 = KCalCore::Todo::Ptr::create();
```

#### AUTO 


```{c}
auto todo4 = KCalCore::Todo::Ptr::create();
```

#### AUTO 


```{c}
auto job = new Akonadi::CollectionFetchJob(collection, Akonadi::CollectionFetchJob::Base);
```

#### AUTO 


```{c}
auto compositeJob = new CompositeJob();
```

#### AUTO 


```{c}
const auto job = m_tagRepository->dissociate(m_tag, note);
```

#### AUTO 


```{c}
auto item = fetchJob->items().at(0);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto item : job->items()) {
                    if (!isInboxItem(item))
                        continue;

                    auto artifact = deserializeArtifact(item);
                    if (artifact)
                        provider->append(artifact);
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this, &savedArtifact] (const Domain::Artifact::Ptr &artifact) {
            savedArtifact = artifact;
            auto job = new FakeJob(this);
            job->setExpectedError(KJob::KilledJobError, "Foo");
            return job;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[serializer, storage, job, add, parent] {
            if (job->kjob()->error() != KJob::NoError)
                return;

            foreach (const auto &collection, job->collections()) {
                if (!serializer->isSelectedCollection(collection))
                    continue;

                auto job = storage->fetchItems(collection, parent);
                Utils::JobHandler::install(job->kjob(), [job, add] {
                    if (job->kjob()->error() != KJob::NoError)
                        return;

                    foreach (const auto &item, job->items())
                        add(item);
                });
            }
        }
```

#### AUTO 


```{c}
auto tags = job->tags();
```

#### AUTO 


```{c}
const auto email = QInputDialog::getItem(window,
                                             QObject::tr("Choose an identity"),
                                             QObject::tr("Choose the identity to use for the groupware message"),
                                             emails,
                                             defaultIndex,
                                             false);
```

#### AUTO 


```{c}
auto query = [this](const Domain::Artifact::Ptr &artifact) -> Domain::QueryResultInterface<Domain::Artifact::Ptr>::Ptr {
        if (!artifact)
            return m_projectQueries->findTopLevelArtifacts(m_project);
        else if (auto task = artifact.dynamicCast<Domain::Task>())
            return Domain::QueryResult<Domain::Task::Ptr, Domain::Artifact::Ptr>::copy(taskQueries()->findChildren(task));
        else
            return Domain::QueryResult<Domain::Artifact::Ptr>::Ptr();
    };
```

#### AUTO 


```{c}
auto textEdit = editor.findChild<QPlainTextEdit*>(QStringLiteral("textEdit"));
```

#### AUTO 


```{c}
const auto parentId = findParentId(m_collections[collection.id()]);
```

#### LAMBDA EXPRESSION 


```{c}
[cache, toCollectionNames]{
                const auto collections = cache->collections(Akonadi::StorageInterface::AllContent);
                return toCollectionNames(collections);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[storage, contentTypes, searchTerm, root] (const Domain::LiveQueryInput<Collection>::AddFunction &add) {
        if (searchTerm->isEmpty())
            return;

        auto job = storage->searchCollections(*searchTerm, contentTypes);
        Utils::JobHandler::install(job->kjob(), [root, job, add] {
            if (job->kjob()->error())
                return;

            auto directChildren = QHash<Collection::Id, Collection>();
            foreach (const auto &collection, job->collections()) {
                auto directChild = collection;
                while (directChild.parentCollection() != root && directChild.parentCollection().isValid())
                    directChild = directChild.parentCollection();
                if (directChild.parentCollection() != root)
                    continue;
                if (!directChildren.contains(directChild.id()))
                    directChildren[directChild.id()] = directChild;
            }

            foreach (const auto &directChild, directChildren.values())
                add(directChild);
        });
    }
```

#### AUTO 


```{c}
auto tags = m_data->tags();
```

#### AUTO 


```{c}
auto job = storage->createItem(item, calendar2());
```

#### LAMBDA EXPRESSION 


```{c}
[storage, serializer] (const Domain::LiveQueryInput<Akonadi::Item>::AddFunction &add) {
            auto job = storage->fetchCollections(Akonadi::Collection::root(), Akonadi::Storage::Recursive, Akonadi::Storage::AllContent);
            Utils::JobHandler::install(job->kjob(), [add, job, storage, serializer] {
                foreach (const auto &col, job->collections()) {
                    if (!serializer->isSelectedCollection(col))
                        continue;

                    auto itemJob = storage->fetchItems(col);
                    Utils::JobHandler::install(itemJob->kjob(), [add, itemJob] {
                        foreach (const auto &item, itemJob->items())
                            add(item);
                    });
                }
            });
        }
```

#### AUTO 


```{c}
auto repository = Akonadi::TaskRepository::Ptr::create();
```

#### AUTO 


```{c}
auto setData = [this] (const Domain::Artifact::Ptr &artifact, const QVariant &value, int role) {
        if (role != Qt::EditRole && role != Qt::CheckStateRole) {
            return false;
        }

        if (auto task = artifact.dynamicCast<Domain::Task>()) {
            if (role == Qt::EditRole)
                task->setTitle(value.toString());
            else
                task->setDone(value.toInt() == Qt::Checked);

            taskRepository()->update(task);
            return true;

        } else if (auto note = artifact.dynamicCast<Domain::Note>()) {
            if (role != Qt::EditRole)
                return false;

            note->setTitle(value.toString());
            noteRepository()->save(note);
            return true;

        }

        return false;
    };
```

#### AUTO 


```{c}
auto startMode = startModeForParent(parent);
```

#### AUTO 


```{c}
auto task = serializer.createTaskFromItem(item);
```

#### AUTO 


```{c}
auto note = artifact.dynamicCast<Domain::Note>()
```

#### AUTO 


```{c}
const auto collection = Akonadi::Collection(GenCollection().withId(42).withRootAsParent().withName(QStringLiteral("folder")).withTaskContent());
```

#### AUTO 


```{c}
const auto data = index.data(Presentation::QueryTreeModelBase::ObjectRole);
```

#### LAMBDA EXPRESSION 


```{c}
[] (const Domain::DataSource::Ptr &source) {
        Q_UNUSED(source)
        return Qt::ItemIsSelectable
             | Qt::ItemIsEnabled;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Domain::Artifact::Ptr &artifact) -> Domain::QueryResultInterface<Domain::Artifact::Ptr>::Ptr {
        if (!artifact)
            return Domain::QueryResult<Domain::Task::Ptr, Domain::Artifact::Ptr>::copy(m_taskQueries->findWorkdayTopLevel());
        else if (auto task = artifact.dynamicCast<Domain::Task>())
            return Domain::QueryResult<Domain::Task::Ptr, Domain::Artifact::Ptr>::copy(m_taskQueries->findChildren(task));
        else
            return Domain::QueryResult<Domain::Artifact::Ptr>::Ptr();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=] () mutable {
            std::transform(items.constBegin(), items.constEnd(),
                           items.begin(),
                           [=] (const Akonadi::Item &item) {
                               auto result = item;
                               result.setParentCollection(collection);
                               // Force payload detach
                               result.setPayloadFromData(result.payloadData());
                               return result;
                           });

            foreach (const Akonadi::Item &item, items) {
                m_data->modifyItem(item);
            }
        }
```

#### AUTO 


```{c}
auto taskAction = qobject_cast<QWidgetAction*>(actions.at(0));
```

#### AUTO 


```{c}
auto roleNames = model()->roleNames();
```

#### AUTO 


```{c}
auto delegate = new DataSourceDelegate(sourcesView);
```

#### AUTO 


```{c}
const auto currentTitle = m_task->title();
```

#### AUTO 


```{c}
const auto parentData = parentIndex.data(QueryTreeModelBase::ObjectRole);
```

#### LAMBDA EXPRESSION 


```{c}
[] (const QList<QColor> &) -> QMimeData* {
            return nullptr;
        }
```

#### AUTO 


```{c}
auto context2 = Domain::Context::Ptr::create();
```

#### AUTO 


```{c}
auto drag = [](const Domain::Artifact::List &artifacts) -> QMimeData* {
        if (artifacts.isEmpty())
            return Q_NULLPTR;

        auto data = new QMimeData;
        data->setData("application/x-zanshin-object", "object");
        data->setProperty("objects", QVariant::fromValue(artifacts));
        return data;
    };
```

#### AUTO 


```{c}
auto job = storage->updateTag(tag);
```

#### AUTO 


```{c}
auto answer = QMessageBox::question(this,
                                            i18n("Multiple Agent Deletion"),
                                            i18n("Do you really want to delete the selected agent instances?"),
                                            QMessageBox::Yes | QMessageBox::No,
                                            QMessageBox::No);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QMimeData *mimeData, Qt::DropAction, const QObjectPtr &object) {
        if (!mimeData->hasFormat(QStringLiteral("application/x-zanshin-object")))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (auto project = object.objectCast<Domain::Project>()) {
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                const auto job = m_projectRepository->associate(project, droppedArtifact);
                installHandler(job, i18n("Cannot add %1 to project %2", droppedArtifact->title(), project->name()));
            }
            return true;
        } else if (auto context = object.objectCast<Domain::Context>()) {
            if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                            [](const Domain::Artifact::Ptr &droppedArtifact) {
                                return !droppedArtifact.objectCast<Domain::Task>();
                            })) {
                return false;
            }
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                auto task = droppedArtifact.staticCast<Domain::Task>();
                const auto job = m_contextRepository->associate(context, task);
                installHandler(job, i18n("Cannot add %1 to context %2", task->title(), context->name()));
            }
            return true;
        } else if (object == m_inboxObject) {
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                const auto job = m_projectRepository->dissociate(droppedArtifact);
                installHandler(job, i18n("Cannot move %1 to Inbox", droppedArtifact->title()));

                if (auto task = droppedArtifact.objectCast<Domain::Task>()) {
                    Utils::JobHandler::install(job, [this, task] {
                        const auto dissociateJob = m_taskRepository->dissociateAll(task);
                        installHandler(dissociateJob, i18n("Cannot move task %1 to Inbox", task->title()));
                    });
                }
            }
            return true;
        } else if (object == m_workdayObject) {
            foreach (const auto &droppedArtifact, droppedArtifacts) {

                if (auto task = droppedArtifact.objectCast<Domain::Task>()) {

                    task->setStartDate(Utils::DateTime::currentDate());
                    const auto job = m_taskRepository->update(task);

                    installHandler(job, i18n("Cannot update task %1 to Workday", task->title()));
                }
            }
            return true;
        }

        return false;
    }
```

#### AUTO 


```{c}
auto sourceIndex = Zanshin::findIndex(model(), sourceName);
```

#### AUTO 


```{c}
const auto rightArtifact = right.data(QueryTreeModelBase::ObjectRole).value<Domain::Artifact::Ptr>();
```

#### AUTO 


```{c}
auto job = new Akonadi::ItemFetchJob(item);
```

#### AUTO 


```{c}
auto setData = [this] (const Domain::DataSource::Ptr &source, const QVariant &value, int role) {
        if (role != Qt::CheckStateRole)
            return false;
        if (source->contentTypes() == Domain::DataSource::NoContent)
            return false;

        source->setSelected(value.toInt() == Qt::Checked);
        const auto job = m_dataSourceRepository->update(source);
        installHandler(job, i18n("Cannot modify source %1", source->name()));
        return true;
    };
```

#### AUTO 


```{c}
auto task = serializer.createTaskFromItem(originalItem);
```

#### AUTO 


```{c}
auto delegateLabel = editor.findChild<QLabel*>("delegateLabel");
```

#### AUTO 


```{c}
auto reconstructedParent = reconstructAncestors(m_collections.value(parent.id()), root);
```

#### AUTO 


```{c}
auto task = serializer->createTaskFromItem(data.item(42));
```

#### AUTO 


```{c}
auto artifact = mimeData->property("object").value<Domain::Artifact::Ptr>();
```

#### AUTO 


```{c}
auto drop = [this] (const QMimeData *mimeData, Qt::DropAction, const Domain::Artifact::Ptr &artifact) {
        auto parentTask = artifact.objectCast<Domain::Task>();
        if (!parentTask)
            return false;

        if (!mimeData->hasFormat("application/x-zanshin-object"))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                        [](const Domain::Artifact::Ptr &droppedArtifact) {
                            return !droppedArtifact.objectCast<Domain::Task>();
                        })) {
            return false;
        }

        foreach(const Domain::Artifact::Ptr &droppedArtifact, droppedArtifacts) {
            auto childTask = droppedArtifact.objectCast<Domain::Task>();
            taskRepository()->associate(parentTask, childTask);
        }

        return true;
    };
```

#### AUTO 


```{c}
const auto taskCollection1 = Akonadi::Collection(GenCollection().withRootAsParent()
                                                                        .withId(1)
                                                                        .withName("tasks1")
                                                                        .withTaskContent());
```

#### AUTO 


```{c}
auto dialogStub = NewPageDialogStub::Ptr::create();
```

#### AUTO 


```{c}
auto dataFunction = [] (const QString &, int, int) {
            return QVariant();
        };
```

#### AUTO 


```{c}
auto fetchItemsInSelectedCollectionsFunction(Akonadi::StorageInterface::Ptr storage, Akonadi::SerializerInterface::Ptr serializer)
    {
        return [storage, serializer] (const Domain::LiveQueryInput<Akonadi::Item>::AddFunction &add) {
            auto job = storage->fetchCollections(Akonadi::Collection::root(), Akonadi::Storage::Recursive);
            Utils::JobHandler::install(job->kjob(), [add, job, storage, serializer] {
                foreach (const auto &col, job->collections()) {
                    if (!serializer->isSelectedCollection(col))
                        continue;

                    auto itemJob = storage->fetchItems(col, nullptr);
                    Utils::JobHandler::install(itemJob->kjob(), [add, itemJob] {
                        foreach (const auto &item, itemJob->items())
                            add(item);
                    });
                }
            });
        };
    }
```

#### AUTO 


```{c}
auto window = new KXmlGuiWindow;
```

#### AUTO 


```{c}
auto tags = Akonadi::Tag::List();
```

#### AUTO 


```{c}
const auto ids = m_collectionItems.value(collection.id());
```

#### AUTO 


```{c}
auto movedItem = spyMoved.takeFirst().takeFirst().value<Akonadi::Item>();
```

#### LAMBDA EXPRESSION 


```{c}
[fetchCollectionJob, item, job, this] {
                if (fetchCollectionJob->kjob()->error() != KJob::NoError)
                    return;

                Q_ASSERT(fetchCollectionJob->collections().size() > 0);
                const Akonadi::Collection::List collections = fetchCollectionJob->collections();
                Akonadi::Collection col = *std::find_if(collections.constBegin(), collections.constEnd(),
                                                        [] (const Akonadi::Collection &c) {
                                                            return c.rights() == Akonadi::Collection::AllRights;
                                                        });
                Q_ASSERT(col.isValid());
                auto createJob = m_storage->createItem(item, col);
                job->addSubjob(createJob);
                createJob->start();
            }
```

#### AUTO 


```{c}
auto addItemAction = new QAction(this);
```

#### AUTO 


```{c}
auto notifiedCollection = spy.takeFirst().at(0).value<Akonadi::Collection>();
```

#### AUTO 


```{c}
auto parentId = project->property("parentCollectionId").value<Akonadi::Collection::Id>();
```

#### AUTO 


```{c}
auto repository = new TaskRepository(StorageInterface::Ptr(new Storage),
                                         SerializerInterface::Ptr(new Serializer),
                                         MessagingInterface::Ptr());
```

#### LAMBDA EXPRESSION 


```{c}
[=] () mutable {
            if (!job->error()) {
                item.setParentCollection(collection);
                // Force payload detach
                item.setPayloadFromData(item.payloadData());
                m_data->modifyItem(item);
            }
        }
```

#### AUTO 


```{c}
auto topLevelResult = Domain::QueryResult<Domain::Task::Ptr>::create(topLevelProvider);
```

#### AUTO 


```{c}
auto query = [this](const QObjectPtr &object) -> Domain::QueryResultInterface<QObjectPtr>::Ptr {
        if (!object)
            return Domain::QueryResult<QObjectPtr>::create(m_rootsProvider);
        else if (object == m_projectsObject)
            return Domain::QueryResult<Domain::DataSource::Ptr, QObjectPtr>::copy(m_dataSourceQueries->findAllSelected());
        else if (object == m_contextsObject)
            return Domain::QueryResult<Domain::Context::Ptr, QObjectPtr>::copy(m_contextQueries->findAll());
        else if (const auto source = object.objectCast<Domain::DataSource>())
            return Domain::QueryResult<Domain::Project::Ptr, QObjectPtr>::copy(m_dataSourceQueries->findProjects(source));
        else
            return Domain::QueryResult<QObjectPtr>::Ptr();
    };
```

#### LAMBDA EXPRESSION 


```{c}
[relatedUid, this] (const Akonadi::Item &item) {
                    // TODO Qt5: This is a bit wasteful, add an itemUid on the serializer
                    auto task = m_serializer->createTaskFromItem(item);
                    return task && m_serializer->objectUid(task) == relatedUid;
                }
```

#### AUTO 


```{c}
const auto artifact = currentArtifact();
```

#### LAMBDA EXPRESSION 


```{c}
[] (Utils::DependencyManager *) {
            return new Presentation::RunningTaskModel(Domain::TaskQueries::Ptr(),
                                                      Domain::TaskRepository::Ptr());
        }
```

#### AUTO 


```{c}
const auto createdTask = page.addItem(title, parentIndex);
```

#### LAMBDA EXPRESSION 


```{c}
[this, itemsRemoved](Akonadi::Item::List result, Akonadi::Item currentItem) {
                                     result << currentItem;
                                     return result += filterDescendantItems(itemsRemoved, currentItem);
                                 }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &collection : collections) {
        auto parent = collection.parentCollection();
        while (parent != Akonadi::Collection::root()) {
            QVERIFY(parent.isValid());
            QVERIFY(!parent.displayName().isEmpty());
            parent = parent.parentCollection();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[fetchJob, job, this] {
        if (fetchJob->kjob()->error() != KJob::NoError)
           return;

        Q_ASSERT(fetchJob->items().size() == 1);
        auto item = fetchJob->items().at(0);
        m_serializer->promoteItemToProject(item);

        auto updateJob = m_storage->updateItem(item);
        job->addSubjob(updateJob);
        updateJob->start();
    }
```

#### AUTO 


```{c}
auto inboxPageModel = new InboxPageModel(m_taskQueries,
                                                 m_taskRepository,
                                                 this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &collection : collections) {
        collectionNames << collection.name();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QObjectPtr &object, const QVariant &value, int role) {
        if (role != Qt::EditRole) {
            return false;
        }

        if (object == m_inboxObject
         || object == m_workdayObject
         || object == m_projectsObject
         || object == m_contextsObject) {
            return false;
        }

        if (auto project = object.objectCast<Domain::Project>()) {
            const auto currentName = project->name();
            project->setName(value.toString());
            const auto job = m_projectRepository->update(project);
            installHandler(job, i18n("Cannot modify project %1", currentName));
        } else if (auto context = object.objectCast<Domain::Context>()) {
            const auto currentName = context->name();
            context->setName(value.toString());
            const auto job = m_contextRepository->update(context);
            installHandler(job, i18n("Cannot modify context %1", currentName));
        } else {
            Q_ASSERT(false);
        }

        return true;
    }
```

#### AUTO 


```{c}
auto setData = [this](const Domain::Task::Ptr &task, const QVariant &value, int role) {
        if (role != Qt::EditRole && role != Qt::CheckStateRole) {
            return false;
        }

        const auto currentTitle = task->title();
        if (role == Qt::EditRole)
            task->setTitle(value.toString());
        else
            task->setDone(value.toInt() == Qt::Checked);

        const auto job = m_taskRepository->update(task);
        installHandler(job, tr("Cannot modify task %1 in Inbox").arg(currentTitle));
        return true;
    };
```

#### AUTO 


```{c}
auto drop = [this](const QMimeData *mimeData, Qt::DropAction, const QObjectPtr &object) {
        if (!mimeData->hasFormat("application/x-zanshin-object"))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (auto project = object.objectCast<Domain::Project>()) {
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                m_projectRepository->associate(project, droppedArtifact);
            }
            return true;
        } else if (auto context = object.objectCast<Domain::Context>()) {
            if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                            [](const Domain::Artifact::Ptr &droppedArtifact) {
                                return !droppedArtifact.objectCast<Domain::Task>();
                            })) {
                return false;
            }

            foreach (const auto &droppedArtifact, droppedArtifacts) {
                auto task = droppedArtifact.staticCast<Domain::Task>();
                m_contextRepository->associate(context, task);
            }
            return true;
        } else if (object == m_inboxObject) {
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                auto job = m_projectRepository->dissociate(droppedArtifact);
                if (auto task = droppedArtifact.objectCast<Domain::Task>()) {
                    Utils::JobHandler::install(job, [this, task] {
                        m_taskRepository->dissociate(task);
                    });
                }
            }
            return true;
        }

        return false;
    };
```

#### AUTO 


```{c}
const auto job = m_noteRepository->createInTag(note, m_tag);
```

#### AUTO 


```{c}
const auto oldParentId = findParentId(m_items[item.id()]);
```

#### AUTO 


```{c}
auto inboxPageModel = new NoteInboxPageModel(m_noteQueries,
                                                     m_noteRepository,
                                                     this);
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Akonadi::Item &item) {
                       auto result = m_data->reconstructItemDependencies(item);
                       // Force payload detach
                       result.setPayloadFromData(result.payloadData());
                       return result;
                   }
```

#### AUTO 


```{c}
const auto items2 = Akonadi::Item::List() << Akonadi::Item(GenTodo().withId(3).withTitle("item3"))
                                                  << Akonadi::Item(GenTodo().withId(4).withTitle("item4"));
```

#### AUTO 


```{c}
auto monitor = MockMonitor::Ptr::create();
```

#### AUTO 


```{c}
auto flags = [this](const QObjectPtr &object) {
        const Qt::ItemFlags defaultFlags = Qt::ItemIsSelectable
                                         | Qt::ItemIsEnabled
                                         | Qt::ItemIsEditable
                                         | Qt::ItemIsDropEnabled;
        const Qt::ItemFlags immutableNodeFlags = Qt::ItemIsSelectable
                                               | Qt::ItemIsEnabled
                                               | Qt::ItemIsDropEnabled;
        const Qt::ItemFlags structureNodeFlags = Qt::NoItemFlags;

        return object.objectCast<Domain::Project>() ? defaultFlags
             : object.objectCast<Domain::Context>() ? defaultFlags
             : object.objectCast<Domain::Tag>() ? defaultFlags
             : object == m_inboxObject ? immutableNodeFlags
             : object == m_workdayObject ? immutableNodeFlags
             : structureNodeFlags;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const QString &s) -> QObject* {
            bool ok = false;
            const int id = s.toInt(&ok);
            if (ok) {
                auto object = new QObject(this);
                object->setProperty("id", id);
                return object;
            } else {
                return Q_NULLPTR;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Akonadi::Item &item) {
            if (!m_serializer->isTaskItem(item))
                return false;

            const Domain::Task::Ptr task = m_serializer->createTaskFromItem(item);
            const QDate startDate = task->startDate().date();
            const QDate dueDate = task->dueDate().date();
            const QDate today = Utils::DateTime::currentDateTime().date();

            const bool pastStartDate = startDate.isValid() && startDate <= today;
            const bool pastDueDate = dueDate.isValid() && dueDate <= today;

            return ((pastStartDate || pastDueDate) && !task->isDone());
        }
```

#### AUTO 


```{c}
auto datesHBox = new QHBoxLayout;
```

#### AUTO 


```{c}
const auto data = current.data(Presentation::QueryTreeModelBase::ObjectRole);
```

#### AUTO 


```{c}
auto availablePagesTreeView = availablePageView->findChild<QTreeView*>("pagesView");
```

#### AUTO 


```{c}
auto fetch = helpers->fetchCollections(root, contentTypes);
```

#### AUTO 


```{c}
auto inPredicate = [] (const Akonadi::Tag &tag) {
            return tag.name().endsWith(QLatin1String("-in"));
        };
```

#### AUTO 


```{c}
auto job = storage.fetchCollections(rootCollection, fetchDepth, contentTypes);
```

#### LAMBDA EXPRESSION 


```{c}
[](const Akonadi::Item::List &items) {
            auto res = QVector<Akonadi::Item::Id>();
            std::transform(items.cbegin(), items.cend(),
                           std::back_inserter(res),
                           std::mem_fn(&Akonadi::Item::id));
            std::sort(res.begin(), res.end());
            return res;
        }
```

#### AUTO 


```{c}
auto task2 = model->data(task2Index, Presentation::QueryTreeModelBase::ObjectRole).value<Domain::Task::Ptr>();
```

#### LAMBDA EXPRESSION 


```{c}
[allowedMimeTypes] (const Collection &collection) {
                                                auto mimeTypes = collection.contentMimeTypes().toSet();
                                                return !mimeTypes.intersects(allowedMimeTypes);
                                             }
```

#### LAMBDA EXPRESSION 


```{c}
[] (const Akonadi::Item &contextItem) {
            auto todo = contextItem.payload<KCalCore::Todo::Ptr>();
            return todo->summary().endsWith(QLatin1String("-ex"));
        }
```

#### AUTO 


```{c}
auto actualNames = QStringList();
```

#### AUTO 


```{c}
auto it = pageGlobalActions.cbegin();
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &, const QVariant &, int) {
            return false;
        }
```

#### AUTO 


```{c}
auto query = TaskQueries::TaskQuery::Ptr::create();
```

#### LAMBDA EXPRESSION 


```{c}
[provider, job, task, this] {
        Q_ASSERT(job->items().size() == 1);
        auto item = job->items()[0];
        Q_ASSERT(item.parentCollection().isValid());
        ItemFetchJobInterface *job = m_storage->fetchItems(item.parentCollection());
        Utils::JobHandler::install(job->kjob(), [provider, job, task, this] {
            for (auto item : job->items()) {
                if (m_serializer->isTaskChild(task, item)) {
                    auto task = deserializeTask(item);
                    if (task)
                        provider->append(task);
                }
            }
        });
    }
```

#### AUTO 


```{c}
auto addAction = page.findChild<QAction*>(QStringLiteral("addItemAction"));
```

#### AUTO 


```{c}
const auto baseColor = opt.palette.color(colorGroup, colorRole);
```

#### AUTO 


```{c}
auto items = m_data->items();
```

#### AUTO 


```{c}
auto job = new FakeJob(parent);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Domain::DataSource::Ptr &, int idx) {
                                         emit dataChanged(index(idx), index(idx));
                                     }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QObjectPtrList &) -> QMimeData* {
        return nullptr;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[] (const Akonadi::Collection &col) {
                                     const auto mime = col.contentMimeTypes();
                                     return !mime.contains(KCalCore::Todo::todoMimeType());
                                 }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto collection : job->collections()) {
                    ItemFetchJobInterface *job = m_storage->fetchItems(collection);
                    Utils::JobHandler::install(job->kjob(), [this, job, add] {
                        if (job->kjob()->error() != KJob::NoError)
                            return;

                        for (auto item : job->items()) {
                            add(item);
                        }
                    });
                }
```

#### AUTO 


```{c}
const auto bogusMimeTypes = QStringList() << QStringLiteral("foo/bar");
```

#### RANGE FOR STATEMENT 


```{c}
for (auto provider : providers) {
        if (!provider)
            continue;

        for (int i = 0; i < provider->data().size(); i++) {
            auto dataSource = provider->data().at(i);
            if (m_serializer->representsCollection(dataSource, collection)) {
                provider->removeAt(i);
                i--;
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const Domain::Artifact::Ptr &droppedArtifact) {
                                return !droppedArtifact.objectCast<Domain::Task>();
                            }
```

#### AUTO 


```{c}
auto jobDelete = storage->removeTag(tag);
```

#### LAMBDA EXPRESSION 


```{c}
[](const QColor &, int) {
            return QVariant();
        }
```

#### AUTO 


```{c}
auto fetch = m_helpers->fetchItems();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto item : job->items()) {
                    auto note = deserializeNote(item);
                    if (note)
                        provider->append(note);
                }
```

#### LAMBDA EXPRESSION 


```{c}
[fetchItemJob, parent, job, this] {
        if (fetchItemJob->kjob()->error() != KJob::NoError)
           return;

        Q_ASSERT(fetchItemJob->items().size() == 1);
        auto childItem = fetchItemJob->items().first();
        m_serializer->updateItemParent(childItem, parent);
        auto updateJob = m_storage->updateItem(childItem);
        job->addSubjob(updateJob);
        updateJob->start();
    }
```

#### AUTO 


```{c}
auto result = queries->findTopLevelTasks(context);
```

#### AUTO 


```{c}
auto parentIndex = QModelIndex();
```

#### AUTO 


```{c}
auto query = TagQueries::ArtifactQuery::Ptr::create();
```

#### AUTO 


```{c}
auto m = m_presentation->property("centralListModel").value<QAbstractItemModel*>();
```

#### AUTO 


```{c}
auto sourceRepository = Domain::DataSourceRepository::Ptr();
```

#### AUTO 


```{c}
auto task = workday.addTask(title);
```

#### AUTO 


```{c}
auto job = m_storage->fetchCollections(Akonadi::Collection::root(),
                                                   Akonadi::StorageInterface::Recursive,
                                                   this);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto collection : collections) {
            collectionsMap[collection.id()] = collection;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[query] (const Domain::DataSource::Ptr &source) {
              if (source)
                  return Domain::QueryResultInterface<Domain::DataSource::Ptr>::Ptr();
              else
                  return query();
          }
```

#### LAMBDA EXPRESSION 


```{c}
[=] {
            if (!job->error()) {
                m_data->removeCollection(collection);
            }
        }
```

#### AUTO 


```{c}
const auto note = Akonadi::Collection(GenCollection(none).withNoteContent());
```

#### AUTO 


```{c}
auto dissociate = std::function<KJob*(Domain::Task::Ptr)>();
```

#### AUTO 


```{c}
auto actionBar = new QToolBar(this);
```

#### AUTO 


```{c}
auto expectedIndex = Zanshin::findIndex(model(), expectedName);
```

#### LAMBDA EXPRESSION 


```{c}
[this, item] (const ArtifactQuery::AddFunction &add) {
            CollectionFetchJobInterface *job = m_storage->fetchCollections(Akonadi::Collection::root(),
                                                                           StorageInterface::Recursive,
                                                                           StorageInterface::Tasks | StorageInterface::Notes);
            Utils::JobHandler::install(job->kjob(), [this, job, add] {
                if (job->kjob()->error() != KJob::NoError)
                    return;

                for (auto collection : job->collections()) {
                    ItemFetchJobInterface *job = m_storage->fetchItems(collection);
                    Utils::JobHandler::install(job->kjob(), [this, job, add] {
                        if (job->kjob()->error() != KJob::NoError)
                            return;

                        for (auto item : job->items())
                            add(item);
                    });
                }
            });
        }
```

#### AUTO 


```{c}
auto job = storage.searchCollections(name);
```

#### AUTO 


```{c}
const auto job = parentTask ? m_taskRepository->createChild(task, parentTask)
                   : m_taskRepository->createInProject(task, m_project);
```

#### LAMBDA EXPRESSION 


```{c}
[this, queries, model](const Domain::Task::Ptr &task, int index) {
                                        Node *node = new Node(task, this, queries, model);
                                        insertChild(index, node);
                                        model->beginInsertRows(model->createIndex(row(), 0, this), index, index);
                                    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, taskItemId] (const Akonadi::Item &contextItem) {
        auto context = m_serializer->createContextFromItem(contextItem);
        if (!context)
            return false;

        const auto taskItem = m_findContextsItem[taskItemId];
        return m_serializer->isContextChild(context, taskItem);
    }
```

#### AUTO 


```{c}
const auto job = m_contextRepository->dissociate(m_context, task);
```

#### LAMBDA EXPRESSION 


```{c}
[] (const Domain::Task::List &tasks) -> QMimeData* {
        if (tasks.isEmpty())
            return nullptr;

        auto data = new QMimeData();
        data->setData(QStringLiteral("application/x-zanshin-object"), "object");
        data->setProperty("objects", QVariant::fromValue(tasks));
        return data;
    }
```

#### AUTO 


```{c}
auto t2 = Akonadi::Tag(t1.id());
```

#### AUTO 


```{c}
auto dataSource4 = serializer.createDataSourceFromCollection(collection, Akonadi::SerializerInterface::BaseName);
```

#### AUTO 


```{c}
auto partialParentItem = m_serializer->createItemFromTask(parent);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Domain::Task::Ptr &task, const QVariant &value, int role) {
        if (role != Qt::EditRole && role != Qt::CheckStateRole) {
            return false;
        }

        const auto currentTitle = task->title();
        if (role == Qt::EditRole)
            task->setTitle(value.toString());
        else
            task->setDone(value.toInt() == Qt::Checked);

        const auto job = m_taskRepository->update(task);
        installHandler(job, i18n("Cannot modify task %1 in Inbox", currentTitle));
        return true;
    }
```

#### AUTO 


```{c}
auto self = const_cast<CollectionSearchJob*>(this);
```

#### AUTO 


```{c}
auto job = storage->fetchItem(item);
```

#### AUTO 


```{c}
const auto dataSourceInfo = index.data(Presentation::QueryTreeModelBase::DataSourceRole);
```

#### AUTO 


```{c}
auto task = workday.addItem(title).objectCast<Domain::Task>();
```

#### LAMBDA EXPRESSION 


```{c}
[] (Domain::Task::Ptr) -> KJob* { return Q_NULLPTR; }
```

#### AUTO 


```{c}
auto drop = [this](const QMimeData *mimeData, Qt::DropAction, const QObjectPtr &object) {
        if (!mimeData->hasFormat("application/x-zanshin-object"))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (auto project = object.objectCast<Domain::Project>()) {
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                const auto job = m_projectRepository->associate(project, droppedArtifact);
                installHandler(job, tr("Cannot add %1 to project %2").arg(droppedArtifact->title()).arg(project->name()));
            }
            return true;
        } else if (auto context = object.objectCast<Domain::Context>()) {
            if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                            [](const Domain::Artifact::Ptr &droppedArtifact) {
                                return !droppedArtifact.objectCast<Domain::Task>();
                            })) {
                return false;
            }
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                auto task = droppedArtifact.staticCast<Domain::Task>();
                const auto job = m_contextRepository->associate(context, task);
                installHandler(job, tr("Cannot add %1 to context %2").arg(task->title()).arg(context->name()));
            }
            return true;
        } else if (auto tag = object.objectCast<Domain::Tag>()) {
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                const auto job = m_tagRepository->associate(tag, droppedArtifact);
                installHandler(job, tr("Cannot tag %1 with %2").arg(droppedArtifact->title()).arg(tag->name()));
            }
            return true;
        } else if (object == m_inboxObject) {
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                const auto job = m_projectRepository->dissociate(droppedArtifact);
                installHandler(job, tr("Cannot move %1 to Inbox").arg(droppedArtifact->title()));

                if (auto task = droppedArtifact.objectCast<Domain::Task>()) {
                    Utils::JobHandler::install(job, [this, task] {
                        const auto dissociateJob = m_taskRepository->dissociate(task);
                        installHandler(dissociateJob, tr("Cannot move task %1 to Inbox").arg(task->title()));
                    });
                }
            }
            return true;
        } else if (object == m_workdayObject) {
            foreach (const auto &droppedArtifact, droppedArtifacts) {

                if (auto task = droppedArtifact.objectCast<Domain::Task>()) {

                    task->setStartDate(Utils::DateTime::currentDateTime());
                    const auto job = m_taskRepository->update(task);

                    installHandler(job, tr("Cannot update task %1 to Workday").arg(task->title()));
                }
            }
            return true;
        }

        return false;
    };
```

#### AUTO 


```{c}
auto expectedTitiNames = QStringList();
```

#### AUTO 


```{c}
auto akonadiTag = Akonadi::Tag();
```

#### AUTO 


```{c}
auto editor = static_cast<Presentation::EditorModel*>(app.editor());
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QMimeData *mimeData, Qt::DropAction, const Domain::Task::Ptr &parentTask) {
        if (!mimeData->hasFormat(QStringLiteral("application/x-zanshin-object")))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                        [](const Domain::Artifact::Ptr &droppedArtifact) {
                            return !droppedArtifact.objectCast<Domain::Task>();
                        })) {
            return false;
        }

        using namespace std::placeholders;
        auto associate = std::function<KJob*(Domain::Task::Ptr)>();
        auto parentTitle = QString();

        if (parentTask) {
            associate = std::bind(&Domain::TaskRepository::associate, m_taskRepository, parentTask, _1);
            parentTitle = parentTask->title();
        } else {
            associate = std::bind(&Domain::ProjectRepository::associate, m_projectRepository, m_project, _1);
            parentTitle = m_project->name();
        }

        foreach(const Domain::Artifact::Ptr &droppedArtifact, droppedArtifacts) {
            auto childTask = droppedArtifact.objectCast<Domain::Task>();
            const auto job = associate(childTask);
            installHandler(job, i18n("Cannot move task %1 as a sub-task of %2", childTask->title(), parentTitle));
        }

        return true;
    }
```

#### AUTO 


```{c}
auto configureButton = new QToolButton(widget);
```

#### AUTO 


```{c}
auto parameters = spy.takeFirst();
```

#### AUTO 


```{c}
auto project2Result = Domain::QueryResult<Domain::Project::Ptr>::create(project2Provider);
```

#### AUTO 


```{c}
auto index = m_pagesView->indexBelow(m_pagesView->currentIndex());
```

#### AUTO 


```{c}
auto item = Akonadi::Item(44);
```

#### AUTO 


```{c}
const auto taskItemId = taskItem.id();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &collection : collections) {
            collectionNames << collection.name();
        }
```

#### AUTO 


```{c}
auto result = weakResult.toStrongRef();
```

#### AUTO 


```{c}
auto model = new ArtifactEditorModel(m_taskRepository, m_noteRepository, this);
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Domain::Artifact::Ptr &artifact, const QVariant &value, int role) {
        if (role != Qt::EditRole && role != Qt::CheckStateRole) {
            return false;
        }

        if (auto task = artifact.dynamicCast<Domain::Task>()) {
            const auto currentTitle = task->title();
            if (role == Qt::EditRole)
                task->setTitle(value.toString());
            else
                task->setDone(value.toInt() == Qt::Checked);

            const auto job = m_taskRepository->update(task);
            installHandler(job, tr("Cannot modify task %1 in tag %2").arg(currentTitle).arg(m_tag->name()));
            return true;

        } else if (auto note = artifact.dynamicCast<Domain::Note>()) {
            if (role != Qt::EditRole)
                return false;

            const auto currentTitle = note->title();
            note->setTitle(value.toString());
            const auto job = m_noteRepository->update(note);
            installHandler(job, tr("Cannot modify note %1 in tag %2").arg(currentTitle).arg(m_tag->name()));
            return true;

        }

        return false;
    }
```

#### AUTO 


```{c}
auto model = Utils::DependencyManager::globalInstance().create<ArtifactEditorModel>();
```

#### AUTO 


```{c}
const auto ids = m_childCollections.value(parentId);
```

#### AUTO 


```{c}
auto note = item.payload<KMime::Message::Ptr>();
```

#### AUTO 


```{c}
const auto colorRole = (isSelected && !isEditing) ? QPalette::HighlightedText : QPalette::Text;
```

#### AUTO 


```{c}
auto futureAction = page.findChild<QAction*>(QStringLiteral("futureViewAction"));
```

#### LAMBDA EXPRESSION 


```{c}
[](const Domain::Context::Ptr &context) { return context->name(); }
```

#### AUTO 


```{c}
auto data = [] (const Domain::DataSource::Ptr &source, int role) -> QVariant {
        if (role != Qt::DisplayRole
         && role != Qt::EditRole
         && role != Qt::DecorationRole
         && role != Qt::CheckStateRole
         && role != QueryTreeModelBase::IconNameRole) {
            return QVariant();
        }

        if (role == Qt::DisplayRole || role == Qt::EditRole) {
            return source->name();
        } else if (role == Qt::DecorationRole || role == QueryTreeModelBase::IconNameRole) {
            const QString iconName = source->iconName().isEmpty() ? "folder" : source->iconName();

            if (role == Qt::DecorationRole)
                return QVariant::fromValue(QIcon::fromTheme(iconName));
            else
                return iconName;
        } else if (role == Qt::CheckStateRole) {
            if (source->contentTypes() != Domain::DataSource::NoContent)
                return source->isSelected() ? Qt::Checked : Qt::Unchecked;
            else
                return QVariant();
        } else {
            return QVariant();
        }
    };
```

#### AUTO 


```{c}
auto context2 = serializer->createContextFromTag(data.tag(43));
```

#### AUTO 


```{c}
auto job = m_storage->fetchCollections(Collection::root(), StorageInterface::Recursive, contentTypes);
```

#### LAMBDA EXPRESSION 


```{c}
[](const Domain::Task::Ptr &) {
        return Qt::ItemIsSelectable
             | Qt::ItemIsEnabled
             | Qt::ItemIsEditable
             | Qt::ItemIsUserCheckable;
    }
```

#### AUTO 


```{c}
auto save = [this, &savedArtifact] (const Domain::Artifact::Ptr &artifact) {
            savedArtifact = artifact;
            auto job = new FakeJob(this);
            job->setExpectedError(KJob::KilledJobError, QStringLiteral("Foo"));
            return job;
        };
```

#### AUTO 


```{c}
const auto contexts = todo->customProperty(s_appName, s_contextListProperty);
```

#### LAMBDA EXPRESSION 


```{c}
[dialogStub] (QWidget *parent) {
            dialogStub->parent = parent;
            dialogStub->setPageType(Widgets::NewPageDialogInterface::Project);
            return dialogStub;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QMimeData *mimeData, Qt::DropAction, const QObjectPtr &object) {
        if (!mimeData->hasFormat("application/x-zanshin-object"))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (auto project = object.objectCast<Domain::Project>()) {
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                const auto job = m_projectRepository->associate(project, droppedArtifact);
                installHandler(job, tr("Cannot add %1 to project %2").arg(droppedArtifact->title()).arg(project->name()));
            }
            return true;
        } else if (auto context = object.objectCast<Domain::Context>()) {
            if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                            [](const Domain::Artifact::Ptr &droppedArtifact) {
                                return !droppedArtifact.objectCast<Domain::Task>();
                            })) {
                return false;
            }
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                auto task = droppedArtifact.staticCast<Domain::Task>();
                const auto job = m_contextRepository->associate(context, task);
                installHandler(job, tr("Cannot add %1 to context %2").arg(task->title()).arg(context->name()));
            }
            return true;
        } else if (auto tag = object.objectCast<Domain::Tag>()) {
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                const auto job = m_tagRepository->associate(tag, droppedArtifact);
                installHandler(job, tr("Cannot tag %1 with %2").arg(droppedArtifact->title()).arg(tag->name()));
            }
            return true;
        } else if (object == m_inboxObject) {
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                const auto job = m_projectRepository->dissociate(droppedArtifact);
                installHandler(job, tr("Cannot move %1 to Inbox").arg(droppedArtifact->title()));

                if (auto task = droppedArtifact.objectCast<Domain::Task>()) {
                    Utils::JobHandler::install(job, [this, task] {
                        const auto dissociateJob = m_taskRepository->dissociateAll(task);
                        installHandler(dissociateJob, tr("Cannot move task %1 to Inbox").arg(task->title()));
                    });
                }
            }
            return true;
        } else if (object == m_workdayObject) {
            foreach (const auto &droppedArtifact, droppedArtifacts) {

                if (auto task = droppedArtifact.objectCast<Domain::Task>()) {

                    task->setStartDate(Utils::DateTime::currentDateTime());
                    const auto job = m_taskRepository->update(task);

                    installHandler(job, tr("Cannot update task %1 to Workday").arg(task->title()));
                }
            }
            return true;
        }

        return false;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const Domain::Task::Ptr &task, int role) -> QVariant {
        if (role != Qt::DisplayRole && role != Qt::CheckStateRole) {
            return QVariant();
        }

        if (role == Qt::DisplayRole)
            return task->title();
        else
            return task->isDone() ? Qt::Checked : Qt::Unchecked;
    }
```

#### AUTO 


```{c}
auto job = createStorage()->fetchCollections(collection, Akonadi::StorageInterface::Base, Akonadi::StorageInterface::AllContent);
```

#### AUTO 


```{c}
auto filterAction = page.findChild<QAction*>(QStringLiteral("filterViewAction"));
```

#### LAMBDA EXPRESSION 


```{c}
[] (const QStringList &strings) -> QMimeData* {
            auto data = new QMimeData;
            data->setData("application/x-zanshin-object", "object");
            data->setProperty("objects", QVariant::fromValue(strings));
            return data;
        }
```

#### AUTO 


```{c}
const auto allowedMimeTypes = listToSet(self->fetchScope().contentMimeTypes());
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Domain::DataSource::Ptr &source, const QVariant &value, int role) {
        if (role != Qt::CheckStateRole)
            return false;
        if (source->contentTypes() == Domain::DataSource::NoContent)
            return false;

        source->setSelected(value.toInt() == Qt::Checked);
        m_dataSourceRepository->update(source);
        return true;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto collection : job->collections()) {
            ItemFetchJobInterface *job = m_storage->fetchItems(collection);
            registerJobHandler(job->kjob(), [provider, job, this] {
                for (auto item : job->items()) {
                    provider->append(deserializeTask(item));
                }
            });
        }
```

#### AUTO 


```{c}
auto filterProxy = filter->proxyModel();
```

#### AUTO 


```{c}
auto project = provider->data().at(i);
```

#### AUTO 


```{c}
auto flagsFunction = [] (const QColor &) {
            return Qt::NoItemFlags;
        };
```

#### AUTO 


```{c}
auto contextResult = Domain::QueryResult<Domain::Context::Ptr>::create(contextProvider);
```

#### AUTO 


```{c}
auto savedTask = Domain::Task::Ptr();
```

#### AUTO 


```{c}
auto fetch = m_helpers->fetchAllCollections(const_cast<DataSourceQueries*>(this));
```

#### AUTO 


```{c}
auto it = std::max_element(m_items.constBegin(), m_items.constEnd(),
                               idLessThan<Akonadi::Item>);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &cleanupFunction : std::as_const(m_cleanupFunctions)) {
        cleanupFunction(this);
    }
```

#### AUTO 


```{c}
auto transaction = storage->createTransaction();
```

#### AUTO 


```{c}
auto task = Domain::Task::Ptr();
```

#### AUTO 


```{c}
auto self = jobHandlerInstance();
```

#### AUTO 


```{c}
auto fetchAdditionalInfo = [this](const QModelIndex &index, const Domain::Task::Ptr &task) -> AdditionalInfo {
        AdditionalInfo projectQueryResult = m_taskQueries->findProject(task);
        if (projectQueryResult) {
            QPersistentModelIndex persistentIndex(index);
            projectQueryResult->addPostInsertHandler([persistentIndex](const Domain::Project::Ptr &, int) {
                // When a project was found (inserted into the result), update the rendering of the item
                auto model = const_cast<QAbstractItemModel *>(persistentIndex.model());
                model->dataChanged(persistentIndex, persistentIndex);
            });
        }
        return projectQueryResult;
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (auto id : ids) {
        list << Collection(id);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[] (const QString &text, QWidget *parent) -> int {
        QString title = tr("Delete Tasks");
        return QMessageBox::question(parent, title, text, QMessageBox::Yes | QMessageBox::No);
    }
```

#### AUTO 


```{c}
auto taskSourceProxy = new TaskSourceProxy(this);
```

#### AUTO 


```{c}
auto draggedArtifacts = Domain::Artifact::List();
```

#### AUTO 


```{c}
auto i1 = serializer.createItemFromTask(task1);
```

#### AUTO 


```{c}
auto msgBoxStub = MessageBoxStub::Ptr::create();
```

#### AUTO 


```{c}
auto cache = Akonadi::Cache::Ptr::create(serializer, Akonadi::MonitorInterface::Ptr(data.createMonitor()));
```

#### AUTO 


```{c}
auto jobUpdate = storage.updateItem(item);
```

#### AUTO 


```{c}
auto model = Utils::DependencyManager::globalInstance().create<AvailableSourcesModel>();
```

#### AUTO 


```{c}
auto root1 = createSourceItem(QStringLiteral("Root 1"));
```

#### AUTO 


```{c}
auto createdTask = pageModel.addItem(title);
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Akonadi::Item &item) {
            if (m_serializer->isTaskItem(item)) {
                auto task = m_serializer->createTaskFromItem(item);
                return Domain::Artifact::Ptr(task);

            } else if (m_serializer->isNoteItem(item)) {
                auto note = m_serializer->createNoteFromItem(item);
                return Domain::Artifact::Ptr(note);

            } else {
                return Domain::Artifact::Ptr();
            }
        }
```

#### AUTO 


```{c}
auto moveAction = components.findChild<QAction*>("moveItemAction");
```

#### AUTO 


```{c}
auto delegateEdit = editor.findChild<KLineEdit*>("delegateEdit");
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Domain::DataSource::Ptr &source, const QVariant &value, int role) {
        if (role != Qt::CheckStateRole)
            return false;
        if (source->contentTypes() == Domain::DataSource::NoContent)
            return false;

        source->setSelected(value.toInt() == Qt::Checked);
        const auto job = m_dataSourceRepository->update(source);
        installHandler(job, i18n("Cannot modify source %1", source->name()));
        return true;
    }
```

#### AUTO 


```{c}
auto storage = m_storage;
```

#### AUTO 


```{c}
const auto items = Akonadi::Item::List() << Akonadi::Item(GenTodo().withId(1).withParent(1).withContexts({"ctx-1"}).withTitle("item1"))
                                                 << Akonadi::Item(GenTodo().withId(2).withParent(1).withContexts({"ctx-1"}).withTitle("item2"));
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const ContextQuery::AddFunction &add) {
            TagFetchJobInterface *job = m_storage->fetchTags();
            Utils::JobHandler::install(job->kjob(), [this, job, add] {
                for (Akonadi::Tag tag : job->tags())
                    add(tag);
            });
        }
```

#### AUTO 


```{c}
auto job = new AkonadiFakeCollectionSearchJob;
```

#### LAMBDA EXPRESSION 


```{c}
[persistentIndex](const Domain::Project::Ptr &, int) {
            // When a project was found (inserted into the result), update the rendering of the item
            auto model = const_cast<QAbstractItemModel *>(persistentIndex.model());
            model->dataChanged(persistentIndex, persistentIndex);
        }
```

#### AUTO 


```{c}
auto fetch = m_helpers->fetchItemsForContext(context);
```

#### AUTO 


```{c}
auto parent = notifiedCollection.parentCollection();
```

#### AUTO 


```{c}
auto query = TagQueries::TagQuery::Ptr::create();
```

#### AUTO 


```{c}
auto i2 = Akonadi::Item(i1.id());
```

#### AUTO 


```{c}
auto dataString = data->property("objects").toStringList();
```

#### AUTO 


```{c}
auto sourceCombo = dialog.findChild<QComboBox*>(QStringLiteral("sourceCombo"));
```

#### AUTO 


```{c}
const auto unlisted = Domain::DataSource::Unlisted;
```

#### AUTO 


```{c}
auto workdayPageModel = new WorkdayPageModel(m_taskQueries,
                                                     m_taskRepository,
                                                     m_noteRepository,
                                                     this);
```

#### AUTO 


```{c}
auto data = std::unique_ptr<QMimeData>(model.mimeData(indexes));
```

#### AUTO 


```{c}
auto fetch = helpers->searchCollections(Akonadi::Collection::root(), &term,
                                                Akonadi::StorageInterface::FetchContentTypes(contentTypes));
```

#### AUTO 


```{c}
auto settingsCollection = StorageSettings::instance().defaultNoteCollection();
```

#### AUTO 


```{c}
const auto index = m_collections.indexOf(Collection(id));
```

#### AUTO 


```{c}
auto note = createNoteFromItem(item);
```

#### LAMBDA EXPRESSION 


```{c}
[collectionsMap, &reconstructAncestors, this] (const Collection &collection) -> Collection {
                Q_ASSERT(collection.isValid());

                if (collection == m_collection)
                    return collection;

                auto parent = collection.parentCollection();
                auto reconstructedParent = reconstructAncestors(collectionsMap[parent.id()]);

                auto result = collection;
                result.setParentCollection(reconstructedParent);
                return result;
            }
```

#### AUTO 


```{c}
auto item = addStubItem(title, parentItem);
```

#### AUTO 


```{c}
auto setData = [this](const Domain::Task::Ptr &task, const QVariant &value, int role) {
        if (role != Qt::EditRole && role != Qt::CheckStateRole) {
            return false;
        }

        const auto currentTitle = task->title();
        if (role == Qt::EditRole)
            task->setTitle(value.toString());
        else
            task->setDone(value.toInt() == Qt::Checked);

        const auto job = m_taskRepository->update(task);
        installHandler(job, tr("Cannot modify task %1 in project %2").arg(currentTitle).arg(m_project->name()));
        return true;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[fetchItemJob, compositeJob, this] {
        if (fetchItemJob->kjob()->error() != KJob::NoError)
           return;

        Q_ASSERT(fetchItemJob->items().size() == 1);
        auto item = fetchItemJob->items().at(0);

        ItemFetchJobInterface *fetchCollectionItemsJob = m_storage->fetchItems(item.parentCollection());
        compositeJob->install(fetchCollectionItemsJob->kjob(), [fetchCollectionItemsJob, item, compositeJob, this] {
            if (fetchCollectionItemsJob->kjob()->error() != KJob::NoError)
                return;

            Item::List childItems = m_serializer->filterDescendantItems(fetchCollectionItemsJob->items(), item);
            childItems << item;

            auto removeJob = m_storage->removeItems(childItems);
            compositeJob->addSubjob(removeJob);
            removeJob->start();
        });
    }
```

#### AUTO 


```{c}
auto project12 = Domain::Project::Ptr::create();
```

#### LAMBDA EXPRESSION 


```{c}
[this, job, add] {
                if (job->kjob()->error() != KJob::NoError)
                    return;

                for (auto item : job->items())
                    add(item);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[&listingDone] (const Domain::LiveRelationshipQuery<QObject*, QString>::AddFunction &add) {
            Q_UNUSED(add);
            Utils::JobHandler::install(new FakeJob, [&listingDone] {
                listingDone = true;
            });
        }
```

#### AUTO 


```{c}
auto expected = QStringList();
```

#### AUTO 


```{c}
auto buttonBox = new QDialogButtonBox(this);
```

#### LAMBDA EXPRESSION 


```{c}
[] (const Akonadi::Item &) {
            return true;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&removedId] (const Akonadi::Collection &collection) {
            removedId = collection.id();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, root] (const Akonadi::Item &item) {
        return root == item.parentCollection()
            && m_serializer->isProjectItem(item);
    }
```

#### AUTO 


```{c}
auto todo = KCalCore::Todo::Ptr::create();
```

#### LAMBDA EXPRESSION 


```{c}
[this, add] {
                add(createObject(0, QStringLiteral("0A")));
                add(createObject(1, QStringLiteral("1A")));
                add(createObject(2, QStringLiteral("2A")));
                add(createObject(3, QStringLiteral("0B")));
                add(createObject(4, QStringLiteral("1B")));
                add(createObject(5, QStringLiteral("2B")));
                add(createObject(6, QStringLiteral("0C")));
                add(createObject(7, QStringLiteral("1C")));
                add(createObject(8, QStringLiteral("2C")));
            }
```

#### AUTO 


```{c}
auto fetchCollectionsFunction(Akonadi::StorageInterface::Ptr storage, QObject *parent) {
        return [storage, parent] (const Domain::LiveQueryInput<Akonadi::Collection>::AddFunction &add) {
            auto job = storage->fetchCollections(Akonadi::Collection::root(), Akonadi::Storage::Recursive, parent);
            Utils::JobHandler::install(job->kjob(), [add, job] {
                foreach (const auto &col, job->collections()) {
                    add(col);
                }
            });
        };
    }
```

#### AUTO 


```{c}
auto addTagAction = available.findChild<QAction*>("addTagAction");
```

#### AUTO 


```{c}
const auto parentId = findParentId(newItem);
```

#### AUTO 


```{c}
const auto job = noteRepository()->save(note);
```

#### LAMBDA EXPRESSION 


```{c}
[this, context] (const Akonadi::Item &item) {
        if (!m_serializer->isContextChild(context, item))
            return false;

        const auto items = m_cache->items(item.parentCollection());
        auto currentItem = item;
        auto parentUid = m_serializer->relatedUidFromItem(currentItem);
        while (!parentUid.isEmpty()) {
            const auto parent = std::find_if(items.cbegin(), items.cend(),
                                             [this, parentUid] (const Akonadi::Item &item) {
                                                 return m_serializer->itemUid(item) == parentUid;
                                             });
            if (parent == items.cend())
                break;

            if (m_serializer->isContextChild(context, *parent))
                return false;

            currentItem = *parent;
            parentUid = m_serializer->relatedUidFromItem(currentItem);
        }

        return true;
    }
```

#### AUTO 


```{c}
auto object = deps.create<AnotherInterface>();
```

#### AUTO 


```{c}
const auto collections = cache->collections(Akonadi::StorageInterface::AllContent);
```

#### LAMBDA EXPRESSION 


```{c}
[serializer, storage, parent] (const Domain::LiveQueryInput<Item>::AddFunction &add) {
        auto job = storage->fetchCollections(Akonadi::Collection::root(),
                                             StorageInterface::Recursive);
        Utils::JobHandler::install(job->kjob(), [serializer, storage, job, add, parent] {
            if (job->kjob()->error() != KJob::NoError)
                return;

            foreach (const auto &collection, job->collections()) {
                if (!serializer->isSelectedCollection(collection))
                    continue;

                auto job = storage->fetchItems(collection, parent);
                Utils::JobHandler::install(job->kjob(), [job, add] {
                    if (job->kjob()->error() != KJob::NoError)
                        return;

                    foreach (const auto &item, job->items())
                        add(item);
                });
            }
        });
    }
```

#### AUTO 


```{c}
const auto text = m_model->property("text").toString();
```

#### AUTO 


```{c}
const auto isEnabled = (opt.state & QStyle::State_Enabled);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Domain::Artifact::Ptr &artifact, const QVariant &value, int role) {
        if (role != Qt::EditRole && role != Qt::CheckStateRole) {
            return false;
        }

        if (auto task = artifact.dynamicCast<Domain::Task>()) {
            const auto currentTitle = task->title();
            if (role == Qt::EditRole)
                task->setTitle(value.toString());
            else
                task->setDone(value.toInt() == Qt::Checked);

            const auto job = m_taskRepository->update(task);
            installHandler(job, i18n("Cannot modify task %1 in Workday", currentTitle));
            return true;
        }

        return false;
    }
```

#### AUTO 


```{c}
auto collections = CollectionFetchJob::collections();
```

#### AUTO 


```{c}
auto setData = [this](const QObjectPtr &object, const QVariant &value, int role) {
        if (role != Qt::EditRole) {
            return false;
        }

        if (object == m_inboxObject
         || object == m_workdayObject
         || object == m_projectsObject
         || object == m_contextsObject
         || object == m_allTasksObject
         || object.objectCast<Domain::DataSource>()) {
            return false;
        }

        if (auto project = object.objectCast<Domain::Project>()) {
            const auto currentName = project->name();
            project->setName(value.toString());
            const auto job = m_projectRepository->update(project);
            installHandler(job, i18n("Cannot modify project %1", currentName));
        } else if (auto context = object.objectCast<Domain::Context>()) {
            const auto currentName = context->name();
            context->setName(value.toString());
            const auto job = m_contextRepository->update(context);
            installHandler(job, i18n("Cannot modify context %1", currentName));
        } else {
            Q_ASSERT(false);
        }

        return true;
    };
```

#### AUTO 


```{c}
auto drag = [] (const Domain::Artifact::List &artifacts) -> QMimeData* {
        if (artifacts.isEmpty())
            return Q_NULLPTR;

        auto data = new QMimeData;
        data->setData("application/x-zanshin-object", "object");
        data->setProperty("objects", QVariant::fromValue(artifacts));
        return data;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this, job, add] {
            if (job->kjob()->error() != KJob::NoError)
                return;

            foreach (const auto &collection, job->collections()) {
                if (!m_serializer->isSelectedCollection(collection))
                    continue;

                auto job = m_storage->fetchItems(collection);
                Utils::JobHandler::install(job->kjob(), [this, job, add] {
                    if (job->kjob()->error() != KJob::NoError)
                        return;

                    foreach (const auto &item, job->items())
                        add(item);
                });
            }
        }
```

#### AUTO 


```{c}
auto data = [this] (const Domain::DataSource::Ptr &source, int role) -> QVariant {
        if (role != Qt::DisplayRole
         && role != Qt::EditRole
         && role != Qt::DecorationRole
         && role != Qt::CheckStateRole
         && role != QueryTreeModelBase::IconNameRole
         && role != QueryTreeModelBase::IsDefaultRole) {
            return QVariant();
        }

        if (role == Qt::DisplayRole || role == Qt::EditRole) {
            return source->name();
        } else if (role == Qt::DecorationRole || role == QueryTreeModelBase::IconNameRole) {
            const QString iconName = source->iconName().isEmpty() ? "folder" : source->iconName();

            if (role == Qt::DecorationRole)
                return QVariant::fromValue(QIcon::fromTheme(iconName));
            else
                return iconName;
        } else if (role == Qt::CheckStateRole) {
            if (source->contentTypes() != Domain::DataSource::NoContent)
                return source->isSelected() ? Qt::Checked : Qt::Unchecked;
            else
                return QVariant();
        } else if (role == QueryTreeModelBase::IsDefaultRole) {
            return m_dataSourceQueries->isDefaultSource(source);
        } else {
            return QVariant();
        }
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this, add] {
                add(createObject(0, QStringLiteral("ProjectA")));
                add(createObject(1, QStringLiteral("ItemA")));
                add(createObject(2, QStringLiteral("ParentA")));
                add(createObject(3, QStringLiteral("ProjectB-Renamed")));
                add(createObject(4, QStringLiteral("ItemB")));
                add(createObject(5, QStringLiteral("ParentB")));
                add(createObject(6, QStringLiteral("ProjectC")));
                add(createObject(7, QStringLiteral("ItemC")));
                add(createObject(8, QStringLiteral("ParentC")));
            }
```

#### LAMBDA EXPRESSION 


```{c}
[=] (const Akonadi::Item &item) {
                    auto result = item;
                    result.setParentCollection(collection);
                    // Force payload detach
                    result.setPayloadFromData(result.payloadData());
                    return result;
                }
```

#### AUTO 


```{c}
auto centralView = page.findChild<QTreeView*>(QStringLiteral("centralView"));
```

#### AUTO 


```{c}
auto job = createStorage()->fetchItem(item, nullptr);
```

#### AUTO 


```{c}
auto actions = QHash<QString, QAction*>();
```

#### LAMBDA EXPRESSION 


```{c}
[tag, fetchFunction] (const Domain::LiveQueryInput<Item>::AddFunction &add) {
        auto filterAdd = [tag, add] (const Item &item) {
            if (item.tags().contains(tag))
                add(item);
        };
        fetchFunction(filterAdd);
    }
```

#### AUTO 


```{c}
auto it = expectedItems.constBegin();
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QMimeData *mimeData, Qt::DropAction, const QObjectPtr &object) {
        if (!mimeData->hasFormat("application/x-zanshin-object"))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (auto project = object.objectCast<Domain::Project>()) {
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                m_projectRepository->associate(project, droppedArtifact);
            }
            return true;
        } else if (auto context = object.objectCast<Domain::Context>()) {
            if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                            [](const Domain::Artifact::Ptr &droppedArtifact) {
                                return !droppedArtifact.objectCast<Domain::Task>();
                            })) {
                return false;
            }
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                auto task = droppedArtifact.staticCast<Domain::Task>();
                m_contextRepository->associate(context, task);
            }
            return true;
        } else if (auto tag = object.objectCast<Domain::Tag>()) {
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                m_tagRepository->associate(tag, droppedArtifact);
            }
            return true;
        } else if (object == m_inboxObject) {
            foreach (const auto &droppedArtifact, droppedArtifacts) {
                auto job = m_projectRepository->dissociate(droppedArtifact);
                if (auto task = droppedArtifact.objectCast<Domain::Task>()) {
                    Utils::JobHandler::install(job, [this, task] {
                        m_taskRepository->dissociate(task);
                    });
                }
            }
            return true;
        }

        return false;
    }
```

#### AUTO 


```{c}
auto settingsCollection = StorageSettings::instance().defaultTaskCollection();
```

#### AUTO 


```{c}
auto job = new AkonadiFakeTagFetchJob;
```

#### AUTO 


```{c}
auto fileName = m_requestFileNameFunction(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const QMimeData *mimeData, Qt::DropAction, const Domain::Artifact::Ptr &artifact) {
        auto parentTask = artifact.objectCast<Domain::Task>();
        if (!parentTask)
            return false;

        if (!mimeData->hasFormat("application/x-zanshin-object"))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                        [](const Domain::Artifact::Ptr &droppedArtifact) {
                            return !droppedArtifact.objectCast<Domain::Task>();
                        })) {
            return false;
        }

        foreach(const Domain::Artifact::Ptr &droppedArtifact, droppedArtifacts) {
            auto childTask = droppedArtifact.objectCast<Domain::Task>();
            const auto job = taskRepository()->associate(parentTask, childTask);
            installHandler(job, tr("Cannot move task %1 as sub-task of %2").arg(childTask->title()).arg(parentTask->title()));
        }

        return true;
    }
```

#### AUTO 


```{c}
auto job = storage->updateItem(item);
```

#### AUTO 


```{c}
auto job = storage->updateCollection(collection);
```

#### LAMBDA EXPRESSION 


```{c}
[=] (const Akonadi::Item &item) {
                               auto result = item;
                               result.setParentCollection(collection);
                               // Force payload detach
                               result.setPayloadFromData(result.payloadData());
                               return result;
                           }
```

#### AUTO 


```{c}
auto availableSourcesView = new AvailableSourcesView(m_parent);
```

#### AUTO 


```{c}
auto job = storage->removeItems(list);
```

#### LAMBDA EXPRESSION 


```{c}
[] (Utils::DependencyManager *deps) {
        return new Akonadi::CachingStorage(deps->create<Akonadi::Cache>(),
                                           Akonadi::StorageInterface::Ptr(new Akonadi::Storage));
    }
```

#### AUTO 


```{c}
auto job = storage->searchCollections(name);
```

#### AUTO 


```{c}
auto userSelectedSource = Domain::DataSource::Ptr::create();
```

#### AUTO 


```{c}
auto job = storage->createTag(tag);
```

#### AUTO 


```{c}
const auto job = m_taskRepository->update(task);
```

#### AUTO 


```{c}
auto dataSource1 = serializer.createDataSourceFromCollection(collection);
```

#### AUTO 


```{c}
auto parentId = m_uidtoIdCache.value(uid);
```

#### AUTO 


```{c}
auto data = [](const Domain::Task::Ptr &task, int role, const AdditionalInfo &dataSourceQueryResult) -> QVariant {
        switch (role) {
            case Qt::DisplayRole:
            case Qt::EditRole:
                return task->title();
            case Qt::CheckStateRole:
                return task->isDone() ? Qt::Checked : Qt::Unchecked;
            case Presentation::QueryTreeModelBase::AdditionalInfoRole:
                if (dataSourceQueryResult && !dataSourceQueryResult->data().isEmpty()) {
                    Domain::DataSource::Ptr dataSource = dataSourceQueryResult->data().at(0);
                    return dataSource->name();
                }
                return QString();
            default:
                break;
        }
        return QVariant();
    };
```

#### AUTO 


```{c}
auto drop = [this](const QMimeData *mimeData, Qt::DropAction, const Domain::Task::Ptr &parentTask) {
        if (!mimeData->hasFormat(QStringLiteral("application/x-zanshin-object")))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                        [](const Domain::Artifact::Ptr &droppedArtifact) {
                            return !droppedArtifact.objectCast<Domain::Task>();
                        })) {
            return false;
        }

        using namespace std::placeholders;
        auto associate = std::function<KJob*(Domain::Task::Ptr)>();
        auto parentTitle = QString();

        if (parentTask) {
            associate = std::bind(&Domain::TaskRepository::associate, m_taskRepository, parentTask, _1);
            parentTitle = parentTask->title();
        } else {
            associate = std::bind(&Domain::ProjectRepository::associate, m_projectRepository, m_project, _1);
            parentTitle = m_project->name();
        }

        foreach(const Domain::Artifact::Ptr &droppedArtifact, droppedArtifacts) {
            auto childTask = droppedArtifact.objectCast<Domain::Task>();
            const auto job = associate(childTask);
            installHandler(job, i18n("Cannot move task %1 as a sub-task of %2", childTask->title(), parentTitle));
        }

        return true;
    };
```

#### AUTO 


```{c}
auto source = app.defaultNoteDataSource();
```

#### AUTO 


```{c}
auto drop = [this] (const QMimeData *mimeData, Qt::DropAction, const Domain::Task::Ptr &parentTask) {
        if (!mimeData->hasFormat("application/x-zanshin-object"))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                        [](const Domain::Artifact::Ptr &droppedArtifact) {
                            return !droppedArtifact.objectCast<Domain::Task>();
                        })) {
            return false;
        }

        foreach(const Domain::Artifact::Ptr &droppedArtifact, droppedArtifacts) {
            auto childTask = droppedArtifact.objectCast<Domain::Task>();
            const auto job = taskRepository()->associate(parentTask, childTask);
            if (!errorHandler())
                continue;

            errorHandler()->installHandler(job, tr("Cannot move task %1 as sub-task of %2").arg(childTask->title()).arg(parentTask->title()));
        }

        return true;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this, project] (const Akonadi::Item &item) {
            return m_serializer->isProjectChild(project, item);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Tag &tag) { return m_tagItems.contains(tag.id()); }
```

#### LAMBDA EXPRESSION 


```{c}
[provider, job, this] {
        if (job->kjob()->error() != KJob::NoError)
            return;

        for (auto collection : job->collections()) {
            ItemFetchJobInterface *job = m_storage->fetchItems(collection);
            Utils::JobHandler::install(job->kjob(), [provider, job, this] {
                if (job->kjob()->error() != KJob::NoError)
                    return;

                for (auto item : job->items()) {
                    if (m_serializer->relatedUidFromItem(item).isEmpty()) {
                        auto task = deserializeTask(item);
                        if (task)
                            provider->append(task);
                    }
                }
            });
        }
    }
```

#### AUTO 


```{c}
const auto colSet = QSet<Akonadi::Collection>() << c2;
```

#### RANGE FOR STATEMENT 


```{c}
for (auto child : m_children->data()) {
            QueryTreeNodeBase *node = new QueryTreeNode<ItemType>(child, this,
                                                                  model, queryGenerator,
                                                                  m_flagsFunction,
                                                                  m_dataFunction, m_setDataFunction,
                                                                  m_dropFunction, m_dragFunction);
            appendChild(node);
        }
```

#### AUTO 


```{c}
auto it = std::find_if(m_collections.cbegin(), m_collections.cend(), isInputCollection);
```

#### AUTO 


```{c}
auto object = QObjectPtr::create();
```

#### AUTO 


```{c}
const auto summaryFont = [=] {
        auto font = baseFont;
        font.setStrikeOut(isDone);
        font.setBold(!isDone && (onStartDate || onDueDate || pastDueDate));
        font.setItalic(taskDelegate.isValid());
        return font;
    }();
```

#### LAMBDA EXPRESSION 


```{c}
[&mimeDb] (const KCalCore::Attachment::Ptr &attach) {
                       Domain::Task::Attachment attachment;
                       if (attach->isUri())
                           attachment.setUri(QUrl(attach->uri()));
                       else
                           attachment.setData(attach->decodedData());
                       attachment.setLabel(attach->label());
                       attachment.setMimeType(attach->mimeType());
                       attachment.setIconName(mimeDb.mimeTypeForName(attach->mimeType()).iconName());
                       return attachment;
                   }
```

#### AUTO 


```{c}
auto today = QDate::currentDate();
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Tag &tag) {
        m_findTopLevel.remove(tag.id());
    }
```

#### AUTO 


```{c}
auto fetch = helpers->fetchItems(contentTypes);
```

#### AUTO 


```{c}
auto job = m_storage->fetchCollections(Akonadi::Collection::root(),
                                                   Akonadi::StorageInterface::Recursive,
                                                   m_types);
```

#### AUTO 


```{c}
auto flagsFunction = [] (const QString &) {
            return Qt::NoItemFlags;
        };
```

#### AUTO 


```{c}
auto child
```

#### LAMBDA EXPRESSION 


```{c}
[] (Utils::DependencyManager *deps) {
        return new Akonadi::DataSourceQueries(Akonadi::StorageInterface::Tasks,
                                              deps->create<Akonadi::StorageInterface>(),
                                              deps->create<Akonadi::SerializerInterface>(),
                                              deps->create<Akonadi::MonitorInterface>());
    }
```

#### AUTO 


```{c}
auto mimeData = std::make_unique<QMimeData>();
```

#### AUTO 


```{c}
auto serializer = m_serializer;
```

#### AUTO 


```{c}
auto projectRepository = Domain::ProjectRepository::Ptr();
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Akonadi::Item &item) {
            return m_serializer->isNoteItem(item);
        }
```

#### AUTO 


```{c}
auto queries = Akonadi::TaskQueries::Ptr::create();
```

#### AUTO 


```{c}
auto result = std::accumulate(itemsToProcess.begin(), itemsToProcess.end(), Akonadi::Item::List(),
                                 [this, itemsRemoved](Akonadi::Item::List result, Akonadi::Item currentItem) {
                                     result << currentItem;
                                     return result += filterDescendantItems(itemsRemoved, currentItem);
                                 });
```

#### LAMBDA EXPRESSION 


```{c}
[] (const Domain::DataSource::Ptr &) {
              return Qt::ItemIsSelectable | Qt::ItemIsEnabled;
          }
```

#### AUTO 


```{c}
const auto tag1 = Akonadi::Tag(GenTag().withId(1).withName("tag1"));
```

#### AUTO 


```{c}
const auto childItems = m_childItems[collection.id()];
```

#### AUTO 


```{c}
auto taskRepository = Domain::TaskRepository::Ptr();
```

#### AUTO 


```{c}
auto taskInModel = model->data(model->index(0, 0, parentIndex), Presentation::QueryTreeModelBase::ObjectRole).value<Domain::Task::Ptr>();
```

#### AUTO 


```{c}
auto tagPageModel = new TagPageModel(tag,
                                             m_tagQueries,
                                             m_tagRepository,
                                             m_noteRepository,
                                             this);
```

#### LAMBDA EXPRESSION 


```{c}
[storage, job, add] {
            if (job->kjob()->error() != KJob::NoError)
                return;

            Q_ASSERT(job->items().size() == 1);
            auto item = job->items().at(0);
            Q_ASSERT(item.parentCollection().isValid());
            auto job = storage->fetchItems(item.parentCollection());
            Utils::JobHandler::install(job->kjob(), [job, add] {
                if (job->kjob()->error() != KJob::NoError)
                    return;

                foreach (const auto &item, job->items())
                    add(item);
            });
        }
```

#### AUTO 


```{c}
const auto title = QStringLiteral("New task");
```

#### AUTO 


```{c}
auto drop = [this](const QMimeData *mimeData, Qt::DropAction, const Domain::Artifact::Ptr &artifact) {
        auto parentTask = artifact.objectCast<Domain::Task>();
        if (!parentTask)
            return false;

        if (!mimeData->hasFormat("application/x-zanshin-object"))
            return false;

        auto droppedArtifacts = mimeData->property("objects").value<Domain::Artifact::List>();
        if (droppedArtifacts.isEmpty())
            return false;

        if (std::any_of(droppedArtifacts.begin(), droppedArtifacts.end(),
                        [](const Domain::Artifact::Ptr &droppedArtifact) {
                            return !droppedArtifact.objectCast<Domain::Task>();
                        })) {
            return false;
        }

        foreach(const auto &droppedArtifact, droppedArtifacts) {
            auto childTask = droppedArtifact.objectCast<Domain::Task>();
            const auto job = taskRepository()->associate(parentTask, childTask);
            if (!errorHandler())
                continue;

            errorHandler()->installHandler(job, tr("Cannot move task %1 as sub-task of %2").arg(childTask->title()).arg(parentTask->title()));
        }

        return true;
    };
```

#### AUTO 


```{c}
auto fetch = [storage] (const Domain::LiveQueryInput<Akonadi::Item>::AddFunction &add) {
            auto job = storage->fetchCollections(Akonadi::Collection::root(), Akonadi::Storage::Recursive, Akonadi::Storage::AllContent);
            Utils::JobHandler::install(job->kjob(), [add, job, storage] {
                foreach (const auto &col, job->collections()) {
                    auto itemJob = storage->fetchItems(col);
                    Utils::JobHandler::install(itemJob->kjob(), [add, itemJob] {
                        foreach (const auto &item, itemJob->items())
                            add(item);
                    });
                }
            });
        };
```

#### AUTO 


```{c}
const auto itemCachedIds = [cache, toItemIds]{
                const auto items = cache->items(Akonadi::Tag(43));
                return toItemIds(items);
            }();
```

#### AUTO 


```{c}
const auto data = attr.serialized();
```

#### AUTO 


```{c}
auto *fetchJob = storage->fetchItems(collection);
```

#### AUTO 


```{c}
auto goPreviousAction = new QAction(this);
```

#### AUTO 


```{c}
auto topProvider = Domain::QueryResultProvider<QString>::Ptr::create();
```

#### AUTO 


```{c}
auto &item
```

#### LAMBDA EXPRESSION 


```{c}
[=] {
            foreach (const Akonadi::Item &item, items) {
                m_data->removeItem(item);
            }
        }
```

#### AUTO 


```{c}
auto notifiedCollection = reconstructAncestors(newCollection);
```

#### LAMBDA EXPRESSION 


```{c}
[provider, job, this] {
        for (auto collection : job->collections()) {
            ItemFetchJobInterface *job = m_storage->fetchItems(collection);
            Utils::JobHandler::install(job->kjob(), [provider, job, this] {
                for (auto item : job->items()) {
                    auto task = deserializeTask(item);
                    if (task)
                        provider->append(task);
                }
            });
        }
    }
```

#### AUTO 


```{c}
auto task = deserializeTask(item);
```

#### LAMBDA EXPRESSION 


```{c}
[collectionName, types] (const Akonadi::Collection &col) {
                     const auto mime = col.contentMimeTypes();
                     auto contentMimeTypes = QSet<QString>();
                     if (types & Notes)
                         contentMimeTypes << Akonadi::NoteUtils::noteMimeType();
                     if (types & Tasks)
                         contentMimeTypes << KCalCore::Todo::todoMimeType();

                     const bool supportedType = contentMimeTypes.isEmpty()
                                             || !mime.toSet().intersect(contentMimeTypes).isEmpty();
                     return supportedType && col.displayName().contains(collectionName, Qt::CaseInsensitive);
                 }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Akonadi::Item &item) {
        return m_serializer->isProjectItem(item);
    }
```

#### AUTO 


```{c}
auto drop = [] (const QMimeData *mimeData, Qt::DropAction, const Domain::DataSource::Ptr &source) {
        Q_UNUSED(mimeData)
        Q_UNUSED(source)
        return false;
    };
```

#### AUTO 


```{c}
auto provider = Domain::QueryResultProvider<QColor>::Ptr::create();
```

#### AUTO 


```{c}
auto fetch = m_helpers->fetchTags();
```

#### AUTO 


```{c}
auto job = m_storage.fetchItems(collection);
```

#### AUTO 


```{c}
const auto collection3 = Akonadi::Collection(GenCollection().withRootAsParent()
                                                                    .withId(3)
                                                                    .withName("tasks3")
                                                                    .withTaskContent());
```

#### AUTO 


```{c}
auto handler = [&]() {
            compositeJob->emitError(QStringLiteral("Error reached"));
        };
```

#### AUTO 


```{c}
auto drag = [](const Domain::Artifact::Ptr &artifact) -> QMimeData* {
        if (!artifact)
            return 0;

        QMimeData *data = new QMimeData;
        data->setData("application/x-zanshin-object", "object");
        data->setProperty("object", QVariant::fromValue(artifact));
        return data;
    };
```

