#### AUTO 


```{c}
auto *job = new KIO::CommandLauncherJob(QStringLiteral("kdf"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const Column &c : qAsConst(m_columnList)){
        columns << c.columnName;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Column &c : qAsConst(m_columnList)){
            int width = config.readEntry( c.name, c.defaultWidth );
            m_listWidget->setColumnWidth( c.number, width );
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const Column &c : std::as_const(m_columnList))
        {
            headerLabels << c.columnName;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Column &c : std::as_const(m_columnList)){
        columns << c.columnName;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Column &c : qAsConst(m_columnList)){
            if( !m_listWidget->isColumnHidden( c.number ) )
                config.writeEntry( c.name, m_listWidget->columnWidth(c.number) );
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Column &c : std::as_const(m_columnList)){
            bool visible = config_visible.readEntry( c.name , true );
            m_listWidget->setColumnHidden( c.number, !visible );
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Column &c : std::as_const(m_columnList)){
            int width = config.readEntry( c.name, c.defaultWidth );
            m_listWidget->setColumnWidth( c.number, width );
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const Column &c : qAsConst(m_columnList))
        {
            headerLabels << c.columnName;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Column &c : qAsConst(m_columnList)){
            bool visible = config_visible.readEntry( c.name , true );
            m_listWidget->setColumnHidden( c.number, !visible );
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Column &c : std::as_const(m_columnList)){
            if( !m_listWidget->isColumnHidden( c.number ) )
                config.writeEntry( c.name, m_listWidget->columnWidth(c.number) );
        }
```

