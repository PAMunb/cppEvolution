#### AUTO 


```{c}
const auto shapes = m_citem->shapes();
```

#### LAMBDA EXPRESSION 


```{c}
[minSlider, minSpinBox] {minSpinBox->setValue(minSlider->value()/100.0);}
```

#### RANGE FOR STATEMENT 


```{c}
for (Kolf::Wall* wall : std::as_const(m_walls))
		applyWallStyle(wall);
```

#### AUTO 


```{c}
const auto collidingItems = this->collidingItems();
```

#### RANGE FOR STATEMENT 


```{c}
for (QGraphicsItem* qitem : currentTopLevelQItems) {
		if (dynamic_cast<Ball*>(qitem))
		{
			//do not delete balls
			newTopLevelQItems << qitem;
			continue;
		}
		CanvasItem *citem = dynamic_cast<CanvasItem *>(qitem);
		if (citem)
		{
			delete citem;
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const Kolf::ItemMetadata& metadata : knownTypes)
		if (metadata.addOnNewHole)
			addNewObject(metadata.identifier);
```

#### RANGE FOR STATEMENT 


```{c}
for (QGraphicsItem* qitem : qAsConst(m_topLevelQItems)) {
		CanvasItem *citem = dynamic_cast<CanvasItem *>(qitem);
		if (citem)
			infoItems << citem->infoItems();
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (QGraphicsItem* qitem : infoItems)
		qitem->setVisible(m_showInfo);
```

#### RANGE FOR STATEMENT 


```{c}
for (CanvasItem* item : std::as_const(m_struttedItems))
		item->m_strut = nullptr;
```

#### RANGE FOR STATEMENT 


```{c}
for (QGraphicsItem* qitem : std::as_const(m_topLevelQItems)) {
		CanvasItem *citem = dynamic_cast<CanvasItem *>(qitem);
		if (citem)
			infoItems << citem->infoItems();
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (QGraphicsItem* qitem : std::as_const(m_topLevelQItems)) {
			CanvasItem *citem = dynamic_cast<CanvasItem *>(qitem);
			if (citem)
			{
				if (citem->curId() == i)
				{
					found = true;
					break;
				}
			}
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (QGraphicsItem* qitem : std::as_const(m_topLevelQItems)) {
		CanvasItem *citem = dynamic_cast<CanvasItem *>(qitem);
		if (citem)
		{
			cfgGroup = KConfigGroup(cfg->group(makeGroup(citem->curId(), curHole, citem->name(), (int)qitem->x(), (int)qitem->y())));
			citem->save(&cfgGroup);
		}
	}
```

#### LAMBDA EXPRESSION 


```{c}
[maxSlider, maxSpinBox] {maxSlider->setValue(qRound(maxSpinBox->value()*100));}
```

#### RANGE FOR STATEMENT 


```{c}
for (ArrowItem* arrow : m_arrows)
		result << arrow;
```

#### RANGE FOR STATEMENT 


```{c}
for (QGraphicsItem* item : itemsCopy) {
		CanvasItem* citem = dynamic_cast<CanvasItem*>(item);
		delete citem;
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (Kolf::Shape* shape : shapes) {
		activationOutline.addPath(shape->activationOutline());
		interactionOutline.addPath(shape->interactionOutline());
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (Kolf::Wall* wall : qAsConst(m_walls))
		applyWallStyle(wall);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& dir : dirs) {
			const QStringList fileNames = QDir(dir).entryList(QStringList() << QStringLiteral("*"), QDir::Files);
			for (const QString& file : fileNames) {
				files.append(dir + QLatin1Char('/') + file);
			}
		}
```

#### LAMBDA EXPRESSION 


```{c}
[maxSlider, maxSpinBox] {maxSpinBox->setValue(maxSlider->value()/100.0);}
```

#### RANGE FOR STATEMENT 


```{c}
for (QGraphicsItem* otherQitem : std::as_const(m_topLevelQItems)) {
		CanvasItem* otherCitem = dynamic_cast<CanvasItem*>(otherQitem);
		if (otherCitem && otherCitem != citem)
		{
			//false = do not create overlay if it does not exist yet
			Kolf::Overlay* otherOverlay = otherCitem->overlay(false);
			if (otherOverlay)
				otherOverlay->setState(Kolf::Overlay::Passive);
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (QGraphicsItem* qitem : qAsConst(m_topLevelQItems)) {
		if (dynamic_cast<Ball*>(qitem)) continue;
		CanvasItem *citem = dynamic_cast<CanvasItem *>(qitem);
		if (citem)
			citem->editModeChanged(editing);
	}
```

#### AUTO 


```{c}
auto okButton = buttonBox->button(QDialogButtonBox::Ok);
```

#### RANGE FOR STATEMENT 


```{c}
for (Kolf::Wall* wall : std::as_const(m_walls))
		if (wall)
			wall->setPos(pos);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& file : fileNames) {
				files.append(dir + QLatin1Char('/') + file);
			}
```

#### RANGE FOR STATEMENT 


```{c}
for (QGraphicsItem* qitem : qAsConst(infoItems))
		qitem->setVisible(m_showInfo);
```

#### AUTO 


```{c}
const auto knownTypes = factory.knownTypes();
```

#### RANGE FOR STATEMENT 


```{c}
for (QGraphicsItem* item : qAsConst(m_topLevelQItems)) {
		if (dynamic_cast<Ball*>(item)) continue; //see below
		CanvasItem* citem = dynamic_cast<CanvasItem*>(item);
		if (citem)
		{
			const QString key = makeStateGroup(citem->curId(), citem->name());
			const QPointF currentPos = item->pos();
			const QPointF posDiff = savedState.value(key, currentPos) - currentPos;
			citem->moveBy(posDiff.x(), posDiff.y());
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (QGraphicsItem* qitem : qAsConst(m_topLevelQItems)) {
		CanvasItem *citem = dynamic_cast<CanvasItem *>(qitem);
		if (citem)
		{
			cfgGroup = KConfigGroup(cfg->group(makeGroup(citem->curId(), curHole, citem->name(), (int)qitem->x(), (int)qitem->y())));
			citem->save(&cfgGroup);
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (QGraphicsItem* item : qAsConst(m_topLevelQItems)) {
		if (dynamic_cast<Ball*>(item)) continue; //see below
		CanvasItem* citem = dynamic_cast<CanvasItem*>(item);
		if (citem)
		{
			const QString key = makeStateGroup(citem->curId(), citem->name());
			savedState.insert(key, item->pos());
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (QGraphicsItem* qitem :collidingItems) {
			CanvasItem* citem = dynamic_cast<CanvasItem*>(qitem);
			if (citem && citem->m_zBehavior == CanvasItem::IsStrut)
			{
				//special condition for slopes: they must lie inside the strut's area, not only touch it
				Kolf::Slope* slope = dynamic_cast<Kolf::Slope*>(this);
				if (slope)
					if (!slope->collidesWithItem(qitem, Qt::ContainsItemBoundingRect))
						continue;
				//strut found
				m_strut = citem;
				break;
			}
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (CanvasItem* citem : qAsConst(m_struttedItems)) {
		QGraphicsItem* qitem = dynamic_cast<QGraphicsItem*>(citem);
		if (!qitem || qitem->data(0) == Rtti_Putter)
			continue;
		citem->moveBy(posDiff.x(), posDiff.y());
		Ball* ball = dynamic_cast<Ball*>(citem);
		if (ball && game && !game->isEditing() && game->curBall() == ball)
			game->ballMoved();
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (Kolf::Wall* wall : qAsConst(borderWalls))
		wall->setVisible(showing);
```

#### LAMBDA EXPRESSION 


```{c}
[minSlider, minSpinBox] {minSlider->setValue(qRound(minSpinBox->value()*100));}
```

#### AUTO 


```{c}
const auto collidingItems = self->collidingItems();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Kolf::ItemMetadata& metadata : knownTypes) {
		QListWidgetItem* item = new QListWidgetItem(metadata.name);
		item->setData(Qt::UserRole, metadata.identifier);
		m_typeList->addItem(item);
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (QGraphicsItem* qitem : collidingItems) {
		CanvasItem* citem = dynamic_cast<CanvasItem*>(qitem);
		if (citem)
			citem->updateZ(qitem);
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (CanvasItem* citem : std::as_const(m_struttedItems)) {
		QGraphicsItem* qitem = dynamic_cast<QGraphicsItem*>(citem);
		if (!qitem || qitem->data(0) == Rtti_Putter)
			continue;
		citem->moveBy(posDiff.x(), posDiff.y());
		Ball* ball = dynamic_cast<Ball*>(citem);
		if (ball && game && !game->isEditing() && game->curBall() == ball)
			game->ballMoved();
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (QGraphicsItem* qitem : std::as_const(m_topLevelQItems)) {
		if (dynamic_cast<Ball*>(qitem)) continue;
		CanvasItem *citem = dynamic_cast<CanvasItem *>(qitem);
		if (citem)
			citem->editModeChanged(editing);
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (QGraphicsItem* item : std::as_const(m_topLevelQItems)) {
		if (dynamic_cast<Ball*>(item)) continue; //see below
		CanvasItem* citem = dynamic_cast<CanvasItem*>(item);
		if (citem)
		{
			const QString key = makeStateGroup(citem->curId(), citem->name());
			const QPointF currentPos = item->pos();
			const QPointF posDiff = savedState.value(key, currentPos) - currentPos;
			citem->moveBy(posDiff.x(), posDiff.y());
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (QGraphicsItem* item : items) {
			CanvasItem *citem = dynamic_cast<CanvasItem *>(item);
			if (citem && citem->terrainCollisions())
			{
				// slopes return false
				// as only one should be processed
				// however that might not always be true
				if (!citem->collision(this))
				{
					break;
				}
			}
		}
```

#### AUTO 


```{c}
auto mainLayout = new QVBoxLayout(this);
```

#### AUTO 


```{c}
const auto currentTopLevelQItems = m_topLevelQItems;
```

#### LAMBDA EXPRESSION 


```{c}
[minSlider, minSpinBox] {
                  minSlider->setValue(qRound(minSpinBox->value() * 100));
                }
```

#### AUTO 


```{c}
auto *generator = QRandomGenerator::global();
```

#### RANGE FOR STATEMENT 


```{c}
for (QGraphicsItem* qitem : std::as_const(m_topLevelQItems)) {
		CanvasItem *citem = dynamic_cast<CanvasItem *>(qitem);
		if (citem)
			citem->shotStarted();
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (QGraphicsItem* qitem : qAsConst(m_topLevelQItems)) {
		CanvasItem *citem = dynamic_cast<CanvasItem *>(qitem);
		if (citem)
			citem->shotStarted();
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (Kolf::Wall* wall : qAsConst(m_walls))
		if (wall)
			wall->setPos(pos);
```

#### RANGE FOR STATEMENT 


```{c}
for (QGraphicsItem* item : std::as_const(m_topLevelQItems)) {
		if (dynamic_cast<Ball*>(item)) continue; //see below
		CanvasItem* citem = dynamic_cast<CanvasItem*>(item);
		if (citem)
		{
			const QString key = makeStateGroup(citem->curId(), citem->name());
			savedState.insert(key, item->pos());
		}
	}
```

#### AUTO 


```{c}
const auto knownTypes = m_factory.knownTypes();
```

#### LAMBDA EXPRESSION 


```{c}
[maxSlider, maxSpinBox] {
                  maxSlider->setValue(qRound(maxSpinBox->value() * 100));
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (QGraphicsItem* item : items) {
		if (item->data(0) == Rtti_NoCollision || item->data(0) == Rtti_Putter)
		{
			if (item->data(0) == Rtti_NoCollision)
				game->playSound(Sound::Wall);
			continue;
		}
	
		if (!isVisible() || state == Holed)
			return;

		CanvasItem *citem = dynamic_cast<CanvasItem *>(item);
		if (citem)
		{
			if (!citem->terrainCollisions())
			{
				//do collision
				const bool allowTerrainCollisions = citem->collision(this);
				doTerrainCollisions = doTerrainCollisions && allowTerrainCollisions;
			}
			break;
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (QGraphicsItem* qitem : qAsConst(m_topLevelQItems)) {
			CanvasItem *citem = dynamic_cast<CanvasItem *>(qitem);
			if (citem)
			{
				if (citem->curId() == i)
				{
					found = true;
					break;
				}
			}
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (CanvasItem* item : qAsConst(m_struttedItems))
		item->m_strut = nullptr;
```

#### RANGE FOR STATEMENT 


```{c}
for (Kolf::Wall* wall : std::as_const(borderWalls))
		wall->setVisible(showing);
```

#### AUTO 


```{c}
const auto infoItems = sceneItem->infoItems();
```

#### RANGE FOR STATEMENT 


```{c}
for (QGraphicsItem* qitem : std::as_const(infoItems))
		qitem->setVisible(m_showInfo);
```

#### RANGE FOR STATEMENT 


```{c}
for (QGraphicsItem* otherQitem : qAsConst(m_topLevelQItems)) {
		CanvasItem* otherCitem = dynamic_cast<CanvasItem*>(otherQitem);
		if (otherCitem && otherCitem != citem)
		{
			//false = do not create overlay if it does not exist yet
			Kolf::Overlay* otherOverlay = otherCitem->overlay(false);
			if (otherOverlay)
				otherOverlay->setState(Kolf::Overlay::Passive);
		}
	}
```

#### AUTO 


```{c}
auto buttonBox = new QDialogButtonBox(QDialogButtonBox::Ok);
```

