#### AUTO 


```{c}
auto appModel = qobject_cast<ConnectedAppModel *>(model);
```

#### AUTO 


```{c}
auto item = new QStandardItem(appName);
```

#### AUTO 


```{c}
auto e = dynamic_cast<InlineEditor *>(editor);
```

#### AUTO 


```{c}
auto p = static_cast<QListWidget *>(parent());
```

#### AUTO 


```{c}
auto fi = dynamic_cast<KWalletFolderItem *>(i);
```

#### AUTO 


```{c}
auto btn = new DisconnectAppButton(model->index(row, 0).data().toString(), _wallet);
```

#### AUTO 


```{c}
const auto w = viewport()->width();
```

#### AUTO 


```{c}
auto btn = new RevokeAuthButton(model->index(row, 0).data().toString(), _wallet);
```

#### AUTO 


```{c}
auto ci = dynamic_cast<KWalletContainerItem *>(item->parent());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &appName : apps) {
                setItem(row, 0, new QStandardItem(appName));
                setItem(row, 1, new QStandardItem(QStringLiteral("dummy"))); // this item will be hidden by the disconnect button, see below setIndexWidget call
                _authorizedAppsIndexMap.insert(appName, QPersistentModelIndex(index(row, 0)));
                row++;
            }
```

#### AUTO 


```{c}
auto item = new KWalletFolderItem(_w, _entryList, *i, entries.count());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &entry : entries) {
        str << entry;
        KWallet::Wallet::EntryType et = w._wallet->entryType(entry);
        str << (qint32)et;
        QByteArray a;
        w._wallet->readEntry(entry, a);
        str << a;
    }
```

#### AUTO 


```{c}
auto m = new QMenu(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &ch: text)
        if (!ch.isPrint()) ch = QLatin1Char('.');
```

#### AUTO 


```{c}
auto ci = dynamic_cast<KWalletContainerItem *>(ei->parent());
```

#### AUTO 


```{c}
auto stride =  chars / 3 / hexStride * hexStride;
```

#### AUTO 


```{c}
auto fi = dynamic_cast< KWalletFolderItem * >(item);
```

#### AUTO 


```{c}
auto end = createActionMethodList->end();
```

#### AUTO 


```{c}
auto twi = new QTreeWidgetItem(_wcw->_accessList, QStringList() << *i);
```

#### AUTO 


```{c}
auto appModel = qobject_cast<AuthorizedAppModel *>(model);
```

#### AUTO 


```{c}
const auto stride = calculateStride();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &appName : qAsConst(_connectedApps)) {
        // for un unknown reason, kwalletd returs empty strings so lets avoid inserting them
        // FIXME: find out why kwalletd returns empty strings here
        if (!appName.isEmpty()) {
            QStandardItem *item = new QStandardItem(appName);
            item->setEditable(false);
            setItem(row, 0, item);
            // this item will be hidden by the disconnect button, see below setIndexWidget call
            setItem(row, 1, new QStandardItem(QStringLiteral("dummy")));
            _connectedAppsIndexMap.insert(appName, QPersistentModelIndex(index(row, 0)));
            row++;
        }
    }
```

#### AUTO 


```{c}
auto page = qobject_cast<KWalletManagerWidgetItem *>(currentPage());
```

#### AUTO 


```{c}
auto pm = new QMenu(this);
```

#### AUTO 


```{c}
const auto ei = dynamic_cast<const KWalletEntryItem *>(i);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &cfgWalletName : keys) {
        if (cfgWalletName == walletName) {
            const QStringList apps = aa.readEntry(cfgWalletName, QStringList());
            int row = 0;
            for (const QString &appName : apps) {
                setItem(row, 0, new QStandardItem(appName));
                setItem(row, 1, new QStandardItem(QStringLiteral("dummy"))); // this item will be hidden by the disconnect button, see below setIndexWidget call
                _authorizedAppsIndexMap.insert(appName, QPersistentModelIndex(index(row, 0)));
                row++;
            }
        }
    }
```

#### AUTO 


```{c}
const auto fi = dynamic_cast<const KWalletFolderItem *>(i);
```

#### AUTO 


```{c}
const auto iconSize = KIconLoader::global()->currentSize(group);
```

#### AUTO 


```{c}
auto bi = new KWalletContainerItem(item, i18n("Binary Data"), KWallet::Wallet::Stream);
```

#### AUTO 


```{c}
const auto sEnd = qMin(it + hexStride, end);
```

#### AUTO 


```{c}
auto entryItem = dynamic_cast<KWalletEntryItem *>(child(i));
```

#### AUTO 


```{c}
auto &ch
```

#### AUTO 


```{c}
const auto em = fontMetrics().averageCharWidth();
```

#### AUTO 


```{c}
auto ci = dynamic_cast<KWalletContainerItem *>(p);
```

#### AUTO 


```{c}
auto mi = new KWalletContainerItem(item, i18n("Maps"), KWallet::Wallet::Map);
```

#### AUTO 


```{c}
auto ni = new KWalletEntryItem(_w, p, n);
```

#### AUTO 


```{c}
auto it = createActionMethodList->begin();
```

#### AUTO 


```{c}
auto bd = new KBetterThanKDialogBase(this);
```

#### AUTO 


```{c}
auto fi = dynamic_cast<KWalletFolderItem *>(sel);
```

#### AUTO 


```{c}
auto drag = new QDrag(this);
```

#### AUTO 


```{c}
auto end = qMin(it + stride, data.end());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &localFile : localFiles) {
        if (QFile::exists(localFile)) {
            QMimeType mt = mimeDb.mimeTypeForFile(localFile, QMimeDatabase::MatchContent);

            if (mt.isValid() && mt.inherits(QStringLiteral("application/x-kwallet"))) {
                openWalletFile(localFile);
            }
        }
    }
```

#### AUTO 


```{c}
auto ci = dynamic_cast<KWalletContainerItem *>(child(i));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &arg : positionalArguments) {
        const QString fn = QFileInfo(arg).absoluteFilePath();
        if (QFile::exists(fn)) {
            localFiles.append(fn);
        } else {
            openWallet(arg);
        }
    }
```

#### AUTO 


```{c}
const auto hexwidth = stride * 2 + (stride / hexStride) + 1;
```

#### AUTO 


```{c}
auto fi = dynamic_cast<KWalletFolderItem *>(_entryList->topLevelItem(i));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl& url : urls) {
        localFiles.append(url.toLocalFile());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &appName : std::as_const(_connectedApps)) {
        // for un unknown reason, kwalletd returs empty strings so lets avoid inserting them
        // FIXME: find out why kwalletd returns empty strings here
        if (!appName.isEmpty()) {
            auto item = new QStandardItem(appName);
            item->setEditable(false);
            setItem(row, 0, item);
            // this item will be hidden by the disconnect button, see below setIndexWidget call
            setItem(row, 1, new QStandardItem(QStringLiteral("dummy")));
            _connectedAppsIndexMap.insert(appName, QPersistentModelIndex(index(row, 0)));
            row++;
        }
    }
```

#### AUTO 


```{c}
const auto chars =  w / em - 1;
```

#### AUTO 


```{c}
auto *job = new KIO::CommandLauncherJob(QStringLiteral("kcmshell5"), {QStringLiteral("kwalletconfig5")});
```

#### AUTO 


```{c}
auto fi = dynamic_cast<KWalletFolderItem *>(item->parent()->parent());
```

#### AUTO 


```{c}
auto wi = new KWalletManagerWidgetItem(this, name);
```

#### AUTO 


```{c}
auto i = dynamic_cast<KWalletEntryItem *>(item);
```

#### AUTO 


```{c}
auto twi = new QTreeWidgetItem(_wcw->_accessList, QStringList() << walletName);
```

#### AUTO 


```{c}
auto box = new QVBoxLayout(_entryListFrame);
```

#### AUTO 


```{c}
auto fi = dynamic_cast<KWalletFolderItem *>(p->parent());
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &ch: text)
        if (!ch.isPrint()) ch = '.';
```

#### AUTO 


```{c}
auto lineEdit = new QLineEdit;
```

#### AUTO 


```{c}
auto mapEditor = static_cast<KWMapEditor *>(parent());
```

#### AUTO 


```{c}
auto ui = new KWalletContainerItem(item, i18n("Unknown"), KWallet::Wallet::Unknown);
```

#### AUTO 


```{c}
auto ke = static_cast<QKeyEvent *>(event);
```

#### AUTO 


```{c}
auto a = qobject_cast<QAction *>(sender());
```

#### AUTO 


```{c}
auto it = data.begin();
```

#### AUTO 


```{c}
auto fi =
                dynamic_cast<KWalletFolderItem *>(el->currentItem());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &appName : qAsConst(_connectedApps)) {
        // for un unknown reason, kwalletd returs empty strings so lets avoid inserting them
        // FIXME: find out why kwalletd returns empty strings here
        if (!appName.isEmpty()) {
            auto item = new QStandardItem(appName);
            item->setEditable(false);
            setItem(row, 0, item);
            // this item will be hidden by the disconnect button, see below setIndexWidget call
            setItem(row, 1, new QStandardItem(QStringLiteral("dummy")));
            _connectedAppsIndexMap.insert(appName, QPersistentModelIndex(index(row, 0)));
            row++;
        }
    }
```

#### AUTO 


```{c}
auto buttonBox = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel);
```

#### AUTO 


```{c}
auto job = new KIO::CommandLauncherJob(QStringLiteral("kcmshell5"), {QStringLiteral("kwalletconfig5")});
```

#### AUTO 


```{c}
auto pi = new KWalletContainerItem(item, i18n("Passwords"), KWallet::Wallet::Password);
```

#### AUTO 


```{c}
auto ac = new KActionCollection(this/*, "kwallet context actions"*/);
```

#### AUTO 


```{c}
auto fi = dynamic_cast<KWalletFolderItem *>(topLevelItem(i));
```

#### AUTO 


```{c}
auto b = new QToolButton(this);
```

