#### RANGE FOR STATEMENT 


```{c}
for(const FileAccess& dir : *pDirList)
    {
        if(dir.fileName() == ".cvsignore")
            return true;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const KIO::UDSEntry& e: l)
    {
        FileAccess fa;

        fa.setFromUdsEntry(e, m_pFileAccess);

        //must be manually filtered KDE does not supply API for ignoring these.
        if(fa.fileName() != "." && fa.fileName() != "..")
        {
            m_pDirList->push_back(std::move(fa));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(MergeFileInfos &mfi: m_fileMergeMap)
    {
        const QString& fileName = mfi.subPath();

        pp.setInformation(
            i18n("Processing %1 / %2\n%3", currentIdx, nrOfFiles, fileName), currentIdx, false);
        if(pp.wasCancelled()) break;
        ++currentIdx;

        // The comparisons and calculations for each file take place here.
        if(!mfi.compareFilesAndCalcAges(errors, m_pOptions, mWindow) && errors.size() >= 30)
            break;

        // Get dirname from fileName: Search for "/" from end:
        int pos = fileName.lastIndexOf('/');
        QString dirPart;
        QString filePart;
        if(pos == -1)
        {
            // Top dir
            filePart = fileName;
        }
        else
        {
            dirPart = fileName.left(pos);
            filePart = fileName.mid(pos + 1);
        }

        if(dirPart.isEmpty()) // Top level
        {
            m_pRoot->addChild(&mfi); //new DirMergeItem( this, filePart, &mfi );
            mfi.setParent(m_pRoot);
        }
        else
        {
            const FileAccess* pFA = mfi.getFileInfoA() ? mfi.getFileInfoA() : mfi.getFileInfoB() ? mfi.getFileInfoB() : mfi.getFileInfoC();
            MergeFileInfos& dirMfi = pFA->parent() ? m_fileMergeMap[FileKey(*pFA->parent())] : *m_pRoot; // parent

            dirMfi.addChild(&mfi); //new DirMergeItem( dirMfi.m_pDMI, filePart, &mfi );
            mfi.setParent(&dirMfi);
            //   // Equality for parent dirs is set in updateFileVisibilities()
        }

        mfi.updateAge();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto& pair: names)
        {
            insertCodec("", pair.second);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString& file : qAsConst(*s_pHistory))
         {
             pAction = new QAction(file, this);
             pAction->setData(file);
             connect(pAction, &QAction::triggered, this, &KDiff3FileItemAction::slotCompareWithHistoryItem);
             pHistoryMenu->addAction(pAction);
         }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QModelIndex& i : m_mergeItemList)
    {
        MergeFileInfos* pMFI = getMFI(i);
        ++nrOfItems;
        if(!pMFI->isOperationRunning())
            ++nrOfCompletedItems;
        if(!pMFI->isSimOpRunning())
            ++nrOfCompletedSimItems;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QFileInfo& fi: fiList) // for each file...
            {
                if(pp.wasCancelled())
                    break;

                assert(fi.fileName() != "." && fi.fileName() != "..");

                FileAccess fa;

                fa.setFile(mFileAccess, fi);
                pDirList->push_back(fa);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for(const MergeLine& ml: m_mergeLineList.list())
    {
        for(const MergeEditLine& mel: ml.list())
        {
            if(m_selection.lineWithin(line))
            {
                int outPos = 0;
                if(mel.isEditableText())
                {
                    const QString str = mel.getString(m_pldA, m_pldB, m_pldC);

                    // Consider tabs
                    for(int i = 0; i < str.length(); ++i)
                    {
                        int spaces = 1;
                        if(str[i] == '\t')
                        {
                            spaces = tabber(outPos, m_pOptions->m_tabSize);
                        }

                        if(m_selection.within(line, outPos))
                        {
                            selectionString += str[i];
                        }

                        outPos += spaces;
                    }
                }
                else if(mel.isConflict())
                {
                    selectionString += i18n("<Merge Conflict>");
                }

                if(m_selection.within(line, outPos))
                {
#ifdef Q_OS_WIN
                    selectionString += '\r';
#endif
                    selectionString += '\n';
                }
            }

            ++line;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString& regExp : regExpList)
    {
        QHash<QString, QRegExp>::iterator patIt = s_patternMap.find(regExp);
        if(patIt == s_patternMap.end())
        {
            QRegExp pattern(regExp, bCaseSensitive ? Qt::CaseSensitive : Qt::CaseInsensitive, QRegExp::Wildcard);
            patIt = s_patternMap.insert(regExp, pattern);
        }

        if(patIt.value().exactMatch(testString))
            return true;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const uint fieldId: fields)
    {
        switch(fieldId)
        {
            case KIO::UDSEntry::UDS_SIZE:
                m_size = e.numberValue(fieldId);
                break;
            case KIO::UDSEntry::UDS_NAME:
                filePath = e.stringValue(fieldId);
                qCDebug(kdiffFileAccess) << "filePath = " << filePath;
                break; // During listDir the relative path is given here.
            case KIO::UDSEntry::UDS_MODIFICATION_TIME:
                m_modificationTime = QDateTime::fromMSecsSinceEpoch(e.numberValue(fieldId));
                break;
            case KIO::UDSEntry::UDS_LINK_DEST:
                m_linkTarget = e.stringValue(fieldId);
                break;
            case KIO::UDSEntry::UDS_ACCESS:
                acc = e.numberValue(fieldId);
                m_bReadable = (acc & S_IRUSR) != 0;
                m_bWritable = (acc & S_IWUSR) != 0;
                m_bExecutable = (acc & S_IXUSR) != 0;
                break;
            case KIO::UDSEntry::UDS_FILE_TYPE:
                /*
                    According to KIO docs UDS_LINK_DEST not S_ISLNK should be used to determine if the url is a symlink.
                    UDS_FILE_TYPE is explicitly stated to be the type of the linked file not the link itself.
                */

                m_bSymLink = e.isLink();
                if(!m_bSymLink)
                {
                    fileType = e.numberValue(fieldId);
                    m_bDir = (fileType & QT_STAT_MASK) == QT_STAT_DIR;
                    m_bFile = (fileType & QT_STAT_MASK) == QT_STAT_REG;
                    m_bExists = fileType != 0;
                }
                else
                {
                    m_bDir = false;
                    m_bFile = false;
                    m_bExists = true;
                }
                break;
            case KIO::UDSEntry::UDS_URL:
                m_url = QUrl(e.stringValue(fieldId));
                qCDebug(kdiffFileAccess) << "Url = " << m_url;
                break;
            case KIO::UDSEntry::UDS_DISPLAY_NAME:
                mDisplayName = e.stringValue(fieldId);
                break;
            case KIO::UDSEntry::UDS_LOCAL_PATH:
                mPhysicalPath = e.stringValue(fieldId);
                break;
            case KIO::UDSEntry::UDS_MIME_TYPE:
            case KIO::UDSEntry::UDS_GUESSED_MIME_TYPE:
            case KIO::UDSEntry::UDS_XML_PROPERTIES:
            default:
                break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString &optionString : optionList)
    {
        int pos = optionString.indexOf('=');
        if(pos > 0) // seems not to have a tag
        {
            const QString key = optionString.left(pos);
            const QString val = optionString.mid(pos + 1);

            bool bFound = accept(key, val);

            if(!bFound)
            {
                result += "No config item named \"" + key + "\"\n";
            }
        }
        else
        {
            result += "No '=' found in \"" + optionString + "\"\n";
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QChar &c : line)
    {
        processChar(line, c);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString& pattern : patternList)
    {
        addEntry(pattern);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const CommentRange &range : comments)
    {
        /*
            assert isn't useful during auto testing as it causes the QTest not to show the actual line that
            the test failed on.
        */
#ifndef AUTOTEST
        assert(range.endOffset <= line.length() && range.startOffset <= line.length());
        assert(range.endOffset >= range.startOffset);
#else
        if(range.endOffset > line.length() && range.startOffset > line.length()) return;
        if(range.endOffset < range.startOffset) return;
#endif
        QtSizeType size = range.endOffset - range.startOffset;
        line.replace(range.startOffset, size, QString(" ").repeated(size));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const Diff3Line &diffRec : *this)
    {
        out << "line = " << i<< "\n";
        out << "lineA = " << diffRec.getLineA()<< "\n";
        out << "lineB = " << diffRec.getLineB()<< "\n";
        out << "lineC = " << diffRec.getLineC()<< "\n";

        out << "isEqualAB = " << diffRec.isEqualAB()<< "\n";
        out << "isEqualAC = " << diffRec.isEqualAC()<< "\n";
        out << "isEqualBC = " << diffRec.isEqualBC()<< "\n";
        ++i;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const FileAccess& fi2: dirList) // for each file...
            {
                Q_ASSERT(fi2.fileName() != "." && fi2.fileName() != "..");

                bSuccess = deleteFLD(fi2.absoluteFilePath(), false);
                if(!bSuccess) break;
            }
```

#### RANGE FOR STATEMENT 


```{c}
for(const CommentRange &range : comments)
    {
        /*
            Q_ASSERT isn't useful during auto testing as it causes the QTest not to show the actual line that
            the test failed on.
        */
#ifndef AUTOTEST
        Q_ASSERT(range.endOffset <= line.length() && range.startOffset <= line.length());
        Q_ASSERT(range.endOffset >= range.startOffset);
#else
        if(range.endOffset > line.length() && range.startOffset > line.length()) return;
        if(range.endOffset < range.startOffset) return;
#endif
        QtSizeType size = range.endOffset - range.startOffset;
        line.replace(range.startOffset, size, QString(" ").repeated(size));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const MergeEditLine& mel: ml.list())
        {
            if(m_selection.lineWithin(line))
            {
                int outPos = 0;
                if(mel.isEditableText())
                {
                    const QString str = mel.getString(m_pldA, m_pldB, m_pldC);

                    // Consider tabs
                    for(int i = 0; i < str.length(); ++i)
                    {
                        int spaces = 1;
                        if(str[i] == '\t')
                        {
                            spaces = tabber(outPos, m_pOptions->m_tabSize);
                        }

                        if(m_selection.within(line, outPos))
                        {
                            selectionString += str[i];
                        }

                        outPos += spaces;
                    }
                }
                else if(mel.isConflict())
                {
                    selectionString += i18n("<Merge Conflict>");
                }

                if(m_selection.within(line, outPos))
                {
#ifdef Q_OS_WIN
                    selectionString += '\r';
#endif
                    selectionString += '\n';
                }
            }

            ++line;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString& pattern: patternList)
    {
        addEntry(dir, pattern);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const FileAccess& dir : *pDirList)
    {
        if(dir.fileName() == getIgnoreName())
            return true;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(QRegularExpression& pattern: dirPattern.second)
        {
            if(!bCaseSensitive)
            {
                pattern.setPatternOptions(QRegularExpression::CaseInsensitiveOption);
            }
            const QRegularExpressionMatch match = pattern.match(text);
            if(match.hasMatch())
            {
                qCDebug(kdiffGitIgnoreList) << "Matched entry" << text;
                return true;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(const MergeEditLine& mel: ml.list())
        {
            if(mel.isEditableText() && m_selection.lineWithin(line))
            {
                if(!firstLine.isValid())
                    firstLine = line;
                lastLine = line;
            }

            ++line;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QFileInfo& fi: fiList) // for each file...
            {
                if(pp.wasCancelled())
                    break;

                Q_ASSERT(fi.fileName() != "." && fi.fileName() != "..");

                FileAccess fa;

                fa.setFile(m_pFileAccess, fi);
                pDirList->push_back(fa);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &entry: m_map)
    {
        const QString key = entry.first;
        const QString val = entry.second;
        ts << key << "=" << val << "\n";
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(QString ignorableOption: ignorableOptions)
        {
            ignorableOption.remove('-');
            if(!ignorableOption.isEmpty())
            {
                if(ignorableOption.length() == 1)
                {
                    cmdLineParser->addOption(QCommandLineOption({ignorableOption, u8"ignore"}, i18n("Ignored. (User defined.)")));
                }
                else
                {
                    cmdLineParser->addOption(QCommandLineOption(ignorableOption, i18n("Ignored. (User defined.)")));
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(const Diff& curDiff: *this)
        {
            Q_ASSERT(curDiff.diff1() <= TYPE_MAX(LineRef::LineType) && curDiff.diff2() <= TYPE_MAX(LineRef::LineType));
            l1 += curDiff.numberOfEquals() + LineRef(curDiff.diff1());
            l2 += curDiff.numberOfEquals() + LineRef(curDiff.diff2());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(const MergeLine& entry: m_mergeLineList.list())
    {
        if(entry.isConflict() || entry.isDelta())
            ++nrOfConflicts;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString &optionString : optionList)
    {
        int pos = optionString.indexOf('=');
        if(pos > 0) // seems not to have a tag
        {
            const QString key = optionString.left(pos);
            const QString val = optionString.mid(pos + 1);

            bool bFound = false;
            for(OptionItemBase* item : mOptionItemList)
            {
                if(item->getSaveName() == key)
                {
                    item->doPreserve();
                    ValueMap config;
                    config.writeEntry(key, val); // Write the value as a string and
                    item->read(&config);         // use the internal conversion from string to the needed value.
                    bFound = true;
                    break;
                }
            }
            if(!bFound)
            {
                result += "No config item named \"" + key + "\"\n";
            }
        }
        else
        {
            result += "No '=' found in \"" + optionString + "\"\n";
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const uint fieldId: fields)
    {
        switch(fieldId)
        {
            case KIO::UDSEntry::UDS_SIZE:
                m_size = e.numberValue(fieldId);
                break;
            case KIO::UDSEntry::UDS_NAME:
                filePath = e.stringValue(fieldId);
                break; // During listDir the relative path is given here.
            case KIO::UDSEntry::UDS_MODIFICATION_TIME:
                m_modificationTime = QDateTime::fromMSecsSinceEpoch(e.numberValue(fieldId));
                break;
            case KIO::UDSEntry::UDS_LINK_DEST:
                m_linkTarget = e.stringValue(fieldId);
                break;
            case KIO::UDSEntry::UDS_ACCESS:
#ifndef Q_OS_WIN
                acc = e.numberValue(fieldId);
                m_bReadable = (acc & S_IRUSR) != 0;
                m_bWritable = (acc & S_IWUSR) != 0;
                m_bExecutable = (acc & S_IXUSR) != 0;
#endif
                break;
            case KIO::UDSEntry::UDS_FILE_TYPE:
                /*
                    According to KIO docs UDS_LINK_DEST not S_ISLNK should be used to determine if the url is a symlink.
                    UDS_FILE_TYPE is explictitly stated to be the type of the linked file not the link itself.
                */

                m_bSymLink = e.isLink();
                if(!m_bSymLink)
                {
                    fileType = e.numberValue(fieldId);
                    m_bDir = (fileType & QT_STAT_MASK) == QT_STAT_DIR;
                    m_bFile = (fileType & QT_STAT_MASK) == QT_STAT_REG;
                    m_bExists = fileType != 0;
                }
                else
                {
                    m_bDir = false;
                    m_bFile = false;
                    m_bExists = true;
                }
                break;
            case KIO::UDSEntry::UDS_URL:
                m_url = QUrl(e.stringValue(fieldId));
                break;
            case KIO::UDSEntry::UDS_DISPLAY_NAME:
                mDisplayName = e.stringValue(fieldId);
                break;
            case KIO::UDSEntry::UDS_LOCAL_PATH:
                mPhysicalPath = e.stringValue(fieldId);
                break;
            case KIO::UDSEntry::UDS_MIME_TYPE:
            case KIO::UDSEntry::UDS_GUESSED_MIME_TYPE:
            case KIO::UDSEntry::UDS_XML_PROPERTIES:
            default:
                break;
        }
    }
```

#### AUTO 


```{c}
auto& pattern
```

#### RANGE FOR STATEMENT 


```{c}
for(const CommentRange &range : comments)
    {
        /*
            Q_ASSERT isn't useful during auto testing as it causes the QTest not to show the actual line that
            the test failed on.
        */
#ifndef AUTOTEST
        Q_ASSERT(range.endOffset <= line.length() && range.startOffset <= line.length());
        Q_ASSERT(range.endOffset >= range.startOffset);
#endif
        qint32 size = range.endOffset - range.startOffset;
        line.replace(range.startOffset, size, QString(" ").repeated(size));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(OptionItemBase* item : mOptionItemList)
    {
        item->apply();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString& globStr: ignorePatternsIt->second.m_generalPatterns)
    {
        QRegularExpression pattern(QRegularExpression::wildcardToRegularExpression(globStr), bCaseSensitive ? QRegularExpression::UseUnicodePropertiesOption : QRegularExpression::UseUnicodePropertiesOption | QRegularExpression::CaseInsensitiveOption);
        if(pattern.match(text).hasMatch())
            return true;
    }
```

#### AUTO 


```{c}
const auto ignorePatternsIt = m_ignorePatterns.find(dir);
```

#### RANGE FOR STATEMENT 


```{c}
for(QString ignorableOption : ignorableOptions)
        {
            ignorableOption.remove('-');
            if(!ignorableOption.isEmpty())
            {
                if(ignorableOption.length() == 1) {
                    cmdLineParser->addOption(QCommandLineOption({ignorableOption, u8"ignore"}, i18n("Ignored. (User defined.)")));
                }
                else
                {
                    cmdLineParser->addOption(QCommandLineOption(ignorableOption, i18n("Ignored. (User defined.)")));
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(const Diff3Line &entry: *this)
    {
        LineRef line;

        assert(srcSelector == e_SrcSelector::A || srcSelector == e_SrcSelector::B || srcSelector == e_SrcSelector::C);
        if(srcSelector == e_SrcSelector::A)
            line = entry.getLineA();
        else if(srcSelector == e_SrcSelector::B)
            line = entry.getLineB();
        else if(srcSelector == e_SrcSelector::C)
            line = entry.getLineC();

        if(line.isValid())
        {
            if(line != i)
            {
                #ifndef AUTOTEST
                KMessageBox::error(nullptr, i18n("Data loss error:\n"
                                                 "If it is reproducible please contact the author.\n"),
                                   i18n("Severe Internal Error"));
                #endif

                qCCritical(kdiffMain) << "Severe Internal Error." << " line != i for srcSelector=" << (int)srcSelector << "\n";
                ::exit(-1);
            }
            ++i;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString& s: recentEncodings)
            {
                insertCodec("", QTextCodec::codecForName(s.toLatin1()), codecEnumList, m_pContextEncodingMenu, currentTextCodecEnum);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for(int i : mibs)
        {
            QTextCodec* c = QTextCodec::codecForMib(i);
            if(c != nullptr)
                insertCodec("", c, codecEnumList, pContextEncodingSubMenu, currentTextCodecEnum);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(QRegularExpression& pattern: dirPattern.second)
        {
            if(!bCaseSensitive)
            {
                pattern.setPatternOptions(QRegularExpression::CaseInsensitiveOption | QRegularExpression::UseUnicodePropertiesOption);
            }
            else
            {
                pattern.setPatternOptions(QRegularExpression::UseUnicodePropertiesOption);
            }
            const QRegularExpressionMatch match = pattern.match(text);
            if(match.hasMatch())
            {
                qCDebug(kdiffGitIgnoreList) << "Matched entry" << text;
                return true;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString& keyIt : keyOrderList)
    {
        if(keyIt.isEmpty())
            continue;
        bool bOk = false;
        int groupIdx = keyIt.toInt(&bOk);
        if(!bOk || groupIdx < 0 || groupIdx > parenthesesGroupList.size())
            continue;
        QString s = matchedRegExpr.cap(groupIdx);
        if(groupIdx == 0)
        {
            key += s + ' ';
            continue;
        }

        QString groupRegExp = parenthesesGroupList[groupIdx - 1];
        if(groupRegExp.indexOf('|') < 0 || groupRegExp.indexOf('(') >= 0)
        {
            bOk = false;
            int i = s.toInt(&bOk);
            if(bOk && i >= 0 && i < 10000)
            {
                s += QString(4 - s.size(), '0'); // This should help for correct sorting of numbers.
            }
            key += s + ' ';
        }
        else
        {
            // Assume that the groupRegExp consists of something like "Jan|Feb|Mar|Apr"
            // s is the string that managed to match.
            // Now we want to know at which position it occurred. e.g. Jan=0, Feb=1, Mar=2, etc.
            QStringList sl = groupRegExp.split('|');
            int idx = sl.indexOf(s);
            if(idx >= 0)
            {
                QString sIdx;
                sIdx.setNum(idx);
                Q_ASSERT(sIdx.size() <= 2);
                sIdx += QString(2 - sIdx.size(), '0'); // Up to 99 words in the groupRegExp (more than 12 aren't expected)
                key += sIdx + ' ';
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const MergeLine& ml: m_mergeLineList.list())
    {
        for(const MergeEditLine& mel: ml.list())
        {
            if(mel.isEditableText() && m_selection.lineWithin(line))
            {
                if(!firstLine.isValid())
                    firstLine = line;
                lastLine = line;
            }

            ++line;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(int i: mibs)
    {
        QTextCodec* c = QTextCodec::codecForMib(i);
        if(c != nullptr)
            names[QLatin1String(c->name())] = c;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const Diff3Line &entry: *this)
    {
        LineRef line;

        Q_ASSERT(srcSelector == e_SrcSelector::A || srcSelector == e_SrcSelector::B || srcSelector == e_SrcSelector::C);
        if(srcSelector == e_SrcSelector::A)
            line = entry.getLineA();
        else if(srcSelector == e_SrcSelector::B)
            line = entry.getLineB();
        else if(srcSelector == e_SrcSelector::C)
            line = entry.getLineC();

        if(line.isValid())
        {
            if(line != i)
            {
                #ifndef AUTOTEST
                KMessageBox::error(nullptr, i18n("Data loss error:\n"
                                                 "If it is reproducible please contact the author.\n"),
                                   i18n("Severe Internal Error"));
                #endif

                qCCritical(kdiffMain) << "Severe Internal Error." << " line != i for srcSelector=" << (int)srcSelector << "\n";
                ::exit(-1);
            }
            ++i;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(MergeFileInfos& mfi: m_fileMergeMap)
    {
        const QString& fileName = mfi.subPath();

        pp.setInformation(
            i18n("Processing %1 / %2\n%3", currentIdx, nrOfFiles, fileName), currentIdx, false);
        if(pp.wasCancelled()) break;
        ++currentIdx;

        // The comparisons and calculations for each file take place here.
        if(!mfi.compareFilesAndCalcAges(errors, m_pOptions, mWindow) && errors.size() >= 30)
            break;

        // Get dirname from fileName: Search for "/" from end:
        int pos = fileName.lastIndexOf('/');
        QString dirPart;
        QString filePart;
        if(pos == -1)
        {
            // Top dir
            filePart = fileName;
        }
        else
        {
            dirPart = fileName.left(pos);
            filePart = fileName.mid(pos + 1);
        }

        if(dirPart.isEmpty()) // Top level
        {
            m_pRoot->addChild(&mfi); // new DirMergeItem( this, filePart, &mfi );
            mfi.setParent(m_pRoot);
        }
        else
        {
            const FileAccess* pFA = mfi.getFileInfoA() ? mfi.getFileInfoA() : mfi.getFileInfoB() ? mfi.getFileInfoB() :
                                                                                                   mfi.getFileInfoC();
            MergeFileInfos& dirMfi = pFA->parent() ? m_fileMergeMap[FileKey(*pFA->parent())] : *m_pRoot; // parent

            dirMfi.addChild(&mfi); // new DirMergeItem( dirMfi.m_pDMI, filePart, &mfi );
            mfi.setParent(&dirMfi);
            //   // Equality for parent dirs is set in updateFileVisibilities()
        }

        mfi.updateAge();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString& s : recentEncodings)
            {
                insertCodec("", QTextCodec::codecForName(s.toLatin1()), codecEnumList, m_pContextEncodingMenu, currentTextCodecEnum);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for(int i: mibs)
        {
            QTextCodec* c = QTextCodec::codecForMib(i);
            if(c != nullptr)
                names[QString(QLatin1String(c->name())).toUpper()] = c;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString& startPattern: ignorePatternsIt->second.m_startPatterns)
    {
        if(text.startsWith(startPattern, bCaseSensitive ? Qt::CaseSensitive : Qt::CaseInsensitive))
        {
            return true;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString& optionString: optionList)
    {
        int pos = optionString.indexOf('=');
        if(pos > 0) // seems not to have a tag
        {
            const QString key = optionString.left(pos);
            const QString val = optionString.mid(pos + 1);

            bool bFound = accept(key, val);

            if(!bFound)
            {
                result += "No config item named \"" + key + "\"\n";
            }
        }
        else
        {
            result += "No '=' found in \"" + optionString + "\"\n";
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto& pattern : dirPattern.second)
        {
            if(bCaseSensitive == false)
            {
                pattern.setPatternOptions(QRegularExpression::CaseInsensitiveOption);
            }
            const auto match = pattern.match(text);
            if(match.hasMatch())
            {
                qCDebug(kdiffGitIgnoreList) << "Matched entry" << text;
                return true;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString& regExp : regExpList)
    {
        QHash<QString, QRegularExpression>::iterator patIt = s_patternMap.find(regExp);
        if(patIt == s_patternMap.end())
        {
            QRegularExpression pattern(QRegularExpression::wildcardToRegularExpression(regExp), bCaseSensitive ? QRegularExpression::NoPatternOption : QRegularExpression::CaseInsensitiveOption);
            patIt = s_patternMap.insert(regExp, pattern);
        }

        if(patIt.value().match(testString).hasMatch())
            return true;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(Diff3Line& d3l: *this)
        {
            if(resetDisplayCount)
                d3l.mLinesNeededForDisplay = 1;
            
            d3l.mSumLinesNeededForDisplay = sumOfLines;
            sumOfLines += d3l.linesNeededForDisplay();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto& dirPattern: m_patterns)
    {
        if(!dir.startsWith(dirPattern.first))
        {
            continue;
        }
        for(QRegularExpression& pattern: dirPattern.second)
        {
            if(!bCaseSensitive)
            {
                pattern.setPatternOptions(QRegularExpression::CaseInsensitiveOption);
            }
            const QRegularExpressionMatch match = pattern.match(text);
            if(match.hasMatch())
            {
                qCDebug(kdiffGitIgnoreList) << "Matched entry" << text;
                return true;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const Diff3Line &d: diff3List)
    {
        MergeLine ml;
        bool bLineRemoved;
        ml.mergeOneLine(d, bLineRemoved, !isThreeway);
        ml.dectectWhiteSpaceConflict(d, isThreeway);

        ml.d3lLineIdx = lineIdx;
        ml.bDelta = ml.srcSelect != e_SrcSelector::A;
        ml.mId3l = it;
        ml.srcRangeLength = 1;

        MergeLine *back = mList.empty() ? nullptr : &mList.back();

        bool bSame = back != nullptr && ml.isSameKind(*back);
        if(bSame)
        {
            ++back->srcRangeLength;
            if(back->isWhiteSpaceConflict() && !ml.isWhiteSpaceConflict())
                back->bWhiteSpaceConflict = false;
        }
        else
        {
            mList.push_back(ml);
        }

        if(!ml.isConflict())
        {
            MergeLine &tmpBack = mList.back();
            MergeEditLine mel(ml.id3l());
            mel.setSource(ml.srcSelect, bLineRemoved);
            tmpBack.mergeEditLineList.push_back(mel);
        }
        else if(back == nullptr || !back->isConflict() || !bSame)
        {
            MergeLine &tmpBack = mList.back();
            MergeEditLine mel(ml.id3l());
            mel.setConflict();
            tmpBack.mergeEditLineList.push_back(mel);
        }

        ++lineIdx;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const Diff& curDiff: *this)
        {
            assert(curDiff.diff1() <= TYPE_MAX(LineRef::LineType) && curDiff.diff2() <= TYPE_MAX(LineRef::LineType));
            l1 += curDiff.numberOfEquals() + LineRef(curDiff.diff1());
            l2 += curDiff.numberOfEquals() + LineRef(curDiff.diff2());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(Diff3Line d3l: *this)
        {
            d3l.linesNeededForDisplay = 1;
            d3l.sumLinesNeededForDisplay = sumOfLines;
            sumOfLines += d3l.linesNeededForDisplay;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(OptionItemBase* item : mOptionItemList)
    {
        item->read(&cvm);
    }
```

#### AUTO 


```{c}
const auto directoryListIt = std::find_if(directoryList.begin(), directoryList.end(), [](const FileAccess& file) {
        return file.fileName() == ".gitignore";
    });
```

#### RANGE FOR STATEMENT 


```{c}
for(const MergeLine& ml: m_mergeLineList.list())
        {
            for(const MergeEditLine& mel: ml.list())
            {
                QString s = mel.getString(m_pldA, m_pldB, m_pldC);

                QTextLayout textLayout(s, font(), this);
                textLayout.beginLayout();
                textLayout.createLine();
                textLayout.endLayout();
                if(m_maxTextWidth < textLayout.maximumWidth())
                {
                    m_maxTextWidth = qCeil(textLayout.maximumWidth());
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(const uint fieldId: fields)
    {
        switch(fieldId)
        {
            case KIO::UDSEntry::UDS_SIZE:
                m_size = e.numberValue(fieldId);
                break;
            case KIO::UDSEntry::UDS_NAME:
                filePath = e.stringValue(fieldId);
                qCDebug(kdiffFileAccess) << "filePath = " << filePath;
                break; // During listDir the relative path is given here.
            case KIO::UDSEntry::UDS_MODIFICATION_TIME:
                m_modificationTime = QDateTime::fromMSecsSinceEpoch(e.numberValue(fieldId));
                break;
            case KIO::UDSEntry::UDS_LINK_DEST:
                m_linkTarget = e.stringValue(fieldId);
                break;
            case KIO::UDSEntry::UDS_ACCESS:
#ifndef Q_OS_WIN
                acc = e.numberValue(fieldId);
                m_bReadable = (acc & S_IRUSR) != 0;
                m_bWritable = (acc & S_IWUSR) != 0;
                m_bExecutable = (acc & S_IXUSR) != 0;
#endif
                break;
            case KIO::UDSEntry::UDS_FILE_TYPE:
                /*
                    According to KIO docs UDS_LINK_DEST not S_ISLNK should be used to determine if the url is a symlink.
                    UDS_FILE_TYPE is explicitly stated to be the type of the linked file not the link itself.
                */

                m_bSymLink = e.isLink();
                if(!m_bSymLink)
                {
                    fileType = e.numberValue(fieldId);
                    m_bDir = (fileType & QT_STAT_MASK) == QT_STAT_DIR;
                    m_bFile = (fileType & QT_STAT_MASK) == QT_STAT_REG;
                    m_bExists = fileType != 0;
                }
                else
                {
                    m_bDir = false;
                    m_bFile = false;
                    m_bExists = true;
                }
                break;
            case KIO::UDSEntry::UDS_URL:
                m_url = QUrl(e.stringValue(fieldId));
                qCDebug(kdiffFileAccess) << "Url = " << m_url;
                break;
            case KIO::UDSEntry::UDS_DISPLAY_NAME:
                mDisplayName = e.stringValue(fieldId);
                break;
            case KIO::UDSEntry::UDS_LOCAL_PATH:
                mPhysicalPath = e.stringValue(fieldId);
                break;
            case KIO::UDSEntry::UDS_MIME_TYPE:
            case KIO::UDSEntry::UDS_GUESSED_MIME_TYPE:
            case KIO::UDSEntry::UDS_XML_PROPERTIES:
            default:
                break;
        }
    }
```

#### AUTO 


```{c}
const auto match = pattern.match(text);
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString& error: qAsConst(errors))
        {
            KMessageBox::error(m_pOptionDialog, error);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto& line : lineList)
    {
        if(isComment(line))
        {
            continue;
        }
        QRegularExpression expression(QRegularExpression::wildcardToRegularExpression(line));
        if(expression.isValid() == false)
        {
            qCDebug(kdiffGitIgnoreList) << "Expression" << line << "is not valid - skipping ...";
            continue;
        }
        qCDebug(kdiffGitIgnoreList) << "Adding entry [" << dir << "]" << line;
        m_patterns[dir].push_back(expression);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString& globStr : ignorePatternsIt->second.m_generalPatterns)
    {
        QRegExp pattern(globStr, bCaseSensitive ? Qt::CaseSensitive : Qt::CaseInsensitive, QRegExp::Wildcard);
        if(pattern.exactMatch(text))
            return true;
    }
```

#### AUTO 


```{c}
auto it = diff3List.cbegin();
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString& globStr : m_generalPatterns)
    {
        QRegExp pattern(globStr, bCaseSensitive ? Qt::CaseSensitive : Qt::CaseInsensitive, QRegExp::Wildcard);
        if(pattern.exactMatch(text))
            return true;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString& keyIt : keyOrderList)
    {
        if(keyIt.isEmpty())
            continue;
        bool bOk = false;
        int groupIdx = keyIt.toInt(&bOk);
        if(!bOk || groupIdx < 0 || groupIdx > parenthesesGroupList.size())
            continue;
        QString s = regExprMatch.captured(groupIdx);
        if(groupIdx == 0)
        {
            key += s + ' ';
            continue;
        }

        QString groupRegExp = parenthesesGroupList[groupIdx - 1];
        if(groupRegExp.indexOf('|') < 0 || groupRegExp.indexOf('(') >= 0)
        {
            bOk = false;
            int i = s.toInt(&bOk);
            if(bOk && i >= 0 && i < 10000)
            {
                s += QString(4 - s.size(), '0'); // This should help for correct sorting of numbers.
            }
            key += s + ' ';
        }
        else
        {
            // Assume that the groupRegExp consists of something like "Jan|Feb|Mar|Apr"
            // s is the string that managed to match.
            // Now we want to know at which position it occurred. e.g. Jan=0, Feb=1, Mar=2, etc.
            QStringList sl = groupRegExp.split('|');
            int idx = sl.indexOf(s);
            if(idx >= 0)
            {
                QString sIdx;
                sIdx.setNum(idx);
                assert(sIdx.size() <= 2);
                sIdx += QString(2 - sIdx.size(), '0'); // Up to 99 words in the groupRegExp (more than 12 aren't expected)
                key += sIdx + ' ';
            }
        }
    }
```

#### AUTO 


```{c}
const auto &entry
```

#### RANGE FOR STATEMENT 


```{c}
for(const Diff3Line &entry: *this)
    {
        LineRef line;

        Q_ASSERT(srcSelector == e_SrcSelector::A || srcSelector == e_SrcSelector::B || srcSelector == e_SrcSelector::C);
        if(srcSelector == e_SrcSelector::A)
            line = entry.getLineA();
        else if(srcSelector == e_SrcSelector::B)
            line = entry.getLineB();
        else if(srcSelector == e_SrcSelector::C)
            line = entry.getLineC();

        if(line.isValid())
        {
            if(line != i)
            {
                KMessageBox::error(nullptr, i18n(
                                          "Data loss error:\n"
                                          "If it is reproducible please contact the author.\n"),
                                   i18n("Severe Internal Error"));

                qCCritical(kdiffMain) << i18n("Severe Internal Error.") << " line != i for srcSelector=" << (int)srcSelector << "\n";
                ::exit(-1);
            }
            ++i;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const FileAccess& dir : pDirList)
    {
        if(dir.fileName() == getIgnoreName())
            return true;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(QString ignorableOption : ignorableOptions)
        {
            ignorableOption.remove('-');
            if(!ignorableOption.isEmpty())
            {
                if(ignorableOption.length() == 1) {
                    cmdLineParser->addOption(QCommandLineOption({ignorableOption, QLatin1String("ignore")}, i18n("Ignored. (User defined.)")));
                }
                else
                {
                    cmdLineParser->addOption(QCommandLineOption(ignorableOption, i18n("Ignored. (User defined.)")));
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString& file: qAsConst(*s_pHistory))
            {
                pAction = new QAction(file, this);
                pAction->setData(file);
                connect(pAction, &QAction::triggered, this, &KDiff3FileItemAction::slotCompareWithHistoryItem);
                pHistoryMenu->addAction(pAction);
            }
```

#### CONST EXPRESSION 


```{c}
constexpr bool g_bIgnoreWhiteSpace = true;
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString& globStr : ignorePatternsIt->second.m_generalPatterns)
    {
        QRegularExpression pattern(QRegularExpression::wildcardToRegularExpression(globStr), bCaseSensitive ? QRegularExpression::NoPatternOption : QRegularExpression::CaseInsensitiveOption);
        if(pattern.match(text).hasMatch())
            return true;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const MergeEditLine& mel: ml.list())
            {
                QString s = mel.getString(m_pldA, m_pldB, m_pldC);

                QTextLayout textLayout(s, font(), this);
                textLayout.beginLayout();
                textLayout.createLine();
                textLayout.endLayout();
                if(m_maxTextWidth < textLayout.maximumWidth())
                {
                    m_maxTextWidth = qCeil(textLayout.maximumWidth());
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString& startPattern: m_startPatterns)
    {
        if(text.startsWith(startPattern))
        {
            return true;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto& dirPattern: m_patterns)
    {
        if(!dir.startsWith(dirPattern.first))
        {
            continue;
        }
        for(QRegularExpression& pattern: dirPattern.second)
        {
            if(!bCaseSensitive)
            {
                pattern.setPatternOptions(QRegularExpression::CaseInsensitiveOption | QRegularExpression::UseUnicodePropertiesOption);
            }
            else
            {
                pattern.setPatternOptions(QRegularExpression::UseUnicodePropertiesOption);
            }
            const QRegularExpressionMatch match = pattern.match(text);
            if(match.hasMatch())
            {
                qCDebug(kdiffGitIgnoreList) << "Matched entry" << text;
                return true;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(Diff3Line& diff3Line: *this)
    {
        diff3Line.bWhiteLineA = (!diff3Line.getLineA().isValid() || pldA == nullptr || (*pldA)[diff3Line.getLineA()].whiteLine() || (bIgnoreComments && (*pldA)[diff3Line.getLineA()].isPureComment()));
        diff3Line.bWhiteLineB = (!diff3Line.getLineB().isValid() || pldB == nullptr || (*pldB)[diff3Line.getLineB()].whiteLine() || (bIgnoreComments && (*pldB)[diff3Line.getLineB()].isPureComment()));
        diff3Line.bWhiteLineC = (!diff3Line.getLineC().isValid() || pldC == nullptr || (*pldC)[diff3Line.getLineC()].whiteLine() || (bIgnoreComments && (*pldC)[diff3Line.getLineC()].isPureComment()));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(OptionItemBase* item : mOptionItemList)
    {
        item->write(&config);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(FileAccess& fileRecord: dirInfo->getDirListA())
        {
            MergeFileInfos& mfi = m_fileMergeMap[FileKey(fileRecord)];

            mfi.setFileInfoA(&fileRecord);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString& keyIt : keyOrderList)
    {
        if(keyIt.isEmpty())
            continue;
        bool bOk = false;
        int groupIdx = keyIt.toInt(&bOk);
        if(!bOk || groupIdx < 0 || groupIdx > parenthesesGroupList.size())
            continue;
        QString s = regExprMatch.captured(groupIdx);
        if(groupIdx == 0)
        {
            key += s + ' ';
            continue;
        }

        QString groupRegExp = parenthesesGroupList[groupIdx - 1];
        if(groupRegExp.indexOf('|') < 0 || groupRegExp.indexOf('(') >= 0)
        {
            bOk = false;
            int i = s.toInt(&bOk);
            if(bOk && i >= 0 && i < 10000)
            {
                s += QString(4 - s.size(), '0'); // This should help for correct sorting of numbers.
            }
            key += s + ' ';
        }
        else
        {
            // Assume that the groupRegExp consists of something like "Jan|Feb|Mar|Apr"
            // s is the string that managed to match.
            // Now we want to know at which position it occurred. e.g. Jan=0, Feb=1, Mar=2, etc.
            QStringList sl = groupRegExp.split('|');
            int idx = sl.indexOf(s);
            if(idx >= 0)
            {
                QString sIdx;
                sIdx.setNum(idx);
                Q_ASSERT(sIdx.size() <= 2);
                sIdx += QString(2 - sIdx.size(), '0'); // Up to 99 words in the groupRegExp (more than 12 aren't expected)
                key += sIdx + ' ';
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString& error: qAsConst(errors))
                {
                    KMessageBox::error(m_pOptionDialog, error);
                }
```

#### CONST EXPRESSION 


```{c}
constexpr char varname[] = "CVSIGNORE";
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString& pattern : patternList)
    {
        addEntry(dir, pattern);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const MergeEditLine& mel: ml.list())
        {
            if(mel.isEditableText())
            {
                const QString str = mel.getString(m_pldA, m_pldB, m_pldC);

                if(line > 0 && !mel.isRemoved())
                {
                    // Put line feed between lines, but not for the first line
                    // or between lines that have been removed (because there
                    // isn't a line there).
                    textOutStream << lineFeed;
                }

                textOutStream << str;
                ++line;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QModelIndex& i: m_mergeItemList)
    {
        MergeFileInfos* pMFI = getMFI(i);
        ++nrOfItems;
        if(!pMFI->isOperationRunning())
            ++nrOfCompletedItems;
        if(!pMFI->isSimOpRunning())
            ++nrOfCompletedSimItems;
    }
```

#### AUTO 


```{c}
const auto &d = *it;
```

#### RANGE FOR STATEMENT 


```{c}
for(const FileAccess& dir: pDirList)
    {
        if(dir.fileName() == getIgnoreName())
            return true;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(OptionItemBase* item : mOptionItemList)
    {
        item->setToCurrent();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &entry: m_map)
    {
        const QString key = entry.first;
        const QString val = entry.second;
        result += key + '=' + val + '\n';
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString& endPattern: m_endPatterns)
    {
        if(text.endsWith(endPattern, bCaseSensitive ? Qt::CaseSensitive : Qt::CaseInsensitive))
        {
            return true;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(FileAccess& fileRecord: dirInfo->getDirListB())
        {
            MergeFileInfos& mfi = m_fileMergeMap[FileKey(fileRecord)];

            mfi.setFileInfoB(&(fileRecord));
        }
```

#### CONST EXPRESSION 


```{c}
constexpr int topLineYOffset = 0;
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString& endPattern: ignorePatternsIt->second.m_endPatterns)
    {
        if(text.endsWith(endPattern, bCaseSensitive ? Qt::CaseSensitive : Qt::CaseInsensitive))
        {
            return true;
        }
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr int s_linesPerRunnable = 2000;
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString& endPattern: m_endPatterns)
    {
        if(text.mid(text.length() - endPattern.length()) == endPattern) //(text.endsWith(*it))
        {
            Q_ASSERT(text.endsWith(endPattern));
            return true;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const MergeLine& ml: m_mergeLineList.list())
    {
        for(const MergeEditLine& mel: ml.list())
        {
            if(mel.isEditableText())
            {
                const QString str = mel.getString(m_pldA, m_pldB, m_pldC);

                if(line > 0 && !mel.isRemoved())
                {
                    // Put line feed between lines, but not for the first line
                    // or between lines that have been removed (because there
                    // isn't a line there).
                    textOutStream << lineFeed;
                }

                textOutStream << str;
                ++line;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const ManualDiffHelpEntry& mdhe: *this)
        {
            if(!mdhe.isValidMove(line1, line2, winIdx1, winIdx2)) return false;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(const Diff& theDiff: diffList)
        {
            l1 += (theDiff.numberOfEquals() + theDiff.diff1());
            l2 += (theDiff.numberOfEquals() + theDiff.diff2());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(const CommentRange &range : comments)
    {
        /*
            Q_ASSERT isn't useful during auto testing as it causes the QTest not to show the actual line that
            the test failed on.
        */
#ifndef AUTOTEST
        Q_ASSERT(range.endOffset <= line.length() && range.startOffset <= line.length());
        Q_ASSERT(range.endOffset >= range.startOffset);
#else
        if(range.endOffset > line.length() && range.startOffset > line.length()) return;
        if(range.endOffset < range.startOffset) return;
#endif
        qint32 size = range.endOffset - range.startOffset;
        line.replace(range.startOffset, size, QString(" ").repeated(size));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const MergeLine& ml: m_mergeLineList.list())
    {
        MergeEditLineList::const_iterator melIt = ml.list().cbegin();
        if(melIt->isConflict())
        {
            ++nrOfUnsolvedConflicts;
            if(ml.isWhiteSpaceConflict() && pNrOfWhiteSpaceConflicts != nullptr)
                ++*pNrOfWhiteSpaceConflicts;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(int i: mibs)
        {
            QTextCodec* c = QTextCodec::codecForMib(i);
            if(c != nullptr)
                insertCodec("", c, codecEnumList, pContextEncodingSubMenu, currentTextCodecEnum);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(const std::unique_ptr<IgnoreList>& ignoreList : m_ignoreLists)
    {
        ignoreList->enterDir(dir, directoryList);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(Diff3Line& d3l: *this)
        {
            if(resetDisplayCount)
                d3l.mLinesNeededForDisplay = 1;

            d3l.mSumLinesNeededForDisplay = sumOfLines;
            sumOfLines += d3l.linesNeededForDisplay();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(const KIO::UDSEntry& e: l)
    {
        FileAccess fa;

        fa.setFromUdsEntry(e, m_pFileAccess);

        //must be manually filtered KDE does not supply API for ignoring these.
        if(fa.fileName() != "." && fa.fileName() != ".." && fa.isValid())
        {
            m_pDirList->push_back(std::move(fa));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(Diff3Line& diff3Line: *this)
    {
        diff3Line.bWhiteLineA = (!diff3Line.getLineA().isValid() || (*pldA)[diff3Line.getLineA()].whiteLine() || (bIgnoreComments && (*pldA)[diff3Line.getLineA()].isPureComment()));
        diff3Line.bWhiteLineB = (!diff3Line.getLineB().isValid() || (*pldB)[diff3Line.getLineB()].whiteLine() || (bIgnoreComments && (*pldB)[diff3Line.getLineB()].isPureComment()));
        diff3Line.bWhiteLineC = (!diff3Line.getLineC().isValid() || (*pldC)[diff3Line.getLineC()].whiteLine() || (bIgnoreComments && (*pldC)[diff3Line.getLineC()].isPureComment()));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const uint fieldId: fields)
    {
        switch(fieldId)
        {
            case KIO::UDSEntry::UDS_SIZE:
                m_size = e.numberValue(fieldId);
                break;
            case KIO::UDSEntry::UDS_NAME:
                filePath = e.stringValue(fieldId);
                break; // During listDir the relative path is given here.
            case KIO::UDSEntry::UDS_MODIFICATION_TIME:
                m_modificationTime = QDateTime::fromMSecsSinceEpoch(e.numberValue(fieldId));
                break;
            case KIO::UDSEntry::UDS_LINK_DEST:
                m_linkTarget = e.stringValue(fieldId);
                break;
            case KIO::UDSEntry::UDS_ACCESS:
#ifndef Q_OS_WIN
                acc = e.numberValue(fieldId);
                m_bReadable = (acc & S_IRUSR) != 0;
                m_bWritable = (acc & S_IWUSR) != 0;
                m_bExecutable = (acc & S_IXUSR) != 0;
#endif
                break;
            case KIO::UDSEntry::UDS_FILE_TYPE:
                /*
                    According to KIO docs UDS_LINK_DEST not S_ISLNK should be used to determine if the url is a symlink.
                    UDS_FILE_TYPE is explictitly stated to be the type of the linked file not the link itself.
                */

                m_bSymLink = e.isLink();
                if(!m_bSymLink)
                {
                    fileType = e.numberValue(fieldId);
                    m_bDir = (fileType & QT_STAT_MASK) == QT_STAT_DIR;
                    m_bFile = (fileType & QT_STAT_MASK) == QT_STAT_REG;
                    m_bExists = fileType != 0;
                }
                else
                {
                    m_bDir = false;
                    m_bFile = false;
                    m_bExists = true;
                }
                break;
            case KIO::UDSEntry::UDS_URL:
                m_url = QUrl(e.stringValue(fieldId));
                break;
            case KIO::UDSEntry::UDS_DISPLAY_NAME:
                mDisplayName = e.stringValue(fieldId);
                break;
            case KIO::UDSEntry::UDS_LOCAL_PATH:
                //TODO: Support this. We don't want to expose implmentation details to the user
                break;
            case KIO::UDSEntry::UDS_MIME_TYPE:
            case KIO::UDSEntry::UDS_GUESSED_MIME_TYPE:
            case KIO::UDSEntry::UDS_XML_PROPERTIES:
            default:
                break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const std::unique_ptr<IgnoreList>& ignoreList : m_ignoreLists)
    {
        if(ignoreList->matches(dir, text, bCaseSensitive))
        {
            return true;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(Diff3Line &diff: *this)
    {
        bTextsTotalEqual = diff.fineDiff(bTextsTotalEqual, selector, v1, v2, eIgnoreFlags);
        ++listIdx;
        pp.step();
    }
```

#### AUTO 


```{c}
auto pDiffList = std::make_shared<DiffList>();
```

#### AUTO 


```{c}
auto& dirPattern
```

#### AUTO 


```{c}
const auto& pair
```

#### RANGE FOR STATEMENT 


```{c}
for(const Diff3Line &d: diff3List)
    {
        MergeLine ml;
        bool bLineRemoved;
        ml.mergeOneLine(d, bLineRemoved, !isThreeway);
        ml.dectectWhiteSpaceConflict(d, isThreeway);

        ml.d3lLineIdx = lineIdx;
        ml.bDelta = ml.srcSelect != e_SrcSelector::A;
        ml.mId3l = it;
        ml.srcRangeLength = 1;

        MergeLine *lBack = mImp.empty() ? nullptr : &mImp.back();

        bool bSame = lBack != nullptr && ml.isSameKind(*lBack);
        if(bSame)
        {
            ++lBack->srcRangeLength;
            if(lBack->isWhiteSpaceConflict() && !ml.isWhiteSpaceConflict())
                lBack->bWhiteSpaceConflict = false;
        }
        else
        {
            mImp.push_back(ml);
        }

        if(!ml.isConflict())
        {
            MergeLine &tmpBack = mImp.back();
            MergeEditLine mel(ml.id3l());
            mel.setSource(ml.srcSelect, bLineRemoved);
            tmpBack.list().push_back(mel);
        }
        else if(lBack == nullptr || !lBack->isConflict() || !bSame)
        {
            MergeLine &tmpBack = mImp.back();
            MergeEditLine mel(ml.id3l());
            mel.setConflict();
            tmpBack.list().push_back(mel);
        }

        ++lineIdx;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(FileAccess& fileRecord: dirInfo->getDirListC())
        {
            MergeFileInfos& mfi = m_fileMergeMap[FileKey(fileRecord)];

            mfi.setFileInfoC(&(fileRecord));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(const Diff& curDiff: *this)
    {
        assert(curDiff.diff1() <= TYPE_MAX(LineRef::LineType) && curDiff.diff2() <= TYPE_MAX(LineRef::LineType));
        l1 += curDiff.numberOfEquals() + LineRef(curDiff.diff1());
        l2 += curDiff.numberOfEquals() + LineRef(curDiff.diff2());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const KIO::UDSEntry& e: l)
    {
        FileAccess fa;

        fa.setFromUdsEntry(e, mFileAccess);

        //must be manually filtered KDE does not supply API for ignoring these.
        if(fa.fileName() != "." && fa.fileName() != ".." && fa.isValid())
        {
            m_pDirList->push_back(std::move(fa));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const Diff& diff: *pDiffList)
            {
                if(diff.numberOfEquals() >= 4)
                {
                    bUsefulFineDiff = true;
                    break;
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[](const FileAccess& file) {
        return file.fileName() == ".gitignore";
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString& endPattern: m_endPatterns)
    {
        if(text.mid(text.length() - endPattern.length()) == endPattern) //(text.endsWith(*it))
        {
            return true;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QChar &c : trimmedLine)
    {
        processChar(trimmedLine, c);
    }
```

#### AUTO 


```{c}
const auto dpr = thePainter->device()->devicePixelRatioF();
```

#### LAMBDA EXPRESSION 


```{c}
[&pDialog, pLineNumEdit]() {
                    if(pLineNumEdit->text() != "")
                    {
                        int lineNum = pLineNumEdit->text().toInt();
                        lineNum = qMax(lineNum - 2, 0);
                        //No need for anything else here setValue triggers a valueChanged signal internally.
                        DiffTextWindow::mVScrollBar->setValue(lineNum);
                    }
                    pDialog.close();
                }
```

#### RANGE FOR STATEMENT 


```{c}
for(const FileAccess& fi2: dirList) // for each file...
            {
                assert(fi2.fileName() != "." && fi2.fileName() != "..");

                bSuccess = deleteFLD(fi2.absoluteFilePath(), false);
                if(!bSuccess) break;
            }
```

#### RANGE FOR STATEMENT 


```{c}
for(Diff3Line& d3l: *this)
        {
            //Diff3Line& d3l = *i;
            if(resetDisplayCount)
                d3l.linesNeededForDisplay = 1;
            
            d3l.sumLinesNeededForDisplay = sumOfLines;
            sumOfLines += d3l.linesNeededForDisplay;
        }
```

#### AUTO 


```{c}
const auto dpr = devicePixelRatioF();
```

#### RANGE FOR STATEMENT 


```{c}
for(const Diff& theDiff: *this)
        {
            l1 += (theDiff.numberOfEquals() + theDiff.diff1());
            l2 += (theDiff.numberOfEquals() + theDiff.diff2());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString& line: lineList)
    {
        if(isComment(line))
        {
            continue;
        }
        QRegularExpression expression(QRegularExpression::wildcardToRegularExpression(line));
        if(!expression.isValid())
        {
            qCDebug(kdiffGitIgnoreList) << "Expression" << line << "is not valid - skipping ...";
            continue;
        }
        qCDebug(kdiffGitIgnoreList) << "Adding entry [" << dir << "]" << line;
        m_patterns[dir].push_back(expression);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(OptionItemBase* item : mOptionItemList)
            {
                if(item->getSaveName() == key)
                {
                    item->doPreserve();
                    ValueMap config;
                    config.writeEntry(key, val); // Write the value as a string and
                    item->read(&config);         // use the internal conversion from string to the needed value.
                    bFound = true;
                    break;
                }
            }
```

#### AUTO 


```{c}
const auto& line
```

#### RANGE FOR STATEMENT 


```{c}
for(auto& dirPattern : m_patterns)
    {
        if(dir.startsWith(dirPattern.first) == false)
        {
            continue;
        }
        for(auto& pattern : dirPattern.second)
        {
            if(bCaseSensitive == false)
            {
                pattern.setPatternOptions(QRegularExpression::CaseInsensitiveOption);
            }
            const auto match = pattern.match(text);
            if(match.hasMatch())
            {
                qCDebug(kdiffGitIgnoreList) << "Matched entry" << text;
                return true;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString& startPattern: m_startPatterns)
    {
        if(text.startsWith(startPattern, bCaseSensitive ? Qt::CaseSensitive : Qt::CaseInsensitive))
        {
            return true;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(OptionItemBase* item : mOptionItemList)
    {
        item->doUnpreserve();
        item->write(&cvm);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString& keyIt : keyOrderList)
    {
        if(keyIt.isEmpty())
            continue;
        bool bOk = false;
        int groupIdx = keyIt.toInt(&bOk);
        if(!bOk || groupIdx < 0 || groupIdx > parenthesesGroupList.size())
            continue;
        QString s = matchedRegExpr.cap(groupIdx);
        if(groupIdx == 0)
        {
            key += s + ' ';
            continue;
        }

        QString groupRegExp = parenthesesGroupList[groupIdx - 1];
        if(groupRegExp.indexOf('|') < 0 || groupRegExp.indexOf('(') >= 0)
        {
            bOk = false;
            int i = s.toInt(&bOk);
            if(bOk && i >= 0 && i < 10000)
                s.sprintf("%04d", i); // This should help for correct sorting of numbers.
            key += s + ' ';
        }
        else
        {
            // Assume that the groupRegExp consists of something like "Jan|Feb|Mar|Apr"
            // s is the string that managed to match.
            // Now we want to know at which position it occurred. e.g. Jan=0, Feb=1, Mar=2, etc.
            QStringList sl = groupRegExp.split('|');
            int idx = sl.indexOf(s);
            if(idx < 0)
            {
                // Didn't match
            }
            else
            {
                QString sIdx;
                sIdx.sprintf("%02d", idx + 1); // Up to 99 words in the groupRegExp (more than 12 aren't expected)
                key += sIdx + ' ';
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QFileInfo& fi: fiList) // for each file...
            {
                if(pp.wasCancelled())
                    break;

                Q_ASSERT(fi.fileName() != "." && fi.fileName() != "..");

                FileAccess fa;

                fa.setFile(mFileAccess, fi);
                pDirList->push_back(fa);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for(OptionItemBase* item : mOptionItemList)
    {
        item->setToDefault();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString& keyIt : keyOrderList)
    {
        if(keyIt.isEmpty())
            continue;
        bool bOk = false;
        int groupIdx = keyIt.toInt(&bOk);
        if(!bOk || groupIdx < 0 || groupIdx > parenthesesGroupList.size())
            continue;
        QString s = matchedRegExpr.cap(groupIdx);
        if(groupIdx == 0)
        {
            key += s + ' ';
            continue;
        }

        QString groupRegExp = parenthesesGroupList[groupIdx - 1];
        if(groupRegExp.indexOf('|') < 0 || groupRegExp.indexOf('(') >= 0)
        {
            bOk = false;
            int i = s.toInt(&bOk);
            if(bOk && i >= 0 && i < 10000)
                s.asprintf("%04d", i); // This should help for correct sorting of numbers.
            key += s + ' ';
        }
        else
        {
            // Assume that the groupRegExp consists of something like "Jan|Feb|Mar|Apr"
            // s is the string that managed to match.
            // Now we want to know at which position it occurred. e.g. Jan=0, Feb=1, Mar=2, etc.
            QStringList sl = groupRegExp.split('|');
            int idx = sl.indexOf(s);
            if(idx < 0)
            {
                // Didn't match
            }
            else
            {
                QString sIdx;
                sIdx.asprintf("%02d", idx + 1); // Up to 99 words in the groupRegExp (more than 12 aren't expected)
                key += sIdx + ' ';
            }
        }
    }
```

