#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : entry.installedFiles()) {
      const QMimeType mimeType = db.mimeTypeForFile(file);
      if (mimeType.name() == QLatin1String("application/x-kvtml")) {
	    KProcess::startDetached(QStringLiteral("kwordquiz"), QStringList() << file);
      }
    }
```

#### AUTO 


```{c}
const auto errors{m_quiz->errorList()};
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &entry : entries) {
    // check mime type and if kvtml, open it
    for (const QString &file : entry.installedFiles()) {
      const QMimeType mimeType = db.mimeTypeForFile(file);
      if (mimeType.name() == QLatin1String("application/x-kvtml")) {
	    KProcess::startDetached(QStringLiteral("kwordquiz"), QStringList() << file);
      }
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (int item : errors) {
      KEduVocExpression *errorExpr = new KEduVocExpression();
      errorDoc->lesson()->appendEntry(errorExpr);
      errorExpr->setTranslation(0, m_quiz->data(m_quiz->index(item, 0), Qt::DisplayRole).toString());
      errorExpr->setTranslation(1, m_quiz->data(m_quiz->index(item, 1), Qt::DisplayRole).toString());
    }
```

#### AUTO 


```{c}
const auto &entry
```

#### RANGE FOR STATEMENT 


```{c}
for (const IndexAndData &id : qAsConst(m_deleteIndexAndData))
    view()->model()->setData(id.index, id.data, Qt::EditRole);
```

#### RANGE FOR STATEMENT 


```{c}
for(const QByteArray b: QImageReader::supportedMimeTypes()) {
      if (! b.isEmpty()) imageFormats.append(QString(b));
  }
```

#### LAMBDA EXPRESSION 


```{c}
[this, i] () { slotInsertChar(i); }
```

#### RANGE FOR STATEMENT 


```{c}
for (QObject *object : listOfChildren) {
    if(!object->isWidgetType())
      continue;

    QWidget *childWidget = static_cast<QWidget *>(object);

    if (childWidget->inherits("QListView"))
      childWidget->setFocusPolicy(Qt::NoFocus);
  }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QByteArray &b: QImageReader::supportedMimeTypes()) {
      if (! b.isEmpty()) imageFormats.append(QString(b));
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &s : layouts) {
            a = m->addAction(s);
            a->setData(s);
            a->setCheckable(true);
            a->setActionGroup(m_layoutActionGroup);
            if (s == currentLayout)
              a->setChecked(true);
        }
```

