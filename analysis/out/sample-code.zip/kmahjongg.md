#### CONST EXPRESSION 


```{c}
constexpr int BOARD_WIDTH = 36;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString & dir : dirs) {
        const QStringList fileNames = QDir(dir).entryList(QStringList() << QStringLiteral("*.desktop"));
        for (const QString & file : fileNames) {
            tilesAvailable.append(dir + QLatin1Char('/') + file);
        }
    }
```

#### CONST EXPRESSION 


```{c}
constexpr int TILE_WIND = 31 + TILE_OFFSET;
```

#### CONST EXPRESSION 


```{c}
constexpr int ANIMATION_SPEED = 200;
```

#### CONST EXPRESSION 


```{c}
constexpr int TILE_CHARACTER = 0 + TILE_OFFSET;
```

#### RANGE FOR STATEMENT 


```{c}
for (GameItem * item : gameItems) {
        item->hide();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (GameItem * item : gameItems) {
        item->prepareForGeometryChange();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString & dir : layoutDirs) {
            const QStringList fileNames = QDir(dir).entryList(QStringList() << QStringLiteral("*.desktop"));
            for (const QString & file : fileNames) {
                availableLayouts.append(dir + QLatin1Char('/') + file);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (GameItem * item : gameItems) {
            item->show();
        }
```

#### CONST EXPRESSION 


```{c}
constexpr int BOARD_DEPTH = 5;
```

#### CONST EXPRESSION 


```{c}
constexpr int gameDataVersion = 1;
```

#### CONST EXPRESSION 


```{c}
constexpr int TILE_ROD = 18 + TILE_OFFSET;
```

#### CONST EXPRESSION 


```{c}
constexpr int BOARD_HEIGHT = 16;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString & file : fileNames) {
            tilesAvailable.append(dir + QLatin1Char('/') + file);
        }
```

#### CONST EXPRESSION 


```{c}
constexpr int TILE_BAMBOO = 9 + TILE_OFFSET;
```

#### RANGE FOR STATEMENT 


```{c}
for (GameItem * item : gameItems) {
            item->hide();
        }
```

#### CONST EXPRESSION 


```{c}
constexpr int TILE_FLOWER = 38 + TILE_OFFSET;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString & file : fileNames) {
                availableLayouts.append(dir + QLatin1Char('/') + file);
            }
```

#### CONST EXPRESSION 


```{c}
constexpr int kLayoutVersionFormat = 1;
```

#### CONST EXPRESSION 


```{c}
constexpr int TILE_SEASON = 27 + TILE_OFFSET;
```

#### CONST EXPRESSION 


```{c}
constexpr int TILE_DRAGON = 35 + TILE_OFFSET;
```

#### CONST EXPRESSION 


```{c}
constexpr int TILE_OFFSET = 2;
```

