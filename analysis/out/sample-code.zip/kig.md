#### RANGE FOR STATEMENT 


```{c}
for( const QString & folderPath : allFolders )
  {
    QDirIterator folderIterator( folderPath, QDirIterator::Subdirectories );

    while ( folderIterator.hasNext() )
    {
      const QString fileName = folderIterator.next();

      if ( fileName.endsWith( QLatin1String( ".kigt" ) ) )
      {
        dataFiles << fileName;
      }
    }
  }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QPrinter *p){
      doPrint( *p, document().grid(), document().axes() );
  }
```

#### RANGE FOR STATEMENT 


```{c}
for( const QString & folderPath : allFolders )
  {
    QDirIterator folderIterator( folderPath, QDirIterator::Subdirectories );

    while ( folderIterator.hasNext() )
    {
      const QString fileName = folderIterator.next();

      if ( fileName.endsWith( ".kigt" ) )
      {
        dataFiles << fileName;
      }
    }
  }
```

