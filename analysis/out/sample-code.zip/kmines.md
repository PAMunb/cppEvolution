#### AUTO 


```{c}
auto *dialog = new KConfigDialog( this, QStringLiteral( "settings" ), Settings::self() );
```

#### RANGE FOR STATEMENT 


```{c}
for (CellItem *item : neighbours) {
                if(!item->isRevealed()) // revealing only unrevealed ones
                {
                    // force=true to omit Pressed check
                    item->release(true);
                    // If revealing the item ends the game, stop the loop,
                    // since everything that needs to be done for the current game is finished.
                    // Otherwise, if the user has restarted the game, we'll be revealing
                    // items for the new game.
                    if(item->isRevealed() && onItemRevealed(item))
                        break;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (CellItem* item : qAsConst(m_cells)) {
        if(item->isExploded())
        {
            m_gameOver = true;
            Q_EMIT gameOver(false);
            return true;
        }
    }
```

#### AUTO 


```{c}
auto *mw = new KMinesMainWindow;
```

#### RANGE FOR STATEMENT 


```{c}
for(CellItem* item : qAsConst(m_cells)) {
        item->unreveal();
        item->unflag();
        item->unexplode();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (int idx : qAsConst(cellsWithMines)) {
        FieldPos rc = rowColFromIndex(idx);
        const QList<CellItem*> neighbours = adjacentItemsFor(rc.first, rc.second);
        for (CellItem *item : neighbours) {
            if(!item->hasMine())
                item->setDigit( item->digit()+1 );
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (CellItem* item : std::as_const(m_cells)) {
        if( (item->isFlagged() && !item->hasMine()) || (!item->isFlagged() && item->hasMine()) )
        {
            item->reveal();
            m_numUnrevealed--;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (CellItem* item : neighbours) {
            if(!item->isFlagged() && !item->isQuestioned() && !item->isRevealed())
                item->press();
            m_midButtonPos = qMakePair(row,col);

            m_leftButtonPos = qMakePair(-1,-1); // reset it
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const FieldPos& pos : rowcolList) {
        resultingList.append( itemAt(pos) );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (CellItem* item : std::as_const(m_cells)) {
        if(item->isExploded())
        {
            m_gameOver = true;
            Q_EMIT gameOver(false);
            return true;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QGraphicsItem* item : children) {
        ((KGameRenderedItem*)item)->setRenderSize(renderSize);
    }
```

#### AUTO 


```{c}
auto* prov = new KgThemeProvider;
```

#### RANGE FOR STATEMENT 


```{c}
for (CellItem *item : neighbours) {
                item->undoPress();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (CellItem *item : neighbours) {
            if(!item->hasMine())
                item->setDigit( item->digit()+1 );
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (BorderItem *item : qAsConst(m_borders)) {
        item->setRenderSize(QSize(m_cellSize, m_cellSize));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (CellItem* item : std::as_const(m_cells)) {
            if( item->isQuestioned() )
                item->mark();
            if( !item->isRevealed() && !item->isFlagged() )
                item->mark();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (CellItem* item : qAsConst(m_cells)) {
        item->setRenderSize(QSize(m_cellSize, m_cellSize));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (BorderItem* item : std::as_const(m_borders)) {
        item->setPos( item->col()*m_cellSize, item->row()*m_cellSize );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(CellItem* item : m_cells) {
        item->unreveal();
        item->unflag();
        item->unexplode();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(CellItem* item : std::as_const(m_cells)) {
        item->unreveal();
        item->unflag();
        item->unexplode();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (CellItem *item : neighbours) {
                item->press();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (CellItem *item : prevNeighbours) {
                   item->undoPress();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (CellItem* item : std::as_const(m_cells)) {
        item->setRenderSize(QSize(m_cellSize, m_cellSize));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (int idx : std::as_const(cellsWithMines)) {
        FieldPos rc = rowColFromIndex(idx);
        const QList<CellItem*> neighbours = adjacentItemsFor(rc.first, rc.second);
        for (CellItem *item : neighbours) {
            if(!item->hasMine())
                item->setDigit( item->digit()+1 );
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (BorderItem *item : std::as_const(m_borders)) {
        item->setRenderSize(QSize(m_cellSize, m_cellSize));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (CellItem *item : neighbours) {
            if(item->isFlagged())
                numFlags++;
            if(item->hasMine())
                numMines++;
        }
```

#### AUTO 


```{c}
auto* overlay = new KGameRenderedItem(renderer(), spriteKey, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const FieldPos& pos : list) {
        // first is row, second is col
        item = itemAt(pos);
        if(item->isRevealed() || item->isFlagged() || item->isQuestioned())
            continue;
        if(item->digit() == 0)
        {
            item->reveal();
            m_numUnrevealed--;
            revealEmptySpace(pos.first,pos.second);
        }
        else
        {
            item->reveal();
            m_numUnrevealed--;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (CellItem* item : qAsConst(m_cells)) {
            if( item->isQuestioned() )
                item->mark();
            if( !item->isRevealed() && !item->isFlagged() )
                item->mark();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (BorderItem* item : qAsConst(m_borders)) {
        item->setPos( item->col()*m_cellSize, item->row()*m_cellSize );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (CellItem* item : qAsConst(m_cells)) {
        if( (item->isFlagged() && !item->hasMine()) || (!item->isFlagged() && item->hasMine()) )
        {
            item->reveal();
            m_numUnrevealed--;
        }
    }
```

