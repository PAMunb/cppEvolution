#### AUTO 


```{c}
auto about = new KAboutData(QStringLiteral("KCMDesignerfields"),
                                i18n("KCMDesignerfields"),
                                QString(),
                                i18n("Qt Designer Fields Dialog"),
                                KAboutLicense::LGPL,
                                i18n("(c) 2004 Tobias Koenig"));
```

#### AUTO 


```{c}
auto vbox = new QVBoxLayout(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &email : splittedEmail) {
        const QString str = KEmailAddress::extractEmailAddress(KEmailAddress::normalizeAddressesAndEncodeIdn(
                                                                   email));
        normalizedEmail << str;
    }
```

#### AUTO 


```{c}
auto *reminderItem = dynamic_cast<ReminderTreeItem *>(item);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &regionStr : regions) {
        auto region = new KHolidays::HolidayRegion(regionStr);
        if (region->isValid()) {
            mHolidayRegions.append(region);
        } else {
            delete region;
        }
    }
```

#### AUTO 


```{c}
auto *suspendBoxHBoxLayout = new QHBoxLayout(suspendBox);
```

#### RANGE FOR STATEMENT 


```{c}
for (const ReparentingModel::Node::Ptr &existing : qAsConst(mProxyNodes)) {
        if (*existing == *node) {
            existing->update(node);
            const QModelIndex i = index(existing.data());
            Q_EMIT dataChanged(i, i);
            return;
        }
    }
```

#### AUTO 


```{c}
auto noteedit = new CalendarSupport::NoteEditDialog(this);
```

#### AUTO 


```{c}
auto w = new KPrefsWidDuration(item, format, parent);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KNS3::Entry &e : installedEntries) {
        qCDebug(KORGANIZER_LOG) << " downloadNewStuff :";
        const QStringList lstFile = e.installedFiles();
        if (lstFile.count() != 1) {
            continue;
        }
        const QString file = lstFile.at(0);
        const QUrl filename = QUrl::fromLocalFile(file);
        qCDebug(KORGANIZER_LOG) << "filename :" << filename;
        if (!filename.isValid()) {
            continue;
        }

        KCalCore::FileStorage storage(calendar());
        storage.setFileName(file);
        storage.setSaveFormat(new KCalCore::ICalFormat);
        if (!storage.load()) {
            KMessageBox::error(mCalendarView, i18n("Could not load calendar %1.", file));
        } else {
            QStringList eventSummaries;
            const KCalCore::Event::List events = calendar()->events();
            eventSummaries.reserve(events.count());
            for (const KCalCore::Event::Ptr &event : events) {
                eventSummaries.append(event->summary());
            }

            const int result
                = KMessageBox::warningContinueCancelList(
                      mCalendarView,
                      i18n("The downloaded events will be merged into your current calendar."),
                      eventSummaries);

            if (result != KMessageBox::Continue) {
                // FIXME (KNS2): hm, no way out here :-)
            }

            if (importURL(QUrl::fromLocalFile(file), true)) {
                // FIXME (KNS2): here neither
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Node::Ptr &proxyNode : std::as_const(mProxyNodes)) {
        // Reparent source nodes according to the provided rules
        // The proxy can be ignored if it is a duplicate, so only reparent to proxies that are in the model
        if (proxyNode->parent && proxyNode->adopts(sourceIndex)) {
            Q_ASSERT(validateNode(proxyNode.data()));
            return proxyNode.data();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KHolidays::HolidayRegion *region : std::as_const(mHolidayRegions)) {
        if (region && region->isValid()) {
#if KHOLIDAYS_VERSION < QT_VERSION_CHECK(5, 95, 0)
            const KHolidays::Holiday::List list = region->holidays(start, end);
#else
            const KHolidays::Holiday::List list = region->rawHolidaysWithAstroSeasons(start, end);
#endif
            const int listCount(list.count());
            for (int i = 0; i < listCount; ++i) {
                const KHolidays::Holiday &h = list.at(i);
                // dedupe, since we support multiple holiday regions which may have similar holidays
                if (!holidaysByDate[h.observedStartDate()].contains(h.name())) {
                    holidaysByDate[h.observedStartDate()].append(h.name());
                }
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](){history->redo();}
```

#### AUTO 


```{c}
auto bJob = qobject_cast<BirthdaySearchJob *>(job);
```

#### AUTO 


```{c}
auto *layout = new QVBoxLayout;
```

#### RANGE FOR STATEMENT 


```{c}
for (const Node::Ptr &proxyNode : std::as_const(mProxyNodes)) {
            if (proxyNode->isDuplicateOf(descendant)) {
                // Removenode from proxy
                if (!proxyNode->parent) {
                    qCWarning(KORGANIZER_LOG) << objectName() << "Found proxy that is already not part of the model "
                                              << proxyNode->data(Qt::DisplayRole).toString();
                    continue;
                }
                const int targetRow = proxyNode->row();
                beginRemoveRows(index(proxyNode->parent), targetRow, targetRow);
                proxyNode->parent->children.remove(targetRow);
                proxyNode->parent = nullptr;
                endRemoveRows();
            }
        }
```

#### AUTO 


```{c}
auto filter = new KCalendarCore::CalFilter(*it);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Todo::Ptr &todo : alltodos) {
                Q_ASSERT(todo);
                if ((!todo->hasStartDate() && !todo->hasDueDate()) || // undated
                    (todo->hasStartDate() &&
                       (todo->dtStart().toLocalTime().date() >= startDt) &&
                       (todo->dtStart().toLocalTime().date() <= endDt)) || //start dt in range
                    (todo->hasDueDate() &&
                       (todo->dtDue().toLocalTime().date() >= startDt) &&
                       (todo->dtDue().toLocalTime().date() <= endDt)) || //due dt in range
                    (todo->hasCompletedDate() &&
                       (todo->completed().toLocalTime().date() >= startDt) &&
                       (todo->completed().toLocalTime().date() <= endDt))) { //completed dt in range
                    todos.append(todo);
                }
            }
```

#### AUTO 


```{c}
auto *topLayout = new QGridLayout(this);
```

#### AUTO 


```{c}
auto job = KIO::mkdir(cepPath);
```

#### AUTO 


```{c}
auto *pageItem = static_cast<PageItem *>(item->parent() ? item->parent() : item);
```

#### AUTO 


```{c}
auto boolItem = dynamic_cast<KConfigSkeleton::ItemBool *>(item);
```

#### AUTO 


```{c}
const auto next = ev->recurrence()->getNextDateTime(kdt);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalCore::Todo::Ptr &todo : alltodos) {
                Q_ASSERT(todo);
                if ((!todo->hasStartDate() && !todo->hasDueDate())       // undated
                    || (todo->hasStartDate()
                        && (todo->dtStart().toLocalTime().date() >= startDt)
                        && (todo->dtStart().toLocalTime().date() <= endDt))       //start dt in range
                    || (todo->hasDueDate()
                        && (todo->dtDue().toLocalTime().date() >= startDt)
                        && (todo->dtDue().toLocalTime().date() <= endDt))       //due dt in range
                    || (todo->hasCompletedDate()
                        && (todo->completed().toLocalTime().date() >= startDt)
                        && (todo->completed().toLocalTime().date() <= endDt))) {    //completed dt in range
                    todos.append(todo);
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : indexes) {
        if (index.isValid()) {
            const Akonadi::Collection c = index.data(Akonadi::EntityTreeModel::CollectionRole).value<Akonadi::Collection>();
            if (c.id() == collection.id()) {
                return true;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &url : lst) {
            korg->actionManager()->importURL(QUrl::fromUserInput(url), false);
        }
```

#### AUTO 


```{c}
const auto tags = mCategorySelectDialog->selection();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &str : checkedItems) {
        int index = mHolidayCheckCombo->findText(str);
        if (index >= 0) {
            HolidayRegions.append(mHolidayCheckCombo->itemData(index).toString());
        }
    }
```

#### AUTO 


```{c}
auto progressBar = new KPIM::ProgressStatusBarWidget(statusBar(), this);
```

#### AUTO 


```{c}
auto *createJob = qobject_cast<Akonadi::SearchCreateJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (Action action : lstActions) {
            if (action != Total) {
                QStyleOptionButton buttonOption = buttonOpt(opt, mIcon.value(action), index, i);
                s->drawControl(QStyle::CE_PushButton, &buttonOption, painter, nullptr);
            } else {
                QStyleOptionButton buttonOption = buttonOpt(opt, QPixmap(), index, i);
                buttonOption.features = QStyleOptionButton::Flat;
                buttonOption.rect.setHeight(buttonOption.rect.height() + 4);
                if (col.statistics().count() > 0) {
                    buttonOption.text = QString::number(col.statistics().count());
                }
                s->drawControl(QStyle::CE_PushButton, &buttonOption, painter, nullptr);
            }
            i++;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalCore::Todo::Ptr &t : incidences) {
        if (mEvents.count() == NUMDAYS) {
            // No point in wasting cpu, all days are bold already
            break;
        }
        Q_ASSERT(t);
        if (t->hasDueDate()) {
            ushort recurType = t->recurrenceType();

            if (t->recurs() &&
                !(recurType == KCalCore::Recurrence::rDaily &&
                  !KOPrefs::instance()->mDailyRecur) &&
                !(recurType == KCalCore::Recurrence::rWeekly &&
                  !KOPrefs::instance()->mWeeklyRecur)) {
                // It's a recurring todo, find out in which days it occurs
                const auto timeDateList
                    = t->recurrence()->timesInInterval(
                    QDateTime(mDays[0], {}, Qt::LocalTime),
                    QDateTime(mDays[NUMDAYS - 1], {}, Qt::LocalTime));

                for (const QDateTime &dt : timeDateList) {
                    d = dt.toLocalTime().date();
                    if (!mEvents.contains(d)) {
                        mEvents.append(d);
                    }
                }
            } else {
                d = t->dtDue().toLocalTime().date();
                if (d >= mDays[0] && d <= mDays[NUMDAYS - 1] && !mEvents.contains(d)) {
                    mEvents.append(d);
                }
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *it : list) {
                if (allowedTypes.contains(QLatin1String(it->metaObject()->className()))) {
                    const QString name = it->objectName();
                    if (name.startsWith(QStringLiteral("X_"))) {
                        new QTreeWidgetItem(this, QStringList()
                                            << name
                                            << allowedTypes[ QLatin1String(it->metaObject()->
                                                                           className()) ]
                                            << QLatin1String(it->metaObject()->className())
                                            << it->whatsThis());
                    }
                }
            }
```

#### AUTO 


```{c}
auto *hbox = new QHBoxLayout();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Alarm::Ptr &a : alarms) {
            const Incidence::Ptr parentIncidence = mCalendar->incidence(a->parentUid());
            lst << QStringLiteral("  ") + parentIncidence->summary() + QLatin1String(" (")
                + a->time().toString() + QLatin1Char(')');
        }
```

#### AUTO 


```{c}
auto item = static_cast<PageItem *>(*it);
```

#### RANGE FOR STATEMENT 


```{c}
for (KDateNavigator *nav : std::as_const(mExtraViews)) {
                if (nav) {
                    limits = KODayMatrix::matrixLimits(nav->month());
                    if (date >= limits.first && date <= limits.second) {
                        navigator = nav;
                        break;
                    }
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[=](const Akonadi::Item &i) {
            mMainView->editIncidence(i);
        }
```

#### AUTO 


```{c}
auto but = new QToolButton(mTreeWidget);
```

#### AUTO 


```{c}
auto buttonBox = new QDialogButtonBox(QDialogButtonBox::Close, this);
```

#### AUTO 


```{c}
auto font = qvariant_cast<QFont>(QSortFilterProxyModel::data(index, Qt::FontRole));
```

#### AUTO 


```{c}
auto displayname = col.attribute<Akonadi::EntityDisplayAttribute>(Akonadi::Collection::AddIfMissing);
```

#### RANGE FOR STATEMENT 


```{c}
for (KDateNavigator *n : qAsConst(mExtraViews)) {
                if (n) {
                    n->selectDates(dateList);
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[=](){history->undo();}
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Collection &checkedCollection : collections) {
        supportsMimeType =
            checkedCollection.contentMimeTypes().contains(mimeType) || mimeType == QLatin1String("");
        hasRights = checkedCollection.rights() & Akonadi::Collection::CanCreateItem;
        if (checkedCollection.isValid() && supportsMimeType && hasRights) {
            return checkedCollection;
        }
    }
```

#### AUTO 


```{c}
const auto &entry
```

#### LAMBDA EXPRESSION 


```{c}
[=](bool) {
        mCalendarView->schedule_refresh();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (BaseView *view : qAsConst(mViews)) {
        if (view) {
            view->setChanges(view->changes() | change);
        }
    }
```

#### AUTO 


```{c}
auto noTodos = new QLabel(i18np("No pending to-dos due within the next day", "No pending to-dos due within the next %1 days", mDaysToGo), this);
```

#### AUTO 


```{c}
auto *annotationsAttribute
        = collection.attribute<PimCommon::CollectionAnnotationsAttribute>(Collection::AddIfMissing);
```

#### LAMBDA EXPRESSION 


```{c}
[this, url](KJob *job) {
                        if (job->error()) {
                            return;
                        }
                        Akonadi::ItemFetchJob *fetchJob = qobject_cast<Akonadi::ItemFetchJob *>(job);
                        const Akonadi::Item::List items = fetchJob->items();
                        for (const Akonadi::Item &item : items) {
                            if (item.mimeType() == QStringLiteral("message/rfc822")) {
                                auto mail = item.payload<KMime::Message::Ptr>();
                                interface()->openEventEditor(i18nc("Event from email summary", "Mail: %1", mail->subject()->asUnicodeString()),
                                                             i18nc("Event from email content",
                                                                   "<b>From:</b> %1<br /><b>To:</b> %2<br /><b>Subject:</b> %3",
                                                                   mail->from()->displayString(),
                                                                   mail->to()->displayString(),
                                                                   mail->subject()->asUnicodeString()),
                                                             url.toDisplayString(),
                                                             QString(),
                                                             QStringList(),
                                                             QStringLiteral("message/rfc822"));
                            }
                        }
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Node::Ptr &node : qAsConst(parent->children)) {
        if (node.data() == this) {
            return row;
        }
        row++;
    }
```

#### AUTO 


```{c}
auto *noteedit = new CalendarSupport::NoteEditDialog(this);
```

#### AUTO 


```{c}
const auto monthViewTop = KOPrefs::instance()->decorationsAtMonthViewTop();
```

#### AUTO 


```{c}
auto calendarDelegateModel = new CalendarDelegateModel(this);
```

#### AUTO 


```{c}
const auto &instance
```

#### AUTO 


```{c}
auto *mEventViewerBoxVBoxLayout = new QVBoxLayout(mEventViewerBox);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Node::Ptr &c : std::as_const(node->parent->children)) {
        if (c.data() == node) {
            return row;
        }
        row++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalCore::Todo::Ptr &todo : alltodos) {
                Q_ASSERT(todo);
                if ((!todo->hasStartDate() && !todo->hasDueDate()) ||    // undated
                        (todo->hasStartDate() &&
                         (todo->dtStart().toLocalTime().date() >= startDt) &&
                         (todo->dtStart().toLocalTime().date() <= endDt)) ||      //start dt in range
                        (todo->hasDueDate() &&
                         (todo->dtDue().toLocalTime().date() >= startDt) &&
                         (todo->dtDue().toLocalTime().date() <= endDt)) ||      //due dt in range
                        (todo->hasCompletedDate() &&
                         (todo->completed().toLocalTime().date() >= startDt) &&
                         (todo->completed().toLocalTime().date() <= endDt))) {      //completed dt in range
                    todos.append(todo);
                }
            }
```

#### AUTO 


```{c}
auto *radios = new KPrefsWidRadios(enumItem, parent);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &url : parser.positionalArguments()) {
            korg->actionManager()->importCalendar(QUrl::fromUserInput(url));
        }
```

#### AUTO 


```{c}
auto *item = static_cast<PluginItem *>(serviceTypeGroup->child(j));
```

#### AUTO 


```{c}
auto *l = new QLabel(i18nc("@label:spinbox", "Suspend &duration:"), suspendBox);
```

#### AUTO 


```{c}
auto *pageItem = static_cast<PageItem *>(item->parent());
```

#### LAMBDA EXPRESSION 


```{c}
[this, urlLabel] {
                    popupMenu(urlLabel->url());
                }
```

#### AUTO 


```{c}
auto tmw = new MailTransport::TransportManagementWidget(topFrame);
```

#### AUTO 


```{c}
auto *sync
        = new Akonadi::CollectionAttributesSynchronizationJob(col);
```

#### AUTO 


```{c}
auto filterTreeViewModel = new QSortFilterProxyModel(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Node::Ptr &child : qAsConst(n->parent->children)) {
            if (child.data() == n) {
                found = true;
            }
        }
```

#### AUTO 


```{c}
auto r = new QRadioButton(text, mBox);
```

#### AUTO 


```{c}
auto *item = new QStandardItem;
```

#### LAMBDA EXPRESSION 


```{c}
[this, urlLabel] {
                viewTodo(urlLabel->url());
            }
```

#### AUTO 


```{c}
const auto holidays = KOGlobals::self()->holidays();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &regionCode : regions) {
        const QString name = KHolidays::HolidayRegion::name(regionCode);
        const QLocale locale(KHolidays::HolidayRegion::languageCode(regionCode));
        const QString languageName = QLocale::languageToString(locale.language());
        QString label;
        if (languageName.isEmpty()) {
            label = name;
        } else {
            label = i18nc("@item:inlistbox Holiday region, region language", "%1 (%2)",
                          name, languageName);
        }
        regionsMap.push_back(std::make_pair(label, regionCode));
    }
```

#### AUTO 


```{c}
auto *topLayout = new QGridLayout(topFrame);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : subTodos) {
            if (CalendarSupport::hasTodo(item)) {
                deleteSubTodosIncidence(item);
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](const auto &lhs, const auto &rhs) { return lhs.first < rhs.first; }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &url : argList) {
                importURL(QUrl::fromUserInput(url), /*merge=*/ false);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (SummaryEventInfo *event : events) {
        // Optionally, show only my Events
        /*      if ( mShowMineOnly &&
                  !KCalendarCore::CalHelper::isMyCalendarIncidence( mCalendarAdaptor, event->ev ) ) {
              continue;
            }
            TODO: CalHelper is deprecated, remove this?
        */

        KCalendarCore::Event::Ptr ev = event->ev;
        // print the first of the recurring event series only
        if (ev->recurs()) {
            if (uidList.contains(ev->instanceIdentifier())) {
                continue;
            }
            uidList.append(ev->instanceIdentifier());
        }

        // Icon label
        auto label = new QLabel(this);
        if (ev->categories().contains(QLatin1String("BIRTHDAY"), Qt::CaseInsensitive)) {
            label->setPixmap(pmb);
        } else if (ev->categories().contains(QLatin1String("ANNIVERSARY"), Qt::CaseInsensitive)) {
            label->setPixmap(pma);
        } else {
            label->setPixmap(pm);
        }
        label->setMaximumWidth(label->minimumSizeHint().width());
        mLayout->addWidget(label, counter, 0);
        mLabels.append(label);

        // Start date or date span label
        QString dateToDisplay = event->startDate;
        if (!event->dateSpan.isEmpty()) {
            dateToDisplay = event->dateSpan;
        }
        label = new QLabel(dateToDisplay, this);
        label->setAlignment(Qt::AlignLeft | Qt::AlignVCenter);
        mLayout->addWidget(label, counter, 1);
        mLabels.append(label);
        if (event->makeBold) {
            QFont font = label->font();
            font.setBold(true);
            label->setFont(font);
            if (!event->makeUrgent) {
                label->setPalette(todayPalette);
            } else {
                label->setPalette(urgentPalette);
            }
            label->setAutoFillBackground(true);
        }

        // Days to go label
        label = new QLabel(event->daysToGo, this);
        label->setAlignment(Qt::AlignLeft | Qt::AlignVCenter);
        mLayout->addWidget(label, counter, 2);
        mLabels.append(label);

        // Summary label
        auto urlLabel = new KUrlLabel(this);
        urlLabel->setText(event->summaryText);
        urlLabel->setUrl(event->summaryUrl);
        urlLabel->installEventFilter(this);
        urlLabel->setTextFormat(Qt::RichText);
        urlLabel->setWordWrap(true);
        mLayout->addWidget(urlLabel, counter, 3);
        mLabels.append(urlLabel);
        connect(urlLabel, &KUrlLabel::leftClickedUrl, this, [this, urlLabel] {
            viewEvent(urlLabel->url());
        });
        connect(urlLabel, &KUrlLabel::rightClickedUrl, this, [this, urlLabel] {
            popupMenu(urlLabel->url());
        });
        if (!event->summaryTooltip.isEmpty()) {
            urlLabel->setToolTip(event->summaryTooltip);
        }

        // Time range label (only for non-floating events)
        if (!event->timeRange.isEmpty()) {
            label = new QLabel(event->timeRange, this);
            label->setAlignment(Qt::AlignLeft | Qt::AlignVCenter);
            mLayout->addWidget(label, counter, 4);
            mLabels.append(label);
        }

        counter++;
    }
```

#### AUTO 


```{c}
auto topLayout = new QGridLayout(this);
```

#### AUTO 


```{c}
auto buttonBox = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel | QDialogButtonBox::Apply, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (KDateNavigator *n : std::as_const(mExtraViews)) {
        if (n) {
            n->setCalendar(calendar);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](bool) {
        mCalendarView->schedule_reply();
    }
```

#### AUTO 


```{c}
auto *filterTreeViewModel = new QSortFilterProxyModel(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &subInc : subIncs) {
        incidence_unsub(subInc);
    }
```

#### AUTO 


```{c}
auto *collectionSelection = new CalendarSupport::CollectionSelection(selectionModel);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Node::Ptr &proxyNode : qAsConst(mProxyNodes)) {
        //Reparent source nodes according to the provided rules
        //The proxy can be ignored if it is a duplicate, so only reparent to proxies that are in the model
        if (proxyNode->parent && proxyNode->adopts(sourceIndex)) {
            Q_ASSERT(validateNode(proxyNode.data()));
            return proxyNode.data();
        }
    }
```

#### AUTO 


```{c}
auto summaryEvent = new SummaryEventInfo();
```

#### AUTO 


```{c}
auto *emailSettingsLayout = new QFormLayout(mUserEmailSettings);
```

#### AUTO 


```{c}
auto w = new KPrefsWidBool(item, parent);
```

#### RANGE FOR STATEMENT 


```{c}
for (Node *n : std::as_const(mSourceNodes)) {
        if (n->sourceIndex == sourceIndex) {
            return n;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &url : argList) {
                importURL(QUrl::fromUserInput(url), /*merge=*/false);
            }
```

#### AUTO 


```{c}
auto label = new QLabel(i18nc("@label",
                                  "Reminders: "
                                  "Clicking on the title toggles details for item"),
                            topBox);
```

#### AUTO 


```{c}
auto newFilter = new KCalendarCore::CalFilter(newFilterName);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &url : parser.positionalArguments()) {
                mainWindow->actionManager()->importCalendar(QUrl::fromUserInput(url));
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Event::Ptr &ev : events) {
            // Optionally, show only my Events
            /* if ( mShowMineOnly &&
                    !KCalendarCore::CalHelper::isMyCalendarIncidence( mCalendarAdaptor, ev. ) ) {
              // FIXME; does isMyCalendarIncidence work !? It's deprecated too.
              continue;
              }
              // TODO: CalHelper is deprecated, remove this?
              */

            if (ev->customProperty("KABC", "BIRTHDAY") == QLatin1String("YES")) {
                // Skipping, because these are got by the BirthdaySearchJob
                // See comments in updateView()
                continue;
            }

            if (!ev->categoriesStr().isEmpty()) {
                QStringList::ConstIterator it2;
                const QStringList c = ev->categories();
                QStringList::ConstIterator end(c.constEnd());
                for (it2 = c.constBegin(); it2 != end; ++it2) {
                    const QString itUpper((*it2).toUpper());
                    // Append Birthday Event?
                    if (mShowBirthdaysFromCal && (itUpper == QLatin1String("BIRTHDAY"))) {
                        SDEntry entry;
                        entry.type = IncidenceTypeEvent;
                        entry.category = CategoryBirthday;
                        entry.date = dt;
                        entry.summary = ev->summary();
                        entry.desc = ev->description();
                        dateDiff(ev->dtStart().date(), entry.daysTo, entry.yearsOld);
                        entry.span = 1;

                        /* The following check is to prevent duplicate entries,
                         * so in case of having a KCal incidence with category birthday
                         * with summary and date equal to some KABC Attendee we don't show it
                         * FIXME: port to akonadi, it's kresource based
                         * */
                        if (/*!check( bdayRes, dt, ev->summary() )*/ true) {
                            mDates.append(entry);
                        }
                        break;
                    }

                    // Append Anniversary Event?
                    if (mShowAnniversariesFromCal && (itUpper == QLatin1String("ANNIVERSARY"))) {
                        SDEntry entry;
                        entry.type = IncidenceTypeEvent;
                        entry.category = CategoryAnniversary;
                        entry.date = dt;
                        entry.summary = ev->summary();
                        entry.desc = ev->description();
                        dateDiff(ev->dtStart().date(), entry.daysTo, entry.yearsOld);
                        entry.span = 1;
                        if (/*!check( annvRes, dt, ev->summary() )*/ true) {
                            mDates.append(entry);
                        }
                        break;
                    }

                    // Append Holiday Event?
                    if (mShowHolidays && (itUpper == QLatin1String("HOLIDAY"))) {
                        SDEntry entry;
                        entry.type = IncidenceTypeEvent;
                        entry.category = CategoryHoliday;
                        entry.date = dt;
                        entry.summary = ev->summary();
                        entry.desc = ev->description();
                        dateDiff(dt, entry.daysTo, entry.yearsOld);
                        entry.yearsOld = -1; // ignore age of holidays
                        entry.span = span(ev);
                        if (entry.span > 1 && dayof(ev, dt) > 1) { // skip days 2,3,...
                            break;
                        }
                        mDates.append(entry);
                        break;
                    }

                    // Append Special Occasion Event?
                    if (mShowSpecialsFromCal && (itUpper == QLatin1String("SPECIAL OCCASION"))) {
                        SDEntry entry;
                        entry.type = IncidenceTypeEvent;
                        entry.category = CategoryOther;
                        entry.date = dt;
                        entry.summary = ev->summary();
                        entry.desc = ev->description();
                        dateDiff(dt, entry.daysTo, entry.yearsOld);
                        entry.yearsOld = -1; // ignore age of special occasions
                        entry.span = span(ev);
                        if (entry.span > 1 && dayof(ev, dt) > 1) { // skip days 2,3,...
                            break;
                        }
                        mDates.append(entry);
                        break;
                    }
                }
            }
        }
```

#### AUTO 


```{c}
auto radios = new KPrefsWidRadios(enumItem, parent);
```

#### LAMBDA EXPRESSION 


```{c}
[=](bool){mCalendarView->schedule_publish();}
```

#### AUTO 


```{c}
auto sync = qobject_cast<Akonadi::CollectionAttributesSynchronizationJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &url : lst) {
            korg->actionManager()->importURL(QUrl::fromUserInput(url), true);
        }
```

#### AUTO 


```{c}
auto bodyMessage = new KMime::Content;
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : selectedViewIncidences) {
            if (item.hasPayload<KCalCore::Incidence::Ptr>()) {
                selectedIncidences.append(item.payload<KCalCore::Incidence::Ptr>());
            }
        }
```

#### AUTO 


```{c}
const auto timeDateList =
                    t->recurrence()->timesInInterval(QDateTime(mDays[0], {}, Qt::LocalTime), QDateTime(mDays[NUMDAYS - 1], {}, Qt::LocalTime));
```

#### RANGE FOR STATEMENT 


```{c}
for (const Alarm::Ptr &alarm : alarms) {
        const QString uid = alarm->customProperty("ETMCalendar", "parentUid");
        const Akonadi::Item::Id id = mCalendar->item(uid).id();
        const Akonadi::Item item = mCalendar->item(id);

        createReminder(item, mLastChecked, alarm->text());
    }
```

#### AUTO 


```{c}
auto *bodyDisposition
            = new KMime::Headers::ContentDisposition;
```

#### AUTO 


```{c}
const auto selected = m_listView->selectedIncidences();
```

#### AUTO 


```{c}
const auto descendantsItem = descendants(sourceIndex);
```

#### AUTO 


```{c}
auto *mainLayout = new QVBoxLayout(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (Node *n : qAsConst(mSourceNodes)) {
        if (proxyNode->adopts(n->sourceIndex)) {
            // qCDebug(KORGANIZER_LOG) << "reparenting" << n->data(Qt::DisplayRole).toString() << "from" << n->parent->data(Qt::DisplayRole).toString()
            //         << "to" << proxyNode->data(Qt::DisplayRole).toString();

            // WARNING: While a beginMoveRows/endMoveRows would be more suitable, QSortFilterProxyModel can't deal with that. Therefore we
            // cannot use them.
            const int oldRow = n->row();
            beginRemoveRows(index(n->parent), oldRow, oldRow);
            Node::Ptr nodePtr = proxyNode->searchNode(n);
            // We lie about the row being removed already, but the view can deal with that better than if we call endRemoveRows after beginInsertRows
            endRemoveRows();

            const int newRow = proxyNode->children.size();
            beginInsertRows(index(proxyNode.data()), newRow, newRow);
            proxyNode->addChild(nodePtr);
            endInsertRows();
            Q_ASSERT(validateNode(n));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Incidence::Ptr &ev : incidences) {
        Q_ASSERT(ev);
        Akonadi::Item item = m_calendarview->calendar()->item(ev->uid());
        if (m_ui->summaryCheck->isChecked()) {
            if (re.indexIn(ev->summary()) != -1) {
                m_matchedEvents.append(item);
                continue;
            }
        }
        if (m_ui->descriptionCheck->isChecked()) {
            if (re.indexIn(ev->description()) != -1) {
                m_matchedEvents.append(item);
                continue;
            }
        }
        if (m_ui->categoryCheck->isChecked()) {
            if (re.indexIn(ev->categoriesStr()) != -1) {
                m_matchedEvents.append(item);
                continue;
            }
        }
        if (m_ui->locationCheck->isChecked()) {
            if (re.indexIn(ev->location()) != -1) {
                m_matchedEvents.append(item);
                continue;
            }
        }
        if (m_ui->attendeeCheck->isChecked()) {
            const KCalendarCore::Attendee::List lstAttendees = ev->attendees();
            for (const KCalendarCore::Attendee &attendee : lstAttendees) {
                if (re.indexIn(attendee.fullName()) != -1) {
                    m_matchedEvents.append(item);
                    break;
                }
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KDateNavigator *nav : qAsConst(mExtraViews)) {
                if (nav) {
                    limits = KODayMatrix::matrixLimits(nav->month());
                    if (date >= limits.first && date <= limits.second) {
                        navigator = nav;
                        break;
                    }
                }
            }
```

#### AUTO 


```{c}
auto *label = static_cast<KUrlLabel *>(obj);
```

#### AUTO 


```{c}
auto dlg = menu.findChild<IncidenceEditorNG::IncidenceDialog *>(QStringLiteral("incidencedialog"));
```

#### RANGE FOR STATEMENT 


```{c}
for (KCalendarCore::CalFilter *i : std::as_const(*mFilters)) {
        if (i && i->name().isEmpty()) {
            allOk = false;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KCalendarCore::CalFilter *filter : qAsConst(mFilters)) {
        filterList << filter->name();
        KConfigGroup filterConfig(config, QStringLiteral("Filter_") + filter->name());
        filterConfig.writeEntry("Criteria", filter->criteria());
        filterConfig.writeEntry("CategoryList", filter->categoryList());
        filterConfig.writeEntry("HideTodoDays", filter->completedTimeSpan());
    }
```

#### AUTO 


```{c}
const auto dummyNode = dynamic_cast<const DummyNode *>(&node);
```

#### AUTO 


```{c}
const auto currentDateTime = QDateTime::currentDateTime();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &instance : mCalendar->instances(incidence)) {
                (void) mChanger->deleteIncidence(mCalendar->item(instance), this);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[=](bool) {
        mCalendarView->schedule_request();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &url : md->urls()) {
            if (url.scheme() == QStringLiteral("akonadi") && url.hasQuery()) {
                const QUrlQuery query(url.query());
                if (!query.queryItemValue(QStringLiteral("item")).isEmpty()
                    && query.queryItemValue(QStringLiteral("type")) == QStringLiteral("message/rfc822")) {
                    Akonadi::ItemFetchJob *job =
                        new Akonadi::ItemFetchJob(Akonadi::Item(static_cast<qint64>(query.queryItemValue(QStringLiteral("item")).toLongLong())));
                    job->fetchScope().fetchAllAttributes();
                    job->fetchScope().fetchFullPayload(true);
                    connect(job, &KJob::result, this, [this, url](KJob *job) {
                        if (job->error()) {
                            return;
                        }
                        Akonadi::ItemFetchJob *fetchJob = qobject_cast<Akonadi::ItemFetchJob *>(job);
                        const Akonadi::Item::List items = fetchJob->items();
                        for (const Akonadi::Item &item : items) {
                            if (item.mimeType() == QStringLiteral("message/rfc822")) {
                                auto mail = item.payload<KMime::Message::Ptr>();
                                interface()->openEventEditor(i18nc("Event from email summary", "Mail: %1", mail->subject()->asUnicodeString()),
                                                             i18nc("Event from email content",
                                                                   "<b>From:</b> %1<br /><b>To:</b> %2<br /><b>Subject:</b> %3",
                                                                   mail->from()->displayString(),
                                                                   mail->to()->displayString(),
                                                                   mail->subject()->asUnicodeString()),
                                                             url.toDisplayString(),
                                                             QString(),
                                                             QStringList(),
                                                             QStringLiteral("message/rfc822"));
                            }
                        }
                    });
                }
                return;
            }
        }
```

#### AUTO 


```{c}
const auto names = mCurrent->categoryList();
```

#### AUTO 


```{c}
auto *importer = new Akonadi::ICalImporter();
```

#### LAMBDA EXPRESSION 


```{c}
[=](const QDateTime &s, const QDateTime &e) {
        mMainView->newEvent(s, e, false);
    }
```

#### AUTO 


```{c}
auto kcm = new MyDesignerFields();
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Todo::Ptr &todo : todos) {
        if (todo->hasDueDate()) {
            const int daysTo = currDate.daysTo(todo->dtDue().date());
            if (daysTo >= mDaysToGo) {
                continue;
            }
        }

        if (mHideOverdue && todo->isOverdue()) {
            continue;
        }
        if (mHideInProgress && todo->isInProgress(false)) {
            continue;
        }
        if (mHideCompleted && todo->isCompleted()) {
            continue;
        }
        if (mHideOpenEnded && todo->isOpenEnded()) {
            continue;
        }
        if (mHideNotStarted && todo->isNotStarted(false)) {
            continue;
        }

        prList.append(todo);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto instance : mCalendar->instances(incidence)) {
                    (void) mChanger->deleteIncidence(mCalendar->item(instance), this);
                }
```

#### AUTO 


```{c}
auto rightBox = new QWidget(mPanner);
```

#### AUTO 


```{c}
auto *w = new KPrefsWidCombo(item, parent);
```

#### AUTO 


```{c}
auto *calendarFrameLayout = new QHBoxLayout;
```

#### AUTO 


```{c}
auto *w = new KPrefsWidString(item, parent, KLineEdit::Normal);
```

#### RANGE FOR STATEMENT 


```{c}
for (Node *n : std::as_const(mSourceNodes)) {
        if (proxyNode->adopts(n->sourceIndex)) {
            // qCDebug(KORGANIZER_LOG) << "reparenting" << n->data(Qt::DisplayRole).toString() << "from" << n->parent->data(Qt::DisplayRole).toString()
            //         << "to" << proxyNode->data(Qt::DisplayRole).toString();

            // WARNING: While a beginMoveRows/endMoveRows would be more suitable, QSortFilterProxyModel can't deal with that. Therefore we
            // cannot use them.
            const int oldRow = n->row();
            beginRemoveRows(index(n->parent), oldRow, oldRow);
            Node::Ptr nodePtr = proxyNode->searchNode(n);
            // We lie about the row being removed already, but the view can deal with that better than if we call endRemoveRows after beginInsertRows
            endRemoveRows();

            const int newRow = proxyNode->children.size();
            beginInsertRows(index(proxyNode.data()), newRow, newRow);
            proxyNode->addChild(nodePtr);
            endInsertRows();
            Q_ASSERT(validateNode(n));
        }
    }
```

#### AUTO 


```{c}
auto item = new QStandardItem(QStringLiteral("row1"));
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
            history->redo();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Event::Ptr &ev : events) {
            // Optionally, show only my Events
            /* if ( mShowMineOnly &&
                    !KCalendarCore::CalHelper::isMyCalendarIncidence( mCalendarAdaptor, ev. ) ) {
              // FIXME; does isMyCalendarIncidence work !? It's deprecated too.
              continue;
              }
              // TODO: CalHelper is deprecated, remove this?
              */

            if (ev->customProperty("KABC", "BIRTHDAY") == QLatin1String("YES")) {
                // Skipping, because these are got by the BirthdaySearchJob
                // See comments in updateView()
                continue;
            }

            if (!ev->categoriesStr().isEmpty()) {
                QStringList::ConstIterator it2;
                const QStringList c = ev->categories();
                QStringList::ConstIterator end(c.constEnd());
                for (it2 = c.constBegin(); it2 != end; ++it2) {
                    const QString itUpper((*it2).toUpper());
                    // Append Birthday Event?
                    if (mShowBirthdaysFromCal && (itUpper == QLatin1String("BIRTHDAY"))) {
                        SDEntry entry;
                        entry.type = IncidenceTypeEvent;
                        entry.category = CategoryBirthday;
                        entry.date = dt;
                        entry.summary = ev->summary();
                        entry.desc = ev->description();
                        dateDiff(ev->dtStart().date(), entry.daysTo, entry.yearsOld);
                        entry.span = 1;

                        /* The following check is to prevent duplicate entries,
                         * so in case of having a KCal incidence with category birthday
                         * with summary and date equal to some KABC Attendee we don't show it
                         * FIXME: port to akonadi, it's kresource based
                         * */
                        if (/*!check( bdayRes, dt, ev->summary() )*/ true) {
                            mDates.append(entry);
                        }
                        break;
                    }

                    // Append Anniversary Event?
                    if (mShowAnniversariesFromCal && (itUpper == QStringLiteral("ANNIVERSARY"))) {
                        SDEntry entry;
                        entry.type = IncidenceTypeEvent;
                        entry.category = CategoryAnniversary;
                        entry.date = dt;
                        entry.summary = ev->summary();
                        entry.desc = ev->description();
                        dateDiff(ev->dtStart().date(), entry.daysTo, entry.yearsOld);
                        entry.span = 1;
                        if (/*!check( annvRes, dt, ev->summary() )*/ true) {
                            mDates.append(entry);
                        }
                        break;
                    }

                    // Append Holiday Event?
                    if (mShowHolidays && (itUpper == QLatin1String("HOLIDAY"))) {
                        SDEntry entry;
                        entry.type = IncidenceTypeEvent;
                        entry.category = CategoryHoliday;
                        entry.date = dt;
                        entry.summary = ev->summary();
                        entry.desc = ev->description();
                        dateDiff(dt, entry.daysTo, entry.yearsOld);
                        entry.yearsOld = -1; //ignore age of holidays
                        entry.span = span(ev);
                        if (entry.span > 1 && dayof(ev, dt) > 1) {     // skip days 2,3,...
                            break;
                        }
                        mDates.append(entry);
                        break;
                    }

                    // Append Special Occasion Event?
                    if (mShowSpecialsFromCal && (itUpper == QLatin1String("SPECIAL OCCASION"))) {
                        SDEntry entry;
                        entry.type = IncidenceTypeEvent;
                        entry.category = CategoryOther;
                        entry.date = dt;
                        entry.summary = ev->summary();
                        entry.desc = ev->description();
                        dateDiff(dt, entry.daysTo, entry.yearsOld);
                        entry.yearsOld = -1; //ignore age of special occasions
                        entry.span = span(ev);
                        if (entry.span > 1 && dayof(ev, dt) > 1) {     // skip days 2,3,...
                            break;
                        }
                        mDates.append(entry);
                        break;
                    }
                }
            }
        }
```

#### AUTO 


```{c}
auto saveLayout = new QVBoxLayout(saveFrame);
```

#### AUTO 


```{c}
auto *e4 = new Event;
```

#### AUTO 


```{c}
const auto item = mCalendar->item(uid);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Todo::Ptr &todo : qAsConst(prList)) {
            bool makeBold = false;
            int daysTo = -1;

            // Optionally, show only my To-dos
            /*      if ( mShowMineOnly &&
                         !KCalendarCore::CalHelper::isMyCalendarIncidence( mCalendarAdaptor, todo.get() ) ) {
                    continue;
                  }
            TODO: calhelper is deprecated, remove this?
            */

            // Icon label
            label = new QLabel(this);
            label->setPixmap(pm);
            label->setMaximumWidth(label->minimumSizeHint().width());
            mLayout->addWidget(label, counter, 0);
            mLabels.append(label);

            // Due date label
            str.clear();
            if (todo->hasDueDate() && todo->dtDue().date().isValid()) {
                daysTo = currDate.daysTo(todo->dtDue().date());

                if (daysTo == 0) {
                    makeBold = true;
                    str = i18nc("the to-do is due today", "Today");
                } else if (daysTo == 1) {
                    str = i18nc("the to-do is due tomorrow", "Tomorrow");
                } else {
                    const auto locale = QLocale::system();
                    for (int i = 3; i < 8; ++i) {
                        if (daysTo < i * 24 * 60 * 60) {
                            str = i18nc("1. weekday, 2. time", "%1 %2",
                                        locale.dayName(todo->dtDue().date().dayOfWeek(),
                                                       QLocale::LongFormat),
                                        locale.toString(todo->dtDue().time(),
                                                        QLocale::ShortFormat));
                            break;
                        }
                    }
                    if (str.isEmpty()) {
                        str = locale.toString(todo->dtDue(), QLocale::ShortFormat);
                    }
                }
            }

            label = new QLabel(str, this);
            label->setAlignment(Qt::AlignLeft | Qt::AlignVCenter);
            mLayout->addWidget(label, counter, 1);
            mLabels.append(label);
            if (makeBold) {
                QFont font = label->font();
                font.setBold(true);
                label->setFont(font);
            }

            // Days togo/ago label
            str.clear();
            if (todo->hasDueDate() && todo->dtDue().date().isValid()) {
                if (daysTo > 0) {
                    str = i18np("in 1 day", "in %1 days", daysTo);
                } else if (daysTo < 0) {
                    str = i18np("1 day ago", "%1 days ago", -daysTo);
                } else {
                    str = i18nc("the to-do is due", "due");
                }
            }
            label = new QLabel(str, this);
            label->setAlignment(Qt::AlignLeft | Qt::AlignVCenter);
            mLayout->addWidget(label, counter, 2);
            mLabels.append(label);

            // Priority label
            str = QLatin1Char('[') + QString::number(todo->priority()) + QLatin1Char(']');
            label = new QLabel(str, this);
            label->setAlignment(Qt::AlignRight | Qt::AlignVCenter);
            mLayout->addWidget(label, counter, 3);
            mLabels.append(label);

            // Summary label
            str = todo->summary();
            if (!todo->relatedTo().isEmpty()) {   // show parent only, not entire ancestry
                KCalendarCore::Incidence::Ptr inc = mCalendar->incidence(todo->relatedTo());
                if (inc) {
                    str = inc->summary() + QLatin1Char(':') + str;
                }
            }
            if (!Qt::mightBeRichText(str)) {
                str = str.toHtmlEscaped();
            }

            KUrlLabel *urlLabel = new KUrlLabel(this);
            urlLabel->setText(str);
            urlLabel->setUrl(todo->uid());
            urlLabel->installEventFilter(this);
            urlLabel->setTextFormat(Qt::RichText);
            urlLabel->setWordWrap(true);
            mLayout->addWidget(urlLabel, counter, 4);
            mLabels.append(urlLabel);

            connect(urlLabel, QOverload<const QString &>::of(
                        &KUrlLabel::leftClickedUrl), this, &TodoSummaryWidget::viewTodo);
            connect(urlLabel, QOverload<const QString &>::of(
                        &KUrlLabel::rightClickedUrl), this, &TodoSummaryWidget::popupMenu);

            // State text label
            str = stateStr(todo);
            label = new QLabel(str, this);
            label->setAlignment(Qt::AlignLeft | Qt::AlignVCenter);
            mLayout->addWidget(label, counter, 5);
            mLabels.append(label);

            counter++;
        }
```

#### AUTO 


```{c}
auto pageItem = static_cast<PageItem *>(item->parent());
```

#### AUTO 


```{c}
auto item = new QStandardItem(QStringLiteral("parent"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Event::Ptr &event : events) {
                    eventSummaries.append(event->summary());
                }
```

#### AUTO 


```{c}
auto *colorProxy = new ColorProxyModel(this);
```

#### AUTO 


```{c}
auto *w = new KPrefsWidString(item, parent, KLineEdit::Password);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Node::Ptr &proxyNode : std::as_const(mProxyNodes)) {
        // qCDebug(KORGANIZER_LOG) << "checking " << proxyNode->data(Qt::DisplayRole).toString();
        // Avoid inserting a node that is already part of the source model
        if (isDuplicate(proxyNode)) {
            continue;
        }
        insertProxyNode(proxyNode);
        reparentSourceNodes(proxyNode);
    }
```

#### AUTO 


```{c}
auto *me = static_cast<QMouseEvent *>(event);
```

#### AUTO 


```{c}
auto job = new KIO::CommandLauncherJob(QStringLiteral("designer"), args, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Incidence::Ptr &inc : incidences) {
        Q_ASSERT(inc);
        QDate d = inc->dtStart().toLocalTime().date();
        if (inc->type() == KCalendarCore::Incidence::TypeJournal
            && d >= mDays[0]
            && d <= mDays[NUMDAYS - 1]
            && !mEvents.contains(d)) {
            mEvents.append(d);
        }
        if (mEvents.count() == NUMDAYS) {
            // No point in wasting cpu, all days are bold already
            break;
        }
    }
```

#### AUTO 


```{c}
auto *msg = new KMime::Message();
```

#### AUTO 


```{c}
auto adisplayLayout = new QVBoxLayout;
```

#### AUTO 


```{c}
auto *gdisplayLayout = new QVBoxLayout;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &dir : dirs) {
        const QStringList fileNames = QDir(dir).entryList(QStringList() << QStringLiteral("*.ui"));
        for (const QString &file : fileNames) {
            new PageItem(mPageView, dir + QLatin1Char('/') + file);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](Akonadi::ServerManager::State state) {
                    if (state == Akonadi::ServerManager::Running) {
                        setupAkonadi();
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (KHolidays::HolidayRegion *region : holidays) {
        const QString regionStr = region->regionCode();
        mHolidayCheckCombo->setItemCheckState(
            mHolidayCheckCombo->findData(regionStr), Qt::Checked);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](const Akonadi::Item &i) {
        mMainView->editIncidence(i, false);
    }
```

#### AUTO 


```{c}
auto *hourSizeLayout = new QHBoxLayout;
```

#### RANGE FOR STATEMENT 


```{c}
for (Akonadi::StandardActionManager::Type standardAction : qAsConst(standardActions)) {
            mActionManager->createAction(standardAction);
        }
```

#### AUTO 


```{c}
auto *tdisplayLayout = new QVBoxLayout;
```

#### AUTO 


```{c}
auto *korg = new KOrganizer();
```

#### AUTO 


```{c}
const auto *dummyNode = dynamic_cast<const DummyNode *>(&node);
```

#### RANGE FOR STATEMENT 


```{c}
for (Akonadi::StandardCalendarActionManager::Type calendarAction : qAsConst(calendarActions)) {
            mActionManager->createAction(calendarAction);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Alarm::Ptr &alarm : alarms) {
        const QString uid = alarm->customProperty("ETMCalendar", "parentUid");
        const Akonadi::Item::Id id = mCalendar->item(uid).id();
        const Akonadi::Item item = mCalendar->item(id);

        createReminder(mCalendar, item, from, alarm->text());
    }
```

#### AUTO 


```{c}
const auto *annotationAttribute
            = collection.attribute<PimCommon::CollectionAnnotationsAttribute>();
```

#### AUTO 


```{c}
auto *boolItem = dynamic_cast<KConfigSkeleton::ItemBool *>(item);
```

#### AUTO 


```{c}
auto enumItem = dynamic_cast<KConfigSkeleton::ItemEnum *>(item);
```

#### AUTO 


```{c}
auto topLayout = new QFormLayout(this);
```

#### AUTO 


```{c}
const auto timeDateList
                    = t->recurrence()->timesInInterval(
                    QDateTime(mDays[0], {}, Qt::LocalTime),
                    QDateTime(mDays[NUMDAYS - 1], {}, Qt::LocalTime));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &descendant : descendantsItem) {
                if (Node *proxyNode = getReparentNode(descendant)) {
                    qCDebug(KORGANIZER_LOG) << "reparenting " << descendant.data().toString();
                    int targetRow = proxyNode->children.size();
                    beginInsertRows(index(proxyNode), targetRow, targetRow);
                    appendSourceNode(proxyNode, descendant);
                    reparented << descendant;
                    endInsertRows();
                }
            }
```

#### AUTO 


```{c}
auto row2 = new QStandardItem(QStringLiteral("row2"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const Alarm::Ptr &a : alarms) {
            const Incidence::Ptr parentIncidence = mCalendar->incidence(a->parentUid());
            lst << QStringLiteral("  ") + parentIncidence->summary() +
                   QLatin1String(" (") + a->time().toString() + QLatin1Char(')');
        }
```

#### AUTO 


```{c}
auto *attribute
            = col.attribute<Akonadi::PersistentSearchAttribute>(Akonadi::Collection::AddIfMissing);
```

#### AUTO 


```{c}
auto mainWidget = new QWidget(this);
```

#### AUTO 


```{c}
auto *sync
            = qobject_cast<Akonadi::CollectionAttributesSynchronizationJob *>(job);
```

#### AUTO 


```{c}
auto *ctrlLayout = new QHBoxLayout(this);
```

#### AUTO 


```{c}
auto *job = new BirthdaySearchJob(this, mDaysAhead);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &url : parser.positionalArguments()) {
            korg->actionManager()->importURL(QUrl::fromUserInput(url), false);
        }
```

#### AUTO 


```{c}
auto proxy = qobject_cast<QAbstractProxyModel *>(mCollectionView->model());
```

#### AUTO 


```{c}
auto *progressBar = new KPIM::ProgressStatusBarWidget(statusBar(), this);
```

#### AUTO 


```{c}
auto *tabWidget = new QTabWidget(this);
```

#### AUTO 


```{c}
auto bodyDisposition = new KMime::Headers::ContentDisposition;
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Incidence::Ptr &ev : incidences) {
        Q_ASSERT(ev);
        Akonadi::Item item = m_calendarview->calendar()->item(ev->uid());
        if (m_ui->summaryCheck->isChecked()) {
            if (re.indexIn(ev->summary()) != -1) {
                mMatchedEvents.append(item);
                continue;
            }
        }
        if (m_ui->descriptionCheck->isChecked()) {
            if (re.indexIn(ev->description()) != -1) {
                mMatchedEvents.append(item);
                continue;
            }
        }
        if (m_ui->categoryCheck->isChecked()) {
            if (re.indexIn(ev->categoriesStr()) != -1) {
                mMatchedEvents.append(item);
                continue;
            }
        }
        if (m_ui->locationCheck->isChecked()) {
            if (re.indexIn(ev->location()) != -1) {
                mMatchedEvents.append(item);
                continue;
            }
        }
        if (m_ui->attendeeCheck->isChecked()) {
            const KCalendarCore::Attendee::List lstAttendees = ev->attendees();
            for (const KCalendarCore::Attendee &attendee : lstAttendees) {
                if (re.indexIn(attendee.fullName()) != -1) {
                    mMatchedEvents.append(item);
                    break;
                }
            }
        }
    }
```

#### AUTO 


```{c}
auto itemDateTime = recur->startDateTime();
```

#### AUTO 


```{c}
auto *qjob = new MailTransport::MessageQueueJob(this);
```

#### AUTO 


```{c}
auto layout = new QVBoxLayout(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &email : splittedEmail) {
        const QString str = KEmailAddress::extractEmailAddress(KEmailAddress::normalizeAddressesAndEncodeIdn(email));
        normalizedEmail << str;
    }
```

#### AUTO 


```{c}
auto *qsm
                = new QItemSelectionModel(columnFilterProxy, columnFilterProxy);
```

#### AUTO 


```{c}
auto positioningLayout = new QVBoxLayout(mPositioningGroupBox);
```

#### AUTO 


```{c}
auto job = KIO::del(pageItem->path());
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &name) {
        return Akonadi::Tag{name};
    }
```

#### AUTO 


```{c}
auto w = new KPrefsWidString(item, parent, KLineEdit::Password);
```

#### AUTO 


```{c}
const auto dateTime = triggerDateForIncidence(incidence, reminderAt, displayStr);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KNS3::Entry &e : installedEntries) {
        qCDebug(KORGANIZER_LOG) << " downloadNewStuff :";
        const QStringList lstFile = e.installedFiles();
        if (lstFile.count() != 1) {
            continue;
        }
        const QString file = lstFile.at(0);
        const QUrl filename = QUrl::fromLocalFile(file);
        qCDebug(KORGANIZER_LOG) << "filename :" << filename;
        if (!filename.isValid()) {
            continue;
        }

        KCalendarCore::FileStorage storage(calendar());
        storage.setFileName(file);
        storage.setSaveFormat(new KCalendarCore::ICalFormat);
        if (!storage.load()) {
            KMessageBox::error(mCalendarView, i18n("Could not load calendar %1.", file));
        } else {
            QStringList eventSummaries;
            const KCalendarCore::Event::List events = calendar()->events();
            eventSummaries.reserve(events.count());
            for (const KCalendarCore::Event::Ptr &event : events) {
                eventSummaries.append(event->summary());
            }

            const int result =
                KMessageBox::warningContinueCancelList(mCalendarView, i18n("The downloaded events will be merged into your current calendar."), eventSummaries);

            if (result != KMessageBox::Continue) {
                // FIXME (KNS2): hm, no way out here :-)
            }

            if (importURL(QUrl::fromLocalFile(file), true)) {
                // FIXME (KNS2): here neither
            }
        }
    }
```

#### AUTO 


```{c}
auto *etm = qobject_cast<Akonadi::EntityTreeModel *>(
            proxy->sourceModel());
```

#### AUTO 


```{c}
auto personalLayout = new QVBoxLayout(personalFrame);
```

#### RANGE FOR STATEMENT 


```{c}
for (KDateNavigator *n : std::as_const(mExtraViews)) {
        if (n) {
            n->updateDayMatrix();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalCore::Incidence::Ptr &inc : incidences) {
        Q_ASSERT(inc);
        QDate d = inc->dtStart().toLocalTime().date();
        if (inc->type() == KCalCore::Incidence::TypeJournal &&
            d >= mDays[0] &&
            d <= mDays[NUMDAYS - 1] &&
            !mEvents.contains(d)) {
            mEvents.append(d);
        }
        if (mEvents.count() == NUMDAYS) {
            // No point in wasting cpu, all days are bold already
            break;
        }
    }
```

#### AUTO 


```{c}
auto *systrayGroupLayout = new QVBoxLayout;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &url : argList) {
                mainWindow->actionManager()->importCalendar(QUrl::fromUserInput(url));
            }
```

#### AUTO 


```{c}
const auto lstActions = getActions(option, index);
```

#### AUTO 


```{c}
auto regionalLayout = new QGridLayout(regionalPage);
```

#### AUTO 


```{c}
auto w = new KPrefsWidColor(item, parent);
```

#### RANGE FOR STATEMENT 


```{c}
for (KOrg::Part *part : currentParts) {
        parent->mainGuiClient()->removeChildClient(part);
        delete part;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Node::Ptr &proxyNode : qAsConst(mProxyNodes)) {
        // qCDebug(KORGANIZER_LOG) << "checking " << proxyNode->data(Qt::DisplayRole).toString();
        //Avoid inserting a node that is already part of the source model
        if (isDuplicate(proxyNode)) {
            continue;
        }
        insertProxyNode(proxyNode);
        reparentSourceNodes(proxyNode);
    }
```

#### AUTO 


```{c}
const auto &url
```

#### AUTO 


```{c}
auto deletejob = static_cast<Akonadi::CollectionDeleteJob *>(job);
```

#### AUTO 


```{c}
auto fetch = qobject_cast<Akonadi::CollectionFetchJob *>(job);
```

#### AUTO 


```{c}
auto factory = loader.instance();
```

#### AUTO 


```{c}
auto *w = new KPrefsWidColor(item, parent);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Event::Ptr &event : events) {
                eventSummaries.append(event->summary());
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalCore::Incidence::Ptr &ev : incidences) {
        Q_ASSERT(ev);
        Akonadi::Item item = m_calendarview->calendar()->item(ev->uid());
        if (m_ui->summaryCheck->isChecked()) {
            if (re.indexIn(ev->summary()) != -1) {
                mMatchedEvents.append(item);
                continue;
            }
        }
        if (m_ui->descriptionCheck->isChecked()) {
            if (re.indexIn(ev->description()) != -1) {
                mMatchedEvents.append(item);
                continue;
            }
        }
        if (m_ui->categoryCheck->isChecked()) {
            if (re.indexIn(ev->categoriesStr()) != -1) {
                mMatchedEvents.append(item);
                continue;
            }
        }
        if (m_ui->locationCheck->isChecked()) {
            if (re.indexIn(ev->location()) != -1) {
                mMatchedEvents.append(item);
                continue;
            }
        }
        if (m_ui->attendeeCheck->isChecked()) {
            const KCalCore::Attendee::List lstAttendees = ev->attendees();
            for (const KCalCore::Attendee::Ptr &attendee : lstAttendees) {
                if (re.indexIn(attendee->fullName()) != -1) {
                    mMatchedEvents.append(item);
                    break;
                }
            }
        }
    }
```

#### AUTO 


```{c}
auto dlg = menu.findChild<IncidenceEditorNG::IncidenceDialog *>();
```

#### AUTO 


```{c}
auto createJob = qobject_cast<Akonadi::SearchCreateJob *>(job);
```

#### AUTO 


```{c}
const auto action = static_cast<StyledCalendarDelegate::Action>(a);
```

#### LAMBDA EXPRESSION 


```{c}
[=](){mDateNavigator->selectNextMonth();}
```

#### AUTO 


```{c}
auto job = new Akonadi::SearchCreateJob(name, query);
```

#### LAMBDA EXPRESSION 


```{c}
[=](const Akonadi::Item &i){mMainView->editIncidence(i, false);}
```

#### AUTO 


```{c}
auto parent = new QStandardItem(QStringLiteral("parent"));
```

#### RANGE FOR STATEMENT 


```{c}
for (QTreeWidgetItem *item : selectedItems) {
        auto pageItem = static_cast<PageItem *>(item->parent() ? item->parent() : item);
        if (KMessageBox::warningContinueCancel(this,
                                               i18n("<qt>Do you really want to delete '<b>%1</b>'?</qt>", pageItem->text(0)),
                                               QString(),
                                               KStandardGuiItem::del())
            == KMessageBox::Continue) {
            QFile::remove(pageItem->path());
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        mDateNavigator->selectNextMonth();
    }
```

#### AUTO 


```{c}
auto *job = new Akonadi::SearchCreateJob(name, query);
```

#### AUTO 


```{c}
auto *newMsg = new KMime::Message();
```

#### AUTO 


```{c}
auto incidence = Akonadi::CalendarUtils::incidence(todoItem);
```

#### AUTO 


```{c}
auto *summaryEvent = new SummaryEventInfo();
```

#### AUTO 


```{c}
auto selection = new KCheckableProxyModel;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : indexes) {
        if (index.isValid()) {
            const Akonadi::Collection c
                = index.data(Akonadi::EntityTreeModel::CollectionRole).value<Akonadi::Collection>();
            if (c.id() == collection.id()) {
                return true;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Alarm::Ptr &alarm : alarms) {
        const QString uid = alarm->customProperty("ETMCalendar", "parentUid");
        const Akonadi::Item::Id id = mCalendar->item(uid).id();
        const Akonadi::Item item = mCalendar->item(id);

        createReminder(item, from, alarm->text());
    }
```

#### AUTO 


```{c}
auto *dw = new KDirWatch(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Collection &col : lstCols) {
            const QString collectionName = col.name();
            if (collectionName == QLatin1String("OpenInvitations")) {
                mOpenInvitationCollection = col;
            } else if (collectionName == QLatin1String("DeclinedInvitations")) {
                mDeclineCollection = col;
            }
        }
```

#### AUTO 


```{c}
auto helpEvent = static_cast<QHelpEvent *>(event);
```

#### AUTO 


```{c}
auto *w = new KPrefsWidDate(item, parent);
```

#### AUTO 


```{c}
auto colorProxy = new ColorProxyModel(this);
```

#### AUTO 


```{c}
auto *aTransportLabel = new QLabel(
        i18nc("@label", "Mail transport:"), topFrame);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &url : parser.positionalArguments()) {
                importURL(QUrl::fromUserInput(url), /*merge=*/true);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalCore::Event::Ptr &event : eventlist) {
        if (mEvents.count() == NUMDAYS) {
            // No point in wasting cpu, all days are bold already
            break;
        }

        Q_ASSERT(event);
        const ushort recurType = event->recurrenceType();
        const QDateTime dtStart = event->dtStart().toLocalTime();

        // timed incidences occur in
        //   [dtStart(), dtEnd()[. All-day incidences occur in [dtStart(), dtEnd()]
        // so we subtract 1 second in the timed case
        const int secsToAdd = event->allDay() ? 0 : -1;
        const QDateTime dtEnd = event->dtEnd().toLocalTime().addSecs(secsToAdd);

        if (!(recurType == KCalCore::Recurrence::rDaily
              && !KOPrefs::instance()->mDailyRecur)
            && !(recurType == KCalCore::Recurrence::rWeekly
                 && !KOPrefs::instance()->mWeeklyRecur)) {
            KCalCore::SortableList<QDateTime> timeDateList;
            const bool isRecurrent = event->recurs();
            const int eventDuration = dtStart.daysTo(dtEnd);

            if (isRecurrent) {
                //Its a recurring event, find out in which days it occurs
                timeDateList = event->recurrence()->timesInInterval(
                    QDateTime(mDays[0], {}, Qt::LocalTime),
                    QDateTime(mDays[NUMDAYS - 1], {}, Qt::LocalTime));
            } else {
                if (dtStart.date() >= mDays[0]) {
                    timeDateList.append(dtStart);
                } else {
                    // The event starts in another month (not visible))
                    timeDateList.append(QDateTime(mDays[0], {}, Qt::LocalTime));
                }
            }

            for (auto t = timeDateList.begin(); t != timeDateList.end(); ++t) {
                //This could be a multiday event, so iterate from dtStart() to dtEnd()
                QDate d = t->toLocalTime().date();
                int j = 0;

                QDate occurrenceEnd;
                if (isRecurrent) {
                    occurrenceEnd = d.addDays(eventDuration);
                } else {
                    occurrenceEnd = dtEnd.date();
                }

                do {
                    mEvents.append(d);
                    ++j;
                    d = d.addDays(1);
                } while (d <= occurrenceEnd && j < NUMDAYS);
            }
        }
    }
```

#### AUTO 


```{c}
auto item = new QStandardItem(QStringLiteral("folder"));
```

#### AUTO 


```{c}
auto w = new KPrefsWidDate(item, parent);
```

#### AUTO 


```{c}
auto boxLayout = new QVBoxLayout(box);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QDateTime &dt : timeDateList) {
                    d = dt.toLocalTime().date();
                    if (!mEvents.contains(d)) {
                        mEvents.append(d);
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &descendant : list) {
        for (const Node::Ptr &proxyNode : qAsConst(mProxyNodes)) {
            if (proxyNode->isDuplicateOf(descendant)) {
                // Removenode from proxy
                if (!proxyNode->parent) {
                    qCWarning(KORGANIZER_LOG) << objectName() << "Found proxy that is already not part of the model "
                                              << proxyNode->data(Qt::DisplayRole).toString();
                    continue;
                }
                const int targetRow = proxyNode->row();
                beginRemoveRows(index(proxyNode->parent), targetRow, targetRow);
                proxyNode->parent->children.remove(targetRow);
                proxyNode->parent = nullptr;
                endRemoveRows();
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Node::Ptr &proxyNode : qAsConst(mProxyNodes)) {
        // Reparent source nodes according to the provided rules
        // The proxy can be ignored if it is a duplicate, so only reparent to proxies that are in the model
        if (proxyNode->parent && proxyNode->adopts(sourceIndex)) {
            Q_ASSERT(validateNode(proxyNode.data()));
            return proxyNode.data();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KDateNavigator *n : qAsConst(mExtraViews)) {
            if (n) {
                n->show();
            }
        }
```

#### AUTO 


```{c}
auto *w = const_cast<QWidget *>(opt.widget);
```

#### AUTO 


```{c}
auto *attr = collection.attribute<BlockAlarmsAttribute>(Collection::AddIfMissing);
```

#### AUTO 


```{c}
auto *createnote = menu.findChild<QAction *>(QStringLiteral("createnote"));
```

#### AUTO 


```{c}
auto *categoryLayout = new QGridLayout;
```

#### AUTO 


```{c}
auto *selection = new KCheckableProxyModel;
```

#### AUTO 


```{c}
auto itEnd = events.constEnd();
```

#### AUTO 


```{c}
const auto locale = QLocale::system();
```

#### AUTO 


```{c}
auto *dlg
        = menu.findChild<IncidenceEditorNG::IncidenceDialog *>();
```

#### AUTO 


```{c}
auto e1 = new Event;
```

#### AUTO 


```{c}
auto columnFilterProxy = new KRearrangeColumnsProxyModel(sortProxy);
```

#### AUTO 


```{c}
auto *menu = new QMenu(nullptr);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &descendant : list) {
        Q_FOREACH (const Node::Ptr &proxyNode, mProxyNodes) {
            if (proxyNode->isDuplicateOf(descendant)) {
                //Removenode from proxy
                if (!proxyNode->parent) {
                    qCWarning(KORGANIZER_LOG) <<  objectName()
                                              <<
                        "Found proxy that is already not part of the model " << proxyNode->data(
                        Qt::DisplayRole).toString();
                    continue;
                }
                const int targetRow = proxyNode->row();
                beginRemoveRows(index(proxyNode->parent), targetRow, targetRow);
                proxyNode->parent->children.remove(targetRow);
                proxyNode->parent = nullptr;
                endRemoveRows();
            }
        }
    }
```

#### AUTO 


```{c}
auto *rightBoxVBoxLayout = new QVBoxLayout(rightBox);
```

#### AUTO 


```{c}
auto menu = new QMenu(mYear);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &url : parser.positionalArguments()) {
                importURL(QUrl::fromUserInput(url), /*merge=*/false);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (KCalendarCore::CalFilter *filter : std::as_const(mFilters)) {
        filterList << filter->name();
        KConfigGroup filterConfig(config, QStringLiteral("Filter_") + filter->name());
        filterConfig.writeEntry("Criteria", filter->criteria());
        filterConfig.writeEntry("CategoryList", filter->categoryList());
        filterConfig.writeEntry("HideTodoDays", filter->completedTimeSpan());
    }
```

#### AUTO 


```{c}
auto *workEndLayout = new QHBoxLayout;
```

#### AUTO 


```{c}
auto importer = new Akonadi::ICalImporter();
```

#### AUTO 


```{c}
auto manager = new KColorSchemeManager(this);
```

#### AUTO 


```{c}
auto *displayname
            = col.attribute<Akonadi::EntityDisplayAttribute >(Akonadi::Collection::AddIfMissing);
```

#### AUTO 


```{c}
auto *r = new QRadioButton(text, mBox);
```

#### AUTO 


```{c}
const auto c = index.data(Akonadi::EntityTreeModel::CollectionRole).value<Akonadi::Collection>();
```

#### AUTO 


```{c}
auto topLayout = new QVBoxLayout(topBox);
```

#### AUTO 


```{c}
const auto annotationAttribute = collection.attribute<PimCommon::CollectionAnnotationsAttribute>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Event::Ptr &event : eventlist) {
        if (mEvents.count() == NUMDAYS) {
            // No point in wasting cpu, all days are bold already
            break;
        }

        Q_ASSERT(event);
        const ushort recurType = event->recurrenceType();
        const QDateTime dtStart = event->dtStart().toLocalTime();

        // timed incidences occur in
        //   [dtStart(), dtEnd()[. All-day incidences occur in [dtStart(), dtEnd()]
        // so we subtract 1 second in the timed case
        const int secsToAdd = event->allDay() ? 0 : -1;
        const QDateTime dtEnd = event->dtEnd().toLocalTime().addSecs(secsToAdd);

        if (!(recurType == KCalendarCore::Recurrence::rDaily
              && !KOPrefs::instance()->mDailyRecur)
            && !(recurType == KCalendarCore::Recurrence::rWeekly
                 && !KOPrefs::instance()->mWeeklyRecur)) {
            KCalendarCore::DateTimeList timeDateList;
            const bool isRecurrent = event->recurs();
            const int eventDuration = dtStart.daysTo(dtEnd);

            if (isRecurrent) {
                //Its a recurring event, find out in which days it occurs
                timeDateList = event->recurrence()->timesInInterval(
                    QDateTime(mDays[0], {}, Qt::LocalTime),
                    QDateTime(mDays[NUMDAYS - 1], {}, Qt::LocalTime));
            } else {
                if (dtStart.date() >= mDays[0]) {
                    timeDateList.append(dtStart);
                } else {
                    // The event starts in another month (not visible))
                    timeDateList.append(QDateTime(mDays[0], {}, Qt::LocalTime));
                }
            }

            for (auto t = timeDateList.begin(); t != timeDateList.end(); ++t) {
                //This could be a multiday event, so iterate from dtStart() to dtEnd()
                QDate d = t->toLocalTime().date();
                int j = 0;

                QDate occurrenceEnd;
                if (isRecurrent) {
                    occurrenceEnd = d.addDays(eventDuration);
                } else {
                    occurrenceEnd = dtEnd.date();
                }

                do {
                    mEvents.append(d);
                    ++j;
                    d = d.addDays(1);
                } while (d <= occurrenceEnd && j < NUMDAYS);
            }
        }
    }
```

#### AUTO 


```{c}
auto incidence = CalendarSupport::incidence(item);
```

#### AUTO 


```{c}
auto *proxy = qobject_cast<QAbstractProxyModel *>(mCollectionView->model());
```

#### RANGE FOR STATEMENT 


```{c}
for (KOrg::Part *part : qAsConst(mParts)) {
        if (part) {
            dlg.addCollection(part->actionCollection(), part->shortInfo());
        }
    }
```

#### AUTO 


```{c}
auto *mdisplayLayout = new QVBoxLayout;
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Event::Ptr &event : eventlist) {
        if (mEvents.count() == NUMDAYS) {
            // No point in wasting cpu, all days are bold already
            break;
        }

        Q_ASSERT(event);
        const ushort recurType = event->recurrenceType();
        const QDateTime dtStart = event->dtStart().toLocalTime();

        // timed incidences occur in
        //   [dtStart(), dtEnd()[. All-day incidences occur in [dtStart(), dtEnd()]
        // so we subtract 1 second in the timed case
        const int secsToAdd = event->allDay() ? 0 : -1;
        const QDateTime dtEnd = event->dtEnd().toLocalTime().addSecs(secsToAdd);

        if (!(recurType == KCalendarCore::Recurrence::rDaily && !KOPrefs::instance()->mDailyRecur)
            && !(recurType == KCalendarCore::Recurrence::rWeekly && !KOPrefs::instance()->mWeeklyRecur)) {
            KCalendarCore::DateTimeList timeDateList;
            const bool isRecurrent = event->recurs();
            const int eventDuration = dtStart.daysTo(dtEnd);

            if (isRecurrent) {
                // Its a recurring event, find out in which days it occurs
                timeDateList = event->recurrence()->timesInInterval(QDateTime(mDays[0], {}, Qt::LocalTime), QDateTime(mDays[NUMDAYS - 1], {}, Qt::LocalTime));
            } else {
                if (dtStart.date() >= mDays[0]) {
                    timeDateList.append(dtStart);
                } else {
                    // The event starts in another month (not visible))
                    timeDateList.append(QDateTime(mDays[0], {}, Qt::LocalTime));
                }
            }

            for (auto t = timeDateList.begin(); t != timeDateList.end(); ++t) {
                // This could be a multiday event, so iterate from dtStart() to dtEnd()
                QDate d = t->toLocalTime().date();
                int j = 0;

                QDate occurrenceEnd;
                if (isRecurrent) {
                    occurrenceEnd = d.addDays(eventDuration);
                } else {
                    occurrenceEnd = dtEnd.date();
                }

                do {
                    mEvents.append(d);
                    ++j;
                    d = d.addDays(1);
                } while (d <= occurrenceEnd && j < NUMDAYS);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalCore::Event::Ptr &event : events) {
                eventSummaries.append(event->summary());
            }
```

#### AUTO 


```{c}
auto columnFilterProxy = new KRearrangeColumnsProxyModel(
                sortProxy);
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
            history->undo();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const KCalendarCore::DateList &dates) {
        mDateNavigator->selectDates(dates);
    }
```

#### AUTO 


```{c}
auto eventViewer = new KOEventViewerDialog(mCalendar.data(), this);
```

#### AUTO 


```{c}
auto propsIface = new OrgFreedesktopDBusPropertiesInterface(QString::fromLatin1(s_fdo_notifications_service),
                                                                    QString::fromLatin1(s_fdo_notifications_path),
                                                                    dbusConn,
                                                                    this);
```

#### AUTO 


```{c}
auto *layout = new QVBoxLayout(this);
```

#### AUTO 


```{c}
auto timesLayout = new QGridLayout(timesGroupBox);
```

#### AUTO 


```{c}
auto plugins = KOCore::self()->availableCalendarDecorations();
```

#### AUTO 


```{c}
auto tdisplayLayout = new QVBoxLayout;
```

#### AUTO 


```{c}
auto gdisplayLayout = new QVBoxLayout;
```

#### LAMBDA EXPRESSION 


```{c}
[=](bool){mCalendarView->schedule_refresh();}
```

#### AUTO 


```{c}
auto qjob = new MailTransport::MessageQueueJob(this);
```

#### AUTO 


```{c}
auto *w = new KPrefsWidRadios(item, parent);
```

#### AUTO 


```{c}
auto cview = new AkonadiCollectionView(nullptr, false, q);
```

#### AUTO 


```{c}
auto *enumItem = dynamic_cast<KConfigSkeleton::ItemEnum *>(item);
```

#### RANGE FOR STATEMENT 


```{c}
for (KColorButton *colorButton : qAsConst(mButtonsDisable)) {
        if (useSystemColor) {
            colorButton->setEnabled(false);
        } else {
            colorButton->setEnabled(true);
        }
    }
```

#### AUTO 


```{c}
auto *stringItem
        = dynamic_cast<KConfigSkeleton::ItemString *>(item);
```

#### AUTO 


```{c}
const auto timeDateList
                    = t->recurrence()->timesInInterval(
                          QDateTime(mDays[0], {}, Qt::LocalTime),
                          QDateTime(mDays[NUMDAYS - 1], {}, Qt::LocalTime));
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Todo::Ptr &todo : qAsConst(prList)) {
            bool makeBold = false;
            int daysTo = -1;

            // Optionally, show only my To-dos
            /*      if ( mShowMineOnly &&
                         !KCalendarCore::CalHelper::isMyCalendarIncidence( mCalendarAdaptor, todo.get() ) ) {
                    continue;
                  }
            TODO: calhelper is deprecated, remove this?
            */

            // Icon label
            label = new QLabel(this);
            label->setPixmap(pm);
            label->setMaximumWidth(label->minimumSizeHint().width());
            mLayout->addWidget(label, counter, 0);
            mLabels.append(label);

            // Due date label
            str.clear();
            if (todo->hasDueDate() && todo->dtDue().date().isValid()) {
                daysTo = currDate.daysTo(todo->dtDue().date());

                if (daysTo == 0) {
                    makeBold = true;
                    str = i18nc("the to-do is due today", "Today");
                } else if (daysTo == 1) {
                    str = i18nc("the to-do is due tomorrow", "Tomorrow");
                } else {
                    const auto locale = QLocale::system();
                    for (int i = 3; i < 8; ++i) {
                        if (daysTo < i * 24 * 60 * 60) {
                            str = i18nc("1. weekday, 2. time", "%1 %2",
                                        locale.dayName(todo->dtDue().date().dayOfWeek(),
                                                       QLocale::LongFormat),
                                        locale.toString(todo->dtDue().time(),
                                                        QLocale::ShortFormat));
                            break;
                        }
                    }
                    if (str.isEmpty()) {
                        str = locale.toString(todo->dtDue(), QLocale::ShortFormat);
                    }
                }
            }

            label = new QLabel(str, this);
            label->setAlignment(Qt::AlignLeft | Qt::AlignVCenter);
            mLayout->addWidget(label, counter, 1);
            mLabels.append(label);
            if (makeBold) {
                QFont font = label->font();
                font.setBold(true);
                label->setFont(font);
            }

            // Days togo/ago label
            str.clear();
            if (todo->hasDueDate() && todo->dtDue().date().isValid()) {
                if (daysTo > 0) {
                    str = i18np("in 1 day", "in %1 days", daysTo);
                } else if (daysTo < 0) {
                    str = i18np("1 day ago", "%1 days ago", -daysTo);
                } else {
                    str = i18nc("the to-do is due", "due");
                }
            }
            label = new QLabel(str, this);
            label->setAlignment(Qt::AlignLeft | Qt::AlignVCenter);
            mLayout->addWidget(label, counter, 2);
            mLabels.append(label);

            // Priority label
            str = QLatin1Char('[') + QString::number(todo->priority()) + QLatin1Char(']');
            label = new QLabel(str, this);
            label->setAlignment(Qt::AlignRight | Qt::AlignVCenter);
            mLayout->addWidget(label, counter, 3);
            mLabels.append(label);

            // Summary label
            str = todo->summary();
            if (!todo->relatedTo().isEmpty()) {   // show parent only, not entire ancestry
                KCalendarCore::Incidence::Ptr inc = mCalendar->incidence(todo->relatedTo());
                if (inc) {
                    str = inc->summary() + QLatin1Char(':') + str;
                }
            }
            if (!Qt::mightBeRichText(str)) {
                str = str.toHtmlEscaped();
            }

            KUrlLabel *urlLabel = new KUrlLabel(this);
            urlLabel->setText(str);
            urlLabel->setUrl(todo->uid());
            urlLabel->installEventFilter(this);
            urlLabel->setTextFormat(Qt::RichText);
            urlLabel->setWordWrap(true);
            mLayout->addWidget(urlLabel, counter, 4);
            mLabels.append(urlLabel);
            connect(urlLabel, &KUrlLabel::leftClickedUrl, this, [this, urlLabel] {
                viewTodo(urlLabel->url());
            });
            connect(urlLabel, &KUrlLabel::rightClickedUrl, this, [this, urlLabel] {
                popupMenu(urlLabel->url());
            });
            // State text label
            str = stateStr(todo);
            label = new QLabel(str, this);
            label->setAlignment(Qt::AlignLeft | Qt::AlignVCenter);
            mLayout->addWidget(label, counter, 5);
            mLabels.append(label);

            counter++;
        }
```

#### AUTO 


```{c}
const auto v3 = qstyleoption_cast<const QStyleOptionViewItem *>(&option)
```

#### AUTO 


```{c}
auto fontLayout = new QGridLayout(fontFrame);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Collection &checkedCollection : collections) {
        supportsMimeType = checkedCollection.contentMimeTypes().contains(mimeType) || mimeType == QLatin1String("");
        hasRights = checkedCollection.rights() & Akonadi::Collection::CanCreateItem;
        if (checkedCollection.isValid() && supportsMimeType && hasRights) {
            return checkedCollection;
        }
    }
```

#### AUTO 


```{c}
auto mainLayout = new QVBoxLayout(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &descendant : list) {
        Q_FOREACH (const Node::Ptr &proxyNode, mProxyNodes) {
            if (proxyNode->isDuplicateOf(descendant)) {
                //Removenode from proxy
                if (!proxyNode->parent) {
                    qCWarning(KORGANIZER_LOG) <<  objectName()
                                              <<
                    "Found proxy that is already not part of the model " << proxyNode->data(
                        Qt::DisplayRole).toString();
                    continue;
                }
                const int targetRow = proxyNode->row();
                beginRemoveRows(index(proxyNode->parent), targetRow, targetRow);
                proxyNode->parent->children.remove(targetRow);
                proxyNode->parent = nullptr;
                endRemoveRows();
            }
        }
    }
```

#### AUTO 


```{c}
auto user2Button = new QPushButton(this);
```

#### AUTO 


```{c}
auto *timesLayout = new QGridLayout(timesGroupBox);
```

#### AUTO 


```{c}
auto label = new QLabel(i18nc("@label:textbox Name of the folder.", "&Name:"), this);
```

#### AUTO 


```{c}
auto fetch = new Akonadi::CollectionFetchJob(mCollectionView->currentCalendar(), Akonadi::CollectionFetchJob::Base);
```

#### LAMBDA EXPRESSION 


```{c}
[](KJob *job) {
            if (job->error()) {
                KMessageBox::detailedSorry(nullptr, i18n("Failed to retrieve incidence from Akonadi"), job->errorText());
                return;
            }
            auto fetchJob = static_cast<Akonadi::ItemFetchJob *>(job);
            if (fetchJob->count() != 1) {
                KMessageBox::sorry(nullptr, i18n("Failed to retrieve incidence from Akonadi: requested incidence doesn't exist."));
                return;
            }
            KOrg::MainWindow *korg = ActionManager::findInstance(QUrl());
            korg->actionManager()->view()->showIncidence(fetchJob->items().first());
        }
```

#### AUTO 


```{c}
auto createnotefortodo = menu.findChild<QAction *>(QStringLiteral("createnotefortodo"));
```

#### AUTO 


```{c}
auto systrayLayout = new QVBoxLayout(systrayFrame);
```

#### AUTO 


```{c}
auto *positioningLayout = new QVBoxLayout(mPositioningGroupBox);
```

#### AUTO 


```{c}
auto *displayname = col.attribute<Akonadi::EntityDisplayAttribute>(Akonadi::Collection::AddIfMissing);
```

#### AUTO 


```{c}
auto *collectionFilter = new CollectionFilter(this);
```

#### AUTO 


```{c}
auto *job = new Akonadi::ItemFetchJob(item, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Node::Ptr &proxyNode : qAsConst(mProxyNodes)) {
            if (proxyNode->isDuplicateOf(descendant)) {
                // Removenode from proxy
                if (!proxyNode->parent) {
                    qCWarning(KORGANIZER_LOG) << objectName() << "Found proxy that is already not part of the model "
                                              << proxyNode->data(Qt::DisplayRole).toString();
                    continue;
                }
                const int targetRow = proxyNode->row();
                beginRemoveRows(index(proxyNode->parent), targetRow, targetRow);
                proxyNode->parent->children.remove(targetRow);
                proxyNode->parent = nullptr;
                endRemoveRows();
            }
        }
```

#### AUTO 


```{c}
auto *columnFilterProxy = new KRearrangeColumnsProxyModel(
                sortProxy);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &a : attendees) {
        const QString email = a.email();
        if (email.isEmpty()) {
            continue;
        }

        // In case we (as one of our identities) are the organizer we are sending
        // this mail. We could also have added ourselves as an attendee, in which
        // case we don't want to send ourselves a notification mail.
        if (organizerEmail == email) {
            continue;
        }

        // Build a nice address for this attendee including the CN.
        QString tname, temail;
        const QString username = KEmailAddress::quoteNameIfNecessary(a.name());
        // ignore the return value from extractEmailAddressAndName() because
        // it will always be false since tusername does not contain "@domain".
        KEmailAddress::extractEmailAddressAndName(username, temail /*byref*/, tname /*byref*/);
        tname += QStringLiteral(" <") + email + QLatin1Char('>');

        // Optional Participants and Non-Participants are copied on the email
        if (a.role() == KCalendarCore::Attendee::OptParticipant
            || a.role() == KCalendarCore::Attendee::NonParticipant) {
            ccList << tname;
        } else {
            toList << tname;
        }
    }
```

#### AUTO 


```{c}
auto *createjob
        = static_cast<Akonadi::AgentInstanceCreateJob *>(job);
```

#### AUTO 


```{c}
auto eventPopup = new KOEventPopupMenu(calendar(), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &metaData : availablePlugins) {
#if KCMUTILS_VERSION >= QT_VERSION_CHECK(5, 84, 0)
            mOptionsDialog->addModule(metaData);
#else
            mOptionsDialog->addModule(metaData.pluginId());
#endif
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Incidence::Ptr &inc : incidences) {
        Q_ASSERT(inc);
        QDate d = inc->dtStart().toLocalTime().date();
        if (inc->type() == KCalendarCore::Incidence::TypeJournal && d >= mDays[0] && d <= mDays[NUMDAYS - 1] && !mEvents.contains(d)) {
            mEvents.append(d);
        }
        if (mEvents.count() == NUMDAYS) {
            // No point in wasting cpu, all days are bold already
            break;
        }
    }
```

#### AUTO 


```{c}
const auto agendaViewTop = viewPrefs->decorationsAtAgendaViewTop();
```

#### AUTO 


```{c}
const auto desc = KHolidays::HolidayRegion::description(regionCode);
```

#### AUTO 


```{c}
const auto retKey = new QShortcut(QKeySequence(Qt::Key_Return), this);
```

#### AUTO 


```{c}
auto *e3 = new Event;
```

#### AUTO 


```{c}
auto delegate = new StyledCalendarDelegate(mCollectionView);
```

#### LAMBDA EXPRESSION 


```{c}
[=](const Akonadi::Item &i) {
        mMainView->deleteIncidence(i, false);
    }
```

#### AUTO 


```{c}
auto qsm = new QItemSelectionModel(columnFilterProxy, columnFilterProxy);
```

#### LAMBDA EXPRESSION 


```{c}
[=](const Akonadi::Item & i){mMainView->deleteIncidence(i, false);}
```

#### AUTO 


```{c}
const auto collection = index.data(Akonadi::EntityTreeModel::CollectionRole).value<Akonadi::Collection>();
```

#### AUTO 


```{c}
auto *menu = new QMenu(mMonth);
```

#### RANGE FOR STATEMENT 


```{c}
for (KColorButton *colorButton : mButtonsDisable) {
        if (useSystemColor) {
            colorButton->setEnabled(false);
        } else {
            colorButton->setEnabled(true);
        }
    }
```

#### AUTO 


```{c}
const auto agendaViewBottom = viewPrefs->decorationsAtAgendaViewBottom();
```

#### AUTO 


```{c}
const auto incidence = CalendarSupport::incidence(item);
```

#### AUTO 


```{c}
auto *w = new KPrefsWidBool(item, parent);
```

#### RANGE FOR STATEMENT 


```{c}
for (Akonadi::StandardActionManager::Type standardAction : std::as_const(standardActions)) {
            mActionManager->createAction(standardAction);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalCore::Event::Ptr &ev : events) {
            // Optionally, show only my Events
            /* if ( mShowMineOnly &&
                    !KCalCore::CalHelper::isMyCalendarIncidence( mCalendarAdaptor, ev. ) ) {
              // FIXME; does isMyCalendarIncidence work !? It's deprecated too.
              continue;
              }
              // TODO: CalHelper is deprecated, remove this?
              */

            if (ev->customProperty("KABC", "BIRTHDAY") == QLatin1String("YES")) {
                // Skipping, because these are got by the BirthdaySearchJob
                // See comments in updateView()
                continue;
            }

            if (!ev->categoriesStr().isEmpty()) {
                QStringList::ConstIterator it2;
                const QStringList c = ev->categories();
                QStringList::ConstIterator end(c.constEnd());
                for (it2 = c.constBegin(); it2 != end; ++it2) {
                    const QString itUpper((*it2).toUpper());
                    // Append Birthday Event?
                    if (mShowBirthdaysFromCal && (itUpper == QLatin1String("BIRTHDAY"))) {
                        SDEntry entry;
                        entry.type = IncidenceTypeEvent;
                        entry.category = CategoryBirthday;
                        entry.date = dt;
                        entry.summary = ev->summary();
                        entry.desc = ev->description();
                        dateDiff(ev->dtStart().date(), entry.daysTo, entry.yearsOld);
                        entry.span = 1;

                        /* The following check is to prevent duplicate entries,
                         * so in case of having a KCal incidence with category birthday
                         * with summary and date equal to some KABC Atendee we don't show it
                         * FIXME: port to akonadi, it's kresource based
                         * */
                        if (/*!check( bdayRes, dt, ev->summary() )*/ true) {
                            mDates.append(entry);
                        }
                        break;
                    }

                    // Append Anniversary Event?
                    if (mShowAnniversariesFromCal && (itUpper == QStringLiteral("ANNIVERSARY"))) {
                        SDEntry entry;
                        entry.type = IncidenceTypeEvent;
                        entry.category = CategoryAnniversary;
                        entry.date = dt;
                        entry.summary = ev->summary();
                        entry.desc = ev->description();
                        dateDiff(ev->dtStart().date(), entry.daysTo, entry.yearsOld);
                        entry.span = 1;
                        if (/*!check( annvRes, dt, ev->summary() )*/ true) {
                            mDates.append(entry);
                        }
                        break;
                    }

                    // Append Holiday Event?
                    if (mShowHolidays && (itUpper == QLatin1String("HOLIDAY"))) {
                        SDEntry entry;
                        entry.type = IncidenceTypeEvent;
                        entry.category = CategoryHoliday;
                        entry.date = dt;
                        entry.summary = ev->summary();
                        entry.desc = ev->description();
                        dateDiff(dt, entry.daysTo, entry.yearsOld);
                        entry.yearsOld = -1; //ignore age of holidays
                        entry.span = span(ev);
                        if (entry.span > 1 && dayof(ev, dt) > 1) {     // skip days 2,3,...
                            break;
                        }
                        mDates.append(entry);
                        break;
                    }

                    // Append Special Occasion Event?
                    if (mShowSpecialsFromCal && (itUpper == QLatin1String("SPECIAL OCCASION"))) {
                        SDEntry entry;
                        entry.type = IncidenceTypeEvent;
                        entry.category = CategoryOther;
                        entry.date = dt;
                        entry.summary = ev->summary();
                        entry.desc = ev->description();
                        dateDiff(dt, entry.daysTo, entry.yearsOld);
                        entry.yearsOld = -1; //ignore age of special occasions
                        entry.span = span(ev);
                        if (entry.span > 1 && dayof(ev, dt) > 1) {     // skip days 2,3,...
                            break;
                        }
                        mDates.append(entry);
                        break;
                    }
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (KCalCore::CalFilter *filter : qAsConst(mFilters)) {
        if (filter) {
            filters << filter->name();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KHolidays::HolidayRegion *region : holidays) {
        const QString regionStr = region->regionCode();
        mHolidayCheckCombo->setItemCheckState(
                    mHolidayCheckCombo->findData(regionStr), Qt::Checked);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Node::Ptr &proxyNode : std::as_const(mProxyNodes)) {
        proxyNode->clearHierarchy();
    }
```

#### AUTO 


```{c}
auto *createtodo = menu.findChild<QAction *>(QStringLiteral("createtodo"));
```

#### AUTO 


```{c}
auto job = new Akonadi::ItemFetchJob(Akonadi::Item(static_cast<qint64>(query.queryItemValue(QStringLiteral("item")).toLongLong())));
```

#### AUTO 


```{c}
auto pluginFactory = qobject_cast<CalendarSupport::PluginFactory*>(factory);
```

#### AUTO 


```{c}
auto mEventViewerBoxVBoxLayout = new QVBoxLayout(mEventViewerBox);
```

#### LAMBDA EXPRESSION 


```{c}
[=](const Akonadi::Item &i) {
            mMainView->deleteIncidence(i, false);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalCore::Attendee::Ptr &attendee : lstAttendees) {
                if (re.indexIn(attendee->fullName()) != -1) {
                    mMatchedEvents.append(item);
                    break;
                }
            }
```

#### AUTO 


```{c}
auto createevent = menu.findChild<QAction *>(QStringLiteral("createevent"));
```

#### AUTO 


```{c}
auto datetimeLayout = new QGridLayout(datetimeGroupBox);
```

#### AUTO 


```{c}
auto *menu = new QMenu(this);
```

#### AUTO 


```{c}
auto *disposition
                = new KMime::Headers::ContentDisposition;
```

#### AUTO 


```{c}
auto *audioFileRemindersBox = new QVBoxLayout;
```

#### RANGE FOR STATEMENT 


```{c}
for (KOrg::MainWindow *inst : qAsConst(mWindowList)) {
        if (inst && inst->getCurrentURL() == url) {
            return inst;
        }
    }
```

#### AUTO 


```{c}
const auto newState = static_cast<Qt::CheckState>(value.toInt());
```

#### RANGE FOR STATEMENT 


```{c}
for (KDateNavigator *n : std::as_const(mExtraViews)) {
        if (n) {
            n->updateConfig();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &metaData : availablePlugins) {
            mOptionsDialog->addModule(metaData);
        }
```

#### AUTO 


```{c}
auto job = KIO::file_copy(QUrl::fromLocalFile(tfile), dest);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KDateTime &dt : timeDateList) {
                    d = dt.toTimeSpec(mCalendar->timeSpec()).date();
                    if (!mEvents.contains(d)) {
                        mEvents.append(d);
                    }
                }
```

#### AUTO 


```{c}
auto *note = new QLabel(
        xi18nc("@info",
               "<note>The daemon will continue running even if it is not shown "
               "in the system tray.</note>"));
```

#### AUTO 


```{c}
auto *firstDayLayout = new QHBoxLayout;
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalCore::Event::Ptr &event : eventlist) {
        if (mEvents.count() == NUMDAYS) {
            // No point in wasting cpu, all days are bold already
            break;
        }

        Q_ASSERT(event);
        const ushort recurType = event->recurrenceType();
        const KDateTime dtStart = event->dtStart().toTimeSpec(mCalendar->timeSpec());

        // timed incidences occur in
        //   [dtStart(), dtEnd()[. All-day incidences occur in [dtStart(), dtEnd()]
        // so we subtract 1 second in the timed case
        const int secsToAdd = event->allDay() ? 0 : -1;
        const KDateTime dtEnd = event->dtEnd().toTimeSpec(mCalendar->timeSpec()).addSecs(secsToAdd);

        if (!(recurType == KCalCore::Recurrence::rDaily  && !KOPrefs::instance()->mDailyRecur) &&
                !(recurType == KCalCore::Recurrence::rWeekly && !KOPrefs::instance()->mWeeklyRecur)) {

            KCalCore::DateTimeList timeDateList;
            const bool isRecurrent = event->recurs();
            const int eventDuration = dtStart.daysTo(dtEnd);

            if (isRecurrent) {
                //Its a recurring event, find out in which days it occurs
                timeDateList = event->recurrence()->timesInInterval(
                                   KDateTime(mDays[0], mCalendar->timeSpec()),
                                   KDateTime(mDays[NUMDAYS - 1], mCalendar->timeSpec()));
            } else {
                if (dtStart.date() >= mDays[0]) {
                    timeDateList.append(dtStart);
                } else {
                    // The event starts in another month (not visible))
                    timeDateList.append(KDateTime(mDays[0], mCalendar->timeSpec()));
                }
            }

            KCalCore::DateTimeList::iterator t;
            for (t = timeDateList.begin(); t != timeDateList.end(); ++t) {
                //This could be a multiday event, so iterate from dtStart() to dtEnd()
                QDate d = t->toTimeSpec(mCalendar->timeSpec()).date();
                int j   = 0;

                QDate occurrenceEnd;
                if (isRecurrent) {
                    occurrenceEnd = d.addDays(eventDuration);
                } else {
                    occurrenceEnd = dtEnd.date();
                }

                do {
                    mEvents.append(d);
                    ++j;
                    d = d.addDays(1);
                } while (d <= occurrenceEnd && j < NUMDAYS);
            }
        }
    }
```

#### AUTO 


```{c}
auto e3 = new Event;
```

#### AUTO 


```{c}
auto *user2Button = new QPushButton(this);
```

#### AUTO 


```{c}
auto attachMessage = new KMime::Content;
```

#### AUTO 


```{c}
const auto occurrences = event->recurrence()->timesInInterval(QDateTime(start,
                                                                                    {}),
                                                                          QDateTime(end, {}));
```

#### AUTO 


```{c}
auto *kcm = new MyDesignerFields();
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalCore::Todo::Ptr &t : incidences) {
        if (mEvents.count() == NUMDAYS) {
            // No point in wasting cpu, all days are bold already
            break;
        }
        Q_ASSERT(t);
        if (t->hasDueDate()) {
            ushort recurType = t->recurrenceType();

            if (t->recurs() &&
                    !(recurType == KCalCore::Recurrence::rDaily && !KOPrefs::instance()->mDailyRecur) &&
                    !(recurType == KCalCore::Recurrence::rWeekly && !KOPrefs::instance()->mWeeklyRecur)) {

                // It's a recurring todo, find out in which days it occurs
                const KCalCore::DateTimeList timeDateList =
                    t->recurrence()->timesInInterval(
                        KDateTime(mDays[0], mCalendar->timeSpec()),
                        KDateTime(mDays[NUMDAYS - 1], mCalendar->timeSpec()));

                for (const KDateTime &dt : timeDateList) {
                    d = dt.toTimeSpec(mCalendar->timeSpec()).date();
                    if (!mEvents.contains(d)) {
                        mEvents.append(d);
                    }
                }

            } else {
                d = t->dtDue().toTimeSpec(mCalendar->timeSpec()).date();
                if (d >= mDays[0] && d <= mDays[NUMDAYS - 1] && !mEvents.contains(d)) {
                    mEvents.append(d);
                }
            }
        }
    }
```

#### AUTO 


```{c}
const auto addressee = item.payload<KContacts::Addressee>();
```

#### AUTO 


```{c}
auto about = new KAboutData(QStringLiteral("kcmsdsummary"),
                                i18n("Upcoming Special Dates Configuration Dialog"),
                                QString(),
                                QString(),
                                KAboutLicense::GPL,
                                i18n("Copyright � 2004 Tobias Koenig\n"
                                     "Copyright � 2004�2010 Allen Winter"));
```

#### AUTO 


```{c}
auto attachDisposition = new KMime::Headers::ContentDisposition;
```

#### AUTO 


```{c}
auto *sortProxy = new QSortFilterProxyModel;
```

#### RANGE FOR STATEMENT 


```{c}
for (KHolidays::HolidayRegion *region : holidays) {
        const QString regionStr = region->regionCode();
        mHolidayCheckCombo->setItemCheckState(mHolidayCheckCombo->findData(regionStr), Qt::Checked);
    }
```

#### AUTO 


```{c}
auto *newFilter = new KCalendarCore::CalFilter(newFilterName);
```

#### AUTO 


```{c}
auto *topLayout = new QVBoxLayout(this);
```

#### AUTO 


```{c}
auto label = new QLabel(i18np("No special dates within the next 1 day", "No special dates pending within the next %1 days", mDaysAhead), this);
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
                history->undo();
            }
```

#### AUTO 


```{c}
auto quickview = new Quickview(CalendarSupport::collectionFromIndex(index));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &entry : regionsMap) {
            mHolidayCheckCombo->addItem(entry.first, entry.second);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, url](KJob *job) {
                        if (job->error()) {
                            return;
                        }
                        auto fetchJob = qobject_cast<Akonadi::ItemFetchJob *>(job);
                        const Akonadi::Item::List items = fetchJob->items();
                        for (const Akonadi::Item &item : items) {
                            if (item.mimeType() == QStringLiteral("message/rfc822")) {
                                auto mail = item.payload<KMime::Message::Ptr>();
                                interface()->openTodoEditor(i18nc("Event from email summary", "Mail: %1", mail->subject()->asUnicodeString()),
                                                            i18nc("Event from email content",
                                                                  "<b>From:</b> %1<br /><b>To:</b> %2<br /><b>Subject:</b> %3",
                                                                  mail->from()->displayString(),
                                                                  mail->to()->displayString(),
                                                                  mail->subject()->asUnicodeString()),
                                                            url.toDisplayString(),
                                                            QString(),
                                                            QStringList(),
                                                            QStringLiteral("message/rfc822"));
                            }
                        }
                    }
```

#### AUTO 


```{c}
auto box = new QDialogButtonBox(QDialogButtonBox::Yes | QDialogButtonBox::No | QDialogButtonBox::Cancel | QDialogButtonBox::Ok, parent);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KNS3::Entry &e : installedEntries) {
        qCDebug(KORGANIZER_LOG) << " downloadNewStuff :";
        const QStringList lstFile = e.installedFiles();
        if (lstFile.count() != 1) {
            continue;
        }
        const QString file = lstFile.at(0);
        const QUrl filename = QUrl::fromLocalFile(file);
        qCDebug(KORGANIZER_LOG) << "filename :" << filename;
        if (!filename.isValid()) {
            continue;
        }

        KCalendarCore::FileStorage storage(calendar());
        storage.setFileName(file);
        storage.setSaveFormat(new KCalendarCore::ICalFormat);
        if (!storage.load()) {
            KMessageBox::error(mCalendarView, i18n("Could not load calendar %1.", file));
        } else {
            QStringList eventSummaries;
            const KCalendarCore::Event::List events = calendar()->events();
            eventSummaries.reserve(events.count());
            for (const KCalendarCore::Event::Ptr &event : events) {
                eventSummaries.append(event->summary());
            }

            const int result
                = KMessageBox::warningContinueCancelList(
                      mCalendarView,
                      i18n("The downloaded events will be merged into your current calendar."),
                      eventSummaries);

            if (result != KMessageBox::Continue) {
                // FIXME (KNS2): hm, no way out here :-)
            }

            if (importURL(QUrl::fromLocalFile(file), true)) {
                // FIXME (KNS2): here neither
            }
        }
    }
```

#### AUTO 


```{c}
auto layout = new QHBoxLayout(q);
```

#### AUTO 


```{c}
auto createtodo = menu.findChild<QAction *>(QStringLiteral("createtodo"));
```

#### RANGE FOR STATEMENT 


```{c}
for (KDateNavigator *n : std::as_const(mExtraViews)) {
                if (n) {
                    n->selectDates(dateList);
                }
            }
```

#### AUTO 


```{c}
auto *e1 = new Event;
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Todo::Ptr &todo : qAsConst(prList)) {
            bool makeBold = false;
            int daysTo = -1;

            // Optionally, show only my To-dos
            /*      if ( mShowMineOnly &&
                         !KCalendarCore::CalHelper::isMyCalendarIncidence( mCalendarAdaptor, todo.get() ) ) {
                    continue;
                  }
            TODO: calhelper is deprecated, remove this?
            */

            // Icon label
            label = new QLabel(this);
            label->setPixmap(pm);
            label->setMaximumWidth(label->minimumSizeHint().width());
            mLayout->addWidget(label, counter, 0);
            mLabels.append(label);

            // Due date label
            str.clear();
            if (todo->hasDueDate() && todo->dtDue().date().isValid()) {
                daysTo = currDate.daysTo(todo->dtDue().date());

                if (daysTo == 0) {
                    makeBold = true;
                    str = i18nc("the to-do is due today", "Today");
                } else if (daysTo == 1) {
                    str = i18nc("the to-do is due tomorrow", "Tomorrow");
                } else {
                    const auto locale = QLocale::system();
                    for (int i = 3; i < 8; ++i) {
                        if (daysTo < i * 24 * 60 * 60) {
                            str = i18nc("1. weekday, 2. time",
                                        "%1 %2",
                                        locale.dayName(todo->dtDue().date().dayOfWeek(), QLocale::LongFormat),
                                        locale.toString(todo->dtDue().time(), QLocale::ShortFormat));
                            break;
                        }
                    }
                    if (str.isEmpty()) {
                        str = locale.toString(todo->dtDue(), QLocale::ShortFormat);
                    }
                }
            }

            label = new QLabel(str, this);
            label->setAlignment(Qt::AlignLeft | Qt::AlignVCenter);
            mLayout->addWidget(label, counter, 1);
            mLabels.append(label);
            if (makeBold) {
                QFont font = label->font();
                font.setBold(true);
                label->setFont(font);
            }

            // Days togo/ago label
            str.clear();
            if (todo->hasDueDate() && todo->dtDue().date().isValid()) {
                if (daysTo > 0) {
                    str = i18np("in 1 day", "in %1 days", daysTo);
                } else if (daysTo < 0) {
                    str = i18np("1 day ago", "%1 days ago", -daysTo);
                } else {
                    str = i18nc("the to-do is due", "due");
                }
            }
            label = new QLabel(str, this);
            label->setAlignment(Qt::AlignLeft | Qt::AlignVCenter);
            mLayout->addWidget(label, counter, 2);
            mLabels.append(label);

            // Priority label
            str = QLatin1Char('[') + QString::number(todo->priority()) + QLatin1Char(']');
            label = new QLabel(str, this);
            label->setAlignment(Qt::AlignRight | Qt::AlignVCenter);
            mLayout->addWidget(label, counter, 3);
            mLabels.append(label);

            // Summary label
            str = todo->summary();
            if (!todo->relatedTo().isEmpty()) { // show parent only, not entire ancestry
                KCalendarCore::Incidence::Ptr inc = mCalendar->incidence(todo->relatedTo());
                if (inc) {
                    str = inc->summary() + QLatin1Char(':') + str;
                }
            }
            if (!Qt::mightBeRichText(str)) {
                str = str.toHtmlEscaped();
            }

            auto urlLabel = new KUrlLabel(this);
            urlLabel->setText(str);
            urlLabel->setUrl(todo->uid());
            urlLabel->installEventFilter(this);
            urlLabel->setTextFormat(Qt::RichText);
            urlLabel->setWordWrap(true);
            mLayout->addWidget(urlLabel, counter, 4);
            mLabels.append(urlLabel);
            connect(urlLabel, &KUrlLabel::leftClickedUrl, this, [this, urlLabel] {
                viewTodo(urlLabel->url());
            });
            connect(urlLabel, &KUrlLabel::rightClickedUrl, this, [this, urlLabel] {
                popupMenu(urlLabel->url());
            });
            // State text label
            str = stateStr(todo);
            label = new QLabel(str, this);
            label->setAlignment(Qt::AlignLeft | Qt::AlignVCenter);
            mLayout->addWidget(label, counter, 5);
            mLabels.append(label);

            counter++;
        }
```

#### AUTO 


```{c}
auto *bodyMessage = new KMime::Content;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &regionStr : regions) {
        auto *region = new KHolidays::HolidayRegion(regionStr);
        if (region->isValid()) {
            mHolidayRegions.append(region);
        } else {
            delete region;
        }
    }
```

#### AUTO 


```{c}
auto createnote = menu.findChild<QAction *>(QStringLiteral("createnote"));
```

#### AUTO 


```{c}
auto *item = static_cast<ReminderTreeItem *>(*it);
```

#### AUTO 


```{c}
auto *eventViewer = new KOEventViewerDialog(mCalendar.data(), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &regionCode : regions) {
            const QString name = KHolidays::HolidayRegion::name(regionCode);
            const QLocale locale(KHolidays::HolidayRegion::languageCode(regionCode));
            const QString languageName = QLocale::languageToString(locale.language());
            QString label;
            if (languageName.isEmpty()) {
                label = name;
            } else {
                label = i18nc("@item:inlistbox Holiday region, region language", "%1 (%2)",
                              name, languageName);
            }
            const auto desc = KHolidays::HolidayRegion::description(regionCode);
            if (!desc.isEmpty()) {
                label = i18nc("@item:inlistbox holiday region, region description", "%1 - %2", label, desc);
            }
            regionsMap.push_back(std::make_pair(label, regionCode));
        }
```

#### AUTO 


```{c}
auto *noTodos = new QLabel(
            i18np("No pending to-dos due within the next day",
                  "No pending to-dos due within the next %1 days",
                  mDaysToGo), this);
```

#### AUTO 


```{c}
auto *manageAccountWidget = new Akonadi::ManageAccountWidget(this);
```

#### AUTO 


```{c}
auto suspendBoxHBoxLayout = new QHBoxLayout(suspendBox);
```

#### AUTO 


```{c}
auto cfgGroup = config->group("ListView Layout");
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : selectedViewIncidences) {
            if (item.hasPayload<KCalendarCore::Incidence::Ptr>()) {
                selectedIncidences.append(item.payload<KCalendarCore::Incidence::Ptr>());
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=](const QDateTime &s, const QDateTime &e){mMainView->newEvent(s, e, false);}
```

#### RANGE FOR STATEMENT 


```{c}
for (QLabel *label : std::as_const(mLabels)) {
        label->show();
    }
```

#### AUTO 


```{c}
auto *monitor = new Akonadi::ChangeRecorder(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (Action action : lstActions) {
            if (action != Total) {
                QStyleOptionButton buttonOption = buttonOpt(opt, mPixmap.value(action), index, i);
                s->drawControl(QStyle::CE_PushButton, &buttonOption, painter, nullptr);
            } else {
                QStyleOptionButton buttonOption = buttonOpt(opt, QPixmap(), index, i);
                buttonOption.features = QStyleOptionButton::Flat;
                buttonOption.rect.setHeight(buttonOption.rect.height() + 4);
                if (col.statistics().count() > 0) {
                    buttonOption.text = QString::number(col.statistics().count());
                }
                s->drawControl(QStyle::CE_PushButton, &buttonOption, painter, nullptr);
            }
            i++;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (KColorButton *colorButton : std::as_const(mButtonsDisable)) {
        if (useSystemColor) {
            colorButton->setEnabled(false);
        } else {
            colorButton->setEnabled(true);
        }
    }
```

#### AUTO 


```{c}
auto w = new KPrefsWidString(item, parent, KLineEdit::Normal);
```

#### AUTO 


```{c}
auto *bodyDisposition = new KMime::Headers::ContentDisposition;
```

#### AUTO 


```{c}
auto topBox = new QWidget(this);
```

#### AUTO 


```{c}
auto *boolItem
        = dynamic_cast<KConfigSkeleton::ItemBool *>(item);
```

#### AUTO 


```{c}
auto *attachDisposition
                = new KMime::Headers::ContentDisposition;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : indexes) {
        if (index.isValid()) {
            const Akonadi::Collection collection = index.data(
                Akonadi::EntityTreeModel::CollectionRole).value<Akonadi::Collection>();
            if (collection.isValid()) {
                collections << collection;
            }
        }
    }
```

#### AUTO 


```{c}
auto *cview = new AkonadiCollectionView(nullptr, false, q);
```

#### AUTO 


```{c}
auto korg = new KOrganizer();
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalCore::Event::Ptr &event : events) {
        Q_ASSERT(event);
        const KCalCore::Attendee::List attendees = event->attendees();
        if (!attendees.isEmpty()) {
            Akonadi::ContactSearchJob *job = new Akonadi::ContactSearchJob(this);
            job->setQuery(Akonadi::ContactSearchJob::Email, event->organizer()->email());
            job->setProperty("incidenceUid", event->uid());
            connect(job, &Akonadi::ContactSearchJob::result, this, &HtmlExportJob::receivedOrganizerInfo);
            job->start();

            d->mSubJobCount++;
            canExportItem = true;
        }
    }
```

#### AUTO 


```{c}
auto *job = new Akonadi::CollectionDeleteJob(collection, this);
```

#### AUTO 


```{c}
auto attr = collection.attribute<BlockAlarmsAttribute>(Collection::AddIfMissing);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &url : argList) {
                importURL(QUrl::fromUserInput(url), /*merge=*/ true);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &descendant : list) {
        for (const Node::Ptr &proxyNode : qAsConst(mProxyNodes)) {
            if (proxyNode->isDuplicateOf(descendant)) {
                //Removenode from proxy
                if (!proxyNode->parent) {
                    qCWarning(KORGANIZER_LOG) <<  objectName()
                                              <<
                        "Found proxy that is already not part of the model " << proxyNode->data(
                        Qt::DisplayRole).toString();
                    continue;
                }
                const int targetRow = proxyNode->row();
                beginRemoveRows(index(proxyNode->parent), targetRow, targetRow);
                proxyNode->parent->children.remove(targetRow);
                proxyNode->parent = nullptr;
                endRemoveRows();
            }
        }
    }
```

#### AUTO 


```{c}
const auto incidence = Akonadi::CalendarUtils::incidence(item);
```

#### AUTO 


```{c}
auto topLayout = new QVBoxLayout(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Todo::Ptr &todo : alltodos) {
                Q_ASSERT(todo);
                if ((!todo->hasStartDate() && !todo->hasDueDate()) // undated
                    || (todo->hasStartDate() && (todo->dtStart().toLocalTime().date() >= startDt)
                        && (todo->dtStart().toLocalTime().date() <= endDt)) // start dt in range
                    || (todo->hasDueDate() && (todo->dtDue().toLocalTime().date() >= startDt)
                        && (todo->dtDue().toLocalTime().date() <= endDt)) // due dt in range
                    || (todo->hasCompletedDate() && (todo->completed().toLocalTime().date() >= startDt)
                        && (todo->completed().toLocalTime().date() <= endDt))) { // completed dt in range
                    todos.append(todo);
                }
            }
```

#### AUTO 


```{c}
auto *label = new QLabel(
        i18nc("@label",
              "Reminders: "
              "Clicking on the title toggles details for item"),
        topBox);
```

#### AUTO 


```{c}
auto *collectionSelection
        = new CalendarSupport::CollectionSelection(selectionModel);
```

#### LAMBDA EXPRESSION 


```{c}
[=](const Akonadi::Item &i){mMainView->deleteIncidence(i, false);}
```

#### AUTO 


```{c}
auto job = new Akonadi::CollectionModifyJob(col, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (KOrg::Part *part : std::as_const(mParts)) {
        if (part) {
            dlg.addCollection(part->actionCollection(), part->shortInfo());
        }
    }
```

#### AUTO 


```{c}
auto aTransportLabel = new QLabel(i18nc("@label", "Mail transport:"), topFrame);
```

#### AUTO 


```{c}
const auto eventEnd = event->dtEnd().toLocalTime();
```

#### AUTO 


```{c}
auto *item = static_cast<PageItem *>(*it);
```

#### RANGE FOR STATEMENT 


```{c}
for (KOrg::BaseView *const baseView : std::as_const(mViews)) {
        KConfigGroup group = KSharedConfig::openConfig()->group(baseView->identifier());
        baseView->saveConfig(group);
    }
```

#### AUTO 


```{c}
auto remindersLayout = new QGridLayout(remindersGroupBox);
```

#### AUTO 


```{c}
auto ctrlLayout = new QHBoxLayout(this);
```

#### AUTO 


```{c}
const auto &plugin
```

#### AUTO 


```{c}
auto *tmw
        = new MailTransport::TransportManagementWidget(topFrame);
```

#### AUTO 


```{c}
auto otherLayout = new QVBoxLayout;
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *it : list) {
                if (allowedTypes.contains(QLatin1String(it->metaObject()->className()))) {
                    const QString name = it->objectName();
                    if (name.startsWith(QLatin1String("X_"))) {
                        new QTreeWidgetItem(this, QStringList()
                                            << name
                                            << allowedTypes[ QLatin1String(it->metaObject()->
                                                                           className()) ]
                                            << QLatin1String(it->metaObject()->className())
                                            << it->whatsThis());
                    }
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Collection &checkedCollection : collections) {
        supportsMimeType
            = checkedCollection.contentMimeTypes().contains(mimeType) || mimeType == QLatin1String("");
        hasRights = checkedCollection.rights() & Akonadi::Collection::CanCreateItem;
        if (checkedCollection.isValid() && supportsMimeType && hasRights) {
            return checkedCollection;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &regionCode : regions) {
            const QString name = KHolidays::HolidayRegion::name(regionCode);
            const QLocale locale(KHolidays::HolidayRegion::languageCode(regionCode));
            const QString languageName = QLocale::languageToString(locale.language());
            QString label;
            if (languageName.isEmpty()) {
                label = name;
            } else {
                label = i18nc("@item:inlistbox Holiday region, region language", "%1 (%2)",
                              name, languageName);
            }
            regionsMap.push_back(std::make_pair(label, regionCode));
        }
```

#### AUTO 


```{c}
auto *bJob = qobject_cast<BirthdaySearchJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const ReparentingModel::Node::Ptr &existing : qAsConst(mProxyNodes)) {
        if (*existing == *node) {
            // qCDebug(KORGANIZER_LOG) << "node is already existing";
            return;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalCore::Event::Ptr &ev : events) {
            // Optionally, show only my Events
            /* if ( mShowMineOnly &&
                    !KCalCore::CalHelper::isMyCalendarIncidence( mCalendarAdaptor, ev. ) ) {
              // FIXME; does isMyCalendarIncidence work !? It's deprecated too.
              continue;
              }
              // TODO: CalHelper is deprecated, remove this?
              */

            if (ev->customProperty("KABC", "BIRTHDAY") == QLatin1String("YES")) {
                // Skipping, because these are got by the BirthdaySearchJob
                // See comments in updateView()
                continue;
            }

            if (!ev->categoriesStr().isEmpty()) {
                QStringList::ConstIterator it2;
                const QStringList c = ev->categories();
                QStringList::ConstIterator end(c.constEnd());
                for (it2 = c.constBegin(); it2 != end; ++it2) {
                    const QString itUpper((*it2).toUpper());
                    // Append Birthday Event?
                    if (mShowBirthdaysFromCal && (itUpper == QLatin1String("BIRTHDAY"))) {
                        SDEntry entry;
                        entry.type = IncidenceTypeEvent;
                        entry.category = CategoryBirthday;
                        entry.date = dt;
                        entry.summary = ev->summary();
                        entry.desc = ev->description();
                        dateDiff(ev->dtStart().date(), entry.daysTo, entry.yearsOld);
                        entry.span = 1;

                        /* The following check is to prevent duplicate entries,
                         * so in case of having a KCal incidence with category birthday
                         * with summary and date equal to some KABC Attendee we don't show it
                         * FIXME: port to akonadi, it's kresource based
                         * */
                        if (/*!check( bdayRes, dt, ev->summary() )*/ true) {
                            mDates.append(entry);
                        }
                        break;
                    }

                    // Append Anniversary Event?
                    if (mShowAnniversariesFromCal && (itUpper == QStringLiteral("ANNIVERSARY"))) {
                        SDEntry entry;
                        entry.type = IncidenceTypeEvent;
                        entry.category = CategoryAnniversary;
                        entry.date = dt;
                        entry.summary = ev->summary();
                        entry.desc = ev->description();
                        dateDiff(ev->dtStart().date(), entry.daysTo, entry.yearsOld);
                        entry.span = 1;
                        if (/*!check( annvRes, dt, ev->summary() )*/ true) {
                            mDates.append(entry);
                        }
                        break;
                    }

                    // Append Holiday Event?
                    if (mShowHolidays && (itUpper == QLatin1String("HOLIDAY"))) {
                        SDEntry entry;
                        entry.type = IncidenceTypeEvent;
                        entry.category = CategoryHoliday;
                        entry.date = dt;
                        entry.summary = ev->summary();
                        entry.desc = ev->description();
                        dateDiff(dt, entry.daysTo, entry.yearsOld);
                        entry.yearsOld = -1; //ignore age of holidays
                        entry.span = span(ev);
                        if (entry.span > 1 && dayof(ev, dt) > 1) {     // skip days 2,3,...
                            break;
                        }
                        mDates.append(entry);
                        break;
                    }

                    // Append Special Occasion Event?
                    if (mShowSpecialsFromCal && (itUpper == QLatin1String("SPECIAL OCCASION"))) {
                        SDEntry entry;
                        entry.type = IncidenceTypeEvent;
                        entry.category = CategoryOther;
                        entry.date = dt;
                        entry.summary = ev->summary();
                        entry.desc = ev->description();
                        dateDiff(dt, entry.daysTo, entry.yearsOld);
                        entry.yearsOld = -1; //ignore age of special occasions
                        entry.span = span(ev);
                        if (entry.span > 1 && dayof(ev, dt) > 1) {     // skip days 2,3,...
                            break;
                        }
                        mDates.append(entry);
                        break;
                    }
                }
            }
        }
```

#### AUTO 


```{c}
auto *job = new Akonadi::CollectionModifyJob(col, this);
```

#### AUTO 


```{c}
auto datenavLayout = new QVBoxLayout;
```

#### AUTO 


```{c}
auto *buttonBox = new QDialogButtonBox(
        QDialogButtonBox::Ok | QDialogButtonBox::Cancel | QDialogButtonBox::Apply, this);
```

#### AUTO 


```{c}
auto buttonBox = new QDialogButtonBox(
        QDialogButtonBox::Ok | QDialogButtonBox::Cancel, this);
```

#### AUTO 


```{c}
auto *w = new KPrefsWidDuration(item, format, parent);
```

#### AUTO 


```{c}
auto *job
        = new PimCommon::ManageServerSideSubscriptionJob(this);
```

#### AUTO 


```{c}
auto *sync = qobject_cast<Akonadi::CollectionAttributesSynchronizationJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalCore::Incidence::Ptr &inc : incidences) {
        Q_ASSERT(inc);
        QDate d = inc->dtStart().toTimeSpec(mCalendar->timeSpec()).date();
        if (inc->type() == KCalCore::Incidence::TypeJournal &&
                d >= mDays[0] &&
                d <= mDays[NUMDAYS - 1] &&
                !mEvents.contains(d)) {
            mEvents.append(d);
        }
        if (mEvents.count() == NUMDAYS) {
            // No point in wasting cpu, all days are bold already
            break;
        }
    }
```

#### AUTO 


```{c}
const auto eventEnd = ev->dtEnd().toLocalZone().dateTime();
```

#### RANGE FOR STATEMENT 


```{c}
for (SummaryEventInfo *event : events) {
        // Optionally, show only my Events
        /*      if ( mShowMineOnly &&
                  !KCalendarCore::CalHelper::isMyCalendarIncidence( mCalendarAdaptor, event->ev ) ) {
              continue;
            }
            TODO: CalHelper is deprecated, remove this?
        */

        KCalendarCore::Event::Ptr ev = event->ev;
        // print the first of the recurring event series only
        if (ev->recurs()) {
            if (uidList.contains(ev->instanceIdentifier())) {
                continue;
            }
            uidList.append(ev->instanceIdentifier());
        }

        // Icon label
        label = new QLabel(this);
        if (ev->categories().contains(QLatin1String("BIRTHDAY"), Qt::CaseInsensitive)) {
            label->setPixmap(pmb);
        } else if (ev->categories().contains(QLatin1String("ANNIVERSARY"), Qt::CaseInsensitive)) {
            label->setPixmap(pma);
        } else {
            label->setPixmap(pm);
        }
        label->setMaximumWidth(label->minimumSizeHint().width());
        mLayout->addWidget(label, counter, 0);
        mLabels.append(label);

        // Start date or date span label
        QString dateToDisplay = event->startDate;
        if (!event->dateSpan.isEmpty()) {
            dateToDisplay = event->dateSpan;
        }
        label = new QLabel(dateToDisplay, this);
        label->setAlignment(Qt::AlignLeft | Qt::AlignVCenter);
        mLayout->addWidget(label, counter, 1);
        mLabels.append(label);
        if (event->makeBold) {
            QFont font = label->font();
            font.setBold(true);
            label->setFont(font);
            if (!event->makeUrgent) {
                label->setPalette(todayPalette);
            } else {
                label->setPalette(urgentPalette);
            }
            label->setAutoFillBackground(true);
        }

        // Days to go label
        label = new QLabel(event->daysToGo, this);
        label->setAlignment(Qt::AlignLeft | Qt::AlignVCenter);
        mLayout->addWidget(label, counter, 2);
        mLabels.append(label);

        // Summary label
        auto urlLabel = new KUrlLabel(this);
        urlLabel->setText(event->summaryText);
        urlLabel->setUrl(event->summaryUrl);
        urlLabel->installEventFilter(this);
        urlLabel->setTextFormat(Qt::RichText);
        urlLabel->setWordWrap(true);
        mLayout->addWidget(urlLabel, counter, 3);
        mLabels.append(urlLabel);
        connect(urlLabel, &KUrlLabel::leftClickedUrl, this, [this, urlLabel] {
            viewEvent(urlLabel->url());
        });
        connect(urlLabel, &KUrlLabel::rightClickedUrl, this, [this, urlLabel] {
            popupMenu(urlLabel->url());
        });
        if (!event->summaryTooltip.isEmpty()) {
            urlLabel->setToolTip(event->summaryTooltip);
        }

        // Time range label (only for non-floating events)
        if (!event->timeRange.isEmpty()) {
            label = new QLabel(event->timeRange, this);
            label->setAlignment(Qt::AlignLeft | Qt::AlignVCenter);
            mLayout->addWidget(label, counter, 4);
            mLabels.append(label);
        }

        counter++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalCore::Todo::Ptr &todo : alltodos) {
                Q_ASSERT(todo);
                if ((!todo->hasStartDate() && !todo->hasDueDate()) ||    // undated
                        (todo->hasStartDate() &&
                         (todo->dtStart().toTimeSpec(spec).date() >= startDt) &&
                         (todo->dtStart().toTimeSpec(spec).date() <= endDt)) ||      //start dt in range
                        (todo->hasDueDate() &&
                         (todo->dtDue().toTimeSpec(spec).date() >= startDt) &&
                         (todo->dtDue().toTimeSpec(spec).date() <= endDt)) ||      //due dt in range
                        (todo->hasCompletedDate() &&
                         (todo->completed().toTimeSpec(spec).date() >= startDt) &&
                         (todo->completed().toTimeSpec(spec).date() <= endDt))) {      //completed dt in range
                    todos.append(todo);
                }
            }
```

#### AUTO 


```{c}
auto holidaysLayout = new QGridLayout(holidaysGroupBox);
```

#### AUTO 


```{c}
auto *tmw = new MailTransport::TransportManagementWidget(topFrame);
```

#### AUTO 


```{c}
auto mail = item.payload<KMime::Message::Ptr>();
```

#### RANGE FOR STATEMENT 


```{c}
for (KCalendarCore::CalFilter *filter : qAsConst(mFilters)) {
        if (filter) {
            filters << filter->name();
        }
    }
```

#### AUTO 


```{c}
auto *editor
        = menu.findChild<IncidenceEditorNG::IncidenceEditor *>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalCore::Todo::Ptr &t : incidences) {
        if (mEvents.count() == NUMDAYS) {
            // No point in wasting cpu, all days are bold already
            break;
        }
        Q_ASSERT(t);
        if (t->hasDueDate()) {
            ushort recurType = t->recurrenceType();

            if (t->recurs() &&
                    !(recurType == KCalCore::Recurrence::rDaily && !KOPrefs::instance()->mDailyRecur) &&
                    !(recurType == KCalCore::Recurrence::rWeekly && !KOPrefs::instance()->mWeeklyRecur)) {

                // It's a recurring todo, find out in which days it occurs
                const auto timeDateList =
                    t->recurrence()->timesInInterval(
                        QDateTime(mDays[0], {}, Qt::LocalTime),
                        QDateTime(mDays[NUMDAYS - 1], {}, Qt::LocalTime));

                for (const QDateTime &dt : timeDateList) {
                    d = dt.toLocalTime().date();
                    if (!mEvents.contains(d)) {
                        mEvents.append(d);
                    }
                }

            } else {
                d = t->dtDue().toLocalTime().date();
                if (d >= mDays[0] && d <= mDays[NUMDAYS - 1] && !mEvents.contains(d)) {
                    mEvents.append(d);
                }
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString email : lstEmails) {
        if (!email.isEmpty()) {
            query.addTerm(Akonadi::IncidenceSearchTerm(Akonadi::IncidenceSearchTerm::PartStatus, QString(email + QString::number(status))));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KDateNavigator *n : qAsConst(mExtraViews)) {
        if (n) {
            n->updateConfig();
        }
    }
```

#### AUTO 


```{c}
auto *label = new QLabel(i18nc("@label:textbox Name of the folder.", "&Name:"), this);
```

#### AUTO 


```{c}
auto tabWidget = new QTabWidget(this);
```

#### AUTO 


```{c}
const auto dateTime = triggerDateForIncidence(incidence, item->mRemindAt, displayStr);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &instance : mCalendar->instances(inc)) {
        KCalendarCore::Incidence::Ptr oldInstance(instance->clone());
        instance->setRelatedTo(QString());
        (void)mChanger->modifyIncidence(mCalendar->item(instance), oldInstance, this);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &url : argList) {
                importURL(QUrl::fromUserInput(url), /*merge=*/true);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &mimetype : allMimeTypes) {
            monitor->setMimeTypeMonitored(mimetype, true);
        }
```

#### AUTO 


```{c}
auto fetchJob = static_cast<Akonadi::CollectionFetchJob *>(job);
```

#### AUTO 


```{c}
const auto eventStart = event->dtStart().toLocalTime();
```

#### AUTO 


```{c}
const auto items = bJob->items();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &e : changedEntries) {
            qCDebug(KORGANIZER_LOG) << " downloadNewStuff :";
            const QStringList lstFile = e.installedFiles();
            if (lstFile.count() != 1) {
                continue;
            }
            const QString file = lstFile.at(0);
            const QUrl filename = QUrl::fromLocalFile(file);
            qCDebug(KORGANIZER_LOG) << "filename :" << filename;
            if (!filename.isValid()) {
                continue;
            }

            KCalendarCore::FileStorage storage(calendar());
            storage.setFileName(file);
            storage.setSaveFormat(new KCalendarCore::ICalFormat);
            if (!storage.load()) {
                KMessageBox::error(mCalendarView, i18n("Could not load calendar %1.", file));
            } else {
                QStringList eventSummaries;
                const KCalendarCore::Event::List events = calendar()->events();
                eventSummaries.reserve(events.count());
                for (const KCalendarCore::Event::Ptr &event : events) {
                    eventSummaries.append(event->summary());
                }

                const int result = KMessageBox::warningContinueCancelList(mCalendarView,
                                                                          i18n("The downloaded events will be merged into your current calendar."),
                                                                          eventSummaries);

                if (result != KMessageBox::Continue) {
                    // FIXME (KNS2): hm, no way out here :-)
                }

                if (importURL(QUrl::fromLocalFile(file), true)) {
                    // FIXME (KNS2): here neither
                }
            }
        }
```

#### AUTO 


```{c}
auto *layout = new QHBoxLayout(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto instance : mCalendar->instances(incidence)) {
                (void) mChanger->deleteIncidence(mCalendar->item(instance), this);
            }
```

#### AUTO 


```{c}
auto stringItem = dynamic_cast<KConfigSkeleton::ItemString *>(item);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : indexes) {
        if (index.isValid()) {
            const auto collection = index.data(Akonadi::EntityTreeModel::CollectionRole).value<Akonadi::Collection>();
            if (collection.isValid()) {
                collections << collection;
            }
        }
    }
```

#### AUTO 


```{c}
auto msg = new KMime::Message();
```

#### LAMBDA EXPRESSION 


```{c}
[this, url](KJob *job) {
                        if (job->error()) {
                            return;
                        }
                        auto fetchJob = qobject_cast<Akonadi::ItemFetchJob *>(job);
                        const Akonadi::Item::List items = fetchJob->items();
                        for (const Akonadi::Item &item : items) {
                            if (item.mimeType() == QStringLiteral("message/rfc822")) {
                                auto mail = item.payload<KMime::Message::Ptr>();
                                interface()->openEventEditor(i18nc("Event from email summary", "Mail: %1", mail->subject()->asUnicodeString()),
                                                             i18nc("Event from email content",
                                                                   "<b>From:</b> %1<br /><b>To:</b> %2<br /><b>Subject:</b> %3",
                                                                   mail->from()->displayString(),
                                                                   mail->to()->displayString(),
                                                                   mail->subject()->asUnicodeString()),
                                                             url.toDisplayString(),
                                                             QString(),
                                                             QStringList(),
                                                             QStringLiteral("message/rfc822"));
                            }
                        }
                    }
```

#### AUTO 


```{c}
auto *dlg = menu.findChild<IncidenceEditorNG::IncidenceDialog *>(QStringLiteral("incidencedialog"));
```

#### AUTO 


```{c}
auto item = static_cast<PluginItem *>(serviceTypeGroup->child(j));
```

#### AUTO 


```{c}
auto about = new KAboutData(QStringLiteral("kcmtodosummary"),
                                i18n("Pending To-dos Configuration Dialog"),
                                QString(),
                                QString(),
                                KAboutLicense::GPL,
                                i18n("Copyright � 2003�2004 Tobias Koenig\n"
                                     "Copyright � 2005�2010 Allen Winter"));
```

#### AUTO 


```{c}
const auto eventStart = ev->dtStart().toLocalZone().dateTime();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &email : splittedEmail) {
        const QString str
            = KEmailAddress::extractEmailAddress(KEmailAddress::normalizeAddressesAndEncodeIdn(email));
        normalizedEmail << str;
    }
```

#### AUTO 


```{c}
auto t = timeDateList.begin();
```

#### AUTO 


```{c}
auto noTodos = new QLabel(
            i18np("No pending to-dos due within the next day",
                  "No pending to-dos due within the next %1 days",
                  mDaysToGo), this);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const KCalendarCore::DateList &dates) { mDateNavigator->selectDates(dates); }
```

#### AUTO 


```{c}
auto *searchProxy = new ReparentingModel(this);
```

#### AUTO 


```{c}
auto hourSizeLayout = new QHBoxLayout;
```

#### AUTO 


```{c}
auto etm = qobject_cast<Akonadi::EntityTreeModel *>(proxy->sourceModel());
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPIM::Person &p : persons) {
        PersonNode *personNode = new PersonNode(*mSearchModel, p);
        personNode->isSearchNode = true;
        //toggled by the checkbox, results in person getting added to main model
        // connect(&personNode->emitter, SIGNAL(enabled(bool,Person)), this, SLOT(onPersonEnabled(bool,Person)));
        mSearchModel->addNode(ReparentingModel::Node::Ptr(personNode));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Node *n : std::as_const(mSourceNodes)) {
        // qCDebug(KORGANIZER_LOG) << index << index.data().toString();
        if (proxyNode->isDuplicateOf(n->sourceIndex)) {
            return true;
        }
    }
```

#### AUTO 


```{c}
auto layout = new QVBoxLayout;
```

#### AUTO 


```{c}
auto node = new DummyNode(reparentingModel, QStringLiteral("col1"));
```

#### AUTO 


```{c}
auto buttonBox = new QDialogButtonBox(
        QDialogButtonBox::Ok | QDialogButtonBox::Cancel | QDialogButtonBox::Apply, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &conf : oldFilterList) {
        KConfigGroup group = config->group(conf);
        group.deleteGroup();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KHolidays::Holiday &holiday : holidays) {
            exportJob->addHoliday(holiday.observedStartDate(), holiday.name());
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=](){mDateNavigator->selectPreviousMonth();}
```

#### AUTO 


```{c}
auto searchProxy = new ReparentingModel(this);
```

#### AUTO 


```{c}
auto *remindersLayout = new QGridLayout(remindersGroupBox);
```

#### RANGE FOR STATEMENT 


```{c}
for (BaseView *view : std::as_const(mViews)) {
        if (view) {
            view->setChanges(view->changes() | change);
        }
    }
```

#### AUTO 


```{c}
auto *adisplayLayout = new QVBoxLayout;
```

#### AUTO 


```{c}
const auto eventStart = event->dtStart().toLocalZone().dateTime();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &c : childItems) {
            deleteIncidenceFamily(c);
        }
```

#### AUTO 


```{c}
auto createnoteforevent = menu.findChild<QAction *>(QStringLiteral("createnoteforevent"));
```

#### RANGE FOR STATEMENT 


```{c}
for (KCalendarCore::CalFilter *filter : std::as_const(mFilters)) {
        if (filter) {
            filters << filter->name();
        }
    }
```

#### AUTO 


```{c}
auto item = new QStandardItem;
```

#### LAMBDA EXPRESSION 


```{c}
[=](bool){mCalendarView->schedule_forward();}
```

#### AUTO 


```{c}
auto *boxLayout = new QVBoxLayout(box);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalCore::Event::Ptr &event : eventlist) {
        if (mEvents.count() == NUMDAYS) {
            // No point in wasting cpu, all days are bold already
            break;
        }

        Q_ASSERT(event);
        const ushort recurType = event->recurrenceType();
        const QDateTime dtStart = event->dtStart().toLocalTime();

        // timed incidences occur in
        //   [dtStart(), dtEnd()[. All-day incidences occur in [dtStart(), dtEnd()]
        // so we subtract 1 second in the timed case
        const int secsToAdd = event->allDay() ? 0 : -1;
        const QDateTime dtEnd = event->dtEnd().toLocalTime().addSecs(secsToAdd);

        if (!(recurType == KCalCore::Recurrence::rDaily
              && !KOPrefs::instance()->mDailyRecur)
            && !(recurType == KCalCore::Recurrence::rWeekly
                 && !KOPrefs::instance()->mWeeklyRecur)) {
            KCalCore::DateTimeList timeDateList;
            const bool isRecurrent = event->recurs();
            const int eventDuration = dtStart.daysTo(dtEnd);

            if (isRecurrent) {
                //Its a recurring event, find out in which days it occurs
                timeDateList = event->recurrence()->timesInInterval(
                    QDateTime(mDays[0], {}, Qt::LocalTime),
                    QDateTime(mDays[NUMDAYS - 1], {}, Qt::LocalTime));
            } else {
                if (dtStart.date() >= mDays[0]) {
                    timeDateList.append(dtStart);
                } else {
                    // The event starts in another month (not visible))
                    timeDateList.append(QDateTime(mDays[0], {}, Qt::LocalTime));
                }
            }

            for (auto t = timeDateList.begin(); t != timeDateList.end(); ++t) {
                //This could be a multiday event, so iterate from dtStart() to dtEnd()
                QDate d = t->toLocalTime().date();
                int j = 0;

                QDate occurrenceEnd;
                if (isRecurrent) {
                    occurrenceEnd = d.addDays(eventDuration);
                } else {
                    occurrenceEnd = dtEnd.date();
                }

                do {
                    mEvents.append(d);
                    ++j;
                    d = d.addDays(1);
                } while (d <= occurrenceEnd && j < NUMDAYS);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Akonadi::StandardCalendarActionManager::Type calendarAction : std::as_const(calendarActions)) {
            mActionManager->createAction(calendarAction);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Collection &col : lstCols) {
            if (col.name() == QLatin1String("OpenInvitations")) {
                mOpenInvitationCollection = col;
            } else if (col.name() == QLatin1String("DeclinedInvitations")) {
                mDeclineCollection = col;
            }
        }
```

#### AUTO 


```{c}
auto *buttonBox = new QDialogButtonBox(QDialogButtonBox::Close, this);
```

#### AUTO 


```{c}
auto createjob = static_cast<Akonadi::AgentInstanceCreateJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : subIncs) {
        incidence_unsub(item);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &regionStr : regions) {
        KHolidays::HolidayRegion *region = new KHolidays::HolidayRegion(regionStr);
        if (region->isValid()) {
            mHolidayRegions.append(region);
        } else {
            delete region;
        }
    }
```

#### AUTO 


```{c}
auto buttonBox = new QDialogButtonBox(this);
```

#### AUTO 


```{c}
auto *attachMessage = new KMime::Content;
```

#### AUTO 


```{c}
auto pluginFactory = static_cast<KOrg::PartFactory *>(factory);
```

#### AUTO 


```{c}
const auto instance
```

#### AUTO 


```{c}
auto *createJob = new Akonadi::ItemCreateJob(noteItem, collection, this);
```

#### LAMBDA EXPRESSION 


```{c}
[this, player](QMediaPlayer::State state) {
                    if (state == QMediaPlayer::StoppedState) {
                        player->deleteLater();
                    }
                }
```

#### AUTO 


```{c}
auto w = new KPrefsWidRadios(item, parent);
```

#### AUTO 


```{c}
auto widget = new QWidget;
```

#### AUTO 


```{c}
auto pluginFactory = qobject_cast<CalendarSupport::PluginFactory *>(factory);
```

#### AUTO 


```{c}
auto *attr
        = collection.attribute<BlockAlarmsAttribute>(Collection::AddIfMissing);
```

#### AUTO 


```{c}
auto monitor = new Akonadi::ChangeRecorder(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalCore::Todo::Ptr &t : incidences) {
        if (mEvents.count() == NUMDAYS) {
            // No point in wasting cpu, all days are bold already
            break;
        }
        Q_ASSERT(t);
        if (t->hasDueDate()) {
            ushort recurType = t->recurrenceType();

            if (t->recurs()
                && !(recurType == KCalCore::Recurrence::rDaily && !KOPrefs::instance()->mDailyRecur)
                && !(recurType == KCalCore::Recurrence::rWeekly
                     && !KOPrefs::instance()->mWeeklyRecur)) {
                // It's a recurring todo, find out in which days it occurs
                const auto timeDateList
                    = t->recurrence()->timesInInterval(
                    QDateTime(mDays[0], {}, Qt::LocalTime),
                    QDateTime(mDays[NUMDAYS - 1], {}, Qt::LocalTime));

                for (const QDateTime &dt : timeDateList) {
                    d = dt.toLocalTime().date();
                    if (!mEvents.contains(d)) {
                        mEvents.append(d);
                    }
                }
            } else {
                d = t->dtDue().toLocalTime().date();
                if (d >= mDays[0] && d <= mDays[NUMDAYS - 1] && !mEvents.contains(d)) {
                    mEvents.append(d);
                }
            }
        }
    }
```

#### AUTO 


```{c}
auto row1 = new QStandardItem(QStringLiteral("row1"));
```

#### RANGE FOR STATEMENT 


```{c}
for (QLabel *label : std::as_const(mLabels)) {
        mLayout->removeWidget(label);
        delete (label);
        update();
    }
```

#### AUTO 


```{c}
auto w = new KPrefsWidPath(item, parent, filter, mode);
```

#### AUTO 


```{c}
auto *calendarDelegateModel = new CalendarDelegateModel(this);
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        mDateNavigator->selectPreviousMonth();
    }
```

#### AUTO 


```{c}
auto *attachDisposition = new KMime::Headers::ContentDisposition;
```

#### AUTO 


```{c}
auto *importer = qobject_cast<Akonadi::ICalImporter *>(sender());
```

#### LAMBDA EXPRESSION 


```{c}
[=](const QDate &d, int n){mMainView->dateNavigator()->selectDates(d, n, QDate());}
```

#### AUTO 


```{c}
auto job = new Akonadi::AgentInstanceCreateJob(agentType, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (KDateNavigator *n : std::as_const(mExtraViews)) {
        if (n) {
            n->updateToday();
        }
    }
```

#### AUTO 


```{c}
auto urlLabel = new KUrlLabel(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (KCalendarCore::CalFilter *i : qAsConst(*mFilters)) {
        if (i && i->name().isEmpty()) {
            allOk = false;
        }
    }
```

#### AUTO 


```{c}
auto act = new QAction(but);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : subTodos) {
        if (CalendarSupport::hasTodo(item)) {
            deleteSubTodosIncidence(item);
        }
    }
```

#### AUTO 


```{c}
auto *datenavLayout = new QVBoxLayout;
```

#### LAMBDA EXPRESSION 


```{c}
[=](bool){mCalendarView->schedule_reply();}
```

#### AUTO 


```{c}
auto editor = menu.findChild<IncidenceEditorNG::IncidenceEditor *>();
```

#### AUTO 


```{c}
auto *workStartLayout = new QHBoxLayout;
```

#### RANGE FOR STATEMENT 


```{c}
for (const KHolidays::HolidayRegion *region : qAsConst(mHolidayRegions)) {
            const KHolidays::Holiday::List list = region->holidays(startDate, endDate);
            for (int i = 0; i < list.count(); ++i) {
                const KHolidays::Holiday &h = list.at(i);
                if (h.dayType() == KHolidays::Holiday::NonWorkday) {
                    result.removeAll(h.observedStartDate());
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &url : lst) {
            korg->actionManager()->importCalendar(QUrl::fromUserInput(url));
        }
```

#### AUTO 


```{c}
auto *urlLabel = new KUrlLabel(this);
```

#### AUTO 


```{c}
auto *colorLayout = new QGridLayout(colorFrame);
```

#### AUTO 


```{c}
auto *personalLayout = new QVBoxLayout(personalFrame);
```

#### AUTO 


```{c}
auto box = new QGroupBox(i18n("Preview of Selected Page"), this);
```

#### AUTO 


```{c}
auto sortProxy = new QSortFilterProxyModel;
```

#### AUTO 


```{c}
auto newMsg = new KMime::Message();
```

#### AUTO 


```{c}
const auto *attr = col.attribute<Akonadi::CollectionIdentificationAttribute>();
```

#### AUTO 


```{c}
auto factory = loader.factory();
```

#### AUTO 


```{c}
auto workEndLayout = new QHBoxLayout;
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Collection &checkedCollection : collections) {
        supportsMimeType = checkedCollection.contentMimeTypes().contains(mimeType)
                           || mimeType == QLatin1String("");
        hasRights = checkedCollection.rights() & Akonadi::Collection::CanCreateItem;
        if (checkedCollection.isValid() && supportsMimeType && hasRights) {
            return checkedCollection;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KCalCore::CalFilter *i : qAsConst(*mFilters)) {
        if (i && i->name().isEmpty()) {
            allOk = false;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QEvent *e : std::as_const(mTypeAheadEvents)) {
            QApplication::sendEvent(mTypeAheadReceiver, e);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalCore::Todo::Ptr &t : incidences) {
        if (mEvents.count() == NUMDAYS) {
            // No point in wasting cpu, all days are bold already
            break;
        }
        Q_ASSERT(t);
        if (t->hasDueDate()) {
            ushort recurType = t->recurrenceType();

            if (t->recurs() &&
                    !(recurType == KCalCore::Recurrence::rDaily && !KOPrefs::instance()->mDailyRecur) &&
                    !(recurType == KCalCore::Recurrence::rWeekly && !KOPrefs::instance()->mWeeklyRecur)) {

                // It's a recurring todo, find out in which days it occurs
                KCalCore::DateTimeList timeDateList =
                    t->recurrence()->timesInInterval(
                        KDateTime(mDays[0], mCalendar->timeSpec()),
                        KDateTime(mDays[NUMDAYS - 1], mCalendar->timeSpec()));

                foreach (const KDateTime &dt, timeDateList) {
                    d = dt.toTimeSpec(mCalendar->timeSpec()).date();
                    if (!mEvents.contains(d)) {
                        mEvents.append(d);
                    }
                }

            } else {
                d = t->dtDue().toTimeSpec(mCalendar->timeSpec()).date();
                if (d >= mDays[0] && d <= mDays[NUMDAYS - 1] && !mEvents.contains(d)) {
                    mEvents.append(d);
                }
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KDateNavigator *n : qAsConst(mExtraViews)) {
        if (n) {
            n->updateToday();
        }
    }
```

#### AUTO 


```{c}
auto workStartLayout = new QHBoxLayout;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &email : lstEmails) {
        if (!email.isEmpty()) {
            query.addTerm(Akonadi::IncidenceSearchTerm(Akonadi::IncidenceSearchTerm::PartStatus, QString(email + QString::number(status))));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KDateNavigator *n : qAsConst(mExtraViews)) {
                if (n) {
                    n->show();
                }
            }
```

#### AUTO 


```{c}
auto noEvents =
            new QLabel(i18np("No upcoming events starting within the next day", "No upcoming events starting within the next %1 days", mDaysAhead), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &descendant : list) {
        for (const Node::Ptr &proxyNode : std::as_const(mProxyNodes)) {
            if (proxyNode->isDuplicateOf(descendant)) {
                // Removenode from proxy
                if (!proxyNode->parent) {
                    qCWarning(KORGANIZER_LOG) << objectName() << "Found proxy that is already not part of the model "
                                              << proxyNode->data(Qt::DisplayRole).toString();
                    continue;
                }
                const int targetRow = proxyNode->row();
                beginRemoveRows(index(proxyNode->parent), targetRow, targetRow);
                proxyNode->parent->children.remove(targetRow);
                proxyNode->parent = nullptr;
                endRemoveRows();
            }
        }
    }
```

#### AUTO 


```{c}
auto item = static_cast<ReminderTreeItem *>(*it);
```

#### AUTO 


```{c}
auto pageItem = static_cast<PageItem *>(item);
```

#### AUTO 


```{c}
auto *buttonBox = new QDialogButtonBox(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &email : lstEmails) {
        if (!email.isEmpty()) {
            query.addTerm(Akonadi::IncidenceSearchTerm(Akonadi::IncidenceSearchTerm::PartStatus,
                                                       QString(email + QString::number(status))));
        }
    }
```

#### AUTO 


```{c}
auto *region = new KHolidays::HolidayRegion(regionStr);
```

#### AUTO 


```{c}
auto createJob = new Akonadi::ItemCreateJob(noteItem, collection, this);
```

#### LAMBDA EXPRESSION 


```{c}
[=](const QDate &d, int n) {
                mMainView->dateNavigator()->selectDates(d, n, QDate());
            }
```

#### LAMBDA EXPRESSION 


```{c}
[=](bool) {
        mCalendarView->schedule_publish();
    }
```

#### AUTO 


```{c}
auto etm = qobject_cast<Akonadi::EntityTreeModel *>(
            proxy->sourceModel());
```

#### AUTO 


```{c}
auto *annotationsAttribute = collection.attribute<PimCommon::CollectionAnnotationsAttribute>(Collection::AddIfMissing);
```

#### LAMBDA EXPRESSION 


```{c}
[=](bool){mCalendarView->schedule_counter();}
```

#### AUTO 


```{c}
auto noteedit = menu.findChild<CalendarSupport::NoteEditDialog *>();
```

#### AUTO 


```{c}
auto importer = qobject_cast<Akonadi::ICalImporter *>(sender());
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *it : list) {
                if (allowedTypes.contains(QLatin1String(it->metaObject()->className()))) {
                    const QString name = it->objectName();
                    if (name.startsWith(QLatin1String("X_"))) {
                        new QTreeWidgetItem(this,
                                            QStringList() << name << allowedTypes[QLatin1String(it->metaObject()->className())]
                                                          << QLatin1String(it->metaObject()->className()) << it->whatsThis());
                    }
                }
            }
```

#### AUTO 


```{c}
auto menu = new QMenu(mMonth);
```

#### AUTO 


```{c}
auto holidayRegBoxHBoxLayout = new QHBoxLayout(holidayRegBox);
```

#### AUTO 


```{c}
const auto selected = listView->selectedIncidences();
```

#### AUTO 


```{c}
auto *delegate = new StyledCalendarDelegate(mCollectionView);
```

#### AUTO 


```{c}
auto defaultLayout = new QGridLayout(defaultPage);
```

#### AUTO 


```{c}
auto *job = new PimCommon::ManageServerSideSubscriptionJob(this);
```

#### AUTO 


```{c}
auto item = new QStandardItem(QStringLiteral("personfolder"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Todo::Ptr &todo : alltodos) {
                Q_ASSERT(todo);
                if ((!todo->hasStartDate() && !todo->hasDueDate())       // undated
                    || (todo->hasStartDate()
                        && (todo->dtStart().toLocalTime().date() >= startDt)
                        && (todo->dtStart().toLocalTime().date() <= endDt))       //start dt in range
                    || (todo->hasDueDate()
                        && (todo->dtDue().toLocalTime().date() >= startDt)
                        && (todo->dtDue().toLocalTime().date() <= endDt))       //due dt in range
                    || (todo->hasCompletedDate()
                        && (todo->completed().toLocalTime().date() >= startDt)
                        && (todo->completed().toLocalTime().date() <= endDt))) {    //completed dt in range
                    todos.append(todo);
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this, urlLabel] {
                popupMenu(urlLabel->url());
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &regionCode : regions) {
            QString name = KHolidays::HolidayRegion::name(regionCode);
            QLocale locale(KHolidays::HolidayRegion::languageCode(regionCode));
            QString languageName = QLocale::languageToString(locale.language());
            QString label;
            if (languageName.isEmpty()) {
                label = name;
            } else {
                label = i18nc("Holday region, region language", "%1 (%2)", name, languageName);
            }
            regionsMap.insert(label, regionCode);
        }
```

#### AUTO 


```{c}
auto collectionSelection = new CalendarSupport::CollectionSelection(selectionModel);
```

#### AUTO 


```{c}
auto attribute = col.attribute<Akonadi::PersistentSearchAttribute>(Akonadi::Collection::AddIfMissing);
```

#### RANGE FOR STATEMENT 


```{c}
for (const ReparentingModel::Node::Ptr &existing : std::as_const(mProxyNodes)) {
        if (*existing == *node) {
            // qCDebug(KORGANIZER_LOG) << "node is already existing";
            return;
        }
    }
```

#### AUTO 


```{c}
auto *buttonBox = new QDialogButtonBox(
        QDialogButtonBox::Close | QDialogButtonBox::Help, this);
```

#### AUTO 


```{c}
auto job = new KIO::CommandLauncherJob(QStringLiteral("kaddressbook"), {}, this);
```

#### AUTO 


```{c}
const auto contact = lst.first().payload<KContacts::Addressee>();
```

#### AUTO 


```{c}
const auto eventStart = ev->dtStart().toLocalTime();
```

#### AUTO 


```{c}
auto job = new BirthdaySearchJob(this, mDaysAhead);
```

#### AUTO 


```{c}
auto intItem = dynamic_cast<KConfigSkeleton::ItemInt *>(item);
```

#### AUTO 


```{c}
auto *noteedit = menu.findChild<CalendarSupport::NoteEditDialog *>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Alarm::Ptr &a : alarms) {
            const Incidence::Ptr parentIncidence = mCalendar->incidence(a->parentUid());
            lst << QStringLiteral("  ") + parentIncidence->summary() + QLatin1String(" (") + a->time().toString() + QLatin1Char(')');
        }
```

#### AUTO 


```{c}
auto *fetch = qobject_cast<Akonadi::CollectionFetchJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalCore::Incidence::Ptr &ev : incidences) {
        Q_ASSERT(ev);
        Akonadi::Item item = m_calendarview->calendar()->item(ev->uid());
        if (m_ui->summaryCheck->isChecked()) {
            if (re.indexIn(ev->summary()) != -1) {
                mMatchedEvents.append(item);
                continue;
            }
        }
        if (m_ui->descriptionCheck->isChecked()) {
            if (re.indexIn(ev->description()) != -1) {
                mMatchedEvents.append(item);
                continue;
            }
        }
        if (m_ui->categoryCheck->isChecked()) {
            if (re.indexIn(ev->categoriesStr()) != -1) {
                mMatchedEvents.append(item);
                continue;
            }
        }
        if (m_ui->locationCheck->isChecked()) {
            if (re.indexIn(ev->location()) != -1) {
                mMatchedEvents.append(item);
                continue;
            }
        }
        if (m_ui->attendeeCheck->isChecked()) {
            const KCalCore::Attendee::List lstAttendees = ev->attendees();
            for (const KCalCore::Attendee &attendee : lstAttendees) {
                if (re.indexIn(attendee.fullName()) != -1) {
                    mMatchedEvents.append(item);
                    break;
                }
            }
        }
    }
```

#### AUTO 


```{c}
auto job = new Akonadi::ItemFetchJob(item, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : items) {
            if (item.hasPayload<KContacts::Addressee>()) {
                const KContacts::Addressee addressee = item.payload<KContacts::Addressee>();
                const QDate birthday = addressee.birthday().date();
                if (birthday.isValid()) {
                    SDEntry entry;
                    entry.type = IncidenceTypeContact;
                    entry.category = CategoryBirthday;
                    dateDiff(birthday, entry.daysTo, entry.yearsOld);
                    if (entry.daysTo < mDaysAhead) {
                        // We need to check the days ahead here because we don't
                        // filter out Contact Birthdays by mDaysAhead in createLabels().
                        entry.date = birthday;
                        entry.addressee = addressee;
                        entry.item = item;
                        entry.span = 1;
                        mDates.append(entry);
                    }
                }
            }
        }
```

#### AUTO 


```{c}
const auto eventEnd = event->dtEnd().toLocalZone().dateTime();
```

#### AUTO 


```{c}
auto region = new KHolidays::HolidayRegion(regionStr);
```

#### RANGE FOR STATEMENT 


```{c}
for (QTreeWidgetItem *item : selectedItems) {
        auto *pageItem = static_cast<PageItem *>(item->parent() ? item->parent() : item);
        if (KMessageBox::warningContinueCancel(
                this,
                i18n("<qt>Do you really want to delete '<b>%1</b>'?</qt>",
                     pageItem->text(0)), QString(),
                KStandardGuiItem::del()) == KMessageBox::Continue) {
            QFile::remove(pageItem->path());
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const KCalCore::DateList &dates) { mDateNavigator->selectDates(dates); }
```

#### RANGE FOR STATEMENT 


```{c}
for (KOrg::BaseView *const view : std::as_const(mViews)) {
        KConfigGroup group = KSharedConfig::openConfig()->group(view->identifier());
        view->saveConfig(group);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, urlLabel] {
                    mailContact(urlLabel->url());
                }
```

#### AUTO 


```{c}
auto holidayLabel = new QLabel(i18nc("@label", "Use holiday region:"), holidayRegBox);
```

#### AUTO 


```{c}
auto *n = new KDateNavigator(this);
```

#### AUTO 


```{c}
auto l = new QLabel(i18nc("@label:spinbox", "Suspend &duration:"), suspendBox);
```

#### LAMBDA EXPRESSION 


```{c}
[=](bool) {
        mCalendarView->schedule_cancel();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Todo::Ptr &todo : std::as_const(prList)) {
            bool makeBold = false;
            int daysTo = -1;

            // Optionally, show only my To-dos
            /*      if ( mShowMineOnly &&
                         !KCalendarCore::CalHelper::isMyCalendarIncidence( mCalendarAdaptor, todo.get() ) ) {
                    continue;
                  }
            TODO: calhelper is deprecated, remove this?
            */

            // Icon label
            auto label = new QLabel(this);
            label->setPixmap(pm);
            label->setMaximumWidth(label->minimumSizeHint().width());
            mLayout->addWidget(label, counter, 0);
            mLabels.append(label);

            // Due date label
            str.clear();
            if (todo->hasDueDate() && todo->dtDue().date().isValid()) {
                daysTo = currDate.daysTo(todo->dtDue().date());

                if (daysTo == 0) {
                    makeBold = true;
                    str = i18nc("the to-do is due today", "Today");
                } else if (daysTo == 1) {
                    str = i18nc("the to-do is due tomorrow", "Tomorrow");
                } else {
                    const auto locale = QLocale::system();
                    for (int i = 3; i < 8; ++i) {
                        if (daysTo < i * 24 * 60 * 60) {
                            str = i18nc("1. weekday, 2. time",
                                        "%1 %2",
                                        locale.dayName(todo->dtDue().date().dayOfWeek(), QLocale::LongFormat),
                                        locale.toString(todo->dtDue().time(), QLocale::ShortFormat));
                            break;
                        }
                    }
                    if (str.isEmpty()) {
                        str = locale.toString(todo->dtDue(), QLocale::ShortFormat);
                    }
                }
            }

            label = new QLabel(str, this);
            label->setAlignment(Qt::AlignLeft | Qt::AlignVCenter);
            mLayout->addWidget(label, counter, 1);
            mLabels.append(label);
            if (makeBold) {
                QFont font = label->font();
                font.setBold(true);
                label->setFont(font);
            }

            // Days togo/ago label
            str.clear();
            if (todo->hasDueDate() && todo->dtDue().date().isValid()) {
                if (daysTo > 0) {
                    str = i18np("in 1 day", "in %1 days", daysTo);
                } else if (daysTo < 0) {
                    str = i18np("1 day ago", "%1 days ago", -daysTo);
                } else {
                    str = i18nc("the to-do is due", "due");
                }
            }
            label = new QLabel(str, this);
            label->setAlignment(Qt::AlignLeft | Qt::AlignVCenter);
            mLayout->addWidget(label, counter, 2);
            mLabels.append(label);

            // Priority label
            str = QLatin1Char('[') + QString::number(todo->priority()) + QLatin1Char(']');
            label = new QLabel(str, this);
            label->setAlignment(Qt::AlignRight | Qt::AlignVCenter);
            mLayout->addWidget(label, counter, 3);
            mLabels.append(label);

            // Summary label
            str = todo->summary();
            if (!todo->relatedTo().isEmpty()) { // show parent only, not entire ancestry
                KCalendarCore::Incidence::Ptr inc = mCalendar->incidence(todo->relatedTo());
                if (inc) {
                    str = inc->summary() + QLatin1Char(':') + str;
                }
            }
            if (!Qt::mightBeRichText(str)) {
                str = str.toHtmlEscaped();
            }

            auto urlLabel = new KUrlLabel(this);
            urlLabel->setText(str);
            urlLabel->setUrl(todo->uid());
            urlLabel->installEventFilter(this);
            urlLabel->setTextFormat(Qt::RichText);
            urlLabel->setWordWrap(true);
            mLayout->addWidget(urlLabel, counter, 4);
            mLabels.append(urlLabel);
            connect(urlLabel, &KUrlLabel::leftClickedUrl, this, [this, urlLabel] {
                viewTodo(urlLabel->url());
            });
            connect(urlLabel, &KUrlLabel::rightClickedUrl, this, [this, urlLabel] {
                popupMenu(urlLabel->url());
            });
            // State text label
            str = stateStr(todo);
            label = new QLabel(str, this);
            label->setAlignment(Qt::AlignLeft | Qt::AlignVCenter);
            mLayout->addWidget(label, counter, 5);
            mLabels.append(label);

            counter++;
        }
```

#### AUTO 


```{c}
auto fetchJob = qobject_cast<Akonadi::ItemFetchJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (Node *n : qAsConst(mSourceNodes)) {
        if (n->sourceIndex == sourceIndex) {
            return n;
        }
    }
```

#### AUTO 


```{c}
auto *searchCol = new QLineEdit(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            updateHamburgerMenu();
            // Immediately disconnect. We only need to run this once, but on demand.
            // NOTE: The nullptr at the end disconnects all connections between
            // q and mHamburgerMenu's aboutToShowMenu signal.
            disconnect(mHamburgerMenu, &KHamburgerMenu::aboutToShowMenu, this, nullptr);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto instance : mCalendar->instances(inc)) {
        KCalendarCore::Incidence::Ptr oldInstance(instance->clone());
        instance->setRelatedTo(QString());
        (void) mChanger->modifyIncidence(mCalendar->item(instance), oldInstance, this);
    }
```

#### AUTO 


```{c}
const auto next = ev->recurrence()->getNextDateTime(KDateTime(kdt)).dateTime();
```

#### AUTO 


```{c}
auto *topLayout = new QVBoxLayout(topBox);
```

#### LAMBDA EXPRESSION 


```{c}
[this, urlLabel] {
            popupMenu(urlLabel->url());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Todo::Ptr &todo : qAsConst(prList)) {
            bool makeBold = false;
            int daysTo = -1;

            // Optionally, show only my To-dos
            /*      if ( mShowMineOnly &&
                         !KCalendarCore::CalHelper::isMyCalendarIncidence( mCalendarAdaptor, todo.get() ) ) {
                    continue;
                  }
            TODO: calhelper is deprecated, remove this?
            */

            // Icon label
            label = new QLabel(this);
            label->setPixmap(pm);
            label->setMaximumWidth(label->minimumSizeHint().width());
            mLayout->addWidget(label, counter, 0);
            mLabels.append(label);

            // Due date label
            str.clear();
            if (todo->hasDueDate() && todo->dtDue().date().isValid()) {
                daysTo = currDate.daysTo(todo->dtDue().date());

                if (daysTo == 0) {
                    makeBold = true;
                    str = i18nc("the to-do is due today", "Today");
                } else if (daysTo == 1) {
                    str = i18nc("the to-do is due tomorrow", "Tomorrow");
                } else {
                    const auto locale = QLocale::system();
                    for (int i = 3; i < 8; ++i) {
                        if (daysTo < i * 24 * 60 * 60) {
                            str = i18nc("1. weekday, 2. time", "%1 %2",
                                        locale.dayName(todo->dtDue().date().dayOfWeek(),
                                                       QLocale::LongFormat),
                                        locale.toString(todo->dtDue().time(),
                                                        QLocale::ShortFormat));
                            break;
                        }
                    }
                    if (str.isEmpty()) {
                        str = locale.toString(todo->dtDue(), QLocale::ShortFormat);
                    }
                }
            }

            label = new QLabel(str, this);
            label->setAlignment(Qt::AlignLeft | Qt::AlignVCenter);
            mLayout->addWidget(label, counter, 1);
            mLabels.append(label);
            if (makeBold) {
                QFont font = label->font();
                font.setBold(true);
                label->setFont(font);
            }

            // Days togo/ago label
            str.clear();
            if (todo->hasDueDate() && todo->dtDue().date().isValid()) {
                if (daysTo > 0) {
                    str = i18np("in 1 day", "in %1 days", daysTo);
                } else if (daysTo < 0) {
                    str = i18np("1 day ago", "%1 days ago", -daysTo);
                } else {
                    str = i18nc("the to-do is due", "due");
                }
            }
            label = new QLabel(str, this);
            label->setAlignment(Qt::AlignLeft | Qt::AlignVCenter);
            mLayout->addWidget(label, counter, 2);
            mLabels.append(label);

            // Priority label
            str = QLatin1Char('[') + QString::number(todo->priority()) + QLatin1Char(']');
            label = new QLabel(str, this);
            label->setAlignment(Qt::AlignRight | Qt::AlignVCenter);
            mLayout->addWidget(label, counter, 3);
            mLabels.append(label);

            // Summary label
            str = todo->summary();
            if (!todo->relatedTo().isEmpty()) {   // show parent only, not entire ancestry
                KCalendarCore::Incidence::Ptr inc = mCalendar->incidence(todo->relatedTo());
                if (inc) {
                    str = inc->summary() + QLatin1Char(':') + str;
                }
            }
            if (!Qt::mightBeRichText(str)) {
                str = str.toHtmlEscaped();
            }

            KUrlLabel *urlLabel = new KUrlLabel(this);
            urlLabel->setText(str);
            urlLabel->setUrl(todo->uid());
            urlLabel->installEventFilter(this);
            urlLabel->setTextFormat(Qt::RichText);
            urlLabel->setWordWrap(true);
            mLayout->addWidget(urlLabel, counter, 4);
            mLabels.append(urlLabel);
#if KWIDGETSADDONS_VERSION < QT_VERSION_CHECK(5, 65, 0)
            connect(urlLabel, QOverload<const QString &>::of(
                        &KUrlLabel::leftClickedUrl), this, &TodoSummaryWidget::viewTodo);
            connect(urlLabel, QOverload<const QString &>::of(
                        &KUrlLabel::rightClickedUrl), this, &TodoSummaryWidget::popupMenu);
#else
            connect(urlLabel, &KUrlLabel::leftClickedUrl, this, [this, urlLabel] {
                viewTodo(urlLabel->url());
            });
            connect(urlLabel, &KUrlLabel::rightClickedUrl, this, [this, urlLabel] {
                popupMenu(urlLabel->url());
            });
#endif
            // State text label
            str = stateStr(todo);
            label = new QLabel(str, this);
            label->setAlignment(Qt::AlignLeft | Qt::AlignVCenter);
            mLayout->addWidget(label, counter, 5);
            mLabels.append(label);

            counter++;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &url : md->urls()) {
            if (url.scheme() == QStringLiteral("akonadi") && url.hasQuery()) {
                const QUrlQuery query(url.query());
                if (!query.queryItemValue(QStringLiteral("item")).isEmpty()
                    && query.queryItemValue(QStringLiteral("type")) == QStringLiteral("message/rfc822")) {
                    auto job = new Akonadi::ItemFetchJob(Akonadi::Item(static_cast<qint64>(query.queryItemValue(QStringLiteral("item")).toLongLong())));
                    job->fetchScope().fetchAllAttributes();
                    job->fetchScope().fetchFullPayload(true);
                    connect(job, &KJob::result, this, [this, url](KJob *job) {
                        if (job->error()) {
                            return;
                        }
                        auto fetchJob = qobject_cast<Akonadi::ItemFetchJob *>(job);
                        const Akonadi::Item::List items = fetchJob->items();
                        for (const Akonadi::Item &item : items) {
                            if (item.mimeType() == QStringLiteral("message/rfc822")) {
                                auto mail = item.payload<KMime::Message::Ptr>();
                                interface()->openEventEditor(i18nc("Event from email summary", "Mail: %1", mail->subject()->asUnicodeString()),
                                                             i18nc("Event from email content",
                                                                   "<b>From:</b> %1<br /><b>To:</b> %2<br /><b>Subject:</b> %3",
                                                                   mail->from()->displayString(),
                                                                   mail->to()->displayString(),
                                                                   mail->subject()->asUnicodeString()),
                                                             url.toDisplayString(),
                                                             QString(),
                                                             QStringList(),
                                                             QStringLiteral("message/rfc822"));
                            }
                        }
                    });
                }
                return;
            }
        }
```

#### AUTO 


```{c}
auto *dlg
        = menu.findChild<IncidenceEditorNG::IncidenceDialog *>(QStringLiteral("incidencedialog"));
```

#### LAMBDA EXPRESSION 


```{c}
[=](const Akonadi::Item & i){mMainView->editIncidence(i);}
```

#### AUTO 


```{c}
auto menu = new QMenu;
```

#### AUTO 


```{c}
auto *newFilter
        = new KCalendarCore::CalFilter(newFilterName);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Todo::Ptr &todo : qAsConst(prList)) {
            bool makeBold = false;
            int daysTo = -1;

            // Optionally, show only my To-dos
            /*      if ( mShowMineOnly &&
                         !KCalendarCore::CalHelper::isMyCalendarIncidence( mCalendarAdaptor, todo.get() ) ) {
                    continue;
                  }
            TODO: calhelper is deprecated, remove this?
            */

            // Icon label
            label = new QLabel(this);
            label->setPixmap(pm);
            label->setMaximumWidth(label->minimumSizeHint().width());
            mLayout->addWidget(label, counter, 0);
            mLabels.append(label);

            // Due date label
            str.clear();
            if (todo->hasDueDate() && todo->dtDue().date().isValid()) {
                daysTo = currDate.daysTo(todo->dtDue().date());

                if (daysTo == 0) {
                    makeBold = true;
                    str = i18nc("the to-do is due today", "Today");
                } else if (daysTo == 1) {
                    str = i18nc("the to-do is due tomorrow", "Tomorrow");
                } else {
                    const auto locale = QLocale::system();
                    for (int i = 3; i < 8; ++i) {
                        if (daysTo < i * 24 * 60 * 60) {
                            str = i18nc("1. weekday, 2. time", "%1 %2",
                                        locale.dayName(todo->dtDue().date().dayOfWeek(),
                                                       QLocale::LongFormat),
                                        locale.toString(todo->dtDue().time(),
                                                        QLocale::ShortFormat));
                            break;
                        }
                    }
                    if (str.isEmpty()) {
                        str = locale.toString(todo->dtDue(), QLocale::ShortFormat);
                    }
                }
            }

            label = new QLabel(str, this);
            label->setAlignment(Qt::AlignLeft | Qt::AlignVCenter);
            mLayout->addWidget(label, counter, 1);
            mLabels.append(label);
            if (makeBold) {
                QFont font = label->font();
                font.setBold(true);
                label->setFont(font);
            }

            // Days togo/ago label
            str.clear();
            if (todo->hasDueDate() && todo->dtDue().date().isValid()) {
                if (daysTo > 0) {
                    str = i18np("in 1 day", "in %1 days", daysTo);
                } else if (daysTo < 0) {
                    str = i18np("1 day ago", "%1 days ago", -daysTo);
                } else {
                    str = i18nc("the to-do is due", "due");
                }
            }
            label = new QLabel(str, this);
            label->setAlignment(Qt::AlignLeft | Qt::AlignVCenter);
            mLayout->addWidget(label, counter, 2);
            mLabels.append(label);

            // Priority label
            str = QLatin1Char('[') + QString::number(todo->priority()) + QLatin1Char(']');
            label = new QLabel(str, this);
            label->setAlignment(Qt::AlignRight | Qt::AlignVCenter);
            mLayout->addWidget(label, counter, 3);
            mLabels.append(label);

            // Summary label
            str = todo->summary();
            if (!todo->relatedTo().isEmpty()) {   // show parent only, not entire ancestry
                KCalendarCore::Incidence::Ptr inc = mCalendar->incidence(todo->relatedTo());
                if (inc) {
                    str = inc->summary() + QLatin1Char(':') + str;
                }
            }
            if (!Qt::mightBeRichText(str)) {
                str = str.toHtmlEscaped();
            }

            auto urlLabel = new KUrlLabel(this);
            urlLabel->setText(str);
            urlLabel->setUrl(todo->uid());
            urlLabel->installEventFilter(this);
            urlLabel->setTextFormat(Qt::RichText);
            urlLabel->setWordWrap(true);
            mLayout->addWidget(urlLabel, counter, 4);
            mLabels.append(urlLabel);
            connect(urlLabel, &KUrlLabel::leftClickedUrl, this, [this, urlLabel] {
                viewTodo(urlLabel->url());
            });
            connect(urlLabel, &KUrlLabel::rightClickedUrl, this, [this, urlLabel] {
                popupMenu(urlLabel->url());
            });
            // State text label
            str = stateStr(todo);
            label = new QLabel(str, this);
            label->setAlignment(Qt::AlignLeft | Qt::AlignVCenter);
            mLayout->addWidget(label, counter, 5);
            mLabels.append(label);

            counter++;
        }
```

#### AUTO 


```{c}
auto *button = new QToolButton(this);
```

#### AUTO 


```{c}
auto menu = new QMenu(nullptr);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Node *n : qAsConst(mSourceNodes)) {
        // qCDebug(KORGANIZER_LOG) << index << index.data().toString();
        if (proxyNode->isDuplicateOf(n->sourceIndex)) {
            return true;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (SummaryEventInfo *event : events) {
        // Optionally, show only my Events
        /*      if ( mShowMineOnly &&
                  !KCalCore::CalHelper::isMyCalendarIncidence( mCalendarAdaptor, event->ev ) ) {
              continue;
            }
            TODO: CalHelper is deprecated, remove this?
        */

        KCalCore::Event::Ptr ev = event->ev;
        // print the first of the recurring event series only
        if (ev->recurs()) {
            if (uidList.contains(ev->instanceIdentifier())) {
                continue;
            }
            uidList.append(ev->instanceIdentifier());
        }

        // Icon label
        label = new QLabel(this);
        if (ev->categories().contains(QLatin1String("BIRTHDAY"), Qt::CaseInsensitive)) {
            label->setPixmap(pmb);
        } else if (ev->categories().contains(QLatin1String("ANNIVERSARY"), Qt::CaseInsensitive)) {
            label->setPixmap(pma);
        } else {
            label->setPixmap(pm);
        }
        label->setMaximumWidth(label->minimumSizeHint().width());
        mLayout->addWidget(label, counter, 0);
        mLabels.append(label);

        // Start date or date span label
        QString dateToDisplay = event->startDate;
        if (!event->dateSpan.isEmpty()) {
            dateToDisplay = event->dateSpan;
        }
        label = new QLabel(dateToDisplay, this);
        label->setAlignment(Qt::AlignLeft | Qt::AlignVCenter);
        mLayout->addWidget(label, counter, 1);
        mLabels.append(label);
        if (event->makeBold) {
            QFont font = label->font();
            font.setBold(true);
            label->setFont(font);
            if (!event->makeUrgent) {
                label->setPalette(todayPalette);
            } else {
                label->setPalette(urgentPalette);
            }
            label->setAutoFillBackground(true);
        }

        // Days to go label
        label = new QLabel(event->daysToGo, this);
        label->setAlignment(Qt::AlignLeft | Qt::AlignVCenter);
        mLayout->addWidget(label, counter, 2);
        mLabels.append(label);

        // Summary label
        KUrlLabel *urlLabel = new KUrlLabel(this);
        urlLabel->setText(event->summaryText);
        urlLabel->setUrl(event->summaryUrl);
        urlLabel->installEventFilter(this);
        urlLabel->setTextFormat(Qt::RichText);
        urlLabel->setWordWrap(true);
        mLayout->addWidget(urlLabel, counter, 3);
        mLabels.append(urlLabel);

        connect(urlLabel, QOverload<const QString &>::of(
                    &KUrlLabel::leftClickedUrl), this, &ApptSummaryWidget::viewEvent);
        connect(urlLabel, QOverload<const QString &>::of(
                    &KUrlLabel::rightClickedUrl), this, &ApptSummaryWidget::popupMenu);
        if (!event->summaryTooltip.isEmpty()) {
            urlLabel->setToolTip(event->summaryTooltip);
        }

        // Time range label (only for non-floating events)
        if (!event->timeRange.isEmpty()) {
            label = new QLabel(event->timeRange, this);
            label->setAlignment(Qt::AlignLeft | Qt::AlignVCenter);
            mLayout->addWidget(label, counter, 4);
            mLabels.append(label);
        }

        counter++;
    }
```

#### AUTO 


```{c}
auto knsAction = new KNSWidgets::Action(i18n("Get New Calendars..."), QStringLiteral("korganizer.knsrc"), this);
```

#### AUTO 


```{c}
const auto it = changedProperties.find(QStringLiteral("Inhibited"));
```

#### AUTO 


```{c}
auto note = new QLabel(xi18nc("@info",
                                  "<note>The daemon will continue running even if it is not shown "
                                  "in the system tray.</note>"));
```

#### AUTO 


```{c}
auto *stringItem = dynamic_cast<KConfigSkeleton::ItemString *>(item);
```

#### AUTO 


```{c}
auto *pageItem = static_cast<PageItem *>(item);
```

#### AUTO 


```{c}
const auto installedEntries = KNS3::QtQuickDialogWrapper(QStringLiteral("korganizer.knsrc")).exec();
```

#### AUTO 


```{c}
auto *activeLabel = new QLabel(
        i18n("<a href=\"whatsthis:%1\">How does this work?</a>", cwHowto), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Node::Ptr &node : std::as_const(parent->children)) {
        if (node.data() == this) {
            return row;
        }
        row++;
    }
```

#### AUTO 


```{c}
auto *attribute = col.attribute<Akonadi::PersistentSearchAttribute>(Akonadi::Collection::AddIfMissing);
```

#### AUTO 


```{c}
auto menu = new QMenu(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalCore::Todo::Ptr &todo : alltodos) {
                Q_ASSERT(todo);
                if ((!todo->hasStartDate() && !todo->hasDueDate()) ||    // undated
                        (todo->hasStartDate() &&
                         (todo->dtStart().toLocalZone().date() >= startDt) &&
                         (todo->dtStart().toLocalZone().date() <= endDt)) ||      //start dt in range
                        (todo->hasDueDate() &&
                         (todo->dtDue().toLocalZone().date() >= startDt) &&
                         (todo->dtDue().toLocalZone().date() <= endDt)) ||      //due dt in range
                        (todo->hasCompletedDate() &&
                         (todo->completed().toLocalZone().date() >= startDt) &&
                         (todo->completed().toLocalZone().date() <= endDt))) {      //completed dt in range
                    todos.append(todo);
                }
            }
```

#### AUTO 


```{c}
auto topLayout = new QGridLayout(topFrame);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto instance : mCalendar->instances(incidence)) {
                (void) mChanger->deleteIncidence(mCalendar->item(instance), this); //?!
            }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
                history->redo();
            }
```

#### AUTO 


```{c}
auto label = new QLabel(
        i18nc("@label",
              "Reminders: "
              "Clicking on the title toggles details for item"),
        topBox);
```

#### AUTO 


```{c}
auto label = new QLabel(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &mimetype : allMimeTypes) {
        monitor->setMimeTypeMonitored(mimetype, true);
    }
```

#### AUTO 


```{c}
auto layout = new QHBoxLayout(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (QTreeWidgetItem *item : selectedItems) {
        PageItem *pageItem = static_cast<PageItem *>(item->parent() ? item->parent() : item);
        if (KMessageBox::warningContinueCancel(
                this,
                i18n("<qt>Do you really want to delete '<b>%1</b>'?</qt>",
                     pageItem->text(0)), QString(),
                KStandardGuiItem::del()) == KMessageBox::Continue) {
            QFile::remove(pageItem->path());
        }
    }
```

#### AUTO 


```{c}
const auto timeDateList =
                    t->recurrence()->timesInInterval(
                        QDateTime(mDays[0], {}, Qt::LocalTime),
                        QDateTime(mDays[NUMDAYS - 1], {}, Qt::LocalTime));
```

#### AUTO 


```{c}
auto job = new Akonadi::CollectionDeleteJob(collection, this);
```

#### AUTO 


```{c}
const auto *attr
            = col.attribute<Akonadi::CollectionIdentificationAttribute>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &plugin : plugins) {
        qDebug() << "CalendarDecoration:" << plugin.pluginId() << "(" << plugin.name() << ")";
        EventViews::CalendarDecoration::Decoration *p = KOCore::self()->loadCalendarDecoration(plugin);
        if (!p) {
            qDebug() << "Calendar decoration loading failed.";
        } else {
            qDebug() << "CALENDAR DECORATION INFO:" << p->info();
        }
    }
```

#### AUTO 


```{c}
auto *box = new QDialogButtonBox(QDialogButtonBox::Yes | QDialogButtonBox::No | QDialogButtonBox::Cancel | QDialogButtonBox::Ok, parent);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        printTodo();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *it : list) {
                if (allowedTypes.contains(QLatin1String(it->metaObject()->className()))) {
                    const QString name = it->objectName();
                    if (name.startsWith(QStringLiteral("X_"))) {
                        new QTreeWidgetItem(this, QStringList()
                                            << name
                                            << allowedTypes[ QLatin1String(it->metaObject()->className()) ]
                                            << QLatin1String(it->metaObject()->className())
                                            << it->whatsThis());
                    }
                }
            }
```

#### AUTO 


```{c}
auto *job = new Akonadi::AgentInstanceCreateJob(agentType,
                                                                                       this);
```

#### AUTO 


```{c}
const auto &e
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalCore::Incidence::Ptr &inc : incidences) {
        Q_ASSERT(inc);
        QDate d = inc->dtStart().toLocalTime().date();
        if (inc->type() == KCalCore::Incidence::TypeJournal &&
                d >= mDays[0] &&
                d <= mDays[NUMDAYS - 1] &&
                !mEvents.contains(d)) {
            mEvents.append(d);
        }
        if (mEvents.count() == NUMDAYS) {
            // No point in wasting cpu, all days are bold already
            break;
        }
    }
```

#### AUTO 


```{c}
auto *layout = new QHBoxLayout(q);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Alarm::Ptr &alarm : alarms) {
        const QString uid = alarm->parentUid();
        const Akonadi::Item::Id id = mCalendar->item(uid).id();
        const Akonadi::Item item = mCalendar->item(id);

        createReminder(item, mLastChecked, alarm->text());
    }
```

#### AUTO 


```{c}
const auto selectedItems = mPageView->selectedItems();
```

#### AUTO 


```{c}
auto *deletejob = static_cast<Akonadi::CollectionDeleteJob *>(job);
```

#### AUTO 


```{c}
auto buttonBox = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (KOrg::MainWindow *inst : std::as_const(mWindowList)) {
        if (inst && inst->getCurrentURL() == url) {
            return inst;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &descendant : list) {
        Q_FOREACH (const Node::Ptr &proxyNode, mProxyNodes) {
            if (proxyNode->isDuplicateOf(descendant)) {
                //Removenode from proxy
                if (!proxyNode->parent) {
                    qCWarning(KORGANIZER_LOG) <<  objectName()
                                              <<
                    "Found proxy that is already not part of the model " << proxyNode->data(
                        Qt::DisplayRole).toString();
                    continue;
                }
                const int targetRow = proxyNode->row();
                beginRemoveRows(index(proxyNode->parent), targetRow, targetRow);
                proxyNode->parent->children.remove(targetRow);
                proxyNode->parent = 0;
                endRemoveRows();
            }
        }
    }
```

#### AUTO 


```{c}
auto *filter = new KCalendarCore::CalFilter(*it);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Node::Ptr &proxyNode : qAsConst(mProxyNodes)) {
        proxyNode->clearHierarchy();
    }
```

#### AUTO 


```{c}
auto job = new PimCommon::ManageServerSideSubscriptionJob(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KHolidays::HolidayRegion *region : std::as_const(mHolidayRegions)) {
        if (region && region->isValid()) {
            const KHolidays::Holiday::List list = region->holidays(start, end);
            const int listCount(list.count());
            for (int i = 0; i < listCount; ++i) {
                const KHolidays::Holiday &h = list.at(i);
                // dedupe, since we support multiple holiday regions which may have similar holidays
                if (!holidaysByDate[h.observedStartDate()].contains(h.name())) {
                    holidaysByDate[h.observedStartDate()].append(h.name());
                }
            }
        }
    }
```

#### AUTO 


```{c}
const auto &a
```

#### AUTO 


```{c}
const auto occurrences = event->recurrence()->timesInInterval(QDateTime(start, {}), QDateTime(end, {}));
```

#### AUTO 


```{c}
auto *mSearchView = new Akonadi::EntityTreeView(this);
```

#### AUTO 


```{c}
auto mSearchView = new Akonadi::EntityTreeView(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Node::Ptr &child : std::as_const(n->parent->children)) {
            if (child.data() == n) {
                found = true;
            }
        }
```

#### AUTO 


```{c}
auto *sync = new Akonadi::CollectionAttributesSynchronizationJob(col);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : indexes) {
        if (index.isValid()) {
            const Akonadi::Collection collection = index.data(Akonadi::EntityTreeModel::CollectionRole).value<Akonadi::Collection>();
            if (collection.isValid()) {
                collections << collection;
            }
        }
    }
```

#### AUTO 


```{c}
auto *dlg = menu.findChild<IncidenceEditorNG::IncidenceDialog *>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Todo::Ptr &todo : std::as_const(prList)) {
            bool makeBold = false;
            int daysTo = -1;

            // Optionally, show only my To-dos
            /*      if ( mShowMineOnly &&
                         !KCalendarCore::CalHelper::isMyCalendarIncidence( mCalendarAdaptor, todo.get() ) ) {
                    continue;
                  }
            TODO: calhelper is deprecated, remove this?
            */

            // Icon label
            label = new QLabel(this);
            label->setPixmap(pm);
            label->setMaximumWidth(label->minimumSizeHint().width());
            mLayout->addWidget(label, counter, 0);
            mLabels.append(label);

            // Due date label
            str.clear();
            if (todo->hasDueDate() && todo->dtDue().date().isValid()) {
                daysTo = currDate.daysTo(todo->dtDue().date());

                if (daysTo == 0) {
                    makeBold = true;
                    str = i18nc("the to-do is due today", "Today");
                } else if (daysTo == 1) {
                    str = i18nc("the to-do is due tomorrow", "Tomorrow");
                } else {
                    const auto locale = QLocale::system();
                    for (int i = 3; i < 8; ++i) {
                        if (daysTo < i * 24 * 60 * 60) {
                            str = i18nc("1. weekday, 2. time",
                                        "%1 %2",
                                        locale.dayName(todo->dtDue().date().dayOfWeek(), QLocale::LongFormat),
                                        locale.toString(todo->dtDue().time(), QLocale::ShortFormat));
                            break;
                        }
                    }
                    if (str.isEmpty()) {
                        str = locale.toString(todo->dtDue(), QLocale::ShortFormat);
                    }
                }
            }

            label = new QLabel(str, this);
            label->setAlignment(Qt::AlignLeft | Qt::AlignVCenter);
            mLayout->addWidget(label, counter, 1);
            mLabels.append(label);
            if (makeBold) {
                QFont font = label->font();
                font.setBold(true);
                label->setFont(font);
            }

            // Days togo/ago label
            str.clear();
            if (todo->hasDueDate() && todo->dtDue().date().isValid()) {
                if (daysTo > 0) {
                    str = i18np("in 1 day", "in %1 days", daysTo);
                } else if (daysTo < 0) {
                    str = i18np("1 day ago", "%1 days ago", -daysTo);
                } else {
                    str = i18nc("the to-do is due", "due");
                }
            }
            label = new QLabel(str, this);
            label->setAlignment(Qt::AlignLeft | Qt::AlignVCenter);
            mLayout->addWidget(label, counter, 2);
            mLabels.append(label);

            // Priority label
            str = QLatin1Char('[') + QString::number(todo->priority()) + QLatin1Char(']');
            label = new QLabel(str, this);
            label->setAlignment(Qt::AlignRight | Qt::AlignVCenter);
            mLayout->addWidget(label, counter, 3);
            mLabels.append(label);

            // Summary label
            str = todo->summary();
            if (!todo->relatedTo().isEmpty()) { // show parent only, not entire ancestry
                KCalendarCore::Incidence::Ptr inc = mCalendar->incidence(todo->relatedTo());
                if (inc) {
                    str = inc->summary() + QLatin1Char(':') + str;
                }
            }
            if (!Qt::mightBeRichText(str)) {
                str = str.toHtmlEscaped();
            }

            auto urlLabel = new KUrlLabel(this);
            urlLabel->setText(str);
            urlLabel->setUrl(todo->uid());
            urlLabel->installEventFilter(this);
            urlLabel->setTextFormat(Qt::RichText);
            urlLabel->setWordWrap(true);
            mLayout->addWidget(urlLabel, counter, 4);
            mLabels.append(urlLabel);
            connect(urlLabel, &KUrlLabel::leftClickedUrl, this, [this, urlLabel] {
                viewTodo(urlLabel->url());
            });
            connect(urlLabel, &KUrlLabel::rightClickedUrl, this, [this, urlLabel] {
                popupMenu(urlLabel->url());
            });
            // State text label
            str = stateStr(todo);
            label = new QLabel(str, this);
            label->setAlignment(Qt::AlignLeft | Qt::AlignVCenter);
            mLayout->addWidget(label, counter, 5);
            mLabels.append(label);

            counter++;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &url : md->urls()) {
            if (url.scheme() == QStringLiteral("akonadi") && url.hasQuery()) {
                const QUrlQuery query(url.query());
                if (!query.queryItemValue(QStringLiteral("item")).isEmpty()
                    && query.queryItemValue(QStringLiteral("type")) == QStringLiteral("message/rfc822")) {
                    Akonadi::ItemFetchJob *job =
                        new Akonadi::ItemFetchJob(Akonadi::Item(static_cast<qint64>(query.queryItemValue(QStringLiteral("item")).toLongLong())));
                    job->fetchScope().fetchAllAttributes();
                    job->fetchScope().fetchFullPayload(true);
                    connect(job, &KJob::result, this, [this, url](KJob *job) {
                        if (job->error()) {
                            return;
                        }
                        Akonadi::ItemFetchJob *fetchJob = qobject_cast<Akonadi::ItemFetchJob *>(job);
                        const Akonadi::Item::List items = fetchJob->items();
                        for (const Akonadi::Item &item : items) {
                            if (item.mimeType() == QStringLiteral("message/rfc822")) {
                                auto mail = item.payload<KMime::Message::Ptr>();
                                interface()->openTodoEditor(i18nc("Event from email summary", "Mail: %1", mail->subject()->asUnicodeString()),
                                                            i18nc("Event from email content",
                                                                  "<b>From:</b> %1<br /><b>To:</b> %2<br /><b>Subject:</b> %3",
                                                                  mail->from()->displayString(),
                                                                  mail->to()->displayString(),
                                                                  mail->subject()->asUnicodeString()),
                                                            url.toDisplayString(),
                                                            QString(),
                                                            QStringList(),
                                                            QStringLiteral("message/rfc822"));
                            }
                        }
                    });
                }
                return;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (SummaryEventInfo *ev : events3) {
            QVERIFY(ev->summaryText.contains(multiDayAllDayInFuture));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (KDateNavigator *n : std::as_const(mExtraViews)) {
        if (n) {
            n->setUpdateNeeded();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &instance : mCalendar->instances(incidence)) {
                (void)mChanger->deleteIncidence(mCalendar->item(instance), this);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const ReparentingModel::Node::Ptr &node : currentProxyNodes) {
        if (!nodes.contains(node)) {
            removeNode(*node);
        }
    }
```

#### AUTO 


```{c}
auto job = KIO::file_copy(QUrl::fromLocalFile(mFile), mURL);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : indexes) {
        if (index.isValid()) {
            const auto c = index.data(Akonadi::EntityTreeModel::CollectionRole).value<Akonadi::Collection>();
            if (c.id() == collection.id()) {
                return true;
            }
        }
    }
```

#### AUTO 


```{c}
auto *systrayLayout = new QVBoxLayout(systrayFrame);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &a : attendees) {
        const QString email = a.email();
        if (email.isEmpty()) {
            continue;
        }

        // In case we (as one of our identities) are the organizer we are sending
        // this mail. We could also have added ourselves as an attendee, in which
        // case we don't want to send ourselves a notification mail.
        if (organizerEmail == email) {
            continue;
        }

        // Build a nice address for this attendee including the CN.
        QString tname, temail;
        const QString username = KEmailAddress::quoteNameIfNecessary(a.name());
        // ignore the return value from extractEmailAddressAndName() because
        // it will always be false since tusername does not contain "@domain".
        KEmailAddress::extractEmailAddressAndName(username, temail /*byref*/, tname /*byref*/);
        tname += QStringLiteral(" <") + email + QLatin1Char('>');

        // Optional Participants and Non-Participants are copied on the email
        if (a.role() == KCalCore::Attendee::OptParticipant
            || a.role() == KCalCore::Attendee::NonParticipant) {
            ccList << tname;
        } else {
            toList << tname;
        }
    }
```

#### AUTO 


```{c}
auto job = new Akonadi::AgentInstanceCreateJob(agentType,
                                                                                       this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Todo::Ptr &todo : qAsConst(prList)) {
            bool makeBold = false;
            int daysTo = -1;

            // Optionally, show only my To-dos
            /*      if ( mShowMineOnly &&
                         !KCalendarCore::CalHelper::isMyCalendarIncidence( mCalendarAdaptor, todo.get() ) ) {
                    continue;
                  }
            TODO: calhelper is deprecated, remove this?
            */

            // Icon label
            label = new QLabel(this);
            label->setPixmap(pm);
            label->setMaximumWidth(label->minimumSizeHint().width());
            mLayout->addWidget(label, counter, 0);
            mLabels.append(label);

            // Due date label
            str.clear();
            if (todo->hasDueDate() && todo->dtDue().date().isValid()) {
                daysTo = currDate.daysTo(todo->dtDue().date());

                if (daysTo == 0) {
                    makeBold = true;
                    str = i18nc("the to-do is due today", "Today");
                } else if (daysTo == 1) {
                    str = i18nc("the to-do is due tomorrow", "Tomorrow");
                } else {
                    const auto locale = QLocale::system();
                    for (int i = 3; i < 8; ++i) {
                        if (daysTo < i * 24 * 60 * 60) {
                            str = i18nc("1. weekday, 2. time", "%1 %2",
                                        locale.dayName(todo->dtDue().date().dayOfWeek(),
                                                       QLocale::LongFormat),
                                        locale.toString(todo->dtDue().time(),
                                                        QLocale::ShortFormat));
                            break;
                        }
                    }
                    if (str.isEmpty()) {
                        str = locale.toString(todo->dtDue(), QLocale::ShortFormat);
                    }
                }
            }

            label = new QLabel(str, this);
            label->setAlignment(Qt::AlignLeft | Qt::AlignVCenter);
            mLayout->addWidget(label, counter, 1);
            mLabels.append(label);
            if (makeBold) {
                QFont font = label->font();
                font.setBold(true);
                label->setFont(font);
            }

            // Days togo/ago label
            str.clear();
            if (todo->hasDueDate() && todo->dtDue().date().isValid()) {
                if (daysTo > 0) {
                    str = i18np("in 1 day", "in %1 days", daysTo);
                } else if (daysTo < 0) {
                    str = i18np("1 day ago", "%1 days ago", -daysTo);
                } else {
                    str = i18nc("the to-do is due", "due");
                }
            }
            label = new QLabel(str, this);
            label->setAlignment(Qt::AlignLeft | Qt::AlignVCenter);
            mLayout->addWidget(label, counter, 2);
            mLabels.append(label);

            // Priority label
            str = QLatin1Char('[') + QString::number(todo->priority()) + QLatin1Char(']');
            label = new QLabel(str, this);
            label->setAlignment(Qt::AlignRight | Qt::AlignVCenter);
            mLayout->addWidget(label, counter, 3);
            mLabels.append(label);

            // Summary label
            str = todo->summary();
            if (!todo->relatedTo().isEmpty()) {   // show parent only, not entire ancestry
                KCalendarCore::Incidence::Ptr inc = mCalendar->incidence(todo->relatedTo());
                if (inc) {
                    str = inc->summary() + QLatin1Char(':') + str;
                }
            }
            if (!Qt::mightBeRichText(str)) {
                str = str.toHtmlEscaped();
            }

            auto *urlLabel = new KUrlLabel(this);
            urlLabel->setText(str);
            urlLabel->setUrl(todo->uid());
            urlLabel->installEventFilter(this);
            urlLabel->setTextFormat(Qt::RichText);
            urlLabel->setWordWrap(true);
            mLayout->addWidget(urlLabel, counter, 4);
            mLabels.append(urlLabel);
            connect(urlLabel, &KUrlLabel::leftClickedUrl, this, [this, urlLabel] {
                viewTodo(urlLabel->url());
            });
            connect(urlLabel, &KUrlLabel::rightClickedUrl, this, [this, urlLabel] {
                popupMenu(urlLabel->url());
            });
            // State text label
            str = stateStr(todo);
            label = new QLabel(str, this);
            label->setAlignment(Qt::AlignLeft | Qt::AlignVCenter);
            mLayout->addWidget(label, counter, 5);
            mLabels.append(label);

            counter++;
        }
```

#### AUTO 


```{c}
const auto currentProxyNodes = mProxyNodes;
```

#### AUTO 


```{c}
auto incidence = Akonadi::CalendarUtils::incidence(item);
```

#### AUTO 


```{c}
auto pluginFactory = qobject_cast<EventViews::CalendarDecoration::DecorationFactory *>(factory);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &a : attendees) {
        const QString email = a.email();
        if (email.isEmpty()) {
            continue;
        }

        // In case we (as one of our identities) are the organizer we are sending
        // this mail. We could also have added ourselves as an attendee, in which
        // case we don't want to send ourselves a notification mail.
        if (organizerEmail == email) {
            continue;
        }

        // Build a nice address for this attendee including the CN.
        QString tname, temail;
        const QString username = KEmailAddress::quoteNameIfNecessary(a.name());
        // ignore the return value from extractEmailAddressAndName() because
        // it will always be false since tusername does not contain "@domain".
        KEmailAddress::extractEmailAddressAndName(username, temail /*byref*/, tname /*byref*/);
        tname += QLatin1String(" <") + email + QLatin1Char('>');

        // Optional Participants and Non-Participants are copied on the email
        if (a.role() == KCalendarCore::Attendee::OptParticipant
            || a.role() == KCalendarCore::Attendee::NonParticipant) {
            ccList << tname;
        } else {
            toList << tname;
        }
    }
```

#### AUTO 


```{c}
auto buttonBox = new QDialogButtonBox(QDialogButtonBox::Close | QDialogButtonBox::Help, this);
```

#### AUTO 


```{c}
auto me = static_cast<QMouseEvent *>(event);
```

#### AUTO 


```{c}
auto quickview = new Quickview(Akonadi::CollectionUtils::fromIndex(index));
```

#### AUTO 


```{c}
auto label = static_cast<KUrlLabel *>(obj);
```

#### AUTO 


```{c}
auto calendarFrameLayout = new QHBoxLayout;
```

#### AUTO 


```{c}
auto button = new QToolButton(this);
```

#### AUTO 


```{c}
auto activeLabel = new QLabel(
        i18n("<a href=\"whatsthis:%1\">How does this work?</a>", cwHowto), this);
```

#### AUTO 


```{c}
auto manageAccountWidget = new Akonadi::ManageAccountWidget(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (KDateNavigator *n : std::as_const(mExtraViews)) {
        if (n) {
            n->setHighlightMode(highlightEvents, highlightTodos, highlightJournals);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](auto changedEntries) {
        for (const auto &e : changedEntries) {
            qCDebug(KORGANIZER_LOG) << " downloadNewStuff :";
            const QStringList lstFile = e.installedFiles();
            if (lstFile.count() != 1) {
                continue;
            }
            const QString file = lstFile.at(0);
            const QUrl filename = QUrl::fromLocalFile(file);
            qCDebug(KORGANIZER_LOG) << "filename :" << filename;
            if (!filename.isValid()) {
                continue;
            }

            KCalendarCore::FileStorage storage(calendar());
            storage.setFileName(file);
            storage.setSaveFormat(new KCalendarCore::ICalFormat);
            if (!storage.load()) {
                KMessageBox::error(mCalendarView, i18n("Could not load calendar %1.", file));
            } else {
                QStringList eventSummaries;
                const KCalendarCore::Event::List events = calendar()->events();
                eventSummaries.reserve(events.count());
                for (const KCalendarCore::Event::Ptr &event : events) {
                    eventSummaries.append(event->summary());
                }

                const int result = KMessageBox::warningContinueCancelList(mCalendarView,
                                                                          i18n("The downloaded events will be merged into your current calendar."),
                                                                          eventSummaries);

                if (result != KMessageBox::Continue) {
                    // FIXME (KNS2): hm, no way out here :-)
                }

                if (importURL(QUrl::fromLocalFile(file), true)) {
                    // FIXME (KNS2): here neither
                }
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalCore::Event::Ptr &event : eventlist) {
        if (mEvents.count() == NUMDAYS) {
            // No point in wasting cpu, all days are bold already
            break;
        }

        Q_ASSERT(event);
        const ushort recurType = event->recurrenceType();
        const QDateTime dtStart = event->dtStart().toLocalTime();

        // timed incidences occur in
        //   [dtStart(), dtEnd()[. All-day incidences occur in [dtStart(), dtEnd()]
        // so we subtract 1 second in the timed case
        const int secsToAdd = event->allDay() ? 0 : -1;
        const QDateTime dtEnd = event->dtEnd().toLocalTime().addSecs(secsToAdd);

        if (!(recurType == KCalCore::Recurrence::rDaily  && !KOPrefs::instance()->mDailyRecur) &&
                !(recurType == KCalCore::Recurrence::rWeekly && !KOPrefs::instance()->mWeeklyRecur)) {

            KCalCore::SortableList<QDateTime> timeDateList;
            const bool isRecurrent = event->recurs();
            const int eventDuration = dtStart.daysTo(dtEnd);

            if (isRecurrent) {
                //Its a recurring event, find out in which days it occurs
                timeDateList = event->recurrence()->timesInInterval(
                                   QDateTime(mDays[0], {}, Qt::LocalTime),
                                   QDateTime(mDays[NUMDAYS - 1], {}, Qt::LocalTime));
            } else {
                if (dtStart.date() >= mDays[0]) {
                    timeDateList.append(dtStart);
                } else {
                    // The event starts in another month (not visible))
                    timeDateList.append(QDateTime(mDays[0], {}, Qt::LocalTime));
                }
            }

            for (auto t = timeDateList.begin(); t != timeDateList.end(); ++t) {
                //This could be a multiday event, so iterate from dtStart() to dtEnd()
                QDate d = t->toLocalTime().date();
                int j   = 0;

                QDate occurrenceEnd;
                if (isRecurrent) {
                    occurrenceEnd = d.addDays(eventDuration);
                } else {
                    occurrenceEnd = dtEnd.date();
                }

                do {
                    mEvents.append(d);
                    ++j;
                    d = d.addDays(1);
                } while (d <= occurrenceEnd && j < NUMDAYS);
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](bool) {
        mCalendarView->schedule_forward();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KDateNavigator *n : qAsConst(mExtraViews)) {
        if (n) {
            n->setHighlightMode(highlightEvents, highlightTodos, highlightJournals);
        }
    }
```

#### AUTO 


```{c}
auto *buttonBox = new QDialogButtonBox(
        QDialogButtonBox::Ok | QDialogButtonBox::Cancel, this);
```

#### AUTO 


```{c}
const auto *annotationAttribute = collection.attribute<PimCommon::CollectionAnnotationsAttribute>();
```

#### AUTO 


```{c}
auto *datetimeLayout = new QGridLayout(datetimeGroupBox);
```

#### AUTO 


```{c}
auto colorLayout = new QGridLayout(colorFrame);
```

#### AUTO 


```{c}
const auto *item = static_cast<const ReminderTreeItem *>(&other);
```

#### RANGE FOR STATEMENT 


```{c}
for (Akonadi::Item::Id id : itemIdList) {
            Akonadi::Item item = mCalendar->item(id);
            if (item.isValid()) {
                changeIncidenceDisplay(item, Akonadi::IncidenceChanger::ChangeTypeDelete);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &a : attendees) {
        const QString email = a.email();
        if (email.isEmpty()) {
            continue;
        }

        // In case we (as one of our identities) are the organizer we are sending
        // this mail. We could also have added ourselves as an attendee, in which
        // case we don't want to send ourselves a notification mail.
        if (organizerEmail == email) {
            continue;
        }

        // Build a nice address for this attendee including the CN.
        QString tname;
        QString temail;
        const QString username = KEmailAddress::quoteNameIfNecessary(a.name());
        // ignore the return value from extractEmailAddressAndName() because
        // it will always be false since tusername does not contain "@domain".
        KEmailAddress::extractEmailAddressAndName(username, temail /*byref*/, tname /*byref*/);
        tname += QLatin1String(" <") + email + QLatin1Char('>');

        // Optional Participants and Non-Participants are copied on the email
        if (a.role() == KCalendarCore::Attendee::OptParticipant || a.role() == KCalendarCore::Attendee::NonParticipant) {
            ccList << tname;
        } else {
            toList << tname;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Alarm::Ptr &alarm : alarms) {
            const QString uid = alarm->customProperty("ETMCalendar", "parentUid");
            const Akonadi::Item::Id id = mCalendar->item(uid).id();
            const Akonadi::Item item = mCalendar->item(id);

            const Incidence::Ptr incidence = CalendarSupport::incidence(item);
            const QString summary = incidence->summary();

            const QDateTime time = incidence->dateTime(Incidence::RoleAlarm);
            lst << QStringLiteral("%1: \"%2\" (alarm text \"%3\")").arg(time.toString(Qt::ISODate), summary, alarm->text());
        }
```

#### AUTO 


```{c}
auto format = new KCalendarCore::ICalFormat;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : fileNames) {
            new PageItem(mPageView, dir + QLatin1Char('/') + file);
        }
```

#### AUTO 


```{c}
auto w = new KPrefsWidCombo(item, parent);
```

#### LAMBDA EXPRESSION 


```{c}
[this](Akonadi::ServerManager::State state) {
            if (state == Akonadi::ServerManager::Running) {
                setupAkonadi();
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &plugin : plugins) {
        PluginItem *item = new PluginItem(mDecorations, plugin);

        if (selectedPlugins.contains(plugin.pluginId())) {
            item->setCheckState(0, Qt::Checked);
        } else {
            item->setCheckState(0, Qt::Unchecked);
        }
        const QVariant variant = plugin.value(QStringLiteral("X-KDE-KOrganizer-HasSettings"));
        const bool hasSettings = (variant.isValid() && variant.toBool());
        if (hasSettings) {
            auto but = new QToolButton(mTreeWidget);
            auto act = new QAction(but);
            const QString decoration = plugin.pluginId();
            act->setData(QVariant::fromValue<PluginItem *>(item));
            but->setDefaultAction(act);
            but->setIcon(QIcon::fromTheme(QStringLiteral("configure")));
            but->setFixedWidth(28);
            but->setToolTip(i18nc("@action", "Configure"));
            but->setAutoFillBackground(true);
            but->setEnabled(true);
            mTreeWidget->setItemWidget(item, 1, but);
            connect(but, &QToolButton::triggered, this, &KOPrefsDialogPlugins::configureClicked);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KDateNavigator *n : qAsConst(mExtraViews)) {
        if (n) {
            n->updateDayMatrix();
        }
    }
```

#### AUTO 


```{c}
auto audioFileRemindersBox = new QVBoxLayout;
```

#### AUTO 


```{c}
auto about = new KAboutData(QStringLiteral("kcmapptsummary"),
                                i18n("Upcoming Events Configuration Dialog"),
                                QString(),
                                QString(),
                                KAboutLicense::GPL,
                                i18n("Copyright � 2003�2004 Tobias Koenig\n"
                                     "Copyright � 2005�2010 Allen Winter"));
```

#### AUTO 


```{c}
auto collectionFilter = new CollectionFilter(this);
```

#### AUTO 


```{c}
auto it = events.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &entry : regionsMap) {
        mHolidayCheckCombo->addItem(entry.first, entry.second);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KOrg::BaseView *const view : qAsConst(mViews)) {
        KConfigGroup group = KSharedConfig::openConfig()->group(view->identifier());
        view->saveConfig(group);
    }
```

#### AUTO 


```{c}
auto firstDayLayout = new QHBoxLayout;
```

#### RANGE FOR STATEMENT 


```{c}
for (KDateNavigator *n : qAsConst(mExtraViews)) {
        baseDate = baseDate.addMonths(1);
        if (!mIgnoreNavigatorUpdates) {
            n->setBaseDate(baseDate);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &a : attendees) {
        const QString email = a.email();
        if (email.isEmpty()) {
            continue;
        }

        // In case we (as one of our identities) are the organizer we are sending
        // this mail. We could also have added ourselves as an attendee, in which
        // case we don't want to send ourselves a notification mail.
        if (organizerEmail == email) {
            continue;
        }

        // Build a nice address for this attendee including the CN.
        QString tname, temail;
        const QString username = KEmailAddress::quoteNameIfNecessary(a.name());
        // ignore the return value from extractEmailAddressAndName() because
        // it will always be false since tusername does not contain "@domain".
        KEmailAddress::extractEmailAddressAndName(username, temail /*byref*/, tname /*byref*/);
        tname += QLatin1String(" <") + email + QLatin1Char('>');

        // Optional Participants and Non-Participants are copied on the email
        if (a.role() == KCalendarCore::Attendee::OptParticipant || a.role() == KCalendarCore::Attendee::NonParticipant) {
            ccList << tname;
        } else {
            toList << tname;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &regionCode : regions) {
        const QString name = KHolidays::HolidayRegion::name(regionCode);
        const QLocale locale(KHolidays::HolidayRegion::languageCode(regionCode));
        const QString languageName = QLocale::languageToString(locale.language());
        QString label;
        if (languageName.isEmpty()) {
            label = name;
        } else {
            label = i18nc("@item:inlistbox Holiday region, region language", "%1 (%2)", name, languageName);
        }
        regionsMap.push_back(std::make_pair(label, regionCode));
    }
```

#### AUTO 


```{c}
const auto delKey = new QShortcut(QKeySequence(Qt::Key_Delete), this);
```

#### AUTO 


```{c}
auto dw = new KDirWatch(this);
```

#### AUTO 


```{c}
auto w = new KPrefsWidTime(item, parent);
```

#### LAMBDA EXPRESSION 


```{c}
[](KJob *job) {
                    if (job->error()) {
                        KMessageBox::detailedSorry(nullptr, i18n("Failed to retrieve incidence from Akonadi"), job->errorText());
                        return;
                    }
                    auto fetchJob = static_cast<Akonadi::ItemFetchJob*>(job);
                    if (fetchJob->count() != 1) {
                        KMessageBox::sorry(nullptr, i18n("Failed to retrieve incidence from Akonadi: requested incidence doesn't exist."));
                        return;
                    }
                    KOrg::MainWindow *korg = ActionManager::findInstance(QUrl());
                    korg->actionManager()->view()->showIncidence(fetchJob->items().first());
               }
```

#### AUTO 


```{c}
auto fetchJob = static_cast<Akonadi::ItemFetchJob *>(job);
```

#### AUTO 


```{c}
auto *format = new KCalendarCore::ICalFormat;
```

#### AUTO 


```{c}
auto e2 = new Event;
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalCore::Event::Ptr &event : eventlist) {
        if (mEvents.count() == NUMDAYS) {
            // No point in wasting cpu, all days are bold already
            break;
        }

        Q_ASSERT(event);
        const ushort recurType = event->recurrenceType();
        const QDateTime dtStart = event->dtStart().toLocalTime();

        // timed incidences occur in
        //   [dtStart(), dtEnd()[. All-day incidences occur in [dtStart(), dtEnd()]
        // so we subtract 1 second in the timed case
        const int secsToAdd = event->allDay() ? 0 : -1;
        const QDateTime dtEnd = event->dtEnd().toLocalTime().addSecs(secsToAdd);

        if (!(recurType == KCalCore::Recurrence::rDaily &&
              !KOPrefs::instance()->mDailyRecur) &&
            !(recurType == KCalCore::Recurrence::rWeekly &&
              !KOPrefs::instance()->mWeeklyRecur)) {
            KCalCore::SortableList<QDateTime> timeDateList;
            const bool isRecurrent = event->recurs();
            const int eventDuration = dtStart.daysTo(dtEnd);

            if (isRecurrent) {
                //Its a recurring event, find out in which days it occurs
                timeDateList = event->recurrence()->timesInInterval(
                    QDateTime(mDays[0], {}, Qt::LocalTime),
                    QDateTime(mDays[NUMDAYS - 1], {}, Qt::LocalTime));
            } else {
                if (dtStart.date() >= mDays[0]) {
                    timeDateList.append(dtStart);
                } else {
                    // The event starts in another month (not visible))
                    timeDateList.append(QDateTime(mDays[0], {}, Qt::LocalTime));
                }
            }

            for (auto t = timeDateList.begin(); t != timeDateList.end(); ++t) {
                //This could be a multiday event, so iterate from dtStart() to dtEnd()
                QDate d = t->toLocalTime().date();
                int j = 0;

                QDate occurrenceEnd;
                if (isRecurrent) {
                    occurrenceEnd = d.addDays(eventDuration);
                } else {
                    occurrenceEnd = dtEnd.date();
                }

                do {
                    mEvents.append(d);
                    ++j;
                    d = d.addDays(1);
                } while (d <= occurrenceEnd && j < NUMDAYS);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Event::Ptr &ev : events) {
            // Optionally, show only my Events
            /* if ( mShowMineOnly &&
                    !KCalendarCore::CalHelper::isMyCalendarIncidence( mCalendarAdaptor, ev. ) ) {
              // FIXME; does isMyCalendarIncidence work !? It's deprecated too.
              continue;
              }
              // TODO: CalHelper is deprecated, remove this?
              */

            if (ev->customProperty("KABC", "BIRTHDAY") == QLatin1String("YES")) {
                // Skipping, because these are got by the BirthdaySearchJob
                // See comments in updateView()
                continue;
            }

            if (!ev->categoriesStr().isEmpty()) {
                QStringList::ConstIterator it2;
                const QStringList c = ev->categories();
                QStringList::ConstIterator end(c.constEnd());
                for (it2 = c.constBegin(); it2 != end; ++it2) {
                    const QString itUpper((*it2).toUpper());
                    // Append Birthday Event?
                    if (mShowBirthdaysFromCal && (itUpper == QLatin1String("BIRTHDAY"))) {
                        SDEntry entry;
                        entry.type = IncidenceTypeEvent;
                        entry.category = CategoryBirthday;
                        entry.date = dt;
                        entry.summary = ev->summary();
                        entry.desc = ev->description();
                        dateDiff(ev->dtStart().date(), entry.daysTo, entry.yearsOld);
                        entry.span = 1;

                        /* The following check is to prevent duplicate entries,
                         * so in case of having a KCal incidence with category birthday
                         * with summary and date equal to some KABC Attendee we don't show it
                         * FIXME: port to akonadi, it's kresource based
                         * */
                        if (/*!check( bdayRes, dt, ev->summary() )*/ true) {
                            mDates.append(entry);
                        }
                        break;
                    }

                    // Append Anniversary Event?
                    if (mShowAnniversariesFromCal && (itUpper == QLatin1String("ANNIVERSARY"))) {
                        SDEntry entry;
                        entry.type = IncidenceTypeEvent;
                        entry.category = CategoryAnniversary;
                        entry.date = dt;
                        entry.summary = ev->summary();
                        entry.desc = ev->description();
                        dateDiff(ev->dtStart().date(), entry.daysTo, entry.yearsOld);
                        entry.span = 1;
                        if (/*!check( annvRes, dt, ev->summary() )*/ true) {
                            mDates.append(entry);
                        }
                        break;
                    }

                    // Append Holiday Event?
                    if (mShowHolidays && (itUpper == QLatin1String("HOLIDAY"))) {
                        SDEntry entry;
                        entry.type = IncidenceTypeEvent;
                        entry.category = CategoryHoliday;
                        entry.date = dt;
                        entry.summary = ev->summary();
                        entry.desc = ev->description();
                        dateDiff(dt, entry.daysTo, entry.yearsOld);
                        entry.yearsOld = -1; //ignore age of holidays
                        entry.span = span(ev);
                        if (entry.span > 1 && dayof(ev, dt) > 1) {     // skip days 2,3,...
                            break;
                        }
                        mDates.append(entry);
                        break;
                    }

                    // Append Special Occasion Event?
                    if (mShowSpecialsFromCal && (itUpper == QLatin1String("SPECIAL OCCASION"))) {
                        SDEntry entry;
                        entry.type = IncidenceTypeEvent;
                        entry.category = CategoryOther;
                        entry.date = dt;
                        entry.summary = ev->summary();
                        entry.desc = ev->description();
                        dateDiff(dt, entry.daysTo, entry.yearsOld);
                        entry.yearsOld = -1; //ignore age of special occasions
                        entry.span = span(ev);
                        if (entry.span > 1 && dayof(ev, dt) > 1) {     // skip days 2,3,...
                            break;
                        }
                        mDates.append(entry);
                        break;
                    }
                }
            }
        }
```

#### AUTO 


```{c}
auto *createevent = menu.findChild<QAction *>(QStringLiteral("createevent"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalCore::Todo::Ptr &t : incidences) {
        if (mEvents.count() == NUMDAYS) {
            // No point in wasting cpu, all days are bold already
            break;
        }
        Q_ASSERT(t);
        if (t->hasDueDate()) {
            ushort recurType = t->recurrenceType();

            if (t->recurs()
                && !(recurType == KCalCore::Recurrence::rDaily
                     && !KOPrefs::instance()->mDailyRecur)
                && !(recurType == KCalCore::Recurrence::rWeekly
                     && !KOPrefs::instance()->mWeeklyRecur)) {
                // It's a recurring todo, find out in which days it occurs
                const auto timeDateList
                    = t->recurrence()->timesInInterval(
                          QDateTime(mDays[0], {}, Qt::LocalTime),
                          QDateTime(mDays[NUMDAYS - 1], {}, Qt::LocalTime));

                for (const QDateTime &dt : timeDateList) {
                    d = dt.toLocalTime().date();
                    if (!mEvents.contains(d)) {
                        mEvents.append(d);
                    }
                }
            } else {
                d = t->dtDue().toLocalTime().date();
                if (d >= mDays[0] && d <= mDays[NUMDAYS - 1] && !mEvents.contains(d)) {
                    mEvents.append(d);
                }
            }
        }
    }
```

#### AUTO 


```{c}
auto *fetchJob = static_cast<Akonadi::CollectionFetchJob *>(job);
```

#### AUTO 


```{c}
auto *helpEvent = static_cast<QHelpEvent *>(event);
```

#### AUTO 


```{c}
auto config = KSharedConfig::openConfig();
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalCore::Attendee &attendee : lstAttendees) {
                if (re.indexIn(attendee.fullName()) != -1) {
                    mMatchedEvents.append(item);
                    break;
                }
            }
```

#### AUTO 


```{c}
const auto *v3 = qstyleoption_cast<const QStyleOptionViewItem *>(&option)
```

#### AUTO 


```{c}
auto *w = new KPrefsWidInt(item, parent);
```

#### AUTO 


```{c}
auto *holidayLabel = new QLabel(i18nc("@label", "Use holiday region:"), holidayRegBox);
```

#### LAMBDA EXPRESSION 


```{c}
[=](bool){mCalendarView->schedule_request();}
```

#### AUTO 


```{c}
auto w = new QWidget(this);
```

#### AUTO 


```{c}
auto *pluginFactory = static_cast<KOrg::PartFactory *>(factory);
```

#### AUTO 


```{c}
const auto installedEntries = dialog->installedEntries();
```

#### AUTO 


```{c}
auto aTransportLabel = new QLabel(
        i18nc("@label", "Mail transport:"), topFrame);
```

#### AUTO 


```{c}
auto *intItem = dynamic_cast<KConfigSkeleton::ItemInt *>(item);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &regionCode : regions) {
            const QString name = KHolidays::HolidayRegion::name(regionCode);
            const QLocale locale(KHolidays::HolidayRegion::languageCode(regionCode));
            const QString languageName = QLocale::languageToString(locale.language());
            QString label;
            if (languageName.isEmpty()) {
                label = name;
            } else {
                label = i18nc("@item:inlistbox Holiday region, region language", "%1 (%2)",
                              name, languageName);
            }
            regionsMap.insert(label, regionCode);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Node::Ptr &proxyNode : qAsConst(mProxyNodes)) {
            if (proxyNode->isDuplicateOf(descendant)) {
                //Removenode from proxy
                if (!proxyNode->parent) {
                    qCWarning(KORGANIZER_LOG) <<  objectName()
                                              <<
                        "Found proxy that is already not part of the model " << proxyNode->data(
                        Qt::DisplayRole).toString();
                    continue;
                }
                const int targetRow = proxyNode->row();
                beginRemoveRows(index(proxyNode->parent), targetRow, targetRow);
                proxyNode->parent->children.remove(targetRow);
                proxyNode->parent = nullptr;
                endRemoveRows();
            }
        }
```

#### AUTO 


```{c}
auto *pluginFactory
        = static_cast<KOrg::PartFactory *>(factory);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &instance : mCalendar->instances(inc)) {
        KCalendarCore::Incidence::Ptr oldInstance(instance->clone());
        instance->setRelatedTo(QString());
        (void) mChanger->modifyIncidence(mCalendar->item(instance), oldInstance, this);
    }
```

#### AUTO 


```{c}
auto rightBoxVBoxLayout = new QVBoxLayout(rightBox);
```

#### AUTO 


```{c}
auto sync = new Akonadi::CollectionAttributesSynchronizationJob(col);
```

#### AUTO 


```{c}
auto fetchJob = static_cast<Akonadi::ItemFetchJob*>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalCore::Incidence::Ptr &ev : incidences) {
        Q_ASSERT(ev);
        Akonadi::Item item = m_calendarview->calendar()->item(ev->uid());
        if (m_ui->summaryCheck->isChecked()) {
            if (re.indexIn(ev->summary()) != -1) {
                mMatchedEvents.append(item);
                continue;
            }
        }
        if (m_ui->descriptionCheck->isChecked()) {
            if (re.indexIn(ev->description()) != -1) {
                mMatchedEvents.append(item);
                continue;
            }
        }
        if (m_ui->categoryCheck->isChecked()) {
            if (re.indexIn(ev->categoriesStr()) != -1) {
                mMatchedEvents.append(item);
                continue;
            }
        }
        if (m_ui->locationCheck->isChecked()) {
            if (re.indexIn(ev->location()) != -1) {
                mMatchedEvents.append(item);
                continue;
            }
        }
        if (m_ui->attendeeCheck->isChecked()) {
            Q_FOREACH (const KCalCore::Attendee::Ptr &attendee, ev->attendees()) {
                if (re.indexIn(attendee->fullName()) != -1) {
                    mMatchedEvents.append(item);
                    break;
                }
            }
        }
    }
```

#### AUTO 


```{c}
auto *menu = new QMenu(mYear);
```

#### LAMBDA EXPRESSION 


```{c}
[=](bool) {
        mCalendarView->schedule_counter();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalCore::Todo::Ptr &todo : todos) {
        Q_ASSERT(todo);
        const KCalCore::Attendee::List attendees = todo->attendees();
        if (!attendees.isEmpty()) {
            Akonadi::ContactSearchJob *job = new Akonadi::ContactSearchJob(this);
            job->setQuery(Akonadi::ContactSearchJob::Email, todo->organizer()->email());
            job->setProperty("incidenceUid", todo->uid());
            connect(job, &Akonadi::ContactSearchJob::result, this, &HtmlExportJob::receivedOrganizerInfo);
            job->start();

            d->mSubJobCount++;
            canExportItem = true;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QEvent *e : qAsConst(mTypeAheadEvents)) {
            QApplication::sendEvent(mTypeAheadReceiver, e);
        }
```

#### AUTO 


```{c}
auto fetchJob = new Akonadi::CollectionFetchJob(Akonadi::Collection(1), Akonadi::CollectionFetchJob::FirstLevel);
```

#### AUTO 


```{c}
auto lbl = new QLabel(txt, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Todo::Ptr &todo : alltodos) {
                Q_ASSERT(todo);
                if ((!todo->hasStartDate() && !todo->hasDueDate())    // undated
                    || (todo->hasStartDate()
                        && (todo->dtStart().toLocalTime().date() >= startDt)
                        && (todo->dtStart().toLocalTime().date() <= endDt)) //start dt in range
                    || (todo->hasDueDate()
                        && (todo->dtDue().toLocalTime().date() >= startDt)
                        && (todo->dtDue().toLocalTime().date() <= endDt)) //due dt in range
                    || (todo->hasCompletedDate()
                        && (todo->completed().toLocalTime().date() >= startDt)
                        && (todo->completed().toLocalTime().date() <= endDt))) { //completed dt in range
                    todos.append(todo);
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (KCalCore::CalFilter *filter : qAsConst(mFilters)) {
        filterList << filter->name();
        KConfigGroup filterConfig(config, QStringLiteral("Filter_") + filter->name());
        filterConfig.writeEntry("Criteria", filter->criteria());
        filterConfig.writeEntry("CategoryList", filter->categoryList());
        filterConfig.writeEntry("HideTodoDays", filter->completedTimeSpan());
    }
```

#### AUTO 


```{c}
auto *fontLayout = new QGridLayout(fontFrame);
```

#### AUTO 


```{c}
auto systrayGroupLayout = new QVBoxLayout;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &plugin : plugins) {
            QString name = plugin.pluginId();
            if (selectedPlugins.contains(name)) {
                EventViews::CalendarDecoration::Decoration *d = loadCalendarDecoration(plugin);
                mCalendarDecorations.append(d);
            }
        }
```

#### AUTO 


```{c}
auto *w = new KPrefsWidFont(item, parent, sampleText);
```

#### RANGE FOR STATEMENT 


```{c}
for (KDateNavigator *n : qAsConst(mExtraViews)) {
        if (n) {
            n->setUpdateNeeded();
        }
    }
```

#### AUTO 


```{c}
auto *otherLayout = new QVBoxLayout;
```

#### RANGE FOR STATEMENT 


```{c}
for (const Node::Ptr &proxyNode : qAsConst(mProxyNodes)) {
        // qCDebug(KORGANIZER_LOG) << "checking " << proxyNode->data(Qt::DisplayRole).toString();
        // Avoid inserting a node that is already part of the source model
        if (isDuplicate(proxyNode)) {
            continue;
        }
        insertProxyNode(proxyNode);
        reparentSourceNodes(proxyNode);
    }
```

#### AUTO 


```{c}
auto n = new KDateNavigator(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &str : checkedItems) {
            int index = mHolidayCheckCombo->findText(str);
            if (index >= 0) {
                HolidayRegions.append(mHolidayCheckCombo->itemData(index).toString());
            }
        }
```

#### AUTO 


```{c}
auto incidence = CalendarSupport::incidence(todoItem);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KHolidays::HolidayRegion *region : qAsConst(mHolidayRegions)) {
        if (region && region->isValid()) {
            const KHolidays::Holiday::List list = region->holidays(start, end);
            const int listCount(list.count());
            for (int i = 0; i < listCount; ++i) {
                const KHolidays::Holiday &h = list.at(i);
                // dedupe, since we support multiple holiday regions which may have similar holidays
                if (!holidaysByDate[h.observedStartDate()].contains(h.name())) {
                    holidaysByDate[h.observedStartDate()].append(h.name());
                }
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QLabel *label : qAsConst(mLabels)) {
        mLayout->removeWidget(label);
        delete (label);
        update();
    }
```

#### AUTO 


```{c}
const auto lst = parser.positionalArguments();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &url : md->urls()) {
            if (url.scheme() == QStringLiteral("akonadi") && url.hasQuery()) {
                const QUrlQuery query(url.query());
                if (!query.queryItemValue(QStringLiteral("item")).isEmpty()
                    && query.queryItemValue(QStringLiteral("type")) == QStringLiteral("message/rfc822")) {
                    auto job = new Akonadi::ItemFetchJob(Akonadi::Item(static_cast<qint64>(query.queryItemValue(QStringLiteral("item")).toLongLong())));
                    job->fetchScope().fetchAllAttributes();
                    job->fetchScope().fetchFullPayload(true);
                    connect(job, &KJob::result, this, [this, url](KJob *job) {
                        if (job->error()) {
                            return;
                        }
                        auto fetchJob = qobject_cast<Akonadi::ItemFetchJob *>(job);
                        const Akonadi::Item::List items = fetchJob->items();
                        for (const Akonadi::Item &item : items) {
                            if (item.mimeType() == QStringLiteral("message/rfc822")) {
                                auto mail = item.payload<KMime::Message::Ptr>();
                                interface()->openTodoEditor(i18nc("Event from email summary", "Mail: %1", mail->subject()->asUnicodeString()),
                                                            i18nc("Event from email content",
                                                                  "<b>From:</b> %1<br /><b>To:</b> %2<br /><b>Subject:</b> %3",
                                                                  mail->from()->displayString(),
                                                                  mail->to()->displayString(),
                                                                  mail->subject()->asUnicodeString()),
                                                            url.toDisplayString(),
                                                            QString(),
                                                            QStringList(),
                                                            QStringLiteral("message/rfc822"));
                            }
                        }
                    });
                }
                return;
            }
        }
```

#### AUTO 


```{c}
auto *qsm = new QItemSelectionModel(columnFilterProxy, columnFilterProxy);
```

#### AUTO 


```{c}
auto item = action->data().value<PluginItem *>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const ReparentingModel::Node::Ptr &node : nodes) {
        addNode(node);
    }
```

#### AUTO 


```{c}
const auto url = QUrl{parser.value(QStringLiteral("view"))};
```

#### AUTO 


```{c}
auto reminderItem = dynamic_cast<ReminderTreeItem *>(item);
```

#### AUTO 


```{c}
auto *progressBar
        = new KPIM::ProgressStatusBarWidget(statusBar(), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (QLabel *label : qAsConst(mLabels)) {
        mLayout->removeWidget(label);
        delete(label);
        update();
    }
```

#### AUTO 


```{c}
auto w = new KPrefsWidFont(item, parent, sampleText);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &url : parser.positionalArguments()) {
            korg->actionManager()->importURL(QUrl::fromUserInput(url), true);
        }
```

#### AUTO 


```{c}
auto *e2 = new Event;
```

#### RANGE FOR STATEMENT 


```{c}
for (const Alarm::Ptr &alarm : alarms) {
            const QString uid = alarm->parentUid();
            const Akonadi::Item::Id id = mCalendar->item(uid).id();
            const Akonadi::Item item = mCalendar->item(id);

            const Incidence::Ptr incidence = CalendarSupport::incidence(item);
            const QString summary = incidence->summary();

            const QDateTime time = incidence->dateTime(Incidence::RoleAlarm);
            lst << QStringLiteral("%1: \"%2\" (alarm text \"%3\")").arg(time.toString(Qt::ISODate), summary, alarm->text());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalCore::Todo::Ptr &todo : todos) {
        if (todo->hasDueDate()) {
            const int daysTo = currDate.daysTo(todo->dtDue().date());
            if (daysTo >= mDaysToGo) {
                continue;
            }
        }

        if (mHideOverdue && todo->isOverdue()) {
            continue;
        }
        if (mHideInProgress && todo->isInProgress(false)) {
            continue;
        }
        if (mHideCompleted && todo->isCompleted()) {
            continue;
        }
        if (mHideOpenEnded && todo->isOpenEnded()) {
            continue;
        }
        if (mHideNotStarted && todo->isNotStarted(false)) {
            continue;
        }

        prList.append(todo);
    }
```

#### AUTO 


```{c}
auto disposition = new KMime::Headers::ContentDisposition;
```

#### AUTO 


```{c}
auto suspendBox = new QWidget(topBox);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Node::Ptr &c : qAsConst(node->parent->children)) {
        if (c.data() == node) {
            return row;
        }
        row++;
    }
```

#### AUTO 


```{c}
const auto eventEnd = ev->dtEnd().toLocalTime();
```

#### AUTO 


```{c}
auto fetchJob = new Akonadi::ItemFetchJob(Akonadi::Item::fromUrl(url), this);
```

#### LAMBDA EXPRESSION 


```{c}
[this, urlLabel] {
            viewEvent(urlLabel->url());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalCore::Event::Ptr &ev : events) {
            // Optionally, show only my Events
            /* if ( mShowMineOnly &&
                    !KCalCore::CalHelper::isMyCalendarIncidence( mCalendarAdaptor, ev. ) ) {
              // FIXME; does isMyCalendarIncidence work !? It's deprecated too.
              continue;
              }
              // TODO: CalHelper is deprecated, remove this?
              */

            if (ev->customProperty("KABC", "BIRTHDAY") == QLatin1String("YES")) {
                // Skipping, because these are got by the BirthdaySearchJob
                // See comments in updateView()
                continue;
            }

            if (!ev->categoriesStr().isEmpty()) {
                QStringList::ConstIterator it2;
                const QStringList c = ev->categories();
                QStringList::ConstIterator end(c.constEnd());
                for (it2 = c.constBegin(); it2 != end; ++it2) {

                    const QString itUpper((*it2).toUpper());
                    // Append Birthday Event?
                    if (mShowBirthdaysFromCal && (itUpper == QLatin1String("BIRTHDAY"))) {
                        SDEntry entry;
                        entry.type = IncidenceTypeEvent;
                        entry.category = CategoryBirthday;
                        entry.date = dt;
                        entry.summary = ev->summary();
                        entry.desc = ev->description();
                        dateDiff(ev->dtStart().date(), entry.daysTo, entry.yearsOld);
                        entry.span = 1;

                        /* The following check is to prevent duplicate entries,
                         * so in case of having a KCal incidence with category birthday
                         * with summary and date equal to some KABC Atendee we don't show it
                         * FIXME: port to akonadi, it's kresource based
                         * */
                        if (/*!check( bdayRes, dt, ev->summary() )*/true) {
                            mDates.append(entry);
                        }
                        break;
                    }

                    // Append Anniversary Event?
                    if (mShowAnniversariesFromCal && (itUpper == QStringLiteral("ANNIVERSARY"))) {
                        SDEntry entry;
                        entry.type = IncidenceTypeEvent;
                        entry.category = CategoryAnniversary;
                        entry.date = dt;
                        entry.summary = ev->summary();
                        entry.desc = ev->description();
                        dateDiff(ev->dtStart().date(), entry.daysTo, entry.yearsOld);
                        entry.span = 1;
                        if (/*!check( annvRes, dt, ev->summary() )*/true) {
                            mDates.append(entry);
                        }
                        break;
                    }

                    // Append Holiday Event?
                    if (mShowHolidays && (itUpper == QLatin1String("HOLIDAY"))) {
                        SDEntry entry;
                        entry.type = IncidenceTypeEvent;
                        entry.category = CategoryHoliday;
                        entry.date = dt;
                        entry.summary = ev->summary();
                        entry.desc = ev->description();
                        dateDiff(dt, entry.daysTo, entry.yearsOld);
                        entry.yearsOld = -1; //ignore age of holidays
                        entry.span = span(ev);
                        if (entry.span > 1 && dayof(ev, dt) > 1) {     // skip days 2,3,...
                            break;
                        }
                        mDates.append(entry);
                        break;
                    }

                    // Append Special Occasion Event?
                    if (mShowSpecialsFromCal && (itUpper == QLatin1String("SPECIAL OCCASION"))) {
                        SDEntry entry;
                        entry.type = IncidenceTypeEvent;
                        entry.category = CategoryOther;
                        entry.date = dt;
                        entry.summary = ev->summary();
                        entry.desc = ev->description();
                        dateDiff(dt, entry.daysTo, entry.yearsOld);
                        entry.yearsOld = -1; //ignore age of special occasions
                        entry.span = span(ev);
                        if (entry.span > 1 && dayof(ev, dt) > 1) {     // skip days 2,3,...
                            break;
                        }
                        mDates.append(entry);
                        break;
                    }
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (KDateNavigator *n : std::as_const(mExtraViews)) {
                if (n) {
                    n->show();
                }
            }
```

#### AUTO 


```{c}
auto *holidaysLayout = new QGridLayout(holidaysGroupBox);
```

#### AUTO 


```{c}
auto w = new KPrefsWidInt(item, parent);
```

#### AUTO 


```{c}
auto *regionalLayout = new QGridLayout(regionalPage);
```

#### RANGE FOR STATEMENT 


```{c}
for (Node *n : qAsConst(mSourceNodes)) {
        if (proxyNode->adopts(n->sourceIndex)) {
            //qCDebug(KORGANIZER_LOG) << "reparenting" << n->data(Qt::DisplayRole).toString() << "from" << n->parent->data(Qt::DisplayRole).toString()
            //         << "to" << proxyNode->data(Qt::DisplayRole).toString();

            //WARNING: While a beginMoveRows/endMoveRows would be more suitable, QSortFilterProxyModel can't deal with that. Therefore we
            //cannot use them.
            const int oldRow = n->row();
            beginRemoveRows(index(n->parent), oldRow, oldRow);
            Node::Ptr nodePtr = proxyNode->searchNode(n);
            //We lie about the row being removed already, but the view can deal with that better than if we call endRemoveRows after beginInsertRows
            endRemoveRows();

            const int newRow = proxyNode->children.size();
            beginInsertRows(index(proxyNode.data()), newRow, newRow);
            proxyNode->addChild(nodePtr);
            endInsertRows();
            Q_ASSERT(validateNode(n));
        }
    }
```

#### AUTO 


```{c}
auto *createjob = static_cast<Akonadi::AgentInstanceCreateJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &email : splittedEmail) {
        const QString str =
            KEmailAddress::extractEmailAddress(KEmailAddress::normalizeAddressesAndEncodeIdn(email));
        normalizedEmail << str;
    }
```

#### AUTO 


```{c}
auto hbox = new QHBoxLayout();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { printTodo();}
```

#### RANGE FOR STATEMENT 


```{c}
for (Akonadi::StandardCalendarActionManager::Type calendarAction :
             qAsConst(calendarActions)) {
            mActionManager->createAction(calendarAction);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Todo::Ptr &t : incidences) {
        if (mEvents.count() == NUMDAYS) {
            // No point in wasting cpu, all days are bold already
            break;
        }
        Q_ASSERT(t);
        if (t->hasDueDate()) {
            ushort recurType = t->recurrenceType();

            if (t->recurs() && !(recurType == KCalendarCore::Recurrence::rDaily && !KOPrefs::instance()->mDailyRecur)
                && !(recurType == KCalendarCore::Recurrence::rWeekly && !KOPrefs::instance()->mWeeklyRecur)) {
                // It's a recurring todo, find out in which days it occurs
                const auto timeDateList =
                    t->recurrence()->timesInInterval(QDateTime(mDays[0], {}, Qt::LocalTime), QDateTime(mDays[NUMDAYS - 1], {}, Qt::LocalTime));

                for (const QDateTime &dt : timeDateList) {
                    d = dt.toLocalTime().date();
                    if (!mEvents.contains(d)) {
                        mEvents.append(d);
                    }
                }
            } else {
                d = t->dtDue().toLocalTime().date();
                if (d >= mDays[0] && d <= mDays[NUMDAYS - 1] && !mEvents.contains(d)) {
                    mEvents.append(d);
                }
            }
        }
    }
```

#### AUTO 


```{c}
auto dialog = new QDialog(parent);
```

#### RANGE FOR STATEMENT 


```{c}
for (KDateNavigator *n : qAsConst(mExtraViews)) {
        if (n) {
            n->setCalendar(calendar);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, url](KJob *job) {
                        if (job->error()) {
                            return;
                        }
                        Akonadi::ItemFetchJob *fetchJob = qobject_cast<Akonadi::ItemFetchJob *>(job);
                        const Akonadi::Item::List items = fetchJob->items();
                        for (const Akonadi::Item &item : items) {
                            if (item.mimeType() == QStringLiteral("message/rfc822")) {
                                auto mail = item.payload<KMime::Message::Ptr>();
                                interface()->openTodoEditor(i18nc("Event from email summary", "Mail: %1", mail->subject()->asUnicodeString()),
                                                            i18nc("Event from email content",
                                                                  "<b>From:</b> %1<br /><b>To:</b> %2<br /><b>Subject:</b> %3",
                                                                  mail->from()->displayString(),
                                                                  mail->to()->displayString(),
                                                                  mail->subject()->asUnicodeString()),
                                                            url.toDisplayString(),
                                                            QString(),
                                                            QStringList(),
                                                            QStringLiteral("message/rfc822"));
                            }
                        }
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for (SummaryEventInfo *event : events) {
        // Optionally, show only my Events
        /*      if ( mShowMineOnly &&
                  !KCalendarCore::CalHelper::isMyCalendarIncidence( mCalendarAdaptor, event->ev ) ) {
              continue;
            }
            TODO: CalHelper is deprecated, remove this?
        */

        KCalendarCore::Event::Ptr ev = event->ev;
        // print the first of the recurring event series only
        if (ev->recurs()) {
            if (uidList.contains(ev->instanceIdentifier())) {
                continue;
            }
            uidList.append(ev->instanceIdentifier());
        }

        // Icon label
        label = new QLabel(this);
        if (ev->categories().contains(QLatin1String("BIRTHDAY"), Qt::CaseInsensitive)) {
            label->setPixmap(pmb);
        } else if (ev->categories().contains(QLatin1String("ANNIVERSARY"), Qt::CaseInsensitive)) {
            label->setPixmap(pma);
        } else {
            label->setPixmap(pm);
        }
        label->setMaximumWidth(label->minimumSizeHint().width());
        mLayout->addWidget(label, counter, 0);
        mLabels.append(label);

        // Start date or date span label
        QString dateToDisplay = event->startDate;
        if (!event->dateSpan.isEmpty()) {
            dateToDisplay = event->dateSpan;
        }
        label = new QLabel(dateToDisplay, this);
        label->setAlignment(Qt::AlignLeft | Qt::AlignVCenter);
        mLayout->addWidget(label, counter, 1);
        mLabels.append(label);
        if (event->makeBold) {
            QFont font = label->font();
            font.setBold(true);
            label->setFont(font);
            if (!event->makeUrgent) {
                label->setPalette(todayPalette);
            } else {
                label->setPalette(urgentPalette);
            }
            label->setAutoFillBackground(true);
        }

        // Days to go label
        label = new QLabel(event->daysToGo, this);
        label->setAlignment(Qt::AlignLeft | Qt::AlignVCenter);
        mLayout->addWidget(label, counter, 2);
        mLabels.append(label);

        // Summary label
        KUrlLabel *urlLabel = new KUrlLabel(this);
        urlLabel->setText(event->summaryText);
        urlLabel->setUrl(event->summaryUrl);
        urlLabel->installEventFilter(this);
        urlLabel->setTextFormat(Qt::RichText);
        urlLabel->setWordWrap(true);
        mLayout->addWidget(urlLabel, counter, 3);
        mLabels.append(urlLabel);
        connect(urlLabel, &KUrlLabel::leftClickedUrl, this, [this, urlLabel] {
            viewEvent(urlLabel->url());
        });
        connect(urlLabel, &KUrlLabel::rightClickedUrl, this, [this, urlLabel] {
            popupMenu(urlLabel->url());
        });
        if (!event->summaryTooltip.isEmpty()) {
            urlLabel->setToolTip(event->summaryTooltip);
        }

        // Time range label (only for non-floating events)
        if (!event->timeRange.isEmpty()) {
            label = new QLabel(event->timeRange, this);
            label->setAlignment(Qt::AlignLeft | Qt::AlignVCenter);
            mLayout->addWidget(label, counter, 4);
            mLabels.append(label);
        }

        counter++;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const auto &lhs, const auto &rhs) {
        return lhs.first < rhs.first;
    }
```

#### AUTO 


```{c}
auto annotationsAttribute = collection.attribute<PimCommon::CollectionAnnotationsAttribute>(Collection::AddIfMissing);
```

#### AUTO 


```{c}
auto job = new Akonadi::ItemFetchJob(Akonadi::Item::fromUrl(res));
```

#### AUTO 


```{c}
const auto checkedItems = mHolidayCheckCombo->checkedItems();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &descendant : list) {
        Q_FOREACH (const Node::Ptr &proxyNode, mProxyNodes) {
            if (proxyNode->isDuplicateOf(descendant)) {
                //Removenode from proxy
                if (!proxyNode->parent) {
                    qCWarning(KORGANIZER_LOG) <<  objectName() << "Found proxy that is already not part of the model " << proxyNode->data(Qt::DisplayRole).toString();
                    continue;
                }
                const int targetRow = proxyNode->row();
                beginRemoveRows(index(proxyNode->parent), targetRow, targetRow);
                proxyNode->parent->children.remove(targetRow);
                proxyNode->parent = 0;
                endRemoveRows();
            }
        }
    }
```

#### AUTO 


```{c}
auto pageItem = static_cast<PageItem *>(item->parent() ? item->parent() : item);
```

#### AUTO 


```{c}
auto *w = new KPrefsWidPath(item, parent, filter, mode);
```

#### AUTO 


```{c}
auto *vbox = new QVBoxLayout(this);
```

#### AUTO 


```{c}
auto emailSettingsLayout = new QFormLayout(mUserEmailSettings);
```

#### RANGE FOR STATEMENT 


```{c}
for (QLabel *label : qAsConst(mLabels)) {
        label->show();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : items) {
                            if (item.mimeType() == QStringLiteral("message/rfc822")) {
                                auto mail = item.payload<KMime::Message::Ptr>();
                                interface()->openEventEditor(i18nc("Event from email summary", "Mail: %1", mail->subject()->asUnicodeString()),
                                                             i18nc("Event from email content",
                                                                   "<b>From:</b> %1<br /><b>To:</b> %2<br /><b>Subject:</b> %3",
                                                                   mail->from()->displayString(),
                                                                   mail->to()->displayString(),
                                                                   mail->subject()->asUnicodeString()),
                                                             url.toDisplayString(),
                                                             QString(),
                                                             QStringList(),
                                                             QStringLiteral("message/rfc822"));
                            }
                        }
```

#### AUTO 


```{c}
auto buttonBox = new QDialogButtonBox(
        QDialogButtonBox::Close | QDialogButtonBox::Help, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (QTreeWidgetItem *item : selectedItems) {
        auto pageItem = static_cast<PageItem *>(item->parent() ? item->parent() : item);
        if (KMessageBox::warningContinueCancel(
                this,
                i18n("<qt>Do you really want to delete '<b>%1</b>'?</qt>",
                     pageItem->text(0)), QString(),
                KStandardGuiItem::del()) == KMessageBox::Continue) {
            QFile::remove(pageItem->path());
        }
    }
```

#### AUTO 


```{c}
auto *disposition = new KMime::Headers::ContentDisposition;
```

#### AUTO 


```{c}
auto *w = new KPrefsWidTime(item, parent);
```

#### AUTO 


```{c}
auto mdisplayLayout = new QVBoxLayout;
```

#### RANGE FOR STATEMENT 


```{c}
for (SummaryEventInfo *event : events) {
        // Optionally, show only my Events
        /*      if ( mShowMineOnly &&
                  !KCalendarCore::CalHelper::isMyCalendarIncidence( mCalendarAdaptor, event->ev ) ) {
              continue;
            }
            TODO: CalHelper is deprecated, remove this?
        */

        KCalendarCore::Event::Ptr ev = event->ev;
        // print the first of the recurring event series only
        if (ev->recurs()) {
            if (uidList.contains(ev->instanceIdentifier())) {
                continue;
            }
            uidList.append(ev->instanceIdentifier());
        }

        // Icon label
        label = new QLabel(this);
        if (ev->categories().contains(QLatin1String("BIRTHDAY"), Qt::CaseInsensitive)) {
            label->setPixmap(pmb);
        } else if (ev->categories().contains(QLatin1String("ANNIVERSARY"), Qt::CaseInsensitive)) {
            label->setPixmap(pma);
        } else {
            label->setPixmap(pm);
        }
        label->setMaximumWidth(label->minimumSizeHint().width());
        mLayout->addWidget(label, counter, 0);
        mLabels.append(label);

        // Start date or date span label
        QString dateToDisplay = event->startDate;
        if (!event->dateSpan.isEmpty()) {
            dateToDisplay = event->dateSpan;
        }
        label = new QLabel(dateToDisplay, this);
        label->setAlignment(Qt::AlignLeft | Qt::AlignVCenter);
        mLayout->addWidget(label, counter, 1);
        mLabels.append(label);
        if (event->makeBold) {
            QFont font = label->font();
            font.setBold(true);
            label->setFont(font);
            if (!event->makeUrgent) {
                label->setPalette(todayPalette);
            } else {
                label->setPalette(urgentPalette);
            }
            label->setAutoFillBackground(true);
        }

        // Days to go label
        label = new QLabel(event->daysToGo, this);
        label->setAlignment(Qt::AlignLeft | Qt::AlignVCenter);
        mLayout->addWidget(label, counter, 2);
        mLabels.append(label);

        // Summary label
        KUrlLabel *urlLabel = new KUrlLabel(this);
        urlLabel->setText(event->summaryText);
        urlLabel->setUrl(event->summaryUrl);
        urlLabel->installEventFilter(this);
        urlLabel->setTextFormat(Qt::RichText);
        urlLabel->setWordWrap(true);
        mLayout->addWidget(urlLabel, counter, 3);
        mLabels.append(urlLabel);
#if KWIDGETSADDONS_VERSION < QT_VERSION_CHECK(5, 65, 0)
        connect(urlLabel, QOverload<const QString &>::of(
                    &KUrlLabel::leftClickedUrl), this, &ApptSummaryWidget::viewEvent);
        connect(urlLabel, QOverload<const QString &>::of(
                    &KUrlLabel::rightClickedUrl), this, &ApptSummaryWidget::popupMenu);
#else
        connect(urlLabel, &KUrlLabel::leftClickedUrl, this, [this, urlLabel] {
            viewEvent(urlLabel->url());
        });
        connect(urlLabel, &KUrlLabel::rightClickedUrl, this, [this, urlLabel] {
            popupMenu(urlLabel->url());
        });
#endif
        if (!event->summaryTooltip.isEmpty()) {
            urlLabel->setToolTip(event->summaryTooltip);
        }

        // Time range label (only for non-floating events)
        if (!event->timeRange.isEmpty()) {
            label = new QLabel(event->timeRange, this);
            label->setAlignment(Qt::AlignLeft | Qt::AlignVCenter);
            mLayout->addWidget(label, counter, 4);
            mLabels.append(label);
        }

        counter++;
    }
```

#### AUTO 


```{c}
auto *editor = menu.findChild<IncidenceEditorNG::IncidenceEditor *>();
```

#### AUTO 


```{c}
auto note = new QLabel(
        xi18nc("@info",
               "<note>The daemon will continue running even if it is not shown "
               "in the system tray.</note>"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalCore::Incidence::Ptr &inc : incidences) {
        Q_ASSERT(inc);
        QDate d = inc->dtStart().toLocalTime().date();
        if (inc->type() == KCalCore::Incidence::TypeJournal
            && d >= mDays[0]
            && d <= mDays[NUMDAYS - 1]
            && !mEvents.contains(d)) {
            mEvents.append(d);
        }
        if (mEvents.count() == NUMDAYS) {
            // No point in wasting cpu, all days are bold already
            break;
        }
    }
```

#### AUTO 


```{c}
const auto dateTime
                    = triggerDateForIncidence(incidence, item->mRemindAt, displayStr);
```

#### AUTO 


```{c}
auto *enumItem
        = dynamic_cast<KConfigSkeleton::ItemEnum *>(item);
```

#### AUTO 


```{c}
auto *holidayRegBoxHBoxLayout = new QHBoxLayout(holidayRegBox);
```

#### RANGE FOR STATEMENT 


```{c}
for (SummaryEventInfo *event : events) {
        // Optionally, show only my Events
        /*      if ( mShowMineOnly &&
                  !KCalendarCore::CalHelper::isMyCalendarIncidence( mCalendarAdaptor, event->ev ) ) {
              continue;
            }
            TODO: CalHelper is deprecated, remove this?
        */

        KCalendarCore::Event::Ptr ev = event->ev;
        // print the first of the recurring event series only
        if (ev->recurs()) {
            if (uidList.contains(ev->instanceIdentifier())) {
                continue;
            }
            uidList.append(ev->instanceIdentifier());
        }

        // Icon label
        label = new QLabel(this);
        if (ev->categories().contains(QLatin1String("BIRTHDAY"), Qt::CaseInsensitive)) {
            label->setPixmap(pmb);
        } else if (ev->categories().contains(QLatin1String("ANNIVERSARY"), Qt::CaseInsensitive)) {
            label->setPixmap(pma);
        } else {
            label->setPixmap(pm);
        }
        label->setMaximumWidth(label->minimumSizeHint().width());
        mLayout->addWidget(label, counter, 0);
        mLabels.append(label);

        // Start date or date span label
        QString dateToDisplay = event->startDate;
        if (!event->dateSpan.isEmpty()) {
            dateToDisplay = event->dateSpan;
        }
        label = new QLabel(dateToDisplay, this);
        label->setAlignment(Qt::AlignLeft | Qt::AlignVCenter);
        mLayout->addWidget(label, counter, 1);
        mLabels.append(label);
        if (event->makeBold) {
            QFont font = label->font();
            font.setBold(true);
            label->setFont(font);
            if (!event->makeUrgent) {
                label->setPalette(todayPalette);
            } else {
                label->setPalette(urgentPalette);
            }
            label->setAutoFillBackground(true);
        }

        // Days to go label
        label = new QLabel(event->daysToGo, this);
        label->setAlignment(Qt::AlignLeft | Qt::AlignVCenter);
        mLayout->addWidget(label, counter, 2);
        mLabels.append(label);

        // Summary label
        KUrlLabel *urlLabel = new KUrlLabel(this);
        urlLabel->setText(event->summaryText);
        urlLabel->setUrl(event->summaryUrl);
        urlLabel->installEventFilter(this);
        urlLabel->setTextFormat(Qt::RichText);
        urlLabel->setWordWrap(true);
        mLayout->addWidget(urlLabel, counter, 3);
        mLabels.append(urlLabel);

        connect(urlLabel, QOverload<const QString &>::of(
                    &KUrlLabel::leftClickedUrl), this, &ApptSummaryWidget::viewEvent);
        connect(urlLabel, QOverload<const QString &>::of(
                    &KUrlLabel::rightClickedUrl), this, &ApptSummaryWidget::popupMenu);
        if (!event->summaryTooltip.isEmpty()) {
            urlLabel->setToolTip(event->summaryTooltip);
        }

        // Time range label (only for non-floating events)
        if (!event->timeRange.isEmpty()) {
            label = new QLabel(event->timeRange, this);
            label->setAlignment(Qt::AlignLeft | Qt::AlignVCenter);
            mLayout->addWidget(label, counter, 4);
            mLabels.append(label);
        }

        counter++;
    }
```

#### AUTO 


```{c}
auto activeLabel = new QLabel(i18n("<a href=\"whatsthis:%1\">How does this work?</a>", cwHowto), this);
```

#### LAMBDA EXPRESSION 


```{c}
[=](bool){mCalendarView->schedule_cancel();}
```

#### AUTO 


```{c}
const auto item = static_cast<const ReminderTreeItem *>(&other);
```

#### RANGE FOR STATEMENT 


```{c}
for (const ReparentingModel::Node::Ptr &existing : std::as_const(mProxyNodes)) {
        if (*existing == *node) {
            existing->update(node);
            const QModelIndex i = index(existing.data());
            Q_EMIT dataChanged(i, i);
            return;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SummaryEventInfo *ev : eventsToday) {
        if (ev->summaryText == multidayWithTimeInProgress + QLatin1String(" (2/7)")) {
            QCOMPARE(ev->timeRange,
                     QStringLiteral("%1 - %2").arg(QLocale::system().toString(QTime(0, 0), QLocale::ShortFormat),
                                                   QLocale::system().toString(QTime(23, 59), QLocale::ShortFormat)));
            QCOMPARE(ev->startDate, QStringLiteral("Today"));
            QCOMPARE(ev->daysToGo, QStringLiteral("now"));
            QCOMPARE(ev->makeBold, true);
        } else if (ev->summaryText == multiDayAllDayStartingToday) {
            QVERIFY(ev->timeRange.isEmpty());
            QCOMPARE(ev->startDate, QStringLiteral("Today"));
            QCOMPARE(ev->daysToGo, QStringLiteral("all day"));
            QCOMPARE(ev->makeBold, true);
        } else if (ev->summaryText == multiDayAllDayStartingYesterday) {
            QVERIFY(ev->timeRange.isEmpty());
            QCOMPARE(ev->startDate, QStringLiteral("Today"));
            QCOMPARE(ev->daysToGo, QStringLiteral("all day"));
            QCOMPARE(ev->makeBold, true);
        } else {
            qDebug() << "Unexpected " << ev->summaryText << ev->startDate << ev->timeRange << ev->daysToGo;
            QVERIFY(false); // unexpected event!
        }
    }
```

#### AUTO 


```{c}
auto searchCol = new QLineEdit(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalCore::Todo::Ptr &todo : qAsConst(prList)) {
            bool makeBold = false;
            int daysTo = -1;

            // Optionally, show only my To-dos
            /*      if ( mShowMineOnly &&
                         !KCalCore::CalHelper::isMyCalendarIncidence( mCalendarAdaptor, todo.get() ) ) {
                    continue;
                  }
            TODO: calhelper is deprecated, remove this?
            */

            // Icon label
            label = new QLabel(this);
            label->setPixmap(pm);
            label->setMaximumWidth(label->minimumSizeHint().width());
            mLayout->addWidget(label, counter, 0);
            mLabels.append(label);

            // Due date label
            str.clear();
            if (todo->hasDueDate() && todo->dtDue().date().isValid()) {
                daysTo = currDate.daysTo(todo->dtDue().date());

                if (daysTo == 0) {
                    makeBold = true;
                    str = i18nc("the to-do is due today", "Today");
                } else if (daysTo == 1) {
                    str = i18nc("the to-do is due tomorrow", "Tomorrow");
                } else {
                    const auto locale = QLocale::system();
                    for (int i = 3; i < 8; ++i) {
                        if (daysTo < i * 24 * 60 * 60) {
                            str = i18nc("1. weekday, 2. time", "%1 %2",
                                        locale.dayName(todo->dtDue().date().dayOfWeek(),
                                                       QLocale::LongFormat),
                                        locale.toString(todo->dtDue().time(),
                                                        QLocale::ShortFormat));
                            break;
                        }
                    }
                    if (str.isEmpty()) {
                        str = locale.toString(todo->dtDue(), QLocale::ShortFormat);
                    }
                }
            }

            label = new QLabel(str, this);
            label->setAlignment(Qt::AlignLeft | Qt::AlignVCenter);
            mLayout->addWidget(label, counter, 1);
            mLabels.append(label);
            if (makeBold) {
                QFont font = label->font();
                font.setBold(true);
                label->setFont(font);
            }

            // Days togo/ago label
            str.clear();
            if (todo->hasDueDate() && todo->dtDue().date().isValid()) {
                if (daysTo > 0) {
                    str = i18np("in 1 day", "in %1 days", daysTo);
                } else if (daysTo < 0) {
                    str = i18np("1 day ago", "%1 days ago", -daysTo);
                } else {
                    str = i18nc("the to-do is due", "due");
                }
            }
            label = new QLabel(str, this);
            label->setAlignment(Qt::AlignLeft | Qt::AlignVCenter);
            mLayout->addWidget(label, counter, 2);
            mLabels.append(label);

            // Priority label
            str = QLatin1Char('[') + QString::number(todo->priority()) + QLatin1Char(']');
            label = new QLabel(str, this);
            label->setAlignment(Qt::AlignRight | Qt::AlignVCenter);
            mLayout->addWidget(label, counter, 3);
            mLabels.append(label);

            // Summary label
            str = todo->summary();
            if (!todo->relatedTo().isEmpty()) {   // show parent only, not entire ancestry
                KCalCore::Incidence::Ptr inc = mCalendar->incidence(todo->relatedTo());
                if (inc) {
                    str = inc->summary() + QLatin1Char(':') + str;
                }
            }
            if (!Qt::mightBeRichText(str)) {
                str = str.toHtmlEscaped();
            }

            KUrlLabel *urlLabel = new KUrlLabel(this);
            urlLabel->setText(str);
            urlLabel->setUrl(todo->uid());
            urlLabel->installEventFilter(this);
            urlLabel->setTextFormat(Qt::RichText);
            urlLabel->setWordWrap(true);
            mLayout->addWidget(urlLabel, counter, 4);
            mLabels.append(urlLabel);

            connect(urlLabel, QOverload<const QString &>::of(
                        &KUrlLabel::leftClickedUrl), this, &TodoSummaryWidget::viewTodo);
            connect(urlLabel, QOverload<const QString &>::of(
                        &KUrlLabel::rightClickedUrl), this, &TodoSummaryWidget::popupMenu);

            // State text label
            str = stateStr(todo);
            label = new QLabel(str, this);
            label->setAlignment(Qt::AlignLeft | Qt::AlignVCenter);
            mLayout->addWidget(label, counter, 5);
            mLabels.append(label);

            counter++;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *it : list) {
                if (allowedTypes.contains(QLatin1String(it->metaObject()->className()))) {
                    const QString objectName = it->objectName();
                    if (objectName.startsWith(QLatin1String("X_"))) {
                        new QTreeWidgetItem(this,
                                            QStringList() << objectName << allowedTypes[QLatin1String(it->metaObject()->className())]
                                                          << QLatin1String(it->metaObject()->className()) << it->whatsThis());
                    }
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (KHolidays::HolidayRegion *region : holidays) {
            const QString regionStr = region->regionCode();
            mHolidayCheckCombo->setItemCheckState(
                mHolidayCheckCombo->findData(regionStr), Qt::Checked);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KHolidays::HolidayRegion *region : std::as_const(mHolidayRegions)) {
            const KHolidays::Holiday::List list = region->holidays(startDate, endDate);
            for (int i = 0; i < list.count(); ++i) {
                const KHolidays::Holiday &h = list.at(i);
                if (h.dayType() == KHolidays::Holiday::NonWorkday) {
                    result.removeAll(h.observedStartDate());
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Todo::Ptr &t : incidences) {
        if (mEvents.count() == NUMDAYS) {
            // No point in wasting cpu, all days are bold already
            break;
        }
        Q_ASSERT(t);
        if (t->hasDueDate()) {
            ushort recurType = t->recurrenceType();

            if (t->recurs()
                && !(recurType == KCalendarCore::Recurrence::rDaily
                     && !KOPrefs::instance()->mDailyRecur)
                && !(recurType == KCalendarCore::Recurrence::rWeekly
                     && !KOPrefs::instance()->mWeeklyRecur)) {
                // It's a recurring todo, find out in which days it occurs
                const auto timeDateList
                    = t->recurrence()->timesInInterval(
                          QDateTime(mDays[0], {}, Qt::LocalTime),
                          QDateTime(mDays[NUMDAYS - 1], {}, Qt::LocalTime));

                for (const QDateTime &dt : timeDateList) {
                    d = dt.toLocalTime().date();
                    if (!mEvents.contains(d)) {
                        mEvents.append(d);
                    }
                }
            } else {
                d = t->dtDue().toLocalTime().date();
                if (d >= mDays[0] && d <= mDays[NUMDAYS - 1] && !mEvents.contains(d)) {
                    mEvents.append(d);
                }
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : items) {
                            if (item.mimeType() == QStringLiteral("message/rfc822")) {
                                auto mail = item.payload<KMime::Message::Ptr>();
                                interface()->openTodoEditor(i18nc("Event from email summary", "Mail: %1", mail->subject()->asUnicodeString()),
                                                            i18nc("Event from email content",
                                                                  "<b>From:</b> %1<br /><b>To:</b> %2<br /><b>Subject:</b> %3",
                                                                  mail->from()->displayString(),
                                                                  mail->to()->displayString(),
                                                                  mail->subject()->asUnicodeString()),
                                                            url.toDisplayString(),
                                                            QString(),
                                                            QStringList(),
                                                            QStringLiteral("message/rfc822"));
                            }
                        }
```

#### AUTO 


```{c}
auto e4 = new Event;
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Attendee &attendee : lstAttendees) {
                if (re.indexIn(attendee.fullName()) != -1) {
                    m_matchedEvents.append(item);
                    break;
                }
            }
```

#### AUTO 


```{c}
auto *saveLayout = new QVBoxLayout(saveFrame);
```

#### AUTO 


```{c}
auto *defaultLayout = new QGridLayout(defaultPage);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &e : installedEntries) {
        qCDebug(KORGANIZER_LOG) << " downloadNewStuff :";
        const QStringList lstFile = e.installedFiles();
        if (lstFile.count() != 1) {
            continue;
        }
        const QString file = lstFile.at(0);
        const QUrl filename = QUrl::fromLocalFile(file);
        qCDebug(KORGANIZER_LOG) << "filename :" << filename;
        if (!filename.isValid()) {
            continue;
        }

        KCalendarCore::FileStorage storage(calendar());
        storage.setFileName(file);
        storage.setSaveFormat(new KCalendarCore::ICalFormat);
        if (!storage.load()) {
            KMessageBox::error(mCalendarView, i18n("Could not load calendar %1.", file));
        } else {
            QStringList eventSummaries;
            const KCalendarCore::Event::List events = calendar()->events();
            eventSummaries.reserve(events.count());
            for (const KCalendarCore::Event::Ptr &event : events) {
                eventSummaries.append(event->summary());
            }

            const int result =
                KMessageBox::warningContinueCancelList(mCalendarView, i18n("The downloaded events will be merged into your current calendar."), eventSummaries);

            if (result != KMessageBox::Continue) {
                // FIXME (KNS2): hm, no way out here :-)
            }

            if (importURL(QUrl::fromLocalFile(file), true)) {
                // FIXME (KNS2): here neither
            }
        }
    }
```

#### AUTO 


```{c}
const auto attr = col.attribute<Akonadi::CollectionIdentificationAttribute>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : items) {
            if (item.hasPayload<KContacts::Addressee>()) {
                const auto addressee = item.payload<KContacts::Addressee>();
                const QDate birthday = addressee.birthday().date();
                if (birthday.isValid()) {
                    SDEntry entry;
                    entry.type = IncidenceTypeContact;
                    entry.category = CategoryBirthday;
                    dateDiff(birthday, entry.daysTo, entry.yearsOld);
                    if (entry.daysTo < mDaysAhead) {
                        // We need to check the days ahead here because we don't
                        // filter out Contact Birthdays by mDaysAhead in createLabels().
                        entry.date = birthday;
                        entry.addressee = addressee;
                        entry.item = item;
                        entry.span = 1;
                        mDates.append(entry);
                    }
                }
            }
        }
```

#### AUTO 


```{c}
auto categoryLayout = new QGridLayout;
```

#### RANGE FOR STATEMENT 


```{c}
for (KDateNavigator *n : std::as_const(mExtraViews)) {
        baseDate = baseDate.addMonths(1);
        if (!mIgnoreNavigatorUpdates) {
            n->setBaseDate(baseDate);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (SummaryEventInfo *event : events) {
        // Optionally, show only my Events
        /*      if ( mShowMineOnly &&
                  !KCalendarCore::CalHelper::isMyCalendarIncidence( mCalendarAdaptor, event->ev ) ) {
              continue;
            }
            TODO: CalHelper is deprecated, remove this?
        */

        KCalendarCore::Event::Ptr ev = event->ev;
        // print the first of the recurring event series only
        if (ev->recurs()) {
            if (uidList.contains(ev->instanceIdentifier())) {
                continue;
            }
            uidList.append(ev->instanceIdentifier());
        }

        // Icon label
        label = new QLabel(this);
        if (ev->categories().contains(QLatin1String("BIRTHDAY"), Qt::CaseInsensitive)) {
            label->setPixmap(pmb);
        } else if (ev->categories().contains(QLatin1String("ANNIVERSARY"), Qt::CaseInsensitive)) {
            label->setPixmap(pma);
        } else {
            label->setPixmap(pm);
        }
        label->setMaximumWidth(label->minimumSizeHint().width());
        mLayout->addWidget(label, counter, 0);
        mLabels.append(label);

        // Start date or date span label
        QString dateToDisplay = event->startDate;
        if (!event->dateSpan.isEmpty()) {
            dateToDisplay = event->dateSpan;
        }
        label = new QLabel(dateToDisplay, this);
        label->setAlignment(Qt::AlignLeft | Qt::AlignVCenter);
        mLayout->addWidget(label, counter, 1);
        mLabels.append(label);
        if (event->makeBold) {
            QFont font = label->font();
            font.setBold(true);
            label->setFont(font);
            if (!event->makeUrgent) {
                label->setPalette(todayPalette);
            } else {
                label->setPalette(urgentPalette);
            }
            label->setAutoFillBackground(true);
        }

        // Days to go label
        label = new QLabel(event->daysToGo, this);
        label->setAlignment(Qt::AlignLeft | Qt::AlignVCenter);
        mLayout->addWidget(label, counter, 2);
        mLabels.append(label);

        // Summary label
        auto *urlLabel = new KUrlLabel(this);
        urlLabel->setText(event->summaryText);
        urlLabel->setUrl(event->summaryUrl);
        urlLabel->installEventFilter(this);
        urlLabel->setTextFormat(Qt::RichText);
        urlLabel->setWordWrap(true);
        mLayout->addWidget(urlLabel, counter, 3);
        mLabels.append(urlLabel);
        connect(urlLabel, &KUrlLabel::leftClickedUrl, this, [this, urlLabel] {
            viewEvent(urlLabel->url());
        });
        connect(urlLabel, &KUrlLabel::rightClickedUrl, this, [this, urlLabel] {
            popupMenu(urlLabel->url());
        });
        if (!event->summaryTooltip.isEmpty()) {
            urlLabel->setToolTip(event->summaryTooltip);
        }

        // Time range label (only for non-floating events)
        if (!event->timeRange.isEmpty()) {
            label = new QLabel(event->timeRange, this);
            label->setAlignment(Qt::AlignLeft | Qt::AlignVCenter);
            mLayout->addWidget(label, counter, 4);
            mLabels.append(label);
        }

        counter++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalCore::Event::Ptr &event : eventlist) {
        if (mEvents.count() == NUMDAYS) {
            // No point in wasting cpu, all days are bold already
            break;
        }

        Q_ASSERT(event);
        const ushort recurType = event->recurrenceType();
        const QDateTime dtStart = event->dtStart().toLocalTime();

        // timed incidences occur in
        //   [dtStart(), dtEnd()[. All-day incidences occur in [dtStart(), dtEnd()]
        // so we subtract 1 second in the timed case
        const int secsToAdd = event->allDay() ? 0 : -1;
        const QDateTime dtEnd = event->dtEnd().toLocalTime().addSecs(secsToAdd);

        if (!(recurType == KCalCore::Recurrence::rDaily && !KOPrefs::instance()->mDailyRecur)
            && !(recurType == KCalCore::Recurrence::rWeekly
                 && !KOPrefs::instance()->mWeeklyRecur)) {
            KCalCore::SortableList<QDateTime> timeDateList;
            const bool isRecurrent = event->recurs();
            const int eventDuration = dtStart.daysTo(dtEnd);

            if (isRecurrent) {
                //Its a recurring event, find out in which days it occurs
                timeDateList = event->recurrence()->timesInInterval(
                    QDateTime(mDays[0], {}, Qt::LocalTime),
                    QDateTime(mDays[NUMDAYS - 1], {}, Qt::LocalTime));
            } else {
                if (dtStart.date() >= mDays[0]) {
                    timeDateList.append(dtStart);
                } else {
                    // The event starts in another month (not visible))
                    timeDateList.append(QDateTime(mDays[0], {}, Qt::LocalTime));
                }
            }

            for (auto t = timeDateList.begin(); t != timeDateList.end(); ++t) {
                //This could be a multiday event, so iterate from dtStart() to dtEnd()
                QDate d = t->toLocalTime().date();
                int j = 0;

                QDate occurrenceEnd;
                if (isRecurrent) {
                    occurrenceEnd = d.addDays(eventDuration);
                } else {
                    occurrenceEnd = dtEnd.date();
                }

                do {
                    mEvents.append(d);
                    ++j;
                    d = d.addDays(1);
                } while (d <= occurrenceEnd && j < NUMDAYS);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Attendee &attendee : lstAttendees) {
                if (re.indexIn(attendee.fullName()) != -1) {
                    mMatchedEvents.append(item);
                    break;
                }
            }
```

