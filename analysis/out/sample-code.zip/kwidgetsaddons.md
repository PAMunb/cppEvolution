#### LAMBDA EXPRESSION 


```{c}
[this](QAbstractButton *button) {
            QDialogButtonBox::StandardButton code = d->m_buttonBox->standardButton(button);
            if (code != QDialogButtonBox::NoButton) {
                done(code);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QMimeType &mt : mimetypes) {
        const QString mimetype = mt.name();
        const int index = mimetype.indexOf(QLatin1Char('/'));
        // e.g. "text", "audio", "inode"
        const QString maj = mimetype.left(index);

        if (!groups.isEmpty() && !groups.contains(maj)) {
            continue;
        }

        QStandardItem *groupItem;
        QMap<QString, QStandardItem *>::Iterator mit = groupItems.find(maj);
        if (mit == groupItems.end()) {
            groupItem = new QStandardItem(maj);
            groupItem->setFlags(Qt::ItemIsEnabled);
            // a dud item to fill the patterns column next to "groupItem" and setFlags() on it
            QStandardItem *secondColumn = new QStandardItem();
            secondColumn->setFlags(Qt::NoItemFlags);
            QStandardItem *thirdColumn = new QStandardItem();
            thirdColumn->setFlags(Qt::NoItemFlags);
            m_model->appendRow({groupItem, secondColumn, thirdColumn});
            groupItems.insert(maj, groupItem);
            if (maj == defaultgroup) {
                idefault = groupItem;
            }
        } else {
            groupItem = mit.value();
        }

        // e.g. "html", "plain", "mp4"
        const QString min = mimetype.mid(index + 1);
        QStandardItem *mime = new QStandardItem(QIcon::fromTheme(mt.iconName()), min);
        mime->setFlags(Qt::ItemIsSelectable | Qt::ItemIsUserCheckable | Qt::ItemIsEnabled);

        QStandardItem *comments = nullptr;
        if (visuals & KMimeTypeChooser::Comments) {
            comments = new QStandardItem(mt.comment());
            comments->setFlags(Qt::ItemIsSelectable | Qt::ItemIsEnabled);
        }

        QStandardItem *patterns = nullptr;

        if (visuals & KMimeTypeChooser::Patterns) {
            patterns = new QStandardItem(mt.globPatterns().join(QLatin1String("; ")));
            patterns->setFlags(Qt::ItemIsSelectable | Qt::ItemIsEnabled);
        }

        groupItem->appendRow(QList<QStandardItem *>({mime, comments, patterns}));

        if (selMimeTypes.contains(mimetype)) {
            mime->setCheckState(Qt::Checked);
            const QModelIndex index = m_proxyModel->mapFromSource(m_model->indexFromItem(groupItem));
            mimeTypeTree->expand(index);
            agroupisopen = true;
            if (!firstChecked) {
                firstChecked = mime;
            }
        } else {
            mime->setCheckState(Qt::Unchecked);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->previousMonth();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        chooseColor();
    }
```

#### AUTO 


```{c}
auto lineEdit = new QLineEdit();
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        spyDateEntered.clear();
        spyDateEdited.clear();
        spyDateChanged.clear();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QDateTime& dt) { qDebug() << "dateTimeEdited" << dt; }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QFont &ft) { d->_k_slotFontChanged(ft); }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->_k_back();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *maction : menuActions) {
        if (maction->isSeparator()) {
            continue;
        }

        s = maction->text();

        // in full menus, look at entries with global accelerators last
        int weight = 50;
        if (s.contains(QLatin1Char('\t'))) {
            weight = 0;
        }

        list.append(KAccelString(s, weight));

        // have a look at the popup as well, if present
        if (maction->menu()) {
            KPopupAccelManager::manage(maction->menu());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QToolButton *button : std::as_const(buttons)) {
            layout->addWidget(button);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &str) {
        _k_showToggleEchoModeAction(str);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &s : strings) {
        (*index)[s.toLower()].append(unicode);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (quint16 c : pos.value()) {
            result.insert(mapDataBaseToCodePoint(c));
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            d->copyFullText();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->buildMenu();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](qreal value) {
        slotTimeLineChanged(value);
    }
```

#### AUTO 


```{c}
auto *layout = new QVBoxLayout(&window);
```

#### LAMBDA EXPRESSION 


```{c}
[](QDate date) {
        qInfo() << date;
    }
```

#### AUTO 


```{c}
const auto currentPixmap = pixmap(Qt::ReturnByValue);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const double size) {
        slotSizeValue(size);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QStandardItem *item : checkedItems) {
        mimeList.append(item->parent()->text() + QLatin1Char('/') + item->text());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        d->_k_buttonClicked();
    }
```

#### AUTO 


```{c}
auto *comboSelect = new KSelectAction(QStringLiteral("selectAction"), &mainWindow);
```

#### RANGE FOR STATEMENT 


```{c}
for (Item *it : qAsConst(*item->m_children)) {
        cnt++;

        QDockWidget *dock = qobject_cast<QDockWidget *>(it->m_widget);
        if (dock) {
            if (checkChange(contents[cnt])) {
                dock->setWindowTitle(contents[cnt].accelerated());
            }
            continue;
        }
        QTabBar *tabBar = qobject_cast<QTabBar *>(it->m_widget);
        if (tabBar) {
            if (checkChange(contents[cnt])) {
                tabBar->setTabText(it->m_index, contents[cnt].accelerated());
            }
            continue;
        }
        QMenuBar *menuBar = qobject_cast<QMenuBar *>(it->m_widget);
        if (menuBar) {
            if (it->m_index >= 0) {
                QAction *maction = menuBar->actions()[it->m_index];
                if (maction) {
                    checkChange(contents[cnt]);
                    maction->setText(contents[cnt].accelerated());
                }
                continue;
            }
        }

        // we possibly reserved an accel, but we won't set it as it looks silly
        QGroupBox *groupBox = qobject_cast<QGroupBox *>(it->m_widget);
        if (groupBox && !groupBox->isCheckable()) {
            continue;
        }

        int tprop = it->m_widget->metaObject()->indexOfProperty("text");
        if (tprop != -1) {
            if (checkChange(contents[cnt])) {
                it->m_widget->setProperty("text", contents[cnt].accelerated());
            }
        } else {
            tprop = it->m_widget->metaObject()->indexOfProperty("title");
            if (tprop != -1 && checkChange(contents[cnt])) {
                it->m_widget->setProperty("title", contents[cnt].accelerated());
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        passwordChanged();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](int value) {
        d->selectTime(value);
    }
```

#### AUTO 


```{c}
const auto label = createLabel(QString());
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QDate &date) {
        d->enterDate(date);
    }
```

#### AUTO 


```{c}
auto it = m_saved.constBegin();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            if (d->m_edited) {
                d->enterDate(date());
                Q_EMIT dateChanged(date());
            }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        _k_chooseColor();
    }
```

#### AUTO 


```{c}
auto label = new QLabel(parent);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &c : qAsConst(chars)) {
        int unicode = c.toInt(nullptr, 16);
        if (!allPlanesEnabled && QChar::requiresSurrogates(unicode)) {
            continue;
        }
        QString link = QLatin1String("<a href=\"") + c + QLatin1String("\">");
        if (s_data()->isPrint(unicode)) {
            link += QLatin1String("&#8206;&#") + QString::number(unicode) + QLatin1String(";&nbsp;");
        }
        link += QLatin1String("U+") + c + QLatin1Char(' ');
        link += s_data()->name(unicode).toHtmlEscaped() + QLatin1String("</a>");
        s.replace(c, link);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[d]() {
        d->slotModelAboutToBeReset();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : actions) {
        QToolButton *button = new QToolButton(q);
        button->setDefaultAction(action);
        button->setToolButtonStyle(Qt::ToolButtonTextBesideIcon);
        buttons.append(button);
    }
```

#### AUTO 


```{c}
auto *widget
```

#### AUTO 


```{c}
auto layout = new QVBoxLayout(&window);
```

#### AUTO 


```{c}
auto label = qobject_cast<QLabel*>(widget)
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &family) {
        slotFamilySelected(family);
    }
```

#### AUTO 


```{c}
auto widget1 = parent->findChild<QWidget *>(QStringLiteral("widget1"));
```

#### AUTO 


```{c}
auto item2 = new QTreeWidgetItem(&m_view);
```

#### AUTO 


```{c}
const auto pos = m_view.viewport()->mapToGlobal(rect.topLeft());
```

#### LAMBDA EXPRESSION 


```{c}
[d](QObject *obj) {
            d->comboBoxDeleted(obj);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QComboBox *box : qAsConst(d->m_comboBoxes)) {
        box->setMaximumWidth(d->m_comboWidth);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QModelIndex &index) {
            d->_k_slotCurrentChanged(index);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &family : allFamilies) {
            if ((fontFilters & scalableMask) && (fontFilters & scalableMask) != scalableMask) {
                if (bool(fontFilters & QFontComboBox::ScalableFonts) != dbase.isSmoothlyScalable(family)) {
                    continue;
                }
            }
            if ((fontFilters & spacingMask) && (fontFilters & spacingMask) != spacingMask) {
                if (bool(fontFilters & QFontComboBox::MonospacedFonts) != dbase.isFixedPitch(family)) {
                    continue;
                }
            }

            families << family;
        }
```

#### AUTO 


```{c}
const auto screens = QGuiApplication::screens();
```

#### CONST EXPRESSION 


```{c}
constexpr float radius = 4 * 0.6;
```

#### RANGE FOR STATEMENT 


```{c}
for (QToolButton *button : qAsConst(buttons)) {
                // For some reason, calling show() is necessary if wordwrap is true,
                // otherwise the buttons do not show up. It is not needed if
                // wordwrap is false.
                button->show();
                buttonLayout->addWidget(button);
            }
```

#### AUTO 


```{c}
const auto associatedWidgets = this->associatedWidgets();
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &str) {
        d->editTime(str);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->back();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &family) {
        _k_family_chosen_slot(family);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->timerUpdate();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &s : qAsConst(searchStrings)) {
        QSet<uint> partResult = getMatchingChars(s.toLower());
        if (firstSubString) {
            result = partResult;
            firstSubString = false;
        } else {
            result = result.intersect(partResult);
        }
    }
```

#### AUTO 


```{c}
auto oldModel = d->model;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &zoneId : zoneIds) {
        zones << QTimeZone(zoneId);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->buttonUpClicked();
    }
```

#### AUTO 


```{c}
auto checkBox = new QCheckBox(QStringLiteral("Some really long text that goes on and on and on for ever and ever"));
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &text) {
        d->m_proxyModel->setFilterRegularExpression(
            QRegularExpression(text, QRegularExpression::CaseInsensitiveOption | QRegularExpression::UseUnicodePropertiesOption));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](int value) {
            movieFrameChanged(value);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto type : types) {
        auto dlg = std::unique_ptr<KMessageDialog>(new KMessageDialog(type,
                                                                      QStringLiteral("Do you agree to action foo?"),
                                                                      nullptr));
        dlg->setCaption(QString{});
        dlg->setIcon(QIcon{});
        dlg->setButtons();

        auto getResult = [&]() {
            const auto result = static_cast<QDialogButtonBox::StandardButton>(dlg->exec());
            switch(result) {
            case QDialogButtonBox::Ok:
            case QDialogButtonBox::Yes:
                qDebug() << "Button OK/Yes/Continue clicked."
                         << "Don't ask again status:" << (dlg->isDontAskAgainChecked() ? "Checked" : "Unchecked");
                break;
            case QDialogButtonBox::No:
                qDebug() << "Button No clicked"
                         << "Don't ask again status:" << (dlg->isDontAskAgainChecked() ? "Checked" : "Unchecked");
                break;
            case QDialogButtonBox::Cancel:
                qDebug() << "Button Cancel clicked";
                break;
            default:
                break;
            }
        };

        getResult();

        dlg->setDontAskAgainText(QStringLiteral("Do not show this again"));
        dlg->setDontAskAgainChecked(false);
        getResult();

        dlg->setListWidgetItems(QStringList{QStringLiteral("file1"), QStringLiteral("file2")});
        getResult();

        dlg->setDetails(QStringLiteral("Some more details."));
        getResult();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : actions) {
            if (action->text() == test) {
                setCurrentAction(action);
                return;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QDateTime &dt) {
        qDebug() << "dateTimeEdited" << dt;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const double size) { d->_k_size_value_slot(size); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &style : origStyles) {
        // Sometimes the font database will report an invalid style,
        // that falls back back to another when set.
        // Remove such styles, by checking set/get round-trip.
        QFont testFont = dbase.font(currentFamily, style, 10);
        if (dbase.styleString(testFont) != style) {
            styles.removeAll(style);
            continue;
        }

        QString fstyle = tr("%1", "@item Font style").arg(style);
        if (!filteredStyles.contains(fstyle)) {
            filteredStyles.append(fstyle);
            qtStyles.insert(fstyle, style);
            styleIDs.insert(fstyle, styleIdentifier(testFont));
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->endOfWeek();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *widget : qAsConst(m_widgets)) {
            width = qMax(widget->sizeHint().width(), width);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QChar c : example) {
        if (c == QLatin1Char('0') || c == QLatin1Char('9') || c == QLatin1Char('x')) {
            mask.append(c);
        } else {
            mask.append(QLatin1Char('\\'));
            mask.append(c);
            null.append(c);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &size) {
        slotSizeSelected(size);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QComboBox *box : std::as_const(d->m_comboBoxes)) {
        if (d->m_maxComboViewCount != -1) {
            box->setMaxVisibleItems(d->m_maxComboViewCount);
        } else
        // hardcoded qt default
        {
            box->setMaxVisibleItems(10);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const bool state) {
            q->setFont(m_selectedFont, state);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        slotUpdateButtons();
    }
```

#### AUTO 


```{c}
auto linePassword = pwdWidget->findChild<QLineEdit*>(QStringLiteral("linePassword"));
```

#### RANGE FOR STATEMENT 


```{c}
for (QComboBox *box : std::as_const(m_comboBoxes)) {
            box->removeEventFilter(q_ptr);
            QObject::disconnect(box, nullptr, q_ptr, nullptr); // To prevent a crash in comboBoxDeleted()
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const bool state) {
        q->setFont(selFont, state);
    }
```

#### AUTO 


```{c}
auto widget = static_cast<QWidget *>(ce->child());
```

#### AUTO 


```{c}
auto view = new KDEPrivate::KPageListView(this);
```

#### AUTO 


```{c}
auto *iconLayout = new QVBoxLayout{};
```

#### AUTO 


```{c}
auto lineVerifyPassword = pwdWidget.findChild<QLineEdit *>(QStringLiteral("lineVerifyPassword"));
```

#### RANGE FOR STATEMENT 


```{c}
for (Item *it : qAsConst(*item->m_children)) {
        contents << it->m_content;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->previousMonth(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (Item *it : std::as_const(*item->m_children)) {
        if (it->m_widget && it->m_widget->isVisibleTo(item->m_widget)) {
            calculateAccelerators(it, used);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *widget : associatedWidgets) {
        if (QToolBar *toolBar = qobject_cast<QToolBar *>(widget))
            if (QLabel *label = qobject_cast<QLabel *>(toolBar->widgetForAction(this))) {
                labels.append(label);
            }
    }
```

#### AUTO 


```{c}
auto *noBtn = d->m_buttonBox->button(QDialogButtonBox::No);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->_k_timerUpdate();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &str) { d->editTime(str); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](int index) {
        d->sectionSelected(index);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto c : std::as_const(result)) {
        sortedResult.append(c);
    }
```

#### AUTO 


```{c}
auto lineVerifyPassword = pwdWidget.findChild<QLineEdit*>(QLatin1String("lineVerifyPassword"));
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->fontSelected();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[url] (RecentFilesEntry *entry) {
        return entry->url == url;
    }
```

#### AUTO 


```{c}
auto *hLayout = new QHBoxLayout{};
```

#### LAMBDA EXPRESSION 


```{c}
[d, comboBox]() {
            d->comboBoxDeleted(comboBox);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            slotNextMonth();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QToolButton *button : std::as_const(buttons)) {
                // For some reason, calling show() is necessary if wordwrap is true,
                // otherwise the buttons do not show up. It is not needed if
                // wordwrap is false.
                button->show();
                buttonLayout->addWidget(button);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &style : origStyles) {
        // Sometimes the font database will report an invalid style,
        // that falls back back to another when set.
        // Remove such styles, by checking set/get round-trip.
        QFont testFont = dbase.font(currentFamily, style, 10);
        if (dbase.styleString(testFont) != style) {
            styles.removeAll(style);
            continue;
        }

        QString fstyle = tr("%1", "@item Font style").arg(style);
        if (!filteredStyles.contains(fstyle)) {
            filteredStyles.append(fstyle);
            m_qtStyles.insert({fstyle, style});
            m_styleIDs.insert({fstyle, styleIdentifier(testFont)});
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : actions) {
        ret << ::DropAmpersands(action->text());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &style : styles) {
            // orderded by commonness, i.e. "Regular" is the most common
            if (style == QLatin1String("Regular")
                || style == QLatin1String("Normal")
                || style == QLatin1String("Book")
                || style == QLatin1String("Roman")) {
                styleName = style;
            } else {
                // nothing more we can do
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &style) {
        slotStyleSelected(style);
    }
```

#### AUTO 


```{c}
auto linePassword = pwdWidget.findChild<QLineEdit*>(QLatin1String("linePassword"));
```

#### RANGE FOR STATEMENT 


```{c}
for (QComboBox *comboBox : std::as_const(d->m_comboBoxes)) {
            comboBox->setToolTip(toolTip());
            comboBox->setWhatsThis(whatsThis());
            comboBox->setStatusTip(statusTip());
        }
```

#### AUTO 


```{c}
auto rect = m_view.visualRect(index);
```

#### LAMBDA EXPRESSION 


```{c}
[this](int index) {
        d->slotActivated(index);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (FormLayoutWidgetItem *item : std::as_const(m_formWidgetItemList)) {
            item->setWidth(width);
            item->formLayout()->update();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        QVERIFY(tooltip.isHidden());
        QVERIFY(!label.isVisible());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QFont &ft) {
        Q_D(KFontAction);
        d->slotFontChanged(ft);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QComboBox *comboBox : std::as_const(d->m_comboBoxes)) {
        comboBox->setEnabled(!hasActions);
        comboBox->removeAction(action);
    }
```

#### AUTO 


```{c}
const auto extent = QApplication::style()->pixelMetric(QStyle::PM_SmallIconSize);
```

#### AUTO 


```{c}
auto lineEdit = new QLineEdit(groupBox);
```

#### AUTO 


```{c}
const auto zoneIds = QTimeZone::availableTimeZoneIds();
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : widgetActions) {
        const QList<QKeySequence> actionShortcuts = action->shortcuts();
        for (const QKeySequence &sequence : actionShortcuts) {
            const QString sequenceAsText = sequence.toString(QKeySequence::PortableText);
            const QStringList splitSequence = sequenceAsText.split(QStringLiteral(", "));
            for (const QString &shortcut : splitSequence) {
                if (shortcut.length() == 5 && shortcut.startsWith(QStringLiteral("Alt+"))) {
                    used.append(shortcut.right(1));
                }
            }
        }
    }
```

#### AUTO 


```{c}
auto visibilityAction = linePassword->findChild<QAction*>(QStringLiteral("visibilityAction"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QTime &thisTime : std::as_const(m_timeList)) {
            if (thisTime.isValid() && thisTime >= m_minTime && thisTime <= m_maxTime) {
                q->addItem(formatTime(thisTime), thisTime);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QTime &time : std::as_const(timeList)) {
            if (time.isValid() && !d->m_timeList.contains(time)) {
                d->m_timeList.append(time);
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const bool state) { d->styleListBox->setEnabled(state); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](int index) {
        d->blockSelected(index);
    }
```

#### AUTO 


```{c}
auto type
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->nextMonth(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this, menu]() {
            Q_EMIT menu->urlTriggered(url);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const bool state) { d->familyListBox->setEnabled(state); }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            adjustPixmapSize();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (int block : blocks) {
        if (!allPlanesEnabled) {
            const QVector<uint> contents = s_data()->blockContents(block);
            if (!contents.isEmpty() && QChar::requiresSurrogates(contents.at(0))) {
                continue;
            }
        }
        blockCombo->addItem(s_data()->blockName(block), QVariant(block));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            slotToday();
        }
```

#### AUTO 


```{c}
auto datePicker = combo->findChild<KDatePickerPopup *>();
```

#### LAMBDA EXPRESSION 


```{c}
[&, timer]() {
            d->resizeCells();
            timer->deleteLater();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &family : qAsConst(lstSys)) {
            if ((fontListCriteria & FixedWidthFonts) > 0 && !dbase.isFixedPitch(family)) {
                continue;
            }
            if (((fontListCriteria & (SmoothScalableFonts | ScalableFonts)) == ScalableFonts) && !dbase.isBitmapScalable(family)) {
                continue;
            }
            if ((fontListCriteria & SmoothScalableFonts) > 0 && !dbase.isSmoothlyScalable(family)) {
                continue;
            }
            lstFonts.append(family);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &size) {
        size_chosen_slot(size);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->_k_timerUpdate(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &str : strlist) {
            w = qMax(w, fm.width(str));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto type : types) {
        auto dlg = std::unique_ptr<KMessageDialog>(new KMessageDialog(type, QStringLiteral("Do you agree to action foo?"), nullptr));
        dlg->setCaption(QString{});
        dlg->setIcon(QIcon{});

        auto getResult = [&]() {
            const auto result = static_cast<QDialogButtonBox::StandardButton>(dlg->exec());
            switch (result) {
            case QDialogButtonBox::Ok:
            case QDialogButtonBox::Yes:
                qDebug() << "Button OK/Yes/Continue clicked."
                         << "Don't ask again status:" << (dlg->isDontAskAgainChecked() ? "Checked" : "Unchecked");
                break;
            case QDialogButtonBox::No:
                qDebug() << "Button No clicked"
                         << "Don't ask again status:" << (dlg->isDontAskAgainChecked() ? "Checked" : "Unchecked");
                break;
            case QDialogButtonBox::Cancel:
                qDebug() << "Button Cancel clicked";
                break;
            default:
                break;
            }
        };

        getResult();

        dlg->setDontAskAgainText(QStringLiteral("Do not show this again"));
        dlg->setDontAskAgainChecked(false);
        getResult();

        dlg->setListWidgetItems(QStringList{QStringLiteral("file1"), QStringLiteral("file2")});
        getResult();

        dlg->setDetails(QStringLiteral("Some more details."));
        getResult();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->forward();
    }
```

#### AUTO 


```{c}
auto it = d->findEntry(url);
```

#### AUTO 


```{c}
const auto textLines = d->fullText.split(QLatin1Char('\n'));
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->endOfMonth(); }
```

#### AUTO 


```{c}
auto *layout = new QVBoxLayout(&dialog);
```

#### AUTO 


```{c}
const auto displayedChars = d->charTable->displayedChars();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            if (d->m_edited) {
                d->enterDate(date());
                emit dateChanged(date());
            }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QModelIndex &index) { d->_k_slotCurrentChanged(index); }
```

#### RANGE FOR STATEMENT 


```{c}
for (QObject *child : children) {
        QWidget *widget = qobject_cast<QWidget*>(child);
        if (!widget) {
            continue;
        }
        // Restore old focus policy if expanded, remove from focus chain otherwise.
        if (expanded) {
            widget->setFocusPolicy(focusMap.value(widget));
        } else {
            widget->setFocusPolicy(Qt::NoFocus);
        }
    }
```

#### AUTO 


```{c}
auto *cancelButton = d->m_buttonBox->button(QDialogButtonBox::Cancel);
```

#### AUTO 


```{c}
const auto createdWidgets = this->createdWidgets();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &string : lst) {
        if (!string.isEmpty()) {
            addAction(string);
        } else {
            QAction *action = new QAction(this);
            action->setSeparator(true);
            addAction(action);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &text) {
        d->m_proxyModel->setFilterRegularExpression(QRegularExpression(text, QRegularExpression::CaseInsensitiveOption));
    }
```

#### AUTO 


```{c}
auto getResult = [&]() {
            const auto result = static_cast<QDialogButtonBox::StandardButton>(dlg->exec());
            switch(result) {
            case QDialogButtonBox::Ok:
            case QDialogButtonBox::Yes:
                qDebug() << "Button OK/Yes/Continue clicked."
                         << "Don't ask again status:" << (dlg->isDontAskAgainChecked() ? "Checked" : "Unchecked");
                break;
            case QDialogButtonBox::No:
                qDebug() << "Button No clicked"
                         << "Don't ask again status:" << (dlg->isDontAskAgainChecked() ? "Checked" : "Unchecked");
                break;
            case QDialogButtonBox::Cancel:
                qDebug() << "Button Cancel clicked";
                break;
            default:
                break;
            }
        };
```

#### AUTO 


```{c}
auto linePassword = pwdWidget.findChild<QLineEdit*>(QStringLiteral("linePassword"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &alias : aliases) {
            html += QLatin1String("<li>") + alias.toHtmlEscaped() + QLatin1String("</li>");
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QFont &ft) { Q_D(KFontAction); d->_k_slotFontChanged(ft); }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QDateTime &dt) {
        qDebug() << "dateTimeEntered" << dt;
    }
```

#### CONST EXPRESSION 


```{c}
constexpr float alpha = 0.2;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &style : styles) {
            // orderded by commonness, i.e. "Regular" is the most common
            if (style == QLatin1String("Regular") //
                || style == QLatin1String("Normal") //
                || style == QLatin1String("Book") //
                || style == QLatin1String("Roman")) {
                styleName = style;
            } else {
                // nothing more we can do
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &text : qAsConst(initialTexts)) {
            menu.addAction(text);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QModelIndex &index) {
            d->slotCurrentChanged(index);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (qreal size : qAsConst(sizes)) {
        m_ui->sizeListWidget->addItem(formatFontSize(size));
    }
```

#### AUTO 


```{c}
auto resizer = new KColumnResizer(parent);
```

#### LAMBDA EXPRESSION 


```{c}
[](const QDateTime& dt) { qDebug() << "dateTimeChanged" << dt; }
```

#### RANGE FOR STATEMENT 


```{c}
for (T child : children) {
        if (child->isVisible()) {
            return child;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QComboBox *box : qAsConst(d->m_comboBoxes)) {
        if (d->m_maxComboViewCount != -1) {
            box->setMaxVisibleItems(d->m_maxComboViewCount);
        } else
        // hardcoded qt default
        {
            box->setMaxVisibleItems(10);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const RecentFilesEntry *entry : d->m_entries) {
        addAction(entry->action);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[d]() {
            d->slotModelReset();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
            movieFinished();
        }
```

#### AUTO 


```{c}
const auto children = q->children();
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *widget : associatedWidgets) {
        if (QToolBar *toolBar = qobject_cast<QToolBar *>(widget)) {
            if (QLabel *label = qobject_cast<QLabel *>(toolBar->widgetForAction(this))) {
                labels.append(label);
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QDate &d) {
        qDebug() << "dateEntered" << d;
    }
```

#### AUTO 


```{c}
auto spinBox = new QSpinBox(this);
```

#### AUTO 


```{c}
const auto maxDate = QDate::fromString(parser.value(QStringLiteral("max-date")), Qt::ISODate);
```

#### AUTO 


```{c}
auto toggle = new QPushButton(QStringLiteral("Toggle Visible"), &window);
```

#### LAMBDA EXPRESSION 


```{c}
[this](QAbstractButton *button) {
        QDialogButtonBox::StandardButton code = d->m_buttonBox->standardButton(button);
        if (code != QDialogButtonBox::NoButton) {
            done(code);
        }
    }
```

#### AUTO 


```{c}
const auto label = createLabel(text);
```

#### AUTO 


```{c}
auto clearSpies = [&]() {
        spyDateEntered.clear();
        spyDateEdited.clear();
        spyDateChanged.clear();
    };
```

#### AUTO 


```{c}
auto nIt = m_qtFamilies.find(s);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->_k_copyFullText(); }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QDateTime& dt) { qDebug() << "dateTimeEntered" << dt; }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &key : keys) {
            m_saved.insert(key, static_cast<KMessageBox::ButtonCode>(s.value(key).toInt()));
        }
```

#### AUTO 


```{c}
auto hiddenCheckBox = new QCheckBox(QStringLiteral("This will be always hidden"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QLocale &calendarLocale : qAsConst(m_calendarLocales)) {
        ui.m_calendarCombo->addItem(calendarLocale.name(), calendarLocale);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->_k_back(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (qreal size : std::as_const(sizes)) {
        m_ui->sizeListWidget->addItem(formatFontSize(size));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](int index) {
        d->slotHighlighted(index);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QTimeZone &zone : std::as_const(m_zones)) {
        ui.m_timeZoneCombo->addItem(QString::fromUtf8(zone.id()), zone.id());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QToolButton *button : std::as_const(buttons)) {
            layout->addWidget(button, 0, Qt::AlignTop);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        echoModeToggled();
    }
```

#### AUTO 


```{c}
auto *dlg = new KMessageDialog(KMessageDialog::Error, QObject::tr("Could not find the \"keditfiletype5\" executable in PATH."), widget);
```

#### AUTO 


```{c}
auto linePassword = dialog.findChild<KPasswordLineEdit*>(QStringLiteral("passEdit"));
```

#### AUTO 


```{c}
auto lineVerifyPassword = pwdWidget->findChild<QLineEdit*>(QStringLiteral("lineVerifyPassword"));
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &a, const QString &b) {
        if (isDefaultFontStyleName(a)) {
            return true;
        } else if (isDefaultFontStyleName(b)) {
            return false;
        }
        return false;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->endOfWeek(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->buttonAddClicked(); }
```

#### AUTO 


```{c}
auto *innerLayout = new QVBoxLayout(groupBox);
```

#### RANGE FOR STATEMENT 


```{c}
for (QListWidgetItem *item : list) {
        availableListWidget->takeItem(availableListWidget->row(item));
        selectedListWidget->insertItem(insertionIndex(selectedListWidget, selectedInsertionPolicy), item);
        selectedListWidget->setCurrentItem(item);
        emit q->added(item);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &style) { d->_k_style_chosen_slot(style); }
```

#### RANGE FOR STATEMENT 


```{c}
for (QToolButton *button : std::as_const(m_buttons)) {
            button->removeEventFilter(q_ptr);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &shortcut : splitSequence) {
                if (shortcut.length() == 5 && shortcut.startsWith(QStringLiteral("Alt+"))) {
                    used.append(shortcut.right(1));
                }
            }
```

#### AUTO 


```{c}
auto c
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            d->editMimeType();
        }
```

#### AUTO 


```{c}
const auto contentMargins = layout()->contentsMargins();
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : actions) {
        if (action->isChecked()) {
            //qCDebug(KWidgetsAddonsLog) << "\t\taction " << action << " (text=" << action->text () << ") isChecked";

            // 2 actions checked case?
            if (action != curAction) {
                //qCDebug(KWidgetsAddonsLog) << "\t\t\tmust be newly selected one";
                return i;
            }
        }
        ++i;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QFont &ft) {
        Q_D(KFontAction);
        d->_k_slotFontChanged(ft);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->clickDate(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (Item *it : std::as_const(*item->m_children)) {
        cnt++;

        QDockWidget *dock = qobject_cast<QDockWidget *>(it->m_widget);
        if (dock) {
            if (checkChange(contents[cnt])) {
                dock->setWindowTitle(contents[cnt].accelerated());
            }
            continue;
        }
        QTabBar *tabBar = qobject_cast<QTabBar *>(it->m_widget);
        if (tabBar) {
            if (checkChange(contents[cnt])) {
                tabBar->setTabText(it->m_index, contents[cnt].accelerated());
            }
            continue;
        }
        QMenuBar *menuBar = qobject_cast<QMenuBar *>(it->m_widget);
        if (menuBar) {
            if (it->m_index >= 0) {
                QAction *maction = menuBar->actions()[it->m_index];
                if (maction) {
                    checkChange(contents[cnt]);
                    maction->setText(contents[cnt].accelerated());
                }
                continue;
            }
        }

        // we possibly reserved an accel, but we won't set it as it looks silly
        QGroupBox *groupBox = qobject_cast<QGroupBox *>(it->m_widget);
        if (groupBox && !groupBox->isCheckable()) {
            continue;
        }

        int tprop = it->m_widget->metaObject()->indexOfProperty("text");
        if (tprop != -1) {
            if (checkChange(contents[cnt])) {
                it->m_widget->setProperty("text", contents[cnt].accelerated());
            }
        } else {
            tprop = it->m_widget->metaObject()->indexOfProperty("title");
            if (tprop != -1 && checkChange(contents[cnt])) {
                it->m_widget->setProperty("title", contents[cnt].accelerated());
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &text) {
        d->m_proxyModel->setFilterRegularExpression(
                QRegularExpression(text, QRegularExpression::CaseInsensitiveOption));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        if (d->m_edited) {
            d->enterDate(date());
            Q_EMIT dateChanged(date());
        }
    }
```

#### AUTO 


```{c}
const auto keys = s.allKeys();
```

#### RANGE FOR STATEMENT 


```{c}
for (QPushButton *button : buttons) {
        if (button) {
            // keep focus in widget
            if (!hasSelectedItem && button->hasFocus()) {
                lineEdit->setFocus(Qt::OtherFocusReason);
            }
            button->setEnabled(hasSelectedItem);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *maction : menuActions) {
        if (maction->isSeparator()) {
            continue;
        }

        QString iconText = maction->iconText();
        const QString oldText = maction->text();
        // Check if iconText was generated by Qt. In that case ignore it (no support for CJK accelerators) and set it from the text.
        if (iconText == copy_of_qt_strippedText(oldText)) {
            iconText = removeAcceleratorMarker(oldText);
            if (iconText != maction->iconText()) {
                maction->setIconText(iconText);
            }
        }

        if (KAcceleratorManagerPrivate::checkChange(list[cnt])) {
            maction->setText(list[cnt].accelerated());
        }
        cnt++;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QDate date) {
        d->slotDateChanged(date);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &name : names) {
        const QString trName = translateFontName(name);
        if (!genericNames.contains(name)) {
            trNames.append(trName);
        }
        trMap.insert(trName, name);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](qreal value) {
        setFixedHeight((d->contentSize().height() * value) + d->headerSize.height());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *widget : buddysAssociatedWidgets) {
        if (QToolBar *toolBar = qobject_cast<QToolBar *>(widget)) {
            QWidget *newBuddy = toolBar->widgetForAction(buddy);
            for (QLabel *label : qAsConst(labels)) {
                label->setBuddy(newBuddy);
            }
            return;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (uint c : displayedChars) {
        result.append(QChar(c));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->_k_editMimeType(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &fName : names) {
        trMap.insert({translateFontName(fName), fName});
    }
```

#### AUTO 


```{c}
auto visibilityAction = lineEdit->findChild<QAction*>(QStringLiteral("visibilityAction"));
```

#### AUTO 


```{c}
const auto selectableActions = selectableActionGroup()->actions();
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
            const auto result = static_cast<QDialogButtonBox::StandardButton>(dlg->exec());
            switch(result) {
            case QDialogButtonBox::Ok:
            case QDialogButtonBox::Yes:
                qDebug() << "Button OK/Yes/Continue clicked."
                         << "Don't ask again status:" << (dlg->isDontAskAgainChecked() ? "Checked" : "Unchecked");
                break;
            case QDialogButtonBox::No:
                qDebug() << "Button No clicked"
                         << "Don't ask again status:" << (dlg->isDontAskAgainChecked() ? "Checked" : "Unchecked");
                break;
            case QDialogButtonBox::Cancel:
                qDebug() << "Button Cancel clicked";
                break;
            default:
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &str : strlist) {
            w = qMax(w, fm.boundingRect(str).width());
        }
```

#### AUTO 


```{c}
const auto buddysAssociatedWidgets = buddy->associatedWidgets();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        done(QDialogButtonBox::Cancel);
    }
```

#### AUTO 


```{c}
const auto actions = this->actions();
```

#### LAMBDA EXPRESSION 


```{c}
[this, action]() {
        Q_EMIT q->dateChanged(action->data().toDate());
    }
```

#### AUTO 


```{c}
auto layout = new QVBoxLayout(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { updateColor(); }
```

#### AUTO 


```{c}
auto *mainLayout = new QVBoxLayout(d->m_mainWidget);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &family) { d->_k_family_chosen_slot(family); }
```

#### RANGE FOR STATEMENT 


```{c}
for (QComboBox *box : std::as_const(d->m_comboBoxes)) {
        box->setMaximumWidth(d->m_comboWidth);
    }
```

#### AUTO 


```{c}
auto checkBox = new QCheckBox(QStringLiteral("Some text"));
```

#### RANGE FOR STATEMENT 


```{c}
for (QToolButton *toolButton : std::as_const(d->m_buttons)) {
            toolButton->setToolTip(toolTip());
            toolButton->setWhatsThis(whatsThis());
            toolButton->setStatusTip(statusTip());
        }
```

#### AUTO 


```{c}
const auto result = static_cast<QDialogButtonBox::StandardButton>(dlg->exec());
```

#### AUTO 


```{c}
auto lineEdit = linePassword->lineEdit();
```

#### AUTO 


```{c}
auto *style = q->style();
```

#### LAMBDA EXPRESSION 


```{c}
[this](QTimeLine::State state) {
        if (state == QTimeLine::NotRunning) {
            d->updateChildrenFocus(d->isExpanded);
        }
    }
```

#### AUTO 


```{c}
auto item = new QTreeWidgetItem(&m_view);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {_k_echoModeToggled();}
```

#### RANGE FOR STATEMENT 


```{c}
for (QToolButton *button : std::as_const(d->m_buttons)) {
        button->setEnabled(!hasActions);
        button->removeAction(action);
    }
```

#### AUTO 


```{c}
auto button = new QPushButton(i18n("Push me (row %1)").arg(index.row()), this);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QItemSelection &selected, const QItemSelection &deselected) {
        d->slotSelectionChanged(selected, deselected);
    }
```

#### AUTO 


```{c}
auto *style = this->style();
```

#### RANGE FOR STATEMENT 


```{c}
for (QComboBox *comboBox : std::as_const(d->m_comboBoxes)) {
        comboBox->setEditable(edit);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto type : types) {
        auto dlg = std::unique_ptr<KMessageDialog>(new KMessageDialog(type, QStringLiteral("Do you agree to action foo?"), nullptr));
        dlg->setCaption(QString{});
        dlg->setIcon(QIcon{});
        dlg->setButtons();

        auto getResult = [&]() {
            const auto result = static_cast<QDialogButtonBox::StandardButton>(dlg->exec());
            switch (result) {
            case QDialogButtonBox::Ok:
            case QDialogButtonBox::Yes:
                qDebug() << "Button OK/Yes/Continue clicked."
                         << "Don't ask again status:" << (dlg->isDontAskAgainChecked() ? "Checked" : "Unchecked");
                break;
            case QDialogButtonBox::No:
                qDebug() << "Button No clicked"
                         << "Don't ask again status:" << (dlg->isDontAskAgainChecked() ? "Checked" : "Unchecked");
                break;
            case QDialogButtonBox::Cancel:
                qDebug() << "Button Cancel clicked";
                break;
            default:
                break;
            }
        };

        getResult();

        dlg->setDontAskAgainText(QStringLiteral("Do not show this again"));
        dlg->setDontAskAgainChecked(false);
        getResult();

        dlg->setListWidgetItems(QStringList{QStringLiteral("file1"), QStringLiteral("file2")});
        getResult();

        dlg->setDetails(QStringLiteral("Some more details."));
        getResult();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
            d->_k_timeoutFinished();
        }
```

#### AUTO 


```{c}
const auto label = createLabel();
```

#### RANGE FOR STATEMENT 


```{c}
for (QToolButton *toolButton : qAsConst(d->m_buttons)) {
            toolButton->setToolTip(toolTip());
            toolButton->setWhatsThis(whatsThis());
            toolButton->setStatusTip(statusTip());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QScreen *screen : screens) {
            maxWidthForTitles = qMin(maxWidthForTitles, screen->availableGeometry().width() * 3 / 4);
        }
```

#### AUTO 


```{c}
auto label = qobject_cast<QLabel *>(widget)
```

#### AUTO 


```{c}
const auto desktopWidth = desktop.width();
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : selectableActions) {
            comboBox->addAction(action);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            d->searchEditChanged();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QTime &thisTime : qAsConst(m_timeList)) {
            if (thisTime.isValid() && thisTime >= m_minTime && thisTime <= m_maxTime) {
                q->addItem(formatTime(thisTime), thisTime);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QToolButton *button : qAsConst(d->m_buttons)) {
        button->setEnabled(!hasActions);
        button->removeAction(action);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *w : createdWidgets) {
        QFontComboBox *cb = qobject_cast<QFontComboBox *>(w);
//        qCDebug(KWidgetsAddonsLog) << "\tw=" << w << "cb=" << cb;

        if (!cb) {
            continue;
        }

        cb->setCurrentFont(QFont(family.toLower()));
//        qCDebug(KWidgetsAddonsLog) << "\t\tw spit back=" << cb->currentFont().family();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *w : childList) {
        // Ignore unless we have the direct parent
        if (qobject_cast<QWidget *>(w->parent()) != widget) {
            continue;
        }

        if (!w->isVisibleTo(widget) || (w->isTopLevel() && qobject_cast<QMenu *>(w) == nullptr)) {
            continue;
        }

        if (KAcceleratorManagerPrivate::ignored_widgets.contains(w)) {
            continue;
        }

        manageWidget(w, item, used);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->beginningOfMonth();
    }
```

#### AUTO 


```{c}
auto resizer = new KColumnResizer(parent.data());
```

#### LAMBDA EXPRESSION 


```{c}
[this](const bool state) {
                                                                        d->sizeListBox->setEnabled(state);
                                                                        d->sizeOfFont->setEnabled(state);
                                                                  }
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *button : buttons) {
        font = button->font();
        font.setPointSize(s);
        button->setFont(font);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : selectableActions) {
        const QString text = ::DropAmpersands(action->text());
        if (cs == Qt::CaseSensitive) {
            if (text == compare) {
                return action;
            }

        } else if (cs == Qt::CaseInsensitive) {
            if (text.toLower() == compare) {
                return action;
            }
        }
    }
```

#### AUTO 


```{c}
auto *detailsHLayout = new QHBoxLayout{};
```

#### AUTO 


```{c}
auto linePassword = dialog.findChild<KPasswordLineEdit *>(QStringLiteral("passEdit"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &zoneId : zoneIds) {
        m_zones << QTimeZone(zoneId);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=] {
        busyWidget->setVisible(!busyWidget->isVisible());
    }
```

#### AUTO 


```{c}
auto *dlg = new KMessageDialog(KMessageDialog::Error,
                                       QObject::tr("Could not start the \"keditfiletype5\" executable, please check your installation."),
                                       widget);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &family) {
        family_chosen_slot(family);
    }
```

#### AUTO 


```{c}
const auto actions = sa->actions();
```

#### RANGE FOR STATEMENT 


```{c}
for (QListWidgetItem *item : list) {
        selectedListWidget->takeItem(selectedListWidget->row(item));
        availableListWidget->insertItem(insertionIndex(availableListWidget, availableInsertionPolicy), item);
        availableListWidget->setCurrentItem(item);
        Q_EMIT q->removed(item);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const double size) {
        _k_size_value_slot(size);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QComboBox *box : qAsConst(m_comboBoxes)) {
            box->removeEventFilter(q_ptr);
            QObject::disconnect(box, nullptr, q_ptr, nullptr); // To prevent a crash in comboBoxDeleted()
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QLabel *label : std::as_const(labels)) {
                label->setBuddy(newBuddy);
            }
```

#### AUTO 


```{c}
auto tooltip = new KToolTipWidget();
```

#### AUTO 


```{c}
auto *buttonYes = d->m_buttonBox->button(QDialogButtonBox::Yes);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->beginningOfWeek();
    }
```

#### AUTO 


```{c}
const auto menuActions = menu.actions();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &c : std::as_const(chars)) {
        int unicode = c.toInt(nullptr, 16);
        if (!allPlanesEnabled && QChar::requiresSurrogates(unicode)) {
            continue;
        }
        QString link = QLatin1String("<a href=\"") + c + QLatin1String("\">");
        if (s_data()->isPrint(unicode)) {
            link += QLatin1String("&#8206;&#") + QString::number(unicode) + QLatin1String(";&nbsp;");
        }
        link += QLatin1String("U+") + c + QLatin1Char(' ');
        link += s_data()->name(unicode).toHtmlEscaped() + QLatin1String("</a>");
        s.replace(c, link);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QToolButton *button : qAsConst(d->m_buttons)) {
        button->setEnabled(true);
        button->insertAction(before, action);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &genericName : genericNames) {
        const QString trGenericName = translateFontName(genericName);
        if (trMap.contains(trGenericName)) {
            trNames.prepend(trGenericName);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->buttonUpClicked(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            updateColor();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &c : chars2) {
        int unicode = c.toInt(nullptr, 16);
        if (!allPlanesEnabled && QChar::requiresSurrogates(unicode)) {
            continue;
        }
        QString link = QLatin1String("<a href=\"") + c + QLatin1String("\">");
        if (s_data()->isPrint(unicode)) {
            link += QLatin1String("&#8206;&#") + QString::number(unicode) + QLatin1String(";&nbsp;");
        }
        link += QLatin1String("U+") + c + QLatin1Char(' ');
        link += s_data()->name(unicode).toHtmlEscaped() + QLatin1String("</a>");
        s.replace(c, link);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QDate &d) {
        qDebug() << "dateEdited" << d;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QComboBox *box : qAsConst(m_comboBoxes)) {
            box->removeEventFilter(q_ptr);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &style) {
        _k_style_chosen_slot(style);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            d->activateSearchLine();
        }
```

#### CONST EXPRESSION 


```{c}
constexpr int borderSize = 2;
```

#### RANGE FOR STATEMENT 


```{c}
for (FormLayoutWidgetItem *item : qAsConst(m_formWidgetItemList)) {
            item->setWidth(width);
            item->formLayout()->update();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &style) {
        style_chosen_slot(style);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        QEvent ev(QEvent::WhatsThis);
        qApp->sendEvent(ui.userEdit, &ev);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[d]() {
        d->slotModelReset();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QComboBox *comboBox : qAsConst(d->m_comboBoxes)) {
        comboBox->setEnabled(!hasActions);
        comboBox->removeAction(action);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (int lsize : sizes) {
                int diff = qAbs(refsize - lsize);
                if (mindiff > diff) {
                    mindiff = diff;
                    size = lsize;
                }
            }
```

#### AUTO 


```{c}
auto timer = new QTimer(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (unsigned char c : utf8) {
        html += s_data()->formatCode(c, 3, QStringLiteral("\\"), 8);
    }
```

#### AUTO 


```{c}
auto getResult = [&]() {
            const auto result = static_cast<QDialogButtonBox::StandardButton>(dlg->exec());
            switch (result) {
            case QDialogButtonBox::Ok:
            case QDialogButtonBox::Yes:
                qDebug() << "Button OK/Yes/Continue clicked."
                         << "Don't ask again status:" << (dlg->isDontAskAgainChecked() ? "Checked" : "Unchecked");
                break;
            case QDialogButtonBox::No:
                qDebug() << "Button No clicked"
                         << "Don't ask again status:" << (dlg->isDontAskAgainChecked() ? "Checked" : "Unchecked");
                break;
            case QDialogButtonBox::Cancel:
                qDebug() << "Button Cancel clicked";
                break;
            default:
                break;
            }
        };
```

#### AUTO 


```{c}
auto it = std::find_if(parentGroups.cbegin(), parentGroups.cend(), [maj](const QStandardItem *item) {
            return maj == item->text();
        });
```

#### AUTO 


```{c}
auto linePassword = dialog.findChild<QLineEdit*>(QStringLiteral("passEdit"));
```

#### RANGE FOR STATEMENT 


```{c}
for (QTreeWidgetItem *item : qAsConst(checkedItems)) {
        mimeList.append(item->parent()->text(0) + QLatin1Char('/') + item->text(0));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *widget : std::as_const(m_widgets)) {
            width = qMax(widget->sizeHint().width(), width);
        }
```

#### AUTO 


```{c}
const auto children = parent->findChildren<T>();
```

#### LAMBDA EXPRESSION 


```{c}
[this] {KMessageWidgetPrivate::setPalette();}
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QFont &font) {
        _k_displaySample(font);
    }
```

#### AUTO 


```{c}
auto innerLayout = new QVBoxLayout(groupBox);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->beginningOfWeek(); }
```

#### AUTO 


```{c}
auto layout1 = parent->findChild<QLayout *>(QStringLiteral("layout1"));
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        timeout();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QFont &font) { d->_k_displaySample(font); }
```

#### AUTO 


```{c}
const auto types = {KMessageDialog::QuestionYesNo,
                        KMessageDialog::QuestionYesNoCancel,
                        KMessageDialog::WarningYesNo,
                        KMessageDialog::WarningYesNoCancel,
                        KMessageDialog::WarningContinueCancel,
                        KMessageDialog::Information,
                        KMessageDialog::Sorry,
                        KMessageDialog::Error};
```

#### LAMBDA EXPRESSION 


```{c}
[d](const QModelIndex &topLeft, const QModelIndex &bottomRight) {
            d->dataChanged(topLeft, bottomRight);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            d->_k_activateSearchLine();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QStandardItem *item : checkedItems) {
        QMimeType mime = db.mimeTypeForName(item->parent()->text() + QLatin1Char('/') + item->text());
        Q_ASSERT(mime.isValid());
        patternList += mime.globPatterns();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (uint c2 : seeAlso) {
            if (!allPlanesEnabled && QChar::requiresSurrogates(c2)) {
                continue;
            }
            html += QLatin1String("<li><a href=\"") + QString::number(c2, 16) + QLatin1String("\">");
            if (s_data()->isPrint(c2)) {
                html += QLatin1String("&#8206;&#") + QString::number(c2) + QLatin1String("; ");
            }
            html += s_data()->formatCode(c2) + QLatin1Char(' ') + s_data()->name(c2).toHtmlEscaped() + QLatin1String("</a></li>");
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](uint c) {
        d->charSelected(c);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        qDeleteAll(d->m_entries);
        d->m_entries.clear();
        rebuildMenu();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QListWidgetItem *item : list) {
        availableListWidget->takeItem(availableListWidget->row(item));
        selectedListWidget->insertItem(insertionIndex(selectedListWidget, selectedInsertionPolicy), item);
        selectedListWidget->setCurrentItem(item);
        Q_EMIT q->added(item);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto c : qAsConst(result)) {
        sortedResult.append(c);
    }
```

#### AUTO 


```{c}
auto lineVerifyPassword = pwdWidget->findChild<QLineEdit *>(QStringLiteral("lineVerifyPassword"));
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *w : childList) {
        // Ignore unless we have the direct parent
        if (qobject_cast<QWidget *>(w->parent()) != widget) {
            continue;
        }

        if (!w->isVisibleTo(widget) || (w->isTopLevel() && qobject_cast<QMenu *>(w) == nullptr)) {
            continue;
        }

        if (KAcceleratorManagerPrivate::ignored_widgets.contains(w)) {
            continue;
        }

        manageWidget(w, item);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &family : qAsConst(lstSys)) {
            if ((fontListCriteria & FixedWidthFonts) > 0 && !dbase.isFixedPitch(family)) {
                continue;
            }
            if (((fontListCriteria & (SmoothScalableFonts | ScalableFonts)) == ScalableFonts) &&
                    !dbase.isBitmapScalable(family)) {
                continue;
            }
            if ((fontListCriteria & SmoothScalableFonts) > 0 && !dbase.isSmoothlyScalable(family)) {
                continue;
            }
            lstFonts.append(family);
        }
```

#### AUTO 


```{c}
auto linePassword = pwdWidget.findChild<KPasswordLineEdit *>(QStringLiteral("linePassword"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &approxEquivalent : approxEquivalents) {
            html += QLatin1String("<li>") + createLinks(approxEquivalent.toHtmlEscaped()) + QLatin1String("</li>");
        }
```

#### AUTO 


```{c}
auto lineVerifyPassword = pwdWidget.findChild<QLineEdit*>(QStringLiteral("lineVerifyPassword"));
```

#### LAMBDA EXPRESSION 


```{c}
[this](const bool state) {
            q->setFont(selFont, state);
        }
```

#### AUTO 


```{c}
auto parent = new QWidget();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            d->_k_copyFullText();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QFont &font) {
        displaySample(font);
    }
```

#### AUTO 


```{c}
auto pwdWidget = new KNewPasswordWidget(widget);
```

#### AUTO 


```{c}
const auto types = { KMessageDialog::QuestionYesNo,
                         KMessageDialog::QuestionYesNoCancel,
                         KMessageDialog::WarningYesNo,
                         KMessageDialog::WarningYesNoCancel,
                         KMessageDialog::WarningContinueCancel,
                         KMessageDialog::Information,
                         KMessageDialog::Sorry,
                         KMessageDialog::Error };
```

#### RANGE FOR STATEMENT 


```{c}
for (const GridColumnInfo &info : std::as_const(m_gridColumnInfoList)) {
            info.layout->setColumnMinimumWidth(info.column, width);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QComboBox *comboBox : std::as_const(d->m_comboBoxes)) {
        comboBox->setEnabled(true);
        comboBox->insertAction(before, action);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &size) { d->_k_size_chosen_slot(size); }
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *w : createdWidgets) {
        QFontComboBox *cb = qobject_cast<QFontComboBox *>(w);
        //        qCDebug(KWidgetsAddonsLog) << "\tw=" << w << "cb=" << cb;

        if (!cb) {
            continue;
        }

        cb->setCurrentFont(QFont(family.toLower()));
        //        qCDebug(KWidgetsAddonsLog) << "\t\tw spit back=" << cb->currentFont().family();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[d](int value) {
            d->comboBoxCurrentIndexChanged(value);
        }
```

#### AUTO 


```{c}
auto label = new QLabel(groupBox);
```

#### RANGE FOR STATEMENT 


```{c}
for (uint c2 : decomposition) {
            if (!allPlanesEnabled && QChar::requiresSurrogates(c2)) {
                continue;
            }
            html += QLatin1String("<li>") + createLinks(s_data()->formatCode(c2, 4, QString())) + QLatin1String("</li>");
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        slotTimeLineFinished();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (uint c : qAsConst(returnRes)) {
        result.remove(c);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QModelIndex &parent, int first, int last) {
                rowsInserted(parent, first, last);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[&, timer]() {
            d->_k_resizeCells();
            timer->deleteLater();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->buttonDownClicked();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &family : std::as_const(lstSys)) {
            if ((fontListCriteria & FixedWidthFonts) > 0 && !dbase.isFixedPitch(family)) {
                continue;
            }
            if (((fontListCriteria & (SmoothScalableFonts | ScalableFonts)) == ScalableFonts) && !dbase.isBitmapScalable(family)) {
                continue;
            }
            if ((fontListCriteria & SmoothScalableFonts) > 0 && !dbase.isSmoothlyScalable(family)) {
                continue;
            }
            lstFonts.append(family);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            slotTomorrow();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QDate date) {
        if (d->isInDateRange(date)) {
            d->enterDate(date);
        }
    }
```

#### AUTO 


```{c}
const auto password = QStringLiteral("DHlKOJ1GotXWVE_fnqm1");
```

#### LAMBDA EXPRESSION 


```{c}
[this] { d->_k_buttonClicked(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (Item *it : qAsConst(*item->m_children)) {
        cnt++;

        QDockWidget *dock = qobject_cast<QDockWidget *>(it->m_widget);
        if (dock) {
            if (checkChange(contents[cnt])) {
                dock->setWindowTitle(contents[cnt].accelerated());
            }
            continue;
        }
        QTabBar *tabBar = qobject_cast<QTabBar *>(it->m_widget);
        if (tabBar) {
            if (checkChange(contents[cnt])) {
                tabBar->setTabText(it->m_index, contents[cnt].accelerated());
            }
            continue;
        }
        QMenuBar *menuBar = qobject_cast<QMenuBar *>(it->m_widget);
        if (menuBar) {
            if (it->m_index >= 0) {
                QAction *maction = menuBar->actions()[it->m_index];
                if (maction) {
                    checkChange(contents[cnt]);
                    maction->setText(contents[cnt].accelerated());
                }
                continue;
            }
        }

        // we possibly reserved an accel, but we won't set it as it looks silly
        QGroupBox *groupBox = qobject_cast<QGroupBox *>(it->m_widget);
        if (groupBox && !groupBox->isCheckable()) {
            continue;
        }

        int tprop = it->m_widget->metaObject()->indexOfProperty("text");
        if (tprop != -1)  {
            if (checkChange(contents[cnt])) {
                it->m_widget->setProperty("text", contents[cnt].accelerated());
            }
        } else {
            tprop = it->m_widget->metaObject()->indexOfProperty("title");
            if (tprop != -1 && checkChange(contents[cnt])) {
                it->m_widget->setProperty("title", contents[cnt].accelerated());
            }
        }
    }
```

#### AUTO 


```{c}
const auto menuActions = m_popup->actions();
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *w : childList) {
        if (!w->isVisibleTo(widget) || (w->isTopLevel() && qobject_cast<QMenu *>(w) == nullptr)) {
            continue;
        }

        if (KAcceleratorManagerPrivate::ignored_widgets.contains(w)) {
            continue;
        }

        manageWidget(w, item, used);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->_k_forward(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](int index) {
        d->selectTimeZone(index);
    }
```

#### AUTO 


```{c}
const auto actions = q->actions();
```

#### RANGE FOR STATEMENT 


```{c}
for (QToolButton *button : qAsConst(m_buttons)) {
            button->removeEventFilter(q_ptr);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QDate &d) {
        qDebug() << "dateChanged" << d;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            d->_k_editMimeType();
        }
```

#### AUTO 


```{c}
const auto buddysAssociatedWidgets = d->buddy->associatedWidgets();
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &text) {
        d->editDate(text);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &s : genericTranslatedNames) {
        auto nIt = m_qtFamilies.find(s);
        if (nIt != m_qtFamilies.cend()) {
            list.push_back(s);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &str) {_k_showToggleEchoModeAction(str);}
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
            const auto result = static_cast<QDialogButtonBox::StandardButton>(dlg->exec());
            switch (result) {
            case QDialogButtonBox::Ok:
            case QDialogButtonBox::Yes:
                qDebug() << "Button OK/Yes/Continue clicked."
                         << "Don't ask again status:" << (dlg->isDontAskAgainChecked() ? "Checked" : "Unchecked");
                break;
            case QDialogButtonBox::No:
                qDebug() << "Button No clicked"
                         << "Don't ask again status:" << (dlg->isDontAskAgainChecked() ? "Checked" : "Unchecked");
                break;
            case QDialogButtonBox::Cancel:
                qDebug() << "Button Cancel clicked";
                break;
            default:
                break;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] { d->actuallyAccept(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &line : textLines) {
        int lineWidth = fm.width(line);
        if (lineWidth > labelWidth) {
            squeezed = true;
            squeezedLines << fm.elidedText(line, d->elideMode, labelWidth);
        } else {
            squeezedLines << line;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->nextMonth();
    }
```

#### AUTO 


```{c}
auto busyLayout = new QHBoxLayout(busyWidget);
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : actions) {
        QToolButton *button = new QToolButton(content);
        button->setDefaultAction(action);
        button->setToolButtonStyle(Qt::ToolButtonTextBesideIcon);
        buttons.append(button);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &style : styles) {
            if (isDefaultFontStyleName(style)) {
                styleName = style;
                break;
            } else {
                // nothing more we can do
            }
        }
```

#### AUTO 


```{c}
auto busyWidget = new QWidget(&window);
```

#### AUTO 


```{c}
auto widget = static_cast<QWidget*>(ce->child());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QMimeType &mt : mimetypes) {
        const QString mimetype = mt.name();
        const int index = mimetype.indexOf(QLatin1Char('/'));
        const QString maj = mimetype.left(index);

        if (!groups.isEmpty() && !groups.contains(maj)) {
            continue;
        }

        QTreeWidgetItem *groupItem;
        QMap<QString, QTreeWidgetItem *>::Iterator mit = groupItems.find(maj);
        if (mit == groupItems.end()) {
            groupItem = new QTreeWidgetItem(mimeTypeTree, QStringList(maj));
            groupItems.insert(maj, groupItem);
            if (maj == defaultgroup) {
                idefault = groupItem;
            }
        } else {
            groupItem = mit.value();
        }

        const QString min = mimetype.mid(index + 1);
        QTreeWidgetItem *item = new QTreeWidgetItem(groupItem, QStringList(min));
        item->setIcon(0, QIcon::fromTheme(mt.iconName()));

        int cl = 1;

        if (visuals & KMimeTypeChooser::Comments) {
            item->setText(cl, mt.comment());
            cl++;
        }

        if (visuals & KMimeTypeChooser::Patterns) {
            item->setText(cl, mt.globPatterns().join(QLatin1String("; ")));
        }

        if (selMimeTypes.contains(mimetype)) {
            item->setCheckState(0, Qt::Checked);
            groupItem->setExpanded(true);
            agroupisopen = true;
            if (!firstChecked) {
                firstChecked = item;
            }
        } else {
            item->setCheckState(0, Qt::Unchecked);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &line : textLines) {
        int lineWidth = fm.boundingRect(line).width();
        if (lineWidth > labelWidth) {
            squeezed = true;
            squeezedLines << fm.elidedText(line, d->elideMode, labelWidth);
        } else {
            squeezedLines << line;
        }
    }
```

#### AUTO 


```{c}
auto it = m_dateMap.constBegin();
```

#### AUTO 


```{c}
const auto label = createLabel(QStringLiteral("aaabbbccc"));
```

#### AUTO 


```{c}
auto linePassword = pwdWidget.findChild<KPasswordLineEdit*>(QStringLiteral("linePassword"));
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *widget : buddysAssociatedWidgets) {
        if (QToolBar *toolBar = qobject_cast<QToolBar *>(widget)) {
            QWidget *newBuddy = toolBar->widgetForAction(buddy);
            for (QLabel *label : std::as_const(labels)) {
                label->setBuddy(newBuddy);
            }
            return;
        }
    }
```

#### AUTO 


```{c}
auto dlg = std::unique_ptr<KMessageDialog>(new KMessageDialog(type,
                                                                      QStringLiteral("Do you agree to action foo?"),
                                                                      nullptr));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QTimeZone &zone : qAsConst(m_zones)) {
        ui.m_timeZoneCombo->addItem(QString::fromUtf8(zone.id()), zone.id());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->endOfMonth();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &text : std::as_const(initialTexts)) {
            menu.addAction(text);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : actions) {
        if (action->isChecked()) {
            // qCDebug(KWidgetsAddonsLog) << "\t\taction " << action << " (text=" << action->text () << ") isChecked";

            // 2 actions checked case?
            if (action != curAction) {
                // qCDebug(KWidgetsAddonsLog) << "\t\t\tmust be newly selected one";
                return i;
            }
        }
        ++i;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { _k_chooseColor(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this] { d->_k_timeoutFinished(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QAction *action : menuActions) {
        if (action->isSeparator()) {
            if (!lastIsSeparator) { // Qt gets rid of duplicate separators, so we should too
                ret.append(QStringLiteral("separator"));
            }
            lastIsSeparator = true;
        } else {
            lastIsSeparator = false;
            if (action->menu()) {
                ret.append(QStringLiteral("submenu"));
            } else {
                const QString text = func(action);
                ret.append(text);
            }
        }
    }
```

#### AUTO 


```{c}
auto datePicker = new KDatePicker();
```

#### RANGE FOR STATEMENT 


```{c}
for (int it : std::as_const(lst)) {
            QAction *const action = addAction(QString::number(it));
            if (it == size) {
                setCurrentAction(action);
            }
        }
```

#### AUTO 


```{c}
const auto today = QDate::currentDate();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->_k_activateSearchLine(); }
```

#### AUTO 


```{c}
auto label = std::make_unique<KSqueezedTextLabel>(QStringLiteral(""), nullptr);
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        d->actuallyAccept();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Item *it : qAsConst(*item->m_children)) {
        if (it->m_widget && it->m_widget->isVisibleTo(item->m_widget)) {
            calculateAccelerators(it, used);
        }
    }
```

#### AUTO 


```{c}
auto groupBox = new KCollapsibleGroupBox;
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        slotTriggered();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            d->search();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QItemSelection &selected, const QItemSelection &deselected) {
                                                            pageSelected(selected, deselected);
                                                        }
```

#### LAMBDA EXPRESSION 


```{c}
[]() {
            // Empty, just creating a connection to trigger a crash
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QTreeWidgetItem *item : qAsConst(checkedItems)) {
        QMimeType mime = db.mimeTypeForName(item->parent()->text(0) + QLatin1Char('/') + item->text(0));
        Q_ASSERT(mime.isValid());
        patternList += mime.globPatterns();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            slotNoDate();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QTimeLine::State state) {
        if (state == QTimeLine::NotRunning) {
            //when collapsed hide contents to save resources and more importantly get it out the focus chain
            d->updateChildrenVisibility(d->isExpanded);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QModelIndex &index) {
        d->doubleClicked(index);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QMimeType &mt : mimetypes) {
        const QString mimetype = mt.name();
        const int index = mimetype.indexOf(QLatin1Char('/'));
        // e.g. "text", "audio", "inode"
        const QString maj = mimetype.left(index);

        if (!groups.isEmpty() && !groups.contains(maj)) {
            continue;
        }

        QStandardItem *groupItem;

        auto it = std::find_if(parentGroups.cbegin(), parentGroups.cend(), [maj](const QStandardItem *item) {
            return maj == item->text();
        });

        if (it == parentGroups.cend()) {
            groupItem = new QStandardItem(maj);
            groupItem->setFlags(Qt::ItemIsEnabled);
            // a dud item to fill the patterns column next to "groupItem" and setFlags() on it
            QStandardItem *secondColumn = new QStandardItem();
            secondColumn->setFlags(Qt::NoItemFlags);
            QStandardItem *thirdColumn = new QStandardItem();
            thirdColumn->setFlags(Qt::NoItemFlags);
            m_model->appendRow({groupItem, secondColumn, thirdColumn});
            parentGroups.push_back(groupItem);
            if (maj == defaultgroup) {
                idefault = groupItem;
            }
        } else {
            groupItem = *it;
        }

        // e.g. "html", "plain", "mp4"
        const QString min = mimetype.mid(index + 1);
        QStandardItem *mime = new QStandardItem(QIcon::fromTheme(mt.iconName()), min);
        mime->setFlags(Qt::ItemIsSelectable | Qt::ItemIsUserCheckable | Qt::ItemIsEnabled);

        QStandardItem *comments = nullptr;
        if (visuals & KMimeTypeChooser::Comments) {
            comments = new QStandardItem(mt.comment());
            comments->setFlags(Qt::ItemIsSelectable | Qt::ItemIsEnabled);
        }

        QStandardItem *patterns = nullptr;

        if (visuals & KMimeTypeChooser::Patterns) {
            patterns = new QStandardItem(mt.globPatterns().join(QLatin1String("; ")));
            patterns->setFlags(Qt::ItemIsSelectable | Qt::ItemIsEnabled);
        }

        groupItem->appendRow(QList<QStandardItem *>({mime, comments, patterns}));

        if (selMimeTypes.contains(mimetype)) {
            mime->setCheckState(Qt::Checked);
            const QModelIndex index = m_proxyModel->mapFromSource(m_model->indexFromItem(groupItem));
            mimeTypeTree->expand(index);
            agroupisopen = true;
            if (!firstChecked) {
                firstChecked = mime;
            }
        } else {
            mime->setCheckState(Qt::Unchecked);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (int size : smoothSizes) {
            sizes.append(size);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QDate &date) { d->enterDate(date); }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        _k_echoModeToggled();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QLocale &calendarLocale : std::as_const(m_calendarLocales)) {
        ui.m_calendarCombo->addItem(calendarLocale.name(), calendarLocale);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &text) { d->editDate(text); }
```

#### AUTO 


```{c}
auto *okButton = d->m_buttonBox->button(QDialogButtonBox::Ok);
```

#### RANGE FOR STATEMENT 


```{c}
for (Item *it : std::as_const(*item->m_children)) {
        contents << it->m_content;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QToolButton *button : qAsConst(buttons)) {
            layout->addWidget(button);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &s : std::as_const(searchStrings)) {
        const QRegularExpressionMatch match = hexExp.match(s);
        if (match.hasMatch()) {
            const QString cap = match.captured(1);
            returnRes.append(cap.toInt(nullptr, 16));
            // search for "1234" instead of "0x1234"
            if (s.length() == 6 || s.length() == 7) {
                searchStrings[searchStrings.indexOf(s)] = cap;
            }
        }
        // try to parse string as decimal number
        bool ok;
        int unicode = s.toInt(&ok);
        if (ok && unicode >= 0 && unicode <= QChar::LastValidCodePoint) {
            returnRes.append(unicode);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->clickDate();
    }
```

#### AUTO 


```{c}
const auto allFamilies = dbase.families();
```

#### LAMBDA EXPRESSION 


```{c}
[d]() {
            d->slotModelAboutToBeReset();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->buttonRemoveClicked(); }
```

#### LAMBDA EXPRESSION 


```{c}
[d]() {
        d->restoreScrollBarState();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        colorChosen();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (int it : qAsConst(lst)) {
            QAction *const action = addAction(QString::number(it));
            if (it == size) {
                setCurrentAction(action);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QTime &time : qAsConst(timeList)) {
            if (time.isValid() && !d->m_timeList.contains(time)) {
                d->m_timeList.append(time);
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            updateWidth();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QToolButton *button : std::as_const(d->m_buttons)) {
        button->setEnabled(true);
        button->insertAction(before, action);
    }
```

#### AUTO 


```{c}
auto dlg = std::unique_ptr<KMessageDialog>(new KMessageDialog(type, QStringLiteral("Do you agree to action foo?"), nullptr));
```

#### LAMBDA EXPRESSION 


```{c}
[this](uint c) {
        d->updateCurrentChar(c);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->beginningOfMonth(); }
```

#### AUTO 


```{c}
auto spinBox = new QLineEdit(&collapsible);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->buttonDownClicked(); }
```

#### AUTO 


```{c}
auto linePassword = pwdWidget->findChild<KPasswordLineEdit*>(QStringLiteral("linePassword"));
```

#### LAMBDA EXPRESSION 


```{c}
[d](const QModelIndex &current, const QModelIndex &before) {
        d->slotCurrentPageChanged(current, before);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &size) {
        _k_size_chosen_slot(size);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](const QModelIndex &index) {
        auto rect = m_view.visualRect(index);
        const auto pos = m_view.viewport()->mapToGlobal(rect.topLeft());
        rect.moveTo(pos);
        auto button = new QPushButton(i18n("Push me (row %1)").arg(index.row()), this);
        m_tooltipWidget.showBelow(rect, button, m_view.nativeParentWidget()->windowHandle());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (unsigned char c : utf8) {
        html += QLatin1Char(' ') + s_data()->formatCode(c, 2, QStringLiteral("0x"));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (uint c : std::as_const(returnRes)) {
        result.remove(c);
    }
```

#### AUTO 


```{c}
auto widget2 = parent->findChild<QWidget *>(QStringLiteral("widget2"));
```

#### AUTO 


```{c}
auto it = m_qtFamilies.cbegin();
```

#### AUTO 


```{c}
auto visibilityAction = lineEdit->findChild<QAction *>(QStringLiteral("visibilityAction"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QChar c : qAsConst(label)) {
            if (c.unicode() >= 0x2e00) { // rough, but should be sufficient
                hasCJK = true;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (int block : blocks) {
        if (!allPlanesEnabled) {
            const QVector<uint> contents = s_data()->blockContents(block);
            if (!contents.isEmpty() && QChar::requiresSurrogates(contents.at(0))) {
                continue;
            }
        }
        blockCombo->addItem(s_data()->blockName(block), QVariant(block));
        if (index == 0) {
            chars << s_data()->blockContents(block);
        }
    }
```

#### AUTO 


```{c}
auto busyLabel = new QLabel(QStringLiteral("Busy..."), &window);
```

#### RANGE FOR STATEMENT 


```{c}
for (const RecentFilesEntry *entry : d->m_entries) {
        d->m_settings->setArrayIndex(index);
        d->m_settings->setValue(QStringLiteral("url"), entry->url);
        d->m_settings->setValue(QStringLiteral("displayName"), entry->displayName);
        ++index;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[url](RecentFilesEntry *entry) {
        return entry->url == url;
    }
```

#### AUTO 


```{c}
auto linePassword = pwdWidget->findChild<KPasswordLineEdit *>(QStringLiteral("linePassword"));
```

#### RANGE FOR STATEMENT 


```{c}
for (qreal size : qAsConst(sizes)) {
        m_sizeListBox->addItem(formatFontSize(size));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QKeySequence &sequence : actionShortcuts) {
            const QString sequenceAsText = sequence.toString(QKeySequence::PortableText);
            const QStringList splitSequence = sequenceAsText.split(QStringLiteral(", "));
            for (const QString &shortcut : splitSequence) {
                if (shortcut.length() == 5 && shortcut.startsWith(QStringLiteral("Alt+"))) {
                    used.append(shortcut.right(1));
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QObject *child : children) {
        QWidget *widget = qobject_cast<QWidget *>(child);
        if (!widget) {
            continue;
        }
        // Restore old focus policy if expanded, remove from focus chain otherwise.
        if (expanded) {
            widget->setFocusPolicy(focusMap.value(widget));
        } else {
            widget->setFocusPolicy(Qt::NoFocus);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &equivalent : equivalents) {
            html += QLatin1String("<li>") + createLinks(equivalent.toHtmlEscaped()) + QLatin1String("</li>");
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QDateTime &dt) {
        qDebug() << "dateTimeChanged" << dt;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (qreal size : qAsConst(sizes)) {
        sizeListBox->addItem(formatFontSize(size));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const GridColumnInfo &info : qAsConst(m_gridColumnInfoList)) {
            info.layout->setColumnMinimumWidth(info.column, width);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QAction *action) { d->selectDate(action); }
```

#### LAMBDA EXPRESSION 


```{c}
[maj](const QStandardItem *item) {
            return maj == item->text();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            slotNextWeek();
        }
```

#### AUTO 


```{c}
const auto deskWidthPortion = screen()->geometry().width() * 0.85;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &s : std::as_const(searchStrings)) {
        QSet<uint> partResult = getMatchingChars(s.toLower());
        if (firstSubString) {
            result = partResult;
            firstSubString = false;
        } else {
            result = result.intersect(partResult);
        }
    }
```

#### AUTO 


```{c}
auto visibilityAction = linePassword->findChild<QAction *>(QStringLiteral("visibilityAction"));
```

#### AUTO 


```{c}
auto widget = new QWidget();
```

#### LAMBDA EXPRESSION 


```{c}
[&,timer]() {
            d->_k_resizeCells();
            timer->deleteLater();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &note : notes) {
            html += QLatin1String("<li>") + createLinks(note.toHtmlEscaped()) + QLatin1String("</li>");
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &str : strlist) {
        listWidth = qMax(listWidth, fm.boundingRect(str).width());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *widget : {d->m_ui->familyListWidget, d->m_ui->styleListWidget, d->m_ui->sizeListWidget}) {
        widget->setMinimumHeight(minimumListHeight(widget, visibleItems));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        passwordStatusChanged();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QAction *action) {
        d->selectDate(action);
    }
```

#### AUTO 


```{c}
auto innerLayout = new QVBoxLayout;
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        d->buttonClicked();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &str) {
        showToggleEchoModeAction(str);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[d]() {
            d->modelChanged();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QUrl &url) {
        d->linkClicked(url);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QComboBox *comboBox : qAsConst(d->m_comboBoxes)) {
            comboBox->setToolTip(toolTip());
            comboBox->setWhatsThis(whatsThis());
            comboBox->setStatusTip(statusTip());
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        toggleEchoMode();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QChar c : std::as_const(label)) {
            if (c.unicode() >= 0x2e00) { // rough, but should be sufficient
                hasCJK = true;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QComboBox *box : qAsConst(d->m_comboBoxes)) {
        if (d->m_maxComboViewCount != -1) {
            box->setMaxVisibleItems(d->m_maxComboViewCount);
        } else
            // hardcoded qt default
        {
            box->setMaxVisibleItems(10);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &text) {
        d->activated(text);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (QListWidgetItem *item) { d->itemDoubleClicked(item); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const double size) {
        size_value_slot(size);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &s : qAsConst(searchStrings)) {
        const QRegularExpressionMatch match = hexExp.match(s);
        if (match.hasMatch()) {
            const QString cap = match.captured(1);
            returnRes.append(cap.toInt(nullptr, 16));
            // search for "1234" instead of "0x1234"
            if (s.length() == 6 || s.length() == 7) {
                searchStrings[searchStrings.indexOf(s)] = cap;
            }
        }
        // try to parse string as decimal number
        bool ok;
        int unicode = s.toInt(&ok);
        if (ok && unicode >= 0 && unicode <= QChar::LastValidCodePoint) {
            returnRes.append(unicode);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->buttonRemoveClicked();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        KMessageWidgetPrivate::setPalette();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : selectedIndexes) {
        selection << indexToConfigString(index);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QComboBox *comboBox : qAsConst(d->m_comboBoxes)) {
        comboBox->setEnabled(true);
        comboBox->insertAction(before, action);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QComboBox *comboBox : qAsConst(d->m_comboBoxes)) {
        comboBox->setEditable(edit);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->buttonAddClicked();
    }
```

#### AUTO 


```{c}
const auto deskWidthPortion = QApplication::desktop()->screenGeometry(this).width() * 0.85;
```

#### LAMBDA EXPRESSION 


```{c}
[=](QVariant value) {
            rotation = value.toReal();
            q->update(); // repaint new rotation
        }
```

#### AUTO 


```{c}
auto busyIndicator = new KBusyIndicatorWidget(&window);
```

#### AUTO 


```{c}
const auto minDate = QDate::fromString(parser.value(QStringLiteral("min-date")), Qt::ISODate);
```

#### AUTO 


```{c}
auto datePicker = combo.findChild<KDatePickerPopup *>();
```

#### LAMBDA EXPRESSION 


```{c}
[this](int index) {
        d->selectCalendar(index);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QLabel *label : qAsConst(labels)) {
                label->setBuddy(newBuddy);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *widget : buddysAssociatedWidgets) {
            if (QToolBar *toolBar = qobject_cast<QToolBar *>(widget)) {
                QWidget *newBuddy = toolBar->widgetForAction(d->buddy);
                d->label->setBuddy(newBuddy);
            }
        }
```

#### AUTO 


```{c}
auto layout2 = parent->findChild<QLayout *>(QStringLiteral("layout2"));
```

#### AUTO 


```{c}
const auto actions = d->m_actionGroup->actions();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->_k_forward();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
            d->timeoutFinished();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QListWidgetItem *item : list) {
        selectedListWidget->takeItem(selectedListWidget->row(item));
        availableListWidget->insertItem(insertionIndex(availableListWidget, availableInsertionPolicy), item);
        availableListWidget->setCurrentItem(item);
        emit q->removed(item);
    }
```

