#### AUTO 


```{c}
auto filePathLayout = new QHBoxLayout();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &foundPath : foundPaths) {
                    paths.append(foundPath);
                }
```

#### AUTO 


```{c}
auto logModeConfigurationWidget = new CupsConfigurationWidget();
```

#### AUTO 


```{c}
auto *authenticationLayout = new QVBoxLayout();
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractButton *button : buttons) {
        const auto currentButtonFormat = static_cast<Globals::DateFormat>(mDateFormatGroup->id(button));
        const QString formattedDate = Globals::instance().formatDate(currentButtonFormat, QDateTime().currentDateTime());
        button->setText(i18nc("Date format option (date example)", "%1 (%2)", button->text(), formattedDate));
    }
```

#### AUTO 


```{c}
auto item = new QTreeWidgetItem(QStringList(path));
```

#### AUTO 


```{c}
auto *othersAction
        = new KActionMenu(QIcon::fromTheme(QStringLiteral("preferences-other")), i18n("Others"), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString addressItem : m_remoteJournals) {
        JournalAddress addressInfo;
        addressInfo.address = addressItem.section('|', 0, 0);
        addressInfo.port = addressItem.section('|', 1, 1).toUInt();
        int https = addressItem.section('|', 2).toInt();
        addressInfo.https = https != 0;
        journals.append(addressInfo);
    }
```

#### AUTO 


```{c}
auto model = new LogViewModel(logViewWidget);
```

#### AUTO 


```{c}
auto multipleActions = new MultipleActions(QIcon::fromTheme(QLatin1String(JOURNALD_MODE_ICON)), i18n("Journald"), logMode);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &keyword : keywords) {
        if (message.contains(keyword, Qt::CaseInsensitive)) {
            return true;
        }
    }
```

#### AUTO 


```{c}
auto *model = new LogViewModel(logViewWidget);
```

#### AUTO 


```{c}
auto *cronConfiguration = Globals::instance().findLogMode(QStringLiteral(CRON_LOG_MODE_ID))->logModeConfiguration<CronConfiguration *>();
```

#### AUTO 


```{c}
auto *logViewWidget = new LogViewWidget();
```

#### AUTO 


```{c}
auto *acpidConfiguration = Globals::instance()
                               .findLogMode(QStringLiteral(ACPID_LOG_MODE_ID))
                               ->logModeConfiguration<AcpidConfiguration *>();
```

#### AUTO 


```{c}
auto *configuration = logModeConfiguration<AuthenticationConfiguration *>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &filter : filters) {
        res = sd_journal_add_match(journal, filter.toUtf8(), 0);
        if (res < 0) {
            logWarning() << "Failed to set journal filter.";
            return false;
        }
    }
```

#### AUTO 


```{c}
auto item = new LogViewWidgetItem(mLogViewWidget, line);
```

#### AUTO 


```{c}
auto *actionMenu = new KActionMenu(QIcon::fromTheme(QLatin1String("drive-harddisk")),
                                              i18n("Local journal"), multipleActions);
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : innerActions) {
            ActionData actionData = action->data().value<ActionData>();
            if (actionData.addToActionCollection) {
                logDebug() << "Adding action" << actionData.id;
                action = actionCollection()->addAction(actionData.id, action);
            }
            connect(action, &QAction::triggered, this, &MainWindow::selectLogModeAction);
        }
```

#### AUTO 


```{c}
auto *filterLabel = new QLabel(i18n("Filter:"));
```

#### AUTO 


```{c}
auto *cupsConfiguration = Globals::instance()
                                           .findLogMode(QStringLiteral(CUPS_LOG_MODE_ID))
                                           ->logModeConfiguration<CupsConfiguration *>();
```

#### AUTO 


```{c}
const auto logModes{Globals::instance().logModes()};
```

#### AUTO 


```{c}
auto watcher = new JournalWatcher();
```

#### AUTO 


```{c}
auto *configuration = logModeConfiguration<DaemonConfiguration *>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const JournalAddress &addressInfo : remoteJournals) {
        if (haveJournalAddress(addressInfo.address, QString::number(addressInfo.port), addressInfo.https)) {
            continue;
        }
        remoteJournalsListWidget->insertRow(remoteJournalsListWidget->rowCount());
        remoteJournalsListWidget->setItem(remoteJournalsListWidget->rowCount() - 1, 0,
                                          new QTableWidgetItem(addressInfo.address));
        remoteJournalsListWidget->setItem(remoteJournalsListWidget->rowCount() - 1, 1,
                                          new QTableWidgetItem(QString::number(addressInfo.port)));
        auto *item = new QTableWidgetItem(i18n("Enabled"));
        item->setFlags(item->flags() | Qt::ItemIsUserCheckable);
        item->setCheckState(addressInfo.https ? Qt::Checked : Qt::Unchecked);
        remoteJournalsListWidget->setItem(remoteJournalsListWidget->rowCount() - 1, 2, item);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &path : paths) {
        QFileInfo fileInfo(path);
        if (fileInfo.exists())
            d->logFilesExist = true;
    }
```

#### AUTO 


```{c}
auto action = new QAction(d->icon, d->name, this);
```

#### AUTO 


```{c}
auto layout = new QHBoxLayout(this);
```

#### AUTO 


```{c}
auto *apacheConfiguration = logModeConfiguration<ApacheConfiguration *>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const LogViewColumn &column : cols) {
        if (column.isFiltered()) {
            d->mFilterList->addItem(column.columnName());
        }
    }
```

#### AUTO 


```{c}
auto *filterBarLayout = new QHBoxLayout();
```

#### RANGE FOR STATEMENT 


```{c}
for (TabLogManager *tabLogManager : copy) {
        mTabLogManagers.removeAll(tabLogManager);
        delete tabLogManager;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const LogFile &logFile : logFiles) {
        LogFileReader *logFileReader = createLogFileReader(logFile);
        mLogFileReaders.append(logFileReader);

        connect(logFileReader, &LogFileReader::contentChanged, this, &FileAnalyzer::logFileChanged);
        connect(logFileReader, &LogFileReader::statusBarChanged, this, &Analyzer::statusBarChanged);
        connect(logFileReader, &LogFileReader::errorOccured, this, &Analyzer::errorOccured);
    }
```

#### AUTO 


```{c}
auto *filterBarLayout = new QHBoxLayout(this);
```

#### AUTO 


```{c}
auto *layout = new QVBoxLayout();
```

#### AUTO 


```{c}
const auto selectedItems = remoteJournalsListWidget->selectedItems();
```

#### RANGE FOR STATEMENT 


```{c}
for (const JournalAddress &addressInfo : remoteJournals) {
        m_remoteJournals.append(QStringLiteral("%1|%2|%3")
                                    .arg(addressInfo.address)
                                    .arg(addressInfo.port)
                                    .arg(addressInfo.https ? 1 : 0));
    }
```

#### AUTO 


```{c}
auto separatorAction = new QAction(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const JournalAddress &addressInfo : remoteJournals) {
        if (haveJournalAddress(addressInfo.address, QString::number(addressInfo.port), addressInfo.https))
            continue;
        remoteJournalsListWidget->insertRow(remoteJournalsListWidget->rowCount());
        remoteJournalsListWidget->setItem(remoteJournalsListWidget->rowCount() - 1, 0,
                                          new QTableWidgetItem(addressInfo.address));
        remoteJournalsListWidget->setItem(remoteJournalsListWidget->rowCount() - 1, 1,
                                          new QTableWidgetItem(QString::number(addressInfo.port)));
        QTableWidgetItem *item = new QTableWidgetItem(i18n("Enabled"));
        item->setFlags(item->flags() | Qt::ItemIsUserCheckable);
        item->setCheckState(addressInfo.https ? Qt::Checked : Qt::Unchecked);
        remoteJournalsListWidget->setItem(remoteJournalsListWidget->rowCount() - 1, 2, item);
    }
```

#### AUTO 


```{c}
auto *action = new QAction(this);
```

#### AUTO 


```{c}
const auto innerActions{logModeAction->innerActions()};
```

#### AUTO 


```{c}
auto endIt = protMap.constEnd();
```

#### AUTO 


```{c}
auto *xorgConfiguration = Globals::instance().findLogMode(QStringLiteral(XORG_LOG_MODE_ID))->logModeConfiguration<XorgConfiguration *>();
```

#### AUTO 


```{c}
auto item = new QListWidgetItem(level->icon(), itemText, fileList);
```

#### AUTO 


```{c}
auto filterActionMenu = new KActionMenu(filterIcon, i18n("Filter by syslog identifier"), actionMenu);
```

#### AUTO 


```{c}
const auto &msg
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &filter : filters) {
        res = sd_journal_add_match(journal, filter.toUtf8().constData(), 0);
        if (res < 0) {
            qCWarning(KSYSTEMLOG) << "Failed to set journal filter.";
            return false;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (LogLine *logLine : logLines) {
        if (logLine->time() < minTime) {
            QFAIL(QString::fromLatin1("The line '%1' has a lesser time than the required min time (%2)")
                  .arg(logLine->logItems().join(QLatin1Char(' ')))
                  .arg(logLine->time().toString())
                  .toUtf8().constData());
        }
    }
```

#### AUTO 


```{c}
auto *filePathLayout = new QHBoxLayout();
```

#### AUTO 


```{c}
auto *sambaConfiguration = Globals::instance()
                                             .findLogMode(QStringLiteral(SAMBA_LOG_MODE_ID))
                                             ->logModeConfiguration<SambaConfiguration *>();
```

#### AUTO 


```{c}
auto *watcher = static_cast<JournalWatcher *>(sender());
```

#### AUTO 


```{c}
auto it = protMap.constBegin();
```

#### AUTO 


```{c}
auto line = new LogLine(mLogLineInternalIdGenerator++,
                            dateTime,
                            messages,
                            originalLogFile.url().toLocalFile(),
                            Globals::instance().informationLogLevel(),
                            mLogMode);
```

#### AUTO 


```{c}
auto logFileReader = new KioLogFileReader(logFile);
```

#### RANGE FOR STATEMENT 


```{c}
for (const LogViewColumn &column : cols) {
        if (column.isFiltered()) {
            mFilterList->addItem(column.columnName());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const JournalAddress &addressInfo : remoteJournals) {
        mRemoteJournals.append(QStringLiteral("%1|%2|%3")
                               .arg(addressInfo.address)
                               .arg(addressInfo.port)
                               .arg(addressInfo.https ? 1 : 0));
    }
```

#### AUTO 


```{c}
auto *configuration = mLogMode->logModeConfiguration<AuthenticationConfiguration *>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const RemoteJournalAddress &addressInfo : remoteJournals) {
        m_remoteJournals.append(QString("%1|%2").arg(addressInfo.address).arg(addressInfo.port));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (LogManager *manager : logManagers) {
        manager->usedView()->toggleLogViewFilter(mFilterBarAction->isChecked());
    }
```

#### AUTO 


```{c}
auto *separator = new QAction(this);
```

#### AUTO 


```{c}
auto multipleActions = new MultipleActions(QIcon::fromTheme(QStringLiteral(APACHE_MODE_ICON)), i18n("Apache"), apacheLogMode);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &filter : filters) {
        res = sd_journal_add_match(journal, filter.toLatin1(), 0);
        if (res < 0) {
            logWarning() << "Failed to set journald filter.";
            sd_journal_close(journal);
            return QList<JournalEntry>();
        }
    }
```

#### AUTO 


```{c}
const auto dateFormat = (QLocale::FormatType)KSystemLogConfig::dateFormat();
```

#### AUTO 


```{c}
auto *line
        = new LogLine(mLogLineInternalIdGenerator++, dateTime, messages, originalLogFile.url().toLocalFile(),
                      Globals::instance().informationLogLevel(), mLogMode);
```

#### AUTO 


```{c}
auto selectedItems = remoteJournalsListWidget->selectedItems();
```

#### AUTO 


```{c}
auto *action = new QAction(button);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &addressInfo : remoteJournals) {
        QString menuText = QString("%1:%2").arg(addressInfo.address).arg(addressInfo.port);
        actionMenu = new KActionMenu(remoteIcon, menuText, multipleActions);

        action = new QAction(QIcon::fromTheme(QLatin1String("network-connect")), i18n("Connect"), actionMenu);
        analyzerOptions.address = addressInfo.address;
        analyzerOptions.port = addressInfo.port;
        actionData.analyzerOptions = QVariant::fromValue(analyzerOptions);
        action->setData(QVariant::fromValue(actionData));
        actionMenu->addAction(action);
        multipleActions->addInnerAction(action, false, true);

        // Add separator.
        action = new QAction(actionMenu);
        action->setSeparator(true);
        actionMenu->addAction(action);

        // Add filtering by systemd unit.
        JournalFilters filters = logMode->filters(addressInfo);
        if (!filters.systemdUnits.isEmpty()) {
            KActionMenu *filterActionMenu
                = new KActionMenu(filterIcon, i18n("Filter by systemd unit"), actionMenu);

            for (const QString &unit : filters.systemdUnits) {
                action = new QAction(unit, filterActionMenu);

                analyzerOptions.filter = QString("_SYSTEMD_UNIT=%1").arg(unit);
                actionData.analyzerOptions = QVariant::fromValue(analyzerOptions);
                action->setData(QVariant::fromValue(actionData));

                filterActionMenu->addAction(action);
                multipleActions->addInnerAction(action, false, true);
            }
            actionMenu->addAction(filterActionMenu);
        }

        // Add filtering by syslog identifier.
        if (!filters.syslogIdentifiers.isEmpty()) {
            KActionMenu *filterActionMenu
                = new KActionMenu(filterIcon, i18n("Filter by syslog identifier"), actionMenu);

            for (const QString &id : filters.syslogIdentifiers) {
                action = new QAction(id, filterActionMenu);

                analyzerOptions.filter = QString("SYSLOG_IDENTIFIER=%1").arg(id);
                actionData.analyzerOptions = QVariant::fromValue(analyzerOptions);
                action->setData(QVariant::fromValue(actionData));

                filterActionMenu->addAction(action);
                multipleActions->addInnerAction(action, false, true);
            }
            actionMenu->addAction(filterActionMenu);
        }

        multipleActions->addInnerAction(actionMenu, true, false);
    }
```

#### AUTO 


```{c}
auto *layout = new QHBoxLayout(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (LogManager *manager : logManagers) {
        manager->usedView()->logViewWidget()->toggleToolTip(enabled);
    }
```

#### AUTO 


```{c}
auto *multipleActions
        = new MultipleActions(QIcon::fromTheme(QStringLiteral(CUPS_MODE_ICON)), i18n("Cups"), cupsLogMode);
```

#### RANGE FOR STATEMENT 


```{c}
for (LogLevel *level : logLevels) {
        auto button = new QCheckBox(level->name(), this); //, m_btnGroup, 0

        mLevelCheckBoxes.append(button);
        mBtnGroup->addButton(button, level->id());
        mBtnGroupLayout->addWidget(button, row, col);

        logDebug() << "name: " << level->name() << " id: " << level->id();

        row++;
        if (row >= 4) {
            row = 0;
            col++;
        }
    }
```

#### AUTO 


```{c}
auto item = static_cast<LogViewWidgetItem *>(*it);
```

#### AUTO 


```{c}
auto it = mmapMap.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &unit : units) {
        action = new QAction(unit, filterActionMenu);

        analyzerOptions.filter = QString("_SYSTEMD_UNIT=%1").arg(unit);
        actionData.analyzerOptions = QVariant::fromValue(analyzerOptions);
        action->setData(QVariant::fromValue(actionData));

        filterActionMenu->addAction(action);
        multipleActions->addInnerAction(action, false, true);
    }
```

#### AUTO 


```{c}
auto *systemConfiguration = Globals::instance().findLogMode(QStringLiteral(SYSTEM_LOG_MODE_ID))->logModeConfiguration<SystemConfiguration *>();
```

#### AUTO 


```{c}
auto *configuration
        = mLogMode->logModeConfiguration<AuthenticationConfiguration *>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : urls) {
        const QFileInfo fileInfo(url.toLocalFile());

        // TODO Add a recognition of binary files (using the Url mimetype) and refuse them

        if (!fileInfo.isReadable()) {
            qCWarning(KSYSTEMLOG) << "The drag and dropped file is not readable " << url.path();
            return;
        }

        if (fileInfo.isDir()) {
            qCWarning(KSYSTEMLOG) << "Tried to drag and drop a directory " << url.path();
            return;
        }
    }
```

#### AUTO 


```{c}
auto watcher = static_cast<JournalWatcher *>(sender());
```

#### AUTO 


```{c}
auto *multipleActions
        = new MultipleActions(QIcon::fromTheme(QLatin1String(JOURNALD_MODE_ICON)), i18n("Journald"), logMode);
```

#### AUTO 


```{c}
const auto logLevels = Globals::instance().logLevels();
```

#### RANGE FOR STATEMENT 


```{c}
for (JournalWatcher *watcher : m_journalWatchers) {
            watcher->waitForFinished();
        }
```

#### AUTO 


```{c}
auto *daemonConfiguration = Globals::instance()
                                               .findLogMode(QStringLiteral(DAEMON_LOG_MODE_ID))
                                               ->logModeConfiguration<DaemonConfiguration *>();
```

#### LAMBDA EXPRESSION 


```{c}
[=](const QString &line) {
        qCDebug(KSYSTEMLOG) << "Line " << line;
        static QFile file(fixturePath);
        static bool open = false;
        if (!open) {
            QVERIFY(file.open(QIODevice::ReadOnly | QIODevice::Text));
            open = true;
        }
        static QTextStream stream(&file);
        QCOMPARE(line, stream.readLine());
    }
```

#### AUTO 


```{c}
auto *configuration = Globals::instance().findLogMode(QLatin1String(JOURNALD_LOG_MODE_ID))->logModeConfiguration<JournaldConfiguration *>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &unit : filters.systemdUnits) {
                action = new QAction(unit, filterActionSystemdMenu);

                analyzerOptions.filter = QStringLiteral("_SYSTEMD_UNIT=%1").arg(unit);
                actionData.analyzerOptions = QVariant::fromValue(analyzerOptions);
                action->setData(QVariant::fromValue(actionData));

                filterActionSystemdMenu->addAction(action);
                multipleActions->addInnerAction(action, false, true);
            }
```

#### AUTO 


```{c}
auto filterActionMenu = new KActionMenu(filterIcon, i18n("Filter by systemd unit"), actionMenu);
```

#### AUTO 


```{c}
auto *configuration = Globals::instance()
                                           .findLogMode(QStringLiteral(X_SESSION_LOG_MODE_ID))
                                           ->logModeConfiguration<XSessionConfiguration *>();
```

#### AUTO 


```{c}
auto logViewWidget = new LogViewWidget();
```

#### AUTO 


```{c}
auto *action = new QAction(filterIcon, i18n("All messages"), actionMenu);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &addressItem : std::as_const(mRemoteJournals)) {
        JournalAddress addressInfo;
        addressInfo.address = addressItem.section(QChar::fromLatin1('|'), 0, 0);
        addressInfo.port = addressItem.section(QChar::fromLatin1('|'), 1, 1).toUInt();
        const int https = addressItem.section(QChar::fromLatin1('|'), 2).toInt();
        addressInfo.https = https != 0;
        journals.append(addressInfo);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : innerActions) {
            ActionData actionData = action->data().value<ActionData>();
            if (actionData.addToActionCollection) {
                qCDebug(KSYSTEMLOG) << "Adding action" << actionData.id;
                action = actionCollection()->addAction(actionData.id, action);
            }
            connect(action, &QAction::triggered, this, &MainWindow::selectLogModeAction);
        }
```

#### AUTO 


```{c}
const auto logItems = line->logItems();
```

#### AUTO 


```{c}
auto *filterActionMenu
                = new KActionMenu(filterIcon, i18n("Filter by syslog identifier"), actionMenu);
```

#### AUTO 


```{c}
auto *tabNewTabButton
        = new QPushButton(QIcon::fromTheme(QStringLiteral("tab-new")), QLatin1String(""), this);
```

#### AUTO 


```{c}
auto item = new QTableWidgetItem(i18n("Enabled"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &unit : filters.systemdUnits) {
                action = new QAction(unit, filterActionMenu);

                analyzerOptions.filter = QString("_SYSTEMD_UNIT=%1").arg(unit);
                actionData.analyzerOptions = QVariant::fromValue(analyzerOptions);
                action->setData(QVariant::fromValue(actionData));

                filterActionMenu->addAction(action);
                multipleActions->addInnerAction(action, false, true);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[=](const QString &line) {
        logDebug() << "Line " << line << endl;
        static QFile file(fixturePath);
        static bool open = false;
        if (!open) {
            QVERIFY(file.open(QIODevice::ReadOnly | QIODevice::Text));
            open = true;
        }
        static QTextStream stream(&file);
        QCOMPARE(line, stream.readLine());
    }
```

#### AUTO 


```{c}
auto *item = new QStandardItem(logLevel->name());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &filter : filters) {
        res = sd_journal_add_match(journal, filter.toUtf8().constData(), 0);
        if (res < 0) {
            logWarning() << "Failed to set journal filter.";
            return false;
        }
    }
```

#### AUTO 


```{c}
auto *widgetLayout = new QHBoxLayout(this);
```

#### AUTO 


```{c}
auto *delegate = new ComboBoxDelegate(d->mPrioritiesComboBox);
```

#### AUTO 


```{c}
auto *configuration = logModeConfiguration<XorgConfiguration *>();
```

#### RANGE FOR STATEMENT 


```{c}
for (LogModeConfigurationWidget *logModeConfigurationWidget : qAsConst(mLogModeConfigurations)) {
        logModeConfigurationWidget->readConfig();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (LogMode *logMode : logModes) {
        // Some Log mode does not need a configuration widget
        if (logMode->logModeConfigurationWidget() == nullptr) {
            continue;
        }

        // The configuration widget could be shared between Log Modes
        if (mLogModeConfigurations.contains(logMode->logModeConfigurationWidget())) {
            continue;
        }

        mLogModeConfigurations.append(logMode->logModeConfigurationWidget());
    }
```

#### AUTO 


```{c}
auto it1 = shmmodeMap.constBegin();
```

#### AUTO 


```{c}
auto action = qobject_cast<QAction *>(sender());
```

#### AUTO 


```{c}
auto item = new QListWidgetItem(path);
```

#### AUTO 


```{c}
auto dialog = new QPrintPreviewDialog(mParent);
```

#### AUTO 


```{c}
auto *configuration = mode->logModeConfiguration<JournaldConfiguration *>();
```

#### AUTO 


```{c}
const auto currentButtonFormat = static_cast<Globals::DateFormat>(mDateFormatGroup->id(button));
```

#### AUTO 


```{c}
auto *acpidConfiguration = Globals::instance().findLogMode(QStringLiteral(ACPID_LOG_MODE_ID))->logModeConfiguration<AcpidConfiguration *>();
```

#### RANGE FOR STATEMENT 


```{c}
for (LogModeConfigurationWidget *logModeConfigurationWidget : qAsConst(mLogModeConfigurations)) {
        logDebug() << "Adding " << logModeConfigurationWidget->itemName() << " configuration...";

        addPage(logModeConfigurationWidget,
                logModeConfigurationWidget->itemName(),
                logModeConfigurationWidget->iconName(),
                logModeConfigurationWidget->header(),
                false);

        connect(logModeConfigurationWidget, &LogModeConfigurationWidget::configurationChanged, this, &ConfigurationDialog::updateConfiguration);
    }
```

#### AUTO 


```{c}
auto timestampUsec = object[QStringLiteral("__REALTIME_TIMESTAMP")].toVariant().value<quint64>();
```

#### AUTO 


```{c}
auto widgetLayout = new QHBoxLayout(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &path : paths) {
        fileList->addItem(path);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QListWidgetItem *item : selectedItems) {
        item->setSelected(false);
    }
```

#### AUTO 


```{c}
auto *acpidConfiguration = Globals::instance()
                                             .findLogMode(QStringLiteral(ACPID_LOG_MODE_ID))
                                             ->logModeConfiguration<AcpidConfiguration *>();
```

#### AUTO 


```{c}
auto item = new QStandardItem(i18n("Select priorities"));
```

#### AUTO 


```{c}
const auto &otherItem = static_cast<const LogViewWidgetItem &>(other);
```

#### AUTO 


```{c}
auto *logModeAction = new SimpleAction(logMode->action(), logMode);
```

#### AUTO 


```{c}
auto it = umountMap.constBegin();
```

#### AUTO 


```{c}
auto *daemonConfiguration = Globals::instance()
                                .findLogMode(QStringLiteral(DAEMON_LOG_MODE_ID))
                                ->logModeConfiguration<DaemonConfiguration *>();
```

#### AUTO 


```{c}
auto *authenticationConfiguration
        = Globals::instance()
          .findLogMode(QStringLiteral(AUTHENTICATION_LOG_MODE_ID))
          ->logModeConfiguration<AuthenticationConfiguration *>();
```

#### AUTO 


```{c}
auto *item = new QListWidgetItem(path);
```

#### AUTO 


```{c}
auto *logFileReader = new KioLogFileReader(logFile);
```

#### AUTO 


```{c}
auto *cupsConfiguration = logModeConfiguration<CupsConfiguration *>();
```

#### AUTO 


```{c}
auto *apacheConfiguration = Globals::instance().findLogMode(QStringLiteral(APACHE_LOG_MODE_ID))->logModeConfiguration<ApacheConfiguration *>();
```

#### AUTO 


```{c}
auto *layout = new QVBoxLayout(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const JournalAddress &addressInfo : remoteJournals) {
        mRemoteJournals.append(QStringLiteral("%1|%2|%3").arg(addressInfo.address).arg(addressInfo.port).arg(addressInfo.https ? 1 : 0));
    }
```

#### AUTO 


```{c}
auto *systemConfiguration = Globals::instance()
                                .findLogMode(QStringLiteral(SYSTEM_LOG_MODE_ID))
                                ->logModeConfiguration<SystemConfiguration *>();
```

#### AUTO 


```{c}
auto action = new QAction(button);
```

#### AUTO 


```{c}
auto *multipleActions = new MultipleActions(QIcon::fromTheme(QStringLiteral(APACHE_MODE_ICON)),
                                                           i18n("Apache"), apacheLogMode);
```

#### RANGE FOR STATEMENT 


```{c}
for (const JournalAddress &addressInfo : remoteJournals) {
        m_remoteJournals.append(QString("%1|%2|%3")
                                    .arg(addressInfo.address)
                                    .arg(addressInfo.port)
                                    .arg(addressInfo.https ? 1 : 0));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : actions) {
        action->setEnabled(enabled);
    }
```

#### AUTO 


```{c}
auto multipleActions = new MultipleActions(QIcon::fromTheme(QStringLiteral(SAMBA_MODE_ICON)), i18n("Samba"), sambaLogMode);
```

#### AUTO 


```{c}
auto *configuration = logMode->logModeConfiguration<JournaldConfiguration *>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &id : syslogIDs) {
        action = new QAction(id, filterActionMenu);

        analyzerOptions.filter = QString("SYSLOG_IDENTIFIER=%1").arg(id);
        actionData.analyzerOptions = QVariant::fromValue(analyzerOptions);
        action->setData(QVariant::fromValue(actionData));

        filterActionMenu->addAction(action);
        multipleActions->addInnerAction(action, false, true);
    }
```

#### AUTO 


```{c}
auto filterActionSystemdMenu = new KActionMenu(filterIcon, i18n("Filter by systemd unit"), actionMenu);
```

#### AUTO 


```{c}
const auto xorgErrorKeywords = configuration->xorgErrorKeywords();
```

#### AUTO 


```{c}
auto *separatorAction = new QAction(this);
```

#### AUTO 


```{c}
auto logModeConfigurationWidget = new ApacheConfigurationWidget();
```

#### AUTO 


```{c}
auto emptyItem = new QTreeWidgetItem(item, QStringList(i18n("No log file...")));
```

#### AUTO 


```{c}
auto *logManager = new LogManager(view);
```

#### AUTO 


```{c}
auto *configuration = Globals::instance().findLogMode(QStringLiteral(X_SESSION_LOG_MODE_ID))->logModeConfiguration<XSessionConfiguration *>();
```

#### AUTO 


```{c}
auto *cronConfiguration = Globals::instance()
                                           .findLogMode(QStringLiteral(CRON_LOG_MODE_ID))
                                           ->logModeConfiguration<CronConfiguration *>();
```

#### AUTO 


```{c}
auto *tabLogManager = new TabLogManager(logManager);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &addressInfo : remoteJournals) {
        QString menuText = QStringLiteral("%1:%2").arg(addressInfo.address).arg(addressInfo.port);
        actionMenu = new KActionMenu(remoteIcon, menuText, multipleActions);

        action = new QAction(QIcon::fromTheme(QLatin1String("network-connect")), i18n("Connect"), actionMenu);
        analyzerOptions.address = addressInfo;
        actionData.analyzerOptions = QVariant::fromValue(analyzerOptions);
        action->setData(QVariant::fromValue(actionData));
        actionMenu->addAction(action);
        multipleActions->addInnerAction(action, false, true);

        // Add separator.
        action = new QAction(actionMenu);
        action->setSeparator(true);
        actionMenu->addAction(action);

        // Add filtering by systemd unit.
        JournalFilters filters = logMode->filters(addressInfo);
        if (!filters.systemdUnits.isEmpty()) {
            auto *filterActionSystemdMenu
                = new KActionMenu(filterIcon, i18n("Filter by systemd unit"), actionMenu);

            for (const QString &unit : filters.systemdUnits) {
                action = new QAction(unit, filterActionSystemdMenu);

                analyzerOptions.filter = QStringLiteral("_SYSTEMD_UNIT=%1").arg(unit);
                actionData.analyzerOptions = QVariant::fromValue(analyzerOptions);
                action->setData(QVariant::fromValue(actionData));

                filterActionSystemdMenu->addAction(action);
                multipleActions->addInnerAction(action, false, true);
            }
            actionMenu->addAction(filterActionSystemdMenu);
        }

        // Add filtering by syslog identifier.
        if (!filters.syslogIdentifiers.isEmpty()) {
            auto *filterActionMenu
                = new KActionMenu(filterIcon, i18n("Filter by syslog identifier"), actionMenu);

            for (const QString &id : filters.syslogIdentifiers) {
                action = new QAction(id, filterActionMenu);

                analyzerOptions.filter = QStringLiteral("SYSLOG_IDENTIFIER=%1").arg(id);
                actionData.analyzerOptions = QVariant::fromValue(analyzerOptions);
                action->setData(QVariant::fromValue(actionData));

                filterActionMenu->addAction(action);
                multipleActions->addInnerAction(action, false, true);
            }
            actionMenu->addAction(filterActionMenu);
        }

        multipleActions->addInnerAction(actionMenu, true, false);
    }
```

#### AUTO 


```{c}
auto tabLogManager = new TabLogManager(logManager);
```

#### AUTO 


```{c}
auto button = new QCheckBox(level->name(), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (LogLevel *level : logLevels) {
        auto *button = new QCheckBox(level->name(), this); //, m_btnGroup, 0

        mLevelCheckBoxes.append(button);
        mBtnGroup->addButton(button, level->id());
        mBtnGroupLayout->addWidget(button, row, col);

        logDebug() << "name: " << level->name() << " id: " << level->id();

        row++;
        if (row >= 4) {
            row = 0;
            col++;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : urls) {
        logFiles.append(LogFile(url, Globals::instance().informationLogLevel()));
    }
```

#### AUTO 


```{c}
auto *cronConfiguration = mLogMode->logModeConfiguration<CronConfiguration *>();
```

#### AUTO 


```{c}
const auto cols = columns.columns();
```

#### AUTO 


```{c}
auto *configuration = Globals::instance()
                          .findLogMode(QStringLiteral(POSTFIX_LOG_MODE_ID))
                          ->logModeConfiguration<PostfixConfiguration *>();
```

#### RANGE FOR STATEMENT 


```{c}
for (LogModeFactory *factory : qAsConst(d->mFactories)) {
        LogModeAction *logModeAction = factory->createLogModeAction();
        if (logModeAction) {
            d->mLogModeActions.append(logModeAction);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QListWidgetItem *item : selectedItems) {
        delete fileList->takeItem(fileList->row(item));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (LogModeAction *logModeAction : logModeActions) {
        if (logModeAction->category() == LogModeAction::RootCategory) {
            menuLogModeActions.append(logModeAction->actionMenu());
        } else if (logModeAction->category() == LogModeAction::ServicesCategory) {
            serviceItems++;
            servicesAction->addAction(logModeAction->actionMenu());
        } else if (logModeAction->category() == LogModeAction::OthersCategory) {
            othersAction->addAction(logModeAction->actionMenu());
            othersItems++;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (LogModeFactory *factory : std::as_const(d->mFactories)) {
        LogModeAction *logModeAction = factory->createLogModeAction();
        if (logModeAction) {
            d->mLogModeActions.append(logModeAction);
        }
    }
```

#### AUTO 


```{c}
auto layout = new QVBoxLayout();
```

#### AUTO 


```{c}
auto *line =
            new LogLine(mLogLineInternalIdGenerator++, entry.date, itemComponents, QString(), Globals::instance().logLevelByPriority(entry.priority), mLogMode);
```

#### AUTO 


```{c}
auto printDialog = new QPrintDialog(&printer, mParent);
```

#### AUTO 


```{c}
auto action = new QAction(this);
```

#### LAMBDA EXPRESSION 


```{c}
[=](const QString &line) { logDebug() << "Line " << line << endl; static QFile file(fixturePath); static bool open = false; if (!open) { QVERIFY(file.open(QIODevice::ReadOnly | QIODevice::Text)); open = true; } static QTextStream stream(&file); QCOMPARE(line, stream.readLine());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (LogMode *logMode : logModes) {
        // Log mode
        d->mLogModes.insert(logMode->id(), logMode);
    }
```

#### AUTO 


```{c}
auto authenticationBox = new QGroupBox(i18n("Authentication Log File"));
```

#### RANGE FOR STATEMENT 


```{c}
for (TabLogManager *tabLogManager : std::as_const(mTabLogManagers)) {
        if (tabLogManager->logManager()->usedView() == view) {
            return tabLogManager;
        }
    }
```

#### AUTO 


```{c}
auto *sambaConfiguration = Globals::instance().findLogMode(QStringLiteral(SAMBA_LOG_MODE_ID))->logModeConfiguration<SambaConfiguration *>();
```

#### AUTO 


```{c}
const auto logModeActions{Globals::instance().logModeActions()};
```

#### AUTO 


```{c}
const auto associatedWidgets{mResumePauseAction->associatedObjects()};
```

#### AUTO 


```{c}
auto *authenticationConfiguration =
        Globals::instance().findLogMode(QStringLiteral(AUTHENTICATION_LOG_MODE_ID))->logModeConfiguration<AuthenticationConfiguration *>();
```

#### AUTO 


```{c}
auto *servicesAction = new KActionMenu(
        QIcon::fromTheme(QStringLiteral("preferences-system-session-services")), i18n("Services"), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &path : paths) {
        auto *item = new QListWidgetItem(path);
        const QFileInfo checkFile(path);
        if (!checkFile.exists()) {
            item->setForeground(Qt::red);
            missingFiles = true;
        }
        fileList->addItem(item);
    }
```

#### AUTO 


```{c}
auto *watcher = new JournalWatcher();
```

#### RANGE FOR STATEMENT 


```{c}
for (QTreeWidgetItem *item : selectedItems) {
        QTreeWidgetItem *categoryItem = findCategoryOfChild(item);
        delete categoryItem->takeChild(categoryItem->indexOfChild(item));
    }
```

#### AUTO 


```{c}
auto *configuration = Globals::instance()
                          .findLogMode(QLatin1String(JOURNALD_LOG_MODE_ID))
                          ->logModeConfiguration<JournaldConfiguration *>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &id : syslogIDs) {
        action = new QAction(id, filterActionMenu);

        analyzerOptions.filter = QStringLiteral("SYSLOG_IDENTIFIER=%1").arg(id);
        actionData.analyzerOptions = QVariant::fromValue(analyzerOptions);
        action->setData(QVariant::fromValue(actionData));

        filterActionMenu->addAction(action);
        multipleActions->addInnerAction(action, false, true);
    }
```

#### AUTO 


```{c}
auto &refToNonConstOption = const_cast<QStyleOptionViewItem &>(option);
```

#### AUTO 


```{c}
const auto &addressInfo
```

#### AUTO 


```{c}
auto *configuration = Globals::instance()
                                           .findLogMode(QLatin1String(JOURNALD_LOG_MODE_ID))
                                           ->logModeConfiguration<JournaldConfiguration *>();
```

#### AUTO 


```{c}
auto *apacheConfiguration = Globals::instance()
                                .findLogMode(QStringLiteral(APACHE_LOG_MODE_ID))
                                ->logModeConfiguration<ApacheConfiguration *>();
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &status) {
        d->mAnalyzerStatus = status;
        Q_EMIT tabTitleChanged(d->mUsedView, d->mLogMode->icon(), title());
        Q_EMIT windowTitleChanged(title());
    }
```

#### AUTO 


```{c}
auto *item = new LogViewWidgetItem(mLogViewWidget, line);
```

#### AUTO 


```{c}
auto *sambaConfiguration = Globals::instance()
                               .findLogMode(QStringLiteral(SAMBA_LOG_MODE_ID))
                               ->logModeConfiguration<SambaConfiguration *>();
```

#### AUTO 


```{c}
auto *configuration = Globals::instance().findLogMode(QStringLiteral(POSTFIX_LOG_MODE_ID))->logModeConfiguration<PostfixConfiguration *>();
```

#### AUTO 


```{c}
auto *line = new LogLine(mLogLineInternalIdGenerator++, entry.date, itemComponents, QString(),
                                 Globals::instance().logLevelByPriority(entry.priority), mLogMode);
```

#### RANGE FOR STATEMENT 


```{c}
for (LogModeConfigurationWidget *logModeConfigurationWidget : qAsConst(mLogModeConfigurations)) {
        logDebug() << "Adding " << logModeConfigurationWidget->itemName() << " configuration...";

        addPage(logModeConfigurationWidget, logModeConfigurationWidget->itemName(),
                logModeConfigurationWidget->iconName(), logModeConfigurationWidget->header(), false);

        connect(logModeConfigurationWidget, &LogModeConfigurationWidget::configurationChanged, this,
                &ConfigurationDialog::updateConfiguration);
    }
```

#### AUTO 


```{c}
const auto buttons = mDateFormatGroup->buttons();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &addressItem : qAsConst(mRemoteJournals)) {
        JournalAddress addressInfo;
        addressInfo.address = addressItem.section(QChar::fromLatin1('|'), 0, 0);
        addressInfo.port = addressItem.section(QChar::fromLatin1('|'), 1, 1).toUInt();
        const int https = addressItem.section(QChar::fromLatin1('|'), 2).toInt();
        addressInfo.https = https != 0;
        journals.append(addressInfo);
    }
```

#### AUTO 


```{c}
const auto logManagers = mTabs->logManagers();
```

#### AUTO 


```{c}
auto delegate = new ComboBoxDelegate(mPrioritiesComboBox);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &label : logItems) {
        item->setText(i, label);
        i++;
    }
```

#### AUTO 


```{c}
auto kernelAnalyzer = new KernelAnalyzerLocalReader(logMode);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &addressInfo : remoteJournals) {
        actionMenu = new KActionMenu(QString("%1:%2").arg(addressInfo.address).arg(addressInfo.port),
                                     multipleActions);

        action = new QAction(i18n("Connect"), actionMenu);
        analyzerOptions.address = addressInfo.address;
        analyzerOptions.port = addressInfo.port;
        actionData.analyzerOptions = QVariant::fromValue(analyzerOptions);
        action->setData(QVariant::fromValue(actionData));
        actionMenu->addAction(action);
        multipleActions->addInnerAction(action, false, true);

        multipleActions->addInnerAction(actionMenu, true, false);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString addressItem : m_remoteJournals) {
        RemoteJournalAddress addressInfo;
        addressInfo.address = addressItem.section('|', 0, 0);
        addressInfo.port = addressItem.section('|', 1).toUInt();
        journals.append(addressInfo);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString addressItem : m_remoteJournals) {
        JournalAddress addressInfo;
        addressInfo.address = addressItem.section(QChar::fromLatin1('|'), 0, 0);
        addressInfo.port = addressItem.section(QChar::fromLatin1('|'), 1, 1).toUInt();
        int https = addressItem.section(QChar::fromLatin1('|'), 2).toInt();
        addressInfo.https = https != 0;
        journals.append(addressInfo);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (LogModeConfigurationWidget *logModeConfigurationWidget : qAsConst(mLogModeConfigurations)) {
        logModeConfigurationWidget->defaultConfig();
    }
```

#### AUTO 


```{c}
auto *action = qobject_cast<QAction *>(sender());
```

#### AUTO 


```{c}
auto item = new QTreeWidgetItem(fileList, QStringList(itemName));
```

#### RANGE FOR STATEMENT 


```{c}
for (LogModeConfigurationWidget *logModeConfigurationWidget : std::as_const(mLogModeConfigurations)) {
        logDebug() << "Adding " << logModeConfigurationWidget->itemName() << " configuration...";

        addPage(logModeConfigurationWidget,
                logModeConfigurationWidget->itemName(),
                logModeConfigurationWidget->iconName(),
                logModeConfigurationWidget->header(),
                false);

        connect(logModeConfigurationWidget, &LogModeConfigurationWidget::configurationChanged, this, &ConfigurationDialog::updateConfiguration);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (LogMode *logMode : logModes) {
        // Ignore this special case
        if (logMode->id() == QLatin1String("openLogMode")) {
            continue;
        }

        startupLogMode->addItem(logMode->icon(), logMode->name(), QVariant(logMode->id()));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &path : paths) {
        addItemInternal(categoryItem, path);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &xorgErrorKeyword : xorgErrorKeywords) {
            text.append(i18n("<li><b>%1</b>: ...</li>", xorgErrorKeyword));
        }
```

#### AUTO 


```{c}
auto action = new QAction(filterIcon, i18n("All messages"), actionMenu);
```

#### RANGE FOR STATEMENT 


```{c}
for (QObject *obj : associatedWidgets) {
        QWidget *widget = qobject_cast<QWidget *>(obj);

        if (widget && (widget->sizeHint().width() > widget->size().width())) {
            widget->setMinimumSize(widget->sizeHint());
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](const QString &line) { logDebug() << "Line " << line; static QFile file(fixturePath); static bool open = false; if (!open) { QVERIFY(file.open(QIODevice::ReadOnly | QIODevice::Text)); open = true; } static QTextStream stream(&file); QCOMPARE(line, stream.readLine());
    }
```

#### AUTO 


```{c}
auto ioDev = new QFile(filename);
```

#### AUTO 


```{c}
auto *cronConfiguration = Globals::instance()
                              .findLogMode(QStringLiteral(CRON_LOG_MODE_ID))
                              ->logModeConfiguration<CronConfiguration *>();
```

#### AUTO 


```{c}
auto *apacheConfiguration = Globals::instance()
                                               .findLogMode(QStringLiteral(APACHE_LOG_MODE_ID))
                                               ->logModeConfiguration<ApacheConfiguration *>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &bootID : bootIdentifiers) {
        // Flush previous journal filters.
        sd_journal_flush_matches(journal);

        // Filter by bootID.
        res = sd_journal_add_match(journal, QString("_BOOT_ID=%1").arg(bootID).toLatin1(), 0);
        if (res < 0)
            logWarning() << "Failed to filter the journal by boot ID" << bootID;

        // Find the oldest entry within this bootID.
        res = sd_journal_seek_head(journal);
        if (res < 0)
            logWarning() << "Failed to seek journal head after filtering by boot ID" << bootID;

        res = sd_journal_next(journal);
        if (res < 1)
            logWarning() << "Failed to go to next entry after filtering by boot ID" << bootID;

        // Get the date for this entry.
        uint64_t time;
        res = sd_journal_get_realtime_usec(journal, &time);
        if (res == 0) {
            identifiersByTime[time] = bootID;
        } else {
            logWarning() << "Failed to get entry time after filtering by boot ID" << bootID;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &path : paths) {
        auto item = new QListWidgetItem(path);
        const QFileInfo checkFile(path);
        if (!checkFile.exists()) {
            item->setForeground(Qt::red);
            missingFiles = true;
        }
        fileList->addItem(item);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (LogLine *logLine : logLines) {
        if (logLine->time() < minTime) {
            QFAIL(QString::fromLatin1("The line '%1' has a lesser time than the required min time (%2)")
                      .arg(logLine->logItems().join(QLatin1Char(' ')), logLine->time().toString())
                      .toUtf8()
                      .constData());
        }
    }
```

#### AUTO 


```{c}
auto *systemConfiguration = Globals::instance()
                                               .findLogMode(QStringLiteral(SYSTEM_LOG_MODE_ID))
                                               ->logModeConfiguration<SystemConfiguration *>();
```

#### AUTO 


```{c}
auto it = openflagMap.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &unit : filters.systemdUnits) {
                action = new QAction(unit, filterActionMenu);

                analyzerOptions.filter = QStringLiteral("_SYSTEMD_UNIT=%1").arg(unit);
                actionData.analyzerOptions = QVariant::fromValue(analyzerOptions);
                action->setData(QVariant::fromValue(actionData));

                filterActionMenu->addAction(action);
                multipleActions->addInnerAction(action, false, true);
            }
```

#### AUTO 


```{c}
auto *item = new QStandardItem(i18n("Select priorities"));
```

#### AUTO 


```{c}
auto *processFilterLayout = new QHBoxLayout();
```

#### RANGE FOR STATEMENT 


```{c}
for (const LogFile &logFile : logFiles) {
        LogFileReader *logFileReader = createLogFileReader(logFile);
        mLogFileReaders.append(logFileReader);

        connect(logFileReader, &LogFileReader::contentChanged, this, &AuditAnalyzer::logFileChanged);
        connect(logFileReader, &LogFileReader::statusBarChanged, this, &Analyzer::statusBarChanged);
        connect(logFileReader, &LogFileReader::errorOccured, this, &Analyzer::errorOccured);
    }
```

#### AUTO 


```{c}
auto *action = new QAction(d->icon, d->name, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (LogManager *manager : logManagers) {
        if (manager != activeLogManager) {
            manager->usedView()->toggleLogViewSearch(true);
        }
    }
```

#### AUTO 


```{c}
auto othersAction = new KActionMenu(QIcon::fromTheme(QStringLiteral("preferences-other")), i18n("Others"), this);
```

#### AUTO 


```{c}
auto *cronConfiguration = logModeConfiguration<CronConfiguration *>();
```

#### RANGE FOR STATEMENT 


```{c}
for (JournalWatcher *watcher : mJournalWatchers) {
            watcher->waitForFinished();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (LogModeConfigurationWidget *logModeConfigurationWidget : std::as_const(mLogModeConfigurations)) {
            if (!logModeConfigurationWidget->isValid()) {
                valid = false;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (TabLogManager *tabLogManager : tabLogManagers) {
        // Log manager without log mode does not need to be reloaded
        if (tabLogManager->logManager()->logMode() == nullptr) {
            continue;
        }

        // Do a simple reload if it is an open log mode
        if (tabLogManager->logManager()->logMode()->id() == QLatin1String("openLogMode")) {
            tabLogManager->logManager()->reload();
            continue;
        }

        // Do a full loading of other log modes (needed if log files have been modified)
        load(tabLogManager->logManager()->logMode(), tabLogManager->logManager(),
             tabLogManager->logManager()->analyzerOptions());
    }
```

#### AUTO 


```{c}
auto *filterIcon = new QLabel();
```

#### AUTO 


```{c}
const auto items{mLogViewWidget->items()};
```

#### AUTO 


```{c}
auto *logModeConfigurationWidget = new ApacheConfigurationWidget();
```

#### AUTO 


```{c}
auto *configuration = Globals::instance()
                          .findLogMode(QStringLiteral(X_SESSION_LOG_MODE_ID))
                          ->logModeConfiguration<XSessionConfiguration *>();
```

#### AUTO 


```{c}
const auto associatedWidgets{mResumePauseAction->associatedWidgets()};
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &addressInfo : remoteJournals) {
        QString menuText = QString("%1:%2").arg(addressInfo.address).arg(addressInfo.port);
        actionMenu = new KActionMenu(remoteIcon, menuText, multipleActions);

        action = new QAction(QIcon::fromTheme(QLatin1String("network-connect")), i18n("Connect"), actionMenu);
        analyzerOptions.address = addressInfo;
        actionData.analyzerOptions = QVariant::fromValue(analyzerOptions);
        action->setData(QVariant::fromValue(actionData));
        actionMenu->addAction(action);
        multipleActions->addInnerAction(action, false, true);

        // Add separator.
        action = new QAction(actionMenu);
        action->setSeparator(true);
        actionMenu->addAction(action);

        // Add filtering by systemd unit.
        JournalFilters filters = logMode->filters(addressInfo);
        if (!filters.systemdUnits.isEmpty()) {
            KActionMenu *filterActionMenu
                = new KActionMenu(filterIcon, i18n("Filter by systemd unit"), actionMenu);

            for (const QString &unit : filters.systemdUnits) {
                action = new QAction(unit, filterActionMenu);

                analyzerOptions.filter = QString("_SYSTEMD_UNIT=%1").arg(unit);
                actionData.analyzerOptions = QVariant::fromValue(analyzerOptions);
                action->setData(QVariant::fromValue(actionData));

                filterActionMenu->addAction(action);
                multipleActions->addInnerAction(action, false, true);
            }
            actionMenu->addAction(filterActionMenu);
        }

        // Add filtering by syslog identifier.
        if (!filters.syslogIdentifiers.isEmpty()) {
            KActionMenu *filterActionMenu
                = new KActionMenu(filterIcon, i18n("Filter by syslog identifier"), actionMenu);

            for (const QString &id : filters.syslogIdentifiers) {
                action = new QAction(id, filterActionMenu);

                analyzerOptions.filter = QString("SYSLOG_IDENTIFIER=%1").arg(id);
                actionData.analyzerOptions = QVariant::fromValue(analyzerOptions);
                action->setData(QVariant::fromValue(actionData));

                filterActionMenu->addAction(action);
                multipleActions->addInnerAction(action, false, true);
            }
            actionMenu->addAction(filterActionMenu);
        }

        multipleActions->addInnerAction(actionMenu, true, false);
    }
```

#### AUTO 


```{c}
auto *configuration = logModeConfiguration<XSessionConfiguration *>();
```

#### AUTO 


```{c}
auto filterIcon = new QLabel();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &path : paths) {
        insertItem(Globals::instance().informationLogLevel(), path);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &addressInfo : remoteJournals) {
        QString menuText = QStringLiteral("%1:%2").arg(addressInfo.address).arg(addressInfo.port);
        actionMenu = new KActionMenu(remoteIcon, menuText, multipleActions);

        action = new QAction(QIcon::fromTheme(QLatin1String("network-connect")), i18n("Connect"), actionMenu);
        analyzerOptions.address = addressInfo;
        actionData.analyzerOptions = QVariant::fromValue(analyzerOptions);
        action->setData(QVariant::fromValue(actionData));
        actionMenu->addAction(action);
        multipleActions->addInnerAction(action, false, true);

        // Add separator.
        action = new QAction(actionMenu);
        action->setSeparator(true);
        actionMenu->addAction(action);

        // Add filtering by systemd unit.
        JournalFilters filters = logMode->filters(addressInfo);
        if (!filters.systemdUnits.isEmpty()) {
            KActionMenu *filterActionMenu
                = new KActionMenu(filterIcon, i18n("Filter by systemd unit"), actionMenu);

            for (const QString &unit : filters.systemdUnits) {
                action = new QAction(unit, filterActionMenu);

                analyzerOptions.filter = QStringLiteral("_SYSTEMD_UNIT=%1").arg(unit);
                actionData.analyzerOptions = QVariant::fromValue(analyzerOptions);
                action->setData(QVariant::fromValue(actionData));

                filterActionMenu->addAction(action);
                multipleActions->addInnerAction(action, false, true);
            }
            actionMenu->addAction(filterActionMenu);
        }

        // Add filtering by syslog identifier.
        if (!filters.syslogIdentifiers.isEmpty()) {
            KActionMenu *filterActionMenu
                = new KActionMenu(filterIcon, i18n("Filter by syslog identifier"), actionMenu);

            for (const QString &id : filters.syslogIdentifiers) {
                action = new QAction(id, filterActionMenu);

                analyzerOptions.filter = QStringLiteral("SYSLOG_IDENTIFIER=%1").arg(id);
                actionData.analyzerOptions = QVariant::fromValue(analyzerOptions);
                action->setData(QVariant::fromValue(actionData));

                filterActionMenu->addAction(action);
                multipleActions->addInnerAction(action, false, true);
            }
            actionMenu->addAction(filterActionMenu);
        }

        multipleActions->addInnerAction(actionMenu, true, false);
    }
```

#### AUTO 


```{c}
auto processFilterLayout = new QHBoxLayout();
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *widget : associatedWidgets) {
        if (widget->sizeHint().width() > widget->size().width()) {
            widget->setMinimumSize(widget->sizeHint());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (LogLevel *level : logLevels) {
        auto *button = new QCheckBox(level->name()); //, m_btnGroup, 0

        mLevelCheckBoxes.append(button);
        mBtnGroup->addButton(button, level->id());
        mBtnGroupLayout->addWidget(button, row, col);

        logDebug() << "name: " << level->name() << " id: " << level->id();

        row++;
        if (row >= 4) {
            row = 0;
            col++;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &string : stringList) {
        const QUrl url = QUrl::fromLocalFile(string);
        if (!url.isValid()) {
            logWarning() << i18n("URL '%1' is not valid, skipping this URL.", url.path());
            continue;
        }

        logFiles.append(LogFile(url, level));
    }
```

#### AUTO 


```{c}
auto configurationWidget = new SambaConfigurationWidget();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : files) {
        logFiles.append(findGenericLogFile(file));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (LogMode *logMode : logModes) {
        if (logMode->id() == selectedModeId) {
            currentMode = logMode;
            break;
        }
    }
```

#### AUTO 


```{c}
auto *item = new QTableWidgetItem(i18n("Enabled"));
```

#### AUTO 


```{c}
const auto logModes = Globals::instance().logModes();
```

#### AUTO 


```{c}
auto *configuration = mLogMode->logModeConfiguration<XSessionConfiguration *>();
```

#### RANGE FOR STATEMENT 


```{c}
for (LogModeConfigurationWidget *logModeConfigurationWidget : qAsConst(mLogModeConfigurations)) {
            if (!logModeConfigurationWidget->isValid()) {
                valid = false;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (LogMode *logMode : logModes) {
        connect(logMode, &LogMode::menuChanged, this, &MainWindow::recreateActions);
    }
```

#### AUTO 


```{c}
const auto logManagers{mTabs->logManagers()};
```

#### RANGE FOR STATEMENT 


```{c}
for (const LogViewColumn &column : qAsConst(mColumns)) {
        columnNames.append(column.columnName());
    }
```

#### AUTO 


```{c}
auto it = cloneFlagMap.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (JournalWatcher *watcher : m_journalWatchers) {
            logDebug() << "watch for" << watcher;
            watcher->waitForFinished();
            logDebug() << "~watch for" << watcher;
        }
```

#### AUTO 


```{c}
auto *addButton = new QPushButton(buttonName, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (LogViewWidgetItem *item : items) {
        item->logLine()->setRecent(false);
    }
```

#### AUTO 


```{c}
auto remoteJournals = configuration->remoteJournals();
```

#### RANGE FOR STATEMENT 


```{c}
for (LogModeAction *logModeAction : logModeActions) {
        const auto innerActions{logModeAction->innerActions()};
        for (QAction *action : innerActions) {
            ActionData actionData = action->data().value<ActionData>();
            if (actionData.addToActionCollection) {
                qCDebug(KSYSTEMLOG) << "Adding action" << actionData.id;
                action = actionCollection()->addAction(actionData.id, action);
            }
            connect(action, &QAction::triggered, this, &MainWindow::selectLogModeAction);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (LogLine *logLine : logLines) {
        if (logLine->time() < minTime) {
            QFAIL(QString::fromLatin1("The line '%1' has a lesser time than the required min time (%2)")
                      .arg(logLine->logItems().join(QLatin1Char(' ')))
                      .arg(logLine->time().toString())
                      .toUtf8()
                      .constData());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (LogModeConfigurationWidget *logModeConfigurationWidget : std::as_const(mLogModeConfigurations)) {
        logModeConfigurationWidget->readConfig();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (TabLogManager *tabLogManager : tabLogManagers) {
        // Log manager without log mode does not need to be reloaded
        if (!tabLogManager->logManager()->logMode()) {
            continue;
        }

        // Do a simple reload if it is an open log mode
        if (tabLogManager->logManager()->logMode()->id() == QLatin1String("openLogMode")) {
            tabLogManager->logManager()->reload();
            continue;
        }

        // Do a full loading of other log modes (needed if log files have been modified)
        load(tabLogManager->logManager()->logMode(), tabLogManager->logManager(), tabLogManager->logManager()->analyzerOptions());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const LogViewColumn &column : columnsLst) {
        auto *action = new QAction(this);
        action->setText(column.columnName());
        // helloAction->setIcon(QIcon::fromTheme( QLatin1String( "media-playback-start" )));
        // helloAction->setShortcut(Qt::CTRL | Qt::Key_M);
        action->setCheckable(true);
        action->setChecked(true);
        action->setToolTip(i18n("Display/Hide the '%1' column", column.columnName()));
        action->setData(QVariant(columnIndex));

        mHeadersTogglingActions->addAction(action);

        ++columnIndex;
    }
```

#### AUTO 


```{c}
auto *kernelAnalyzer = new KernelAnalyzerLocalReader(logMode);
```

#### AUTO 


```{c}
const auto &line
```

#### AUTO 


```{c}
auto it = ipccmdMap.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (TabLogManager *tabLogManager : tabLogManagers) {
        logManagers.append(tabLogManager->logManager());
    }
```

#### AUTO 


```{c}
auto it = m_paramMap.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (TabLogManager *tabLogManager : qAsConst(mTabLogManagers)) {
        if (tabLogManager->logManager()->usedView() == view) {
            return tabLogManager;
        }
    }
```

#### AUTO 


```{c}
auto item = new QStandardItem(logLevel->name());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &path : paths) {
        QFileInfo fileInfo(path);
        if (fileInfo.exists()) {
            d->logFilesExist = true;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &id : filters.syslogIdentifiers) {
                action = new QAction(id, filterActionMenu);

                analyzerOptions.filter = QStringLiteral("SYSLOG_IDENTIFIER=%1").arg(id);
                actionData.analyzerOptions = QVariant::fromValue(analyzerOptions);
                action->setData(QVariant::fromValue(actionData));

                filterActionMenu->addAction(action);
                multipleActions->addInnerAction(action, false, true);
            }
```

#### AUTO 


```{c}
const auto tabLogManagers = mTabLogManagers;
```

#### RANGE FOR STATEMENT 


```{c}
for (const LogViewColumn &column : std::as_const(mColumns)) {
        columnNames.append(column.columnName());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &string : stringList) {
        const QUrl url = QUrl::fromLocalFile(string);
        if (!url.isValid()) {
            qCWarning(KSYSTEMLOG) << i18n("URL '%1' is not valid, skipping this URL.", url.path());
            continue;
        }

        logFiles.append(LogFile(url, level));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const JournalAddress &addressInfo : remoteJournals) {
        m_remoteJournals.append(QString("%1|%2|%3").arg(addressInfo.address).arg(addressInfo.port).arg(addressInfo.https ? 1 : 0));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (LogLevel *level : logLevels) {
        auto button = new QCheckBox(level->name(), this); //, m_btnGroup, 0

        mLevelCheckBoxes.append(button);
        mBtnGroup->addButton(button, level->id());
        mBtnGroupLayout->addWidget(button, row, col);

        qCDebug(KSYSTEMLOG) << "name: " << level->name() << " id: " << level->id();

        row++;
        if (row >= 4) {
            row = 0;
            col++;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (LogModeConfigurationWidget *logModeConfigurationWidget : qAsConst(mLogModeConfigurations)) {
        logModeConfigurationWidget->saveConfig();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &status) {
        d->analyzerStatus = status;
        emit tabTitleChanged(d->usedView, d->logMode->icon(), title());
        emit windowTitleChanged(title());
    }
```

#### AUTO 


```{c}
auto *topLayout = new QVBoxLayout(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (LogModeAction *logModeAction : logModeActions) {
        const auto innerActions{logModeAction->innerActions()};
        for (QAction *action : innerActions) {
            ActionData actionData = action->data().value<ActionData>();
            if (actionData.addToActionCollection) {
                logDebug() << "Adding action" << actionData.id;
                action = actionCollection()->addAction(actionData.id, action);
            }
            connect(action, &QAction::triggered, this, &MainWindow::selectLogModeAction);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QTreeWidgetItem *childItem : children) {
            delete childItem;
        }
```

#### AUTO 


```{c}
auto logModeAction = new SimpleAction(logMode->action(), logMode);
```

#### RANGE FOR STATEMENT 


```{c}
for (LogViewWidgetItem *item : items) {
        if (!mOldestItem) {
            mOldestItem = item;
            continue;
        }

        if (mOldestItem->logLine()->isNewerThan(*(item->logLine()))) {
            mOldestItem = item;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](QPrinter *printing) {
        print(printing);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (LogModeConfigurationWidget *logModeConfigurationWidget : std::as_const(mLogModeConfigurations)) {
        logModeConfigurationWidget->saveConfig();
    }
```

#### AUTO 


```{c}
auto *line = new LogLine(mLogLineInternalIdGenerator++, entry.date, itemComponents, QString(),
                                    Globals::instance().logLevelByPriority(entry.priority), mLogMode);
```

#### AUTO 


```{c}
auto *journalLogMode = dynamic_cast<JournaldLogMode *>(mLogMode);
```

#### AUTO 


```{c}
auto *configuration = Globals::instance()
                                          .findLogMode(QStringLiteral(POSTFIX_LOG_MODE_ID))
                                          ->logModeConfiguration<PostfixConfiguration *>();
```

#### AUTO 


```{c}
auto addButton = new QPushButton(buttonName, this);
```

#### AUTO 


```{c}
auto *multipleActions
        = new MultipleActions(QIcon::fromTheme(QStringLiteral(SAMBA_MODE_ICON)), i18n("Samba"), sambaLogMode);
```

#### AUTO 


```{c}
const auto columnsLst = columns.columns();
```

#### AUTO 


```{c}
auto it = recvMap.constBegin();
```

#### AUTO 


```{c}
auto *printDialog = new QPrintDialog(&printer, mParent);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &addressItem : m_remoteJournals) {
        JournalAddress addressInfo;
        addressInfo.address = addressItem.section(QChar::fromLatin1('|'), 0, 0);
        addressInfo.port = addressItem.section(QChar::fromLatin1('|'), 1, 1).toUInt();
        int https = addressItem.section(QChar::fromLatin1('|'), 2).toInt();
        addressInfo.https = https != 0;
        journals.append(addressInfo);
    }
```

#### AUTO 


```{c}
auto *item = new QTreeWidgetItem(fileList, QStringList(itemName));
```

#### RANGE FOR STATEMENT 


```{c}
for (QListWidgetItem *item : selectedItems) {
                item->setIcon(logLevel->icon());
                item->setData(LogLevelFileList::LogLevelRole, selectedLogLevel);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[=](const QString &line) {
        logDebug() << "Line " << line;
        static QFile file(fixturePath);
        static bool open = false;
        if (!open) {
            QVERIFY(file.open(QIODevice::ReadOnly | QIODevice::Text));
            open = true;
        }
        static QTextStream stream(&file);
        QCOMPARE(line, stream.readLine());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : urls) {
        const QFileInfo fileInfo(url.toLocalFile());

        // TODO Add a recognition of binary files (using the Url mimetype) and refuse them

        if (!fileInfo.isReadable()) {
            logWarning() << "The drag and dropped file is not readable " << url.path();
            return;
        }

        if (fileInfo.isDir()) {
            logWarning() << "Tried to drag and drop a directory " << url.path();
            return;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &unit : units) {
        action = new QAction(unit, filterActionMenu);

        analyzerOptions.filter = QStringLiteral("_SYSTEMD_UNIT=%1").arg(unit);
        actionData.analyzerOptions = QVariant::fromValue(analyzerOptions);
        action->setData(QVariant::fromValue(actionData));

        filterActionMenu->addAction(action);
        multipleActions->addInnerAction(action, false, true);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : files) {
        foundPaths.append(info.dir().absoluteFilePath(file));
    }
```

#### AUTO 


```{c}
auto *filterActionSystemdMenu
                = new KActionMenu(filterIcon, i18n("Filter by systemd unit"), actionMenu);
```

#### AUTO 


```{c}
auto *actionMenu = new KActionMenu(QIcon::fromTheme(QLatin1String("drive-harddisk")),
                                       i18n("Local journal"), multipleActions);
```

#### AUTO 


```{c}
auto *daemonConfiguration = Globals::instance().findLogMode(QStringLiteral(DAEMON_LOG_MODE_ID))->logModeConfiguration<DaemonConfiguration *>();
```

#### RANGE FOR STATEMENT 


```{c}
for (LogModeAction *logModeAction : logModeActions) {
        logModeAction->actionMenu()->setEnabled(enabled);
    }
```

#### AUTO 


```{c}
auto multipleActions = new MultipleActions(QIcon::fromTheme(QStringLiteral(CUPS_MODE_ICON)), i18n("Cups"), cupsLogMode);
```

#### AUTO 


```{c}
auto *multipleActions = new MultipleActions(QIcon::fromTheme(QStringLiteral(APACHE_MODE_ICON)),
                                                i18n("Apache"), apacheLogMode);
```

#### AUTO 


```{c}
auto *ioDev = new QFile(filename);
```

#### AUTO 


```{c}
auto tabCloseTabButton = new QPushButton(QIcon::fromTheme(QStringLiteral("tab-close")), QLatin1String(""), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &line : addedLines) {
            out << line << '\n';
        }
```

#### AUTO 


```{c}
auto actionMenu = new KActionMenu(QIcon::fromTheme(QLatin1String("drive-harddisk")), i18n("Local journal"), multipleActions);
```

#### AUTO 


```{c}
const auto items = mLogViewWidget->items();
```

#### AUTO 


```{c}
auto *cupsConfiguration = Globals::instance()
                              .findLogMode(QStringLiteral(CUPS_LOG_MODE_ID))
                              ->logModeConfiguration<CupsConfiguration *>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &addressInfo : remoteJournals) {
        QString menuText = QStringLiteral("%1:%2").arg(addressInfo.address).arg(addressInfo.port);
        actionMenu = new KActionMenu(remoteIcon, menuText, multipleActions);

        action = new QAction(QIcon::fromTheme(QLatin1String("network-connect")), i18n("Connect"), actionMenu);
        analyzerOptions.address = addressInfo;
        actionData.analyzerOptions = QVariant::fromValue(analyzerOptions);
        action->setData(QVariant::fromValue(actionData));
        actionMenu->addAction(action);
        multipleActions->addInnerAction(action, false, true);

        // Add separator.
        action = new QAction(actionMenu);
        action->setSeparator(true);
        actionMenu->addAction(action);

        // Add filtering by systemd unit.
        JournalFilters filters = logMode->filters(addressInfo);
        if (!filters.systemdUnits.isEmpty()) {
            auto filterActionSystemdMenu = new KActionMenu(filterIcon, i18n("Filter by systemd unit"), actionMenu);

            for (const QString &unit : filters.systemdUnits) {
                action = new QAction(unit, filterActionSystemdMenu);

                analyzerOptions.filter = QStringLiteral("_SYSTEMD_UNIT=%1").arg(unit);
                actionData.analyzerOptions = QVariant::fromValue(analyzerOptions);
                action->setData(QVariant::fromValue(actionData));

                filterActionSystemdMenu->addAction(action);
                multipleActions->addInnerAction(action, false, true);
            }
            actionMenu->addAction(filterActionSystemdMenu);
        }

        // Add filtering by syslog identifier.
        if (!filters.syslogIdentifiers.isEmpty()) {
            auto filterActionMenu = new KActionMenu(filterIcon, i18n("Filter by syslog identifier"), actionMenu);

            for (const QString &id : filters.syslogIdentifiers) {
                action = new QAction(id, filterActionMenu);

                analyzerOptions.filter = QStringLiteral("SYSLOG_IDENTIFIER=%1").arg(id);
                actionData.analyzerOptions = QVariant::fromValue(analyzerOptions);
                action->setData(QVariant::fromValue(actionData));

                filterActionMenu->addAction(action);
                multipleActions->addInnerAction(action, false, true);
            }
            actionMenu->addAction(filterActionMenu);
        }

        multipleActions->addInnerAction(actionMenu, true, false);
    }
```

#### AUTO 


```{c}
auto tabNewTabButton = new QPushButton(QIcon::fromTheme(QStringLiteral("tab-new")), QLatin1String(""), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &line : bufferedLines) {
        msgField = getMsgField(line);

        if (msgField != curMsgField) {
            eventLines.append(event);
            curMsgField = msgField;
            event.clear();
        }

        event.push_front(line);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (LogModeConfigurationWidget *logModeConfigurationWidget : std::as_const(mLogModeConfigurations)) {
        qCDebug(KSYSTEMLOG) << "Adding " << logModeConfigurationWidget->itemName() << " configuration...";

        addPage(logModeConfigurationWidget,
                logModeConfigurationWidget->itemName(),
                logModeConfigurationWidget->iconName(),
                logModeConfigurationWidget->header(),
                false);

        connect(logModeConfigurationWidget, &LogModeConfigurationWidget::configurationChanged, this, &ConfigurationDialog::updateConfiguration);
    }
```

#### AUTO 


```{c}
auto *item = static_cast<LogViewWidgetItem *>(*it);
```

#### AUTO 


```{c}
auto *cupsConfiguration = Globals::instance().findLogMode(QStringLiteral(CUPS_LOG_MODE_ID))->logModeConfiguration<CupsConfiguration *>();
```

#### AUTO 


```{c}
auto filterLabel = new QLabel(i18n("Filter:"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &bootID : bootIdentifiers) {
        // Flush previous journal filters.
        sd_journal_flush_matches(journal);

        // Filter by bootID.
        res = sd_journal_add_match(journal, QString("_BOOT_ID=%1").arg(bootID).toUtf8(), 0);
        if (res < 0)
            logWarning() << "Failed to filter the journal by boot ID" << bootID;

        // Find the oldest entry within this bootID.
        res = sd_journal_seek_head(journal);
        if (res < 0)
            logWarning() << "Failed to seek journal head after filtering by boot ID" << bootID;

        res = sd_journal_next(journal);
        if (res < 1)
            logWarning() << "Failed to go to next entry after filtering by boot ID" << bootID;

        // Get the date for this entry.
        uint64_t time;
        res = sd_journal_get_realtime_usec(journal, &time);
        if (res == 0) {
            identifiersByTime[time] = bootID;
        } else {
            logWarning() << "Failed to get entry time after filtering by boot ID" << bootID;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (LogMode *logMode : logModes) {
        // Some Log mode does not need a configuration widget
        if (!logMode->logModeConfigurationWidget()) {
            continue;
        }

        // The configuration widget could be shared between Log Modes
        if (mLogModeConfigurations.contains(logMode->logModeConfigurationWidget())) {
            continue;
        }

        mLogModeConfigurations.append(logMode->logModeConfigurationWidget());
    }
```

#### AUTO 


```{c}
auto logManager = new LogManager(view);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &id : filters.syslogIdentifiers) {
                action = new QAction(id, filterActionMenu);

                analyzerOptions.filter = QString("SYSLOG_IDENTIFIER=%1").arg(id);
                actionData.analyzerOptions = QVariant::fromValue(analyzerOptions);
                action->setData(QVariant::fromValue(actionData));

                filterActionMenu->addAction(action);
                multipleActions->addInnerAction(action, false, true);
            }
```

#### AUTO 


```{c}
auto *tabCloseTabButton
        = new QPushButton(QIcon::fromTheme(QStringLiteral("tab-close")), QLatin1String(""), this);
```

#### AUTO 


```{c}
auto separator = new QAction(this);
```

#### AUTO 


```{c}
auto *emptyItem = new QTreeWidgetItem(item, QStringList(i18n("No log file...")));
```

#### RANGE FOR STATEMENT 


```{c}
for (LogModeConfigurationWidget *logModeConfigurationWidget : std::as_const(mLogModeConfigurations)) {
        logModeConfigurationWidget->defaultConfig();
    }
```

#### AUTO 


```{c}
auto authenticationLayout = new QVBoxLayout();
```

#### AUTO 


```{c}
auto *configurationWidget = new SambaConfigurationWidget();
```

#### AUTO 


```{c}
auto *authenticationBox = new QGroupBox(i18n("Authentication Log File"));
```

#### AUTO 


```{c}
auto it = accessMap.constBegin();
```

#### AUTO 


```{c}
auto layout = new QVBoxLayout(this);
```

#### AUTO 


```{c}
auto *xorgConfiguration = Globals::instance()
                              .findLogMode(QStringLiteral(XORG_LOG_MODE_ID))
                              ->logModeConfiguration<XorgConfiguration *>();
```

#### AUTO 


```{c}
auto *filterActionMenu = new KActionMenu(filterIcon, i18n("Filter by systemd unit"), actionMenu);
```

#### AUTO 


```{c}
auto *xorgConfiguration = Globals::instance()
                                           .findLogMode(QStringLiteral(XORG_LOG_MODE_ID))
                                           ->logModeConfiguration<XorgConfiguration *>();
```

#### AUTO 


```{c}
auto filterBarLayout = new QHBoxLayout(this);
```

#### AUTO 


```{c}
auto topLayout = new QVBoxLayout(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (QTreeWidgetItem *item : selectedItems) {
        item->setSelected(false);
    }
```

#### AUTO 


```{c}
auto *item = new QListWidgetItem(level->icon(), itemText, fileList);
```

#### AUTO 


```{c}
auto *logModeConfigurationWidget = new CupsConfigurationWidget();
```

#### AUTO 


```{c}
auto *configuration = logModeConfiguration<AcpidConfiguration *>();
```

#### RANGE FOR STATEMENT 


```{c}
for (TabLogManager *tabLogManager : tabLogManagers) {
        // Log manager without log mode does not need to be reloaded
        if (!tabLogManager->logManager()->logMode()) {
            continue;
        }

        // Do a simple reload if it is an open log mode
        if (tabLogManager->logManager()->logMode()->id() == QLatin1String("openLogMode")) {
            tabLogManager->logManager()->reload();
            continue;
        }

        // Do a full loading of other log modes (needed if log files have been modified)
        load(tabLogManager->logManager()->logMode(), tabLogManager->logManager(),
             tabLogManager->logManager()->analyzerOptions());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const JournaldConfiguration::RemoteJournalAddress &addressInfo : remoteJournals) {
        remoteJournalsListWidget->insertRow(remoteJournalsListWidget->rowCount());
        remoteJournalsListWidget->setItem(remoteJournalsListWidget->rowCount() - 1, 0,
                                          new QTableWidgetItem(addressInfo.address));
        remoteJournalsListWidget->setItem(remoteJournalsListWidget->rowCount() - 1, 1,
                                          new QTableWidgetItem(QString::number(addressInfo.port)));
    }
```

#### AUTO 


```{c}
auto *item = new QTreeWidgetItem(QStringList(path));
```

#### AUTO 


```{c}
auto *sambaConfiguration = logModeConfiguration<SambaConfiguration *>();
```

#### RANGE FOR STATEMENT 


```{c}
for (LogLevel *level : logLevelsItems) {
        logLevels->addItem(new QListWidgetItem(level->icon(), level->name()));
    }
```

#### AUTO 


```{c}
auto *button = new QCheckBox(level->name());
```

#### RANGE FOR STATEMENT 


```{c}
for (const LogViewColumn &column : columnsLst) {
        auto action = new QAction(this);
        action->setText(column.columnName());
        // helloAction->setIcon(QIcon::fromTheme( QLatin1String( "media-playback-start" )));
        // helloAction->setShortcut(Qt::CTRL | Qt::Key_M);
        action->setCheckable(true);
        action->setChecked(true);
        action->setToolTip(i18n("Display/Hide the '%1' column", column.columnName()));
        action->setData(QVariant(columnIndex));

        mHeadersTogglingActions->addAction(action);

        ++columnIndex;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &msg : event) {
        message = m_conv.convertMessage(msg);
        re.setPattern(QStringLiteral("^type="));
        message.remove(re);
        re.setPattern(QStringLiteral("\\smsg=audit\\(\\d*\\.\\d*:\\d*\\)"));
        message.remove(re);
        messages.append(message);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const JournalAddress &addressInfo : remoteJournals) {
        if (haveJournalAddress(addressInfo.address, QString::number(addressInfo.port), addressInfo.https)) {
            continue;
        }
        remoteJournalsListWidget->insertRow(remoteJournalsListWidget->rowCount());
        remoteJournalsListWidget->setItem(remoteJournalsListWidget->rowCount() - 1, 0, new QTableWidgetItem(addressInfo.address));
        remoteJournalsListWidget->setItem(remoteJournalsListWidget->rowCount() - 1, 1, new QTableWidgetItem(QString::number(addressInfo.port)));
        auto item = new QTableWidgetItem(i18n("Enabled"));
        item->setFlags(item->flags() | Qt::ItemIsUserCheckable);
        item->setCheckState(addressInfo.https ? Qt::Checked : Qt::Unchecked);
        remoteJournalsListWidget->setItem(remoteJournalsListWidget->rowCount() - 1, 2, item);
    }
```

#### AUTO 


```{c}
auto servicesAction = new KActionMenu(QIcon::fromTheme(QStringLiteral("preferences-system-session-services")), i18n("Services"), this);
```

#### AUTO 


```{c}
const auto logLevelsItems{Globals::instance().logLevels()};
```

#### AUTO 


```{c}
auto *button = new QCheckBox(level->name(), this);
```

