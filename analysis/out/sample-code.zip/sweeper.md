#### RANGE FOR STATEMENT 


```{c}
for(const QString &entry: entries2) {
      if(!thumbnailDir.remove(entry)) {
         errMsg = i18n("A thumbnail could not be removed.");
         return false;
      }
   }
```

#### AUTO 


```{c}
auto query = UsedResources
                | Agent::any()
                | Type::any()
                | Url::startsWith(QStringLiteral("applications:"));
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &&act: checklist) {
      m_privacyConfGroup.writeEntry(act->configKey(), act->checkState(0) == Qt::Checked);
   }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString &entry: entries) {
      // ...if we're not supposed to save them, of course
      if (!saveTheseFavicons.contains(entry)) {
         qCDebug(SWEEPER_LOG) << "removing " << entry ;
         if(!favIconDir.remove(entry)) {
            errMsg = i18n("A favicon could not be removed.");
            return false;
         }
      }
   }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &&act: checklist) {
      act->setCheckState(0, Qt::Unchecked);
   }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &&act: checklist) {
      act->setCheckState(0, m_privacyConfGroup.readEntry(act->configKey(), true) ? Qt::Checked : Qt::Unchecked);
   }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString &entry: entries3) {
      if(!thumbnailDir.remove(entry)) {
         errMsg = i18n("A thumbnail could not be removed.");
         return false;
      }
   }
```

#### AUTO 


```{c}
auto c = new KConfig(QStringLiteral("klipperrc"), KConfig::NoGlobals);
```

#### AUTO 


```{c}
auto mainWidget = new QWidget(this);
```

#### AUTO 


```{c}
auto &&act
```

#### AUTO 


```{c}
auto query = UsedResources
               | Agent::any()
               | Type::any()
               | Url::file();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &&act: checklist) {
      if(act->checkState(0) == Qt::Checked) {
         QString statusText = i18n("Clearing %1...", act->text(0));
         ui.statusTextEdit->append(statusText);

         // actions return whether they were successful
         if(!act->action()) {
            QString errorText = i18n("Clearing of %1 failed: %2", act->text(0), act->getErrMsg());
            ui.statusTextEdit->append(errorText);
         }
      }
   }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &&act: checklist) {
      act->setCheckState(0, Qt::Checked);
   }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString &entry: entries) {
      // ...if we're not supposed to save them, of course
      if (!saveTheseFavicons.contains(entry)) {
         qDebug() << "removing " << entry ;
         if(!favIconDir.remove(entry)) {
            errMsg = i18n("A favicon could not be removed.");
            return false;
         }
      }
   }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString &entry: entries) {
      if(!thumbnailDir.remove(entry)) {
         errMsg = i18n("A thumbnail could not be removed.");
         return false;
      }
   }
```

