#### LAMBDA EXPRESSION 


```{c}
[](growl_callback_data * data)->void {
        snoreDebug(SNORE_DEBUG) << data->id << QString(data->reason) << QString(data->data);
        Notification n = Snore::SnoreCore::instance().getActiveNotificationByID(data->id);
        if (!n.isValid())
        {
            return;
        }
        Notification::CloseReasons r = Notification::NONE;
        std::string reason(data->reason);
        if (reason == "TIMEDOUT")
        {
            r = Notification::TIMED_OUT;
        } else if (reason == "CLOSED")
        {
            r = Notification::DISMISSED;
        } else if (reason == "CLICK")
        {
            r = Notification::ACTIVATED;
            s_instance->slotNotificationActionInvoked(n);
        }
        s_instance->closeNotification(n, r);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, p, noti](QProcess::ProcessError) {
        setErrorString(name() + p->errorString());
        qCDebug(SNORE) << p->readAll();
        if (noti.isValid()) {
            closeNotification(noti, Notification::None);
        }
        p->deleteLater();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, w](){
                Notification notification = w->notification();
                closeNotification(notification, Notification::DISMISSED);
                slotCloseNotification(notification);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[ &, box](QAbstractButton * button) {
        switch (box->buttonRole(button)) {
        case QDialogButtonBox::AcceptRole:
            m_settings->accept();
            m_settings->setVisible(false);
            break;
        case QDialogButtonBox::ApplyRole:
            m_settings->accept();
            break;
        case QDialogButtonBox::ResetRole:
            m_settings->reset();
            break;
        case QDialogButtonBox::RejectRole:
            m_settings->setVisible(false);
            break;
        default:
            qCWarning(SNORE) << "unhandled role" << button->text() << box->buttonRole(button);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool enabled) {
        if (enabled) {
            connect(m_interface, &org::freedesktop::Notifications::ActionInvoked, this, &FreedesktopBackend::slotActionInvoked);
            connect(m_interface, &org::freedesktop::Notifications::NotificationClosed, this , &FreedesktopBackend::slotNotificationClosed);
        } else {
            disconnect(m_interface, &org::freedesktop::Notifications::ActionInvoked, this, &FreedesktopBackend::slotActionInvoked);
            disconnect(m_interface, &org::freedesktop::Notifications::NotificationClosed, this , &FreedesktopBackend::slotNotificationClosed);

        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, notification](int code) {
        Notification::CloseReasons reason = Notification::NONE;

        switch (code) {
        case 0:
            reason = Notification::ACTIVATED;
            slotNotificationActionInvoked(notification);
            break;
        case 1:
            //hidden;
            break;
        case 2:
            reason = Notification::DISMISSED;
            break;
        case 3:
            reason = Notification::TIMED_OUT;
            break;
        case -1:
            //failed
            snoreDebug(SNORE_WARNING) << "SnoreToast failed to display " << notification;
            break;
        }

        closeNotification(notification, reason);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &key : SettingsWindow::allSettingsKeysWithPrefix(
                Utils::normalizeSettingsKey(QLatin1String(""), type, application), settings, getAllKeys)) {
        cout << "  " << qPrintable(key) << ": " << qPrintable(settings.value(Utils::normalizeSettingsKey(key, type, application)).toString()) << endl;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &p : list) {
            path = QDir(p);

            if (!path.entryInfoList(pluginFileFilters()).isEmpty()) {
                break;
            } else {
                snoreDebug(SNORE_DEBUG) << "Possible pluginpath:" << path.absolutePath() << "does not contain plugins.";
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString & p : list) {
            path = QDir(p);

            if (!path.entryInfoList(pluginFileFilters()).isEmpty()) {
                break;
            } else {
                snoreDebug(SNORE_DEBUG) << "Possible pluginpath:" << path.absolutePath() << "does not contain plugins.";
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[reply,this]() {
        snoreDebug(SNORE_DEBUG) << reply->error();
        QByteArray input = reply->readAll();
        reply->close();
        reply->deleteLater();

        snoreDebug(SNORE_DEBUG) << input;

        QJsonObject message = QJsonDocument::fromJson(input).object();

        int latestID = -1;
        if(message.value(QLatin1String("status")).toInt() == 1){
            QJsonArray notifications = message.value(QLatin1String("messages")).toArray();
            for( const QJsonValue &v : notifications) {
                QJsonObject notification = v.toObject();

                latestID = qMax(latestID, notification.value(QLatin1String("id")).toInt());

                QString appName = notification.value(QLatin1String("app")).toString();
                Application app = SnoreCore::instance().aplications().value(appName);

                if (!app.isValid()){
                    Icon icon(QLatin1String("https://api.pushover.net/icons/") +
                                                 notification.value(QLatin1String("icon")).toString() +
                                                 QLatin1String(".png"));
                    app = Application(appName, icon);
                    SnoreCore::instance().registerApplication(app);
                }


                Notification n(app, app.defaultAlert(), notification.value(QLatin1String("title")).toString(),
                               notification.value(QLatin1String("message")).toString(),
                               app.icon(), Notification::defaultTimeout(),
                               static_cast<Notification::Prioritys>(notification.value(QLatin1String("priority")).toInt()));
                if(n.priority() == Notification::EMERGENCY){
                    n.hints().setValue("receipt", notification.value(QLatin1String("receipt")).toString());
                    n.hints().setValue("acked", notification.value(QLatin1String("acked")).toInt());
                }
                if(notification.value(QLatin1String("html")).toInt() == 1) {
                    n.hints().setValue("use-markup", true) ;
                }
                SnoreCore::instance().broadcastNotification(n);
            }
            if(latestID != -1){
                deleteMessages(latestID);
            }
        } else {
            snoreDebug(SNORE_WARNING) << "An error occure" << input;
        }

    }
```

#### LAMBDA EXPRESSION 


```{c}
[](growl_callback_data * data)->void {
        qCDebug(SNORE) << data->id << QString::fromUtf8(data->reason) << QString::fromUtf8(data->data);
        Notification n = Snore::SnoreCore::instance().getActiveNotificationByID(data->id);
        if (!n.isValid())
        {
            return;
        }
        Notification::CloseReasons r = Notification::None;
        std::string reason(data->reason);
        if (reason == "TIMEDOUT")
        {
            r = Notification::TimedOut;
        } else if (reason == "CLOSED")
        {
            r = Notification::Dismissed;
        } else if (reason == "CLICK")
        {
            r = Notification::Activated;
            s_instance->slotNotificationActionInvoked(n);
        }
        s_instance->closeNotification(n, r);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (PluginContainer *info : PluginContainer::pluginCache(type).values()) {
                SnorePlugin *plugin = info->load();
                if (!plugin) {
                    continue;
                }

                switch (info->type()) {
                case SnorePlugin::BACKEND:
                    break;
                case SnorePlugin::SECONDARY_BACKEND:
                case SnorePlugin::FRONTEND:
                case SnorePlugin::PLUGIN:
                    plugin->setEnabled(plugin->settingsValue(QLatin1String("Enabled"), LOCAL_SETTING).toBool());
                    break;
                default:
                    snoreDebug(SNORE_WARNING) << "Plugin Cache corrupted\n" << info->file() << info->type();
                    continue;
                }

                snoreDebug(SNORE_DEBUG) << info->name() << "is a" << info->type();
                d->m_pluginNames[info->type()].append(info->name());
                auto key = qMakePair(type, info->name());
                Q_ASSERT_X(!d->m_plugins.contains(key), Q_FUNC_INFO, "Multiple plugins of the same type with the same name.");
                d->m_plugins.insert(key, plugin);
            }
```

#### AUTO 


```{c}
auto addWidgets = [&](QTabWidget * target, QWidget * container, SnorePlugin::PluginTypes type) {
        bool enabled = false;
        target->clear();
        if (types & type) {
            for (PluginSettingsWidget *widget : SnoreCore::instance().settingWidgets(type)) {
                target->addTab(widget, widget->name());
                m_tabs.append(widget);
                enabled = true;
            }
        }
        if (enabled) {
            if (ui->tabWidget->indexOf(container) == -1) {
                ui->tabWidget->addTab(container, container->property("TAB_NAME").toString());
            }
        } else {
            int index = ui->tabWidget->indexOf(container);
            container->setProperty("TAB_NAME", ui->tabWidget->tabText(index));
            ui->tabWidget->removeTab(index);
        }
    };
```

#### LAMBDA EXPRESSION 


```{c}
[&](QTabWidget * target, QWidget * container, SnorePlugin::PluginTypes type) {
        bool enabled = false;
        target->clear();
        if (types & type) {
            foreach(PluginSettingsWidget * widget, Settings::settingWidgets(type)) {
                target->addTab(widget, widget->name());
                m_tabs.append(widget);
                enabled = true;
            }
        }
        if (enabled) {
            if (ui->tabWidget->indexOf(container) == -1) {
                ui->tabWidget->addTab(container, container->property("TAB_NAME").toString());
            }
        } else {
            int index = ui->tabWidget->indexOf(container);
            container->setProperty("TAB_NAME", ui->tabWidget->tabText(index));
            ui->tabWidget->removeTab(index);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, w]() {
                Notification notification = w->notification();
                slotNotificationActionInvoked(notification);
                closeNotification(notification, Notification::ACTIVATED);
                slotCloseNotification(notification);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[&](QAbstractSocket::SocketError error) {
        snoreDebug(SNORE_WARNING) << error << m_socket->errorString();
        emit loggedInChanged(false);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[reply](){
        snoreDebug(SNORE_DEBUG) << reply->error();
        snoreDebug(SNORE_DEBUG) << reply->readAll();
        reply->close();
        reply->deleteLater();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](NotifyWidget *w, Snore::Notification notification){
        w->display(notification);
        notification.hints().setPrivateValue(this, "id", w->id());
        slotNotificationDisplayed(notification);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &app : SettingsWindow::knownApps()) {
        cout << qPrintable(app) << endl;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Application & a : SnoreCore::instance().aplications()) {
                        m_snarl->slotRegisterApplication(a);
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &pluginName : m_pluginNames[type]) {
            SnorePlugin *plugin = m_plugins.value(pluginName);
            bool enable = m_plugins[pluginName]->value("Enabled", LOCAL_SETTING).toBool();
            if (!plugin->isInitialized() && enable) {
                plugin->initialize();
            } else if (plugin->isInitialized() && !enable) {
                plugin->deinitialize();
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[q, notification]() {
        qCDebug(SNORE) << notification;
        q->requestCloseNotification(notification, Notification::TimedOut);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[reply, deviceName, this]() {
        qCDebug(SNORE) << reply->error();
        QByteArray input = reply->readAll();
        reply->close();
        reply->deleteLater();

        QJsonObject message = QJsonDocument::fromJson(input).object();

        if (message.value(QStringLiteral("status")).toInt() == 1) {
            registerDevice(message.value(QStringLiteral("secret")).toString(), deviceName);
        } else {
            qCWarning(SNORE) << "An error occure" << input;
            emit loggedInChanged(false);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](PushoverClient::LoginState state) {
        m_loggedIn = state;
    }
```

#### AUTO 


```{c}
auto addWidgets = [&](QTabWidget * target, QWidget * container, SnorePlugin::PluginTypes type) {
        bool enabled = false;
        target->clear();
        if (types & type) {
            foreach (PluginSettingsWidget * widget, Settings::settingWidgets(type)) {
                target->addTab(widget, widget->name());
                m_tabs.append(widget);
                enabled = true;
            }
        }
        if (enabled) {
            if (ui->tabWidget->indexOf(container) == -1) {
                ui->tabWidget->addTab(container, container->property("TAB_NAME").toString());
            }
        } else {
            int index = ui->tabWidget->indexOf(container);
            container->setProperty("TAB_NAME", ui->tabWidget->tabText(index));
            ui->tabWidget->removeTab(index);
        }
    };
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString & pluginName) {
        SnorePlugin *plugin = m_plugins.value(pluginName);
        bool enable = m_plugins[pluginName]->value("Enabled", LOCAL_SETTING).toBool();
        if (!plugin->isInitialized() && enable) {
            plugin->initialize();
        } else if (plugin->isInitialized() && !enable) {
            plugin->deinitialize();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[reply, this]() {
        qCDebug(SNORE) << reply->error();
        QByteArray input = reply->readAll();
        reply->close();
        reply->deleteLater();

        qCDebug(SNORE) << input;

        QJsonObject message = QJsonDocument::fromJson(input).object();

        int latestID = -1;
        if (message.value(QStringLiteral("status")).toInt() == 1) {
            QJsonArray notifications = message.value(QStringLiteral("messages")).toArray();
            foreach (const QJsonValue &v, notifications) {
                QJsonObject notification = v.toObject();

                latestID = qMax(latestID, notification.value(QStringLiteral("id")).toInt());

                QString appName = notification.value(QStringLiteral("app")).toString();
                Application app = SnoreCore::instance().aplications().value(appName);

                if (!app.isValid()) {
                    Icon icon(Icon::fromWebUrl(QUrl::fromEncoded((QLatin1String("https://api.pushover.net/icons/") +
                                               notification.value(QStringLiteral("icon")).toString() +
                                               QLatin1String(".png")).toUtf8().constData())));
                    app = Application(appName, icon);
                    SnoreCore::instance().registerApplication(app);
                }

                Notification n(app, app.defaultAlert(), notification.value(QStringLiteral("title")).toString(),
                               notification.value(QStringLiteral("message")).toString(),
                               app.icon(), Notification::defaultTimeout(),
                               static_cast<Notification::Prioritys>(notification.value(QStringLiteral("priority")).toInt()));
                if (n.priority() == Notification::Emergency) {
                    n.hints().setValue("receipt", notification.value(QStringLiteral("receipt")).toString());
                    n.hints().setValue("acked", notification.value(QStringLiteral("acked")).toInt());
                }
                if (notification.value(QStringLiteral("html")).toInt() == 1) {
                    n.hints().setValue("use-markup", true) ;
                }
                n.data()->setSource(m_frontend);
                SnoreCore::instance().broadcastNotification(n);
            }
            if (latestID != -1) {
                deleteMessages(latestID);
            }
        } else {
            qCWarning(SNORE) << "An error occured" << input;
        }

    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Application & a : SnoreCore::instance().aplications()) {
                slotRegisterApplication(a);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (PluginSettingsWidget *widget : SnoreCore::instance().settingWidgets(type)) {
                target->addTab(widget, widget->name());
                m_tabs.append(widget);
                enabled = true;
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (NotifyWidget *w : m_widgets) {
                if (w->acquire(notification.timeout())) {
                    display(w, notification);
                    return;
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[reply, watcher, this]() {
        m_supportsRichtext = reply.value().contains(QLatin1String("body-markup"));
        watcher->deleteLater();
    }
```

#### AUTO 


```{c}
auto func = [](growl_callback_data * data)->void {
        qCDebug(SNORE) << data->id << QString::fromUtf8(data->reason) << QString::fromUtf8(data->data);
        Notification n = Snore::SnoreCore::instance().getActiveNotificationByID(data->id);
        if (!n.isValid())
        {
            return;
        }
        Notification::CloseReasons r = Notification::None;
        std::string reason(data->reason);
        if (reason == "TIMEDOUT")
        {
            r = Notification::TimedOut;
        } else if (reason == "CLOSED")
        {
            r = Notification::Dismissed;
        } else if (reason == "CLICK")
        {
            r = Notification::Activated;
            s_instance->slotNotificationActionInvoked(n);
        }
        s_instance->closeNotification(n, r);
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &key : Utils::allSettingsKeysWithPrefix(
                Utils::normalizeSettingsKey(QLatin1String(""), type, application), settings, getAllKeys)) {
        cout <<"  " << qPrintable(key) << ": " << qPrintable(settings.value(Utils::normalizeSettingsKey(key, type, application)).toString()) << endl;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&](QTabWidget * target, QWidget * container, SnorePlugin::PluginTypes type) {
        bool enabled = false;
        target->clear();
        if (types & type) {
            foreach (PluginSettingsWidget * widget, Settings::settingWidgets(type)) {
                target->addTab(widget, widget->name());
                m_tabs.append(widget);
                enabled = true;
            }
        }
        if (enabled) {
            if (ui->tabWidget->indexOf(container) == -1) {
                ui->tabWidget->addTab(container, container->property("TAB_NAME").toString());
            }
        } else {
            int index = ui->tabWidget->indexOf(container);
            container->setProperty("TAB_NAME", ui->tabWidget->tabText(index));
            ui->tabWidget->removeTab(index);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        snoreDebug(SNORE_DEBUG) << "connecting";
        m_socket->sendBinaryMessage((QLatin1String("login:") + device() + QLatin1Char(':') + secret() + QLatin1Char('\n')).toUtf8().constData());
        emit loggedInChanged(true);
        getMessages();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (NotifyWidget *w : m_widgets) {
            if (!m_queue.isEmpty() && w->acquire(m_queue.first().timeout())) {
                Notification notification = m_queue.takeFirst();
                notification.hints().setPrivateValue(this, "id", w->id());
                w->display(notification);
                slotNotificationDisplayed(notification);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto name : d->m_pluginNames[type]) {
        //TODO: mem leak?
        SnorePlugin *p = d->m_plugins[name];
        PluginSettingsWidget *widget = p->settingsWidget();
        if (widget) {
            list.append(widget);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, p, noti](QProcess::ProcessError) {
        setErrorString(name() + p->errorString());
        qCDebug(SNORE) << p->readAll();
        if (noti.isValid()) {
            closeNotification(noti, Snore::Notification::None);
        }
        p->deleteLater();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        QFileDialog dialog;
        dialog.setNameFilter(tr("All Audio files").append("(*.mp3 *.wav *.ogg)"));
        dialog.setFileMode(QFileDialog::ExistingFile);
        dialog.setDirectory(m_lineEditFileName->text());
        if (dialog.exec()) {
            m_lineEditFileName->setText(dialog.selectedFiles().first());
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, b](const QString &) {
            slotInitPrimaryNotificationBackend();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](PluginSettingsWidget * a, PluginSettingsWidget * b) {
        return a->name() < b->name();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (SnorePlugin::PluginTypes type : PluginContainer::types()) {
        if (type != SnorePlugin::ALL && types & type) {
            for (PluginContainer *info : PluginContainer::pluginCache(type).values()) {
                SnorePlugin *plugin = info->load();
                if (!plugin) {
                    continue;
                }

                switch (info->type()) {
                case SnorePlugin::BACKEND:
                    break;
                case SnorePlugin::SECONDARY_BACKEND:
                case SnorePlugin::FRONTEND:
                case SnorePlugin::PLUGIN: {
                    if (plugin->value("Enabled").toBool()) {
                        if (!plugin->initialize()) {
                            snoreDebug(SNORE_WARNING) << "Failed to initialize" << plugin->name();
                            plugin->deinitialize();
                            //info->unload();
                            break;
                        }
                    }
                }
                break;
                default:
                    snoreDebug(SNORE_WARNING) << "Plugin Cache corrupted\n" << info->file() << info->type();
                    continue;
                }
                snoreDebug(SNORE_DEBUG) << info->name() << "is a" << info->type();
                d->m_pluginNames[info->type()].append(info->name());
                d->m_plugins[info->name()] = plugin;
            }
            if (d->m_pluginNames.contains(type)) {
                qSort(d->m_pluginNames[type]);
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QByteArray & msg) {
        char c = msg.at(0);
        switch (c) {
        case '#':
            snoreDebug(SNORE_DEBUG) << "still alive";
            break;
        case '!':
            getMessages();
            break;
        case 'R':
            snoreDebug(SNORE_DEBUG) << "need to reconnect";
            m_socket->close();
            m_socket->deleteLater();
            connectToService();
            break;
        case 'E':
            snoreDebug(SNORE_WARNING) << "Connection Error";
            emit error(QStringLiteral("Please Loggin to https://pushover.net and reanble your device."));
            emit loggedInChanged(false);
            m_socket->close();
            m_socket->deleteLater();
            break;
        default:
            snoreDebug(SNORE_WARNING) << "unknown message received" << msg;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool enabled) {
        if (enabled) {
            tcpServer = new QTcpServer(this);
            if (!tcpServer->listen(QHostAddress::Any, port)) {
                setErrorString(tr("The port is already used by a different application."));
                return;
            }
            connect(tcpServer, &QTcpServer::newConnection, this, &SnarlNetworkFrontend::handleConnection);
        } else {
            tcpServer->deleteLater();
        }
    }
```

#### AUTO 


```{c}
auto func = [](growl_callback_data *data)->void{
        snoreDebug(SNORE_DEBUG) << data->id << QString(data->reason) << QString(data->data);
        Notification n = Snore::SnoreCore::instance().getActiveNotificationByID(data->id);
        if (!n.isValid()) {
            return;
        }
        Notification::CloseReasons r = Notification::NONE;
        std::string reason(data->reason);
        if (reason == "TIMEDOUT") {
            r = Notification::TIMED_OUT;
        } else if (reason == "CLOSED") {
            r = Notification::DISMISSED;
        } else if (reason == "CLICK") {
            r = Notification::ACTIVATED;
            s_instance->slotNotificationActionInvoked(n);
        }
        s_instance->closeNotification(n, r);
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &pluginName : m_pluginNames[type]) {
            SnorePlugin *plugin = m_plugins.value(pluginName);
            bool enable = m_plugins[pluginName]->settingsValue(QLatin1String("Enabled"), LOCAL_SETTING).toBool();
            if (!plugin->isInitialized() && enable) {
                plugin->initialize();
            } else if (plugin->isInitialized() && !enable) {
                plugin->deinitialize();
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Snore::Application &a : Snore::SnoreCore::instance().aplications()) {
                        m_snarl->slotRegisterApplication(a);
                    }
```

#### LAMBDA EXPRESSION 


```{c}
[reply]() {
        qCDebug(SNORE) << reply->error();
        qCDebug(SNORE) << reply->readAll();
        //TODO:parse reply
        reply->close();
        reply->deleteLater();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (PluginContainer *info : PluginContainer::pluginCache(type).values()) {
                SnorePlugin *plugin = info->load();
                if (!plugin) {
                    continue;
                }

                switch (info->type()) {
                case SnorePlugin::BACKEND:
                    break;
                case SnorePlugin::SECONDARY_BACKEND:
                case SnorePlugin::FRONTEND:
                case SnorePlugin::PLUGIN: {
                    if (plugin->value("Enabled").toBool()) {
                        if (!plugin->initialize()) {
                            snoreDebug(SNORE_WARNING) << "Failed to initialize" << plugin->name();
                            plugin->deinitialize();
                            //info->unload();
                            break;
                        }
                    }
                }
                break;
                default:
                    snoreDebug(SNORE_WARNING) << "Plugin Cache corrupted\n" << info->file() << info->type();
                    continue;
                }
                snoreDebug(SNORE_DEBUG) << info->name() << "is a" << info->type();
                d->m_pluginNames[info->type()].append(info->name());
                d->m_plugins[info->name()] = plugin;
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool enabled) {
        if (enabled) {
            connect(&SnoreCore::instance(), &SnoreCore::notificationClosed, this, &SnoreFrontend::slotNotificationClosed, Qt::QueuedConnection);
            connect(&SnoreCore::instance(), &SnoreCore::actionInvoked, this, &SnoreFrontend::slotActionInvoked, Qt::QueuedConnection);
        } else {
            disconnect(&SnoreCore::instance(), &SnoreCore::notificationClosed, this, &SnoreFrontend::slotNotificationClosed);
            disconnect(&SnoreCore::instance(), &SnoreCore::actionInvoked, this, &SnoreFrontend::slotActionInvoked);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto widget : SnoreCore::instance().settingWidgets()) {
        ui->tabWidget->addTab(widget, widget->name());
        m_tabs.append(widget);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[reply, this]() {
        snoreDebug(SNORE_DEBUG) << reply->error();
        QByteArray input = reply->readAll();
        reply->close();
        reply->deleteLater();

        snoreDebug(SNORE_DEBUG) << input;

        QJsonObject message = QJsonDocument::fromJson(input).object();

        int latestID = -1;
        if (message.value(QStringLiteral("status")).toInt() == 1) {
            QJsonArray notifications = message.value(QStringLiteral("messages")).toArray();
            foreach(const QJsonValue & v, notifications) {
                QJsonObject notification = v.toObject();

                latestID = qMax(latestID, notification.value(QStringLiteral("id")).toInt());

                QString appName = notification.value(QStringLiteral("app")).toString();
                Application app = SnoreCore::instance().aplications().value(appName);

                if (!app.isValid()) {
                    Icon icon(Icon::fromWebUrl(QUrl::fromEncoded((QLatin1String("https://api.pushover.net/icons/") +
                                               notification.value(QStringLiteral("icon")).toString() +
                                               QLatin1String(".png")).toUtf8().constData())));
                    app = Application(appName, icon);
                    SnoreCore::instance().registerApplication(app);
                }

                Notification n(app, app.defaultAlert(), notification.value(QStringLiteral("title")).toString(),
                               notification.value(QStringLiteral("message")).toString(),
                               app.icon(), Notification::defaultTimeout(),
                               static_cast<Notification::Prioritys>(notification.value(QStringLiteral("priority")).toInt()));
                if (n.priority() == Notification::EMERGENCY) {
                    n.hints().setValue("receipt", notification.value(QStringLiteral("receipt")).toString());
                    n.hints().setValue("acked", notification.value(QStringLiteral("acked")).toInt());
                }
                if (notification.value(QStringLiteral("html")).toInt() == 1) {
                    n.hints().setValue("use-markup", true) ;
                }
                n.data()->setSource(this);
                SnoreCore::instance().broadcastNotification(n);
            }
            if (latestID != -1) {
                deleteMessages(latestID);
            }
        } else {
            snoreDebug(SNORE_WARNING) << "An error occure" << input;
        }

    }
```

#### AUTO 


```{c}
auto notify = [&backends, &snore, &messages, this](Notification n) {
            qDebug() << n << "closed";
            qDebug() << backends.size();
            if (backends.empty()) {
                return;
            }
            QString old = snore.primaryNotificationBackend();
            while (!backends.empty() && snore.primaryNotificationBackend() == old) {
                QString p = backends.takeLast();
                snore.setSettingsValue(QStringLiteral("PrimaryBackend"), p, LocalSetting);
                SnoreCorePrivate::instance()->syncSettings();
                if (snore.primaryNotificationBackend() == p) {
                    for (const auto &message : messages) {
                        snore.broadcastNotification(Notification(app, app.defaultAlert(), QStringLiteral("Title"), message, app.icon()));
                    }
                }
            }
        };
```

#### LAMBDA EXPRESSION 


```{c}
[&](Notification noti) {
            if (!parser.isSet(silent)) {
                QString reason;
                QDebug(&reason) << noti.closeReason();
                cout << qPrintable(reason) << endl;
            }
            if (noti.closeReason() == Notification::Closed) {
#ifdef Q_OS_WIN
                if (parser.isSet(_bringProcessToFront)) {
                    bringToFront(parser.value(_bringProcessToFront));
                } else if (parser.isSet(_bringWindowToFront)) {
                    Utils::bringWindowToFront((HWND)parser.value(_bringWindowToFront).toULongLong(), true);
                }
#endif
            }
            returnCode = noti.closeReason();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto w : m_widgets) {
            w->deleteLater();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool enabled) {
        if (enabled) {
            connect(SnoreCorePrivate::instance(), &SnoreCorePrivate::applicationRegistered, this, &SnoreBackend::slotRegisterApplication, Qt::QueuedConnection);
            connect(SnoreCorePrivate::instance(), &SnoreCorePrivate::applicationDeregistered, this, &SnoreBackend::slotDeregisterApplication, Qt::QueuedConnection);

            connect(this, &SnoreBackend::notificationClosed, SnoreCorePrivate::instance(), &SnoreCorePrivate::slotNotificationClosed, Qt::QueuedConnection);
            connect(SnoreCorePrivate::instance(), &SnoreCorePrivate::notify, this, &SnoreBackend::slotNotify, Qt::QueuedConnection);

            for (const Application &a : SnoreCore::instance().aplications()) {
                slotRegisterApplication(a);
            }
        } else {
            for (const Application &a : SnoreCore::instance().aplications()) {
                slotDeregisterApplication(a);
            }
            disconnect(SnoreCorePrivate::instance(), &SnoreCorePrivate::applicationRegistered, this, &SnoreBackend::slotRegisterApplication);
            disconnect(SnoreCorePrivate::instance(), &SnoreCorePrivate::applicationDeregistered, this, &SnoreBackend::slotDeregisterApplication);

            disconnect(this, &SnoreBackend::notificationClosed, SnoreCorePrivate::instance(), &SnoreCorePrivate::slotNotificationClosed);
            disconnect(SnoreCorePrivate::instance(), &SnoreCorePrivate::notify, this, &SnoreBackend::slotNotify);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[updateTimer, this](){
                qDebug() << value(QLatin1String("Registered")).toBool();
                if (value(QLatin1String("Registered"), Snore::LOCAL_SETTING).toBool()) {
                    updateLoginState();
                    updateTimer->deleteLater();
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this, notification](int code) {
        Notification::CloseReasons reason = Notification::None;

        switch (code) {
        case 0:
            reason = Notification::Activated;
            slotNotificationActionInvoked(notification);
            break;
        case 1:
            //hidden;
            break;
        case 2:
            reason = Notification::Dismissed;
            break;
        case 3:
            reason = Notification::TimedOut;
            break;
        case -1:
            //failed
            qCWarning(SNORE) << "SnoreToast failed to display " << notification;
            break;
        }

        closeNotification(notification, reason);
    }
```

#### AUTO 


```{c}
auto pluginName
```

#### LAMBDA EXPRESSION 


```{c}
[reply, watcher, this]() {
        m_supportsRichtext = reply.value().contains(QStringLiteral("body-markup"));
        watcher->deleteLater();
    }
```

#### AUTO 


```{c}
auto addWidgets = [&](QTabWidget * target, QWidget * container, SnorePlugin::PluginTypes type) {
        bool enabled = false;
        target->clear();
        if (types & type) {
            foreach(PluginSettingsWidget * widget, Settings::settingWidgets(type)) {
                target->addTab(widget, widget->name());
                m_tabs.append(widget);
                enabled = true;
            }
        }
        if (enabled) {
            if (ui->tabWidget->indexOf(container) == -1) {
                ui->tabWidget->addTab(container, container->property("TAB_NAME").toString());
            }
        } else {
            int index = ui->tabWidget->indexOf(container);
            container->setProperty("TAB_NAME", ui->tabWidget->tabText(index));
            ui->tabWidget->removeTab(index);
        }
    };
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &locale)
    {
        snoreDebug(SNORE_DEBUG) << locale;
        if(locale != "C") {
            QTranslator* translator = new QTranslator( qApp->instance() );
            if ( translator->load(locale, ":/lang/libsnore/") )
            {
                snoreDebug(SNORE_INFO) << "Using system locale:" << locale;
                snoreDebug(SNORE_INFO) << qApp->installTranslator( translator );
            }
            else
            {
                translator->deleteLater();
                QString fileName = QString(":/lang/libsnore/%1.qm").arg(locale);
                snoreDebug(SNORE_WARNING)<< "Failed to load translations for:" << locale << fileName << QFile::exists(fileName) ;
                return false;
            }
        }
        return true;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (SnorePlugin::PluginTypes type : SnorePlugin::types()) {
        if (type != SnorePlugin::ALL && types & type) {
            for (PluginContainer *info : PluginContainer::pluginCache(type).values()) {
                SnorePlugin *plugin = info->load();
                if (!plugin) {
                    continue;
                }

                switch (info->type()) {
                case SnorePlugin::BACKEND:
                    break;
                case SnorePlugin::SECONDARY_BACKEND:
                case SnorePlugin::FRONTEND:
                case SnorePlugin::PLUGIN:
                    plugin->setEnabled(plugin->settingsValue(QLatin1String("Enabled"), LOCAL_SETTING).toBool());
                    break;
                default:
                    snoreDebug(SNORE_WARNING) << "Plugin Cache corrupted\n" << info->file() << info->type();
                    continue;
                }

                snoreDebug(SNORE_DEBUG) << info->name() << "is a" << info->type();
                d->m_pluginNames[info->type()].append(info->name());
                auto key = qMakePair(type, info->name());
                Q_ASSERT_X(!d->m_plugins.contains(key), Q_FUNC_INFO, "Multiple plugins of the same type with the same name.");
                d->m_plugins.insert(key, plugin);
            }
            if (d->m_pluginNames.contains(type)) {
                qSort(d->m_pluginNames[type]);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &key : SettingsWindow::allSettingsKeysWithPrefix(
                Utils::normalizeSettingsKey(QLatin1String(""), type, prefix), settings, getAllKeys)) {
        cout << "  " << qPrintable(key) << ": " << qPrintable(settings.value(Utils::normalizeSettingsKey(key, type, prefix)).toString()) << endl;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[reply, deviceName, this]() {
        snoreDebug(SNORE_DEBUG) << reply->error();
        QByteArray input = reply->readAll();
        reply->close();
        reply->deleteLater();


        QJsonObject message = QJsonDocument::fromJson(input).object();

        if(message.value(QLatin1String("status")).toInt() == 1)
        {
            QString secret = message.value(QLatin1String("secret")).toString();
            QNetworkRequest request(QUrl(QLatin1String("https://api.pushover.net/1/devices.json")));

            request.setHeader(QNetworkRequest::ContentTypeHeader, QVariant(QLatin1String("application/x-www-form-urlencoded")));
            QNetworkReply *reply = m_manager.post(request, QString(QLatin1String("secret=%1&name=%2&os=O")).arg(secret, deviceName).toUtf8().constData());


            connect(reply, &QNetworkReply::finished, [reply, secret, this]() {
                snoreDebug(SNORE_DEBUG) << reply->error();
                QByteArray input = reply->readAll();
                reply->close();
                reply->deleteLater();


                QJsonObject message = QJsonDocument::fromJson(input).object();


                if(message.value(QLatin1String("status")).toInt() == 1) {
                    setValue(QLatin1String("Secret"), secret, LOCAL_SETTING);
                    setValue(QLatin1String("DeviceID"), message.value(QLatin1String("id")).toString(), LOCAL_SETTING);
                    setValue(QLatin1String("Registered"), true, LOCAL_SETTING);
                    connectToService();
                } else {
                    snoreDebug(SNORE_WARNING) << "An error occure" << input;
                }

            });
        }else {
            snoreDebug(SNORE_WARNING) << "An error occure" << input;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Application &a : SnoreCore::instance().aplications()) {
        this->slotRegisterApplication(a);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool enabled) {
        if (enabled) {
            m_adaptor = new  NotificationsAdaptor(this);
            QDBusConnection dbus = QDBusConnection::sessionBus();
            if (dbus.registerService(QLatin1String("org.freedesktop.Notifications"))) {
                if (!dbus.registerObject(QLatin1String("/org/freedesktop/Notifications"), this)) {
                    setErrorString(tr("Failed to register dbus object."));
                }
            } else {
                setErrorString(tr("Failed to register dbus service."));
            }
        } else {
            QDBusConnection dbus = QDBusConnection::sessionBus();
            dbus.unregisterService(QLatin1String("org.freedesktop.Notifications"));
            dbus.unregisterObject(QLatin1String("/org/freedesktop/Notifications"));
            m_adaptor->deleteLater();
            m_adaptor = nullptr;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&](QTabWidget * target, QWidget * container, SnorePlugin::PluginTypes type) {
        bool enabled = false;
        target->clear();
        if (types & type) {
            for (PluginSettingsWidget *widget : SnoreCore::instance().settingWidgets(type)) {
                target->addTab(widget, widget->name());
                m_tabs.append(widget);
                enabled = true;
            }
        }
        if (enabled) {
            if (ui->tabWidget->indexOf(container) == -1) {
                ui->tabWidget->addTab(container, container->property("TAB_NAME").toString());
            }
        } else {
            int index = ui->tabWidget->indexOf(container);
            container->setProperty("TAB_NAME", ui->tabWidget->tabText(index));
            ui->tabWidget->removeTab(index);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &extention : pluginExtentions()) {
            out << QLatin1String("libsnore_*.") + extention;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &s : qApp->libraryPaths()) {
         list << s + suffix;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&,reply,manager]() {
                m_img = QImage::fromData(reply->readAll(), "PNG");
                m_img.save(m_localUrl, "PNG");
                s_localImageCache.insert(m_localUrl);
                snoreDebug(SNORE_DEBUG) << m_localUrl << "added to cache";
                reply->close();
                reply->deleteLater();
                manager->deleteLater();
                m_isDownloading = false;
            }
```

#### LAMBDA EXPRESSION 


```{c}
[reply, this]() {
        qCDebug(SNORE) << reply->error();
        QByteArray input = reply->readAll();
        reply->close();
        reply->deleteLater();

        qCDebug(SNORE) << input;

        QJsonObject message = QJsonDocument::fromJson(input).object();

        int latestID = -1;
        if (message.value(QStringLiteral("status")).toInt() == 1) {
            QJsonArray notifications = message.value(QStringLiteral("messages")).toArray();
            foreach(const QJsonValue & v, notifications) {
                QJsonObject notification = v.toObject();

                latestID = qMax(latestID, notification.value(QStringLiteral("id")).toInt());

                QString appName = notification.value(QStringLiteral("app")).toString();
                Application app = SnoreCore::instance().aplications().value(appName);

                if (!app.isValid()) {
                    Icon icon(Icon::fromWebUrl(QUrl::fromEncoded((QLatin1String("https://api.pushover.net/icons/") +
                                               notification.value(QStringLiteral("icon")).toString() +
                                               QLatin1String(".png")).toUtf8().constData())));
                    app = Application(appName, icon);
                    SnoreCore::instance().registerApplication(app);
                }

                Notification n(app, app.defaultAlert(), notification.value(QStringLiteral("title")).toString(),
                               notification.value(QStringLiteral("message")).toString(),
                               app.icon(), Notification::defaultTimeout(),
                               static_cast<Notification::Prioritys>(notification.value(QStringLiteral("priority")).toInt()));
                if (n.priority() == Notification::Emergency) {
                    n.hints().setValue("receipt", notification.value(QStringLiteral("receipt")).toString());
                    n.hints().setValue("acked", notification.value(QStringLiteral("acked")).toInt());
                }
                if (notification.value(QStringLiteral("html")).toInt() == 1) {
                    n.hints().setValue("use-markup", true) ;
                }
                n.data()->setSource(this);
                SnoreCore::instance().broadcastNotification(n);
            }
            if (latestID != -1) {
                deleteMessages(latestID);
            }
        } else {
            qCWarning(SNORE) << "An error occure" << input;
        }

    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool enabled) {
        if (enabled) {
            connectToService();
        } else {
            disconnectService();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QString message) {
        m_errorMessageLabel->setText(message);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&](QAbstractSocket::SocketError error) {
        qCWarning(SNORE) << error << m_socket->errorString();
        emit loggedInChanged(false);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString & locale) {
        snoreDebug(SNORE_DEBUG) << locale;
        if (locale != "C") {
            QTranslator *translator = new QTranslator(qApp->instance());
            if (translator->load(locale, ":/lang/libsnore/")) {
                snoreDebug(SNORE_INFO) << "Using system locale:" << locale;
                snoreDebug(SNORE_INFO) << qApp->installTranslator(translator);
            } else {
                translator->deleteLater();
                QString fileName = QString(":/lang/libsnore/%1.qm").arg(locale);
                snoreDebug(SNORE_WARNING) << "Failed to load translations for:" << locale << fileName << QFile::exists(fileName) ;
                return false;
            }
        }
        return true;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &key : Utils::allSettingsKeysWithPrefix(
                Utils::normalizeSettingsKey("", type, application), settings, getAllKeys)) {
        cout << "  " << qPrintable(key) << ": " << qPrintable(settings.value(Utils::normalizeSettingsKey(key, type, application)).toString()) << endl;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &t : SnorePlugin::types()) {
        if (t & type) {
            out.unite(s_pluginCache.value(t));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Application & a : SnoreCore::instance().aplications()) {
                slotDeregisterApplication(a);
            }
```

#### AUTO 


```{c}
auto &pluginName
```

#### AUTO 


```{c}
auto func = [](growl_callback_data * data)->void {
        qCDebug(SNORE) << data->id << QString::fromUtf8(data->reason) << QString::fromUtf8(data->data);
        Snore::Notification n = Snore::SnoreCore::instance().getActiveNotificationByID(data->id);
        if (!n.isValid())
        {
            return;
        }
        Snore::Notification::CloseReasons r = Snore::Notification::None;
        std::string reason(data->reason);
        if (reason == "TIMEDOUT")
        {
            r = Snore::Notification::TimedOut;
        } else if (reason == "CLOSED")
        {
            r = Snore::Notification::Dismissed;
        } else if (reason == "CLICK")
        {
            r = Snore::Notification::Activated;
            s_instance->slotNotificationActionInvoked(n);
        }
        s_instance->closeNotification(n, r);
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this,timeout]{
           m_player->stop();
           timeout->deleteLater();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, w]() {
            Notification notification = w->notification();
            closeNotification(notification, Notification::Dismissed);
            slotCloseNotification(notification);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[ & ]() {
            if(reply->isOpen()){
                QImage img(QImage::fromData(reply->readAll(), "PNG"));
                icon = Icon(QPixmap::fromImage(img));
                s_downloadImageCache.insert(url, icon);
                snoreDebug(SNORE_DEBUG) << url << "added to cache.";
                isDownloading.unlock();
            } else {
                snoreDebug(SNORE_DEBUG) << "Download of " << url << "timed out.";

            }
        }
```

#### AUTO 


```{c}
auto it = hint.m_privateData.cbegin();
```

#### LAMBDA EXPRESSION 


```{c}
[&backends, &snore, &messages, this](Notification n) {
            qDebug() << n << "closed";
            qDebug() << backends.size();
            if (backends.empty()) {
                return;
            }
            QString old = snore.primaryNotificationBackend();
            while (!backends.empty() && snore.primaryNotificationBackend() == old) {
                QString p = backends.takeLast();
                snore.setSettingsValue(QStringLiteral("PrimaryBackend"), p, LocalSetting);
                SnoreCorePrivate::instance()->syncSettings();
                if (snore.primaryNotificationBackend() == p) {
                    for (const auto &message : messages) {
                        snore.broadcastNotification(Notification(app, app.defaultAlert(), QStringLiteral("Title"), message, app.icon()));
                    }
                }
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        QFileDialog dialog;
        dialog.setNameFilter(tr("All Audio files").append(QLatin1String("(*.mp3 *.wav *.ogg)")));
        dialog.setFileMode(QFileDialog::ExistingFile);
        dialog.setDirectory(m_lineEditFileName->text());
        if (dialog.exec()) {
            m_lineEditFileName->setText(dialog.selectedFiles().first());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (PluginContainer *info : PluginContainer::pluginCache(type).values()) {
                SnorePlugin *plugin = info->load();
                if (!plugin) {
                    continue;
                }
                switch (info->type()) {
                case SnorePlugin::BACKEND:
                    break;
                case SnorePlugin::SECONDARY_BACKEND:
                case SnorePlugin::FRONTEND:
                case SnorePlugin::PLUGIN: {
                    if (plugin->settingsValue(QLatin1String("Enabled"), LOCAL_SETTING).toBool()) {
                        if (!plugin->initialize()) {
                            snoreDebug(SNORE_WARNING) << "Failed to initialize" << plugin->name();
                            plugin->deinitialize();
                            //info->unload();
                            break;
                        }
                    }
                }
                    break;
                default:
                    snoreDebug(SNORE_WARNING) << "Plugin Cache corrupted\n" << info->file() << info->type();
                    continue;
                }
                snoreDebug(SNORE_DEBUG) << info->name() << "is a" << info->type();
                d->m_pluginNames[info->type()].append(info->name());
                d->m_plugins[info->name()] = plugin;
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (PluginContainer *p : PluginContainer::pluginCache(SnorePlugin::ALL)) {
        if (p->isLoaded()) {
            snoreDebug(SNORE_DEBUG) << "deinitialize" << p->name();
            p->load()->disable();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString & message) {
            m_errorMessageLabel->setText(message);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](PluginSettingsWidget *a,PluginSettingsWidget *b){
       return a->name() < b->name();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[reply]() {
        qCDebug(SNORE) << reply->error();
        qCDebug(SNORE) << reply->readAll();
        reply->close();
        reply->deleteLater();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        qCWarning(SNORE) << "disconnected";
        //TODO: use new style connect once we depend on qt 5.4
        QTimer::singleShot(500, this, SLOT(connectToService()));
    }
```

#### AUTO 


```{c}
auto notify = [&backends, &snore, &message, this](Notification n) {
            qDebug() << n << "closed";
            qDebug() << backends.size();
            if (backends.empty()) {
                return;
            }
            QString old = snore.primaryNotificationBackend();
            while (snore.primaryNotificationBackend() == old) {
                QString p = backends.takeLast();
                snore.setSettingsValue(QStringLiteral("PrimaryBackend"), p, LocalSetting);
                SnoreCorePrivate::instance()->syncSettings();
                if (snore.primaryNotificationBackend() == p) {
                    qDebug() << p;
                    snore.broadcastNotification(Notification(app, app.defaultAlert(), QStringLiteral("Title"), message, app.icon()));
                }
            }
        };
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QByteArray & msg) {
        char c = msg.at(0);
        switch (c) {
        case '#':
            snoreDebug(SNORE_DEBUG) << "still alive";
            break;
        case '!':
            getMessages();
            break;
        case 'R':
            snoreDebug(SNORE_DEBUG) << "need to reconnect";
            m_socket->close();
            m_socket->deleteLater();
            connectToService();
            break;
        case 'E':
            snoreDebug(SNORE_WARNING) << "Connection Error";
            emit error(QLatin1String("Please Loggin to https://pushover.net and reanble your device."));
            emit loggedInChanged(false);
            m_socket->close();
            m_socket->deleteLater();
            break;
        default:
            snoreDebug(SNORE_WARNING) << "unknown message recieved" << msg;
        }
    }
```

#### AUTO 


```{c}
auto *w = new NotifyWidget(i, this);
```

#### AUTO 


```{c}
auto installTranslator = [](const QString & locale) {
        snoreDebug(SNORE_DEBUG) << locale;
        if (locale != QLatin1String("C")) {
            QTranslator *translator = new QTranslator(qApp->instance());
            if (translator->load(locale, QLatin1String(":/lang/libsnore/"))) {
                snoreDebug(SNORE_DEBUG) << "Using system locale:" << locale;
                snoreDebug(SNORE_DEBUG) << qApp->installTranslator(translator);
            } else {
                translator->deleteLater();
                QString fileName = QLatin1String(":/lang/libsnore/") + locale + QLatin1String(".qm");
                snoreDebug(SNORE_DEBUG) << "Failed to load translations for:" << locale << fileName << QFile::exists(fileName) ;
                return false;
            }
        }
        return true;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool enabled) {
        if (enabled) {
            connect(SnoreCorePrivate::instance(), &SnoreCorePrivate::notify, this, &SnoreSecondaryBackend::slotNotify, Qt::QueuedConnection);
            connect(SnoreCorePrivate::instance(), &SnoreCorePrivate::notificationDisplayed, this, &SnoreSecondaryBackend::slotNotificationDisplayed, Qt::QueuedConnection);
        } else {
            disconnect(SnoreCorePrivate::instance(), &SnoreCorePrivate::notify, this, &SnoreSecondaryBackend::slotNotify);
            disconnect(SnoreCorePrivate::instance(), &SnoreCorePrivate::notificationDisplayed, this, &SnoreSecondaryBackend::slotNotificationDisplayed);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&backends, &snore, &messages, this](Notification n) {
            qDebug() << n << "closed";
            qDebug() << backends.size();
            if (backends.empty()) {
                return;
            }
            QString old = snore.primaryNotificationBackend();
            while (!backends.empty() && snore.primaryNotificationBackend() == old) {
                QString p = backends.takeLast();
                snore.setSettingsValue(Snore::Constants::SettingsKeys::PrimaryBackend, p);
                SnoreCorePrivate::instance()->syncSettings();
                if (snore.primaryNotificationBackend() == p) {
                    for (const auto &message : messages) {
                        snore.broadcastNotification(Notification(app, app.defaultAlert(), QStringLiteral("Title"), message, app.icon()));
                    }
                }
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QByteArray & msg) {
        char c = msg.at(0);
        switch (c) {
        case '#':
            snoreDebug(SNORE_DEBUG) << "still alive";
            break;
        case '!':
            getMessages();
            break;
        case 'R':
            snoreDebug(SNORE_DEBUG) << "need to reconnect";
            m_socket->close();
            m_socket->deleteLater();
            connectToService();
            break;
        case 'E':
            snoreDebug(SNORE_WARNING) << "Connection Error";
            emit error(QLatin1String("Please Loggin to https://pushover.net and reanble your device."));
            emit loggedInChanged(false);
            m_socket->close();
            m_socket->deleteLater();
            break;
        default:
            snoreDebug(SNORE_WARNING) << "unknown message received" << msg;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[reply, secret, this]() {
        qCDebug(SNORE) << reply->error();
        QByteArray input = reply->readAll();
        reply->close();
        reply->deleteLater();
        QJsonObject message = QJsonDocument::fromJson(input).object();
        if (message.value(QStringLiteral("status")).toInt() == 1) {
            m_frontend->setSettingsValue(QStringLiteral("Secret"), secret, LocalSetting);
            m_frontend->setSettingsValue(QStringLiteral("DeviceID"), message.value(QStringLiteral("id")).toString(), LocalSetting);;
            connectToService();
        } else {
            qCWarning(SNORE) << "An error occured" << input;
            emit loggedInChanged(Error);
            QStringList errorMessages;
            QJsonObject errors = message.value(QStringLiteral("errors")).toObject();
            foreach (const auto &errorKey, errors.keys()) {
                foreach (const auto &error, errors.value(errorKey).toArray()) {
                    errorMessages << errorKey + QLatin1Char(' ') + error.toString();
                }
            }
            emit error(tr("Failed to login due to errors: %1").arg(errorMessages.join(QStringLiteral(", "))));
        }

    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, w]() {
            Notification notification = w->notification();
            closeNotification(notification, Notification::DISMISSED);
            slotCloseNotification(notification);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[reply, deviceName, this]() {
        qCDebug(SNORE) << reply->error();
        QByteArray input = reply->readAll();
        reply->close();
        reply->deleteLater();

        QJsonObject message = QJsonDocument::fromJson(input).object();

        if (message.value(QStringLiteral("status")).toInt() == 1) {
            registerDevice(message.value(QStringLiteral("secret")).toString(), deviceName);
        } else {
            emit error(tr("Failed to login. Please check your credentials."));
            emit loggedInChanged(Error);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&,box](QAbstractButton *button){
        switch (box->buttonRole(button)) {
        case QDialogButtonBox::AcceptRole:
            m_settings->accept();
            m_settings->setVisible(false);
            break;
        case QDialogButtonBox::ApplyRole:
            m_settings->accept();
            break;
        case QDialogButtonBox::ResetRole:
            m_settings->reset();
            break;
        case QDialogButtonBox::RejectRole:
            m_settings->setVisible(false);
            break;
        default:
            snoreDebug(SNORE_WARNING) << "unhandled role" << button->text() << box->buttonRole(button);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[pushover, this]() {
            m_registerButton->setEnabled(false);
            if (pushover->isLoggedIn() != PushoverClient::LoggedIn) {
                pushover->login(m_emailLineEdit->text(), m_passwordLineEdit->text(), m_deviceLineEdit->text());
            } else {
                pushover->logOut();
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, w](){
                Notification notification = w->notification();
                slotNotificationActionInvoked(notification);
                closeNotification(notification, Notification::ACTIVATED);
                slotCloseNotification(notification);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[p](int, QProcess::ExitStatus) {
        qCDebug(SNORE) << p->readAll();
        p->deleteLater();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](NotifyWidget * w, Snore::Notification notification) {
        w->display(notification);
        notification.hints().setPrivateValue(this, "id", w->id());
        slotNotificationDisplayed(notification);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString & locale) {
        snoreDebug(SNORE_DEBUG) << locale;
        if (locale != QLatin1String("C")) {
            QTranslator *translator = new QTranslator(qApp->instance());
            if (translator->load(locale, QLatin1String(":/lang/libsnore/"))) {
                snoreDebug(SNORE_DEBUG) << "Using system locale:" << locale;
                snoreDebug(SNORE_DEBUG) << qApp->installTranslator(translator);
            } else {
                translator->deleteLater();
                QString fileName = QLatin1String(":/lang/libsnore/") + locale + QLatin1String(".qm");
                snoreDebug(SNORE_DEBUG) << "Failed to load translations for:" << locale << fileName << QFile::exists(fileName) ;
                return false;
            }
        }
        return true;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (PluginContainer *p : PluginContainer::pluginCache(SnorePlugin::ALL)) {
        if (p->isLoaded()) {
            snoreDebug(SNORE_DEBUG) << "deinitialize" << p->name();
            p->load()->deinitialize();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        if (m_queue.isEmpty()) {
            snoreDebug(SNORE_DEBUG) << "queue is empty";
            m_timer->stop();
        } else {
            foreach(NotifyWidget * w, m_widgets) {
                if (w->acquire()) {
                    Notification notification = m_queue.takeFirst();
                    w->display(notification);
                    notification.hints().setPrivateValue(this, "id", w->id());
                    slotNotificationDisplayed(notification);
                    if (m_queue.isEmpty()) {
                        m_timer->stop();
                        return;
                    }
                }
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](){
        if (m_queue.isEmpty()) {
            snoreDebug(SNORE_DEBUG) << "queue is empty";
            m_timer->stop();
        } else {
            foreach(NotifyWidget * w, m_widgets) {
                if (w->acquire()) {
                    Notification notification = m_queue.takeFirst();
                    w->display(notification);
                    notification.hints().setPrivateValue(this, "id", w->id());
                    slotNotificationDisplayed(notification);
                    if (m_queue.isEmpty()) {
                        m_timer->stop();
                        return;
                    }
                }
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        QFileDialog dialog;
        dialog.setNameFilter(tr("All Audio files").append(QLatin1String("(*.mp3 *.wav *.ogg)")));
        dialog.setFileMode(QFileDialog::ExistingFile);
        dialog.setDirectory(m_lineEditFileName->text());
        if (dialog.exec()) {
            QStringList files = dialog.selectedFiles();
            m_lineEditFileName->setText(files.first());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto t : PluginContainer::types()) {
        if (t & type) {
            out.append(d->m_pluginNames.value(t));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto pluginName : m_pluginNames[SnorePlugin::PLUGIN]) {
        syncPluginStatus(pluginName);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[reply, watcher, this](){
        m_supportsRichtext = reply.value().contains(QLatin1String("body-markup"));
        watcher->deleteLater();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[reply, this]() {
        snoreDebug(SNORE_DEBUG) << reply->error();
        QByteArray input = reply->readAll();
        reply->close();
        reply->deleteLater();

        snoreDebug(SNORE_DEBUG) << input;

        QJsonObject message = QJsonDocument::fromJson(input).object();

        int latestID = -1;
        if (message.value(QLatin1String("status")).toInt() == 1) {
            QJsonArray notifications = message.value(QLatin1String("messages")).toArray();
            for (const QJsonValue &v : notifications) {
                QJsonObject notification = v.toObject();

                latestID = qMax(latestID, notification.value(QLatin1String("id")).toInt());

                QString appName = notification.value(QLatin1String("app")).toString();
                Application app = SnoreCore::instance().aplications().value(appName);

                if (!app.isValid()) {
                    Icon icon(Icon::fromWebUrl(QUrl::fromEncoded((QLatin1String("https://api.pushover.net/icons/") +
                                               notification.value(QLatin1String("icon")).toString() +
                                               QLatin1String(".png")).toUtf8().constData())));
                    app = Application(appName, icon);
                    SnoreCore::instance().registerApplication(app);
                }

                Notification n(app, app.defaultAlert(), notification.value(QLatin1String("title")).toString(),
                               notification.value(QLatin1String("message")).toString(),
                               app.icon(), Notification::defaultTimeout(),
                               static_cast<Notification::Prioritys>(notification.value(QLatin1String("priority")).toInt()));
                if (n.priority() == Notification::EMERGENCY) {
                    n.hints().setValue("receipt", notification.value(QLatin1String("receipt")).toString());
                    n.hints().setValue("acked", notification.value(QLatin1String("acked")).toInt());
                }
                if (notification.value(QLatin1String("html")).toInt() == 1) {
                    n.hints().setValue("use-markup", true) ;
                }
                n.data()->setSource(this);
                SnoreCore::instance().broadcastNotification(n);
            }
            if (latestID != -1) {
                deleteMessages(latestID);
            }
        } else {
            snoreDebug(SNORE_WARNING) << "An error occure" << input;
        }

    }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        qCDebug(SNORE) << "connecting";
        m_socket->sendBinaryMessage((QLatin1String("login:") + device() + QLatin1Char(':') + secret() + QLatin1Char('\n')).toUtf8().constData());
        emit loggedInChanged(Error);
        getMessages();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[reply]() {
        snoreDebug(SNORE_DEBUG) << reply->error();
        snoreDebug(SNORE_DEBUG) << reply->readAll();
        reply->close();
        reply->deleteLater();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Application &a : SnoreCore::instance().aplications()) {
                        m_snarl->slotRegisterApplication(a);
                    }
```

#### LAMBDA EXPRESSION 


```{c}
[&](Notification noti) {
            if (!parser.isSet(silent)) {
                QString reason;
                QDebug(&reason) << noti.closeReason();
                cout << qPrintable(reason) << endl;
            }
            if (noti.closeReason() == Notification::CLOSED) {
                if (parser.isSet(_bringProcessToFront)) {
                    bringToFront(parser.value(_bringProcessToFront));
                } else if (parser.isSet(_bringWindowToFront)) {
                    Utils::bringWindowToFront((WId)parser.value(_bringWindowToFront).toULongLong(), true);
                }
            }
            returnCode = noti.closeReason();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool) {
        m_currentlyDisplaying = false;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&, box](QAbstractButton * button) {
        switch (box->buttonRole(button)) {
        case QDialogButtonBox::AcceptRole:
            m_settings->accept();
            m_settings->setVisible(false);
            break;
        case QDialogButtonBox::ApplyRole:
            m_settings->accept();
            break;
        case QDialogButtonBox::ResetRole:
            m_settings->reset();
            break;
        case QDialogButtonBox::RejectRole:
            m_settings->setVisible(false);
            break;
        default:
            qCWarning(SNORE) << "unhandled role" << button->text() << box->buttonRole(button);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&,reply,manager](QNetworkReply::NetworkError code){
                snoreDebug(SNORE_WARNING) << "Error:" << code;
                reply->deleteLater();
                manager->deleteLater();
                m_isDownloading = false;
            }
```

#### LAMBDA EXPRESSION 


```{c}
[](QSettings & settings) {
        return settings.allKeys();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QJsonValue &v : notifications) {
                QJsonObject notification = v.toObject();

                latestID = qMax(latestID, notification.value(QLatin1String("id")).toInt());

                QString appName = notification.value(QLatin1String("app")).toString();
                Application app = SnoreCore::instance().aplications().value(appName);

                if (!app.isValid()) {
                    Icon icon(Icon::fromWebUrl(QUrl::fromEncoded((QLatin1String("https://api.pushover.net/icons/") +
                                               notification.value(QLatin1String("icon")).toString() +
                                               QLatin1String(".png")).toUtf8().constData())));
                    app = Application(appName, icon);
                    SnoreCore::instance().registerApplication(app);
                }

                Notification n(app, app.defaultAlert(), notification.value(QLatin1String("title")).toString(),
                               notification.value(QLatin1String("message")).toString(),
                               app.icon(), Notification::defaultTimeout(),
                               static_cast<Notification::Prioritys>(notification.value(QLatin1String("priority")).toInt()));
                if (n.priority() == Notification::EMERGENCY) {
                    n.hints().setValue("receipt", notification.value(QLatin1String("receipt")).toString());
                    n.hints().setValue("acked", notification.value(QLatin1String("acked")).toInt());
                }
                if (notification.value(QLatin1String("html")).toInt() == 1) {
                    n.hints().setValue("use-markup", true) ;
                }
                n.data()->setSource(this);
                SnoreCore::instance().broadcastNotification(n);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QString message) {
            m_errorMessageLabel->setText(message);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &extention : pluginExtentions()) {
            out << QLatin1String("libsnore_") + typeName + QLatin1String("_*.") + extention;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[reply, secret, this]() {
        qCDebug(SNORE) << reply->error();
        QByteArray input = reply->readAll();
        reply->close();
        reply->deleteLater();
        QJsonObject message = QJsonDocument::fromJson(input).object();
        if (message.value(QStringLiteral("status")).toInt() == 1) {
            m_frontend->setSettingsValue(QStringLiteral("Secret"), secret, LocalSetting);
            m_frontend->setSettingsValue(QStringLiteral("DeviceID"), message.value(QStringLiteral("id")).toString(), LocalSetting);;
            connectToService();
        } else {
            qCWarning(SNORE) << "An error occured" << input;
            emit loggedInChanged(Error);
            QStringList errorMessages;
            QJsonObject errors = message.value(QStringLiteral("errors")).toObject();
            foreach (const auto & errorKey, errors.keys()) {
                auto array = errors.value(errorKey).toArray();
                errorMessages.reserve(array.size());
                foreach (const auto & error, array) {
                    errorMessages << errorKey + QLatin1Char(' ') + error.toString();
                }
            }
            emit error(tr("Failed to login due to errors: %1").arg(errorMessages.join(QStringLiteral(", "))));
        }

    }
```

#### AUTO 


```{c}
auto func = [](growl_callback_data *data)->void{
        snoreDebug(SNORE_DEBUG) << data->id << QString(data->reason) << QString(data->data);
        Notification n = Snore::SnoreCore::instance().activeNotificationById(data->id);
        if (!n.isValid()) {
            return;
        }
        Notification::CloseReasons r = Notification::NONE;
        std::string reason(data->reason);
        if (reason == "TIMEDOUT") {
            r = Notification::TIMED_OUT;
        } else if (reason == "CLOSED") {
            r = Notification::DISMISSED;
        } else if (reason == "CLICK") {
            r = Notification::ACTIVATED;
            SnoreCorePrivate::instance()->notificationActionInvoked(n);
        }
        s_instance->closeNotification(n, r);
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this](QString error) {
        m_errorMessage = error;
    }
```

#### AUTO 


```{c}
auto installTranslator = [](const QString & locale) {
        snoreDebug(SNORE_DEBUG) << locale;
        if (locale != "C") {
            QTranslator *translator = new QTranslator(qApp->instance());
            if (translator->load(locale, ":/lang/libsnore/")) {
                snoreDebug(SNORE_INFO) << "Using system locale:" << locale;
                snoreDebug(SNORE_INFO) << qApp->installTranslator(translator);
            } else {
                translator->deleteLater();
                QString fileName = QString(":/lang/libsnore/%1.qm").arg(locale);
                snoreDebug(SNORE_WARNING) << "Failed to load translations for:" << locale << fileName << QFile::exists(fileName) ;
                return false;
            }
        }
        return true;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[ &, reply, manager](QNetworkReply::NetworkError code) {
                snoreDebug(SNORE_WARNING) << "Error:" << code;
                reply->deleteLater();
                manager->deleteLater();
                m_isDownloading = false;
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (PluginContainer *info : PluginContainer::pluginCache(type).values()) {
                SnorePlugin *plugin = info->load();
                if (!plugin) {
                    continue;
                }
                switch (info->type()) {
                case SnorePlugin::BACKEND:
                    break;
                case SnorePlugin::SECONDARY_BACKEND:
                case SnorePlugin::FRONTEND:
                case SnorePlugin::PLUGIN: {
                    if (plugin->value(QLatin1String("Enabled"), LOCAL_SETTING).toBool()) {
                        if (!plugin->initialize()) {
                            snoreDebug(SNORE_WARNING) << "Failed to initialize" << plugin->name();
                            plugin->deinitialize();
                            //info->unload();
                            break;
                        }
                    }
                }
                    break;
                default:
                    snoreDebug(SNORE_WARNING) << "Plugin Cache corrupted\n" << info->file() << info->type();
                    continue;
                }
                snoreDebug(SNORE_DEBUG) << info->name() << "is a" << info->type();
                d->m_pluginNames[info->type()].append(info->name());
                d->m_plugins[info->name()] = plugin;
            }
```

#### RANGE FOR STATEMENT 


```{c}
for( const QJsonValue &v : notifications) {
                QJsonObject notification = v.toObject();

                latestID = qMax(latestID, notification.value(QLatin1String("id")).toInt());

                QString appName = notification.value(QLatin1String("app")).toString();
                Application app = SnoreCore::instance().aplications().value(appName);

                if (!app.isValid()){
                    Icon icon(QLatin1String("https://api.pushover.net/icons/") +
                                                 notification.value(QLatin1String("icon")).toString() +
                                                 QLatin1String(".png"));
                    app = Application(appName, icon);
                    SnoreCore::instance().registerApplication(app);
                }


                Notification n(app, app.defaultAlert(), notification.value(QLatin1String("title")).toString(),
                               notification.value(QLatin1String("message")).toString(),
                               app.icon(), Notification::defaultTimeout(),
                               static_cast<Notification::Prioritys>(notification.value(QLatin1String("priority")).toInt()));
                if(n.priority() == Notification::EMERGENCY){
                    n.hints().setValue("receipt", notification.value(QLatin1String("receipt")).toString());
                    n.hints().setValue("acked", notification.value(QLatin1String("acked")).toInt());
                }
                if(notification.value(QLatin1String("html")).toInt() == 1) {
                    n.hints().setValue("use-markup", true) ;
                }
                SnoreCore::instance().broadcastNotification(n);
            }
```

#### AUTO 


```{c}
auto addWidgets = [&](QTabWidget *target, QWidget *container, SnorePlugin::PluginTypes type){
        bool enabled = false;
        target->clear();
        if (types & type) {
            for (PluginSettingsWidget *widget : SnoreCore::instance().settingWidgets(type)) {
                target->addTab(widget, widget->name());
                m_tabs.append(widget);
                enabled = true;
            }
        }
        if (enabled) {
            if (ui->tabWidget->indexOf(container) == -1) {
                ui->tabWidget->addTab(container,container->property("TAB_NAME").toString());
            }
        } else {
            int index = ui->tabWidget->indexOf(container);
            container->setProperty("TAB_NAME", ui->tabWidget->tabText(index));
            ui->tabWidget->removeTab(index);
        }
    };
```

#### LAMBDA EXPRESSION 


```{c}
[](growl_callback_data * data)->void {
        snoreDebug(SNORE_DEBUG) << data->id << QString::fromUtf8(data->reason) << QString::fromUtf8(data->data);
        Notification n = Snore::SnoreCore::instance().getActiveNotificationByID(data->id);
        if (!n.isValid())
        {
            return;
        }
        Notification::CloseReasons r = Notification::NONE;
        std::string reason(data->reason);
        if (reason == "TIMEDOUT")
        {
            r = Notification::TIMED_OUT;
        } else if (reason == "CLOSED")
        {
            r = Notification::DISMISSED;
        } else if (reason == "CLICK")
        {
            r = Notification::ACTIVATED;
            s_instance->slotNotificationActionInvoked(n);
        }
        s_instance->closeNotification(n, r);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString & locale) {
        snoreDebug(SNORE_DEBUG) << locale;
        if (locale != "C") {
            QTranslator *translator = new QTranslator(qApp->instance());
            if (translator->load(locale, ":/lang/libsnore/")) {
                snoreDebug(SNORE_DEBUG) << "Using system locale:" << locale;
                snoreDebug(SNORE_DEBUG) << qApp->installTranslator(translator);
            } else {
                translator->deleteLater();
                QString fileName = QString(":/lang/libsnore/%1.qm").arg(locale);
                snoreDebug(SNORE_DEBUG) << "Failed to load translations for:" << locale << fileName << QFile::exists(fileName) ;
                return false;
            }
        }
        return true;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        snoreDebug(SNORE_WARNING) << "disconnected";
        QTimer::singleShot(500, this, &PushoverFrontend::connectToService);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[reply, this]() {
        snoreDebug(SNORE_DEBUG) << reply->error();
        QByteArray input = reply->readAll();
        reply->close();
        reply->deleteLater();

        snoreDebug(SNORE_DEBUG) << input;

        QJsonObject message = QJsonDocument::fromJson(input).object();

        int latestID = -1;
        if (message.value(QLatin1String("status")).toInt() == 1) {
            QJsonArray notifications = message.value(QLatin1String("messages")).toArray();
            for (const QJsonValue &v : notifications) {
                QJsonObject notification = v.toObject();

                latestID = qMax(latestID, notification.value(QLatin1String("id")).toInt());

                QString appName = notification.value(QLatin1String("app")).toString();
                Application app = SnoreCore::instance().aplications().value(appName);

                if (!app.isValid()) {
                    Icon icon(QLatin1String("https://api.pushover.net/icons/") +
                              notification.value(QLatin1String("icon")).toString() +
                              QLatin1String(".png"));
                    app = Application(appName, icon);
                    SnoreCore::instance().registerApplication(app);
                }

                Notification n(app, app.defaultAlert(), notification.value(QLatin1String("title")).toString(),
                               notification.value(QLatin1String("message")).toString(),
                               app.icon(), Notification::defaultTimeout(),
                               static_cast<Notification::Prioritys>(notification.value(QLatin1String("priority")).toInt()));
                if (n.priority() == Notification::EMERGENCY) {
                    n.hints().setValue("receipt", notification.value(QLatin1String("receipt")).toString());
                    n.hints().setValue("acked", notification.value(QLatin1String("acked")).toInt());
                }
                if (notification.value(QLatin1String("html")).toInt() == 1) {
                    n.hints().setValue("use-markup", true) ;
                }
                SnoreCore::instance().broadcastNotification(n);
            }
            if (latestID != -1) {
                deleteMessages(latestID);
            }
        } else {
            snoreDebug(SNORE_WARNING) << "An error occure" << input;
        }

    }
```

#### AUTO 


```{c}
auto display = [this](NotifyWidget *w, Snore::Notification notification){
        w->display(notification);
        notification.hints().setPrivateValue(this, "id", w->id());
        slotNotificationDisplayed(notification);
    };
```

#### RANGE FOR STATEMENT 


```{c}
for(NotifyWidget * w : m_widgets) {
                if (w->acquire()) {
                    Notification notification = m_queue.takeFirst();
                    w->display(notification);
                    notification.hints().setPrivateValue(this, "id", w->id());
                    slotNotificationDisplayed(notification);
                    if (m_queue.isEmpty()) {
                        m_timer->stop();
                        return;
                    }
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[id]() {
        Notification notification = SnoreCore::instance().getActiveNotificationByID(id);
        if (notification.isValid()) {
            snoreDebug(SNORE_DEBUG) << notification;
            SnoreCore::instance().requestCloseNotification(notification, Notification::TIMED_OUT);
        }
    }
```

#### AUTO 


```{c}
auto widget
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QByteArray & msg) {
        char c = msg.at(0);
        switch (c) {
        case '#':
            qCDebug(SNORE) << "still alive";
            break;
        case '!':
            getMessages();
            break;
        case 'R':
            qCDebug(SNORE) << "need to reconnect";
            m_socket->close();
            m_socket->deleteLater();
            connectToService();
            break;
        case 'E':
            qCWarning(SNORE) << "Connection Error";
            emit error(tr("Please login to %1 and reenable your device.").arg(QStringLiteral("https://pushover.net")));
            emit loggedInChanged(Error);
            m_socket->close();
            m_socket->deleteLater();
            break;
        default:
            qCWarning(SNORE) << "unknown message received" << msg;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &pluginName : m_pluginNames[type]) {
            SnorePlugin *plugin = m_plugins.value(pluginName);
            bool enable = m_plugins[pluginName]->value(QLatin1String("Enabled"), LOCAL_SETTING).toBool();
            if (!plugin->isInitialized() && enable) {
                plugin->initialize();
            } else if (plugin->isInitialized() && !enable) {
                plugin->deinitialize();
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (NotifyWidget *w : m_widgets) {
                if (w->acquire(m_queue.first().timeout())) {
                    Notification notification = m_queue.takeFirst();
                    w->display(notification);
                    notification.hints().setPrivateValue(this, "id", w->id());
                    slotNotificationDisplayed(notification);
                    if (m_queue.isEmpty()) {
                        m_timer->stop();
                        return;
                    }
                }
            }
```

#### AUTO 


```{c}
auto notify = [&backends, &snore, &messages, this](Notification n) {
            qDebug() << n << "closed";
            qDebug() << backends.size();
            if (backends.empty()) {
                return;
            }
            QString old = snore.primaryNotificationBackend();
            while (!backends.empty() && snore.primaryNotificationBackend() == old) {
                QString p = backends.takeLast();
                snore.setSettingsValue(Snore::Constants::SettingsKeys::PrimaryBackend, p);
                SnoreCorePrivate::instance()->syncSettings();
                if (snore.primaryNotificationBackend() == p) {
                    for (const auto &message : messages) {
                        snore.broadcastNotification(Notification(app, app.defaultAlert(), QStringLiteral("Title"), message, app.icon()));
                    }
                }
            }
        };
```

#### AUTO 


```{c}
auto func = [](growl_callback_data * data)->void {
        snoreDebug(SNORE_DEBUG) << data->id << QString(data->reason) << QString(data->data);
        Notification n = Snore::SnoreCore::instance().getActiveNotificationByID(data->id);
        if (!n.isValid())
        {
            return;
        }
        Notification::CloseReasons r = Notification::NONE;
        std::string reason(data->reason);
        if (reason == "TIMEDOUT")
        {
            r = Notification::TIMED_OUT;
        } else if (reason == "CLOSED")
        {
            r = Notification::DISMISSED;
        } else if (reason == "CLICK")
        {
            r = Notification::ACTIVATED;
            s_instance->slotNotificationActionInvoked(n);
        }
        s_instance->closeNotification(n, r);
    };
```

#### LAMBDA EXPRESSION 


```{c}
[&](qint64 bytesReceived, qint64 bytesTotal) {
            qCDebug(SNORE) << "Downloading:" << url << bytesReceived / double(bytesTotal) * 100.0 << "%";
        }
```

#### AUTO 


```{c}
const auto &message
```

#### AUTO 


```{c}
auto notify = [&backends, &snore, &message, this](Notification n) {
            qDebug() << n << "closed";
            qDebug() << backends.size();
            if (backends.empty()) {
                return;
            }
            QString old = snore.primaryNotificationBackend();
            while (snore.primaryNotificationBackend() == old) {
                QString p = backends.takeLast();
                snore.setSettingsValue(QLatin1String("PrimaryBackend"), p, LOCAL_SETTING);
                SnoreCorePrivate::instance()->syncSettings();
                if (snore.primaryNotificationBackend() == p) {
                    qDebug() << p;
                    snore.broadcastNotification(Notification(app, app.defaultAlert(), QLatin1String("Title"), message, app.icon()));
                }
            }
        };
```

#### LAMBDA EXPRESSION 


```{c}
[pushover, this]() {
        m_registerButton->setEnabled(false);
        if (!pushover->isLoggedIn()) {
            pushover->login(m_emailLineEdit->text(), m_passwordLineEdit->text(), m_deviceLineEdit->text());
        } else {
            pushover->logOut();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto p : d->m_plugins) {
//TODO: mem leak?
        PluginSettingsWidget *widget = p->settingsWidget();
        if (widget) {
            list.append(widget);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        qCDebug(SNORE) << "connecting";
        m_socket->sendBinaryMessage((QLatin1String("login:") + device() + QLatin1Char(':') + secret() + QLatin1Char('\n')).toUtf8().constData());
        emit loggedInChanged(true);
        getMessages();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (SnorePlugin::PluginTypes type : SnorePlugin::types()) {
        if (type != SnorePlugin::ALL && types & type) {
            for (PluginContainer *info : PluginContainer::pluginCache(type).values()) {
                SnorePlugin *plugin = info->load();
                if (!plugin) {
                    continue;
                }
                switch (info->type()) {
                case SnorePlugin::BACKEND:
                    break;
                case SnorePlugin::SECONDARY_BACKEND:
                case SnorePlugin::FRONTEND:
                case SnorePlugin::PLUGIN: {
                    if (plugin->value(QLatin1String("Enabled"), LOCAL_SETTING).toBool()) {
                        if (!plugin->initialize()) {
                            snoreDebug(SNORE_WARNING) << "Failed to initialize" << plugin->name();
                            plugin->deinitialize();
                            //info->unload();
                            break;
                        }
                    }
                }
                    break;
                default:
                    snoreDebug(SNORE_WARNING) << "Plugin Cache corrupted\n" << info->file() << info->type();
                    continue;
                }
                snoreDebug(SNORE_DEBUG) << info->name() << "is a" << info->type();
                d->m_pluginNames[info->type()].append(info->name());
                d->m_plugins[info->name()] = plugin;
            }
            if (d->m_pluginNames.contains(type)) {
                qSort(d->m_pluginNames[type]);
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](){
        snoreDebug(SNORE_DEBUG) << "disconnected";
    }
```

#### AUTO 


```{c}
auto con = connect(&snore, &SnoreCore::notificationClosed, notify);
```

#### LAMBDA EXPRESSION 


```{c}
[this, p, noti](QProcess::ProcessError) {
        setErrorString(name() + p->errorString());
        snoreDebug(SNORE_DEBUG) << p->readAll();
        if (noti.isValid()) {
            closeNotification(noti, Notification::NONE);
        }
        p->deleteLater();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        QFileDialog dialog;
        dialog.setNameFilter(tr("All Audio files").append("(*.mp3 *.wav *.ogg)"));
        dialog.setFileMode(QFileDialog::ExistingFile);
        dialog.setDirectory(m_lineEdit->text());
        if (dialog.exec()) {
            m_lineEdit->setText(dialog.selectedFiles().first());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Application &a : SnoreCore::instance().aplications()) {
            slotDeregisterApplication(a);
        }
```

#### AUTO 


```{c}
auto name
```

#### AUTO 


```{c}
auto installTranslator = [](const QString &locale)
    {
        snoreDebug(SNORE_DEBUG) << locale;
        if(locale != "C") {
            QTranslator* translator = new QTranslator( qApp->instance() );
            if ( translator->load(locale, ":/lang/libsnore/") )
            {
                snoreDebug(SNORE_INFO) << "Using system locale:" << locale;
                snoreDebug(SNORE_INFO) << qApp->installTranslator( translator );
            }
            else
            {
                translator->deleteLater();
                QString fileName = QString(":/lang/libsnore/%1.qm").arg(locale);
                snoreDebug(SNORE_WARNING)<< "Failed to load translations for:" << locale << fileName << QFile::exists(fileName) ;
                return false;
            }
        }
        return true;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[reply, secret, this]() {
        snoreDebug(SNORE_DEBUG) << reply->error();
        QByteArray input = reply->readAll();
        reply->close();
        reply->deleteLater();
        QJsonObject message = QJsonDocument::fromJson(input).object();
        if (message.value(QLatin1String("status")).toInt() == 1) {
            setSettingsValue(QLatin1String("Secret"), secret, LOCAL_SETTING);
            setSettingsValue(QLatin1String("DeviceID"), message.value(QLatin1String("id")).toString(), LOCAL_SETTING);;
            connectToService();
        } else {
            snoreDebug(SNORE_WARNING) << "An error occure" << input;
            emit loggedInChanged(false);
            emit error(message.value(QLatin1String("error")).toString());
        }

    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, w]() {
            ::Snore::Notification notification = w->notification();
            closeNotification(notification, ::Snore::Notification::Dismissed);
            slotCloseNotification(notification);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](QSettings & settings) {
        return settings.childGroups();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto type : types) {
        for (auto &pluginName : m_pluginNames[type]) {
            auto key = qMakePair(type, pluginName);
            SnorePlugin *plugin = m_plugins.value(key);
            bool enable = m_plugins[key]->settingsValue(QLatin1String("Enabled"), LOCAL_SETTING).toBool();
            plugin->setEnabled(enable);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto type : types) {
        for (auto &pluginName : m_pluginNames[type]) {
            SnorePlugin *plugin = m_plugins.value(pluginName);
            bool enable = m_plugins[pluginName]->settingsValue(QLatin1String("Enabled"), LOCAL_SETTING).toBool();
            if (!plugin->isInitialized() && enable) {
                plugin->initialize();
            } else if (plugin->isInitialized() && !enable) {
                plugin->deinitialize();
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &pluginName : m_pluginNames[type]) {
            auto key = qMakePair(type, pluginName);
            SnorePlugin *plugin = m_plugins.value(key);
            bool enable = m_plugins[key]->settingsValue(QLatin1String("Enabled"), LOCAL_SETTING).toBool();
            plugin->setEnabled(enable);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&](qint64 bytesReceived, qint64 bytesTotal) {
            snoreDebug(SNORE_DEBUG) << "Downloading:" << url << bytesReceived / double(bytesTotal) * 100.0 << "%";
        }
```

#### AUTO 


```{c}
auto addWidgets = [&](QTabWidget * target, QWidget * container, SnorePlugin::PluginTypes type) {
        bool enabled = false;
        target->clear();
        if (types & type) {
            foreach(PluginSettingsWidget * widget, SnoreCore::instance().settingWidgets(type)) {
                target->addTab(widget, widget->name());
                m_tabs.append(widget);
                enabled = true;
            }
        }
        if (enabled) {
            if (ui->tabWidget->indexOf(container) == -1) {
                ui->tabWidget->addTab(container, container->property("TAB_NAME").toString());
            }
        } else {
            int index = ui->tabWidget->indexOf(container);
            container->setProperty("TAB_NAME", ui->tabWidget->tabText(index));
            ui->tabWidget->removeTab(index);
        }
    };
```

#### LAMBDA EXPRESSION 


```{c}
[](growl_callback_data *data)->void{
        snoreDebug(SNORE_DEBUG) << data->id << QString(data->reason) << QString(data->data);
        Notification n = Snore::SnoreCore::instance().activeNotificationById(data->id);
        if (!n.isValid()) {
            return;
        }
        Notification::CloseReasons r = Notification::NONE;
        std::string reason(data->reason);
        if (reason == "TIMEDOUT") {
            r = Notification::TIMED_OUT;
        } else if (reason == "CLOSED") {
            r = Notification::DISMISSED;
        } else if (reason == "CLICK") {
            r = Notification::ACTIVATED;
            SnoreCorePrivate::instance()->notificationActionInvoked(n);
        }
        s_instance->closeNotification(n, r);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[ & ](QNetworkReply::NetworkError code) {
            snoreDebug(SNORE_WARNING) << "Error downloading" << url << ":" << code;
            isDownloading.unlock();
        }
```

#### AUTO 


```{c}
auto getAllKeys = [](QSettings & settings) {
        return settings.allKeys();
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool enabled) {
        if (enabled) {
            m_client->connectToService();
        } else {
            m_client->disconnectService();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[reply](){
        snoreDebug(SNORE_DEBUG) << reply->readAll();
        reply->close();
        reply->deleteLater();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        if (m_queue.isEmpty()) {
            snoreDebug(SNORE_DEBUG) << "queue is empty";
            m_timer->stop();
        } else {
            for(NotifyWidget * w : m_widgets) {
                if (w->acquire()) {
                    Notification notification = m_queue.takeFirst();
                    w->display(notification);
                    notification.hints().setPrivateValue(this, "id", w->id());
                    slotNotificationDisplayed(notification);
                    if (m_queue.isEmpty()) {
                        m_timer->stop();
                        return;
                    }
                }
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto list : s_pluginCache) {
        foreach (PluginContainer *p, list.values()) {
            delete p;
        }
        list.clear();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (PluginContainer * p : PluginContainer::pluginCache(SnorePlugin::All)) {
        if (p->isLoaded()) {
            qCDebug(SNORE) << "deinitialize" << p->name();
            p->load()->disable();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[ &, reply, manager]() {
                m_img = QImage::fromData(reply->readAll(), "PNG");
                m_img.save(m_localUrl, "PNG");
                s_localImageCache.insert(m_localUrl);
                snoreDebug(SNORE_DEBUG) << m_localUrl << "added to cache";
                reply->close();
                reply->deleteLater();
                manager->deleteLater();
                m_isDownloading = false;
            }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString &extention : pluginExtentions() ) {
            out << QLatin1String ( "libsnore_*." ) + extention;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](growl_callback_data *data)->void{
        snoreDebug(SNORE_DEBUG) << data->id << QString(data->reason) << QString(data->data);
        Notification n = Snore::SnoreCore::instance().getActiveNotificationByID(data->id);
        if (!n.isValid()) {
            return;
        }
        Notification::CloseReasons r = Notification::NONE;
        std::string reason(data->reason);
        if (reason == "TIMEDOUT") {
            r = Notification::TIMED_OUT;
        } else if (reason == "CLOSED") {
            r = Notification::DISMISSED;
        } else if (reason == "CLICK") {
            r = Notification::ACTIVATED;
            s_instance->slotNotificationActionInvoked(n);
        }
        s_instance->closeNotification(n, r);
    }
```

#### AUTO 


```{c}
auto addWidgets = [&](QTabWidget * target, QWidget * container, SnorePlugin::PluginTypes type) {
        bool enabled = false;
        target->clear();
        if (types & type) {
            foreach (PluginSettingsWidget *widget, Settings::settingWidgets(type)) {
                target->addTab(widget, widget->name());
                m_tabs.append(widget);
                enabled = true;
            }
        }
        if (enabled) {
            if (ui->tabWidget->indexOf(container) == -1) {
                ui->tabWidget->addTab(container, container->property("TAB_NAME").toString());
            }
        } else {
            int index = ui->tabWidget->indexOf(container);
            container->setProperty("TAB_NAME", ui->tabWidget->tabText(index));
            ui->tabWidget->removeTab(index);
        }
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const Application &a : SnoreCore::instance().aplications()) {
                slotDeregisterApplication(a);
            }
```

#### AUTO 


```{c}
auto func = [](growl_callback_data * data)->void {
        snoreDebug(SNORE_DEBUG) << data->id << QString::fromUtf8(data->reason) << QString::fromUtf8(data->data);
        Notification n = Snore::SnoreCore::instance().getActiveNotificationByID(data->id);
        if (!n.isValid())
        {
            return;
        }
        Notification::CloseReasons r = Notification::NONE;
        std::string reason(data->reason);
        if (reason == "TIMEDOUT")
        {
            r = Notification::TIMED_OUT;
        } else if (reason == "CLOSED")
        {
            r = Notification::DISMISSED;
        } else if (reason == "CLICK")
        {
            r = Notification::ACTIVATED;
            s_instance->slotNotificationActionInvoked(n);
        }
        s_instance->closeNotification(n, r);
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const Application &a : SnoreCore::instance().aplications()) {
                    m_snarl->slotRegisterApplication(a);
                }
```

#### LAMBDA EXPRESSION 


```{c}
[reply, deviceName, this]() {
        snoreDebug(SNORE_DEBUG) << reply->error();
        QByteArray input = reply->readAll();
        reply->close();
        reply->deleteLater();

        QJsonObject message = QJsonDocument::fromJson(input).object();

        if (message.value(QLatin1String("status")).toInt() == 1) {
            registerDevice(message.value(QLatin1String("secret")).toString(), deviceName);
        } else {
            snoreDebug(SNORE_WARNING) << "An error occure" << input;
            emit loggedInChanged(false);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&,box](QAbstractButton *button){
        switch (box->buttonRole(button)) {
        case QDialogButtonBox::AcceptRole:
            m_settings->accept();
            qApp->quit();
            break;
        case QDialogButtonBox::ApplyRole:
            m_settings->accept();
            break;
        case QDialogButtonBox::ResetRole:
            m_settings->reset();
            break;
        case QDialogButtonBox::RejectRole:
            qApp->quit();
            break;
        default:
            snoreDebug(SNORE_WARNING) << "unhandled role" << button->text() << box->buttonRole(button);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&backends, &snore, &message, this](Notification n) {
            qDebug() << n << "closed";
            qDebug() << backends.size();
            if (backends.empty()) {
                return;
            }
            QString old = snore.primaryNotificationBackend();
            while (snore.primaryNotificationBackend() == old) {
                QString p = backends.takeLast();
                snore.setSettingsValue(QStringLiteral("PrimaryBackend"), p, LocalSetting);
                SnoreCorePrivate::instance()->syncSettings();
                if (snore.primaryNotificationBackend() == p) {
                    qDebug() << p;
                    snore.broadcastNotification(Notification(app, app.defaultAlert(), QStringLiteral("Title"), message, app.icon()));
                }
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](QMediaPlayer::State state) {
        qCDebug(SNORE) << "Player: " << state;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[reply, secret, this]() {
        qCDebug(SNORE) << reply->error();
        QByteArray input = reply->readAll();
        reply->close();
        reply->deleteLater();
        QJsonObject message = QJsonDocument::fromJson(input).object();
        if (message.value(QStringLiteral("status")).toInt() == 1) {
            setSettingsValue(QStringLiteral("Secret"), secret, LocalSetting);
            setSettingsValue(QStringLiteral("DeviceID"), message.value(QStringLiteral("id")).toString(), LocalSetting);;
            connectToService();
        } else {
            qCWarning(SNORE) << "An error occure" << input;
            emit loggedInChanged(false);
            emit error(message.value(QStringLiteral("error")).toString());
        }

    }
```

#### LAMBDA EXPRESSION 


```{c}
[id](){
        Notification notification = SnoreCore::instance().getActiveNotificationByID(id);
        if(notification.isValid()){
            snoreDebug(SNORE_DEBUG) << notification;
            SnoreCore::instance().requestCloseNotification(notification, Notification::TIMED_OUT);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&backends, &snore, &message, this](Notification n) {
            qDebug() << n << "closed";
            qDebug() << backends.size();
            if (backends.empty()) {
                return;
            }
            QString old = snore.primaryNotificationBackend();
            while (snore.primaryNotificationBackend() == old) {
                QString p = backends.takeLast();
                snore.setSettingsValue(QStringLiteral("PrimaryBackend"), p, LOCAL_SETTING);
                SnoreCorePrivate::instance()->syncSettings();
                if (snore.primaryNotificationBackend() == p) {
                    qDebug() << p;
                    snore.broadcastNotification(Notification(app, app.defaultAlert(), QStringLiteral("Title"), message, app.icon()));
                }
            }
        }
```

#### AUTO 


```{c}
auto syncPluginStatus = [&](const QString & pluginName) {
        SnorePlugin *plugin = m_plugins.value(pluginName);
        bool enable = m_plugins[pluginName]->value("Enabled", LOCAL_SETTING).toBool();
        if (!plugin->isInitialized() && enable) {
            plugin->initialize();
        } else if (plugin->isInitialized() && !enable) {
            plugin->deinitialize();
        }
    };
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QByteArray &msg){
        char c = msg.at(0);
        switch(c){
        case '#':
            snoreDebug(SNORE_DEBUG) << "still alive";
            break;
        case '!':
            getMessages();
            break;
        case 'R':
            snoreDebug(SNORE_DEBUG) << "need to reconnect";
            m_socket->close();
            m_socket->deleteLater();
            connectToService();
            break;
        case 'E':
            snoreDebug(SNORE_DEBUG) << "Connection Error";
            setValue(QLatin1String("Registered"), false, LOCAL_SETTING);
            m_socket->close();
            m_socket->deleteLater();
            break;
        default:
            snoreDebug(SNORE_WARNING) << "unknown message recieved" << msg;
        }
    }
```

#### AUTO 


```{c}
auto it = hint.m_data.cbegin();
```

#### LAMBDA EXPRESSION 


```{c}
[reply, secret, this]() {
                snoreDebug(SNORE_DEBUG) << reply->error();
                QByteArray input = reply->readAll();
                reply->close();
                reply->deleteLater();


                QJsonObject message = QJsonDocument::fromJson(input).object();


                if(message.value(QLatin1String("status")).toInt() == 1) {
                    setValue(QLatin1String("Secret"), secret, LOCAL_SETTING);
                    setValue(QLatin1String("DeviceID"), message.value(QLatin1String("id")).toString(), LOCAL_SETTING);
                    setValue(QLatin1String("Registered"), true, LOCAL_SETTING);
                    connectToService();
                } else {
                    snoreDebug(SNORE_WARNING) << "An error occure" << input;
                }

            }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto type : types) {
        for (auto &pluginName : m_pluginNames[type]) {
            SnorePlugin *plugin = m_plugins.value(pluginName);
            bool enable = m_plugins[pluginName]->value("Enabled", LOCAL_SETTING).toBool();
            if (!plugin->isInitialized() && enable) {
                plugin->initialize();
            } else if (plugin->isInitialized() && !enable) {
                plugin->deinitialize();
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[]() {
        return SnoreCore::instance().settingsValue(QLatin1String("Silent"), LOCAL_SETTING);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[reply, this]() {
        qCDebug(SNORE) << reply->error();
        QByteArray input = reply->readAll();
        reply->close();
        reply->deleteLater();

        qCDebug(SNORE) << input;

        QJsonObject message = QJsonDocument::fromJson(input).object();

        int latestID = -1;
        if (message.value(QStringLiteral("status")).toInt() == 1) {
            QJsonArray notifications = message.value(QStringLiteral("messages")).toArray();
            foreach(const QJsonValue & v, notifications) {
                QJsonObject notification = v.toObject();

                latestID = qMax(latestID, notification.value(QStringLiteral("id")).toInt());

                QString appName = notification.value(QStringLiteral("app")).toString();
                Application app = SnoreCore::instance().aplications().value(appName);

                if (!app.isValid()) {
                    Icon icon(Icon::fromWebUrl(QUrl::fromEncoded((QLatin1String("https://api.pushover.net/icons/") +
                                               notification.value(QStringLiteral("icon")).toString() +
                                               QLatin1String(".png")).toUtf8().constData())));
                    app = Application(appName, icon);
                    SnoreCore::instance().registerApplication(app);
                }

                Notification n(app, app.defaultAlert(), notification.value(QStringLiteral("title")).toString(),
                               notification.value(QStringLiteral("message")).toString(),
                               app.icon(), Notification::defaultTimeout(),
                               static_cast<Notification::Prioritys>(notification.value(QStringLiteral("priority")).toInt()));
                if (n.priority() == Notification::Emergency) {
                    n.hints().setValue("receipt", notification.value(QStringLiteral("receipt")).toString());
                    n.hints().setValue("acked", notification.value(QStringLiteral("acked")).toInt());
                }
                if (notification.value(QStringLiteral("html")).toInt() == 1) {
                    n.hints().setValue("use-markup", true) ;
                }
                n.data()->setSource(m_frontend);
                SnoreCore::instance().broadcastNotification(n);
            }
            if (latestID != -1) {
                deleteMessages(latestID);
            }
        } else {
            qCWarning(SNORE) << "An error occured" << input;
        }

    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, notification](int code) {
        Snore::Notification::CloseReasons reason = Snore::Notification::None;

        switch (code) {
        case 0:
            reason = Snore::Notification::Activated;
            slotNotificationActionInvoked(notification);
            break;
        case 1:
            //hidden;
            break;
        case 2:
            reason = Snore::Notification::Dismissed;
            break;
        case 3:
            reason = Snore::Notification::TimedOut;
            break;
        case -1:
            //failed
            qCWarning(SNORE) << "SnoreToast failed to display " << notification;
            break;
        }

        closeNotification(notification, reason);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QTextToSpeech::State state) {
        qCDebug(SNORE) << state;
        if (state == QTextToSpeech::BackendError) {
            setErrorString(tr("System Backend Error"));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto w : m_widgets) {
        w->deleteLater();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto list : s_pluginCache) {
        foreach(PluginContainer * p, list.values()) {
            delete p;
        }
        list.clear();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&](Notification noti) {
            if (!parser.isSet(silent)) {
                QString reason;
                QDebug(&reason) << noti.closeReason();
                cout << qPrintable(reason) << endl;
            }
            if(noti.closeReason() == Notification::CLOSED  && parser.isSet(_bringToFront)) {
                bringToFront(parser.value(_bringToFront), noti);
            }
            returnCode = noti.closeReason();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Application &a : SnoreCore::instance().aplications()) {
                slotRegisterApplication(a);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[&](QTabWidget * target, QWidget * container, SnorePlugin::PluginTypes type) {
        bool enabled = false;
        target->clear();
        if (types & type) {
            foreach(PluginSettingsWidget * widget, SnoreCore::instance().settingWidgets(type)) {
                target->addTab(widget, widget->name());
                m_tabs.append(widget);
                enabled = true;
            }
        }
        if (enabled) {
            if (ui->tabWidget->indexOf(container) == -1) {
                ui->tabWidget->addTab(container, container->property("TAB_NAME").toString());
            }
        } else {
            int index = ui->tabWidget->indexOf(container);
            container->setProperty("TAB_NAME", ui->tabWidget->tabText(index));
            ui->tabWidget->removeTab(index);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto w : m_tabs) {
        w->saveSettings();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&](qint64 bytesReceived, qint64 bytesTotal) {
                snoreDebug(SNORE_DEBUG) << "Downloading:" << m_localUrl << bytesReceived / double(bytesTotal) * 100.0 << "%";
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString & error) {
        ui->errorLabel->setVisible(true);
        ui->errorLineEdit->setVisible(true);
        ui->errorLineEdit->setText(error);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        snoreDebug(SNORE_WARNING) << "disconnected";
        //TODO: use new style connect once we depend on qt 5.4
        QTimer::singleShot(500, this, SLOT(PushoverFrontend::connectToService()));
    }
```

#### AUTO 


```{c}
auto installTranslator = [](const QString & locale) {
        snoreDebug(SNORE_DEBUG) << locale;
        if (locale != "C") {
            QTranslator *translator = new QTranslator(qApp->instance());
            if (translator->load(locale, ":/lang/libsnore/")) {
                snoreDebug(SNORE_DEBUG) << "Using system locale:" << locale;
                snoreDebug(SNORE_DEBUG) << qApp->installTranslator(translator);
            } else {
                translator->deleteLater();
                QString fileName = QString(":/lang/libsnore/%1.qm").arg(locale);
                snoreDebug(SNORE_DEBUG) << "Failed to load translations for:" << locale << fileName << QFile::exists(fileName) ;
                return false;
            }
        }
        return true;
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const QJsonValue &v : notifications) {
                QJsonObject notification = v.toObject();

                latestID = qMax(latestID, notification.value(QLatin1String("id")).toInt());

                QString appName = notification.value(QLatin1String("app")).toString();
                Application app = SnoreCore::instance().aplications().value(appName);

                if (!app.isValid()) {
                    Icon icon(QLatin1String("https://api.pushover.net/icons/") +
                              notification.value(QLatin1String("icon")).toString() +
                              QLatin1String(".png"));
                    app = Application(appName, icon);
                    SnoreCore::instance().registerApplication(app);
                }

                Notification n(app, app.defaultAlert(), notification.value(QLatin1String("title")).toString(),
                               notification.value(QLatin1String("message")).toString(),
                               app.icon(), Notification::defaultTimeout(),
                               static_cast<Notification::Prioritys>(notification.value(QLatin1String("priority")).toInt()));
                if (n.priority() == Notification::EMERGENCY) {
                    n.hints().setValue("receipt", notification.value(QLatin1String("receipt")).toString());
                    n.hints().setValue("acked", notification.value(QLatin1String("acked")).toInt());
                }
                if (notification.value(QLatin1String("html")).toInt() == 1) {
                    n.hints().setValue("use-markup", true) ;
                }
                n.data()->setSource(this);
                SnoreCore::instance().broadcastNotification(n);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool enabled) {
        if (enabled) {
            m_adaptor = new  NotificationsAdaptor(this);
            QDBusConnection dbus = QDBusConnection::sessionBus();
            if (dbus.registerService(QStringLiteral("org.freedesktop.Notifications"))) {
                if (!dbus.registerObject(QStringLiteral("/org/freedesktop/Notifications"), this)) {
                    setErrorString(tr("Failed to register dbus object."));
                }
            } else {
                setErrorString(tr("Failed to register dbus service."));
            }
        } else {
            QDBusConnection dbus = QDBusConnection::sessionBus();
            dbus.unregisterService(QStringLiteral("org.freedesktop.Notifications"));
            dbus.unregisterObject(QStringLiteral("/org/freedesktop/Notifications"));
            m_adaptor->deleteLater();
            m_adaptor = nullptr;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&](Notification noti) {
            if (!parser.isSet(silent)) {
                QString reason;
                QDebug(&reason) << noti.closeReason();
                cout << qPrintable(reason) << endl;
            }
            if (noti.closeReason() == Notification::Closed) {
                if (parser.isSet(_bringProcessToFront)) {
                    bringToFront(parser.value(_bringProcessToFront));
                } else if (parser.isSet(_bringWindowToFront)) {
                    Utils::bringWindowToFront((WId)parser.value(_bringWindowToFront).toULongLong(), true);
                }
            }
            returnCode = noti.closeReason();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, b](const QString&) {
            slotInitPrimaryNotificationBackend();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto list : s_pluginCache) {
        foreach(PluginContainer * p, list.values()) {
            delete p;
        }
        list.clear();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        if (m_queue.isEmpty()) {
            snoreDebug(SNORE_DEBUG) << "queue is empty";
            m_timer->stop();
        } else {
            for (NotifyWidget *w : m_widgets) {
                if (w->acquire()) {
                    Notification notification = m_queue.takeFirst();
                    w->display(notification);
                    notification.hints().setPrivateValue(this, "id", w->id());
                    slotNotificationDisplayed(notification);
                    if (m_queue.isEmpty()) {
                        m_timer->stop();
                        return;
                    }
                }
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[reply, deviceName, this]() {
        snoreDebug(SNORE_DEBUG) << reply->error();
        QByteArray input = reply->readAll();
        reply->close();
        reply->deleteLater();

        QJsonObject message = QJsonDocument::fromJson(input).object();

        if (message.value(QStringLiteral("status")).toInt() == 1) {
            registerDevice(message.value(QStringLiteral("secret")).toString(), deviceName);
        } else {
            snoreDebug(SNORE_WARNING) << "An error occure" << input;
            emit loggedInChanged(false);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](QMediaPlayer::State state) {
        snoreDebug(SNORE_DEBUG) << "Player: " << state;
    }
```

#### AUTO 


```{c}
auto list
```

#### RANGE FOR STATEMENT 


```{c}
for (auto widget : m_tabs) {
        widget->loadSettings();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[reply, secret, this]() {
        qCDebug(SNORE) << reply->error();
        QByteArray input = reply->readAll();
        reply->close();
        reply->deleteLater();
        QJsonObject message = QJsonDocument::fromJson(input).object();
        if (message.value(QStringLiteral("status")).toInt() == 1) {
            m_frontend->setSettingsValue(PushoverConstants::Secret, secret);
            m_frontend->setSettingsValue(PushoverConstants::DeviceID, message.value(QStringLiteral("id")).toString());
            connectToService();
        } else {
            qCWarning(SNORE) << "An error occured" << input;
            emit loggedInChanged(Error);
            QStringList errorMessages;
            QJsonObject errors = message.value(QStringLiteral("errors")).toObject();
            foreach(const auto & errorKey, errors.keys()) {
                auto array = errors.value(errorKey).toArray();
                errorMessages.reserve(array.size());
                foreach(const auto & error, array) {
                    errorMessages << errorKey + QLatin1Char(' ') + error.toString();
                }
            }
            emit error(tr("Failed to login due to errors: %1").arg(errorMessages.join(QStringLiteral(", "))));
        }

    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto pluginName : m_pluginNames[SnorePlugin::SECONDARY_BACKEND]) {
        syncPluginStatus(pluginName);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[reply, this]() {
        qCDebug(SNORE) << reply->error();
        QByteArray input = reply->readAll();
        reply->close();
        reply->deleteLater();

        qCDebug(SNORE) << input;

        QJsonObject message = QJsonDocument::fromJson(input).object();

        int latestID = -1;
        if (message.value(QStringLiteral("status")).toInt() == 1) {
            QJsonArray notifications = message.value(QStringLiteral("messages")).toArray();
            foreach (const QJsonValue & v, notifications) {
                QJsonObject notification = v.toObject();

                latestID = qMax(latestID, notification.value(QStringLiteral("id")).toInt());

                QString appName = notification.value(QStringLiteral("app")).toString();
                Application app = SnoreCore::instance().aplications().value(appName);

                if (!app.isValid()) {
                    Icon icon(Icon::fromWebUrl(QUrl::fromEncoded((QLatin1String("https://api.pushover.net/icons/") +
                                               notification.value(QStringLiteral("icon")).toString() +
                                               QLatin1String(".png")).toUtf8().constData())));
                    app = Application(appName, icon);
                    SnoreCore::instance().registerApplication(app);
                }

                Notification n(app, app.defaultAlert(), notification.value(QStringLiteral("title")).toString(),
                               notification.value(QStringLiteral("message")).toString(),
                               app.icon(), Notification::defaultTimeout(),
                               static_cast<Notification::Prioritys>(notification.value(QStringLiteral("priority")).toInt()));
                if (n.priority() == Notification::Emergency) {
                    n.hints().setValue("receipt", notification.value(QStringLiteral("receipt")).toString());
                    n.hints().setValue("acked", notification.value(QStringLiteral("acked")).toInt());
                }
                if (notification.value(QStringLiteral("html")).toInt() == 1) {
                    n.hints().setValue("use-markup", true) ;
                }
                n.data()->setSource(m_frontend);
                SnoreCore::instance().broadcastNotification(n);
            }
            if (latestID != -1) {
                deleteMessages(latestID);
            }
        } else {
            qCWarning(SNORE) << "An error occured" << input;
        }

    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto t : SnorePlugin::types()) {
        if (t & type) {
            out.append(d->m_pluginNames.value(t));
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&](){
        snoreDebug(SNORE_DEBUG) << "connecting";
        m_socket->sendBinaryMessage((QLatin1String("login:=") + device() + QLatin1Char(':') + secret() + QLatin1Char('\n')).toUtf8().constData());
        getMessages();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[reply, this]() {
        snoreDebug(SNORE_DEBUG) << reply->error();
        QByteArray input = reply->readAll();
        reply->close();
        reply->deleteLater();

        snoreDebug(SNORE_DEBUG) << input;

        QJsonObject message = QJsonDocument::fromJson(input).object();

        int latestID = -1;
        if (message.value(QLatin1String("status")).toInt() == 1) {
            QJsonArray notifications = message.value(QLatin1String("messages")).toArray();
            for (const QJsonValue &v : notifications) {
                QJsonObject notification = v.toObject();

                latestID = qMax(latestID, notification.value(QLatin1String("id")).toInt());

                QString appName = notification.value(QLatin1String("app")).toString();
                Application app = SnoreCore::instance().aplications().value(appName);

                if (!app.isValid()) {
                    Icon icon(QLatin1String("https://api.pushover.net/icons/") +
                              notification.value(QLatin1String("icon")).toString() +
                              QLatin1String(".png"));
                    app = Application(appName, icon);
                    SnoreCore::instance().registerApplication(app);
                }

                Notification n(app, app.defaultAlert(), notification.value(QLatin1String("title")).toString(),
                               notification.value(QLatin1String("message")).toString(),
                               app.icon(), Notification::defaultTimeout(),
                               static_cast<Notification::Prioritys>(notification.value(QLatin1String("priority")).toInt()));
                if (n.priority() == Notification::EMERGENCY) {
                    n.hints().setValue("receipt", notification.value(QLatin1String("receipt")).toString());
                    n.hints().setValue("acked", notification.value(QLatin1String("acked")).toInt());
                }
                if (notification.value(QLatin1String("html")).toInt() == 1) {
                    n.hints().setValue("use-markup", true) ;
                }
                n.data()->setSource(this);
                SnoreCore::instance().broadcastNotification(n);
            }
            if (latestID != -1) {
                deleteMessages(latestID);
            }
        } else {
            snoreDebug(SNORE_WARNING) << "An error occure" << input;
        }

    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto & t : SnorePlugin::types()) {
        if (t & type) {
            out.unite(s_pluginCache.value(t));
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QString error) {
        qCWarning(SNORE) << error;
        m_errorMessage = error;
    }
```

#### AUTO 


```{c}
auto key = qMakePair(type, info->name());
```

#### LAMBDA EXPRESSION 


```{c}
[this, w]() {
            Notification notification = w->notification();
            slotNotificationActionInvoked(notification);
            closeNotification(notification, Notification::ACTIVATED);
            slotCloseNotification(notification);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[reply, secret, this]() {
        snoreDebug(SNORE_DEBUG) << reply->error();
        QByteArray input = reply->readAll();
        reply->close();
        reply->deleteLater();
        QJsonObject message = QJsonDocument::fromJson(input).object();
        if (message.value(QStringLiteral("status")).toInt() == 1) {
            setSettingsValue(QStringLiteral("Secret"), secret, LOCAL_SETTING);
            setSettingsValue(QStringLiteral("DeviceID"), message.value(QStringLiteral("id")).toString(), LOCAL_SETTING);;
            connectToService();
        } else {
            snoreDebug(SNORE_WARNING) << "An error occure" << input;
            emit loggedInChanged(false);
            emit error(message.value(QStringLiteral("error")).toString());
        }

    }
```

#### AUTO 


```{c}
auto display = [this](NotifyWidget * w, ::Snore::Notification notification) {
        w->display(notification);
        notification.hints().setPrivateValue(this, "id", w->id());
        slotNotificationDisplayed(notification);
    };
```

#### LAMBDA EXPRESSION 


```{c}
[]()
{
    return QVariant();
}
```

#### LAMBDA EXPRESSION 


```{c}
[]() {
        return SnoreCore::instance().settingsValue(Snore::Constants::SettingsKeys::Silent);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[reply, this]() {
        snoreDebug(SNORE_DEBUG) << reply->error();
        QByteArray input = reply->readAll();
        reply->close();
        reply->deleteLater();

        snoreDebug(SNORE_DEBUG) << input;

        QJsonObject message = QJsonDocument::fromJson(input).object();

        int latestID = -1;
        if (message.value(QLatin1String("status")).toInt() == 1) {
            QJsonArray notifications = message.value(QLatin1String("messages")).toArray();
            for (const QJsonValue &v : notifications) {
                QJsonObject notification = v.toObject();

                latestID = qMax(latestID, notification.value(QLatin1String("id")).toInt());

                QString appName = notification.value(QLatin1String("app")).toString();
                Application app = SnoreCore::instance().aplications().value(appName);

                if (!app.isValid()) {
                    Icon icon(Icon::fromWebUrl(QUrl::fromEncoded((QLatin1String("https://api.pushover.net/icons/") +
                              notification.value(QLatin1String("icon")).toString() +
                              QLatin1String(".png")).toUtf8().constData())));
                    app = Application(appName, icon);
                    SnoreCore::instance().registerApplication(app);
                }

                Notification n(app, app.defaultAlert(), notification.value(QLatin1String("title")).toString(),
                               notification.value(QLatin1String("message")).toString(),
                               app.icon(), Notification::defaultTimeout(),
                               static_cast<Notification::Prioritys>(notification.value(QLatin1String("priority")).toInt()));
                if (n.priority() == Notification::EMERGENCY) {
                    n.hints().setValue("receipt", notification.value(QLatin1String("receipt")).toString());
                    n.hints().setValue("acked", notification.value(QLatin1String("acked")).toInt());
                }
                if (notification.value(QLatin1String("html")).toInt() == 1) {
                    n.hints().setValue("use-markup", true) ;
                }
                n.data()->setSource(this);
                SnoreCore::instance().broadcastNotification(n);
            }
            if (latestID != -1) {
                deleteMessages(latestID);
            }
        } else {
            snoreDebug(SNORE_WARNING) << "An error occure" << input;
        }

    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Application &a : SnoreCore::instance().aplications()) {
        QMetaObject::invokeMethod(this, "slotRegisterApplication", Qt::QueuedConnection, Q_ARG(Snore::Application, a));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&](QTabWidget *target, QWidget *container, SnorePlugin::PluginTypes type){
        bool enabled = false;
        target->clear();
        if (types & type) {
            for (PluginSettingsWidget *widget : SnoreCore::instance().settingWidgets(type)) {
                target->addTab(widget, widget->name());
                m_tabs.append(widget);
                enabled = true;
            }
        }
        if (enabled) {
            if (ui->tabWidget->indexOf(container) == -1) {
                ui->tabWidget->addTab(container,container->property("TAB_NAME").toString());
            }
        } else {
            int index = ui->tabWidget->indexOf(container);
            container->setProperty("TAB_NAME", ui->tabWidget->tabText(index));
            ui->tabWidget->removeTab(index);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](growl_callback_data * data)->void {
        qCDebug(SNORE) << data->id << QString::fromUtf8(data->reason) << QString::fromUtf8(data->data);
        Snore::Notification n = Snore::SnoreCore::instance().getActiveNotificationByID(data->id);
        if (!n.isValid())
        {
            return;
        }
        Snore::Notification::CloseReasons r = Snore::Notification::None;
        std::string reason(data->reason);
        if (reason == "TIMEDOUT")
        {
            r = Snore::Notification::TimedOut;
        } else if (reason == "CLOSED")
        {
            r = Snore::Notification::Dismissed;
        } else if (reason == "CLICK")
        {
            r = Snore::Notification::Activated;
            s_instance->slotNotificationActionInvoked(n);
        }
        s_instance->closeNotification(n, r);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto name : d->m_pluginNames[type]) {
//TODO: mem leak?
        SnorePlugin *p = d->m_plugins[name];
        PluginSettingsWidget *widget = p->settingsWidget();
        if (widget) {
            list.append(widget);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&](QAbstractSocket::SocketError error) {
        qCWarning(SNORE) << error << m_socket->errorString();
        emit loggedInChanged(Error);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        qCWarning(SNORE) << "disconnected";
        //TODO: use new style connect once we depend on qt 5.4
        QTimer::singleShot(500, this, SLOT(PushoverFrontend::connectToService()));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[pushover, this] () {
        if(!value(QLatin1String("Registered"), Snore::LOCAL_SETTING).toBool()) {
            pushover->registerDevice(m_emailLineEdit->text(), m_passwordLineEdit->text(), m_deviceLineEdit->text());
            setValue(QLatin1String("DeviceName"), m_deviceLineEdit->text(), Snore::LOCAL_SETTING);
            QTimer *updateTimer = new QTimer(this);
            updateTimer->setInterval(500);
            connect(updateTimer, &QTimer::timeout, [updateTimer, this](){
                qDebug() << value(QLatin1String("Registered")).toBool();
                if (value(QLatin1String("Registered"), Snore::LOCAL_SETTING).toBool()) {
                    updateLoginState();
                    updateTimer->deleteLater();
                }
            });

            updateTimer->start();
        }else{
            setValue(QLatin1String("Registered"), false, Snore::LOCAL_SETTING);
            updateLoginState();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[reply]() {
        snoreDebug(SNORE_DEBUG) << reply->error();
        snoreDebug(SNORE_DEBUG) << reply->readAll();
        //TODO:parse reply
        reply->close();
        reply->deleteLater();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString group : groups) {
            settings.beginGroup(group);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto type : types) {
        for (auto &pluginName : m_pluginNames[type]) {
            SnorePlugin *plugin = m_plugins.value(pluginName);
            bool enable = m_plugins[pluginName]->value(QLatin1String("Enabled"), LOCAL_SETTING).toBool();
            if (!plugin->isInitialized() && enable) {
                plugin->initialize();
            } else if (plugin->isInitialized() && !enable) {
                plugin->deinitialize();
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, w]() {
            Notification notification = w->notification();
            slotNotificationActionInvoked(notification);
            closeNotification(notification, Notification::Activated);
            slotCloseNotification(notification);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[]() {
        return SnoreCore::instance().settingsValue(QStringLiteral("Silent"), LocalSetting);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (SnorePlugin::PluginTypes type : SnorePlugin::types()) {
        if (type != SnorePlugin::ALL && types & type) {
            for (PluginContainer *info : PluginContainer::pluginCache(type).values()) {
                SnorePlugin *plugin = info->load();
                if (!plugin) {
                    continue;
                }
                switch (info->type()) {
                case SnorePlugin::BACKEND:
                    break;
                case SnorePlugin::SECONDARY_BACKEND:
                case SnorePlugin::FRONTEND:
                case SnorePlugin::PLUGIN: {
                    if (plugin->settingsValue(QLatin1String("Enabled"), LOCAL_SETTING).toBool()) {
                        if (!plugin->initialize()) {
                            snoreDebug(SNORE_WARNING) << "Failed to initialize" << plugin->name();
                            plugin->deinitialize();
                            //info->unload();
                            break;
                        }
                    }
                }
                    break;
                default:
                    snoreDebug(SNORE_WARNING) << "Plugin Cache corrupted\n" << info->file() << info->type();
                    continue;
                }
                snoreDebug(SNORE_DEBUG) << info->name() << "is a" << info->type();
                d->m_pluginNames[info->type()].append(info->name());
                d->m_plugins[info->name()] = plugin;
            }
            if (d->m_pluginNames.contains(type)) {
                qSort(d->m_pluginNames[type]);
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&](qint64 bytesReceived, qint64 bytesTotal){
                snoreDebug(SNORE_DEBUG) << "Downloading:" << m_localUrl << bytesReceived/double(bytesTotal) * 100.0 << "%";
            }
```

#### LAMBDA EXPRESSION 


```{c}
[&](QAbstractSocket::SocketError error){
        snoreDebug(SNORE_DEBUG) << error << m_socket->errorString();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool state) {
        m_loggedIn = state;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (PluginContainer *p : PluginContainer::pluginCache(SnorePlugin::All)) {
        if (p->isLoaded()) {
            qCDebug(SNORE) << "deinitialize" << p->name();
            p->load()->disable();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto pluginName : m_pluginNames[SnorePlugin::SECONDARY_BACKEND]) {
        SnorePlugin *plugin = m_plugins.value(pluginName);
        bool enable = m_plugins[pluginName]->value("Enabled").toBool();
        if (!plugin->isInitialized() && enable) {
            plugin->initialize();
        } else if (plugin->isInitialized() && !enable) {
            plugin->deinitialize();
        }
    }
```

#### AUTO 


```{c}
auto & t
```

#### AUTO 


```{c}
auto key = qMakePair(type, pluginName);
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString &extention : pluginExtentions() ) {
            out << QLatin1String ( "libsnore_" ) + typeName + QLatin1String ( "_*." ) + extention;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &message : messages) {
                        snore.broadcastNotification(Notification(app, app.defaultAlert(), QStringLiteral("Title"), message, app.icon()));
                    }
```

#### LAMBDA EXPRESSION 


```{c}
[&](Notification noti) {
            if (!parser.isSet(silent)) {
                QString reason;
                QDebug(&reason) << noti.closeReason();
                cout << qPrintable(reason) << endl;
            }
            if (noti.closeReason() == Notification::CLOSED) {
                if (parser.isSet(_bringProcessToFront)) {
                    bringToFront(parser.value(_bringProcessToFront));
                } else if (parser.isSet(_bringWindowToFront)) {
                    Utils::bringWindowToFront((WId)parser.value(_bringWindowToFront).toULongLong(),true);
                }
            }
            returnCode = noti.closeReason();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&backends, &snore, &message, this](Notification n) {
            qDebug() << n << "closed";
            qDebug() << backends.size();
            if (backends.empty()) {
                return;
            }
            QString old = snore.primaryNotificationBackend();
            while (snore.primaryNotificationBackend() == old) {
                QString p = backends.takeLast();
                snore.setSettingsValue(QLatin1String("PrimaryBackend"), p, LOCAL_SETTING);
                SnoreCorePrivate::instance()->syncSettings();
                if (snore.primaryNotificationBackend() == p) {
                    qDebug() << p;
                    snore.broadcastNotification(Notification(app, app.defaultAlert(), QLatin1String("Title"), message, app.icon()));
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (NotifyWidget *w : m_widgets) {
                if (w->acquire()) {
                    Notification notification = m_queue.takeFirst();
                    w->display(notification);
                    notification.hints().setPrivateValue(this, "id", w->id());
                    slotNotificationDisplayed(notification);
                    if (m_queue.isEmpty()) {
                        m_timer->stop();
                        return;
                    }
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool b) {
        if (b) {
            connect(&Snore::SnoreCore::instance(), &Snore::SnoreCore::notificationClosed, this, &Speech::slotNotificationClosed);
        } else {
            disconnect(&Snore::SnoreCore::instance(), &Snore::SnoreCore::notificationClosed, this, &Speech::slotNotificationClosed);
        }
    }
```

#### AUTO 


```{c}
auto p
```

#### LAMBDA EXPRESSION 


```{c}
[q, notification]() {
        snoreDebug(SNORE_DEBUG) << notification;
        q->requestCloseNotification(notification, Notification::TIMED_OUT);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](growl_callback_data * data)->void {
        qCDebug(SNORE) << data->id << QString::fromUtf8(data->reason) << QString::fromUtf8(data->data);
        Notification n = Snore::SnoreCore::instance().getActiveNotificationByID(data->id);
        if (!n.isValid()) {
            return;
        }
        Notification::CloseReasons r = Notification::None;
        std::string reason(data->reason);
        if (reason == "TIMEDOUT") {
            r = Notification::TimedOut;
        } else if (reason == "CLOSED") {
            r = Notification::Dismissed;
        } else if (reason == "CLICK") {
            r = Notification::Activated;
            s_instance->slotNotificationActionInvoked(n);
        }
        s_instance->closeNotification(n, r);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto pluginName : m_pluginNames[SnorePlugin::FRONTEND]) {
        syncPluginStatus(pluginName);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(NotifyWidget * w : m_widgets) {
                if (w->acquire()) {
                    display(w, notification);
                    return;
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[p](int, QProcess::ExitStatus) {
        snoreDebug(SNORE_DEBUG) << p->readAll();
        p->deleteLater();
    }
```

#### AUTO 


```{c}
auto t
```

#### LAMBDA EXPRESSION 


```{c}
[]() {
        return SnoreCore::instance().settingsValue(QStringLiteral("Silent"), LOCAL_SETTING);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto w : m_widgets) {
        w->deleteLater();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[notification](){
        if (notification.isValid()) {
            snoreDebug(SNORE_DEBUG) << notification;
            SnoreCore::instance().requestCloseNotification(notification, Notification::TIMED_OUT);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto t : SnorePlugin::types()) {
        if (t & type) {
            out.unite(s_pluginCache.value(t));
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&closed](Notification) {
        closed++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (PluginContainer *info : PluginContainer::pluginCache(type).values()) {
                SnorePlugin *plugin = info->load();
                if (!plugin) {
                    continue;
                }
                switch (info->type()) {
                case SnorePlugin::BACKEND:
                    break;
                case SnorePlugin::SECONDARY_BACKEND:
                case SnorePlugin::FRONTEND:
                case SnorePlugin::PLUGIN: {
                    if (plugin->value("Enabled", LOCAL_SETTING).toBool()) {
                        if (!plugin->initialize()) {
                            snoreDebug(SNORE_WARNING) << "Failed to initialize" << plugin->name();
                            plugin->deinitialize();
                            //info->unload();
                            break;
                        }
                    }
                }
                break;
                default:
                    snoreDebug(SNORE_WARNING) << "Plugin Cache corrupted\n" << info->file() << info->type();
                    continue;
                }
                snoreDebug(SNORE_DEBUG) << info->name() << "is a" << info->type();
                d->m_pluginNames[info->type()].append(info->name());
                d->m_plugins[info->name()] = plugin;
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool enabled) {
        if (enabled) {
            connect(SnoreCorePrivate::instance(), &SnoreCorePrivate::applicationRegistered, this, &SnoreBackend::slotRegisterApplication, Qt::QueuedConnection);
            connect(SnoreCorePrivate::instance(), &SnoreCorePrivate::applicationDeregistered, this, &SnoreBackend::slotDeregisterApplication, Qt::QueuedConnection);

            connect(this, &SnoreBackend::notificationClosed, SnoreCorePrivate::instance(), &SnoreCorePrivate::slotNotificationClosed, Qt::QueuedConnection);
            connect(SnoreCorePrivate::instance(), &SnoreCorePrivate::notify, this, &SnoreBackend::slotNotify, Qt::QueuedConnection);

            for (const Application & a : SnoreCore::instance().aplications()) {
                slotRegisterApplication(a);
            }
        } else {
            for (const Application & a : SnoreCore::instance().aplications()) {
                slotDeregisterApplication(a);
            }
            disconnect(SnoreCorePrivate::instance(), &SnoreCorePrivate::applicationRegistered, this, &SnoreBackend::slotRegisterApplication);
            disconnect(SnoreCorePrivate::instance(), &SnoreCorePrivate::applicationDeregistered, this, &SnoreBackend::slotDeregisterApplication);

            disconnect(this, &SnoreBackend::notificationClosed, SnoreCorePrivate::instance(), &SnoreCorePrivate::slotNotificationClosed);
            disconnect(SnoreCorePrivate::instance(), &SnoreCorePrivate::notify, this, &SnoreBackend::slotNotify);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](NotifyWidget * w, ::Snore::Notification notification) {
        w->display(notification);
        notification.hints().setPrivateValue(this, "id", w->id());
        slotNotificationDisplayed(notification);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[ &, box](QAbstractButton * button) {
        switch (box->buttonRole(button)) {
        case QDialogButtonBox::AcceptRole:
            m_settings->accept();
            m_settings->setVisible(false);
            break;
        case QDialogButtonBox::ApplyRole:
            m_settings->accept();
            break;
        case QDialogButtonBox::ResetRole:
            m_settings->reset();
            break;
        case QDialogButtonBox::RejectRole:
            m_settings->setVisible(false);
            break;
        default:
            snoreDebug(SNORE_WARNING) << "unhandled role" << button->text() << box->buttonRole(button);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        QFileDialog dialog;
        dialog.setNameFilter("All Audio files (*.mp3 *.wav *.ogg)");
        dialog.setFileMode(QFileDialog::ExistingFile);
        dialog.setDirectory(m_lineEdit->text());
        if (dialog.exec()) {
            m_lineEdit->setText(dialog.selectedFiles().first());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto w : m_tabs) {
        w->saveSettings();
        dirty |= w->isDirty();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QJsonValue &v : notifications) {
                QJsonObject notification = v.toObject();

                latestID = qMax(latestID, notification.value(QLatin1String("id")).toInt());

                QString appName = notification.value(QLatin1String("app")).toString();
                Application app = SnoreCore::instance().aplications().value(appName);

                if (!app.isValid()) {
                    Icon icon(Icon::fromWebUrl(QUrl::fromEncoded((QLatin1String("https://api.pushover.net/icons/") +
                              notification.value(QLatin1String("icon")).toString() +
                              QLatin1String(".png")).toUtf8().constData())));
                    app = Application(appName, icon);
                    SnoreCore::instance().registerApplication(app);
                }

                Notification n(app, app.defaultAlert(), notification.value(QLatin1String("title")).toString(),
                               notification.value(QLatin1String("message")).toString(),
                               app.icon(), Notification::defaultTimeout(),
                               static_cast<Notification::Prioritys>(notification.value(QLatin1String("priority")).toInt()));
                if (n.priority() == Notification::EMERGENCY) {
                    n.hints().setValue("receipt", notification.value(QLatin1String("receipt")).toString());
                    n.hints().setValue("acked", notification.value(QLatin1String("acked")).toInt());
                }
                if (notification.value(QLatin1String("html")).toInt() == 1) {
                    n.hints().setValue("use-markup", true) ;
                }
                n.data()->setSource(this);
                SnoreCore::instance().broadcastNotification(n);
            }
```

#### AUTO 


```{c}
auto type
```

#### AUTO 


```{c}
auto &t
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QByteArray & msg) {
        char c = msg.at(0);
        switch (c) {
        case '#':
            qCDebug(SNORE) << "still alive";
            break;
        case '!':
            getMessages();
            break;
        case 'R':
            qCDebug(SNORE) << "need to reconnect";
            m_socket->close();
            m_socket->deleteLater();
            connectToService();
            break;
        case 'E':
            qCWarning(SNORE) << "Connection Error";
            emit error(QStringLiteral("Please Loggin to https://pushover.net and reanble your device."));
            emit loggedInChanged(false);
            m_socket->close();
            m_socket->deleteLater();
            break;
        default:
            qCWarning(SNORE) << "unknown message received" << msg;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&](QTabWidget * target, QWidget * container, SnorePlugin::PluginTypes type) {
        bool enabled = false;
        target->clear();
        if (types & type) {
            foreach (PluginSettingsWidget *widget, Settings::settingWidgets(type)) {
                target->addTab(widget, widget->name());
                m_tabs.append(widget);
                enabled = true;
            }
        }
        if (enabled) {
            if (ui->tabWidget->indexOf(container) == -1) {
                ui->tabWidget->addTab(container, container->property("TAB_NAME").toString());
            }
        } else {
            int index = ui->tabWidget->indexOf(container);
            container->setProperty("TAB_NAME", ui->tabWidget->tabText(index));
            ui->tabWidget->removeTab(index);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, w]() {
                Notification notification = w->notification();
                closeNotification(notification, Notification::DISMISSED);
                slotCloseNotification(notification);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this, timeout] {
            m_player->stop();
            timeout->deleteLater();
        }
```

#### AUTO 


```{c}
auto func = [](growl_callback_data * data)->void {
        qCDebug(SNORE) << data->id << QString::fromUtf8(data->reason) << QString::fromUtf8(data->data);
        Notification n = Snore::SnoreCore::instance().getActiveNotificationByID(data->id);
        if (!n.isValid()) {
            return;
        }
        Notification::CloseReasons r = Notification::None;
        std::string reason(data->reason);
        if (reason == "TIMEDOUT") {
            r = Notification::TimedOut;
        } else if (reason == "CLOSED") {
            r = Notification::Dismissed;
        } else if (reason == "CLICK") {
            r = Notification::Activated;
            s_instance->slotNotificationActionInvoked(n);
        }
        s_instance->closeNotification(n, r);
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (auto name : d->m_pluginNames[type]) {
        //TODO: mem leak?
        SnorePlugin *p = d->m_plugins[qMakePair(type, name)];
        PluginSettingsWidget *widget = p->settingsWidget();
        if (widget) {
            list.append(widget);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool enabled) {
        if (enabled) {
            connect(m_interface, &org::freedesktop::Notifications::ActionInvoked, this, &Freedesktop::slotActionInvoked);
            connect(m_interface, &org::freedesktop::Notifications::NotificationClosed, this , &Freedesktop::slotNotificationClosed);
        } else {
            disconnect(m_interface, &org::freedesktop::Notifications::ActionInvoked, this, &Freedesktop::slotActionInvoked);
            disconnect(m_interface, &org::freedesktop::Notifications::NotificationClosed, this , &Freedesktop::slotNotificationClosed);

        }
    }
```

#### AUTO 


```{c}
auto display = [this](NotifyWidget * w, Snore::Notification notification) {
        w->display(notification);
        notification.hints().setPrivateValue(this, "id", w->id());
        slotNotificationDisplayed(notification);
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (NotifyWidget *w : m_widgets) {
                if (w->acquire()) {
                    display(w, notification);
                    return;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto t : types()) {
        if (t & type) {
            out.unite(s_pluginCache.value(t));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QJsonValue &v : notifications) {
                QJsonObject notification = v.toObject();

                latestID = qMax(latestID, notification.value(QLatin1String("id")).toInt());

                QString appName = notification.value(QLatin1String("app")).toString();
                Application app = SnoreCore::instance().aplications().value(appName);

                if (!app.isValid()) {
                    Icon icon(QLatin1String("https://api.pushover.net/icons/") +
                              notification.value(QLatin1String("icon")).toString() +
                              QLatin1String(".png"));
                    app = Application(appName, icon);
                    SnoreCore::instance().registerApplication(app);
                }

                Notification n(app, app.defaultAlert(), notification.value(QLatin1String("title")).toString(),
                               notification.value(QLatin1String("message")).toString(),
                               app.icon(), Notification::defaultTimeout(),
                               static_cast<Notification::Prioritys>(notification.value(QLatin1String("priority")).toInt()));
                if (n.priority() == Notification::EMERGENCY) {
                    n.hints().setValue("receipt", notification.value(QLatin1String("receipt")).toString());
                    n.hints().setValue("acked", notification.value(QLatin1String("acked")).toInt());
                }
                if (notification.value(QLatin1String("html")).toInt() == 1) {
                    n.hints().setValue("use-markup", true) ;
                }
                SnoreCore::instance().broadcastNotification(n);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (NotifyWidget *w : m_widgets) {
            if (w->acquire(notification.timeout())) {
                display(w, notification);
                return;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString & error) {
        qCWarning(SNORE) << error;
        m_errorMessage = error;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[reply, secret, this]() {
        qCDebug(SNORE) << reply->error();
        QByteArray input = reply->readAll();
        reply->close();
        reply->deleteLater();
        QJsonObject message = QJsonDocument::fromJson(input).object();
        if (message.value(QStringLiteral("status")).toInt() == 1) {
            m_frontend->setSettingsValue(QStringLiteral("Secret"), secret, LocalSetting);
            m_frontend->setSettingsValue(QStringLiteral("DeviceID"), message.value(QStringLiteral("id")).toString(), LocalSetting);;
            connectToService();
        } else {
            qCWarning(SNORE) << "An error occured" << input;
            emit loggedInChanged(Error);
            QStringList errorMessages;
            QJsonObject errors = message.value(QStringLiteral("errors")).toObject();
            foreach(const auto & errorKey, errors.keys()) {
                auto array = errors.value(errorKey).toArray();
                errorMessages.reserve(array.size());
                foreach(const auto & error, array) {
                    errorMessages << errorKey + QLatin1Char(' ') + error.toString();
                }
            }
            emit error(tr("Failed to login due to errors: %1").arg(errorMessages.join(QStringLiteral(", "))));
        }

    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &extention : pluginExtentions()) {
            out << QLatin1String("libsnore_") + SnorePlugin::typeToString(type).toLower() + QLatin1String("_*.") + extention;
        }
```

#### AUTO 


```{c}
auto types = SnorePlugin::types();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        if (m_queue.isEmpty()) {
            snoreDebug(SNORE_DEBUG) << "queue is empty";
            m_timer->stop();
        } else {
            for (NotifyWidget *w : m_widgets) {
                if (w->acquire(m_queue.first().timeout())) {
                    Notification notification = m_queue.takeFirst();
                    w->display(notification);
                    notification.hints().setPrivateValue(this, "id", w->id());
                    slotNotificationDisplayed(notification);
                    if (m_queue.isEmpty()) {
                        m_timer->stop();
                        return;
                    }
                }
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (SnorePlugin::PluginTypes type : SnorePlugin::types()) {
        if (type != SnorePlugin::ALL && types & type) {
            for (PluginContainer *info : PluginContainer::pluginCache(type).values()) {
                SnorePlugin *plugin = info->load();
                if (!plugin) {
                    continue;
                }
                switch (info->type()) {
                case SnorePlugin::BACKEND:
                    break;
                case SnorePlugin::SECONDARY_BACKEND:
                case SnorePlugin::FRONTEND:
                case SnorePlugin::PLUGIN: {
                    if (plugin->value("Enabled", LOCAL_SETTING).toBool()) {
                        if (!plugin->initialize()) {
                            snoreDebug(SNORE_WARNING) << "Failed to initialize" << plugin->name();
                            plugin->deinitialize();
                            //info->unload();
                            break;
                        }
                    }
                }
                break;
                default:
                    snoreDebug(SNORE_WARNING) << "Plugin Cache corrupted\n" << info->file() << info->type();
                    continue;
                }
                snoreDebug(SNORE_DEBUG) << info->name() << "is a" << info->type();
                d->m_pluginNames[info->type()].append(info->name());
                d->m_plugins[info->name()] = plugin;
            }
            if (d->m_pluginNames.contains(type)) {
                qSort(d->m_pluginNames[type]);
            }
        }
    }
```

#### AUTO 


```{c}
auto notify = [&backends, &snore, &message, this](Notification n) {
            qDebug() << n << "closed";
            qDebug() << backends.size();
            if (backends.empty()) {
                return;
            }
            QString old = snore.primaryNotificationBackend();
            while (snore.primaryNotificationBackend() == old) {
                QString p = backends.takeLast();
                snore.setSettingsValue(QStringLiteral("PrimaryBackend"), p, LOCAL_SETTING);
                SnoreCorePrivate::instance()->syncSettings();
                if (snore.primaryNotificationBackend() == p) {
                    qDebug() << p;
                    snore.broadcastNotification(Notification(app, app.defaultAlert(), QStringLiteral("Title"), message, app.icon()));
                }
            }
        };
```

#### AUTO 


```{c}
auto w
```

#### LAMBDA EXPRESSION 


```{c}
[this, w]() {
            ::Snore::Notification notification = w->notification();
            slotNotificationActionInvoked(notification);
            closeNotification(notification, ::Snore::Notification::Activated);
            slotCloseNotification(notification);
        }
```

