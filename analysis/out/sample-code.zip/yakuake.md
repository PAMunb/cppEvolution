#### LAMBDA EXPRESSION 


```{c}
[=](KJob* deleteJob) {
        if (deleteJob->error()) {
            KMessageBox::error(parentWidget(), deleteJob->errorString(), xi18nc("@title:Window", "Could Not Delete Skin"));
        } else if (successCallback) {
           successCallback();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](KIO::Job* /* job */, const KIO::UDSEntryList& list) {
        if (list.count() == 0) return;

        QListIterator<KIO::UDSEntry> i(list);
        while (i.hasNext())
            m_installSkinFileList.append(i.next().stringValue(KIO::UDSEntry::UDS_NAME));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &skinId : skinIdList) {
                // Validate the current skin.
                if (!validateSkin(skinId, true)) {
                    isValid = false;
                }
            }
```

#### AUTO 


```{c}
auto* session
```

#### LAMBDA EXPRESSION 


```{c}
[&](int , QString) {
                    m_sessionStack->raiseSession(m_sessionStack->activeSessionId());
            }
```

#### AUTO 


```{c}
const auto rootCollection = collections.at(0);
```

#### AUTO 


```{c}
auto message = QDBusMessage::createMethodCall(QStringLiteral("org.kde.plasmashell"),
                                                      QStringLiteral("/StrutManager"),
                                                      QStringLiteral("org.kde.PlasmaShell.StrutManager"),
                                                      QStringLiteral("availableScreenRect"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : files) {
                QFileInfo info(QString(file).remove(QStringLiteral("/*")));
                if (!info.exists()) {
                    continue;
                }
                if (info.isDir()) {
                    QDir(info.absoluteFilePath()).removeRecursively();
                } else {
                    QFile::remove(info.absoluteFilePath());
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this](){
            bool showTitleBar = !Settings::showTitleBar();
            m_titleBar->setVisible(showTitleBar);
            Settings::setShowTitleBar(showTitleBar);
            Settings::self()->save();
            applyWindowGeometry();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[factory, this] {
                            factory->removeClient(m_part);
                        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto* client : guiClients) {
            if (client->actionCollection()->associatedWidgets().contains(m_terminalWidget)) {
                return client->actionCollection();
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
                    installSkinArchive();
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &terminalID : terminalIds) {
            auto *terminal = session->getTerminal(terminalID.toInt());
            if (terminal) {
                auto *collection = terminal->actionCollection();
                if (collection) {
                    actionCollections.append(collection);
                }
            }
        }
```

#### AUTO 


```{c}
const auto& terminalID
```

#### AUTO 


```{c}
auto *collection = terminal->actionCollection();
```

#### LAMBDA EXPRESSION 


```{c}
[=](KJob *job) {
        if (!job->error())
            checkForExistingSkin();
        else
            failInstall(xi18nc("@info", "Unable to list the skin archive contents.") + QStringLiteral("\n\n") + job->errorString());
    }
```

#### AUTO 


```{c}
auto factory = new KXMLGUIFactory(m_part->clientBuilder(), this);
```

#### AUTO 


```{c}
auto *session
```

#### AUTO 


```{c}
const auto* action
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        bool showTitleBar = !Settings::showTitleBar();
        m_titleBar->setVisible(showTitleBar);
        Settings::setShowTitleBar(showTitleBar);
        Settings::self()->save();
        applyWindowGeometry();
    }
```

#### AUTO 


```{c}
auto message = QDBusMessage::createMethodCall(QStringLiteral("org.kde.plasmashell"), QStringLiteral("/StrutManager"),
                                                      QStringLiteral("org.kde.PlasmaShell.StrutManager"), QStringLiteral("availableScreenRect"));
```

#### AUTO 


```{c}
const auto childClients = m_part->childClients();
```

#### AUTO 


```{c}
auto message = QDBusMessage::createMethodCall(QStringLiteral("org.kde.KWin"),
                                                      QStringLiteral("/KWin"),
                                                      QStringLiteral("org.kde.KWin"),
                                                      QStringLiteral("activeOutputName"));
```

#### AUTO 


```{c}
const auto *action
```

#### AUTO 


```{c}
auto *client
```

#### AUTO 


```{c}
const auto collections = m_sessionStack->getPartActionCollections();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& terminalID : terminalIds) {

            auto *terminal = session->getTerminal(terminalID.toInt());
            if (terminal) {
                auto* collection = terminal->actionCollection();
                if (collection) {
                    actionCollections.append(collection);
                }
            }

        }
```

#### AUTO 


```{c}
const auto sessions = m_sessions.values();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &skinId : skinIdList) {
            // Validate the current skin.
            if (!validateSkin(skinId, true)) {
                isValid = false;
            }
        }
```

#### AUTO 


```{c}
auto *destaction = collections.at(i)->action(action->objectName())
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &_entry : changedEntries) {
        if (_entry.status() != KNS3::Entry::Installed) {
            continue;
        }
#if KNEWSTUFF_VERSION < QT_VERSION_CHECK(5, 78, 0)
        const KNSCore::EntryInternal entry = KNSCore::EntryInternal::fromEntry(_entry);
#else
        const KNSCore::EntryInternal &entry = _entry;
#endif
        bool isValid = true;
        const QSet<QString> &skinIdList = extractKnsSkinIds(entry.installedFiles());

        // Validate all skin IDs as each archive can contain multiple skins.
        for (const QString &skinId : skinIdList) {
            // Validate the current skin.
            if (!validateSkin(skinId, true)) {
                isValid = false;
            }
        }

        // We'll add an error message for the whole KNS entry if
        // the current skin is marked as invalid.
        // We should not do this per skin as the user does not know that
        // there are more skins inside one archive.
        if (!isValid) {
            invalidEntryCount++;

            // The user needs to know the name of the skin which
            // was removed.
            invalidSkinText += QString(QStringLiteral("<li>%1</li>")).arg(entry.name());

            // Then remove the skin.
            const QStringList files = entry.installedFiles();
            for (const QString &file : files) {
                QFileInfo info(QString(file).remove(QStringLiteral("/*")));
                if (!info.exists()) {
                    continue;
                }
                if (info.isDir()) {
                    QDir(info.absoluteFilePath()).removeRecursively();
                } else {
                    QFile::remove(info.absoluteFilePath());
                }
            }
        }
    }
```

#### AUTO 


```{c}
auto* destaction = collections.at(i)->action(action->objectName())
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto childClient : childClients) {
            QAction *closeSessionAction = childClient->actionCollection()->action(QStringLiteral("close-session"));
            if (closeSessionAction) {
                closeSessionAction->setShortcut(QKeySequence());
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto* session : sessions) {

        const auto terminalIds = session->terminalIdList().split(QStringLiteral(","));

        for (const auto& terminalID : terminalIds) {

            auto *terminal = session->getTerminal(terminalID.toInt());
            if (terminal) {
                auto* collection = terminal->actionCollection();
                if (collection) {
                    actionCollections.append(collection);
                }
            }

        }

    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &_entry : changedEntries) {
        if (_entry.status() != KNS3::Entry::Installed) {
            continue;
        }
        const KNSCore::EntryInternal &entry = _entry;
        bool isValid = true;
        const QSet<QString> &skinIdList = extractKnsSkinIds(entry.installedFiles());

        // Validate all skin IDs as each archive can contain multiple skins.
        for (const QString &skinId : skinIdList) {
            // Validate the current skin.
            if (!validateSkin(skinId, true)) {
                isValid = false;
            }
        }

        // We'll add an error message for the whole KNS entry if
        // the current skin is marked as invalid.
        // We should not do this per skin as the user does not know that
        // there are more skins inside one archive.
        if (!isValid) {
            invalidEntryCount++;

            // The user needs to know the name of the skin which
            // was removed.
            invalidSkinText += QString(QStringLiteral("<li>%1</li>")).arg(entry.name());

            // Then remove the skin.
            const QStringList files = entry.installedFiles();
            for (const QString &file : files) {
                QFileInfo info(QString(file).remove(QStringLiteral("/*")));
                if (!info.exists()) {
                    continue;
                }
                if (info.isDir()) {
                    QDir(info.absoluteFilePath()).removeRecursively();
                } else {
                    QFile::remove(info.absoluteFilePath());
                }
            }
        }
    }
```

#### AUTO 


```{c}
const auto terminalIds = session->terminalIdList().split(QStringLiteral(","));
```

#### AUTO 


```{c}
auto *terminal = session->getTerminal(terminalID.toInt());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : fileList) {
        // We only care about files/directories which are subdirectories of our KNS skins dir.
        if (file.startsWith(m_knsSkinDir, Qt::CaseInsensitive)) {
            // Get the relative filename (this removes the KNS install dir from the filename).
            QString relativeName = QString(file).remove(m_knsSkinDir, Qt::CaseInsensitive);

            // Get everything before the first slash - that should be our skins ID.
            QString skinId = relativeName.section(QLatin1Char('/'), 0, 0, QString::SectionSkipEmpty);

            // Skip all other entries in the file list if we found what we were searching for.
            if (!skinId.isEmpty()) {
                // First remove all remaining slashes (as there could be leading or trailing ones).
                skinId.remove(QStringLiteral("/"));

                skinIdList.insert(skinId);
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](KIO::Job* /* job */, const KIO::UDSEntryList& list) {
        if (list.isEmpty()) return;

        QListIterator<KIO::UDSEntry> i(list);
        while (i.hasNext())
            m_installSkinFileList.append(i.next().stringValue(KIO::UDSEntry::UDS_NAME));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *session : sessions) {
        const auto terminalIds = session->terminalIdList().split(QStringLiteral(","));

        for (const auto &terminalID : terminalIds) {
            auto *terminal = session->getTerminal(terminalID.toInt());
            if (terminal) {
                auto *collection = terminal->actionCollection();
                if (collection) {
                    actionCollections.append(collection);
                }
            }
        }
    }
```

#### AUTO 


```{c}
const auto &_entry
```

#### AUTO 


```{c}
auto* client
```

#### LAMBDA EXPRESSION 


```{c}
[=](KJob *job) {
        if (job->error())
        {
            job->uiDelegate()->showErrorMessage();
            job->kill();

            cleanupAfterInstall();

            return;
        }

        installSkin(static_cast<KIO::CopyJob*>(job)->destUrl());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto *action : rootActions) {
                if (auto *destaction = collections.at(i)->action(action->objectName())) {
                    destaction->setShortcuts(action->shortcuts());
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[=](KIO::Job * /* job */, const KIO::UDSEntryList &list) {
        if (list.isEmpty())
            return;

        QListIterator<KIO::UDSEntry> i(list);
        while (i.hasNext())
            m_installSkinFileList.append(i.next().stringValue(KIO::UDSEntry::UDS_NAME));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &skin : skins) {
        if (m_skins->item(skin.row())->data(SkinInstalledWithKns).toBool())
            --exists;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](KJob *job) {
        if (!job->error())
        {
            m_installSkinId = m_installSkinFileList.at(0);

            if (validateSkin(m_installSkinId, m_installSkinFileList))
                checkForExistingSkin();
            else
                failInstall(xi18nc("@info", "Unable to locate required files in the skin archive.<nl/><nl/>The archive appears to be invalid."));
        }
        else
            failInstall(xi18nc("@info", "Unable to list the skin archive contents.") + QStringLiteral("\n\n") + job->errorString());
    }
```

#### AUTO 


```{c}
auto* action = actionCollection()->action(QStringLiteral("toggle-window-state"));
```

#### AUTO 


```{c}
auto *action = actionCollection()->action(QStringLiteral("toggle-window-state"));
```

#### AUTO 


```{c}
auto toggleFunc = [this](){
            bool showTitleBar = !Settings::showTitleBar();
            m_titleBar->setVisible(showTitleBar);
            Settings::setShowTitleBar(showTitleBar);
            Settings::self()->save();
            applyWindowGeometry();
        };
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
            QDBusPendingReply<QRect> reply = *watcher;
            m_availableScreenRect = reply.isValid() ? reply.value() : QRect();
            setWindowGeometry(Settings::width(), Settings::height(), Settings::position());
            watcher->deleteLater();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
            QString skinId = skinList->currentIndex().data(SkinId).toString();
            if (skinId == Settings::skin()) {
                Settings::setSkin(QStringLiteral("default"));
                Settings::setSkinInstalledWithKns(false);
                Settings::self()->save();
                Q_EMIT settingsChanged();
            }

            resetSelection();
            populateSkinList();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&](int, QString) {
        m_sessionStack->raiseSession(m_sessionStack->activeSessionId());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
            QDBusPendingReply<QRect> reply = *watcher;
            m_availableScreenRect = reply.isValid() ? reply.value() : QRect();
            _toggleWindowState();
            watcher->deleteLater();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=](){
            QString skinId = skinList->currentIndex().data(SkinId).toString();
            if (skinId == Settings::skin())
            {
                Settings::setSkin(QStringLiteral("default"));
                Settings::setSkinInstalledWithKns(false);
                Settings::self()->save();
                emit settingsChanged();
            }

            resetSelection();
            populateSkinList();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=](KJob *deleteJob) {
        if (deleteJob->error()) {
            KMessageBox::error(parentWidget(), deleteJob->errorString(), xi18nc("@title:Window", "Could Not Delete Skin"));
        } else if (successCallback) {
            successCallback();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *client : guiClients) {
            if (client->actionCollection()->associatedWidgets().contains(m_terminalWidget)) {
                return client->actionCollection();
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        m_toggleLock = true;
        KWindowSystem::activateWindow(winId());
        KWindowSystem::forceActiveWindow(winId());
    }
```

#### AUTO 


```{c}
const auto &terminalID
```

#### LAMBDA EXPRESSION 


```{c}
[=](){ installSkinArchive(); }
```

#### AUTO 


```{c}
auto toggleFunc = [this]() {
        bool showTitleBar = !Settings::showTitleBar();
        m_titleBar->setVisible(showTitleBar);
        Settings::setShowTitleBar(showTitleBar);
        Settings::self()->save();
        applyWindowGeometry();
    };
```

#### LAMBDA EXPRESSION 


```{c}
[factory, this] {
                    factory->removeClient(m_part);
                }
```

#### LAMBDA EXPRESSION 


```{c}
[=](KJob* deleteJob) {
            if (deleteJob->error())
            {
                KMessageBox::error(parentWidget(), deleteJob->errorString(), xi18nc("@title:Window", "Could Not Delete Skin"));
            } else {
                if (skinId == Settings::skin())
                {
                    Settings::setSkin(QStringLiteral("default"));
                    Settings::setSkinInstalledWithKns(false);
                    Settings::self()->save();
                    emit settingsChanged();
                }

                resetSelection();
                populateSkinList();
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &skinLocation : std::as_const(allSkinLocations)) {
        populateSkinList(skinLocation);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto* action : rootActions) {
                if (auto* destaction = collections.at(i)->action(action->objectName())) {
                    destaction->setShortcuts(action->shortcuts());
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this, dialog] {
        const QList<KNSCore::EntryInternal> changedEntries = dialog->changedEntries();
        quint32 invalidEntryCount = 0;
        QString invalidSkinText;
        for (const auto &_entry : changedEntries) {
            if (_entry.status() != KNS3::Entry::Installed) {
                continue;
            }
            const KNSCore::EntryInternal &entry = _entry;
            bool isValid = true;
            const QSet<QString> &skinIdList = extractKnsSkinIds(entry.installedFiles());

            // Validate all skin IDs as each archive can contain multiple skins.
            for (const QString &skinId : skinIdList) {
                // Validate the current skin.
                if (!validateSkin(skinId, true)) {
                    isValid = false;
                }
            }

            // We'll add an error message for the whole KNS entry if
            // the current skin is marked as invalid.
            // We should not do this per skin as the user does not know that
            // there are more skins inside one archive.
            if (!isValid) {
                invalidEntryCount++;

                // The user needs to know the name of the skin which
                // was removed.
                invalidSkinText += QString(QStringLiteral("<li>%1</li>")).arg(entry.name());

                // Then remove the skin.
                const QStringList files = entry.installedFiles();
                for (const QString &file : files) {
                    QFileInfo info(QString(file).remove(QStringLiteral("/*")));
                    if (!info.exists()) {
                        continue;
                    }
                    if (info.isDir()) {
                        QDir(info.absoluteFilePath()).removeRecursively();
                    } else {
                        QFile::remove(info.absoluteFilePath());
                    }
                }
            }
        }

        // Are there any invalid entries?
        if (invalidEntryCount > 0) {
            failInstall(xi18ncp("@info",
                                "The following skin is missing required files. Thus it was removed:<ul>%2</ul>",
                                "The following skins are missing required files. Thus they were removed:<ul>%2</ul>",
                                invalidEntryCount,
                                invalidSkinText));
        }

        if (!changedEntries.isEmpty()) {
            // Reset the selection in case the currently selected
            // skin was removed.
            resetSelection();

            // Re-populate the list of skins if the user changed something.
            populateSkinList();
        }

        dialog->deleteLater();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &_entry : changedEntries) {
            if (_entry.status() != KNS3::Entry::Installed) {
                continue;
            }
            const KNSCore::EntryInternal &entry = _entry;
            bool isValid = true;
            const QSet<QString> &skinIdList = extractKnsSkinIds(entry.installedFiles());

            // Validate all skin IDs as each archive can contain multiple skins.
            for (const QString &skinId : skinIdList) {
                // Validate the current skin.
                if (!validateSkin(skinId, true)) {
                    isValid = false;
                }
            }

            // We'll add an error message for the whole KNS entry if
            // the current skin is marked as invalid.
            // We should not do this per skin as the user does not know that
            // there are more skins inside one archive.
            if (!isValid) {
                invalidEntryCount++;

                // The user needs to know the name of the skin which
                // was removed.
                invalidSkinText += QString(QStringLiteral("<li>%1</li>")).arg(entry.name());

                // Then remove the skin.
                const QStringList files = entry.installedFiles();
                for (const QString &file : files) {
                    QFileInfo info(QString(file).remove(QStringLiteral("/*")));
                    if (!info.exists()) {
                        continue;
                    }
                    if (info.isDir()) {
                        QDir(info.absoluteFilePath()).removeRecursively();
                    } else {
                        QFile::remove(info.absoluteFilePath());
                    }
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &_entry : changedEntries) {
        if (_entry.status() != KNS3::Entry::Installed) {
            continue;
        }
#if KNEWSTUFF_VERSION < QT_VERSION_CHECK(5, 78, 0)
        const KNSCore::EntryInternal entry = KNSCore::EntryInternal::fromEntry(_entry);
#else
        const KNSCore::EntryInternal &entry = _entry;
#endif
        bool isValid = true;
        const QSet<QString>& skinIdList = extractKnsSkinIds(entry.installedFiles());

        // Validate all skin IDs as each archive can contain multiple skins.
        for (const QString& skinId : skinIdList) {
            // Validate the current skin.
            if (!validateSkin(skinId, true)) {
                isValid = false;
            }
        }

        // We'll add an error message for the whole KNS entry if
        // the current skin is marked as invalid.
        // We should not do this per skin as the user does not know that
        // there are more skins inside one archive.
        if (!isValid)
        {
            invalidEntryCount++;

            // The user needs to know the name of the skin which
            // was removed.
            invalidSkinText += QString(QStringLiteral("<li>%1</li>")).arg(entry.name());

            // Then remove the skin.
            const QStringList files = entry.installedFiles();
            for (const QString &file : files) {
                QFileInfo info(QString(file).remove(QStringLiteral("/*")));
                if (!info.exists()) {
                    continue;
                }
                if (info.isDir()) {
                    QDir(info.absoluteFilePath()).removeRecursively();
                } else {
                    QFile::remove(info.absoluteFilePath());
                }
            }
        }
    }
```

#### AUTO 


```{c}
const auto screens = QGuiApplication::screens();
```

#### AUTO 


```{c}
auto i = 1;
```

#### AUTO 


```{c}
auto borderWidth = Settings::hideSkinBorders() ? 0 : m_skin->borderWidth();
```

#### LAMBDA EXPRESSION 


```{c}
[=](KJob *job) {
        if (job->error()) {
            job->uiDelegate()->showErrorMessage();
            job->kill();

            cleanupAfterInstall();

            return;
        }

        installSkin(static_cast<KIO::CopyJob *>(job)->destUrl());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& skinId : skinIdList) {
            // Validate the current skin.
            if (!validateSkin(skinId, true)) {
                isValid = false;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : files) {
                    QFileInfo info(QString(file).remove(QStringLiteral("/*")));
                    if (!info.exists()) {
                        continue;
                    }
                    if (info.isDir()) {
                        QDir(info.absoluteFilePath()).removeRecursively();
                    } else {
                        QFile::remove(info.absoluteFilePath());
                    }
                }
```

#### AUTO 


```{c}
const auto rootActions = rootCollection->actions();
```

#### AUTO 


```{c}
const auto guiClients = m_part->childClients();
```

#### AUTO 


```{c}
const auto childClient
```

#### AUTO 


```{c}
auto* collection = terminal->actionCollection();
```

