#### RANGE FOR STATEMENT 


```{c}
for (QGraphicsItem *sprite : qAsConst(hitlist)) {
      switch(sprite->type())
      {
         case S_BULLET:
            bullet=(BulletSprite *)sprite;
            bullet->hide();
            bullets[bullet->getPlayerNumber()]->removeAll(bullet);
            delete bullet;
            break;
         case S_MINE:
            mine=(MineSprite*)sprite;
            mine->stop();
            if(!mine->explodes())
               mine->explode();
            break;
      }
   }
```

#### RANGE FOR STATEMENT 


```{c}
for (QGraphicsItem *sprite : std::as_const(unexact)) {
               if(sprite->type()==S_BULLET)
                  if(mine->collidesWithItem(sprite))
                     if(!hitlist.contains(sprite))
                        hitlist.append(sprite);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (QGraphicsItem *sprite : std::as_const(unexact)) {
      switch(sprite->type())
      {
         case S_BULLET:
            if(sun->collidesWithItem(sprite))
               if(!hitlist.contains(sprite))
                  hitlist.append(sprite);
            break;
         case S_MINE:
            if(!((MobileSprite*)sprite)->isStopped())
               if(sun->collidesWithItem(sprite))
                  if(!hitlist.contains(sprite))
                     hitlist.append(sprite);
            break;
      }
   }
```

#### RANGE FOR STATEMENT 


```{c}
for (QGraphicsItem *item : qAsConst(hitlist)) {
                  // FIXME: why does it crash with qgraphicsitem_cast?
		  bullet = static_cast<BulletSprite*>(item);// qgraphicsitem_cast<BulletSprite*>(item);
//                   bullets[bullet->getPlayerNumber()]->removeRef(bullet);
                  bullets[bullet->getPlayerNumber()]->removeAll(bullet);
                  delete bullet;
               }
```

#### RANGE FOR STATEMENT 


```{c}
for (QGraphicsItem *item : std::as_const(hitlist)) {
                  // FIXME: why does it crash with qgraphicsitem_cast?
		  bullet = static_cast<BulletSprite*>(item);// qgraphicsitem_cast<BulletSprite*>(item);
//                   bullets[bullet->getPlayerNumber()]->removeRef(bullet);
                  bullets[bullet->getPlayerNumber()]->removeAll(bullet);
                  delete bullet;
               }
```

#### AUTO 


```{c}
auto &label
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &label : m_statusBarLabel)
   {
      label = new QLabel(this);
      label->setAlignment(Qt::AlignCenter);
      statusBar()->addWidget(label, 1);
   }
```

#### RANGE FOR STATEMENT 


```{c}
for (QGraphicsItem *sprite : std::as_const(hitlist)) {
            switch(sprite->type())
            {
               case S_SUN:
                  hp=0;
                  ship[pl]->stop();
                  break;
               case S_BULLET:
                  bullet=(BulletSprite *)sprite;
                  bullet->hide();
                  //bullets[bullet->getPlayerNumber()]->removeRef(bullet);
                  bullets[bullet->getPlayerNumber()]->removeAll(bullet);
                  delete bullet;
                  hp-=config.bulletDamage;
                  break;
               case S_SHIP:
                  s=(ShipSprite*)sprite;
                  ohp=s->getHitPoints();
                  if(ohp>0)
                  {
                     s->setHitPoints(ohp-hp-config.shipDamage);
                     Q_EMIT hitPoints(s->getPlayerNumber(),s->getHitPoints());
                     ndx[0]=((1-EPSILON)*ship[0]->xVelocity()+(1+EPSILON)*ship[1]->xVelocity())/2.0;
                     ndy[0]=((1-EPSILON)*ship[0]->yVelocity()+(1+EPSILON)*ship[1]->yVelocity())/2.0;
                     ndx[1]=((1-EPSILON)*ship[1]->xVelocity()+(1+EPSILON)*ship[0]->xVelocity())/2.0;
                     ndy[1]=((1-EPSILON)*ship[1]->yVelocity()+(1+EPSILON)*ship[0]->yVelocity())/2.0;
                     ship[0]->setVelocity(ndx[0],ndy[0]);
                     ship[1]->setVelocity(ndx[1],ndy[1]);
                     hp-=ohp+config.shipDamage;
                  }
                  break;
               case S_MINE:
                  mine=(MineSprite *)sprite;
                  if(mine->isActive()&& !mine->explodes())
                  {
                     mine->explode();
                     ndx[0]=(ship[pl]->xVelocity()+0.3*mine->xVelocity())/1.3;
                     ndy[0]=(ship[pl]->yVelocity()+0.3*mine->yVelocity())/1.3;
                     ship[pl]->setVelocity(ndx[0],ndy[0]);
                     mine->setVelocity(ndx[0],ndy[0]);
                     hp-=config.mineDamage;
                  }
                  break;
               case S_POWERUP:
                  power=(PowerupSprite *)sprite;
                  switch(power->getType())
                  {
                     case PowerupSprite::PowerupShield:
                        hp+=config.powerupShieldAmount;
                        break;
                     case PowerupSprite::PowerupEnergy:
                        en=ship[pl]->getEnergy()+config.powerupEnergyAmount;
                        if(en>MAX_ENERGY)
                           en=MAX_ENERGY;
                        ship[pl]->setEnergy(en);
                        break;
                     case PowerupSprite::PowerupMine:
                        ship[pl]->setMinePowerups(
                           ship[pl]->getMinePowerups()+1);
                        break;
                     case PowerupSprite::PowerupBullet:
                        ship[pl]->setBulletPowerups(
                           ship[pl]->getMinePowerups()+1);
                        break;
                  }
                  power->hide();
                  powerups.removeAll(power);
                  delete power;
                  break;
            }
         }
```

#### RANGE FOR STATEMENT 


```{c}
for (QGraphicsItem *sprite : std::as_const(hitlist)) {
      switch(sprite->type())
      {
         case S_BULLET:
            bullet=(BulletSprite *)sprite;
            bullet->hide();
            bullets[bullet->getPlayerNumber()]->removeAll(bullet);
            delete bullet;
            break;
         case S_MINE:
            mine=(MineSprite*)sprite;
            mine->stop();
            if(!mine->explodes())
               mine->explode();
            break;
      }
   }
```

#### RANGE FOR STATEMENT 


```{c}
for (QGraphicsItem *sprite : qAsConst(hitlist)) {
            switch(sprite->type())
            {
               case S_SUN:
                  hp=0;
                  ship[pl]->stop();
                  break;
               case S_BULLET:
                  bullet=(BulletSprite *)sprite;
                  bullet->hide();
                  //bullets[bullet->getPlayerNumber()]->removeRef(bullet);
                  bullets[bullet->getPlayerNumber()]->removeAll(bullet);
                  delete bullet;
                  hp-=config.bulletDamage;
                  break;
               case S_SHIP:
                  s=(ShipSprite*)sprite;
                  ohp=s->getHitPoints();
                  if(ohp>0)
                  {
                     s->setHitPoints(ohp-hp-config.shipDamage);
                     Q_EMIT hitPoints(s->getPlayerNumber(),s->getHitPoints());
                     ndx[0]=((1-EPSILON)*ship[0]->xVelocity()+(1+EPSILON)*ship[1]->xVelocity())/2.0;
                     ndy[0]=((1-EPSILON)*ship[0]->yVelocity()+(1+EPSILON)*ship[1]->yVelocity())/2.0;
                     ndx[1]=((1-EPSILON)*ship[1]->xVelocity()+(1+EPSILON)*ship[0]->xVelocity())/2.0;
                     ndy[1]=((1-EPSILON)*ship[1]->yVelocity()+(1+EPSILON)*ship[0]->yVelocity())/2.0;
                     ship[0]->setVelocity(ndx[0],ndy[0]);
                     ship[1]->setVelocity(ndx[1],ndy[1]);
                     hp-=ohp+config.shipDamage;
                  }
                  break;
               case S_MINE:
                  mine=(MineSprite *)sprite;
                  if(mine->isActive()&& !mine->explodes())
                  {
                     mine->explode();
                     ndx[0]=(ship[pl]->xVelocity()+0.3*mine->xVelocity())/1.3;
                     ndy[0]=(ship[pl]->yVelocity()+0.3*mine->yVelocity())/1.3;
                     ship[pl]->setVelocity(ndx[0],ndy[0]);
                     mine->setVelocity(ndx[0],ndy[0]);
                     hp-=config.mineDamage;
                  }
                  break;
               case S_POWERUP:
                  power=(PowerupSprite *)sprite;
                  switch(power->getType())
                  {
                     case PowerupSprite::PowerupShield:
                        hp+=config.powerupShieldAmount;
                        break;
                     case PowerupSprite::PowerupEnergy:
                        en=ship[pl]->getEnergy()+config.powerupEnergyAmount;
                        if(en>MAX_ENERGY)
                           en=MAX_ENERGY;
                        ship[pl]->setEnergy(en);
                        break;
                     case PowerupSprite::PowerupMine:
                        ship[pl]->setMinePowerups(
                           ship[pl]->getMinePowerups()+1);
                        break;
                     case PowerupSprite::PowerupBullet:
                        ship[pl]->setBulletPowerups(
                           ship[pl]->getMinePowerups()+1);
                        break;
                  }
                  power->hide();
                  powerups.removeAll(power);
                  delete power;
                  break;
            }
         }
```

#### RANGE FOR STATEMENT 


```{c}
for (QGraphicsItem *sprite : qAsConst(unexact)) {
            if((sprite->type()!=S_EXPLOSION)
               && !((sprite->type()!=S_SUN)&&(ship[pl]->getHitPoints()==0)))
               if(ship[pl]->collidesWithItem(sprite,Qt::IntersectsItemShape))
                  if(!hitlist.contains(sprite))
                     hitlist.append(sprite);
         }
```

#### RANGE FOR STATEMENT 


```{c}
for (QGraphicsItem *sprite : std::as_const(unexact)) {
            if((sprite->type()!=S_EXPLOSION)
               && !((sprite->type()!=S_SUN)&&(ship[pl]->getHitPoints()==0)))
               if(ship[pl]->collidesWithItem(sprite,Qt::IntersectsItemShape))
                  if(!hitlist.contains(sprite))
                     hitlist.append(sprite);
         }
```

#### RANGE FOR STATEMENT 


```{c}
for (QGraphicsItem *sprite : qAsConst(unexact)) {
               if(sprite->type()==S_BULLET)
                  if(mine->collidesWithItem(sprite))
                     if(!hitlist.contains(sprite))
                        hitlist.append(sprite);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (QGraphicsItem *sprite : qAsConst(unexact)) {
      switch(sprite->type())
      {
         case S_BULLET:
            if(sun->collidesWithItem(sprite))
               if(!hitlist.contains(sprite))
                  hitlist.append(sprite);
            break;
         case S_MINE:
            if(!((MobileSprite*)sprite)->isStopped())
               if(sun->collidesWithItem(sprite))
                  if(!hitlist.contains(sprite))
                     hitlist.append(sprite);
            break;
      }
   }
```

