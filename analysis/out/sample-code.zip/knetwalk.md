#### RANGE FOR STATEMENT 


```{c}
for (AbstractCell *cell : std::as_const(m_cells)) {
        if (!cell->hasBeenMoved()) {
            Directions dirs = cell->cables();
            Move move;
            if (dirs == None) {
                // no cables
                move = Move(cell->index(), Move::None);
                possibleNextMoves.append(move);
            } else if (dirs == (Up | Down) || dirs == (Left | Right)) {
                // cables forming a line
                move = Move(cell->index(), Move::None);
                possibleNextMoves.append(move);

                move = Move(cell->index(), Move::Left);
                possibleNextMoves.append(move);
            } else {
                // other kind of cables
                move = Move(cell->index(), Move::None);
                possibleNextMoves.append(move);

                move = Move(cell->index(), Move::Left);
                possibleNextMoves.append(move);

                move = Move(cell->index(), Move::Right);
                possibleNextMoves.append(move);

                move = Move(cell->index(), Move::Inverted);
                possibleNextMoves.append(move);
            }
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Move &nextMove : std::as_const(possibleNextMoves)) {
        int index = nextMove.index();

        switch (nextMove.move()) {
        case Move::None:
            m_cells[index]->emptyMove();
            break;
        case Move::Right:
            m_cells[index]->rotateClockwise();
            break;
        case Move::Left:
            m_cells[index]->rotateCounterclockwise();
            break;
        case Move::Inverted:
            m_cells[index]->invert();
            break;
        }

        if (movesDoneArePossible()) {
            solutionsFound += solutionCount(); // recursive call
        }

        m_cells[index]->reset(); // undo move
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractCell *cell : std::as_const(m_cells)) {
        cell->setConnected(false);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractCell *cell : std::as_const(m_cells)) {
        if (cell->isTerminal() && !cell->isConnected()) {
            return false;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractCell *cell : std::as_const(m_cells)) {
        if (!cell->hasBeenMoved()) continue;

        uint x = cell->index() % m_width;
        uint y = cell->index() / m_width;
        Directions cables = cell->cables();

        // check if there are moved cells near the borders that are wrong
        if (!m_isWrapped) {
            if (x == 0          && cables & Left)  return false;
            if (x == m_width-1  && cables & Right) return false;
            if (y == 0          && cables & Up)    return false;
            if (y == m_height-1 && cables & Down)  return false;
        }

        // check if there are contiguous moved cells that are wrong

        if (cables & Left) {
            int lcell = lCell(cell->index());
            if (lcell != NO_CELL && m_cells[lcell]->hasBeenMoved()) {
                // also the cell to the left of the current has been moved

                // if it doesn't connect return false
                if (!(m_cells[lcell]->cables() & Right)) return false;
            }
        }
        if (cables & Right) {
            int rcell = rCell(cell->index());
            if (rcell != NO_CELL && m_cells[rcell]->hasBeenMoved()) {
                if (!(m_cells[rcell]->cables() & Left)) return false;
            }
        }
        if (cables & Up) {
            int ucell = uCell(cell->index());
            if (ucell != NO_CELL && m_cells[ucell]->hasBeenMoved()) {
                if (!(m_cells[ucell]->cables() & Down)) return false;
            }
        }
        if (cables & Down) {
            int dcell = dCell(cell->index());
            if (dcell != NO_CELL && m_cells[dcell]->hasBeenMoved()) {
                if (!(m_cells[dcell]->cables() & Up)) return false;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (int i : changedCells) {
        if(grid->cellAt(i)->isTerminal()){
            newTerminalConnected = true;
        }
        updateSprite(i);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractCell *cell : std::as_const(m_cells)) {
        if (cell->isTerminal() || cell->isServer() || cell->cables() == None) {
            continue;
        }

        Directions oldCables = cell->cables();
        cell->setCables(None);

        bool solution = isPossibleSolution();
        cell->setCables(oldCables);

        if (solution) {
            // it has a solution also when the cables of cell are removed
            return true;
        }
    }
```

#### AUTO 


```{c}
auto *generator = QRandomGenerator::global();
```

