#### AUTO 


```{c}
auto mainWidget = new QWidget( this );
```

#### RANGE FOR STATEMENT 


```{c}
for( const auto &location : QCoreApplication::libraryPaths() )
        plugins << KPluginLoader::findPlugins( location, [] ( const KPluginMetaData &metadata )
            { return metadata.serviceTypes().contains( QStringLiteral( "Amarok/Plugin" ) ); } );
```

#### AUTO 


```{c}
auto mainWidget = new Context::ContextView();
```

#### LAMBDA EXPRESSION 


```{c}
[] (const QString &a, const QString &b)  {
                  QStringList ae = Amarok::config(QStringLiteral("Context")).readEntry("enabledApplets", QStringList());
                  return ae.indexOf(a) < ae.indexOf(b);
              }
```

#### LAMBDA EXPRESSION 


```{c}
[=] (Collection* collection) {
        return toScriptValue<Collection*, CollectionPrototype>( engine, collection );
    }
```

#### AUTO 


```{c}
const auto &factory
```

#### AUTO 


```{c}
auto sqlAlbum = AmarokSharedPointer<Meta::SqlAlbum>::staticCast( album );
```

#### RANGE FOR STATEMENT 


```{c}
for( const auto &factory : factories )
    {
        bool callSucceeded = false;
        QStringList connectionErrors;

        callSucceeded = QMetaObject::invokeMethod( factory.data(),
                               "testSettings",
                               Q_RETURN_ARG( QStringList, connectionErrors ),
                               Q_ARG( QString, kcfg_Host->text() ),
                               Q_ARG( QString, kcfg_User->text() ),
                               Q_ARG( QString, kcfg_Password->text() ),
                               Q_ARG( int, kcfg_Port->text().toInt() ),
                               Q_ARG( QString, kcfg_Database->text() )
                               );

        if( callSucceeded )
        {
            if( connectionErrors.isEmpty() )
                KMessageBox::messageBox( this, KMessageBox::Information,
                                         i18n( "Amarok was able to establish a successful connection to the database." ),
                                         i18n( "Success" ) );
            else
                KMessageBox::error( this, i18n( "The amarok database reported "
                                                "the following errors:\n%1\nIn most cases you will need to resolve "
                                                "these errors before Amarok will run properly." ).
                                    arg( connectionErrors.join( "\n" ) ),
                                    i18n( "Database Error" ));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const auto &logger : s_loggers )
        logger->shortMessageImpl( text );
```

#### AUTO 


```{c}
const auto &plugin
```

#### AUTO 


```{c}
auto sql = StorageManager::instance()->sqlStorage();
```

#### LAMBDA EXPRESSION 


```{c}
[] (const KPluginMetaData &data)
                                        { return data.serviceTypes().contains(QStringLiteral("Amarok/ContextApplet")); }
```

#### AUTO 


```{c}
auto pointer = qobject_cast<PluginFactory*>( loader.instance() );
```

#### RANGE FOR STATEMENT 


```{c}
for( const auto &fadebar : m_fadebars.at(x) )
            {
                if( fadebar.intensity > 0 )
                {
                    const uint offset = fadebar.intensity;
                    const int fadeHeight = frameHeight - fadebar.y * (BLOCK_HEIGHT + 1);
                    if( fadeHeight > 0 )
                        p.drawPixmap(x * ( m_columnWidth + 1 ), 0, m_fadeBarsPixmaps.value(offset), 0, 0, m_columnWidth, fadeHeight);
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for( const auto &plugin : m_pluginsByType.value( type ) )
    {
        if( isPluginEnabled( plugin ) )
            enabledList << plugin;
    }
```

#### AUTO 


```{c}
auto device = new KCompressionDevice( &file, true, KCompressionDevice::BZip2 );
```

#### AUTO 


```{c}
const auto &scriptLocation
```

#### RANGE FOR STATEMENT 


```{c}
for( const auto &tag : tags->list() )
    {
        GpodderTagTreeItem *treeItem = new GpodderTagTreeItem( tag, this );
        appendChild( treeItem );
    }
```

#### AUTO 


```{c}
auto resetButton = buttonBox->button( QDialogButtonBox::Reset );
```

#### RANGE FOR STATEMENT 


```{c}
for( const auto &p : list )
        data << Meta::DataPtr::staticCast( p );
```

#### AUTO 


```{c}
auto scannerJob = QSharedPointer<GenericScannerJob>( new GenericScannerJob( this, input, type ) );
```

#### AUTO 


```{c}
auto removeFunction = [data] () {
        QMutexLocker locker( &s_mutex );
        s_progressList.removeAll( data );
    };
```

#### AUTO 


```{c}
auto worker = new BlockWorker( m_rows, m_columns, m_step, m_showFadebars );
```

#### AUTO 


```{c}
auto okButton = findChild<QDialogButtonBox*>()->button( QDialogButtonBox::Ok );
```

#### AUTO 


```{c}
auto package = findPackage(id);
```

#### AUTO 


```{c}
auto copyButton = new QPushButton( i18n( "Copy to Clipboard" ) );
```

#### LAMBDA EXPRESSION 


```{c}
[] (QJSValue jsValue) {
        Playlists::PlaylistPtr playlistPtr;
        fromScriptValue<Playlists::PlaylistPtr,PlaylistPrototype>( jsValue, playlistPtr );
        return playlistPtr;
    }
```

#### AUTO 


```{c}
auto it = destinations.constBegin();
```

#### LAMBDA EXPRESSION 


```{c}
[=] () mutable
            {
                if( data.contains( Meta::Field::SCORE ) )
                    track->statistics()->setScore( data.value( Meta::Field::SCORE ).toInt() );
                if( data.contains( Meta::Field::RATING ) )
                    track->statistics()->setRating( data.value( Meta::Field::RATING ).toInt() );
                if( data.contains( Meta::Field::LYRICS ) )
                    track->setCachedLyrics( data.value( Meta::Field::LYRICS ).toString() );

                QStringList labels = data.value( Meta::Field::LABELS ).toStringList();
                QHash<QString, Meta::LabelPtr> labelMap;
                for( const auto &label : track->labels() )
                    labelMap.insert( label->name(), label );

                // labels to remove
                for( const auto &label : labelMap.keys().toSet() - labels.toSet() )
                    track->removeLabel( labelMap.value( label ) );

                // labels to add
                for( const auto &label : labels.toSet() - labelMap.keys().toSet() )
                    track->addLabel( label );

                Meta::TrackEditorPtr ec = track->editor();
                if( !ec )
                {
                    debug() << "Track" << track->prettyUrl() << "does not have Meta::TrackEditor. Skipping.";
                    return;
                }

                ec->beginUpdate();

                if( data.contains( Meta::Field::TITLE ) )
                    ec->setTitle( data.value( Meta::Field::TITLE ).toString() );
                if( data.contains( Meta::Field::COMMENT ) )
                    ec->setComment( data.value( Meta::Field::COMMENT ).toString() );
                if( data.contains( Meta::Field::ARTIST ) )
                    ec->setArtist( data.value( Meta::Field::ARTIST ).toString() );
                if( data.contains( Meta::Field::ALBUM ) )
                    ec->setAlbum( data.value( Meta::Field::ALBUM ).toString() );
                if( data.contains( Meta::Field::GENRE ) )
                    ec->setGenre( data.value( Meta::Field::GENRE ).toString() );
                if( data.contains( Meta::Field::COMPOSER ) )
                    ec->setComposer( data.value( Meta::Field::COMPOSER ).toString() );
                if( data.contains( Meta::Field::YEAR ) )
                    ec->setYear( data.value( Meta::Field::YEAR ).toInt() );
                if( data.contains( Meta::Field::TRACKNUMBER ) )
                    ec->setTrackNumber( data.value( Meta::Field::TRACKNUMBER ).toInt() );
                if( data.contains( Meta::Field::DISCNUMBER ) )
                    ec->setDiscNumber( data.value( Meta::Field::DISCNUMBER ).toInt() );
                if( data.contains( Meta::Field::BPM ) )
                    ec->setBpm( data.value( Meta::Field::BPM ).toDouble() );
                if( data.contains( Meta::Field::ALBUMARTIST ) )
                    ec->setAlbumArtist( data.value( Meta::Field::ALBUMARTIST ).toString() );

                ec->endUpdate();
                // note: the track should by itself Q_EMIT a collectionUpdated signal if needed
            }
```

#### RANGE FOR STATEMENT 


```{c}
for( const auto &data : s_shortMessageList )
        shortMessageImpl( data );
```

#### RANGE FOR STATEMENT 


```{c}
for (QObject* childObject : rootObject->findChildren<QObject*>( QString(), Qt::FindDirectChildrenOnly ) ) {
                QJSValue childJSValue = mirrorObjectTree( childObject, engine ) ;
                rootJSValue.setProperty( childObject->objectName(), childJSValue );
            }
```

#### AUTO 


```{c}
auto &fadebar
```

#### LAMBDA EXPRESSION 


```{c}
[=] (BookmarkGroupPtr bGroup) { return toScriptValue<BookmarkGroupPtr, BookmarkGroupPrototype>( m_engine, bGroup ); }
```

#### LAMBDA EXPRESSION 


```{c}
[] (QJSValue scriptObj) {
                    T arrayObj;
                    fromScriptArray( scriptObj, arrayObj );
                    return arrayObj;
                }
```

#### RANGE FOR STATEMENT 


```{c}
for( auto &fadebar : fadebars )
            fadebar.intensity -= fadeStep;
```

#### AUTO 


```{c}
const auto& band
```

#### LAMBDA EXPRESSION 


```{c}
[this] (Map mapObj) { return toScriptMap( this, mapObj ); }
```

#### AUTO 


```{c}
const auto &e
```

#### RANGE FOR STATEMENT 


```{c}
for( auto item : childCrumbs)
    {
        item->deleteLater();
    }
```

#### AUTO 


```{c}
auto removeFunction = [text] () {
        QMutexLocker locker( &s_mutex );
        s_shortMessageList.removeAll( text );
    };
```

#### RANGE FOR STATEMENT 


```{c}
for( const QString &siblingName : childNames )
            {
                //no point in adding ourselves to this menu
                if ( siblingName == list->name() )
                    continue;

                BrowserCategory * siblingCategory = childMap.value( siblingName );

                QAction * action = menu->addAction( siblingCategory->icon(), siblingCategory->prettyName() );
                connect( action, &QAction::triggered, childMap.value( siblingName ), &BrowserCategory::activate );

            }
```

#### LAMBDA EXPRESSION 


```{c}
[this, action]() { m_composerActions.removeAll( action ); }
```

#### LAMBDA EXPRESSION 


```{c}
[] (QJSValue jsValue) {
        Meta::TrackList trackList;
        fromScriptArray<Meta::TrackList>( jsValue, trackList );
        return trackList;
    }
```

#### AUTO 


```{c}
auto list = document.elementsByTagName( QStringLiteral( "rev" ) );
```

#### AUTO 


```{c}
auto copyJob = KIO::copy( file, QUrl::fromLocalFile( coverDownloadPath ) );
```

#### RANGE FOR STATEMENT 


```{c}
for( const auto &logger : s_loggers )
            logger->newProgressOperationImpl( job, text, context, function, type );
```

#### AUTO 


```{c}
auto track = AmarokSharedPointer<Meta::MagnatuneTrack>::dynamicCast( dataPtr )
```

#### RANGE FOR STATEMENT 


```{c}
for( const auto &location : locations )
    {
        QDir dir( location + "/amarok/scripts" );

        if( !dir.exists() )
            continue;

        for( const auto &scriptLocation : dir.entryList( QDir::NoDotAndDotDot | QDir::Dirs ) )
        {
            QDir scriptDir( dir.absoluteFilePath( scriptLocation ) );
            if( scriptDir.exists( QStringLiteral( "main.js" ) ) )
                foundScripts << scriptDir.absoluteFilePath( QStringLiteral( "main.js" ) );
        }
    }
```

#### AUTO 


```{c}
auto doc = QJsonDocument::fromJson( storedResultsJob->data(), &err );
```

#### AUTO 


```{c}
const auto &p
```

#### LAMBDA EXPRESSION 


```{c}
[this, action]() { m_genreActions.removeAll( action ); }
```

#### AUTO 


```{c}
auto buttonBox = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &applet : applets)
        result << applet.pluginId();
```

#### AUTO 


```{c}
auto storedJob = qobject_cast< KIO::StoredTransferJob * >( job );
```

#### LAMBDA EXPRESSION 


```{c}
[=] () { m_queue->add( unit->options(), fetchSource(), data );
                                                 m_queue->remove( unit ); }
```

#### AUTO 


```{c}
auto dialog = qobject_cast<Amarok2ConfigDialog*>(parent)
```

#### AUTO 


```{c}
auto currentTrack = The::engineController()->currentTrack();
```

#### RANGE FOR STATEMENT 


```{c}
for( const auto &applet : applets )
    {
        appletNames << applet.name();
    }
```

#### AUTO 


```{c}
auto directoryWatcher = QSharedPointer<SqlDirectoryWatcher>::create( this );
```

#### LAMBDA EXPRESSION 


```{c}
[] (QJSValue jsValue) {
        Collection* collection;
        fromScriptValue<Collection*, CollectionPrototype>( jsValue, collection );
        return collection;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, indexes] () { editSelected( indexes ); }
```

#### RANGE FOR STATEMENT 


```{c}
for( auto &band : m_interpolatedScopeBands )
    {
        const double x = band.midK;
        auto &scope = m_currentScope[band.scopeIndex];

        // Search for the interval x is in, returning the corresponding y if x is one of the original xs
        int low = 0, mid, high = c3s.size() - 1;
        while ( low <= high )
        {
            mid = std::floor( 0.5 * ( low + high ) );
            double xHere = data[mid].x();
            if( xHere < x )
                low = mid + 1;
            else if( xHere > x )
                high = mid - 1;
            else
                scope = data[mid].y();
        }
        int i = qMax( 0, high );

        // Interpolate
        double diff = x - data[i].x(), diffSq = diff * diff;
        scope = qMax( 0.0, data[i].y() + c1s[i] * diff + c2s[i] * diffSq + c3s[i] * diff * diffSq );
    }
```

#### AUTO 


```{c}
auto window = pApp->mainWindow()
```

#### LAMBDA EXPRESSION 


```{c}
[=] (Playlists::PlaylistProvider* providerPtr) {
        return toScriptValue<Playlists::PlaylistProvider*,PlaylistProviderPrototype>( engine, providerPtr);

    }
```

#### AUTO 


```{c}
const auto &label
```

#### LAMBDA EXPRESSION 


```{c}
[=] (Meta::TrackPtr trackPtr) { return toScriptValue<Meta::TrackPtr, MetaTrackPrototype>( engine, trackPtr ); }
```

#### LAMBDA EXPRESSION 


```{c}
[] (QObject* qObjPtr) {
                    const T* dataPtr = qobject_cast<T*>( qObjPtr );
                    return (dataPtr == nullptr) ? T() : T( *dataPtr ) ;
                }
```

#### AUTO 


```{c}
auto url = AmarokUrlPtr::dynamicCast( item )
```

#### RANGE FOR STATEMENT 


```{c}
for( const auto &label : track->labels() )
                    labelMap.insert( label->name(), label );
```

#### LAMBDA EXPRESSION 


```{c}
[=] (Playlists::PlaylistPtr playlistPtr) {
        return toScriptValue<Playlists::PlaylistPtr,PlaylistPrototype>( engine, playlistPtr );
    }
```

#### AUTO 


```{c}
auto raw = plugin.rawData();
```

#### LAMBDA EXPRESSION 


```{c}
[=] () {
        if( !m_years.contains( album.data() ) || m_years.value( album.data() ) != year )
        {
            m_years[ album.data() ] = year;
            emit dataChanged( index, index );
        }
    }
```

#### AUTO 


```{c}
auto factory = createFactory( pluginInfo );
```

#### AUTO 


```{c}
auto lambda = [=] () {
        if( !m_years.contains( album.data() ) || m_years.value( album.data() ) != year )
        {
            m_years[ album.data() ] = year;
            emit dataChanged( index, index );
        }
    };
```

#### AUTO 


```{c}
auto palette = The::paletteHandler()->palette();
```

#### RANGE FOR STATEMENT 


```{c}
for( const QModelIndex &index : indexes )
    {
        if( index.isValid() )
        {
            const QModelIndex &srcIndex = m_proxyModel->mapToSource( index );
            const QStandardItem *item = m_model->itemFromIndex( srcIndex );
            if( item->type() == AlbumType )
            {
                selected << static_cast<const AlbumItem*>( item )->album()->tracks();
            }
            else if( item->type() == TrackType )
            {
                selected << static_cast<const TrackItem*>( item )->track();
            }
            else if( m_model->hasChildren( srcIndex ) ) // disc type
            {
                for( int i = m_model->rowCount( srcIndex ) - 1; i >= 0; --i )
                {
                    const QStandardItem *trackItem = m_model->itemFromIndex( srcIndex.child(i, 0) );
                    selected << static_cast<const TrackItem*>( trackItem )->track();
                }
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, action]() { m_trackActions.removeAll( action ); }
```

#### LAMBDA EXPRESSION 


```{c}
[=] () { m_queue->addQuery( query, fetchSource(), page, album ); }
```

#### LAMBDA EXPRESSION 


```{c}
[] (QJSValue jsValue) {
        PlaylistProviderList providerList;
        fromScriptArray<PlaylistProviderList>( jsValue, providerList );
        return providerList;
    }
```

#### AUTO 


```{c}
auto storage = m_collection->sqlStorage();
```

#### LAMBDA EXPRESSION 


```{c}
[] (QJSValue jsValue) {
            QueryMaker* queryMaker;
            fromScriptValue<QueryMaker*, QueryMakerPrototype>( jsValue, queryMaker );
            return queryMaker;
    }
```

#### AUTO 


```{c}
auto &scope = m_currentScope[band.scopeIndex];
```

#### AUTO 


```{c}
const auto &applet
```

#### AUTO 


```{c}
auto metadata = package.metadata();
```

#### AUTO 


```{c}
auto scannerJob = m_scannerJob.data();
```

#### LAMBDA EXPRESSION 


```{c}
[this] () { this->loadExistingMessages(); }
```

#### RANGE FOR STATEMENT 


```{c}
for( const auto &factory : m_factoriesByType[ Storage ] )
        factory->init();
```

#### AUTO 


```{c}
auto incrementSlot = m_progressBar->staticMetaObject.method( incrementIndex );
```

#### AUTO 


```{c}
const auto &pluginInfo
```

#### RANGE FOR STATEMENT 


```{c}
for( const auto &resultVariant : object.value( "results" ).toArray() )
        {
            auto result = resultVariant.toObject();
            Meta::PlaydarTrackPtr aTrack;
            QUrl resultUrl( m_controller->urlForSid( result.value( "sid" ).toString() ) );
            
            QString trackSid = result.value( "sid" ).toString();
            QString trackUrl = resultUrl.url();
            QString trackTitle = result.value( "track" ).toString();
            QString trackArtist = result.value( "artist" ).toString();
            QString trackAlbum = result.value( "album" ).toString();
            QString trackType = result.value( "mimetype" ).toString();
            QString trackSource = result.value( "source" ).toString();
            qint64 trackLengthInSeconds( result.value( "duration" ).toInt() );
            aTrack = new Meta::PlaydarTrack
            (
                trackSid,
                trackUrl,
                trackTitle,
                trackArtist,
                trackAlbum,
                trackType,
                result.value( "score" ).toDouble() * 100,
                ( trackLengthInSeconds * 1000 ), //convert s to ms
                result.value( "bitrate" ).toInt(),
                result.value( "size" ).toInt(),
                trackSource
            );
            
            if( !m_solved && aTrack->score() >= 1.00 )
            {
                m_solved = true;
                m_trackList.prepend( aTrack );
                emit querySolved( aTrack );
                
                if( m_waitForSolution )
                {
                    emit queryDone( this, m_trackList );
                    return;
                }
            }
            else
            {
                m_trackList.append( aTrack );
            }
            emit newTrackAdded( aTrack );
        }
```

#### AUTO 


```{c}
auto storage = StorageManager::instance()->sqlStorage();
```

#### AUTO 


```{c}
auto loader = KPackage::PackageLoader::self();
```

#### LAMBDA EXPRESSION 


```{c}
[this, indexes] () { queueSelected( indexes ); }
```

#### AUTO 


```{c}
auto pluginFactory = QSharedPointer<Plugins::PluginFactory>( pointer );
```

#### AUTO 


```{c}
auto removeTag = [&wiki] ( const QString& tagStart, const QString& tagEnd )
    {
        const int tagEndSize = tagEnd.size();
        int matchIndex = 0;
        const QStringMatcher tagMatcher( tagStart );
        while( ( matchIndex = tagMatcher.indexIn( wiki, matchIndex ) ) != -1 )
        {
            const int nToTagEnd = wiki.indexOf( tagEnd, matchIndex ) - matchIndex;
            const QStringRef tagRef = wiki.midRef( matchIndex, nToTagEnd + tagEndSize );
            wiki.remove( tagRef.toString() );
        }
    };
```

#### AUTO 


```{c}
auto buttonBox = new QDialogButtonBox( this );
```

#### AUTO 


```{c}
auto buttonBox = new QDialogButtonBox( QDialogButtonBox::Reset | QDialogButtonBox::Ok | QDialogButtonBox::Cancel, this );
```

#### AUTO 


```{c}
auto job = QSharedPointer<TrackLoaderJob>::create( itemIndex( item ), album, nonConstThis );
```

#### AUTO 


```{c}
auto app = qobject_cast<App*>(qApp)
```

#### RANGE FOR STATEMENT 


```{c}
for( const auto &factory : m_factoriesByType[ Service ] )
        factory->init();
```

#### LAMBDA EXPRESSION 


```{c}
[=] (Meta::FieldHash fieldHash) { return toScriptTagMap( engine, fieldHash); }
```

#### LAMBDA EXPRESSION 


```{c}
[=] (PlaylistProviderList providerList) { return toScriptArray<PlaylistProviderList>( engine, providerList); }
```

#### AUTO 


```{c}
auto factory = qobject_cast<ServiceFactory*>( pFactory );
```

#### AUTO 


```{c}
auto vital = raw.value( QStringLiteral( "X-KDE-Amarok-vital" ) );
```

#### AUTO 


```{c}
const auto &location
```

#### AUTO 


```{c}
auto factory = qobject_cast<CollectionFactory*>( pFactory );
```

#### LAMBDA EXPRESSION 


```{c}
[=] (Playlists::PlaylistList playlistList) {
        return toScriptArray<Playlists::PlaylistList>( engine, playlistList );

    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const auto &pluginInfo : m_plugins )
    {
        // create the factories and sort them by type
        PluginFactory *factory = createFactory( pluginInfo );

        if( factory )
        {
            Type type;

            if( qobject_cast<StorageFactory*>( factory ) )
                type = Storage;
            else if( qobject_cast<Collections::CollectionFactory*>( factory ) )
                type = Collection;
            else if( qobject_cast<ServiceFactory*>( factory ) )
                type = Service;
            else if( qobject_cast<StatSyncing::ProviderFactory*>( factory ) )
                type = Importer;
            else
            {
                warning() << pluginInfo.name() << "has unknown category";
                warning() << pluginInfo.rawData().keys();
                continue;
            }

            m_pluginsByType[ type ] << pluginInfo;

            if( isPluginEnabled( pluginInfo ) )
                m_factoriesByType[ type ] << factory;
        }
        else
            warning() << pluginInfo.name() << "could not create factory";
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, indexes] () { replaceWithSelected( indexes ); }
```

#### RANGE FOR STATEMENT 


```{c}
for ( QAction * action : actions )
        menu->addAction( action );
```

#### RANGE FOR STATEMENT 


```{c}
for( const auto &aInfo : qAsConst(aPlugins) )
    {
        aPluginString += "   " + aInfo.name() + " (" + aInfo.version() + ")\n";
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const auto &podcast : podcasts->list() )
    {
        appendChild( new GpodderPodcastTreeItem( podcast, this ) );
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=] (Collections::CollectionList collectionList) {
        return toScriptArray<Collections::CollectionList>( engine, collectionList);

    }
```

#### AUTO 


```{c}
auto findItem = KStandardGuiItem::find();
```

#### LAMBDA EXPRESSION 


```{c}
[=] () mutable
            {
                if( data.contains( Meta::Field::SCORE ) )
                    track->statistics()->setScore( data.value( Meta::Field::SCORE ).toInt() );
                if( data.contains( Meta::Field::RATING ) )
                    track->statistics()->setRating( data.value( Meta::Field::RATING ).toInt() );
                if( data.contains( Meta::Field::LYRICS ) )
                    track->setCachedLyrics( data.value( Meta::Field::LYRICS ).toString() );

                QStringList labels = data.value( Meta::Field::LABELS ).toStringList();
                QHash<QString, Meta::LabelPtr> labelMap;
                for( const auto &label : track->labels() )
                    labelMap.insert( label->name(), label );

                // labels to remove
                for( const auto &label : labelMap.keys().toSet() - labels.toSet() )
                    track->removeLabel( labelMap.value( label ) );

                // labels to add
                for( const auto &label : labels.toSet() - labelMap.keys().toSet() )
                    track->addLabel( label );

                Meta::TrackEditorPtr ec = track->editor();
                if( !ec )
                {
                    debug() << "Track" << track->prettyUrl() << "does not have Meta::TrackEditor. Skipping.";
                    return;
                }

                ec->beginUpdate();

                if( data.contains( Meta::Field::TITLE ) )
                    ec->setTitle( data.value( Meta::Field::TITLE ).toString() );
                if( data.contains( Meta::Field::COMMENT ) )
                    ec->setComment( data.value( Meta::Field::COMMENT ).toString() );
                if( data.contains( Meta::Field::ARTIST ) )
                    ec->setArtist( data.value( Meta::Field::ARTIST ).toString() );
                if( data.contains( Meta::Field::ALBUM ) )
                    ec->setAlbum( data.value( Meta::Field::ALBUM ).toString() );
                if( data.contains( Meta::Field::GENRE ) )
                    ec->setGenre( data.value( Meta::Field::GENRE ).toString() );
                if( data.contains( Meta::Field::COMPOSER ) )
                    ec->setComposer( data.value( Meta::Field::COMPOSER ).toString() );
                if( data.contains( Meta::Field::YEAR ) )
                    ec->setYear( data.value( Meta::Field::YEAR ).toInt() );
                if( data.contains( Meta::Field::TRACKNUMBER ) )
                    ec->setTrackNumber( data.value( Meta::Field::TRACKNUMBER ).toInt() );
                if( data.contains( Meta::Field::DISCNUMBER ) )
                    ec->setDiscNumber( data.value( Meta::Field::DISCNUMBER ).toInt() );
                if( data.contains( Meta::Field::BPM ) )
                    ec->setBpm( data.value( Meta::Field::BPM ).toDouble() );
                if( data.contains( Meta::Field::ALBUMARTIST ) )
                    ec->setAlbumArtist( data.value( Meta::Field::ALBUMARTIST ).toString() );

                ec->endUpdate();
                // note: the track should by itself emit a collectionUpdated signal if needed
            }
```

#### LAMBDA EXPRESSION 


```{c}
[] (QJSValue jsValue) {
        Playlists::PlaylistProvider* providerPtr;
        fromScriptValue<Playlists::PlaylistProvider*,PlaylistProviderPrototype>( jsValue, providerPtr );
        return providerPtr;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=] (CollectionTreeItem* item) { return CollectionViewItem::toScriptValue( m_engine, item ); }
```

#### LAMBDA EXPRESSION 


```{c}
[this, action]() { m_actions.removeAll( action ); }
```

#### AUTO 


```{c}
auto nonConstThis = const_cast<CollectionTreeItemModelBase*>( this );
```

#### AUTO 


```{c}
auto widget = qobject_cast<QWidget*>( child );
```

#### AUTO 


```{c}
const auto &track
```

#### LAMBDA EXPRESSION 


```{c}
[=] (BookmarkGroupList bgList) { return toScriptArray<BookmarkGroupList>( m_engine, bgList ); }
```

#### AUTO 


```{c}
const auto &pFactory
```

#### AUTO 


```{c}
const auto album = dynamic_cast<const AlbumItem *>( item )
```

#### AUTO 


```{c}
const auto mt( QImageReader::supportedMimeTypes() );
```

#### AUTO 


```{c}
auto button = QMessageBox::question( The::mainWindow(),
                                                     i18n( "Move Podcasts" ),
                                                     i18n( "Do you want to move all downloaded episodes to the new location?") );
```

#### AUTO 


```{c}
const auto &tag
```

#### AUTO 


```{c}
auto buttonBox = new QDialogButtonBox( QDialogButtonBox::Ok | QDialogButtonBox::Cancel, dialog );
```

#### RANGE FOR STATEMENT 


```{c}
for( const StringIntPair &pair : pathsCounts )
    {
        TrackLoader *loader = new TrackLoader( TrackLoader::FullMetadataRequired );
        QSignalSpy spy( loader, &TrackLoader::finished );
        loader->init( QUrl::fromLocalFile( pair.first ) );

        QVERIFY2( spy.wait( 15000 ), "loader did not finish within timeout" );

        Meta::TrackList found = spy.first().first().value<Meta::TrackList>();
        QCOMPARE( found.count(), pair.second );
        for( const Meta::TrackPtr &track : found )
        {
            MetaProxy::TrackPtr proxyTrack = MetaProxy::TrackPtr::dynamicCast( track );
            if( !proxyTrack )
            {
                qDebug() << track->prettyUrl() << "is not a MetaProxy::Track. Strange and we cannot test it";
                continue;
            }
            QVERIFY2( proxyTrack->isResolved(), proxyTrack->prettyUrl().toLocal8Bit().data() );
        }
        delete loader;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const auto &resultVariant : object.value( "results" ).toArray() )
        {
            auto result = resultVariant.toObject();
            Meta::PlaydarTrackPtr aTrack;
            QUrl resultUrl( m_controller->urlForSid( result.value( "sid" ).toString() ) );
            
            QString trackSid = result.value( "sid" ).toString();
            QString trackUrl = resultUrl.url();
            QString trackTitle = result.value( "track" ).toString();
            QString trackArtist = result.value( "artist" ).toString();
            QString trackAlbum = result.value( "album" ).toString();
            QString trackType = result.value( "mimetype" ).toString();
            QString trackSource = result.value( "source" ).toString();
            qint64 trackLengthInSeconds( result.value( "duration" ).toInt() );
            aTrack = new Meta::PlaydarTrack
            (
                trackSid,
                trackUrl,
                trackTitle,
                trackArtist,
                trackAlbum,
                trackType,
                result.value( "score" ).toDouble() * 100,
                ( trackLengthInSeconds * 1000 ), //convert s to ms
                result.value( "bitrate" ).toInt(),
                result.value( "size" ).toInt(),
                trackSource
            );
            
            if( !m_solved && aTrack->score() >= 1.00 )
            {
                m_solved = true;
                m_trackList.prepend( aTrack );
                Q_EMIT querySolved( aTrack );
                
                if( m_waitForSolution )
                {
                    Q_EMIT queryDone( this, m_trackList );
                    return;
                }
            }
            else
            {
                m_trackList.append( aTrack );
            }
            Q_EMIT newTrackAdded( aTrack );
        }
```

#### LAMBDA EXPRESSION 


```{c}
[] (QJSValue jsValue) {
        Meta::TrackPtr trackPtr;
        fromScriptValue<Meta::TrackPtr, MetaTrackPrototype>( jsValue, trackPtr );
        return trackPtr;
    }
```

#### AUTO 


```{c}
const auto track = dynamic_cast<const TrackItem *>( item )
```

#### RANGE FOR STATEMENT 


```{c}
for( const auto &factory : factories )
    {
        bool callSucceeded = false;
        QStringList connectionErrors;

        callSucceeded = QMetaObject::invokeMethod( factory.data(),
                               "testSettings",
                               Q_RETURN_ARG( QStringList, connectionErrors ),
                               Q_ARG( QString, kcfg_Host->text() ),
                               Q_ARG( QString, kcfg_User->text() ),
                               Q_ARG( QString, kcfg_Password->text() ),
                               Q_ARG( int, kcfg_Port->text().toInt() ),
                               Q_ARG( QString, kcfg_Database->text() )
                               );

        if( callSucceeded )
        {
            if( connectionErrors.isEmpty() )
                KMessageBox::messageBox( this, KMessageBox::Information,
                                         i18n( "Amarok was able to establish a successful connection to the database." ),
                                         i18n( "Success" ) );
            else
                KMessageBox::error( this, i18n( "The amarok database reported "
                                                "the following errors:\n%1\nIn most cases you will need to resolve "
                                                "these errors before Amarok will run properly.",
                                    connectionErrors.join( QStringLiteral("\n") ) ),
                                    i18n( "Database Error" ));
        }
    }
```

#### AUTO 


```{c}
const auto applet
```

#### AUTO 


```{c}
auto &store = m_store[x];
```

#### LAMBDA EXPRESSION 


```{c}
[this, action]() { m_albumActions.removeAll( action ); }
```

#### LAMBDA EXPRESSION 


```{c}
[] (const KPluginMetaData &data)
                                     { return data.serviceTypes().contains(QStringLiteral("Amarok/ContextApplet")); }
```

#### RANGE FOR STATEMENT 


```{c}
for( const auto &photo : m_photos )
    {
        list << photo.urlpage;
    }
```

#### AUTO 


```{c}
auto m = static_cast<PlaylistBrowserNS::PlaylistBrowserModel*>(sourceModel())
```

#### AUTO 


```{c}
auto elements = m_domDocument->elementsByTagName( name );
```

#### AUTO 


```{c}
auto applets = loader->findPackages(QStringLiteral("Amarok/ContextApplet"),
                                        QString(),
                                        [] (const KPluginMetaData &data)
                                        { return data.serviceTypes().contains(QStringLiteral("Amarok/ContextApplet")); });
```

#### AUTO 


```{c}
auto lastPlayed = m_currentTrack->statistics()->lastPlayed();
```

#### RANGE FOR STATEMENT 


```{c}
for ( int deviceId : ids )
    {
        if( !folderMap.contains( deviceId ) )
        {
            folderConf.deleteEntry( QString::number( deviceId ) );
        }
    }
```

#### AUTO 


```{c}
auto d = new ExportDialog( activePreset() );
```

#### RANGE FOR STATEMENT 


```{c}
for( auto &track : m_tracks )
    {
        QVariantMap data = m_storedTags[ track ];
        //there is really no need to write to the file if only info m_stored in the db has changed
        if( !data.isEmpty() )
        {
            debug() << "File info changed....";

            auto lambda = [=] () mutable
            {
                if( data.contains( Meta::Field::SCORE ) )
                    track->statistics()->setScore( data.value( Meta::Field::SCORE ).toInt() );
                if( data.contains( Meta::Field::RATING ) )
                    track->statistics()->setRating( data.value( Meta::Field::RATING ).toInt() );
                if( data.contains( Meta::Field::LYRICS ) )
                    track->setCachedLyrics( data.value( Meta::Field::LYRICS ).toString() );

                QStringList labels = data.value( Meta::Field::LABELS ).toStringList();
                QHash<QString, Meta::LabelPtr> labelMap;
                for( const auto &label : track->labels() )
                    labelMap.insert( label->name(), label );

                // labels to remove
                for( const auto &label : labelMap.keys().toSet() - labels.toSet() )
                    track->removeLabel( labelMap.value( label ) );

                // labels to add
                for( const auto &label : labels.toSet() - labelMap.keys().toSet() )
                    track->addLabel( label );

                Meta::TrackEditorPtr ec = track->editor();
                if( !ec )
                {
                    debug() << "Track" << track->prettyUrl() << "does not have Meta::TrackEditor. Skipping.";
                    return;
                }

                ec->beginUpdate();

                if( data.contains( Meta::Field::TITLE ) )
                    ec->setTitle( data.value( Meta::Field::TITLE ).toString() );
                if( data.contains( Meta::Field::COMMENT ) )
                    ec->setComment( data.value( Meta::Field::COMMENT ).toString() );
                if( data.contains( Meta::Field::ARTIST ) )
                    ec->setArtist( data.value( Meta::Field::ARTIST ).toString() );
                if( data.contains( Meta::Field::ALBUM ) )
                    ec->setAlbum( data.value( Meta::Field::ALBUM ).toString() );
                if( data.contains( Meta::Field::GENRE ) )
                    ec->setGenre( data.value( Meta::Field::GENRE ).toString() );
                if( data.contains( Meta::Field::COMPOSER ) )
                    ec->setComposer( data.value( Meta::Field::COMPOSER ).toString() );
                if( data.contains( Meta::Field::YEAR ) )
                    ec->setYear( data.value( Meta::Field::YEAR ).toInt() );
                if( data.contains( Meta::Field::TRACKNUMBER ) )
                    ec->setTrackNumber( data.value( Meta::Field::TRACKNUMBER ).toInt() );
                if( data.contains( Meta::Field::DISCNUMBER ) )
                    ec->setDiscNumber( data.value( Meta::Field::DISCNUMBER ).toInt() );
                if( data.contains( Meta::Field::BPM ) )
                    ec->setBpm( data.value( Meta::Field::BPM ).toDouble() );
                if( data.contains( Meta::Field::ALBUMARTIST ) )
                    ec->setAlbumArtist( data.value( Meta::Field::ALBUMARTIST ).toString() );

                ec->endUpdate();
                // note: the track should by itself emit a collectionUpdated signal if needed
            };
            std::thread thread( lambda );
            thread.detach();
        }
    }
```

#### AUTO 


```{c}
const auto &package = m_packages.at(row);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &otherButton : other.buttons() )
        {
           this->addButton(otherButton,QDialogButtonBox::AcceptRole);
        }
```

#### AUTO 


```{c}
auto list = QUrl::fromStringList( resultRow );
```

#### LAMBDA EXPRESSION 


```{c}
[data] () {
        QMutexLocker locker( &s_mutex );
        s_progressList.removeAll( data );
    }
```

#### LAMBDA EXPRESSION 


```{c}
[] (QJSValue jsValue) {
        Collections::CollectionList collectionList;
        fromScriptArray<Collections::CollectionList>( jsValue, collectionList );
        return collectionList;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=] () { m_queue->add( album, CoverFetch::Automatic ); }
```

#### AUTO 


```{c}
auto closeButton = buttonBox->addButton( QDialogButtonBox::Close );
```

#### THREAD 


```{c}
std::thread thread( QOverload<const QString&, const char*, int>::of( &QImage::save ), image, cacheCoverPath, "PNG", -1 );
```

#### AUTO 


```{c}
auto factories = Plugins::PluginManager::instance()->factories( Plugins::PluginManager::Storage );
```

#### THREAD 


```{c}
std::thread thread( std::bind( &Meta::Album::setImage, album, image ) );
```

#### AUTO 


```{c}
auto &band
```

#### LAMBDA EXPRESSION 


```{c}
[]( const KPluginInfo &left, const KPluginInfo &right ){ return left.name() < right.name(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto applet : applets)
    {
        auto loader = KPackage::PackageLoader::self();
        auto structure = new AmarokContextPackageStructure;
        loader->addKnownPackageStructure(QStringLiteral("Amarok/Context"), structure);
        auto package = loader->loadPackage(QStringLiteral("Amarok/Context"), applet.pluginId());

        if (package.isValid())
        {
            m_packages << package;
        }
        else
            error() << "Error loading package:" << applet.pluginId();
    }
```

#### AUTO 


```{c}
auto result = resultVariant.toObject();
```

#### LAMBDA EXPRESSION 


```{c}
[] (QJSValue jsValue) {
        Playlists::PlaylistList playlistList;
        fromScriptArray<Playlists::PlaylistList>( jsValue, playlistList );
        return playlistList;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[] (const QString &a, const QString &b)  {
                  QStringList ae = Amarok::config("Context").readEntry("enabledApplets", QStringList());
                  return ae.indexOf(a) < ae.indexOf(b);
              }
```

#### RANGE FOR STATEMENT 


```{c}
for( const auto &factory : factories )
    {
        bool callSucceeded = false;
        QStringList connectionErrors;

        callSucceeded = QMetaObject::invokeMethod( factory.data(),
                               "testSettings",
                               Q_RETURN_ARG( QStringList, connectionErrors ),
                               Q_ARG( QString, kcfg_Host->text() ),
                               Q_ARG( QString, kcfg_User->text() ),
                               Q_ARG( QString, kcfg_Password->text() ),
                               Q_ARG( int, kcfg_Port->text().toInt() ),
                               Q_ARG( QString, kcfg_Database->text() )
                               );

        if( callSucceeded )
        {
            if( connectionErrors.isEmpty() )
                KMessageBox::messageBox( this, KMessageBox::Information,
                                         i18n( "Amarok was able to establish a successful connection to the database." ),
                                         i18n( "Success" ) );
            else
                KMessageBox::error( this, i18n( "The amarok database reported "
                                                "the following errors:\n%1\nIn most cases you will need to resolve "
                                                "these errors before Amarok will run properly.",
                                    connectionErrors.join( "\n" ) ),
                                    i18n( "Database Error" ));
        }
    }
```

#### AUTO 


```{c}
const auto &child
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString &applet : appletList )
    {
        // Currently we cannot extract the applet version number this way
        appletString += "   " + applet + '\n';
    }
```

#### AUTO 


```{c}
const auto &fadebar
```

#### AUTO 


```{c}
auto pluginFactory = qobject_cast<PluginFactory*>( loader.instance() );
```

#### LAMBDA EXPRESSION 


```{c}
[] ( const KPluginMetaData &metadata )
            { return metadata.serviceTypes().contains( QStringLiteral( "Amarok/Plugin" ) ); }
```

#### RANGE FOR STATEMENT 


```{c}
for( const auto &logger : s_loggers )
            logger->newProgressOperationImpl( reply, text, context, function, type );
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString& methodName : getStaticMethods() ) {
                    scopeObj.property( qTypeName )
                        .setProperty( methodName, classObj.property( methodName ) );
                }
```

#### RANGE FOR STATEMENT 


```{c}
for( const auto &aInfo : aPlugins )
    {
        aPluginString += "   " + aInfo.name() + " (" + aInfo.version() + ")\n";
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &applet : m_applets)
    {
        if (enabledApplets.contains(applet.pluginId()))
            list << applet;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const auto &logger : s_loggers )
        logger->longMessageImpl( text, type );
```

#### THREAD 


```{c}
std::thread thread( &Meta::Track::finishedPlaying, track, playedFraction );
```

#### RANGE FOR STATEMENT 


```{c}
for( const auto &pFactory : m_factories )
    {
        auto factory = qobject_cast<ServiceFactory*>( pFactory );
        if( !factory )
            continue;

        foreach( ServiceBase *service, factory->activeServices() )
            names << service->name();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, action]() { m_extraActions.removeAll( action ); }
```

#### AUTO 


```{c}
auto package = loader->loadPackage(QStringLiteral("Amarok/Context"), applet.pluginId());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &applet : m_applets)
    {
        debug() << "Applet found:" << applet.name();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const auto &scriptLocation : dir.entryList( QDir::NoDotAndDotDot | QDir::Dirs ) )
        {
            QDir scriptDir( dir.absoluteFilePath( scriptLocation ) );
            if( scriptDir.exists( QStringLiteral( "main.js" ) ) )
                foundScripts << scriptDir.absoluteFilePath( QStringLiteral( "main.js" ) );
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &applet : m_appletModel->loader()->enabledApplets())
    {
        list << applet.pluginId();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[] (QJSValue jsValue) {
        StringMap stringMap;
        fromScriptMap<StringMap>( jsValue, stringMap );
        return stringMap;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString &elem : ancestors )
                    {
                        m_checked.remove( elem );
                        if( elem < topAncestor || topAncestor.isEmpty() )
                            topAncestor = elem;
                    }
```

#### AUTO 


```{c}
auto m = static_cast<Playlist::Model*>(model())
```

#### RANGE FOR STATEMENT 


```{c}
for( const auto &photo : m_photos )
    {
        list << photo.urlphoto;
    }
```

#### AUTO 


```{c}
const auto &podcast
```

#### AUTO 


```{c}
auto l = static_cast<QBoxLayout*>( layout() );
```

#### RANGE FOR STATEMENT 


```{c}
for( auto &band : m_interpolatedScopeBands )
        {
            const double x = band.midK;
            auto &scope = m_currentScope[band.scopeIndex];

            // Search for the interval x is in, returning the corresponding y if x is one of the original xs
            int low = 0, mid, high = c3s.size() - 1;
            while ( low <= high )
            {
                mid = std::floor( 0.5 * ( low + high ) );
                double xHere = data[mid].x();
                if( xHere < x )
                    low = mid + 1;
                else if( xHere > x )
                    high = mid - 1;
                else
                    scope = data[mid].y();
            }
            int i = qMax( 0, high );

            // Interpolate
            double diff = x - data[i].x(), diffSq = diff * diff;
            scope = qMax( 0.0, data[i].y() + c1s[i] * diff + c2s[i] * diffSq + c3s[i] * diff * diffSq );
        }
```

#### RANGE FOR STATEMENT 


```{c}
for( const auto &pFactory : newFactories - oldFactories )
    {
        auto factory = qobject_cast<ServiceFactory*>( pFactory );
        if( !factory )
            continue;

        connect( factory.data(), &ServiceFactory::newService, this, &ServicePluginManager::slotNewService );
        connect( factory.data(), &ServiceFactory::removeService, this, &ServicePluginManager::slotRemoveService );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const auto &data : s_longMessageList )
        longMessageImpl( data.text, data.type );
```

#### AUTO 


```{c}
const auto &resultVariant
```

#### AUTO 


```{c}
auto sql =  StorageManager::instance()->sqlStorage();
```

#### RANGE FOR STATEMENT 


```{c}
for( auto &track : m_tracks )
    {
        QVariantMap data = m_storedTags[ track ];
        //there is really no need to write to the file if only info m_stored in the db has changed
        if( !data.isEmpty() )
        {
            debug() << "File info changed....";

            auto lambda = [=] () mutable
            {
                if( data.contains( Meta::Field::SCORE ) )
                    track->statistics()->setScore( data.value( Meta::Field::SCORE ).toInt() );
                if( data.contains( Meta::Field::RATING ) )
                    track->statistics()->setRating( data.value( Meta::Field::RATING ).toInt() );
                if( data.contains( Meta::Field::LYRICS ) )
                    track->setCachedLyrics( data.value( Meta::Field::LYRICS ).toString() );

                QStringList labels = data.value( Meta::Field::LABELS ).toStringList();
                QHash<QString, Meta::LabelPtr> labelMap;
                for( const auto &label : track->labels() )
                    labelMap.insert( label->name(), label );

                // labels to remove
                for( const auto &label : labelMap.keys().toSet() - labels.toSet() )
                    track->removeLabel( labelMap.value( label ) );

                // labels to add
                for( const auto &label : labels.toSet() - labelMap.keys().toSet() )
                    track->addLabel( label );

                Meta::TrackEditorPtr ec = track->editor();
                if( !ec )
                {
                    debug() << "Track" << track->prettyUrl() << "does not have Meta::TrackEditor. Skipping.";
                    return;
                }

                ec->beginUpdate();

                if( data.contains( Meta::Field::TITLE ) )
                    ec->setTitle( data.value( Meta::Field::TITLE ).toString() );
                if( data.contains( Meta::Field::COMMENT ) )
                    ec->setComment( data.value( Meta::Field::COMMENT ).toString() );
                if( data.contains( Meta::Field::ARTIST ) )
                    ec->setArtist( data.value( Meta::Field::ARTIST ).toString() );
                if( data.contains( Meta::Field::ALBUM ) )
                    ec->setAlbum( data.value( Meta::Field::ALBUM ).toString() );
                if( data.contains( Meta::Field::GENRE ) )
                    ec->setGenre( data.value( Meta::Field::GENRE ).toString() );
                if( data.contains( Meta::Field::COMPOSER ) )
                    ec->setComposer( data.value( Meta::Field::COMPOSER ).toString() );
                if( data.contains( Meta::Field::YEAR ) )
                    ec->setYear( data.value( Meta::Field::YEAR ).toInt() );
                if( data.contains( Meta::Field::TRACKNUMBER ) )
                    ec->setTrackNumber( data.value( Meta::Field::TRACKNUMBER ).toInt() );
                if( data.contains( Meta::Field::DISCNUMBER ) )
                    ec->setDiscNumber( data.value( Meta::Field::DISCNUMBER ).toInt() );
                if( data.contains( Meta::Field::BPM ) )
                    ec->setBpm( data.value( Meta::Field::BPM ).toDouble() );
                if( data.contains( Meta::Field::ALBUMARTIST ) )
                    ec->setAlbumArtist( data.value( Meta::Field::ALBUMARTIST ).toString() );

                ec->endUpdate();
                // note: the track should by itself Q_EMIT a collectionUpdated signal if needed
            };
            std::thread thread( lambda );
            thread.detach();
        }
    }
```

#### AUTO 


```{c}
auto doc = QJsonDocument::fromJson( storedQueryJob->data(), &err );
```

#### LAMBDA EXPRESSION 


```{c}
[=] (StringMap stringMap) { return toScriptMap<StringMap>( engine, stringMap); }
```

#### AUTO 


```{c}
auto slot = std::bind( &CollectionTreeItemModelBase::tracksLoaded, m_model, m_album, m_index, tracks );
```

#### RANGE FOR STATEMENT 


```{c}
for( const auto &mimetype : mt )
        mimetypes << QString( mimetype );
```

#### AUTO 


```{c}
auto album
```

#### LAMBDA EXPRESSION 


```{c}
[=] (QJSValue jsValue) {
        CollectionTreeItem* item;
        fromScriptValue<CollectionTreeItem*, CollectionViewItem>( jsValue, item );
        return item;
    }
```

#### AUTO 


```{c}
auto object = doc.object();
```

#### LAMBDA EXPRESSION 


```{c}
[] (QJSValue jsValue) {
        Meta::FieldHash fieldHash;
        fromScriptTagMap( jsValue, fieldHash );
        return fieldHash;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &package : m_packages)
    {
        auto metadata = package.metadata();

        if (metadata.pluginId() == id)
            return package;
    }
```

#### AUTO 


```{c}
auto job = KIO::get( m_url, KIO::NoReload, KIO::HideProgressInfo );
```

#### RANGE FOR STATEMENT 


```{c}
for( const auto &factory : factories )
    {
        // check the meta object if there is a testSettings slot available
        if( factory->metaObject()->
            indexOfMethod( QMetaObject::normalizedSignature("testSettings(QString, QString, QString, int, QString)" ) ) >= 0 )
            testFunctionAvailable = true;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const auto &applet : applets )
    {
        appletNames << applet.pluginId();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (T arrayObj) { return toScriptArray( this, arrayObj ); }
```

#### AUTO 


```{c}
auto buttonBox = new QDialogButtonBox( QDialogButtonBox::Ok | QDialogButtonBox::Cancel | QDialogButtonBox::Apply, m_providerSettingsDialog );
```

#### AUTO 


```{c}
auto button = QMessageBox::question( The::mainWindow(),
                                         i18n( "Confirm Playlist Deletion" ),
                                         i18nc( "%1 is playlist provider pretty name",
                                                "Delete playlist from %1.", providerNames.join( ", " ) ),
                                         QMessageBox::Yes | QMessageBox::No,
                                         QMessageBox::Yes );
```

#### LAMBDA EXPRESSION 


```{c}
[this, action]() { m_artistActions.removeAll( action ); }
```

#### AUTO 


```{c}
auto menu = new QMenu( item );
```

#### AUTO 


```{c}
auto configureItem = KStandardGuiItem::configure();
```

#### AUTO 


```{c}
auto scannerJob = QSharedPointer<GenericScannerJob>( new GenericScannerJob( this, scanDirsSet.values(), type ) );
```

#### AUTO 


```{c}
const auto &logger
```

#### AUTO 


```{c}
auto db = StorageManager::instance()->sqlStorage();
```

#### AUTO 


```{c}
auto doc = QJsonDocument::fromJson( storedStatusJob->data(), &err );
```

#### RANGE FOR STATEMENT 


```{c}
for( const auto &applet : enabledApplets() )
    {
        setAppletEnabled( applet, false );
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=] () { m_queue->add( unit->album(), unit->options(), payload->source(), data );
                                                 m_queue->remove( unit ); }
```

#### AUTO 


```{c}
auto p = static_cast<Playlist::PrettyListView*>(parent)
```

#### AUTO 


```{c}
auto model = Context::ContextView::self()->appletModel();
```

#### AUTO 


```{c}
const auto &aInfo
```

#### AUTO 


```{c}
auto factory = qobject_cast<ProviderFactory*>( pFactory );
```

#### LAMBDA EXPRESSION 


```{c}
[text] () {
        QMutexLocker locker( &s_mutex );
        s_shortMessageList.removeAll( text );
    }
```

#### AUTO 


```{c}
auto sqlStorage = StorageManager::instance()->sqlStorage();
```

#### AUTO 


```{c}
const auto currentTrack = The::engineController()->currentTrack();
```

#### RANGE FOR STATEMENT 


```{c}
for( const auto &label : labelMap.keys().toSet() - labels.toSet() )
                    track->removeLabel( labelMap.value( label ) );
```

#### AUTO 


```{c}
auto dialog = qobject_cast<Amarok2ConfigDialog*>(m_parent)
```

#### AUTO 


```{c}
auto structure = new AmarokContextPackageStructure;
```

#### RANGE FOR STATEMENT 


```{c}
for( const auto &pFactory : oldFactories - newFactories )
    {
        auto factory = qobject_cast<ServiceFactory*>( pFactory );
        if( !factory )
            continue;

        foreach( ServiceBase * service, factory->activeServices() )
            ServiceBrowser::instance()->removeCategory( service );
        factory->clearActiveServices();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &applet : applets)
    {
        auto loader = KPackage::PackageLoader::self();
        auto structure = new AmarokContextPackageStructure;
        loader->addKnownPackageStructure(QStringLiteral("Amarok/Context"), structure);
        auto package = loader->loadPackage(QStringLiteral("Amarok/Context"), applet.pluginId());

        if (package.isValid())
        {
            m_packages << package;
        }
        else
            error() << "Error loading package:" << applet.pluginId();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=] (Meta::TrackList trackList) { return toScriptArray<Meta::TrackList>( engine, trackList); }
```

#### AUTO 


```{c}
auto qmlPackage = KPackage::PackageLoader::self()->loadPackage( QStringLiteral( "KPackage/GenericQML" ),
                                                                    QStringLiteral( "org.kde.amarok.context" ) );
```

#### AUTO 


```{c}
auto job = KIO::storedGet( ocsPerson.avatarUrl(), KIO::NoReload, KIO::HideProgressInfo );
```

#### AUTO 


```{c}
auto endSlot = m_progressBar->staticMetaObject.method( endIndex );
```

#### AUTO 


```{c}
auto lambda = [=] () mutable
            {
                if( data.contains( Meta::Field::SCORE ) )
                    track->statistics()->setScore( data.value( Meta::Field::SCORE ).toInt() );
                if( data.contains( Meta::Field::RATING ) )
                    track->statistics()->setRating( data.value( Meta::Field::RATING ).toInt() );
                if( data.contains( Meta::Field::LYRICS ) )
                    track->setCachedLyrics( data.value( Meta::Field::LYRICS ).toString() );

                QStringList labels = data.value( Meta::Field::LABELS ).toStringList();
                QHash<QString, Meta::LabelPtr> labelMap;
                for( const auto &label : track->labels() )
                    labelMap.insert( label->name(), label );

                // labels to remove
                for( const auto &label : labelMap.keys().toSet() - labels.toSet() )
                    track->removeLabel( labelMap.value( label ) );

                // labels to add
                for( const auto &label : labels.toSet() - labelMap.keys().toSet() )
                    track->addLabel( label );

                Meta::TrackEditorPtr ec = track->editor();
                if( !ec )
                {
                    debug() << "Track" << track->prettyUrl() << "does not have Meta::TrackEditor. Skipping.";
                    return;
                }

                ec->beginUpdate();

                if( data.contains( Meta::Field::TITLE ) )
                    ec->setTitle( data.value( Meta::Field::TITLE ).toString() );
                if( data.contains( Meta::Field::COMMENT ) )
                    ec->setComment( data.value( Meta::Field::COMMENT ).toString() );
                if( data.contains( Meta::Field::ARTIST ) )
                    ec->setArtist( data.value( Meta::Field::ARTIST ).toString() );
                if( data.contains( Meta::Field::ALBUM ) )
                    ec->setAlbum( data.value( Meta::Field::ALBUM ).toString() );
                if( data.contains( Meta::Field::GENRE ) )
                    ec->setGenre( data.value( Meta::Field::GENRE ).toString() );
                if( data.contains( Meta::Field::COMPOSER ) )
                    ec->setComposer( data.value( Meta::Field::COMPOSER ).toString() );
                if( data.contains( Meta::Field::YEAR ) )
                    ec->setYear( data.value( Meta::Field::YEAR ).toInt() );
                if( data.contains( Meta::Field::TRACKNUMBER ) )
                    ec->setTrackNumber( data.value( Meta::Field::TRACKNUMBER ).toInt() );
                if( data.contains( Meta::Field::DISCNUMBER ) )
                    ec->setDiscNumber( data.value( Meta::Field::DISCNUMBER ).toInt() );
                if( data.contains( Meta::Field::BPM ) )
                    ec->setBpm( data.value( Meta::Field::BPM ).toDouble() );
                if( data.contains( Meta::Field::ALBUMARTIST ) )
                    ec->setAlbumArtist( data.value( Meta::Field::ALBUMARTIST ).toString() );

                ec->endUpdate();
                // note: the track should by itself emit a collectionUpdated signal if needed
            };
```

#### AUTO 


```{c}
auto album = AmarokSharedPointer<Meta::MagnatuneAlbum>::dynamicCast( dataPtr )
```

#### AUTO 


```{c}
const auto aPluginManager = Plugins::PluginManager::instance();
```

#### LAMBDA EXPRESSION 


```{c}
[this, action]() { m_yearActions.removeAll( action ); }
```

#### RANGE FOR STATEMENT 


```{c}
for( const Meta::TrackPtr &t : tl ) {
        l += t->length();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=] (Dynamic::TrackSet trackSet) { return toScriptValue( engine, trackSet ); }
```

#### AUTO 


```{c}
const auto &it
```

#### AUTO 


```{c}
auto index = createIndex(row, 0);
```

#### AUTO 


```{c}
const auto tracks = m_album->tracks();
```

#### AUTO 


```{c}
auto worker = qobject_cast<const BlockWorker*>(analyzer->worker());
```

#### AUTO 


```{c}
auto sqlDb = StorageManager::instance()->sqlStorage();
```

#### AUTO 


```{c}
auto group = BookmarkGroupPtr::dynamicCast( item )
```

#### LAMBDA EXPRESSION 


```{c}
[] (QJSValue scriptObj) {
                    Map mapObj;
                    fromScriptMap( scriptObj, mapObj );
                    return mapObj;
                }
```

#### AUTO 


```{c}
auto endSlot = m_progressBar->metaObject()->method( endIndex );
```

#### LAMBDA EXPRESSION 


```{c}
[=] () { m_queue->remove( unit ); }
```

#### RANGE FOR STATEMENT 


```{c}
for( const auto &plugin : plugins )
    {
        bool enabled = isPluginEnabled( plugin );
        debug() << "found plugin:" << plugin.pluginId()
                << "enabled:" << enabled;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[] (QJSValue jsValue) {
        AmarokUrlPtr url;
        fromScriptValue<AmarokUrlPtr, BookmarkPrototype>( jsValue, url );
        return url;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const auto &location : locations )
        if( m_fileName.startsWith( location ) )
            relativePath = m_fileName.remove( location );
```

#### RANGE FOR STATEMENT 


```{c}
for( const auto &track : tracks )
        {
            if( numberOfDiscs < track->discNumber() )
                numberOfDiscs = track->discNumber();

            TrackItem *trackItem = new TrackItem();
            trackItem->setTrack( track );

            // bold the current track to make it more visible
            if( m_currentTrack && m_currentTrack == track )
            {
                trackItem->bold();
            }

            // If compilation and same artist, then highlight, but only if there's a current track
            if( m_currentTrack
                && m_currentTrack->artist() && track->artist()
                && album->isCompilation() )
            {
                trackItem->italicise();
            }
            trackItems.insert( track->discNumber(), trackItem );
        }
```

#### AUTO 


```{c}
auto window = App::instance()->mainWindow()
```

#### AUTO 


```{c}
auto buttonBox = m_providerSettingsDialog->findChild<QDialogButtonBox*>();
```

#### RANGE FOR STATEMENT 


```{c}
for( const auto &factory : m_providerFactories )
        dialog->addProviderType( factory->type(), factory->prettyName(),
                                 factory->icon(), factory->createConfigWidget() );
```

#### THREAD 


```{c}
std::thread thread( lambda );
```

#### RANGE FOR STATEMENT 


```{c}
for( const auto &pluginInfo : m_plugins )
    {
        // create the factories and sort them by type
        auto factory = createFactory( pluginInfo );

        if( factory )
        {
            Type type;

            if( qobject_cast<StorageFactory*>( factory ) )
                type = Storage;
            else if( qobject_cast<Collections::CollectionFactory*>( factory ) )
                type = Collection;
            else if( qobject_cast<ServiceFactory*>( factory ) )
                type = Service;
            else if( qobject_cast<StatSyncing::ProviderFactory*>( factory ) )
                type = Importer;
            else
            {
                warning() << pluginInfo.name() << "has unknown category";
                warning() << pluginInfo.rawData().keys();
                continue;
            }

            m_pluginsByType[ type ] << pluginInfo;

            if( isPluginEnabled( pluginInfo ) )
                m_factoriesByType[ type ] << factory;
        }
        else
            warning() << pluginInfo.name() << "could not create factory";
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const auto &pFactory : factories )
    {
        auto factory = qobject_cast<StorageFactory*>( pFactory );
        if( !factory )
            continue;

        connect( factory.data(), &StorageFactory::newStorage,
                 this, &StorageManager::slotNewStorage );
        connect( factory.data(), &StorageFactory::newError,
                 this, &StorageManager::slotNewError );
    }
```

#### AUTO 


```{c}
auto storage = QSharedPointer<MySqlServerStorage>::create();
```

#### LAMBDA EXPRESSION 


```{c}
[] (QJSValue jsValue) {
        BookmarkList bList;
        fromScriptArray<BookmarkList>( jsValue, bList );
        return bList;
    }
```

#### AUTO 


```{c}
auto button = QMessageBox::question( The::mainWindow(),
                                         i18n( "Confirm Playlist Deletion" ),
                                         i18nc( "%1 is playlist provider pretty name",
                                                "Delete playlist from %1.", providerNames.join( QStringLiteral(", ") ) ),
                                         QMessageBox::Yes | QMessageBox::No,
                                         QMessageBox::Yes );
```

#### AUTO 


```{c}
auto coll = m_collectionMap[ key ];
```

#### RANGE FOR STATEMENT 


```{c}
for( auto album : albums )
    {
        // do not show all tracks without an album from the collection, this takes ages
        // TODO: show all tracks from this artist that are not part of an album
        if( album->name().isEmpty() )
            continue;

        Meta::TrackList tracks = album->tracks();
        if( tracks.isEmpty() )
            continue;

        AlbumItem *albumItem = new AlbumItem();
        albumItem->setIconSize( 50 );
        albumItem->setAlbum( album );
        albumItem->setShowArtist( !m_currentTrack );

        int numberOfDiscs = 0;
        int childRow = 0;

        std::stable_sort( tracks.begin(), tracks.end(), Meta::Track::lessThan );

        QMultiHash< int, TrackItem* > trackItems; // hash of tracks items for each disc
        for( const auto &track : tracks )
        {
            if( numberOfDiscs < track->discNumber() )
                numberOfDiscs = track->discNumber();

            TrackItem *trackItem = new TrackItem();
            trackItem->setTrack( track );

            // bold the current track to make it more visible
            if( m_currentTrack && m_currentTrack == track )
            {
                trackItem->bold();
            }

            // If compilation and same artist, then highlight, but only if there's a current track
            if( m_currentTrack
                && m_currentTrack->artist() && track->artist()
                && album->isCompilation() )
            {
                trackItem->italicise();
            }
            trackItems.insert( track->discNumber(), trackItem );
        }

        for( int i = 0; i <= numberOfDiscs; ++i )
        {
            QList<TrackItem*> items = trackItems.values( i );
            if( !items.isEmpty() )
            {
                const TrackItem *item = items.first();
                QStandardItem *discItem( 0 );
                if( numberOfDiscs > 1 )
                {
                    discItem = new QStandardItem( i18n("Disc %1", item->track()->discNumber()) );
                    albumItem->setChild( childRow++, discItem );
                    int discChildRow = 0;
                    foreach( TrackItem *trackItem, items )
                        discItem->setChild( discChildRow++, trackItem );
                }
                else
                {
                    foreach( TrackItem *trackItem, items )
                        albumItem->setChild( childRow++, trackItem );
                }
            }
        }
        m_model->appendRow( albumItem );
    }
```

#### THREAD 


```{c}
std::thread thread( QOverload<const QString&, const char*, int>::of( &QPixmap::save ), pixmap, cacheCoverDir.filePath( noCoverKey ), "PNG", -1 );
```

#### LAMBDA EXPRESSION 


```{c}
[=] (AmarokUrlPtr url) { return toScriptValue<AmarokUrlPtr, BookmarkPrototype>( m_engine, url ); }
```

#### RANGE FOR STATEMENT 


```{c}
for( const Meta::TrackPtr &track : found )
        {
            MetaProxy::TrackPtr proxyTrack = MetaProxy::TrackPtr::dynamicCast( track );
            if( !proxyTrack )
            {
                qDebug() << track->prettyUrl() << "is not a MetaProxy::Track. Strange and we cannot test it";
                continue;
            }
            QVERIFY2( proxyTrack->isResolved(), proxyTrack->prettyUrl().toLocal8Bit().data() );
        }
```

#### AUTO 


```{c}
auto childMenuButton = new BreadcrumbItemMenuButton( m_breadcrumbArea );
```

#### LAMBDA EXPRESSION 


```{c}
[&wiki] ( const QString& tagStart, const QString& tagEnd )
    {
        const int tagEndSize = tagEnd.size();
        int matchIndex = 0;
        const QStringMatcher tagMatcher( tagStart );
        while( ( matchIndex = tagMatcher.indexIn( wiki, matchIndex ) ) != -1 )
        {
            const int nToTagEnd = wiki.indexOf( tagEnd, matchIndex ) - matchIndex;
            const QStringRef tagRef = wiki.midRef( matchIndex, nToTagEnd + tagEndSize );
            wiki.remove( tagRef.toString() );
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const auto &pFactory : newFactories - oldFactories )
    {
        auto factory = qobject_cast<CollectionFactory*>( pFactory );
        if( !factory )
            continue;

        connect( factory.data(), &CollectionFactory::newCollection,
                 this, &CollectionManager::slotNewCollection );
        {
            QWriteLocker locker( &d->lock );
            d->factories.append( factory );
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const auto &pFactory : factories )
    {
        auto factory = qobject_cast<ProviderFactory*>( pFactory );
        if( !factory )
            continue;

        if( m_providerFactories.contains( factory->type() ) ) // we have it already
            continue;

        m_providerFactories.insert( factory->type(), factory );
    }
```

#### AUTO 


```{c}
auto analyzer = qobject_cast<BlockAnalyzer*>(item);
```

#### AUTO 


```{c}
auto p = static_cast<Amarok2ConfigDialog*>(parent)
```

#### AUTO 


```{c}
auto button = QMessageBox::question( The::mainWindow(),
                                             i18n( "Confirm Delete" ),
                                             i18n( "Are you sure you want to delete this folder and its contents?" ) );
```

#### RANGE FOR STATEMENT 


```{c}
for( const auto &e : errors() )
            error( e.description() );
```

#### LAMBDA EXPRESSION 


```{c}
[] ( QtMsgType type, const QMessageLogContext &context, const QString &msg )
    {
        Q_UNUSED( type );
        QString category(context.category);
        if ( category.compare( "js" ) == 0 ) {

            QString scriptName( context.file );
            // clean "file:" from file name
            scriptName.remove( 0, 5);

            // Search script by name
            ScriptConsoleItem *searchResult = instance()->getScriptListDockWidget()->getScript( scriptName );
            if (searchResult != nullptr ) {
                // Found it - update its console widget
                QString logEntry = QString("[%1: %2] %3")
                .arg( scriptName )
                .arg( context.line )
                .arg( msg );
                searchResult->appendToConsoleWidget( logEntry );
            }
        }

        // Print all QT logging to STDERR as default
        std::cerr << msg.toStdString() << std::endl;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const auto &factory : m_factoriesByType[ Collection ] )
        factory->init();
```

#### RANGE FOR STATEMENT 


```{c}
for( int artistId : qAsConst(d->parentArtistIds) )
            artists << d->collection->artistById( artistId );
```

#### LAMBDA EXPRESSION 


```{c}
[this, indexes] () { appendSelected( indexes ); }
```

#### AUTO 


```{c}
auto applets = m_loader->enabledApplets();
```

#### RANGE FOR STATEMENT 


```{c}
for( const auto &it : m_collectionMap )
    {
        if( it.data() == collection )
        {
            m_collectionMap.remove( m_collectionMap.key( it ) );
            break;
        }
    }
```

#### AUTO 


```{c}
auto closeItem = KStandardGuiItem::close();
```

#### RANGE FOR STATEMENT 


```{c}
for( const QString &folder : folders )
    {
        int id = getIdForUrl( QUrl::fromLocalFile(folder) );
        const QString rpath = getRelativePath( id, folder );
        if( folderMap.contains( id ) ) {
            if( !folderMap[id].contains( rpath ) )
                folderMap[id].append( rpath );
        }
        else
            folderMap[id] = QStringList( rpath );
    }
```

#### AUTO 


```{c}
auto directoryWatcher = m_directoryWatcher.toStrongRef()
```

#### RANGE FOR STATEMENT 


```{c}
for( const auto &data : s_progressList )
    {
        if( data.job )
            newProgressOperationImpl( data.job, data.text, data.cancelObject, data.function, data.type );
        else if( data.reply )
            newProgressOperationImpl( data.reply, data.text, data.cancelObject, data.function, data.type );
        else if( data.sender )
            newProgressOperationImpl( data.sender, data.increment, data.end, data.text, data.maximum, data.cancelObject, data.function, data.type );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const auto &child : m_dialog->children() )
        {
            auto widget = qobject_cast<QWidget*>( child );
            if( widget )
            {
                widget->hide(); // otherwise it may last as a ghost image
                widget->deleteLater();
            }
        }
```

#### AUTO 


```{c}
auto syncedPlaylist = SyncedPlaylistPtr::dynamicCast( playlist )
```

#### AUTO 


```{c}
const auto aScriptManager = ScriptManager::instance();
```

#### LAMBDA EXPRESSION 


```{c}
[] (QJSValue jsValue) {
            BookmarkGroupPtr bGroup;
            fromScriptValue<BookmarkGroupPtr, BookmarkGroupPrototype>( jsValue, bGroup );
            return bGroup;
        }
```

#### AUTO 


```{c}
auto bookmark = AmarokUrlPtr::dynamicCast( item )
```

#### RANGE FOR STATEMENT 


```{c}
for( const auto &factory : m_factoriesByType[ Importer ] )
        factory->init();
```

#### AUTO 


```{c}
auto incrementSlot = m_progressBar->metaObject()->method( incrementIndex );
```

#### AUTO 


```{c}
auto info = KPluginInfo( pluginInfo );
```

#### LAMBDA EXPRESSION 


```{c}
[=] (BookmarkList bList) { return toScriptArray<BookmarkList>( m_engine, bList); }
```

#### RANGE FOR STATEMENT 


```{c}
for( const auto &label : labels.toSet() - labelMap.keys().toSet() )
                    track->addLabel( label );
```

#### LAMBDA EXPRESSION 


```{c}
[] (QJSValue jsValue) {
        Dynamic::TrackSet trackSet;
        fromScriptValue( jsValue, trackSet );
        return trackSet;
    }
```

#### AUTO 


```{c}
const auto &package
```

#### AUTO 


```{c}
const auto &mimetype
```

#### RANGE FOR STATEMENT 


```{c}
for( const QModelIndex &index : indexes )
    {
        if( index.isValid() )
        {
            const QModelIndex &srcIndex = m_proxyModel->mapToSource( index );
            const QStandardItem *item = m_model->itemFromIndex( srcIndex );
            if( item->type() == AlbumType )
            {
                selected << static_cast<const AlbumItem*>( item )->album()->tracks();
            }
            else if( item->type() == TrackType )
            {
                selected << static_cast<const TrackItem*>( item )->track();
            }
            else if( m_model->hasChildren( srcIndex ) ) // disc type
            {
                for( int i = m_model->rowCount( srcIndex ) - 1; i >= 0; --i )
                {
                    const QStandardItem *trackItem = m_model->itemFromIndex( m_model->index(i, 0, srcIndex) );
                    selected << static_cast<const TrackItem*>( trackItem )->track();
                }
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QFileInfo &fi : fileInfos )
    {
        if( !fi.exists() )
            continue;

        const QFileInfo &f = fi.isSymLink() ? QFileInfo( fi.symLinkTarget() ) : fi;

        if( !f.exists() )
            continue;

        if( f.isDir() )
        {
            addDir( QString( f.absoluteFilePath() + '/' ), entries );
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const auto &logger : s_loggers )
            logger->newProgressOperationImpl( sender, increment, end, text, maximum, context, function, type );
```

#### AUTO 


```{c}
auto playlistDock = The::mainWindow()->playlistDock();
```

#### LAMBDA EXPRESSION 


```{c}
[=] () { m_queue->add( album, CoverFetch::Interactive, fetchSource() ); }
```

#### RANGE FOR STATEMENT 


```{c}
for( BrowserBreadcrumbItem *addItem : additionalItems )
            {
                //hack to ensure that we have not already added it to the front of the breadcrumb...
                addBreadCrumbItem( addItem );
            }
```

#### RANGE FOR STATEMENT 


```{c}
for( const auto &photo : m_photos )
    {
        list << photo.title;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const auto &pFactory : oldFactories - newFactories )
    {

        auto factory = qobject_cast<CollectionFactory*>( pFactory );
        if( !factory )
            continue;

        disconnect( factory.data(), &CollectionFactory::newCollection,
                    this, &CollectionManager::slotNewCollection );
        {
            QWriteLocker locker( &d->lock );
            d->factories.removeAll( factory );
        }
    }
```

#### AUTO 


```{c}
auto element = elements.at( 0 );
```

#### RANGE FOR STATEMENT 


```{c}
for( const QString &line : lines )
        {
            formatAvailable |= format->verifyAvailability( line );
            if( formatAvailable )
                break;
        }
```

#### AUTO 


```{c}
const auto &photo
```

#### RANGE FOR STATEMENT 


```{c}
for( const auto& band : m_notInterpolatedScopeBands )
    {
        m_currentScope[band.scopeIndex] = 0.0;
        uint numValues = 0;
        for( long k = std::lround( std::ceil( band.lowerK ) ); k <= std::lround( std::floor( band.upperK ) ); k++ )
        {
            m_currentScope[band.scopeIndex] += std::abs( m_out[k] ) * sqrt( k );
            numValues++;
        }
        m_currentScope[band.scopeIndex] /= numValues;
        m_currentScope[band.scopeIndex] /= m_size / 2;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[] (QJSValue jsValue) {
        BookmarkGroupList bgList;
        fromScriptArray<BookmarkGroupList>( jsValue, bgList );
        return bgList;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=] () {  m_queue->remove( unit ); }
```

#### AUTO 


```{c}
auto &track
```

#### LAMBDA EXPRESSION 


```{c}
[=] (QueryMaker* queryMaker) { return toScriptValue<QueryMaker*, QueryMakerPrototype>( engine, queryMaker ); }
```

#### AUTO 


```{c}
auto job = KIO::http_post( m_url, postData.toUtf8(), KIO::HideProgressInfo );
```

#### AUTO 


```{c}
auto item
```

#### AUTO 


```{c}
const auto &data
```

#### RANGE FOR STATEMENT 


```{c}
for( const auto &pluginInfo : m_pluginsByType.value( type ) )
    {
        auto info = KPluginInfo( pluginInfo );
        info.setConfig( Amarok::config( "Plugins" ) );
        infos << info;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[] (const AppletPackage &p1, const AppletPackage &p2) {
        return p1.metadata().name() < p2.metadata().name();
    }
```

#### AUTO 


```{c}
auto scannerJob = m_scannerJob.toStrongRef();
```

#### AUTO 


```{c}
auto &otherButton
```

#### AUTO 


```{c}
auto mimetypes = QStringList() << QStringLiteral("image/svg+xml");
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &fadebar : qAsConst(fadebars.at(x)))
            {
                if(fadebar.intensity > 0)
                {
                    const uint offset = fadebar.intensity;
                    const int fadeHeight = fadebar.y * (BLOCK_HEIGHT + 1);
                    if(fadeHeight > 0)
                        p.drawPixmap(x * (m_columnWidth + 1), 0, m_fadeBarsPixmaps.value(offset), 0, 0, m_columnWidth, fadeHeight);
                }
            }
```

#### AUTO 


```{c}
auto buttonBox = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel);
```

#### AUTO 


```{c}
auto factory = qobject_cast<StorageFactory*>( pFactory );
```

#### AUTO 


```{c}
auto scannerJob = QSharedPointer<GenericScannerJob>( new GenericScannerJob( this, scanDirsSet.toList(), type ) );
```

#### AUTO 


```{c}
const auto scopeData = scope();
```

#### AUTO 


```{c}
auto &fadebars = m_fadebars[x];
```

#### AUTO 


```{c}
auto lambda = [=] () mutable
            {
                if( data.contains( Meta::Field::SCORE ) )
                    track->statistics()->setScore( data.value( Meta::Field::SCORE ).toInt() );
                if( data.contains( Meta::Field::RATING ) )
                    track->statistics()->setRating( data.value( Meta::Field::RATING ).toInt() );
                if( data.contains( Meta::Field::LYRICS ) )
                    track->setCachedLyrics( data.value( Meta::Field::LYRICS ).toString() );

                QStringList labels = data.value( Meta::Field::LABELS ).toStringList();
                QHash<QString, Meta::LabelPtr> labelMap;
                for( const auto &label : track->labels() )
                    labelMap.insert( label->name(), label );

                // labels to remove
                for( const auto &label : labelMap.keys().toSet() - labels.toSet() )
                    track->removeLabel( labelMap.value( label ) );

                // labels to add
                for( const auto &label : labels.toSet() - labelMap.keys().toSet() )
                    track->addLabel( label );

                Meta::TrackEditorPtr ec = track->editor();
                if( !ec )
                {
                    debug() << "Track" << track->prettyUrl() << "does not have Meta::TrackEditor. Skipping.";
                    return;
                }

                ec->beginUpdate();

                if( data.contains( Meta::Field::TITLE ) )
                    ec->setTitle( data.value( Meta::Field::TITLE ).toString() );
                if( data.contains( Meta::Field::COMMENT ) )
                    ec->setComment( data.value( Meta::Field::COMMENT ).toString() );
                if( data.contains( Meta::Field::ARTIST ) )
                    ec->setArtist( data.value( Meta::Field::ARTIST ).toString() );
                if( data.contains( Meta::Field::ALBUM ) )
                    ec->setAlbum( data.value( Meta::Field::ALBUM ).toString() );
                if( data.contains( Meta::Field::GENRE ) )
                    ec->setGenre( data.value( Meta::Field::GENRE ).toString() );
                if( data.contains( Meta::Field::COMPOSER ) )
                    ec->setComposer( data.value( Meta::Field::COMPOSER ).toString() );
                if( data.contains( Meta::Field::YEAR ) )
                    ec->setYear( data.value( Meta::Field::YEAR ).toInt() );
                if( data.contains( Meta::Field::TRACKNUMBER ) )
                    ec->setTrackNumber( data.value( Meta::Field::TRACKNUMBER ).toInt() );
                if( data.contains( Meta::Field::DISCNUMBER ) )
                    ec->setDiscNumber( data.value( Meta::Field::DISCNUMBER ).toInt() );
                if( data.contains( Meta::Field::BPM ) )
                    ec->setBpm( data.value( Meta::Field::BPM ).toDouble() );
                if( data.contains( Meta::Field::ALBUMARTIST ) )
                    ec->setAlbumArtist( data.value( Meta::Field::ALBUMARTIST ).toString() );

                ec->endUpdate();
                // note: the track should by itself Q_EMIT a collectionUpdated signal if needed
            };
```

