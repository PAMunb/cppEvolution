#### LAMBDA EXPRESSION 


```{c}
[&](KIO::Job *, const KIO::UDSEntryList &l) { list.append(l); }
```

#### RANGE FOR STATEMENT 


```{c}
for( KFileMetaData::ExtractorPlugin* plugin : d->metaDataPluginManager.fetchExtractors( d->mimeType.name() ) )
        {
            ExtractionResult extractionResult(m_fileName, d->mimeType.name(), d->metaInfoMap);
            plugin->extract(&extractionResult);
        }
```

#### AUTO 


```{c}
const auto buttonId = d->buttons.count();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &metadata : metadataList) {
        KPluginFactory::Result<K3b::Plugin> result = KPluginFactory::instantiatePlugin<K3b::Plugin>(metadata);
        if (result) {
            K3b::Plugin *plugin = result.plugin;
            plugin->d->metadata = metadata;
            qDebug() << "Loaded plugin" << metadata.metaDataFileName();
            d->plugins.append(plugin);
        } else {
            qDebug() << "failed to load plugin" << metadata.metaDataFileName();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&](KJob*){
            if( statJob->error() == KJob::NoError )
                uds = statJob->statResult();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&](KJob*){
                        if( deleteJob->error() != KJob::NoError ) {
                            qDebug() << "(K3b::CdrdaoWriter) delete tocfile backkup " << m_backupTocFile << " failed.";
                        }
                    }
```

#### LAMBDA EXPRESSION 


```{c}
[&](KJob*) { exists = ( statJob->error() != KJob::NoError ); }
```

#### LAMBDA EXPRESSION 


```{c}
[&](KAuth::Action::AuthStatus status)
    {
        if( status == KAuth::Action::AuthorizedStatus ||
            status == KAuth::Action::AuthRequiredStatus ) {
            m_messageWidget->removeAction(m_addToGroupAction);
            m_messageWidget->setMessageType(KMessageWidget::Information);
            m_messageWidget->setText(i18n("Please relogin to apply the changes."));
        } else if( status == KAuth::Action::DeniedStatus ||
                   status == KAuth::Action::ErrorStatus ||
                   status == KAuth::Action::InvalidStatus ) {
            m_messageWidget->setText(i18n("Unable to execute the action: %1", job->errorString()));
            m_addToGroupAction->setText(i18n("Retry"));
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&](KJob*) {
            if( statJob->error() != KJob::NoError )
                size += K3b::filesize( nextUrl );
            else
                exists = false;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&](KJob*) {
        if( transferJob->error() != KJob::NoError ) {
            tmpfile.open();
            tmpfile.write( transferJob->data() );
            tmpfile.close();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const QList<KNSCore::Entry> &changedEntries) {
        if (!changedEntries.isEmpty()) {
	    m_themeModel->reload();
	}
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&](KJob* job){ result = ( job->error() != KJob::NoError ); }
```

#### RANGE FOR STATEMENT 


```{c}
for( KFileMetaData::Extractor* plugin : d->metaDataCollection->fetchExtractors( d->mimeType.name() ) )
        {
            ExtractionResult extractionResult(m_fileName, d->mimeType.name(), d->metaInfoMap);
            plugin->extract(&extractionResult);
        }
```

#### AUTO 


```{c}
auto *job = new KIO::OpenUrlJob( url, item->mimeType().name() );
```

#### LAMBDA EXPRESSION 


```{c}
[&](KAuth::Action::AuthStatus status)
    {
        if( status == KAuth::Action::AuthorizedStatus ||
            status == KAuth::Action::AuthRequiredStatus ) {
            // Success!!
            QStringList updated = job->data()["updated"].toStringList();
            QStringList failedToUpdate = job->data()["failedToUpdate"].toStringList();
            qDebug() << "Objects updated: " << updated;
            qDebug() << "Objects failed to update: " << failedToUpdate;

            if (!failedToUpdate.isEmpty()) {
                KMessageBox::errorList(this, i18n("Following programs could not be updated:"), failedToUpdate);
            }

            m_permissionModel->update();
        } else if( status == KAuth::Action::DeniedStatus ||
                   status == KAuth::Action::ErrorStatus ||
                   status == KAuth::Action::InvalidStatus ) {
            KMessageBox::error(this, i18n("Unable to execute the action: %1", job->errorString()));
        }
    }
```

#### AUTO 


```{c}
auto& url
```

#### AUTO 


```{c}
const auto result = KPluginFactory::instantiatePlugin<KCModule>(KPluginMetaData(QStringLiteral("kcm_cddb")), this);
```

#### RANGE FOR STATEMENT 


```{c}
for( QString url : m_cmdLine->positionalArguments() ) {
            m_mainWindow->openDocument( QUrl::fromUserInput( url ) );
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, buttonId]() { done(buttonId); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](){
        buttonBox()->button(QDialogButtonBox::Apply)->setDefault(true);
    }
```

#### AUTO 


```{c}
const auto videoDir =
#if QT_VERSION < 0x050900
        d->tempDir->path() + "/VIDEO_TS";
```

#### LAMBDA EXPRESSION 


```{c}
[&](KIO::Job *, const KIO::UDSEntryList &l) { list = l; }
```

#### LAMBDA EXPRESSION 


```{c}
[this, job]()
    {
        if( job->error() == KJob::NoError ) {
            // Success!!
            QStringList updated = job->data()["updated"].toStringList();
            QStringList failedToUpdate = job->data()["failedToUpdate"].toStringList();
            qDebug() << "Objects updated: " << updated;
            qDebug() << "Objects failed to update: " << failedToUpdate;

            if (!failedToUpdate.isEmpty()) {
                KMessageBox::errorList(this, i18n("Following programs could not be updated:"), failedToUpdate);
            }

            m_permissionModel->update();
        } else {
            KMessageBox::error(this, i18n("Unable to execute the action: %1", job->errorString()));
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const QList<KNS3::Entry> &changedEntries) {
        if (!changedEntries.isEmpty()) {
	    m_themeModel->reload();
	}
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&](KJob*) {
            if( statJob->error() == KJob::NoError )
                result = statJob->mostLocalUrl();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&](KJob*) {
                if( copyJob->error() != KJob::NoError ) {
                    qDebug() << "(K3b::CdrdaoWriter) restoring tocfile " << m_tocFile << " failed.";
                    emit infoMessage( i18n("Due to a bug in cdrdao the toc/cue file %1 has been deleted. "
                                           "K3b was unable to restore it from the backup %2.",m_tocFile,m_backupTocFile), MessageError );
                } else {
                    KIO::DeleteJob* deleteJob = KIO::del(QUrl::fromLocalFile(m_backupTocFile), KIO::HideProgressInfo);
                    connect( deleteJob, &KJob::result, [&](KJob*){
                        if( deleteJob->error() != KJob::NoError ) {
                            qDebug() << "(K3b::CdrdaoWriter) delete tocfile backkup " << m_backupTocFile << " failed.";
                        }
                    } );
                    deleteJob->exec();
                }
            }
```

#### AUTO 


```{c}
auto *dlg = new DataUrlAddingDialog( urls, dir, parent );
```

#### LAMBDA EXPRESSION 


```{c}
[&](KJob*) {
        if( transferJob->error() != KJob::NoError ) {
            themeTmpFile.open();
            themeTmpFile.write( transferJob->data() );
            themeTmpFile.close();
        } else {
            transferJobSucceed = false;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &metadata : metadataList) {
        KPluginLoader loader(metadata.fileName());
        KPluginFactory *factory = loader.factory();
        if (auto *plugin = factory->create<K3b::Plugin>()) {
            plugin->d->metadata = metadata;
            qDebug() << "Loaded plugin" << metadata.metaDataFileName();
            d->plugins.append(plugin);
        } else {
            qDebug() << "failed to load plugin" << metadata.metaDataFileName();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( KFileMetaData::Extractor* plugin : d->metaDataCollection.fetchExtractors( d->mimeType.name() ) )
        {
            ExtractionResult extractionResult(m_fileName, d->mimeType.name(), d->metaInfoMap);
            plugin->extract(&extractionResult);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, job]()
    {
        if( job->error() == KJob::NoError ) {
            m_messageWidget->removeAction(m_addToGroupAction);
            m_messageWidget->setMessageType(KMessageWidget::Information);
            m_messageWidget->setText(i18n("Please relogin to apply the changes."));
        } else {
            m_messageWidget->setMessageType(KMessageWidget::Error);
            m_messageWidget->setText(i18n("Unable to execute the action: %1 (Error code: %2)", job->errorString(), job->error()));
            m_addToGroupAction->setText(i18n("Retry"));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QString line : lines) {
        QString perStr = line;
        perStr.truncate(perStr.indexOf('%'));
        QRegExp rx("(\\d+.|,+\\d)");
        QStringList list;
        int pos = 0;
        while ((pos = rx.indexIn(perStr, pos)) != -1) {
            list << rx.cap(1);
            pos += rx.matchedLength();
        }
        if (list.size() > 1)
            qDebug() << "DEBUG:" << __PRETTY_FUNCTION__ << list[0].replace(',', '.') + list[1];
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&](KJob*) {
                    if( copyJob->error() != KJob::NoError ) {
                        qDebug() << "(K3b::CdrdaoWriter) could not backup " << m_tocFile << " to " << m_backupTocFile;
                        emit infoMessage( i18n("Could not backup tocfile."), MessageError );
                        jobFinished(false);
                        copyJobSucceed = false;
                    }
                }
```

#### LAMBDA EXPRESSION 


```{c}
[&](KJob*) {
      if( transferJob->error() != KJob::NoError ) {
        tmpFile.open();
        tmpFile.write( transferJob->data() );
        tmpFile.close();
      } else {
        downloaded = false;
      }
    }
```

#### AUTO 


```{c}
const auto &metadata
```

#### LAMBDA EXPRESSION 


```{c}
[&](QAbstractButton *button) {
            switch( buttonBox->standardButton( button ) )
            {
            case QDialogButtonBox::Ok: dlg.accept(); break;
            case QDialogButtonBox::Cancel: dlg.reject(); break;
            case QDialogButtonBox::RestoreDefaults: moduleProxy->defaults(); break;
            default: break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for( QString url : m_cmdLine->positionalArguments() ) {
            urls.append( QUrl::fromUserInput( url ) );
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&](KJob*) {
            if( copyJob->error() != KJob::NoError ) {
                emit infoMessage( i18n("Failed to backup boot image file %1",item->localPath()), MessageError );
                copyJobSucceed = false;
            }
        }
```

#### AUTO 


```{c}
auto *dlg = new DataUrlAddingDialog( items, dir, true, parent );
```

#### LAMBDA EXPRESSION 


```{c}
[this]{ Q_EMIT changed(); }
```

#### RANGE FOR STATEMENT 


```{c}
for( auto& url : urls ) { urlList.push_back( QUrl::fromUserInput( url ) ); }
```

#### AUTO 


```{c}
auto *dlg = new DataUrlAddingDialog( items, dir, false, parent );
```

#### AUTO 


```{c}
auto *plugin = factory->create<K3b::Plugin>()
```

