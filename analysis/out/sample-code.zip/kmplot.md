#### RANGE FOR STATEMENT 


```{c}
for ( const Value &y : qAsConst(state->y0) )
			{
				if ( !first )
					ys += ';';
				first = false;
				ys += y.expression();
			}
```

#### RANGE FOR STATEMENT 


```{c}
for ( Equation * eq : qAsConst(f->eq) )
		eq->differentialStates.resetToInitial();
```

#### LAMBDA EXPRESSION 


```{c}
[previewWidget, printSettingsDialog]{
				previewWidget->updatePreview();
				printSettingsDialog->close();
			}
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString &name : constantNames )
		strings[name] = ConstantString;
```

#### LAMBDA EXPRESSION 


```{c}
[this]{
		QClipboard * cb = QApplication::clipboard();
		cb->setText( QLocale().toString( m_rootValue, 'f', 5 ), QClipboard::Clipboard );
	}
```

#### LAMBDA EXPRESSION 


```{c}
[previewWidget, printSettingsDialog] {
                previewWidget->updatePreview();
                printSettingsDialog->close();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const Value &it : qAsConst(item->m_parameters.list) )
		str_parameter << it.expression();
```

#### RANGE FOR STATEMENT 


```{c}
for (Plot plot : qAsConst(list)) {
                plot.pmSignature = pmSignature;
                duplicated << plot;
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (int row : indexes)
        m_model->removeRows(-row, 1, QModelIndex());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &mimeType : QImageWriter::supportedMimeTypes()) {
		const QString filter = mimeDatabase.mimeTypeForName(QLatin1String(mimeType)).filterString();
		if (!filter.isEmpty()) {
			if (mimeType == QByteArrayLiteral("image/png")) {
				if (!filters.isEmpty()) {
					filters.prepend(QStringLiteral(";;"));
				}
				filters.prepend(filter);
			} else {
				if (!filters.isEmpty()) {
					filters.append(QStringLiteral(";;"));
                                }
				filters.append(filter);
			}
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for ( Equation * eq : qAsConst(it->eq) )
		{
			if ( eq->looksLikeFunction() && (name == eq->name()) )
				return it->id();
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (Function *function : qAsConst(XParser::self()->m_ufkt)) {
        if (function->type() != Function::Cartesian && function->type() != Function::Differential)
            continue;

        QList<Plot> plots = function->plots();

        for (int i = 0; i < function->eq.size(); ++i) {
            for (const Plot &plot : qAsConst(plots))
                m_equations << EquationPair(plot, i);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( Function * it : qAsConst(m_ufkt) )
	{
		for ( int i = 0; i < it->eq.size(); ++i )
		{
			if ( !match( it->eq[i]->name()) )
				continue;
			
			if ( it->eq[i] == m_currentEquation || (m_currentEquation && it->dependsOn( m_currentEquation->parent() )) )
			{
				*m_error = RecursiveFunctionCall;
				return true;
			}
			
			int argCount = readFunctionArguments();
			if ( argCount != it->eq[i]->variables().size() )
			{
				*m_error = IncorrectArgumentCount;
				return true;
			}
			
			addToken(UFKT);
			addfptr( it->id(), i, argCount );
			if ( m_currentEquation->parent() )
				m_currentEquation->parent()->addFunctionDependency( it );
			
			return true;
		}
	}
```

#### LAMBDA EXPRESSION 


```{c}
[preview, previewWidget, printdlg]{
			QDialog *printSettingsDialog = new QDialog( preview, Qt::WindowFlags() );
			printSettingsDialog->setWindowTitle( i18nc("@title:window", "Print Settings") );
			QVBoxLayout *mainLayout = new QVBoxLayout;
			printSettingsDialog->setLayout(mainLayout);
			mainLayout->addWidget(printdlg);
			QDialogButtonBox *buttonBox = new QDialogButtonBox( QDialogButtonBox::Ok|QDialogButtonBox::Cancel );
			connect(buttonBox, &QDialogButtonBox::accepted, [previewWidget, printSettingsDialog]{
				previewWidget->updatePreview();
				printSettingsDialog->close();
			} );
			connect(buttonBox, &QDialogButtonBox::rejected, printSettingsDialog, &QDialog::reject);
			mainLayout->addWidget(buttonBox);
			printSettingsDialog->show();
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (Function *f : m_ufkt) {
        for (Equation *eq : f->eq)
            initEquation(eq);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( Function * it : qAsConst(m_ufkt) )
	{
		for ( Equation * eq : qAsConst(it->eq) )
		{
			if ( eq->looksLikeFunction() && (name == eq->name()) )
				return it->id();
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for ( double root : qAsConst(roots) )
	{
		QPointF rv = realValue( plot, root, false );
		if ( (type == Maximum && rv.y() > best) || (type == Minimum && rv.y() < best) )
		{
			best = rv.y();
			bestPoint = QPointF(rv.x(), rv.y());
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (Equation *equation : qAsConst(eq)) {
                int pmCount = equation->pmCount();
                QVector<bool> sig(pmCount);
                for (int i = 0; i < pmCount; ++i)
                    sig[i] = signature[i + at];
                at += pmCount;

                pmSignature << sig;
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Plot &plot : qAsConst(plots))
                m_equations << EquationPair(plot, i);
```

#### RANGE FOR STATEMENT 


```{c}
for (Equation *eq : qAsConst(it->eq)) {
            if (eq->looksLikeFunction() && (name == eq->name()))
                return it->id();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Function *function : qAsConst(XParser::self()->m_ufkt)) {
        if (m_stopCalculating)
            break;

        for (const Plot &plot : function->plots()) {
            plot.updateFunction();

            // Draw extrema points?
            if ((function->type() == Function::Cartesian) && function->plotAppearance(plot.plotMode).showExtrema) {
                const QList<QPointF> stationaryPoints = findStationaryPoints(plot);
                for (const QPointF &realValue : stationaryPoints) {
                    painter->setPen(QPen(Qt::black, millimetersToPixels(1.5, painter->device())));
                    painter->drawPoint(toPixel(realValue));

                    QString x = posToString(realValue.x(), (m_xmax - m_xmin) / m_clipRect.width(), View::DecimalFormat);
                    QString y = posToString(realValue.y(), (m_ymax - m_ymin) / m_clipRect.width(), View::DecimalFormat);

                    drawLabel(painter,
                              plot.color(),
                              realValue,
                              i18nc("Extrema point", "x = %1   y = %2", x.replace('.', QLocale().decimalPoint()), y.replace('.', QLocale().decimalPoint())));
                }
            }

            // Show the name of the plot?
            if (function->plotAppearance(plot.plotMode).showPlotName) {
                double x, y;

                double xmin = m_xmin + 0.1 * (m_xmax - m_xmin);
                double xmax = m_xmax - 0.1 * (m_xmax - m_xmin);
                double ymin = m_ymin + 0.1 * (m_ymax - m_ymin);
                double ymax = m_ymax - 0.1 * (m_ymax - m_ymin);

                // Find out where on the outer edge of the view to draw it
                if (0 <= plotNameAt && plotNameAt <= 2) {
                    x = xmax;
                    y = ymax - (ymax - ymin) * plotNameAt / 2;
                } else if (3 <= plotNameAt && plotNameAt <= 5) {
                    x = xmax - (xmax - xmin) * (plotNameAt - 2) / 3;
                    y = ymin;
                } else if (6 <= plotNameAt && plotNameAt <= 7) {
                    x = xmin;
                    y = ymin + (ymax - ymin) * (plotNameAt - 5) / 2;
                } else {
                    x = xmin + (xmax - xmin) * (plotNameAt - 7) / 3;
                    y = ymax;
                }

                plotNameAt = (plotNameAt + 1) % 10;

                QPointF realPos;

                if (function->type() == Function::Implicit) {
                    findRoot(&x, &y, plot, RoughRoot);
                    realPos = QPointF(x, y);
                } else {
                    double t = getClosestPoint(QPointF(x, y), plot);
                    realPos = realValue(plot, t, false);
                }

                // If the closest point isn't in the view, then don't draw the label
                if (realPos.x() < m_xmin || realPos.x() > m_xmax || realPos.y() < m_ymin || realPos.y() > m_ymax)
                    continue;

                drawLabel(painter, plot.color(), realPos, plot.name());
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &mimeType : QImageWriter::supportedMimeTypes()) {
        const QString filter = mimeDatabase.mimeTypeForName(QLatin1String(mimeType)).filterString();
        if (!filter.isEmpty()) {
            if (mimeType == QByteArrayLiteral("image/png")) {
                if (!filters.isEmpty()) {
                    filters.prepend(QStringLiteral(";;"));
                }
                filters.prepend(filter);
            } else {
                if (!filters.isEmpty()) {
                    filters.append(QStringLiteral(";;"));
                }
                filters.append(filter);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
CONNECT_WIDGETS(EquationEdit, editingFinished())
```

#### RANGE FOR STATEMENT 


```{c}
for (const QPointF &point : qAsConst(singular)) {
            // radius of circle around singular point
            double epsilon = qMin(FuzzyPoint::dx, FuzzyPoint::dy);

            QString fstr;
            fstr = QString("%1(x)=%2(%3+%6*cos(x),%4+%6*sin(x)%5)")
                       .arg(circular.function()->eq[0]->name())
                       .arg(function->eq[0]->name())
                       .arg(XParser::self()->number(point.x()))
                       .arg(XParser::self()->number(point.y()))
                       .arg(function->eq[0]->usesParameter() ? ',' + XParser::self()->number(function->k) : QString())
                       .arg(XParser::self()->number(epsilon));

            bool setFstrOk = circular.function()->eq[0]->setFstr(fstr);
            qDebug() << "------------ " << setFstrOk;
            assert(setFstrOk);

            QList<double> roots = findRoots(circular, 0, 2 * M_PI / XParser::self()->radiansPerAngleUnit(), PreciseRoot);

#ifdef DEBUG_IMPLICIT
            qDebug() << "Singular point at (x,y)=(" << point.x() << ',' << point.y() << ")\n";
            qDebug() << "fstr is    " << fstr;
            qDebug() << "Found " << roots.size() << " roots.\n";
#endif

            for (double t : qAsConst(roots)) {
#ifdef DEBUG_IMPLICIT
                painter->setPen(QPen(Qt::green, painter->pen().width()));
#endif
                double x = point.x() + epsilon * lcos(t);
                double y = point.y() + epsilon * lsin(t);
                drawImplicitInSquare(plot, painter, x, y, {}, &singular);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Equation *eq : f->eq)
            initEquation(eq);
```

#### RANGE FOR STATEMENT 


```{c}
for ( Function * it : qAsConst(m_ufkt) )
	{
		if ( int(it->id()) == id )
			continue;
		
		for ( Equation * eq : qAsConst(it->eq) )
		{
			if ( eq->name() != fname )
				continue;
			
			str = str.mid(p1,str.length()-1);
			QString function_name;
			if ( type == Equation::ParametricX )
				function_name = 'x';
			else if ( type == Equation::ParametricY )
				function_name = 'y';
			else
				function_name = 'f';
			function_name = findFunctionName( function_name, id );
			str.prepend( function_name );
			return;
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (double root : qAsConst(roots)) {
        QPointF rv = realValue(plot, root, false);
        if ((type == Maximum && rv.y() > best) || (type == Minimum && rv.y() < best)) {
            best = rv.y();
            bestPoint = QPointF(rv.x(), rv.y());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QString s : listSplit) {
            s = s.remove(' ');
            if (!s.isEmpty())
                m_variables << s;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Plot &plot : plots) {
            plot.updateFunction();

            double best_x = 0.0, distance;
            QPointF cspos;

            if (function->type() == Function::Implicit) {
                double x = m_crosshairPosition.x();
                double y = m_crosshairPosition.y();
                findRoot(&x, &y, plot, PreciseRoot);

                QPointF d = toPixel(QPointF(x, y), ClipInfinite) - toPixel(QPointF(m_crosshairPosition.x(), m_crosshairPosition.y()), ClipInfinite);

                distance = std::sqrt(d.x() * d.x() + d.y() * d.y());
                cspos = QPointF(x, y);
            } else {
                best_x = getClosestPoint(m_crosshairPosition, plot);
                distance = pixelDistance(m_crosshairPosition, plot, best_x, false);
                cspos = realValue(plot, best_x, false);
            }

            if (distance < best_distance) {
                best_distance = distance;
                bestPlot = plot;
                m_trace_x = best_x;
                best_cspos = cspos;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( Equation * equation : qAsConst(eq) )
			{
				int pmCount = equation->pmCount();
				QVector<bool> sig( pmCount );
				for ( int i = 0; i < pmCount; ++i )
					sig[i] = signature[ i + at];
				at += pmCount;
			
				pmSignature << sig;
			}
```

#### RANGE FOR STATEMENT 


```{c}
for (Plot plot : qAsConst(list)) {
                if (!plotAppearance(p).visible)
                    continue;
                plot.plotMode = p;
                duplicated << plot;
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (double t : qAsConst(roots)) {
#ifdef DEBUG_IMPLICIT
                painter->setPen(QPen(Qt::green, painter->pen().width()));
#endif
                double x = point.x() + epsilon * lcos(t);
                double y = point.y() + epsilon * lsin(t);
                drawImplicitInSquare(plot, painter, x, y, {}, &singular);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (Function *function : qAsConst(XParser::self()->m_ufkt)) {
        at += 1;

        if (m_stopCalculating)
            break;

        // 		QDBusInterface( QDBus::sessionBus().baseService(), "/kmplot", "org.kde.kmplot.KmPlot" ).call( QDBus::Block, "setDrawProgress", at/numPlots );

        if (function->type() == Function::Implicit)
            drawImplicit(function, &painter);
        else
            drawFunction(function, &painter);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[preview, previewWidget, printdlg, &prt]{
			QDialog *printSettingsDialog = new QDialog( preview, Qt::WindowFlags() );
			printSettingsDialog->setWindowTitle( i18n("Print Settings") );
			QVBoxLayout *mainLayout = new QVBoxLayout;
			printSettingsDialog->setLayout(mainLayout);
			mainLayout->addWidget(printdlg);
			QDialogButtonBox *buttonBox = new QDialogButtonBox( QDialogButtonBox::Ok|QDialogButtonBox::Cancel );
			connect(buttonBox, &QDialogButtonBox::accepted, [previewWidget, printSettingsDialog]{
				previewWidget->updatePreview();
				printSettingsDialog->close();
			} );
			connect(buttonBox, &QDialogButtonBox::rejected, printSettingsDialog, &QDialog::reject);
			mainLayout->addWidget(buttonBox);
			printSettingsDialog->show();
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (EquationEdit *edit : qAsConst(m_equationEdits)) {
        if (edit->equation()->usesParameter() || !edit->equation()->looksLikeFunction())
            continue;

        QString text = edit->text();
        int bracket = text.indexOf(')');
        if (bracket < 0)
            continue;

        text.replace(bracket, 1, ",k)");
        edit->setText(text);
    }
```

#### AUTO 


```{c}
const auto result = KPluginFactory::instantiatePlugin<KParts::ReadWritePart>(KPluginMetaData(QStringLiteral("kf5/parts/kmplotpart")), this);
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QGradientStop &stop : qAsConst(stops) )
		string += QString( "%1;%2," ).arg( stop.first ).arg( stop.second.name() );
```

#### RANGE FOR STATEMENT 


```{c}
for ( const Plot &plot : plots )
		{
			plot.updateFunction();
			
			double best_x = 0.0, distance;
			QPointF cspos;
			
			if ( function->type() == Function::Implicit )
			{
				double x = m_crosshairPosition.x();
				double y = m_crosshairPosition.y();
				findRoot( & x, & y, plot, PreciseRoot );
				
				QPointF d = toPixel( QPointF( x, y ), ClipInfinite ) - toPixel( QPointF( m_crosshairPosition.x(), m_crosshairPosition.y() ), ClipInfinite );
				
				distance = std::sqrt( d.x()*d.x() + d.y()*d.y() );
				cspos = QPointF( x, y );
			}
			else
			{
				best_x = getClosestPoint( m_crosshairPosition, plot );
				distance = pixelDistance( m_crosshairPosition, plot, best_x, false );
				cspos = realValue( plot, best_x, false );
			}

			if ( distance < best_distance )
			{
				best_distance = distance;
				bestPlot = plot;
				m_trace_x = best_x;
				best_cspos = cspos;
			}
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &var : variables)
        sorted.insert(-var.length(), var);
```

#### RANGE FOR STATEMENT 


```{c}
for ( QString s : listSplit ) {
			s = s.remove(' ');
			if ( !s.isEmpty() )
				m_variables << s;
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (Function *it : qAsConst(m_ufkt)) {
        if (int(it->id()) == id)
            continue;

        for (Equation *eq : qAsConst(it->eq)) {
            if (eq->name() != fname)
                continue;

            str = str.mid(p1, str.length() - 1);
            QString function_name;
            if (type == Equation::ParametricX)
                function_name = 'x';
            else if (type == Equation::ParametricY)
                function_name = 'y';
            else
                function_name = 'f';
            function_name = findFunctionName(function_name, id);
            str.prepend(function_name);
            return;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( Equation * equation : qAsConst(eq) )
			size += equation->pmCount();
```

#### RANGE FOR STATEMENT 


```{c}
for (QListWidgetItem *item : qAsConst(items)) {
        int f = static_cast<FunctionListItem *>(item)->function();

        if (Function *function = XParser::self()->functionWithID(f))
            io.addFunction(doc, root, function);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const Value &k : qAsConst(function->m_parameters.list) )
		str_parameters << k.expression();
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QPointF &point : qAsConst(singular) )
		{
			// radius of circle around singular point
			double epsilon = qMin( FuzzyPoint::dx, FuzzyPoint::dy );
			
			QString fstr;
			fstr = QString("%1(x)=%2(%3+%6*cos(x),%4+%6*sin(x)%5)")
					.arg( circular.function()->eq[0]->name() )
					.arg( function->eq[0]->name() )
					.arg( XParser::self()->number( point.x() ) )
					.arg( XParser::self()->number( point.y() ) )
					.arg( function->eq[0]->usesParameter() ? ',' + XParser::self()->number( function->k ) : QString() )
					.arg( XParser::self()->number( epsilon ) );
			
			bool setFstrOk = circular.function()->eq[0]->setFstr( fstr );
                        qDebug() << "------------ " << setFstrOk << endl;
			assert( setFstrOk );
			
			QList<double> roots = findRoots( circular, 0, 2*M_PI / XParser::self()->radiansPerAngleUnit(), PreciseRoot );
			
#ifdef DEBUG_IMPLICIT
			qDebug() << "Singular point at (x,y)=("<<point.x()<<','<<point.y()<<")\n";
			qDebug() << "fstr is    " << fstr;
			qDebug() << "Found " << roots.size() << " roots.\n";
#endif
			
			for ( double t : qAsConst(roots) )
			{	
#ifdef DEBUG_IMPLICIT
				painter->setPen( QPen( Qt::green, painter->pen().width() ) );
#endif
				double x = point.x() + epsilon * lcos(t);
				double y = point.y() + epsilon * lsin(t);
				drawImplicitInSquare( plot, painter, x, y, 0, & singular );
			}
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (Function *function : qAsConst(XParser::self()->m_ufkt)) {
        const QList<Plot> plots = function->plots();
        for (const Plot &plot : plots) {
            plot.updateFunction();

            double best_x = 0.0, distance;
            QPointF cspos;

            if (function->type() == Function::Implicit) {
                double x = m_crosshairPosition.x();
                double y = m_crosshairPosition.y();
                findRoot(&x, &y, plot, PreciseRoot);

                QPointF d = toPixel(QPointF(x, y), ClipInfinite) - toPixel(QPointF(m_crosshairPosition.x(), m_crosshairPosition.y()), ClipInfinite);

                distance = std::sqrt(d.x() * d.x() + d.y() * d.y());
                cspos = QPointF(x, y);
            } else {
                best_x = getClosestPoint(m_crosshairPosition, plot);
                distance = pixelDistance(m_crosshairPosition, plot, best_x, false);
                cspos = realValue(plot, best_x, false);
            }

            if (distance < best_distance) {
                best_distance = distance;
                bestPlot = plot;
                m_trace_x = best_x;
                best_cspos = cspos;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Function *it : qAsConst(m_ufkt)) {
                if (int(it->id()) == id)
                    continue;

                for (Equation *eq : qAsConst(it->eq)) {
                    for (const QString &pattern : neededPatterns) {
                        if (eq->name() == pattern.arg(name))
                            ok = false;
                    }
                }

                if (!ok)
                    break;
            }
```

#### RANGE FOR STATEMENT 


```{c}
for ( Equation * e : qAsConst(eq) )
		delete e;
```

#### RANGE FOR STATEMENT 


```{c}
for ( Function * f : qAsConst(m_ufkt) )
	{
		for ( Equation * eq : qAsConst(f->eq) )
		{
			if ( !eq->name().isEmpty() )
				names << eq->name();
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QModelIndex &index : selected )
		sorted.insert( -index.row(), 0l );
```

#### RANGE FOR STATEMENT 


```{c}
CONNECT_WIDGETS( QLineEdit, editingFinished() )
```

#### LAMBDA EXPRESSION 


```{c}
[] {
        QClipboard *cb = QApplication::clipboard();
        QPointF currentXY = View::self()->getCrosshairPosition();
        cb->setText(
            i18nc("Copied pair of coordinates (x, y)", "(%1, %2)", QLocale().toString(currentXY.x(), 'f', 5), QLocale().toString(currentXY.y(), 'f', 5)),
            QClipboard::Clipboard);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Equation *eq : qAsConst(it->eq)) {
                    for (const QString &pattern : neededPatterns) {
                        if (eq->name() == pattern.arg(name))
                            ok = false;
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for ( Function * it : qAsConst(XParser::self()->m_ufkt) )
	{
		if ( it->m_parameters.useSlider && !it->allPlotsAreHidden() )
		{
			needSliderWindow = true;
			break;
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (double x : qAsConst(roots)) {
#ifdef DEBUG_IMPLICIT
                painter->setPen(QPen(Qt::red, painter->pen().width()));
#endif
                drawImplicitInSquare(plot, painter, x, y, Qt::Horizontal, &singular);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& var : variables) {
			if (remaining.startsWith(var)) {
				setFormat(i, var.length(), variable);
				i += var.length() - 1;
				found = true;
				break;
			}
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (Equation *eq : qAsConst(it->eq))
            strings[eq->name()] = FunctionString;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &name : constantNames)
        strings[name] = ConstantString;
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QPointF &realValue : stationaryPoints )
				{
					painter->setPen( QPen( Qt::black, millimetersToPixels( 1.5, painter->device() ) ) );
					painter->drawPoint( toPixel( realValue ) );
					
					QString x = posToString( realValue.x(), (m_xmax-m_xmin)/m_clipRect.width(), View::DecimalFormat );
					QString y = posToString( realValue.y(), (m_ymax-m_ymin)/m_clipRect.width(), View::DecimalFormat );
					
					drawLabel( painter, plot.color(), realValue, i18nc( "Extrema point", "x = %1   y = %2", x.replace('.', QLocale().decimalPoint()), y.replace('.', QLocale().decimalPoint()) ) );
				}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QGradientStop &stop : stops)
        drawArrow(&painter, stop);
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        QClipboard *cb = QApplication::clipboard();
        cb->setText(QLocale().toString(m_rootValue, 'f', 5), QClipboard::Clipboard);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( int functionId : qAsConst(m_dependencies) )
	{
		Function * f = XParser::self()->functionWithID( functionId );
		
		if ( f->dependsOn( function ) )
			return true;
	}
```

#### RANGE FOR STATEMENT 


```{c}
for ( const Value &v : qAsConst(*m_parameter) )
		m_mainWidget->list->addItem( v.expression() );
```

#### RANGE FOR STATEMENT 


```{c}
for ( EquationEdit * edit : qAsConst(m_equationEdits) )
	{
		if ( edit->equation()->usesParameter() || !edit->equation()->looksLikeFunction() )
			continue;
		
		QString text = edit->text();
		int bracket = text.indexOf( ')' );
		if ( bracket < 0 )
			continue;
		
		text.replace( bracket, 1, ",k)" );
		edit->setText( text );
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (Plot plot : qAsConst(list)) {
                plot.stateNumber = i;
                duplicated << plot;
            }
```

#### RANGE FOR STATEMENT 


```{c}
for ( double y : qAsConst(roots) )
			{	
#ifdef DEBUG_IMPLICIT
				painter->setPen( QPen( Qt::blue, painter->pen().width() ) );
#endif
				drawImplicitInSquare( plot, painter, x, y, Qt::Vertical, & singular );
			}
```

#### RANGE FOR STATEMENT 


```{c}
for (const Value &it : qAsConst(item->m_parameters.list))
        str_parameter << it.expression();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVector<bool> &signature : qAsConst(signatures)) {
            int at = 0;
            QList<QVector<bool>> pmSignature;

            for (Equation *equation : qAsConst(eq)) {
                int pmCount = equation->pmCount();
                QVector<bool> sig(pmCount);
                for (int i = 0; i < pmCount; ++i)
                    sig[i] = signature[i + at];
                at += pmCount;

                pmSignature << sig;
            }

            for (Plot plot : qAsConst(list)) {
                plot.pmSignature = pmSignature;
                duplicated << plot;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Function *it : qAsConst(XParser::self()->m_ufkt)) {
        if (it->m_parameters.useSlider && !it->allPlotsAreHidden()) {
            needSliderWindow = true;
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (FunctionListItem *item : qAsConst(currentFunctionItems)) {
        if (m_functionID == item->function())
            m_functionID = -1;

        delete m_functionList->takeItem(m_functionList->row(item));
    }
```

#### AUTO 


```{c}
const auto arguments = parser.positionalArguments();
```

#### RANGE FOR STATEMENT 


```{c}
for ( Function * function : qAsConst(XParser::self()->m_ufkt) )
		text += "<li>" + function->name().replace( '\n', "<br>" ) + "</li>";
```

#### RANGE FOR STATEMENT 


```{c}
for ( const Value &it : qAsConst(tmp_ufkt->m_parameters.list) )
	{
		if ( it.expression() == new_parameter )
			return false;
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &f : y)
                state->y0[at++] = f;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &var : variables) {
            if (remaining.startsWith(var)) {
                setFormat(i, var.length(), variable);
                i += var.length() - 1;
                found = true;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Plot &plot : plots)
        drawPlot(plot, painter);
```

#### RANGE FOR STATEMENT 


```{c}
for ( QListWidgetItem * item : qAsConst(items) )
	{
		int f = static_cast<FunctionListItem*>(item)->function();
		
		if ( Function * function = XParser::self()->functionWithID( f ) )
			io.addFunction( doc, root, function );
	}
```

#### RANGE FOR STATEMENT 


```{c}
for ( const Plot &plot : plots )
	{
		bool setAliased = false;
		if ( plot.parameter.type() == Parameter::Animated )
		{
			// Don't use antialiasing, so that rendering is sped up
			if ( painter->renderHints() & QPainter::Antialiasing )
			{
				setAliased = true;
				painter->setRenderHint( QPainter::Antialiasing, false );
			}
		}
		
		painter->setPen( penForPlot( plot, painter ) );
		
		QList<QPointF> singular;
		
		for ( int i = 0; i <= squares; ++i )
		{
			double y = m_ymin + i*(m_ymax-m_ymin)/double(squares);
			
			function->y = y;
			function->m_implicitMode = Function::FixedY;
			QList<double> roots = findRoots( plot, m_xmin, m_xmax, RoughRoot );
			
			for ( double x : qAsConst(roots) )
			{
#ifdef DEBUG_IMPLICIT
				painter->setPen( QPen( Qt::red, painter->pen().width() ) );
#endif
				drawImplicitInSquare( plot, painter, x, y, Qt::Horizontal, & singular );
			}
			
			
			
			double x = m_xmin + i*(m_xmax-m_xmin)/double(squares);
			
			function->x = x;
			function->m_implicitMode = Function::FixedX;
			roots = findRoots( plot, m_ymin, m_ymax, RoughRoot );
			
			for ( double y : qAsConst(roots) )
			{	
#ifdef DEBUG_IMPLICIT
				painter->setPen( QPen( Qt::blue, painter->pen().width() ) );
#endif
				drawImplicitInSquare( plot, painter, x, y, Qt::Vertical, & singular );
			}
		}
		
		// Sort out the implicit points
		FuzzyPointMap singularSorted;
		FuzzyPoint::dx = (m_xmax-m_xmin) * SegmentMin * 0.1 / m_clipRect.width();
		FuzzyPoint::dy = (m_ymax-m_ymin) * SegmentMin * 0.1 / m_clipRect.height();
		for ( const QPointF &point : qAsConst(singular) )
			singularSorted.insert( point, point );
		singular = singularSorted.values();
		
		for ( const QPointF &point : qAsConst(singular) )
		{
			// radius of circle around singular point
			double epsilon = qMin( FuzzyPoint::dx, FuzzyPoint::dy );
			
			QString fstr;
			fstr = QString("%1(x)=%2(%3+%6*cos(x),%4+%6*sin(x)%5)")
					.arg( circular.function()->eq[0]->name() )
					.arg( function->eq[0]->name() )
					.arg( XParser::self()->number( point.x() ) )
					.arg( XParser::self()->number( point.y() ) )
					.arg( function->eq[0]->usesParameter() ? ',' + XParser::self()->number( function->k ) : QString() )
					.arg( XParser::self()->number( epsilon ) );
			
			bool setFstrOk = circular.function()->eq[0]->setFstr( fstr );
                        qDebug() << "------------ " << setFstrOk << endl;
			assert( setFstrOk );
			
			QList<double> roots = findRoots( circular, 0, 2*M_PI / XParser::self()->radiansPerAngleUnit(), PreciseRoot );
			
#ifdef DEBUG_IMPLICIT
			qDebug() << "Singular point at (x,y)=("<<point.x()<<','<<point.y()<<")\n";
			qDebug() << "fstr is    " << fstr;
			qDebug() << "Found " << roots.size() << " roots.\n";
#endif
			
			for ( double t : qAsConst(roots) )
			{	
#ifdef DEBUG_IMPLICIT
				painter->setPen( QPen( Qt::green, painter->pen().width() ) );
#endif
				double x = point.x() + epsilon * lcos(t);
				double y = point.y() + epsilon * lsin(t);
				drawImplicitInSquare( plot, painter, x, y, 0, & singular );
			}
		}
		
		
		if ( setAliased )
			painter->setRenderHint( QPainter::Antialiasing, true );
	}
```

#### RANGE FOR STATEMENT 


```{c}
for ( Plot plot : qAsConst(list) ) {
				plot.pmSignature = pmSignature;
				duplicated << plot;
			}
```

#### RANGE FOR STATEMENT 


```{c}
for (Equation *e : qAsConst(eq))
        delete e;
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QVector<bool> &signature : qAsConst(signatures) )
		{
			int at = 0;
			QList< QVector<bool> > pmSignature;
		
			for ( Equation * equation : qAsConst(eq) )
			{
				int pmCount = equation->pmCount();
				QVector<bool> sig( pmCount );
				for ( int i = 0; i < pmCount; ++i )
					sig[i] = signature[ i + at];
				at += pmCount;
			
				pmSignature << sig;
			}
		
			for ( Plot plot : qAsConst(list) ) {
				plot.pmSignature = pmSignature;
				duplicated << plot;
			}
		}
```

#### RANGE FOR STATEMENT 


```{c}
CONNECT_WIDGETS( EquationEdit, editingFinished() )
```

#### RANGE FOR STATEMENT 


```{c}
for (const Plot &plot : plots)
            drawTangentField(plot, painter);
```

#### RANGE FOR STATEMENT 


```{c}
for (QToolButton *w : buttons) {
        KAcceleratorManager::setNoAccel(w);

        connect(w, &QToolButton::clicked, this, &EquationEditorWidget::characterButtonClicked);

        // Also increase the font size, since the fractions, etc are probably not that visible
        // at the default font size
        w->setFont(buttonFont);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (double y : qAsConst(roots)) {
#ifdef DEBUG_IMPLICIT
                painter->setPen(QPen(Qt::blue, painter->pen().width()));
#endif
                drawImplicitInSquare(plot, painter, x, y, Qt::Vertical, &singular);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this, newCoords]
		{
			finishAnimation( newCoords );
		}
```

#### RANGE FOR STATEMENT 


```{c}
CONNECT_WIDGETS( ParametersWidget, parameterListChanged() )
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString &stopString : stopStrings )
	{
		QString pos = stopString.section( ';', 0, 0 );
		QString color = stopString.section( ';', 1, 1 );
		
		QGradientStop stop;
		stop.first = pos.toDouble();
		stop.second = color;
		stops << stop;
	}
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString &f : y )
				state->y0[at++] = f;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &var : qAsConst(sorted)) {
        if (match(var)) {
            addToken(VAR);
            adduint(variables.indexOf(var));
            return true;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Function *function : qAsConst(XParser::self()->m_ufkt))
        text += "<li>" + function->name().replace('\n', "<br>") + "</li>";
```

#### RANGE FOR STATEMENT 


```{c}
for (Equation *eq : qAsConst(f->eq)) {
            if (!eq->name().isEmpty())
                names << eq->name();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const Plot &plot : plots )
		drawPlot( plot, painter );
```

#### RANGE FOR STATEMENT 


```{c}
for ( Function * function : qAsConst(XParser::self()->m_ufkt) )
	{
		at += 1;
		
		if ( m_stopCalculating )
			break;
		
// 		QDBusInterface( QDBus::sessionBus().baseService(), "/kmplot", "org.kde.kmplot.KmPlot" ).call( QDBus::Block, "setDrawProgress", at/numPlots );

		if ( function->type() == Function::Implicit )
			drawImplicit( function, & painter );
		else
			drawFunction( function, & painter );
	}
```

#### RANGE FOR STATEMENT 


```{c}
for ( const EquationPair &eq : qAsConst(m_equations) )
	{
		Equation * equation = eq.first.function()->eq[ eq.second ];
		QListWidgetItem * item = new QListWidgetItem( equation->fstr(), m_widget->list );
		item->setForeground( eq.first.color() );
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (Function *f : qAsConst(m_ufkt)) {
        for (Equation *eq : qAsConst(f->eq)) {
            if (!eq->name().isEmpty())
                names << eq->name();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &stopString : stopStrings) {
        QString pos = stopString.section(';', 0, 0);
        QString color = stopString.section(';', 1, 1);

        QGradientStop stop;
        stop.first = pos.toDouble();
        stop.second = color;
        stops << stop;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Function *f : qAsConst(XParser::self()->m_ufkt))
        addFunction(doc, root, f);
```

#### RANGE FOR STATEMENT 


```{c}
for ( double t : qAsConst(roots) )
			{	
#ifdef DEBUG_IMPLICIT
				painter->setPen( QPen( Qt::green, painter->pen().width() ) );
#endif
				double x = point.x() + epsilon * lcos(t);
				double y = point.y() + epsilon * lsin(t);
				drawImplicitInSquare( plot, painter, x, y, 0, & singular );
			}
```

#### RANGE FOR STATEMENT 


```{c}
for ( double x : qAsConst(roots) )
			{
#ifdef DEBUG_IMPLICIT
				painter->setPen( QPen( Qt::red, painter->pen().width() ) );
#endif
				drawImplicitInSquare( plot, painter, x, y, Qt::Horizontal, & singular );
			}
```

#### RANGE FOR STATEMENT 


```{c}
for ( Equation * eq : qAsConst(it->eq) )
				{
					for ( const QString& pattern : neededPatterns) {
						if ( eq->name() == pattern.arg(name) )
							ok = false;
					}
				}
```

#### RANGE FOR STATEMENT 


```{c}
for ( Function *f : qAsConst(toRemove) )
	{
		uint id = f->id();
		m_ufkt.remove( id );
		delete f;
		emit functionRemoved( id );
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QPointF &realValue : stationaryPoints) {
                    painter->setPen(QPen(Qt::black, millimetersToPixels(1.5, painter->device())));
                    painter->drawPoint(toPixel(realValue));

                    QString x = posToString(realValue.x(), (m_xmax - m_xmin) / m_clipRect.width(), View::DecimalFormat);
                    QString y = posToString(realValue.y(), (m_ymax - m_ymin) / m_clipRect.width(), View::DecimalFormat);

                    drawLabel(painter,
                              plot.color(),
                              realValue,
                              i18nc("Extrema point", "x = %1   y = %2", x.replace('.', QLocale().decimalPoint()), y.replace('.', QLocale().decimalPoint())));
                }
```

#### RANGE FOR STATEMENT 


```{c}
CONNECT_WIDGETS(QLineEdit, editingFinished())
```

#### RANGE FOR STATEMENT 


```{c}
for (const QGradientStop &stop : qAsConst(stops))
        string += QString("%1;%2,").arg(stop.first).arg(stop.second.name());
```

#### RANGE FOR STATEMENT 


```{c}
for (double x : roots) {
        QPointF real = realValue(plot, x, false);
        if (real.y() >= m_ymin && real.y() <= m_ymax)
            stationaryPoints << real;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &pattern : neededPatterns) {
                        if (eq->name() == pattern.arg(name))
                            ok = false;
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( int row : indexes )
		m_model->removeRows( -row, 1, QModelIndex() );
```

#### RANGE FOR STATEMENT 


```{c}
for (Function *function : qAsConst(m_ufkt))
        delete function;
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString &f : predefinedFunctions )
		strings[f] = FunctionString;
```

#### RANGE FOR STATEMENT 


```{c}
for ( Function * function : qAsConst(m_ufkt) )
		delete function;
```

#### RANGE FOR STATEMENT 


```{c}
for ( const Plot &plot : plots )
			drawTangentField( plot, painter );
```

#### RANGE FOR STATEMENT 


```{c}
for (Equation *eq : qAsConst(it->eq)) {
            if (eq->name() != fname)
                continue;

            str = str.mid(p1, str.length() - 1);
            QString function_name;
            if (type == Equation::ParametricX)
                function_name = 'x';
            else if (type == Equation::ParametricY)
                function_name = 'y';
            else
                function_name = 'f';
            function_name = findFunctionName(function_name, id);
            str.prepend(function_name);
            return;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Value &y : qAsConst(state->y0)) {
                if (!first)
                    ys += ';';
                first = false;
                ys += y.expression();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (Function *it : qAsConst(m_ufkt)) {
        for (Equation *eq : qAsConst(it->eq)) {
            if (eq->looksLikeFunction() && (name == eq->name()))
                return it->id();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const Plot &plot : plots )
	{
		bool setAliased = false;
		if ( plot.parameter.type() == Parameter::Animated )
		{
			// Don't use antialiasing, so that rendering is sped up
			if ( painter->renderHints() & QPainter::Antialiasing )
			{
				setAliased = true;
				painter->setRenderHint( QPainter::Antialiasing, false );
			}
		}
		
		painter->setPen( penForPlot( plot, painter ) );
		
		QList<QPointF> singular;
		
		for ( int i = 0; i <= squares; ++i )
		{
			double y = m_ymin + i*(m_ymax-m_ymin)/double(squares);
			
			function->y = y;
			function->m_implicitMode = Function::FixedY;
			QList<double> roots = findRoots( plot, m_xmin, m_xmax, RoughRoot );
			
			for ( double x : qAsConst(roots) )
			{
#ifdef DEBUG_IMPLICIT
				painter->setPen( QPen( Qt::red, painter->pen().width() ) );
#endif
				drawImplicitInSquare( plot, painter, x, y, Qt::Horizontal, & singular );
			}
			
			
			
			double x = m_xmin + i*(m_xmax-m_xmin)/double(squares);
			
			function->x = x;
			function->m_implicitMode = Function::FixedX;
			roots = findRoots( plot, m_ymin, m_ymax, RoughRoot );
			
			for ( double y : qAsConst(roots) )
			{	
#ifdef DEBUG_IMPLICIT
				painter->setPen( QPen( Qt::blue, painter->pen().width() ) );
#endif
				drawImplicitInSquare( plot, painter, x, y, Qt::Vertical, & singular );
			}
		}
		
		// Sort out the implicit points
		FuzzyPointMap singularSorted;
		FuzzyPoint::dx = (m_xmax-m_xmin) * SegmentMin * 0.1 / m_clipRect.width();
		FuzzyPoint::dy = (m_ymax-m_ymin) * SegmentMin * 0.1 / m_clipRect.height();
		for ( const QPointF &point : qAsConst(singular) )
			singularSorted.insert( point, point );
		singular = singularSorted.values();
		
		for ( const QPointF &point : qAsConst(singular) )
		{
			// radius of circle around singular point
			double epsilon = qMin( FuzzyPoint::dx, FuzzyPoint::dy );
			
			QString fstr;
			fstr = QString("%1(x)=%2(%3+%6*cos(x),%4+%6*sin(x)%5)")
					.arg( circular.function()->eq[0]->name() )
					.arg( function->eq[0]->name() )
					.arg( XParser::self()->number( point.x() ) )
					.arg( XParser::self()->number( point.y() ) )
					.arg( function->eq[0]->usesParameter() ? ',' + XParser::self()->number( function->k ) : QString() )
					.arg( XParser::self()->number( epsilon ) );
			
			bool setFstrOk = circular.function()->eq[0]->setFstr( fstr );
                        qDebug() << "------------ " << setFstrOk;
			assert( setFstrOk );
			
			QList<double> roots = findRoots( circular, 0, 2*M_PI / XParser::self()->radiansPerAngleUnit(), PreciseRoot );
			
#ifdef DEBUG_IMPLICIT
			qDebug() << "Singular point at (x,y)=("<<point.x()<<','<<point.y()<<")\n";
			qDebug() << "fstr is    " << fstr;
			qDebug() << "Found " << roots.size() << " roots.\n";
#endif
			
			for ( double t : qAsConst(roots) )
			{	
#ifdef DEBUG_IMPLICIT
				painter->setPen( QPen( Qt::green, painter->pen().width() ) );
#endif
				double x = point.x() + epsilon * lcos(t);
				double y = point.y() + epsilon * lsin(t);
				drawImplicitInSquare( plot, painter, x, y, {}, & singular );
			}
		}
		
		
		if ( setAliased )
			painter->setRenderHint( QPainter::Antialiasing, true );
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (Function *it : qAsConst(m_parser->m_ufkt)) {
        for (Equation *eq : qAsConst(it->eq))
            strings[eq->name()] = FunctionString;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( Function *other : qAsConst(m_ufkt) )
			{
				if ( (other==f) || toRemove.contains(other) )
					continue;
				
				if ( other->dependsOn( f ) )
				{
					toRemove << other;
					otherRemoveNames << other->name();
					newFunctions << other;
				}
			}
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QPointF &point : qAsConst(singular) )
			singularSorted.insert( point, point );
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &f : predefinedFunctions)
        strings[f] = FunctionString;
```

#### LAMBDA EXPRESSION 


```{c}
[]{
		QClipboard * cb = QApplication::clipboard();
		QPointF currentXY = View::self()->getCrosshairPosition();
		cb->setText( i18nc("Copied pair of coordinates (x, y)", "(%1, %2)", QLocale().toString( currentXY.x(), 'f', 5 ), QLocale().toString( currentXY.y(), 'f', 5 )), QClipboard::Clipboard );
	}
```

#### RANGE FOR STATEMENT 


```{c}
for ( Function *f : qAsConst(XParser::self()->m_ufkt) )
		addFunction( doc, root, f );
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString &var : variables )
		sorted.insert( -var.length(), var );
```

#### RANGE FOR STATEMENT 


```{c}
for (const Plot &plot : plots) {
        bool setAliased = false;
        if (plot.parameter.type() == Parameter::Animated) {
            // Don't use antialiasing, so that rendering is sped up
            if (painter->renderHints() & QPainter::Antialiasing) {
                setAliased = true;
                painter->setRenderHint(QPainter::Antialiasing, false);
            }
        }

        painter->setPen(penForPlot(plot, painter));

        QList<QPointF> singular;

        for (int i = 0; i <= squares; ++i) {
            double y = m_ymin + i * (m_ymax - m_ymin) / double(squares);

            function->y = y;
            function->m_implicitMode = Function::FixedY;
            QList<double> roots = findRoots(plot, m_xmin, m_xmax, RoughRoot);

            for (double x : qAsConst(roots)) {
#ifdef DEBUG_IMPLICIT
                painter->setPen(QPen(Qt::red, painter->pen().width()));
#endif
                drawImplicitInSquare(plot, painter, x, y, Qt::Horizontal, &singular);
            }

            double x = m_xmin + i * (m_xmax - m_xmin) / double(squares);

            function->x = x;
            function->m_implicitMode = Function::FixedX;
            roots = findRoots(plot, m_ymin, m_ymax, RoughRoot);

            for (double y : qAsConst(roots)) {
#ifdef DEBUG_IMPLICIT
                painter->setPen(QPen(Qt::blue, painter->pen().width()));
#endif
                drawImplicitInSquare(plot, painter, x, y, Qt::Vertical, &singular);
            }
        }

        // Sort out the implicit points
        FuzzyPointMap singularSorted;
        FuzzyPoint::dx = (m_xmax - m_xmin) * SegmentMin * 0.1 / m_clipRect.width();
        FuzzyPoint::dy = (m_ymax - m_ymin) * SegmentMin * 0.1 / m_clipRect.height();
        for (const QPointF &point : qAsConst(singular))
            singularSorted.insert(point, point);
        singular = singularSorted.values();

        for (const QPointF &point : qAsConst(singular)) {
            // radius of circle around singular point
            double epsilon = qMin(FuzzyPoint::dx, FuzzyPoint::dy);

            QString fstr;
            fstr = QString("%1(x)=%2(%3+%6*cos(x),%4+%6*sin(x)%5)")
                       .arg(circular.function()->eq[0]->name())
                       .arg(function->eq[0]->name())
                       .arg(XParser::self()->number(point.x()))
                       .arg(XParser::self()->number(point.y()))
                       .arg(function->eq[0]->usesParameter() ? ',' + XParser::self()->number(function->k) : QString())
                       .arg(XParser::self()->number(epsilon));

            bool setFstrOk = circular.function()->eq[0]->setFstr(fstr);
            qDebug() << "------------ " << setFstrOk;
            assert(setFstrOk);

            QList<double> roots = findRoots(circular, 0, 2 * M_PI / XParser::self()->radiansPerAngleUnit(), PreciseRoot);

#ifdef DEBUG_IMPLICIT
            qDebug() << "Singular point at (x,y)=(" << point.x() << ',' << point.y() << ")\n";
            qDebug() << "fstr is    " << fstr;
            qDebug() << "Found " << roots.size() << " roots.\n";
#endif

            for (double t : qAsConst(roots)) {
#ifdef DEBUG_IMPLICIT
                painter->setPen(QPen(Qt::green, painter->pen().width()));
#endif
                double x = point.x() + epsilon * lcos(t);
                double y = point.y() + epsilon * lsin(t);
                drawImplicitInSquare(plot, painter, x, y, {}, &singular);
            }
        }

        if (setAliased)
            painter->setRenderHint(QPainter::Antialiasing, true);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( Equation * eq : f->eq )
            initEquation( eq );
```

#### RANGE FOR STATEMENT 


```{c}
for ( double x : roots )
	{
		QPointF real = realValue( plot, x, false );
		if ( real.y() >= m_ymin && real.y() <= m_ymax )
			stationaryPoints << real;
	}
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QPointF &point : qAsConst(singular) )
		{
			// radius of circle around singular point
			double epsilon = qMin( FuzzyPoint::dx, FuzzyPoint::dy );
			
			QString fstr;
			fstr = QString("%1(x)=%2(%3+%6*cos(x),%4+%6*sin(x)%5)")
					.arg( circular.function()->eq[0]->name() )
					.arg( function->eq[0]->name() )
					.arg( XParser::self()->number( point.x() ) )
					.arg( XParser::self()->number( point.y() ) )
					.arg( function->eq[0]->usesParameter() ? ',' + XParser::self()->number( function->k ) : QString() )
					.arg( XParser::self()->number( epsilon ) );
			
			bool setFstrOk = circular.function()->eq[0]->setFstr( fstr );
                        qDebug() << "------------ " << setFstrOk;
			assert( setFstrOk );
			
			QList<double> roots = findRoots( circular, 0, 2*M_PI / XParser::self()->radiansPerAngleUnit(), PreciseRoot );
			
#ifdef DEBUG_IMPLICIT
			qDebug() << "Singular point at (x,y)=("<<point.x()<<','<<point.y()<<")\n";
			qDebug() << "fstr is    " << fstr;
			qDebug() << "Found " << roots.size() << " roots.\n";
#endif
			
			for ( double t : qAsConst(roots) )
			{	
#ifdef DEBUG_IMPLICIT
				painter->setPen( QPen( Qt::green, painter->pen().width() ) );
#endif
				double x = point.x() + epsilon * lcos(t);
				double y = point.y() + epsilon * lsin(t);
				drawImplicitInSquare( plot, painter, x, y, {}, & singular );
			}
		}
```

#### RANGE FOR STATEMENT 


```{c}
for ( const Plot &plot : function->plots() )
		{
			plot.updateFunction();
			
			// Draw extrema points?
			if ( (function->type() == Function::Cartesian) && function->plotAppearance( plot.plotMode ).showExtrema )
			{
				const QList<QPointF> stationaryPoints = findStationaryPoints( plot );
				for ( const QPointF &realValue : stationaryPoints )
				{
					painter->setPen( QPen( Qt::black, millimetersToPixels( 1.5, painter->device() ) ) );
					painter->drawPoint( toPixel( realValue ) );
					
					QString x = posToString( realValue.x(), (m_xmax-m_xmin)/m_clipRect.width(), View::DecimalFormat );
					QString y = posToString( realValue.y(), (m_ymax-m_ymin)/m_clipRect.width(), View::DecimalFormat );
					
					drawLabel( painter, plot.color(), realValue, i18nc( "Extrema point", "x = %1   y = %2", x.replace('.', QLocale().decimalPoint()), y.replace('.', QLocale().decimalPoint()) ) );
				}
			}
			
			// Show the name of the plot?
			if ( function->plotAppearance( plot.plotMode ).showPlotName )
			{
				double x, y;
				
				double xmin = m_xmin + 0.1 * (m_xmax-m_xmin);
				double xmax = m_xmax - 0.1 * (m_xmax-m_xmin);
				double ymin = m_ymin + 0.1 * (m_ymax-m_ymin);
				double ymax = m_ymax - 0.1 * (m_ymax-m_ymin);
				
				// Find out where on the outer edge of the view to draw it
				if ( 0 <= plotNameAt && plotNameAt <= 2 )
				{
					x = xmax;
					y = ymax - (ymax-ymin)*plotNameAt/2;
				}
				else if ( 3 <= plotNameAt && plotNameAt <= 5 )
				{
					x = xmax - (xmax-xmin)*(plotNameAt-2)/3;
					y = ymin;
				}
				else if ( 6 <= plotNameAt && plotNameAt <= 7 )
				{
					x = xmin;
					y = ymin + (ymax-ymin)*(plotNameAt-5)/2;
				}
				else
				{
					x = xmin + (xmax-xmin)*(plotNameAt-7)/3;
					y = ymax;
				}
				
				plotNameAt = (plotNameAt+1) % 10;
				
				QPointF realPos;
				
				if ( function->type() == Function::Implicit )
				{
					findRoot( & x, & y, plot, RoughRoot );
					realPos = QPointF( x, y );
				}
				else
				{
					double t = getClosestPoint( QPointF( x, y ), plot );
					realPos = realValue( plot, t, false );
				}
				
				// If the closest point isn't in the view, then don't draw the label
				if ( realPos.x() < m_xmin || realPos.x() > m_xmax || realPos.y() < m_ymin || realPos.y() > m_ymax )
					continue;
				
				drawLabel( painter, plot.color(), realPos, plot.name() );
			}
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &f : functions) {
            if (remaining.startsWith(f)) {
                setFormat(i, f.length(), function);
                i += f.length() - 1;
                found = true;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( Plot plot : qAsConst(list) ) {
				plot.stateNumber = i;
				duplicated << plot;
			}
```

#### RANGE FOR STATEMENT 


```{c}
for ( Function * it : qAsConst(m_ufkt) )
			{
				if ( int(it->id()) == id )
					continue;
				
				for ( Equation * eq : qAsConst(it->eq) )
				{
					for ( const QString& pattern : neededPatterns) {
						if ( eq->name() == pattern.arg(name) )
							ok = false;
					}
				}
				
				if (!ok)
					break;
			}
```

#### RANGE FOR STATEMENT 


```{c}
for ( Function * function : qAsConst(XParser::self()->m_ufkt) )
	{
		if ( m_stopCalculating )
			break;
		
		for ( const Plot &plot : function->plots() )
		{
			plot.updateFunction();
			
			// Draw extrema points?
			if ( (function->type() == Function::Cartesian) && function->plotAppearance( plot.plotMode ).showExtrema )
			{
				const QList<QPointF> stationaryPoints = findStationaryPoints( plot );
				for ( const QPointF &realValue : stationaryPoints )
				{
					painter->setPen( QPen( Qt::black, millimetersToPixels( 1.5, painter->device() ) ) );
					painter->drawPoint( toPixel( realValue ) );
					
					QString x = posToString( realValue.x(), (m_xmax-m_xmin)/m_clipRect.width(), View::DecimalFormat );
					QString y = posToString( realValue.y(), (m_ymax-m_ymin)/m_clipRect.width(), View::DecimalFormat );
					
					drawLabel( painter, plot.color(), realValue, i18nc( "Extrema point", "x = %1   y = %2", x.replace('.', QLocale().decimalPoint()), y.replace('.', QLocale().decimalPoint()) ) );
				}
			}
			
			// Show the name of the plot?
			if ( function->plotAppearance( plot.plotMode ).showPlotName )
			{
				double x, y;
				
				double xmin = m_xmin + 0.1 * (m_xmax-m_xmin);
				double xmax = m_xmax - 0.1 * (m_xmax-m_xmin);
				double ymin = m_ymin + 0.1 * (m_ymax-m_ymin);
				double ymax = m_ymax - 0.1 * (m_ymax-m_ymin);
				
				// Find out where on the outer edge of the view to draw it
				if ( 0 <= plotNameAt && plotNameAt <= 2 )
				{
					x = xmax;
					y = ymax - (ymax-ymin)*plotNameAt/2;
				}
				else if ( 3 <= plotNameAt && plotNameAt <= 5 )
				{
					x = xmax - (xmax-xmin)*(plotNameAt-2)/3;
					y = ymin;
				}
				else if ( 6 <= plotNameAt && plotNameAt <= 7 )
				{
					x = xmin;
					y = ymin + (ymax-ymin)*(plotNameAt-5)/2;
				}
				else
				{
					x = xmin + (xmax-xmin)*(plotNameAt-7)/3;
					y = ymax;
				}
				
				plotNameAt = (plotNameAt+1) % 10;
				
				QPointF realPos;
				
				if ( function->type() == Function::Implicit )
				{
					findRoot( & x, & y, plot, RoughRoot );
					realPos = QPointF( x, y );
				}
				else
				{
					double t = getClosestPoint( QPointF( x, y ), plot );
					realPos = realValue( plot, t, false );
				}
				
				// If the closest point isn't in the view, then don't draw the label
				if ( realPos.x() < m_xmin || realPos.x() > m_xmax || realPos.y() < m_ymin || realPos.y() > m_ymax )
					continue;
				
				drawLabel( painter, plot.color(), realPos, plot.name() );
			}
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (Function *it : qAsConst(m_ufkt)) {
        for (int i = 0; i < it->eq.size(); ++i) {
            if (!match(it->eq[i]->name()))
                continue;

            if (it->eq[i] == m_currentEquation || (m_currentEquation && it->dependsOn(m_currentEquation->parent()))) {
                *m_error = RecursiveFunctionCall;
                return true;
            }

            int argCount = readFunctionArguments();
            if (argCount != it->eq[i]->variables().size()) {
                *m_error = IncorrectArgumentCount;
                return true;
            }

            addToken(UFKT);
            addfptr(it->id(), i, argCount);
            if (m_currentEquation->parent())
                m_currentEquation->parent()->addFunctionDependency(it);

            return true;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Equation *eq : qAsConst(f->eq))
        eq->differentialStates.resetToInitial();
```

#### RANGE FOR STATEMENT 


```{c}
for ( double t : qAsConst(roots) )
			{	
#ifdef DEBUG_IMPLICIT
				painter->setPen( QPen( Qt::green, painter->pen().width() ) );
#endif
				double x = point.x() + epsilon * lcos(t);
				double y = point.y() + epsilon * lsin(t);
				drawImplicitInSquare( plot, painter, x, y, {}, & singular );
			}
```

#### LAMBDA EXPRESSION 


```{c}
[preview, previewWidget, printdlg] {
            QDialog *printSettingsDialog = new QDialog(preview, Qt::WindowFlags());
            printSettingsDialog->setWindowTitle(i18nc("@title:window", "Print Settings"));
            QVBoxLayout *mainLayout = new QVBoxLayout;
            printSettingsDialog->setLayout(mainLayout);
            mainLayout->addWidget(printdlg);
            QDialogButtonBox *buttonBox = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel);
            connect(buttonBox, &QDialogButtonBox::accepted, [previewWidget, printSettingsDialog] {
                previewWidget->updatePreview();
                printSettingsDialog->close();
            });
            connect(buttonBox, &QDialogButtonBox::rejected, printSettingsDialog, &QDialog::reject);
            mainLayout->addWidget(buttonBox);
            printSettingsDialog->show();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QGradientStop &stop : stops )
		drawArrow( & painter, stop );
```

#### RANGE FOR STATEMENT 


```{c}
for (Function *f : currentFunctions) {
            for (Function *other : qAsConst(m_ufkt)) {
                if ((other == f) || toRemove.contains(other))
                    continue;

                if (other->dependsOn(f)) {
                    toRemove << other;
                    otherRemoveNames << other->name();
                    newFunctions << other;
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( Equation * eq : qAsConst(it->eq) )
			strings[eq->name()] = FunctionString;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : selected)
        sorted.insert(-index.row(), 0l);
```

#### LAMBDA EXPRESSION 


```{c}
[this, &printdlg, &prt]{
		setupPrinter(printdlg, &prt);
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const Value &it : qAsConst(tmp_ufkt->m_parameters.list)) {
        if (it.expression() == new_parameter)
            return false;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& f : functions) {
			if (remaining.startsWith(f)) {
				setFormat(i, f.length(), function);
				i += f.length() - 1;
				found = true;
				break;
			}
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QPointF &point : qAsConst(singular))
            singularSorted.insert(point, point);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Plot &plot : function->plots()) {
            plot.updateFunction();

            // Draw extrema points?
            if ((function->type() == Function::Cartesian) && function->plotAppearance(plot.plotMode).showExtrema) {
                const QList<QPointF> stationaryPoints = findStationaryPoints(plot);
                for (const QPointF &realValue : stationaryPoints) {
                    painter->setPen(QPen(Qt::black, millimetersToPixels(1.5, painter->device())));
                    painter->drawPoint(toPixel(realValue));

                    QString x = posToString(realValue.x(), (m_xmax - m_xmin) / m_clipRect.width(), View::DecimalFormat);
                    QString y = posToString(realValue.y(), (m_ymax - m_ymin) / m_clipRect.width(), View::DecimalFormat);

                    drawLabel(painter,
                              plot.color(),
                              realValue,
                              i18nc("Extrema point", "x = %1   y = %2", x.replace('.', QLocale().decimalPoint()), y.replace('.', QLocale().decimalPoint())));
                }
            }

            // Show the name of the plot?
            if (function->plotAppearance(plot.plotMode).showPlotName) {
                double x, y;

                double xmin = m_xmin + 0.1 * (m_xmax - m_xmin);
                double xmax = m_xmax - 0.1 * (m_xmax - m_xmin);
                double ymin = m_ymin + 0.1 * (m_ymax - m_ymin);
                double ymax = m_ymax - 0.1 * (m_ymax - m_ymin);

                // Find out where on the outer edge of the view to draw it
                if (0 <= plotNameAt && plotNameAt <= 2) {
                    x = xmax;
                    y = ymax - (ymax - ymin) * plotNameAt / 2;
                } else if (3 <= plotNameAt && plotNameAt <= 5) {
                    x = xmax - (xmax - xmin) * (plotNameAt - 2) / 3;
                    y = ymin;
                } else if (6 <= plotNameAt && plotNameAt <= 7) {
                    x = xmin;
                    y = ymin + (ymax - ymin) * (plotNameAt - 5) / 2;
                } else {
                    x = xmin + (xmax - xmin) * (plotNameAt - 7) / 3;
                    y = ymax;
                }

                plotNameAt = (plotNameAt + 1) % 10;

                QPointF realPos;

                if (function->type() == Function::Implicit) {
                    findRoot(&x, &y, plot, RoughRoot);
                    realPos = QPointF(x, y);
                } else {
                    double t = getClosestPoint(QPointF(x, y), plot);
                    realPos = realValue(plot, t, false);
                }

                // If the closest point isn't in the view, then don't draw the label
                if (realPos.x() < m_xmin || realPos.x() > m_xmax || realPos.y() < m_ymin || realPos.y() > m_ymax)
                    continue;

                drawLabel(painter, plot.color(), realPos, plot.name());
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[preview, previewWidget, printdlg]{
			QDialog *printSettingsDialog = new QDialog( preview, Qt::WindowFlags() );
			printSettingsDialog->setWindowTitle( i18n("Print Settings") );
			QVBoxLayout *mainLayout = new QVBoxLayout;
			printSettingsDialog->setLayout(mainLayout);
			mainLayout->addWidget(printdlg);
			QDialogButtonBox *buttonBox = new QDialogButtonBox( QDialogButtonBox::Ok|QDialogButtonBox::Cancel );
			connect(buttonBox, &QDialogButtonBox::accepted, [previewWidget, printSettingsDialog]{
				previewWidget->updatePreview();
				printSettingsDialog->close();
			} );
			connect(buttonBox, &QDialogButtonBox::rejected, printSettingsDialog, &QDialog::reject);
			mainLayout->addWidget(buttonBox);
			printSettingsDialog->show();
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (const EquationPair &eq : qAsConst(m_equations)) {
        Equation *equation = eq.first.function()->eq[eq.second];
        QListWidgetItem *item = new QListWidgetItem(equation->fstr(), m_widget->list);
        item->setForeground(eq.first.color());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, copyRootValue]( bool haveRoot, double rootValue ){
		copyRootValue->setVisible(haveRoot);
		m_rootValue = rootValue;
	}
```

#### RANGE FOR STATEMENT 


```{c}
for ( Function *f : currentFunctions )
		{
			for ( Function *other : qAsConst(m_ufkt) )
			{
				if ( (other==f) || toRemove.contains(other) )
					continue;
				
				if ( other->dependsOn( f ) )
				{
					toRemove << other;
					otherRemoveNames << other->name();
					newFunctions << other;
				}
			}
		}
```

#### RANGE FOR STATEMENT 


```{c}
for ( FunctionListItem * item : qAsConst(currentFunctionItems) )
	{
		if ( m_functionID == item->function() )
			m_functionID = -1;
		
		delete m_functionList->takeItem( m_functionList->row( item ) );
	}
```

#### RANGE FOR STATEMENT 


```{c}
for ( Function * f : m_ufkt )
    {
        for ( Equation * eq : f->eq )
            initEquation( eq );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( Equation * eq : qAsConst(it->eq) )
		{
			if ( eq->name() != fname )
				continue;
			
			str = str.mid(p1,str.length()-1);
			QString function_name;
			if ( type == Equation::ParametricX )
				function_name = 'x';
			else if ( type == Equation::ParametricY )
				function_name = 'y';
			else
				function_name = 'f';
			function_name = findFunctionName( function_name, id );
			str.prepend( function_name );
			return;
		}
```

#### RANGE FOR STATEMENT 


```{c}
for ( Function * function : qAsConst(XParser::self()->m_ufkt) )
	{
		const QList< Plot > plots = function->plots();
		for ( const Plot &plot : plots )
		{
			plot.updateFunction();
			
			double best_x = 0.0, distance;
			QPointF cspos;
			
			if ( function->type() == Function::Implicit )
			{
				double x = m_crosshairPosition.x();
				double y = m_crosshairPosition.y();
				findRoot( & x, & y, plot, PreciseRoot );
				
				QPointF d = toPixel( QPointF( x, y ), ClipInfinite ) - toPixel( QPointF( m_crosshairPosition.x(), m_crosshairPosition.y() ), ClipInfinite );
				
				distance = std::sqrt( d.x()*d.x() + d.y()*d.y() );
				cspos = QPointF( x, y );
			}
			else
			{
				best_x = getClosestPoint( m_crosshairPosition, plot );
				distance = pixelDistance( m_crosshairPosition, plot, best_x, false );
				cspos = realValue( plot, best_x, false );
			}

			if ( distance < best_distance )
			{
				best_distance = distance;
				bestPlot = plot;
				m_trace_x = best_x;
				best_cspos = cspos;
			}
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for ( Function * function : qAsConst(XParser::self()->m_ufkt) )
	{
		if ( function->type() != Function::Cartesian && function->type() != Function::Differential )
			continue;
		
		QList<Plot> plots = function->plots();
		
		for ( int i = 0; i < function->eq.size(); ++i )
		{
			for ( const Plot &plot : qAsConst(plots) )
				m_equations << EquationPair( plot, i );
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for ( Function * it : qAsConst(m_parser->m_ufkt) )
	{
		for ( Equation * eq : qAsConst(it->eq) )
			strings[eq->name()] = FunctionString;
	}
```

#### RANGE FOR STATEMENT 


```{c}
for ( Equation * eq : qAsConst(f->eq) )
		{
			if ( !eq->name().isEmpty() )
				names << eq->name();
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& arg : arguments)
		{
			QUrl url = urlFromArg(arg);
			if (first)
			{
				exit = !load(url);
			}
			else
				openFileInNewWindow( url );
		}
```

#### RANGE FOR STATEMENT 


```{c}
for ( const Plot &plot : qAsConst(plots) )
				m_equations << EquationPair( plot, i );
```

#### RANGE FOR STATEMENT 


```{c}
for (int functionId : qAsConst(m_dependencies)) {
        Function *f = XParser::self()->functionWithID(functionId);

        if (f->dependsOn(function))
            return true;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Value &v : qAsConst(*m_parameter))
        m_mainWidget->list->addItem(v.expression());
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString &var : qAsConst(sorted) )
	{
		if ( match( var ) )
		{
			addToken( VAR );
			adduint( variables.indexOf( var ) );
			return true;
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString& pattern : neededPatterns) {
						if ( eq->name() == pattern.arg(name) )
							ok = false;
					}
```

#### LAMBDA EXPRESSION 


```{c}
[this, &printdlg, &prt] {
        setupPrinter(printdlg, &prt);
    }
```

#### RANGE FOR STATEMENT 


```{c}
CONNECT_WIDGETS(ParametersWidget, parameterListChanged())
```

#### RANGE FOR STATEMENT 


```{c}
for (Equation *equation : qAsConst(eq))
            size += equation->pmCount();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &arg : arguments) {
            QUrl url = urlFromArg(arg);
            if (first) {
                exit = !load(url);
            } else
                openFileInNewWindow(url);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Function *other : qAsConst(m_ufkt)) {
                if ((other == f) || toRemove.contains(other))
                    continue;

                if (other->dependsOn(f)) {
                    toRemove << other;
                    otherRemoveNames << other->name();
                    newFunctions << other;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for ( Plot plot : qAsConst(list) ) {
				if ( !plotAppearance(p).visible )
					continue;
				plot.plotMode = p;
				duplicated << plot;
			}
```

#### RANGE FOR STATEMENT 


```{c}
for (Function *f : qAsConst(toRemove)) {
        uint id = f->id();
        m_ufkt.remove(id);
        delete f;
        emit functionRemoved(id);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Value &k : qAsConst(function->m_parameters.list))
        str_parameters << k.expression();
```

#### LAMBDA EXPRESSION 


```{c}
[this, copyRootValue](bool haveRoot, double rootValue) {
        copyRootValue->setVisible(haveRoot);
        m_rootValue = rootValue;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, newCoords] {
            finishAnimation(newCoords);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QToolButton* w : buttons) {
		KAcceleratorManager::setNoAccel(w);
		
		connect(w, &QToolButton::clicked, this, &EquationEditorWidget::characterButtonClicked);
		
		// Also increase the font size, since the fractions, etc are probably not that visible
		// at the default font size
		w->setFont(buttonFont);
	}
```

