#### RANGE FOR STATEMENT 


```{c}
for (Task *task : storage()->tasksModel()->getAllTasks()) {
        if (!m_storage->allEventsHaveEndTime(task)) {
            task->resumeRunning();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : taskView->storage()->tasksModel()->getAllTasks()) {
        if (task->uid() == taskId) {
            taskView->stopTimerFor(task);
            return;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : taskView->storage()->tasksModel()->getAllTasks()) {
        if (task->isRunning()) {
            result << task->name();
        }
    }
```

#### AUTO 


```{c}
auto *item
```

#### AUTO 


```{c}
auto *checkbox = new QCheckBox(m_ui.autotrackinggroupbox);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &event : m_storage->rawevents()) {
                if (event->uid() == uid) {
                    event->setDtStart(datetime);
                    emit timesChanged();
                    qCDebug(KTT_LOG) << "Program SetDtStart to" << m_ui.historytablewidget->item(row, col)->text();
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto *event : storage()->eventsModel()->eventsForTask(task)) {
            QDateTime eventStart = event->dtStart();
            QDateTime eventEnd = event->dtEnd();

            const int duration = event->duration() / 60;
            task->addTime(duration);
            qCDebug(KTT_LOG) << "duration is" << duration;

            if (task->sessionStartTiMe().isValid()) {
                // if there is a session
                if (task->sessionStartTiMe().secsTo(eventStart) > 0 &&
                    task->sessionStartTiMe().secsTo(eventEnd) > 0) {
                    // if the event is after the session start
                    task->addSessionTime(duration);
                }
            } else {
                // so there is no session at all
                task->addSessionTime(duration);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *item : m_tasksModel->getAllItems()) {
            auto *task = dynamic_cast<Task *>(item);
            setExpanded(m_filterProxyModel->mapFromSource(m_tasksModel->index(task, 0)), readBoolEntry(task->uid()));
        }
```

#### AUTO 


```{c}
auto *e = new Event(kcalEvent, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto *event : storage()->eventsModel()->eventsForTask(task)) {
            QDateTime eventStart = event->dtStart();
            QDateTime eventEnd = event->dtEnd();

            const int64_t duration = event->duration() / 60;
            task->addTime(duration);
            qCDebug(KTT_LOG) << "duration is" << duration;

            if (task->sessionStartTiMe().isValid()) {
                // if there is a session
                if (task->sessionStartTiMe().secsTo(eventStart) > 0 &&
                    task->sessionStartTiMe().secsTo(eventEnd) > 0) {
                    // if the event is after the session start
                    task->addSessionTime(duration);
                }
            } else {
                // so there is no session at all
                task->addSessionTime(duration);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto *event : eventsModel()->eventsForTask(task)) {
            QDateTime eventStart = event->dtStart();
            QDateTime eventEnd = event->dtEnd();

            const int64_t duration = event->duration() / 60;
            task->addTime(duration);
            qCDebug(KTT_LOG) << "duration is" << duration;

            if (task->sessionStartTiMe().isValid()) {
                // if there is a session
                if (task->sessionStartTiMe().secsTo(eventStart) > 0 && task->sessionStartTiMe().secsTo(eventEnd) > 0) {
                    // if the event is after the session start
                    task->addSessionTime(duration);
                }
            } else {
                // so there is no session at all
                task->addSessionTime(duration);
            }
        }
```

#### AUTO 


```{c}
auto *infoGroup = new QGroupBox(i18nc("@title:group", "Task"), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (Event *event : m_eventsModel->events()) {
        KCalendarCore::Event::Ptr calEvent(new KCalendarCore::Event());
        calendar->addEvent(event->asCalendarEvent(calEvent));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& desktopStr : desktopStrList) {
        int desktopInt = desktopStr.toInt(&ok);
        if (ok) {
            desktops.push_back(desktopInt);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : m_activeTasks) {
        QApplication::processEvents();
        task->setRunning(false, m_storage, when);
        dialog.setValue(dialog.value() + 1);
    }
```

#### AUTO 


```{c}
auto *task = taskView->addTask("1");
```

#### AUTO 


```{c}
auto *const job = KIO::storedPut(textUtf8, url, -1, KIO::Overwrite);
```

#### RANGE FOR STATEMENT 


```{c}
for (Event *event : m_eventsModel->events()) {
        KCalCore::Event::Ptr calEvent(new KCalCore::Event());
        calendar->addEvent(event->asCalendarEvent(calEvent));
    }
```

#### AUTO 


```{c}
auto* dialog = new HistoryDialog(m_parent);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &event : m_storage->rawevents()) {
        int row = m_ui.historytablewidget->rowCount();
        m_ui.historytablewidget->insertRow(row);

        // maybe the file is corrupt and (*i)->relatedTo is NULL
        if (!event->relatedTo().isEmpty()) {
            KCalCore::Incidence::Ptr parent = calendar ? calendar->incidence(event->relatedTo()) : KCalCore::Incidence::Ptr();
            auto *item = new QTableWidgetItem(parent ? parent->summary() : event->summary());
            item->setFlags(Qt::ItemIsEnabled);
            item->setWhatsThis(i18n("You can change this task's comment, start time and end time."));
            m_ui.historytablewidget->setItem(row, 0, item);

            QDateTime start = event->dtStart();
            QDateTime end = event->dtEnd();
            m_ui.historytablewidget->setItem(row, 1, new QTableWidgetItem(start.toString(dateTimeFormat)));
            m_ui.historytablewidget->setItem(row, 2, new QTableWidgetItem(end.toString(dateTimeFormat)));
            m_ui.historytablewidget->setItem(row, 4, new QTableWidgetItem(event->uid()));
            qDebug() << "event->comments.count() =" << event->comments().count();
            if (event->comments().count() > 0) {
                m_ui.historytablewidget->setItem(row, 3, new QTableWidgetItem(event->comments().last()));
            }
        } else {
            qCDebug(KTT_LOG) << "There is no 'relatedTo' entry for " << event->summary();
            err = "NoRelatedToForEvent";
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : storage()->tasksModel()->getAllTasks()) {
        // get all events for task
        for (const auto *event : storage()->eventsModel()->eventsForTask(task)) {
            QDateTime eventStart = event->dtStart();
            QDateTime eventEnd = event->dtEnd();

            const int duration = event->duration() / 60;
            task->addTime(duration);
            qCDebug(KTT_LOG) << "duration is" << duration;

            if (task->sessionStartTiMe().isValid()) {
                // if there is a session
                if (task->sessionStartTiMe().secsTo(eventStart) > 0 &&
                    task->sessionStartTiMe().secsTo(eventEnd) > 0) {
                    // if the event is after the session start
                    task->addSessionTime(duration);
                }
            } else {
                // so there is no session at all
                task->addSessionTime(duration);
            }
        }
    }
```

#### AUTO 


```{c}
auto *storagePage = new QWidget;
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : getAllTasks()) {
        if (task->uid() == taskId) {
            result = task;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : taskView->storage()->tasksModel()->getAllTasks()) {
        if (task->uid() == taskId) {
            taskView->deleteTaskBatch(task);
            taskView->save();
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : tasksModel()->getAllTasks()) {
        if (startTimeForUid.contains(task->uid())) {
            m_taskView->startTimerFor(task, startTimeForUid[task->uid()]);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        const QString &fileName = QFileDialog::getOpenFileName();
        importPlannerFile(fileName);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (TasksModelItem *item : m_model->getAllItems()) {
        Task *task = dynamic_cast<Task*>(item);
        if (task) {
            tasks.append(task);
        } else {
            qFatal("dynamic_cast to Task failed");
        }
    }
```

#### AUTO 


```{c}
auto todos = calendar->rawTodos(KCalCore::TodoSortSummary);
```

#### AUTO 


```{c}
auto *action = new QAction(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &todo : todos) {
        Task* task = new Task(todo, view, m_model);
        map.insert(todo->uid(), task);
        task->invalidateCompletedState();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : getAllTasks()) {
        if (dialog.wasCanceled()) {
            break;
        }

        dialog.setValue(dialog.value() + 1);

//        if (tasknr % 15 == 0) {
//            QApplication::processEvents(); // repainting is slow
//        }
        QApplication::processEvents();

        if (task->depth() > maxdepth) {
            maxdepth = task->depth();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : m_desktopTracker[currentDesktop]) {
        emit reachedActiveDesktop(task);
    }
```

#### AUTO 


```{c}
auto *task = dynamic_cast<Task*>(item(indexes[0]));
```

#### AUTO 


```{c}
auto *checkbox = new QCheckBox(KWindowSystem::desktopName(i + 1));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto *event : m_projectModel->eventsModel()->events()) {
        int row = m_ui.historytablewidget->rowCount();
        m_ui.historytablewidget->insertRow(row);

        // maybe the file is corrupt and (*i)->relatedTo is NULL
        if (event->relatedTo().isEmpty()) {
            qCDebug(KTT_LOG) << "There is no 'relatedTo' entry for " << event->summary();
            err = "NoRelatedToForEvent";
            continue;
        }

        const Task *parent = dynamic_cast<Task*>(m_projectModel->tasksModel()->taskByUID(event->relatedTo()));
        if (!parent) {
            qFatal("orphan event");
        }

        auto *item = new QTableWidgetItem(parent->name());
        item->setFlags(Qt::ItemIsEnabled);
        item->setWhatsThis(i18n("You can change this task's comment, start time and end time."));
        m_ui.historytablewidget->setItem(row, 0, item);

        QDateTime start = event->dtStart();
        QDateTime end = event->dtEnd();
        m_ui.historytablewidget->setItem(row, 1, new QTableWidgetItem(start.toString(dateTimeFormat)));
        m_ui.historytablewidget->setItem(row, 2, new QTableWidgetItem(end.toString(dateTimeFormat)));
        m_ui.historytablewidget->setItem(row, 4, new QTableWidgetItem(event->uid()));
        qDebug() << "event->comments.count() =" << event->comments().count();
        if (event->comments().count() > 0) {
            m_ui.historytablewidget->setItem(row, 3, new QTableWidgetItem(event->comments().last()));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : storage()->tasksModel()->getAllTasks()) {
        task->resetTimes();
    }
```

#### AUTO 


```{c}
auto *icsFile = new QTemporaryFile(parent);
```

#### AUTO 


```{c}
auto* configureAction = new QAction(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : tasksModel->getAllTasks()) {
//        if (dialog.wasCanceled()) {
//            break;
//        }
//
//        dialog.setValue(dialog.value() + 1);

//        if (tasknr % 15 == 0) {
//            QApplication::processEvents(); // repainting is slow
//        }
        QApplication::processEvents();

        // indent the task in the csv-file:
        for (int i = 0; i < task->depth(); ++i) {
            retval += delim;
        }

        /*
        // CSV compliance
        // Surround the field with quotes if the field contains
        // a comma (delim) or a double quote
        if (task->name().contains(delim) || task->name().contains(dquote))
        to_quote = true;
        else
        to_quote = false;
        */
        bool to_quote = true;

        if (to_quote) {
            retval += dquote;
        }

        // Double quotes replaced by a pair of consecutive double quotes
        retval += task->name().replace(dquote, double_dquote);

        if (to_quote) {
            retval += dquote;
        }

        // maybe other tasks are more indented, so to align the columns:
        for (int i = 0; i < maxdepth - task->depth(); ++i) {
            retval += delim;
        }

        retval += delim + formatTime(static_cast<double>(task->sessionTime()), rc.decimalMinutes) + delim
            + formatTime(static_cast<double>(task->time()), rc.decimalMinutes) + delim
            + formatTime(static_cast<double>(task->totalSessionTime()), rc.decimalMinutes) + delim
            + formatTime(static_cast<double>(task->totalTime()), rc.decimalMinutes) + '\n';
    }
```

#### AUTO 


```{c}
auto *closureTask = dynamic_cast<Task*>(model->topLevelItem(3));
```

#### RANGE FOR STATEMENT 


```{c}
for (const int desktop : m_desktops) {
        desktopsStr += QString::number(desktop) + QString::fromLatin1(",");
    }
```

#### AUTO 


```{c}
auto* const job = KIO::storedPut(retval.toUtf8(), rc.url, -1);
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : tasks) {
        qCDebug(KTT_LOG) << ", Task Name: " << task->name() << ", UID: " << task->uid();
        // uid -> seconds each day
        // * Init each element to zero
        QVector<int64_t> vector(intervalLength, 0);
        secsForUid[task->uid()] = vector;

        // name -> uid
        // * Create task fullname concatenating each parent's name
        QString fullName;
        Task *parentTask;
        parentTask = task;
        fullName += parentTask->name();
        parentTask = parentTask->parentTask();
        while (parentTask) {
            fullName = parentTask->name() + "->" + fullName;
            qCDebug(KTT_LOG) << "Fullname(inside): " << fullName;
            parentTask = parentTask->parentTask();
            qCDebug(KTT_LOG) << "Parent task: " << parentTask;
        }

        uidForName[fullName] = task->uid();

        qCDebug(KTT_LOG) << "Fullname(end): " << fullName;
    }
```

#### AUTO 


```{c}
const auto &rc = createRC(ReportCriteria::CSVTotalsExport, false);
```

#### AUTO 


```{c}
auto* engine = new QQmlApplicationEngine();
```

#### AUTO 


```{c}
auto *event = taskView->storage()->eventsModel()->eventsForTask(task)[0];
```

#### AUTO 


```{c}
const auto result = KMessageBox::questionYesNo(
        nullptr,
        i18n("Desktop has been idle since %1. What do you want to do ?", backThen),
        QString(), buttonYes, buttonNo);
```

#### AUTO 


```{c}
auto *task = m_storage->tasksModel()->taskByUID(taskUid);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& item : m_ui.historytablewidget->selectedItems()) {
        rows.insert(item->row());
    }
```

#### AUTO 


```{c}
auto *tasksWidget = taskView->tasksWidget();
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : taskView->storage()->tasksModel()->getAllTasks()) {
        if (task->uid() == taskId) {
            return task->isRunning();
        }
    }
```

#### AUTO 


```{c}
auto* widget = dynamic_cast<TimeTrackerWidget*>(parent->centralWidget());
```

#### RANGE FOR STATEMENT 


```{c}
for (QCheckBox *checkbox : m_desktopCheckboxes) {
            checkbox->setEnabled(false);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : taskView->storage()->tasksModel()->getAllTasks()) {
        if (task->uid() == taskId) {
            taskView->startTimerFor(task);
            return;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : taskView->storage()->tasksModel()->getAllTasks()) {
        if (task->uid() == taskId) {
            taskView->startTimerForNow(task);
            return;
        }
    }
```

#### AUTO 


```{c}
auto *closureTask = dynamic_cast<Task *>(model->topLevelItem(4));
```

#### AUTO 


```{c}
auto* dialog = new HistoryDialog(m_parent->tasksWidget(), m_parent->storage()->projectModel());
```

#### AUTO 


```{c}
auto *scrollArea = new QScrollArea(m_trackingGroup);
```

#### RANGE FOR STATEMENT 


```{c}
for (int row : rows) {
        QString uid = m_ui.historytablewidget->item(row, 4)->text();
        qDebug() << "uid =" << uid;
        const Event *event = m_projectModel->eventsModel()->eventByUID(uid);
        if (event) {
            qCDebug(KTT_LOG) << "removing uid " << event->uid();
            m_projectModel->eventsModel()->removeByUID(event->uid());
            refresh = true;
        }
    }
```

#### AUTO 


```{c}
auto *editLayout = new QGridLayout(editGroup);
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : storage()->tasksModel()->getAllTasks()) {
        if (!m_storage->allEventsHaveEndTime(task)) {
            task->resumeRunning();
            m_activeTasks.append(task);
            emit updateButtons();
            if (m_activeTasks.count() == 1) {
                emit timersActive();
            }
            emit tasksChanged(m_activeTasks);
        }
    }
```

#### AUTO 


```{c}
auto *app = dynamic_cast<QGuiApplication *>(QGuiApplication::instance());
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : taskView->getAllTasks()) {
        result << task->name();
    }
```

#### AUTO 


```{c}
auto *taskView = currentTaskView();
```

#### AUTO 


```{c}
const auto result = KMessageBox::questionYesNo(
        nullptr,
        i18n("Desktop has been idle since %1. What do you want to do?", backThen),
        QString(), buttonYes, buttonNo);
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : tasksModel()->getAllTasks()) {
        task->invalidateCompletedState();
        task->update(); // maybe there was a change in the times's format
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : tasksModel->getAllTasks()) {
//        if (dialog.wasCanceled()) {
//            break;
//        }
//
//        dialog.setValue(dialog.value() + 1);

//        if (tasknr % 15 == 0) {
//            QApplication::processEvents(); // repainting is slow
//        }
        QApplication::processEvents();

        // indent the task in the csv-file:
        for (int i = 0; i < task->depth(); ++i) {
            retval += delim;
        }

        /*
        // CSV compliance
        // Surround the field with quotes if the field contains
        // a comma (delim) or a double quote
        if (task->name().contains(delim) || task->name().contains(dquote))
        to_quote = true;
        else
        to_quote = false;
        */
        bool to_quote = true;

        if (to_quote) {
            retval += dquote;
        }

        // Double quotes replaced by a pair of consecutive double quotes
        retval += task->name().replace(dquote, double_dquote);

        if (to_quote) {
            retval += dquote;
        }

        // maybe other tasks are more indented, so to align the columns:
        for (int i = 0; i < maxdepth - task->depth(); ++i) {
            retval += delim;
        }

        retval += delim + formatTime(task->sessionTime(), rc.decimalMinutes)
                  + delim + formatTime(task->time(), rc.decimalMinutes)
                  + delim + formatTime(task->totalSessionTime(), rc.decimalMinutes)
                  + delim + formatTime(task->totalTime(), rc.decimalMinutes)
                  + '\n';
    }
```

#### AUTO 


```{c}
auto *task
```

#### AUTO 


```{c}
auto *desktopsWidget = new QWidget(m_trackingGroup);
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : tasksModel()->getActiveTasks()) {
        startTimeForUid[task->uid()] = task->startTime();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : getAllTasks()) {
        if (!m_storage->allEventsHaveEndTiMe(task)) {
            task->resumeRunning();
            m_activeTasks.append(task);
            emit updateButtons();
            if (m_activeTasks.count() == 1) {
                emit timersActive();
            }
            emit tasksChanged(m_activeTasks);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : getAllTasks()) {
        task->resetTimes();
    }
```

#### AUTO 


```{c}
auto *task = dynamic_cast<Task *>(item(indexes[0]));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &event : m_storage->rawevents()) {
                if (event->uid() == uid) {
                    event->addComment(m_ui.historytablewidget->item(row, col)->text());
                    qCDebug(KTT_LOG) << "added" << m_ui.historytablewidget->item(row, col)->text();
                }
            }
```

#### AUTO 


```{c}
auto *task2 = taskView->task(taskView->addTask("2", QString(), 0, 0, QVector<int>(0, 0), task1));
```

#### AUTO 


```{c}
auto* action = new QAction(this);
```

#### AUTO 


```{c}
auto *mainWindow = dynamic_cast<MainWindow *>(parent()->parent());
```

#### AUTO 


```{c}
auto* const job = KIO::storedPut(textUtf8, url, -1, KIO::Overwrite);
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : getAllTasks()) {
        task->invalidateCompletedState();
        task->update();  // maybe there was a change in the times's format
    }
```

#### AUTO 


```{c}
auto* dialog = new HistoryDialog(m_parent, m_parent->storage());
```

#### AUTO 


```{c}
const auto &item
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : getAllTasks()) {
        if (dialog.wasCanceled()) {
            break;
        }

        dialog.setValue(dialog.value() + 1);

//        if (tasknr % 15 == 0) {
//            QApplication::processEvents(); // repainting is slow
//        }
        QApplication::processEvents();

        // indent the task in the csv-file:
        for (int i = 0; i < task->depth(); ++i) {
            retval += delim;
        }

        /*
        // CSV compliance
        // Surround the field with quotes if the field contains
        // a comma (delim) or a double quote
        if (task->name().contains(delim) || task->name().contains(dquote))
        to_quote = true;
        else
        to_quote = false;
        */
        bool to_quote = true;

        if (to_quote) {
            retval += dquote;
        }

        // Double quotes replaced by a pair of consecutive double quotes
        retval += task->name().replace(dquote, double_dquote);

        if (to_quote) {
            retval += dquote;
        }

        // maybe other tasks are more indented, so to align the columns:
        for (int i = 0; i < maxdepth - task->depth(); ++i) {
            retval += delim;
        }

        retval += delim + formatTime(task->sessionTime(), rc.decimalMinutes)
                  + delim + formatTime(task->time(), rc.decimalMinutes)
                  + delim + formatTime(task->totalSessionTime(), rc.decimalMinutes)
                  + delim + formatTime(task->totalTime(), rc.decimalMinutes)
                  + '\n';
    }
```

#### AUTO 


```{c}
auto *dialog = new KConfigDialog(this, "settings", KTimeTrackerSettings::self());
```

#### AUTO 


```{c}
auto *const job = KIO::storedGet(url, KIO::Reload);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto *event : m_projectModel->eventsModel()->events()) {
        int row = m_ui.historytablewidget->rowCount();
        m_ui.historytablewidget->insertRow(row);

        // maybe the file is corrupt and (*i)->relatedTo is NULL
        if (event->relatedTo().isEmpty()) {
            qCDebug(KTT_LOG) << "There is no 'relatedTo' entry for " << event->summary();
            err = "NoRelatedToForEvent";
            continue;
        }

        const Task *parent = dynamic_cast<Task*>(m_projectModel->tasksModel()->taskByUID(event->relatedTo()));
        if (!parent) {
            qFatal("orphan event");
        }

        auto *item = new QTableWidgetItem(parent->name());
        item->setFlags(Qt::ItemIsEnabled);
        item->setWhatsThis(i18nc("@info:whatsthis", "You can change this task's comment, start time and end time."));
        m_ui.historytablewidget->setItem(row, 0, item);

        QDateTime start = event->dtStart();
        QDateTime end = event->dtEnd();
        m_ui.historytablewidget->setItem(row, 1, new QTableWidgetItem(start.toString(dateTimeFormat)));
        m_ui.historytablewidget->setItem(row, 2, new QTableWidgetItem(end.toString(dateTimeFormat)));
        m_ui.historytablewidget->setItem(row, 4, new QTableWidgetItem(event->uid()));
        qDebug() << "event->comments.count() =" << event->comments().count();
        if (event->comments().count() > 0) {
            m_ui.historytablewidget->setItem(row, 3, new QTableWidgetItem(event->comments().last()));
        }
    }
```

#### AUTO 


```{c}
auto *model = taskView->storage()->tasksModel();
```

#### AUTO 


```{c}
const auto &rc = createRC(ReportCriteria::CSVTotalsExport);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *task : getAllItems()) {
        task->invalidateRunningState();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : taskView->getAllTasks()) {
        if (task->name() == taskName) {
            result << task->uid();
        }
    }
```

#### AUTO 


```{c}
auto *e = new Event(baseEvent(task));
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *checkbox : m_trackingDesktops) {
            if (checkbox->isChecked()) {
                res.append(i);
            }

            i++;
        }
```

#### AUTO 


```{c}
auto* mainWindow = dynamic_cast<MainWindow*>(parent()->parent());
```

#### AUTO 


```{c}
auto *taskView = createTaskView(true);
```

#### AUTO 


```{c}
const auto result =
        KMessageBox::questionYesNo(nullptr,
                                   i18n("Desktop has been idle since %1. What do you want to do?", backThen),
                                   QString(),
                                   buttonYes,
                                   buttonNo);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *event : events()) {
        if (event->relatedTo() == task->uid()) {
            res.append(event);
        }
    }
```

#### AUTO 


```{c}
auto *closureTask = dynamic_cast<Task*>(model->topLevelItem(4));
```

#### AUTO 


```{c}
auto e = baseEvent(task);
```

#### AUTO 


```{c}
auto *taskView = new TaskView();
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : taskView->storage()->tasksModel()->getAllTasks()) {
        if (task->uid() == taskId) {
            taskView->deleteTaskBatch(task);
        }
    }
```

#### AUTO 


```{c}
auto *handler = new PlannerParser(storage()->projectModel(), m_tasksWidget->currentItem());
```

#### AUTO 


```{c}
auto *placeholderWidget = new QWidget(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : getAllTasks()) {
        task->startNewSession();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : storage()->tasksModel()->getAllTasks()) {
            if (task->name() == newTaskName) {
                startTimerForNow(task);
                m_lastTaskWithFocus = task;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : storage()->tasksModel()->getAllTasks()) {
        task->invalidateCompletedState();
        task->update();  // maybe there was a change in the times's format
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        m_editHistoryRequested = true;
        accept();
    }
```

#### AUTO 


```{c}
auto *itm = const_cast<TasksModelItem*>(item);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &item : m_ui.historytablewidget->selectedItems()) {
        rows.insert(item->row());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : taskView->getAllTasks()) {
        if (task->uid() == taskId) {
            task->setPercentComplete(percent, taskView->storage());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (int desktop : *desktopList) {
            m_desktopCheckboxes[desktop]->setChecked(true);
        }
```

#### AUTO 


```{c}
auto *taskView = createTaskView(false);
```

#### AUTO 


```{c}
auto *dialog = new HistoryDialog(currentTaskView()->tasksWidget(), currentTaskView()->storage()->projectModel());
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : tasksModel()->getAllTasks()) {
        if (task->isRunning()) {
            runningTasks.append(task->uid());
            startTimes.append(task->startTime());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &comment : comments()) {
        event->addComment(comment);
    }
```

#### AUTO 


```{c}
const auto& otherTask = dynamic_cast<const Task&>(other);
```

#### AUTO 


```{c}
auto *dialog = new EditTaskDialog(this, caption, 0);
```

#### AUTO 


```{c}
auto* historyWidgetDelegate = new HistoryWidgetDelegate(m_ui.historytablewidget);
```

#### AUTO 


```{c}
auto *checkbox
```

#### AUTO 


```{c}
auto *item = static_cast<TasksModelItem *>(child.internalPointer());
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : taskView->getAllTasks()) {
        if (task->uid() == taskId) {
            task->setPercentComplete(percent);
        }
    }
```

#### AUTO 


```{c}
auto *dialog = new EditTaskDialog(m_tasksWidget->parentWidget(), storage()->projectModel(), i18n("Edit Task"), &desktopList);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &todo : todos) {
        Task *task = map.value(todo->uid());
        // No relatedTo incident just means this is a top-level task.
        if (!todo->relatedTo().isEmpty()) {
            Task *newParent = map.value(todo->relatedTo());
            // Complete the loading but return a message
            if (!newParent) {
                err = i18n("Error loading \"%1\": could not find parent (uid=%2)",
                           task->name(),
                           todo->relatedTo());
            } else {
                task->move(newParent);
            }
        }
    }
```

#### AUTO 


```{c}
auto *task1 = taskView->task(taskView->addTask("1"));
```

#### RANGE FOR STATEMENT 


```{c}
for (int index : desktops) {
        if (index >= 0 && index < numDesktops) {
            m_trackingDesktops[index]->setChecked(true);
        }
    }
```

#### AUTO 


```{c}
auto *behaviorUi = new Ui::BehaviorPage;
```

#### AUTO 


```{c}
const auto &todo
```

#### AUTO 


```{c}
auto *displayPage = new QWidget;
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : taskView->getAllTasks()) {
        if (task->uid() == taskId) {
            taskView->startTimerFor(task);
            return;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : taskView->storage()->tasksModel()->getAllTasks()) {
        if (task->uid() == taskId) {
            return task->totalTime();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : taskView->storage()->tasksModel()->getAllTasks()) {
        if (task->name() == taskName) {
            taskView->stopTimerFor(task);
            return true;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : mActions) {
            mContextMenu->removeAction(action);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &todo : todos) {
        Task *task = new Task(todo, m_model);
        map.insert(todo->uid(), task);
        task->invalidateCompletedState();
    }
```

#### AUTO 


```{c}
auto* app = dynamic_cast<QGuiApplication*>(QGuiApplication::instance());
```

#### AUTO 


```{c}
auto *m_buttonBox = new QDialogButtonBox(this);
```

#### AUTO 


```{c}
const auto absMinutes = static_cast<qlonglong>(std::round(std::fabs(minutes)));
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *item : m_tasksModel->getAllItems()) {
        Task *task = dynamic_cast<Task *>(item);

        KCalCore::Todo::Ptr todo(new KCalCore::Todo());
        calendar->addTodo(task->asTodo(todo));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &event : events) {
        m_events.append(new Event(event));
    }
```

#### AUTO 


```{c}
auto *item = new QTableWidgetItem(parent->name());
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : taskView->storage()->tasksModel()->getAllTasks()) {
        if (task->name() == taskName ) {
            taskView->startTimerFor(task);
            return true;
        }
    }
```

#### AUTO 


```{c}
auto oldDeskTopList = task->desktops();
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : storage()->tasksModel()->getAllTasks()) {
        if (task->name() == newTaskName) {
            found = true;
            startTimerFor(task);
            m_lastTaskWithFocus = task;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : tasksModel->getAllTasks()) {
//        if (dialog.wasCanceled()) {
//            break;
//        }
//
//        dialog.setValue(dialog.value() + 1);

//        if (tasknr % 15 == 0) {
//            QApplication::processEvents(); // repainting is slow
//        }
        QApplication::processEvents();

        if (task->depth() > maxdepth) {
            maxdepth = task->depth();
        }
    }
```

#### AUTO 


```{c}
auto* const job = KIO::storedGet(url, KIO::Reload);
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : storage()->tasksModel()->getAllTasks()) {
        // Start recursive method recalculateTotalTimesSubtree() for each top-level task.
        if (task->isRoot()) {
            task->recalculateTotalTimesSubtree();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : view->getAllTasks()) {
        for (int n = 0; n < runningTasks.count(); ++n) {
            if (runningTasks[n] == task->uid()) {
                view->startTimerFor(task, startTimes[n]);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : getAllTasks()) {
        m_desktopTracker->registerForDesktops(task, task->desktops());
    }
```

#### AUTO 


```{c}
const auto &rc = createRC(ReportCriteria::CSVHistoryExport, false);
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : taskview->getAllTasks()) {
        if (dialog.wasCanceled()) {
            break;
        }

        dialog.setValue(dialog.value() + 1);

//        if (tasknr % 15 == 0) {
//            QApplication::processEvents(); // repainting is slow
//        }
        QApplication::processEvents();

        // indent the task in the csv-file:
        for (int i = 0; i < task->depth(); ++i) {
            retval += delim;
        }

        /*
        // CSV compliance
        // Surround the field with quotes if the field contains
        // a comma (delim) or a double quote
        if (task->name().contains(delim) || task->name().contains(dquote))
        to_quote = true;
        else
        to_quote = false;
        */
        bool to_quote = true;

        if (to_quote) {
            retval += dquote;
        }

        // Double quotes replaced by a pair of consecutive double quotes
        retval += task->name().replace(dquote, double_dquote);

        if (to_quote) {
            retval += dquote;
        }

        // maybe other tasks are more indented, so to align the columns:
        for (int i = 0; i < maxdepth - task->depth(); ++i) {
            retval += delim;
        }

        retval += delim + formatTime(task->sessionTime(), rc.decimalMinutes)
                + delim + formatTime(task->time(), rc.decimalMinutes)
                + delim + formatTime(task->totalSessionTime(), rc.decimalMinutes)
                + delim + formatTime(task->totalTime(), rc.decimalMinutes)
                + '\n';
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QCheckBox *checkbox : m_desktopCheckboxes) {
        checkbox->setEnabled(m_ui.autotrackinggroupbox->isChecked());
     }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto *event : m_model->eventsModel()->eventsForTask(task)) {
        if (!event->hasEndDate()) {
            return false;
        }
    }
```

#### AUTO 


```{c}
auto *idletimedetector1=new IdleTimeDetector(50);
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : mActions) {
        updateAction(action, mActionColumnMapping[action]);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : taskView->storage()->tasksModel()->getAllTasks()) {
        if (task->name() == taskName) {
            taskView->startTimerForNow(task);
            return true;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : getAllTasks()) {
            if (task->name() == newTaskName) {
                found = true;
                startTimerFor(task);
                m_lastTaskWithFocus = task;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : taskView->getAllTasks()) {
        if (task->uid() == taskId) {
            taskView->deleteTaskBatch(task);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : m_desktopTracker[m_desktop]) {
        emit reachedActiveDesktop(task);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : taskView->storage()->tasksModel()->getAllTasks()) {
        if (task->uid() == taskId) {
            taskView->deleteTaskBatch(task);
            break;
        }
    }
```

#### AUTO 


```{c}
auto *model = taskView->tasksModel();
```

#### AUTO 


```{c}
auto comment
```

#### AUTO 


```{c}
auto *historyButton = new QPushButton(
        QIcon::fromTheme("document-edit"), i18nc("@action:button", "Edit History..."), m_buttonBox);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *event : eventsForTask(task)) {
        if (!event->hasEndDate()) {
            openEvents.append(event);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : taskView->storage()->tasksModel()->getAllTasks()) {
        result << task->name();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : m_activeTasks) {
        QApplication::processEvents();

        task->setRunning(false, when);
        save();

        dialog.setValue(dialog.value() + 1);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (TasksModelItem *item : m_children) {
            item->sortChildren(column, order, climb);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (TasksModelItem *item : getAllItems()) {
        Task *task = dynamic_cast<Task*>(item);
        if (task) {
            tasks.append(task);
        } else {
            qFatal("dynamic_cast to Task failed");
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const int desktop : mDesktops) {
        desktopsStr += QString::number(desktop) + QString::fromLatin1(",");
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto comment : comments()) {
        event->addComment(comment);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *item : m_tasksModel->getAllItems()) {
        Task *task = dynamic_cast<Task*>(item);

        KCalCore::Todo::Ptr todo(new KCalCore::Todo());
        calendar->addTodo(task->asTodo(todo));
    }
```

#### AUTO 


```{c}
auto *itm = const_cast<TasksModelItem *>(item);
```

#### AUTO 


```{c}
const auto &comment
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto *event : m_projectModel->eventsModel()->events()) {
        int row = m_ui.historytablewidget->rowCount();
        m_ui.historytablewidget->insertRow(row);

        // maybe the file is corrupt and (*i)->relatedTo is NULL
        if (event->relatedTo().isEmpty()) {
            qCDebug(KTT_LOG) << "There is no 'relatedTo' entry for " << event->summary();
            err = "NoRelatedToForEvent";
            continue;
        }

        const Task *parent = dynamic_cast<Task *>(m_projectModel->tasksModel()->taskByUID(event->relatedTo()));
        if (!parent) {
            qCWarning(KTT_LOG) << "Unable to load 'relatedTo' entry for " << event->summary();
            err = "NoRelatedToForEvent";
            continue;
        }

        auto *item = new QTableWidgetItem(parent->name());
        item->setFlags(Qt::ItemIsEnabled);
        item->setWhatsThis(i18nc("@info:whatsthis", "You can change this task's comment, start time and end time."));
        m_ui.historytablewidget->setItem(row, 0, item);

        QDateTime start = event->dtStart();
        QDateTime end = event->dtEnd();
        m_ui.historytablewidget->setItem(row, 1, new QTableWidgetItem(start.toString(dateTimeFormat)));
        m_ui.historytablewidget->setItem(row, 2, new QTableWidgetItem(end.toString(dateTimeFormat)));
        m_ui.historytablewidget->setItem(row, 4, new QTableWidgetItem(event->uid()));
        qDebug() << "event->comments.count() =" << event->comments().count();
        if (event->comments().count() > 0) {
            m_ui.historytablewidget->setItem(row, 3, new QTableWidgetItem(event->comments().last()));
        }
    }
```

#### AUTO 


```{c}
auto *task2Mirror = taskView2->storage()->tasksModel()->taskByUID(task2->uid());
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : taskView->getAllTasks()) {
        if (task->name() == taskName) {
            return task->isRunning();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : taskView->storage()->tasksModel()->getAllTasks()) {
        if (task->name() == taskName ) {
            taskView->startTimerForNow(task);
            return true;
        }
    }
```

#### AUTO 


```{c}
auto *file = new QTemporaryFile(this);
```

#### AUTO 


```{c}
auto *dateTimeWidget = dynamic_cast<QDateTimeEdit*>(editor);
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : m_desktopTracker[m_previousDesktop]) {
        emit leftActiveDesktop(task);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : tasksModel()->getAllTasks()) {
        // get all events for task
        for (const auto *event : eventsModel()->eventsForTask(task)) {
            QDateTime eventStart = event->dtStart();
            QDateTime eventEnd = event->dtEnd();

            const int64_t duration = event->duration() / 60;
            task->addTime(duration);
            qCDebug(KTT_LOG) << "duration is" << duration;

            if (task->sessionStartTiMe().isValid()) {
                // if there is a session
                if (task->sessionStartTiMe().secsTo(eventStart) > 0 && task->sessionStartTiMe().secsTo(eventEnd) > 0) {
                    // if the event is after the session start
                    task->addSessionTime(duration);
                }
            } else {
                // so there is no session at all
                task->addSessionTime(duration);
            }
        }
    }
```

#### AUTO 


```{c}
const auto *event
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& event : events) {
        m_events.append(new Event(event));
    }
```

#### AUTO 


```{c}
auto *e = new Event(kcalEvent);
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : m_activeTasks) {
        task->changeTime(minutes, save_data ? m_storage : 0);
    }
```

#### AUTO 


```{c}
const auto& event
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *item : m_tasksModel->getAllItems()) {
            auto *task = dynamic_cast<Task*>(item);
            setExpanded(m_filterProxyModel->mapFromSource(
                m_tasksModel->index(task, 0)), readBoolEntry(task->uid()));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto *event : m_model->eventsModel()->events()) {
        if (!event->hasEndDate()) {
            return false;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : storage()->tasksModel()->getAllTasks()) {
        if (task->name() == newTaskName) {
            found = true;
            startTimerForNow(task);
            m_lastTaskWithFocus = task;
        }
    }
```

#### AUTO 


```{c}
auto *mainLayout = new QVBoxLayout(this);
```

#### AUTO 


```{c}
static const auto cr = QStringLiteral("\n");
```

#### AUTO 


```{c}
auto it = m_events.begin();
```

#### AUTO 


```{c}
auto* keyEvent = dynamic_cast<QKeyEvent*>(event);
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *t : taskView->getAllTasks()) {
            if (t->uid() == taskId) {
                task = t;
                break;
            }
        }
```

#### AUTO 


```{c}
auto *task = dynamic_cast<Task*>(item);
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : storage()->tasksModel()->getAllTasks()) {
        if (!m_storage->allEventsHaveEndTiMe(task)) {
            task->resumeRunning();
            m_activeTasks.append(task);
            emit updateButtons();
            if (m_activeTasks.count() == 1) {
                emit timersActive();
            }
            emit tasksChanged(m_activeTasks);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : getAllTasks()) {
        result << task->name();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : m_actions) {
        updateAction(action, m_actionColumnMapping[action]);
    }
```

#### AUTO 


```{c}
const auto &rc = createRC(ReportCriteria::CSVHistoryExport);
```

#### AUTO 


```{c}
auto *task = dynamic_cast<Task *>(item);
```

#### AUTO 


```{c}
const auto& item
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : storage()->tasksModel()->getAllTasks()) {
        // get all events for task
        for (const auto *event : storage()->eventsModel()->eventsForTask(task)) {
            QDateTime kdatetimestart = event->dtStart();
            QDateTime kdatetimeend = event->dtEnd();
            QDateTime eventstart = QDateTime::fromString(kdatetimestart.toString().remove("Z"));
            QDateTime eventend = QDateTime::fromString(kdatetimeend.toString().remove("Z"));
            int duration = eventstart.secsTo(eventend) / 60;
            task->addTime(duration);
            qCDebug(KTT_LOG) << "duration is" << duration;

            if (task->sessionStartTiMe().isValid()) {
                // if there is a session
                if (task->sessionStartTiMe().secsTo(eventstart) > 0 &&
                    task->sessionStartTiMe().secsTo(eventend) > 0) {
                    // if the event is after the session start
                    int sessionTime = eventstart.secsTo(eventend) / 60;
                    task->setSessionTime(task->sessionTime() + sessionTime);
                }
            } else {
                // so there is no session at all
                task->addSessionTime(duration);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &desktopStr : desktopStrList) {
        int desktopInt = desktopStr.toInt(&ok);
        if (ok) {
            desktops.push_back(desktopInt);
        }
    }
```

#### AUTO 


```{c}
auto *task = taskByUID(m_dragCutTaskId);
```

#### AUTO 


```{c}
auto *headerContextMenu = new TreeViewHeaderContextMenu(this, m_tasksWidget, QVector<int>{0});
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &event : m_storage->rawevents()) {
                qDebug() <<"row=" << row <<" col=" << col;
                if (event->uid() == uid) {
                    QDateTime datetime = QDateTime::fromString(m_ui.historytablewidget->item(row, col)->text(), dateTimeFormat);
                    if (datetime.isValid()) {
                        event->setDtEnd(datetime);
                        emit timesChanged();
                        qCDebug(KTT_LOG) << "Program SetDtEnd to" << m_ui.historytablewidget->item(row, col)->text();
                    } else {
                        KMessageBox::information(nullptr, i18n("This is not a valid Date/Time."));
                    }
                }
            }
```

#### AUTO 


```{c}
auto* editor = new QDateTimeEdit(parent);
```

#### AUTO 


```{c}
auto *nameText = new QLineEdit(name, infoGroup);
```

#### AUTO 


```{c}
auto *storageUi = new Ui::StoragePage;
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : tasksModel()->getAllTasks()) {
        // Start recursive method recalculateTotalTimesSubtree() for each top-level task.
        if (task->isRoot()) {
            task->recalculateTotalTimesSubtree();
        }
    }
```

#### AUTO 


```{c}
auto *historyButton =
        new QPushButton(QIcon::fromTheme("document-edit"), i18nc("@action:button", "Edit History..."), m_buttonBox);
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : view->getAllTasks()) {
        if (task->isRunning()) {
            runningTasks.append(task->uid());
            startTimes.append(task->startTime());
        }
    }
```

#### AUTO 


```{c}
auto *tasksModel = m_storage->tasksModel();
```

#### AUTO 


```{c}
auto *item = new QTableWidgetItem(parent ? parent->summary() : event->summary());
```

#### AUTO 


```{c}
auto *taskView2 = new TaskView();
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : m_actions) {
            m_contextMenu->removeAction(action);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &event : calendar->rawEventsForDate(mdate)) {
            qCDebug(KTT_LOG) << "Summary: " << event->summary() << ", Related to uid: " << event->relatedTo();
            qCDebug(KTT_LOG) << "Today's seconds: " << todaySeconds(mdate, event);
            secsForUid[event->relatedTo()][from.daysTo(mdate)] += todaySeconds(mdate, event);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *item : m_tasksModel->getAllItems()) {
        Task *task = dynamic_cast<Task*>(item);

        KCalendarCore::Todo::Ptr todo(new KCalendarCore::Todo());
        calendar->addTodo(task->asTodo(todo));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *item : getAllItems()) {
        auto *task = dynamic_cast<Task *>(item);
        if (task->uid() == uid) {
            return task;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (TasksModelItem *item : tasksModel()->getAllItems()) {
            Task *task = dynamic_cast<Task*>(item);
            if (task) {
                tasks.append(task);
            } else {
                qFatal("dynamic_cast to Task failed");
            }
        }
```

#### AUTO 


```{c}
auto events = calendar->rawEvents(KCalCore::EventSortSummary);
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : m_activeTasks) {
        task->changeTime(minutes, save_data ? m_storage : nullptr);
    }
```

#### AUTO 


```{c}
auto *widget = dynamic_cast<TimeTrackerWidget *>(parent->centralWidget());
```

#### AUTO 


```{c}
auto *task = addTask(taskName, taskDescription, total, session, desktopList, parent);
```

#### AUTO 


```{c}
auto *task1 = taskView->addTask("1");
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto *event : eventsModel()->eventsForTask(task)) {
            QDateTime eventStart = event->dtStart();
            QDateTime eventEnd = event->dtEnd();

            const int64_t duration = event->duration() / 60;
            task->addTime(duration);
            qCDebug(KTT_LOG) << "duration is" << duration;

            if (task->sessionStartTiMe().isValid()) {
                // if there is a session
                if (task->sessionStartTiMe().secsTo(eventStart) > 0 &&
                    task->sessionStartTiMe().secsTo(eventEnd) > 0) {
                    // if the event is after the session start
                    task->addSessionTime(duration);
                }
            } else {
                // so there is no session at all
                task->addSessionTime(duration);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : storage()->tasksModel()->getAllTasks()) {
        task->recalculatetotaltime();
        task->recalculatetotalsessiontime();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *t : taskView->storage()->tasksModel()->getAllTasks()) {
            if (t->uid() == taskId) {
                task = t;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : getActiveTasks()) {
        task->changeTime(minutes, nullptr);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &todo : todos) {
        Task* task = map.value(todo->uid());
        // No relatedTo incident just means this is a top-level task.
        if (!todo->relatedTo().isEmpty()) {
            Task* newParent = map.value(todo->relatedTo());
            // Complete the loading but return a message
            if (!newParent) {
                err = i18n("Error loading \"%1\": could not find parent (uid=%2)",
                           task->name(),
                           todo->relatedTo());
            } else {
                task->move(newParent);
            }
        }
    }
```

#### AUTO 


```{c}
auto *keyEvent = dynamic_cast<QKeyEvent *>(event);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &event : m_storage->rawevents()) {
            if (event->uid() == uid) {
                qCDebug(KTT_LOG) << "removing uid " << event->uid();
                m_storage->removeEvent(event->uid());
                emit timesChanged();
                this->refresh();
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : getAllTasks()) {
        ++n;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &event : m_storage->rawevents()) {
        int row = m_ui.historytablewidget->rowCount();
        m_ui.historytablewidget->insertRow(row);

        // maybe the file is corrupt and (*i)->relatedTo is NULL
        if (!event->relatedTo().isEmpty()) {
            KCalCore::Incidence::Ptr parent = calendar ? calendar->incidence(event->relatedTo()) : KCalCore::Incidence::Ptr();
            auto *item = new QTableWidgetItem(parent ? parent->summary() : event->summary());
            item->setFlags(Qt::ItemIsEnabled);
            item->setWhatsThis(i18n("You can change this task's comment, start time and end time."));
            m_ui.historytablewidget->setItem(row, 0, item);
            // dtStart is stored like DTSTART;TZID=Europe/Berlin:20080327T231056
            // dtEnd is stored like DTEND:20080327T231509Z
            // we need to handle both differently
            QDateTime start = QDateTime::fromTime_t(event->dtStart().toTime_t());
            QDateTime end = QDateTime::fromString(event->dtEnd().toString(), Qt::ISODate);
            qDebug() << "start =" << start << "; end =" << end;
            m_ui.historytablewidget->setItem(row, 1, new QTableWidgetItem(start.toString(dateTimeFormat)));
            m_ui.historytablewidget->setItem(row, 2, new QTableWidgetItem(end.toString(dateTimeFormat)));
            m_ui.historytablewidget->setItem(row, 4, new QTableWidgetItem(event->uid()));
            qDebug() << "event->comments.count() =" << event->comments().count();
            if (event->comments().count() > 0) {
                m_ui.historytablewidget->setItem(row, 3, new QTableWidgetItem(event->comments().last()));
            }
        } else {
            qCDebug(KTT_LOG) << "There is no 'relatedTo' entry for " << event->summary();
            err = "NoRelatedToForEvent";
        }
    }
```

#### AUTO 


```{c}
auto *handler = new PlannerParser(this, currentTask);
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : taskView->getAllTasks()) {
        if (task->name() == taskName ) {
            taskView->startTimerFor(task);
            return true;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : getAllTasks()) {
        // get all events for task
        for (const auto *event : storage()->eventsModel()->eventsForTask(task)) {
            QDateTime kdatetimestart = event->dtStart();
            QDateTime kdatetimeend = event->dtEnd();
            QDateTime eventstart = QDateTime::fromString(kdatetimestart.toString().remove("Z"));
            QDateTime eventend = QDateTime::fromString(kdatetimeend.toString().remove("Z"));
            int duration = eventstart.secsTo(eventend) / 60;
            task->addTime(duration);
            qCDebug(KTT_LOG) << "duration is" << duration;

            if (task->sessionStartTiMe().isValid()) {
                // if there is a session
                if (task->sessionStartTiMe().secsTo(eventstart) > 0 &&
                    task->sessionStartTiMe().secsTo(eventend) > 0) {
                    // if the event is after the session start
                    int sessionTime = eventstart.secsTo(eventend) / 60;
                    task->setSessionTime(task->sessionTime() + sessionTime);
                }
            } else {
                // so there is no session at all
                task->addSessionTime(duration);
            }
        }
    }
```

#### AUTO 


```{c}
auto *behaviorPage = new QWidget;
```

#### AUTO 


```{c}
auto *dialog = new EditTaskDialog(m_tasksWidget->parentWidget(), storage()->projectModel(), caption, nullptr);
```

#### AUTO 


```{c}
auto *taskView = createTaskView(this, false);
```

#### AUTO 


```{c}
auto *infoLayout = new QGridLayout(infoGroup);
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
            const QString &fileName = QFileDialog::getOpenFileName();
            importPlannerFile(fileName);
        }
```

#### AUTO 


```{c}
auto *lay = new QHBoxLayout(this);
```

#### AUTO 


```{c}
auto tasks = projectModel->tasksModel()->getAllTasks();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto *event : storage()->eventsModel()->eventsForTask(task)) {
            QDateTime kdatetimestart = event->dtStart();
            QDateTime kdatetimeend = event->dtEnd();
            QDateTime eventstart = QDateTime::fromString(kdatetimestart.toString().remove("Z"));
            QDateTime eventend = QDateTime::fromString(kdatetimeend.toString().remove("Z"));
            int duration = eventstart.secsTo(eventend) / 60;
            task->addTime(duration);
            qCDebug(KTT_LOG) << "duration is" << duration;

            if (task->sessionStartTiMe().isValid()) {
                // if there is a session
                if (task->sessionStartTiMe().secsTo(eventstart) > 0 &&
                    task->sessionStartTiMe().secsTo(eventend) > 0) {
                    // if the event is after the session start
                    int sessionTime = eventstart.secsTo(eventend) / 60;
                    task->setSessionTime(task->sessionTime() + sessionTime);
                }
            } else {
                // so there is no session at all
                task->addSessionTime(duration);
            }
        }
```

#### AUTO 


```{c}
auto *editGroup = new QGroupBox(i18nc("@title:group", "Time Editing"), this);
```

#### AUTO 


```{c}
auto* task = m_storage->tasksModel()->taskByUID(taskUid);
```

#### AUTO 


```{c}
auto *parentItem = tasksModel()->item(parent);
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : tasks) {
        qCDebug(KTT_LOG) << ", Task Name: " << task->name() << ", UID: " << task->uid();
        // uid -> seconds each day
        // * Init each element to zero
        QVector<int> vector(intervalLength, 0);
        secsForUid[task->uid()] = vector;

        // name -> uid
        // * Create task fullname concatenating each parent's name
        QString fullName;
        Task* parentTask;
        parentTask = task;
        fullName += parentTask->name();
        parentTask = parentTask->parentTask();
        while (parentTask) {
            fullName = parentTask->name() + "->" + fullName;
            qCDebug(KTT_LOG) << "Fullname(inside): " << fullName;
            parentTask = parentTask->parentTask();
            qCDebug(KTT_LOG) << "Parent task: " << parentTask;
        }

        uidForName[fullName] = task->uid();

        qCDebug(KTT_LOG) << "Fullname(end): " << fullName;
    }
```

#### AUTO 


```{c}
auto* const job = KIO::storedPut(data.toUtf8(), url, -1);
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : getAllTasks()) {
            setExpanded(m_filterProxyModel->mapFromSource(m_model->index(task, 0)), readBoolEntry(task->uid()));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : tasksModel()->getAllTasks()) {
        task->invalidateCompletedState();
        task->update();  // maybe there was a change in the times's format
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *t : taskView->storage()->tasksModel()->getAllTasks()) {
        if (t->uid() == taskId) {
            task = t;
            break;
        }
    }
```

#### AUTO 


```{c}
auto desktopList = dialog->desktops();
```

#### AUTO 


```{c}
const auto absMinutes = static_cast<long long int>(std::round(std::fabs(minutes)));
```

#### AUTO 


```{c}
auto todos = calendar->rawTodos(KCalendarCore::TodoSortSummary);
```

#### AUTO 


```{c}
auto *dialog = new HistoryDialog(m_tasksWidget->parentWidget(), storage()->projectModel());
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *t : taskView->getAllTasks()) {
        if (t->uid() == taskId) {
            task = t;
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto *event : projectModel->eventsModel()->events()) {
        row.clear();

        QDateTime start = event->dtStart();
        QDateTime end = event->dtEnd();

        if (start.date() < from || end.date() > to) {
            continue;
        }

        // Write CSV row
        row.append(start.toString(dateTimeFormat));
        row.append(delim);
        row.append(end.toString(dateTimeFormat));
        row.append(delim);
        row.append(getFullEventName(event, projectModel));
        row.append(delim);

        qDebug() << "event->comments.count() =" << event->comments().count();
        if (event->comments().count() > 0) {
            row.append(event->comments().last());
        }
        row.append(delim);

        row.append(event->uid());
        row.append(cr);

        events.append(row);
    }
```

#### AUTO 


```{c}
auto *file = new QTemporaryFile();
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : taskView->storage()->tasksModel()->getAllTasks()) {
        if (task->uid() == taskId) {
            task->setPercentComplete(percent);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : tasksModel()->getAllTasks()) {
        for (int n = 0; n < runningTasks.count(); ++n) {
            if (runningTasks[n] == task->uid()) {
                view->startTimerFor(task, startTimes[n]);
            }
        }
    }
```

#### AUTO 


```{c}
auto *closureTask = dynamic_cast<Task *>(task1->child(4));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &todo : todos) {
        Task *task = map.value(todo->uid());
        // No relatedTo incident just means this is a top-level task.
        if (!todo->relatedTo().isEmpty()) {
            Task *newParent = map.value(todo->relatedTo());
            // Complete the loading but return a message
            if (!newParent) {
                err = i18n("Error loading \"%1\": could not find parent (uid=%2)", task->name(), todo->relatedTo());
            } else {
                task->move(newParent);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto *event : m_projectModel->eventsModel()->events()) {
        int row = m_ui.historytablewidget->rowCount();
        m_ui.historytablewidget->insertRow(row);

        // maybe the file is corrupt and (*i)->relatedTo is NULL
        if (event->relatedTo().isEmpty()) {
            qCDebug(KTT_LOG) << "There is no 'relatedTo' entry for " << event->summary();
            err = "NoRelatedToForEvent";
            continue;
        }

        const Task *parent = dynamic_cast<Task*>(m_projectModel->tasksModel()->taskByUID(event->relatedTo()));
        if (!parent) {
            qCWarning(KTT_LOG) << "Unable to load 'relatedTo' entry for " << event->summary();
            err = "NoRelatedToForEvent";
            continue;
        }

        auto *item = new QTableWidgetItem(parent->name());
        item->setFlags(Qt::ItemIsEnabled);
        item->setWhatsThis(i18nc("@info:whatsthis", "You can change this task's comment, start time and end time."));
        m_ui.historytablewidget->setItem(row, 0, item);

        QDateTime start = event->dtStart();
        QDateTime end = event->dtEnd();
        m_ui.historytablewidget->setItem(row, 1, new QTableWidgetItem(start.toString(dateTimeFormat)));
        m_ui.historytablewidget->setItem(row, 2, new QTableWidgetItem(end.toString(dateTimeFormat)));
        m_ui.historytablewidget->setItem(row, 4, new QTableWidgetItem(event->uid()));
        qDebug() << "event->comments.count() =" << event->comments().count();
        if (event->comments().count() > 0) {
            m_ui.historytablewidget->setItem(row, 3, new QTableWidgetItem(event->comments().last()));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &event : m_storage->rawevents()) {
                qCDebug(KTT_LOG) << "row=" << row <<" col=" << col;
                if (event->uid() == uid) {
                    QDateTime datetime = QDateTime::fromString(m_ui.historytablewidget->item(row, col)->text(), dateTimeFormat);
                    if (datetime.isValid()) {
                        event->setDtStart(datetime);
                        emit timesChanged();
                        qCDebug(KTT_LOG) << "Program SetDtStart to" << m_ui.historytablewidget->item(row, col)->text();
                    } else {
                        KMessageBox::information(nullptr, i18n("This is not a valid Date/Time."));
                    }
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (TasksModelItem *item : getAllItems()) {
        // If "item" is not a Task, then we are probably in the middle
        // of class Task or TasksModelItem destructor.
        Task *task = dynamic_cast<Task*>(item);
        if (task) {
            tasks.append(task);
        }
    }
```

#### AUTO 


```{c}
auto *closureTask = dynamic_cast<Task*>(task1->child(4));
```

#### AUTO 


```{c}
auto *historyWidgetDelegate = new HistoryWidgetDelegate(m_ui.historytablewidget);
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : storage()->tasksModel()->getAllTasks()) {
            if (task->name() == newTaskName) {
                startTimerFor(task);
                m_lastTaskWithFocus = task;
            }
        }
```

#### AUTO 


```{c}
auto kcalEvent = baseEvent(task);
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : taskView->getAllTasks()) {
        if (task->uid() == taskId) {
            return task->totalTime();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : taskView->getAllTasks()) {
        if (task->name() == taskName) {
            taskView->stopTimerFor(task);
            return true;
        }
    }
```

#### AUTO 


```{c}
auto *dialog = new HistoryDialog(currentTaskView(), currentTaskView()->storage());
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : storage()->tasksModel()->getAllTasks()) {
        task->startNewSession();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : tasksModel()->getActiveTasks()) {
        runningTasks.append(task->uid());
        startTimes.append(task->startTime());
    }
```

#### AUTO 


```{c}
auto *task = dynamic_cast<Task *>(item(index));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &event : m_storage->rawevents()) {
                qDebug() << "row=" << row << " col=" << col;
                if (event->uid() == uid) {
                    event->addComment(m_ui.historytablewidget->item(row, col)->text());
                    qDebug() << "added" << m_ui.historytablewidget->item(row, col)->text();
                }
            }
```

#### AUTO 


```{c}
auto *historyButton = new QPushButton(QIcon::fromTheme("document-edit"), i18n("Edit History..."), m_buttonBox);
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : taskView->getAllTasks()) {
        if (task->uid() == taskId) {
            taskView->stopTimerFor(task);
            return;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *event : m_events) {
        delete event;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : tasksModel->getAllTasks()) {
//        if (dialog.wasCanceled()) {
//            break;
//        }
//
//        dialog.setValue(dialog.value() + 1);

//        if (tasknr % 15 == 0) {
//            QApplication::processEvents(); // repainting is slow
//        }
        QApplication::processEvents();

        // indent the task in the csv-file:
        for (int i = 0; i < task->depth(); ++i) {
            retval += delim;
        }

        /*
        // CSV compliance
        // Surround the field with quotes if the field contains
        // a comma (delim) or a double quote
        if (task->name().contains(delim) || task->name().contains(dquote))
        to_quote = true;
        else
        to_quote = false;
        */
        bool to_quote = true;

        if (to_quote) {
            retval += dquote;
        }

        // Double quotes replaced by a pair of consecutive double quotes
        retval += task->name().replace(dquote, double_dquote);

        if (to_quote) {
            retval += dquote;
        }

        // maybe other tasks are more indented, so to align the columns:
        for (int i = 0; i < maxdepth - task->depth(); ++i) {
            retval += delim;
        }

        retval += delim + formatTime(static_cast<double>(task->sessionTime()), rc.decimalMinutes)
                  + delim + formatTime(static_cast<double>(task->time()), rc.decimalMinutes)
                  + delim + formatTime(static_cast<double>(task->totalSessionTime()), rc.decimalMinutes)
                  + delim + formatTime(static_cast<double>(task->totalTime()), rc.decimalMinutes)
                  + '\n';
    }
```

#### AUTO 


```{c}
const auto &event
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &event : m_storage->rawevents()) {
                if (event->uid() == uid) {
                    event->setDtEnd(datetime);
                    emit timesChanged();
                    qCDebug(KTT_LOG) << "Program SetDtEnd to" << m_ui.historytablewidget->item(row, col)->text();
                }
            }
```

#### AUTO 


```{c}
auto *event
```

#### AUTO 


```{c}
auto *deleteButton = m_ui.buttonbox->addButton(QString(), QDialogButtonBox::ActionRole);
```

#### AUTO 


```{c}
auto *dialog = new EditTaskDialog(this, caption, nullptr);
```

#### AUTO 


```{c}
auto *task2 = taskView->addTask("2", QString(), 0, 0, QVector<int>(0, 0), task1);
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : storage()->tasksModel()->getAllTasks()) {
        // get all events for task
        for (const auto *event : storage()->eventsModel()->eventsForTask(task)) {
            QDateTime eventStart = event->dtStart();
            QDateTime eventEnd = event->dtEnd();

            const int64_t duration = event->duration() / 60;
            task->addTime(duration);
            qCDebug(KTT_LOG) << "duration is" << duration;

            if (task->sessionStartTiMe().isValid()) {
                // if there is a session
                if (task->sessionStartTiMe().secsTo(eventStart) > 0 &&
                    task->sessionStartTiMe().secsTo(eventEnd) > 0) {
                    // if the event is after the session start
                    task->addSessionTime(duration);
                }
            } else {
                // so there is no session at all
                task->addSessionTime(duration);
            }
        }
    }
```

#### AUTO 


```{c}
auto *desktopsLayout = new QGridLayout(scrollArea);
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : taskView->getAllTasks()) {
        if (task->uid() == taskId) {
            return task->isRunning();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : taskview->getAllTasks()) {
        qCDebug(KTT_LOG) << ", Task Name: " << task->name() << ", UID: " << task->uid();
        // uid -> seconds each day
        // * Init each element to zero
        QVector<int> vector(intervalLength, 0);
        secsForUid[task->uid()] = vector;

        // name -> uid
        // * Create task fullname concatenating each parent's name
        QString fullName;
        Task* parentTask;
        parentTask = task;
        fullName += parentTask->name();
        parentTask = parentTask->parentTask();
        while (parentTask) {
            fullName = parentTask->name() + "->" + fullName;
            qCDebug(KTT_LOG) << "Fullname(inside): " << fullName;
            parentTask = parentTask->parentTask();
            qCDebug(KTT_LOG) << "Parent task: " << parentTask;
        }

        uidForName[fullName] = task->uid();

        qCDebug(KTT_LOG) << "Fullname(end): " << fullName;
    }
```

#### AUTO 


```{c}
auto *taskView = createTaskView(this, true);
```

#### AUTO 


```{c}
auto *closureTask = dynamic_cast<Task *>(model->topLevelItem(3));
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : getAllTasks()) {
        if (task->isRunning()) {
            activeTasks.append(task);
        }
    }
```

#### AUTO 


```{c}
auto *configureAction = new QAction(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : tasksModel()->getAllTasks()) {
        // get all events for task
        for (const auto *event : eventsModel()->eventsForTask(task)) {
            QDateTime eventStart = event->dtStart();
            QDateTime eventEnd = event->dtEnd();

            const int64_t duration = event->duration() / 60;
            task->addTime(duration);
            qCDebug(KTT_LOG) << "duration is" << duration;

            if (task->sessionStartTiMe().isValid()) {
                // if there is a session
                if (task->sessionStartTiMe().secsTo(eventStart) > 0 &&
                    task->sessionStartTiMe().secsTo(eventEnd) > 0) {
                    // if the event is after the session start
                    task->addSessionTime(duration);
                }
            } else {
                // so there is no session at all
                task->addSessionTime(duration);
            }
        }
    }
```

#### AUTO 


```{c}
auto *displayUi = new Ui::DisplayPage;
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *event : events()) {
        if (event->uid() == uid) {
            return event;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& event : events) {
        m_events.append(new Event(event, this));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *item : getAllItems()) {
        auto *task = dynamic_cast<Task*>(item);
        if (task->uid() == uid) {
            return task;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : tasks) {
        qCDebug(KTT_LOG) << ", Task Name: " << task->name() << ", UID: " << task->uid();
        // uid -> seconds each day
        // * Init each element to zero
        QVector<int64_t> vector(intervalLength, 0);
        secsForUid[task->uid()] = vector;

        // name -> uid
        // * Create task fullname concatenating each parent's name
        QString fullName;
        Task* parentTask;
        parentTask = task;
        fullName += parentTask->name();
        parentTask = parentTask->parentTask();
        while (parentTask) {
            fullName = parentTask->name() + "->" + fullName;
            qCDebug(KTT_LOG) << "Fullname(inside): " << fullName;
            parentTask = parentTask->parentTask();
            qCDebug(KTT_LOG) << "Parent task: " << parentTask;
        }

        uidForName[fullName] = task->uid();

        qCDebug(KTT_LOG) << "Fullname(end): " << fullName;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto *event : projectModel->eventsModel()->events()) {

        row.clear();

        QDateTime start = event->dtStart();
        QDateTime end = event->dtEnd();

        if(start.date() < from || end.date() > to) {
            continue;
        }

        // Write CSV row
        row.append(start.toString(dateTimeFormat));
        row.append(delim);
        row.append(end.toString(dateTimeFormat));
        row.append(delim);
        row.append(getFullEventName(event, projectModel));
        row.append(delim);

        qDebug() << "event->comments.count() =" << event->comments().count();
        if (event->comments().count() > 0) {
            row.append(event->comments().last());
        }
        row.append(delim);

        row.append(event->uid());
        row.append(cr);

        events.append(row);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : getAllTasks()) {
        task->recalculatetotaltime();
        task->recalculatetotalsessiontime();
    }
```

#### AUTO 


```{c}
auto *dateTimeWidget = dynamic_cast<QDateTimeEdit *>(editor);
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : m_activeTasks) {
        task->changeTime(minutes, save_data ? m_storage->eventsModel() : nullptr);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &todo : todos) {
        Task* task = new Task(todo, m_model);
        map.insert(todo->uid(), task);
        task->invalidateCompletedState();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : tasksModel()->getAllTasks()) {
        task->resetTimes();
    }
```

#### AUTO 


```{c}
auto events = calendar->rawEvents(KCalendarCore::EventSortSummary);
```

#### AUTO 


```{c}
auto *dialog = new HistoryDialog(parentWidget(), m_projectModel);
```

#### AUTO 


```{c}
auto *parentItem = storage()->tasksModel()->item(parent);
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : storage()->tasksModel()->getActiveTasks()) {
        QApplication::processEvents();

        task->setRunning(false, when);

        dialog.setValue(dialog.value() + 1);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : taskview->getAllTasks()) {
        if (dialog.wasCanceled()) {
            break;
        }

        dialog.setValue(dialog.value() + 1);

//        if (tasknr % 15 == 0) {
//            QApplication::processEvents(); // repainting is slow
//        }
        QApplication::processEvents();

        if (task->depth() > maxdepth) {
            maxdepth = task->depth();
        }
    }
```

#### AUTO 


```{c}
const auto absMinutes = static_cast<int64_t>(std::round(std::fabs(minutes)));
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : taskView->storage()->tasksModel()->getAllTasks()) {
        if (task->name() == taskName) {
            result << task->uid();
        }
    }
```

#### AUTO 


```{c}
auto *deletedTask = static_cast<Task*>(item);
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : storage()->tasksModel()->getAllTasks()) {
        m_desktopTracker->registerForDesktops(task, task->desktops());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : taskView->storage()->tasksModel()->getActiveTasks()) {
        result << task->name();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *item : getAllItems()) {
        if (dynamic_cast<Task*>(item)->uid() == uid) {
            return item;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : d->mActiveTasks) {
//        kapp->processEvents();
        task->setRunning(false, d->mStorage, when);
        dialog.setValue(dialog.value() + 1);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *event : openEvents) {
        qCDebug(KTT_LOG) << "found an event for task, event=" << event->uid();
        event->setDtEnd(when);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (TasksModelItem *item : getAllItems()) {
        // If "item" is not a Task, then we are probably in the middle
        // of class Task or TasksModelItem destructor.
        Task *task = dynamic_cast<Task *>(item);
        if (task) {
            tasks.append(task);
        }
    }
```

#### AUTO 


```{c}
auto* dateTimeWidget = dynamic_cast<QDateTimeEdit*>(editor);
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : taskView->getAllTasks()) {
        if (task->isRunning()) {
            result << task->name();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : getAllTasks()) {
                if (task->name() == newTaskName) {
                    startTimerFor(task);
                    m_lastTaskWithFocus = task;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : m_activeTasks) {
        QApplication::processEvents();
        task->setRunning(false, when);
        dialog.setValue(dialog.value() + 1);
    }
```

#### AUTO 


```{c}
auto* t = static_cast< Task* >(*it);
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : getAllTasks()) {
        for( KCalCore::Event::List::iterator i = eventList.begin(); i != eventList.end(); ++i ) // loop over all events
        {
            if ( (*i)->relatedTo() == task->uid() ) // if event i belongs to task n
            {
                QDateTime kdatetimestart = (*i)->dtStart();
                QDateTime kdatetimeend = (*i)->dtEnd();
                QDateTime eventstart = QDateTime::fromString(kdatetimestart.toString().remove("Z"));
                QDateTime eventend = QDateTime::fromString(kdatetimeend.toString().remove("Z"));
                int duration=eventstart.secsTo( eventend )/60;
                task->addTime( duration );
                emit totalTimesChanged( 0, duration );
                qCDebug(KTT_LOG) << "duration is " << duration;

                if ( task->sessionStartTiMe().isValid() )
                {
                    // if there is a session
                    if ((task->sessionStartTiMe().secsTo( eventstart )>0) &&
                        (task->sessionStartTiMe().secsTo( eventend )>0))
                    // if the event is after the session start
                    {
                        int sessionTime=eventstart.secsTo( eventend )/60;
                        task->setSessionTime( task->sessionTime()+sessionTime );
                    }
                }
                else
                // so there is no session at all
                {
                    task->addSessionTime( duration );
                    emit totalTimesChanged( duration, 0 );
                };
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : taskView->storage()->tasksModel()->getAllTasks()) {
        if (task->name() == taskName) {
            return task->isRunning();
        }
    }
```

#### AUTO 


```{c}
auto *trackingLayout = new QHBoxLayout(m_trackingGroup);
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *task : taskView->storage()->tasksModel()->getAllTasks()) {
        if (task->uid() == taskId) {
            taskView->deleteTaskBatch(task);
            taskView->save();
        }
    }
```

#### AUTO 


```{c}
auto *descText = new QPlainTextEdit(description, infoGroup);
```

