#### AUTO 


```{c}
auto mouseEvent = static_cast<QMouseEvent *>(event);
```

#### LAMBDA EXPRESSION 


```{c}
[this, tp](){ emit clicked(tp); }
```

#### AUTO 


```{c}
const auto showRegExpDialog = [this]() {
            QDialog *editorDialog = KServiceTypeTrader::createInstanceFromQuery<QDialog>(QStringLiteral("KRegExpEditor/KRegExpEditor"), QString(), this);
            if ( editorDialog ) {
                KRegExpEditorInterface* iface = qobject_cast<KRegExpEditorInterface*>(editorDialog);
                Q_ASSERT( iface ); // This should not fail!

                // now use the editor.
                iface->setRegExp(QStringLiteral("foo"));

                if(editorDialog->exec() == QDialog::Accepted) {
                    //TODO
                }
            } else {
                qDebug() << " Unable to create QDialog";
            }
        };
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            QDialog *editorDialog = KServiceTypeTrader::createInstanceFromQuery<QDialog>(QStringLiteral("KRegExpEditor/KRegExpEditor"), QString(), this);
            if ( editorDialog ) {
                KRegExpEditorInterface* iface = qobject_cast<KRegExpEditorInterface*>(editorDialog);
                Q_ASSERT( iface ); // This should not fail!

                // now use the editor.
                iface->setRegExp(QStringLiteral("foo"));

                if(editorDialog->exec() == QDialog::Accepted) {
                    //TODO
                }
            } else {
                qDebug() << " Unable to create QDialog";
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, tp](){ Q_EMIT clicked(tp); }
```

