#### AUTO 


```{c}
auto *delegate = new KDialogJobUiDelegate;
```

#### AUTO 


```{c}
auto mime
```

#### AUTO 


```{c}
auto *edit = new KActionCategory(i18nc("@title actions category - means actions changing smth in interface", "Edit"), actionCollection);
```

#### AUTO 


```{c}
auto *anim = new QPropertyAnimation(this, "slideHeight", this);
```

#### AUTO 


```{c}
auto job = static_cast<SaveJob *>(_job);
```

#### AUTO 


```{c}
auto *touchEvent = static_cast<QTouchEvent *>(event);
```

#### AUTO 


```{c}
auto doc = new Document(url);
```

#### AUTO 


```{c}
auto* assignToAllButton = static_cast<QToolButton*>(widgets[1]);
```

#### LAMBDA EXPRESSION 


```{c}
[=] (int value) {mGeneralConfigPage.kcfg_JPEGQuality->setValue(value);}
```

#### AUTO 


```{c}
auto* anim = new QPropertyAnimation(this, "geometry");
```

#### AUTO 


```{c}
auto *touchEvent = static_cast<QTouchEvent *>(event)
```

#### AUTO 


```{c}
auto* layout = new QGridLayout(mPositionFrame);
```

#### AUTO 


```{c}
auto effect2 = new QGraphicsOpacityEffect(mRequireRestartLabel);
```

#### AUTO 


```{c}
auto assignToAllButton = new QToolButton;
```

#### RANGE FOR STATEMENT 


```{c}
for(auto action : mSortAction->actions()) {
            sortActionMenu->addAction(action);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : actionsList) {
        if (sortingFromSortAction(action) == GwenviewConfig::sorting()) {
            action->setChecked(true);
            break;
        }
    }
```

#### AUTO 


```{c}
auto it = d->mExifData.findKey(Exiv2::ExifKey("Exif.Canon.ThumbnailImageValidArea"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &mime : supported) {
            const auto resolved = resolveAlias(QString::fromUtf8(mime));
            if (resolved.isEmpty()) {
                qCWarning(GWENVIEW_LIB_LOG) << "Unresolved mime type " << mime;
            } else {
                list << resolved;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto w : d->mAdvancedWidgets) {
        w->setVisible(checked);
    }
```

#### AUTO 


```{c}
auto *historyItem = static_cast<RecentFilesItem *>(item(row, 0));
```

#### AUTO 


```{c}
auto watcher = new QDBusPendingCallWatcher(mScreenSaverInterface->GetActive(), this);
```

#### AUTO 


```{c}
auto scaleMode = ScaleMode(d->mScaleGroup.checkedId());
```

#### AUTO 


```{c}
auto *anim = new QPropertyAnimation(mOpacityEffect, "opacity");
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction* action : qAsConst(d->mExportActionList)) {
            if (action->text() == defaultActionText) {
                setDefaultAction(action);
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &item : itemList) {
        QModelIndex index = dirModel->indexForItem(item);
        TagSet tags = TagSet::fromVariant(dirModel->data(index, SemanticInfoDirModel::TagsRole));
        if (!tags.contains(tag)) {
            tags << tag;
            dirModel->setData(index, tags.toVariant(), SemanticInfoDirModel::TagsRole);
        }
    }
```

#### AUTO 


```{c}
auto *layout = new QVBoxLayout(mAutoHideContainer);
```

#### AUTO 


```{c}
auto hLayout = new QHBoxLayout(mInformationContainer);
```

#### AUTO 


```{c}
auto *folderViewItem = new FolderViewContextManagerItem(mContextManager);
```

#### AUTO 


```{c}
auto* dirModel = new SortedDirModel(this);
```

#### AUTO 


```{c}
auto* moreLabel = new QLabel(mOneFileWidget);
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction * action : qAsConst(info.mActions)) {
                menu->addAction(action);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (DocumentView* view : qAsConst(*d->mViews)) {
        if (view == d->mCurrentView.data()) {
            continue;
        }
        view->setZoomToFill(fit);
    }
```

#### AUTO 


```{c}
auto startSlideShowAction = new QAction(text, parentWidget);
```

#### AUTO 


```{c}
auto* fileOpsItem = new FileOpsContextManagerItem(mContextManager, mThumbnailView, actionCollection, q);
```

#### AUTO 


```{c}
auto* statJob = KIO::statDetails(baseUrl, KIO::StatJob::DestinationSide, KIO::StatNoDetails);
```

#### RANGE FOR STATEMENT 


```{c}
for (MetaInfoGroup::Entry *entry : qAsConst(hash)) {
            group->addEntry(entry);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (NodeHash *nodeHash : qAsConst(d->mNodes)) {
        qDeleteAll(*nodeHash);
    }
```

#### AUTO 


```{c}
auto *adapterContainerLayout = new QVBoxLayout(mAdapterContainer);
```

#### AUTO 


```{c}
auto *startSlideShowAction = new QAction(text, parentWidget);
```

#### AUTO 


```{c}
auto op = new TransformImageOperation(VFLIP);
```

#### AUTO 


```{c}
auto button = new HudButton;
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction * action : actionList) {
            menu->addAction(action);
        }
```

#### AUTO 


```{c}
auto* layout = new QHBoxLayout(mTooManyChangesFrame);
```

#### AUTO 


```{c}
auto removeButton = static_cast<QToolButton *>(widgets[0]);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        // The splitter can be moved until the bar has a size of zero which makes it invisible.
        const bool isThumbnailBarVisible = d->mThumbnailSplitter->sizes().constLast() > 0;
        GwenviewConfig::setThumbnailBarIsVisible(isThumbnailBarVisible);
        d->mToggleThumbnailBarAction->setChecked(isThumbnailBarVisible);
    }
```

#### AUTO 


```{c}
auto* glWidget = new QOpenGLWidget;
```

#### AUTO 


```{c}
auto *proxy = new QGraphicsProxyWidget(this);
```

#### AUTO 


```{c}
auto viewMainPageLayout = new QVBoxLayout(q);
```

#### AUTO 


```{c}
auto* hLayout = new QHBoxLayout;
```

#### AUTO 


```{c}
auto expectedKind = MimeTypeUtils::Kind(expectedKindInt);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem & item : qAsConst(mItems)) {
            itemSet.insert(item.url().url());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (DocumentView *view : qAsConst(d->mDocumentViews)) {
        QUrl url = view->url();
        if (urls.contains(url)) {
            // view displays an url we must display, keep it
            urls.remove(url);
            viewForUrlMap.insert(url, view);
        } else {
            // view url is not interesting, drop it
            d->deleteDocumentView(view);
        }
    }
```

#### AUTO 


```{c}
auto layout = new QGraphicsLinearLayout(content);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &item : list) {
        if (!item.isNull() && !ArchiveUtils::fileItemIsDirOrArchive(item)) {
            urls << item.url();

            ++count;
            if (count == ViewMainPage::MaxViewCount) {
                break;
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](const QString &filter) {
            JPEGQualityChooserWidget->setVisible(filter.contains(QLatin1String("jpeg")));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : qAsConst(urls)) {
        if (d->mDocumentViews.count() >= MaxViewCount) {
            qWarning() << "Too many documents to show";
            break;
        }
        DocumentView* view = d->createDocumentView();
        viewForUrlMap.insert(url, view);
    }
```

#### AUTO 


```{c}
auto* impl = qobject_cast<LoadingDocumentImpl*>(mImpl);
```

#### AUTO 


```{c}
auto *edit = qobject_cast<QLineEdit *>(ratioComboBox->lineEdit());
```

#### AUTO 


```{c}
auto* innerLayout = new QHBoxLayout();
```

#### AUTO 


```{c}
auto *dialog = new ResizeImageDialog(d->mMainWindow);
```

#### AUTO 


```{c}
auto* binder = new BaseBinder<Receiver, Arg, MethodArg>(emitter);
```

#### AUTO 


```{c}
auto* completer = new QCompleter(mTagComboBox);
```

#### AUTO 


```{c}
auto messageViewAdapter = qobject_cast<MessageViewAdapter *>(d->mAdapter.data());
```

#### AUTO 


```{c}
auto horizontalSpacer = new QSpacerItem(1, 1, QSizePolicy::Expanding, QSizePolicy::Fixed);
```

#### AUTO 


```{c}
auto* floater = new GraphicsWidgetFloater(q);
```

#### AUTO 


```{c}
const auto &item
```

#### AUTO 


```{c}
auto watcher = dynamic_cast<DBusStringReplyWatcher *>(sender());
```

#### AUTO 


```{c}
auto* fadeIn = new QPropertyAnimation(mToolTip, "opacity");
```

#### AUTO 


```{c}
auto *remainingTimeProxy = new QGraphicsProxyWidget(hudContent);
```

#### AUTO 


```{c}
auto* mouseEvent = static_cast<QMouseEvent *>(event);
```

#### AUTO 


```{c}
auto action
```

#### AUTO 


```{c}
const auto destinationRect = QRect{// Ceil the top left corner to avoid pixel alignment issues on higher DPI because QPoint/QSize/QRect
                                       // round instead of flooring when converting from float to int.
                                       QPoint{int(std::ceil(imageRect.left() * (zoom / dpr))), int(std::ceil(imageRect.top() * (zoom / dpr)))},
                                       // Floor the size, similarly to above.
                                       QSize{int(image.size().width() / dpr), int(image.size().height() / dpr)}};
```

#### AUTO 


```{c}
auto widget = new QWidget(parent);
```

#### AUTO 


```{c}
auto *layout = new QVBoxLayout(mUrlNavigatorContainer);
```

#### AUTO 


```{c}
auto *enterKeyShortcut = new QShortcut(Qt::Key_Return, this);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QUrl &, const QUrl &newUrl) {
              setCurrentDirUrl(newUrl);
            }
```

#### AUTO 


```{c}
auto *action = static_cast<QAction *>(object);
```

#### AUTO 


```{c}
const auto currentViews = d->mAddedViews;
```

#### AUTO 


```{c}
auto *layout = new QHBoxLayout(mTooManyChangesFrame);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KIPI::ImageCollection & collection : list) {
            if (collection.name() == name) {
                selectedList << collection;
                break;
            }
        }
```

#### AUTO 


```{c}
auto *delegate = new PreviewItemDelegate(mThumbnailView);
```

#### AUTO 


```{c}
auto actionGroup = new QActionGroup(d->q);
```

#### AUTO 


```{c}
auto tagModel = new TagModel(parent);
```

#### AUTO 


```{c}
auto glWidget = new QOpenGLWidget;
```

#### RANGE FOR STATEMENT 


```{c}
for (auto w : qAsConst(d->mAdvancedWidgets)) {
        w->setVisible(false);
    }
```

#### AUTO 


```{c}
auto* button = new HudButton();
```

#### AUTO 


```{c}
auto finder = new DocumentDirFinder(srcBaseUrl);
```

#### AUTO 


```{c}
auto op = new CropImageOperation(d->mRect);
```

#### AUTO 


```{c}
auto mime = db.mimeTypeForData(mData);
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        const QString name = dialog->filename();
        if (name.isEmpty() || name == oldUrl.fileName()) {
            return;
        }

        QUrl newUrl = oldUrl;
        newUrl = newUrl.adjusted(QUrl::RemoveFilename);
        newUrl.setPath(newUrl.path() + name);
        KIO::SimpleJob* job = KIO::rename(oldUrl, newUrl, KIO::HideProgressInfo);
        KJobWidgets::setWindow(job, parent);
        job->uiDelegate()->setAutoErrorHandlingEnabled(true);
        QObject::connect(job, &KJob::result, parent, [contextManager, job, oldUrl, newUrl]() {
            if (!job->error()) {
                contextManager->setCurrentUrl(newUrl);
                ThumbnailProvider::moveThumbnail(oldUrl, newUrl);
            }
        });
    }
```

#### AUTO 


```{c}
auto *job = new LoadingJob;
```

#### AUTO 


```{c}
auto move = new QPropertyAnimation(mToolTip, "geometry");
```

#### AUTO 


```{c}
auto *dialog = new RenameDialog(parent);
```

#### AUTO 


```{c}
auto *hLayout = new QHBoxLayout;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString & token : lst) {
                if (!token.isEmpty()) {
                    semanticInfo.mTags << '#' + token.toLower();
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->setupPalettes();
    }
```

#### AUTO 


```{c}
auto *label = new QLabel(i18nc("@label:listbox", "Aspect ratio:"), box);
```

#### AUTO 


```{c}
auto* view = new DocumentView(d->mScene);
```

#### AUTO 


```{c}
auto* messageViewAdapter = qobject_cast<MessageViewAdapter*>(d->mAdapter.data());
```

#### AUTO 


```{c}
auto aligningSpacer = new AligningSpacer(parent);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : list) {
        Document::Ptr doc = DocumentFactory::instance()->load(url);
        DocumentJob* job = doc->save(url, doc->format());
        connect(job, &DocumentJob::result, this, &SaveAllHelper::slotResult);
        d->mJobSet << job;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &item : list) {
        MimeTypeUtils::Kind kind = MimeTypeUtils::fileItemKind(item);
        switch (kind) {
        case MimeTypeUtils::KIND_DIR:
        case MimeTypeUtils::KIND_ARCHIVE:
            if (d->mFoundDirUrl.isValid()) {
                // This is the second dir we find, stop now
                finish(dir, MultipleDirsFound);
                return;
            } else {
                // First dir
                d->mFoundDirUrl = item.url();
            }
            break;

        case MimeTypeUtils::KIND_RASTER_IMAGE:
        case MimeTypeUtils::KIND_SVG_IMAGE:
        case MimeTypeUtils::KIND_VIDEO:
            finish(dir, DocumentDirFound);
            return;

        case MimeTypeUtils::KIND_UNKNOWN:
        case MimeTypeUtils::KIND_FILE:
            break;
        }
    }
```

#### AUTO 


```{c}
auto mainLayout = new QVBoxLayout;
```

#### AUTO 


```{c}
auto *job = new KIO::ApplicationLauncherJob(service);
```

#### AUTO 


```{c}
auto *configureMenu = new QMenu(i18nc("@title:menu submenu for actions that open configuration dialogs", "Configure"));
```

#### AUTO 


```{c}
auto *watcher = dynamic_cast<DBusBoolReplyWatcher *>(sender());
```

#### LAMBDA EXPRESSION 


```{c}
[=] (int value) {mGeneralConfigPage.jpegQualitySpinner->setValue(value);}
```

#### LAMBDA EXPRESSION 


```{c}
[this](){
        d->mView->setBackgroundColorMode(BackgroundColorWidget::Light);
        qApp->paletteChanged(qApp->palette());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
            if (GwenviewConfig::jPEGQuality() != d->configFileJPEGQualityValue)
                GwenviewConfig::setJPEGQuality(d->configFileJPEGQualityValue);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString & url : qAsConst(tmpArgs)) {
                list << QUrl::fromUserInput(url, QDir::currentPath(), QUrl::AssumeLocalFile);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &key : preferredMetaInfoKeyList) {
        QString label;
        QString value;
        metaInfoModel->getInfoForKey(key, &label, &value);
        if (!label.isEmpty() && !value.isEmpty()) {
            d->mKeyValueWidget->addRow(label, value);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[dialog, url, deviceUdi]() {
            dialog->setSourceUrl(url, deviceUdi);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : actions) {
            KIPI::Category category = plugin->category(action);

            if (!d->mMenuInfoMap.contains(category)) {
                qCWarning(GWENVIEW_APP_LOG) << "Unknown category '" << category;
                continue;
            }

            d->mMenuInfoMap[category].mActions << action;
        }
```

#### AUTO 


```{c}
auto delegate = new PreviewItemDelegate(view);
```

#### AUTO 


```{c}
auto *content = new QLineEdit(container);
```

#### AUTO 


```{c}
auto* viewMainPageLayout = new QVBoxLayout(q);
```

#### AUTO 


```{c}
auto* floater = new GraphicsWidgetFloater(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Exiv2::ExifKey& key : qAsConst(lst)) {
        it = exifData.findKey(key);
        if (it != end) {
            return it;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString & parentMimeType : allAncestors) {
            protocol = KProtocolManager::protocolForArchiveMimetype(parentMimeType);
            if (!protocol.isEmpty()) {
                break;
            }
        }
```

#### AUTO 


```{c}
const auto transformationMode = zoom < 4.0 ? Qt::SmoothTransformation : Qt::FastTransformation;
```

#### RANGE FOR STATEMENT 


```{c}
for (DocumentJob *job : qAsConst(d->mJobSet)) {
        job->kill();
    }
```

#### AUTO 


```{c}
auto supported = QImageReader::supportedMimeTypes();
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem & item : itemList) {
        QModelIndex index = dirModel->indexForItem(item);
        dirModel->setData(index, description, SemanticInfoDirModel::DescriptionRole);
    }
```

#### AUTO 


```{c}
auto* layout = new QGraphicsLinearLayout(content);
```

#### AUTO 


```{c}
auto sourceRect = QRect{imageRect.topLeft() * Sixth, imageRect.size() * Sixth};
```

#### AUTO 


```{c}
auto anim = new QPropertyAnimation(this, "geometry");
```

#### AUTO 


```{c}
auto *watcher = dynamic_cast<DBusStringReplyWatcher *>(sender());
```

#### AUTO 


```{c}
auto proxy = new QGraphicsProxyWidget(this);
```

#### AUTO 


```{c}
auto job = qobject_cast<DownSamplingJob *>(*it);
```

#### RANGE FOR STATEMENT 


```{c}
for (DocumentView* view : qAsConst(*d->mViews)) {
        if (view == d->mCurrentView.data()) {
            continue;
        }
        view->setZoom(zoom);
    }
```

#### AUTO 


```{c}
auto *src = (IODeviceJpegSourceManager *)(*cinfo->mem->alloc_small)((j_common_ptr)cinfo, JPOOL_PERMANENT, sizeof(IODeviceJpegSourceManager));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString & key : fullScreenPreferredMetaInfoKeyList) {
        const QString value = model->getValueForKey(key);
        if (!value.isEmpty()) {
            valueList << value;
        }
    }
```

#### AUTO 


```{c}
auto *statusBarContainerLayout = new QHBoxLayout(mStatusBarContainer);
```

#### AUTO 


```{c}
auto* job = new Baloo::TagListJob();
```

#### AUTO 


```{c}
auto historyItem = static_cast<HistoryItem *>(item(row, 0));
```

#### AUTO 


```{c}
auto *menu = new QMenu(mAddFilterButton);
```

#### AUTO 


```{c}
auto op = new SuccessOperation;
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
            cancel();
            wait();
        }
```

#### AUTO 


```{c}
auto buttons = d->mCropWidget->findChild<QDialogButtonBox *>();
```

#### AUTO 


```{c}
auto* job = static_cast<SaveJob*>(_job);
```

#### AUTO 


```{c}
auto* layout = new QGraphicsLinearLayout(hudContent);
```

#### AUTO 


```{c}
auto *button = new QPushButton;
```

#### AUTO 


```{c}
auto folderViewItem = new FolderViewContextManagerItem(mContextManager);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : qAsConst(urls)) {
        if (d->mDocumentViews.count() >= MaxViewCount) {
            qCWarning(GWENVIEW_APP_LOG) << "Too many documents to show";
            break;
        }
        DocumentView* view = d->createDocumentView();
        viewForUrlMap.insert(url, view);
    }
```

#### AUTO 


```{c}
auto *binder = new BaseBinder<Receiver, Arg, MethodArg>(emitter);
```

#### AUTO 


```{c}
auto *layout = new QVBoxLayout(mContentWidget);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KIPI::ImageCollection & collection : list) {
        QListWidgetItem* item = new QListWidgetItem(d->mListWidget);
        QString name = collection.name();
        int imageCount = collection.images().size();
        QString title = i18ncp("%1 is collection name, %2 is image count in collection",
                               "%1 (%2 image)", "%1 (%2 images)", name, imageCount);

        item->setText(title);
        item->setData(Qt::UserRole, name);
    }
```

#### AUTO 


```{c}
auto * clearAction = mFileOpenRecentAction->menu()->findChild<QAction*>("clear_action");
```

#### AUTO 


```{c}
auto* data = new KAboutData(appName, programName, QStringLiteral(GWENVIEW_VERSION_STRING));
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem & item : itemList) {
        if (item.isDir()) {
            folderCount++;
        } else {
            fileCount++;
        }
    }
```

#### AUTO 


```{c}
auto image = q->document()->image();
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : qAsConst(d->mActionList)) {
        if (action->isEnabled() && action->priority() != QAction::LowPriority) {
            d->mGroup->addAction(action);
        }
    }
```

#### AUTO 


```{c}
auto closeButton = new QToolButton;
```

#### AUTO 


```{c}
auto layout = new QGridLayout(mPositionFrame);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto w : qAsConst(d->mAdvancedWidgets)) {
        w->setVisible(checked);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : qAsConst(list)) {
        if (action->isEnabled() && !action->isSeparator()) {
            mGroup->addAction(action);
        }
    }
```

#### AUTO 


```{c}
auto tag = item->widget();
```

#### AUTO 


```{c}
auto dialog = new ResizeImageDialog(d->mMainWindow);
```

#### AUTO 


```{c}
auto *effect2 = new QGraphicsOpacityEffect(mRequireRestartLabel);
```

#### AUTO 


```{c}
auto statJob = KIO::statDetails(baseUrl, KIO::StatJob::DestinationSide, KIO::StatNoDetails);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto button : buttonList) {
        button->setIcon(QIcon::fromTheme(iconName));
        button->setToolTip(toolTip);
    }
```

#### AUTO 


```{c}
auto view = new DocumentView(d->mScene);
```

#### AUTO 


```{c}
auto* label = new QLabel(i18nc("@label:listbox", "Aspect ratio:"), box);
```

#### AUTO 


```{c}
auto optionsPage = new PrintOptionsPage(doc->size());
```

#### AUTO 


```{c}
auto* src = (IODeviceJpegSourceManager*)
                                     (*cinfo->mem->alloc_small)((j_common_ptr) cinfo, JPOOL_PERMANENT,
                                             sizeof(IODeviceJpegSourceManager));
```

#### RANGE FOR STATEMENT 


```{c}
for (auto group : s_thumbnailGroups) {
        moveThumbnailHelper(oldUri, newUri, group);
    }
```

#### AUTO 


```{c}
auto buttonBox = new QDialogButtonBox(QDialogButtonBox::Close);
```

#### AUTO 


```{c}
auto* JPEGQualityChooserLabel = new QLabel;
```

#### LAMBDA EXPRESSION 


```{c}
[d]() {
        d->mirrored = qApp->isRightToLeft();
        d->autoButton->setGroupPosition(d->mirrored ? StatusBarToolButton::GroupRight : StatusBarToolButton::GroupLeft);
        d->darkButton->setGroupPosition(d->mirrored ? StatusBarToolButton::GroupLeft : StatusBarToolButton::GroupRight);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto w : d->mAdvancedWidgets) {
        w->setVisible(false);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString & key : preferredMetaInfoKeyList) {
        QString label;
        QString value;
        metaInfoModel->getInfoForKey(key, &label, &value);
        if (!label.isEmpty() && !value.isEmpty()) {
            d->mKeyValueWidget->addRow(label, value);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &mimeType : svgImageMimeTypesList) {
            list.removeOne(mimeType);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &filePath : filePaths) {
        QFileInfo info(*this, filePath);
        mkpath(info.absolutePath());
        createEmptyFile(info.absoluteFilePath());
    }
```

#### AUTO 


```{c}
auto enterKeyShortcut = new QShortcut(Qt::Key_Return, this);
```

#### AUTO 


```{c}
auto action = new QAction(q);
```

#### AUTO 


```{c}
auto *historyItem = static_cast<HistoryItem *>(item(row, 0));
```

#### AUTO 


```{c}
auto* view = new KActionCategory(i18nc("@title actions category - means actions changing smth in interface", "View"), actionCollection);
```

#### RANGE FOR STATEMENT 


```{c}
for (ContextManagerPrivate::Signal signal : qAsConst(d->mQueuedSignals)) {
        emit (this->*signal)();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : qAsConst(urls)) {
        if (d->mDocumentViews.count() >= MaxViewCount) {
            qCWarning(GWENVIEW_APP_LOG) << "Too many documents to show";
            break;
        }
        DocumentView *view = d->createDocumentView();
        viewForUrlMap.insert(url, view);
    }
```

#### AUTO 


```{c}
auto *item = new QListWidgetItem(d->mListWidget);
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
                if (GwenviewConfig::jPEGQuality() != d->configFileJPEGQualityValue) {
                    GwenviewConfig::setJPEGQuality(d->configFileJPEGQualityValue);
                }
            }
```

#### AUTO 


```{c}
auto *widgetTarget = qobject_cast<QGraphicsWidget *>(target);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QRect &rect : qAsConst(d->mRegion)) {
        LOG(rect);
        scaleRect(rect);
    }
```

#### AUTO 


```{c}
auto* closeButton = new QToolButton;
```

#### RANGE FOR STATEMENT 


```{c}
for (const CropHandle &handle : qAsConst(mCropHandleList)) {
            QRectF rect = handleViewportRect(handle);
            if (rect.contains(pos)) {
                return handle;
            }
        }
```

#### AUTO 


```{c}
auto* historyItem = static_cast<HistoryItem*>(item(row, 0));
```

#### RANGE FOR STATEMENT 


```{c}
for (DocumentView *view : qAsConst(d->mRemovedViews)) {
            view->fadeOut();
            QTimer::singleShot(DocumentView::AnimDuration, view, &QObject::deleteLater);
        }
```

#### AUTO 


```{c}
const auto mFileOpenRecentActionUrls = d->mFileOpenRecentAction->urls();
```

#### AUTO 


```{c}
const auto list = d->mContextManager->selectedFileItemList();
```

#### AUTO 


```{c}
auto job = new LoadingJob;
```

#### AUTO 


```{c}
const auto docSize = doc->size();
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        wait();
    }
```

#### AUTO 


```{c}
auto *currentTimeProxy = new QGraphicsProxyWidget(hudContent);
```

#### RANGE FOR STATEMENT 


```{c}
for (const CropHandle & handle : qAsConst(mCropHandleList)) {
            QRectF rect = handleViewportRect(handle);
            if (rect.contains(pos)) {
                return handle;
            }
        }
```

#### AUTO 


```{c}
auto layout = new QVBoxLayout(d->mSaveBarWidget);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->updateHandleRect();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex & index : list) {
        d->mThumbnailView->reloadThumbnail(index);
    }
```

#### AUTO 


```{c}
const auto dpr = mParentView->devicePixelRatio();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString & item : qAsConst(d->mErrorList)) {
            msg += "<li>" + item + "</li>";
        }
```

#### AUTO 


```{c}
auto *in = (QIODevice *)png_get_io_ptr(png_ptr);
```

#### AUTO 


```{c}
auto op = new RedEyeReductionImageOperation(docRectF);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QUrl &, const QUrl &newUrl) {
        setCurrentDirUrl(newUrl);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, urlList, destUrl]() { showMenuForDroppedUrls(urlList, destUrl); }
```

#### AUTO 


```{c}
auto *ratingMenu = static_cast<QMenu *>(guiFactory()->container("rating", this));
```

#### AUTO 


```{c}
const auto destinationRect = QRect{
        // Ceil the top left corner to avoid pixel alignment issues on higher DPI because QPoint/QSize/QRect
        // round instead of flooring when converting from float to int.
        QPoint{int(std::ceil(imageRect.left() * (zoom / dpr))), int(std::ceil(imageRect.top() * (zoom / dpr)))},
        // Floor the size, similarly to above.
        QSize{int(image.size().width() / dpr), int(image.size().height() / dpr)}
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &tag : tagSet) {
            TagHash::Iterator it = tagHash.find(tag);
            if (it == tagHash.end()) {
                tagHash[tag] = 1;
            } else {
                ++it.value();
            }
        }
```

#### AUTO 


```{c}
auto *drag = new QDrag(this);
```

#### AUTO 


```{c}
auto *hudContent = new QGraphicsWidget;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &name : entryList) {
        const QUrl url = QUrl::fromLocalFile(dir.absoluteFilePath(name));
        KFileItem item(url);
        list << item;
    }
```

#### AUTO 


```{c}
auto dirLister = new DirLister;
```

#### AUTO 


```{c}
auto *actionGroup = new QActionGroup(d->q);
```

#### AUTO 


```{c}
auto op = new TransformImageOperation(orientation);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->mView->setBackgroundColorMode(BackgroundColorWidget::Light);
        qApp->paletteChanged(qApp->palette());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { finish(false); }
```

#### AUTO 


```{c}
auto alignWithSideBarWidgetAction = new AlignWithSideBarWidgetAction();
```

#### RANGE FOR STATEMENT 


```{c}
for (DocumentView* view : qAsConst(d->mAddedViews)) {
        slotFadeInFinished(view);
    }
```

#### AUTO 


```{c}
auto container = new FilterWidgetContainer;
```

#### LAMBDA EXPRESSION 


```{c}
[this, url]() {
        Q_EMIT readyForDirListerStart(url);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : lst) {
        qWarning() << url.fileName();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, tool]() {
        this->d->mCropStateRect->setTopLeft(tool->rect().topLeft());
        this->d->mCropStateRect->setSize(tool->rect().size());
        this->restoreDefaultImageViewTool();
    }
```

#### AUTO 


```{c}
auto* proxy = new QGraphicsProxyWidget(this);
```

#### AUTO 


```{c}
auto* widget = new QWidget;
```

#### AUTO 


```{c}
auto* JPEGQualityChooserLayout = new QHBoxLayout(JPEGQualityChooserWidget);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &src : qAsConst(list)) {
        QUrl dst = localUrl;
        dst.setPath(dst.path() + '/' + src.fileName());
        QVERIFY(FileUtils::contentsAreIdentical(src, dst));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : qAsConst(info.mActions)) {
                menu->addAction(action);
            }
```

#### AUTO 


```{c}
auto* button = new QToolButton;
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->updateCaption();
    }
```

#### AUTO 


```{c}
auto *dirModel = new KDirModel(this);
```

#### AUTO 


```{c}
auto *watcher = dynamic_cast<DBusStringReplyWatcher*>(sender());
```

#### RANGE FOR STATEMENT 


```{c}
for (NodeHash * nodeHash : qAsConst(d->mNodes)) {
        qDeleteAll(*nodeHash);
    }
```

#### AUTO 


```{c}
auto *floater = new GraphicsWidgetFloater(this);
```

#### AUTO 


```{c}
auto focusButton = static_cast<QPushButton*>(buttons->focusWidget());
```

#### RANGE FOR STATEMENT 


```{c}
for (ContextManagerPrivate::Signal signal : qAsConst(d->mQueuedSignals)) {
        Q_EMIT(this->*signal)();
    }
```

#### AUTO 


```{c}
auto* iconLabel = new QLabel;
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem & item : itemList) {
        QModelIndex index = dirModel->indexForItem(item);

        QVariant value = dirModel->data(index, SemanticInfoDirModel::RatingRole);
        if (first) {
            rating = ratingForVariant(value);
        } else if (rating != ratingForVariant(value)) {
            // Ratings aren't the same, reset
            rating = 0;
        }

        QString indexDescription = index.data(SemanticInfoDirModel::DescriptionRole).toString();
        if (first) {
            description = indexDescription;
        } else if (description != indexDescription) {
            description.clear();
        }

        // Fill tagHash, incrementing the tag count if it's already there
        const TagSet tagSet = TagSet::fromVariant(index.data(SemanticInfoDirModel::TagsRole));
        for (const QString & tag : tagSet) {
            TagHash::Iterator it = tagHash.find(tag);
            if (it == tagHash.end()) {
                tagHash[tag] = 1;
            } else {
                ++it.value();
            }
        }

        first = false;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString & name : rcFilesList) {
            HistoryItem* item = HistoryItem::load(dir.filePath(name));
            if (!item) {
                continue;
            }

            QUrl itemUrl = item->url();
            if (UrlUtils::urlIsFastLocalFile(itemUrl)) {
                if (!QFile::exists(itemUrl.path())) {
                    qCDebug(GWENVIEW_LIB_LOG) << "Removing" << itemUrl.path() << "from recent folders. It does not exist anymore";
                    item->unlink();
                    delete item;
                    continue;
                }
            }

            HistoryItem* existingItem = mHistoryItemForUrl.value(item->url());
            if (existingItem) {
                // We already know this url(!) update existing item dateTime
                // and get rid of duplicate
                if (existingItem->dateTime() < item->dateTime()) {
                    existingItem->setDateTime(item->dateTime());
                }
                item->unlink();
                delete item;
            } else {
                mHistoryItemForUrl.insert(item->url(), item);
                q->appendRow(item);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Exiv2::ExifKey &key : qAsConst(lst)) {
        it = exifData.findKey(key);
        if (it != end) {
            return it;
        }
    }
```

#### AUTO 


```{c}
auto* widget = new QWidget(parent);
```

#### AUTO 


```{c}
auto layout = new QVBoxLayout(this);
```

#### AUTO 


```{c}
auto removeButton = new QToolButton;
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : qAsConst(d->mExportActionList)) {
            if (action->text() == defaultActionText) {
                setDefaultAction(action);
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto action : toolbarActions) {
        if (actionForThisSpacerFound) {
            if (visible && mWasSeparatorRemoved) {
                mToolbar->insertSeparator(action);
                mWasSeparatorRemoved = false;
            } else if (!visible && action->isSeparator()) {
                mToolbar->removeAction(action);
                mWasSeparatorRemoved = true;
            }
            return;
        }
        if (mToolbar->widgetForAction(action) == this) {
            actionForThisSpacerFound = true;
        }
    }
```

#### AUTO 


```{c}
auto *completer = new QCompleter(q);
```

#### AUTO 


```{c}
auto item
```

#### AUTO 


```{c}
auto* enterKeyShortcut = new QShortcut(Qt::Key_Return, this);
```

#### AUTO 


```{c}
auto* edit = qobject_cast<QLineEdit*>(ratioComboBox->lineEdit());
```

#### AUTO 


```{c}
auto w
```

#### AUTO 


```{c}
const auto dpr = devicePixelRatioF();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QAction * action : actionList) {
        if (action->isChecked()) {
            details |= PreviewItemDelegate::ThumbnailDetail(action->data().toInt());
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        cancel();
        wait();
    }
```

#### AUTO 


```{c}
auto layout = new QHBoxLayout(mContent);
```

#### AUTO 


```{c}
auto dialog = new QFileDialog(this);
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        // gwenview -s %u
        auto job = new KIO::CommandLauncherJob(QStringLiteral("gwenview"), QStringList("-s") << itemsForSlideShow);
        job->setDesktopName("org.kde.gwenview");
        job->setUiDelegate(new KNotificationJobUiDelegate(KJobUiDelegate::AutoHandlingEnabled));

        job->start();
    }
```

#### AUTO 


```{c}
auto layout = new QVBoxLayout(mAutoHideContainer);
```

#### AUTO 


```{c}
auto *layout = new QHBoxLayout(widget);
```

#### LAMBDA EXPRESSION 


```{c}
[=](const QModelIndex &index, int first, int last) {
        // Avoid the delegate doing a ton of work if we're not visible
        if (isVisible()) {
            Q_EMIT rowsRemovedSignal(index, first, last);
        }
    }
```

#### AUTO 


```{c}
auto* op = new ResizeImageOperation(dialog->size());
```

#### AUTO 


```{c}
auto tool = new RedEyeReductionTool(view);
```

#### AUTO 


```{c}
auto *watcher = new EventWatcher(watched, eventTypes);
```

#### AUTO 


```{c}
auto* layout = new QVBoxLayout(mUrlNavigatorContainer);
```

#### AUTO 


```{c}
auto* ratingMenu = static_cast<QMenu*>(guiFactory()->container("rating", this));
```

#### AUTO 


```{c}
auto* sortActionMenu = view->add<KActionMenu>("sort_by");
```

#### LAMBDA EXPRESSION 


```{c}
[=](){
            mToggleOperationsSideBarAction->setChecked(
                    mSideBar->isVisible() && mSideBar->currentPage() == QLatin1String("operations"));
        }
```

#### AUTO 


```{c}
auto button = new QToolButton;
```

#### AUTO 


```{c}
auto *button = new HudButton();
```

#### AUTO 


```{c}
auto* layout = new QVBoxLayout(mAutoHideContainer);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QUrl& url) {
            mFileOpenRecentAction->removeUrl(url);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SemanticInfoTag & tag : set) {
        QString label = d->mBackEnd->labelForTag(tag);
        QStandardItem* item = createItem(tag, label, TagModel::FullyAssigned);
        appendRow(item);
    }
```

#### AUTO 


```{c}
const auto viewportRect = mParentView->scene()->views().first()->rect();
```

#### AUTO 


```{c}
auto* tagModel = new TagModel(parent);
```

#### AUTO 


```{c}
auto ownerWatcher = new DBusStringReplyWatcher(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem & item : itemList) {
        QModelIndex index = dirModel->indexForItem(item);
        TagSet tags = TagSet::fromVariant(dirModel->data(index, SemanticInfoDirModel::TagsRole));
        if (!tags.contains(tag)) {
            tags << tag;
            dirModel->setData(index, tags.toVariant(), SemanticInfoDirModel::TagsRole);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        GwenviewConfig::setSideBarPage(currentPage());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : selection.indexes()) {
            mSelectedFileItemList << mDirModel->itemForIndex(index);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto index : deselected.indexes()) {
            KFileItem item = mDirModel->itemForIndex(index);
            mSelectedMediaItems->removeOne(item);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : qAsConst(d->mActions)) {
            disconnect(action, nullptr, d->mView, nullptr);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[contextManager, job, oldUrl, newUrl]() {
            if (!job->error()) {
                contextManager->setCurrentUrl(newUrl);
                ThumbnailProvider::moveThumbnail(oldUrl, newUrl);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& mimeType : svgImageMimeTypesList) {
            list.removeOne(mimeType);
        }
```

#### AUTO 


```{c}
auto *tool = new RedEyeReductionTool(view);
```

#### AUTO 


```{c}
auto* container = new FilterWidgetContainer;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : list) {
        KFileItem item = itemForIndex(index);
        if (!ArchiveUtils::fileItemIsDirOrArchive(item)) {
            d->mUrlList << item.url();
        }
        // FIXME: Handle dirs (do we want to import recursively?)
    }
```

#### AUTO 


```{c}
auto *floater = new GraphicsWidgetFloater(view);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto index : indexes) {
        selectedFiles << fileItemForIndex(index);
    }
```

#### AUTO 


```{c}
auto action = new QAction(text, q);
```

#### AUTO 


```{c}
auto innerLayout = new QHBoxLayout();
```

#### AUTO 


```{c}
auto pinch = static_cast<QPinchGesture *>(event->gesture(Qt::PinchGesture))
```

#### AUTO 


```{c}
auto* op = new TestOperation;
```

#### AUTO 


```{c}
auto layout = new QVBoxLayout(q);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->mView->setBackgroundColorMode(BackgroundColorWidget::Auto);
        qApp->paletteChanged(qApp->palette());
    }
```

#### AUTO 


```{c}
auto *moreLabel = new QLabel(mOneFileWidget);
```

#### AUTO 


```{c}
auto* imageOpsItem =
            new ImageOpsContextManagerItem(mContextManager, q);
```

#### AUTO 


```{c}
auto *finder = new DocumentDirFinder(srcBaseUrl);
```

#### AUTO 


```{c}
auto decoratedTag = new DecoratedTag(label);
```

#### AUTO 


```{c}
auto *flowLayout = new FlowLayout(cropWidget, 6, 0);
```

#### AUTO 


```{c}
auto *closeButton = new QToolButton;
```

#### AUTO 


```{c}
auto remainingTimeProxy = new QGraphicsProxyWidget(hudContent);
```

#### AUTO 


```{c}
auto* op = new TransformImageOperation(HFLIP);
```

#### AUTO 


```{c}
auto* delegate = new PreviewItemDelegate(mThumbnailView);
```

#### AUTO 


```{c}
auto* pinch = static_cast<QPinchGesture*>(event->gesture(Qt::PinchGesture))
```

#### AUTO 


```{c}
auto watcher = new EventWatcher(watched, eventTypes);
```

#### AUTO 


```{c}
auto *delegate = new TagItemDelegate(mListView);
```

#### AUTO 


```{c}
auto *evt = new QMouseEvent(type, pos, button, buttons, Qt::NoModifier);
```

#### AUTO 


```{c}
auto* textLabel = new QLabel;
```

#### AUTO 


```{c}
auto mainWidget = new QWidget;
```

#### AUTO 


```{c}
const auto zoom = mParentView->zoom() / dpr;
```

#### LAMBDA EXPRESSION 


```{c}
[=](){QDesktopServices::openUrl(QUrl(KIPI_PLUGINS_URL));}
```

#### AUTO 


```{c}
const auto actionsList = d->mSortAction->actions();
```

#### AUTO 


```{c}
auto focusButton = static_cast<QPushButton *>(buttons->focusWidget());
```

#### AUTO 


```{c}
auto* touchEvent = static_cast<QTouchEvent*>(event);
```

#### AUTO 


```{c}
auto *ownerWatcher = new DBusStringReplyWatcher(this);
```

#### AUTO 


```{c}
auto job = new Baloo::TagListJob();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto index : selected.indexes()) {
            KFileItem item = mDirModel->itemForIndex(index);
            if (!ArchiveUtils::fileItemIsDirOrArchive(item)) {
                mSelectedMediaItems->append(item);
            }
        }
```

#### AUTO 


```{c}
auto* menu = new QMenu(mAddFilterButton);
```

#### AUTO 


```{c}
const auto selectedFileItemList = contextManager()->selectedFileItemList();
```

#### LAMBDA EXPRESSION 


```{c}
[=](int value) {
            GwenviewConfig::setJPEGQuality(value);
        }
```

#### AUTO 


```{c}
auto edit = new KActionCategory(i18nc("@title actions category", "Edit"), actionCollection);
```

#### AUTO 


```{c}
auto *JPEGQualityChooserLabel = new QLabel;
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction * action : actionsList) {
        if (sortingFromSortAction(action) == GwenviewConfig::sorting()) {
            action->setChecked(true);
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem& item : qAsConst(fileList)) {
            d->addItem(item);
        }
```

#### AUTO 


```{c}
auto *buttonBox = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QRect &outerRect : outerRegion) {
        painter->fillRect(outerRect, outerColor);
    }
```

#### AUTO 


```{c}
auto *completer = new QCompleter(mTagComboBox);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KIPI::ImageCollection &collection : list) {
        auto *item = new QListWidgetItem(d->mListWidget);
        QString name = collection.name();
        int imageCount = collection.images().size();
        QString title = i18ncp("%1 is collection name, %2 is image count in collection", "%1 (%2 image)", "%1 (%2 images)", name, imageCount);

        item->setText(title);
        item->setData(Qt::UserRole, name);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, rating]() {
                mRatingWidget->setRating(rating * 2);
            }
```

#### AUTO 


```{c}
auto *dirModel = new SortedDirModel(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->mView->setBackgroundColorMode(DocumentView::BackgroundColorMode::Light);
        qApp->paletteChanged(qApp->palette());
    }
```

#### AUTO 


```{c}
auto* adapter = new MessageViewAdapter;
```

#### AUTO 


```{c}
auto assignToAllButton = static_cast<QToolButton *>(widgets[1]);
```

#### AUTO 


```{c}
auto *inButton = new QPushButton(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString & pathPart : relativePathList) {
        bool found = false;
        for (int row = 0; row < mModel->rowCount(lastFoundIndex); ++row) {
            QModelIndex index = mModel->index(row, 0, lastFoundIndex);
            if (index.data().toString() == pathPart) {
                // FIXME: Check encoding
                found = true;
                lastFoundIndex = index;
                break;
            }
        }
        if (!found) {
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl & src : qAsConst(list)) {
        QUrl dst = remoteUrl;
        dst.setPath(dst.path() + '/' + src.fileName());
        QVERIFY(FileUtils::contentsAreIdentical(src, dst));
    }
```

#### AUTO 


```{c}
auto action = new QWidgetAction(&menu);
```

#### AUTO 


```{c}
auto *buttonBox = new QDialogButtonBox(QDialogButtonBox::Ok|QDialogButtonBox::Cancel);
```

#### AUTO 


```{c}
const auto dpr = painter->device()->devicePixelRatioF();
```

#### AUTO 


```{c}
auto sortActionMenu = view->add<KActionMenu>("sort_by");
```

#### AUTO 


```{c}
auto dialog = new ConfigDialog(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const AbstractSortedDirModelFilter *filter : qAsConst(d->mFilters)) {
                // Make sure we have semanticinfo, otherwise retrieve it and
                // return false, we will be called again later when it is
                // there.
                if (filter->needsSemanticInfo()) {
                    d->mSourceModel->retrieveSemanticInfoForIndex(index);
                    return false;
                }
            }
```

#### AUTO 


```{c}
auto in = (QIODevice *)png_get_io_ptr(png_ptr);
```

#### AUTO 


```{c}
auto completer = new QCompleter(q);
```

#### AUTO 


```{c}
auto *doc = new Document(url);
```

#### AUTO 


```{c}
auto *onlyBaseUrlModel = new OnlyBaseUrlProxyModel(d->mSrcBaseUrl, d->mSrcBaseIcon, d->mSrcBaseName, this);
```

#### AUTO 


```{c}
auto* item = new QListWidgetItem(d->mListWidget);
```

#### AUTO 


```{c}
auto JPEGQualityChooserSpinBox = new QSpinBox;
```

#### AUTO 


```{c}
auto* onlyBaseUrlModel = new OnlyBaseUrlProxyModel(d->mSrcBaseUrl, d->mSrcBaseIcon, d->mSrcBaseName, this);
```

#### AUTO 


```{c}
const auto imageRect = QRectF{mParent->imageOffset().toPoint(), QSize{width, height}};
```

#### AUTO 


```{c}
auto *watcher = new QDBusPendingCallWatcher(mScreenSaverInterface->GetActive(), this);
```

#### LAMBDA EXPRESSION 


```{c}
[this, d](const QString &text) {
        const bool startsWithNumber = text.constBegin()->isNumber();
        int matches = 0;
        for (int i = 0; i < count(); ++i) {
            if (itemText(i).startsWith(text, Qt::CaseInsensitive)) {
                matches += 1;
            }
        }
        Qt::MatchFlags matchFlags = startsWithNumber || matches > 1 ? Qt::MatchFixedString : Qt::MatchStartsWith;
        const int textIndex = findText(text, matchFlags);
        if (textIndex < 0) {
            setValue(valueFromText(text));
        }
        activateAndChangeZoomTo(textIndex);
        lineEdit()->setCursorPosition(lineEdit()->cursorPosition() - 1);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : qAsConst(shortList)) {
        if (longList.contains(index)) {
            d->mSelectedFileItemListNeedsUpdate = true;
            d->queueSignal(&ContextManager::selectionDataChanged);
            return;
        }
    }
```

#### AUTO 


```{c}
auto* edit = new KActionCategory(i18nc("@title actions category - means actions changing image", "Edit"), actionCollection);
```

#### AUTO 


```{c}
auto fadeOut = new QPropertyAnimation(mToolTip, "opacity");
```

#### RANGE FOR STATEMENT 


```{c}
for (const QPixmap& pix : pixmaps) {
        QPixmap pix2 = pix.scaled(DRAG_THUMB_SIZE - 2, DRAG_THUMB_SIZE - 2, Qt::KeepAspectRatio, Qt::SmoothTransformation);
        QRect rect(-pix2.width() / 2, -pix2.height() - extraSpace, pix2.width(), pix2.height());

        if (!pix2.hasAlphaChannel()) {
            // Draw a thin white border around fully opaque pictures to give them a photo-like appearance
            painter.fillRect(rect.adjusted(-1, -1, 1, 1), Qt::white);
        }
        painter.drawPixmap(rect.topLeft(), pix2);

        QPoint topRight = painter.transform().map(rect.topRight());
        maxX = qMax(topRight.x(), maxX);
        /*
        painter.drawRect(-pix2.width() / 2, -pix2.height() - extraSpace, pix2.width(), pix2.height());
        painter.drawText(-pix2.width() / 2, -pix2.height() - extraSpace, pix2.width(), pix2.height(), Qt::AlignTop | Qt::AlignLeft, QString::number(index));
        index++;
        */
        painter.rotate(delta);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            this->updateHamburgerMenu();
            // Immediately disconnect. We only need to run this once, but on demand.
            // NOTE: The nullptr at the end disconnects all connections between
            // q and mHamburgerMenu's aboutToShowMenu signal.
            disconnect(mHamburgerMenu, &KHamburgerMenu::aboutToShowMenu, q, nullptr);
        }
```

#### AUTO 


```{c}
auto dest = (inmem_dest_mgr *)(*cinfo->mem->alloc_small)((j_common_ptr)cinfo, JPOOL_PERMANENT, sizeof(inmem_dest_mgr));
```

#### AUTO 


```{c}
static const auto MAXSTEP = sqrt(2.0);
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
                QDesktopServices::openUrl(QUrl(KIPI_PLUGINS_URL));
                d->mPluginWatcher.addPaths(QCoreApplication::libraryPaths());
                connect(&d->mPluginWatcher, &QFileSystemWatcher::directoryChanged, this, &KIPIInterface::packageFinished);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this](){ d->applyPalette(window()->isFullScreen()); }
```

#### AUTO 


```{c}
auto* muteButton = new HudButton;
```

#### AUTO 


```{c}
auto fileOpsItem = new FileOpsContextManagerItem(mContextManager, mThumbnailView, actionCollection, q);
```

#### AUTO 


```{c}
auto *tagModel = new TagModel(parent);
```

#### AUTO 


```{c}
auto touchEvent = static_cast<QTouchEvent *>(event);
```

#### AUTO 


```{c}
const auto zoom = mParentView->zoom();
```

#### AUTO 


```{c}
auto *layout = new QVBoxLayout(this);
```

#### AUTO 


```{c}
auto edit = new KActionCategory(i18nc("@title actions category - means actions changing image", "Edit"), actionCollection);
```

#### AUTO 


```{c}
auto* infoItem = new InfoContextManagerItem(mContextManager);
```

#### RANGE FOR STATEMENT 


```{c}
for (const AbstractSortedDirModelFilter * filter : qAsConst(d->mFilters)) {
                // Make sure we have semanticinfo, otherwise retrieve it and
                // return false, we will be called again later when it is
                // there.
                if (filter->needsSemanticInfo()) {
                    d->mSourceModel->retrieveSemanticInfoForIndex(index);
                    return false;
                }
            }
```

#### AUTO 


```{c}
auto *op = new CropImageOperation(d->mRect);
```

#### AUTO 


```{c}
auto* mimeData = new QMimeData;
```

#### RANGE FOR STATEMENT 


```{c}
for (DocumentView *view : qAsConst(*d->mViews)) {
        if (view == d->mCurrentView.data()) {
            continue;
        }
        view->setZoom(zoom);
    }
```

#### AUTO 


```{c}
auto* delegate = new KDialogJobUiDelegate;
```

#### AUTO 


```{c}
auto edit = new KActionCategory(i18nc("@title actions category", "Edit"), mActionCollection);
```

#### AUTO 


```{c}
auto *button = qobject_cast<QToolButton *>(object);
```

#### AUTO 


```{c}
auto *widget = qobject_cast<QGraphicsWidget *>(d->mTarget);
```

#### AUTO 


```{c}
auto *button = new QToolButton(mPositionFrame);
```

#### AUTO 


```{c}
auto *JPEGQualityChooserSpinBox = new QSpinBox;
```

#### AUTO 


```{c}
auto *floater = new GraphicsWidgetFloater(q);
```

#### AUTO 


```{c}
auto job = new KIO::ApplicationLauncherJob(service);
```

#### AUTO 


```{c}
auto floater = new GraphicsWidgetFloater(q);
```

#### AUTO 


```{c}
auto *tap = static_cast<QTapGesture *>(event->gesture(Qt::TapGesture))
```

#### AUTO 


```{c}
auto *label = new QLabel(this);
```

#### AUTO 


```{c}
auto currentTimeProxy = new QGraphicsProxyWidget(hudContent);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QFileInfo &info : entryInfoList) {
        QUrl url("file://" + info.absoluteFilePath());
        KFileItem item(url);
        list << item;
    }
```

#### AUTO 


```{c}
auto edit = new KActionCategory(i18nc("@title actions category - means actions changing smth in interface", "Edit"), actionCollection);
```

#### AUTO 


```{c}
auto* anim = new QParallelAnimationGroup();
```

#### AUTO 


```{c}
auto* layout = new QVBoxLayout(d->mSaveBarWidget);
```

#### AUTO 


```{c}
auto rowLayout = new QHBoxLayout(d->mTopRowWidget);
```

#### AUTO 


```{c}
auto *view = new KActionCategory(i18nc("@title actions category - means actions changing smth in interface", "View"), mActionCollection);
```

#### AUTO 


```{c}
auto *op = new TransformImageOperation(ROT_270);
```

#### RANGE FOR STATEMENT 


```{c}
for (DocumentView *view : qAsConst(d->mDocumentViews)) {
        view->setCompareMode(d->mCompareMode);
        if (view->url() == currentUrl) {
            d->setCurrentView(view);
        } else {
            view->setCurrent(false);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction * action : qAsConst(d->mActions)) {
        action->setEnabled(enabled);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](const QModelIndex &index, int first, int last) {
        // Avoid the delegate doing a ton of work if we're not visible
        if (isVisible()) {
            emit rowsRemovedSignal(index, first, last);
        }
    }
```

#### AUTO 


```{c}
auto *action = new QWidgetAction(&menu);
```

#### AUTO 


```{c}
auto *adapter = new MessageViewAdapter;
```

#### RANGE FOR STATEMENT 


```{c}
for (auto mime: supported) {
            list << resolveAlias(QString::fromUtf8(mime));
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=](int value) {
        mGeneralConfigPage.kcfg_JPEGQuality->setValue(value);
    }
```

#### AUTO 


```{c}
auto* edit = new KActionCategory(i18nc("@title actions category - means actions changing smth in interface", "Edit"), actionCollection);
```

#### AUTO 


```{c}
auto widget
```

#### RANGE FOR STATEMENT 


```{c}
for (const KService::Ptr & service : qAsConst(mServiceList)) {
        QString text = service->name().replace('&', "&&");
        QAction* action = openMenu->addAction(text);
        action->setIcon(QIcon::fromTheme(service->icon()));
        action->setData(idx);
        ++idx;
    }
```

#### AUTO 


```{c}
auto monitor = new DisabledActionShortcutMonitor(action, q);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem & item : items) {
            if (!itemSet.contains(item.url().url())) {
                mItems.append(item);
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        QUrl destUrl = dialog->selectedUrls().at(0);

        KIO::CopyJob* job = nullptr;
        switch (operation) {
        case COPY:
            job = KIO::copy(urlList, destUrl);
            break;
        case MOVE:
            job = KIO::move(urlList, destUrl);
            break;
        case LINK:
            job = KIO::link(urlList, destUrl);
            break;
        default:
            Q_ASSERT(0);
        }
        KJobWidgets::setWindow(job, parent);
        job->uiDelegate()->setAutoErrorHandlingEnabled(true);

        if (numberOfImages == 1) {
            destUrl = destUrl.adjusted(QUrl::RemoveFilename|QUrl::StripTrailingSlash);
        }
        contextManager->setTargetDirUrl(destUrl);
    }
```

#### AUTO 


```{c}
auto* edit = new KActionCategory(i18nc("@title actions category", "Edit"), actionCollection);
```

#### AUTO 


```{c}
auto *muteButton = new HudButton;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : list) {
        Document::Ptr doc = DocumentFactory::instance()->load(url);
        DocumentJob *job = doc->save(url, doc->format());
        connect(job, &DocumentJob::result, this, &SaveAllHelper::slotResult);
        d->mJobSet << job;
    }
```

#### AUTO 


```{c}
auto data = new KAboutData(appName, programName, QStringLiteral(GWENVIEW_VERSION_STRING));
```

#### AUTO 


```{c}
auto* flowLayout = new FlowLayout(cropWidget, 6, 0);
```

#### AUTO 


```{c}
auto *proxy = new QGraphicsProxyWidget;
```

#### AUTO 


```{c}
auto *action = new QAction(text, q);
```

#### RANGE FOR STATEMENT 


```{c}
for (ContextManagerPrivate::Signal signal : qAsConst(d->mQueuedSignals)) {
        emit(this->*signal)();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex & index : list) {
        KFileItem item = itemForIndex(index);
        if (!ArchiveUtils::fileItemIsDirOrArchive(item)) {
            d->mUrlList << item.url();
        }
        // FIXME: Handle dirs (do we want to import recursively?)
    }
```

#### AUTO 


```{c}
auto *clearAction = mFileOpenRecentAction->menu()->findChild<QAction *>("clear_action");
```

#### AUTO 


```{c}
auto iconLabel = new QLabel;
```

#### AUTO 


```{c}
auto* item = new HistoryItem(url, dateTime, file.fileName());
```

#### AUTO 


```{c}
auto mouseEvent = static_cast<QMouseEvent *>(event);
```

#### AUTO 


```{c}
auto iconEffect = new QGraphicsOpacityEffect(mPlaceHolderIconLabel);
```

#### AUTO 


```{c}
auto *job = qobject_cast<DownSamplingJob *>(mCurrentJob.data());
```

#### AUTO 


```{c}
auto layout = new QGraphicsLinearLayout(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &dirItem : fileItems) {
                QDir dir = QDir(dirItem.localPath());
                const QStringList fileList = dir.entryList(QDir::Filter::Files);
                const bool containsAtLeastAnImage = std::any_of(fileList.cbegin(), fileList.cend(), [&db, &dir](const QString& fileName){
                    const auto mimeType = db.mimeTypeForFile(dir.absoluteFilePath(fileName), QMimeDatabase::MatchExtension);
                    return mimeType.name().startsWith(QStringLiteral("image"));
                });
                if (containsAtLeastAnImage) {
                    itemsForSlideShow << dirItem.localPath();
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &tag : tags) {
        d->mAllTags << tag;
    }
```

#### AUTO 


```{c}
auto watcher = new DBusBoolReplyWatcher(this);
```

#### AUTO 


```{c}
auto *layout = new QHBoxLayout(d->mContextBar);
```

#### AUTO 


```{c}
auto *removeButton = static_cast<QToolButton *>(widgets[0]);
```

#### AUTO 


```{c}
auto* removeButton = new QToolButton;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString & name : rcFilesList) {
            HistoryItem* item = HistoryItem::load(dir.filePath(name));
            if (!item) {
                continue;
            }

            QUrl itemUrl = item->url();
            if (UrlUtils::urlIsFastLocalFile(itemUrl)) {
                if (!QFile::exists(itemUrl.path())) {
                    qDebug() << "Removing" << itemUrl.path() << "from recent folders. It does not exist anymore";
                    item->unlink();
                    delete item;
                    continue;
                }
            }

            HistoryItem* existingItem = mHistoryItemForUrl.value(item->url());
            if (existingItem) {
                // We already know this url(!) update existing item dateTime
                // and get rid of duplicate
                if (existingItem->dateTime() < item->dateTime()) {
                    existingItem->setDateTime(item->dateTime());
                }
                item->unlink();
                delete item;
            } else {
                mHistoryItemForUrl.insert(item->url(), item);
                q->appendRow(item);
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->mView->setBackgroundColorMode(BackgroundColorWidget::Dark);
        qApp->paletteChanged(qApp->palette());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (DocumentView *view : qAsConst(*d->mViews)) {
        if (view == d->mCurrentView.data()) {
            continue;
        }
        view->setZoomToFit(fit);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &item : selectedFileItemList) {
        const QString mimeType = item.mimetype();
        if (!mimeTypes.contains(mimeType)) {
            mimeTypes << mimeType;
        }
    }
```

#### AUTO 


```{c}
auto* bottomRowLayout = new QHBoxLayout;
```

#### AUTO 


```{c}
auto* content = new QWidget(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->mView->setBackgroundColorMode(DocumentView::BackgroundColorMode::Auto);
        qApp->paletteChanged(qApp->palette());
    }
```

#### AUTO 


```{c}
auto item = new QStandardItem(label);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &item : items) {
            if (!itemSet.contains(item)) {
                mItems.append(item);
            }
        }
```

#### AUTO 


```{c}
auto *ke = static_cast<QKeyEvent*>(event);
```

#### LAMBDA EXPRESSION 


```{c}
[this, d](const QString &text) {
        const bool startsWithNumber = text.constBegin()->isNumber();
        int matches = 0;
        for (int i = 0; i < count(); ++i) {
            if (itemText(i).startsWith(text, Qt::CaseInsensitive)) {
                matches += 1;
            }
        }
        Qt::MatchFlags matchFlags = startsWithNumber || matches > 1 ? Qt::MatchFixedString : Qt::MatchStartsWith;
        const int textIndex = findText(text, matchFlags);
        if (textIndex < 0) {
            d->value = valueFromText(text);
        }
        if (textIndex >= 0 || d->value >= minimum()) {
            // update only when doing so would not change the typed text due
            // to being below the mininum as that means we can't type a new percentage
            // one key at a time.
            if (textIndex < 0)
                d->lastCustomZoomValue = d->value;
            updateDisplayedText();
            activateAndChangeZoomTo(textIndex);
            lineEdit()->setCursorPosition(lineEdit()->cursorPosition() - 1);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        // gwenview -s %u
        auto job = new KIO::CommandLauncherJob(QStringLiteral("gwenview"), QStringList(QStringLiteral("-s")) << itemsForSlideShow);
        job->setDesktopName(QStringLiteral("org.kde.gwenview"));
        job->setUiDelegate(new KNotificationJobUiDelegate(KJobUiDelegate::AutoHandlingEnabled));

        job->start();
    }
```

#### AUTO 


```{c}
auto *containerLayout = new QVBoxLayout(d->mContainer);
```

#### AUTO 


```{c}
auto* containerLayout = new QVBoxLayout(d->mContainer);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &name : files) {
        lst << QUrl::fromLocalFile(dir.absoluteFilePath(name));
    }
```

#### AUTO 


```{c}
auto* touchEvent = static_cast<QTouchEvent*>(event)
```

#### AUTO 


```{c}
auto *innerLayout = new QHBoxLayout();
```

#### AUTO 


```{c}
auto *statJob = KIO::statDetails(baseUrl, KIO::StatJob::DestinationSide, KIO::StatNoDetails);
```

#### AUTO 


```{c}
auto *container = new SlideContainer(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QAction *action : actionList) {
        if (action->isChecked()) {
            details |= PreviewItemDelegate::ThumbnailDetail(action->data().toInt());
        }
    }
```

#### AUTO 


```{c}
auto* container = new SlideContainer(this);
```

#### AUTO 


```{c}
auto *kindProxyModel = new KindProxyModel(q);
```

#### AUTO 


```{c}
auto job = static_cast<KIO::CopyJob *>(_job);
```

#### AUTO 


```{c}
auto *content = new QGraphicsWidget();
```

#### AUTO 


```{c}
auto* outButton = new QPushButton(this);
```

#### AUTO 


```{c}
auto *timer = new QTimer(this);
```

#### AUTO 


```{c}
auto* layout = new QVBoxLayout(mContentWidget);
```

#### AUTO 


```{c}
auto *watcher = new EventWatcher(watched, QList<QEvent::Type>() << eventType);
```

#### RANGE FOR STATEMENT 


```{c}
for (const CropHandle & handle : qAsConst(d->mCropHandleList)) {
            rect = d->handleViewportRect(handle);
            painter->drawRect(rect);
        }
```

#### AUTO 


```{c}
const auto resolved = resolveAlias(rawMimetype);
```

#### AUTO 


```{c}
auto *item = new HistoryItem(url, dateTime, file.fileName());
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            d->setupPlaceHolderView();
        }
```

#### AUTO 


```{c}
auto* layout = new QVBoxLayout(this);
```

#### AUTO 


```{c}
auto *src = static_cast<IODeviceJpegSourceManager *>(cinfo->src);
```

#### AUTO 


```{c}
auto tool = new CropTool(imageView);
```

#### RANGE FOR STATEMENT 


```{c}
for (QSizeF size : qAsConst(ratioList)) {
            size.transpose();
            addRatioToComboBox(size);
        }
```

#### AUTO 


```{c}
auto *layout = new QHBoxLayout(mContent);
```

#### AUTO 


```{c}
auto *op = new SuccessOperation;
```

#### AUTO 


```{c}
auto playPauseButton = new HudButton;
```

#### AUTO 


```{c}
auto *content = new QWidget(this);
```

#### AUTO 


```{c}
auto *edit = new KActionCategory(i18nc("@title actions category - means actions changing image", "Edit"), actionCollection);
```

#### AUTO 


```{c}
auto* anim = new QPropertyAnimation(mOpacityEffect, "opacity");
```

#### AUTO 


```{c}
auto container = new QWidget;
```

#### AUTO 


```{c}
auto *op = new TestOperation;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex & index : qAsConst(shortList)) {
        if (longList.contains(index)) {
            d->mSelectedFileItemListNeedsUpdate = true;
            d->queueSignal(&ContextManager::selectionDataChanged);
            return;
        }
    }
```

#### AUTO 


```{c}
auto* hudContent = new QGraphicsWidget;
```

#### AUTO 


```{c}
auto* finder = new DocumentDirFinder(srcBaseUrl);
```

#### AUTO 


```{c}
auto *buttonBox = new QDialogButtonBox(QDialogButtonBox::Close);
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool checked){
        if (checked) {
            d->mView->setZoom(1.0);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (DocumentView* view : qAsConst(*d->mViews)) {
        if (view == d->mCurrentView.data()) {
            continue;
        }
        view->setZoomToFit(fit);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](int value) {
        mGeneralConfigPage.jpegQualitySpinner->setValue(value);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (HudButton *button : qAsConst(mButtonList)) {
            button->setMinimumWidth(minWidth);
        }
```

#### AUTO 


```{c}
auto *edit = new KActionCategory(i18nc("@title actions category", "Edit"), actionCollection);
```

#### AUTO 


```{c}
auto *delegate = new PreviewItemDelegate(view);
```

#### AUTO 


```{c}
auto* horizontalSpacer = new QSpacerItem(1, 1, QSizePolicy::Expanding, QSizePolicy::Fixed);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto action : mSortAction->actions()) {
            sortActionMenu->addAction(action);
        }
```

#### AUTO 


```{c}
auto *dirModel = static_cast<SortedDirModel *>(sender());
```

#### AUTO 


```{c}
auto* job = qobject_cast<DownSamplingJob*>(mCurrentJob.data());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString & dirName : qAsConst(mUrl1Dirs)) {
        dir.mkdir("url1/" + dirName);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : urlList) {
        DocumentFactory::instance()->forget(url);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (qreal zoom : qAsConst(d->mZoomSnapValues)) {
        if (zoom > currentZoom + REAL_DELTA) {
            d->setZoom(zoom, center);
            return;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& key : textKeys) {
            QString text = largeImage.text(key);
            image.setText(key, text);
        }
```

#### AUTO 


```{c}
auto* bubble = new HudMessageBubble();
```

#### AUTO 


```{c}
auto* myerr = static_cast<JPEGErrorManager*>(cinfo->err);
```

#### LAMBDA EXPRESSION 


```{c}
[this](){
            this->resetCropState();
        }
```

#### AUTO 


```{c}
auto* tool = new RedEyeReductionTool(view);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : qAsConst(dirUrls)) {
        d->mDirLister->openUrl(url, KDirLister::Keep);
    }
```

#### AUTO 


```{c}
auto* sortModel = new QSortFilterProxyModel(this);
```

#### AUTO 


```{c}
auto* delegate = new ThumbnailBarItemDelegate(mThumbnailBar);
```

#### AUTO 


```{c}
auto* historyItem = static_cast<RecentFilesItem*>(item(row, 0));
```

#### AUTO 


```{c}
auto JPEGQualityChooserLabel = new QLabel;
```

#### LAMBDA EXPRESSION 


```{c}
[this, url]() {
        emit readyForDirListerStart(url);
    }
```

#### AUTO 


```{c}
auto imageRect = mParentView->mapToImage(viewportRect);
```

#### AUTO 


```{c}
auto* mappedFile = reinterpret_cast<unsigned char*>(d->mRawData.data());
```

#### AUTO 


```{c}
auto *screenLockServiceWatcher = new QDBusServiceWatcher(this);
```

#### AUTO 


```{c}
auto *layout = new QGridLayout(mPositionFrame);
```

#### AUTO 


```{c}
auto* job = static_cast<DocumentJob*>(_job);
```

#### AUTO 


```{c}
auto adapterContainerLayout = new QVBoxLayout(mAdapterContainer);
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : qAsConst(d->mActions)) {
        action->setEnabled(enabled);
    }
```

#### AUTO 


```{c}
auto widget = qobject_cast<QGraphicsWidget *>(d->mTarget);
```

#### AUTO 


```{c}
auto it = exifData.findKey(key);
```

#### AUTO 


```{c}
const auto &index
```

#### AUTO 


```{c}
auto *action = new QAction(q);
```

#### LAMBDA EXPRESSION 


```{c}
[=](const int &state) {
        mGeneralConfigPage.kcfg_AutoplayVideos->setEnabled(state == Qt::Checked);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &index : indexes) {
        selectedFiles << fileItemForIndex(index);
    }
```

#### AUTO 


```{c}
auto anim = new QPropertyAnimation(mOpacityEffect, "opacity");
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->applyPalette(window()->isFullScreen());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &token : lst) {
                if (!token.isEmpty()) {
                    semanticInfo.mTags << '#' + token.toLower();
                }
            }
```

#### AUTO 


```{c}
const auto duration = qlonglong(mSlideShow->interval() * 1000000);
```

#### AUTO 


```{c}
auto dest = (inmem_dest_mgr *)(cinfo->dest);
```

#### AUTO 


```{c}
auto *op = new TransformImageOperation(ROT_90);
```

#### AUTO 


```{c}
auto *buttons = d->mCropWidget->findChild<QDialogButtonBox *>();
```

#### AUTO 


```{c}
auto layout = new QGraphicsLinearLayout(hudContent);
```

#### AUTO 


```{c}
auto* menu = static_cast<QMenu*>(q->menu());
```

#### AUTO 


```{c}
auto mappedFile = reinterpret_cast<unsigned char *>(d->mRawData.data());
```

#### AUTO 


```{c}
auto onlyBaseUrlModel = new OnlyBaseUrlProxyModel(d->mSrcBaseUrl, d->mSrcBaseIcon, d->mSrcBaseName, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const CropHandle &handle : qAsConst(d->mCropHandleList)) {
            rect = d->handleViewportRect(handle);
            painter->drawRect(rect);
        }
```

#### AUTO 


```{c}
auto document = mParentView->document();
```

#### AUTO 


```{c}
auto layout = new QVBoxLayout(mContentWidget);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto button : buttonList) {
        button->setText(text);
        button->setToolTip(toolTip);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](int i){ setCustomZoomFromSpinBox(static_cast<qreal>(i)); }
```

#### AUTO 


```{c}
auto* layout = new QGraphicsLinearLayout(this);
```

#### AUTO 


```{c}
auto dirModel = new SortedDirModel(this);
```

#### AUTO 


```{c}
auto* watcher = new EventWatcher(watched, QList<QEvent::Type>() << eventType);
```

#### AUTO 


```{c}
auto separator = new QFrame;
```

#### AUTO 


```{c}
auto* button = new QToolButton(mPositionFrame);
```

#### RANGE FOR STATEMENT 


```{c}
for (DocumentView* view : d->mViews | d->mAddedViews) {
        view->setPalette(palette);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (DocumentView * view : qAsConst(views)) {
            QRect rect;
            rect.setLeft(col * viewWidth);
            rect.setTop(row * viewHeight);
            rect.setWidth(viewWidth);
            rect.setHeight(viewHeight);

            if (animated) {
                if (d->mViews.contains(view)) {
                    if (rect != view->geometry()) {
                        if (d->mAddedViews.isEmpty() && d->mRemovedViews.isEmpty()) {
                            // View moves because of a resize
                            view->moveTo(rect);
                        } else {
                            // View moves because the number of views changed,
                            // animate the change
                            view->moveToAnimated(rect);
                        }
                    }
                } else {
                    view->setGeometry(rect);
                    view->fadeIn();
                }
            } else {
                // Not animated, set final geometry and opacity now
                view->setGeometry(rect);
                view->setGraphicsEffectOpacity(1);
            }

            ++col;
            if (col == colCount) {
                col = 0;
                ++row;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Row* row : qAsConst(mRows)) {
            rowY = row->setLabelGeometries(rowY, labelWidth);
        }
```

#### AUTO 


```{c}
auto job = new KIO::CommandLauncherJob(QStringLiteral("gwenview"), QStringList("-s") << itemsForSlideShow);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem & item : selectedFileItemList) {
        const QString mimeType = item.mimetype();
        if (!mimeTypes.contains(mimeType)) {
            mimeTypes << mimeType;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->mView->setBackgroundColorMode(DocumentView::BackgroundColorMode::Dark);
        qApp->paletteChanged(qApp->palette());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &name : attributeNames) {
            mAttributes.remove(name);
        }
```

#### AUTO 


```{c}
auto *removeButton = new QToolButton;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &url : qAsConst(tmpArgs)) {
                QUrl fileUrl = QUrl::fromUserInput(url, QDir::currentPath(), QUrl::AssumeLocalFile);
                if (!fileNames.contains(fileUrl.fileName())) {
                    fileNames << fileUrl.fileName();
                    list << fileUrl;
                }
            }
```

#### AUTO 


```{c}
auto *anim = new QPropertyAnimation(this, "geometry");
```

#### AUTO 


```{c}
auto evt = new QMouseEvent(type, pos, button, buttons, Qt::NoModifier);
```

#### LAMBDA EXPRESSION 


```{c}
[this](){
        d->mView->setBackgroundColorMode(BackgroundColorWidget::Neutral);
        qApp->paletteChanged(qApp->palette());
    }
```

#### AUTO 


```{c}
auto* saveJob = static_cast<SaveJob*>(job);
```

#### LAMBDA EXPRESSION 


```{c}
[this](){ applyPalette(d->mGvCore->palette(GvCore::NormalViewPalette)); }
```

#### AUTO 


```{c}
auto* op = new RedEyeReductionImageOperation(docRectF);
```

#### AUTO 


```{c}
auto* op = new SuccessOperation;
```

#### AUTO 


```{c}
auto *delegate = new ThumbnailBarItemDelegate(mThumbnailBar);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &mime: supported) {
            const auto resolved = resolveAlias(QString::fromUtf8(mime));
            if (resolved.isEmpty()) {
                qCWarning(GWENVIEW_LIB_LOG) << "Unresolved mime type " << mime;
            } else {
                list << resolved;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QSizeF &size : qAsConst(ratioList)) {
            addRatioToComboBox(size);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Row* row : qAsConst(mRows)) {
             height += row->heightForWidth(w);
        }
```

#### AUTO 


```{c}
auto* widgetTarget = qobject_cast<QGraphicsWidget*>(target);
```

#### AUTO 


```{c}
auto *fileOpsItem = new FileOpsContextManagerItem(mContextManager, mThumbnailView, actionCollection, q);
```

#### AUTO 


```{c}
auto* view = new KActionCategory(i18nc("@title actions category - means actions changing smth in interface", "View"), mActionCollection);
```

#### AUTO 


```{c}
auto *JPEGQualityChooserWidget = new QWidget;
```

#### AUTO 


```{c}
auto* timer = new QTimer(this);
```

#### AUTO 


```{c}
auto* fadeOut = new QPropertyAnimation(mToolTip, "opacity");
```

#### AUTO 


```{c}
const auto height = int((mParent->documentSize().height() / qApp->devicePixelRatio()) * mParent->zoom());
```

#### AUTO 


```{c}
auto *layout = new QHBoxLayout(this);
```

#### AUTO 


```{c}
auto* dialog = new Gwenview::ImportDialog();
```

#### AUTO 


```{c}
auto touchEvent = static_cast<QTouchEvent *>(event)
```

#### AUTO 


```{c}
auto *job = static_cast<SaveJob *>(_job);
```

#### LAMBDA EXPRESSION 


```{c}
[&db, &dir](const QString& fileName){
                    const auto mimeType = db.mimeTypeForFile(dir.absoluteFilePath(fileName), QMimeDatabase::MatchExtension);
                    return mimeType.name().startsWith(QStringLiteral("image"));
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this, d](const QString &text){
        const bool startsWithNumber = text.constBegin()->isNumber();
        int matches = 0;
        for (int i = 0; i < count(); ++i) {
            if (itemText(i).startsWith(text, Qt::CaseInsensitive)) {
                matches += 1;
            }
        }
        Qt::MatchFlags matchFlags = startsWithNumber || matches > 1 ? Qt::MatchFixedString : Qt::MatchStartsWith;
        const int textIndex = findText(text, matchFlags);
        if (textIndex < 0) {
            setValue(valueFromText(text));
        }
        activateAndChangeZoomTo(textIndex);
        lineEdit()->setCursorPosition(lineEdit()->cursorPosition() - 1);
    }
```

#### AUTO 


```{c}
auto* statusBarContainerLayout = new QHBoxLayout(mStatusBarContainer);
```

#### AUTO 


```{c}
const auto mimeType = db.mimeTypeForFile(dir.absoluteFilePath(fileName), QMimeDatabase::MatchExtension);
```

#### RANGE FOR STATEMENT 


```{c}
for (QLayoutItem *item : qAsConst(itemList))
        size = size.expandedTo(item->minimumSize());
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->mView->setBackgroundColorMode(DocumentView::BackgroundColorMode::Neutral);
        qApp->paletteChanged(qApp->palette());
    }
```

#### AUTO 


```{c}
auto dialog = new Gwenview::ImportDialog();
```

#### AUTO 


```{c}
auto content = new QGraphicsWidget();
```

#### AUTO 


```{c}
auto menu = new QMenu(mAddFilterButton);
```

#### AUTO 


```{c}
auto* dest = (inmem_dest_mgr*)
                               (*cinfo->mem->alloc_small)((j_common_ptr) cinfo, JPOOL_PERMANENT,
                                       sizeof(inmem_dest_mgr));
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction * action : qAsConst(mExportActionList)) {
            action->setIconVisibleInMenu(true);
            if (action != mDefaultAction) {
                menu->addAction(action);
            }
        }
```

#### AUTO 


```{c}
auto bubble = new HudMessageBubble();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto item : *mSelectedMediaItems) {
                totalSize += item.size();
            }
```

#### AUTO 


```{c}
auto layout = new QVBoxLayout(content);
```

#### AUTO 


```{c}
auto content = new QGraphicsWidget;
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        applyPalette(d->mGvCore->palette(GvCore::NormalViewPalette));
    }
```

#### AUTO 


```{c}
auto* op = new TransformImageOperation(orientation);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &name : entryList) {
        QUrl url = QUrl::fromLocalFile(dir.absoluteFilePath(name));
        KFileItem item(url);
        list << item;
    }
```

#### AUTO 


```{c}
auto *watcher = new QFutureWatcher<void>(this);
```

#### AUTO 


```{c}
auto op = new TestOperation;
```

#### AUTO 


```{c}
auto textLabel = new QLabel;
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString & parentMimeType : mime.allAncestors()) {
            protocol = KProtocolManager::protocolForArchiveMimetype(parentMimeType);
            if (!protocol.isEmpty()) {
                break;
            }
        }
```

#### AUTO 


```{c}
auto *layout = new QGraphicsLinearLayout(content);
```

#### AUTO 


```{c}
auto *layout = new FlowLayout(mFrame);
```

#### AUTO 


```{c}
auto anim = new QPropertyAnimation(this, "slideHeight", this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& name : attributeNames) {
            mAttributes.remove(name);
        }
```

#### AUTO 


```{c}
auto content = new QLineEdit(container);
```

#### AUTO 


```{c}
auto* dirLister = new DirLister;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl & src : qAsConst(list)) {
        QUrl dst = destUrl;
        dst.setPath(dst.path() + '/' + src.fileName());
        QVERIFY(FileUtils::contentsAreIdentical(src, dst));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &item : itemList) {
        QModelIndex index = dirModel->indexForItem(item);
        dirModel->setData(index, description, SemanticInfoDirModel::DescriptionRole);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &key : textKeys) {
                QString text = largeImage.text(key);
                image.setText(key, text);
            }
```

#### AUTO 


```{c}
auto dialog = new KFileCustomDialog(mMainWindow);
```

#### AUTO 


```{c}
auto layout = new QHBoxLayout(widget);
```

#### AUTO 


```{c}
auto* layout = new QHBoxLayout(this);
```

#### AUTO 


```{c}
auto *layout = new QVBoxLayout(d->mSaveBarWidget);
```

#### AUTO 


```{c}
auto* floater = new GraphicsWidgetFloater(view);
```

#### AUTO 


```{c}
static const auto MINSTEP = sqrt(0.5);
```

#### AUTO 


```{c}
auto delegate = new TagItemDelegate(mListView);
```

#### AUTO 


```{c}
auto muteButton = new HudButton;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QPersistentModelIndex &index : qAsConst(d->mBusyIndexSet)) {
        update(index);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                    finish(true);
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : qAsConst(mExportActionList)) {
            action->setIconVisibleInMenu(true);
            if (action != mDefaultAction) {
                menu->addAction(action);
            }
        }
```

#### AUTO 


```{c}
auto *op = new TransformImageOperation(HFLIP);
```

#### AUTO 


```{c}
auto JPEGQualityChooserWidget = new QWidget;
```

#### AUTO 


```{c}
auto *glWidget = new QOpenGLWidget;
```

#### AUTO 


```{c}
auto *iconLabel = new QLabel;
```

#### AUTO 


```{c}
auto watcher = new QFutureWatcher<void>(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem & item : list) {
        MimeTypeUtils::Kind kind = MimeTypeUtils::fileItemKind(item);
        switch (kind) {
        case MimeTypeUtils::KIND_DIR:
        case MimeTypeUtils::KIND_ARCHIVE:
            if (d->mFoundDirUrl.isValid()) {
                // This is the second dir we find, stop now
                finish(dir, MultipleDirsFound);
                return;
            } else {
                // First dir
                d->mFoundDirUrl = item.url();
            }
            break;

        case MimeTypeUtils::KIND_RASTER_IMAGE:
        case MimeTypeUtils::KIND_SVG_IMAGE:
        case MimeTypeUtils::KIND_VIDEO:
            finish(dir, DocumentDirFound);
            return;

        case MimeTypeUtils::KIND_UNKNOWN:
        case MimeTypeUtils::KIND_FILE:
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (DocumentView* view : qAsConst(*mViews)) {
            if (view == mCurrentView.data()) {
                continue;
            }
            view->setZoom(mCurrentView.data()->zoom());
            view->setZoomToFit(mCurrentView.data()->zoomToFit());
            view->setZoomToFill(mCurrentView.data()->zoomToFill());
        }
```

#### AUTO 


```{c}
auto* completer = new QCompleter(q);
```

#### AUTO 


```{c}
auto *impl = qobject_cast<LoadingDocumentImpl *>(mImpl);
```

#### AUTO 


```{c}
auto layout = new FlowLayout(mFrame);
```

#### AUTO 


```{c}
auto* mainWidget = new QWidget;
```

#### AUTO 


```{c}
const auto entryList = dir.entryList();
```

#### AUTO 


```{c}
auto widget = new QWidget;
```

#### AUTO 


```{c}
auto delegate = new ThumbnailBarItemDelegate(mThumbnailBar);
```

#### AUTO 


```{c}
auto *assignToAllButton = new QToolButton;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &label : labels) {
            DecoratedTag *decoratedTag = new DecoratedTag(label);
            mTagLayout->addWidget(decoratedTag);
        }
```

#### AUTO 


```{c}
auto *dest = (inmem_dest_mgr *)(*cinfo->mem->alloc_small)((j_common_ptr)cinfo, JPOOL_PERMANENT, sizeof(inmem_dest_mgr));
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QUrl &url) {
            mFileOpenRecentAction->removeUrl(url);
        }
```

#### AUTO 


```{c}
auto *saveJob = static_cast<SaveJob *>(job);
```

#### AUTO 


```{c}
auto* tool = new CropTool(imageView);
```

#### AUTO 


```{c}
auto* layout = static_cast<QVBoxLayout*>(mSaveBarWidget->layout());
```

#### RANGE FOR STATEMENT 


```{c}
for (auto mime: qAsConst(supported)) {
            list << resolveAlias(QString::fromUtf8(mime));
        }
```

#### AUTO 


```{c}
auto* mouseEvent = static_cast<QMouseEvent*>(event);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &name : rcFilesList) {
            HistoryItem *item = HistoryItem::load(dir.filePath(name));
            if (!item) {
                continue;
            }

            const QUrl itemUrl = item->url();
            if (UrlUtils::urlIsFastLocalFile(itemUrl)) {
                if (!QFile::exists(itemUrl.path())) {
                    qCDebug(GWENVIEW_LIB_LOG) << "Removing" << itemUrl.path() << "from recent folders. It does not exist anymore";
                    item->unlink();
                    delete item;
                    continue;
                }
            }

            HistoryItem *existingItem = mHistoryItemForUrl.value(item->url());
            if (existingItem) {
                // We already know this url(!) update existing item dateTime
                // and get rid of duplicate
                if (existingItem->dateTime() < item->dateTime()) {
                    existingItem->setDateTime(item->dateTime());
                }
                item->unlink();
                delete item;
            } else {
                mHistoryItemForUrl.insert(item->url(), item);
                q->appendRow(item);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &key : textKeys) {
            QString text = largeImage.text(key);
            image.setText(key, text);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KService::Ptr &service : qAsConst(mServiceList)) {
        QString text = service->name().replace('&', "&&");
        QAction *action = openMenu->addAction(text);
        action->setIcon(QIcon::fromTheme(service->icon()));
        action->setData(idx);
        ++idx;
    }
```

#### AUTO 


```{c}
auto *keyEvent = static_cast<QKeyEvent *>(event);
```

#### AUTO 


```{c}
auto view = new KActionCategory(i18nc("@title actions category - means actions changing smth in interface", "View"), actionCollection);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &mimeName : QImageWriter::supportedMimeTypes()) {
            supportedMimetypes.append(QString::fromLocal8Bit(mimeName));
        }
```

#### AUTO 


```{c}
const auto actionList = mFilterController->actionList();
```

#### AUTO 


```{c}
const auto width = int((mParent->documentSize().width() / qApp->devicePixelRatio()) * mParent->zoom());
```

#### AUTO 


```{c}
auto * action = new QAction(q);
```

#### AUTO 


```{c}
auto *content = new QWidget;
```

#### LAMBDA EXPRESSION 


```{c}
[this, dialog]() {
        applyImageOperation(new ResizeImageOperation(dialog->size()));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QGraphicsView *view : views) {
                if (view->underMouse()) {
                    return q->mapFromScene(view->mapFromGlobal(QCursor::pos()));
                }
            }
```

#### AUTO 


```{c}
auto *monitor = new DisabledActionShortcutMonitor(action, q);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem& item : list) {
        if (item.isDir()) {
            continue;
        }
        int row = d->rowForUrl(item.url());
        if (row == -1) {
            qWarning() << "Received itemsDeleted for an unknown item: this should not happen!";
            GV_FATAL_FAILS;
            continue;
        }
        beginRemoveRows(QModelIndex(), row, row);
        d->removeAt(row);
        endRemoveRows();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QPersistentModelIndex & index : qAsConst(d->mBusyIndexSet)) {
        update(index);
    }
```

#### AUTO 


```{c}
auto* edit = new KActionCategory(i18nc("@title actions category", "Edit"), mActionCollection);
```

#### AUTO 


```{c}
auto button = new QToolButton(mPositionFrame);
```

#### AUTO 


```{c}
auto action = new QAction(parent);
```

#### AUTO 


```{c}
auto* adapterContainerLayout = new QVBoxLayout(mAdapterContainer);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem& item : newList) {
        if (item.isFile()) {
            if (d->rowForUrl(item.url()) == -1) {
                fileList << item;
            }
        } else {
            dirUrls << item.url();
        }
    }
```

#### AUTO 


```{c}
const auto defaultSplitterSizes = GwenviewConfig::thumbnailSplitterSizes();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &item : *mSelectedMediaItems) {
                totalSize += item.size();
            }
```

#### AUTO 


```{c}
auto *view = new KActionCategory(i18nc("@title actions category - means actions changing smth in interface", "View"), actionCollection);
```

#### AUTO 


```{c}
auto edit = qobject_cast<ItemEditor *>(widget);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& name : entryList) {
        QImage thumb;
        QVERIFY(thumb.load(thumbnailDir.filePath(name)));

        QUrl url(thumb.text("Thumb::URI"));
        KFileItem item = list.findByUrl(url);
        QVERIFY(!item.isNull());

        QSize originalSize = mSandBox.mSizeHash.value(item.url().fileName());
        uint mtime = item.time(KFileItem::ModificationTime).toSecsSinceEpoch();

        if (mtime == uint(-1)) {
            // This happens from time to time on build.kde.org, but I haven't
            // been able to reproduce it locally, so let's try to gather more
            // information.
            qWarning() << "mtime == -1 for url" << url << ". This should not happen!";
            qWarning() << "errno:" << errno << "message:" << strerror(errno);
            qWarning() << "QFile::exists(" << url.toLocalFile() << "):" << QFile::exists(url.toLocalFile());
            qWarning() << "Recalculating mtime" << item.time(KFileItem::ModificationTime).toSecsSinceEpoch();
            QFAIL("Invalid time for test KFileItem");
        }

        QCOMPARE(thumb.text("Thumb::Image::Width"), QString::number(originalSize.width()));
        QCOMPARE(thumb.text("Thumb::Image::Height"), QString::number(originalSize.height()));
        QCOMPARE(thumb.text("Thumb::Mimetype"), item.mimetype());
        QCOMPARE(thumb.text("Thumb::Size"), QString::number(item.size()));
        QCOMPARE(thumb.text("Thumb::MTime"), QString::number(mtime));
    }
```

#### AUTO 


```{c}
auto *tool = new CropTool(imageView);
```

#### AUTO 


```{c}
auto group
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &fileItem : fileItems) {
            itemsForSlideShow << fileItem.url().toString();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (DocumentView * view : qAsConst(d->mDocumentViews)) {
        QUrl url = view->url();
        if (urls.contains(url)) {
            // view displays an url we must display, keep it
            urls.remove(url);
            viewForUrlMap.insert(url, view);
        } else {
            // view url is not interesting, drop it
            d->deleteDocumentView(view);
        }
    }
```

#### AUTO 


```{c}
const auto views = sc->views();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : list) {
        d->mThumbnailView->reloadThumbnail(index);
    }
```

#### AUTO 


```{c}
auto it = d->mExifData.findKey(keyResUnit);
```

#### AUTO 


```{c}
auto effect = new QGraphicsOpacityEffect(mPlaceHolderLabel);
```

#### AUTO 


```{c}
auto impl = qobject_cast<LoadingDocumentImpl *>(mImpl);
```

#### AUTO 


```{c}
const auto index
```

#### AUTO 


```{c}
auto *myerr = static_cast<JPEGErrorManager *>(cinfo->err);
```

#### AUTO 


```{c}
auto *mainLayout = new QVBoxLayout;
```

#### RANGE FOR STATEMENT 


```{c}
for (QLayoutItem *item : qAsConst(itemList)) {
        const bool itemIsSpacer = item->spacerItem() != nullptr;
        // Don't add invisible items or succeeding spacer items
        if (item->sizeHint().width() == 0 || (itemIsSpacer && lastItemIsSpacer)) {
            continue;
        }

        int nextX = x + item->sizeHint().width() + horizontalSpacing();
        if (nextX - horizontalSpacing() > rect.right() - margin() && lineHeight > 0) {
            x = left;
            y = y + lineHeight + verticalSpacing();
            nextX = x + item->sizeHint().width() + horizontalSpacing();
            lineHeight = 0;
        }

        // Don't place spacer items at start of line
        if (itemIsSpacer && x == left) {
            continue;
        }

        if (!testOnly)
            item->setGeometry(QRect(QPoint(x, y), item->sizeHint()));

        x = nextX;
        // Don't add spacer items at end of line
        if (!itemIsSpacer) {
            widthForY[y] = x - margin();
        }
        lineHeight = qMax(lineHeight, item->sizeHint().height());
        lastItemIsSpacer = itemIsSpacer;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (DocumentView *view : qAsConst(d->mRemovedViews)) {
            view->deleteLater();
        }
```

#### AUTO 


```{c}
auto* move = new QPropertyAnimation(mToolTip, "geometry");
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &src : qAsConst(list)) {
        QUrl dst = destUrl;
        dst.setPath(dst.path() + '/' + src.fileName());
        QVERIFY(FileUtils::contentsAreIdentical(src, dst));
    }
```

#### AUTO 


```{c}
auto* event = static_cast<QKeyEvent*>(ev);
```

#### AUTO 


```{c}
auto *dialog = new QFileDialog(this);
```

#### AUTO 


```{c}
auto src = (IODeviceJpegSourceManager *)(*cinfo->mem->alloc_small)((j_common_ptr)cinfo, JPOOL_PERMANENT, sizeof(IODeviceJpegSourceManager));
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem & item : itemList) {
        QModelIndex index = dirModel->indexForItem(item);
        dirModel->setData(index, rating, SemanticInfoDirModel::RatingRole);
    }
```

#### AUTO 


```{c}
auto *widget = new QWidget;
```

#### AUTO 


```{c}
auto *widget = new QWidget(parent);
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction * action : qAsConst(d->mActionList)) {
        if (action->isEnabled() && action->priority() != QAction::LowPriority) {
            d->mGroup->addAction(action);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->mView->setBackgroundColorMode(BackgroundColorWidget::Neutral);
        qApp->paletteChanged(qApp->palette());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex & index : selection.indexes()) {
            mSelectedFileItemList << mDirModel->itemForIndex(index);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &item : qAsConst(fileList)) {
            d->addItem(item);
        }
```

#### AUTO 


```{c}
const auto entryInfoList = dir.entryInfoList(QDir::Files);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &item : list) {
        if (item.isDir()) {
            continue;
        }
        int row = d->rowForUrl(item.url());
        if (row == -1) {
            qCWarning(GWENVIEW_LIB_LOG) << "Received itemsDeleted for an unknown item: this should not happen!";
            GV_FATAL_FAILS;
            continue;
        }
        beginRemoveRows(QModelIndex(), row, row);
        d->removeAt(row);
        endRemoveRows();
    }
```

#### AUTO 


```{c}
auto* monitor = new DisabledActionShortcutMonitor(action, q);
```

#### AUTO 


```{c}
auto *bubble = new HudMessageBubble();
```

#### AUTO 


```{c}
auto *dialog = new ImporterConfigDialog(this);
```

#### AUTO 


```{c}
auto *view = new DocumentView(d->mScene);
```

#### AUTO 


```{c}
auto* layout = new FlowLayout(mFrame);
```

#### LAMBDA EXPRESSION 


```{c}
[this, dialog]() {
        if (!dialog->selectedUrls().isEmpty()) {
            openUrl(dialog->selectedUrls().at(0));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem& item : list) {
        if (item.isDir()) {
            continue;
        }
        int row = d->rowForUrl(item.url());
        if (row == -1) {
            qCWarning(GWENVIEW_LIB_LOG) << "Received itemsDeleted for an unknown item: this should not happen!";
            GV_FATAL_FAILS;
            continue;
        }
        beginRemoveRows(QModelIndex(), row, row);
        d->removeAt(row);
        endRemoveRows();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (DocumentView* view : qAsConst(d->mRemovedViews)) {
            view->fadeOut();
            QTimer::singleShot(DocumentView::AnimDuration, view, &QObject::deleteLater);
        }
```

#### AUTO 


```{c}
auto dialog = new ImporterConfigDialog(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QSizeF& size : qAsConst(ratioList)) {
            addRatioToComboBox(size);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[d]() {
        d->usingLightTheme = usingLightTheme();
        d->initPixmaps();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        this->resetCropState();
    }
```

#### AUTO 


```{c}
const auto actionList = d->mThumbnailDetailsActionGroup->actions();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& filePath : filePaths) {
        QFileInfo info(*this, filePath);
        mkpath(info.absolutePath());
        createEmptyFile(info.absoluteFilePath());
    }
```

#### AUTO 


```{c}
auto *optionsPage = new PrintOptionsPage(doc->size());
```

#### AUTO 


```{c}
auto job = static_cast<DocumentJob *>(_job);
```

#### RANGE FOR STATEMENT 


```{c}
for (HudButton *button : qAsConst(mButtonList)) {
            minWidth = qMax(minWidth, button->preferredWidth());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (DocumentView *view : qAsConst(*mViews)) {
            if (view == mCurrentView.data()) {
                continue;
            }
            view->setZoom(mCurrentView.data()->zoom());
            view->setZoomToFit(mCurrentView.data()->zoomToFit());
            view->setZoomToFill(mCurrentView.data()->zoomToFill());
        }
```

#### AUTO 


```{c}
auto* removeButton = static_cast<QToolButton*>(widgets[0]);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto group : s_thumbnailGroups) {
        const QString thumbnailDir = ThumbnailProvider::thumbnailBaseDir(group);
        QDir().mkpath(thumbnailDir);
        QFile::setPermissions(thumbnailDir, QFileDevice::WriteOwner | QFileDevice::ReadOwner | QFileDevice::ExeOwner);
    }
```

#### AUTO 


```{c}
auto dirModel = new KDirModel(this);
```

#### AUTO 


```{c}
auto it = d->mExifData.findKey(key);
```

#### AUTO 


```{c}
auto* content = new QLineEdit(container);
```

#### LAMBDA EXPRESSION 


```{c}
[&db, &dir](const QString &fileName) {
                    const auto mimeType = db.mimeTypeForFile(dir.absoluteFilePath(fileName), QMimeDatabase::MatchExtension);
                    return mimeType.name().startsWith(QStringLiteral("image"));
                }
```

#### AUTO 


```{c}
auto* anim = new QPropertyAnimation(this, "slideHeight", this);
```

#### AUTO 


```{c}
const auto separatorWidth = static_cast<float>(style()->pixelMetric(QStyle::PM_ToolBarSeparatorExtent, nullptr, this));
```

#### AUTO 


```{c}
auto imageOpsItem = new ImageOpsContextManagerItem(mContextManager, q);
```

#### AUTO 


```{c}
auto content = new QWidget;
```

#### RANGE FOR STATEMENT 


```{c}
for (Row *row : qAsConst(mRows)) {
            height += row->heightForWidth(w);
        }
```

#### AUTO 


```{c}
auto *event = static_cast<QKeyEvent *>(ev);
```

#### AUTO 


```{c}
auto *sortActionMenu = view->add<KActionMenu>("sort_by");
```

#### AUTO 


```{c}
auto op = new TransformImageOperation(ROT_90);
```

#### RANGE FOR STATEMENT 


```{c}
for (DocumentView* view : currentViews) {
        slotFadeInFinished(view);
    }
```

#### AUTO 


```{c}
auto statusBarContainerLayout = new QHBoxLayout(mStatusBarContainer);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QUrl &urlReady) {
        setCurrentDirUrl(urlReady.adjusted(QUrl::RemoveFilename));
    }
```

#### AUTO 


```{c}
const auto dpr = q->devicePixelRatio();
```

#### AUTO 


```{c}
auto* inButton = new QPushButton(this);
```

#### AUTO 


```{c}
const auto supported = QImageReader::supportedMimeTypes();
```

#### RANGE FOR STATEMENT 


```{c}
for (const KIPI::ImageCollection & collection : list) {
        auto* item = new QListWidgetItem(d->mListWidget);
        QString name = collection.name();
        int imageCount = collection.images().size();
        QString title = i18ncp("%1 is collection name, %2 is image count in collection",
                               "%1 (%2 image)", "%1 (%2 images)", name, imageCount);

        item->setText(title);
        item->setData(Qt::UserRole, name);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](){
        d->mView->setBackgroundColorMode(BackgroundColorWidget::Auto);
        qApp->paletteChanged(qApp->palette());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SemanticInfoTag &tag : set) {
        QString label = d->mBackEnd->labelForTag(tag);
        QStandardItem *item = createItem(tag, label, TagModel::FullyAssigned);
        appendRow(item);
    }
```

#### AUTO 


```{c}
auto container = new SlideContainer(this);
```

#### AUTO 


```{c}
auto *dest = (inmem_dest_mgr *)(cinfo->dest);
```

#### AUTO 


```{c}
auto hudContent = new QGraphicsWidget;
```

#### RANGE FOR STATEMENT 


```{c}
for (auto item : itemList) {
            QRect itemRect = item->geometry();
            // Center lines horizontally if flag AlignHCenter is set
            if (alignment() & Qt::AlignHCenter) {
                if (widthForY.contains(itemRect.y())) {
                    const int offset = (contentWidth - widthForY[itemRect.y()]) / 2;
                    itemRect.translate(offset, 0);
                }
            }
            // Center items vertically if flag AlignVCenter is set
            if (alignment() & Qt::AlignVCenter) {
                const int offset = (lineHeight - itemRect.height()) / 2;
                itemRect.translate(0, offset);
            }
            item->setGeometry(itemRect);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem & item : itemList) {
        QModelIndex index = dirModel->indexForItem(item);
        TagSet tags = TagSet::fromVariant(dirModel->data(index, SemanticInfoDirModel::TagsRole));
        if (tags.contains(tag)) {
            tags.remove(tag);
            dirModel->setData(index, tags.toVariant(), SemanticInfoDirModel::TagsRole);
        }
    }
```

#### AUTO 


```{c}
auto button = new HudButton();
```

#### AUTO 


```{c}
auto *content = new QGraphicsWidget;
```

#### AUTO 


```{c}
auto* JPEGQualityChooserSpinBox = new QSpinBox;
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->mImageItem->updateCache();
    }
```

#### AUTO 


```{c}
auto layout = static_cast<QVBoxLayout *>(mSaveBarWidget->layout());
```

#### AUTO 


```{c}
auto *sortModel = new QSortFilterProxyModel(q);
```

#### AUTO 


```{c}
auto edit = qobject_cast<QLineEdit *>(ratioComboBox->lineEdit());
```

#### RANGE FOR STATEMENT 


```{c}
for (auto button : {autoButton, lightButton, neutralButton, darkButton}) {
        button->setToolButtonStyle(Qt::ToolButtonIconOnly);
        button->setCheckable(true);
        buttonGroup->addButton(button);
        hBoxLayout->addWidget(button);
    }
```

#### AUTO 


```{c}
auto *move = new QPropertyAnimation(mToolTip, "geometry");
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        KFileWidget *fileWidget = dialog->fileWidget();

        const QList<QUrl> files = fileWidget->selectedUrls();
        if (files.isEmpty()) {
            return;
        }

        const QString filename = files.at(0).fileName();

        const QMimeType mimeType = QMimeDatabase().mimeTypeForFile(filename, QMimeDatabase::MatchExtension);
        QByteArray format;
        if (mimeType.isValid()) {
            format = mimeType.preferredSuffix().toLocal8Bit();
        } else {
            KMessageBox::sorry(d->mMainWindow, i18nc("@info", "Gwenview cannot save images as %1.", QFileInfo(filename).suffix()));
        }

        QUrl saveAsUrl = fileWidget->selectedUrls().constFirst();

        if (format == "jpg") {
            // Gwenview code assumes JPEG images have "jpeg" format, so if the
            // dialog returned the format "jpg", use "jpeg" instead
            // This does not affect the actual filename extension
            format = "jpeg";
        }

        // Start save
        Document::Ptr doc = DocumentFactory::instance()->load(url);
        KJob *job = doc->save(saveAsUrl, format);
        if (!job) {
            const QString saveName = saveAsUrl.fileName();
            const QString name = !saveName.isEmpty() ? saveName : saveAsUrl.toDisplayString();
            const QString msg = xi18nc("@info", "<emphasis strong='true'>Saving <filename>%1</filename> failed:</emphasis><nl />%2", name, doc->errorString());
            KMessageBox::sorry(QApplication::activeWindow(), msg);
        } else {
            // Regardless of job result, reset JPEG config value if it was changed by
            // the Save As dialog
            connect(job, &KJob::result, this, [=]() {
                if (GwenviewConfig::jPEGQuality() != d->configFileJPEGQualityValue) {
                    GwenviewConfig::setJPEGQuality(d->configFileJPEGQualityValue);
                }
            });

            connect(job, &KJob::result, this, &GvCore::slotSaveResult);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (DocumentView *view : currentViews) {
        slotFadeInFinished(view);
    }
```

#### AUTO 


```{c}
auto *mimeData = new QMimeData;
```

#### AUTO 


```{c}
auto *container = new QWidget;
```

#### LAMBDA EXPRESSION 


```{c}
[=](const QString &filter) {
            JPEGQualityChooserWidget->setVisible(filter.contains(QLatin1String("jpeg")) || filter.contains(QLatin1String("jxl"))
                                                 || filter.contains(QLatin1String("webp")) || filter.contains(QLatin1String("avif"))
                                                 || filter.contains(QLatin1String("heif")) || filter.contains(QLatin1String("heic")));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (DocumentView *view : d->mViews | d->mAddedViews) {
        view->setPalette(palette);
    }
```

#### AUTO 


```{c}
auto *infoItem = new InfoContextManagerItem(mContextManager);
```

#### AUTO 


```{c}
auto *file = new KActionCategory(i18nc("@title actions category", "File"), actionCollection);
```

#### AUTO 


```{c}
auto floater = new GraphicsWidgetFloater(view);
```

#### AUTO 


```{c}
auto *layout = new QVBoxLayout(content);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &item : itemList) {
        // If we are removing the next item, update to be the item after or the
        // first if we removed the last item
        mItems.removeAll(item);

        if (item == mCurrentItem) {
            abortSubjob();
        }
    }
```

#### AUTO 


```{c}
auto drag = new QDrag(this);
```

#### AUTO 


```{c}
auto *job = new Baloo::TagListJob();
```

#### AUTO 


```{c}
auto* layout = new QHBoxLayout(mContent);
```

#### AUTO 


```{c}
auto *textLabel = new QLabel;
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &item : itemList) {
        if (item.isDir()) {
            folderCount++;
        } else {
            fileCount++;
        }
    }
```

#### AUTO 


```{c}
auto* op = new TransformImageOperation(ROT_270);
```

#### LAMBDA EXPRESSION 


```{c}
[this, doc](QPrinter *printer) {
        d->print(printer, doc, false);
    }
```

#### AUTO 


```{c}
auto* label = new QLabel(this);
```

#### AUTO 


```{c}
auto keyEvent = static_cast<QKeyEvent *>(event);
```

#### AUTO 


```{c}
auto* file = new KActionCategory(i18nc("@title actions category", "File"), actionCollection);
```

#### AUTO 


```{c}
auto dialog = new QFileDialog(parent->nativeParentWidget(), QString());
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {

        // gwenview -s %u
        auto job = new KIO::CommandLauncherJob(QStringLiteral("gwenview"), QStringList("-s") << itemsForSlideShow);
        job->setDesktopName("org.kde.gwenview");
        job->setUiDelegate(new KNotificationJobUiDelegate(KJobUiDelegate::AutoHandlingEnabled));

        job->start();
    }
```

#### AUTO 


```{c}
auto *anim = new QParallelAnimationGroup();
```

#### AUTO 


```{c}
auto *watcher = new DBusBoolReplyWatcher(this);
```

#### AUTO 


```{c}
auto* layout = new QVBoxLayout(content);
```

#### AUTO 


```{c}
auto menu = new QMenu;
```

#### AUTO 


```{c}
auto* anim = new QSequentialAnimationGroup();
```

#### AUTO 


```{c}
auto *viewMainPageLayout = new QVBoxLayout(q);
```

#### AUTO 


```{c}
auto buttonBox = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &parentMimeType : allAncestors) {
            protocol = KProtocolManager::protocolForArchiveMimetype(parentMimeType);
            if (!protocol.isEmpty()) {
                break;
            }
        }
```

#### AUTO 


```{c}
auto* button = new QPushButton;
```

#### LAMBDA EXPRESSION 


```{c}
[dialog, url, deviceUdi]() { dialog->setSourceUrl(url, deviceUdi); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &rawMimetype : rawMimeTypes()) {
            const auto resolved = resolveAlias(rawMimetype);
            if (resolved.isEmpty()) {
                qCWarning(GWENVIEW_LIB_LOG) << "Unresolved raw mime type " << rawMimetype;
            } else {
                list << resolved;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &pathPart : relativePathList) {
        bool found = false;
        for (int row = 0; row < mModel->rowCount(lastFoundIndex); ++row) {
            QModelIndex index = mModel->index(row, 0, lastFoundIndex);
            if (index.data().toString() == pathPart) {
                // FIXME: Check encoding
                found = true;
                lastFoundIndex = index;
                break;
            }
        }
        if (!found) {
            break;
        }
    }
```

#### AUTO 


```{c}
auto floater = new GraphicsWidgetFloater(this);
```

#### AUTO 


```{c}
auto *JPEGQualityChooserLayout = new QHBoxLayout(JPEGQualityChooserWidget);
```

#### RANGE FOR STATEMENT 


```{c}
for (HudButton* button : qAsConst(mButtonList)) {
            minWidth = qMax(minWidth, button->preferredWidth());
        }
```

#### AUTO 


```{c}
auto *playPauseButton = new HudButton;
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            q->guiFactory()->refreshActionProperties();
        }
```

#### AUTO 


```{c}
auto *job = qobject_cast<DownSamplingJob *>(*it);
```

#### LAMBDA EXPRESSION 


```{c}
[this](){
            this->updateHamburgerMenu();
            // Immediately disconnect. We only need to run this once, but on demand.
            // NOTE: The nullptr at the end disconnects all connections between
            // q and mHamburgerMenu's aboutToShowMenu signal.
            disconnect(mHamburgerMenu, &KHamburgerMenu::aboutToShowMenu, q, nullptr);
        }
```

#### AUTO 


```{c}
auto *pluginsMenu = static_cast<QMenu *>(guiFactory()->container("plugins", this));
```

#### AUTO 


```{c}
auto alignWithSideBarWidgetAction = new AlignWithSideBarWidgetAction(q);
```

#### AUTO 


```{c}
auto watcher = new EventWatcher(watched, QList<QEvent::Type>() << eventType);
```

#### AUTO 


```{c}
auto* proxy = new QGraphicsProxyWidget;
```

#### AUTO 


```{c}
auto layout = new QHBoxLayout(this);
```

#### AUTO 


```{c}
auto *menu = static_cast<QMenu *>(q->menu());
```

#### AUTO 


```{c}
auto ratingMenu = static_cast<QMenu *>(guiFactory()->container("rating", this));
```

#### AUTO 


```{c}
auto flowLayout = new FlowLayout(cropWidget, 6, 0);
```

#### AUTO 


```{c}
auto* job = static_cast<KIO::CopyJob*>(_job);
```

#### AUTO 


```{c}
auto layout = new QHBoxLayout(mTooManyChangesFrame);
```

#### AUTO 


```{c}
auto layout = new QHBoxLayout(d->mContextBar);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl & src : qAsConst(list)) {
        QUrl dst = localUrl;
        dst.setPath(dst.path() + '/' + src.fileName());
        QVERIFY(FileUtils::contentsAreIdentical(src, dst));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &item : itemList) {
        QModelIndex index = dirModel->indexForItem(item);
        TagSet tags = TagSet::fromVariant(dirModel->data(index, SemanticInfoDirModel::TagsRole));
        if (tags.contains(tag)) {
            tags.remove(tag);
            dirModel->setData(index, tags.toVariant(), SemanticInfoDirModel::TagsRole);
        }
    }
```

#### AUTO 


```{c}
auto* rowLayout = new QHBoxLayout(d->mTopRowWidget);
```

#### AUTO 


```{c}
auto* watcher = new EventWatcher(watched, eventTypes);
```

#### AUTO 


```{c}
auto sortModel = new QSortFilterProxyModel(this);
```

#### AUTO 


```{c}
auto* thumbnailDetailsAction = view->add<KActionMenu>("thumbnail_details");
```

#### AUTO 


```{c}
auto *horizontalSpacer = new QSpacerItem(1, 1, QSizePolicy::Expanding, QSizePolicy::Fixed);
```

#### AUTO 


```{c}
const auto destinationRect = QRect{
        // Ceil the top left corner to avoid pixel alignment issues on higher DPI
        QPoint{int(std::ceil(imageRect.left() * zoom)), int(std::ceil(imageRect.top() * zoom))},
        image.size()
    };
```

#### AUTO 


```{c}
auto clearAction = mFileOpenRecentAction->menu()->findChild<QAction *>("clear_action");
```

#### AUTO 


```{c}
auto it = findDateTimeKey(exifData);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QGraphicsView* view : views) {
                if (view->underMouse()) {
                    return q->mapFromScene(view->mapFromGlobal(QCursor::pos()));
                }
            }
```

#### AUTO 


```{c}
auto *hLayout = new QHBoxLayout(mInformationContainer);
```

#### AUTO 


```{c}
auto *anim = new QSequentialAnimationGroup();
```

#### AUTO 


```{c}
auto* action = new QAction(parent);
```

#### AUTO 


```{c}
auto* widget = qobject_cast<QGraphicsWidget*>(d->mTarget);
```

#### AUTO 


```{c}
auto* dest = (inmem_dest_mgr*)(cinfo->dest);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QPixmap &pix : pixmaps) {
        QPixmap pix2 = pix.scaled(DRAG_THUMB_SIZE - 2, DRAG_THUMB_SIZE - 2, Qt::KeepAspectRatio, Qt::SmoothTransformation);
        QRect rect(-pix2.width() / 2, -pix2.height() - extraSpace, pix2.width(), pix2.height());

        if (!pix2.hasAlphaChannel()) {
            // Draw a thin white border around fully opaque pictures to give them a photo-like appearance
            painter.fillRect(rect.adjusted(-1, -1, 1, 1), Qt::white);
        }
        painter.drawPixmap(rect.topLeft(), pix2);

        QPoint topRight = painter.transform().map(rect.topRight());
        maxX = qMax(topRight.x(), maxX);
        /*
        painter.drawRect(-pix2.width() / 2, -pix2.height() - extraSpace, pix2.width(), pix2.height());
        painter.drawText(-pix2.width() / 2, -pix2.height() - extraSpace, pix2.width(), pix2.height(), Qt::AlignTop | Qt::AlignLeft, QString::number(index));
        index++;
        */
        painter.rotate(delta);
    }
```

#### AUTO 


```{c}
auto delegate = new PreviewItemDelegate(mThumbnailView);
```

#### RANGE FOR STATEMENT 


```{c}
for (DocumentJob * job : qAsConst(d->mJobSet)) {
        job->kill();
    }
```

#### AUTO 


```{c}
auto* folderViewItem = new FolderViewContextManagerItem(mContextManager);
```

#### RANGE FOR STATEMENT 


```{c}
for (DocumentView * view : qAsConst(d->mDocumentViews)) {
        view->loadAdapterConfig();
    }
```

#### AUTO 


```{c}
auto* layout = new QHBoxLayout(widget);
```

#### AUTO 


```{c}
auto screenLockServiceWatcher = new QDBusServiceWatcher(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (DocumentView *view : qAsConst(*d->mViews)) {
        if (view == d->mCurrentView.data()) {
            continue;
        }
        view->setPosition(view->position() + delta);
    }
```

#### AUTO 


```{c}
auto timer = new QTimer(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &key : fullScreenPreferredMetaInfoKeyList) {
        const QString value = model->getValueForKey(key);
        if (!value.isEmpty()) {
            valueList << value;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl& url : mFileOpenRecentActionUrls) {
            d->mGvCore->addUrlToRecentFiles(url);
        }
```

#### AUTO 


```{c}
auto layout = new QVBoxLayout(mUrlNavigatorContainer);
```

#### AUTO 


```{c}
auto* watcher = new QFutureWatcher<void>(this);
```

#### AUTO 


```{c}
auto action = static_cast<QAction *>(object);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &mime: supported) {
            list << resolveAlias(QString::fromUtf8(mime));
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->updateToggleSelectionButton();
    }
```

#### AUTO 


```{c}
auto tap = static_cast<QTapGesture *>(event->gesture(Qt::TapGesture))
```

#### RANGE FOR STATEMENT 


```{c}
for (const KIPI::ImageCollection &collection : list) {
            if (collection.name() == name) {
                selectedList << collection;
                break;
            }
        }
```

#### AUTO 


```{c}
auto *op = new RedEyeReductionImageOperation(docRectF);
```

#### AUTO 


```{c}
auto *watcher = dynamic_cast<DBusBoolReplyWatcher*>(sender());
```

#### LAMBDA EXPRESSION 


```{c}
[this, id]() {
        d->mEventLoop->exit(id);
    }
```

#### AUTO 


```{c}
auto anim = new QParallelAnimationGroup();
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : actionList) {
            menu->addAction(action);
        }
```

#### AUTO 


```{c}
auto* button = qobject_cast<QToolButton*>(object);
```

#### AUTO 


```{c}
auto *dialog = new QFileDialog(parent->nativeParentWidget(), QString());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& name : entryList) {
        QImage thumb;
        QVERIFY(thumb.load(thumbnailDir.filePath(name)));

        QUrl url(thumb.text("Thumb::URI"));
        KFileItem item = list.findByUrl(url);
        QVERIFY(!item.isNull());

        QSize originalSize = mSandBox.mSizeHash.value(item.url().fileName());
        uint mtime = item.time(KFileItem::ModificationTime).toTime_t();

        if (mtime == uint(-1)) {
            // This happens from time to time on build.kde.org, but I haven't
            // been able to reproduce it locally, so let's try to gather more
            // information.
            qWarning() << "mtime == -1 for url" << url << ". This should not happen!";
            qWarning() << "errno:" << errno << "message:" << strerror(errno);
            qWarning() << "QFile::exists(" << url.toLocalFile() << "):" << QFile::exists(url.toLocalFile());
            qWarning() << "Recalculating mtime" << item.time(KFileItem::ModificationTime).toTime_t();
            QFAIL("Invalid time for test KFileItem");
        }

        QCOMPARE(thumb.text("Thumb::Image::Width"), QString::number(originalSize.width()));
        QCOMPARE(thumb.text("Thumb::Image::Height"), QString::number(originalSize.height()));
        QCOMPARE(thumb.text("Thumb::Mimetype"), item.mimetype());
        QCOMPARE(thumb.text("Thumb::Size"), QString::number(item.size()));
        QCOMPARE(thumb.text("Thumb::MTime"), QString::number(mtime));
    }
```

#### AUTO 


```{c}
auto *op = new TransformImageOperation(orientation);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : list) {
            Document::Ptr doc = DocumentFactory::instance()->load(url);
            memoryUsage += doc->memoryUsage();
        }
```

#### AUTO 


```{c}
auto button = new QPushButton;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QFileInfo & info : entryInfoList) {
        QUrl url("file://" + info.absoluteFilePath());
        KFileItem item(url);
        list << item;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction * action : qAsConst(mActions)) {
            action->setEnabled(enabled);
        }
```

#### AUTO 


```{c}
const auto transformationMode = zoom < 1.0 ? Qt::SmoothTransformation : Qt::FastTransformation;
```

#### AUTO 


```{c}
auto* playPauseButton = new HudButton;
```

#### AUTO 


```{c}
auto content = new QWidget(this);
```

#### AUTO 


```{c}
auto* evt = new QMouseEvent(type, pos, button, buttons, Qt::NoModifier);
```

#### AUTO 


```{c}
auto sortModel = new QSortFilterProxyModel(q);
```

#### AUTO 


```{c}
const auto &mime
```

#### AUTO 


```{c}
auto *sortModel = new QSortFilterProxyModel(this);
```

#### AUTO 


```{c}
auto* op = new TransformImageOperation(ROT_90);
```

#### AUTO 


```{c}
auto* content = new QGraphicsWidget();
```

#### AUTO 


```{c}
auto *ke = static_cast<QKeyEvent *>(event);
```

#### LAMBDA EXPRESSION 


```{c}
[this, tool]() {
            this->d->mCropStateRect->setTopLeft(tool->rect().topLeft());
            this->d->mCropStateRect->setSize(tool->rect().size());
            this->restoreDefaultImageViewTool();
        }
```

#### AUTO 


```{c}
auto* action = static_cast<QAction*>(object);
```

#### AUTO 


```{c}
auto *layout = new QGraphicsLinearLayout(this);
```

#### AUTO 


```{c}
auto button
```

#### AUTO 


```{c}
auto *dialog = new Gwenview::ImportDialog();
```

#### AUTO 


```{c}
auto kindProxyModel = new KindProxyModel(q);
```

#### AUTO 


```{c}
auto *iconEffect = new QGraphicsOpacityEffect(mPlaceHolderIconLabel);
```

#### LAMBDA EXPRESSION 


```{c}
[=](const QString &filter) {
            JPEGQualityChooserWidget->setVisible(filter.contains(QLatin1String("jpeg")) ||
                                                 filter.contains(QLatin1String("jxl"))  ||
                                                 filter.contains(QLatin1String("webp")) ||
                                                 filter.contains(QLatin1String("avif")) ||
                                                 filter.contains(QLatin1String("heif")) ||
                                                 filter.contains(QLatin1String("heic")) );
        }
```

#### AUTO 


```{c}
auto* content = new QGraphicsWidget;
```

#### RANGE FOR STATEMENT 


```{c}
for (const ImageInfo & info : qAsConst(mImageInfoList)) {
            int right = info.left + info.image.width();
            int bottom = info.top + info.image.height();
            imageWidth = qMax(imageWidth, right);
            imageHeight = qMax(imageHeight, bottom);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : qAsConst(mActions)) {
            action->setEnabled(enabled);
        }
```

#### AUTO 


```{c}
const auto urls = KUrlMimeData::urlsFromMimeData(event->mimeData());
```

#### AUTO 


```{c}
auto *edit = qobject_cast<ItemEditor *>(widget);
```

#### AUTO 


```{c}
auto* assignToAllButton = new QToolButton;
```

#### RANGE FOR STATEMENT 


```{c}
for (const AbstractSortedDirModelFilter *filter : qAsConst(d->mFilters)) {
            if (!filter->acceptsIndex(index)) {
                return false;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction * action : qAsConst(d->mActions)) {
            disconnect(action, nullptr, d->mView, nullptr);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &item : itemList) {
        QModelIndex index = dirModel->indexForItem(item);
        dirModel->setData(index, rating, SemanticInfoDirModel::RatingRole);
    }
```

#### AUTO 


```{c}
auto *lockScreenWatcher = new LockScreenWatcher(this);
```

#### AUTO 


```{c}
auto* action = new QWidgetAction(&menu);
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
            mToggleOperationsSideBarAction->setChecked(mSideBar->isVisible() && mSideBar->currentPage() == QLatin1String("operations"));
        }
```

#### AUTO 


```{c}
auto outButton = new QPushButton(this);
```

#### AUTO 


```{c}
auto *data = new KAboutData(appName, programName, QStringLiteral(GWENVIEW_VERSION_STRING));
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem & item : items) {
            if (!itemSet.contains(item)) {
                mItems.append(item);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto widget : widgets) {
        static_cast<AligningSpacer *>(widget)->setSideBar(sideBar);
    }
```

#### AUTO 


```{c}
auto* edit = qobject_cast<ItemEditor*>(widget);
```

#### AUTO 


```{c}
auto button = qobject_cast<QToolButton *>(object);
```

#### RANGE FOR STATEMENT 


```{c}
for (Row *row : qAsConst(mRows)) {
            rowY = row->setLabelGeometries(rowY, labelWidth);
        }
```

#### AUTO 


```{c}
auto* dirModel = static_cast<SortedDirModel*>(sender());
```

#### AUTO 


```{c}
auto *button = new QToolButton;
```

#### AUTO 


```{c}
auto* job = qobject_cast<DownSamplingJob*>(*it);
```

#### AUTO 


```{c}
auto fadeIn = new QPropertyAnimation(mToolTip, "opacity");
```

#### AUTO 


```{c}
auto *action = new QAction(parent);
```

#### AUTO 


```{c}
auto op = new TransformImageOperation(ROT_270);
```

#### LAMBDA EXPRESSION 


```{c}
[&](){
                QDesktopServices::openUrl(QUrl(KIPI_PLUGINS_URL));
                d->mPluginWatcher.addPaths(QCoreApplication::libraryPaths());
                connect(&d->mPluginWatcher, &QFileSystemWatcher::directoryChanged, this, &KIPIInterface::packageFinished);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Exiv2::ExifKey& key : lst) {
        it = exifData.findKey(key);
        if (it != end) {
            return it;
        }
    }
```

#### AUTO 


```{c}
auto* doc = new Document(url);
```

#### AUTO 


```{c}
auto *optionsPage = new PrintOptionsPage(docSize);
```

#### AUTO 


```{c}
auto moreLabel = new QLabel(mOneFileWidget);
```

#### AUTO 


```{c}
auto item = new HistoryItem(url, dateTime, file.fileName());
```

#### LAMBDA EXPRESSION 


```{c}
[=](const QString &filter) {
            JPEGQualityChooserWidget->setVisible(filter.contains(QStringLiteral("jpeg")));
        }
```

#### AUTO 


```{c}
auto* item = new QStandardItem(label);
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction * action : actions) {
            KIPI::Category category = plugin->category(action);

            if (!d->mMenuInfoMap.contains(category)) {
                qCWarning(GWENVIEW_APP_LOG) << "Unknown category '" << category;
                continue;
            }

            d->mMenuInfoMap[category].mActions << action;
        }
```

#### AUTO 


```{c}
auto *assignToAllButton = static_cast<QToolButton *>(widgets[1]);
```

#### AUTO 


```{c}
auto *op = new TransformImageOperation(VFLIP);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QUrl &, const QUrl &newUrl) {
        slotDirListerRedirection(newUrl);
    }
```

#### AUTO 


```{c}
auto *item = new QStandardItem(label);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString & tag : tagSet) {
            TagHash::Iterator it = tagHash.find(tag);
            if (it == tagHash.end()) {
                tagHash[tag] = 1;
            } else {
                ++it.value();
            }
        }
```

#### AUTO 


```{c}
auto *outButton = new QPushButton(this);
```

#### AUTO 


```{c}
auto *edit = new KActionCategory(i18nc("@title actions category", "Edit"), mActionCollection);
```

#### AUTO 


```{c}
auto* tap = static_cast<QTapGesture*>(event->gesture(Qt::TapGesture))
```

#### AUTO 


```{c}
auto *container = new FilterWidgetContainer;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &label : labels) {
            auto decoratedTag = new DecoratedTag(label);
            mTagLayout->addWidget(decoratedTag);
        }
```

#### AUTO 


```{c}
auto index
```

#### AUTO 


```{c}
auto* content = new QWidget;
```

#### LAMBDA EXPRESSION 


```{c}
[this, urlList, destUrl]() {
            showMenuForDroppedUrls(urlList, destUrl);
        }
```

#### AUTO 


```{c}
auto historyItem = static_cast<RecentFilesItem *>(item(row, 0));
```

#### AUTO 


```{c}
auto mimeData = new QMimeData;
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool checked) {
        if (checked) {
            d->mView->setZoom(1.0);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : allUrls) {
        viewForUrlMap[url]->setSortKey(sortKey);
        ++sortKey;
    }
```

#### AUTO 


```{c}
auto *separator = new QFrame;
```

#### AUTO 


```{c}
const auto separatorWidth = static_cast<float>(
            style()->pixelMetric(QStyle::PM_ToolBarSeparatorExtent, nullptr, this));
```

#### AUTO 


```{c}
auto* delegate = new PreviewItemDelegate(view);
```

#### RANGE FOR STATEMENT 


```{c}
for (DocumentView* view : qAsConst(*d->mViews)) {
        if (view == d->mCurrentView.data()) {
            continue;
        }
        view->setPosition(view->position() + delta);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](const QString &filter) {
            JPEGQualityChooserWidget->setVisible(filter.contains(QLatin1String("jpeg")) ||
                                                 filter.contains(QLatin1String("webp")) ||
                                                 filter.contains(QLatin1String("avif")) ||
                                                 filter.contains(QLatin1String("heif")) ||
                                                 filter.contains(QLatin1String("heic")) );
        }
```

#### AUTO 


```{c}
auto linkPathList = linkAddress.split(QLatin1Char('/'));
```

#### AUTO 


```{c}
auto dirModel = static_cast<SortedDirModel *>(sender());
```

#### AUTO 


```{c}
auto action = itemData.value<QAction *>();
```

#### LAMBDA EXPRESSION 


```{c}
[this](){ d->setupPalettes(); }
```

#### AUTO 


```{c}
auto file = new KActionCategory(i18nc("@title actions category", "File"), actionCollection);
```

#### AUTO 


```{c}
auto *job = static_cast<KIO::CopyJob *>(_job);
```

#### AUTO 


```{c}
auto* layout = new QHBoxLayout(d->mContextBar);
```

#### AUTO 


```{c}
auto* drag = new QDrag(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (DocumentView* view : qAsConst(d->mRemovedViews)) {
            view->deleteLater();
        }
```

#### AUTO 


```{c}
auto* kindProxyModel = new KindProxyModel(q);
```

#### RANGE FOR STATEMENT 


```{c}
for (QLayoutItem *item : qAsConst(itemList)) {
        const bool itemIsSpacer = item->spacerItem() != nullptr;
        // Don't add invisible items or succeeding spacer items
        if (item->sizeHint().width() == 0 || (itemIsSpacer && lastItemIsSpacer)) {
            continue;
        }

        int nextX = x + item->sizeHint().width() + horizontalSpacing();
        if (nextX - horizontalSpacing() > rect.right() - getMargin() && lineHeight > 0) {
            x = left;
            y = y + lineHeight + verticalSpacing();
            nextX = x + item->sizeHint().width() + horizontalSpacing();
            lineHeight = 0;
        }

        // Don't place spacer items at start of line
        if (itemIsSpacer && x == left) {
            continue;
        }

        if (!testOnly)
            item->setGeometry(QRect(QPoint(x, y), item->sizeHint()));

        x = nextX;
        // Don't add spacer items at end of line
        if (!itemIsSpacer) {
            widthForY[y] = x - getMargin();
        }
        lineHeight = qMax(lineHeight, item->sizeHint().height());
        lastItemIsSpacer = itemIsSpacer;
    }
```

#### AUTO 


```{c}
auto anim = new QSequentialAnimationGroup();
```

#### AUTO 


```{c}
auto mainWindow = static_cast<MainWindow *>(parent());
```

#### AUTO 


```{c}
auto containerLayout = new QVBoxLayout(d->mContainer);
```

#### AUTO 


```{c}
auto op = new TransformImageOperation(HFLIP);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : mFileOpenRecentActionUrls) {
            d->mGvCore->addUrlToRecentFiles(url);
        }
```

#### AUTO 


```{c}
auto *job = static_cast<DocumentJob *>(_job);
```

#### AUTO 


```{c}
auto *layout = new QVBoxLayout(q);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &src : qAsConst(list)) {
        QUrl dst = remoteUrl;
        dst.setPath(dst.path() + '/' + src.fileName());
        QVERIFY(FileUtils::contentsAreIdentical(src, dst));
    }
```

#### AUTO 


```{c}
auto *mappedFile = reinterpret_cast<unsigned char *>(d->mRawData.data());
```

#### AUTO 


```{c}
auto* menu = new QMenu;
```

#### AUTO 


```{c}
const auto resolved = resolveAlias(QString::fromUtf8(mime));
```

#### RANGE FOR STATEMENT 


```{c}
for (const AbstractSortedDirModelFilter * filter : qAsConst(d->mFilters)) {
            if (!filter->acceptsIndex(index)) {
                return false;
            }
        }
```

#### AUTO 


```{c}
auto *fadeOut = new QPropertyAnimation(mToolTip, "opacity");
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction * action : qAsConst(list)) {
        if (action->isEnabled() && !action->isSeparator()) {
            mGroup->addAction(action);
        }
    }
```

#### AUTO 


```{c}
auto* delegate = new TagItemDelegate(mListView);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& tag : tags) {
        d->mAllTags << tag;
    }
```

#### AUTO 


```{c}
auto* job = new LoadingJob;
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &item : newList) {
        if (item.isFile()) {
            if (d->rowForUrl(item.url()) == -1) {
                fileList << item;
            }
        } else {
            dirUrls << item.url();
        }
    }
```

#### AUTO 


```{c}
auto *effect = new QGraphicsOpacityEffect(mPlaceHolderLabel);
```

#### AUTO 


```{c}
auto saveJob = static_cast<SaveJob *>(job);
```

#### AUTO 


```{c}
auto* button = new HudButton;
```

#### AUTO 


```{c}
auto *layout = static_cast<QVBoxLayout *>(mSaveBarWidget->layout());
```

#### AUTO 


```{c}
auto dialog = new RenameDialog(parent);
```

#### AUTO 


```{c}
auto hLayout = new QHBoxLayout;
```

#### AUTO 


```{c}
auto watcher = dynamic_cast<DBusBoolReplyWatcher *>(sender());
```

#### RANGE FOR STATEMENT 


```{c}
for (DocumentView *view : qAsConst(views)) {
            QRect rect;
            rect.setLeft(col * viewWidth);
            rect.setTop(row * viewHeight);
            rect.setWidth(viewWidth);
            rect.setHeight(viewHeight);

            if (animated) {
                if (d->mViews.contains(view)) {
                    if (rect != view->geometry()) {
                        if (d->mAddedViews.isEmpty() && d->mRemovedViews.isEmpty()) {
                            // View moves because of a resize
                            view->moveTo(rect);
                        } else {
                            // View moves because the number of views changed,
                            // animate the change
                            view->moveToAnimated(rect);
                        }
                    }
                } else {
                    view->setGeometry(rect);
                    view->fadeIn();
                }
            } else {
                // Not animated, set final geometry and opacity now
                view->setGeometry(rect);
                view->setGraphicsEffectOpacity(1);
            }

            ++col;
            if (col == colCount) {
                col = 0;
                ++row;
            }
        }
```

#### AUTO 


```{c}
auto *thumbnailDetailsAction = view->add<KActionMenu>("thumbnail_details");
```

#### AUTO 


```{c}
auto thumbnailDetailsAction = view->add<KActionMenu>("thumbnail_details");
```

#### AUTO 


```{c}
auto widgetTarget = qobject_cast<QGraphicsWidget *>(target);
```

#### AUTO 


```{c}
auto* src = static_cast<IODeviceJpegSourceManager*>(cinfo->src);
```

#### AUTO 


```{c}
auto bottomRowLayout = new QHBoxLayout;
```

#### AUTO 


```{c}
auto* hLayout = new QHBoxLayout(mInformationContainer);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &name : entryList) {
        QImage thumb;
        QVERIFY(thumb.load(thumbnailDir.filePath(name)));

        QUrl url(thumb.text("Thumb::URI"));
        KFileItem item = list.findByUrl(url);
        QVERIFY(!item.isNull());

        QSize originalSize = mSandBox.mSizeHash.value(item.url().fileName());
        uint mtime = item.time(KFileItem::ModificationTime).toSecsSinceEpoch();

        if (mtime == uint(-1)) {
            // This happens from time to time on build.kde.org, but I haven't
            // been able to reproduce it locally, so let's try to gather more
            // information.
            qWarning() << "mtime == -1 for url" << url << ". This should not happen!";
            qWarning() << "errno:" << errno << "message:" << strerror(errno);
            qWarning() << "QFile::exists(" << url.toLocalFile() << "):" << QFile::exists(url.toLocalFile());
            qWarning() << "Recalculating mtime" << item.time(KFileItem::ModificationTime).toSecsSinceEpoch();
            QFAIL("Invalid time for test KFileItem");
        }

        QCOMPARE(thumb.text("Thumb::Image::Width"), QString::number(originalSize.width()));
        QCOMPARE(thumb.text("Thumb::Image::Height"), QString::number(originalSize.height()));
        QCOMPARE(thumb.text("Thumb::Mimetype"), item.mimetype());
        QCOMPARE(thumb.text("Thumb::Size"), QString::number(item.size()));
        QCOMPARE(thumb.text("Thumb::MTime"), QString::number(mtime));
    }
```

#### AUTO 


```{c}
auto *rowLayout = new QHBoxLayout(d->mTopRowWidget);
```

#### AUTO 


```{c}
auto proxy = new QGraphicsProxyWidget;
```

#### AUTO 


```{c}
auto actionGroup = new QActionGroup(q);
```

#### AUTO 


```{c}
auto *dialog = new KFileCustomDialog(mMainWindow);
```

#### AUTO 


```{c}
auto configureMenu = new QMenu(i18nc("@title:menu submenu for actions that open configuration dialogs", "Configure"));
```

#### AUTO 


```{c}
auto *imageOpsItem = new ImageOpsContextManagerItem(mContextManager, q);
```

#### AUTO 


```{c}
auto adapter = new MessageViewAdapter;
```

#### AUTO 


```{c}
const auto itemList = KFileItemList({q->document()->url()});
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &item : itemList) {
        QModelIndex index = dirModel->indexForItem(item);

        QVariant value = dirModel->data(index, SemanticInfoDirModel::RatingRole);
        if (first) {
            rating = ratingForVariant(value);
        } else if (rating != ratingForVariant(value)) {
            // Ratings aren't the same, reset
            rating = 0;
        }

        QString indexDescription = index.data(SemanticInfoDirModel::DescriptionRole).toString();
        if (first) {
            description = indexDescription;
        } else if (description != indexDescription) {
            description.clear();
        }

        // Fill tagHash, incrementing the tag count if it's already there
        const TagSet tagSet = TagSet::fromVariant(index.data(SemanticInfoDirModel::TagsRole));
        for (const QString &tag : tagSet) {
            TagHash::Iterator it = tagHash.find(tag);
            if (it == tagHash.end()) {
                tagHash[tag] = 1;
            } else {
                ++it.value();
            }
        }

        first = false;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &dirItem : fileItems) {
                QDir dir = QDir(dirItem.localPath());
                const QStringList fileList = dir.entryList(QDir::Filter::Files);
                const bool containsAtLeastAnImage = std::any_of(fileList.cbegin(), fileList.cend(), [&db, &dir](const QString &fileName) {
                    const auto mimeType = db.mimeTypeForFile(dir.absoluteFilePath(fileName), QMimeDatabase::MatchExtension);
                    return mimeType.name().startsWith(QStringLiteral("image"));
                });
                if (containsAtLeastAnImage) {
                    itemsForSlideShow << dirItem.localPath();
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (DocumentView *view : qAsConst(*d->mViews)) {
        if (view == d->mCurrentView.data()) {
            continue;
        }
        view->setZoomToFill(fit);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const ImageInfo & info : qAsConst(mImageInfoList)) {
            painter.drawImage(info.left, info.top, info.image);
        }
```

#### AUTO 


```{c}
auto *layout = new QGraphicsLinearLayout(hudContent);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &name : rcFilesList) {
            HistoryItem *item = HistoryItem::load(dir.filePath(name));
            if (!item) {
                continue;
            }

            QUrl itemUrl = item->url();
            if (UrlUtils::urlIsFastLocalFile(itemUrl)) {
                if (!QFile::exists(itemUrl.path())) {
                    qCDebug(GWENVIEW_LIB_LOG) << "Removing" << itemUrl.path() << "from recent folders. It does not exist anymore";
                    item->unlink();
                    delete item;
                    continue;
                }
            }

            HistoryItem *existingItem = mHistoryItemForUrl.value(item->url());
            if (existingItem) {
                // We already know this url(!) update existing item dateTime
                // and get rid of duplicate
                if (existingItem->dateTime() < item->dateTime()) {
                    existingItem->setDateTime(item->dateTime());
                }
                item->unlink();
                delete item;
            } else {
                mHistoryItemForUrl.insert(item->url(), item);
                q->appendRow(item);
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            mFileOpenRecentAction->clear();
        }
```

#### AUTO 


```{c}
auto event = static_cast<QKeyEvent *>(ev);
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction * action : actions) {
            KIPI::Category category = plugin->category(action);

            if (!d->mMenuInfoMap.contains(category)) {
                qWarning() << "Unknown category '" << category;
                continue;
            }

            d->mMenuInfoMap[category].mActions << action;
        }
```

#### AUTO 


```{c}
auto* dirModel = new KDirModel(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this](KIO::Job *job) {
        if (job->error() == KIO::Error::ERR_CANNOT_CREATE_SLAVE) {
            Q_EMIT protocollNotSupportedError();
        } else {
            job->uiDelegate()->showErrorMessage();
        }
    }
```

#### AUTO 


```{c}
auto job = new KIO::CommandLauncherJob(QStringLiteral("gwenview"), QStringList(QStringLiteral("-s")) << itemsForSlideShow);
```

#### AUTO 


```{c}
auto *mainWidget = new QWidget;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString & url : qAsConst(tmpArgs)) {
                QUrl fileUrl = QUrl::fromUserInput(url, QDir::currentPath(), QUrl::AssumeLocalFile);
                if (!fileNames.contains(fileUrl.fileName())) {
                    fileNames << fileUrl.fileName();
                    list <<fileUrl;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &item : qAsConst(d->mErrorList)) {
            msg += "<li>" + item + "</li>";
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](){
        d->mView->setBackgroundColorMode(BackgroundColorWidget::Dark);
        qApp->paletteChanged(qApp->palette());
    }
```

#### AUTO 


```{c}
auto *button = new HudButton;
```

#### AUTO 


```{c}
auto label = new QLabel(i18nc("@label:listbox", "Aspect ratio:"), box);
```

#### AUTO 


```{c}
auto *dialog = new ConfigDialog(this);
```

#### AUTO 


```{c}
auto *messageViewAdapter = qobject_cast<MessageViewAdapter *>(d->mAdapter.data());
```

#### AUTO 


```{c}
auto view = new KActionCategory(i18nc("@title actions category - means actions changing smth in interface", "View"), mActionCollection);
```

#### AUTO 


```{c}
auto *dirLister = new DirLister;
```

#### AUTO 


```{c}
auto* JPEGQualityChooserWidget = new QWidget;
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->mImageItem->updateCache(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { finish(true); }
```

#### AUTO 


```{c}
auto* keyEvent = static_cast<QKeyEvent*>(event);
```

#### AUTO 


```{c}
auto *mouseEvent = static_cast<QMouseEvent *>(event);
```

#### AUTO 


```{c}
auto *pinch = static_cast<QPinchGesture *>(event->gesture(Qt::PinchGesture))
```

#### RANGE FOR STATEMENT 


```{c}
for (HudButton* button : qAsConst(mButtonList)) {
            button->setMinimumWidth(minWidth);
        }
```

#### AUTO 


```{c}
auto job = qobject_cast<DownSamplingJob *>(mCurrentJob.data());
```

#### AUTO 


```{c}
auto sourceRect = QRect{imageRect.topLeft() * Third, imageRect.size() * Third};
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &dirName : qAsConst(mUrl1Dirs)) {
        dir.mkdir("url1/" + dirName);
    }
```

#### AUTO 


```{c}
auto inButton = new QPushButton(this);
```

#### AUTO 


```{c}
auto* pluginsMenu = static_cast<QMenu*>(guiFactory()->container("plugins", this));
```

#### AUTO 


```{c}
auto* layout = new QVBoxLayout(q);
```

#### RANGE FOR STATEMENT 


```{c}
for (DocumentView * view : qAsConst(d->mDocumentViews)) {
        view->setCompareMode(d->mCompareMode);
        if (view->url() == currentUrl) {
            d->setCurrentView(view);
        } else {
            view->setCurrent(false);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (DocumentView *view : qAsConst(d->mDocumentViews)) {
        view->loadAdapterConfig();
    }
```

#### AUTO 


```{c}
auto* optionsPage = new PrintOptionsPage(doc->size());
```

#### AUTO 


```{c}
auto* op = new TransformImageOperation(VFLIP);
```

#### AUTO 


```{c}
auto completer = new QCompleter(mTagComboBox);
```

#### AUTO 


```{c}
auto *fadeIn = new QPropertyAnimation(mToolTip, "opacity");
```

#### AUTO 


```{c}
auto* op = new CropImageOperation(d->mRect);
```

#### AUTO 


```{c}
auto infoItem = new InfoContextManagerItem(mContextManager);
```

#### AUTO 


```{c}
auto delegate = new KDialogJobUiDelegate;
```

#### AUTO 


```{c}
auto *menu = new QMenu;
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem & item : itemList) {
        // If we are removing the next item, update to be the item after or the
        // first if we removed the last item
        mItems.removeAll(item);

        if (item == mCurrentItem) {
            abortSubjob();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[scheme]() {
                const QString searchKeyword(QUrl::toPercentEncoding(i18nc("@info this text will be used as a search term in an online search engine, %1 protocol name", "How to install protocol support for \"%1\" on Linux", scheme)).constData());
                const QString searchEngineURL(i18nc("search engine URL, %1 search keyword, and translators can replace duckduckgo with other search engines", "https://duckduckgo.com/?q=%1", searchKeyword));
                QDesktopServices::openUrl(QUrl(searchEngineURL));
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto group : s_thumbnailGroups) {
        QFile::remove(generateThumbnailPath(uri, group));
    }
```

#### AUTO 


```{c}
auto ke = static_cast<QKeyEvent *>(event);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->updateZoomSnapValues();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                    finish(false);
                }
```

#### AUTO 


```{c}
auto* container = new QWidget;
```

#### RANGE FOR STATEMENT 


```{c}
for (MetaInfoGroup::Entry * entry : qAsConst(hash)) {
            group->addEntry(entry);
        }
```

#### AUTO 


```{c}
auto* action = new QAction(text, q);
```

#### AUTO 


```{c}
auto JPEGQualityChooserLayout = new QHBoxLayout(JPEGQualityChooserWidget);
```

#### AUTO 


```{c}
auto *bottomRowLayout = new QHBoxLayout;
```

#### AUTO 


```{c}
auto src = static_cast<IODeviceJpegSourceManager *>(cinfo->src);
```

#### AUTO 


```{c}
auto lockScreenWatcher = new LockScreenWatcher(this);
```

