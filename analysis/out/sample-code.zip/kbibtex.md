#### RANGE FOR STATEMENT 


```{c}
for (FieldInput *widget : fieldInputWidgetsToBeCleared)
        widget->clear();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &containedValueItem : const_cast<const Value &>(entrysValueForField)) {
                    valueItemAlreadyContained |= PlainTextValue::text(containedValueItem) == toBeAssignedValueText;
                    if (valueItemAlreadyContained) break;
                }
```

#### AUTO 


```{c}
const auto buffer = reply->readAll();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QSharedPointer<ValueItem> &vi : v) {
                        filesUrlsDoiList << PlainTextValue::text(vi);
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for (OpenFileInfo *openFileInfo : const_cast<const OpenFileInfoManager::OpenFileInfoList &>(d->openFileInfoList)) {
        /// Check only open file (ignore recently used, favorites, ...)
        if (openFileInfo->flags().testFlag(OpenFileInfo::StatusFlag::Open)) {
            if (openFileInfo->close()) {
                /// If file could be closed without user canceling the operation ...
                /// Mark file as closed (i.e. not open)
                openFileInfo->removeFlags(OpenFileInfo::StatusFlag::Open);
                /// If file has a filename, remember as recently used
                if (openFileInfo->flags().testFlag(OpenFileInfo::StatusFlag::HasName))
                    openFileInfo->addFlags(OpenFileInfo::StatusFlag::RecentlyUsed);
                /// Remember file as to be marked as open later
                restoreLaterList.append(openFileInfo);
            } else {
                /// User chose to cancel closing operation,
                /// stop everything here
                isClosing = false;
                break;
            }
        }
    }
```

#### AUTO 


```{c}
const auto &pair
```

#### LAMBDA EXPRESSION 


```{c}
[this, bibtexUrl, primaryUrl, documentUrl, reply]() {
                    QNetworkRequest request(bibtexUrl);
                    QNetworkReply *newReply = InternalNetworkAccessManager::instance().get(request, reply);
                    if (!primaryUrl.isEmpty()) {
                        /// Store primary URL as a property of the request/reply
                        newReply->setProperty("primaryurl", QVariant::fromValue<QString>(primaryUrl));
                    }
                    if (!documentUrl.isEmpty()) {
                        /// Store URL to document as a property of the request/reply
                        newReply->setProperty("documenturl", QVariant::fromValue<QString>(documentUrl));
                    }
                    InternalNetworkAccessManager::instance().setNetworkReplyTimeout(newReply);
                    connect(newReply, &QNetworkReply::finished, this, &OnlineSearchGoogleScholar::doneFetchingBibTeX);
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &authorToken : authorTokenList) {
            QSharedPointer<Person> person = personFromString(authorToken);
            if (!person.isNull())
                result.append(person);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &infoMessage : etl->infoMessages) {
            KMessageWidget *infoMessagesWidget = new KMessageWidget(infoMessage, this);
            connect(infoMessagesWidget, &KMessageWidget::linkActivated, this, &EntryConfiguredWidget::infoMessageLinkActivated);
            vboxLayout->addWidget(infoMessagesWidget, 1);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &ed : BibTeXEntries::instance()) {
            if (entryTypeLc == ed.upperCamelCase.toLower() || entryTypeLc == ed.upperCamelCaseAlt.toLower()) {
                /// this ugly conversion is necessary because we have a "^" (xor) and "|" (and/or)
                /// syntax to differentiate required items (not used yet, but will be used
                /// later if missing required items are marked).
                QString visible = ed.requiredItems.join(QStringLiteral(","));
                visible += QLatin1Char(',') + ed.optionalItems.join(QStringLiteral(","));
                visible = visible.replace(QLatin1Char('|'), QLatin1Char(',')).replace(QLatin1Char('^'), QLatin1Char(','));
                visibleItems = visible.split(QStringLiteral(","));
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (ElementWidget *widget : const_cast<const ElementEditor::ElementEditorPrivate::WidgetList &>(d->widgets)) {
            EntryConfiguredWidget *ecw = qobject_cast<EntryConfiguredWidget *>(widget);
            if (ecw != nullptr && ecw->identifier() == tabIdentifier) {
                setCurrentPage(ecw);
                break;
            }
        }
```

#### AUTO 


```{c}
auto &pair
```

#### LAMBDA EXPRESSION 


```{c}
[&gotErrors](const FileImporter::MessageSeverity messageSeverity, const QString &messageText) {
        gotErrors |= messageSeverity >= FileImporter::MessageSeverity::Error;
        Q_UNUSED(messageText)
        //qCDebug(LOG_KBIBTEX_TEST)<<"FileImporterBibTeX issues message during 'partialBibTeXInput' test: "<<messageText;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[ = ]() {
            d->requestZoteroUrl(url);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QChar &c : text)
        if (c.unicode() > 127) return false;
```

#### AUTO 


```{c}
const auto encodedposlen = Encoder::Private::unidecode_pos[unicode];
```

#### AUTO 


```{c}
const auto &element
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &fd : const_cast<const BibTeXFields &>(*bf)) {
        QAction *action = new QAction(fd.label, header());
        action->setData(col);
        action->setCheckable(true);
        action->setChecked(!header()->isSectionHidden(col));
        connect(action, &QAction::triggered, this, &BasicFileView::headerActionToggled);
        header()->addAction(action);
        ++col;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QChar &encoderLaTeXProtectedTextOnlySymbol : encoderLaTeXProtectedTextOnlySymbols)
                    if (encoderLaTeXProtectedTextOnlySymbol == c) {
                        output.append(QLatin1Char('\\'));
                        break;
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &etl : const_cast<const EntryLayout &>(*el)) {
            ElementWidget *widget = new EntryConfiguredWidget(etl, tab);
            connect(widget, &ElementWidget::modified, p, &ElementEditor::childModified);
            widgets << widget;
            if (previousWidget == nullptr)
                previousWidget = widget; ///< memorize the first tab
            int index = tab->addTab(widget, widget->icon(), widget->label());
            tab->hideTab(index);
        }
```

#### AUTO 


```{c}
auto values = currentClique->values(fieldName);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &origin : crossRefList)
                        allProcessed &= processedEntryIds.contains(origin);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &keyword : const_cast<const QStringList &>(items))
        forCaseInsensitiveSorting.insert(keyword.toLower(), keyword);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &element : *bibtexFile) {
                QSharedPointer<Entry> entry = element.dynamicCast<Entry>();
                hasEntry |= publishEntry(entry);

            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const ColorLabelPair &clp : const_cast<const QList<ColorLabelPair> &>(colorLabelPairs)) {
        colorCodes << clp.color.name();
        colorLabels << clp.label;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &valueItem : const_cast<const Value &>(combinedValue)) {
        const QSharedPointer<const VerbatimText> verbatimText = valueItem.dynamicCast<const VerbatimText>();
        if (!verbatimText.isNull()) {
            const QString text = verbatimText->text();
            QRegularExpressionMatch match;
            if ((match = KBibTeX::urlRegExp.match(text)).hasMatch()) {
                /// add full URL
                VerbatimText *newVT = new VerbatimText(match.captured(0));
                /// test for duplicates
                if (urlValue.contains(*newVT))
                    delete newVT;
                else
                    urlValue.append(QSharedPointer<VerbatimText>(newVT));
            } else if ((match = KBibTeX::doiRegExp.match(text)).hasMatch()) {
                /// add DOI
                VerbatimText *newVT = new VerbatimText(match.captured(0));
                /// test for duplicates
                if (doiValue.contains(*newVT))
                    delete newVT;
                else
                    doiValue.append(QSharedPointer<VerbatimText>(newVT));
            } else {
                /// add anything else (e.g. local file)
                VerbatimText *newVT = new VerbatimText(*verbatimText);
                /// test for duplicates
                if (localFileValue.contains(*newVT))
                    delete newVT;
                else
                    localFileValue.append(QSharedPointer<VerbatimText>(newVT));
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                if (busyCounter.load() <= 0 && urlsToCheck.isEmpty())
                    QMetaObject::invokeMethod(p, "finished", Qt::DirectConnection, QGenericReturnArgument());
                else
                    /// It should not happen that when this timer is triggered the original condition is violated
                    qCCritical(LOG_KBIBTEX_NETWORKING) << "This cannot happen:" << busyCounter.load() << urlsToCheck.count();
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                typeChanged(KBibTeX::tfVerbatim);
            }
```

#### AUTO 


```{c}
const auto alt = currentClique->values(fieldName);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &text : authorWords)
            queryFragments.append(text + QStringLiteral("[Author]"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &etl : EntryLayout::instance()) {
            ElementWidget *widget = new EntryConfiguredWidget(etl, tab);
            connect(widget, &ElementWidget::modified, p, &ElementEditor::childModified);
            widgets << widget;
            if (previousWidget == nullptr)
                previousWidget = widget; ///< memorize the first tab
            int index = tab->addTab(widget, widget->icon(), widget->label());
            tab->hideTab(index);
        }
```

#### AUTO 


```{c}
const auto actionList = p->header()->actions();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            addToken(ttVolume, locAtTop);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &crossRefField : crossRefFields) {
        const QString crossRefValue = PlainTextValue::text(result->value(crossRefField));
        if (crossRefValue.isEmpty())
            continue;

        const QSharedPointer<Entry> crossRefEntry = bibTeXfile->containsKey(crossRefField, File::ElementType::Entry).dynamicCast<Entry>();
        if (!crossRefEntry.isNull()) {
            /// Copy all fields from crossref'ed entry to new entry which do not (yet) exist in the new entry
            for (Entry::ConstIterator it = crossRefEntry->constBegin(); it != crossRefEntry->constEnd(); ++it)
                if (!result->contains(it.key()))
                    result->insert(it.key(), Value(it.value()));

            if (crossRefEntry->type().compare(etProceedings, Qt::CaseInsensitive) && result->type().compare(etInProceedings, Qt::CaseInsensitive) && crossRefEntry->contains(ftTitle) && !result->contains(ftBookTitle)) {
                /// In case current entry is of type 'inproceedings' but lacks a 'book title'
                /// and the crossref'ed entry is of type 'proceedings' and has a 'title', then
                /// copy this 'title into as the 'book title' of the current entry.
                /// Note: the correct way should be that the crossref'ed entry has a 'book title'
                /// field, but that case was handled above when copying non-existing fields,
                /// so this if-block is only a fall-back case.
                result->insert(ftBookTitle, Value(crossRefEntry->operator [](ftTitle)));
            }

            /// Remove crossref field (no longer of use as all data got copied)
            result->remove(crossRefField);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &word : authorWords)
        queryFragments.append(rangeSearch.arg(QStringLiteral("author"), word));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &valueItem : value) {
                QSharedPointer<const MacroKey> macro = valueItem.dynamicCast<const MacroKey>();
                if (!macro.isNull())
                    for (int i = 0; i < 12; i++) {
                        if (QString::compare(macro->text(), KBibTeX::MonthsTriple[ i ]) == 0) {
                            if (month < 1) {
                                tag = KBibTeX::MonthsTriple[ i ];
                                month = i + 1;
                            }
                            content.append(KBibTeX::Months[ i ]);
                            ok = true;
                            break;
                        }
                    }
                else
                    content.append(PlainTextValue::text(valueItem));
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &fd : const_cast<const BibTeXFields &>(*this)) {
        if (fd.upperCamelCase.toLower() == iName && fd.upperCamelCaseAlt.isEmpty())
            return fd;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, recentlyOpenURL]() {
        /// In case there is at least one file marked as 'open' but it is not yet actually open,
        /// set it as current file now. The file to be opened (identified by URL) should be
        /// preferrably the file that was actively open at the end of last KBibTeX session.
        /// Slightly delaying the actually opening of files is necessary to give precendence
        /// to bibliography files passed as command line arguments (see program.cpp) over files
        /// that where open when the previous KBibTeX session was quit.
        /// See KDE bug 417164.
        /// TODO still necessary to refactor the whole 'file opening' control flow to avoid hacks like this one
        if (d->currentFileInfo == nullptr) {
            OpenFileInfo *ofiToUse = nullptr;
            /// Go over the list of files that are flagged as 'open' ...
            for (auto *ofi : const_cast<const OpenFileInfoManager::OpenFileInfoList &>(d->openFileInfoList))
                if (ofi->flags().testFlag(OpenFileInfo::StatusFlag::Open) && (ofiToUse == nullptr || (recentlyOpenURL.isValid() && ofi->url() == recentlyOpenURL)))
                    ofiToUse = ofi;
            if (ofiToUse != nullptr)
                setCurrentFile(ofiToUse);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &treeViewName : treeViewNames) {
                fd->width.insert(treeViewName, configGroup.readEntry("Width_" + treeViewName, fd->defaultWidth));
                fd->visible.insert(treeViewName, configGroup.readEntry("Visible_" + treeViewName,  fd->defaultVisible));
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const int eventId : const_cast<const QSet<int> &>(d->eventIdsToNotify))
            NotificationHub::publishEvent(eventId);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &objectValue : object.keys()) objectsValues.insert(objectValue);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &sfl : const_cast<const QList<SingleFieldLayout> &>(etl->singleFieldLayouts))
                blacklistedFields << sfl.bibtexLabel;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto *fieldLineEdit : const_cast<const QList<FieldLineEdit *> &>(lineEditList))
            heightHint += fieldLineEdit->sizeHint().height();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Value &value : const_cast<const QList<Value> &>(chosenValueMap[field]))
            if (PlainTextValue::text(value) == text)
                return;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &element : const_cast<const File &>(*bibtexfile))
        fillEmbeddedFileList(element, bibtexfile);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &key : expectedResult.keys()) {
        QCOMPARE(computedResult.contains(key), true);
        const QList<QString> expectedValues = expectedResult.values(key);
        const QList<QString> computedValues = computedResult.values(key);
        QCOMPARE(expectedValues.size(), computedValues.size());
        for (int p = expectedValues.size() - 1; p >= 0; --p) {
            const QString &expectedValue = expectedValues[p];
            const QString &computedValue = computedValues[p];
            QCOMPARE(expectedValue, computedValue);
        }
    }
```

#### AUTO 


```{c}
const auto &entry
```

#### RANGE FOR STATEMENT 


```{c}
for (const EncoderLaTeXCharacterCommand &encoderLaTeXCharacterCommand : encoderLaTeXCharacterCommands) {
                        if (encoderLaTeXCharacterCommand.command == alpha) {
                            output.append(QChar(encoderLaTeXCharacterCommand.unicode));
                            foundCommand = true;
                            break;
                        }
                    }
```

#### AUTO 


```{c}
const auto unicode = c.unicode();
```

#### AUTO 


```{c}
const auto &item
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &author : authors) {
            queryText << QString(QStringLiteral("Author:\"%1\"")).arg(author);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const EncoderLaTeXCharacterCommand &encoderLaTeXCharacterCommand : encoderLaTeXCharacterCommands)
                    if (encoderLaTeXCharacterCommand.unicode == c.unicode() && (encoderLaTeXCharacterCommand.direction & DirectionUnicodeToCommand)) {
                        output.append(QString(QStringLiteral("{\\%1}")).arg(encoderLaTeXCharacterCommand.command));
                        found = true;
                        break;
                    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            m_testWidget->setProgress(-1, -1);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &filesUrlsDoi : const_cast<const QStringList &>(filesUrlsDoiList)) {
        const QByteArray filesUrlsDoiUtf8 = filesUrlsDoi.toUtf8();
#ifdef WRITE_RAWDATAFILE
        sourceCode += rewriteNonASCII(QString(filesUrlsDoi));
        len += filesUrlsDoiUtf8.length();
        if (len > max_len) {
            sourceCode += QStringLiteral("\"\n        \"");
            len = 0;
        }
#endif // WRITE_RAWDATAFILE
        hashFilesUrlsDoi.addData(filesUrlsDoiUtf8);
    }
```

#### AUTO 


```{c}
const auto respectingQuotationMarksAuthor = splitRespectingQuotationMarks(query[QueryKey::Author]);
```

#### AUTO 


```{c}
const auto &person
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &vi : fieldValue) {
                        const QString text = PlainTextValue::text(*vi);
                        Value v;
                        v << vi;
                        insertKeyValueToValueMap(fieldName, v, text);
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &entry : el)
        if (isEntryChecked(entry)) {

            /// cover entry type
            Value v;
            v.append(QSharedPointer<VerbatimText>(new VerbatimText(entry->type())));
            insertKeyValueToValueMap(QStringLiteral("^type"), v, entry->type());

            /// cover entry id
            v.clear();
            v.append(QSharedPointer<VerbatimText>(new VerbatimText(entry->id())));
            insertKeyValueToValueMap(QStringLiteral("^id"), v, entry->id());

            /// go through each and every field of this entry
            for (Entry::ConstIterator fieldIt = entry->constBegin(); fieldIt != entry->constEnd(); ++fieldIt) {
                /// store both field name and value for later reference
                const QString fieldName = fieldIt.key().toLower();
                const Value fieldValue = fieldIt.value();

                if (fieldName == Entry::ftKeywords || fieldName == Entry::ftUrl) {
                    for (const auto &vi : fieldValue) {
                        const QString text = PlainTextValue::text(*vi);
                        Value v;
                        v << vi;
                        insertKeyValueToValueMap(fieldName, v, text);
                    }
                } else {
                    const QString fieldValueText = PlainTextValue::text(fieldValue);
                    insertKeyValueToValueMap(fieldName, fieldValue, fieldValueText);
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QChar &encoderLaTeXProtectedTextOnlySymbol : encoderLaTeXProtectedTextOnlySymbols)
                            if (encoderLaTeXProtectedTextOnlySymbol == input[i + 1]) {
                                output.append(encoderLaTeXProtectedTextOnlySymbol);
                                found = true;
                                break;
                            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : const_cast<const QList<QUrl> &>(urlList))
            openDocument(url);
```

#### LAMBDA EXPRESSION 


```{c}
[ = ]() {
                     d->requestZoteroUrl(nextPage);
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &text : titleWords)
        queryFragments.append(typedSearch.arg(QStringLiteral("t"), text));
```

#### LAMBDA EXPRESSION 


```{c}
[this, watchableFilename]() {
            d->fileSystemWatcher.addPath(watchableFilename);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                if (busyCounter.load() <= 0 && urlsToCheck.isEmpty())
                    QMetaObject::invokeMethod(p, "finished", Qt::DirectConnection, QGenericReturnArgument());
                else
                    /// It should not happen that when this timer is triggered the original condition is violated
                    qCritical() << "This cannot happen:" << busyCounter.load() << urlsToCheck.count();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &titleChunk : bookTitleChunks) {
            queryString += QString(QStringLiteral(" ( journal:%1 OR book:%1 )")).arg(EncoderLaTeX::instance().convertToPlainAscii(titleChunk));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const EncoderLaTeXEscapedCharacter &encoderLaTeXEscapedCharacter : encoderLaTeXEscapedCharacters)
                    if (encoderLaTeXEscapedCharacter.unicode == c.unicode() && (encoderLaTeXEscapedCharacter.direction & DirectionUnicodeToCommand)) {
                        const QString formatString = isAsciiLetter(encoderLaTeXEscapedCharacter.modifier) ? QStringLiteral("{\\%1 %2}") : QStringLiteral("{\\%1%2}");
                        output.append(formatString.arg(encoderLaTeXEscapedCharacter.modifier).arg(encoderLaTeXEscapedCharacter.letter));
                        found = true;
                        break;
                    }
```

#### AUTO 


```{c}
const auto urlList = FileInfo::entryUrls(entry, baseUrl, FileInfo::TestExistenceYes);
```

#### RANGE FOR STATEMENT 


```{c}
for (const MathCommand &mathCommand : mathCommands)
                    if ((mathCommand.direction & DirectionUnicodeToCommand) && mathCommand.unicode == c.unicode()) {
                        // FIXME Find a better solution, as the \ensuremath should span several characters
                        // e.g. '\ensuremath{\alpha}\ensuremath{\alpha}' should better be '\ensuremath{\alpha\alpha}'
                        output.append(QString(QStringLiteral("\\ensuremath{\\%1}")).arg(mathCommand.command));
                        found = true;
                        break;
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &element : const_cast<const File &>(*bibtexFile)) {
                    QSharedPointer<Entry> entry = element.dynamicCast<Entry>();
                    hasEntries |= publishEntry(entry);
                }
```

#### AUTO 


```{c}
const auto respectingQuotationMarks = OnlineSearchAbstract::splitRespectingQuotationMarks(it.value());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &chunk : chunksKeywords) {
            if (index > 1)
                query.addQueryItem(QString(QStringLiteral("operator%1")).arg(index), QStringLiteral("AND"));
            query.addQueryItem(QString(QStringLiteral("option%1")).arg(index), QStringLiteral("tka"));
            query.addQueryItem(QString(QStringLiteral("value%1")).arg(index), chunk);
            ++index;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *ofi : const_cast<const OpenFileInfoManager::OpenFileInfoList &>(d->openFileInfoList)) {
        if (ofi->url() == url)
            return ofi;
    }
```

#### AUTO 


```{c}
const auto chromeVersionMinor = randomGeneratorGlobalBounded(0, 4);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &fd : const_cast<const BibTeXFields &>(BibTeXFields::instance())) {
            if (!fd.upperCamelCaseAlt.isEmpty()) continue; /// keep only "single" fields and not combined ones like "Author or Editor"
            if (fd.upperCamelCase.startsWith(QLatin1Char('^'))) continue; /// skip "type" and "id" (those are marked with '^')
            comboboxFieldNames->addItem(fd.label, fd.upperCamelCase);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &extension : fileNameExtensions) {
        const QString fileName = fileNameStem + extension;
        if (QFileInfo::exists(fileName))
            return QIcon(fileName);
    }
```

#### AUTO 


```{c}
const auto fieldList = entryClique->fieldList();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &dbItem : availablePageSizes)
        if (dbItem.internalPageSizeId == pageSizeId)
            return dbItem.laTeXName;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &valueItem : v) {
            QString plainText = PlainTextValue::text(*valueItem);

            int pos = -1;
            while ((pos = regExpEscapedChars.indexIn(plainText, pos + 1)) != -1)
                plainText = plainText.replace(regExpEscapedChars.cap(0), regExpEscapedChars.cap(1));

            urlsInText(plainText, testExistence, baseDirectory, result);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto *fieldLineEdit : const_cast<const QList<FieldLineEdit *> &>(d->lineEditList)) {
        Value v;
        fieldLineEdit->apply(v);
        for (const auto &valueItem : const_cast<const Value &>(v))
            value.append(valueItem);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &modelIndex : selList) {
        /// Map from visible row to 'real' row
        /// that may be hidden through sorting
        int row = d->resultList->sortFilterProxyModel()->mapToSource(modelIndex).row();
        /// Should only be an Entry,
        /// everthing else is unexpected
        QSharedPointer<Entry> entry = sourceModel->element(row).dynamicCast<Entry>();
        if (!entry.isNull()) {
            /// Important: make clone of entry before inserting
            /// in main list, otherwise data would be shared
            QSharedPointer<Entry> clone(new Entry(*entry));
            targetModel->insertRow(clone, targetModel->rowCount());
        } else
            qCWarning(LOG_KBIBTEX_PROGRAM) << "Trying to import something that isn't an Entry";
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &element : elementsTitle) {
        d->queryParameters.insert(QString(QStringLiteral("pg%1")).arg(index), QStringLiteral("TI"));
        d->queryParameters.insert(QString(QStringLiteral("s%1")).arg(index), element);
        ++index;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &titleChunk : titleChunks) {
            queryString += QString(QStringLiteral(" title:%1")).arg(Encoder::instance().convertToPlainAscii(titleChunk));
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, url, replyUrl]() {
                QNetworkRequest request(url);
                QNetworkReply *newReply = InternalNetworkAccessManager::instance().get(request, replyUrl);
                InternalNetworkAccessManager::instance().setNetworkReplyTimeout(newReply);
                connect(newReply, &QNetworkReply::finished, this, &OnlineSearchGoogleScholar::doneFetchingConfigPage);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &text : freeTextWords) {
            static const QString freeWorldTemplate = QStringLiteral("(+srw.ti+all+\"%1\"+or+srw.kw+all+\"%1\"+or+srw.au+all+\"%1\"+or+srw.bn+all+\"%1\"+or+srw.su+all+\"%1\"+)");
            queryFragments.append(freeWorldTemplate.arg(text));
        }
```

#### AUTO 


```{c}
const auto urlList = FileInfo::entryUrls(entry, bibtexfile->property(File::Url).toUrl(), FileInfo::TestExistenceYes);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &element : const_cast<const File &>(*bibTeXFile)) {
        QSharedPointer<Entry> entry = element.dynamicCast<Entry>();
        if (!entry.isNull()) {
            ++numEntries;
            lastEntryId = entry->id();

            Value authors = entry->value(Entry::ftAuthor);
            if (!authors.isEmpty()) {
                ValueItem *vi = authors.last().data();
                Person *p = dynamic_cast<Person *>(vi);
                if (p != nullptr) {
                    lastEntryLastAuthorLastName = p->lastName();
                } else
                    lastEntryLastAuthorLastName.clear();
            } else {
                Value editors = entry->value(Entry::ftEditor);
                if (!editors.isEmpty()) {
                    ValueItem *vi = editors.last().data();
                    Person *p = dynamic_cast<Person *>(vi);
                    if (p != nullptr) {
                        lastEntryLastAuthorLastName = p->lastName();
                    } else
                        lastEntryLastAuthorLastName.clear();
                } else
                    lastEntryLastAuthorLastName.clear();
            }

            if (!lastEntryLastAuthorLastName.isEmpty()) {
                if (lastEntryLastAuthorLastName[0] == QLatin1Char('{') && lastEntryLastAuthorLastName[lastEntryLastAuthorLastName.length() - 1] == QLatin1Char('}'))
                    lastEntryLastAuthorLastName = lastEntryLastAuthorLastName.mid(1, lastEntryLastAuthorLastName.length() - 2);
                lastAuthorsList << lastEntryLastAuthorLastName;
            }

            static const QStringList stems {Entry::ftUrl, Entry::ftDOI, Entry::ftLocalFile, Entry::ftFile};
            for (const QString &stem : stems) {
                for (int index = 1; index < 100; ++index) {
                    const QString field = index == 1 ? stem : QString(QStringLiteral("%1%2")).arg(stem).arg(index);
                    const Value v = entry->value(field);
                    for (const QSharedPointer<ValueItem> &vi : v) {
                        filesUrlsDoiList << PlainTextValue::text(vi);
                    }
                    if (v.isEmpty() && index > 10) break;
                }
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QSharedPointer<Element> &element : *bibtexFile) {
                    QSharedPointer<Entry> entry = element.dynamicCast<Entry>();
                    hasEntries |= publishEntry(entry);
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &item : charmappingdataxml)
        result.replace(item.xml, item.unicode);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            updateReqOptWidgets();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &personNameFormatting : const_cast<const QSet<QString> &>(personNameFormattingSet))
                                valueSet.insert(Person::transcribePersonName(person.data(), personNameFormatting));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &valueItem : const_cast<const Value &>(value))
                combinedValue.append(valueItem);
```

#### AUTO 


```{c}
static const auto &xsltToKeyToXsltData = fileExporterXSLTtestCases();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto *fd : const_cast<const BibTeXFields &>(*p)) {
            ++columnCount;
            QString groupName = QString(QStringLiteral("Column%1")).arg(columnCount);
            KConfigGroup configGroup(layoutConfig, groupName);

            for (QMap<QString, int>::ConstIterator it = fd->width.constBegin(); it != fd->width.constEnd(); ++it) {
                configGroup.writeEntry("Width_" + it.key(), it.value());
                configGroup.writeEntry("Visible_" +  it.key(), it.value());
            }
            QString typeFlagsString = fd->typeFlags == fd->preferredTypeFlag ? QString() : QLatin1Char(';') + typeFlagsToString(fd->typeFlags);
            typeFlagsString.prepend(typeFlagToString(fd->preferredTypeFlag));
            configGroup.writeEntry("TypeFlags", typeFlagsString);
            configGroup.writeEntry("TypeIndependent", fd->typeIndependent);

            if (treeViewNames.isEmpty())
                treeViewNames.append(fd->width.keys());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &item : const_cast<const QList<EncoderXMLPrivate::CharMappingItem> &>(d->charMapping))
        result.replace(item.unicode, item.xml);
```

#### AUTO 


```{c}
const auto chosenValues = currentClique->chosenValues(fieldName);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &element : const_cast<const File &>(*bibtexFile)) {
                            QSharedPointer<Entry> entry = element.dynamicCast<Entry>();
                            if (!publishEntry(entry))
                                qCWarning(LOG_KBIBTEX_NETWORKING) << "Failed to publish entry";
                        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &dbItem : Preferences::availablePageSizes)
        if (dbItem.first == pageSizeId)
            return dbItem.second;
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                if (
#if QT_VERSION >= 0x050e00
                    busyCounter.loadRelaxed() <= 0 ///< This function was introduced in Qt 5.14.
#else // QT_VERSION < 0x050e00
                    busyCounter.load() <= 0
#endif // QT_VERSION >= 0x050e00
                    && urlsToCheck.isEmpty())
                    QMetaObject::invokeMethod(p, "finished", Qt::DirectConnection, QGenericReturnArgument());
                else
                    /// It should not happen that when this timer is triggered the original condition is violated
                    qCCritical(LOG_KBIBTEX_NETWORKING) << "This cannot happen:" <<
#if QT_VERSION >= 0x050e00
                                                       busyCounter.loadRelaxed()
#else // QT_VERSION < 0x050e00
                                                       busyCounter.load()
#endif // QT_VERSION >= 0x050e00
                                                       << urlsToCheck.count();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QSharedPointer<ValueItem> &item : value) {
        const QString text = PlainTextValue::text(*item);
        if (text.isEmpty()) continue; ///< skip empty values

        int index = indexOf(text);
        if (index < 0) {
            /// previously unknown text
            ValueLine newValueLine;
            newValueLine.text = text;
            newValueLine.count = 1;
            newValueLine.value.append(item);

            /// memorize sorting criterium:
            /// * for persons, use last name first
            /// * in any case, use lower case
            const QSharedPointer<Person> person = item.dynamicCast<Person>();
            newValueLine.sortBy = person.isNull() ? text.toLower() : person->lastName().toLower() + QStringLiteral(" ") + person->firstName().toLower();

            values << newValueLine;
        } else {
            ++values[index].count;
        }
    }
```

#### AUTO 


```{c}
const auto listBibTeXurlsFront = d->listBibTeXurls.begin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &mimeType : BibliographyService::Private::textBasedMimeTypes) {
        d->setKBibTeXforMimeType(mimeType, true);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const EncoderLaTeXCharacterCommand &encoderLaTeXCharacterCommand : encoderLaTeXCharacterCommands) {
                        if ((encoderLaTeXCharacterCommand.direction & DirectionCommandToUnicode) && encoderLaTeXCharacterCommand.command == alpha) {
                            output.append(QChar(encoderLaTeXCharacterCommand.unicode));
                            found = true;
                            break;
                        }
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &field : fieldList) {
            coveredFields << field;
            if (field == QStringLiteral("^id"))
                mergedEntry->setId(PlainTextValue::text(entryClique->chosenValue(field)));
            else if (field == QStringLiteral("^type"))
                mergedEntry->setType(PlainTextValue::text(entryClique->chosenValue(field)));
            else {
                Value combined;
                const auto chosenValues = entryClique->chosenValues(field);
                for (const Value &v : chosenValues) {
                    combined.append(v);
                }
                if (!combined.isEmpty())
                    mergedEntry->insert(field, combined);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &filename : fileList) {
                        value.append(QSharedPointer<VerbatimText>(new VerbatimText(filename)));
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &queryFragment : respectingQuotationMarks)
                queryFragments.append(p->encodeURL(queryFragment));
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                typeChanged(KBibTeX::tfReference);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QSharedPointer<ValueItem> &item : const_cast<const Value &>(value)) {
        QSharedPointer<const Person> person = item.dynamicCast<const Person>();
        if (!person.isNull()) {
            const QString lastName = person->lastName();
            if (!lastName.isEmpty())
                result << lastName;
        }
        if (--maxAuthors <= 0) break;   ///< limit the number of authors considered
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QJsonValue &resultValue : resultArray) {
                        if (resultValue.isObject()) {
                            Entry *entry = d->entryFromJsonObject(resultValue.toObject());
                            if (entry != nullptr)
                                publishEntry(QSharedPointer<Entry>(entry));
                            else {
                                qCWarning(LOG_KBIBTEX_NETWORKING) << "Problem with JSON data from ScienceDirect: Data could not be interpreted as a bibliographic entry";
                                encounteredUnexpectedData = true;
                                break;
                            }
                        } else {
                            qCWarning(LOG_KBIBTEX_NETWORKING) << "Problem with JSON data from ScienceDirect: No object found in 'results' array where expected";
                            encounteredUnexpectedData = true;
                            break;
                        }
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DotlessIJCharacter &dotlessIJCharacter : dotlessIJCharacters)
                    if (dotlessIJCharacter.letter == input[i + 4 + skipSpaces] && dotlessIJCharacter.modifier == input[i + 1]) {
                        output.append(QChar(dotlessIJCharacter.unicode));
                        found = true;
                        break;
                    }
```

#### AUTO 


```{c}
const auto &sfl
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &valueItem : value) {
        if (!isFirst)
            result.append(' ');
        isFirst = false;

        QSharedPointer<const PlainText> plainText = valueItem.dynamicCast<const PlainText>();
        if (!plainText.isNull())
            result.append("<text>" +  cleanXML(EncoderXML::instance().encode(PlainTextValue::text(valueItem), Encoder::TargetEncoding::UTF8)) + "</text>");
        else {
            QSharedPointer<const Person> p = valueItem.dynamicCast<const Person>();
            if (!p.isNull()) {
                result.append("<person>");
                if (!p->firstName().isEmpty())
                    result.append("<firstname>" +  cleanXML(EncoderXML::instance().encode(p->firstName(), Encoder::TargetEncoding::UTF8)) + "</firstname>");
                if (!p->lastName().isEmpty())
                    result.append("<lastname>" +  cleanXML(EncoderXML::instance().encode(p->lastName(), Encoder::TargetEncoding::UTF8)) + "</lastname>");
                if (!p->suffix().isEmpty())
                    result.append("<suffix>" +  cleanXML(EncoderXML::instance().encode(p->suffix(), Encoder::TargetEncoding::UTF8)) + "</suffix>");
                result.append("</person>");
            }
            // TODO: Other data types
            else
                result.append("<text>" + cleanXML(EncoderXML::instance().encode(PlainTextValue::text(valueItem), Encoder::TargetEncoding::UTF8)) + "</text>");
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &element : const_cast<const File &>(*bibtexFile)) {
                QSharedPointer<Entry> entry = element.dynamicCast<Entry>();
                if (publishEntry(entry))
                    ++numFoundResults;
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &doi : dois) {
                if (first)
                    first = false;
                else
                    postBody.append(',');
                postBody.append(doi.toUtf8());
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &formattingOption : formattingOptions)
            comboBoxPersonNameFormatting->addItem(Person::transcribePersonName(&dummyPerson, formattingOption), formattingOption);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &bibStyle : stylesToTestFor)
            if (kpsewhich(bibStyle + ".bst"))
                listOfBibStyles.append(bibStyle);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &element : const_cast<const File &>(*this)) {
        const QSharedPointer<Entry> entry = elementTypes.testFlag(ElementType::Entry) ? element.dynamicCast<Entry>() : QSharedPointer<Entry>();
        if (!entry.isNull()) {
            if (entry->id() == key)
                return entry;
        } else {
            const QSharedPointer<Macro> macro = elementTypes.testFlag(ElementType::Macro) ? element.dynamicCast<Macro>() : QSharedPointer<Macro>();
            if (!macro.isNull()) {
                if (macro->key() == key)
                    return macro;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &mimeType : BibliographyService::Private::textBasedMimeTypes) {
        /// Test if KBibTeX is default handler for mime type
        if (!d->isKBibTeXdefaultForMimeType(mimeType))
            return false; ///< Failing any test means KBibTeX is not default application/part
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const EncoderLaTeXCharacterCommand &encoderLaTeXCharacterCommand : encoderLaTeXCharacterCommands)
                    if (encoderLaTeXCharacterCommand.unicode == c.unicode() && (encoderLaTeXCharacterCommand.direction & DirectionUnicodeToCommand)) {
                        // FIXME Find a better solution, as the curly brackets are unnecessary in some situations
                        // e.g. '{\command}{\command}' should better be '{\command\command}'
                        output.append(QString(QStringLiteral("{\\%1}")).arg(encoderLaTeXCharacterCommand.command));
                        found = true;
                        break;
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QJsonValue &author : authorArray) {
            const QString name = author.toObject().value(QStringLiteral("name")).toString();
            const int order = author.toObject().value(QStringLiteral("order")).toInt(-1);
            if (order >= 0 && !name.isEmpty()) {
                if (order > maxOrder) maxOrder = order;
                authorMap.insert(order, name);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : urlList) {
            if (!url.isLocalFile()) continue;
            const QString filename = url.url(QUrl::PreferLocalFile);
            const QString basename = QFileInfo(filename).fileName();
            m_embeddedFileList.append(QString(QStringLiteral("%1|%2|%3")).arg(title, filename, basename));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const MathCommand &mathCommand : mathCommands) {
                            if (mathCommand.command == alpha) {
                                output.append(QChar(mathCommand.unicode));
                                found = true;
                                break;
                            }
                        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &labelText : const_cast<const QStringList &>(paperSizeLabelToNameKeys)) {
            comboBoxPaperSize->addItem(labelText, paperSizeLabelToName[labelText]);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : urlList) {
                    /// First iteration: local references only
                    if (!url.isLocalFile()) continue; ///< skip remote URLs

                    /// Build a nice menu item (label, icon, ...)
                    const QFileInfo fi(url.toLocalFile());
                    const QString label = QString(QStringLiteral("%1 [%2]")).arg(fi.fileName(), fi.absolutePath());
                    QMimeDatabase db;
                    QAction *action = new QAction(QIcon::fromTheme(db.mimeTypeForUrl(url).iconName()), label, p);
                    action->setData(fi.absoluteFilePath());
                    action->setToolTip(fi.absoluteFilePath());
                    /// Register action at signal handler to open URL when triggered
                    connect(action, &QAction::triggered, signalMapperViewDocument, static_cast<void(QSignalMapper::*)()>(&QSignalMapper::map));
                    signalMapperViewDocument->setMapping(action, action);
                    signalMapperViewDocumentSenders.insert(action);
                    viewDocumentMenu->addAction(action);
                    /// Memorize first action
                    if (firstAction == nullptr) firstAction = action;
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &key : const_cast<const QStringList &>(modifiedKeys)) {
        entry->remove(key);
        entry->insert(key, internalEntry->value(key));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const MathCommand &mathCommand : mathCommands) {
                            if ((mathCommand.direction & DirectionCommandToUnicode) && mathCommand.command == alpha) {
                                if (currentMathModeTop() == MathModeNone)
                                    qCDebug(LOG_KBIBTEX_IO) << "Found math mode command" << QString(QStringLiteral("\\%1")).arg(alpha) << "outside of a math expression";
                                output.append(QChar(mathCommand.unicode));
                                found = true;
                                break;
                            }
                        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &mimeType : d->textBasedMimeTypes) {
        /// Test if KBibTeX is default handler for mime type
        if (!d->isKBibTeXdefaultForMimeType(mimeType))
            return false; ///< Failing any test means KBibTeX is not default application/part
    }
```

#### AUTO 


```{c}
const auto &valueItem
```

#### LAMBDA EXPRESSION 


```{c}
[&bibtexOutput](const QString & line) {
        bibtexOutput.append(line);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &rawHeaderName : rawHeaderList) {
            if (rawHeaderName.toLower().contains("apikey") || rawHeaderName.toLower().contains("api-key")) continue; ///< skip dumping header values containing an API key
            qCDebug(LOG_KBIBTEX_NETWORKING) << " " << rawHeaderName << ":" << request.rawHeader(rawHeaderName);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, buttonSaveLocally, fieldLineEdit]() {
        textChanged(buttonSaveLocally, fieldLineEdit);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (ElementWidget *widget : const_cast<const WidgetList &>(widgets)) {
                const int index = tab->indexOf(widget);
                const bool canEdit = widget->canEdit(element.data());

                if (widget == referenceWidget) {
                    /// Reference widget
                    widget->setVisible(canEdit);
                    widget->setEnabled(canEdit);
                } else {
                    if (canEdit) tab->showTab(widget);
                    else if (index >= 0) tab->hideTab(index);
                    if (canEdit && index >= 0 && index < firstEnabledTab)
                        firstEnabledTab = index;
                }
            }
```

#### AUTO 


```{c}
const auto &dbItem
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &ed : const_cast<const BibTeXEntries &>(*be))
        entryType->addItem(ed.label, ed.upperCamelCase);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &rawHeaderName : rawHeadersSent) {
            if (rawHeaderName.toLower().contains("apikey") || rawHeaderName.toLower().contains("api-key")) continue; ///< skip dumping header values containing an API key
            qCDebug(LOG_KBIBTEX_NETWORKING) << "SENT " << rawHeaderName << ":" << request.rawHeader(rawHeaderName);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &token : tokens) {
        /// Position where comma was found, or -1 if no comma in token
        int p = -1;
        if (commaCount < 2) {
            /// Only check if token contains comma
            /// if no comma was found before
            int bracketCounter = 0;
            for (int i = 0; i < token.length(); ++i) {
                /// Consider opening curly brackets
                if (token[i] == QChar('{')) ++bracketCounter;
                /// Consider closing curly brackets
                else if (token[i] == QChar('}')) --bracketCounter;
                /// Only if outside any open curly bracket environments
                /// consider comma characters
                else if (bracketCounter == 0 && token[i] == QChar(',')) {
                    /// Memorize comma's position and break from loop
                    p = i;
                    break;
                } else if (bracketCounter < 0) {
                    /// Should never happen: more closing brackets than opening ones
                    qCWarning(LOG_KBIBTEX_IO) << "Opening and closing brackets do not match near line" << line_number;
                    if (parent != nullptr)
                        QMetaObject::invokeMethod(parent, "message", Qt::QueuedConnection, QGenericReturnArgument(), Q_ARG(FileImporter::MessageSeverity, SeverityWarning), Q_ARG(QString, QString(QStringLiteral("Opening and closing brackets do not match near line %1")).arg(line_number)));
                }
            }
        }

        if (p >= 0) {
            if (commaCount == 0) {
                if (p > 0) partA.append(token.left(p));
                if (p < token.length() - 1) partB.append(token.mid(p + 1));
            } else if (commaCount == 1) {
                if (p > 0) partB.append(token.left(p));
                if (p < token.length() - 1) partC.append(token.mid(p + 1));
            }
            ++commaCount;
        } else if (commaCount == 0)
            partA.append(token);
        else if (commaCount == 1)
            partB.append(token);
        else if (commaCount == 2)
            partC.append(token);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const MathCommand &mathCommand : mathCommands) {
                            if (mathCommand.command == alpha) {
                                if (output.endsWith(QStringLiteral("\\ensuremath"))) {
                                    /// Remove "\ensuremath" right before this math command,
                                    /// it will be re-inserted when exporting/saving the document
                                    output = output.left(output.length() - 11);
                                }
                                output.append(QChar(mathCommand.unicode));
                                foundCommand = true;
                                break;
                            }
                        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QChar &encoderLaTeXProtectedTextOnlySymbol : encoderLaTeXProtectedTextOnlySymbols)
                    if (encoderLaTeXProtectedTextOnlySymbol == c) {
                        output.append(QLatin1Char('\\'));
                        found = true;
                        break;
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &keyword : keywords)
                value.append(keyword);
```

#### LAMBDA EXPRESSION 


```{c}
[ = ]() {
        d->requestZoteroUrl(url);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &etl : const_cast<const EntryLayout &>(*this)) {
        ++tabCount;
        QString groupName = QString(QStringLiteral("EntryLayoutTab%1")).arg(tabCount);
        KConfigGroup configGroup(d->layoutConfig, groupName);

        configGroup.writeEntry(QStringLiteral("uiCaption"), etl->uiCaption);
        configGroup.writeEntry(QStringLiteral("iconName"), etl->iconName);
        configGroup.writeEntry(QStringLiteral("columns"), etl->columns);

        int fieldCount = 0;
        for (const SingleFieldLayout &sfl : const_cast<const QList<SingleFieldLayout> &>(etl->singleFieldLayouts)) {
            ++fieldCount;
            configGroup.writeEntry(QString(QStringLiteral("bibtexLabel%1")).arg(fieldCount), sfl.bibtexLabel);
            configGroup.writeEntry(QString(QStringLiteral("uiLabel%1")).arg(fieldCount), sfl.uiLabel);
            configGroup.writeEntry(QString(QStringLiteral("fieldInputLayout%1")).arg(fieldCount), EntryLayoutPrivate::convert(sfl.fieldInputLayout));
        }
        configGroup.writeEntry(QStringLiteral("count"), fieldCount);
    }
```

#### AUTO 


```{c}
const auto urlList = FileInfo::entryUrls(entry, bibliographyFile->property(File::Url).toUrl(), FileInfo::TestExistence::Yes);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &fd : const_cast<const BibTeXFields &>(BibTeXFields::instance())) {
        QAction *action = new QAction(fd.label, &menu);
        action->setData(col);
        action->setCheckable(true);
        action->setChecked(!header()->isSectionHidden(col));
        if (onlyOneLastColumnVisible && action->isChecked()) {
            /// If only one last column is visible and the current field is this column,
            /// disable action so that the column cannot be hidden by the user
            action->setEnabled(false);
        }
        connect(action, &QAction::triggered, this, &BasicFileView::headerActionToggled);
        menu.addAction(action);
        ++col;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : selectedRows) {
                const int row = index.row();
                if (row >= 0 && row < file->count())
                    countElement(file->at(row), numEntries, numJournalArticles, numConferencePublications, numBooks, numComments, numMacros);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (QSharedPointer<Element> element : bibtexFile) {
        /// Process only entries, not comments, preambles or macros
        QSharedPointer<Entry> entry = element.dynamicCast<Entry>();
        if (entry.isNull()) continue;

        /// Retrieve set of URLs per entry and add to set of URLS to be checked
        const QSet<QUrl> thisEntryUrls = FileInfo::entryUrls(entry, bibtexFile.property(File::Url).toUrl(), FileInfo::TestExistence::No);
        for (const QUrl &u : thisEntryUrls)
            d->urlsToCheck.insert(u); ///< better?
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &element : const_cast<const File &>(*bibtexFile)) {
                    QSharedPointer<Entry> entry = element.dynamicCast<Entry>();
                    if (!entry.isNull()) {
                        if (!downloadUrl.isEmpty()) {
                            /// There is an external document associated with this BibTeX entry
                            Value urlValue = entry->value(Entry::ftUrl);
                            urlValue.append(QSharedPointer<VerbatimText>(new VerbatimText(downloadUrl)));
                            entry->insert(Entry::ftUrl, urlValue);
                        }

                        Value v;
                        v.append(QSharedPointer<VerbatimText>(new VerbatimText(label())));
                        entry->insert(QStringLiteral("x-fetchedfrom"), v);
                        emit foundEntry(entry);
                    }

                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &msg : const_cast<const QStringList &>(msgList)) {
            static const char linebreak = '\n';
            f.write(&linebreak, 1);
            f.write(msg.toUtf8());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QSslError &error : errors)
        qWarning() << QStringLiteral(" * ") + error.errorString() << "; Code: " << static_cast<int>(error.error());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &person : personList)
                    authorValue << person;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &logLine : errorLog)
        qDebug() << logLine;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &fragment : expectedFragments)
        QVERIFY2(generatedData.contains(fragment), QString(QStringLiteral("Fragment '%1' not found in generated XML data")).arg(fragment).toLatin1().constData());
```

#### AUTO 


```{c}
const auto len = encodedposlen & 31;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &word : freeTextWords)
        queryFragments.append(globalSearch.arg(word));
```

#### RANGE FOR STATEMENT 


```{c}
for (const Value &v : chosenValues) {
                    combined.append(v);
                }
```

#### AUTO 


```{c}
auto &fd = *it;
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                typeChanged(KBibTeX::TypeFlag::PlainText);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &fd : const_cast<const BibTeXFields &>(*bibtexFields)) {
            if (!fd.upperCamelCaseAlt.isEmpty()) continue; /// keep only "single" fields and not combined ones like "Author or Editor"
            if (fd.upperCamelCase.startsWith('^')) continue; /// skip "type" and "id"
            comboboxFieldNames->addItem(fd.label, fd.upperCamelCase);
        }
```

#### AUTO 


```{c}
auto exporter = pair.first;
```

#### LAMBDA EXPRESSION 


```{c}
[ = ]() {
                    requestZoteroUrl(url);
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SingleFieldLayout &sfl : const_cast<const QList<SingleFieldLayout> &>(etl->singleFieldLayouts)) {
        LabeledFieldInput *labeledFieldInput = new LabeledFieldInput;

        /// create an editing widget for this field
        const FieldDescription &fd = BibTeXFields::instance().find(sfl.bibtexLabel);
        labeledFieldInput->fieldInput = new FieldInput(sfl.fieldInputLayout, fd.preferredTypeFlag, fd.typeFlags, this);
        labeledFieldInput->fieldInput->setFieldKey(sfl.bibtexLabel);
        bibtexKeyToWidget.insert(sfl.bibtexLabel, labeledFieldInput->fieldInput);
        connect(labeledFieldInput->fieldInput, &FieldInput::modified, this, &EntryConfiguredWidget::gotModified);

        /// memorize if field input should grow vertically (e.g. is a list)
        labeledFieldInput->isVerticallyMinimumExpaning = sfl.fieldInputLayout == KBibTeX::FieldInputType::MultiLine || sfl.fieldInputLayout == KBibTeX::FieldInputType::List || sfl.fieldInputLayout == KBibTeX::FieldInputType::PersonList || sfl.fieldInputLayout == KBibTeX::FieldInputType::KeywordList;

        /// create a label next to the editing widget
        labeledFieldInput->label = new QLabel(QString(QStringLiteral("%1:")).arg(sfl.uiLabel), this);
        labeledFieldInput->label->setBuddy(labeledFieldInput->fieldInput->buddy());
        /// align label's text vertically to match field input
        const Qt::Alignment horizontalAlignment = static_cast<Qt::Alignment>(labeledFieldInput->label->style()->styleHint(QStyle::SH_FormLayoutLabelAlignment)) & Qt::AlignHorizontal_Mask;
        labeledFieldInput->label->setAlignment(horizontalAlignment | (labeledFieldInput->isVerticallyMinimumExpaning ? Qt::AlignTop : Qt::AlignVCenter));

        listOfLabeledFieldInput[i] = labeledFieldInput;

        ++i;
    }
```

#### AUTO 


```{c}
const auto entryUrlList = FileInfo::entryUrls(entry, fileSourceModel()->bibliographyFile()->property(File::Url, QUrl()).toUrl(), FileInfo::TestExistenceYes);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto *fd : const_cast<const BibTeXFields &>(*bf)) {
            headerProperty->columns[col].isHidden = !fd->defaultVisible;
            headerProperty->columns[col].width = fd->defaultWidth;
            headerProperty->columns[col].visualIndex = col;
            if (!headerProperty->columns[col].isHidden)
                headerProperty->sumWidths += fd->defaultWidth;
            ++col;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &queryFragment : respectingQuotationMarksFreeText) {
        queryFragments.append(encodeURL(queryFragment));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &msg : const_cast<const QStringList &>(msgList))
            ts << endl << msg;
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            addToken(ttPageNumber, locAtBottom);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : mil) {
            QSharedPointer<Entry> entry = d->partWidget->fileView()->fileModel()->element(d->partWidget->fileView()->sortFilterProxyModel()->mapToSource(index).row()).dynamicCast<Entry>();
            if (!entry.isNull())
                references << entry->id();
        }
```

#### AUTO 


```{c}
auto importer = pair.second;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &nameComponent : nameComponents) {
                    newNameComponents.append(nameComponent[0].toUpper() + nameComponent.mid(1));
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->update();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &queryFragment : respectingQuotationMarks)
                queryFragments.append(OnlineSearchAbstract::encodeURL(queryFragment));
```

#### AUTO 


```{c}
const auto chromeVersionMinor = QRandomGenerator::global()->bounded(0, 4);
```

#### AUTO 


```{c}
const auto entryUrlList = FileInfo::entryUrls(entry.data(), fileSourceModel()->bibliographyFile()->property(File::Url, QUrl()).toUrl(), FileInfo::TestExistenceYes);
```

#### RANGE FOR STATEMENT 


```{c}
for (const HiddenTabInfo &hti : const_cast<const QSet<HiddenTabInfo> &>(m_hiddenTabInfo)) {
        if (hti.widget == page) {
            int pos = showTab(hti);
            setTabText(pos, label);
            return pos;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &u : thisEntryUrls)
            d->urlsToCheck.insert(u);
```

#### AUTO 


```{c}
const auto pos = ending.lastIndexOf(QStringLiteral("."));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &modelIndex : selList) {
        /// Map from visible row to 'real' row
        /// that may be hidden through sorting
        int row = d->resultList->sortFilterProxyModel()->mapToSource(modelIndex).row();
        /// Should only be an Entry,
        /// everthing else is unexpected
        QSharedPointer<Entry> entry = sourceModel->element(row).dynamicCast<Entry>();
        if (!entry.isNull()) {
            /// Important: make clone of entry before inserting
            /// in main list, otherwise data would be shared
            QSharedPointer<Entry> clone(new Entry(*entry));
            atLeastOneSuccessfullInsertion |= targetModel->insertRow(clone, targetModel->rowCount());
        } else
            qCWarning(LOG_KBIBTEX_PROGRAM) << "Trying to import something that isn't an Entry";
    }
```

#### LAMBDA EXPRESSION 


```{c}
[errorLog, &process] {
            QByteArray stderr = process.readAllStandardError();
            QTextStream ts(&stderr);
            while (!ts.atEnd())
                errorLog->append(ts.readLine());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &fd : const_cast<const BibTeXFields &>(BibTeXFields::instance())) {
            /// Colors may have changed
            bool columnChanged = fd.upperCamelCase.toLower() == Entry::ftColor;
            /// Person name formatting may has changed
            columnChanged |= fd.upperCamelCase.toLower() == Entry::ftAuthor || fd.upperCamelCase.toLower() == Entry::ftEditor;
            columnChanged |= fd.upperCamelCaseAlt.toLower() == Entry::ftAuthor || fd.upperCamelCaseAlt.toLower() == Entry::ftEditor;
            /// Changes necessary for this column? Publish update
            if (columnChanged)
                emit dataChanged(index(0, column), index(rowCount() - 1, column));
            ++column;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const HiddenTabInfo &hti : const_cast<const QSet<HiddenTabInfo> &>(d->hiddenTabInfo)) {
        if (hti.widget == page)
            return d->showTab(hti);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                typeChanged(KBibTeX::TypeFlag::Reference);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const PreviewStyles &previewStyle : previewStyles) {
            if (!hasBibTeX2HTML && previewStyle.type.contains(QStringLiteral("bibtex2html"))) continue;
            comboBox->addItem(previewStyle.label, QVariant::fromValue(previewStyle));
            if (previousStyle == previewStyle.style)
                styleIndex = c;
            ++c;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &text : authorWords)
        queryFragments.append(typedSearch.arg(QStringLiteral("a"), text));
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString & text) {
            textChanged(text);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &queryFragment : respectingQuotationMarks)
            queryFragments.append(p->encodeURL(queryFragment));
```

#### AUTO 


```{c}
const auto &list = partWidget->fileView()->selectionModel()->selectedRows();
```

#### RANGE FOR STATEMENT 


```{c}
for (const DotlessIJCharacter &dotlessIJCharacter : dotlessIJCharacters)
                        if ((dotlessIJCharacter.direction & DirectionCommandToUnicode) && dotlessIJCharacter.letter == input[i + 4 + skipSpaces] && dotlessIJCharacter.modifier == input[i + 2]) {
                            output.append(QChar(dotlessIJCharacter.unicode));
                            found = true;
                            break;
                        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &url : urls) {
            const QUrl u = (withProtocolChecker.indexIn(url) == 0) ? QUrl::fromUserInput(url) : QUrl::fromLocalFile(url);
            mainWindow->openDocument(u);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &style : styles) {
            QStringList item = style.split(QStringLiteral("|"));
            QString itemLabel = item.at(0);
            item.removeFirst();
            comboBoxBibliographySystem->addItem(itemLabel, item);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &field : const_cast<const QStringList &>(urlFields)) {
        if (entry.contains(field)) {
            const QString fieldText = PlainTextValue::text(entry.value(field));
            QRegularExpressionMatchIterator doiRegExpMatchIt = KBibTeX::doiRegExp.globalMatch(fieldText);
            while (doiRegExpMatchIt.hasNext()) {
                const QRegularExpressionMatch doiRegExpMatch = doiRegExpMatchIt.next();
                d->queueUrl(QUrl(FileInfo::doiUrlPrefix() + doiRegExpMatch.captured(0)), fieldText, Entry::ftDOI, maxDepth);
            }

            QRegularExpressionMatchIterator urlRegExpMatchIt = KBibTeX::urlRegExp.globalMatch(fieldText);
            while (urlRegExpMatchIt.hasNext()) {
                QRegularExpressionMatch urlRegExpMatch = urlRegExpMatchIt.next();
                d->queueUrl(QUrl(urlRegExpMatch.captured(0)), searchWords, Entry::ftUrl, maxDepth);
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            this->limitKeyboardTabStops(); /// naming conflict between local variable 'limitKeyboardTabStops' and function 'limitKeyboardTabStops'
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DotlessIJCharacter &dotlessIJCharacter : dotlessIJCharacters)
                    if (dotlessIJCharacter.letter == input[i + 3 + skipSpaces] && dotlessIJCharacter.modifier == input[i + 1]) {
                        output.append(QChar(dotlessIJCharacter.unicode));
                        i += 3 + skipSpaces;
                        found = true;
                        break;
                    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, url, reply]() {
                QNetworkRequest request(url);
                QNetworkReply *newReply = InternalNetworkAccessManager::instance().get(request, reply);
                InternalNetworkAccessManager::instance().setNetworkReplyTimeout(newReply);
                connect(newReply, &QNetworkReply::finished, this, &OnlineSearchGoogleScholar::doneFetchingSetConfigPage);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const EncoderLaTeXCharacterCommand &encoderLaTeXCharacterCommand : encoderLaTeXCharacterCommands) {
                            if ((encoderLaTeXCharacterCommand.direction & DirectionCommandToUnicode) && encoderLaTeXCharacterCommand.command == alpha) {
                                output.append(QChar(encoderLaTeXCharacterCommand.unicode));
                                found = true;
                                break;
                            }
                        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : mil)
            workingSetFile->append(model->element(d->view->sortFilterProxyModel()->mapToSource(index).row()));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &extension : documentFileExtensions) {
            const QFileInfo fi(directory + QDir::separator() + entry->id() + extension);
            if (fi.exists()) {
                const QUrl url = QUrl::fromLocalFile(fi.canonicalFilePath());
                if (!result.contains(url))
                    result << url;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &xslTranslationFile : xsltToKeyToXsltData.keys()) {
        const QHash<const char *, QSet<QString>> &keyToXsltData = xsltToKeyToXsltData.value(xslTranslationFile);
        for (auto it = keyFileTable.constBegin(); it != keyFileTable.constEnd(); ++it)
            if (keyToXsltData.contains(it->first)) {
                const QString label = QString(QStringLiteral("'%1' with XSLT '%2'")).arg(QString::fromLatin1(it->first)).arg(xslTranslationFile);
                QTest::newRow(label.toUtf8().constData()) << it->second << xslTranslationFile << keyToXsltData.value(it->first);
            }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](int logicalIndex, int oldSize, int newSize) {
            Q_UNUSED(oldSize)
            if (!d->automaticBalancing && !d->name.isEmpty() && newSize > 0 && logicalIndex >= 0 && logicalIndex < BibTeXFields::instance().count()) {
                BibTeXFields::instance()[logicalIndex].width[d->name] = newSize;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &token : tokenList) {
            TokenWidget *tokenWidget = nullptr;

            if (token[0] == 'a' || token[0] == 'A' || token[0] == 'z') {
                struct IdSuggestions::IdSuggestionTokenInfo info = p->evalToken(token.mid(1));
                /// Support deprecated 'a' and 'z' cases
                if (token[0] == 'a')
                    info.startWord = info.endWord = 0;
                else if (token[0] == 'z') {
                    info.startWord = 1;
                    info.endWord = 0x00ffffff;
                }
                tokenWidget = new AuthorWidget(info, p, container);
                widgetList << tokenWidget;
                containerLayout->insertWidget(containerLayout->count() - 2, tokenWidget, 1);
            } else if (token[0] == 'y') {
                tokenWidget = new YearWidget(2, p, container);
                widgetList << tokenWidget;
                containerLayout->insertWidget(containerLayout->count() - 2, tokenWidget, 1);
            } else if (token[0] == 'Y') {
                tokenWidget = new YearWidget(4, p, container);
                widgetList << tokenWidget;
                containerLayout->insertWidget(containerLayout->count() - 2, tokenWidget, 1);
            } else if (token[0] == 't' || token[0] == 'T') {
                struct IdSuggestions::IdSuggestionTokenInfo info = p->evalToken(token.mid(1));
                tokenWidget = new TitleWidget(info, token[0] == 'T', p, container);
                widgetList << tokenWidget;
                containerLayout->insertWidget(containerLayout->count() - 2, tokenWidget, 1);
            } else if (token[0] == 'j') {
                struct IdSuggestions::IdSuggestionTokenInfo info = p->evalToken(token.mid(1));
                tokenWidget = new JournalWidget(info, p, container);
                widgetList << tokenWidget;
                containerLayout->insertWidget(containerLayout->count() - 2, tokenWidget, 1);
            } else if (token[0] == 'v') {
                tokenWidget = new VolumeWidget(p, container);
                widgetList << tokenWidget;
                containerLayout->insertWidget(containerLayout->count() - 2, tokenWidget, 1);
            } else if (token[0] == 'p') {
                tokenWidget = new PageNumberWidget(p, container);
                widgetList << tokenWidget;
                containerLayout->insertWidget(containerLayout->count() - 2, tokenWidget, 1);
            } else if (token[0] == '"') {
                tokenWidget = new TextWidget(token.mid(1), p, container);
                widgetList << tokenWidget;
                containerLayout->insertWidget(containerLayout->count() - 2, tokenWidget, 1);
            }

            if (tokenWidget != nullptr)
                addManagementButtons(tokenWidget);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &extension : fileNameExtensions) {
        const QString fileName = fileNameStem + extension;
        const QFileInfo fi(fileName);
        if (fi.exists(fileName)) {
            if (fi.lastModified().daysTo(QDateTime::currentDateTime()) > 90) {
                /// If icon is other than 90 days, delete it and fetch current one
                QFile::remove(fileName);
            } else {
                favIcon = QIcon(fileName);
                QTimer::singleShot(100, this, [this]() {
                    QMetaObject::invokeMethod(this, "gotIcon", Qt::DirectConnection, QGenericReturnArgument(), Q_ARG(QIcon, favIcon));
                });
                return;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &author : authors)
            result.append(QString(QStringLiteral("author:%1")).arg(author));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : selectedIndexes) {
        if (index.column() == 0) {
            QString itemText = index.data(ValueListModel::SearchTextRole).toString();
            fq.terms << itemText;
        }
    }
```

#### AUTO 


```{c}
const auto values = currentClique->values(fieldName);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QSharedPointer<Element> &element : const_cast<const File &>(*file)) {
        QSharedPointer<Entry> entry = element.dynamicCast<Entry>();
        /// Process only Entry objects
        if (!entry.isNull()) {
            /// Go through every key-value pair in entry (author, title, ...)
            for (Entry::Iterator eit = entry->begin(); eit != entry->end(); ++eit) {
                /// Fetch key-value pair's key
                const QString key = eit.key().toLower();
                /// Process only key-value pairs that are filtered for (e.g. only keywords)
                if (key == fName) {
                    eit.value().replace(origText, newValue.first());
                    break;
                }
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const PreviewStyle &previewStyle : previewStyles()) {
            if (!hasBibTeX2HTML && previewStyle.type.contains(QStringLiteral("bibtex2html"))) continue;
            comboBox->addItem(previewStyle.label, QVariant::fromValue(previewStyle));
            if (previousStyle == previewStyle.style)
                styleIndex = c;
            ++c;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &text : yearWords) {
            static const QString yearTemplate = QStringLiteral("srw.yr+any+\"%1\"");
            queryFragments.append(yearTemplate.arg(text));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &text : fileList) {
        internalText = text;

        /// If testing for the actual existence of a filename found in the text ...
        if (testExistence == TestExistenceYes) {
            /// If a base directory (e.g. the location of the parent .bib file) is given
            /// and the potential filename fragment is NOT an absolute path, ...
            if (internalText.startsWith(QStringLiteral("~") + QDir::separator())) {
                const QString fullFilename = QDir::homePath() + internalText.mid(1);
                const QFileInfo fileInfo(fullFilename);
                const QUrl url = QUrl::fromLocalFile(fileInfo.canonicalFilePath());
                if (fileInfo.exists() && fileInfo.isFile() && url.isValid() && !result.contains(url)) {
                    result << url;
                    /// Stop searching for URLs or filenames in current internal text
                    continue;
                }
            } else if (!baseDirectory.isEmpty() &&
                       // TODO the following test assumes that absolute paths start
                       // with a dir separator, which may only be true on Unix/Linux,
                       // but not Windows. May be a test for 'first character is a letter,
                       // second is ":", third is "\"' may be necessary.
                       !internalText.startsWith(QDir::separator())) {
                /// To get the absolute path, prepend filename fragment with base directory
                const QString fullFilename = baseDirectory + QDir::separator() + internalText;
                const QFileInfo fileInfo(fullFilename);
                const QUrl url = QUrl::fromLocalFile(fileInfo.canonicalFilePath());
                if (fileInfo.exists() && fileInfo.isFile() && url.isValid() && !result.contains(url)) {
                    result << url;
                    /// Stop searching for URLs or filenames in current internal text
                    continue;
                }
            } else {
                /// Either the filename fragment is an absolute path OR no base directory
                /// was given (current working directory is assumed), ...
                const QFileInfo fileInfo(internalText);
                const QUrl url = QUrl::fromLocalFile(fileInfo.canonicalFilePath());
                if (fileInfo.exists() && fileInfo.isFile() && url.isValid() && !result.contains(url)) {
                    result << url;
                    /// stop searching for URLs or filenames in current internal text
                    continue;
                }
            }
        }

        /// extract URL from current field
        pos = 0;
        QRegularExpressionMatch urlRegExpMatch;
        while ((urlRegExpMatch = KBibTeX::urlRegExp.match(internalText, pos)).hasMatch()) {
            pos = urlRegExpMatch.capturedStart(0);
            const QString match = urlRegExpMatch.captured(0);
            QUrl url(match);
            if (url.isValid() && (testExistence == TestExistenceNo || !url.isLocalFile() || QFileInfo::exists(url.toLocalFile())) && !result.contains(url))
                result << url;
            /// remove match from internal text to avoid duplicates
            internalText = internalText.left(pos) + internalText.mid(pos + match.length());
        }

        /// explicitly check URL entry, may be an URL even if http:// or alike is missing
        pos = 0;
        QRegularExpressionMatch domainNameRegExpMatch;
        while ((domainNameRegExpMatch = KBibTeX::domainNameRegExp.match(internalText, pos)).hasMatch()) {
            pos = domainNameRegExpMatch.capturedStart(0);
            int pos2 = internalText.indexOf(QStringLiteral(" "), pos + 1);
            if (pos2 < 0) pos2 = internalText.length();
            QString match = internalText.mid(pos, pos2 - pos);
            const QUrl url(QStringLiteral("http://") + match); // FIXME what about HTTPS?
            if (url.isValid() && !result.contains(url))
                result << url;
            /// remove match from internal text to avoid duplicates
            internalText = internalText.left(pos) + internalText.mid(pos + match.length());
        }

        /// extract general file-like patterns
        pos = 0;
        QRegularExpressionMatch fileRegExpMatch;
        while ((fileRegExpMatch = KBibTeX::fileRegExp.match(internalText, pos)).hasMatch()) {
            pos = fileRegExpMatch.capturedStart(0);
            const QString match = fileRegExpMatch.captured(0);
            const QFileInfo fi(match);
            const QUrl url = QUrl::fromLocalFile(!match.startsWith(QStringLiteral("/")) && !match.startsWith(QStringLiteral("http")) && fi.isRelative() && !baseDirectory.isEmpty() ? baseDirectory + QStringLiteral("/") + match : match);
            if (url.isValid() && (testExistence == TestExistenceNo || QFileInfo::exists(url.toLocalFile())) && !result.contains(url))
                result << url;
            /// remove match from internal text to avoid duplicates
            internalText = internalText.left(pos) + internalText.mid(pos + match.length());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &risDataRow : risDataTable)
        QTest::newRow(risDataRow.label) << risDataRow.isValid << risDataRow.text;
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
#if KIO_VERSION < 0x054700 // < 5.71.0
            KRun::runUrl(QUrl(lineEditAuthorizationUrl->text()), QStringLiteral("text/html"), p, KRun::RunFlags());
#else // KIO_VERSION < 0x054700 // >= 5.71.0
            KIO::OpenUrlJob *job = new KIO::OpenUrlJob(QUrl(lineEditAuthorizationUrl->text()), QStringLiteral("text/html"));
            job->setUiDelegate(new KIO::JobUiDelegate(KJobUiDelegate::AutoHandlingEnabled, o));
            job->start();
#endif // KIO_VERSION < 0x054700
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Value &value : chosenValues) {
                    if (PlainTextValue::text(value) == text)
                        return Qt::Checked;
                }
```

#### AUTO 


```{c}
const auto respectingQuotationMarksAuthor = splitRespectingQuotationMarks(query[queryKeyAuthor]);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                typeChanged(KBibTeX::TypeFlag::Person);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (EntryClique *entryClique : entryCliques) {
        /// Avoid adding fields 20 lines below
        /// which have been remove (not added) 10 lines below
        QSet<QString> coveredFields;

        Entry *mergedEntry = new Entry(QString(), QString());
        const auto fieldList = entryClique->fieldList();
        for (const auto &field : fieldList) {
            coveredFields << field;
            if (field == QStringLiteral("^id"))
                mergedEntry->setId(PlainTextValue::text(entryClique->chosenValue(field)));
            else if (field == QStringLiteral("^type"))
                mergedEntry->setType(PlainTextValue::text(entryClique->chosenValue(field)));
            else {
                Value combined;
                const auto chosenValues = entryClique->chosenValues(field);
                for (const Value &v : chosenValues) {
                    combined.append(v);
                }
                if (!combined.isEmpty())
                    mergedEntry->insert(field, combined);
            }
        }

        bool actuallyMerged = false;
        int preferredInsertionRow = -1;
        const auto entryList = entryClique->entryList();
        for (const auto &entry : entryList) {
            /// if merging entries with identical ids, the merged entry will not yet have an id (is null)
            if (mergedEntry->id().isEmpty())
                mergedEntry->setId(entry->id());
            /// if merging entries with identical types, the merged entry will not yet have an type (is null)
            if (mergedEntry->type().isEmpty())
                mergedEntry->setType(entry->type());

            /// add all other fields not covered by user selection
            /// those fields did only occur in one entry (no conflict)
            /// may add a lot of bloat to merged entry
            if (entryClique->isEntryChecked(entry)) {
                actuallyMerged = true;
                for (Entry::ConstIterator it = entry->constBegin(); it != entry->constEnd(); ++it)
                    if (!mergedEntry->contains(it.key()) && !coveredFields.contains(it.key())) {
                        mergedEntry->insert(it.key(), it.value());
                        coveredFields << it.key();
                    }
                const int row = fileModel->row(entry);
                if (preferredInsertionRow < 0) preferredInsertionRow = row;
                fileModel->removeRow(row);
            }
        }

        if (actuallyMerged) {
            if (preferredInsertionRow < 0) preferredInsertionRow = fileModel->rowCount();
            fileModel->insertRow(QSharedPointer<Entry>(mergedEntry), preferredInsertionRow);
        } else
            delete mergedEntry;
        didMerge |= actuallyMerged;
    }
```

#### AUTO 


```{c}
static const auto pairs = QHash<int, const char *> {
        {static_cast<int>(BibUtils::Format::MODS), "MODS"},
        {static_cast<int>(BibUtils::Format::BibTeX), "BibTeX"},
        {static_cast<int>(BibUtils::Format::BibLaTeX), "BibLaTeX"},
        {static_cast<int>(BibUtils::Format::ISI), "ISI"},
        {static_cast<int>(BibUtils::Format::RIS), "RIS"},
        {static_cast<int>(BibUtils::Format::EndNote), "EndNote"},
        {static_cast<int>(BibUtils::Format::EndNoteXML), "EndNoteXML"},
        {static_cast<int>(BibUtils::Format::ADS), "ADS"},
        {static_cast<int>(BibUtils::Format::WordBib), "WordBib"},
        {static_cast<int>(BibUtils::Format::Copac), "Copac"},
        {static_cast<int>(BibUtils::Format::Med), "Med"}
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (ElementWidget *elementWidget : const_cast<const WidgetList &>(widgets)) {
            elementWidget->showReqOptWidgets(forceVisible, tempEntry->type());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : urlList) {
                bool isLocal = isLocalOrRelative(url);
                anyRemote |= !isLocal;
                if (!onlyLocalFilesButton->isChecked() && !isLocal) continue;

                KIO::StatJob *job = KIO::stat(url, KIO::StatJob::SourceSide, 3, KIO::HideProgressInfo);
                runningJobs << job;
                KJobWidgets::setWindow(job, p);
                connect(job, &KIO::StatJob::result, p, &DocumentPreview::statFinished);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &keyword : const_cast<const QStringList &>(keywords))
        forCaseInsensitiveSorting.insert(keyword.toLower(), keyword);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &propertyKey : propertyKeys)
            properties.insert(propertyKey, other.d->properties[propertyKey]);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &text : titleWords)
            queryFragments.append(text + QStringLiteral("[Title]"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const DotlessIJCharacter &dotlessIJCharacter : dotlessIJCharacters)
                    if ((dotlessIJCharacter.direction & DirectionCommandToUnicode) && dotlessIJCharacter.letter == input[i + 3 + skipSpaces] && dotlessIJCharacter.modifier == input[i + 1]) {
                        output.append(QChar(dotlessIJCharacter.unicode));
                        found = true;
                        break;
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto *fd : const_cast<const BibTeXFields &>(*bf))
            if (fd->upperCamelCaseAlt.isEmpty())
                fielddescs.insert(fd->label, fd->upperCamelCase);
```

#### LAMBDA EXPRESSION 


```{c}
[&gotErrors](const FileImporter::MessageSeverity messageSeverity, const QString &messageText) {
        gotErrors |= messageSeverity >= FileImporter::SeverityError;
        Q_UNUSED(messageText)
        //qCDebug(LOG_KBIBTEX_TEST)<<"FileImporterBibTeX issues message during 'partialBibTeXInput' test: "<<messageText;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto *fd : const_cast<const BibTeXFields &>(*this)) {
        if (fd->upperCamelCase.toLower() == iName && fd->upperCamelCaseAlt.isEmpty())
            return fd;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &valueItem : value) {
        Value v;
        v.append(valueItem);
        // Re-use existing FieldInput widgets and only create new ones if necessary
        FieldLineEdit *fieldLineEdit = pos < d->lineEditList.count() ? d->lineEditList.at(pos) : addFieldLineEdit();
        fieldLineEdit->setFile(d->file);
        fieldLineEdit->reset(v);
        ++pos;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[errorLog, &process] {
            QByteArray stdout = process.readAllStandardOutput();
            QTextStream ts(&stdout);
            while (!ts.atEnd())
                errorLog->append(ts.readLine());
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            addToken(ttAuthor, locAtBottom);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &entry : const_cast<const QVector<QSharedPointer<Entry> > &>(listOfEntries)) {
        QApplication::instance()->processEvents();
        if (progressDlg->wasCanceled()) {
            entryCliqueList.clear();
            break;
        }

        progressDlg->setValue(curProgress);
        emit currentProgress(curProgress);
        /// ... and find a "clique" of entries where it will match, i.e. distance is below sensitivity

        /// assume current entry will match in no clique
        bool foundClique = false;

        /// go through all existing cliques
        for (QVector<EntryClique *>::Iterator cit = entryCliqueList.begin(); cit != entryCliqueList.end(); ++cit) {
            /// check distance between current entry and clique's first entry
            if (d->entryDistance(entry.data(), (*cit)->entryList().constFirst().data()) < d->sensitivity) {
                /// if distance is below sensitivity, add current entry to clique
                foundClique = true;
                (*cit)->addEntry(entry);
                break;
            }

            QApplication::instance()->processEvents();
            if (progressDlg->wasCanceled()) {
                entryCliqueList.clear();
                break;
            }
        }

        if (!progressDlg->wasCanceled() && !foundClique) {
            /// no clique matched to current entry, so create and add new clique
            /// consisting only of the current entry
            EntryClique *newClique = new EntryClique();
            newClique->addEntry(entry);
            entryCliqueList << newClique;
        }

        curProgress += progressDelta;
        ++progressDelta;
        progressDlg->setValue(curProgress);

        emit currentProgress(curProgress);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &token : tokens) {
        /// Position where comma was found, or -1 if no comma in token
        int p = -1;
        if (commaCount < 2) {
            /// Only check if token contains comma
            /// if no comma was found before
            int bracketCounter = 0;
            for (int i = 0; i < token.length(); ++i) {
                /// Consider opening curly brackets
                if (token[i] == QChar('{')) ++bracketCounter;
                /// Consider closing curly brackets
                else if (token[i] == QChar('}')) --bracketCounter;
                /// Only if outside any open curly bracket environments
                /// consider comma characters
                else if (bracketCounter == 0 && token[i] == QChar(',')) {
                    /// Memorize comma's position and break from loop
                    p = i;
                    break;
                } else if (bracketCounter < 0) {
                    /// Should never happen: more closing brackets than opening ones
                    qCWarning(LOG_KBIBTEX_IO) << "Opening and closing brackets do not match near line" << line_number;
                    if (parent != nullptr)
                        QMetaObject::invokeMethod(parent, "message", Qt::DirectConnection, QGenericReturnArgument(), Q_ARG(FileImporter::MessageSeverity, SeverityWarning), Q_ARG(QString, QString(QStringLiteral("Opening and closing brackets do not match near line %1")).arg(line_number)));
                }
            }
        }

        if (p >= 0) {
            if (commaCount == 0) {
                if (p > 0) partA.append(token.left(p));
                if (p < token.length() - 1) partB.append(token.mid(p + 1));
            } else if (commaCount == 1) {
                if (p > 0) partB.append(token.left(p));
                if (p < token.length() - 1) partC.append(token.mid(p + 1));
            }
            ++commaCount;
        } else if (commaCount == 0)
            partA.append(token);
        else if (commaCount == 1)
            partB.append(token);
        else if (commaCount == 2)
            partC.append(token);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &suggestionBase : formatIdList) {
        bool isDefault = suggestionBase == defaultSuggestion;
        QString suggestion = suggestionBase;

        /// Test for duplicate ids, use fallback ids with numeric suffix
        if (m_file != nullptr && m_file->containsKey(suggestion)) {
            int suffix = 2;
            while (m_file->containsKey(suggestion = suggestionBase + QChar('_') + QString::number(suffix)))
                ++suffix;
        }

        /// Keep track of shown suggestions to avoid duplicates
        if (knownIdSuggestion.contains(suggestion)) continue;
        else knownIdSuggestion.insert(suggestion);

        /// Create action for suggestion, use icon depending if default or not
        QAction *suggestionAction = new QAction(suggestion, suggestionsMenu);
        suggestionAction->setIcon(QIcon::fromTheme(isDefault ? QStringLiteral("favorites") : QStringLiteral("view-filter")));

        /// Mesh action into GUI
        suggestionsMenu->addAction(suggestionAction);
        connect(suggestionAction, &QAction::triggered, this, &ReferenceWidget::insertSuggestionFromAction);
        /// Remember suggestion string for time when action gets triggered
        suggestionAction->setProperty(PropertyIdSuggestion, suggestion);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &valueItem : value) {
        Value v;
        v.append(valueItem);
        FieldLineEdit *fieldLineEdit = addFieldLineEdit();
        fieldLineEdit->setFile(d->file);
        fieldLineEdit->reset(v);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const EncoderLaTeXEscapedCharacter &encoderLaTeXEscapedCharacter : encoderLaTeXEscapedCharacters) {
        /// Check if this row's modifier is already known
        bool knownModifier = false;
        int j;
        for (j = lookupTableCount - 1; j >= 0; --j) {
            knownModifier |= lookupTable[j]->modifier == encoderLaTeXEscapedCharacter.modifier;
            if (knownModifier) break;
        }

        if (!knownModifier) {
            /// Ok, this row's modifier appeared for the first time,
            /// therefore initialize memory structure, i.e. row in lookupTable
            lookupTable[lookupTableCount] = new EncoderLaTeXEscapedCharacterLookupTableRow;
            lookupTable[lookupTableCount]->modifier = encoderLaTeXEscapedCharacter.modifier;
            /// If no special character is known for a letter+modifier
            /// combination, fall back using the ASCII character only
            for (ushort k = 0; k < 26; ++k) {
                lookupTable[lookupTableCount]->unicode[k] = QChar(QLatin1Char('A').unicode() + k);
                lookupTable[lookupTableCount]->unicode[k + 26] = QChar(QLatin1Char('a').unicode() + k);
            }
            for (ushort k = 0; k < 10; ++k)
                lookupTable[lookupTableCount]->unicode[k + 52] = QChar(QLatin1Char('0').unicode() + k);
            j = lookupTableCount;
            ++lookupTableCount;
        }

        /// Add the letter as of the current row in encoderLaTeXEscapedCharacters
        /// into Unicode char array in the current modifier's row in the lookup table.
        int pos = -1;
        if ((pos = asciiLetterOrDigitToPos(encoderLaTeXEscapedCharacter.letter)) >= 0)
            lookupTable[j]->unicode[pos] = QChar(encoderLaTeXEscapedCharacter.unicode);
        else
            qCWarning(LOG_KBIBTEX_IO) << "Cannot handle letter " << encoderLaTeXEscapedCharacter.letter;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : actionList) {
                bool ok = false;
                int ac = (int)action->data().toInt(&ok);
                if (ok && ac == col) {
                    action->setChecked(!headerProperty->columns[col].isHidden);
                    break;
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            addToken(ttType, locAtTop);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &flagListItem : flagListItems)
                htmlText.append(QString(QStringLiteral("<li>%1</li>")).arg(flagListItem));
```

#### RANGE FOR STATEMENT 


```{c}
for (QSharedPointer<Element> element : bibtexFile) {
        /// Process only entries, not comments, preambles or macros
        QSharedPointer<Entry> entry = element.dynamicCast<Entry>();
        if (entry.isNull()) continue;

        /// Retrieve set of URLs per entry and add to set of URLS to be checked
        const QSet<QUrl> thisEntryUrls = FileInfo::entryUrls(entry, bibtexFile.property(File::Url).toUrl(), FileInfo::TestExistenceNo);
        for (const QUrl &u : thisEntryUrls)
            d->urlsToCheck.insert(u); ///< better?
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &token : tokenList) {
        QString text;
        if (token[0] == 'a' || token[0] == 'A' || token[0] == 'z') {
            struct IdSuggestionTokenInfo info = evalToken(token.mid(1));
            if (token[0] == 'a')
                info.startWord = info.endWord = 0;
            else if (token[0] == 'z') {
                info.startWord = 1;
                info.endWord = std::numeric_limits<int>::max();
            }
            text = formatAuthorRange(info.startWord, info.endWord, info.lastWord);

            if (info.len > 0 && info.len < std::numeric_limits<int>::max()) text.append(i18np(", but only first letter of each last name", ", but only first %1 letters of each last name", info.len));

            switch (info.caseChange) {
            case IdSuggestions::ccToUpper:
                text.append(i18n(", in upper case"));
                break;
            case IdSuggestions::ccToLower:
                text.append(i18n(", in lower case"));
                break;
            case IdSuggestions::ccToCamelCase:
                text.append(i18n(", in CamelCase"));
                break;
            case IdSuggestions::ccNoChange:
                break;
            }

            if (!info.inBetween.isEmpty()) text.append(i18n(", with '%1' in between", info.inBetween));
        }
        else if (token[0] == 'y')
            text.append(i18n("Year (2 digits)"));
        else if (token[0] == 'Y')
            text.append(i18n("Year (4 digits)"));
        else if (token[0] == 't' || token[0] == 'T') {
            struct IdSuggestionTokenInfo info = evalToken(token.mid(1));
            text.append(i18n("Title"));
            if (info.startWord == 0 && info.endWord < std::numeric_limits<int>::max())
                text.append(i18np(", but only the first word", ", but only first %1 words", info.endWord + 1));
            else if (info.startWord > 0 && info.endWord == std::numeric_limits<int>::max())
                text.append(i18n(", but only starting from word %1", info.startWord + 1));
            else if (info.startWord > 0 && info.endWord < std::numeric_limits<int>::max())
                text.append(i18n(", but only from word %1 to word %2", info.startWord + 1, info.endWord + 1));
            if (info.len > 0 && info.len < std::numeric_limits<int>::max())
                text.append(i18np(", but only first letter of each word", ", but only first %1 letters of each word", info.len));

            switch (info.caseChange) {
            case IdSuggestions::ccToUpper:
                text.append(i18n(", in upper case"));
                break;
            case IdSuggestions::ccToLower:
                text.append(i18n(", in lower case"));
                break;
            case IdSuggestions::ccToCamelCase:
                text.append(i18n(", in CamelCase"));
                break;
            case IdSuggestions::ccNoChange:
                break;
            }

            if (!info.inBetween.isEmpty()) text.append(i18n(", with '%1' in between", info.inBetween));
            if (token[0] == 'T') text.append(i18n(", small words removed"));
        }
        else if (token[0] == 'j') {
            struct IdSuggestionTokenInfo info = evalToken(token.mid(1));
            text.append(i18n("Journal"));
            if (info.len > 0 && info.len < std::numeric_limits<int>::max())
                text.append(i18np(", but only first letter of each word", ", but only first %1 letters of each word", info.len));
            switch (info.caseChange) {
            case IdSuggestions::ccToUpper:
                text.append(i18n(", in upper case"));
                break;
            case IdSuggestions::ccToLower:
                text.append(i18n(", in lower case"));
                break;
            case IdSuggestions::ccToCamelCase:
                text.append(i18n(", in CamelCase"));
                break;
            case IdSuggestions::ccNoChange:
                break;
            }
        } else if (token[0] == 'e') {
            struct IdSuggestionTokenInfo info = evalToken(token.mid(1));
            text.append(i18n("Type"));
            if (info.len > 0 && info.len < std::numeric_limits<int>::max())
                text.append(i18np(", but only first letter of each word", ", but only first %1 letters of each word", info.len));
            switch (info.caseChange) {
            case IdSuggestions::ccToUpper:
                text.append(i18n(", in upper case"));
                break;
            case IdSuggestions::ccToLower:
                text.append(i18n(", in lower case"));
                break;
            case IdSuggestions::ccToCamelCase:
                text.append(i18n(", in CamelCase"));
                break;
            default:
                break;
            }
        } else if (token[0] == 'v') {
            text.append(i18n("Volume"));
        } else if (token[0] == 'p') {
            text.append(i18n("First page number"));
        } else if (token[0] == '"')
            text.append(i18n("Text: '%1'", token.mid(1)));
        else
            text.append("?");

        result.append(text);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &text : authorWords) {
            static const QString authorTemplate = QStringLiteral("srw.au+all+\"%1\"");
            queryFragments.append(authorTemplate.arg(text));
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, recentlyOpenURL]() {
        /// In case there is at least one file marked as 'open' but it is not yet actually open,
        /// set it as current file now. The file to be opened (identified by URL) should be
        /// preferably the file that was actively open at the end of last KBibTeX session.
        /// Slightly delaying the actually opening of files is necessary to give precendence
        /// to bibliography files passed as command line arguments (see program.cpp) over files
        /// that where open when the previous KBibTeX session was quit.
        /// See KDE bug 417164.
        /// TODO still necessary to refactor the whole 'file opening' control flow to avoid hacks like this one
        if (d->currentFileInfo == nullptr) {
            OpenFileInfo *ofiToUse = nullptr;
            /// Go over the list of files that are flagged as 'open' ...
            for (auto *ofi : const_cast<const OpenFileInfoManager::OpenFileInfoList &>(d->openFileInfoList))
                if (ofi->flags().testFlag(OpenFileInfo::StatusFlag::Open) && (ofiToUse == nullptr || (recentlyOpenURL.isValid() && ofi->url() == recentlyOpenURL)))
                    ofiToUse = ofi;
            if (ofiToUse != nullptr)
                setCurrentFile(ofiToUse);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : mil)
            file->append(d->view->fileModel()->element(d->view->sortFilterProxyModel()->mapToSource(index).row()));
```

#### RANGE FOR STATEMENT 


```{c}
for (const EncoderLaTeXSymbolSequence &encoderLaTeXSymbolSequence : encoderLaTeXSymbolSequences)
                    if (encoderLaTeXSymbolSequence.unicode == c.unicode() && (encoderLaTeXSymbolSequence.direction & DirectionUnicodeToCommand)) {
                        for (int l = 0; l < encoderLaTeXSymbolSequence.latex.length(); ++l)
                            output.append(encoderLaTeXSymbolSequence.latex[l]);
                        found = true;
                        break;
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &keyStem : keyStart)
        for (int i = 1; i < 32; ++i) {  /// FIXME replace number by constant
            const QString key = i > 1 ? keyStem + QString::number(i) : keyStem;
            entry->remove(key);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : mil)
            workingSetFile->append(d->view->fileModel()->element(d->view->sortFilterProxyModel()->mapToSource(index).row()));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &item : charmappingdataxml)
        result.replace(item.unicode, item.xml);
```

#### RANGE FOR STATEMENT 


```{c}
for (const EncoderLaTeXEscapedCharacter &encoderLaTeXEscapedCharacter : encoderLaTeXEscapedCharacters)
                    if ((encoderLaTeXEscapedCharacter.direction & DirectionUnicodeToCommand) && encoderLaTeXEscapedCharacter.unicode == c.unicode()) {
                        // FIXME Find a better solution, as the curly brackets are unnecessary in some situations
                        // e.g. '{\"a}{\"a}' should better be '{\"a\"a}'
                        const QString formatString = isAsciiLetter(encoderLaTeXEscapedCharacter.modifier) ? QStringLiteral("{\\%1 %2}") : QStringLiteral("{\\%1%2}");
                        output.append(formatString.arg(encoderLaTeXEscapedCharacter.modifier).arg(encoderLaTeXEscapedCharacter.letter));
                        found = true;
                        break;
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &field : const_cast<const QStringList &>(urlFields)) {
        if (entry.contains(field)) {
            const QString fieldText = PlainTextValue::text(entry.value(field));
            int p = -1;
            while ((p = KBibTeX::doiRegExp.indexIn(fieldText, p + 1)) >= 0)
                d->queueUrl(QUrl(FileInfo::doiUrlPrefix() + KBibTeX::doiRegExp.cap(0)), fieldText, Entry::ftDOI, maxDepth);

            p = -1;
            while ((p = KBibTeX::urlRegExp.indexIn(fieldText, p + 1)) >= 0)
                d->queueUrl(QUrl(KBibTeX::urlRegExp.cap(0)), searchWords, Entry::ftUrl, maxDepth);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &valueItem : value) {
        QSharedPointer<const MacroKey> macroKey = valueItem.dynamicCast<const MacroKey>();
        if (!macroKey.isNull()) {
            if (isOpen) result.append(d->stringCloseDelimiter);
            isOpen = false;
            if (!result.isEmpty()) result.append(" # ");
            result.append(macroKey->text());
            prev = macroKey;
        } else {
            QSharedPointer<const PlainText> plainText = valueItem.dynamicCast<const PlainText>();
            if (!plainText.isNull()) {
                QString textBody = applyEncoder(plainText->text(), useLaTeXEncoding);
                if (!isOpen) {
                    if (!result.isEmpty()) result.append(" # ");
                    result.append(d->stringOpenDelimiter);
                } else if (!prev.dynamicCast<const PlainText>().isNull())
                    result.append(' ');
                else if (!prev.dynamicCast<const Person>().isNull()) {
                    /// handle "et al." i.e. "and others"
                    result.append(" and ");
                } else {
                    result.append(d->stringCloseDelimiter).append(" # ").append(d->stringOpenDelimiter);
                }
                isOpen = true;

                if (d->stringOpenDelimiter == QLatin1Char('"'))
                    d->protectQuotationMarks(textBody);
                result.append(textBody);
                prev = plainText;
            } else {
                QSharedPointer<const VerbatimText> verbatimText = valueItem.dynamicCast<const VerbatimText>();
                if (!verbatimText.isNull()) {
                    QString textBody = verbatimText->text();
                    if (!isOpen) {
                        if (!result.isEmpty()) result.append(" # ");
                        result.append(d->stringOpenDelimiter);
                    } else if (!prev.dynamicCast<const VerbatimText>().isNull()) {
                        const QString keyToLower(key.toLower());
                        if (keyToLower.startsWith(Entry::ftUrl) || keyToLower.startsWith(Entry::ftLocalFile) || keyToLower.startsWith(Entry::ftFile) || keyToLower.startsWith(Entry::ftDOI))
                            /// Filenames and alike have be separated by a semicolon,
                            /// as a plain comma may be part of the filename or URL
                            result.append(QStringLiteral("; "));
                        else
                            result.append(' ');
                    } else {
                        result.append(d->stringCloseDelimiter).append(" # ").append(d->stringOpenDelimiter);
                    }
                    isOpen = true;

                    if (d->stringOpenDelimiter == QLatin1Char('"'))
                        d->protectQuotationMarks(textBody);
                    result.append(textBody);
                    prev = verbatimText;
                } else {
                    QSharedPointer<const Person> person = valueItem.dynamicCast<const Person>();
                    if (!person.isNull()) {
                        QString firstName = person->firstName();
                        if (!firstName.isEmpty() && d->requiresPersonQuoting(firstName, false))
                            firstName = firstName.prepend("{").append("}");

                        QString lastName = person->lastName();
                        if (!lastName.isEmpty() && d->requiresPersonQuoting(lastName, true))
                            lastName = lastName.prepend("{").append("}");

                        QString suffix = person->suffix();

                        /// Fall back and enforce comma-based name formatting
                        /// if name contains a suffix like "Jr."
                        /// Otherwise name could not be parsed again reliable
                        const QString pnf = suffix.isEmpty() ? d->personNameFormatting : Preferences::personNameFormatLastFirst;
                        QString thisName = applyEncoder(Person::transcribePersonName(pnf, firstName, lastName, suffix), useLaTeXEncoding);

                        if (!isOpen) {
                            if (!result.isEmpty()) result.append(" # ");
                            result.append(d->stringOpenDelimiter);
                        } else if (!prev.dynamicCast<const Person>().isNull())
                            result.append(" and ");
                        else {
                            result.append(d->stringCloseDelimiter).append(" # ").append(d->stringOpenDelimiter);
                        }
                        isOpen = true;

                        if (d->stringOpenDelimiter == QLatin1Char('"'))
                            d->protectQuotationMarks(thisName);
                        result.append(thisName);
                        prev = person;
                    } else {
                        QSharedPointer<const Keyword> keyword = valueItem.dynamicCast<const Keyword>();
                        if (!keyword.isNull()) {
                            QString textBody = applyEncoder(keyword->text(), useLaTeXEncoding);
                            if (!isOpen) {
                                if (!result.isEmpty()) result.append(" # ");
                                result.append(d->stringOpenDelimiter);
                            } else if (!prev.dynamicCast<const Keyword>().isNull())
                                result.append(d->listSeparator);
                            else {
                                result.append(d->stringCloseDelimiter).append(" # ").append(d->stringOpenDelimiter);
                            }
                            isOpen = true;

                            if (d->stringOpenDelimiter == QLatin1Char('"'))
                                d->protectQuotationMarks(textBody);
                            result.append(textBody);
                            prev = keyword;
                        }
                    }
                }
            }
        }
        prev = valueItem;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &element : const_cast<const File &>(*bibtexFile)) {
                    QSharedPointer<Entry> entry = element.dynamicCast<Entry>();
                    if (!entry.isNull()) {
                        /// Now check whether the entry contains the user-provided title fragments or free-text fragments
                        const QString title = entry->contains(Entry::ftTitle) ? PlainTextValue::text(entry->value(Entry::ftTitle)).toLower() : QString();
                        bool allTitleFragmentsContained = true;
                        for (const QString &titleFragment : const_cast<const QSet<QString> &>(d->titleFragments))
                            allTitleFragmentsContained &= title.contains(titleFragment);
                        const QString freeText = title;
                        bool allFreeTextFragmentsContained = true;
                        for (const QString &freeTextFragment : const_cast<const QSet<QString> &>(d->freeTextFragments))
                            allFreeTextFragmentsContained &= freeText.contains(freeTextFragment);

                        if (allTitleFragmentsContained && allFreeTextFragmentsContained) {
                            publishEntry(entry);
                            --d->numAwaitedResults;
                            if (d->numAwaitedResults <= 0)
                                break;
                        }
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QChar &c : ninput) {
        /// Get byte sequence representing current character in chosen codec
        const QByteArray cba = destinationCodec->fromUnicode(c);
        if (destinationCodec->canEncode(c) && (c == QChar(0x003f /** question mark */) || cba.size() != 1 || cba[0] != 0x3f /** question mark */)) {
            /// Codec claims that it can encode current character, but some codecs
            /// still cannot encode character and simply return a question mark, so
            /// only accept question marks as encoding result if original character
            /// was question mark (assuming all codecs can encode question marks).
            result.append(cba);
        } else {
            /// Chosen codec can NOT encode current Unicode character, so try to use
            /// 'LaTeX encoder', which may translate 0x00c5 (A with ring above) into
            /// '\AA'. LaTeX encoder returns UTF-8 representation if given character
            /// cannot be encoded
            result.append(laTeXEncoder.encode(QString(c), Encoder::TargetEncoding::ASCII).toUtf8());
        }
    }
```

#### AUTO 


```{c}
const auto chromeVersionPatch = randomGeneratorGlobalBounded(53, 673);
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : const_cast<const QList<QAction *> &>(d->openMenuActions)) {
        d->actionOpenMenu->removeAction(action);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[ = ]() {
                    d->requestZoteroUrl(nextPage);
                }
```

#### AUTO 


```{c}
const auto firefoxVersionMajor = randomGeneratorGlobalBounded(69, 74);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : urlList) {
                    if (url.isLocalFile()) continue; ///< skip local files

                    /// Build a nice menu item (label, icon, ...)
                    const QString prettyUrl = url.toDisplayString();
                    QMimeDatabase db;
                    QAction *action = new QAction(QIcon::fromTheme(db.mimeTypeForUrl(url).iconName()), prettyUrl, p);
                    action->setData(prettyUrl);
                    action->setToolTip(prettyUrl);
                    /// Register action at signal handler to open URL when triggered
                    connect(action, &QAction::triggered, signalMapperViewDocument, static_cast<void(QSignalMapper::*)()>(&QSignalMapper::map));
                    signalMapperViewDocument->setMapping(action, action);
                    signalMapperViewDocumentSenders.insert(action);
                    viewDocumentMenu->addAction(action);
                    /// Memorize first action
                    if (firstAction == nullptr) firstAction = action;
                }
```

#### AUTO 


```{c}
const auto fl = fieldList();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &element : const_cast<const File &>(*file))
            if (Macro::isMacro(*element))
                dummyFile << element;
```

#### LAMBDA EXPRESSION 


```{c}
[this, reply]() {
            const QUrl url = reply->url();
            if (reply->error() != QNetworkReply::NoError) {
                /// Instead of an 'emit' ...
                QMetaObject::invokeMethod(p, "urlChecked", Qt::DirectConnection, QGenericReturnArgument(), Q_ARG(QUrl, url), Q_ARG(UrlChecker::Status, UrlChecker::NetworkError), Q_ARG(QString, reply->errorString()));
                qCWarning(LOG_KBIBTEX_NETWORKING) << "NetworkError:" << reply->errorString() << url.toDisplayString();
            } else {
                const QByteArray data = reply->read(1024);
                if (data.isEmpty()) {
                    /// Instead of an 'emit' ...
                    QMetaObject::invokeMethod(p, "urlChecked", Qt::DirectConnection, QGenericReturnArgument(), Q_ARG(QUrl, url), Q_ARG(UrlChecker::Status, UrlChecker::UnknownError), Q_ARG(QString, QStringLiteral("No data received")));
                    qCWarning(LOG_KBIBTEX_NETWORKING) << "UnknownError: No data received" << url.toDisplayString();
                } else {
                    const QString filename = url.fileName().toLower();
                    const bool filenameSuggestsHTML = filename.isEmpty() || filename.endsWith(QStringLiteral(".html")) || filename.endsWith(QStringLiteral(".htm"));
                    const bool filenameSuggestsPDF =  filename.endsWith(QStringLiteral(".pdf"));
                    const bool filenameSuggestsPostScript =  filename.endsWith(QStringLiteral(".ps"));
                    const bool containsHTML = data.contains("<!DOCTYPE HTML") || data.contains("<html") || data.contains("<HTML") || data.contains("<body") || data.contains("<body");
                    const bool containsPDF = data.startsWith("%PDF");
                    const bool containsPostScript = data.startsWith("%!");
                    if (filenameSuggestsPDF && containsPDF) {
                        /// Instead of an 'emit' ...
                        QMetaObject::invokeMethod(p, "urlChecked", Qt::DirectConnection, QGenericReturnArgument(), Q_ARG(QUrl, url), Q_ARG(UrlChecker::Status, UrlChecker::UrlValid), Q_ARG(QString, QString()));
                        qCWarning(LOG_KBIBTEX_NETWORKING) << "UrlValid: Looks and smells like a PDF" << url.toDisplayString();
                    } else if (filenameSuggestsPostScript && containsPostScript) {
                        /// Instead of an 'emit' ...
                        QMetaObject::invokeMethod(p, "urlChecked", Qt::DirectConnection, QGenericReturnArgument(), Q_ARG(QUrl, url), Q_ARG(UrlChecker::Status, UrlChecker::UrlValid), Q_ARG(QString, QString()));
                        qCWarning(LOG_KBIBTEX_NETWORKING) << "UrlValid: Looks and smells like a PostScript" << url.toDisplayString();
                    } else if (containsHTML) {
                        static const QRegularExpression error404(QStringLiteral("\\b404\\b"));
                        const QRegularExpressionMatch error404match = error404.match(data);
                        if (error404match.hasMatch()) {
                            /// Instead of an 'emit' ...
                            QMetaObject::invokeMethod(p, "urlChecked", Qt::DirectConnection, QGenericReturnArgument(), Q_ARG(QUrl, url), Q_ARG(UrlChecker::Status, UrlChecker::Error404), Q_ARG(QString, QStringLiteral("Got error 404")));
                            qCWarning(LOG_KBIBTEX_NETWORKING) << "Error404" << url.toDisplayString();
                        } else if (filenameSuggestsHTML) {
                            /// Instead of an 'emit' ...
                            QMetaObject::invokeMethod(p, "urlChecked", Qt::DirectConnection, QGenericReturnArgument(), Q_ARG(QUrl, url), Q_ARG(UrlChecker::Status, UrlChecker::UrlValid), Q_ARG(QString, QString()));
                            qCWarning(LOG_KBIBTEX_NETWORKING) << "UrlValid: Looks and smells like a HTML" << url.toDisplayString();
                        } else {
                            /// Instead of an 'emit' ...
                            QMetaObject::invokeMethod(p, "urlChecked", Qt::DirectConnection, QGenericReturnArgument(), Q_ARG(QUrl, url), Q_ARG(UrlChecker::Status, UrlChecker::UnexpectedFileType), Q_ARG(QString, QStringLiteral("Filename's extension does not match content")));
                            qCWarning(LOG_KBIBTEX_NETWORKING) << "NotExpectedFileType (HTML): Filename's extension does not match content" << url.toDisplayString();
                        }
                    } else if (filenameSuggestsPDF != containsPDF) {
                        /// Instead of an 'emit' ...
                        QMetaObject::invokeMethod(p, "urlChecked", Qt::DirectConnection, QGenericReturnArgument(), Q_ARG(QUrl, url), Q_ARG(UrlChecker::Status, UrlChecker::UnexpectedFileType), Q_ARG(QString, QStringLiteral("Filename's extension does not match content")));
                        qCWarning(LOG_KBIBTEX_NETWORKING) << "NotExpectedFileType (PDF): Filename's extension does not match content" << url.toDisplayString();
                    } else if (filenameSuggestsPostScript != containsPostScript) {
                        /// Instead of an 'emit' ...
                        QMetaObject::invokeMethod(p, "urlChecked", Qt::DirectConnection, QGenericReturnArgument(), Q_ARG(QUrl, url), Q_ARG(UrlChecker::Status, UrlChecker::UnexpectedFileType), Q_ARG(QString, QStringLiteral("Filename's extension does not match content")));
                        qCWarning(LOG_KBIBTEX_NETWORKING) << "NotExpectedFileType (PostScript): Filename's extension does not match content" << url.toDisplayString();
                    } else {
                        /// Instead of an 'emit' ...
                        QMetaObject::invokeMethod(p, "urlChecked", Qt::DirectConnection, QGenericReturnArgument(), Q_ARG(QUrl, url), Q_ARG(UrlChecker::Status, UrlChecker::UrlValid), Q_ARG(QString, QString()));
                        qCWarning(LOG_KBIBTEX_NETWORKING) << "UrlValid: Cannot see any issued with this URL" << url.toDisplayString();
                    }
                }
            }
            busyCounter.deref();
            queueMoreOrFinish();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : urlList) {
                    if (url.isLocalFile()) continue; ///< skip local files

                    /// Build a nice menu item (label, icon, ...)
                    const QString prettyUrl = url.toDisplayString();
                    QAction *action = new QAction(QIcon::fromTheme(FileInfo::mimeTypeForUrl(url).iconName()), prettyUrl, p);
                    action->setData(url);
                    action->setToolTip(prettyUrl);
                    /// Open URL when action is triggered
                    connect(action, &QAction::triggered, p, [this, url]() {
                        elementViewDocumentMenu(url);
                    });
                    viewDocumentMenu->addAction(action);
                    /// Memorize first action
                    if (firstAction == nullptr) firstAction = action;
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &text : fileList) {
        internalText = text;

        /// If testing for the actual existence of a filename found in the text ...
        if (testExistence == TestExistenceYes) {
            /// If a base directory (e.g. the location of the parent .bib file) is given
            /// and the potential filename fragment is NOT an absolute path, ...
            if (internalText.startsWith(QStringLiteral("~") + QDir::separator())) {
                const QString fullFilename = QDir::homePath() + internalText.mid(1);
                const QFileInfo fileInfo(fullFilename);
                const QUrl url = QUrl::fromLocalFile(fileInfo.canonicalFilePath());
                if (fileInfo.exists() && fileInfo.isFile() && url.isValid() && !result.contains(url)) {
                    result << url;
                    /// Stop searching for URLs or filenames in current internal text
                    continue;
                }
            } else if (!baseDirectory.isEmpty() &&
                    // TODO the following test assumes that absolute paths start
                    // with a dir separator, which may only be true on Unix/Linux,
                    // but not Windows. May be a test for 'first character is a letter,
                    // second is ":", third is "\"' may be necessary.
                    !internalText.startsWith(QDir::separator())) {
                /// To get the absolute path, prepend filename fragment with base directory
                const QString fullFilename = baseDirectory + QDir::separator() + internalText;
                const QFileInfo fileInfo(fullFilename);
                const QUrl url = QUrl::fromLocalFile(fileInfo.canonicalFilePath());
                if (fileInfo.exists() && fileInfo.isFile() && url.isValid() && !result.contains(url)) {
                    result << url;
                    /// Stop searching for URLs or filenames in current internal text
                    continue;
                }
            } else {
                /// Either the filename fragment is an absolute path OR no base directory
                /// was given (current working directory is assumed), ...
                const QFileInfo fileInfo(internalText);
                const QUrl url = QUrl::fromLocalFile(fileInfo.canonicalFilePath());
                if (fileInfo.exists() && fileInfo.isFile() && url.isValid() && !result.contains(url)) {
                    result << url;
                    /// stop searching for URLs or filenames in current internal text
                    continue;
                }
            }
        }

        /// extract URL from current field
        pos = 0;
        while ((pos = KBibTeX::urlRegExp.indexIn(internalText, pos)) != -1) {
            const QString match = KBibTeX::urlRegExp.cap(0);
            QUrl url(match);
            if (url.isValid() && (testExistence == TestExistenceNo || !url.isLocalFile() || QFileInfo::exists(url.toLocalFile())) && !result.contains(url))
                result << url;
            /// remove match from internal text to avoid duplicates
            internalText = internalText.left(pos) + internalText.mid(pos + match.length());
        }

        /// explicitly check URL entry, may be an URL even if http:// or alike is missing
        pos = 0;
        while ((pos = KBibTeX::domainNameRegExp.indexIn(internalText, pos)) > -1) {
            int pos2 = internalText.indexOf(QStringLiteral(" "), pos + 1);
            if (pos2 < 0) pos2 = internalText.length();
            QString match = internalText.mid(pos, pos2 - pos);
            QUrl url("http://" + match);
            if (url.isValid() && !result.contains(url))
                result << url;
            /// remove match from internal text to avoid duplicates
            internalText = internalText.left(pos) + internalText.mid(pos + match.length());
        }

        /// extract general file-like patterns
        pos = 0;
        while ((pos = KBibTeX::fileRegExp.indexIn(internalText, pos)) != -1) {
            QString match = KBibTeX::fileRegExp.cap(0);
            QUrl url(match);
            if (url.isValid() && (testExistence == TestExistenceNo || !url.isLocalFile() || QFileInfo::exists(url.toLocalFile())) && !result.contains(url))
                result << url;
            /// remove match from internal text to avoid duplicates
            internalText = internalText.left(pos) + internalText.mid(pos + match.length());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : list) {
        const QModelIndex mappedIndex = sfbfm->mapToSource(index);
        /// Selection may span over multiple columns;
        /// to avoid duplicate assignments, consider only column 1
        if (mappedIndex.column() == 1) {
            const int row = mappedIndex.row();
            QSharedPointer<Entry> entry = model->element(row).dynamicCast<Entry>();
            if (!entry.isNull()) {
                /// Clear old color entry
                bool modifying = entry->remove(Entry::ftColor) > 0;
                if (colorString != QStringLiteral("#000000")) { ///< black is a special color that means "no color"
                    /// Only if valid color was selected, set this color
                    Value v;
                    v.append(QSharedPointer<VerbatimText>(new VerbatimText(colorString)));
                    entry->insert(Entry::ftColor, v);
                    modifying = true;
                }
                if (modifying)
                    model->elementChanged(row);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &element : const_cast<const File &>(*file))
                fileModel->insertRow(element, fileView->model()->rowCount());
```

#### LAMBDA EXPRESSION 


```{c}
[ = ]() {
                requestZoteroUrl(internalUrl);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &token : tokens) {
        /// Position where comma was found, or -1 if no comma in token
        int p = -1;
        if (commaCount < 2) {
            /// Only check if token contains comma
            /// if no comma was found before
            int bracketCounter = 0;
            for (int i = 0; i < token.length(); ++i) {
                /// Consider opening curly brackets
                if (token[i] == QChar('{')) ++bracketCounter;
                /// Consider closing curly brackets
                else if (token[i] == QChar('}')) --bracketCounter;
                /// Only if outside any open curly bracket environments
                /// consider comma characters
                else if (bracketCounter == 0 && token[i] == QChar(',')) {
                    /// Memorize comma's position and break from loop
                    p = i;
                    break;
                } else if (bracketCounter < 0)
                    /// Should never happen: more closing brackets than opening ones
                    qCWarning(LOG_KBIBTEX_IO) << "Opening and closing brackets do not match!";
            }
        }

        if (p >= 0) {
            if (commaCount == 0) {
                if (p > 0) partA.append(token.left(p));
                if (p < token.length() - 1) partB.append(token.mid(p + 1));
            } else if (commaCount == 1) {
                if (p > 0) partB.append(token.left(p));
                if (p < token.length() - 1) partC.append(token.mid(p + 1));
            }
            ++commaCount;
        } else if (commaCount == 0)
            partA.append(token);
        else if (commaCount == 1)
            partB.append(token);
        else if (commaCount == 2)
            partC.append(token);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &fd : const_cast<const BibTeXFields &>(BibTeXFields::instance())) {
            if (!p->header()->isSectionHidden(col))
                defaultWidthSumVisible += fd.defaultWidth;
            ++col;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &pair : Preferences::availableBackupScopes)
            comboBoxBackupScope->addItem(pair.second, static_cast<int>(pair.first));
```

#### LAMBDA EXPRESSION 


```{c}
[this, parent](QUrl url) {
            QUrlQuery query(url);
            query.addQueryItem(QStringLiteral("name"), QStringLiteral("KBibTeX"));
            query.addQueryItem(QStringLiteral("library_access"), QStringLiteral("1"));
            query.addQueryItem(QStringLiteral("notes_access"), QStringLiteral("0"));
            query.addQueryItem(QStringLiteral("write_access"), QStringLiteral("0"));
            query.addQueryItem(QStringLiteral("all_groups"), QStringLiteral("read"));
            url.setQuery(query);
            /// Received a URL from Zotero which the user can open in a web browser.
            /// To do that, re-enable various controls.
            lineEditAuthorizationUrl->setText(url.toDisplayString());
            lineEditAuthorizationUrl->setEnabled(true);
            buttonCopyAuthorizationUrl->setEnabled(true);
            buttonOpenAuthorizationUrl->setEnabled(true);
            QApplication::restoreOverrideCursor();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DotlessIJCharacter &dotlessIJCharacter : dotlessIJCharacters)
                        if ((dotlessIJCharacter.direction & DirectionCommandToUnicode) && dotlessIJCharacter.letter == input[i + 5 + skipSpaces] && dotlessIJCharacter.modifier == input[i + 2]) {
                            output.append(QChar(dotlessIJCharacter.unicode));
                            found = true;
                            break;
                        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QSharedPointer<ValueItem> &vi : v) {
                    filesUrlsDoiList << PlainTextValue::text(vi);
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (OnlineSearchAbstract *running : const_cast<const QSet<OnlineSearchAbstract *> &>(d->runningSearches)) {
                remainingEngines.append(running->label());
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &element : const_cast<const File &>(*this)) {
        const QSharedPointer<Entry> entry = element.dynamicCast<Entry>();
        if (!entry.isNull())
            for (Entry::ConstIterator it = entry->constBegin(); it != entry->constEnd(); ++it)
                if (it.key().toLower() == lcFieldName) {
                    const auto itValue = it.value();
                    for (const QSharedPointer<ValueItem> &valueItem : itValue) {
                        /// Check if ValueItem to process points to a person
                        const QSharedPointer<Person> person = valueItem.dynamicCast<Person>();
                        if (!person.isNull()) {
                            QSet<QString> personNameFormattingSet {Preferences::personNameFormatLastFirst, Preferences::personNameFormatFirstLast};
                            personNameFormattingSet.insert(Preferences::instance().personNameFormat());
                            /// Add person's name formatted using each of the templates assembled above
                            for (const QString &personNameFormatting : const_cast<const QSet<QString> &>(personNameFormattingSet))
                                valueSet.insert(Person::transcribePersonName(person.data(), personNameFormatting));
                        } else {
                            /// Default case: use PlainTextValue::text to translate ValueItem
                            /// to a human-readable text
                            valueSet.insert(PlainTextValue::text(*valueItem));
                        }
                    }
                }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const MathCommand &mathCommand : mathCommands)
                    if ((mathCommand.direction & DirectionUnicodeToCommand) && mathCommand.unicode == c.unicode()) {
                        output.append(QString(QStringLiteral("\\%1")).arg(mathCommand.command));
                        const QChar peekAhead = i < len - 1 ? input[i + 1] : QChar();
                        if (peekAhead != QLatin1Char('\\') && peekAhead != QLatin1Char('}') && peekAhead != QLatin1Char('$')) {
                            // Between current command and following character a separator is necessary
                            output.append(QStringLiteral("{}"));
                        }
                        found = true;
                        break;
                    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QListWidgetItem * current, QListWidgetItem *) {
            enginesListCurrentChanged(current);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &valueItem : const_cast<const Value &>(v))
            value.append(valueItem);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &word : titleWords) {
        ++argumentCount;
        q.addQueryItem(QString(QStringLiteral("p%1")).arg(argumentCount), word);
        q.addQueryItem(QString(QStringLiteral("m%1")).arg(argumentCount), QStringLiteral("a"));
        q.addQueryItem(QString(QStringLiteral("op%1")).arg(argumentCount), QStringLiteral("a"));
        q.addQueryItem(QString(QStringLiteral("f%1")).arg(argumentCount), QStringLiteral("title"));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &element : const_cast<const File &>(*bibTeXFile)) {
        QSharedPointer<Entry> entry = element.dynamicCast<Entry>();
        if (!entry.isNull()) {
            ++countEntries;
            lastEntryId = entry->id();

            Value authors = entry->value(Entry::ftAuthor);
            if (!authors.isEmpty()) {
                ValueItem *vi = authors.last().data();
                Person *p = dynamic_cast<Person *>(vi);
                if (p != nullptr) {
                    lastEntryLastAuthorLastName = p->lastName();
                } else
                    lastEntryLastAuthorLastName.clear();
            } else {
                Value editors = entry->value(Entry::ftEditor);
                if (!editors.isEmpty()) {
                    ValueItem *vi = editors.last().data();
                    Person *p = dynamic_cast<Person *>(vi);
                    if (p != nullptr) {
                        lastEntryLastAuthorLastName = p->lastName();
                    } else
                        lastEntryLastAuthorLastName.clear();
                } else
                    lastEntryLastAuthorLastName.clear();
            }

            if (!lastEntryLastAuthorLastName.isEmpty()) {
                if (lastEntryLastAuthorLastName[0] == QLatin1Char('{') && lastEntryLastAuthorLastName[lastEntryLastAuthorLastName.length() - 1] == QLatin1Char('}'))
                    lastEntryLastAuthorLastName = lastEntryLastAuthorLastName.mid(1, lastEntryLastAuthorLastName.length() - 2);
                lastAuthorsList << lastEntryLastAuthorLastName;
            }

            for (int index = 1; index < 100; ++index) {
                const QString field = index == 1 ? Entry::ftUrl : QString(QStringLiteral("%1%2")).arg(Entry::ftUrl).arg(index);
                const Value v = entry->value(field);
                for (const QSharedPointer<ValueItem> &vi : v) {
                    filesUrlsDoiList << PlainTextValue::text(vi);
                }
                if (v.isEmpty() && index > 10) break;
            }
            for (int index = 1; index < 100; ++index) {
                const QString field = index == 1 ? Entry::ftDOI : QString(QStringLiteral("%1%2")).arg(Entry::ftDOI).arg(index);
                const Value v = entry->value(field);
                for (const QSharedPointer<ValueItem> &vi : v) {
                    filesUrlsDoiList << PlainTextValue::text(vi);
                }
                if (v.isEmpty() && index > 10) break;
            }
            for (int index = 1; index < 100; ++index) {
                const QString field = index == 1 ? Entry::ftLocalFile : QString(QStringLiteral("%1%2")).arg(Entry::ftLocalFile).arg(index);
                const Value v = entry->value(field);
                for (const QSharedPointer<ValueItem> &vi : v) {
                    filesUrlsDoiList << PlainTextValue::text(vi);
                }
                if (v.isEmpty() && index > 10) break;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : urlList) {
                    if (url.isLocalFile()) continue; ///< skip local files

                    /// Build a nice menu item (label, icon, ...)
                    const QString prettyUrl = url.url(QUrl::PreferLocalFile);
                    QMimeDatabase db;
                    QAction *action = new QAction(QIcon::fromTheme(db.mimeTypeForUrl(url).iconName()), prettyUrl, p);
                    action->setData(prettyUrl);
                    action->setToolTip(prettyUrl);
                    /// Register action at signal handler to open URL when triggered
                    connect(action, &QAction::triggered, signalMapperViewDocument, static_cast<void(QSignalMapper::*)()>(&QSignalMapper::map));
                    signalMapperViewDocument->setMapping(action, action);
                    signalMapperViewDocumentSenders.insert(action);
                    viewDocumentMenu->addAction(action);
                    /// Memorize first action
                    if (firstAction == nullptr) firstAction = action;
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &field : const_cast<const QStringList &>(urlFields)) {
        if (entry.contains(field)) {
            const QString fieldText = PlainTextValue::text(entry.value(field));
            QRegularExpressionMatchIterator doiRegExpMatchIt = KBibTeX::doiRegExp.globalMatch(fieldText);
            while (doiRegExpMatchIt.hasNext()) {
                const QRegularExpressionMatch doiRegExpMatch = doiRegExpMatchIt.next();
                d->queueUrl(QUrl(KBibTeX::doiUrlPrefix + doiRegExpMatch.captured(0)), fieldText, Entry::ftDOI, maxDepth);
            }

            QRegularExpressionMatchIterator urlRegExpMatchIt = KBibTeX::urlRegExp.globalMatch(fieldText);
            while (urlRegExpMatchIt.hasNext()) {
                QRegularExpressionMatch urlRegExpMatch = urlRegExpMatchIt.next();
                d->queueUrl(QUrl(urlRegExpMatch.captured(0)), searchWords, Entry::ftUrl, maxDepth);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &idx : mil)
        rows << sortFilterProxyModel()->mapToSource(idx).row();
```

#### LAMBDA EXPRESSION 


```{c}
[this, tokenWidget]() {
                moveDownToken(tokenWidget);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &text : freeTextWords)
            queryFragments.append(text + (pmidRegExp.indexIn(text) >= 0 ? QStringLiteral("") : QStringLiteral("[All Fields]")));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &url : urls) {
            const QUrl u = protocolCheckerRegExp.match(url).hasMatch() ? QUrl::fromUserInput(url) : QUrl::fromLocalFile(url);
            mainWindow->openDocument(u);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (FieldLineEdit *fieldLineEdit : const_cast<const QList<FieldLineEdit *> &>(d->lineEditList))
        fieldLineEdit->setElement(element);
```

#### RANGE FOR STATEMENT 


```{c}
for (SettingsAbstractWidget *settingsWidget : const_cast<const QSet<SettingsAbstractWidget *> &>(settingWidgets)) {
                settingsWidget->resetToDefaults();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &element : const_cast<const File &>(*bibtexFile)) {
                QSharedPointer<Entry> entry = element.dynamicCast<Entry>();
                if (publishEntry(entry))
                    ++d->numFoundResults;
            }
```

#### LAMBDA EXPRESSION 


```{c}
[&gotErrors](const FileImporter::MessageSeverity messageSeverity, const QString &messageText) {
        gotErrors |= messageSeverity >= FileImporter::SeverityError;
        Q_UNUSED(messageText);
        //qDebug()<<"FileImporterRIS issues message during 'partialBibTeXInput' test: "<<messageText;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : mil)
            file->append(model->element(fileView->sortFilterProxyModel()->mapToSource(index).row()));
```

#### AUTO 


```{c}
const auto urlList = FileInfo::entryUrls(entry, bibliographyFile->property(File::Url).toUrl(), FileInfo::TestExistenceYes);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QSharedPointer<Element> &element : const_cast<const File &>(*file)) {
        QSharedPointer<Entry> entry = element.dynamicCast<Entry>();
        /// Process only Entry objects
        if (!entry.isNull()) {
            /// Go through every key-value pair in entry (author, title, ...)
            for (Entry::Iterator eit = entry->begin(); eit != entry->end(); ++eit) {
                /// Fetch key-value pair's key
                const QString key = eit.key().toLower();
                /// Process only key-value pairs that are filtered for (e.g. only keywords)
                if (key == fName) {
                    /// Fetch the key-value pair's value's textual representation
                    const QString valueFullText = PlainTextValue::text(eit.value());
                    if (valueFullText == toBeDeletedText) {
                        /// If the key-value pair's value's textual representation is the same
                        /// as the value to be delted, remove this key-value pair
                        /// This test is usually true for keys like title, year, or edition.
                        entry->remove(key); /// This would break the Iterator, but code "breakes" from loop anyways
                    } else {
                        /// The test above failed, but the delete operation may have
                        /// to be applied to a ValueItem inside the value.
                        /// Possible keys for such a case include author, editor, or keywords.

                        /// Process each ValueItem inside this Value
                        for (Value::Iterator vit = eit.value().begin(); vit != eit.value().end();) {
                            /// Similar procedure as for full values above:
                            /// If a ValueItem's textual representation is the same
                            /// as the shown string which has be deleted, remove the
                            /// ValueItem from this Value. If the Value becomes empty,
                            /// remove Value as well.
                            const QString valueItemText = PlainTextValue::text(* (*vit));
                            if (valueItemText == toBeDeletedText) {
                                /// Erase old ValueItem from this Value
                                vit = eit.value().erase(vit);
                            } else
                                ++vit;
                        }

                        if (eit.value().isEmpty()) {
                            /// This value does no longer contain any ValueItems.
                            entry->remove(key); /// This would break the Iterator, but code "breakes" from loop anyways
                        }
                    }
                    break;
                }
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                typeChanged(KBibTeX::TypeFlag::Source);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DotlessIJCharacter &dotlessIJCharacter : dotlessIJCharacters)
                        if (dotlessIJCharacter.letter == input[i + 4 + skipSpaces] && dotlessIJCharacter.modifier == input[i + 2]) {
                            output.append(QChar(dotlessIJCharacter.unicode));
                            found = true;
                            break;
                        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &rawHeaderName : rawHeadersReceived) {
            if (rawHeaderName.toLower().contains("apikey") || rawHeaderName.toLower().contains("api-key")) continue; ///< skip dumping header values containing an API key
            qCDebug(LOG_KBIBTEX_NETWORKING) << "RECVD " << rawHeaderName << ":" << reply->rawHeader(rawHeaderName);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QChar &encoderLaTeXProtectedSymbol : encoderLaTeXProtectedSymbols)
                if (encoderLaTeXProtectedSymbol == c) {
                    output.append(QLatin1Char('\\')).append(c);
                    found = true;
                    break;
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DotlessIJCharacter &dotlessIJCharacter : dotlessIJCharacters)
                if (c.unicode() == dotlessIJCharacter.unicode && (dotlessIJCharacter.direction & DirectionUnicodeToCommand)) {
                    output.append(QString(QStringLiteral("{\\%1\\%2}")).arg(dotlessIJCharacter.modifier, dotlessIJCharacter.letter));
                    found = true;
                    break;
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->resetColumnProperties();
    }
```

#### AUTO 


```{c}
const auto chosenValues = entryClique->chosenValues(field);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            addToken(ttTitle, locAtTop);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            d->verticallyStretchButtons();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &fd : const_cast<const BibTeXFields &>(BibTeXFields::instance())) {
            const bool visibility = fd.visible.contains(name) ? fd.visible[name] : fd.defaultVisible;
            p->header()->setSectionHidden(col, !visibility);
            ++col;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &doi : doiSet)
                doiValue.append(QSharedPointer<PlainText>(new PlainText(doi)));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &element : const_cast<const File &>(*file)) {
        QSharedPointer<const Entry> entry = element.dynamicCast<const Entry>();
        if (!entry.isNull()) {
            for (Entry::ConstIterator eit = entry->constBegin(); eit != entry->constEnd(); ++eit) {
                QString key = eit.key().toLower();
                if (key == fName) {
                    insertValue(eit.value());
                    break;
                }
                if (eit.value().isEmpty())
                    qCWarning(LOG_KBIBTEX_GUI) << "value for key" << key << "in entry" << entry->id() << "is empty";
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : urls) {
                if (url.isValid()) {
                    if (acceptableMimeTypes.isEmpty())
                        /// No limitations regarding which mime types are allowed?
                        /// Then accept any URL
                        result.insert(url);
                    const QMimeType mimeType = FileInfo::mimeTypeForUrl(url);
                    if (acceptableMimeTypes.contains(mimeType.name())) {
                        /// So, there is a list of acceptable mime types.
                        /// Only if URL points to a file that matches a mime type
                        /// from list return URL
                        result.insert(url);
                    }
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const MathCommand &mathCommand : mathCommands)
                    if (mathCommand.unicode == c.unicode() && (mathCommand.direction & DirectionUnicodeToCommand)) {
                        if (!currentMathMode.empty()) {
                            output.append(QString(QStringLiteral("\\%1")).arg(mathCommand.command));
                            const QChar peekAhead = i < len - 1 ? input[i + 1] : QChar();
                            if (peekAhead != QLatin1Char('\\') && peekAhead != QLatin1Char('}') && peekAhead != QLatin1Char('$')) {
                                /// Between current command and following character a separator is necessary
                                output.append(QStringLiteral("{}"));
                            }
                        } else
                            output.append(QString(QStringLiteral("\\ensuremath{\\%1}")).arg(mathCommand.command));
                        found = true;
                        break;
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KService::Ptr servicePtr : services) {
            QAction *menuItem = new QAction(QIcon::fromTheme(servicePtr->icon()), servicePtr->name(), this);
            d->actionOpenMenu->addAction(menuItem);
            d->openMenuActions << menuItem;

            connect(menuItem, &QAction::triggered, this, [this, servicePtr]() {
                d->openFileWithService(servicePtr);
            });
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &pair : listOfExImporter) {
        auto exporter = pair.first;
        auto importer = pair.second;
        const BibUtils::Format bibutilsformat = strncmp(exporter->metaObject()->className() + 12, "BibUtils", 8) == 0 ? qobject_cast<FileExporterBibUtils *>(exporter)->format() : BibUtils::Format::InvalidFormat;
        if (bibutilsformat == BibUtils::Format::InvalidFormat)
            bibutilsbuffer[0] = '\0';
        else
            snprintf(bibutilsbuffer, buffersize, ", format=%s", bibutilsformat == BibUtils::Format::BibTeX ? "BibTeX" : bibutilsformat == BibUtils::Format::BibLaTeX ? "BibLaTeX" : bibutilsformat == BibUtils::Format::RIS ? "RIS" : bibutilsformat == BibUtils::Format::WordBib ? "WordBib" : "???");

        File *file = new File();
        QSharedPointer<Entry> entry = QSharedPointer<Entry>(new Entry(Entry::etArticle, QStringLiteral("jabRefFieldFile")));
        Value value;
        value.append(QSharedPointer<VerbatimText>(new VerbatimText(QStringLiteral("file.pdf"))));
        entry->insert(Entry::ftFile, value);
        file->append(entry);
        int ret = snprintf(buffer, buffersize, "Field 'file' with just a filename (exporter=%s, importer=%s%s)", exporter->metaObject()->className(), importer->metaObject()->className(), bibutilsbuffer);
        if (ret > 0)
            QTest::newRow(buffer) << exporter << importer << file;

        file = new File();
        entry = QSharedPointer<Entry>(new Entry(Entry::etArticle, QStringLiteral("jabRefFieldFile")));
        value.clear();
        VerbatimText *verbatimText = new VerbatimText(QStringLiteral("file.pdf"));
        verbatimText->setComment(QStringLiteral("Some PDF file"));
        value.append(QSharedPointer<VerbatimText>(verbatimText));
        entry->insert(Entry::ftFile, value);
        file->append(entry);
        ret = snprintf(buffer, buffersize, "Field 'file' with a JabRef-like value (exporter=%s, importer=%s%s)", exporter->metaObject()->className(), importer->metaObject()->className(), bibutilsbuffer);
        if (ret > 0)
            QTest::newRow(buffer) << exporter << importer << file;

        file = new File();
        entry = QSharedPointer<Entry>(new Entry(Entry::etArticle, QStringLiteral("jabRefFieldFile")));
        value.clear();
        verbatimText = new VerbatimText(QStringLiteral("file.pdf"));
        verbatimText->setComment();
        value.append(QSharedPointer<VerbatimText>(verbatimText));
        entry->insert(Entry::ftFile, value);
        file->append(entry);
        ret = snprintf(buffer, buffersize, "Field 'file' with a JabRef-like value and empty comment (exporter=%s, importer=%s%s)", exporter->metaObject()->className(), importer->metaObject()->className(), bibutilsbuffer);
        if (ret > 0)
            QTest::newRow(buffer) << exporter << importer << file;

    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : urlList) {
                bool isLocal = KBibTeX::isLocalOrRelative(url);
                anyRemote |= !isLocal;
                if (!onlyLocalFilesButton->isChecked() && !isLocal) continue;

                KIO::StatJob *job = KIO::stat(url, KIO::StatJob::SourceSide, 3, KIO::HideProgressInfo);
                runningJobs << job;
                KJobWidgets::setWindow(job, p);
                connect(job, &KIO::StatJob::result, p, &DocumentPreview::statFinished);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &infoMessage : etl->infoMessages) {
            KMessageWidget *infoMessagesWidget = new KMessageWidget(i18n(infoMessage.toUtf8().constData()), this);
            connect(infoMessagesWidget, &KMessageWidget::linkActivated, this, &EntryConfiguredWidget::infoMessageLinkActivated);
            vboxLayout->addWidget(infoMessagesWidget, 1);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, reply, fileNameStem, webpageUrl]() {
        QUrl favIconUrl;

        if (reply->error() == QNetworkReply::NoError) {
            /// Assume that favicon information is within the first 4K of HTML code
            const QString htmlCode = QString::fromUtf8(reply->readAll()).left(4096);
            /// Some ugly but hopefully fast/flexible/robust HTML code parsing
            int p1 = -1;
            while ((p1 = htmlCode.indexOf(QStringLiteral("<link "), p1 + 5)) > 0) {
                const int p2 = htmlCode.indexOf(QChar('>'), p1 + 5);
                if (p2 > p1) {
                    const int p3 = htmlCode.indexOf(QStringLiteral("rel=\""), p1 + 5);
                    if (p3 > p1 && p3 < p2) {
                        const int p4 = htmlCode.indexOf(QChar('"'), p3 + 5);
                        if (p4 > p3 && p4 < p2) {
                            const QString relValue = htmlCode.mid(p3 + 5, p4 - p3 - 5);
                            if (relValue == QStringLiteral("icon") || relValue == QStringLiteral("shortcut icon")) {
                                const int p5 = htmlCode.indexOf(QStringLiteral("href=\""), p1 + 5);
                                if (p5 > p1 && p5 < p2) {
                                    const int p6 = htmlCode.indexOf(QChar('"'), p5 + 6);
                                    if (p6 > p5 + 5 && p6 < p2) {
                                        QString hrefValue = htmlCode.mid(p5 + 6, p6 - p5 - 6).replace("&", "&amp;").replace(">", "&gt;").replace("<", "&lt;");
                                        /// Do some resolving in case favicon URL in HTML code is relative
                                        favIconUrl = reply->url().resolved(QUrl(hrefValue));
                                        if (favIconUrl.isValid()) {
                                            qCDebug(LOG_KBIBTEX_NETWORKING) << "Found favicon URL" << favIconUrl.toDisplayString() << "in HTML code of webpage" << webpageUrl.toDisplayString();
                                            break;
                                        } else
                                            favIconUrl.clear();
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        if (!favIconUrl.isValid()) {
            favIconUrl = reply->url();
            favIconUrl.setPath(QStringLiteral("/favicon.ico"));
            qCInfo(LOG_KBIBTEX_NETWORKING) << "Could not locate favicon in HTML code for webpage" << webpageUrl.toDisplayString() << ", falling back to" << favIconUrl.toDisplayString();
        }

        QNetworkRequest request(favIconUrl);
        request.setAttribute(QNetworkRequest::FollowRedirectsAttribute, true);
        QNetworkReply *reply = InternalNetworkAccessManager::instance().get(request);
        connect(reply, &QNetworkReply::finished, this, [this, reply, fileNameStem, favIconUrl, webpageUrl]() {
            if (reply->error() == QNetworkReply::NoError) {
                const QByteArray iconData = reply->readAll();
                if (iconData.size() > 10) {
                    QString extension;
                    if (iconData[1] == 'P' && iconData[2] == 'N' && iconData[3] == 'G') {
                        /// PNG files have string "PNG" at second to fourth byte
                        extension = QStringLiteral(".png");
                    } else if (iconData[0] == static_cast<char>(0x00) && iconData[1] == static_cast<char>(0x00) && iconData[2] == static_cast<char>(0x01) && iconData[3] == static_cast<char>(0x00)) {
                        /// Microsoft Icon have first two bytes always 0x0000,
                        /// third and fourth byte is 0x0001 (for .ico)
                        extension = QStringLiteral(".ico");
                    } else if (iconData[0] == '<') {
                        /// HTML or XML code
                        const QString htmlCode = QString::fromUtf8(iconData);
                        qCWarning(LOG_KBIBTEX_NETWORKING) << "Received XML or HTML data from " << InternalNetworkAccessManager::removeApiKey(reply->url()).toDisplayString() << ": " << htmlCode.left(128);
                    } else {
                        qCWarning(LOG_KBIBTEX_NETWORKING) << "Favicon is of unknown format: " << InternalNetworkAccessManager::removeApiKey(reply->url()).toDisplayString();
                    }

                    if (!extension.isEmpty()) {
                        const QString filename = fileNameStem + extension;

                        QFile iconFile(filename);
                        if (iconFile.open(QFile::WriteOnly)) {
                            iconFile.write(iconData);
                            iconFile.close();
                            qCInfo(LOG_KBIBTEX_NETWORKING) << "Got icon from URL" << favIconUrl.toDisplayString() << "for webpage" << webpageUrl.toDisplayString() << "stored in" << filename;
                            favIcon = QIcon(filename);
                        } else {
                            qCWarning(LOG_KBIBTEX_NETWORKING) << "Could not save icon data from URL" << InternalNetworkAccessManager::removeApiKey(reply->url()).toDisplayString() << "to file" << filename;
                        }
                    }
                } else {
                    /// Unlikely that an icon's data is less than 10 bytes,
                    /// must be an error.
                    qCWarning(LOG_KBIBTEX_NETWORKING) << "Received invalid icon data from " << InternalNetworkAccessManager::removeApiKey(reply->url()).toDisplayString();
                }
            } else
                qCWarning(LOG_KBIBTEX_NETWORKING) << "Could not download icon from URL " << InternalNetworkAccessManager::removeApiKey(reply->url()).toDisplayString() << ": " << reply->errorString();

            QMetaObject::invokeMethod(this, "gotIcon", Qt::DirectConnection, QGenericReturnArgument(), Q_ARG(QIcon, favIcon));
        });
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, i]() {
                    setEdition(i + 1);
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (EntryClique *entryClique : entryCliques) {
        /// Avoid adding fields 20 lines below
        /// which have been remove (not added) 10 lines below
        QSet<QString> coveredFields;

        Entry *mergedEntry = new Entry(QString(), QString());
        const auto fieldList = entryClique->fieldList();
        coveredFields.reserve(fieldList.size());
        for (const auto &field : fieldList) {
            coveredFields << field;
            if (field == QStringLiteral("^id"))
                mergedEntry->setId(PlainTextValue::text(entryClique->chosenValue(field)));
            else if (field == QStringLiteral("^type"))
                mergedEntry->setType(PlainTextValue::text(entryClique->chosenValue(field)));
            else {
                Value combined;
                const auto chosenValues = entryClique->chosenValues(field);
                for (const Value &v : chosenValues) {
                    combined.append(v);
                }
                if (!combined.isEmpty())
                    mergedEntry->insert(field, combined);
            }
        }

        bool actuallyMerged = false;
        int preferredInsertionRow = -1;
        const auto entryList = entryClique->entryList();
        for (const auto &entry : entryList) {
            /// if merging entries with identical ids, the merged entry will not yet have an id (is null)
            if (mergedEntry->id().isEmpty())
                mergedEntry->setId(entry->id());
            /// if merging entries with identical types, the merged entry will not yet have an type (is null)
            if (mergedEntry->type().isEmpty())
                mergedEntry->setType(entry->type());

            /// add all other fields not covered by user selection
            /// those fields did only occur in one entry (no conflict)
            /// may add a lot of bloat to merged entry
            if (entryClique->isEntryChecked(entry)) {
                actuallyMerged = true;
                for (Entry::ConstIterator it = entry->constBegin(); it != entry->constEnd(); ++it)
                    if (!mergedEntry->contains(it.key()) && !coveredFields.contains(it.key())) {
                        mergedEntry->insert(it.key(), it.value());
                        coveredFields << it.key();
                    }
                const int row = fileModel->row(entry);
                if (preferredInsertionRow < 0) preferredInsertionRow = row;
                fileModel->removeRow(row);
            }
        }

        if (actuallyMerged) {
            if (preferredInsertionRow < 0) preferredInsertionRow = fileModel->rowCount();
            fileModel->insertRow(QSharedPointer<Entry>(mergedEntry), preferredInsertionRow);
        } else
            delete mergedEntry;
        didMerge |= actuallyMerged;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SingleFieldLayout &sfl : const_cast<const QList<SingleFieldLayout> &>(etl->singleFieldLayouts)) {
            ++fieldCount;
            configGroup.writeEntry(QString(QStringLiteral("bibtexLabel%1")).arg(fieldCount), sfl.bibtexLabel);
            configGroup.writeEntry(QString(QStringLiteral("uiLabel%1")).arg(fieldCount), sfl.uiLabel);
            configGroup.writeEntry(QString(QStringLiteral("fieldInputLayout%1")).arg(fieldCount), EntryLayoutPrivate::convert(sfl.fieldInputLayout));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &element : const_cast<const File &>(*bibtexFile)) {
                QSharedPointer<Entry> entry = element.dynamicCast<Entry>();
                hasEntry |= publishEntry(entry);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto *fd : const_cast<const BibTeXFields &>(*bf)) {
        QAction *action = new QAction(fd->label, header());
        action->setData(col);
        action->setCheckable(true);
        action->setChecked(!isColumnHidden(col));
        connect(action, &QAction::triggered, this, &BasicFileView::headerActionToggled);
        header()->addAction(action);
        ++col;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &lastAuthor : const_cast<const QStringList &>(lastAuthorsList)) {
        const QByteArray lastAuthorUtf8 = lastAuthor.toUtf8();
        hashLastAuthors.addData(lastAuthorUtf8);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &author : authors) {
            queryString += QString(QStringLiteral(" name:%1")).arg(EncoderLaTeX::instance().convertToPlainAscii(author));
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&gotErrors](const FileImporter::MessageSeverity messageSeverity, const QString &messageText) {
        gotErrors |= messageSeverity >= FileImporter::MessageSeverity::Error;
        Q_UNUSED(messageText)
        //qCDebug(LOG_KBIBTEX_TEST)<<"FileImporterRIS issues message during 'partialBibTeXInput' test: "<<messageText;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SingleFieldLayout &sfl : const_cast<const QList<SingleFieldLayout> &>(etl->singleFieldLayouts)) {
        LabeledFieldInput *labeledFieldInput = new LabeledFieldInput;

        /// create an editing widget for this field
        const FieldDescription &fd = bf->find(sfl.bibtexLabel);
        labeledFieldInput->fieldInput = new FieldInput(sfl.fieldInputLayout, fd.preferredTypeFlag, fd.typeFlags, this);
        labeledFieldInput->fieldInput->setFieldKey(sfl.bibtexLabel);
        bibtexKeyToWidget.insert(sfl.bibtexLabel, labeledFieldInput->fieldInput);
        connect(labeledFieldInput->fieldInput, &FieldInput::modified, this, &EntryConfiguredWidget::gotModified);

        /// memorize if field input should grow vertically (e.g. is a list)
        labeledFieldInput->isVerticallyMinimumExpaning = sfl.fieldInputLayout == KBibTeX::MultiLine || sfl.fieldInputLayout == KBibTeX::List || sfl.fieldInputLayout == KBibTeX::PersonList || sfl.fieldInputLayout == KBibTeX::KeywordList;

        /// create a label next to the editing widget
        labeledFieldInput->label = new QLabel(QString(QStringLiteral("%1:")).arg(sfl.uiLabel), this);
        labeledFieldInput->label->setBuddy(labeledFieldInput->fieldInput->buddy());
        /// align label's text vertically to match field input
        const Qt::Alignment horizontalAlignment = static_cast<Qt::Alignment>(labeledFieldInput->label->style()->styleHint(QStyle::SH_FormLayoutLabelAlignment)) & Qt::AlignHorizontal_Mask;
        labeledFieldInput->label->setAlignment(horizontalAlignment | (labeledFieldInput->isVerticallyMinimumExpaning ? Qt::AlignTop : Qt::AlignVCenter));

        listOfLabeledFieldInput[i] = labeledFieldInput;

        ++i;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KService::Ptr servicePtr : const_cast<const KService::List &>(d->openMenuServices)) {
            QAction *menuItem = new QAction(QIcon::fromTheme(servicePtr->icon()), servicePtr->name(), this);
            d->actionOpenMenu->addAction(menuItem);
            d->openMenuActions << menuItem;

            d->openMenuSignalMapper.setMapping(menuItem, i);
            connect(menuItem, &QAction::triggered, &d->openMenuSignalMapper, static_cast<void(QSignalMapper::*)()>(&QSignalMapper::map));
            ++i;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const HiddenTabInfo &hti : const_cast<const QSet<HiddenTabInfo> &>(d->hiddenTabInfo)) {
        if (hti.widget == page) {
            int pos = d->showTab(hti, index);
            setTabText(pos, label);
            return pos;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (OpenFileInfo *ofi : const_cast<const OpenFileInfoManager::OpenFileInfoList &>(d->openFileInfoList)) {
        if (!isClosing && ofi == openFileInfo && openFileInfo->close()) {
            isClosing = true;
            /// Mark file as closed (i.e. not open)
            openFileInfo->removeFlags(OpenFileInfo::Open);
            /// If file has a filename, remember as recently used
            if (openFileInfo->flags().testFlag(OpenFileInfo::HasName))
                openFileInfo->addFlags(OpenFileInfo::RecentlyUsed);
        } else if (nextCurrent == nullptr && ofi->flags().testFlag(OpenFileInfo::Open))
            nextCurrent = ofi;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DotlessIJCharacter &dotlessIJCharacter : dotlessIJCharacters)
                        if (dotlessIJCharacter.letter == input[i + 4 + skipSpaces] && dotlessIJCharacter.modifier == input[i + 2]) {
                            output.append(QChar(dotlessIJCharacter.unicode));
                            i += 5 + skipSpaces;
                            found = true;
                            break;
                        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                area->ensureWidgetVisible(buttonAddTokenAtBottom);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QAction *action : actionList) {
        /// Make URL from action's data ...
        const QString actionData = action->data().toString();
        if (actionData.isEmpty()) continue; ///< No URL from empty string
        const QUrl tmpUrl = QUrl::fromUserInput(actionData);
        /// ... but skip this action if the URL is invalid
        if (!tmpUrl.isValid()) continue;
        if (tmpUrl.isLocalFile()) {
            /// If action's URL points to local file,
            /// keep it and stop search for document
            url = tmpUrl;
            break;
        } else if (!url.isValid())
            /// First valid URL found, keep it
            /// URL is not local, so it may get overwritten by another URL
            url = tmpUrl;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &ed : const_cast<const BibTeXEntries &>(*be)) {
            if (entryTypeLc == ed.upperCamelCase.toLower() || entryTypeLc == ed.upperCamelCaseAlt.toLower()) {
                /// this ugly conversion is necessary because we have a "^" (xor) and "|" (and/or)
                /// syntax to differentiate required items (not used yet, but will be used
                /// later if missing required items are marked).
                QString visible = ed.requiredItems.join(QStringLiteral(","));
                visible += QLatin1Char(',') + ed.optionalItems.join(QStringLiteral(","));
                visible = visible.replace(QLatin1Char('|'), QLatin1Char(',')).replace(QLatin1Char('^'), QLatin1Char(','));
                visibleItems = visible.split(QStringLiteral(","));
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &xslTranslationFile : xsltToKeyToXsltData.keys()) {
        const QHash<const char *, QSet<QString>> &keyToXsltData = xsltToKeyToXsltData.value(xslTranslationFile);
        for (auto it = keyFileTable.constBegin(); it != keyFileTable.constEnd(); ++it)
            if (!it->second->isEmpty() && keyToXsltData.contains(it->first)) {
                const QString label = QString(QStringLiteral("'%1' with XSLT '%2'")).arg(QString::fromLatin1(it->first)).arg(xslTranslationFile);
                QTest::newRow(label.toUtf8().constData()) << it->second->first() << xslTranslationFile << keyToXsltData.value(it->first);
            }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : mil) {
            const QSharedPointer<Entry> entry = model->element(d->partWidget->fileView()->sortFilterProxyModel()->mapToSource(index).row()).dynamicCast<Entry>();
            if (!entry.isNull())
                references << entry->id();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &encoding : listOfASCIIcompatibleEncodings)
        QTest::newRow(QString(QStringLiteral("Moby Dick (ASCII only) encoded in '%1'")).arg(encoding).toLatin1().constData()) << mobyDickBibliography() << encoding << mobyDickExpectedOutput;
```

#### RANGE FOR STATEMENT 


```{c}
for (FieldLineEdit *fieldLineEdit : const_cast<const QList<FieldLineEdit *> &>(d->lineEditList))
        fieldLineEdit->setCompletionItems(items);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &word : freeTextWords) {
        ++argumentCount;
        q.addQueryItem(QString(QStringLiteral("p%1")).arg(argumentCount), word);
        q.addQueryItem(QString(QStringLiteral("m%1")).arg(argumentCount), QStringLiteral("a"));
        q.addQueryItem(QString(QStringLiteral("op%1")).arg(argumentCount), QStringLiteral("a"));
        q.addQueryItem(QString(QStringLiteral("f%1")).arg(argumentCount), QStringLiteral(""));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &keyword : keywordList)
                v.append(QSharedPointer<ValueItem>(new Keyword(keyword)));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &valueItem : value) {
        QString nextText = text(*valueItem, vit);
        if (!nextText.isEmpty()) {
            if (lastVit == ValueItemType::Person && vit == ValueItemType::Person)
                result.append(i18n(" and ")); // TODO proper list of authors/editors, not just joined by "and"
            else if (lastVit == ValueItemType::Person && vit == ValueItemType::Other && nextText == QStringLiteral("others")) {
                /// "and others" case: replace text to be appended by translated variant
                nextText = i18n(" and others");
            } else if (lastVit == ValueItemType::Keyword && vit == ValueItemType::Keyword)
                result.append("; ");
            else if (!result.isEmpty())
                result.append(" ");
            result.append(nextText);

            lastVit = vit;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, i]() {
                    setMonth(i);
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &invalidChar : invalidChars)
        /// Replacing daggers with commas ensures that they act as persons' names separator
        internalText = internalText.replace(invalidChar, QChar(','));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &bibtex2htmlStyle : FileExporterBibTeX2HTML::availableLaTeXBibliographyStyles())
                listOfStyles.append({bibtex2htmlStyle, bibtex2htmlStyle, QStringLiteral("bibtex2html")});
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &key : orderOfParameters) {
                if (!inputMap.contains(key)) continue;
                query.addQueryItem(key, inputMap[key]);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &logLine : const_cast<const QStringList &>(errorLog))
        qCDebug(LOG_KBIBTEX_TEST) << logLine;
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QItemSelection &selected, const QItemSelection &) {
        const bool hasSelection = !selected.empty();
        emit this->hasSelectionChanged(hasSelection);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &indexInSelection : list) {
                const QModelIndex &indexInFileModel = model->mapToSource(indexInSelection);
                const int row = indexInFileModel.row();
                const QSharedPointer<Element> &element = (*bibTeXFile)[row];
                fileWithSelectedElements << element;
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QChar &c : ninput) {
        /// Get byte sequence representing current character in chosen codec
        const QByteArray cba = destinationCodec->fromUnicode(c);
        if (destinationCodec->canEncode(c) && (c == QChar(0x003f /** question mark */) || cba.size() != 1 || cba[0] != 0x3f /** question mark */)) {
            /// Codec claims that it can encode current character, but some codecs
            /// still cannot encode character and simply return a question mark, so
            /// only accept question marks as encoding result if original character
            /// was question mark (assuming all codecs can encode question marks).
            result.append(cba);
        } else {
            /// Chosen codec can NOT encode current Unicode character, so try to use
            /// 'LaTeX encoder', which may translate 0x00c5 (A with ring above) into
            /// '\AA'. LaTeX encoder returns UTF-8 representation if given character
            /// cannot be encoded
            result.append(laTeXEncoder.encode(QString(c), Encoder::TargetEncodingASCII).toUtf8());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &element : const_cast<const File &>(*bibtexFile)) {
                    QSharedPointer<Entry> entry = element.dynamicCast<Entry>();
                    hasEntry |= publishEntry(entry);
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            updateGUI();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Poppler::EmbeddedFile *file : embeddedFiles) {
            if (file->name().endsWith(QStringLiteral(".bib"))) {
                // TODO maybe request implementation of a constData() for
                // Poppler::EmbeddedFile to operate on const objects?
                QByteArray data(file->data());
                QBuffer buffer(&data);
                FileImporterBibTeX bibTeXimporter(this);
                connect(&bibTeXimporter, &FileImporter::progress, this, &FileImporter::progress);
                buffer.open(QIODevice::ReadOnly);
                result = bibTeXimporter.load(&buffer);
                buffer.close();

                if (result) {
                    qCDebug(LOG_KBIBTEX_IO) << "Bibliography extracted from embedded file" << file->name() << "has" << result->count() << "entries";
                    if (result->count() > 0)
                        break; ///< stop processing after first valid, non-empty BibTeX file
                    else {
                        /// ... otherwise delete empty bibliography object
                        delete result;
                        result = nullptr;
                    }
                } else
                    qCDebug(LOG_KBIBTEX_IO) << "Create bibliography file from embedded file" << file->name() << "failed";
            } else
                qCDebug(LOG_KBIBTEX_IO) << "Embedded file" << file->name() << "doesn't have right extension ('.bib')";
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (NotificationListener *listener : const_cast<const QSet<NotificationListener *> &>(set)) {
            listener->notificationEvent(eventId);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &queryFragment : respectingQuotationMarksTitle) {
        queryFragments.append(encodeURL(queryFragment));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : deselectedSet) {
        if (index.column() != 0) continue; ///< consider only column-0 indices to avoid duplicate elements
        m_selection.removeOne(elementAt(index));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (NotificationListener *listener : const_cast<const QSet<NotificationListener *> &>(d->listenersAnyEvent))
            set.insert(listener);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            switchToEngines();
        }
```

#### LAMBDA EXPRESSION 


```{c}
connectStartingDelayedTimer(buttonSearchPDFfiles, &QPushButton::toggled)
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &key : form.keys()) {
            if (!body.isEmpty()) body += QLatin1Char('&');
            for (const QString &value : form.values(key))
                body += key + QLatin1Char('=') + QString(QUrl::toPercentEncoding(value));
        }
```

#### AUTO 


```{c}
const auto respectingQuotationMarksTitle = splitRespectingQuotationMarks(query[queryKeyTitle]);
```

#### LAMBDA EXPRESSION 


```{c}
[this, &doEmitProcessOutput, &process] {
        QTextStream ts(process.readAllStandardOutput());
        while (!ts.atEnd()) {
            const QString line = ts.readLine();
            qCWarning(LOG_KBIBTEX_IO) << line;
            if (doEmitProcessOutput)
                emit processStandardOut(line);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &fd : const_cast<const BibTeXFields &>(BibTeXFields::instance()))
            if (fd.upperCamelCaseAlt.isEmpty())
                fielddescs.insert(fd.label, fd.upperCamelCase);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            reset();
        }
```

#### AUTO 


```{c}
const auto &xAuthorValueItem
```

#### RANGE FOR STATEMENT 


```{c}
for (const DotlessIJCharacter &dotlessIJCharacter : dotlessIJCharacters)
                if ((dotlessIJCharacter.direction & DirectionUnicodeToCommand) && c.unicode() == dotlessIJCharacter.unicode) {
                    output.append(QString(QStringLiteral("{\\%1\\%2}")).arg(dotlessIJCharacter.modifier, dotlessIJCharacter.letter));
                    found = true;
                    break;
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const EncoderLaTeXEscapedCharacter &encoderLaTeXEscapedCharacter : encoderLaTeXEscapedCharacters)
                    if ((encoderLaTeXEscapedCharacter.direction & DirectionUnicodeToCommand) && encoderLaTeXEscapedCharacter.unicode == c.unicode()) {
                        const QString formatString = isAsciiLetter(encoderLaTeXEscapedCharacter.modifier) ? QStringLiteral("{\\%1 %2}") : QStringLiteral("{\\%1%2}");
                        output.append(formatString.arg(encoderLaTeXEscapedCharacter.modifier).arg(encoderLaTeXEscapedCharacter.letter));
                        found = true;
                        break;
                    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                typeChanged(KBibTeX::TypeFlag::Verbatim);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &queryFragment : respectingQuotationMarksAuthor) {
        queryFragments.append(encodeURL(queryFragment));
    }
```

#### AUTO 


```{c}
const auto index = unicode < 0xd800 ? unicode : unicode - 2048;
```

#### AUTO 


```{c}
const auto &bibTeXDataRow
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                typeChanged(KBibTeX::tfKeyword);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : mil) {
        QSharedPointer<Entry> entry = d->partWidget->fileView()->fileModel()->element(d->partWidget->fileView()->sortFilterProxyModel()->mapToSource(index).row()).dynamicCast<Entry>();
        if (!entry.isNull()) {
            static IdSuggestions idSuggestions;
            bool success = idSuggestions.applyDefaultFormatId(*entry.data());
            documentModified |= success;
            if (!success) {
                KMessageBox::information(widget(), i18n("Cannot apply default formatting for entry ids: No default format specified."), i18n("Cannot Apply Default Formatting"));
                break;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &text : fileList) {
        internalText = text;

        /// If testing for the actual existence of a filename found in the text ...
        if (testExistence == TestExistenceYes) {
            /// If a base directory (e.g. the location of the parent .bib file) is given
            /// and the potential filename fragment is NOT an absolute path, ...
            if (!baseDirectory.isEmpty() &&
                    // TODO the following test assumes that absolute paths start
                    // with a dir separator, which may only be true on Unix/Linux,
                    // but not Windows. May be a test for 'first character is a letter,
                    // second is ":", third is "\"' may be necessary.
                    !internalText.startsWith(QDir::separator())) {
                /// To get the absolute path, prepend filename fragment with base directory
                const QString fullFilename = baseDirectory + QDir::separator() + internalText;
                const QFileInfo fileInfo(fullFilename);
                const QUrl url = QUrl::fromLocalFile(fileInfo.canonicalFilePath());
                if (fileInfo.exists() && fileInfo.isFile() && url.isValid() && !result.contains(url)) {
                    result << url;
                    /// Stop searching for URLs or filenames in current internal text
                    continue;
                }
            } else {
                /// Either the filename fragment is an absolute path OR no base directory
                /// was given (current working directory is assumed), ...
                const QFileInfo fileInfo(internalText);
                const QUrl url = QUrl::fromLocalFile(fileInfo.canonicalFilePath());
                if (fileInfo.exists() && fileInfo.isFile() && url.isValid() && !result.contains(url)) {
                    result << url;
                    /// stop searching for URLs or filenames in current internal text
                    continue;
                }
            }
        }

        /// extract URL from current field
        pos = 0;
        while ((pos = KBibTeX::urlRegExp.indexIn(internalText, pos)) != -1) {
            const QString match = KBibTeX::urlRegExp.cap(0);
            QUrl url(match);
            if (url.isValid() && (testExistence == TestExistenceNo || !url.isLocalFile() || QFileInfo::exists(url.toLocalFile())) && !result.contains(url))
                result << url;
            /// remove match from internal text to avoid duplicates
            internalText = internalText.left(pos) + internalText.mid(pos + match.length());
        }

        /// explicitly check URL entry, may be an URL even if http:// or alike is missing
        pos = 0;
        while ((pos = KBibTeX::domainNameRegExp.indexIn(internalText, pos)) > -1) {
            int pos2 = internalText.indexOf(QStringLiteral(" "), pos + 1);
            if (pos2 < 0) pos2 = internalText.length();
            QString match = internalText.mid(pos, pos2 - pos);
            QUrl url("http://" + match);
            if (url.isValid() && !result.contains(url))
                result << url;
            /// remove match from internal text to avoid duplicates
            internalText = internalText.left(pos) + internalText.mid(pos + match.length());
        }

        /// extract general file-like patterns
        pos = 0;
        while ((pos = KBibTeX::fileRegExp.indexIn(internalText, pos)) != -1) {
            QString match = KBibTeX::fileRegExp.cap(0);
            QUrl url(match);
            if (url.isValid() && (testExistence == TestExistenceNo || !url.isLocalFile() || QFileInfo::exists(url.toLocalFile())) && !result.contains(url))
                result << url;
            /// remove match from internal text to avoid duplicates
            internalText = internalText.left(pos) + internalText.mid(pos + match.length());
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            addToken(ttYear, locAtBottom);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, &doEmitProcessOutput, &process] {
        QTextStream ts(process.readAllStandardError());
        while (!ts.atEnd()) {
            const QString line = ts.readLine();
            qCDebug(LOG_KBIBTEX_IO) << line;
            if (doEmitProcessOutput)
                emit processStandardError(line);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &program : programs) {
            const QString fullPath = QStandardPaths::findExecutable(program);
            if (fullPath.isEmpty()) {
                state = unavail; ///< missing a single program is reason to assume that BibUtils is not correctly installed
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &key : const_cast<const QList<QString> &>(keys)) {
            const QString &value = fielddescs[key];
            comboBoxField->addItem(key, value);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &chunk : chunksPublication) {
            if (index > 1)
                query.addQueryItem(QString(QStringLiteral("operator%1")).arg(index), QStringLiteral("AND"));
            query.addQueryItem(QString(QStringLiteral("option%1")).arg(index), QStringLiteral("journalbooktitle"));
            query.addQueryItem(QString(QStringLiteral("value%1")).arg(index), chunk);
            ++index;
        }
```

#### AUTO 


```{c}
const auto &field
```

#### LAMBDA EXPRESSION 


```{c}
connectStartingDelayedTimer(comboBoxFilterText->lineEdit(), &QLineEdit::textChanged)
```

#### RANGE FOR STATEMENT 


```{c}
for (const QChar &c : input) {
            if (codec == nullptr /** meaning UTF-8, which can encode anything */ || canEncode(c, codec))
                rewrittenInput.append(c);
            else
                rewrittenInput.append(laTeXEncoder.encode(QString(c), Encoder::TargetEncoding::ASCII));
        }
```

#### AUTO 


```{c}
const auto urlList = FileInfo::entryUrls(entry, bibtexfile->property(File::Url).toUrl(), FileInfo::TestExistence::Yes);
```

#### AUTO 


```{c}
const auto firefoxVersionMajor = QRandomGenerator::global()->bounded(69, 74);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &word : authorWords) {
        ++argumentCount;
        q.addQueryItem(QString(QStringLiteral("p%1")).arg(argumentCount), word);
        q.addQueryItem(QString(QStringLiteral("m%1")).arg(argumentCount), QStringLiteral("a"));
        q.addQueryItem(QString(QStringLiteral("op%1")).arg(argumentCount), QStringLiteral("a"));
        q.addQueryItem(QString(QStringLiteral("f%1")).arg(argumentCount), QStringLiteral("author"));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &item : const_cast<const QList<EncoderXMLPrivate::CharMappingItem> &>(d->charMapping))
        result.replace(item.regExp, item.unicode);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &token : tokenList) {
        id.append(d->translateToken(entry, token));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QChar &encoderLaTeXProtectedSymbol : encoderLaTeXProtectedSymbols)
                        if (encoderLaTeXProtectedSymbol == input[i + 1]) {
                            output.append(encoderLaTeXProtectedSymbol);
                            foundCommand = true;
                            break;
                        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DotlessIJCharacter &dotlessIJCharacter : dotlessIJCharacters)
                    if (dotlessIJCharacter.letter == input[i + 3 + skipSpaces] && dotlessIJCharacter.modifier == input[i + 1]) {
                        output.append(QChar(dotlessIJCharacter.unicode));
                        found = true;
                        break;
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const HiddenTabInfo &hti : const_cast<const QSet<HiddenTabInfo> &>(d->hiddenTabInfo)) {
        if (hti.widget == page) {
            int pos = d->showTab(hti);
            setTabIcon(pos, icon);
            setTabText(pos, label);
            return pos;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &line : const_cast<const QStringList &>(bibtexOuput)) {
        if (errorLine.indexIn(line) > -1) {
            buffer.open(QIODevice::ReadOnly);
            QTextStream ts(&buffer);
            for (int i = errorLine.cap(1).toInt(); i > 1; --i) {
                errorPlainText = ts.readLine();
                buffer.close();
            }
        } else if (line.startsWith(QStringLiteral("Warning--"))) {
            /// is a warning ...

            if (warningEmptyField.indexIn(line) > -1) {
                /// empty/missing field
                warnings << i18n("Field <b>%1</b> is empty", warningEmptyField.cap(1));
            } else if (warningEmptyField2.indexIn(line) > -1) {
                /// two empty/missing fields
                warnings << i18n("Fields <b>%1</b> and <b>%2</b> are empty, but at least one is required", warningEmptyField2.cap(1), warningEmptyField2.cap(2));
            } else if (warningThereIsBut.indexIn(line) > -1) {
                /// there is a field which exists but another does not exist
                warnings << i18n("Field <b>%1</b> exists, but <b>%2</b> does not exist", warningThereIsBut.cap(1), warningThereIsBut.cap(2));
            } else if (warningCantUseBoth.indexIn(line) > -1) {
                /// there are two conflicting fields, only one may be used
                warnings << i18n("Fields <b>%1</b> and <b>%2</b> cannot be used at the same time", warningCantUseBoth.cap(1), warningCantUseBoth.cap(2));
            } else if (warningSort2.indexIn(line) > -1) {
                /// one out of two fields missing for sorting
                warnings << i18n("Fields <b>%1</b> or <b>%2</b> are required to sort entry", warningSort2.cap(1), warningSort2.cap(2));
            } else if (warningSort3.indexIn(line) > -1) {
                /// one out of three fields missing for sorting
                warnings << i18n("Fields <b>%1</b>, <b>%2</b>, <b>%3</b> are required to sort entry", warningSort3.cap(1), warningSort3.cap(2), warningSort3.cap(3));
            } else {
                /// generic/unknown warning
                warnings << i18n("Unknown warning: %1", line.mid(warningStart.length()));
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &valueItem : value) {
        QString nextText = text(*valueItem, vit);
        if (!nextText.isEmpty()) {
            if (lastVit == VITPerson && vit == VITPerson)
                result.append(i18n(" and ")); // TODO proper list of authors/editors, not just joined by "and"
            else if (lastVit == VITPerson && vit == VITOther && nextText == QStringLiteral("others")) {
                /// "and others" case: replace text to be appended by translated variant
                nextText = i18n(" and others");
            } else if (lastVit == VITKeyword && vit == VITKeyword)
                result.append("; ");
            else if (!result.isEmpty())
                result.append(" ");
            result.append(nextText);

            lastVit = vit;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            addToken(ttAuthor, locAtTop);
        }
```

#### AUTO 


```{c}
const auto &doiValueItem
```

#### AUTO 


```{c}
const auto entryList = entryClique->entryList();
```

#### LAMBDA EXPRESSION 


```{c}
[ = ]() {
            d->retrieveItems(url, 0);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &key : keys) {
        if (numericId == qHash(key))
            return key;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &filesUrlsDoi : const_cast<const QStringList &>(filesUrlsDoiList))
        hashFilesUrlsDoi.addData(filesUrlsDoi.toUtf8());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &unusedValue : unusedValues) {
            const QString valueString = object.value(unusedValue).toString();
            if (!valueString.isEmpty())
                qCDebug(LOG_KBIBTEX_NETWORKING) << "unused value:" << unusedValue << "=" << valueString;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->delayedTimer->start(500);
    }
```

#### AUTO 


```{c}
const auto *fd
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        slotAddReference();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Value &v : const_cast<const QList<Value> &>(alternatives))
            if (PlainTextValue::text(v) == fieldValueText) {
                alreadyContained = true;
                break;
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : mil)
            file->append(fileView->fileModel()->element(fileView->sortFilterProxyModel()->mapToSource(index).row()));
```

#### RANGE FOR STATEMENT 


```{c}
for (const SingleFieldLayout &sfl : const_cast<const QList<SingleFieldLayout> &>(etl->singleFieldLayouts)) {
        LabeledFieldInput *labeledFieldInput = new LabeledFieldInput;

        /// create an editing widget for this field
        const FieldDescription *fd = bf->find(sfl.bibtexLabel);
        KBibTeX::TypeFlags typeFlags = fd == nullptr ? KBibTeX::tfSource : fd->typeFlags;
        KBibTeX::TypeFlag preferredTypeFlag = fd == nullptr ? KBibTeX::tfSource : fd->preferredTypeFlag;
        labeledFieldInput->fieldInput = new FieldInput(sfl.fieldInputLayout, preferredTypeFlag, typeFlags, this);
        labeledFieldInput->fieldInput->setFieldKey(sfl.bibtexLabel);
        bibtexKeyToWidget.insert(sfl.bibtexLabel, labeledFieldInput->fieldInput);
        connect(labeledFieldInput->fieldInput, &FieldInput::modified, this, &EntryConfiguredWidget::gotModified);

        /// memorize if field input should grow vertically (e.g. is a list)
        labeledFieldInput->isVerticallyMinimumExpaning = sfl.fieldInputLayout == KBibTeX::MultiLine || sfl.fieldInputLayout == KBibTeX::List || sfl.fieldInputLayout == KBibTeX::PersonList || sfl.fieldInputLayout == KBibTeX::KeywordList;

        /// create a label next to the editing widget
        labeledFieldInput->label = new QLabel(QString(QStringLiteral("%1:")).arg(sfl.uiLabel), this);
        labeledFieldInput->label->setBuddy(labeledFieldInput->fieldInput->buddy());
        /// align label's text vertically to match field input
        Qt::Alignment horizontalAlignment = (Qt::Alignment)(labeledFieldInput->label->style()->styleHint(QStyle::SH_FormLayoutLabelAlignment) & 0x001f);
        labeledFieldInput->label->setAlignment(horizontalAlignment | (labeledFieldInput->isVerticallyMinimumExpaning ? Qt::AlignTop : Qt::AlignVCenter));

        listOfLabeledFieldInput[i] = labeledFieldInput;

        ++i;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QChar &invalidIdCharacter : invalidIdCharacters)
            if (id.contains(invalidIdCharacter)) {
                qCWarning(LOG_KBIBTEX_IO) << "Entry id" << id << "near line" << state.lineNo << "contains invalid character" << invalidIdCharacter;
                /// Instead of an 'emit' ...
                QMetaObject::invokeMethod(parent, "message", Qt::DirectConnection, QGenericReturnArgument(), Q_ARG(FileImporter::MessageSeverity, MessageSeverity::Error), Q_ARG(QString, QString(QStringLiteral("Entry id '%1' near line %2 contains invalid character '%3'")).arg(id).arg(state.lineNo).arg(invalidIdCharacter)));
                return nullptr;
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &chunk : chunksFullText) {
            if (index > 1)
                query.addQueryItem(QString(QStringLiteral("operator%1")).arg(index), QStringLiteral("AND")); ///< join search terms with an AND operation
            query.addQueryItem(QString(QStringLiteral("option%1")).arg(index), QStringLiteral("fulltext"));
            query.addQueryItem(QString(QStringLiteral("value%1")).arg(index), chunk);
            ++index;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &valueItem : value)
        result.append(valueItemToXML(valueItem));
```

#### LAMBDA EXPRESSION 


```{c}
[this, reply, fileNameStem, webpageUrl]() {
        QUrl favIconUrl;

        if (reply->error() == QNetworkReply::NoError) {
            /// Assume that favicon information is within the first 4K of HTML code
            const QString htmlCode = QString::fromUtf8(reply->readAll()).left(4096);
            /// Some ugly but hopefully fast/flexible/robust HTML code parsing
            int p1 = -1;
            while ((p1 = htmlCode.indexOf(QStringLiteral("<link "), p1 + 5)) > 0) {
                const int p2 = htmlCode.indexOf(QChar('>'), p1 + 5);
                if (p2 > p1) {
                    const int p3 = htmlCode.indexOf(QStringLiteral("rel=\""), p1 + 5);
                    if (p3 > p1 && p3 < p2) {
                        const int p4 = htmlCode.indexOf(QChar('"'), p3 + 5);
                        if (p4 > p3 && p4 < p2) {
                            const QString relValue = htmlCode.mid(p3 + 5, p4 - p3 - 5);
                            if (relValue == QStringLiteral("icon") || relValue == QStringLiteral("shortcut icon")) {
                                const int p5 = htmlCode.indexOf(QStringLiteral("href=\""), p1 + 5);
                                if (p5 > p1 && p5 < p2) {
                                    const int p6 = htmlCode.indexOf(QChar('"'), p5 + 6);
                                    if (p6 > p5 + 5 && p6 < p2) {
                                        QString hrefValue = htmlCode.mid(p5 + 6, p6 - p5 - 6).replace(QLatin1Char('&'), QLatin1String("&amp;")).replace(QLatin1Char('>'), QLatin1String("&gt;")).replace(QLatin1Char('<'), QLatin1String("&lt;"));
                                        /// Do some resolving in case favicon URL in HTML code is relative
                                        favIconUrl = reply->url().resolved(QUrl(hrefValue));
                                        if (favIconUrl.isValid()) {
                                            qCDebug(LOG_KBIBTEX_NETWORKING) << "Found favicon URL" << favIconUrl.toDisplayString() << "in HTML code of webpage" << webpageUrl.toDisplayString();
                                            break;
                                        } else
                                            favIconUrl.clear();
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        if (!favIconUrl.isValid()) {
            favIconUrl = reply->url();
            favIconUrl.setPath(QStringLiteral("/favicon.ico"));
            qCInfo(LOG_KBIBTEX_NETWORKING) << "Could not locate favicon in HTML code for webpage" << webpageUrl.toDisplayString() << ", falling back to" << favIconUrl.toDisplayString();
        }

        QNetworkRequest request(favIconUrl);
        request.setAttribute(QNetworkRequest::FollowRedirectsAttribute, true);
        QNetworkReply *reply = InternalNetworkAccessManager::instance().get(request);
        connect(reply, &QNetworkReply::finished, this, [this, reply, fileNameStem, favIconUrl, webpageUrl]() {
            if (reply->error() == QNetworkReply::NoError) {
                const QByteArray iconData = reply->readAll();
                if (iconData.size() > 10) {
                    QString extension;
                    if (iconData[1] == 'P' && iconData[2] == 'N' && iconData[3] == 'G') {
                        /// PNG files have string "PNG" at second to fourth byte
                        extension = QStringLiteral(".png");
                    } else if (iconData[0] == static_cast<char>(0x00) && iconData[1] == static_cast<char>(0x00) && iconData[2] == static_cast<char>(0x01) && iconData[3] == static_cast<char>(0x00)) {
                        /// Microsoft Icon have first two bytes always 0x0000,
                        /// third and fourth byte is 0x0001 (for .ico)
                        extension = QStringLiteral(".ico");
                    } else if (iconData[0] == '<') {
                        /// HTML or XML code
                        const QString htmlCode = QString::fromUtf8(iconData);
                        qCWarning(LOG_KBIBTEX_NETWORKING) << "Received XML or HTML data from " << InternalNetworkAccessManager::removeApiKey(reply->url()).toDisplayString() << ": " << htmlCode.left(128);
                    } else {
                        qCWarning(LOG_KBIBTEX_NETWORKING) << "Favicon is of unknown format: " << InternalNetworkAccessManager::removeApiKey(reply->url()).toDisplayString();
                    }

                    if (!extension.isEmpty()) {
                        const QString filename = fileNameStem + extension;

                        QFile iconFile(filename);
                        if (iconFile.open(QFile::WriteOnly)) {
                            iconFile.write(iconData);
                            iconFile.close();
                            qCInfo(LOG_KBIBTEX_NETWORKING) << "Got icon from URL" << favIconUrl.toDisplayString() << "for webpage" << webpageUrl.toDisplayString() << "stored in" << filename;
                            favIcon = QIcon(filename);
                        } else {
                            qCWarning(LOG_KBIBTEX_NETWORKING) << "Could not save icon data from URL" << InternalNetworkAccessManager::removeApiKey(reply->url()).toDisplayString() << "to file" << filename;
                        }
                    }
                } else {
                    /// Unlikely that an icon's data is less than 10 bytes,
                    /// must be an error.
                    qCWarning(LOG_KBIBTEX_NETWORKING) << "Received invalid icon data from " << InternalNetworkAccessManager::removeApiKey(reply->url()).toDisplayString();
                }
            } else
                qCWarning(LOG_KBIBTEX_NETWORKING) << "Could not download icon from URL " << InternalNetworkAccessManager::removeApiKey(reply->url()).toDisplayString() << ": " << reply->errorString();

            QMetaObject::invokeMethod(this, "gotIcon", Qt::DirectConnection, QGenericReturnArgument(), Q_ARG(QIcon, favIcon));
        });
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &chunk : chunksAuthor) {
            if (index > 1)
                query.addQueryItem(QString(QStringLiteral("operator%1")).arg(index), QStringLiteral("AND"));
            query.addQueryItem(QString(QStringLiteral("option%1")).arg(index), QStringLiteral("author"));
            query.addQueryItem(QString(QStringLiteral("value%1")).arg(index), chunk);
            ++index;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            QApplication::clipboard()->setText(lineEditAuthorizationUrl->text());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const ValueLine &valueLine : const_cast<const ValueLineList &>(values)) {
        if (valueLine.text == cmpText)
            return i;
        ++i;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const MathCommand &mathCommand : mathCommands) {
                                if ((mathCommand.direction & DirectionCommandToUnicode) && mathCommand.command == alpha) {
                                    output.append(QChar(mathCommand.unicode));
                                    found = true;
                                    break;
                                }
                            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &valueItem : v) {
            QString plainText = PlainTextValue::text(*valueItem);

            static const QRegularExpression regExpEscapedChars = QRegularExpression(QStringLiteral("\\\\+([&_~])"));
            plainText.replace(regExpEscapedChars,QStringLiteral("\\1"));

            urlsInText(plainText, testExistence, baseDirectory, result);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &element : const_cast<const File &>(*bibTeXFile)) {
        QSharedPointer<Entry> entry = element.dynamicCast<Entry>();
        if (!entry.isNull()) {
            ++countEntries;
            lastEntryId = entry->id();

            Value authors = entry->value(Entry::ftAuthor);
            if (!authors.isEmpty()) {
                ValueItem *vi = authors.last().data();
                Person *p = dynamic_cast<Person *>(vi);
                if (p != nullptr) {
                    lastEntryLastAuthorLastName = p->lastName();
                } else
                    lastEntryLastAuthorLastName.clear();
            } else {
                Value editors = entry->value(Entry::ftEditor);
                if (!editors.isEmpty()) {
                    ValueItem *vi = editors.last().data();
                    Person *p = dynamic_cast<Person *>(vi);
                    if (p != nullptr) {
                        lastEntryLastAuthorLastName = p->lastName();
                    } else
                        lastEntryLastAuthorLastName.clear();
                } else
                    lastEntryLastAuthorLastName.clear();
            }

            if (!lastEntryLastAuthorLastName.isEmpty()) {
                if (lastEntryLastAuthorLastName[0] == QLatin1Char('{') && lastEntryLastAuthorLastName[lastEntryLastAuthorLastName.length() - 1] == QLatin1Char('}'))
                    lastEntryLastAuthorLastName = lastEntryLastAuthorLastName.mid(1, lastEntryLastAuthorLastName.length() - 2);
                lastAuthorsList << lastEntryLastAuthorLastName;
            }

            for (int index = 1; index < 100; ++index) {
                const QString field = index == 1 ? Entry::ftUrl : QString(QStringLiteral("%1%2")).arg(Entry::ftUrl).arg(index);
                const Value v = entry->value(field);
                for (const QSharedPointer<ValueItem> &vi : v) {
                    filesUrlsDoiList << PlainTextValue::text(vi);
                }
                if (v.isEmpty() && index > 10) break;
            }
            for (int index = 1; index < 100; ++index) {
                const QString field = index == 1 ? Entry::ftDOI : QString(QStringLiteral("%1%2")).arg(Entry::ftDOI).arg(index);
                const Value v = entry->value(field);
                for (const QSharedPointer<ValueItem> &vi : v) {
                    filesUrlsDoiList << PlainTextValue::text(vi);
                }
                if (v.isEmpty() && index > 10) break;
            }
            for (int index = 1; index < 100; ++index) {
                const QString field = index == 1 ? Entry::ftLocalFile : QString(QStringLiteral("%1%2")).arg(Entry::ftLocalFile).arg(index);
                const Value v = entry->value(field);
                for (const QSharedPointer<ValueItem> &vi : v) {
                    filesUrlsDoiList << PlainTextValue::text(vi);
                }
                if (v.isEmpty() && index > 10) break;
            }
            for (int index = 1; index < 100; ++index) {
                const QString field = index == 1 ? Entry::ftFile : QString(QStringLiteral("%1%2")).arg(Entry::ftFile).arg(index);
                const Value v = entry->value(field);
                for (const QSharedPointer<ValueItem> &vi : v) {
                    filesUrlsDoiList << PlainTextValue::text(vi);
                }
                if (v.isEmpty() && index > 10) break;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &ed : const_cast<const BibTeXEntries &>(*this)) {
        /// Configuration file uses camel-case, convert this to lower case for faster comparison
        QString itName = ed.upperCamelCase.toLower();
        if (itName == iName || (!(itName = ed.upperCamelCaseAlt.toLower()).isEmpty() && itName == iName))
            return ed.label;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &element : const_cast<const File &>(*file))
                countElement(element, numEntries, numJournalArticles, numConferencePublications, numBooks, numComments, numMacros);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            openUrl();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &token : tokenList) {
            TokenWidget *tokenWidget = nullptr;

            if (token[0] == 'a' || token[0] == 'A' || token[0] == 'z') {
                IdSuggestions::IdSuggestionTokenInfo info = IdSuggestions::evalToken(token.mid(1));
                /// Support deprecated 'a' and 'z' cases
                if (token[0] == 'a')
                    info.startWord = info.endWord = 0;
                else if (token[0] == 'z') {
                    info.startWord = 1;
                    info.endWord = std::numeric_limits<int>::max();
                }
                tokenWidget = new AuthorWidget(info, p, container);
                widgetList << tokenWidget;
                containerLayout->insertWidget(containerLayout->count() - 2, tokenWidget, 1);
            } else if (token[0] == 'y') {
                tokenWidget = new YearWidget(2, p, container);
                widgetList << tokenWidget;
                containerLayout->insertWidget(containerLayout->count() - 2, tokenWidget, 1);
            } else if (token[0] == 'Y') {
                tokenWidget = new YearWidget(4, p, container);
                widgetList << tokenWidget;
                containerLayout->insertWidget(containerLayout->count() - 2, tokenWidget, 1);
            } else if (token[0] == 't' || token[0] == 'T') {
                IdSuggestions::IdSuggestionTokenInfo info = IdSuggestions::evalToken(token.mid(1));
                tokenWidget = new TitleWidget(info, token[0].isUpper(), p, container);
                widgetList << tokenWidget;
                containerLayout->insertWidget(containerLayout->count() - 2, tokenWidget, 1);
            } else if (token[0] == 'j' || token[0] == 'J') {
                IdSuggestions::IdSuggestionTokenInfo info = IdSuggestions::evalToken(token.mid(1));
                tokenWidget = new JournalWidget(info, token[0].isUpper(), p, container);
                widgetList << tokenWidget;
                containerLayout->insertWidget(containerLayout->count() - 2, tokenWidget, 1);
            } else if (token[0] == 'e') {
                IdSuggestions::IdSuggestionTokenInfo info = IdSuggestions::evalToken(token.mid(1));
                tokenWidget = new TypeWidget(info, p, container);
                widgetList << tokenWidget;
                containerLayout->insertWidget(containerLayout->count() - 2, tokenWidget, 1);
            } else if (token[0] == 'v') {
                tokenWidget = new VolumeWidget(p, container);
                widgetList << tokenWidget;
                containerLayout->insertWidget(containerLayout->count() - 2, tokenWidget, 1);
            } else if (token[0] == 'p') {
                tokenWidget = new PageNumberWidget(p, container);
                widgetList << tokenWidget;
                containerLayout->insertWidget(containerLayout->count() - 2, tokenWidget, 1);
            } else if (token[0] == '"') {
                tokenWidget = new TextWidget(token.mid(1), p, container);
                widgetList << tokenWidget;
                containerLayout->insertWidget(containerLayout->count() - 2, tokenWidget, 1);
            }

            if (tokenWidget != nullptr)
                addManagementButtons(tokenWidget);
        }
```

#### AUTO 


```{c}
auto firstUrlIt = urlsToCheck.begin();
```

#### AUTO 


```{c}
const auto appleWebKitVersionMinor = randomGeneratorGlobalBounded(3, 53);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &line : const_cast<const QStringList &>(bibtexOuput)) {
        QRegularExpressionMatch match;
        if ((match = errorLine.match(line)).hasMatch()) {
            buffer.open(QIODevice::ReadOnly);
            QTextStream ts(&buffer);
            bool ok = false;
            for (int i = match.captured(1).toInt(&ok); ok && i > 1; --i) {
                errorPlainText = ts.readLine();
                buffer.close();
            }
        } else if (line.startsWith(QStringLiteral("Warning--"))) {
            /// is a warning ...

            if ((match = warningEmptyField.match(line)).hasMatch()) {
                /// empty/missing field
                warnings << i18n("Field <b>%1</b> is empty", match.captured(1));
            } else if ((match = warningEmptyField2.match(line)).hasMatch()) {
                /// two empty/missing fields
                warnings << i18n("Fields <b>%1</b> and <b>%2</b> are empty, but at least one is required", match.captured(1), match.captured(2));
            } else if ((match = warningThereIsBut.match(line)).hasMatch()) {
                /// there is a field which exists but another does not exist
                warnings << i18n("Field <b>%1</b> exists, but <b>%2</b> does not exist", match.captured(1), match.captured(2));
            } else if ((match = warningCantUseBoth.match(line)).hasMatch()) {
                /// there are two conflicting fields, only one may be used
                warnings << i18n("Fields <b>%1</b> and <b>%2</b> cannot be used at the same time", match.captured(1), match.captured(2));
            } else if ((match = warningSort2.match(line)).hasMatch()) {
                /// one out of two fields missing for sorting
                warnings << i18n("Fields <b>%1</b> or <b>%2</b> are required to sort entry", match.captured(1), match.captured(2));
            } else if ((match = warningSort3.match(line)).hasMatch()) {
                /// one out of three fields missing for sorting
                warnings << i18n("Fields <b>%1</b>, <b>%2</b>, <b>%3</b> are required to sort entry", match.captured(1), match.captured(2), match.captured(3));
            } else {
                /// generic/unknown warning
                warnings << i18n("Unknown warning: %1", line.mid(warningStart.length()));
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &text : yearWords)
            queryFragments.append(text);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &valueItem : const_cast<const Value &>(combinedValue)) {
        const QSharedPointer<const VerbatimText> verbatimText = valueItem.dynamicCast<const VerbatimText>();
        if (!verbatimText.isNull()) {
            const QString text = verbatimText->text();
            if (KBibTeX::urlRegExp.indexIn(text) > -1) {
                /// add full URL
                VerbatimText *newVT = new VerbatimText(KBibTeX::urlRegExp.cap(0));
                /// test for duplicates
                if (urlValue.contains(*newVT))
                    delete newVT;
                else
                    urlValue.append(QSharedPointer<VerbatimText>(newVT));
            } else if (KBibTeX::doiRegExp.indexIn(text) > -1) {
                /// add DOI
                VerbatimText *newVT = new VerbatimText(KBibTeX::doiRegExp.cap(0));
                /// test for duplicates
                if (doiValue.contains(*newVT))
                    delete newVT;
                else
                    doiValue.append(QSharedPointer<VerbatimText>(newVT));
            } else {
                /// add anything else (e.g. local file)
                VerbatimText *newVT = new VerbatimText(*verbatimText);
                /// test for duplicates
                if (localFileValue.contains(*newVT))
                    delete newVT;
                else
                    localFileValue.append(QSharedPointer<VerbatimText>(newVT));
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const HiddenTabInfo &hti : const_cast<const QSet<HiddenTabInfo> &>(d->hiddenTabInfo)) {
        if (hti.widget == page) {
            int pos = d->showTab(hti);
            setTabText(pos, label);
            return pos;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &param : copyParameters) {
            query.addQueryItem(param, formParams[param]);
        }
```

#### AUTO 


```{c}
auto it = keyFileTable.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &chunk : chunksFreeText) {
            if (index > 1)
                q.addQueryItem(QString(QStringLiteral("operator%1")).arg(index), QStringLiteral("AND"));
            q.addQueryItem(QString(QStringLiteral("option%1")).arg(index), QStringLiteral("fulltext"));
            q.addQueryItem(QString(QStringLiteral("value%1")).arg(index), chunk);
            ++index;
        }
```

#### AUTO 


```{c}
const auto chromeVersionPatch = QRandomGenerator::global()->bounded(53, 673);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Value &value : const_cast<const QVector<Value> &>(chosenValueMap[field]))
            if (PlainTextValue::text(value) == text)
                return;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &doi : doiSet)
                list.append(doi);
```

#### AUTO 


```{c}
const auto &keyword
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : entryUrlList) {
                if (url.isLocalFile() && url.fileName().endsWith(QStringLiteral(".pdf"))) {
                    // FIXME if you have a large collection of PDF files and the text version
                    // has not been generated yet, this will freeze KBibTeX for some time
                    const QString text = FileInfo::pdfToText(url.url(QUrl::PreferLocalFile));
                    int i = 0;
                    for (QStringList::ConstIterator itsl = m_filterQuery.terms.constBegin(); itsl != m_filterQuery.terms.constEnd(); ++itsl, ++i)
                        eachTerm[i] |= (*itsl).isEmpty() ? true : text.contains(*itsl, Qt::CaseInsensitive);
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QSharedPointer<ValueItem> &valueItem : itValue) {
                        /// Check if ValueItem to process points to a person
                        const QSharedPointer<Person> person = valueItem.dynamicCast<Person>();
                        if (!person.isNull()) {
                            /// Assemble a list of formatting templates for a person's name
                            static QStringList personNameFormattingList; ///< use static to do pattern assembly only once
                            if (personNameFormattingList.isEmpty()) {
                                /// Use the two default patterns last-name-first and first-name-first
                                personNameFormattingList << Preferences::personNameFormatLastFirst << Preferences::personNameFormatFirstLast;
                                /// Check configuration if user-specified formatting template is different
                                KSharedConfigPtr config(KSharedConfig::openConfig(QStringLiteral("kbibtexrc")));
                                KConfigGroup configGroup(config, "General");
                                QString personNameFormatting = configGroup.readEntry(Preferences::keyPersonNameFormatting, Preferences::defaultPersonNameFormatting);
                                /// Add user's template if it differs from the two specified above
                                if (!personNameFormattingList.contains(personNameFormatting))
                                    personNameFormattingList << personNameFormatting;
                            }
                            /// Add person's name formatted using each of the templates assembled above
                            for (const QString &personNameFormatting : const_cast<const QStringList &>(personNameFormattingList)) {
                                valueSet.insert(Person::transcribePersonName(person.data(), personNameFormatting));
                            }
                        } else {
                            /// Default case: use PlainTextValue::text to translate ValueItem
                            /// to a human-readable text
                            valueSet.insert(PlainTextValue::text(*valueItem));
                        }
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &valueItem : value) {
            QSharedPointer<const MacroKey> macroKey = valueItem.dynamicCast<const MacroKey>();
            if (!macroKey.isNull()) {
                if (isOpen) result.append(stringCloseDelimiter);
                isOpen = false;
                if (!result.isEmpty()) result.append(QStringLiteral(" # "));
                result.append(macroKey->text());
                prev = macroKey;
            } else {
                QSharedPointer<const PlainText> plainText = valueItem.dynamicCast<const PlainText>();
                if (!plainText.isNull()) {
                    QString textBody = applyEncoder(plainText->text(), useLaTeXEncoding);
                    if (!isOpen) {
                        if (!result.isEmpty()) result.append(" # ");
                        result.append(stringOpenDelimiter);
                    } else if (!prev.dynamicCast<const PlainText>().isNull())
                        result.append(' ');
                    else if (!prev.dynamicCast<const Person>().isNull()) {
                        /// handle "et al." i.e. "and others"
                        result.append(" and ");
                    } else {
                        result.append(stringCloseDelimiter).append(" # ").append(stringOpenDelimiter);
                    }
                    isOpen = true;

                    if (stringOpenDelimiter == QLatin1Char('"'))
                        protectQuotationMarks(textBody);
                    result.append(textBody);
                    prev = plainText;
                } else {
                    QSharedPointer<const VerbatimText> verbatimText = valueItem.dynamicCast<const VerbatimText>();
                    if (!verbatimText.isNull()) {
                        QString textBody = verbatimText->text();
                        if (!isOpen) {
                            if (!result.isEmpty()) result.append(" # ");
                            result.append(stringOpenDelimiter);
                        } else if (!prev.dynamicCast<const VerbatimText>().isNull()) {
                            const QString keyToLower(key.toLower());
                            if (keyToLower.startsWith(Entry::ftUrl) || keyToLower.startsWith(Entry::ftLocalFile) || keyToLower.startsWith(Entry::ftFile) || keyToLower.startsWith(Entry::ftDOI))
                                /// Filenames and alike have be separated by a semicolon,
                                /// as a plain comma may be part of the filename or URL
                                result.append(QStringLiteral("; "));
                            else
                                result.append(' ');
                        } else {
                            result.append(stringCloseDelimiter).append(" # ").append(stringOpenDelimiter);
                        }
                        isOpen = true;

                        if (stringOpenDelimiter == QLatin1Char('"'))
                            protectQuotationMarks(textBody);
                        result.append(textBody);
                        prev = verbatimText;
                    } else {
                        QSharedPointer<const Person> person = valueItem.dynamicCast<const Person>();
                        if (!person.isNull()) {
                            QString firstName = person->firstName();
                            if (!firstName.isEmpty() && requiresPersonQuoting(firstName, false))
                                firstName = firstName.prepend("{").append("}");

                            QString lastName = person->lastName();
                            if (!lastName.isEmpty() && requiresPersonQuoting(lastName, true))
                                lastName = lastName.prepend("{").append("}");

                            QString suffix = person->suffix();

                            /// Fall back and enforce comma-based name formatting
                            /// if name contains a suffix like "Jr."
                            /// Otherwise name could not be parsed again reliable
                            const QString pnf = suffix.isEmpty() ? personNameFormatting : Preferences::personNameFormatLastFirst;
                            QString thisName = applyEncoder(Person::transcribePersonName(pnf, firstName, lastName, suffix), useLaTeXEncoding);

                            if (!isOpen) {
                                if (!result.isEmpty()) result.append(" # ");
                                result.append(stringOpenDelimiter);
                            } else if (!prev.dynamicCast<const Person>().isNull())
                                result.append(" and ");
                            else {
                                result.append(stringCloseDelimiter).append(" # ").append(stringOpenDelimiter);
                            }
                            isOpen = true;

                            if (stringOpenDelimiter == QLatin1Char('"'))
                                protectQuotationMarks(thisName);
                            result.append(thisName);
                            prev = person;
                        } else {
                            QSharedPointer<const Keyword> keyword = valueItem.dynamicCast<const Keyword>();
                            if (!keyword.isNull()) {
                                QString textBody = applyEncoder(keyword->text(), useLaTeXEncoding);
                                if (!isOpen) {
                                    if (!result.isEmpty()) result.append(" # ");
                                    result.append(stringOpenDelimiter);
                                } else if (!prev.dynamicCast<const Keyword>().isNull())
                                    result.append(listSeparator);
                                else {
                                    result.append(stringCloseDelimiter).append(" # ").append(stringOpenDelimiter);
                                }
                                isOpen = true;

                                if (stringOpenDelimiter == QLatin1Char('"'))
                                    protectQuotationMarks(textBody);
                                result.append(textBody);
                                prev = keyword;
                            }
                        }
                    }
                }
            }
            prev = valueItem;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &element : const_cast<const File &>(*this)) {
        const QSharedPointer<Entry> entry = element.dynamicCast<Entry>();
        if (!entry.isNull())
            for (Entry::ConstIterator it = entry->constBegin(); it != entry->constEnd(); ++it)
                if (it.key().toLower() == lcFieldName) {
                    const auto itValue = it.value();
                    for (const QSharedPointer<ValueItem> &valueItem : itValue) {
                        /// Check if ValueItem to process points to a person
                        const QSharedPointer<Person> person = valueItem.dynamicCast<Person>();
                        if (!person.isNull()) {
                            QSet<QString> personNameFormattingSet {Preferences::personNameFormatLastFirst, Preferences::personNameFormatFirstLast};
                            personNameFormattingSet.insert(Preferences::instance().personNameFormatting());
                            /// Add person's name formatted using each of the templates assembled above
                            for (const QString &personNameFormatting : const_cast<const QSet<QString> &>(personNameFormattingSet))
                                valueSet.insert(Person::transcribePersonName(person.data(), personNameFormatting));
                        } else {
                            /// Default case: use PlainTextValue::text to translate ValueItem
                            /// to a human-readable text
                            valueSet.insert(PlainTextValue::text(*valueItem));
                        }
                    }
                }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &element : const_cast<const File &>(*bibtexFile)) {
                    QSharedPointer<Entry> entry = element.dynamicCast<Entry>();
                    publishEntry(entry);
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &formatString : formatStrings) {
        result << formatId(entry, formatString);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &keyword : keywordList)
                                        v.append(keyword);
```

#### RANGE FOR STATEMENT 


```{c}
for (OpenFileInfo *ofi : const_cast<const OpenFileInfoManager::OpenFileInfoList &>(d->openFileInfoList)) {
        if (!isClosing && ofi == openFileInfo && openFileInfo->close()) {
            isClosing = true;
            /// Mark file as closed (i.e. not open)
            openFileInfo->removeFlags(OpenFileInfo::StatusFlag::Open);
            /// If file has a filename, remember as recently used
            if (openFileInfo->flags().testFlag(OpenFileInfo::StatusFlag::HasName))
                openFileInfo->addFlags(OpenFileInfo::StatusFlag::RecentlyUsed);
        } else if (nextCurrent == nullptr && ofi->flags().testFlag(OpenFileInfo::StatusFlag::Open))
            nextCurrent = ofi;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &ed : const_cast<const BibTeXEntries &>(*be))
                if (typeLower == ed.upperCamelCaseAlt.toLower()) {
                    index = entryType->findData(ed.upperCamelCase);
                    break;
                }
```

#### LAMBDA EXPRESSION 


```{c}
connectStartingDelayedTimer(comboBoxField, static_cast<void(QComboBox::*)(int)>(&QComboBox::currentIndexChanged))
```

#### RANGE FOR STATEMENT 


```{c}
for (const HiddenTabInfo &hti : const_cast<const QSet<HiddenTabInfo> &>(m_hiddenTabInfo)) {
            if (hti.widget == page) {
                m_hiddenTabInfo.remove(hti);
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &valueItem : value) {
            QSharedPointer<const MacroKey> macroKey = valueItem.dynamicCast<const MacroKey>();
            if (!macroKey.isNull()) {
                if (isOpen) result.append(stringCloseDelimiter);
                isOpen = false;
                if (!result.isEmpty()) result.append(QStringLiteral(" # "));
                result.append(macroKey->text());
                prev = macroKey;
            } else {
                QSharedPointer<const PlainText> plainText = valueItem.dynamicCast<const PlainText>();
                if (!plainText.isNull()) {
                    QString textBody = EncoderLaTeX::instance().encode(plainText->text(), targetEncoding);
                    if (!isOpen) {
                        if (!result.isEmpty()) result.append(" # ");
                        result.append(stringOpenDelimiter);
                    } else if (!prev.dynamicCast<const PlainText>().isNull())
                        result.append(' ');
                    else if (!prev.dynamicCast<const Person>().isNull()) {
                        /// handle "et al." i.e. "and others"
                        result.append(" and ");
                    } else {
                        result.append(stringCloseDelimiter).append(" # ").append(stringOpenDelimiter);
                    }
                    isOpen = true;

                    if (stringOpenDelimiter == QLatin1Char('"'))
                        protectQuotationMarks(textBody);
                    result.append(textBody);
                    prev = plainText;
                } else {
                    QSharedPointer<const VerbatimText> verbatimText = valueItem.dynamicCast<const VerbatimText>();
                    if (!verbatimText.isNull()) {
                        const QString keyToLower(key.toLower());
                        QString textBody = verbatimText->text();
                        if (!isOpen) {
                            if (!result.isEmpty()) result.append(" # ");
                            result.append(stringOpenDelimiter);
                        } else if (!prev.dynamicCast<const VerbatimText>().isNull()) {
                            if (keyToLower.startsWith(Entry::ftUrl) || keyToLower.startsWith(Entry::ftLocalFile) || keyToLower.startsWith(Entry::ftFile) || keyToLower.startsWith(Entry::ftDOI))
                                /// Filenames and alike have be separated by a semicolon,
                                /// as a plain comma may be part of the filename or URL
                                result.append(QStringLiteral("; "));
                            else
                                result.append(' ');
                        } else {
                            result.append(stringCloseDelimiter).append(" # ").append(stringOpenDelimiter);
                        }
                        isOpen = true;

                        if (stringOpenDelimiter == QLatin1Char('"'))
                            protectQuotationMarks(textBody);
                        if (keyToLower == Entry::ftFile && verbatimText->hasComment()) {
                            /// Special case: This verbatim text is for a 'file' field and contains a comment.
                            /// This means it most probably came from JabRef which makes use of the non-standard
                            /// format of   comment:filename:filetype
                            /// To be compatible with JabRef, rebuild a string that matches what JabRef would
                            /// generate. As filetype is not stored, make an educated guess here.
                            /// Also, filenames are not verbatim for JabRef, so  _  must be written as  \_
                            const int p = qMin(textBody.length(), qMin(8, qMax(2, textBody.lastIndexOf(QLatin1Char('.')))));
                            const QString extension = textBody.right(p).toLower();
                            const QString filetype = extension == QStringLiteral(".pdf") ? QStringLiteral("PDF") : extension == QStringLiteral(".html") || extension == QStringLiteral(".htm") ? QStringLiteral("HTML") : extension == QStringLiteral(".doc") ? QStringLiteral("DOC") : extension == QStringLiteral(".docx") ? QStringLiteral("DOCX") : QStringLiteral("BINARY");
                            result.append(verbatimText->comment()).append(QLatin1Char(':')).append(EncoderLaTeX::instance().encode(textBody, EncoderLaTeX::TargetEncoding::ASCII)).append(QLatin1Char(':')).append(filetype);
                        } else
                            result.append(textBody);
                        prev = verbatimText;
                    } else {
                        QSharedPointer<const Person> person = valueItem.dynamicCast<const Person>();
                        if (!person.isNull()) {
                            QString firstName = person->firstName();
                            if (!firstName.isEmpty() && requiresPersonQuoting(firstName, false))
                                firstName = firstName.prepend("{").append("}");

                            QString lastName = person->lastName();
                            if (!lastName.isEmpty() && requiresPersonQuoting(lastName, true))
                                lastName = lastName.prepend("{").append("}");

                            QString suffix = person->suffix();

                            /// Fall back and enforce comma-based name formatting
                            /// if name contains a suffix like "Jr."
                            /// Otherwise name could not be parsed again reliable
                            const QString pnf = suffix.isEmpty() ? personNameFormatting : Preferences::personNameFormatLastFirst;
                            QString thisName = EncoderLaTeX::instance().encode(Person::transcribePersonName(pnf, firstName, lastName, suffix), targetEncoding);

                            if (!isOpen) {
                                if (!result.isEmpty()) result.append(" # ");
                                result.append(stringOpenDelimiter);
                            } else if (!prev.dynamicCast<const Person>().isNull())
                                result.append(" and ");
                            else {
                                result.append(stringCloseDelimiter).append(" # ").append(stringOpenDelimiter);
                            }
                            isOpen = true;

                            if (stringOpenDelimiter == QLatin1Char('"'))
                                protectQuotationMarks(thisName);
                            result.append(thisName);
                            prev = person;
                        } else {
                            QSharedPointer<const Keyword> keyword = valueItem.dynamicCast<const Keyword>();
                            if (!keyword.isNull()) {
                                QString textBody = EncoderLaTeX::instance().encode(keyword->text(), targetEncoding);
                                if (!isOpen) {
                                    if (!result.isEmpty()) result.append(" # ");
                                    result.append(stringOpenDelimiter);
                                } else if (!prev.dynamicCast<const Keyword>().isNull())
                                    result.append(listSeparator);
                                else {
                                    result.append(stringCloseDelimiter).append(" # ").append(stringOpenDelimiter);
                                }
                                isOpen = true;

                                if (stringOpenDelimiter == QLatin1Char('"'))
                                    protectQuotationMarks(textBody);
                                result.append(textBody);
                                prev = keyword;
                            }
                        }
                    }
                }
            }
            prev = valueItem;
        }
```

#### AUTO 


```{c}
const auto &queryFragment
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                    QMetaObject::invokeMethod(this, "gotIcon", Qt::DirectConnection, QGenericReturnArgument(), Q_ARG(QIcon, favIcon));
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->readConfig();
    }
```

#### AUTO 


```{c}
const auto selectedRows = selectionModel->selectedRows();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &element : const_cast<const File &>(*bibtexFile)) {
                    QSharedPointer<Entry> entry = element.dynamicCast<Entry>();
                    if (!entry.isNull()) {
                        Value v;
                        v.append(QSharedPointer<VerbatimText>(new VerbatimText(label())));
                        entry->insert(QStringLiteral("x-fetchedfrom"), v);
                        if (!primaryUrl.isEmpty()) {
                            /// There is an external document associated with this BibTeX entry
                            Value urlValue = entry->value(Entry::ftUrl);
                            urlValue.append(QSharedPointer<VerbatimText>(new VerbatimText(primaryUrl)));
                            entry->insert(Entry::ftUrl, urlValue);
                        }
                        if (!documentUrl.isEmpty() &&
                                primaryUrl != documentUrl /** avoid duplicates */) {
                            /// There is a web page associated with this BibTeX entry
                            Value urlValue = entry->value(Entry::ftUrl);
                            urlValue.append(QSharedPointer<VerbatimText>(new VerbatimText(documentUrl)));
                            entry->insert(Entry::ftUrl, urlValue);
                        }
                        emit foundEntry(entry);
                        hasEntry = true;
                    }
                }
```

#### AUTO 


```{c}
const auto respectingQuotationMarks = p->splitRespectingQuotationMarks(form->lineEditFreeText->text());
```

#### RANGE FOR STATEMENT 


```{c}
for (QString filename : fileList) {
                        QString comment;
                        bool hasComment = false; ///< need to have extra flag for comment, as even an empty comment counts as comment
                        if (iKey == Entry::ftFile) {
                            /// Check 'file' field for a JabRef-specific formatting, extract filename
                            /// Example of JabRef-specific value:
                            ///     Some optional text:path/to/file\_name.pdf:PDF
                            /// Regular expression will try to extract filename, then decode some LaTeX-isms
                            /// to get  path/to/file_name.pdf  for in above example
                            static const QRegularExpression jabrefFileRegExp(QStringLiteral("^([^:]*):(.*?):([A-Z]+|pdf)$"));
                            const QRegularExpressionMatch jabrefFileRegExpMatch = jabrefFileRegExp.match(filename);
                            if (jabrefFileRegExpMatch.hasMatch()) {
                                hasComment = true;
                                comment =  EncoderLaTeX::instance().decode(jabrefFileRegExpMatch.captured(1));
                                filename =  EncoderLaTeX::instance().decode(jabrefFileRegExpMatch.captured(2));

                                /// Furthermore, if the file came from Windows, drive letters may have been written as follows:
                                ///    C$\backslash$:/Users/joedoe/filename.pdf
                                static const QRegularExpression windowsDriveBackslashRegExp(QStringLiteral("^([A-Z])\\$\\\\backslash\\$(:.*)$"));
                                const QRegularExpressionMatch windowsDriveBackslashRegExpMatch = windowsDriveBackslashRegExp.match(filename);
                                if (windowsDriveBackslashRegExpMatch.hasMatch()) {
                                    filename = windowsDriveBackslashRegExpMatch.captured(1) + windowsDriveBackslashRegExpMatch.captured(2);
                                } else if (filename.startsWith(QStringLiteral("home/"))) {
                                    /// If filename is a relative path but by name looks almost like it should be an absolute path
                                    /// (starting with some suspicious strings), prepend a slash
                                    filename.prepend(QLatin1Char('/'));
                                }
                            }
                        }

                        VerbatimText *verbatimText = new VerbatimText(filename);
                        if (hasComment)
                            verbatimText->setComment(comment);
                        value.append(QSharedPointer<VerbatimText>(verbatimText));
                    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            addToken(ttJournal, locAtTop);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &text : yearWords)
        queryFragments.append(typedSearch.arg(QStringLiteral("d"), text));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &entry : entryList) {
            /// if merging entries with identical ids, the merged entry will not yet have an id (is null)
            if (mergedEntry->id().isEmpty())
                mergedEntry->setId(entry->id());
            /// if merging entries with identical types, the merged entry will not yet have an type (is null)
            if (mergedEntry->type().isEmpty())
                mergedEntry->setType(entry->type());

            /// add all other fields not covered by user selection
            /// those fields did only occur in one entry (no conflict)
            /// may add a lot of bloat to merged entry
            if (entryClique->isEntryChecked(entry)) {
                actuallyMerged = true;
                for (Entry::ConstIterator it = entry->constBegin(); it != entry->constEnd(); ++it)
                    if (!mergedEntry->contains(it.key()) && !coveredFields.contains(it.key())) {
                        mergedEntry->insert(it.key(), it.value());
                        coveredFields << it.key();
                    }
                const int row = fileModel->row(entry);
                if (preferredInsertionRow < 0) preferredInsertionRow = row;
                fileModel->removeRow(row);
            }
        }
```

#### AUTO 


```{c}
const auto chromeVersionBuild = randomGeneratorGlobalBounded(3793, 8973);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &element : const_cast<const File &>(*bibtexFile)) {
                QSharedPointer<Entry> entry = element.dynamicCast<Entry>();
                hasEntries |= publishEntry(entry);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        stopSearch(m_delayedStoppedSearchReturnCode);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, url, reply]() {
                QNetworkRequest request(url);
                QNetworkReply *newReply = InternalNetworkAccessManager::instance().get(request, reply);
                InternalNetworkAccessManager::instance().setNetworkReplyTimeout(newReply);
                connect(newReply, &QNetworkReply::finished, this, &OnlineSearchGoogleScholar::doneFetchingQueryPage);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this, reply]() {
            const QUrl url = reply->url();
            if (reply->error() != QNetworkReply::NoError) {
                /// Instead of an 'emit' ...
                QMetaObject::invokeMethod(p, "urlChecked", Qt::DirectConnection, QGenericReturnArgument(), Q_ARG(QUrl, url), Q_ARG(UrlChecker::Status, UrlChecker::NetworkError), Q_ARG(QString, reply->errorString()));
                qWarning() << "NetworkError:" << reply->errorString() << url.toDisplayString();
            } else {
                const QByteArray data = reply->read(1024);
                if (data.isEmpty()) {
                    /// Instead of an 'emit' ...
                    QMetaObject::invokeMethod(p, "urlChecked", Qt::DirectConnection, QGenericReturnArgument(), Q_ARG(QUrl, url), Q_ARG(UrlChecker::Status, UrlChecker::UnknownError), Q_ARG(QString, QStringLiteral("No data received")));
                    qWarning() << "UnknownError: No data received" << url.toDisplayString();
                } else {
                    const QString filename = url.fileName().toLower();
                    const bool filenameSuggestsHTML = filename.isEmpty() || filename.endsWith(QStringLiteral(".html")) || filename.endsWith(QStringLiteral(".htm"));
                    const bool filenameSuggestsPDF =  filename.endsWith(QStringLiteral(".pdf"));
                    const bool filenameSuggestsPostScript =  filename.endsWith(QStringLiteral(".ps"));
                    const bool containsHTML = data.contains("<!DOCTYPE HTML") || data.contains("<html") || data.contains("<HTML") || data.contains("<body") || data.contains("<body");
                    const bool containsPDF = data.startsWith("%PDF");
                    const bool containsPostScript = data.startsWith("%!");
                    if (filenameSuggestsPDF && containsPDF) {
                        /// Instead of an 'emit' ...
                        QMetaObject::invokeMethod(p, "urlChecked", Qt::DirectConnection, QGenericReturnArgument(), Q_ARG(QUrl, url), Q_ARG(UrlChecker::Status, UrlChecker::UrlValid), Q_ARG(QString, QString()));
                        qWarning() << "UrlValid: Looks and smells like a PDF" << url.toDisplayString();
                    } else if (filenameSuggestsPostScript && containsPostScript) {
                        /// Instead of an 'emit' ...
                        QMetaObject::invokeMethod(p, "urlChecked", Qt::DirectConnection, QGenericReturnArgument(), Q_ARG(QUrl, url), Q_ARG(UrlChecker::Status, UrlChecker::UrlValid), Q_ARG(QString, QString()));
                        qWarning() << "UrlValid: Looks and smells like a PostScript" << url.toDisplayString();
                    } else if (containsHTML) {
                        static const QRegularExpression error404(QStringLiteral("\\b404\\b"));
                        const QRegularExpressionMatch error404match = error404.match(data);
                        if (error404match.hasMatch()) {
                            /// Instead of an 'emit' ...
                            QMetaObject::invokeMethod(p, "urlChecked", Qt::DirectConnection, QGenericReturnArgument(), Q_ARG(QUrl, url), Q_ARG(UrlChecker::Status, UrlChecker::Error404), Q_ARG(QString, QStringLiteral("Got error 404")));
                            qWarning() << "Error404" << url.toDisplayString();
                        } else if (filenameSuggestsHTML) {
                            /// Instead of an 'emit' ...
                            QMetaObject::invokeMethod(p, "urlChecked", Qt::DirectConnection, QGenericReturnArgument(), Q_ARG(QUrl, url), Q_ARG(UrlChecker::Status, UrlChecker::UrlValid), Q_ARG(QString, QString()));
                            qWarning() << "UrlValid: Looks and smells like a HTML" << url.toDisplayString();
                        } else {
                            /// Instead of an 'emit' ...
                            QMetaObject::invokeMethod(p, "urlChecked", Qt::DirectConnection, QGenericReturnArgument(), Q_ARG(QUrl, url), Q_ARG(UrlChecker::Status, UrlChecker::UnexpectedFileType), Q_ARG(QString, QStringLiteral("Filename's extension does not match content")));
                            qWarning() << "NotExpectedFileType (HTML): Filename's extension does not match content" << url.toDisplayString();
                        }
                    } else if (filenameSuggestsPDF != containsPDF) {
                        /// Instead of an 'emit' ...
                        QMetaObject::invokeMethod(p, "urlChecked", Qt::DirectConnection, QGenericReturnArgument(), Q_ARG(QUrl, url), Q_ARG(UrlChecker::Status, UrlChecker::UnexpectedFileType), Q_ARG(QString, QStringLiteral("Filename's extension does not match content")));
                        qWarning() << "NotExpectedFileType (PDF): Filename's extension does not match content" << url.toDisplayString();
                    } else if (filenameSuggestsPostScript != containsPostScript) {
                        /// Instead of an 'emit' ...
                        QMetaObject::invokeMethod(p, "urlChecked", Qt::DirectConnection, QGenericReturnArgument(), Q_ARG(QUrl, url), Q_ARG(UrlChecker::Status, UrlChecker::UnexpectedFileType), Q_ARG(QString, QStringLiteral("Filename's extension does not match content")));
                        qWarning() << "NotExpectedFileType (PostScript): Filename's extension does not match content" << url.toDisplayString();
                    } else {
                        /// Instead of an 'emit' ...
                        QMetaObject::invokeMethod(p, "urlChecked", Qt::DirectConnection, QGenericReturnArgument(), Q_ARG(QUrl, url), Q_ARG(UrlChecker::Status, UrlChecker::UrlValid), Q_ARG(QString, QString()));
                        qWarning() << "UrlValid: Cannot see any issued with this URL" << url.toDisplayString();
                    }
                }
            }
            busyCounter.deref();
            queueMoreOrFinish();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &clp : const_cast<const QList<ColorLabelPair> &>(colorLabelPairs)) {
            contained = text.compare(clp.hexColor, Qt::CaseInsensitive) == 0 && clp.label.contains(pattern, Qt::CaseInsensitive);
            if (contained) break;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &token : tokens) {
        /// Position where comma was found, or -1 if no comma in token
        int p = -1;
        if (commaCount < 2) {
            /// Only check if token contains comma
            /// if no comma was found before
            int bracketCounter = 0;
            for (int i = 0; i < token.length(); ++i) {
                /// Consider opening curly brackets
                if (token[i] == QChar('{')) ++bracketCounter;
                /// Consider closing curly brackets
                else if (token[i] == QChar('}')) --bracketCounter;
                /// Only if outside any open curly bracket environments
                /// consider comma characters
                else if (bracketCounter == 0 && token[i] == QChar(',')) {
                    /// Memorize comma's position and break from loop
                    p = i;
                    break;
                } else if (bracketCounter < 0) {
                    /// Should never happen: more closing brackets than opening ones
                    qCWarning(LOG_KBIBTEX_IO) << "Opening and closing brackets do not match near line" << line_number;
                    if (parent != nullptr)
                        QMetaObject::invokeMethod(parent, "message", Qt::DirectConnection, QGenericReturnArgument(), Q_ARG(FileImporter::MessageSeverity, MessageSeverity::Warning), Q_ARG(QString, QString(QStringLiteral("Opening and closing brackets do not match near line %1")).arg(line_number)));
                }
            }
        }

        if (p >= 0) {
            if (commaCount == 0) {
                if (p > 0) partA.append(token.left(p));
                if (p < token.length() - 1) partB.append(token.mid(p + 1));
            } else if (commaCount == 1) {
                if (p > 0) partB.append(token.left(p));
                if (p < token.length() - 1) partC.append(token.mid(p + 1));
            }
            ++commaCount;
        } else if (commaCount == 0)
            partA.append(token);
        else if (commaCount == 1)
            partB.append(token);
        else if (commaCount == 2)
            partC.append(token);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &unusedValue : unusedValues) {
            const QString valueString = object.value(unusedValue).toString();
            if (!valueString.isEmpty())
                qDebug(LOG_KBIBTEX_NETWORKING) << "unused value:" << unusedValue << "=" << valueString;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &element : const_cast<const File &>(*this)) {
        const QSharedPointer<Entry> entry = element.dynamicCast<Entry>();
        if (!entry.isNull())
            for (Entry::ConstIterator it = entry->constBegin(); it != entry->constEnd(); ++it)
                if (it.key().toLower() == lcFieldName) {
                    const auto itValue = it.value();
                    for (const QSharedPointer<ValueItem> &valueItem : itValue) {
                        /// Check if ValueItem to process points to a person
                        const QSharedPointer<Person> person = valueItem.dynamicCast<Person>();
                        if (!person.isNull()) {
                            /// Assemble a list of formatting templates for a person's name
                            static QStringList personNameFormattingList; ///< use static to do pattern assembly only once
                            if (personNameFormattingList.isEmpty()) {
                                /// Use the two default patterns last-name-first and first-name-first
#ifdef HAVE_KF5
                                personNameFormattingList << Preferences::personNameFormatLastFirst << Preferences::personNameFormatFirstLast;
                                /// Check configuration if user-specified formatting template is different
                                KSharedConfigPtr config(KSharedConfig::openConfig(QStringLiteral("kbibtexrc")));
                                KConfigGroup configGroup(config, "General");
                                QString personNameFormatting = configGroup.readEntry(Preferences::keyPersonNameFormatting, Preferences::defaultPersonNameFormatting);
                                /// Add user's template if it differs from the two specified above
                                if (!personNameFormattingList.contains(personNameFormatting))
                                    personNameFormattingList << personNameFormatting;
#else // HAVE_KF5
                                personNameFormattingList << QStringLiteral("<%l><, %s><, %f>") << QStringLiteral("<%f ><%l>< %s>");
#endif // HAVE_KF5
                            }
                            /// Add person's name formatted using each of the templates assembled above
                            for (const QString &personNameFormatting : const_cast<const QStringList &>(personNameFormattingList)) {
                                valueSet.insert(Person::transcribePersonName(person.data(), personNameFormatting));
                            }
                        } else {
                            /// Default case: use PlainTextValue::text to translate ValueItem
                            /// to a human-readable text
                            valueSet.insert(PlainTextValue::text(*valueItem));
                        }
                    }
                }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QJsonValue &itemValue : itemsArray) {
                            if (itemValue.isObject()) {
                                const QJsonObject itemObject = itemValue.toObject();
                                if (itemObject.count() == 1) {
                                    if (itemObject.constBegin().value().isObject()) {
                                        Entry *entry = d->entryFromJsonObject(itemObject.constBegin().value().toObject());
                                        if (entry != nullptr) {
                                            if (publishEntry(QSharedPointer<Entry>(entry)))
                                                ++d->numFoundResults;
                                        } else {
                                            qCWarning(LOG_KBIBTEX_NETWORKING) << "Problem with JSON data from ScienceDirect: Data could not be interpreted as a bibliographic entry";
                                            encounteredUnexpectedData = true;
                                            break;
                                        }
                                    } else {
                                        qCWarning(LOG_KBIBTEX_NETWORKING) << "Problem with JSON data from ACM Digital Library: Value is not an object";
                                        encounteredUnexpectedData = true;
                                        break;
                                    }
                                } else {
                                    qCWarning(LOG_KBIBTEX_NETWORKING) << "Problem with JSON data from ACM Digital Library: Object in items does not have exactly one key-value pair";
                                    encounteredUnexpectedData = true;
                                    break;
                                }
                            } else {
                                qCWarning(LOG_KBIBTEX_NETWORKING) << "Problem with JSON data from ACM Digital Library: No object found in 'items' array where expected";
                                encounteredUnexpectedData = true;
                                break;
                            }
                        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &chunk : chunksTitle) {
            if (index > 1)
                query.addQueryItem(QString(QStringLiteral("operator%1")).arg(index), QStringLiteral("AND"));
            query.addQueryItem(QString(QStringLiteral("option%1")).arg(index), QStringLiteral("title"));
            query.addQueryItem(QString(QStringLiteral("value%1")).arg(index), chunk);
            ++index;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &line : const_cast<const QStringList &>(lines))
#if QT_VERSION >= 0x050e00
                ts << line << Qt::endl;
#else // QT_VERSION < 0x050e00
                ts << line << endl;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &token : tokenList) {
            TokenWidget *tokenWidget = nullptr;

            if (token[0] == 'a' || token[0] == 'A' || token[0] == 'z') {
                struct IdSuggestions::IdSuggestionTokenInfo info = p->evalToken(token.mid(1));
                /// Support deprecated 'a' and 'z' cases
                if (token[0] == 'a')
                    info.startWord = info.endWord = 0;
                else if (token[0] == 'z') {
                    info.startWord = 1;
                    info.endWord = 0x00ffffff;
                }
                tokenWidget = new AuthorWidget(info, p, container);
                widgetList << tokenWidget;
                containerLayout->insertWidget(containerLayout->count() - 2, tokenWidget, 1);
            } else if (token[0] == 'y') {
                tokenWidget = new YearWidget(2, p, container);
                widgetList << tokenWidget;
                containerLayout->insertWidget(containerLayout->count() - 2, tokenWidget, 1);
            } else if (token[0] == 'Y') {
                tokenWidget = new YearWidget(4, p, container);
                widgetList << tokenWidget;
                containerLayout->insertWidget(containerLayout->count() - 2, tokenWidget, 1);
            } else if (token[0] == 't' || token[0] == 'T') {
                struct IdSuggestions::IdSuggestionTokenInfo info = p->evalToken(token.mid(1));
                tokenWidget = new TitleWidget(info, token[0].isUpper(), p, container);
                widgetList << tokenWidget;
                containerLayout->insertWidget(containerLayout->count() - 2, tokenWidget, 1);
            } else if (token[0] == 'j' || token[0] == 'J') {
                struct IdSuggestions::IdSuggestionTokenInfo info = p->evalToken(token.mid(1));
                tokenWidget = new JournalWidget(info, token[0].isUpper(), p, container);
                widgetList << tokenWidget;
                containerLayout->insertWidget(containerLayout->count() - 2, tokenWidget, 1);
            } else if (token[0] == 'e') {
                struct IdSuggestions::IdSuggestionTokenInfo info = p->evalToken(token.mid(1));
                tokenWidget = new TypeWidget(info, p, container);
                widgetList << tokenWidget;
                containerLayout->insertWidget(containerLayout->count() - 2, tokenWidget, 1);
            } else if (token[0] == 'v') {
                tokenWidget = new VolumeWidget(p, container);
                widgetList << tokenWidget;
                containerLayout->insertWidget(containerLayout->count() - 2, tokenWidget, 1);
            } else if (token[0] == 'p') {
                tokenWidget = new PageNumberWidget(p, container);
                widgetList << tokenWidget;
                containerLayout->insertWidget(containerLayout->count() - 2, tokenWidget, 1);
            } else if (token[0] == '"') {
                tokenWidget = new TextWidget(token.mid(1), p, container);
                widgetList << tokenWidget;
                containerLayout->insertWidget(containerLayout->count() - 2, tokenWidget, 1);
            }

            if (tokenWidget != nullptr)
                addManagementButtons(tokenWidget);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QChar &c : input) {
        if (c.isHighSurrogate() || c.isLowSurrogate())
            /// Keep surrogate code points unchanged
            result.append(c);
        else {
            const auto unicode = c.unicode();
            const auto index = unicode < 0xd800 ? unicode : unicode - 2048;
            const auto encodedposlen = Encoder::Private::unidecode_pos[index];
            const auto pos = encodedposlen >> 5;
            const auto len = static_cast<int>(encodedposlen & 31);
            result.append(QString::fromLatin1(Encoder::Private::unidecode_text + pos, len));
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        resizeEvent(nullptr);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        /// Delayed initialization to prevent early triggering of the following slot
        connect(header(), &QHeaderView::sectionResized, this, [this](int logicalIndex, int oldSize, int newSize) {
            Q_UNUSED(oldSize)
            if (!d->automaticBalancing && !d->name.isEmpty() && newSize > 0 && logicalIndex >= 0 && logicalIndex < BibTeXFields::instance().count()) {
                BibTeXFields::instance()[logicalIndex].width[d->name] = newSize;
            }
        });
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &word : freeTextWords) {
        ++argumentCount;
        q.addQueryItem(QString(QStringLiteral("p%1")).arg(argumentCount), word);
        q.addQueryItem(QString(QStringLiteral("m%1")).arg(argumentCount), QStringLiteral("a"));
        q.addQueryItem(QString(QStringLiteral("op%1")).arg(argumentCount), QStringLiteral("a"));
        q.addQueryItem(QString(QStringLiteral("f%1")).arg(argumentCount), QString());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &value : inputMap.values(key))
                    query.addQueryItem(key, value);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &element : selection) {
        /// Only entries (not macros or comments) are of interest
        QSharedPointer<Entry> entry = element.dynamicCast<Entry>();
        if (!entry.isNull()) {
            Value entrysValueForField = entry->value(field);
            bool valueModified = false;
            for (int i = 0; i < entrysValueForField.count(); ++i) {
                const QString valueItemText = PlainTextValue::text(entrysValueForField[i]);
                if (valueItemText == toBeRemovedValueText) {
                    valueModified = true;
                    entrysValueForField.remove(i);
                    break;
                }
            }
            if (valueModified) {
                entry->remove(field);
                entry->insert(field, entrysValueForField);
                madeModification = true;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &element : const_cast<const File &>(*this)) {
        const QSharedPointer<Entry> entry = element.dynamicCast<Entry>();
        if (!entry.isNull())
            for (Entry::ConstIterator it = entry->constBegin(); it != entry->constEnd(); ++it)
                if (it.key().toLower() == lcFieldName) {
                    const auto itValue = it.value();
                    for (const QSharedPointer<ValueItem> &valueItem : itValue) {
                        /// Check if ValueItem to process points to a person
                        const QSharedPointer<Person> person = valueItem.dynamicCast<Person>();
                        if (!person.isNull()) {
                            /// Assemble a list of formatting templates for a person's name
                            static QStringList personNameFormattingList; ///< use static to do pattern assembly only once
                            if (personNameFormattingList.isEmpty()) {
                                /// Use the two default patterns last-name-first and first-name-first
                                personNameFormattingList << Preferences::personNameFormatLastFirst << Preferences::personNameFormatFirstLast;
                                /// Check configuration if user-specified formatting template is different
                                KSharedConfigPtr config(KSharedConfig::openConfig(QStringLiteral("kbibtexrc")));
                                KConfigGroup configGroup(config, "General");
                                QString personNameFormatting = configGroup.readEntry(Preferences::keyPersonNameFormatting, Preferences::defaultPersonNameFormatting);
                                /// Add user's template if it differs from the two specified above
                                if (!personNameFormattingList.contains(personNameFormatting))
                                    personNameFormattingList << personNameFormatting;
                            }
                            /// Add person's name formatted using each of the templates assembled above
                            for (const QString &personNameFormatting : const_cast<const QStringList &>(personNameFormattingList)) {
                                valueSet.insert(Person::transcribePersonName(person.data(), personNameFormatting));
                            }
                        } else {
                            /// Default case: use PlainTextValue::text to translate ValueItem
                            /// to a human-readable text
                            valueSet.insert(PlainTextValue::text(*valueItem));
                        }
                    }
                }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, tokenWidget]() {
                moveUpToken(tokenWidget);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto format : bibUtilFormats) {
            FileExporterBibUtils *exporter = new FileExporterBibUtils(this);
            exporter->setFormat(format);
            FileImporterBibUtils *importer = new  FileImporterBibUtils(this);
            importer->setFormat(format);
            listOfExImporter.append(qMakePair(exporter, importer));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &bibTeXDataRow : bibTeXDataTable)
        QTest::newRow(bibTeXDataRow.label) << bibTeXDataRow.isValid << bibTeXDataRow.text;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : urlList) {
                bool isLocal = isLocalOrRelative(url);
                anyRemote |= !isLocal;
                if (!onlyLocalFilesButton->isChecked() && !isLocal) continue;

                KIO::StatJob *job = KIO::mostLocalUrl(url, KIO::HideProgressInfo);
                runningJobs << job;
                KJobWidgets::setWindow(job, p);
                connect(job, &KIO::StatJob::result, p, &DocumentPreview::statFinished);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &authorToken : authorTokenList) {
            QSharedPointer<Person> person = personFromString(authorToken, nullptr, 1, nullptr);
            if (!person.isNull())
                result.append(person);
        }
```

#### AUTO 


```{c}
const auto firefoxVersionMinor = randomGeneratorGlobalBounded(0, 2);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &keyword : keywords) {
            Value *value = new Value();
            value->append(keyword);
            lineAdd(value);
            delete value;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const ResultItem &ri :  const_cast<const QList<ResultItem> &>(result)) {
            containsUrl |= ri.url == url;
            /// Skip already visited URLs
            if (containsUrl) break;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QJsonValue &author : authorArray) {
            const QString name = author.toObject().value(QStringLiteral("name")).toString();
            if (!name.isEmpty()) {
                QSharedPointer<Person> person = FileImporterBibTeX::personFromString(name);
                if (!person.isNull())
                    authors.append(person);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &titleFragment : _titleFragments)
            titleFragments.insert(titleFragment.toLower());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &text : fileList) {
        internalText = text;

        /// If testing for the actual existence of a filename found in the text ...
        if (testExistence == TestExistenceYes) {
            /// If a base directory (e.g. the location of the parent .bib file) is given
            /// and the potential filename fragment is NOT an absolute path, ...
            if (internalText.startsWith(QStringLiteral("~") + QDir::separator())) {
                const QString fullFilename = QDir::homePath() + internalText.mid(1);
                const QFileInfo fileInfo(fullFilename);
                const QUrl url = QUrl::fromLocalFile(fileInfo.canonicalFilePath());
                if (fileInfo.exists() && fileInfo.isFile() && url.isValid() && !result.contains(url)) {
                    result << url;
                    /// Stop searching for URLs or filenames in current internal text
                    continue;
                }
            } else if (!baseDirectory.isEmpty() &&
                    // TODO the following test assumes that absolute paths start
                    // with a dir separator, which may only be true on Unix/Linux,
                    // but not Windows. May be a test for 'first character is a letter,
                    // second is ":", third is "\"' may be necessary.
                    !internalText.startsWith(QDir::separator())) {
                /// To get the absolute path, prepend filename fragment with base directory
                const QString fullFilename = baseDirectory + QDir::separator() + internalText;
                const QFileInfo fileInfo(fullFilename);
                const QUrl url = QUrl::fromLocalFile(fileInfo.canonicalFilePath());
                if (fileInfo.exists() && fileInfo.isFile() && url.isValid() && !result.contains(url)) {
                    result << url;
                    /// Stop searching for URLs or filenames in current internal text
                    continue;
                }
            } else {
                /// Either the filename fragment is an absolute path OR no base directory
                /// was given (current working directory is assumed), ...
                const QFileInfo fileInfo(internalText);
                const QUrl url = QUrl::fromLocalFile(fileInfo.canonicalFilePath());
                if (fileInfo.exists() && fileInfo.isFile() && url.isValid() && !result.contains(url)) {
                    result << url;
                    /// stop searching for URLs or filenames in current internal text
                    continue;
                }
            }
        }

        /// extract URL from current field
        pos = 0;
        QRegularExpressionMatch urlRegExpMatch;
        while ((urlRegExpMatch = KBibTeX::urlRegExp.match(internalText, pos)).hasMatch()) {
            pos = urlRegExpMatch.capturedStart(0);
            const QString match = urlRegExpMatch.captured(0);
            QUrl url(match);
            if (url.isValid() && (testExistence == TestExistenceNo || !url.isLocalFile() || QFileInfo::exists(url.toLocalFile())) && !result.contains(url))
                result << url;
            /// remove match from internal text to avoid duplicates
            internalText = internalText.left(pos) + internalText.mid(pos + match.length());
        }

        /// explicitly check URL entry, may be an URL even if http:// or alike is missing
        pos = 0;
        QRegularExpressionMatch domainNameRegExpMatch;
        while ((domainNameRegExpMatch = KBibTeX::domainNameRegExp.match(internalText, pos)).hasMatch()) {
            pos = domainNameRegExpMatch.capturedStart(0);
            int pos2 = internalText.indexOf(QStringLiteral(" "), pos + 1);
            if (pos2 < 0) pos2 = internalText.length();
            QString match = internalText.mid(pos, pos2 - pos);
            const QUrl url(QStringLiteral("http://") + match); // FIXME what about HTTPS?
            if (url.isValid() && !result.contains(url))
                result << url;
            /// remove match from internal text to avoid duplicates
            internalText = internalText.left(pos) + internalText.mid(pos + match.length());
        }

        /// extract general file-like patterns
        pos = 0;
        QRegularExpressionMatch fileRegExpMatch;
        while ((fileRegExpMatch = KBibTeX::fileRegExp.match(internalText, pos)).hasMatch()) {
            pos = fileRegExpMatch.capturedStart(0);
            const QString match = fileRegExpMatch.captured(0);
            QUrl url(match);
            if (url.isValid() && (testExistence == TestExistenceNo || !url.isLocalFile() || QFileInfo::exists(url.toLocalFile())) && !result.contains(url))
                result << url;
            /// remove match from internal text to avoid duplicates
            internalText = internalText.left(pos) + internalText.mid(pos + match.length());
        }
    }
```

#### AUTO 


```{c}
const auto urlList = FileInfo::entryUrls(entry, baseUrl, FileInfo::TestExistence::Yes);
```

#### RANGE FOR STATEMENT 


```{c}
for (OpenFileInfo *openFileInfo : const_cast<const OpenFileInfoManager::OpenFileInfoList &>(restoreLaterList)) {
            openFileInfo->addFlags(OpenFileInfo::Open);
        }
```

#### AUTO 


```{c}
const auto selectedIndexes = d->treeviewFieldValues->selectionModel()->selectedIndexes();
```

#### AUTO 


```{c}
const auto &ed
```

#### RANGE FOR STATEMENT 


```{c}
for (int row : const_cast<const QList<int> &>(internalRows)) {
        if (row < 0 || row >= rowCount() || row >= m_file->count())
            return false;
        m_file->removeAt(row);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            colorActivated(QStringLiteral("#000000"));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DotlessIJCharacter &dotlessIJCharacter : dotlessIJCharacters)
                    if (dotlessIJCharacter.letter == input[i + 4 + skipSpaces] && dotlessIJCharacter.modifier == input[i + 1]) {
                        output.append(QChar(dotlessIJCharacter.unicode));
                        i += 5 + skipSpaces;
                        found = true;
                        break;
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : mil) {
        QSharedPointer<Entry> entry = model->element(d->fileView->sortFilterProxyModel()->mapToSource(index).row()).dynamicCast<Entry>();
        if (!entry.isNull())
            references << entry->id();
    }
```

#### AUTO 


```{c}
const auto &risDataRow
```

#### LAMBDA EXPRESSION 


```{c}
[this, reply]() {
            const QUrl url = reply->url();
            if (reply->error() != QNetworkReply::NoError) {
                /// Instead of an 'emit' ...
                QMetaObject::invokeMethod(p, "urlChecked", Qt::DirectConnection, QGenericReturnArgument(), Q_ARG(QUrl, url), Q_ARG(UrlChecker::Status, UrlChecker::Status::NetworkError), Q_ARG(QString, reply->errorString()));
                qCWarning(LOG_KBIBTEX_NETWORKING) << "NetworkError:" << reply->errorString() << url.toDisplayString();
            } else {
                const QByteArray data = reply->read(1024);
                if (data.isEmpty()) {
                    /// Instead of an 'emit' ...
                    QMetaObject::invokeMethod(p, "urlChecked", Qt::DirectConnection, QGenericReturnArgument(), Q_ARG(QUrl, url), Q_ARG(UrlChecker::Status, UrlChecker::Status::UnknownError), Q_ARG(QString, QStringLiteral("No data received")));
                    qCWarning(LOG_KBIBTEX_NETWORKING) << "UnknownError: No data received" << url.toDisplayString();
                } else {
                    const QString filename = url.fileName().toLower();
                    const bool filenameSuggestsHTML = filename.isEmpty() || filename.endsWith(QStringLiteral(".html")) || filename.endsWith(QStringLiteral(".htm"));
                    const bool filenameSuggestsPDF =  filename.endsWith(QStringLiteral(".pdf"));
                    const bool filenameSuggestsPostScript =  filename.endsWith(QStringLiteral(".ps"));
                    const bool containsHTML = data.contains("<!DOCTYPE HTML") || data.contains("<html") || data.contains("<HTML") || data.contains("<body") || data.contains("<body");
                    const bool containsPDF = data.startsWith("%PDF");
                    const bool containsPostScript = data.startsWith("%!");
                    if (filenameSuggestsPDF && containsPDF) {
                        /// Instead of an 'emit' ...
                        QMetaObject::invokeMethod(p, "urlChecked", Qt::DirectConnection, QGenericReturnArgument(), Q_ARG(QUrl, url), Q_ARG(UrlChecker::Status, UrlChecker::Status::UrlValid), Q_ARG(QString, QString()));
                        qCWarning(LOG_KBIBTEX_NETWORKING) << "UrlValid: Looks and smells like a PDF" << url.toDisplayString();
                    } else if (filenameSuggestsPostScript && containsPostScript) {
                        /// Instead of an 'emit' ...
                        QMetaObject::invokeMethod(p, "urlChecked", Qt::DirectConnection, QGenericReturnArgument(), Q_ARG(QUrl, url), Q_ARG(UrlChecker::Status, UrlChecker::Status::UrlValid), Q_ARG(QString, QString()));
                        qCWarning(LOG_KBIBTEX_NETWORKING) << "UrlValid: Looks and smells like a PostScript" << url.toDisplayString();
                    } else if (containsHTML) {
                        static const QRegularExpression error404(QStringLiteral("\\b404\\b"));
                        const QRegularExpressionMatch error404match = error404.match(data);
                        if (error404match.hasMatch()) {
                            /// Instead of an 'emit' ...
                            QMetaObject::invokeMethod(p, "urlChecked", Qt::DirectConnection, QGenericReturnArgument(), Q_ARG(QUrl, url), Q_ARG(UrlChecker::Status, UrlChecker::Status::Error404), Q_ARG(QString, QStringLiteral("Got error 404")));
                            qCWarning(LOG_KBIBTEX_NETWORKING) << "Error404" << url.toDisplayString();
                        } else if (filenameSuggestsHTML) {
                            /// Instead of an 'emit' ...
                            QMetaObject::invokeMethod(p, "urlChecked", Qt::DirectConnection, QGenericReturnArgument(), Q_ARG(QUrl, url), Q_ARG(UrlChecker::Status, UrlChecker::Status::UrlValid), Q_ARG(QString, QString()));
                            qCWarning(LOG_KBIBTEX_NETWORKING) << "UrlValid: Looks and smells like a HTML" << url.toDisplayString();
                        } else {
                            /// Instead of an 'emit' ...
                            QMetaObject::invokeMethod(p, "urlChecked", Qt::DirectConnection, QGenericReturnArgument(), Q_ARG(QUrl, url), Q_ARG(UrlChecker::Status, UrlChecker::Status::UnexpectedFileType), Q_ARG(QString, QStringLiteral("Filename's extension does not match content")));
                            qCWarning(LOG_KBIBTEX_NETWORKING) << "NotExpectedFileType (HTML): Filename's extension does not match content" << url.toDisplayString();
                        }
                    } else if (filenameSuggestsPDF != containsPDF) {
                        /// Instead of an 'emit' ...
                        QMetaObject::invokeMethod(p, "urlChecked", Qt::DirectConnection, QGenericReturnArgument(), Q_ARG(QUrl, url), Q_ARG(UrlChecker::Status, UrlChecker::Status::UnexpectedFileType), Q_ARG(QString, QStringLiteral("Filename's extension does not match content")));
                        qCWarning(LOG_KBIBTEX_NETWORKING) << "NotExpectedFileType (PDF): Filename's extension does not match content" << url.toDisplayString();
                    } else if (filenameSuggestsPostScript != containsPostScript) {
                        /// Instead of an 'emit' ...
                        QMetaObject::invokeMethod(p, "urlChecked", Qt::DirectConnection, QGenericReturnArgument(), Q_ARG(QUrl, url), Q_ARG(UrlChecker::Status, UrlChecker::Status::UnexpectedFileType), Q_ARG(QString, QStringLiteral("Filename's extension does not match content")));
                        qCWarning(LOG_KBIBTEX_NETWORKING) << "NotExpectedFileType (PostScript): Filename's extension does not match content" << url.toDisplayString();
                    } else {
                        /// Instead of an 'emit' ...
                        QMetaObject::invokeMethod(p, "urlChecked", Qt::DirectConnection, QGenericReturnArgument(), Q_ARG(QUrl, url), Q_ARG(UrlChecker::Status, UrlChecker::Status::UrlValid), Q_ARG(QString, QString()));
                        qCWarning(LOG_KBIBTEX_NETWORKING) << "UrlValid: Cannot see any issued with this URL" << url.toDisplayString();
                    }
                }
            }
            busyCounter.deref();
            queueMoreOrFinish();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, parent](const QVariantMap &tokens) {
            /// Upon successful authorization, when the web browser is redirected
            /// to the local webserver run by the QOAuthHttpServerReplyHandler instance,
            /// extract the relevant parameters passed along as part of the GET
            /// request sent to this webserver.
            static const QString oauthTokenKey = QStringLiteral("oauth_token");
            static const QString userIdKey = QStringLiteral("userID");
            if (tokens.contains(oauthTokenKey) && tokens.contains(userIdKey)) {
                apiKey = tokens[oauthTokenKey].toString();
                bool ok = false;
                userId = tokens[userIdKey].toString().toInt(&ok);
                if (!ok) {
                    userId = -1;
                    apiKey.clear();
                    parent->reject();
                } else
                    parent->accept();
            } else {
                apiKey.clear();
                userId = -1;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const MathCommand &mathCommand : mathCommands) {
                            if ((mathCommand.direction & DirectionCommandToUnicode) && mathCommand.command == alpha) {
                                if (currentMathModeTop() == MathModeNone)
                                    qDebug() << "Found math mode command" << QString(QStringLiteral("\\%1")).arg(alpha) << "outside of a math expression";
                                output.append(QChar(mathCommand.unicode));
                                found = true;
                                break;
                            }
                        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &authorToken : authorTokenList) {
            QSharedPointer<Person> person = personFromString(authorToken, nullptr, line_number, parent);
            if (!person.isNull())
                result.append(person);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &element : const_cast<const File &>(*file))
                    fileModel->insertRow(element, fileView->model()->rowCount());
```

#### LAMBDA EXPRESSION 


```{c}
[this, le]() {
            removeFieldLineEdit(le);
            const QSize size(container->width(), recommendedHeight());
            container->resize(size);
            /// Instead of an 'emit' ...
            QMetaObject::invokeMethod(p, "modified", Qt::DirectConnection, QGenericReturnArgument());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QSharedPointer<Element> &element : const_cast<const File &>(*bibtexFile)) {
                    emit foundElement(element); ///< ... and publish result
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QSharedPointer<ValueItem> &valueItem : itValue) {
                        /// Check if ValueItem to process points to a person
                        const QSharedPointer<Person> person = valueItem.dynamicCast<Person>();
                        if (!person.isNull()) {
                            QSet<QString> personNameFormattingSet {Preferences::personNameFormatLastFirst, Preferences::personNameFormatFirstLast};
                            personNameFormattingSet.insert(Preferences::instance().personNameFormatting());
                            /// Add person's name formatted using each of the templates assembled above
                            for (const QString &personNameFormatting : const_cast<const QSet<QString> &>(personNameFormattingSet))
                                valueSet.insert(Person::transcribePersonName(person.data(), personNameFormatting));
                        } else {
                            /// Default case: use PlainTextValue::text to translate ValueItem
                            /// to a human-readable text
                            valueSet.insert(PlainTextValue::text(*valueItem));
                        }
                    }
```

#### AUTO 


```{c}
const auto &fd
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &lastAuthor : const_cast<const QStringList &>(lastAuthorsList)) {
        const QByteArray lastAuthorUtf8 = lastAuthor.toUtf8();
#ifdef WRITE_RAWDATAFILE
        sourceCode += rewriteNonASCII(QString(lastAuthor));
        len += lastAuthorUtf8.length();
        if (len > max_len) {
            sourceCode += QStringLiteral("\"\n        \"");
            len = 0;
        }
#endif // WRITE_RAWDATAFILE
        hashAuthors.addData(lastAuthorUtf8);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QAction *action : actionList) {
        /// Make URL from action's data ...
        const QUrl tmpUrl = action->data().toUrl();
        if (!tmpUrl.isValid()) continue;
        /// ... but skip this action if the URL is invalid
        if (!tmpUrl.isValid()) continue;
        if (tmpUrl.isLocalFile()) {
            /// If action's URL points to local file,
            /// keep it and stop search for document
            url = tmpUrl;
            break;
        } else if (!url.isValid())
            /// First valid URL found, keep it
            /// URL is not local, so it may get overwritten by another URL
            url = tmpUrl;
    }
```

#### AUTO 


```{c}
const auto *fieldLineEdit
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &fd : const_cast<const BibTeXFields &>(BibTeXFields::instance())) {
        QAction *action = new QAction(fd.label, &menu);
        action->setData(col);
        action->setCheckable(true);
        action->setChecked(!header()->isSectionHidden(col));
        if (onlyOneLastColumnVisible && action->isChecked()) {
            /// If only one last column is visible and the current field is this column,
            /// disable action so that the column cannot be hidden by the user
            action->setEnabled(false);
        }
        connect(action, &QAction::triggered, this, &BasicFileView::headerColumnVisibilityToggled);
        menu.addAction(action);
        ++col;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &authorToken : authorTokenList) {
            QSharedPointer<Person> person = Private::personFromString(authorToken, nullptr, 1, nullptr);
            if (!person.isNull())
                result.append(person);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &etl : EntryLayout::instance())
            for (const auto &sfl : const_cast<const QList<SingleFieldLayout> &>(etl->singleFieldLayouts))
                blacklistedFields << sfl.bibtexLabel;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QSharedPointer<Element> &element : bibtexFile) {
        /// Process only entries, not comments, preambles or macros
        const QSharedPointer<Entry> entry = element.dynamicCast<Entry>();
        if (entry.isNull()) continue;

        /// Retrieve set of URLs per entry and add to set of URLS to be checked
        const QSet<QUrl> thisEntryUrls = FileInfo::entryUrls(entry, bibtexFile.property(File::Url).toUrl(), FileInfo::TestExistence::No);
        for (const QUrl &u : thisEntryUrls)
            d->urlsToCheck.insert(u); ///< better?
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QJsonValue &itemValue : docsArray) {
                            if (itemValue.isObject()) {
                                const QJsonValue bibcodeValue = itemValue.toObject().value(QString("bibcode"));
                                if (bibcodeValue.isString()) {
                                    bibcodeList.append(bibcodeValue.toString());
                                }
                            } else {
                                qCDebug(LOG_KBIBTEX_NETWORKING) << "Problem with JSON data from Astrophysics Data System: No 'bibcode' found";
                            }
                        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            openHomepage();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, url]() {
                        elementViewDocumentMenu(url);
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto *fd : const_cast<const BibTeXFields &>(*bibtexFields)) {
            if (!fd->upperCamelCaseAlt.isEmpty()) continue; /// keep only "single" fields and not combined ones like "Author or Editor"
            if (fd->upperCamelCase.startsWith('^')) continue; /// skip "type" and "id"
            comboboxFieldNames->addItem(fd->label, fd->upperCamelCase);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                area->ensureWidgetVisible(buttonAddTokenAtTop);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &text : freeTextWords)
        queryFragments.append(typedSearch.arg(QStringLiteral("ft"), text));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : urlList) {
                    /// First iteration: local references only
                    if (!url.isLocalFile()) continue; ///< skip remote URLs

                    /// Build a nice menu item (label, icon, ...)
                    const QFileInfo fi(url.toLocalFile());
                    const QString label = QString(QStringLiteral("%1 [%2]")).arg(fi.fileName(), fi.absolutePath());
                    QAction *action = new QAction(QIcon::fromTheme(FileInfo::mimeTypeForUrl(url).iconName()), label, p);
                    action->setToolTip(fi.absoluteFilePath());
                    /// Open URL when action is triggered
                    connect(action, &QAction::triggered, p, [this, fi]() {
                        elementViewDocumentMenu(QUrl::fromLocalFile(fi.absoluteFilePath()));
                    });
                    viewDocumentMenu->addAction(action);
                    /// Memorize first action
                    if (firstAction == nullptr) firstAction = action;
                }
```

#### LAMBDA EXPRESSION 


```{c}
[]() {
            OpenFileInfoManager::instance().close(OpenFileInfoManager::instance().currentFile());
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            openExternally();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &crossRefField : crossRefFields) {
        const QString crossRefValue = PlainTextValue::text(result->value(crossRefField));
        if (crossRefValue.isEmpty())
            continue;

        const QSharedPointer<Entry> crossRefEntry = bibTeXfile->containsKey(crossRefField, File::etEntry).dynamicCast<Entry>();
        if (!crossRefEntry.isNull()) {
            /// Copy all fields from crossref'ed entry to new entry which do not (yet) exist in the new entry
            for (Entry::ConstIterator it = crossRefEntry->constBegin(); it != crossRefEntry->constEnd(); ++it)
                if (!result->contains(it.key()))
                    result->insert(it.key(), Value(it.value()));

            if (crossRefEntry->type().compare(etProceedings, Qt::CaseInsensitive) && result->type().compare(etInProceedings, Qt::CaseInsensitive) && crossRefEntry->contains(ftTitle) && !result->contains(ftBookTitle)) {
                /// In case current entry is of type 'inproceedings' but lacks a 'book title'
                /// and the crossref'ed entry is of type 'proceedings' and has a 'title', then
                /// copy this 'title into as the 'book title' of the current entry.
                /// Note: the correct way should be that the crossref'ed entry has a 'book title'
                /// field, but that case was handled above when copying non-existing fields,
                /// so this if-block is only a fall-back case.
                result->insert(ftBookTitle, Value(crossRefEntry->operator [](ftTitle)));
            }

            /// Remove crossref field (no longer of use as all data got copied)
            result->remove(crossRefField);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QUrl url) {
            QUrlQuery query(url);
            query.addQueryItem(QStringLiteral("name"), QStringLiteral("KBibTeX"));
            query.addQueryItem(QStringLiteral("library_access"), QStringLiteral("1"));
            query.addQueryItem(QStringLiteral("notes_access"), QStringLiteral("0"));
            query.addQueryItem(QStringLiteral("write_access"), QStringLiteral("0"));
            query.addQueryItem(QStringLiteral("all_groups"), QStringLiteral("read"));
            url.setQuery(query);
            /// Received a URL from Zotero which the user can open in a web browser.
            /// To do that, re-enable various controls.
            lineEditAuthorizationUrl->setText(url.toDisplayString());
            lineEditAuthorizationUrl->setEnabled(true);
            buttonCopyAuthorizationUrl->setEnabled(true);
            buttonOpenAuthorizationUrl->setEnabled(true);
            QApplication::restoreOverrideCursor();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &token : tokens) {
            /// Position where comma was found, or -1 if no comma in token
            int p = -1;
            if (commaCount < 2) {
                /// Only check if token contains comma
                /// if no comma was found before
                int bracketCounter = 0;
                for (int i = 0; i < token.length(); ++i) {
                    /// Consider opening curly brackets
                    if (token[i] == QChar('{')) ++bracketCounter;
                    /// Consider closing curly brackets
                    else if (token[i] == QChar('}')) --bracketCounter;
                    /// Only if outside any open curly bracket environments
                    /// consider comma characters
                    else if (bracketCounter == 0 && token[i] == QChar(',')) {
                        /// Memorize comma's position and break from loop
                        p = i;
                        break;
                    } else if (bracketCounter < 0) {
                        /// Should never happen: more closing brackets than opening ones
                        qCWarning(LOG_KBIBTEX_IO) << "Opening and closing brackets do not match near line" << line_number;
                        if (parent != nullptr)
                            QMetaObject::invokeMethod(parent, "message", Qt::DirectConnection, QGenericReturnArgument(), Q_ARG(FileImporter::MessageSeverity, MessageSeverity::Warning), Q_ARG(QString, QString(QStringLiteral("Opening and closing brackets do not match near line %1")).arg(line_number)));
                    }
                }
            }

            if (p >= 0) {
                if (commaCount == 0) {
                    if (p > 0) partA.append(token.left(p));
                    if (p < token.length() - 1) partB.append(token.mid(p + 1));
                } else if (commaCount == 1) {
                    if (p > 0) partB.append(token.left(p));
                    if (p < token.length() - 1) partC.append(token.mid(p + 1));
                }
                ++commaCount;
            } else if (commaCount == 0)
                partA.append(token);
            else if (commaCount == 1)
                partB.append(token);
            else if (commaCount == 2)
                partC.append(token);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &text : fileList) {
        internalText = text;

        /// If testing for the actual existence of a filename found in the text ...
        if (testExistence == TestExistence::Yes) {
            /// If a base directory (e.g. the location of the parent .bib file) is given
            /// and the potential filename fragment is NOT an absolute path, ...
            if (internalText.startsWith(QStringLiteral("~") + QDir::separator())) {
                const QString fullFilename = QDir::homePath() + internalText.mid(1);
                const QFileInfo fileInfo(fullFilename);
                const QUrl url = QUrl::fromLocalFile(fileInfo.canonicalFilePath());
                if (fileInfo.exists() && fileInfo.isFile() && url.isValid() && !result.contains(url)) {
                    result << url;
                    /// Stop searching for URLs or filenames in current internal text
                    continue;
                }
            } else if (!baseDirectory.isEmpty() &&
                       // TODO the following test assumes that absolute paths start
                       // with a dir separator, which may only be true on Unix/Linux,
                       // but not Windows. May be a test for 'first character is a letter,
                       // second is ":", third is "\"' may be necessary.
                       !internalText.startsWith(QDir::separator())) {
                /// To get the absolute path, prepend filename fragment with base directory
                const QString fullFilename = baseDirectory + QDir::separator() + internalText;
                const QFileInfo fileInfo(fullFilename);
                const QUrl url = QUrl::fromLocalFile(fileInfo.canonicalFilePath());
                if (fileInfo.exists() && fileInfo.isFile() && url.isValid() && !result.contains(url)) {
                    result << url;
                    /// Stop searching for URLs or filenames in current internal text
                    continue;
                }
            } else {
                /// Either the filename fragment is an absolute path OR no base directory
                /// was given (current working directory is assumed), ...
                const QFileInfo fileInfo(internalText);
                const QUrl url = QUrl::fromLocalFile(fileInfo.canonicalFilePath());
                if (fileInfo.exists() && fileInfo.isFile() && url.isValid() && !result.contains(url)) {
                    result << url;
                    /// stop searching for URLs or filenames in current internal text
                    continue;
                }
            }
        }

        /// extract URL from current field
        pos = 0;
        QRegularExpressionMatch urlRegExpMatch;
        while ((urlRegExpMatch = KBibTeX::urlRegExp.match(internalText, pos)).hasMatch()) {
            pos = urlRegExpMatch.capturedStart(0);
            const QString match = urlRegExpMatch.captured(0);
            QUrl url(match);
            if (url.isValid() && (testExistence == TestExistence::No || !url.isLocalFile() || QFileInfo::exists(url.toLocalFile())) && !result.contains(url))
                result << url;
            /// remove match from internal text to avoid duplicates
            internalText = internalText.left(pos) + internalText.mid(pos + match.length());
        }

        /// explicitly check URL entry, may be an URL even if http:// or alike is missing
        pos = 0;
        QRegularExpressionMatch domainNameRegExpMatch;
        while ((domainNameRegExpMatch = KBibTeX::domainNameRegExp.match(internalText, pos)).hasMatch()) {
            pos = domainNameRegExpMatch.capturedStart(0);
            int pos2 = internalText.indexOf(QStringLiteral(" "), pos + 1);
            if (pos2 < 0) pos2 = internalText.length();
            QString match = internalText.mid(pos, pos2 - pos);
            const QUrl url(QStringLiteral("http://") + match); // FIXME what about HTTPS?
            if (url.isValid() && !result.contains(url))
                result << url;
            /// remove match from internal text to avoid duplicates
            internalText = internalText.left(pos) + internalText.mid(pos + match.length());
        }

        /// extract general file-like patterns
        pos = 0;
        QRegularExpressionMatch fileRegExpMatch;
        while ((fileRegExpMatch = KBibTeX::fileRegExp.match(internalText, pos)).hasMatch()) {
            pos = fileRegExpMatch.capturedStart(0);
            const QString match = fileRegExpMatch.captured(0);
            const QFileInfo fi(match);
            const QUrl url = QUrl::fromLocalFile(!match.startsWith(QStringLiteral("/")) && !match.startsWith(QStringLiteral("http")) && fi.isRelative() && !baseDirectory.isEmpty() ? baseDirectory + QStringLiteral("/") + match : match);
            if (url.isValid() && (testExistence == TestExistence::No || QFileInfo::exists(url.toLocalFile())) && !result.contains(url))
                result << url;
            /// remove match from internal text to avoid duplicates
            internalText = internalText.left(pos) + internalText.mid(pos + match.length());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &element : const_cast<const File &>(*bibtexFile)) {
                const QSharedPointer<Entry> entry = element.dynamicCast<Entry>();
                hasEntry |= publishEntry(entry);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &filesUrlsDoi : const_cast<const QStringList &>(filesUrlsDoiList)) {
        const QByteArray filesUrlsDoiUtf8 = filesUrlsDoi.toUtf8();
        hashFilesUrlsDoi.addData(filesUrlsDoiUtf8);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const MathCommand &mathCommand : mathCommands)
                    if ((mathCommand.direction & DirectionUnicodeToCommand) && mathCommand.unicode == c.unicode()) {
                        output.append(QString(QStringLiteral("\\ensuremath{\\%1}")).arg(mathCommand.command));
                        found = true;
                        break;
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QChar &c : input) {
        const auto unicode = c.unicode();
        const auto encodedposlen = Encoder::Private::unidecode_pos[unicode];
        const auto pos = encodedposlen >> 5;
        const auto len = encodedposlen & 31;
        result.append(QString::fromLatin1(Encoder::Private::unidecode_text + pos, len));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&gotErrors](const FileImporter::MessageSeverity messageSeverity, const QString &messageText) {
        gotErrors |= messageSeverity >= FileImporter::SeverityError;
        Q_UNUSED(messageText)
        //qCDebug(LOG_KBIBTEX_TEST)<<"FileImporterRIS issues message during 'partialBibTeXInput' test: "<<messageText;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &fd : const_cast<const BibTeXFields &>(*bf)) {
            if (!p->header()->isSectionHidden(col))
                defaultWidthSumVisible += fd.defaultWidth;
            ++col;
        }
```

#### AUTO 


```{c}
const auto appleWebKitVersionMajor = QRandomGenerator::global()->bounded(537, 856);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &token : tokenList) {
        QString text;
        if (token[0] == 'a' || token[0] == 'A' || token[0] == 'z') {
            struct IdSuggestionTokenInfo info = evalToken(token.mid(1));
            if (token[0] == 'a')
                info.startWord = info.endWord = 0;
            else if (token[0] == 'z') {
                info.startWord = 1;
                info.endWord = 0x00ffffff;
            }
            text = formatAuthorRange(info.startWord, info.endWord, info.lastWord);

            int n = info.len;
            if (info.len < 0x00ffffff) text.append(i18np(", but only first letter of each last name", ", but only first %1 letters of each last name", n));

            switch (info.caseChange) {
            case IdSuggestions::ccToUpper:
                text.append(i18n(", in upper case"));
                break;
            case IdSuggestions::ccToLower:
                text.append(i18n(", in lower case"));
                break;
            case IdSuggestions::ccToCamelCase:
                text.append(i18n(", in CamelCase"));
                break;
            case IdSuggestions::ccNoChange:
                break;
            }

            if (!info.inBetween.isEmpty()) text.append(i18n(", with '%1' in between", info.inBetween));
        }
        else if (token[0] == 'y')
            text.append(i18n("Year (2 digits)"));
        else if (token[0] == 'Y')
            text.append(i18n("Year (4 digits)"));
        else if (token[0] == 't' || token[0] == 'T') {
            struct IdSuggestionTokenInfo info = evalToken(token.mid(1));
            text.append(i18n("Title"));
            if (info.startWord == 0 && info.endWord <= 0xffff)
                text.append(i18np(", but only the first word", ", but only first %1 words", info.endWord + 1));
            else if (info.startWord > 0 && info.endWord > 0xffff)
                text.append(i18n(", but only starting from word %1", info.startWord + 1));
            else if (info.startWord > 0 && info.endWord <= 0xffff)
                text.append(i18n(", but only from word %1 to word %2", info.startWord + 1, info.endWord + 1));
            if (info.len < 0x00ffffff)
                text.append(i18np(", but only first letter of each word", ", but only first %1 letters of each word", info.len));

            switch (info.caseChange) {
            case IdSuggestions::ccToUpper:
                text.append(i18n(", in upper case"));
                break;
            case IdSuggestions::ccToLower:
                text.append(i18n(", in lower case"));
                break;
            case IdSuggestions::ccToCamelCase:
                text.append(i18n(", in CamelCase"));
                break;
            case IdSuggestions::ccNoChange:
                break;
            }

            if (!info.inBetween.isEmpty()) text.append(i18n(", with '%1' in between", info.inBetween));
            if (token[0] == 'T') text.append(i18n(", small words removed"));
        }
        else if (token[0] == 'j') {
            struct IdSuggestionTokenInfo info = evalToken(token.mid(1));
            text.append(i18n("Journal"));
            if (info.len < 0x00ffffff)
                text.append(i18np(", but only first letter of each word", ", but only first %1 letters of each word", info.len));
            switch (info.caseChange) {
            case IdSuggestions::ccToUpper:
                text.append(i18n(", in upper case"));
                break;
            case IdSuggestions::ccToLower:
                text.append(i18n(", in lower case"));
                break;
            case IdSuggestions::ccToCamelCase:
                text.append(i18n(", in CamelCase"));
                break;
            case IdSuggestions::ccNoChange:
                break;
            }
        } else if (token[0] == 'v') {
            text.append(i18n("Volume"));
        } else if (token[0] == 'p') {
            text.append(i18n("First page number"));
        } else if (token[0] == '"')
            text.append(i18n("Text: '%1'", token.mid(1)));
        else
            text.append("?");

        result.append(text);
    }
```

#### AUTO 


```{c}
const auto &values = currentClique->values(fieldName);
```

#### AUTO 


```{c}
const auto respectingQuotationMarksFreeText = splitRespectingQuotationMarks(query[QueryKey::FreeText]);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &citeCommand : citeCommands) {
            itim->addItem(citeCmdToLabel.arg(citeCommand), citeCommand);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        endResetModel();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DotlessIJCharacter &dotlessIJCharacter : dotlessIJCharacters)
                if (c.unicode() == dotlessIJCharacter.unicode && (dotlessIJCharacter.direction & DirectionUnicodeToCommand)) {
                    output.append(QString(QStringLiteral("\\%1{\\%2}")).arg(dotlessIJCharacter.modifier).arg(dotlessIJCharacter.letter));
                    found = true;
                    break;
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QSharedPointer<const ValueItem> &item : const_cast<const Value &>(value)) {
        QSharedPointer<const Person> person = item.dynamicCast<const Person>();
        if (!person.isNull()) {
            const QString lastName = person->lastName();
            if (!lastName.isEmpty())
                result << lastName;
        }
        if (--maxAuthors <= 0) break;   ///< limit the number of authors considered
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->refreshElement();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QJsonValue &authorValue : authorsArray) {
            const QJsonObject authorObject = authorValue.toObject();
            Person *author = new Person(authorObject.value(QStringLiteral("given")).toString(), authorObject.value(QStringLiteral("family")).toString());
            authors.append(QSharedPointer<ValueItem>(author));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QChar &invalidIdCharacter : invalidIdCharacters)
        if (id.contains(invalidIdCharacter)) {
            qCWarning(LOG_KBIBTEX_IO) << "Entry id" << id << "near line" << m_lineNo << "contains invalid character" << invalidIdCharacter;
            emit message(SeverityError, QString(QStringLiteral("Entry id '%1' near line %2 contains invalid character '%3'")).arg(id).arg(m_lineNo).arg(invalidIdCharacter));
            return nullptr;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, buttonBox](QAbstractButton *button) {
            if (button == buttonBox->button(QDialogButtonBox::Close))
                p->reject();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, colorCode]() {
                colorActivated(colorCode);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &urlToAssociate : urls)
                modified |= d->insertUrl(urlToAssociate, dropTarget);
```

#### LAMBDA EXPRESSION 


```{c}
[&errorLog](const FileExporter::MessageSeverity severity, const QString & messageText) {
            if (severity >= FileExporter::MessageSeverity::Warning)
                errorLog.append(messageText);
        }
```

#### AUTO 


```{c}
const auto encodedposlen = Encoder::Private::unidecode_pos[index];
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &ed : const_cast<const BibTeXEntries &>(*this)) {
            /// configuration file uses camel-case
            QString itName = ed.upperCamelCase.toLower();
            if (itName == iName) {
                iName = ed.upperCamelCase;
                break;
            }
        }
```

#### AUTO 


```{c}
const auto &newValueItem
```

#### RANGE FOR STATEMENT 


```{c}
for (OpenFileInfo *openFileInfo : const_cast<const OpenFileInfoManager::OpenFileInfoList &>(d->openFileInfoList)) {
        /// Check only open file (ignore recently used, favorites, ...)
        if (openFileInfo->flags().testFlag(OpenFileInfo::Open)) {
            if (openFileInfo->close()) {
                /// If file could be closed without user canceling the operation ...
                /// Mark file as closed (i.e. not open)
                openFileInfo->removeFlags(OpenFileInfo::Open);
                /// If file has a filename, remember as recently used
                if (openFileInfo->flags().testFlag(OpenFileInfo::HasName))
                    openFileInfo->addFlags(OpenFileInfo::RecentlyUsed);
                /// Remember file as to be marked as open later
                restoreLaterList.append(openFileInfo);
            } else {
                /// User chose to cancel closing operation,
                /// stop everything here
                isClosing = false;
                break;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &element : selection) {
        /// Only entries (not macros or comments) are of interest
        QSharedPointer<Entry> entry = element.dynamicCast<Entry>();
        if (!entry.isNull()) {
            /// Fields are separated into two categories:
            /// 1. Where more values can be appended, like authors or URLs
            /// 2. Where values should be replaced, like title, year, or journal
            if (d->allowsMultipleValues(field)) {
                /// Fields for which multiple values are valid
                bool valueItemAlreadyContained = false; ///< add only if to-be-assigned value is not yet contained
                Value entrysValueForField = entry->value(field);
                for (const auto &containedValueItem : const_cast<const Value &>(entrysValueForField)) {
                    valueItemAlreadyContained |= PlainTextValue::text(containedValueItem) == toBeAssignedValueText;
                    if (valueItemAlreadyContained) break;
                }

                if (!valueItemAlreadyContained) {
                    /// Add each ValueItem from the to-be-assigned value to the entry's value for this field
                    entrysValueForField.reserve(toBeAssignedValue.size());
                    for (const auto &newValueItem : toBeAssignedValue) {
                        entrysValueForField.append(newValueItem);
                    }
                    /// "Write back" value to field in entry
                    entry->remove(field);
                    entry->insert(field, entrysValueForField);
                    /// Keep track that bibliography file has been modified
                    madeModification = true;
                }
            } else {
                /// Fields for which only value is valid, thus the old value will be replaced
                entry->remove(field);
                entry->insert(field, toBeAssignedValue);
                /// Keep track that bibliography file has been modified
                madeModification = true;
            }

        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : Clipboard::urlsToOpen(event->mimeData()))
        openDocument(url);
```

#### RANGE FOR STATEMENT 


```{c}
for (const EncoderLaTeXSymbolSequence &encoderLaTeXSymbolSequence : encoderLaTeXSymbolSequences) {
                /// First, check if read input character matches beginning of symbol sequence
                /// and input buffer as enough characters left to potentially contain
                /// symbol sequence
                const int latexLen = encoderLaTeXSymbolSequence.latex.length();
                if ((encoderLaTeXSymbolSequence.direction & DirectionCommandToUnicode) && encoderLaTeXSymbolSequence.latex[0] == c && i <= len - latexLen) {
                    /// Now actually check if symbol sequence is in input buffer
                    isSymbolSequence = true;
                    for (int p = 1; isSymbolSequence && p < latexLen; ++p)
                        isSymbolSequence &= encoderLaTeXSymbolSequence.latex[p] == input[i + p];
                    if (isSymbolSequence) {
                        /// Ok, found sequence: insert Unicode character in output
                        /// and hop over sequence in input buffer
                        output.append(QChar(encoderLaTeXSymbolSequence.unicode));
                        i += encoderLaTeXSymbolSequence.latex.length() - 1;
                        break;
                    }
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const EncoderLaTeXEscapedCharacter &encoderLaTeXEscapedCharacter : encoderLaTeXEscapedCharacters)
                    if (encoderLaTeXEscapedCharacter.unicode == c.unicode() && (encoderLaTeXEscapedCharacter.direction & DirectionUnicodeToCommand)) {
                        const QChar modifier = encoderLaTeXEscapedCharacter.modifier;
                        const QString formatString = isAsciiLetter(modifier) ? QStringLiteral("{\\%1 %2}") : QStringLiteral("{\\%1%2}");
                        output.append(formatString.arg(modifier).arg(encoderLaTeXEscapedCharacter.letter));
                        found = true;
                        break;
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &chunk : chunksTitle) {
            if (index > 1)
                q.addQueryItem(QString(QStringLiteral("operator%1")).arg(index), QStringLiteral("AND"));
            q.addQueryItem(QString(QStringLiteral("option%1")).arg(index), QStringLiteral("title"));
            q.addQueryItem(QString(QStringLiteral("value%1")).arg(index), chunk);
            ++index;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[errorLog, &process] {
            QTextStream ts(process.readAllStandardOutput());
            while (!ts.atEnd())
                errorLog->append(ts.readLine());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : list) {
            const QModelIndex mappedIndex = sfbfm->mapToSource(index);
            /// Selection may span over multiple columns;
            /// to avoid duplicate assignments, consider only column 1
            if (mappedIndex.column() == 1) {
                const int row = mappedIndex.row();
                QSharedPointer<Entry> entry = model->element(row).dynamicCast<Entry>();
                if (!entry.isNull()) {
                    /// Clear old color entry
                    bool modifying = entry->remove(Entry::ftColor) > 0;
                    if (colorString != QStringLiteral("#000000")) { ///< black is a special color that means "no color"
                        /// Only if valid color was selected, set this color
                        Value v;
                        v.append(QSharedPointer<VerbatimText>(new VerbatimText(colorString)));
                        entry->insert(Entry::ftColor, v);
                        modifying = true;
                    }
                    if (modifying)
                        // TODO notification of modification does not propagate?
                        model->elementChanged(row);
                }
            }
        }
```

#### AUTO 


```{c}
const auto respectingQuotationMarksFreeText = splitRespectingQuotationMarks(query[queryKeyFreeText]);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &titleFragment : const_cast<const QSet<QString> &>(d->titleFragments))
                            allTitleFragmentsContained &= title.contains(titleFragment);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &element : const_cast<const File &>(*this)) {
        const QSharedPointer<Entry> entry = elementTypes.testFlag(etEntry) ? element.dynamicCast<Entry>() : QSharedPointer<Entry>();
        if (!entry.isNull())
            result.append(entry->id());
        else {
            const QSharedPointer<Macro> macro = elementTypes.testFlag(etMacro) ? element.dynamicCast<Macro>() : QSharedPointer<Macro>();
            if (!macro.isNull())
                result.append(macro->key());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QChar &c : input) {
            if (codec == nullptr /** meaning UTF-8, which can encode anything */ || canEncode(c, codec)) {
                rewrittenInput.append(c);
                containsNonASCIIcharacters |= c.unicode() > 127;
            } else
                rewrittenInput.append(laTeXEncoder.encode(QString(c), Encoder::TargetEncoding::ASCII));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &keyStem : keyStart)
        for (int i = 1; i < 32; ++i) {  /// FIXME replace number by constant
            const QString key = i > 1 ? keyStem + QString::number(i) : keyStem;
            const Value &value = entry->operator [](key);
            for (const auto &valueItem : const_cast<const Value &>(value))
                combinedValue.append(valueItem);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto *fieldLineEdit : const_cast<const QList<FieldLineEdit *> &>(d->lineEditList)) {
        const bool v = fieldLineEdit->validate(widgetWithIssue, message);
        if (!v) return false;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &filename : fileList) {
                    value.append(QSharedPointer<VerbatimText>(new VerbatimText(filename)));
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto *fd : const_cast<const BibTeXFields &>(*this)) {
            /// configuration file uses camel-case
            QString itName = fd->upperCamelCase.toLower();
            if (itName == iName && fd->upperCamelCaseAlt.isEmpty()) {
                iName = fd->upperCamelCase;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &s : list)
        result |= typeFlagFromString(s);
```

#### AUTO 


```{c}
const auto respectingQuotationMarks = p->splitRespectingQuotationMarks(it.value());
```

#### RANGE FOR STATEMENT 


```{c}
for (FieldLineEdit *fieldLineEdit : const_cast<const QList<FieldLineEdit *> &>(d->lineEditList))
        fieldLineEdit->setFile(file);
```

#### LAMBDA EXPRESSION 


```{c}
[this](QSharedPointer<Entry> entry) {
            sr->insertElement(entry);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &key : inputMap.keys()) {
                query.removeQueryItem(key);
                for (const QString &value : inputMap.values(key))
                    query.addQueryItem(key, value);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &doiValueItem : doiValue) {
            const QString doi = PlainTextValue::text(doiValueItem);
            Value v = entry->value(Entry::ftUrl);
            bool gotChanged = false;
            for (Value::Iterator it = v.begin(); it != v.end();) {
                const QSharedPointer<ValueItem> &vi = (*it);
                if (vi->containsPattern(QStringLiteral("/") + doi)) {
                    it = v.erase(it);
                    gotChanged = true;
                } else
                    ++it;
            }
            if (v.isEmpty())
                entry->remove(Entry::ftUrl);
            else if (gotChanged)
                entry->insert(Entry::ftUrl, v);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &doi : const_cast<const QStringList &>(list))
                doiValue.append(QSharedPointer<PlainText>(new PlainText(doi)));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &text : freeTextWords)
            queryFragments.append(text + (pmidRegExp.match(text).hasMatch() ? QString() : QStringLiteral("[All Fields]")));
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            addToken(ttTitle, locAtBottom);
        }
```

#### AUTO 


```{c}
static const auto pairs = QHash<const char *, KBibTeX::TypeFlag> {
        {"Invalid", KBibTeX::TypeFlag::Invalid},
        {"PlainText", KBibTeX::TypeFlag::PlainText},
        {"Reference", KBibTeX::TypeFlag::Reference},
        {"Person", KBibTeX::TypeFlag::Person},
        {"Keyword", KBibTeX::TypeFlag::Keyword},
        {"Verbatim", KBibTeX::TypeFlag::Verbatim},
        {"Source", KBibTeX::TypeFlag::Source}
    };
```

#### AUTO 


```{c}
const auto pos = encodedposlen >> 5;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &element : elementsAuthor) {
        if (queryNumber > 0) q.addQueryItem(QString(QStringLiteral("c%1")).arg(queryNumber), QStringLiteral("AND")); ///< join search terms with an AND operation
        q.addQueryItem(QString(QStringLiteral("f%1")).arg(queryNumber), QStringLiteral("au"));
        q.addQueryItem(QString(QStringLiteral("q%1")).arg(queryNumber), element);
        ++queryNumber;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &etl : const_cast<const EntryLayout &>(*el))
            for (const auto &sfl : const_cast<const QList<SingleFieldLayout> &>(etl->singleFieldLayouts))
                blacklistedFields << sfl.bibtexLabel;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &stem : stems) {
                for (int index = 1; index < 100; ++index) {
                    const QString field = index == 1 ? stem : QString(QStringLiteral("%1%2")).arg(stem).arg(index);
                    const Value v = entry->value(field);
                    for (const QSharedPointer<ValueItem> &vi : v) {
                        filesUrlsDoiList << PlainTextValue::text(vi);
                    }
                    if (v.isEmpty() && index > 10) break;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &citeCommand : Preferences::availableCopyReferenceCommands)
            itim->addItem(citeCmdToLabel.arg(citeCommand), citeCommand);
```

#### RANGE FOR STATEMENT 


```{c}
for (const EntryDescription &ed : const_cast<const BibTeXEntries &>(*p)) {
            ++typeCount;
            QString groupName = QString(QStringLiteral("EntryType%1")).arg(typeCount);
            KConfigGroup configGroup(layoutConfig, groupName);

            configGroup.writeEntry("UpperCamelCase", ed.upperCamelCase);
            configGroup.writeEntry("UpperCamelCaseAlt", ed.upperCamelCaseAlt);
            configGroup.writeEntry("Label", ed.label);
            configGroup.writeEntry("RequiredItems", ed.requiredItems);
            configGroup.writeEntry("OptionalItems", ed.optionalItems);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &element : elementsAuthor) {
        d->queryParameters.insert(QString(QStringLiteral("pg%1")).arg(index), QStringLiteral("ICN"));
        d->queryParameters.insert(QString(QStringLiteral("s%1")).arg(index), element);
        ++index;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &chunk : chunksIssue) {
            if (index > 1)
                query.addQueryItem(QString(QStringLiteral("operator%1")).arg(index), QStringLiteral("AND"));
            query.addQueryItem(QString(QStringLiteral("option%1")).arg(index), QStringLiteral("issue"));
            query.addQueryItem(QString(QStringLiteral("value%1")).arg(index), chunk);
            ++index;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (OpenFileInfo *openFileInfo : const_cast<const OpenFileInfoManager::OpenFileInfoList &>(restoreLaterList)) {
            openFileInfo->addFlags(OpenFileInfo::StatusFlag::Open);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : urls)
        openDocument(url);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &extension : documentFileExtensions) {
            const QFileInfo fi(baseDirectory + QDir::separator() + entry->id() + extension);
            if (fi.exists()) {
                const QUrl url = QUrl::fromLocalFile(fi.canonicalFilePath());
                if (!result.contains(url))
                    result << url;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &fd : const_cast<const BibTeXFields &>(*bf)) {
            if (!p->header()->isSectionHidden(col))
                p->header()->resizeSection(col, p->header()->width() * fd.defaultWidth / defaultWidthSumVisible);
            ++col;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            emit finished();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &item : const_cast<const QList<EncoderXMLPrivate::CharMappingItem> &>(d->charMapping))
        result.replace(item.xml, item.unicode);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &fd : const_cast<const BibTeXFields &>(BibTeXFields::instance())) {
                moveTarget[fd.visualIndex[name]] = col;
                ++col;
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto *fd : const_cast<const BibTeXFields &>(*bf)) {
            headerProperty->columns[col].isHidden = configGroup.readEntry(configHeaderState.arg(name).append(QString::number(col)).append(QStringLiteral("IsHidden")), !fd->defaultVisible);
            headerProperty->columns[col].width = configGroup.readEntry(configHeaderState.arg(name).append(QString::number(col)).append(QStringLiteral("Width")), fd->defaultWidth);
            headerProperty->columns[col].visualIndex = configGroup.readEntry(configHeaderState.arg(name).append(QString::number(col)).append(QStringLiteral("VisualIndex")), col);
            if (!headerProperty->columns[col].isHidden)
                headerProperty->sumWidths += headerProperty->columns[col].width;
            ++col;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &keyword : const_cast<const QSet<QString> &>(m_keywordsFromFile))
        forCaseInsensitiveSorting.insert(keyword.toLower(), keyword);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &element : const_cast<const File &>(*file)) {
        QSharedPointer<Entry> e = element.dynamicCast<Entry>();
        if (!e.isNull() && !e->isEmpty())
            listOfEntries << e;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[errorLog, &process] {
            QTextStream ts(process.readAllStandardError());
            while (!ts.atEnd())
                errorLog->append(ts.readLine());
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, action]() {
        d->automaticBalancing = !action->isChecked();
        if (d->automaticBalancing)
            d->resetColumnProperties(); ///< this will set the header's section resize mode to QHeaderView::Fixed
        else {
            header()->setSectionsMovable(true);
            header()->setSectionResizeMode(QHeaderView::Interactive);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &word : yearWords)
        queryFragments.append(word);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &token : tokenList) {
        QString text;
        if (token[0] == 'a' || token[0] == 'A' || token[0] == 'z') {
            struct IdSuggestionTokenInfo info = evalToken(token.mid(1));
            if (token[0] == 'a')
                info.startWord = info.endWord = 0;
            else if (token[0] == 'z') {
                info.startWord = 1;
                info.endWord = 0x00ffffff;
            }
            text = formatAuthorRange(info.startWord, info.endWord, info.lastWord);

            int n = info.len;
            if (info.len < 0x00ffffff) text.append(i18np(", but only first letter of each last name", ", but only first %1 letters of each last name", n));

            switch (info.caseChange) {
            case IdSuggestions::ccToUpper:
                text.append(i18n(", in upper case"));
                break;
            case IdSuggestions::ccToLower:
                text.append(i18n(", in lower case"));
                break;
            case IdSuggestions::ccToCamelCase:
                text.append(i18n(", in CamelCase"));
                break;
            case IdSuggestions::ccNoChange:
                break;
            }

            if (!info.inBetween.isEmpty()) text.append(i18n(", with '%1' in between", info.inBetween));
        }
        else if (token[0] == 'y')
            text.append(i18n("Year (2 digits)"));
        else if (token[0] == 'Y')
            text.append(i18n("Year (4 digits)"));
        else if (token[0] == 't' || token[0] == 'T') {
            struct IdSuggestionTokenInfo info = evalToken(token.mid(1));
            text.append(i18n("Title"));
            if (info.startWord == 0 && info.endWord <= 0xffff)
                text.append(i18np(", but only the first word", ", but only first %1 words", info.endWord + 1));
            else if (info.startWord > 0 && info.endWord > 0xffff)
                text.append(i18n(", but only starting from word %1", info.startWord + 1));
            else if (info.startWord > 0 && info.endWord <= 0xffff)
                text.append(i18n(", but only from word %1 to word %2", info.startWord + 1, info.endWord + 1));
            if (info.len < 0x00ffffff)
                text.append(i18np(", but only first letter of each word", ", but only first %1 letters of each word", info.len));

            switch (info.caseChange) {
            case IdSuggestions::ccToUpper:
                text.append(i18n(", in upper case"));
                break;
            case IdSuggestions::ccToLower:
                text.append(i18n(", in lower case"));
                break;
            case IdSuggestions::ccToCamelCase:
                text.append(i18n(", in CamelCase"));
                break;
            case IdSuggestions::ccNoChange:
                break;
            }

            if (!info.inBetween.isEmpty()) text.append(i18n(", with '%1' in between", info.inBetween));
            if (token[0] == 'T') text.append(i18n(", small words removed"));
        }
        else if (token[0] == 'j') {
            struct IdSuggestionTokenInfo info = evalToken(token.mid(1));
            text.append(i18n("Journal"));
            if (info.len < 0x00ffffff)
                text.append(i18np(", but only first letter of each word", ", but only first %1 letters of each word", info.len));
            switch (info.caseChange) {
            case IdSuggestions::ccToUpper:
                text.append(i18n(", in upper case"));
                break;
            case IdSuggestions::ccToLower:
                text.append(i18n(", in lower case"));
                break;
            case IdSuggestions::ccToCamelCase:
                text.append(i18n(", in CamelCase"));
                break;
            case IdSuggestions::ccNoChange:
                break;
            }
        } else if (token[0] == 'e') {
            struct IdSuggestionTokenInfo info = evalToken(token.mid(1));
            text.append(i18n("Type"));
            if (info.len < 0x00ffffff)
                text.append(i18np(", but only first letter of each word", ", but only first %1 letters of each word", info.len));
            switch (info.caseChange) {
            case IdSuggestions::ccToUpper:
                text.append(i18n(", in upper case"));
                break;
            case IdSuggestions::ccToLower:
                text.append(i18n(", in lower case"));
                break;
            case IdSuggestions::ccToCamelCase:
                text.append(i18n(", in CamelCase"));
                break;
            default:
                break;
            }
        } else if (token[0] == 'v') {
            text.append(i18n("Volume"));
        } else if (token[0] == 'p') {
            text.append(i18n("First page number"));
        } else if (token[0] == '"')
            text.append(i18n("Text: '%1'", token.mid(1)));
        else
            text.append("?");

        result.append(text);
    }
```

#### AUTO 


```{c}
auto it = result.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &key : const_cast<const QStringList &>(deletedKeys))
        entry->remove(key);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                typeChanged(KBibTeX::tfSource);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &element : const_cast<const File &>(*bibtexFile)) {
                QSharedPointer<Entry> entry = element.dynamicCast<Entry>();
                if (publishEntry(entry))
                    ++numFoundResults;

            }
```

#### LAMBDA EXPRESSION 


```{c}
[this, servicePtr]() {
                d->openFileWithService(servicePtr);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            addToken(ttJournal, locAtBottom);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &flagListItem : const_cast<const QStringList &>(flagListItems)) {
                htmlText.append(QString(QStringLiteral("<li>%1</li>")).arg(flagListItem));
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &formattingOption : formattingOptions) {
            comboBoxPersonNameFormatting->addItem(Person::transcribePersonName(&dummyPerson, formattingOption), formattingOption);
        }
```

#### AUTO 


```{c}
const auto code = result[i].unicode();
```

#### AUTO 


```{c}
const auto entryUrlList = FileInfo::entryUrls(entry, fileSourceModel()->bibliographyFile()->property(File::Url, QUrl()).toUrl(), FileInfo::TestExistence::Yes);
```

#### RANGE FOR STATEMENT 


```{c}
for (const HiddenTabInfo &hti : const_cast<const QSet<HiddenTabInfo> &>(d->hiddenTabInfo)) {
            if (hti.widget == page) {
                d->hiddenTabInfo.remove(hti);
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &freeTextFragment : _freeTextFragments)
            freeTextFragments.insert(freeTextFragment.toLower());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &text : fileList) {
        internalText = text;

        /// If testing for the actual existence of a filename found in the text ...
        if (testExistence == TestExistenceYes) {
            /// If a base directory (e.g. the location of the parent .bib file) is given
            /// and the potential filename fragment is NOT an absolute path, ...
            if (internalText.startsWith(QStringLiteral("~") + QDir::separator())) {
                const QString fullFilename = QDir::homePath() + internalText.mid(1);
                const QFileInfo fileInfo(fullFilename);
                const QUrl url = QUrl::fromLocalFile(fileInfo.canonicalFilePath());
                if (fileInfo.exists() && fileInfo.isFile() && url.isValid() && !result.contains(url)) {
                    result << url;
                    /// Stop searching for URLs or filenames in current internal text
                    continue;
                }
            } else if (!baseDirectory.isEmpty() &&
                       // TODO the following test assumes that absolute paths start
                       // with a dir separator, which may only be true on Unix/Linux,
                       // but not Windows. May be a test for 'first character is a letter,
                       // second is ":", third is "\"' may be necessary.
                       !internalText.startsWith(QDir::separator())) {
                /// To get the absolute path, prepend filename fragment with base directory
                const QString fullFilename = baseDirectory + QDir::separator() + internalText;
                const QFileInfo fileInfo(fullFilename);
                const QUrl url = QUrl::fromLocalFile(fileInfo.canonicalFilePath());
                if (fileInfo.exists() && fileInfo.isFile() && url.isValid() && !result.contains(url)) {
                    result << url;
                    /// Stop searching for URLs or filenames in current internal text
                    continue;
                }
            } else {
                /// Either the filename fragment is an absolute path OR no base directory
                /// was given (current working directory is assumed), ...
                const QFileInfo fileInfo(internalText);
                const QUrl url = QUrl::fromLocalFile(fileInfo.canonicalFilePath());
                if (fileInfo.exists() && fileInfo.isFile() && url.isValid() && !result.contains(url)) {
                    result << url;
                    /// stop searching for URLs or filenames in current internal text
                    continue;
                }
            }
        }

        /// extract URL from current field
        pos = 0;
        QRegularExpressionMatch urlRegExpMatch;
        while ((urlRegExpMatch = KBibTeX::urlRegExp.match(internalText, pos)).hasMatch()) {
            pos = urlRegExpMatch.capturedStart(0);
            const QString match = urlRegExpMatch.captured(0);
            QUrl url(match);
            if (url.isValid() && (testExistence == TestExistenceNo || !url.isLocalFile() || QFileInfo::exists(url.toLocalFile())) && !result.contains(url))
                result << url;
            /// remove match from internal text to avoid duplicates
            internalText = internalText.left(pos) + internalText.mid(pos + match.length());
        }

        /// explicitly check URL entry, may be an URL even if http:// or alike is missing
        pos = 0;
        QRegularExpressionMatch domainNameRegExpMatch;
        while ((domainNameRegExpMatch = KBibTeX::domainNameRegExp.match(internalText, pos)).hasMatch()) {
            pos = domainNameRegExpMatch.capturedStart(0);
            int pos2 = internalText.indexOf(QStringLiteral(" "), pos + 1);
            if (pos2 < 0) pos2 = internalText.length();
            QString match = internalText.mid(pos, pos2 - pos);
            const QUrl url(QStringLiteral("http://") + match); // FIXME what about HTTPS?
            if (url.isValid() && !result.contains(url))
                result << url;
            /// remove match from internal text to avoid duplicates
            internalText = internalText.left(pos) + internalText.mid(pos + match.length());
        }

        /// extract general file-like patterns
        pos = 0;
        QRegularExpressionMatch fileRegExpMatch;
        while ((fileRegExpMatch = KBibTeX::fileRegExp.match(internalText, pos)).hasMatch()) {
            pos = fileRegExpMatch.capturedStart(0);
            const QString match = fileRegExpMatch.captured(0);
            QUrl url(match);
            if (url.isValid() && (testExistence == TestExistenceNo || !url.isLocalFile() || QFileInfo::exists(url.toLocalFile())) && !result.contains(url))
                result << url;
            /// remove match from internal text to avoid duplicates
            internalText = internalText.left(pos) + internalText.mid(pos + match.length());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &style : styles) {
            comboBoxBibliographyStyle->addItem(style);
        }
```

#### AUTO 


```{c}
auto it = runningJobs.begin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &text : fileList) {
        internalText = text;

        /// If testing for the actual existence of a filename found in the text ...
        if (testExistence == TestExistence::Yes) {
            /// If a base directory (e.g. the location of the parent .bib file) is given
            /// and the potential filename fragment is NOT an absolute path, ...
            if (internalText.startsWith(QStringLiteral("~") + QDir::separator())) {
                const QString fullFilename = QDir::homePath() + internalText.mid(1);
                const QFileInfo fileInfo(fullFilename);
                const QUrl url = QUrl::fromLocalFile(fileInfo.canonicalFilePath());
                if (fileInfo.exists() && fileInfo.isFile() && url.isValid() && !result.contains(url)) {
                    result << url;
                    /// Stop searching for URLs or filenames in current internal text
                    continue;
                }
            } else if (!baseDirectory.isEmpty() &&
                       // TODO the following test assumes that absolute paths start
                       // with a dir separator, which may only be true on Unix/Linux,
                       // but not Windows. May be a test for 'first character is a letter,
                       // second is ":", third is "\"' may be necessary.
                       !internalText.startsWith(QDir::separator())) {
                /// To get the absolute path, prepend filename fragment with base directory
                const QString fullFilename = baseDirectory + QDir::separator() + internalText;
                const QFileInfo fileInfo(fullFilename);
                const QUrl url = QUrl::fromLocalFile(fileInfo.canonicalFilePath());
                if (fileInfo.exists() && fileInfo.isFile() && url.isValid() && !result.contains(url)) {
                    result << url;
                    /// Stop searching for URLs or filenames in current internal text
                    continue;
                }
            } else {
                /// Either the filename fragment is an absolute path OR no base directory
                /// was given (current working directory is assumed), ...
                const QFileInfo fileInfo(internalText);
                const QUrl url = QUrl::fromLocalFile(fileInfo.canonicalFilePath());
                if (fileInfo.exists() && fileInfo.isFile() && url.isValid() && !result.contains(url)) {
                    result << url;
                    /// stop searching for URLs or filenames in current internal text
                    continue;
                }
            }
        }

        /// extract URL from current field
        pos = 0;
        QRegularExpressionMatch urlRegExpMatch;
        while ((urlRegExpMatch = KBibTeX::urlRegExp.match(internalText, pos)).hasMatch()) {
            pos = urlRegExpMatch.capturedStart(0);
            const QString match = urlRegExpMatch.captured(0);
            QUrl url(match);
            if (url.isValid() && (testExistence == TestExistence::No || !url.isLocalFile() || QFileInfo::exists(url.toLocalFile())) && !result.contains(url))
                result << url;
            /// remove match from internal text to avoid duplicates
            internalText = internalText.left(pos) + internalText.mid(pos + match.length());
        }

        /// explicitly check URL entry, may be an URL even if http:// or alike is missing
        pos = 0;
        QRegularExpressionMatch domainNameRegExpMatch;
        while ((domainNameRegExpMatch = KBibTeX::domainNameRegExp.match(internalText, pos)).hasMatch()) {
            pos = domainNameRegExpMatch.capturedStart(0);
            /// URL ends either at space or at string's end
            int pos2 = internalText.indexOf(QStringLiteral(" "), pos + 1);
            if (pos2 < 0) pos2 = internalText.length();
            QString match = internalText.mid(pos, pos2 - pos);
            const QUrl url(QStringLiteral("https://") + match);
            if (url.isValid() && !result.contains(url))
                result << url;
            /// remove match from internal text to avoid duplicates
            internalText = internalText.left(pos) + internalText.mid(pos + match.length());
        }

        /// extract general file-like patterns
        pos = 0;
        QRegularExpressionMatch fileRegExpMatch;
        while ((fileRegExpMatch = KBibTeX::fileRegExp.match(internalText, pos)).hasMatch()) {
            pos = fileRegExpMatch.capturedStart(0);
            const QString match = fileRegExpMatch.captured(0);
            const QFileInfo fi(match);
            const QUrl url = QUrl::fromLocalFile(!match.startsWith(QStringLiteral("/")) && !match.startsWith(QStringLiteral("http")) && fi.isRelative() && !baseDirectory.isEmpty() ? baseDirectory + QStringLiteral("/") + match : match);
            if (url.isValid() && (testExistence == TestExistence::No || QFileInfo::exists(url.toLocalFile())) && !result.contains(url))
                result << url;
            /// remove match from internal text to avoid duplicates
            internalText = internalText.left(pos) + internalText.mid(pos + match.length());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : mil) {
        QSharedPointer<Entry> entry = d->fileView->fileModel()->element(d->fileView->sortFilterProxyModel()->mapToSource(index).row()).dynamicCast<Entry>();
        if (!entry.isNull())
            references << entry->id();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (ElementWidget *widget : d->widgets) {
            EntryConfiguredWidget *ecw = qobject_cast<EntryConfiguredWidget *>(widget);
            if (ecw != nullptr && ecw->identifier() == tabIdentifier) {
                setCurrentPage(ecw);
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &keyword : keywords)
                        value.append(keyword);
```

#### AUTO 


```{c}
const auto urlList = FileInfo::entryUrls(entry, partWidget->fileView()->fileModel()->bibliographyFile()->property(File::Url).toUrl(), FileInfo::TestExistenceYes);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        slotAddReferenceFromClipboard();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &keyword : keywords)
                    value.append(keyword);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
#if KIO_VERSION < 0x054700 // < 5.71.0
            KRun::runUrl(QUrl(lineEditAuthorizationUrl->text()), QStringLiteral("text/html"), p, KRun::RunFlags());
#else // KIO_VERSION < 0x054700 // >= 5.71.0
            KIO::OpenUrlJob *job = new KIO::OpenUrlJob(QUrl(lineEditAuthorizationUrl->text()), QStringLiteral("text/html"));
            job->setUiDelegate(new KIO::JobUiDelegate(KJobUiDelegate::AutoHandlingEnabled, p));
            job->start();
#endif // KIO_VERSION < 0x054700
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &fieldName : fl)
        if (valueMap[fieldName].count() < 2) {
            valueMap.remove(fieldName);
            chosenValueMap.remove(fieldName);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &logLine : const_cast<const QStringList &>(errorLog))
        qDebug() << logLine;
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &pair : listOfExImporter) {
        auto exporter = pair.first;
        auto importer = pair.second;
        const BibUtils::Format bibutilsformat = strncmp(exporter->metaObject()->className() + 12, "BibUtils", 8) == 0 ? qobject_cast<FileExporterBibUtils *>(exporter)->format() : BibUtils::Format::InvalidFormat;
        if (bibutilsformat == BibUtils::Format::InvalidFormat)
            bibutilsbuffer[0] = '\0';
        else
            snprintf(bibutilsbuffer, buffersize, ", format=%s", bibutilsformat == BibUtils::Format::BibTeX ? "BibTeX" : bibutilsformat == BibUtils::Format::BibLaTeX ? "BibLaTeX" : bibutilsformat == BibUtils::Format::RIS ? "RIS" : bibutilsformat == BibUtils::Format::WordBib ? "WordBib" : "???");

        File *file = new File();
        QSharedPointer<Entry> entry = QSharedPointer<Entry>(new Entry(Entry::etArticle, QStringLiteral("jabRefFieldFile")));
        Value value;
        value.append(QSharedPointer<VerbatimText>(new VerbatimText(QStringLiteral("file.pdf"))));
        entry->insert(Entry::ftFile, value);
        file->append(entry);
        snprintf(buffer, buffersize, "Field 'file' with just a filename (exporter=%s, importer=%s%s)", exporter->metaObject()->className(), importer->metaObject()->className(), bibutilsbuffer);
        QTest::newRow(buffer) << exporter << importer << file;

        file = new File();
        entry = QSharedPointer<Entry>(new Entry(Entry::etArticle, QStringLiteral("jabRefFieldFile")));
        value.clear();
        VerbatimText *verbatimText = new VerbatimText(QStringLiteral("file.pdf"));
        verbatimText->setComment(QStringLiteral("Some PDF file"));
        value.append(QSharedPointer<VerbatimText>(verbatimText));
        entry->insert(Entry::ftFile, value);
        file->append(entry);
        snprintf(buffer, buffersize, "Field 'file' with a JabRef-like value (exporter=%s, importer=%s%s)", exporter->metaObject()->className(), importer->metaObject()->className(), bibutilsbuffer);
        QTest::newRow(buffer) << exporter << importer << file;

        file = new File();
        entry = QSharedPointer<Entry>(new Entry(Entry::etArticle, QStringLiteral("jabRefFieldFile")));
        value.clear();
        verbatimText = new VerbatimText(QStringLiteral("file.pdf"));
        verbatimText->setComment();
        value.append(QSharedPointer<VerbatimText>(verbatimText));
        entry->insert(Entry::ftFile, value);
        file->append(entry);
        snprintf(buffer, buffersize, "Field 'file' with a JabRef-like value and empty comment (exporter=%s, importer=%s%s)", exporter->metaObject()->className(), importer->metaObject()->className(), bibutilsbuffer);
        QTest::newRow(buffer) << exporter << importer << file;

    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                typeChanged(KBibTeX::tfPerson);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &element : const_cast<const File &>(*this)) {
        const QSharedPointer<Entry> entry = elementTypes.testFlag(ElementType::Entry) ? element.dynamicCast<Entry>() : QSharedPointer<Entry>();
        if (!entry.isNull())
            result.append(entry->id());
        else {
            const QSharedPointer<Macro> macro = elementTypes.testFlag(ElementType::Macro) ? element.dynamicCast<Macro>() : QSharedPointer<Macro>();
            if (!macro.isNull())
                result.append(macro->key());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &valueItem : const_cast<const QSet<QSharedPointer<ValueItem> > &>(unique)) {
            containedInUnique = *valueItem.data() == *(*it).data();
            if (containedInUnique) break;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QChar &encoderLaTeXProtectedTextOnlySymbol : encoderLaTeXProtectedTextOnlySymbols)
                            if (encoderLaTeXProtectedTextOnlySymbol == input[i + 1]) {
                                output.append(encoderLaTeXProtectedTextOnlySymbol);
                                foundCommand = true;
                                break;
                            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &fd : const_cast<const BibTeXFields &>(BibTeXFields::instance())) {
                /// Take column width from stored settings, but as a fall-back/default value
                /// take the default width (usually <10) and multiply it by the average character
                /// width and 4 (magic constant)
                p->header()->resizeSection(col, fd.width.value(name, fd.defaultWidth * 4 * p->fontMetrics().averageCharWidth()));
                ++col;
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &line : const_cast<const QStringList &>(bibtexOutput)) {
        QRegularExpressionMatch match;
        if ((match = errorLine.match(line)).hasMatch()) {
            buffer.open(QIODevice::ReadOnly);
            QTextStream ts(&buffer);
            bool ok = false;
            for (int i = match.captured(1).toInt(&ok); ok && i > 1; --i) {
                errorPlainText = ts.readLine();
                buffer.close();
            }
        } else if (line.startsWith(QStringLiteral("Warning--"))) {
            /// is a warning ...

            if ((match = warningEmptyField.match(line)).hasMatch()) {
                /// empty/missing field
                warnings << i18n("Field <b>%1</b> is empty", match.captured(1));
            } else if ((match = warningEmptyField2.match(line)).hasMatch()) {
                /// two empty/missing fields
                warnings << i18n("Fields <b>%1</b> and <b>%2</b> are empty, but at least one is required", match.captured(1), match.captured(2));
            } else if ((match = warningThereIsBut.match(line)).hasMatch()) {
                /// there is a field which exists but another does not exist
                warnings << i18n("Field <b>%1</b> exists, but <b>%2</b> does not exist", match.captured(1), match.captured(2));
            } else if ((match = warningCantUseBoth.match(line)).hasMatch()) {
                /// there are two conflicting fields, only one may be used
                warnings << i18n("Fields <b>%1</b> and <b>%2</b> cannot be used at the same time", match.captured(1), match.captured(2));
            } else if ((match = warningSort2.match(line)).hasMatch()) {
                /// one out of two fields missing for sorting
                warnings << i18n("Fields <b>%1</b> or <b>%2</b> are required to sort entry", match.captured(1), match.captured(2));
            } else if ((match = warningSort3.match(line)).hasMatch()) {
                /// one out of three fields missing for sorting
                warnings << i18n("Fields <b>%1</b>, <b>%2</b>, <b>%3</b> are required to sort entry", match.captured(1), match.captured(2), match.captured(3));
            } else {
                /// generic/unknown warning
                warnings << i18n("Unknown warning: %1", line.mid(warningStart.length()));
            }
        }
    }
```

#### AUTO 


```{c}
const auto randomBits = QRandomGenerator::global()->generate();
```

#### AUTO 


```{c}
const auto &clp
```

#### RANGE FOR STATEMENT 


```{c}
for (SettingsAbstractWidget *settingsWidget : const_cast<const QSet<SettingsAbstractWidget *> &>(settingWidgets)) {
            settingsWidget->loadState();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &urlToAssociate : d->urlsToAssociate(event->mimeData()))
                modified |= d->insertUrl(urlToAssociate, dropTarget);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QChar &encoderLaTeXProtectedSymbol : encoderLaTeXProtectedSymbols)
                if (encoderLaTeXProtectedSymbol == c) {
                    output.append(QLatin1Char('\\'));
                    found = true;
                    break;
                }
```

#### AUTO 


```{c}
const auto &invalidChar
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &chunk : chunksVolume) {
            if (index > 1)
                query.addQueryItem(QString(QStringLiteral("operator%1")).arg(index), QStringLiteral("AND"));
            query.addQueryItem(QString(QStringLiteral("option%1")).arg(index), QStringLiteral("volume"));
            query.addQueryItem(QString(QStringLiteral("value%1")).arg(index), chunk);
            ++index;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &fd : const_cast<const BibTeXFields &>(*bf)) {
            /// Colors may have changed
            bool columnChanged = fd.upperCamelCase.toLower() == Entry::ftColor;
            /// Person name formatting may has changed
            columnChanged |= fd.upperCamelCase.toLower() == Entry::ftAuthor || fd.upperCamelCase.toLower() == Entry::ftEditor;
            columnChanged |= fd.upperCamelCaseAlt.toLower() == Entry::ftAuthor || fd.upperCamelCaseAlt.toLower() == Entry::ftEditor;
            /// Changes necessary for this column? Publish update
            if (columnChanged)
                emit dataChanged(index(0, column), index(rowCount() - 1, column));
            ++column;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &lastAuthor : const_cast<const QStringList &>(lastAuthorsList))
        hashAuthors.addData(lastAuthor.toUtf8());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &token : tokenList) {
        id.append(IdSuggestionsPrivate::translateToken(entry, token));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &valueItem : value) {
        QSharedPointer<const MacroKey> macroKey = valueItem.dynamicCast<const MacroKey>();
        if (!macroKey.isNull()) {
            if (isOpen) result.append(d->stringCloseDelimiter);
            isOpen = false;
            if (!result.isEmpty()) result.append(" # ");
            result.append(macroKey->text());
            prev = macroKey;
        } else {
            QSharedPointer<const PlainText> plainText = valueItem.dynamicCast<const PlainText>();
            if (!plainText.isNull()) {
                QString textBody = applyEncoder(plainText->text(), useLaTeXEncoding);
                if (!isOpen) {
                    if (!result.isEmpty()) result.append(" # ");
                    result.append(d->stringOpenDelimiter);
                } else if (!prev.dynamicCast<const PlainText>().isNull())
                    result.append(' ');
                else if (!prev.dynamicCast<const Person>().isNull()) {
                    /// handle "et al." i.e. "and others"
                    result.append(" and ");
                } else {
                    result.append(d->stringCloseDelimiter).append(" # ").append(d->stringOpenDelimiter);
                }
                isOpen = true;

                if (d->stringOpenDelimiter == QLatin1Char('"'))
                    d->protectQuotationMarks(textBody);
                result.append(textBody);
                prev = plainText;
            } else {
                QSharedPointer<const VerbatimText> verbatimText = valueItem.dynamicCast<const VerbatimText>();
                if (!verbatimText.isNull()) {
                    QString textBody = verbatimText->text();
                    if (!isOpen) {
                        if (!result.isEmpty()) result.append(" # ");
                        result.append(d->stringOpenDelimiter);
                    } else if (!prev.dynamicCast<const VerbatimText>().isNull()) {
                        const QString keyToLower(key.toLower());
                        if (keyToLower.startsWith(Entry::ftUrl) || keyToLower.startsWith(Entry::ftLocalFile) || keyToLower.startsWith(Entry::ftDOI))
                            /// Filenames and alike have be separated by a semicolon,
                            /// as a plain comma may be part of the filename or URL
                            result.append(QStringLiteral("; "));
                        else
                            result.append(' ');
                    } else {
                        result.append(d->stringCloseDelimiter).append(" # ").append(d->stringOpenDelimiter);
                    }
                    isOpen = true;

                    if (d->stringOpenDelimiter == QLatin1Char('"'))
                        d->protectQuotationMarks(textBody);
                    result.append(textBody);
                    prev = verbatimText;
                } else {
                    QSharedPointer<const Person> person = valueItem.dynamicCast<const Person>();
                    if (!person.isNull()) {
                        QString firstName = person->firstName();
                        if (!firstName.isEmpty() && d->requiresPersonQuoting(firstName, false))
                            firstName = firstName.prepend("{").append("}");

                        QString lastName = person->lastName();
                        if (!lastName.isEmpty() && d->requiresPersonQuoting(lastName, true))
                            lastName = lastName.prepend("{").append("}");

                        QString suffix = person->suffix();

                        /// Fall back and enforce comma-based name formatting
                        /// if name contains a suffix like "Jr."
                        /// Otherwise name could not be parsed again reliable
                        const QString pnf = suffix.isEmpty() ? d->personNameFormatting : Preferences::personNameFormatLastFirst;
                        QString thisName = applyEncoder(Person::transcribePersonName(pnf, firstName, lastName, suffix), useLaTeXEncoding);

                        if (!isOpen) {
                            if (!result.isEmpty()) result.append(" # ");
                            result.append(d->stringOpenDelimiter);
                        } else if (!prev.dynamicCast<const Person>().isNull())
                            result.append(" and ");
                        else {
                            result.append(d->stringCloseDelimiter).append(" # ").append(d->stringOpenDelimiter);
                        }
                        isOpen = true;

                        if (d->stringOpenDelimiter == QLatin1Char('"'))
                            d->protectQuotationMarks(thisName);
                        result.append(thisName);
                        prev = person;
                    } else {
                        QSharedPointer<const Keyword> keyword = valueItem.dynamicCast<const Keyword>();
                        if (!keyword.isNull()) {
                            QString textBody = applyEncoder(keyword->text(), useLaTeXEncoding);
                            if (!isOpen) {
                                if (!result.isEmpty()) result.append(" # ");
                                result.append(d->stringOpenDelimiter);
                            } else if (!prev.dynamicCast<const Keyword>().isNull())
                                result.append(d->listSeparator);
                            else {
                                result.append(d->stringCloseDelimiter).append(" # ").append(d->stringOpenDelimiter);
                            }
                            isOpen = true;

                            if (d->stringOpenDelimiter == QLatin1Char('"'))
                                d->protectQuotationMarks(textBody);
                            result.append(textBody);
                            prev = keyword;
                        }
                    }
                }
            }
        }
        prev = valueItem;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QAction *action : actionList) {
        /// Make URL from action's data ...
        QUrl tmpUrl = QUrl(action->data().toString());
        /// ... but skip this action if the URL is invalid
        if (!tmpUrl.isValid()) continue;
        if (tmpUrl.isLocalFile()) {
            /// If action's URL points to local file,
            /// keep it and stop search for document
            url = tmpUrl;
            break;
        } else if (!url.isValid())
            /// First valid URL found, keep it
            /// URL is not local, so it may get overwritten by another URL
            url = tmpUrl;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, fi]() {
                        elementViewDocumentMenu(QUrl::fromLocalFile(fi.absoluteFilePath()));
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &param : copyParameters) {
            for (const QString &value : formParams.values(param))
                query.addQueryItem(param, value);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &element : const_cast<const File &>(*this)) {
        const QSharedPointer<Entry> entry = elementTypes.testFlag(etEntry) ? element.dynamicCast<Entry>() : QSharedPointer<Entry>();
        if (!entry.isNull()) {
            if (entry->id() == key)
                return entry;
        } else {
            const QSharedPointer<Macro> macro = elementTypes.testFlag(etMacro) ? element.dynamicCast<Macro>() : QSharedPointer<Macro>();
            if (!macro.isNull()) {
                if (macro->key() == key)
                    return macro;
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, tokenWidget]() {
                removeToken(tokenWidget);
            }
```

#### AUTO 


```{c}
const auto urlList = FileInfo::entryUrls(entry, QUrl(file->property(File::Url).toUrl()), FileInfo::TestExistence::No);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &fd : const_cast<const BibTeXFields &>(BibTeXFields::instance())) {
            const bool visibility = fd.visible.value(name, fd.defaultVisible);
            /// Width of 0 for all fields means 'enable auto-balancing'
            automaticBalancing &= fd.width.value(name, 0) == 0;
            p->header()->setSectionHidden(col, !visibility);
            ++col;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &element : elementsFreeText) {
        if (queryNumber > 0) q.addQueryItem(QString(QStringLiteral("c%1")).arg(queryNumber), QStringLiteral("AND")); ///< join search terms with an AND operation
        q.addQueryItem(QString(QStringLiteral("f%1")).arg(queryNumber), QStringLiteral("all"));
        q.addQueryItem(QString(QStringLiteral("q%1")).arg(queryNumber), element);
        ++queryNumber;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &fd : const_cast<const BibTeXFields &>(BibTeXFields::instance())) {
        QAction *action = new QAction(fd.label, &menu);
        action->setData(col);
        action->setCheckable(true);
        action->setChecked(!header()->isSectionHidden(col));
        connect(action, &QAction::triggered, this, &BasicFileView::headerActionToggled);
        menu.addAction(action);
        ++col;
    }
```

#### AUTO 


```{c}
auto it = splitAlong.constBegin();
```

#### AUTO 


```{c}
const auto appleWebKitVersionMinor = QRandomGenerator::global()->bounded(3, 53);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &author : authors) {
            queryString += QString(QStringLiteral(" name:%1")).arg(Encoder::instance().convertToPlainAscii(author));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &valueItem : const_cast<const Value &>(*this))
        if (valueItem->operator==(item))
            return true;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto *fd : const_cast<const BibTeXFields &>(*bf)) {
            /// Colors may have changed
            bool columnChanged = fd->upperCamelCase.toLower() == Entry::ftColor;
            /// Person name formatting may has changed
            columnChanged |= fd->upperCamelCase.toLower() == Entry::ftAuthor || fd->upperCamelCase.toLower() == Entry::ftEditor;
            columnChanged |= fd->upperCamelCaseAlt.toLower() == Entry::ftAuthor || fd->upperCamelCaseAlt.toLower() == Entry::ftEditor;
            /// Changes necessary for this column? Publish update
            if (columnChanged)
                emit dataChanged(index(0, column), index(rowCount() - 1, column));
            ++column;
        }
```

#### AUTO 


```{c}
const auto appleWebKitVersionMajor = randomGeneratorGlobalBounded(537, 856);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &valueItem : const_cast<const Value &>(*this)) {
        if (valueItem->containsPattern(pattern, caseSensitive))
            return true;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &element : elementsFreeText) {
        d->queryParameters.insert(QString(QStringLiteral("pg%1")).arg(index), QStringLiteral("ALLF"));
        d->queryParameters.insert(QString(QStringLiteral("s%1")).arg(index), element);
        ++index;
    }
```

#### AUTO 


```{c}
const auto &containedValueItem
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            addToken(ttVolume, locAtBottom);
        }
```

#### AUTO 


```{c}
const auto itValue = it.value();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : urlList) {
                    /// First iteration: local references only
                    if (!url.isLocalFile()) continue; ///< skip remote URLs

                    /// Build a nice menu item (label, icon, ...)
                    const QFileInfo fi(url.toLocalFile());
                    const QString label = QString(QStringLiteral("%1 [%2]")).arg(fi.fileName(), fi.absolutePath());
                    QAction *action = new QAction(QIcon::fromTheme(FileInfo::mimeTypeForUrl(url).iconName()), label, p);
                    action->setData(QUrl::fromLocalFile(fi.absoluteFilePath()));
                    action->setToolTip(fi.absoluteFilePath());
                    /// Open URL when action is triggered
                    connect(action, &QAction::triggered, p, [this, fi]() {
                        elementViewDocumentMenu(QUrl::fromLocalFile(fi.absoluteFilePath()));
                    });
                    viewDocumentMenu->addAction(action);
                    /// Memorize first action
                    if (firstAction == nullptr) firstAction = action;
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &alias : rawAliases) {
                if (entry->contains(alias)) {
                    text = PlainTextValue::text(entry->value(alias)).simplified();
                    if (!text.isEmpty()) break;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const EncoderLaTeXCharacterCommand &encoderLaTeXCharacterCommand : encoderLaTeXCharacterCommands) {
                        if (encoderLaTeXCharacterCommand.command == alpha) {
                            output.append(QChar(encoderLaTeXCharacterCommand.unicode));
                            found = true;
                            break;
                        }
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &freeTextFragment : freeTextFragments) {
            queryText << QString(QStringLiteral("\"%1\"")).arg(freeTextFragment);
        }
```

#### LAMBDA EXPRESSION 


```{c}
connectStartingDelayedTimer(comboBoxCombination, static_cast<void(QComboBox::*)(int)>(&QComboBox::currentIndexChanged))
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &newValueItem : toBeAssignedValue) {
                        entrysValueForField.append(newValueItem);
                    }
```

#### AUTO 


```{c}
const auto format
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &word : journalWords) {
            QString journalComponent = normalizeText(word);

            /// Try to keep sequences of capital letters at the start of the journal name,
            /// those may already be abbreviations.
            unsigned int countCaptialCharsAtStart = 0;
            while (journalComponent[countCaptialCharsAtStart].isUpper()) ++countCaptialCharsAtStart;
            journalComponent = journalComponent.left(qMax(jti.len, countCaptialCharsAtStart));

            if (jti.caseChange == IdSuggestions::ccToCamelCase)
                journalComponent = journalComponent[0].toUpper() + journalComponent.mid(1);
            result.append(journalComponent);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &value : formParams.values(param))
                query.addQueryItem(param, value);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            needToApplyCredentials = true;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
#if KIO_VERSION < 0x054700 // < 5.71.0
            KRun::runUrl(QUrl(lineEditAuthorizationUrl->text()), QStringLiteral("text/html"), p, KRun::RunFlags());
#else // KIO_VERSION < 0x054700 // >= 5.71.0
            KIO::OpenUrlJob *job = new KIO::OpenUrlJob(QUrl(lineEditAuthorizationUrl->text()), QStringLiteral("text/html"));
            job->setUiDelegate(new KIO::JobUiDelegate());
            job->start();
#endif // KIO_VERSION < 0x054700
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &fd : const_cast<const BibTeXFields &>(BibTeXFields::instance())) {
            if (!fd.upperCamelCaseAlt.isEmpty()) continue; /// keep only "single" fields and not combined ones like "Author or Editor"
            if (fd.upperCamelCase.startsWith('^')) continue; /// skip "type" and "id"
            comboboxFieldNames->addItem(fd.label, fd.upperCamelCase);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                typeChanged(KBibTeX::tfPlainText);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &line : const_cast<const QStringList &>(lines))
                ts << line << endl;
```

#### RANGE FOR STATEMENT 


```{c}
for (const DotlessIJCharacter &dotlessIJCharacter : dotlessIJCharacters)
                        if (dotlessIJCharacter.letter == input[i + 5 + skipSpaces] && dotlessIJCharacter.modifier == input[i + 2]) {
                            output.append(QChar(dotlessIJCharacter.unicode));
                            found = true;
                            break;
                        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : entryUrlList) {
                if (url.isLocalFile() && url.fileName().endsWith(QStringLiteral(".pdf"))) {
                    const QString text = FileInfo::pdfToText(url.toLocalFile());
                    int i = 0;
                    for (QStringList::ConstIterator itsl = m_filterQuery.terms.constBegin(); itsl != m_filterQuery.terms.constEnd(); ++itsl, ++i)
                        eachTerm[i] |= (*itsl).isEmpty() ? true : text.contains(*itsl, Qt::CaseInsensitive);
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            addToken(ttType, locAtBottom);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QSslError &error : errors)
        qCWarning(LOG_KBIBTEX_NETWORKING) << QStringLiteral(" * ") + error.errorString() << "; Code: " << static_cast<int>(error.error());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &dbItem : Preferences::availablePageSizes)
            comboBoxPaperSize->addItem(QPageSize::name(dbItem.internalPageSizeId), dbItem.internalPageSizeId);
```

#### LAMBDA EXPRESSION 


```{c}
[&gotErrors](const FileImporter::MessageSeverity messageSeverity, const QString & messageText) {
        gotErrors |= messageSeverity >= FileImporter::MessageSeverity::Error;
        Q_UNUSED(messageText)
        //qCDebug(LOG_KBIBTEX_TEST)<<"FileImporterRIS issues message during 'partialBibTeXInput' test: "<<messageText;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QModelIndex &, const QModelIndex &, const QVector<int> &roles = QVector<int>()){
        if (roles.contains(EngineEnabledRole))
            emit searchEngineCountChanged();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &key : keyData) {
        for (int i = 0; i < 2; ++i) {
            entry.remove(key);
            Value v;
            entry.insert(key, v);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &key : keys) {
        QCOMPARE(computedResult.contains(key), true);
        const QList<QString> expectedValues = expectedResult.values(key);
        const QList<QString> computedValues = computedResult.values(key);
        QCOMPARE(expectedValues.size(), computedValues.size());
        for (int p = expectedValues.size() - 1; p >= 0; --p) {
            const QString &expectedValue = expectedValues[p];
            const QString &computedValue = computedValues[p];
            QCOMPARE(expectedValue, computedValue);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &element : elementsTitle) {
        if (queryNumber > 0) q.addQueryItem(QString(QStringLiteral("c%1")).arg(queryNumber), QStringLiteral("AND")); ///< join search terms with an AND operation
        q.addQueryItem(QString(QStringLiteral("f%1")).arg(queryNumber), QStringLiteral("ti"));
        q.addQueryItem(QString(QStringLiteral("q%1")).arg(queryNumber), element);
        ++queryNumber;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &word : titleWords)
        queryFragments.append(rangeSearch.arg(QStringLiteral("intitle"), word));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &fd : const_cast<const BibTeXFields &>(*bf)) {
            const bool visibility = fd.visible.contains(name) ? fd.visible[name] : fd.defaultVisible;
            p->header()->setSectionHidden(col, !visibility);
            p->header()->actions().at(col)->setChecked(visibility);
            ++col;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](int index) {
            comboBoxChanged(index);
        }
```

#### AUTO 


```{c}
const auto &etl
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &chunk : chunksAuthor) {
            if (index > 1)
                q.addQueryItem(QString(QStringLiteral("operator%1")).arg(index), QStringLiteral("AND"));
            q.addQueryItem(QString(QStringLiteral("option%1")).arg(index), QStringLiteral("author"));
            q.addQueryItem(QString(QStringLiteral("value%1")).arg(index), chunk);
            ++index;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QSharedPointer<ValueItem> &valueItem : itValue) {
                        /// Check if ValueItem to process points to a person
                        const QSharedPointer<Person> person = valueItem.dynamicCast<Person>();
                        if (!person.isNull()) {
                            /// Assemble a list of formatting templates for a person's name
                            static QStringList personNameFormattingList; ///< use static to do pattern assembly only once
                            if (personNameFormattingList.isEmpty()) {
                                /// Use the two default patterns last-name-first and first-name-first
#ifdef HAVE_KF5
                                personNameFormattingList << Preferences::personNameFormatLastFirst << Preferences::personNameFormatFirstLast;
                                /// Check configuration if user-specified formatting template is different
                                KSharedConfigPtr config(KSharedConfig::openConfig(QStringLiteral("kbibtexrc")));
                                KConfigGroup configGroup(config, "General");
                                QString personNameFormatting = configGroup.readEntry(Preferences::keyPersonNameFormatting, Preferences::defaultPersonNameFormatting);
                                /// Add user's template if it differs from the two specified above
                                if (!personNameFormattingList.contains(personNameFormatting))
                                    personNameFormattingList << personNameFormatting;
#else // HAVE_KF5
                                personNameFormattingList << QStringLiteral("<%l><, %s><, %f>") << QStringLiteral("<%f ><%l>< %s>");
#endif // HAVE_KF5
                            }
                            /// Add person's name formatted using each of the templates assembled above
                            for (const QString &personNameFormatting : const_cast<const QStringList &>(personNameFormattingList)) {
                                valueSet.insert(Person::transcribePersonName(person.data(), personNameFormatting));
                            }
                        } else {
                            /// Default case: use PlainTextValue::text to translate ValueItem
                            /// to a human-readable text
                            valueSet.insert(PlainTextValue::text(*valueItem));
                        }
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Poppler::EmbeddedFile *file : embeddedFiles) {
            if (file->name().endsWith(QStringLiteral(".bib"))) {
                // TODO maybe request implementation of a constData() for
                // Poppler::EmbeddedFile to operate on const objects?
                QByteArray data(file->data());
                QBuffer buffer(&data);
                FileImporterBibTeX bibTeXimporter;
                connect(&bibTeXimporter, &FileImporter::progress, this, &FileImporter::progress);
                buffer.open(QIODevice::ReadOnly);
                result = bibTeXimporter.load(&buffer);
                buffer.close();

                if (result) {
                    qCDebug(LOG_KBIBTEX_IO) << "Bibliography extracted from embedded file" << file->name() << "has" << result->count() << "entries";
                    if (result->count() > 0)
                        break; ///< stop processing after first valid, non-empty BibTeX file
                    else {
                        /// ... otherwise delete empty bibliography object
                        delete result;
                        result = NULL;
                    }
                } else
                    qCDebug(LOG_KBIBTEX_IO) << "Create bibliography file from embedded file" << file->name() << "failed";
            } else
                qCDebug(LOG_KBIBTEX_IO) << "Embedded file" << file->name() << "doesn't have right extension ('.bib')";
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, openFileInfo]() {
            loadingFinished(openFileInfo);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : entryUrlList) {
                if (url.isLocalFile() && url.fileName().endsWith(QStringLiteral(".pdf"))) {
                    const QString text = FileInfo::pdfToText(url.url(QUrl::PreferLocalFile));
                    int i = 0;
                    for (QStringList::ConstIterator itsl = m_filterQuery.terms.constBegin(); itsl != m_filterQuery.terms.constEnd(); ++itsl, ++i)
                        eachTerm[i] |= (*itsl).isEmpty() ? true : text.contains(*itsl, Qt::CaseInsensitive);
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (NotificationListener *listener : const_cast<const QSet<NotificationListener *> &>(d->allListeners)) {
            set.insert(listener);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &text : titleWords) {
            static const QString titleTemplate = QStringLiteral("srw.ti+all+\"%1\"");
            queryFragments.append(titleTemplate.arg(text));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &ed : BibTeXEntries::instance())
                if (typeLower == ed.upperCamelCaseAlt.toLower()) {
                    index = entryType->findData(ed.upperCamelCase);
                    break;
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const HiddenTabInfo &hti : const_cast<const QSet<HiddenTabInfo> &>(m_hiddenTabInfo)) {
        if (hti.widget == page)
            return showTab(hti);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const MathCommand &mathCommand : mathCommands)
                    if (mathCommand.unicode == c.unicode() && (mathCommand.direction & DirectionUnicodeToCommand)) {
                        if (inMathMode)
                            output.append(QString(QStringLiteral("\\%1{}")).arg(mathCommand.command));
                        else
                            output.append(QString(QStringLiteral("\\ensuremath{\\%1}")).arg(mathCommand.command));
                        found = true;
                        break;
                    }
```

#### AUTO 


```{c}
const auto respectingQuotationMarksTitle = splitRespectingQuotationMarks(query[QueryKey::Title]);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : urlList) {
                    if (url.isLocalFile()) continue; ///< skip local files

                    /// Build a nice menu item (label, icon, ...)
                    const QString prettyUrl = url.toDisplayString();
                    QAction *action = new QAction(QIcon::fromTheme(FileInfo::mimeTypeForUrl(url).iconName()), prettyUrl, p);
                    action->setToolTip(prettyUrl);
                    /// Open URL when action is triggered
                    connect(action, &QAction::triggered, p, [this, url]() {
                        elementViewDocumentMenu(url);
                    });
                    viewDocumentMenu->addAction(action);
                    /// Memorize first action
                    if (firstAction == nullptr) firstAction = action;
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &fd : const_cast<const BibTeXFields &>(*bf))
            if (fd.upperCamelCaseAlt.isEmpty())
                fielddescs.insert(fd.label, fd.upperCamelCase);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QRegularExpression &anchorRegExp : specificAnchorRegExp) {
            const QRegularExpressionMatch match = anchorRegExp.match(text);
            if (match.hasMatch()) {
                const QUrl url = QUrl::fromEncoded(match.captured(1).toLatin1());
                queueUrl(reply->url().resolved(url), term, origin, depth - 1);
                gotLink = true;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *ofi : const_cast<const OpenFileInfoManager::OpenFileInfoList &>(d->openFileInfoList))
                if (ofi->flags().testFlag(OpenFileInfo::StatusFlag::Open) && (ofiToUse == nullptr || (recentlyOpenURL.isValid() && ofi->url() == recentlyOpenURL)))
                    ofiToUse = ofi;
```

#### LAMBDA EXPRESSION 


```{c}
[this, le]() {
            const bool gotModified = goUpFieldLineEdit(le);
            if (gotModified) {
                /// Instead of an 'emit' ...
                QMetaObject::invokeMethod(p, "modified", Qt::DirectConnection, QGenericReturnArgument());
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &origin : crossRefList)
                    allProcessed &= processedEntryIds.contains(origin);
```

#### AUTO 


```{c}
const auto urlList = FileInfo::entryUrls(entry, QUrl(file->property(File::Url).toUrl()), FileInfo::TestExistenceNo);
```

#### RANGE FOR STATEMENT 


```{c}
for (const DotlessIJCharacter &dotlessIJCharacter : dotlessIJCharacters)
                        if (dotlessIJCharacter.letter == input[i + 5 + skipSpaces] && dotlessIJCharacter.modifier == input[i + 2]) {
                            output.append(QChar(dotlessIJCharacter.unicode));
                            i += 7 + skipSpaces;
                            found = true;
                            break;
                        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &personNameFormatting : const_cast<const QStringList &>(personNameFormattingList)) {
                                valueSet.insert(Person::transcribePersonName(person.data(), personNameFormatting));
                            }
```

#### RANGE FOR STATEMENT 


```{c}
for (SettingsAbstractWidget *settingsWidget : const_cast<const QSet<SettingsAbstractWidget *> &>(settingWidgets)) {
            const bool settingsGotChanged = settingsWidget->saveState();
            if (settingsGotChanged)
                eventIdsToNotify.insert(settingsWidget->eventId());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &valueItem : v) {
            QString plainText = PlainTextValue::text(*valueItem);

            static const QRegularExpression regExpEscapedChars = QRegularExpression(QStringLiteral("\\\\+([&_~])"));
            plainText.replace(regExpEscapedChars, QStringLiteral("\\1"));

            urlsInText(plainText, testExistence, baseDirectory, result);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            checkBibTeX();
        }
```

#### AUTO 


```{c}
const auto formatIdList = idSuggestions->formatIdList(*crossrefResolvedEntry.data());
```

#### AUTO 


```{c}
const auto &vi
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &fd : const_cast<const BibTeXFields &>(BibTeXFields::instance())) {
            if (!p->header()->isSectionHidden(col))
                p->header()->resizeSection(col, p->header()->width() * fd.defaultWidth / defaultWidthSumVisible);
            ++col;
        }
```

#### AUTO 


```{c}
const auto urlList = FileInfo::entryUrls(entry, bibTeXFile->property(File::Url).toUrl(), FileInfo::TestExistence::Yes);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            addToken(ttYear, locAtTop);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QSharedPointer<ValueItem> &vi : v) {
        QSharedPointer<const Person> p = vi.dynamicCast<const Person>();
        if (!p.isNull())
            result.append(encoder.convertToPlainAscii(p->lastName()));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const HiddenTabInfo &hti : const_cast<const QSet<HiddenTabInfo> &>(m_hiddenTabInfo)) {
        if (hti.widget == page) {
            index = showTab(hti, index);
            setTabIcon(index, icon);
            setTabText(index, label);
            return index;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &fd : const_cast<const BibTeXFields &>(*this)) {
            /// configuration file uses camel-case
            QString itName = fd.upperCamelCase.toLower();
            if (itName == iName && fd.upperCamelCaseAlt.isEmpty()) {
                iName = fd.upperCamelCase;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &cmd : inlineCommands) {
            const QString wrappedCmd = QString(QStringLiteral("{%1}")).arg(cmd);
            code = code.replace(cmd, wrappedCmd);
        }
```

#### AUTO 


```{c}
auto *ofi
```

#### RANGE FOR STATEMENT 


```{c}
for (const unsigned char c : outputData)
        if ((c & 128) > 0) {
            hasNonAsciiCharacters = true;
            break;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &encoding : testCase.encodingsToBeTested) {
            const QString testLabel = QString(QStringLiteral("Round-trip of '%1' encoded in '%2'")).arg(testCase.label).arg(encoding);
            QTest::newRow(testLabel.toLatin1().constData()) << testCase.bibliography << encoding;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QChar &encoderLaTeXProtectedSymbol : encoderLaTeXProtectedSymbols)
                        if (encoderLaTeXProtectedSymbol == input[i + 1]) {
                            output.append(encoderLaTeXProtectedSymbol);
                            found = true;
                            break;
                        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &text : freeTextWords)
            queryFragments.append(text + (pmidRegExp.match(text).hasMatch() ? QStringLiteral("") : QStringLiteral("[All Fields]")));
```

#### RANGE FOR STATEMENT 


```{c}
for (const EncoderLaTeXCharacterCommand &encoderLaTeXCharacterCommand : encoderLaTeXCharacterCommands) {
                            if (encoderLaTeXCharacterCommand.command == alpha) {
                                output.append(QChar(encoderLaTeXCharacterCommand.unicode));
                                foundCommand = true;
                                break;
                            }
                        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SingleFieldLayout &sfl : const_cast<const QList<SingleFieldLayout> &>(etl->singleFieldLayouts)) {
        LabeledFieldInput *labeledFieldInput = new LabeledFieldInput;

        /// create an editing widget for this field
        const FieldDescription &fd = bf->find(sfl.bibtexLabel);
        labeledFieldInput->fieldInput = new FieldInput(sfl.fieldInputLayout, fd.preferredTypeFlag, fd.typeFlags, this);
        labeledFieldInput->fieldInput->setFieldKey(sfl.bibtexLabel);
        bibtexKeyToWidget.insert(sfl.bibtexLabel, labeledFieldInput->fieldInput);
        connect(labeledFieldInput->fieldInput, &FieldInput::modified, this, &EntryConfiguredWidget::gotModified);

        /// memorize if field input should grow vertically (e.g. is a list)
        labeledFieldInput->isVerticallyMinimumExpaning = sfl.fieldInputLayout == KBibTeX::MultiLine || sfl.fieldInputLayout == KBibTeX::List || sfl.fieldInputLayout == KBibTeX::PersonList || sfl.fieldInputLayout == KBibTeX::KeywordList;

        /// create a label next to the editing widget
        labeledFieldInput->label = new QLabel(QString(QStringLiteral("%1:")).arg(sfl.uiLabel), this);
        labeledFieldInput->label->setBuddy(labeledFieldInput->fieldInput->buddy());
        /// align label's text vertically to match field input
        Qt::Alignment horizontalAlignment = (Qt::Alignment)(labeledFieldInput->label->style()->styleHint(QStyle::SH_FormLayoutLabelAlignment) & 0x001f);
        labeledFieldInput->label->setAlignment(horizontalAlignment | (labeledFieldInput->isVerticallyMinimumExpaning ? Qt::AlignTop : Qt::AlignVCenter));

        listOfLabeledFieldInput[i] = labeledFieldInput;

        ++i;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &freeTextFragment : const_cast<const QSet<QString> &>(d->freeTextFragments))
                            allFreeTextFragmentsContained &= freeText.contains(freeTextFragment);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            /// When the bibliography system is switched (e.g. from BibTeX to BibLaTeX),
            /// re-load the column properties, e.g. to hide or rebalance columns
            d->loadColumnProperties();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &dbItem : Preferences::availablePageSizes)
            comboBoxPaperSize->addItem(QPageSize::name(dbItem.first), dbItem.second);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QSharedPointer<Person> &person : personList) {
            Value *value = new Value();
            value->append(person);
            lineAdd(value);
            delete value;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &encoding : listOfASCIIcompatibleEncodings) {
        const QByteArray encodingOutput{QByteArray{"@comment{x-kbibtex-encoding="} +encoding.toLatin1() + QByteArray{"}\n\n"}};
        const QByteArray mobyDickExpectedOutput{encoding == QStringLiteral("LaTeX") ? mobyDickEntryOutput : encodingOutput + mobyDickEntryOutput};
        QTest::newRow(QString(QStringLiteral("Moby Dick (ASCII only) encoded in '%1'")).arg(encoding).toLatin1().constData()) << mobyDickBibliography() << encoding << mobyDickExpectedOutput;
    }
```

#### AUTO 


```{c}
static const auto pairs = QHash<int, const char *> {
        {static_cast<int>(KBibTeX::TypeFlag::Invalid), "Invalid"},
        {static_cast<int>(KBibTeX::TypeFlag::PlainText), "PlainText"},
        {static_cast<int>(KBibTeX::TypeFlag::Reference), "Reference"},
        {static_cast<int>(KBibTeX::TypeFlag::Person), "Person"},
        {static_cast<int>(KBibTeX::TypeFlag::Keyword), "Keyword"},
        {static_cast<int>(KBibTeX::TypeFlag::Verbatim), "Verbatim"},
        {static_cast<int>(KBibTeX::TypeFlag::Source), "Source"}
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this, reply, fileNameStem, favIconUrl, webpageUrl]() {
            if (reply->error() == QNetworkReply::NoError) {
                const QByteArray iconData = reply->readAll();
                if (iconData.size() > 10) {
                    QString extension;
                    if (iconData[1] == 'P' && iconData[2] == 'N' && iconData[3] == 'G') {
                        /// PNG files have string "PNG" at second to fourth byte
                        extension = QStringLiteral(".png");
                    } else if (iconData[0] == static_cast<char>(0x00) && iconData[1] == static_cast<char>(0x00) && iconData[2] == static_cast<char>(0x01) && iconData[3] == static_cast<char>(0x00)) {
                        /// Microsoft Icon have first two bytes always 0x0000,
                        /// third and fourth byte is 0x0001 (for .ico)
                        extension = QStringLiteral(".ico");
                    } else if (iconData[0] == '<') {
                        /// HTML or XML code
                        const QString htmlCode = QString::fromUtf8(iconData);
                        qCWarning(LOG_KBIBTEX_NETWORKING) << "Received XML or HTML data from " << InternalNetworkAccessManager::removeApiKey(reply->url()).toDisplayString() << ": " << htmlCode.left(128);
                    } else {
                        qCWarning(LOG_KBIBTEX_NETWORKING) << "Favicon is of unknown format: " << InternalNetworkAccessManager::removeApiKey(reply->url()).toDisplayString();
                    }

                    if (!extension.isEmpty()) {
                        const QString filename = fileNameStem + extension;

                        QFile iconFile(filename);
                        if (iconFile.open(QFile::WriteOnly)) {
                            iconFile.write(iconData);
                            iconFile.close();
                            qCInfo(LOG_KBIBTEX_NETWORKING) << "Got icon from URL" << favIconUrl.toDisplayString() << "for webpage" << webpageUrl.toDisplayString() << "stored in" << filename;
                            favIcon = QIcon(filename);
                        } else {
                            qCWarning(LOG_KBIBTEX_NETWORKING) << "Could not save icon data from URL" << InternalNetworkAccessManager::removeApiKey(reply->url()).toDisplayString() << "to file" << filename;
                        }
                    }
                } else {
                    /// Unlikely that an icon's data is less than 10 bytes,
                    /// must be an error.
                    qCWarning(LOG_KBIBTEX_NETWORKING) << "Received invalid icon data from " << InternalNetworkAccessManager::removeApiKey(reply->url()).toDisplayString();
                }
            } else
                qCWarning(LOG_KBIBTEX_NETWORKING) << "Could not download icon from URL " << InternalNetworkAccessManager::removeApiKey(reply->url()).toDisplayString() << ": " << reply->errorString();

            QMetaObject::invokeMethod(this, "gotIcon", Qt::DirectConnection, QGenericReturnArgument(), Q_ARG(QIcon, favIcon));
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                typeChanged(KBibTeX::TypeFlag::Keyword);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            addToken(ttText, locAtBottom);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : urlList) {
                    /// First iteration: local references only
                    if (!url.isLocalFile()) continue; ///< skip remote URLs

                    /// Build a nice menu item (label, icon, ...)
                    QFileInfo fi(url.url(QUrl::PreferLocalFile));
                    const QString label = QString(QStringLiteral("%1 [%2]")).arg(fi.fileName(), fi.absolutePath());
                    QMimeDatabase db;
                    QAction *action = new QAction(QIcon::fromTheme(db.mimeTypeForUrl(url).iconName()), label, p);
                    action->setData(url.url(QUrl::PreferLocalFile));
                    action->setToolTip(url.url(QUrl::PreferLocalFile));
                    /// Register action at signal handler to open URL when triggered
                    connect(action, &QAction::triggered, signalMapperViewDocument, static_cast<void(QSignalMapper::*)()>(&QSignalMapper::map));
                    signalMapperViewDocument->setMapping(action, action);
                    signalMapperViewDocumentSenders.insert(action);
                    viewDocumentMenu->addAction(action);
                    /// Memorize first action
                    if (firstAction == nullptr) firstAction = action;
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &element : const_cast<const File &>(*bibtexFile)) {
                        QSharedPointer<Entry> entry = element.dynamicCast<Entry>();
                        hasEntries |= publishEntry(entry);
                    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            addToken(ttText, locAtTop);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &embeddedFile : const_cast<const QStringList &>(m_embeddedFileList)) {
                const QStringList param = embeddedFile.split(QStringLiteral("|"));
                QFile file(param[1]);
                if (file.exists())
                    ts << "\\embedfile[desc={" << param[0] << "}";
                ts << ",filespec={" << param[2] << "}";
                if (param[2].endsWith(KBibTeX::extensionBibTeX))
                    ts << ",mimetype={text/x-bibtex}";
                else if (param[2].endsWith(KBibTeX::extensionPDF))
                    ts << ",mimetype={application/pdf}";
                ts << "]{" << param[1] << "}" << endl;
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            addToken(ttPageNumber, locAtTop);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (SettingsAbstractWidget *settingsWidget : const_cast<const QSet<SettingsAbstractWidget *> &>(settingWidgets)) {
            settingsWidget->saveState();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &embeddedFile : const_cast<const QStringList &>(m_embeddedFileList)) {
                const QStringList param = embeddedFile.split(QStringLiteral("|"));
                QFile file(param[1]);
                if (file.exists())
                    ts << "\\embedfile[desc={" << param[0] << "}";
                ts << ",filespec={" << param[2] << "}";
                if (param[2].endsWith(KBibTeX::extensionBibTeX))
                    ts << ",mimetype={text/x-bibtex}";
                else if (param[2].endsWith(KBibTeX::extensionPDF))
                    ts << ",mimetype={application/pdf}";
#if QT_VERSION >= 0x050e00
                ts << "]{" << param[1] << "}" << Qt::endl;
#else // QT_VERSION < 0x050e00
                ts << "]{" << param[1] << "}" << endl;
#endif // QT_VERSION >= 0x050e00
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &backslashSymbol : EncoderXMLPrivate::backslashSymbols) {
        result.replace(backslashSymbol, backslashSymbol[1]);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const HiddenTabInfo &hti : const_cast<const QSet<HiddenTabInfo> &>(m_hiddenTabInfo)) {
        if (hti.widget == page) {
            int pos = showTab(hti, index);
            setTabText(pos, label);
            return pos;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QChar &encoderLaTeXProtectedTextOnlySymbol : encoderLaTeXProtectedTextOnlySymbols)
                    if (encoderLaTeXProtectedTextOnlySymbol == c) {
                        output.append(QLatin1Char('\\')).append(c);
                        found = true;
                        break;
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const HiddenTabInfo &hti : const_cast<const QSet<HiddenTabInfo> &>(d->hiddenTabInfo)) {
        if (hti.widget == page) {
            index = d->showTab(hti, index);
            setTabIcon(index, icon);
            setTabText(index, label);
            return index;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DotlessIJCharacter &dotlessIJCharacter : dotlessIJCharacters)
                if ((dotlessIJCharacter.direction & DirectionUnicodeToCommand) && c.unicode() == dotlessIJCharacter.unicode) {
                    // FIXME Find a better solution, as the curly brackets are unnecessary in some situations
                    // e.g. '{\'\i}{\'\i}' should better be '{\'\i\'\i}'
                    output.append(QString(QStringLiteral("{\\%1\\%2}")).arg(dotlessIJCharacter.modifier, dotlessIJCharacter.letter));
                    found = true;
                    break;
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &titleChunk : titleChunks) {
            queryString += QString(QStringLiteral(" title:%1")).arg(EncoderLaTeX::instance().convertToPlainAscii(titleChunk));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : urlList) {
                v.append(QSharedPointer<VerbatimText>(new VerbatimText(url.url(QUrl::PreferLocalFile))));
            }
```

#### AUTO 


```{c}
const auto firefoxVersionMinor = QRandomGenerator::global()->bounded(0, 2);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QChar &invalidIdCharacter : invalidIdCharacters)
        if (id.contains(invalidIdCharacter)) {
            qCWarning(LOG_KBIBTEX_IO) << "Entry id" << id << "near line" << m_lineNo << "contains invalid character" << invalidIdCharacter;
            emit message(MessageSeverity::Error, QString(QStringLiteral("Entry id '%1' near line %2 contains invalid character '%3'")).arg(id).arg(m_lineNo).arg(invalidIdCharacter));
            return nullptr;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&gotErrors](const FileImporter::MessageSeverity messageSeverity, const QString &messageText) {
        gotErrors |= messageSeverity >= FileImporter::SeverityError;
        Q_UNUSED(messageText);
        //qDebug()<<"FileImporterBibTeX issues message during 'partialBibTeXInput' test: "<<messageText;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : selectedSet) {
        if (index.column() != 0) continue; ///< consider only column-0 indices to avoid duplicate elements
        m_selection.append(elementAt(index));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const MathCommand &mathCommand : mathCommands) {
                                if (mathCommand.command == alpha) {
                                    output.append(QChar(mathCommand.unicode));
                                    found = true;
                                    break;
                                }
                            }
```

#### LAMBDA EXPRESSION 


```{c}
[this, action]() {
        if (action->isChecked())
            d->enableManualColumnSizing(BasicFileView::Private::ColumnSizingOrigin::FromCurrentLayout);
        else
            d->enableAutomaticBalancing();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const int exitCode, const QProcess::ExitStatus exitStatus) {
        if (exitCode != 0 || exitStatus != QProcess::NormalExit)
            KMessageBox::error(d->parentWidget, i18n("Failed to run 'kbuildsycoca5' to update mime type associations.\n\nThe system may not know how to use KBibTeX to open bibliography files."), i18n("Failed to run 'kbuildsycoca5'"));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &extension : documentFileExtensions) {
                const QFileInfo fi(directory + QDir::separator() + entry->id() + extension);
                if (fi.exists()) {
                    const QUrl url = QUrl::fromLocalFile(fi.canonicalFilePath());
                    if (!result.contains(url))
                        result << url;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SingleFieldLayout &sfl : const_cast<const QList<SingleFieldLayout> &>(etl->singleFieldLayouts)) {
        LabeledFieldInput *labeledFieldInput = new LabeledFieldInput;

        /// create an editing widget for this field
        const FieldDescription &fd = BibTeXFields::instance().find(sfl.bibtexLabel);
        labeledFieldInput->fieldInput = new FieldInput(sfl.fieldInputLayout, fd.preferredTypeFlag, fd.typeFlags, this);
        labeledFieldInput->fieldInput->setFieldKey(sfl.bibtexLabel);
        bibtexKeyToWidget.insert(sfl.bibtexLabel, labeledFieldInput->fieldInput);
        connect(labeledFieldInput->fieldInput, &FieldInput::modified, this, &EntryConfiguredWidget::gotModified);

        /// memorize if field input should grow vertically (e.g. is a list)
        labeledFieldInput->isVerticallyMinimumExpaning = sfl.fieldInputLayout == KBibTeX::MultiLine || sfl.fieldInputLayout == KBibTeX::List || sfl.fieldInputLayout == KBibTeX::PersonList || sfl.fieldInputLayout == KBibTeX::KeywordList;

        /// create a label next to the editing widget
        labeledFieldInput->label = new QLabel(QString(QStringLiteral("%1:")).arg(sfl.uiLabel), this);
        labeledFieldInput->label->setBuddy(labeledFieldInput->fieldInput->buddy());
        /// align label's text vertically to match field input
        const Qt::Alignment horizontalAlignment = static_cast<Qt::Alignment>(labeledFieldInput->label->style()->styleHint(QStyle::SH_FormLayoutLabelAlignment)) & Qt::AlignHorizontal_Mask;
        labeledFieldInput->label->setAlignment(horizontalAlignment | (labeledFieldInput->isVerticallyMinimumExpaning ? Qt::AlignTop : Qt::AlignVCenter));

        listOfLabeledFieldInput[i] = labeledFieldInput;

        ++i;
    }
```

#### AUTO 


```{c}
const auto chromeVersionMajor = QRandomGenerator::global()->bounded(77, 85);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : urlList) {
            if (!url.isLocalFile()) continue;
            const QString filename = url.toLocalFile();
            const QString basename = QFileInfo(filename).fileName();
            m_embeddedFileList.append(QString(QStringLiteral("%1|%2|%3")).arg(title, filename, basename));
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, fieldLineEdit]() {
        downloadAndSaveLocally(QUrl::fromUserInput(fieldLineEdit->text()));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &keyword : keywords) {
                result.append(QSharedPointer<Keyword>(new Keyword(keyword)));
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &valueItem : value) {
                bool gotMonthFromThisValueItem = false;
                const QString textualRepresentation = PlainTextValue::text(valueItem);
                for (int i = 0; asInt < 0 && i < 12; i++)
                    if (textualRepresentation == KBibTeX::MonthsTriple[ i ]) {
                        triple = KBibTeX::MonthsTriple[ i ];
                        asInt = i + 1;
                        gotMonthFromThisValueItem = true;
                    }
                if (gotMonthFromThisValueItem)
                    content.append(QStringLiteral("<text>") + KBibTeX::Months[asInt - 1] + QStringLiteral("</text>"));
                else
                    content.append(valueItemToXML(valueItem));
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &valueItem : value) {
        if (!isFirst)
            result.append(' ');
        isFirst = false;

        QSharedPointer<const PlainText> plainText = valueItem.dynamicCast<const PlainText>();
        if (!plainText.isNull())
            result.append("<text>" +  cleanXML(EncoderXML::instance().encode(PlainTextValue::text(valueItem), Encoder::TargetEncodingUTF8)) + "</text>");
        else {
            QSharedPointer<const Person> p = valueItem.dynamicCast<const Person>();
            if (!p.isNull()) {
                result.append("<person>");
                if (!p->firstName().isEmpty())
                    result.append("<firstname>" +  cleanXML(EncoderXML::instance().encode(p->firstName(), Encoder::TargetEncodingUTF8)) + "</firstname>");
                if (!p->lastName().isEmpty())
                    result.append("<lastname>" +  cleanXML(EncoderXML::instance().encode(p->lastName(), Encoder::TargetEncodingUTF8)) + "</lastname>");
                if (!p->suffix().isEmpty())
                    result.append("<suffix>" +  cleanXML(EncoderXML::instance().encode(p->suffix(), Encoder::TargetEncodingUTF8)) + "</suffix>");
                result.append("</person>");
            }
            // TODO: Other data types
            else
                result.append("<text>" + cleanXML(EncoderXML::instance().encode(PlainTextValue::text(valueItem), Encoder::TargetEncodingUTF8)) + "</text>");
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &xAuthorValueItem : xAuthorValue) {
            const QSharedPointer<const PlainText> pt = xAuthorValueItem.dynamicCast<const PlainText>();
            if (!pt.isNull()) {
                const QList<QSharedPointer<Person> > personList = FileImporterBibTeX::splitNames(pt->text());
                for (const auto &person : personList)
                    authorValue << person;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const HiddenTabInfo &hti : const_cast<const QSet<HiddenTabInfo> &>(m_hiddenTabInfo)) {
        if (hti.widget == page) {
            int pos = showTab(hti);
            setTabIcon(pos, icon);
            setTabText(pos, label);
            return pos;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &ed : BibTeXEntries::instance())
        entryType->addItem(ed.label, ed.upperCamelCase);
```

#### RANGE FOR STATEMENT 


```{c}
for (TokenWidget *widget : const_cast<const QList<TokenWidget *> &>(widgetList))
            result << widget->toString();
```

#### LAMBDA EXPRESSION 


```{c}
[this, le]() {
            const bool gotModified = goDownFieldLineEdit(le);
            if (gotModified) {
                /// Instead of an 'emit' ...
                QMetaObject::invokeMethod(p, "modified", Qt::DirectConnection, QGenericReturnArgument());
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &token : tokenList) {
        QString text;
        if (token[0] == 'a' || token[0] == 'A' || token[0] == 'z') {
            struct IdSuggestionTokenInfo info = evalToken(token.mid(1));
            if (token[0] == 'a')
                info.startWord = info.endWord = 0;
            else if (token[0] == 'z') {
                info.startWord = 1;
                info.endWord = std::numeric_limits<int>::max();
            }
            text = formatAuthorRange(info.startWord, info.endWord, info.lastWord);

            if (info.len > 0 && info.len < std::numeric_limits<int>::max()) text.append(i18np(", but only first letter of each last name", ", but only first %1 letters of each last name", info.len));

            switch (info.caseChange) {
            case IdSuggestions::CaseChange::ToUpper:
                text.append(i18n(", in upper case"));
                break;
            case IdSuggestions::CaseChange::ToLower:
                text.append(i18n(", in lower case"));
                break;
            case IdSuggestions::CaseChange::ToCamelCase:
                text.append(i18n(", in CamelCase"));
                break;
            case IdSuggestions::CaseChange::None:
                break;
            }

            if (!info.inBetween.isEmpty()) text.append(i18n(", with '%1' in between", info.inBetween));
        }
        else if (token[0] == 'y')
            text.append(i18n("Year (2 digits)"));
        else if (token[0] == 'Y')
            text.append(i18n("Year (4 digits)"));
        else if (token[0] == 't' || token[0] == 'T') {
            struct IdSuggestionTokenInfo info = evalToken(token.mid(1));
            text.append(i18n("Title"));
            if (info.startWord == 0 && info.endWord < std::numeric_limits<int>::max())
                text.append(i18np(", but only the first word", ", but only first %1 words", info.endWord + 1));
            else if (info.startWord > 0 && info.endWord == std::numeric_limits<int>::max())
                text.append(i18n(", but only starting from word %1", info.startWord + 1));
            else if (info.startWord > 0 && info.endWord < std::numeric_limits<int>::max())
                text.append(i18n(", but only from word %1 to word %2", info.startWord + 1, info.endWord + 1));
            if (info.len > 0 && info.len < std::numeric_limits<int>::max())
                text.append(i18np(", but only first letter of each word", ", but only first %1 letters of each word", info.len));

            switch (info.caseChange) {
            case IdSuggestions::CaseChange::ToUpper:
                text.append(i18n(", in upper case"));
                break;
            case IdSuggestions::CaseChange::ToLower:
                text.append(i18n(", in lower case"));
                break;
            case IdSuggestions::CaseChange::ToCamelCase:
                text.append(i18n(", in CamelCase"));
                break;
            case IdSuggestions::CaseChange::None:
                break;
            }

            if (!info.inBetween.isEmpty()) text.append(i18n(", with '%1' in between", info.inBetween));
            if (token[0] == 'T') text.append(i18n(", small words removed"));
        }
        else if (token[0] == 'j') {
            struct IdSuggestionTokenInfo info = evalToken(token.mid(1));
            text.append(i18n("Journal"));
            if (info.len > 0 && info.len < std::numeric_limits<int>::max())
                text.append(i18np(", but only first letter of each word", ", but only first %1 letters of each word", info.len));
            switch (info.caseChange) {
            case IdSuggestions::CaseChange::ToUpper:
                text.append(i18n(", in upper case"));
                break;
            case IdSuggestions::CaseChange::ToLower:
                text.append(i18n(", in lower case"));
                break;
            case IdSuggestions::CaseChange::ToCamelCase:
                text.append(i18n(", in CamelCase"));
                break;
            case IdSuggestions::CaseChange::None:
                break;
            }
        } else if (token[0] == 'e') {
            struct IdSuggestionTokenInfo info = evalToken(token.mid(1));
            text.append(i18n("Type"));
            if (info.len > 0 && info.len < std::numeric_limits<int>::max())
                text.append(i18np(", but only first letter of each word", ", but only first %1 letters of each word", info.len));
            switch (info.caseChange) {
            case IdSuggestions::CaseChange::ToUpper:
                text.append(i18n(", in upper case"));
                break;
            case IdSuggestions::CaseChange::ToLower:
                text.append(i18n(", in lower case"));
                break;
            case IdSuggestions::CaseChange::ToCamelCase:
                text.append(i18n(", in CamelCase"));
                break;
            default:
                break;
            }
        } else if (token[0] == 'v') {
            text.append(i18n("Volume"));
        } else if (token[0] == 'p') {
            text.append(i18n("First page number"));
        } else if (token[0] == '"')
            text.append(i18n("Text: '%1'", token.mid(1)));
        else
            text.append("?");

        result.append(text);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[ = ]() {
            emit backoffModeEnd();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &mimeType : d->textBasedMimeTypes) {
        d->setKBibTeXforMimeType(mimeType, true);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &backslashSymbol : EncoderXMLPrivate::backslashSymbols) {
        int p = -1;
        while ((p = result.indexOf(backslashSymbol[1], p + 1)) >= 0) {
            if (p == 0 || result[p - 1] != QLatin1Char('\\')) {
                /// replace only symbols which have no backslash on their right
                result = result.left(p) + QLatin1Char('\\') + result.mid(p);
                ++p;
            }
        }
    }
```

#### AUTO 


```{c}
const auto chromeVersionMajor = randomGeneratorGlobalBounded(77, 85);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : list) {
            const QModelIndex mappedIndex = sfbfm->mapToSource(index);
            /// Selection may span over multiple columns;
            /// to avoid duplicate assignments, consider only column 1
            if (mappedIndex.column() == 1) {
                const int row = mappedIndex.row();
                QSharedPointer<Entry> entry = model->element(row).dynamicCast<Entry>();
                if (!entry.isNull()) {
                    /// Clear old color entry
                    bool modifying = entry->remove(Entry::ftColor) > 0;
                    if (colorString != QStringLiteral("#000000")) { ///< black is a special color that means "no color"
                        /// Only if valid color was selected, set this color
                        Value v;
                        v.append(QSharedPointer<VerbatimText>(new VerbatimText(colorString)));
                        entry->insert(Entry::ftColor, v);
                        modifying = true;
                    }
                    if (modifying)
                        model->elementChanged(row);
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &element : const_cast<const File &>(*bibTeXFile)) {
        QSharedPointer<Entry> entry = element.dynamicCast<Entry>();
        if (!entry.isNull()) {
            ++countEntries;
            lastEntryId = entry->id();

            Value authors = entry->value(Entry::ftAuthor);
            if (!authors.isEmpty()) {
                ValueItem *vi = authors.last().data();
                Person *p = dynamic_cast<Person *>(vi);
                if (p != nullptr) {
                    lastEntryLastAuthorLastName = p->lastName();
                } else
                    lastEntryLastAuthorLastName.clear();
            } else {
                Value editors = entry->value(Entry::ftEditor);
                if (!editors.isEmpty()) {
                    ValueItem *vi = editors.last().data();
                    Person *p = dynamic_cast<Person *>(vi);
                    if (p != nullptr) {
                        lastEntryLastAuthorLastName = p->lastName();
                    } else
                        lastEntryLastAuthorLastName.clear();
                } else
                    lastEntryLastAuthorLastName.clear();
            }

            if (!lastEntryLastAuthorLastName.isEmpty()) {
                if (lastEntryLastAuthorLastName[0] == QLatin1Char('{') && lastEntryLastAuthorLastName[lastEntryLastAuthorLastName.length() - 1] == QLatin1Char('}'))
                    lastEntryLastAuthorLastName = lastEntryLastAuthorLastName.mid(1, lastEntryLastAuthorLastName.length() - 2);
                lastAuthorsList << lastEntryLastAuthorLastName;
            }

            for (int index = 1; index < 100; ++index) {
                const QString field = index == 1 ? Entry::ftUrl : QString(QStringLiteral("%1%2")).arg(Entry::ftUrl).arg(index);
                const Value v = entry->value(field);
                for (const QSharedPointer<ValueItem> &vi : v) {
                    filesUrlsDoiList << PlainTextValue::text(vi);
                }
                if (v.isEmpty() && index > 10) break;
            }
            for (int index = 1; index < 100; ++index) {
                const QString field = index == 1 ? Entry::ftDOI : QString(QStringLiteral("%1%2")).arg(Entry::ftDOI).arg(index);
                const Value v = entry->value(field);
                for (const QSharedPointer<ValueItem> &vi : v) {
                    filesUrlsDoiList << PlainTextValue::text(vi);
                }
                if (v.isEmpty() && index > 10) break;
            }
            for (int index = 1; index < 100; ++index) {
                const QString field = index == 1 ? Entry::ftLocalFile : QString(QStringLiteral("%1%2")).arg(Entry::ftLocalFile).arg(index);
                const Value v = entry->value(field);
                for (const QSharedPointer<ValueItem> &vi : v) {
                    filesUrlsDoiList << PlainTextValue::text(vi);
                }
                if (v.isEmpty() && index > 10) break;
            }
            for (int index = 1; index < 100; ++index) {
                const QString field = index == 1 ? Entry::ftLocalFile : QString(QStringLiteral("%1%2")).arg(Entry::ftFile).arg(index);
                const Value v = entry->value(field);
                for (const QSharedPointer<ValueItem> &vi : v) {
                    filesUrlsDoiList << PlainTextValue::text(vi);
                }
                if (v.isEmpty() && index > 10) break;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &entry : el)
        if (isEntryChecked(entry)) {

            /// cover entry type
            Value v;
            v.append(QSharedPointer<VerbatimText>(new VerbatimText(entry->type())));
            insertKeyValueToValueMap(QStringLiteral("^type"), v, entry->type(), Qt::CaseInsensitive /** entry types shall be compared case insensitive */);

            /// cover entry id
            v.clear();
            v.append(QSharedPointer<VerbatimText>(new VerbatimText(entry->id())));
            insertKeyValueToValueMap(QStringLiteral("^id"), v, entry->id());

            /// go through each and every field of this entry
            for (Entry::ConstIterator fieldIt = entry->constBegin(); fieldIt != entry->constEnd(); ++fieldIt) {
                /// store both field name and value for later reference
                const QString fieldName = fieldIt.key().toLower();
                const Value fieldValue = fieldIt.value();

                if (fieldName == Entry::ftKeywords || fieldName == Entry::ftUrl) {
                    for (const auto &vi : fieldValue) {
                        const QString text = PlainTextValue::text(*vi);
                        Value v;
                        v << vi;
                        insertKeyValueToValueMap(fieldName, v, text);
                    }
                } else {
                    const QString fieldValueText = PlainTextValue::text(fieldValue);
                    insertKeyValueToValueMap(fieldName, fieldValue, fieldValueText);
                }
            }
        }
```

#### AUTO 


```{c}
const auto len = static_cast<int>(encodedposlen & 31);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &value : form.values(key))
                body += key + QLatin1Char('=') + QString(QUrl::toPercentEncoding(value));
```

#### AUTO 


```{c}
const auto chromeVersionBuild = QRandomGenerator::global()->bounded(3793, 8973);
```

#### LAMBDA EXPRESSION 


```{c}
[&gotErrors](const FileImporter::MessageSeverity messageSeverity, const QString & messageText) {
        gotErrors |= messageSeverity >= FileImporter::MessageSeverity::Error;
        Q_UNUSED(messageText)
        //qCDebug(LOG_KBIBTEX_TEST)<<"FileImporterBibTeX issues message during 'partialBibTeXInput' test: "<<messageText;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Value &v : const_cast<const QVector<Value> &>(alternatives))
            if (PlainTextValue::text(v) == fieldValueText) {
                alreadyContained = true;
                break;
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &expectedUrl : const_cast<const QSet<QUrl> &>(expectedUrls))
        QCOMPARE(extractedUrls.contains(expectedUrl), true);
```

#### RANGE FOR STATEMENT 


```{c}
for (const TestCase &testCase : testCases) {
        for (const QString &encoding : testCase.encodingsToBeTested) {
            const QString testLabel = QString(QStringLiteral("Round-trip of '%1' encoded in '%2'")).arg(testCase.label).arg(encoding);
            QTest::newRow(testLabel.toLatin1().constData()) << testCase.bibliography << encoding;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &token : tokenList) {
            TokenWidget *tokenWidget = nullptr;

            if (token[0] == 'a' || token[0] == 'A' || token[0] == 'z') {
                struct IdSuggestions::IdSuggestionTokenInfo info = p->evalToken(token.mid(1));
                /// Support deprecated 'a' and 'z' cases
                if (token[0] == 'a')
                    info.startWord = info.endWord = 0;
                else if (token[0] == 'z') {
                    info.startWord = 1;
                    info.endWord = std::numeric_limits<int>::max();
                }
                tokenWidget = new AuthorWidget(info, p, container);
                widgetList << tokenWidget;
                containerLayout->insertWidget(containerLayout->count() - 2, tokenWidget, 1);
            } else if (token[0] == 'y') {
                tokenWidget = new YearWidget(2, p, container);
                widgetList << tokenWidget;
                containerLayout->insertWidget(containerLayout->count() - 2, tokenWidget, 1);
            } else if (token[0] == 'Y') {
                tokenWidget = new YearWidget(4, p, container);
                widgetList << tokenWidget;
                containerLayout->insertWidget(containerLayout->count() - 2, tokenWidget, 1);
            } else if (token[0] == 't' || token[0] == 'T') {
                struct IdSuggestions::IdSuggestionTokenInfo info = p->evalToken(token.mid(1));
                tokenWidget = new TitleWidget(info, token[0].isUpper(), p, container);
                widgetList << tokenWidget;
                containerLayout->insertWidget(containerLayout->count() - 2, tokenWidget, 1);
            } else if (token[0] == 'j' || token[0] == 'J') {
                struct IdSuggestions::IdSuggestionTokenInfo info = p->evalToken(token.mid(1));
                tokenWidget = new JournalWidget(info, token[0].isUpper(), p, container);
                widgetList << tokenWidget;
                containerLayout->insertWidget(containerLayout->count() - 2, tokenWidget, 1);
            } else if (token[0] == 'e') {
                struct IdSuggestions::IdSuggestionTokenInfo info = p->evalToken(token.mid(1));
                tokenWidget = new TypeWidget(info, p, container);
                widgetList << tokenWidget;
                containerLayout->insertWidget(containerLayout->count() - 2, tokenWidget, 1);
            } else if (token[0] == 'v') {
                tokenWidget = new VolumeWidget(p, container);
                widgetList << tokenWidget;
                containerLayout->insertWidget(containerLayout->count() - 2, tokenWidget, 1);
            } else if (token[0] == 'p') {
                tokenWidget = new PageNumberWidget(p, container);
                widgetList << tokenWidget;
                containerLayout->insertWidget(containerLayout->count() - 2, tokenWidget, 1);
            } else if (token[0] == '"') {
                tokenWidget = new TextWidget(token.mid(1), p, container);
                widgetList << tokenWidget;
                containerLayout->insertWidget(containerLayout->count() - 2, tokenWidget, 1);
            }

            if (tokenWidget != nullptr)
                addManagementButtons(tokenWidget);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &valueItem : value) {
            QSharedPointer<const MacroKey> macroKey = valueItem.dynamicCast<const MacroKey>();
            if (!macroKey.isNull()) {
                if (isOpen) result.append(stringCloseDelimiter);
                isOpen = false;
                if (!result.isEmpty()) result.append(QStringLiteral(" # "));
                result.append(macroKey->text());
                prev = macroKey;
            } else {
                QSharedPointer<const PlainText> plainText = valueItem.dynamicCast<const PlainText>();
                if (!plainText.isNull()) {
                    QString textBody = EncoderLaTeX::instance().encode(plainText->text(), targetEncoding);
                    if (!isOpen) {
                        if (!result.isEmpty()) result.append(" # ");
                        result.append(stringOpenDelimiter);
                    } else if (!prev.dynamicCast<const PlainText>().isNull())
                        result.append(' ');
                    else if (!prev.dynamicCast<const Person>().isNull()) {
                        /// handle "et al." i.e. "and others"
                        result.append(" and ");
                    } else {
                        result.append(stringCloseDelimiter).append(" # ").append(stringOpenDelimiter);
                    }
                    isOpen = true;

                    if (stringOpenDelimiter == QLatin1Char('"'))
                        protectQuotationMarks(textBody);
                    result.append(textBody);
                    prev = plainText;
                } else {
                    QSharedPointer<const VerbatimText> verbatimText = valueItem.dynamicCast<const VerbatimText>();
                    if (!verbatimText.isNull()) {
                        QString textBody = verbatimText->text();
                        if (!isOpen) {
                            if (!result.isEmpty()) result.append(" # ");
                            result.append(stringOpenDelimiter);
                        } else if (!prev.dynamicCast<const VerbatimText>().isNull()) {
                            const QString keyToLower(key.toLower());
                            if (keyToLower.startsWith(Entry::ftUrl) || keyToLower.startsWith(Entry::ftLocalFile) || keyToLower.startsWith(Entry::ftFile) || keyToLower.startsWith(Entry::ftDOI))
                                /// Filenames and alike have be separated by a semicolon,
                                /// as a plain comma may be part of the filename or URL
                                result.append(QStringLiteral("; "));
                            else
                                result.append(' ');
                        } else {
                            result.append(stringCloseDelimiter).append(" # ").append(stringOpenDelimiter);
                        }
                        isOpen = true;

                        if (stringOpenDelimiter == QLatin1Char('"'))
                            protectQuotationMarks(textBody);
                        result.append(textBody);
                        prev = verbatimText;
                    } else {
                        QSharedPointer<const Person> person = valueItem.dynamicCast<const Person>();
                        if (!person.isNull()) {
                            QString firstName = person->firstName();
                            if (!firstName.isEmpty() && requiresPersonQuoting(firstName, false))
                                firstName = firstName.prepend("{").append("}");

                            QString lastName = person->lastName();
                            if (!lastName.isEmpty() && requiresPersonQuoting(lastName, true))
                                lastName = lastName.prepend("{").append("}");

                            QString suffix = person->suffix();

                            /// Fall back and enforce comma-based name formatting
                            /// if name contains a suffix like "Jr."
                            /// Otherwise name could not be parsed again reliable
                            const QString pnf = suffix.isEmpty() ? personNameFormatting : Preferences::personNameFormatLastFirst;
                            QString thisName = EncoderLaTeX::instance().encode(Person::transcribePersonName(pnf, firstName, lastName, suffix), targetEncoding);

                            if (!isOpen) {
                                if (!result.isEmpty()) result.append(" # ");
                                result.append(stringOpenDelimiter);
                            } else if (!prev.dynamicCast<const Person>().isNull())
                                result.append(" and ");
                            else {
                                result.append(stringCloseDelimiter).append(" # ").append(stringOpenDelimiter);
                            }
                            isOpen = true;

                            if (stringOpenDelimiter == QLatin1Char('"'))
                                protectQuotationMarks(thisName);
                            result.append(thisName);
                            prev = person;
                        } else {
                            QSharedPointer<const Keyword> keyword = valueItem.dynamicCast<const Keyword>();
                            if (!keyword.isNull()) {
                                QString textBody = EncoderLaTeX::instance().encode(keyword->text(), targetEncoding);
                                if (!isOpen) {
                                    if (!result.isEmpty()) result.append(" # ");
                                    result.append(stringOpenDelimiter);
                                } else if (!prev.dynamicCast<const Keyword>().isNull())
                                    result.append(listSeparator);
                                else {
                                    result.append(stringCloseDelimiter).append(" # ").append(stringOpenDelimiter);
                                }
                                isOpen = true;

                                if (stringOpenDelimiter == QLatin1Char('"'))
                                    protectQuotationMarks(textBody);
                                result.append(textBody);
                                prev = keyword;
                            }
                        }
                    }
                }
            }
            prev = valueItem;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (NotificationListener *listener : const_cast<const QSet<NotificationListener *> &>(set))
            listener->notificationEvent(eventId);
```

#### RANGE FOR STATEMENT 


```{c}
for (const DotlessIJCharacter &dotlessIJCharacter : dotlessIJCharacters)
                    if ((dotlessIJCharacter.direction & DirectionCommandToUnicode) && dotlessIJCharacter.letter == input[i + 4 + skipSpaces] && dotlessIJCharacter.modifier == input[i + 1]) {
                        output.append(QChar(dotlessIJCharacter.unicode));
                        found = true;
                        break;
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : mil) {
        QSharedPointer<Entry> entry = model->element(d->partWidget->fileView()->sortFilterProxyModel()->mapToSource(index).row()).dynamicCast<Entry>();
        if (!entry.isNull()) {
            static IdSuggestions idSuggestions;
            bool success = idSuggestions.applyDefaultFormatId(*entry.data());
            documentModified |= success;
            if (!success) {
                KMessageBox::information(widget(), i18n("Cannot apply default formatting for entry ids: No default format specified."), i18n("Cannot Apply Default Formatting"));
                break;
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            KRun::runUrl(QUrl(lineEditAuthorizationUrl->text()), QStringLiteral("text/html"), p, KRun::RunFlags());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const EncoderLaTeXCharacterCommand &encoderLaTeXCharacterCommand : encoderLaTeXCharacterCommands) {
                            if (encoderLaTeXCharacterCommand.command == alpha) {
                                output.append(QChar(encoderLaTeXCharacterCommand.unicode));
                                found = true;
                                break;
                            }
                        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const MathCommand &mathCommand : mathCommands)
                    if ((mathCommand.direction & DirectionUnicodeToCommand) && mathCommand.unicode == c.unicode()) {
                        output.append(QString(QStringLiteral("\\%1")).arg(mathCommand.command));
                        const QChar peekAhead = i < len - 1 ? input[i + 1] : QChar();
                        if (peekAhead != QLatin1Char('\\') && peekAhead != QLatin1Char('}') && peekAhead != QLatin1Char('$')) {
                            // Between current command and following character a separator is necessary
                            // FIXME This peek-ahead won't do its job properly, as it is not yet known
                            // whether the next character will be kept as-is or rewritten to, for example, a LaTeX command
                            // Example: if the complete input string is '$��$' and the current variable 'c' comes from
                            // the first '�', it will assume that curly brackets are necessary, thus the final output
                            // becomes '$\mu{}\mu$ despite that '$\mu\mu$' would have been a better output.
                            output.append(QStringLiteral("{}"));
                        }
                        found = true;
                        break;
                    }
```

#### AUTO 


```{c}
const auto formatIdList = IdSuggestions::formatIdList(*crossrefResolvedEntry.data());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &etl : EntryLayout::instance()) {
            EntryConfiguredWidget *widget = new EntryConfiguredWidget(etl, tab);
            connect(widget, &ElementWidget::modified, p, &ElementEditor::childModified);
            connect(widget, &EntryConfiguredWidget::requestingTabChange, p, &ElementEditor::switchToTab);
            widgets << widget;
            if (previousWidget == nullptr)
                previousWidget = widget; ///< memorize the first tab
            int index = tab->addTab(widget, widget->icon(), widget->label());
            tab->hideTab(index);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (FieldLineEdit *fieldLineEdit : const_cast<const QList<FieldLineEdit *> &>(d->lineEditList))
        fieldLineEdit->setReadOnly(isReadOnly);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QJsonValue &resultValue : resultArray) {
                            if (resultValue.isObject()) {
                                Entry *entry = d->entryFromJsonObject(resultValue.toObject());
                                if (entry != nullptr)
                                    publishEntry(QSharedPointer<Entry>(entry));
                                else {
                                    qCWarning(LOG_KBIBTEX_NETWORKING) << "Problem with JSON data from ScienceDirect: Data could not be interpreted as a bibliographic entry";
                                    encounteredUnexpectedData = true;
                                    break;
                                }
                            } else {
                                qCWarning(LOG_KBIBTEX_NETWORKING) << "Problem with JSON data from ScienceDirect: No object found in 'results' array where expected";
                                encounteredUnexpectedData = true;
                                break;
                            }
                        }
```

#### RANGE FOR STATEMENT 


```{c}
for (OpenFileInfo *cur : list) {
            /// Fixing bug 19511: too long filenames make menu too large,
            /// therefore squeeze text if it is longer than squeezeLen.
            const int squeezeLen = 64;
            const QString squeezedShortCap = squeeze_text(cur->shortCaption(), squeezeLen);
            const QString squeezedFullCap = squeeze_text(cur->fullCaption(), squeezeLen);
            QAction *action = new QAction(QString(QStringLiteral("%1 [%2]")).arg(squeezedShortCap, squeezedFullCap), this);
            action->setData(cur->url());
            action->setIcon(QIcon::fromTheme(cur->mimeType().replace(QLatin1Char('/'), QLatin1Char('-'))));
            d->actionMenuRecentFilesMenu->addAction(action);
            connect(action, &QAction::triggered, this, &KBibTeXMainWindow::openRecentFile);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QSharedPointer<ValueItem> &valueItem : itValue) {
                        /// Check if ValueItem to process points to a person
                        const QSharedPointer<Person> person = valueItem.dynamicCast<Person>();
                        if (!person.isNull()) {
                            QSet<QString> personNameFormattingSet {Preferences::personNameFormatLastFirst, Preferences::personNameFormatFirstLast};
                            personNameFormattingSet.insert(Preferences::instance().personNameFormat());
                            /// Add person's name formatted using each of the templates assembled above
                            for (const QString &personNameFormatting : const_cast<const QSet<QString> &>(personNameFormattingSet))
                                valueSet.insert(Person::transcribePersonName(person.data(), personNameFormatting));
                        } else {
                            /// Default case: use PlainTextValue::text to translate ValueItem
                            /// to a human-readable text
                            valueSet.insert(PlainTextValue::text(*valueItem));
                        }
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &entry : const_cast<const QList<QSharedPointer<Entry> > &>(listOfEntries)) {
        QApplication::instance()->processEvents();
        if (progressDlg->wasCanceled()) {
            entryCliqueList.clear();
            break;
        }

        progressDlg->setValue(curProgress);
        emit currentProgress(curProgress);
        /// ... and find a "clique" of entries where it will match, i.e. distance is below sensitivity

        /// assume current entry will match in no clique
        bool foundClique = false;

        /// go through all existing cliques
        for (QList<EntryClique *>::Iterator cit = entryCliqueList.begin(); cit != entryCliqueList.end(); ++cit) {
            /// check distance between current entry and clique's first entry
            if (d->entryDistance(entry.data(), (*cit)->entryList().first().data()) < d->sensitivity) {
                /// if distance is below sensitivity, add current entry to clique
                foundClique = true;
                (*cit)->addEntry(entry);
                break;
            }

            QApplication::instance()->processEvents();
            if (progressDlg->wasCanceled()) {
                entryCliqueList.clear();
                break;
            }
        }

        if (!progressDlg->wasCanceled() && !foundClique) {
            /// no clique matched to current entry, so create and add new clique
            /// consisting only of the current entry
            EntryClique *newClique = new EntryClique();
            newClique->addEntry(entry);
            entryCliqueList << newClique;
        }

        curProgress += progressDelta;
        ++progressDelta;
        progressDlg->setValue(curProgress);

        emit currentProgress(curProgress);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (FieldLineEdit *fieldLineEdit : const_cast<const QList<FieldLineEdit *> &>(d->lineEditList))
        fieldLineEdit->setFieldKey(fieldKey);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            ++m_currentOnlineSearchNumFoundEntries;
        }
```

