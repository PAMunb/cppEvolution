#### RANGE FOR STATEMENT 


```{c}
for (QSlider* slider :  qAsConst(m_sliders)) {
        slider->setValue(0);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const ChannelDescription& channel : availableChannels) {
        QAction* lang = new QAction( channelActions );
        qDebug() << "the text is: \"" << channel.name() << "\" and index " << channel.index();
        lang->setCheckable( true );
        lang->setText( channel.name() );
        lang->setProperty( TheStream::CHANNEL_PROPERTY, channel.index() );
        connect( lang, SIGNAL(triggered()), this, actionSlot );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction* subAction : subs) {
            if( subAction->property( TheStream::CHANNEL_PROPERTY ).toInt() == subId ) {
                subAction->setChecked( true );
                break;
            }
            qDebug() << subAction->property( TheStream::CHANNEL_PROPERTY ).toInt() << " not checked.";
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QSlider* slider : qAsConst(m_sliders)) {
        slider->setValue( engine()->videoSetting( slider->objectName() ) );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction* audioAction : audios) {
            if( audioAction->property( TheStream::CHANNEL_PROPERTY ).toInt() == audioId ) {
                audioAction->setChecked( true );
                break;
            }
        }
```

#### AUTO 


```{c}
const auto allProtocols = KProtocolInfo::protocols();
```

#### AUTO 


```{c}
auto urls = QUrl::fromStringList(list);
```

#### AUTO 


```{c}
const auto list = config.readPathEntry( "Recent Urls", QStringList() );
```

#### AUTO 


```{c}
const auto list = configGroup->readPathEntry( "Recent Urls", QStringList() );
```

#### RANGE FOR STATEMENT 


```{c}
for (const Solid::Device& device : deviceList) {
        new SolidListItem( m_listWidget, device );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QSlider* slider : qAsConst(m_sliders)) {
            connect(slider, &QAbstractSlider::valueChanged, engine(), &VideoWindow::settingChanged);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QSlider* slider : qAsConst(m_sliders)) {
            connect( slider, SIGNAL(valueChanged(int)), engine(), SLOT(settingChanged(int)) );
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& protocol : allProtocols) {
        if (!KProtocolInfo::isHelperProtocol(protocol))
            protocols << protocol;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Solid::Device &device : deviceList) {
            const Solid::OpticalDisc* disc = device.as<const Solid::OpticalDisc>();
            if( disc ) {
                if( disc->availableContent() & ( Solid::OpticalDisc::VideoDvd | Solid::OpticalDisc::VideoCd | Solid::OpticalDisc::SuperVideoCd |  Solid::OpticalDisc::Audio ) )
                    playableDiscs << device;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const ChannelDescription& channel : availableChannels) {
        QAction* lang = new QAction( channelActions );
        qDebug() << "the text is: \"" << channel.name() << "\" and index " << channel.index();
        lang->setCheckable( true );
        lang->setText( channel.name() );
        lang->setProperty( TheStream::CHANNEL_PROPERTY, channel.index() );
        connect(lang, &QAction::triggered, this, actionSlot);
    }
```

