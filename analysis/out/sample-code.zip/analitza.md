#### AUTO 


```{c}
const auto dpr = window()->effectiveDevicePixelRatio();
```

#### AUTO 


```{c}
const auto normals = surf->normals();
```

#### AUTO 


```{c}
const auto complex = var->complexValue();
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QModelIndex& start, const QModelIndex& end)
        { m_plotter->updatePlots(QModelIndex(), start.row(), end.row()); }
```

#### AUTO 


```{c}
const auto points = curve->points();
```

#### AUTO 


```{c}
const auto r = args.constLast().toReal().complexValue();
```

#### AUTO 


```{c}
auto updateCount = [this](const QModelIndex &parent, int start, int end) { m_plotter->updatePlots(parent, start, end); };
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &p: points) {
        for (int i = 0; i<3; ++i)
            buffer.append(sin( (2.0 * M_PI * frequency * p.y()) * (points.count() / SAMPLE_RATE)));
    }
```

#### AUTO 


```{c}
const auto &p
```

#### AUTO 


```{c}
auto t = trig(i);
```

#### AUTO 


```{c}
auto it = m_itemGeometries[item];
```

#### AUTO 


```{c}
auto it = v->begin(), itEnd=v->end();
```

#### LAMBDA EXPRESSION 


```{c}
[imgGrab, &ret]() {
        ret = imgGrab->image();
    }
```

#### AUTO 


```{c}
auto it=monos.begin(), itEnd=monos.end();
```

#### AUTO 


```{c}
auto itEnd=v->constEnd();
```

#### AUTO 


```{c}
auto ret = QAbstractTableModel::roleNames();
```

#### AUTO 


```{c}
auto ret=computeStars(initial, candidate.contained(), type.contained());
```

#### AUTO 


```{c}
const auto vertices = surf->vertices();
```

#### AUTO 


```{c}
const auto a = args.constFirst().toReal().value();
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QModelIndex &parent, int start, int end) { m_plotter->updatePlots(parent, start, end); }
```

#### AUTO 


```{c}
auto i=m_scalars.constBegin();
```

#### AUTO 


```{c}
auto it1(begin());
```

#### AUTO 


```{c}
const auto offsetNormal = 3*sizeof(float)*surf->vertices().size();
```

#### AUTO 


```{c}
const auto offsetEnd = offsetNormal + 3*sizeof(float)*surf->normals().size();
```

#### AUTO 


```{c}
const auto a = args.constFirst().toReal().intValue();
```

#### AUTO 


```{c}
const auto offsetNormal = sizeof(double)*surf->vertices().size();
```

#### AUTO 


```{c}
const auto x = args.constFirst().toReal().complexValue();
```

#### AUTO 


```{c}
auto it=o->begin(), itEnd=o->end();
```

#### AUTO 


```{c}
const auto b = args.constLast().toReal().intValue();
```

#### AUTO 


```{c}
auto eigenvalueobj = !std::isnormal(imagpart) ?
                                            new Analitza::Cn(realpart)
                                        : new Analitza::Cn(realpart, imagpart);
```

#### AUTO 


```{c}
auto ret = QAbstractListModel::roleNames();
```

#### AUTO 


```{c}
auto it=v->constBegin();
```

#### AUTO 


```{c}
const auto indexes = surf->indexes();
```

#### AUTO 


```{c}
const auto offsetEnd = offsetNormal + sizeof(double)*surf->normals().size();
```

#### AUTO 


```{c}
auto it = req.create(fcolor, fname);
```

#### AUTO 


```{c}
auto px = grabImage();
```

#### AUTO 


```{c}
auto v = vert(i);
```

#### AUTO 


```{c}
auto i=begin();
```

