#### AUTO 


```{c}
const auto& path
```

#### AUTO 


```{c}
auto uiviewerInterface = qobject_cast<KUIViewerPartInterface*>(m_part);
```

#### AUTO 


```{c}
const auto activeUrl = url();
```

#### AUTO 


```{c}
const auto positionalArguments = parser.positionalArguments();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& path : libraryPaths) {
        paths.append(path + QLatin1String("/designer"));
    }
```

#### AUTO 


```{c}
auto child
```

#### AUTO 


```{c}
const auto success = loadUiFile(&buffer);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& path : libraryPaths) {
        designerPluginPaths.append(path + QLatin1String("/designer"));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto child : childWidgets) {
        child->setStyle(style);
    }
```

#### AUTO 


```{c}
auto mime = QMimeDatabase().mimeTypeForName(mimeType);
```

