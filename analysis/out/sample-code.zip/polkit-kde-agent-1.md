#### AUTO 


```{c}
const auto keys = details.keys();
```

#### RANGE FOR STATEMENT 


```{c}
for (const PolkitQt1::Identity &identity : identities) {
            // First check to see if the user is valid
            qDebug() << "User: " << identity.toString();
            const KUser user(identity.toString().remove("unix-user:"));
            if (!user.isValid()) {
                qWarning() << "User invalid: " << user.loginName();
                continue;
            }

            // Display user Full Name IF available
            QString display;
            if (!user.property(KUser::FullName).toString().isEmpty()) {
                display = i18nc("%1 is the full user name, %2 is the user login name", "%1 (%2)", user.property(KUser::FullName).toString(), user.loginName());
            } else {
                display = user.loginName();
            }

            QIcon icon;
            // load user icon face
            if (!user.faceIconPath().isEmpty()) {
                icon = QIcon(user.faceIconPath());
            } else {
                icon = QIcon::fromTheme("user-identity");
            }
            // appends the user item
            userCB->addItem(icon, display, identity.toString());

            if (user == currentUser) {
                currentUserIndex = index;
            }
            ++index;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=](bool toggled) {
        detailsWidgetContainer->setVisible(toggled);
        if (toggled) {
            detailsButton->setText(detailsButtonText + " <<");
        } else {
            detailsButton->setText(detailsButtonText + " >>");
        }
        adjustSize();
    }
```

#### AUTO 


```{c}
const auto actions = PolkitQt1::Authority::instance()->enumerateActionsSync();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &key : keys) {
        int row = gridLayout->rowCount() + 1;

        QLabel *keyLabel = new QLabel(this);
        keyLabel->setText(
            i18nc("%1 is the name of a detail about the current action "
                  "provided by polkit",
                  "%1:",
                  key));
        gridLayout->addWidget(keyLabel, row, 0);

        keyLabel->setAlignment(Qt::AlignRight);
        QFont lblFont(keyLabel->font());
        lblFont.setBold(true);
        keyLabel->setFont(lblFont);

        QLabel *valueLabel = new QLabel(this);
        valueLabel->setText(details.lookup(key));
        gridLayout->addWidget(valueLabel, row, 1);
    }
```

#### AUTO 


```{c}
auto disableSessionManagement = [](QSessionManager &sm) {
        sm.setRestartHint(QSessionManager::RestartNever);
    };
```

#### LAMBDA EXPRESSION 


```{c}
[](QSessionManager &sm) {
        sm.setRestartHint(QSessionManager::RestartNever);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const PolkitQt1::ActionDescription &desc : actions) {
        if (actionId == desc.actionId()) {
            m_actionDescription = desc;
            qDebug() << "Action description has been found";
            break;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](bool toggled) {
        detailsWidgetContainer->setVisible(toggled);
        if (toggled) {
            detailsButton->setText(detailsButtonText + " <<");
        } else {
               detailsButton->setText(detailsButtonText + " >>");
        }
        adjustSize();
    }
```

