#### RANGE FOR STATEMENT 


```{c}
for (auto& image : data.images)
    {
        QUrl imgUrl = tmpDir.resolved(QUrl::fromLocalFile(image.fileName));

        ItemUrlsMap::const_iterator it;
        const ItemUrlsMap* const ppum = &preProcessedUrlsMap;

        for (it = ppum->constBegin(); it != ppum->constEnd() && it.value().preprocessedUrl.toLocalFile() != imgUrl.toLocalFile(); ++it);

        if (it == ppum->constEnd())
        {
            errString = i18n("Unknown input file in the project file: <filename>%1</filename>", image.fileName);
            qCDebug(KIPIPLUGINS_LOG) << "Unknown input File in the PTO: " << image.fileName;
            qCDebug(KIPIPLUGINS_LOG) << "IMG: " << imgUrl.toLocalFile();
            successFlag = false;
            return;
        }

        image.fileName = it.value().previewUrl.toLocalFile();
        m_meta->load(QUrl::fromLocalFile(image.fileName));
        image.size     = m_meta->getPixelSize();
        image.optimisationParameters.clear();
    }
```

#### AUTO 


```{c}
auto* mainLayout = new QHBoxLayout;
```

#### RANGE FOR STATEMENT 


```{c}
for (QPointer<KDcraw>& rawProcess: d->rawProcesses)
    {
        if (rawProcess)
        {
            rawProcess->cancel();
        }
    }
```

#### AUTO 


```{c}
auto* authLayout = new QVBoxLayout;
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& input : d->mngr->preProcessedMap().keys())
        {
            if (input != d->mngr->preProcessedMap()[input].preprocessedUrl)
            {
                QString dir = input.toString(QUrl::RemoveFilename);
                QUrl derawUrl(dir + d->mngr->preProcessedMap()[input].preprocessedUrl.fileName());
                QFile derawFile(derawUrl.toString(QUrl::PreferLocalFile));
                rawsOk &= !derawFile.exists();
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl& url: d->mixedUrls)
        {
            args << url.toLocalFile();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& arg : args)
    {
        urlList.append(QUrl::fromLocalFile(arg));
    }
```

#### AUTO 


```{c}
auto doc = QJsonDocument::fromJson(reply->readAll()).object();
```

#### LAMBDA EXPRESSION 


```{c}
[this](quint64 bytesSent, quint64 bytesTotal) {
        setProcessedAmount(Bytes, bytesSent);
        setPercent(bytesTotal == 0 ? 0 : (bytesSent*100)/bytesTotal);
    }
```

#### AUTO 


```{c}
auto mkdirJob = KIO::mkdir(root);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl& url: urlList)
    {
        Private::Task* const t = new Private::Task;
        t->action              = IDENTIFY;
        t->urls.append(url);

        QMutexLocker lock(&d->mutex);
        d->todo << t;
        d->condVar.wakeAll();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl& file : urlList)
    {
        preProcessedMap.insert(file, ItemPreprocessedUrls());

        QObjectDecorator* t = new QObjectDecorator(new PreProcessTask(d->preprocessingTmpDir->path(),
                                                                      id++,
                                                                      preProcessedMap[file],
                                                                      file));

        connect(t, SIGNAL(started(ThreadWeaver::JobPointer)),
                this, SLOT(slotStarting(ThreadWeaver::JobPointer)));

        connect(t, SIGNAL(done(ThreadWeaver::JobPointer)),
                this, SLOT(slotStepDone(ThreadWeaver::JobPointer)));

        (*preprocessJobs) << JobPointer(t);
    }
```

#### AUTO 


```{c}
auto* userLabelLabel = new QLabel(i18n("Logged in as:"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl& url: urls)
        {
            if (url.isValid())
            {
                items.append(KFileItem(url));
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto item : pending)
    {
        ImgurAPI3Action action;
        action.type = ImgurAPI3ActionType::ANON_IMG_UPLOAD;
        action.upload.imgpath = item->url().toLocalFile();
        action.upload.title = item->Title();
        action.upload.description = item->Description();

        api->queueWork(action);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const EnfuseSettings& settings: list)
    {
        preprocessedList.clear();

        for (const QUrl& url: settings.inputUrls)
        {
            ItemPreprocessedUrls preprocessedUrls = *(map.find(url));
            preprocessedList.append(preprocessedUrls.preprocessedUrl);
        }

        d->mngr->thread()->enfuseFinal(preprocessedList, d->mngr->itemsList()[0], settings, d->mngr->enfuseBinary().path());
        if (!d->mngr->thread()->isRunning())
            d->mngr->thread()->start();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QUrl& url: d->enfuseTmpUrls)
    {
        qCDebug(KIPIPLUGINS_LOG) << "Removing temp file " << url.toLocalFile();
        QFile(url.toLocalFile()).remove();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QPointer<RawProcessor>& rawProcess: d->rawProcesses)
    {
        if (rawProcess)
        {
            rawProcess->cancel();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto item : pending)
    {
        ImgurAPI3Action action;
        action.type = ImgurAPI3ActionType::IMG_UPLOAD;
        action.upload.imgpath = item->url().toLocalFile();
        action.upload.title = item->Title();
        action.upload.description = item->Description();

        api->queueWork(action);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](QNetworkReply::NetworkError e){ qDebug() << "creation error" << e; }
```

#### AUTO 


```{c}
auto response = QJsonDocument::fromJson(reply->readAll());
```

#### AUTO 


```{c}
auto& input
```

#### RANGE FOR STATEMENT 


```{c}
for (const EnfuseSettings& settings: list)
    {
        preprocessedList.clear();

        for (const QUrl& url: settings.inputUrls)
        {
            ItemPreprocessedUrls preprocessedUrls = *(map.find(url));
            preprocessedList.append(preprocessedUrls.preprocessedUrl);
        }

        d->mngr->thread()->enfuseFinal(preprocessedList, d->mngr->itemsList()[0], settings, d->mngr->enfuseBinary().path());

        if (!d->mngr->thread()->isRunning())
            d->mngr->thread()->start();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl& inputUrl: d->preProcessedUrlsMap.keys())
        {
            qCDebug(KIPIPLUGINS_LOG) << "Pre-processed output urls map: "
                                     << inputUrl << "=>"
                                     << d->preProcessedUrlsMap[inputUrl].preprocessedUrl << ","
                                     << d->preProcessedUrlsMap[inputUrl].previewUrl << ";";
        }
```

#### AUTO 


```{c}
auto reply = m_manager.post(req, m_metadata);
```

#### RANGE FOR STATEMENT 


```{c}
for (QFuture<void>& t: tasks)
    {
        t.waitForFinished();
    }
```

#### AUTO 


```{c}
auto job = new GetCredentialsJob(id, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl& imageUrl: list)
    {
        // Check if the new item already exist in the list.
        bool found = false;

        QTreeWidgetItemIterator iter(this);

        while (*iter)
        {
            BracketStackItem* const item = dynamic_cast<BracketStackItem*>(*iter);

            if (item->url() == imageUrl)
            {
                found = true;
            }

            ++iter;
        }

        if (!found)
        {
            BracketStackItem* const item = new BracketStackItem(this);
            item->setUrl(imageUrl);
            item->setOn(true);
            urls.append(imageUrl);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& arg: args)
    {
        urlList.append(QUrl(arg));
    }
```

#### AUTO 


```{c}
auto &work = m_work_queue.front();
```

#### AUTO 


```{c}
auto reply = m_manager.post(req, data);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& image : data.images)
    {
        QUrl imgUrl = tmpDir.resolved(QUrl::fromLocalFile(image.fileName));

        ItemUrlsMap::const_iterator it;
        const ItemUrlsMap* ppum = &preProcessedUrlsMap;

        for (it = ppum->constBegin(); it != ppum->constEnd() && it.value().preprocessedUrl.toLocalFile() != imgUrl.toLocalFile(); ++it);

        if (it == ppum->constEnd())
        {
            errString = i18n("Unknown input file in the project file: <filename>%1</filename>", image.fileName);
            qCDebug(KIPIPLUGINS_LOG) << "Unknown input File in the PTO: " << image.fileName;
            qCDebug(KIPIPLUGINS_LOG) << "IMG: " << imgUrl.toLocalFile();
            successFlag = false;
            return;
        }

        image.fileName = it.value().previewUrl.toLocalFile();
        KPMetadata metaImage(image.fileName);
        image.size     = metaImage.getPixelSize();
        image.optimisationParameters.clear();
    }
```

#### AUTO 


```{c}
auto& arg
```

#### AUTO 


```{c}
auto* reply = m_reply;
```

#### AUTO 


```{c}
auto mkdirJob3 = KIO::mkdir(imagesDir);
```

#### AUTO 


```{c}
auto* multipart = new QHttpMultiPart(QHttpMultiPart::FormDataType, m_image);
```

#### AUTO 


```{c}
const auto* item = dynamic_cast<const ImgurImageListViewItem*>(listView()->topLevelItem(i));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &key : rootObject.keys()) {
            reply.insert(key, rootObject[key].toVariant());
        }
```

#### AUTO 


```{c}
auto dircopyJob = KIO::copyAs(QUrl::fromLocalFile(d->tempDir->path()), d->settings->exportUrl, KIO::Overwrite);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl& url: settings.inputUrls)
        {
            ItemPreprocessedUrls preprocessedUrls = *(map.find(url));
            preprocessedList.append(preprocessedUrls.preprocessedUrl);
        }
```

#### AUTO 


```{c}
auto& image
```

#### AUTO 


```{c}
auto* item = new ImgurImageListViewItem(listView(), *it);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl& imageUrl: list)
    {
        // Check if the new item already exist in the list.
        bool found = false;

        QTreeWidgetItemIterator iter(this);
        while (*iter)
        {
            BracketStackItem* item = dynamic_cast<BracketStackItem*>(*iter);

            if (item->url() == imageUrl)
            {
                found = true;
            }

            ++iter;
        }

        if (!found)
        {
            BracketStackItem* item = new BracketStackItem(this);
            item->setUrl(imageUrl);
            item->setOn(true);
            urls.append(imageUrl);
        }
    }
```

#### AUTO 


```{c}
auto deleteJob = KIO::del(d->settings->exportUrl);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl& file : urlList)
    {
        preProcessedMap.insert(file, ItemPreprocessedUrls());

        QObjectDecorator* t = new QObjectDecorator(new PreProcessTask(d->preprocessingTmpDir->path(),
                                                                      id++,
                                                                      preProcessedMap[file],
                                                                      file,
                                                                      rawSettings));

        connect(t, SIGNAL(started(ThreadWeaver::JobPointer)),
                this, SLOT(slotStarting(ThreadWeaver::JobPointer)));
        connect(t, SIGNAL(done(ThreadWeaver::JobPointer)),
                this, SLOT(slotStepDone(ThreadWeaver::JobPointer)));

        (*preprocessJobs) << JobPointer(t);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl& url: inUrls)
    {
        args << url.toLocalFile();
    }
```

#### AUTO 


```{c}
auto* mainWidget = new QWidget(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& arg : args)
    {
        urls.append(QUrl::fromLocalFile(arg));
    }
```

#### AUTO 


```{c}
auto *generator = QRandomGenerator::global();
```

#### AUTO 


```{c}
auto mkdirJob2 = KIO::mkdir(thumbsDir);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl& url: inUrls)
        {
            QUrl previewUrl;
            QUrl alignedUrl = QUrl::fromLocalFile(
                d->preprocessingTmpDir->path()
                + QChar::fromLatin1('/')
                + QStringLiteral("aligned")
                + QString::number(i).rightJustified(4, QChar::fromLatin1('0'))
                + QStringLiteral(".tif"));

            if (!computePreview(alignedUrl, previewUrl))
            {
                return false;
            }

            d->preProcessedUrlsMap.insert(url, ItemPreprocessedUrls(alignedUrl, previewUrl));
            i++;
        }
```

#### AUTO 


```{c}
auto dircopyJob = KIO::copy(QUrl(d->tempDir->path() + QStringLiteral("./")), d->settings->exportUrl);
```

#### AUTO 


```{c}
auto item
```

#### AUTO 


```{c}
auto* list = listView();
```

#### AUTO 


```{c}
auto data = response.object()[QLatin1String("data")].toObject();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl& url: inputUrls)
    {
        ret.append(url.fileName() + QStringLiteral(" ; "));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](QNetworkReply::NetworkError e){ qDebug() << "upload error" << e; }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl& url: selectedUrl)
    {
        ItemPreprocessedUrls preprocessedUrls = *(map.find(url));
        preprocessedList.append(preprocessedUrls.previewUrl);
    }
```

#### AUTO 


```{c}
auto copyJob = KIO::copy(files, QUrl::fromLocalFile(d->tempDir->path()), KIO::HideProgressInfo);
```

#### AUTO 


```{c}
auto msg = response.object()[QLatin1String("data")]
                       .toObject()[QLatin1String("error")]
                       .toString(QLatin1String("Could not read response."));
```

#### AUTO 


```{c}
auto deleteJob = KIO::file_delete(d->settings->exportUrl);
```

#### CONST EXPRESSION 


```{c}
static const constexpr char *IMGUR_CLIENT_ID("bd2572bce74b73d"),
                            *IMGUR_CLIENT_SECRET("300988683e99cb7b203a5889cf71de9ac891c1c1");
```

#### AUTO 


```{c}
auto dircopyJob = KIO::copy(QUrl(d->tempDir->path() + "./"), d->settings->exportUrl);
```

#### CONST EXPRESSION 


```{c}
static const constexpr char *IMGUR_CLIENT_ID("575411e9c939b2b"),
                            *IMGUR_CLIENT_SECRET("f39bbddf4052062735bdc7168b33aa795cab361f");
```

