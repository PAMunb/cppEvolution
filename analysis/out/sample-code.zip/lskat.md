#### RANGE FOR STATEMENT 


```{c}
for (const QString &name : decknames)
    {
        KCardThemeInfo v = CardDeckInfo::deckInfo(name);
        // Show only SVG files?
        if (v.svgfile.isEmpty()) continue;

        const int iconSize = 48;
        QPixmap resizedCard = v.preview.scaled(QSize(iconSize, iconSize), Qt::KeepAspectRatio, Qt::SmoothTransformation);
        QPixmap previewPixmap(iconSize, iconSize);
        previewPixmap.fill(Qt::transparent);
        QPainter p(&previewPixmap);
        p.drawPixmap((iconSize - resizedCard.width()) / 2, (iconSize-resizedCard.height()) / 2, resizedCard);
        p.end();

        QListWidgetItem *item = new QListWidgetItem(v.name, d->ui.list);
        item->setFlags(Qt::ItemIsEnabled | Qt::ItemIsSelectable);
        item->setToolTip(v.name);
        item->setData(Qt::DecorationRole, previewPixmap);
        item->setData(Qt::UserRole, v.noi18Name);
        itemSize = itemSize.expandedTo(previewPixmap.size());
    }
```

#### AUTO 


```{c}
auto *display = new DisplayTwo(mDeck, mCanvas, mTheme, ADVANCE_PERIOD, mView);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& dir : dirs) {
            const QStringList deckFolderNames = QDir(dir).entryList(QStringList() << QStringLiteral("svg*"));
            for (const QString& deck : deckFolderNames) {
                list.append(dir + '/' + deck + QStringLiteral("/index.desktop"));
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& file : fileNames) {
            themeList.append(dir + '/' + file);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &element : qAsConst(elementsToRender))
    {
        {
            QMutexLocker l(killMutex);
            if (doKill)
                return;
        }
        QImage img = QImage(size, QImage::Format_ARGB32);
        img.fill(Qt::transparent);
        QPainter p(&img);
        {
            QMutexLocker l(d->rendererMutex);
            d->renderer()->render(&p, element);
        }
        p.end();

        QString key = keyForPixmap(frontTheme, element, size);
        Q_EMIT renderingDone(key, img);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &element : qAsConst(elementsToRender))
    {
        {
            QMutexLocker l(killMutex);
            if (doKill)
                return;
        }
        QImage img = QImage(size, QImage::Format_ARGB32);
        img.fill(Qt::transparent);
        QPainter p(&img);
        {
            QMutexLocker l(d->rendererMutex);
            d->renderer()->render(&p, element);
        }
        p.end();

        QString key = keyForPixmap(frontTheme, element, size);
        emit renderingDone(key, img);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& deck : deckFolderNames) {
                list.append(dir + '/' + deck + QStringLiteral("/index.desktop"));
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &element : std::as_const(elementsToRender))
    {
        {
            QMutexLocker l(killMutex);
            if (doKill)
                return;
        }
        QImage img = QImage(size, QImage::Format_ARGB32);
        img.fill(Qt::transparent);
        QPainter p(&img);
        {
            QMutexLocker l(d->rendererMutex);
            d->renderer()->render(&p, element);
        }
        p.end();

        QString key = keyForPixmap(frontTheme, element, size);
        Q_EMIT renderingDone(key, img);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& dir : dirs) {
        const QStringList fileNames = QDir(dir).entryList(QStringList() << QStringLiteral("*.desktop"));
        for (const QString& file : fileNames) {
            themeList.append(dir + '/' + file);
        }
    }
```

