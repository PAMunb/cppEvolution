#### RANGE FOR STATEMENT 


```{c}
for (const QString & str : factors) {
        bool found = false;
        foreach(const QString & aux, m_usedFactors) {
            if (str.compare(str, aux) == 0) {
                found = true;
                m_theFactors.append(str);
                break;
            }
        }
        if (!found) {
            return false;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString & auxStr : factors) {
            m_factorsEntered.append(auxStr.toUInt());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString & str : factors) {
        bool found = false;
        for (const QString & aux : qAsConst(m_usedFactors)) {
            if (str.compare(str, aux) == 0) {
                found = true;
                m_theFactors.append(str);
                break;
            }
        }
        if (!found) {
            return false;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString & aux : qAsConst(m_usedFactors)) {
            if (str.compare(str, aux) == 0) {
                found = true;
                m_theFactors.append(str);
                break;
            }
        }
```

