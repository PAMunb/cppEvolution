#### LAMBDA EXPRESSION 


```{c}
[=](Tp::PendingOperation *op){
        if (op->isError()) {
            // FIXME: Visual feedback in GUI to user.
            qWarning() << "Could not update parameters:" << op->errorName() << op->errorMessage();
            return;
        }

        Tp::PendingStringList *psl = qobject_cast<Tp::PendingStringList*>(op);

        Q_ASSERT(psl);
        if (!psl) {
            qWarning() << "Something  weird happened";
        }

        if (psl->result().size() > 0) {
            qDebug() << "The following parameters won't be updated until reconnection: " << psl->result();
            d->reconnectRequired = true;
        }

        QVariantMap values = d->accountEditWidget->parametersSet();

        if (values.contains(QLatin1String("password"))) {
            //TODO Store the new password in sso
        } else {
            //TODO ...or remove it.
        }

        if (d->accountEditWidget->updateDisplayName()) {
            connect(d->account->setDisplayName(d->accountEditWidget->displayName()), &Tp::PendingOperation::finished,
                    this, [=](Tp::PendingOperation *op) {
                        if (op->isError()) {
                            qWarning() << "Error updating display name:" << op->errorName() << op->errorMessage();
                        }

                        onConfigureAccountFinished();
                    });
        } else {
            onConfigureAccountFinished();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](Tp::PendingOperation *op){
        if (op->isError()) {
            // FIXME: Visual feedback in GUI to user.
            qWarning() << "Could not update parameters:" << op->errorName() << op->errorMessage();
            return;
        }

        Tp::PendingStringList *psl = qobject_cast<Tp::PendingStringList*>(op);

        Q_ASSERT(psl);
        if (!psl) {
            qWarning() << "Something  weird happened";
        }

        if (psl->result().size() > 0) {
            qDebug() << "The following parameters won't be updated until reconnection: " << psl->result();
            d->reconnectRequired = true;
        }

        QVariantMap values = d->accountEditWidget->parametersSet();

        if (values.contains(QLatin1String("password"))) {
            //TODO Store the new password in sso
            quint32 accountId = d->dialog->property("accountId").toUInt();
            storePasswordInSso(accountId, values.value(QStringLiteral("password")).toString());
        } else {
            //TODO ...or remove it?
        }

        if (d->accountEditWidget->updateDisplayName()) {
            connect(d->account->setDisplayName(d->accountEditWidget->displayName()), &Tp::PendingOperation::finished,
                    this, [=](Tp::PendingOperation *op) {
                        if (op->isError()) {
                            qWarning() << "Error updating display name:" << op->errorName() << op->errorMessage();
                        }

                        onConfigureAccountFinished();
                    });
        } else {
            onConfigureAccountFinished();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](Tp::PendingOperation *op) {
                        if (op->isError()) {
                            qWarning() << "Error updating display name:" << op->errorName() << op->errorMessage();
                        }

                        onConfigureAccountFinished();
                    }
```

#### AUTO 


```{c}
auto nodeList = neededService.domDocument().elementsByTagName(QStringLiteral("group"));
```

#### LAMBDA EXPRESSION 


```{c}
[=](KJob *job){
            QString secret = qobject_cast<GetCredentialsJob*>(job)->credentialsData().value(QLatin1String("Secret")).toString();
            parameterModel->setData(index, secret, Qt::EditRole);
            job->deleteLater();
        }
```

#### AUTO 


```{c}
auto attrsMap = nodeList.at(i).attributes();
```

#### AUTO 


```{c}
auto profiles = d->profileManager->profilesForProtocol(d->protocol);
```

#### LAMBDA EXPRESSION 


```{c}
[=](KJob *job){
            QString secret = qobject_cast<GetCredentialsJob*>(job)->credentialsData().value(QLatin1String("Secret")).toString();
            parameterModel->setData(index, secret, Qt::EditRole);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=](Tp::PendingOperation *op){
        if (op->isError()) {
            // FIXME: Visual feedback in GUI to user.
            qWarning() << "Could not update parameters:" << op->errorName() << op->errorMessage();
            return;
        }

        Tp::PendingStringList *psl = qobject_cast<Tp::PendingStringList*>(op);

        Q_ASSERT(psl);
        if (!psl) {
            qWarning() << "Something  weird happened; couldn't update the parameters";
        }

        if (psl->result().size() > 0) {
            qDebug() << "The following parameters won't be updated until reconnection: " << psl->result();
            d->reconnectRequired = true;
        }

        QVariantMap values = d->accountEditWidget->parametersSet();

        if (values.contains(QLatin1String("password"))) {
            //TODO Store the new password in sso
            quint32 accountId = d->dialog->property("accountId").toUInt();
            storePasswordInSso(accountId, values.value(QStringLiteral("password")).toString());
        } else {
            //TODO ...or remove it?
        }

        if (d->accountEditWidget->updateDisplayName()) {
            connect(d->account->setDisplayName(d->accountEditWidget->displayName()), &Tp::PendingOperation::finished,
                    this, [=](Tp::PendingOperation *op) {
                        if (op->isError()) {
                            qWarning() << "Error updating display name:" << op->errorName() << op->errorMessage();
                        }

                        onConfigureAccountFinished();
                    });
        } else {
            onConfigureAccountFinished();
        }
    }
```

