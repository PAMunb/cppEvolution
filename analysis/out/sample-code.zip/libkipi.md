#### RANGE FOR STATEMENT 


```{c}
for (PluginCheckBox* const item : std::as_const(d->boxes))
    {
        item->setCheckState(0, Qt::Checked);
    }
```

#### AUTO 


```{c}
const auto toolBars = d->parent->toolBars();
```

#### RANGE FOR STATEMENT 


```{c}
for (const ImageCollection& col : list)
            names << col.name();
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction* const action : actions)
    {
        actionCollection()->removeAction(action);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (PluginCheckBox* const item : std::as_const(d->boxes))
    {
        if (!item->isHidden())
            visible++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KToolBar* const toolbar : toolBars)
        {
            toolbar->removeXMLGUIClient(d->plugin);
        }
```

#### AUTO 


```{c}
const auto imageUrls = images.images();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &mimeType : supported)
        mimeTypes.append(QString::fromLatin1(mimeType));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl& url : list)
    {
        QIcon icon(url.url());
        Q_EMIT gotThumbnail(url, icon.pixmap(256));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction* const action : pluginActions)
        {
            QString actionName(action->objectName());
            Category cat = plugin->category(action);

            if (cat == InvalidCategory)
            {
                qWarning() << "Plugin action '" << actionName << "' has invalid category!";
                continue;
            }

            if (!disabledActions.contains(actionName))
            {
                KActionCategory* category = d->kipiCategoryMap[cat];

                if (!category)
                {
                    category = new KActionCategory(categoryName(cat), d->kipipluginsActionCollection);
                    d->kipiCategoryMap.insert(cat, category);
                }

                category->addAction(actionName, qobject_cast<QAction*>(action));
            }
            else
            {
                qDebug() << "Plugin '" << actionName << "' is disabled.";
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (PluginCheckBox* const item : std::as_const(d->boxes))
    {
        if (item->contains(filter, cs))
        {
            query = true;
            item->setHidden(false);
        }
        else
        {
            item->setHidden(true);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &uiFile : std::as_const(d->uiFilesList))
    {
        d->xmlFilesCob->addItem(uiFile, uiFile);
    }
```

#### AUTO 


```{c}
const auto pluginActions = plugin->actions();
```

#### AUTO 


```{c}
const auto infos = loader->pluginList();
```

#### RANGE FOR STATEMENT 


```{c}
for (PluginCheckBox* const item : std::as_const(d->boxes))
    {
        item->setCheckState(0, Qt::Unchecked);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (PluginLoader::Info* const info : infos)
        {
            if (info)
            {
                d->boxes.append(new PluginCheckBox(info, this));
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (PluginCheckBox* const item : std::as_const(d->boxes))
    {
        if (item->checkState(0) == Qt::Checked)
            actived++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl& url : imageUrls)
            names << url.fileName();
```

#### RANGE FOR STATEMENT 


```{c}
for (PluginCheckBox* const item : std::as_const(d->boxes))
        {
            bool orig = item->m_info->shouldLoad();
            bool load = (item->checkState(0) == Qt::Checked);

            if (orig != load)
            {
                group.writeEntry(item->m_info->uname(), load);
                item->m_info->setShouldLoad(load);

                // See Bug #289779 - Plugins are not really freed / unplugged when disabled in the kipi setup dialog, always call reload()
                // to reload plugins properly when the replug() signal is send.
                item->m_info->reload();
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QDomElement element : std::as_const(disabledElements))
    {
        //qCDebug(LIBKIPI_LOG) << "Plugin action '" << element.attribute("name") << "' is disabled.";
        QDomElement parent = element.parentNode().toElement();
        parent.removeChild(element);
    }
```

