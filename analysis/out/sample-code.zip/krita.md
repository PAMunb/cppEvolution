#### AUTO 


```{c}
auto info = d->actionInfo(name);
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    KisSprayOptionProperties option;
                    option.readOptionSetting(prop->settings().data());
                    option.setSpacing(prop->value().toReal());
                    option.writeOptionSetting(prop->settings().data());
                }
```

#### AUTO 


```{c}
const auto frameData = frames->keyframeAt<KisRasterKeyframe>(i);
```

#### LAMBDA EXPRESSION 


```{c}
[dabs] (const QRect &rc) {
            Q_FOREACH (const KisRenderedDab &dab, dabs) {
                if (dab.realBounds().intersects(rc)) {
                    return true;
                }
            }
            return false;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (KoColorSetSP cs : newPaletteList) {
        m_rServer->addResource(cs);
    }
```

#### LAMBDA EXPRESSION 


```{c}
LAZY_STATIC_CATEGORY_DISPLAY_NAME("hsl")
```

#### AUTO 


```{c}
auto it = extraInitJobs.begin();
```

#### LAMBDA EXPRESSION 


```{c}
[this](KoColor color) {
        d->colorChangedCompressor.start({color.toQColor(), d->fillVariant});
    }
```

#### AUTO 


```{c}
const auto width = static_cast<size_t>(gmicImage.m_width);
```

#### LAMBDA EXPRESSION 


```{c}
[](quint8 v) {
            return v > MASK_CLEAR;
        }
```

#### AUTO 


```{c}
const auto rend = penInfoArray.rend();
```

#### RANGE FOR STATEMENT 


```{c}
for (const SwatchInfoType &info : group->infoList()) {
            infoList.append(info);
        }
```

#### AUTO 


```{c}
const auto tileWidth =
        static_cast<size_t>(it->numContiguousColumns(dev->x()));
```

#### LAMBDA EXPRESSION 


```{c}
[dialog, this]() { q->setColor(dialog->getCurrentColor()); }
```

#### LAMBDA EXPRESSION 


```{c}
[](const AuxiliaryPoint &a, const AuxiliaryPoint &b) {
            if (qFuzzyCompare(a.value, b.value)) {
                return a.macrocellPixelIndex < b.macrocellPixelIndex;
            }
            return a.value < b.value;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            Q_FOREACH (KisTransformMask *mask, transformMaskCacheHash.keys()) {
                mask->overrideStaticCacheDevice(0);
                mask->threadSafeForceStaticImageUpdate();
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&](KisNodeSP item) {
                    auto *paintLayer =
                        dynamic_cast<KisPaintLayer *>(item.data());
                    if (paintLayer) {
                        r->append(item);
                    }
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this,
                              argsAreInitialized]() mutable {
        QRect srcRect;

        if (m_d->externalSource) {
            // Start the transformation around the visible pixels of the external image
            srcRect = m_d->externalSource->exactBounds();
        } else if (m_d->selection) {
            srcRect = m_d->selection->selectedExactRect();
        } else {
            srcRect = QRect();
            Q_FOREACH (KisNodeSP node, m_d->processedNodes) {
                // group layers may have a projection of layers
                // that are locked and will not be transformed
                if (node->inherits("KisGroupLayer")) continue;

                if (const KisTransformMask *mask = dynamic_cast<const KisTransformMask*>(node.data())) {
                    srcRect |= mask->sourceDataBounds();
                } else if (const KisSelectionMask *mask = dynamic_cast<const KisSelectionMask*>(node.data())) {
                    srcRect |= mask->selection()->selectedExactRect();
                } else if (const KisTransparencyMask *mask = dynamic_cast<const KisTransparencyMask*>(node.data())) {
                    srcRect |= mask->selection()->selectedExactRect();
                } else {
                    srcRect |= node->exactBounds();
                }
            }
        }

        TransformTransactionProperties transaction(srcRect, &m_d->initialTransformArgs, m_d->rootNode, m_d->processedNodes);
        if (!argsAreInitialized) {
            m_d->initialTransformArgs = KisTransformUtils::resetArgsForMode(m_d->mode, m_d->filterId, transaction);
            m_d->initialTransformArgs.setExternalSource(m_d->externalSource);
        }
        m_d->externalSource.clear();

        m_d->previewLevelOfDetail = calculatePreferredLevelOfDetail(srcRect);

        if (m_d->previewLevelOfDetail > 0) {
            for (auto it = m_d->prevDirtyRects.begin(); it != m_d->prevDirtyRects.end(); ++it) {
                KisLodTransform t(m_d->previewLevelOfDetail);
                m_d->prevDirtyPreviewRects[it.key()] = t.map(it.value());
            }
        }

        Q_EMIT sigTransactionGenerated(transaction, m_d->initialTransformArgs, this);
    }
```

#### AUTO 


```{c}
auto name = config->getString("seexpr", "Disney_noisecolor2");
```

#### LAMBDA EXPRESSION 


```{c}
[](const KisUniformPaintOpProperty *prop) {
                    DynaOption option;
                    option.readOptionSetting(prop->settings().data());
                    return option.dyna_use_fixed_angle;
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &resname : names) {
        if (QFile(":/" + resname).exists()) {
            return resname;
        }
    }
```

#### AUTO 


```{c}
auto *profileInfo = new ICC_PROFILE_1039();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &pair : m_d->asyncRenderers) {
        if (pair.renderer->isActive()) {
            pair.renderer->cancelCurrentFrameRendering();
        }
        KIS_SAFE_ASSERT_RECOVER_NOOP(!pair.renderer->isActive());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[dx, dy] (const QRect &rc) { return rc.translated(dx, dy); }
```

#### AUTO 


```{c}
auto it = rhs.m_d->planes.constBegin();
```

#### AUTO 


```{c}
auto m_this = this;
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    DynaOption option;
                    option.readOptionSetting(prop->settings().data());
                    prop->setValue(option.dyna_mass);
                }
```

#### LAMBDA EXPRESSION 


```{c}
[eps] (const QPointF &pt1, const QPointF &pt2) {
                               return fuzzyPointCompare(pt1, pt2, eps);
                         }
```

#### AUTO 


```{c}
auto it7 = forest.insert(childEnd(it5), 7);
```

#### AUTO 


```{c}
auto errors = expression.getErrors();
```

#### LAMBDA EXPRESSION 


```{c}
[&](const FilterData &filterData) {
        if (retFilterList.contains(filterData.fullLine)) {
            debugWidgetUtils << "KoFileDialog: Duplicated filter" << filterData.fullLine;
            return;
        }
        retFilterList.append(filterData.fullLine);
        // the "simplified" version that comes to "onFilterSelect" when details are disabled
        retFilterToSuffixMap.insert(filterData.descriptionOnly, filterData.defaultSuffix);
        // "full version" that comes when details are enabled
        retFilterToSuffixMap.insert(filterData.fullLine, filterData.defaultSuffix);
    }
```

#### AUTO 


```{c}
auto tester = new QAbstractItemModelTester(m_commentModel, this);
```

#### LAMBDA EXPRESSION 


```{c}
[root] (KisNodeSP node) {
            return node != root && node->visible() && node->inherits("KisTransformMask");
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(quint8 i : m_channels){
                m_dst[i] = KoColorSpaceMaths<T>::invert(m_rgba[i]);
            }
```

#### AUTO 


```{c}
auto rowEnd = std::upper_bound(it, endIt, *it, MergePolicy::rowIsLess);
```

#### LAMBDA EXPRESSION 


```{c}
[](){}
```

#### RANGE FOR STATEMENT 


```{c}
for (const KisSwatchGroup::SwatchInfo &info : groups[groupName].infoList()) {
            lastRowGroup = qMax(lastRowGroup, info.row);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SwatchInfoType & info : group->infoList()) {
        const KoColorProfile *profile = info.swatch.color().colorSpace()->profile();
        // Only save non-builtin profiles.=
        if (!profile->fileName().isEmpty()) {
            colorSetSet.insert(info.swatch.color().colorSpace());
        }
        QDomElement swatchEle = doc.createElement("ColorSetEntry");
        swatchEle.setAttribute("name", info.swatch.name());
        swatchEle.setAttribute("id", info.swatch.id());
        swatchEle.setAttribute("spot", info.swatch.spotColor() ? "true" : "false");
        swatchEle.setAttribute("bitdepth", info.swatch.color().colorSpace()->colorDepthId().id());
        info.swatch.color().toXML(doc, swatchEle);

        QDomElement positionEle = doc.createElement("Position");
        positionEle.setAttribute("row", info.row);
        positionEle.setAttribute("column", info.column);
        swatchEle.appendChild(positionEle);

        parentEle.appendChild(swatchEle);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    DynaOption option;
                    option.readOptionSetting(prop->settings().data());

                    prop->setValue(option.dyna_action);
                }
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QPointF &pt) {
            handles.addRect(
                KisTransformUtils::handleRect(KisTransformUtils::handleVisualRadius,
                                              m_d->handlesTransform,
                                              m_d->transaction.originalRect(), pt)
                .translated(pt));
    }
```

#### AUTO 


```{c}
auto it = m_nodes.begin() + row * m_size.width();
```

#### LAMBDA EXPRESSION 


```{c}
[this, state] () {
            normalizeAndInvertAlpha8Device(state->filteredMainDev, state->boundingRect);

            KisDefaultBoundsBaseSP oldBounds = m_d->filteredSource->defaultBounds();
            m_d->filteredSource->makeCloneFrom(state->filteredMainDev, m_d->boundingRect);
            m_d->filteredSource->setDefaultBounds(oldBounds);
            m_d->filteredSourceValid = true;
        }
```

#### AUTO 


```{c}
auto *watcher = new QFutureWatcher<IconFetchResult>(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this, interface]() {
            undoTransformCommands(interface, 0);
            undoAllCommands(interface);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (int groupNameRowNumber : m_d->model->m_rowGroupNameMap.keys()) {
        if (groupNameRowNumber == -1) { continue; }
        setSpan(groupNameRowNumber, 0, 1, m_d->model->columnCount());
        setRowHeight(groupNameRowNumber, fontMetrics().lineSpacing() + 6);
        verticalHeader()->resizeSection(groupNameRowNumber, fontMetrics().lineSpacing() + 6);
    }
```

#### AUTO 


```{c}
auto segmentIt = mesh.find(SegmentIndex(NodeIndex(0,0), 1));
```

#### LAMBDA EXPRESSION 


```{c}
[uuid] (KisNodeSP node) {
                return node->uuid() == uuid;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    KisCurveOptionProperties option;
                    option.readOptionSetting(prop->settings().data());
                    option.curve_stroke_history_size = prop->value().toInt();
                    option.writeOptionSetting(prop->settings().data());
                }
```

#### AUTO 


```{c}
auto it = info->tileList.begin();
```

#### LAMBDA EXPRESSION 


```{c}
[=]() { return new T(p1, p2); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KoColorSetSP palette : m_d->doc->paletteList()) {
        // Ensure stored palettes are KPL.
        palette->setPaletteType(KoColorSet::KPL);

        if (!store->open(m_d->imageName + PALETTE_PATH + palette->filename())) {
            m_d->errorMessages << i18nc("Error message when saving a .kra file", "Could not save palettes.");
            return false;
        }

        QByteArray ba = palette->toByteArray();

        qDebug() << "Storing palette inside document" << palette->colorCount();

        qint64 nwritten = 0;
        if (!ba.isEmpty()) {
            nwritten = store->write(ba);
        } else {
            qWarning() << "Cannot save the palette to a byte array:" << palette->name();
        }
        res = store->close();
        res = res && (nwritten == ba.size());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&](QString label, int& index) -> bool {
                    if (attribute.value().startsWith(label)) {
                        QString indexString = attribute.value().remove(0, label.length());
                        bool ok = false;
                        index = indexString.toInt(&ok);
                        if (ok) {
                            if (!elementMap.contains(index))
                                elementMap.insert(index, ExportLayoutElement());
                            return true;
                        }
                    }
                    return false;
                }
```

#### AUTO 


```{c}
auto source = resourcesInterface->source<KoAbstractGradient>(ResourceType::Gradients);
```

#### LAMBDA EXPRESSION 


```{c}
[newImage] (KisNodeSP node) {
                                               node->setImage(newImage);
                                           }
```

#### AUTO 


```{c}
auto it = valuesCache.find(key);
```

#### AUTO 


```{c}
auto it = m_d->commands.constBegin();
```

#### LAMBDA EXPRESSION 


```{c}
[this, applyTransform]() {
        Q_FOREACH (KisSelectionSP selection, m_deactivatedSelections) {
            selection->setVisible(true);
        }

        Q_FOREACH (KisNodeSP node, m_hiddenProjectionLeaves) {
            node->projectionLeaf()->setTemporaryHiddenFromRendering(false);
        }

        if (m_deactivatedOverlaySelectionMask) {
            m_deactivatedOverlaySelectionMask->selection()->setVisible(true);
            m_deactivatedOverlaySelectionMask->setDirty();
        }

        if (applyTransform) {
            KisStrokeStrategyUndoCommandBased::finishStrokeCallback();
        } else {
            KisStrokeStrategyUndoCommandBased::cancelStrokeCallback();
        }
    }
```

#### AUTO 


```{c}
auto *session = dynamic_cast<const KisSessionResource*>(layout);
```

#### AUTO 


```{c}
auto result = endSegments();
```

#### RANGE FOR STATEMENT 


```{c}
for (KoColorSet *cs : newPaletteList) {
        m_rServer->addResource(cs);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[] (const QString &id, const KisBaseNode::PropertyList &list) {
        QVariant value;
        Q_FOREACH (const KisBaseNode::Property &prop, list) {
            if (prop.id == id) {
                value = prop.state;
                break;
            }

        }
        return value;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KisBaseNode::Property &prop : props) {
        if (prop.id == KisLayerPropertiesIcons::colorizeShowColoring.id()) {
            return prop.state.toBool();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](KisNodeSP node) { return node->colorSpace(); }
```

#### AUTO 


```{c}
auto itA = chunkA.constBegin();
```

#### LAMBDA EXPRESSION 


```{c}
[]() {
                return KisSuspendResumePair(
                    new KisTestingStrokeStrategy(QLatin1String("susp_u_"), false, true, true),
                    QList<KisStrokeJobData*>());
            }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        QString name = QInputDialog::getText(this, i18nc("@title:window", "New Workspace..."),
                                             i18nc("@label:textbox", "Name:"));
        if (name.isEmpty()) return;
        auto rserver = KisResourceServerProvider::instance()->workspaceServer();

        KisWorkspaceResource* workspace = new KisWorkspaceResource("");
        workspace->setDockerState(m_this->saveState());
        d->viewManager->resourceProvider()->notifySavingWorkspace(workspace);
        workspace->setValid(true);
        QString saveLocation = rserver->saveLocation();

        bool newName = false;
        if(name.isEmpty()) {
            newName = true;
            name = i18n("Workspace");
        }
        QFileInfo fileInfo(saveLocation + name + workspace->defaultFileExtension());

        int i = 1;
        while (fileInfo.exists()) {
            fileInfo.setFile(saveLocation + name + QString("%1").arg(i) + workspace->defaultFileExtension());
            i++;
        }
        workspace->setFilename(fileInfo.filePath());
        if(newName) {
            name = i18n("Workspace %1", i);
        }
        workspace->setName(name);
        rserver->addResource(workspace);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QAbstractButton *button, bool state)
            {
                const int index = m_d->colorButtonGroup->id(button);
                emit buttonToggled(index, state);
                if (!state) {
                    return;
                }
                if (m_d->colorButtonGroup->exclusive()) {
                    emit currentIndexChanged(index);
                } else {
                    emit selectionChanged();
                }
            }
```

#### CONST EXPRESSION 


```{c}
constexpr int mask = Qt::AlignLeft
                       | Qt::AlignRight
                       | Qt::AlignHCenter
                       | Qt::AlignJustify
                       | Qt::AlignTop
                       | Qt::AlignBottom
                       | Qt::AlignVCenter
                       | Qt::AlignCenter;
```

#### AUTO 


```{c}
auto result = map.erase(i - 1);
```

#### AUTO 


```{c}
auto it = std::find_if(properties.begin(), properties.end(),
        [] (const KisBaseNode::Property &prop) {
            return prop.id == KisLayerPropertiesIcons::layerError.id();
        });
```

#### AUTO 


```{c}
auto server = serverProvider->gradientServer();
```

#### LAMBDA EXPRESSION 


```{c}
[&]() -> KisNodeSP {
        if (!d->m_nodes->empty()) {
            return d->m_nodes->first();
        } else if (!d->m_newNodes->empty()) {
            return d->m_newNodes->first();
        }
        return {};
    }
```

#### AUTO 


```{c}
auto *previousButton = new QPushButton("<<", widget);
```

#### LAMBDA EXPRESSION 


```{c}
[this,
                              argsAreInitialized]() mutable {
        QRect srcRect;

        if (m_d->externalSource) {
            // Start the transformation around the visible pixels of the external image
            srcRect = m_d->externalSource->exactBounds();
        } else if (m_d->selection) {
            srcRect = m_d->selection->selectedExactRect();
        } else {
            srcRect = QRect();
            Q_FOREACH (KisNodeSP node, m_d->processedNodes) {
                // group layers may have a projection of layers
                // that are locked and will not be transformed
                if (node->inherits("KisGroupLayer")) continue;

                if (const KisTransformMask *mask = dynamic_cast<const KisTransformMask*>(node.data())) {
                    srcRect |= mask->sourceDataBounds();
                } else if (const KisSelectionMask *mask = dynamic_cast<const KisSelectionMask*>(node.data())) {
                    srcRect |= mask->selection()->selectedExactRect();
                } else if (const KisTransparencyMask *mask = dynamic_cast<const KisTransparencyMask*>(node.data())) {
                    srcRect |= mask->selection()->selectedExactRect();
                } else {
                    srcRect |= node->exactBounds();
                }
            }
        }

        TransformTransactionProperties transaction(srcRect, &m_d->initialTransformArgs, m_d->rootNode, m_d->processedNodes);
        if (!argsAreInitialized) {
            m_d->initialTransformArgs = KisTransformUtils::resetArgsForMode(m_d->mode, m_d->filterId, transaction);
            m_d->initialTransformArgs.setExternalSource(m_d->externalSource);
        }
        m_d->externalSource.clear();

        const QRect imageBoundsRect = m_d->imageRoot->projection()->defaultBounds()->bounds();
        m_d->previewLevelOfDetail = calculatePreferredLevelOfDetail(srcRect & imageBoundsRect);

        if (m_d->previewLevelOfDetail > 0) {
            for (auto it = m_d->prevDirtyRects.begin(); it != m_d->prevDirtyRects.end(); ++it) {
                KisLodTransform t(m_d->previewLevelOfDetail);
                m_d->prevDirtyPreviewRects[it.key()] = t.map(it.value());
            }
        }

        Q_EMIT sigTransactionGenerated(transaction, m_d->initialTransformArgs, this);
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr double showControlsAnimationDuration {150.0};
```

#### LAMBDA EXPRESSION 


```{c}
[&oldNodes](KisNodeSP node) { oldNodes << node; }
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    CurveOption option;
                    option.readOptionSetting(prop->settings().data());
                    prop->setValue(option.curve_curves_opacity * 100.0);
                }
```

#### LAMBDA EXPRESSION 


```{c}
[color] (KoShapeStrokeSP stroke) {
                stroke->setLineBrush(Qt::NoBrush);
                stroke->setColor(color);

            }
```

#### AUTO 


```{c}
auto rangeEnd = std::upper_bound(rangeBegin, updates.end(), *rangeBegin, CollisionPolicy::compare);
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    KisSprayOptionProperties option;
                    option.readOptionSetting(prop->settings().data());
                    option.coverage = prop->value().toReal();
                    option.writeOptionSetting(prop->settings().data());
                }
```

#### AUTO 


```{c}
auto source = resourcesInterface->source<KoColorSet>(ResourceType::Palettes);
```

#### CONST EXPRESSION 


```{c}
static constexpr double MIN_CHANNEL_L = 0;
```

#### RANGE FOR STATEMENT 


```{c}
for (QUrl url : urls) {

                    if (!url.isLocalFile()) {
                        // download the file and substitute the url
                        KisRemoteFileFetcher fetcher;
                        tmp = new QTemporaryFile();
                        tmp->setAutoRemove(true);
                        if (!fetcher.fetchFile(url, tmp)) {
                            qDebug() << "Fetching" << url << "failed";
                            continue;
                        }
                        url = url.fromLocalFile(tmp->fileName());
                    }
                    if (url.isLocalFile()) {
                        if (action == insertAsNewLayer || action == insertManyLayers) {
                            d->viewManager->imageManager()->importImage(url);
                            activateWindow();
                        }
                        else if (action == insertAsNewFileLayer || action == insertManyFileLayers) {
                            KisNodeCommandsAdapter adapter(viewManager());
                            KisFileLayer *fileLayer = new KisFileLayer(image(), "", url.toLocalFile(),
                                                                       KisFileLayer::None, image()->nextLayerName(), OPACITY_OPAQUE_U8);
                            adapter.addNode(fileLayer, viewManager()->activeNode()->parent(), viewManager()->activeNode());
                        }
                        else if (action == openInNewDocument || action == openManyDocuments) {
                            if (mainWindow()) {
                                mainWindow()->openDocument(url, KisMainWindow::None);
                            }
                        }
                        else if (action == insertAsReferenceImage || action == insertAsReferenceImages) {
                            auto *reference = KisReferenceImage::fromFile(url.toLocalFile());
                            reference->setPosition(cursorPos);
                            d->referenceImagesDecoration->addReferenceImage(reference);

                            KoToolManager::instance()->switchToolRequested("ToolReferenceImages");
                        }

                    }
                    delete tmp;
                    tmp = 0;
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this, shared](){
            // Switch time if necessary..
            if (shared->shouldSwitchTime()) {
                runAndSaveCommand( toQShared( new KisLayerUtils::SwitchFrameCommand(shared->image(), shared->frameTime(), false, shared->storage()) )
                                   , KisStrokeJobData::BARRIER, KisStrokeJobData::NORMAL);
            }

            // Copy snapshot of targetDevice for filter processing..
            shared->filterDevice = new KisPaintDevice(*shared->targetDevice());

            // Update all necessary rect data based on contents of frame..
            shared->filterDeviceBounds = shared->filterDevice->extent();

            if (shared->filter()->needsTransparentPixels(shared->filterConfig().data(), shared->targetDevice()->colorSpace())) {
                shared->filterDeviceBounds |= shared->targetDevice()->defaultBounds()->bounds();
            }

            // Account for any size-differential caused by the filter in question.
            shared->filterDeviceBounds |= shared->filter()->changedRect(shared->filterDeviceBounds, shared->filterConfig().data(), 0);

            //If we're dealing with some kind of transparency mask, we will create a compositionSourceDevice instead.
            //  Carry over from commit ca810f85 ...
            if (shared->selection() ||
                    (shared->targetDevice()->colorSpace() != shared->targetDevice()->compositionSourceColorSpace() &&
                    *shared->targetDevice()->colorSpace() != *shared->targetDevice()->compositionSourceColorSpace())) {

                shared->filterDevice = shared->targetDevice()->createCompositionSourceDevice(shared->targetDevice());

                if (shared->selection()) {
                    shared->filterDeviceBounds &= shared->selection()->selectedRect();
                }
            }

            // Filter device needs a transaction to prevent grid-patch artifcacts from multithreaded read/write.
            shared->filterDeviceTransaction.reset(new KisTransaction(shared->filterDevice));

        }
```

#### LAMBDA EXPRESSION 


```{c}
[&linearizedSrcNodes] (KisNodeSP node) {
                    linearizedSrcNodes.enqueue(node);
                }
```

#### AUTO 


```{c}
const auto sz = KisClipboard::instance()->clipSize();
```

#### AUTO 


```{c}
auto checkKey = [this, modifiers] (Qt::Key key, Qt::KeyboardModifier modifier) {
        return m_d->keys.contains(key) == bool(modifiers & modifier);
    };
```

#### AUTO 


```{c}
auto pairIt = sortedPairs.begin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &tex : m_lut3dTexIDs) {
        f->glDeleteTextures(1, &tex.m_uid);
    }
```

#### AUTO 


```{c}
auto clonedStorage = object->clone();
```

#### AUTO 


```{c}
auto it = m_colors.begin();
```

#### AUTO 


```{c}
auto value = [&](const uint8_t *img, int stride, int x, int y, int ch) {
                uint16_t source = reinterpret_cast<const uint16_t *>(img)[y * (stride / 2) + (x * channels) + ch];
                if (luma == 10) {
                    return linearizeValueAsNeeded(float(0x03ff & (source)) * multiplier10bit, linearizePolicy);
                } else if (luma == 12) {
                    return linearizeValueAsNeeded(float(0x0fff & (source)) * multiplier12bit, linearizePolicy);
                } else {
                    return linearizeValueAsNeeded(float(source) * multiplier16bit, linearizePolicy);
                }
            };
```

#### AUTO 


```{c}
const auto srcTileRowStride =
                (tileWidth - columnsToWork) * srcPixelSize;
```

#### AUTO 


```{c}
auto loader = loaders.first();
```

#### AUTO 


```{c}
auto it = m_dependencyFromSource.find(sourceKey);
```

#### AUTO 


```{c}
auto it = s_instance->d->tagModels.begin();
```

#### LAMBDA EXPRESSION 


```{c}
[dialog, stops, this]() mutable
                          {
                              stops[m_selectedStop].type = COLORSTOP;
                              stops[m_selectedStop].color.fromQColor(dialog->currentColor());
                              m_gradient->setStops(stops);
                              emit sigSelectedStop(m_selectedStop);
                              emit updateRequested();
                          }
```

#### AUTO 


```{c}
auto it = shapes.begin();
```

#### AUTO 


```{c}
auto menuActions = menu->actions();
```

#### AUTO 


```{c}
auto *referencesLayer = dynamic_cast<KisReferenceImagesLayer*>(layer);
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
            KisNodeListSP r(new QList<KisNodeSP>());
            KisLayerUtils::recursiveApplyNodes(
                image->root(),
                [&](KisNodeSP item) {
                    auto *paintLayer =
                        dynamic_cast<KisPaintLayer *>(item.data());
                    if (paintLayer) {
                        r->append(item);
                    }
                });
            return r;
        }
```

#### AUTO 


```{c}
auto *layoutManager= KisWindowLayoutManager::instance();
```

#### LAMBDA EXPRESSION 


```{c}
[&] (QPointF a, QPointF b) -> bool {
            return fuzzyCompare(a.x(), b.x()) && fuzzyCompare(a.y(), b.y()); }
```

#### LAMBDA EXPRESSION 


```{c}
[&]()
    {
        QStringList mimeTypes = KisResourceLoaderRegistry::instance()->mimeTypes(ResourceType::Workspaces);
        KoFileDialog dialog(0, KoFileDialog::OpenFile, "OpenDocument");
        dialog.setMimeTypeFilters(mimeTypes);
        dialog.setCaption(i18nc("@title:window", "Choose File to Add"));
        QString filename = dialog.filename();

        d->workspacemodel->importResourceFile(filename);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KisOptionCollectionWidgetWrapper *widgetWrapper : m_d->widgetWrappers) {
        widgetWrapper->setOrientation(orientation);
        if (recursive) {
            KisOptionCollectionWidget *optionCollectionWidget =
                qobject_cast<KisOptionCollectionWidget*>(widgetWrapper->widget());
            if (optionCollectionWidget) {
                optionCollectionWidget->setOrientation(orientation, true);
                continue;
            }
            KisOptionCollectionWidgetWithHeader *optionCollectionWidgetWithHeader =
                qobject_cast<KisOptionCollectionWidgetWithHeader*>(widgetWrapper->widget());
            if (optionCollectionWidgetWithHeader) {
                optionCollectionWidgetWithHeader->setOrientation(orientation, true);
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            m_updatesFacade->disableDirtyRequests();
            m_updatesDisabled = true;
        }
```

#### AUTO 


```{c}
auto calcPath = [] (const std::vector<NodeKey> &expectedPath) {

        const KoColorConversionSystem *system = KoColorSpaceRegistry::instance()->colorConversionSystem();

        Path path =
            system->findBestPath(expectedPath.front(), expectedPath.back());

        std::vector<NodeKey> realPath;

        Q_FOREACH (const Vertex *vertex, path.vertexes) {
            if (!vertex->srcNode->isEngine) {
                realPath.push_back(vertex->srcNode->key());
            }
        }
        realPath.push_back(path.vertexes.last()->dstNode->key());

        return realPath;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[endType1, endType2, color1, color2, segments, this]()
                                        {
                                            if (m_selectedHandle.index == 0) {
                                                segments[0]->setStartType(endType1);
                                                segments[0]->setStartColor(color1);
                                            } else {
                                                segments[m_selectedHandle.index - 1]->setEndType(endType1);
                                                segments[m_selectedHandle.index - 1]->setEndColor(color1);
                                                if (m_selectedHandle.index < segments.size()) {
                                                    segments[m_selectedHandle.index]->setStartType(endType2);
                                                    segments[m_selectedHandle.index]->setStartColor(color2);
                                                }
                                            }
                                            emit selectedHandleChanged();
                                            emit updateRequested();
                                        }
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    KisBrushBasedPaintOpSettings *s =
                        dynamic_cast<KisBrushBasedPaintOpSettings*>(prop->settings().data());

                    s->setAutoSpacing(prop->value().toBool(), s->autoSpacingCoeff());
                }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
                const auto bounds = image->bounds();
                QByteArray p(static_cast<int>(cs->pixelSize()) * bounds.width() * bounds.height(), 0x0);
                image->projection()->readBytes(reinterpret_cast<quint8 *>(pixels.data()), image->bounds());
                return p;
            }
```

#### CONST EXPRESSION 


```{c}
constexpr const int maxItemsCount = 5;
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        QString name;
        auto rserver = KisResourceServerProvider::instance()->workspaceServer();

        KisWorkspaceResourceSP workspace(new KisWorkspaceResource(""));
        workspace->setDockerState(m_this->saveState());
        d->viewManager->canvasResourceProvider()->notifySavingWorkspace(workspace);
        workspace->setValid(true);
        QString saveLocation = rserver->saveLocation();

        QFileInfo fileInfo(saveLocation + name + workspace->defaultFileExtension());
        bool fileOverWriteAccepted = false;

        while(!fileOverWriteAccepted) {
            name = QInputDialog::getText(this, i18nc("@title:window", "New Workspace..."),
                                                        i18nc("@label:textbox", "Name:"));
            if (name.isNull() || name.isEmpty()) {
                return;
            } else {
                fileInfo = QFileInfo(saveLocation + name.split(" ").join("_") + workspace->defaultFileExtension());
                if (fileInfo.exists()) {
                    int res = QMessageBox::warning(this, i18nc("@title:window", "Name Already Exists")
                                                                , i18n("The name '%1' already exists, do you wish to overwrite it?", name)
                                                                , QMessageBox::Yes | QMessageBox::No, QMessageBox::Yes);
                    if (res == QMessageBox::Yes) fileOverWriteAccepted = true;
                } else {
                    fileOverWriteAccepted = true;
                }
            }
        }

        workspace->setFilename(fileInfo.fileName());
        workspace->setName(name);
        rserver->addResource(workspace);
    }
```

#### AUTO 


```{c}
const auto view = window->activeView();
```

#### LAMBDA EXPRESSION 


```{c}
[uniqueFrameNames](QString &framename){
                return !uniqueFrameNames.contains(framename);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KisTextureUniform &uniform : m_lut3dUniforms) {
        const int m_handle = program->uniformLocation(uniform.m_name);

        const OCIO::GpuShaderDesc::UniformData &m_data = uniform.m_data;

        // Update value.
        if (m_data.m_getDouble) {
            program->setUniformValue(m_handle, static_cast<GLfloat>(m_data.m_getDouble()));
        } else if (m_data.m_getBool) {
            program->setUniformValue(m_handle, static_cast<GLfloat>(m_data.m_getBool() ? 1.0f : 0.0f));
        } else if (m_data.m_getFloat3) {
            program->setUniformValue(m_handle,
                                     m_data.m_getFloat3()[0],
                                     m_data.m_getFloat3()[1],
                                     m_data.m_getFloat3()[2]);
        } else if (m_data.m_vectorFloat.m_getSize && m_data.m_vectorFloat.m_getVector) {
            program->setUniformValueArray(m_handle,
                                          m_data.m_vectorFloat.m_getVector(),
                                          m_data.m_vectorFloat.m_getSize(),
                                          1);
        } else if (m_data.m_vectorInt.m_getSize && m_data.m_vectorInt.m_getVector) {
            program->setUniformValueArray(m_handle, m_data.m_vectorInt.m_getVector(), m_data.m_vectorInt.m_getSize());
        } else {
            errOpenGL << "Uniform" << uniform.m_name << "is not linked to any value";
            continue;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    DynaOption option;
                    option.readOptionSetting(prop->settings().data());
                    option.dyna_action = prop->value().toInt();
                    option.writeOptionSetting(prop->settings().data());
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto stroke : m_d->keyStrokes) {
        stroke.color.setProfile(profile);
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr double touchDragDistance{8.0};
```

#### AUTO 


```{c}
auto layer = m_layer.toStrongRef();
```

#### LAMBDA EXPRESSION 


```{c}
[styles] (KisNodeSP node) {
        KisLayer* layer = qobject_cast<KisLayer*>(node.data());

        if (layer && layer->layerStyle()) {
            QUuid uuid = layer->layerStyle()->uuid();

            bool found = false;

            Q_FOREACH (KisPSDLayerStyleSP style, styles) {
                if (style->uuid() == uuid) {
                    layer->setLayerStyle(style->cloneWithResourcesSnapshot(KisGlobalResourcesInterface::instance(), 0));
                    found = true;
                    break;
                }
            }

            if (!found) {
                warnKrita << "WARNING: loading layer style for" << layer->name() << "failed! It requests inexistent style:" << uuid;
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, index](){
        scrollTo(index);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        Q_FOREACH (KisNodeSP node, m_processedNodes) {
            KisDecoratedNodeInterface *decoratedNode = dynamic_cast<KisDecoratedNodeInterface*>(node.data());
            if (decoratedNode && decoratedNode->decorationsVisible()) {
                decoratedNode->setDecorationsVisible(false);
                m_disabledDecoratedNodes << decoratedNode;
            }
        }
    }
```

#### AUTO 


```{c}
auto cfg = KSharedConfig::openConfig();
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        QString extensions = d->workspacemodel->extensions();
        QStringList mimeTypes;
        for(const QString &suffix : extensions.split(":")) {
            mimeTypes << KisMimeDatabase::mimeTypeForSuffix(suffix);
        }

        KoFileDialog dialog(0, KoFileDialog::OpenFile, "OpenDocument");
        dialog.setMimeTypeFilters(mimeTypes);
        dialog.setCaption(i18nc("@title:window", "Choose File to Add"));
        QString filename = dialog.filename();

        d->workspacemodel->importResourceFile(filename);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[]() {
        const QString path = QDir::cleanPath(
                QStandardPaths::writableLocation(QStandardPaths::CacheLocation) + "/impex_test") + '/';
        QDir(path).mkpath(QStringLiteral("."));
        return path;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, interface, args, levelOfDetail]() {
        updatesFacade->disableDirtyRequests();
        updatesDisabled = true;
        undoTransformCommands(interface, levelOfDetail);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    KisSprayOptionProperties option;
                    option.readOptionSetting(prop->settings().data());
                    option.setParticleCount(prop->value().toInt());
                    option.writeOptionSetting(prop->settings().data());
                }
```

#### AUTO 


```{c}
const auto *srcTileIt = it->rawDataConst();
```

#### RANGE FOR STATEMENT 


```{c}
for (QUrl url : urls) {

                    if (!url.isLocalFile()) {
                        // download the file and substitute the url
                        KisRemoteFileFetcher fetcher;
                        tmp = new QTemporaryFile();
                        tmp->setAutoRemove(true);
                        if (!fetcher.fetchFile(url, tmp)) {
                            qWarning() << "Fetching" << url << "failed";
                            continue;
                        }
                        url = url.fromLocalFile(tmp->fileName());
                    }
                    if (url.isLocalFile()) {
                        if (action == insertAsNewLayer || action == insertManyLayers) {
                            d->viewManager->imageManager()->importImage(url);
                            activateWindow();
                        }
                        else if (action == insertAsNewFileLayer || action == insertManyFileLayers) {
                            KisNodeCommandsAdapter adapter(viewManager());
                            KisFileLayer *fileLayer = new KisFileLayer(image(), "", url.toLocalFile(),
                                                                       KisFileLayer::None, image()->nextLayerName(i18n("File Layer")), OPACITY_OPAQUE_U8);
                            adapter.addNode(fileLayer, viewManager()->activeNode()->parent(), viewManager()->activeNode());
                        }
                        else if (action == openInNewDocument || action == openManyDocuments) {
                            if (mainWindow()) {
                                mainWindow()->openDocument(url, KisMainWindow::None);
                            }
                        }
                        else if (action == insertAsReferenceImage || action == insertAsReferenceImages) {
                            auto *reference = KisReferenceImage::fromFile(url.toLocalFile(), d->viewConverter, this);

                            if (reference) {
                                reference->setPosition(d->viewConverter.imageToDocument(cursorPos));
                                d->referenceImagesDecoration->addReferenceImage(reference);

                                KoToolManager::instance()->switchToolRequested("ToolReferenceImages");
                            }
                        }

                    }
                    delete tmp;
                    tmp = 0;
                }
```

#### AUTO 


```{c}
auto constSegmentIt1 = mesh.constFind(SegmentIndex(NodeIndex(0,0), 1));
```

#### AUTO 


```{c}
auto it3 = forest.insert(childEnd(it0), 3);
```

#### AUTO 


```{c}
auto t = frames->allKeyframeTimes().toList();
```

#### LAMBDA EXPRESSION 


```{c}
[targetFrame, cmd](KisNodeSP node){
            if (node->supportsKeyframeChannel(KisKeyframeChannel::Raster.id())
             && node->isEditable(true)) {

                KisKeyframeChannel* chan = node->getKeyframeChannel(KisKeyframeChannel::Raster.id(), true);
                chan->addKeyframe(targetFrame, cmd);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &loader : offers) {
        auto *factory = qobject_cast<KPluginFactory *>(loader->instance());
        if (!factory) {
            warnPlugins << "(GMic) This is not a Krita plugin: " << loader->fileName() << loader->errorString();

            continue;
        }

        auto *pluginBase = factory->create<QObject>();

        plugin.reset(qobject_cast<KisQmicPluginInterface *>(pluginBase));

        if (!plugin) {
            warnPlugins << "(GMic) This is not a valid GMic-Qt plugin: " << loader->fileName();
            continue;
        }

        break;
    }
```

#### AUTO 


```{c}
const auto &windows = kisPart->mainWindows();
```

#### LAMBDA EXPRESSION 


```{c}
[this, index, Model] {
            int row = index.row();
            KisRemoveStoryboardCommand *command = new KisRemoveStoryboardCommand(row, Model->getData().at(row), Model);
            Model->removeItem(index, command);
            Model->pushUndoCommand(command);
        }
```

#### AUTO 


```{c}
auto setColorFn = [dialog, stops, this]() mutable
                          {
                              stops[m_selectedStop].type = COLORSTOP;
                              stops[m_selectedStop].color.fromQColor(dialog->currentColor());
                              m_gradient->setStops(stops);
                              emit sigSelectedStop(m_selectedStop);
                              emit updateRequested();
                          };
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &groupName : groupNames) {
            if (groupName == KoColorSet::GLOBAL_GROUP_NAME) { continue; }
            QDomElement gl = doc.createElement("Group");
            gl.setAttribute("name", groupName);
            root.appendChild(gl);
            saveKplGroup(doc, gl, colorSet->getGroup(groupName), colorSpaces);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[styles] (KisNodeSP node) {
        KisLayer* layer = qobject_cast<KisLayer*>(node.data());

        if (layer && layer->layerStyle()) {
            QUuid uuid = layer->layerStyle()->uuid();

            bool found = false;

            Q_FOREACH (KisPSDLayerStyleSP style, styles) {
                if (style->uuid() == uuid) {
                    layer->setLayerStyle(style->cloneWithResourcesSnapshot());
                    found = true;
                    break;
                }
            }

            if (!found) {
                warnKrita << "WARNING: loading layer style for" << layer->name() << "failed! It requests inexistent style:" << uuid;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& row: other.m_array) {
        newRow();
        for (const auto& patch: row) {
            m_array.last().append(new SvgMeshPatch(*patch));
        }
    }
```

#### AUTO 


```{c}
auto it0 = forest.insert(childBegin(forest), 0);
```

#### LAMBDA EXPRESSION 


```{c}
[&]() -> QPoint {
                if (d->m_selection) {
                    return d->m_selection->selectedExactRect().topLeft();
                } else if (!d->m_nodes->isEmpty()) {
                    const auto root = d->m_nodes->at(0);
                    return {root->x(), root->y()};
                } else {
                    return {};
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (KisFilterConfigurationSP filterConfig : m_generatorConfigurations) {
        resourcesList += filterConfig->embeddedResources(globalResourcesInterface);
    }
```

#### AUTO 


```{c}
auto resources = source.resources(m_patternLink.md5, m_patternLink.filename, m_patternLink.name);
```

#### AUTO 


```{c}
auto *reference = KisReferenceImage::fromPaintDevice(clip, *this->viewConverter(), this);
```

#### AUTO 


```{c}
auto& row
```

#### LAMBDA EXPRESSION 


```{c}
[]() {
                KisSuspendResumePair suspend(
                    new KisTestingStrokeStrategy(QLatin1String("susp_u_"), false, true, true),
                    QList<KisStrokeJobData*>());

                KisSuspendResumePair resume(
                    new KisTestingStrokeStrategy(QLatin1String("resu_u_"), false, true, true),
                    QList<KisStrokeJobData*>());

                return std::make_pair(suspend, resume);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    KisSmudgeOption option;
                    option.readOptionSetting(prop->settings().data());
                    option.setSmearAlpha(prop->value().toBool());
                    option.writeOptionSetting(prop->settings().data());
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &node : nodes) {
        auto layer = qobject_cast<KisLayer*>(node.data());
        if (layer) {
            KisLayerPropertiesIcons::setNodePropertyAutoUndo(node, KisLayerPropertiesIcons::inheritAlpha, !isAlphaDisabled, m_d->view->image());
        }
    }
```

#### AUTO 


```{c}
auto sendProximityEvent = [&](QEvent::Type type) {
        QPointF emptyPos;
        qreal zero = 0.0;
        QTabletEvent e(type, emptyPos, emptyPos, 0, m_devices.at(m_currentDevice).currentPointerType,
                       zero, 0, 0, zero, zero, 0, Qt::NoModifier,
                       m_devices.at(m_currentDevice).uniqueId, Qt::NoButton, (Qt::MouseButtons)0);
        qApp->sendEvent(qApp, &e);
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &bin : bins) {
        bin.resize(std::numeric_limits<quint8>::max() + 1);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &style : m_stylesVector)
        allStyles.insert(style->psdUuid(), style);
```

#### AUTO 


```{c}
auto it = m_d->transformedPoints.constBegin();
```

#### AUTO 


```{c}
auto button = d->buttonsByToolId.find(toolAction->id());
```

#### AUTO 


```{c}
auto handless = sh.handles();
```

#### DECLTYPE 


```{c}
typedef decltype(r1.topLeft()) Point;
```

#### AUTO 


```{c}
_cimg_constructor_cpp11(siz>values.size())
```

#### AUTO 


```{c}
auto *reference = KisReferenceImage::fromFile(filename);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto memorySegment : p->m_sharedMemorySegments) {
        dbgPlugins << "detaching" << memorySegment;
        memorySegment.clear();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KisSwatchGroup::SwatchInfo &info : d->groups[groupName].infoList()) {
            lastRowGroup = qMax(lastRowGroup, info.row);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &bin : vec) {
        bin.resize(std::numeric_limits<quint8>::max() + 1);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &profileStr : profilesList) {
        const QStringList& profileList = profileStr.split("|");
        if (profileList.size() != 3)
            continue;

        profiles.append({profileList[0], profileList[1], QString(profileList[2]).replace("\\n", "\n")});
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Exiv2::Exifdatum &it : exifData) {
        const uint16_t tag = it.tag();

        if (tag == Exif::Image::StripOffsets || tag == Exif::Image::RowsPerStrip || tag == Exif::Image::StripByteCounts
            || tag == Exif::Image::JPEGInterchangeFormat || tag == Exif::Image::JPEGInterchangeFormatLength
            || it.tagName() == "0x0000") {
            dbgMetaData << it.key().c_str() << " is ignored";
        } else if (tag == Exif::Photo::MakerNote) {
            store->addEntry({makerNoteSchema, "RawData", exivValueToKMDValue(it.getValue(), false)});
        } else if (tag == Exif::Image::DateTime) { // load as xmp:ModifyDate
            store->addEntry({xmpSchema, "ModifyDate", exivValueToKMDValue(it.getValue(), false)});
        } else if (tag == Exif::Image::ImageDescription) { // load as "dc:description"
            store->addEntry({dcSchema, "description", exivValueToKMDValue(it.getValue(), false)});
        } else if (tag == Exif::Image::Software) { // load as "xmp:CreatorTool"
            store->addEntry({xmpSchema, "CreatorTool", exivValueToKMDValue(it.getValue(), false)});
        } else if (tag == Exif::Image::Artist) { // load as dc:creator
            QList<KisMetaData::Value> creators = {exivValueToKMDValue(it.getValue(), false)};
            store->addEntry({dcSchema, "creator", {creators, KisMetaData::Value::OrderedArray}});
        } else if (tag == Exif::Image::Copyright) { // load as dc:rights
            store->addEntry({dcSchema, "rights", exivValueToKMDValue(it.getValue(), false)});
        } else if (it.groupName() == "Image") {
            // Tiff tags
            const QString fixedTN(it.tagName().c_str());
            if (tag == Exif::Image::ExifTag || tag == Exif::Image::GPSTag) {
                dbgMetaData << "Ignoring " << it.key().c_str();
            } else if (KisMetaData::Entry::isValidName(fixedTN)) {
                store->addEntry({tiffSchema, fixedTN, exivValueToKMDValue(it.getValue(), false)});
            } else {
                dbgMetaData << "Invalid tag name: " << fixedTN;
            }
        } else if (it.groupName() == "Photo") {
            // Exif tags
            KisMetaData::Value metaDataValue;
            if (tag == Exif::Photo::ExifVersion || tag == Exif::Photo::FlashpixVersion) {
                metaDataValue = exifVersionToKMDValue(it.getValue());
            } else if (tag == Exif::Photo::FileSource) {
                metaDataValue = KisMetaData::Value(3);
            } else if (tag == Exif::Photo::SceneType) {
                metaDataValue = KisMetaData::Value(1);
            } else if (tag == Exif::Photo::ComponentsConfiguration) {
                metaDataValue = exifArrayToKMDIntOrderedArray(it.getValue());
            } else if (tag == Exif::Photo::OECF) {
                metaDataValue = exifOECFToKMDOECFStructure(it.getValue(), byteOrder);
            } else if (tag == Exif::Photo::DateTimeDigitized || tag == Exif::Photo::DateTimeOriginal) {
                metaDataValue = exivValueToKMDValue(it.getValue(), false);
            } else if (tag == Exif::Photo::DeviceSettingDescription) {
                metaDataValue = deviceSettingDescriptionExifToKMD(it.getValue());
            } else if (tag == Exif::Photo::CFAPattern) {
                metaDataValue = cfaPatternExifToKMD(it.getValue(), byteOrder);
            } else if (tag == Exif::Photo::Flash) {
                metaDataValue = flashExifToKMD(it.getValue());
            } else if (tag == Exif::Photo::UserComment) {
                if (it.getValue()->typeId() != Exiv2::undefined) {
                    KisMetaData::Value vUC = exivValueToKMDValue(it.getValue(), false);
                    Q_ASSERT(vUC.type() == KisMetaData::Value::Variant);
                    QVariant commentVar = vUC.asVariant();
                    QString comment;
                    if (commentVar.type() == QVariant::String) {
                        comment = commentVar.toString();
                    } else if (commentVar.type() == QVariant::ByteArray) {
                        const QByteArray commentString = commentVar.toByteArray();
                        comment = QString::fromLatin1(commentString.constData(), commentString.size());
                    } else {
                        warnKrita << "KisExifIO: Unhandled UserComment value type.";
                    }
                    KisMetaData::Value vcomment(comment);
                    vcomment.addPropertyQualifier("xml:lang", KisMetaData::Value("x-default"));
                    QList<KisMetaData::Value> alt;
                    alt.append(vcomment);
                    metaDataValue = KisMetaData::Value(alt, KisMetaData::Value::LangArray);
                }
            } else {
                bool forceSeq = false;
                KisMetaData::Value::ValueType arrayType = KisMetaData::Value::UnorderedArray;
                if (tag == Exif::Photo::ISOSpeedRatings) {
                    forceSeq = true;
                    arrayType = KisMetaData::Value::OrderedArray;
                }
                metaDataValue = exivValueToKMDValue(it.getValue(), forceSeq, arrayType);
            }
            if (tag == Exif::Photo::InteroperabilityTag || tag == 0xea1d
                || metaDataValue.type() == KisMetaData::Value::Invalid) { // InteroperabilityTag isn't useful for XMP,
                // 0xea1d isn't a valid Exif tag
                warnMetaData << "Ignoring " << it.key().c_str();

            } else {
                store->addEntry({exifSchema, it.tagName().c_str(), metaDataValue});
            }
        } else if (it.groupName() == "Thumbnail") {
            dbgMetaData << "Ignoring thumbnail tag :" << it.key().c_str();
        } else if (it.groupName() == "GPSInfo") {
            store->addEntry({exifSchema, it.tagName().c_str(), exivValueToKMDValue(it.getValue(), false)});
        } else {
            dbgMetaData << "Unknown exif tag, cannot load:" << it.key().c_str();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](QString node){return quietlyTranslate(getChild(actionXml, node));}
```

#### LAMBDA EXPRESSION 


```{c}
[&shortcutString] {
#if QT_VERSION < QT_VERSION_CHECK(5, 15, 0)
                auto list = shortcutString.split(QLatin1Char('+'), QString::SkipEmptyParts);
#else
                auto list = shortcutString.split(QLatin1Char('+'), Qt::SkipEmptyParts);
#endif
                if (shortcutString.endsWith(QLatin1String("+"))) {
                    list.append(QStringLiteral("+"));
                }
                return list;
            }
```

#### AUTO 


```{c}
auto pattern = source.resource(patternMD5, "", patternName);
```

#### RANGE FOR STATEMENT 


```{c}
for (QPointF dPos : m_subbrOriginalLocations) {
                path.addEllipse(dPos, ellipsePreviewSize, ellipsePreviewSize);  // Show subbrush reference locations while in add mode
            }
```

#### AUTO 


```{c}
auto it1 = forest.insert(childEnd(it0), 1);
```

#### AUTO 


```{c}
auto it = channels.constBegin();
```

#### LAMBDA EXPRESSION 


```{c}
LAZY_STATIC_CATEGORY_DISPLAY_NAME("quadratic")
```

#### CONST EXPRESSION 


```{c}
static constexpr double MAX_CHANNEL_AB = +127;
```

#### AUTO 


```{c}
auto resourcesFactory =
        [baseBrush, settings, painter] () {
            KisDabCacheUtils::DabRenderingResources *resources =
                new KisBrushOpResources(settings, painter);
            resources->brush = baseBrush->clone();

            return resources;
        };
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    KisGridOpProperties option;
                    option.readOptionSetting(prop->settings().data());

                    prop->setValue(int(option.grid_division_level));
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &lang : newsLangs) {
        QAction *langItem = newsOptionsMenu->addAction(lang.name);
        langItem->setCheckable(true);
        // We can copy `code` into the lambda because its backing string is a
        // static string literal.
        const QString code = lang.siteCode;
        connect(langItem, &QAction::toggled, [=](bool checked) {
            newsWidget->toggleNewsLanguage(code, checked);
        });

        // Set the initial checked state.
        if (enabledNewsLangs->contains(code)) {
            langItem->setChecked(true);
        }

        // Connect this lambda after setting the initial checked state because
        // we don't want to overwrite the config when doing the initial setup.
        connect(langItem, &QAction::toggled, [=](bool checked) {
            KisConfig cfg(false);
            // It is safe to modify `enabledNewsLangs` here, because the slots
            // are called synchronously on the UI thread so there is no need
            // for explicit synchronization.
            if (checked) {
                enabledNewsLangs->insert(QString(code));
            } else {
                enabledNewsLangs->remove(QString(code));
            }
            cfg.writeList(newsLangConfigName, enabledNewsLangs->toList());
        });
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&hasAnimation](KisNodeSP node) {
            hasAnimation |= node->isAnimated();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (KoColorSetSP  &cs : m_activeDocument->paletteList()) {
            KoColorSetSP tmpAddr = cs;
            cs = KoColorSetSP(new KoColorSet(*cs));
            m_rServer->removeResourceFromServer(tmpAddr);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &btn : btns) {
                painter->setPen(Qt::NoPen);
                const QRect &rect = btn.first;

                QRect buttonRect(x, y, rect.width(), rect.height());

                // draw rounded rect shadow
                auto shadowRect = buttonRect.translated(0, 1);
                painter->setBrush(option.palette.shadow());
                painter->drawRoundedRect(shadowRect, 3, 3);

                // draw rounded rect itself
                painter->setBrush(option.palette.button());
                painter->drawRoundedRect(buttonRect, 3, 3);

                // draw text inside rounded rect
                painter->setPen(option.palette.buttonText().color());
                painter->drawText(buttonRect, Qt::AlignCenter, btn.second);

                // draw '+'
                if (i + 1 < total) {
                    x += rect.width() + 8;
                    painter->drawText(QPoint(x, plusY + (rect.height() / 2)), QStringLiteral("+"));
                    x += plusRect.width() + 8;
                }
                i++;
            }
```

#### AUTO 


```{c}
ORDER_BY(isHDRFormat(lhs), isHDRFormat(rhs))
```

#### LAMBDA EXPRESSION 


```{c}
[image] () {
            return !image->globalSelection() ?
                new KisSetEmptyGlobalSelectionCommand(image) : 0;
        }
```

#### AUTO 


```{c}
auto it = std::upper_bound(fontWeights.rbegin(),
                                       fontWeights.rend(),
                                       propertyOrDefault(FontWeightId).toInt(),
                                       std::greater<int>());
```

#### AUTO 


```{c}
const auto getNode = [&](int i) {
        if (i >= d->m_nodes->size()) {
            return d->m_newNodes->at(i - d->m_nodes->size());
        } else {
            return d->m_nodes->at(i);
        }
    };
```

#### AUTO 


```{c}
const auto &type
```

#### RANGE FOR STATEMENT 


```{c}
for (const KoResource * paletteResource :
         KoResourceServerProvider::instance()->paletteServer()->resources()) {
        const KoColorSet *palette = static_cast<const KoColorSet*>(paletteResource);
        Q_ASSERT(palette);
        if (!palette->isGlobal()) {
            list.append(palette);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QPoint seedPoint : m_seedPoints) {
            if (device->defaultBounds()->wrapAroundMode()) {
                seedPoint = KisWrappedRect::ptToWrappedPt(seedPoint, device->defaultBounds()->imageBorderRect());
            }

            if (m_continuousFillMode == ContinuousFillMode_DoNotUse) {
                normalFill(device, fillRect, seedPoint, undoAdapter, helper);
            } else {
                continuousFill(device, fillRect, seedPoint, undoAdapter, helper);
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[keyframeTime, &nextKeyframeTime] (KisNodeSP node)
    {
        if (node->isAnimated() && node->supportsKeyframeChannel(KisKeyframeChannel::Raster.id())) {
            KisKeyframeChannel* channel = node->getKeyframeChannel(KisKeyframeChannel::Raster.id(), false);

            if (!channel) {
                return;
            }

            int nextKeyframeTimeQuery = channel->nextKeyframeTime(keyframeTime);
            if (channel->keyframeAt(nextKeyframeTimeQuery)) {
                if (nextKeyframeTime == INT_MAX) {
                    nextKeyframeTime = nextKeyframeTimeQuery;
                } else {
                    nextKeyframeTime = qMin(nextKeyframeTime, nextKeyframeTimeQuery);
                }
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[cs, op, srcPtr, dstPtr, numTestablePixels] (int badPixelPos,
            const quint8 *goodSrc,
            const quint8 *goodDst,
            const quint8 *badSrc,
            const quint8 *badDst,
            quint8 opacity,
            quint8 *expectedDst) {

        quint8 *badPixelDstPtr = dstPtr + badPixelPos * cs->pixelSize();

        for (int i = 0; i < numTestablePixels; i++) {
            if (i != badPixelPos) {
                memcpy(srcPtr + cs->pixelSize() * i, goodSrc, cs->pixelSize());
                memcpy(dstPtr + cs->pixelSize() * i, goodDst, cs->pixelSize());
            } else {
                memcpy(srcPtr + cs->pixelSize() * i, badSrc, cs->pixelSize());
                memcpy(dstPtr + cs->pixelSize() * i, badDst, cs->pixelSize());
            }
        }

        op->composite(dstPtr, numTestablePixels * cs->pixelSize(),
                      srcPtr, numTestablePixels * cs->pixelSize(),
                      0, 0,
                      1, numTestablePixels, opacity);

        if (memcmp(badPixelDstPtr, expectedDst, cs->pixelSize()) != 0) {
            qDebug() << "badPixelPos" << badPixelPos;
            qDebug() << "opacity" << opacity;
            qDebug() << "oriS" << badSrc[0] << badSrc[1] << badSrc[2] << badSrc[3];
            qDebug() << "oriD" << badDst[0] << badDst[1] << badDst[2] << badDst[3];
            qDebug() << "expD" << expectedDst[0] << expectedDst[1] << expectedDst[2] << expectedDst[3];
            qDebug() << "dst1" << badPixelDstPtr[0] << badPixelDstPtr[1] << badPixelDstPtr[2] << badPixelDstPtr[3];
#if HAVE_XSIMD
            QFAIL("Failed to compose pixels");
#else
            qWarning() << "Skipping failed test when xsimd library is not used";
#endif
        }
    }
```

#### AUTO 


```{c}
auto *srcPixel =
            reinterpret_cast<KoRgbF32Traits::Pixel *>(convertedTile.data());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &image : layers) {
        QString layerName = image->m_layerName;
        int spectrum = image->m_spectrum;
        int width = image->m_width;
        int height = image->m_height;

        dbgPlugins << "Received image: " << (quintptr)image.data() << layerName << width << height;

        gmic_image<float> *gimg = nullptr;

        {
            QMutexLocker lock(&image->m_mutex);

            dbgPlugins << "Memory segment" << (quintptr)image.data() << image->size() << (quintptr)image->constData() << (quintptr)image->m_data;
            gimg = new gmic_image<float>();
            gimg->assign(width, height, 1, spectrum);
            gimg->name = layerName;

            gimg->_data = new float[width * height * spectrum * sizeof(float)];
            dbgPlugins << "width" << width << "height" << height << "size" << width * height * spectrum * sizeof(float) << "shared memory size"
                       << image->size();
            memcpy(gimg->_data, image->constData(), width * height * spectrum * sizeof(float));

            dbgPlugins << "created gmic image" << gimg->name << gimg->_width << gimg->_height;
        }
        images.append(gimg);
    }
```

#### LAMBDA EXPRESSION 


```{c}
LAZY_STATIC_CATEGORY_DISPLAY_NAME("hsy")
```

#### AUTO 


```{c}
auto &image
```

#### LAMBDA EXPRESSION 


```{c}
[](const QScreen *a, const QScreen *b) {
            QRect aRect = a->geometry();
            QRect bRect = b->geometry();

            if (aRect.y() == bRect.y()) return aRect.x() < bRect.x();
            return (aRect.y() < aRect.y());
        }
```

#### AUTO 


```{c}
auto tryIssueCanvasUpdates = [this](const QRect &vRect) {
        if (!m_d->isBatchUpdateActive) {
            // TODO: Implement info->dirtyViewportRect() for KisOpenGLCanvas2 to avoid updating whole canvas
            if (m_d->currentCanvasIsOpenGL) {
                m_d->savedCanvasProjectionUpdateRect |= vRect;

                // we already had a compression in frameRenderStartCompressor, so force the update directly
                slotDoCanvasUpdate();
            } else if (/* !m_d->currentCanvasIsOpenGL && */ !vRect.isEmpty()) {
                m_d->savedCanvasProjectionUpdateRect |= m_d->coordinatesConverter->viewportToWidget(vRect).toAlignedRect();

                // we already had a compression in frameRenderStartCompressor, so force the update directly
                slotDoCanvasUpdate();
            }
        }
    };
```

#### LAMBDA EXPRESSION 


```{c}
[&points](const QPoint &point) { points.append(point); }
```

#### RANGE FOR STATEMENT 


```{c}
for (KisLevelsCurve &levelsCurve : m_levelsCurves) {
        levelsCurve.resetAll();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    ParticleOption option;
                    option.readOptionSetting(prop->settings().data());
                    option.particle_scale_x = prop->value().toReal();
                    option.writeOptionSetting(prop->settings().data());
                }
```

#### AUTO 


```{c}
auto it = m_d->properties.begin();
```

#### LAMBDA EXPRESSION 


```{c}
[&nearestSegment,
                 &nearestSegmentSignificance,
                 &nearestSegmentDistance,
                 &nearestSegmentDistanceSignificance,
                 &nearestSegmentParam,
                 centerDistance,
                 this] (KisBezierTransformMesh::segment_iterator it, qreal param) {

            const QPointF movedPoint = KisBezierUtils::bezierCurve(it.p0(), it.p1(), it.p2(), it.p3(), param);
            const qreal distance = kisDistance(m_d->mouseClickPos, movedPoint);

            if (distance < nearestSegmentDistance) {
                const qreal proportion = KisBezierUtils::curveProportionByParam(it.p0(), it.p1(), it.p2(), it.p3(), param, 0.1);

                qreal distanceSignificance =
                    centerDistance / (centerDistance + distance);

                if (distanceSignificance > 0.6) {
                    distanceSignificance = std::min(1.0, linearReshapeFunc(distanceSignificance, 0.6, 0.75, 0.6, 1.0));
                }

                const qreal directionSignificance =
                    1.0 - std::min(1.0, std::abs(proportion - 0.5) / 0.4);

                nearestSegmentDistance = distance;
                nearestSegment = it;
                nearestSegmentParam = param;
                nearestSegmentSignificance = m_d->mode != Private::OVER_PATCH_LOCKED ? distanceSignificance * directionSignificance : 0;
                nearestSegmentDistanceSignificance = distanceSignificance;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    KisSprayOptionProperties option;
                    option.readOptionSetting(prop->settings().data());
                    option.setCoverage(prop->value().toReal());
                    option.writeOptionSetting(prop->settings().data());
                }
```

#### AUTO 


```{c}
auto *selectOldLayer = new KisLayerUtils::KeepNodesSelectedCommand(
        nodeManager->selectedNodes(),
        nodeManager->selectedNodes(),
        nodeManager->activeNode(),
        nodeManager->activeNode(),
        d->m_image,
        false);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        QMutexLocker l(&m_s->dirtyRectsMutex);

        m_s->updatesFacade->enableDirtyRequests();
        m_s->updatesDisabled = false;

        m_updateTimer.start();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[name] (KisNodeSP node) {
                return node->name() == name;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    ExperimentOption option;
                    option.readOptionSetting(prop->settings().data());
                    option.windingFill = prop->value().toBool();
                    option.writeOptionSetting(prop->settings().data());
                }
```

#### AUTO 


```{c}
const auto &style
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        m_updatesFacade->disableDirtyRequests();
        m_updatesDisabled = true;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto& tile: tiles) {
                KisProcessingInformation dstCfg(dev, tile.topLeft(), KisSelectionSP());
                addJobConcurrent(jobsData, [=]() {
                    f->generate(dstCfg, tile.size(), filterConfig, helper->updater());

                    // HACK ALERT!!!
                    // this avoids cyclic loop with KisRecalculateGeneratorLayerJob::run()
                    const_cast<KisGeneratorLayerSP &>(layer)->setDirtyWithoutUpdate({tile});

                    const_cast<QSharedPointer<bool> &>(cookie).clear();
                });
            }
```

#### AUTO 


```{c}
ORDER_BY(!isBlacklisted(lhs), !isBlacklisted(rhs))
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &groupName : getGroupNames()) {
        KisSwatchGroup *group = getGroup(groupName);
        for (const KisSwatchGroup::SwatchInfo &currInfo : group->infoList()) {
            KoColor color = currInfo.swatch.color();
            if (useGivenColorSpace == true && compare.colorSpace() != color.colorSpace()) {
                color.convertTo(compare.colorSpace());

            } else if (compare.colorSpace() != color.colorSpace()) {
                compare.convertTo(color.colorSpace());
            }
            testPercentage = (255 - compare.colorSpace()->difference(compare.data(), color.data()));
            if (testPercentage > highestPercentage)
            {
                highestPercentage = testPercentage;
                res = currInfo;
            }
        }
    }
```

#### AUTO 


```{c}
auto it = hierarchyBegin(newPos);
```

#### AUTO 


```{c}
const auto convertedTileX = tileWidth - columnsToWork;
```

#### AUTO 


```{c}
const auto &tex
```

#### CONST EXPRESSION 


```{c}
static constexpr int recursionLimit = 10;
```

#### AUTO 


```{c}
auto index = m_d->currentArgs.meshTransform()->hitTestSegment(mousePos, grabRadius, &localSegmentPos);
```

#### LAMBDA EXPRESSION 


```{c}
[](const KisUniformPaintOpProperty *prop) {
                    KisSprayOptionProperties option;
                    option.readOptionSetting(prop->settings().data());
                    return !option.useDensity();
                }
```

#### AUTO 


```{c}
auto channelFlagsLazy = [](KisNodeSP node) {
                KisLayer *layer = dynamic_cast<KisLayer*>(node.data());
                return layer ? layer->channelFlags() : QBitArray();
            };
```

#### LAMBDA EXPRESSION 


```{c}
[&](QTabletEvent::Type t){
            handleTabletEvent(w, localPosF, globalPosF, currentDevice, currentPointerType,
                              button, buttons, pressureNew, tiltX, tiltY, tangentialPressure, rotation, z,
                              m_devices.at(m_currentDevice).uniqueId, keyboardModifiers, t, packet.pkTime);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QPoint &seedPoint : m_seedPoints) {
                if (fillRect.contains(seedPoint)) {
                    selectionFill(device, fillRect, undoAdapter, helper);
                    break;
                }
            }
```

#### AUTO 


```{c}
auto pointBelongsToLeftSideOfEdge = [](const QPointF &point, const QPointF &edgeStart, const QPointF &edgeDirection) -> bool
    {
        const qreal r = (point.x() - edgeStart.x()) * edgeDirection.y() - (point.y() - edgeStart.y()) * edgeDirection.x();
        return (r == 0.0) && ((edgeDirection.y() == 0.0 && edgeDirection.x() > 0.0) || (edgeDirection.y() > 0.0));
    };
```

#### AUTO 


```{c}
auto controlIt = mesh.beginControlPoints();
```

#### LAMBDA EXPRESSION 


```{c}
[&](QTabletEvent::Type t){
            handleTabletEvent(w, localPosF, globalPosF, currentDevice, currentPointerType,
                              button, buttons, pressureNew, tiltX, tiltY, tangentialPressure, rotation, z,
                              m_devices.at(m_currentDevice).uniqueId, keyboardModifiers, t);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](const KisUniformPaintOpProperty *prop) {
                    ExperimentOption option;
                    option.readOptionSetting(prop->settings().data());
                    return option.isDisplacementEnabled;
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KoColorSetSP palette : m_d->doc->paletteList()) {
        if (!palette->isGlobal()) {
            QDomElement eFile =  doc.createElement("palette");
            eFile.setAttribute("filename", palette->filename());
            ePalette.appendChild(eFile);
        }
    }
```

#### AUTO 


```{c}
auto pos = static_cast<size_t>(y) * gmicImage.m_width
                + static_cast<size_t>(x);
```

#### LAMBDA EXPRESSION 


```{c}
[this, shared](){
            shared->image()->animationInterface()->invalidateFrame(shared->frameTime(), shared->node());
            if (shared->shouldSwitchTime()) {
                runAndSaveCommand( toQShared( new KisLayerUtils::SwitchFrameCommand(shared->image(), shared->frameTime(), true, shared->storage()) )
                                   , KisStrokeJobData::BARRIER, KisStrokeJobData::EXCLUSIVE);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (double value : inputValuesRaw) {
        double cValue = value;

        /* IEC 61966-2-4 ...
         * for Lc between 1 and  β
         *  V = α * Lc^0.45 − ( α − 1)
         * for between β and - β
         *  V = 4.5 * Lc
         * for below -β
         *  V = −α * ( −Lc )^0.45 + ( α − 1)
         *
         * reverse = ((1.0 / 1.099)* V + (-0.099 / 1.099) )^(1.0/0.45) + c
         */

        if (value > 0.018){
            cValue = 1.099 * powf(value, 0.45) - (.099) ;
        } else if (value < 0.018 && value > -0.018){
            cValue = 4.5 * value;
        } else {
            cValue = -1.099 * powf(-value, 0.45) - (-.099) ;
        }


        double lValue;
        if (cValue > 0.018){
            lValue = powf((.099+cValue)*1/1.099, 1/ 0.45);
        } else if (cValue < -0.018) {
             lValue = powf( (cValue/-1.099) + (-.099/-1.099), 1/ 0.45) * -1;
        } else {
            lValue = cValue * 1/4.5;
        }

        // Also not possible in iccv4.
        QVERIFY2(fabs(lValue - value) < 0.001, QString("Values don't match for IEC 61966-2-4: %1 %2").arg(value).arg(lValue).toLatin1());
    }
```

#### AUTO 


```{c}
const auto v2 = (xsimd::nearbyint_as_int(c1) & mask) << 16;
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {
            KisProcessingVisitor::ProgressHelper helper(m_d->progressNode);

            KisWatershedWorker worker(m_d->heightMap, m_d->dst, m_d->boundingRect, helper.updater());
            Q_FOREACH (const KeyStroke &stroke, m_d->keyStrokes) {
                KoColor color =
                    !stroke.isTransparent ?
                        stroke.color : KoColor(Qt::transparent, m_d->dst->colorSpace());

                worker.addKeyStroke(stroke.dev, color);
            }
            worker.run(m_d->filteringOptions.cleanUpAmount);
        }
```

#### AUTO 


```{c}
const auto t2 = zip_hi(a, c);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KisSwatchGroup::SwatchInfo &info : d->groups[groupName].infoList()) {
            d->groups[GLOBAL_GROUP_NAME].setEntry(info.swatch,
                                                  info.column,
                                                  info.row + startingRow);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& rc: region) {
        if (f->allowsSplittingIntoPatches()) {
            QVector<QRect> tiles = splitRectIntoPatches(rc, optimalPatchSize());

            for(const auto& tile: tiles) {
                KisProcessingInformation dstCfg(dev, tile.topLeft(), KisSelectionSP());
                addJobConcurrent(jobsData, [=]() {
                    f->generate(dstCfg, tile.size(), filterConfig, helper->updater());

                    // HACK ALERT!!!
                    // this avoids cyclic loop with KisRecalculateGeneratorLayerJob::run()
                    const_cast<KisGeneratorLayerSP &>(layer)->setDirtyWithoutUpdate({tile});

                    const_cast<QSharedPointer<bool> &>(cookie).clear();
                });
            }
        } else {
            KisProcessingInformation dstCfg(dev, rc.topLeft(), KisSelectionSP());

            addJobSequential(jobsData, [=]() {
                f->generate(dstCfg, rc.size(), filterConfig, helper->updater());

                // HACK ALERT!!!
                // this avoids cyclic loop with KisRecalculateGeneratorLayerJob::run()
                const_cast<KisGeneratorLayerSP &>(layer)->setDirtyWithoutUpdate({rc});

                const_cast<QSharedPointer<bool>&>(cookie).clear();
            });
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : indexes)
        directories.append(model->data(index, valueRole).toString());
```

#### LAMBDA EXPRESSION 


```{c}
[&] (KisFreehandStrokeInfo *data) {
        data->painter->paintPolyline(points, index, numPoints);
    }
```

#### AUTO 


```{c}
ORDER_BY(!isHDRFormat(lhs), !isHDRFormat(rhs))
```

#### AUTO 


```{c}
auto *paintLayer =
                        dynamic_cast<KisPaintLayer *>(item.data());
```

#### LAMBDA EXPRESSION 


```{c}
[this, shared](){
            // We will first apply the transaction to the temporary filterDevice
            runAndSaveCommand(toQShared(shared->filterDeviceTransaction->endAndTake()), KisStrokeJobData::BARRIER, KisStrokeJobData::NORMAL);
            shared->filterDeviceTransaction.reset();

            if (!shared->filterDeviceBounds.intersects(
                    shared->filter()->neededRect(shared->applyRect, shared->filterConfig().data(), shared->levelOfDetail()))) {
                return;
            }

            // Make a transaction, change the target device, and "end" transaction.
            // Should be useful for undoing later.
            QScopedPointer<KisTransaction> workingTransaction( new KisTransaction(shared->targetDevice(), AUTOKEY_DISABLED) );
            KisPainter::copyAreaOptimized(shared->applyRect.topLeft(), shared->filterDevice, shared->targetDevice(), shared->applyRect, shared->selection());
            runAndSaveCommand( toQShared(workingTransaction->endAndTake()), KisStrokeJobData::BARRIER, KisStrokeJobData::EXCLUSIVE );

            if (shared->shouldRedraw()) {
                shared->node()->setDirty(shared->filterDeviceBounds);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KoColorSpace *colorSpace : colorSpaces) {
        QString fn = QFileInfo(colorSpace->profile()->fileName()).fileName();
        if (!store->open(fn)) { qWarning() << "Could not open the store for profiles directory"; return false; }
        QByteArray profileRawData = colorSpace->profile()->rawData();
        if (!store->write(profileRawData)) { qWarning() << "Could not write the profiles data into the store"; return false; }
        if (!store->close()) { qWarning() << "Could not close the store for profiles directory"; return false; }
        QDomElement el = doc.createElement(KPL_PALETTE_PROFILE_TAG);
        el.setAttribute(KPL_PALETTE_FILENAME_ATTR, fn);
        el.setAttribute(KPL_PALETTE_NAME_ATTR, colorSpace->profile()->name());
        el.setAttribute(KPL_COLOR_MODEL_ID_ATTR, colorSpace->colorModelId().id());
        el.setAttribute(KPL_COLOR_DEPTH_ID_ATTR, colorSpace->colorDepthId().id());
        profileElement.appendChild(el);

    }
```

#### LAMBDA EXPRESSION 


```{c}
[] (TimelineSelectionEntry lhs, TimelineSelectionEntry rhs) {
                return lhs.time > rhs.time;
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& rc: region) {
        using namespace KritaUtils;

        if (f->allowsSplittingIntoPatches()) {
            using KritaUtils::optimalPatchSize;
            using KritaUtils::splitRectIntoPatches;

            QVector<QRect> tiles = splitRectIntoPatches(rc, optimalPatchSize());

            addJobSequential(jobsData, (QRunnable*)nullptr);

            for(const auto& tile: tiles) {
                KisProcessingInformation dstCfg(dev, tile.topLeft(), KisSelectionSP());
                addJobConcurrent(jobsData, [=]() {
                    const_cast<QSharedPointer<bool> &>(cookie).clear();

                    f->generate(dstCfg, tile.size(), filterConfig, helper->updater());

                    // HACK ALERT!!!
                    // this avoids cyclic loop with KisRecalculateGeneratorLayerJob::run()
                    const_cast<KisGeneratorLayerSP &>(layer)->setDirtyWithoutUpdate({tile});
                });
            }
        } else {
            KisProcessingInformation dstCfg(dev, rc.topLeft(), KisSelectionSP());

            addJobSequential(jobsData, [=]() {
                const_cast<QSharedPointer<bool>&>(cookie).clear();

                f->generate(dstCfg, rc.size(), filterConfig, helper->updater());

                // HACK ALERT!!!
                // this avoids cyclic loop with KisRecalculateGeneratorLayerJob::run()
                const_cast<KisGeneratorLayerSP &>(layer)->setDirtyWithoutUpdate({rc});
            });
        }
    }
```

#### AUTO 


```{c}
auto *rserver = KoResourceServerProvider::instance()->seExprScriptServer();
```

#### LAMBDA EXPRESSION 


```{c}
[&](qint64 & eraseSum, qint64 & insertSum) {
        for (qint32 i = 1; i < numCycles + 1; ++i) {
            auto type = i % numTypes;

            switch (type) {
            case 0: {
                auto result = map.erase(i - 1);
                if (result.data()) {
                    eraseSum += result->member();
                }
                break;
            }
            case 1: {
                bool newTile = false;
                auto result = map.getLazy(i, KisSharedPtr<Wrapper>(new Wrapper()), newTile);
                if (result.data()) {
                    insertSum += result->member();
                }
                break;
            }
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KoGradientStop& stop : stops) {
        const float value = evenDistribution ? (float)stopIndex / (float)(stopCount - 1) : stop.color.toQColor().valueF();
        const float position = ascending ? value : 1.f - value;

        if (ascending) {
            sortedStops.push_back(KoGradientStop(position, stop.color, stop.type));
        } else {
            sortedStops.push_front(KoGradientStop(position, stop.color, stop.type));
        }

        stopIndex++;
    }
```

#### AUTO 


```{c}
auto error = plugin->errorReason();
```

#### AUTO 


```{c}
auto *animatedParameters = dynamic_cast<KisAnimatedTransformMaskParameters*>(mask->transformParams().data());
```

#### AUTO 


```{c}
const auto& corner
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        QWindow *winHandle = m_d->frame->windowHandle();
        if (winHandle && winHandle->screen()) {
            return winHandle->screen();
        }
        return QApplication::primaryScreen();
    }
```

#### AUTO 


```{c}
const auto& tile
```

#### LAMBDA EXPRESSION 


```{c}
[image, node, channelId, time, copy] () mutable -> KUndo2Command* {
                bool result = false;

                QScopedPointer<KUndo2Command> cmd(new KUndo2Command());

                KisKeyframeChannel *channel = node->getKeyframeChannel(channelId);
                bool createdChannel = false;

                if (!channel) {
                    node->enableAnimation();
                    channel = node->getKeyframeChannel(channelId, true);
                    if (!channel) return nullptr;

                    createdChannel = true;
                }

                if (copy) {
                    if (!channel->keyframeAt(time)) {
                        KisKeyframeSP srcFrame = channel->activeKeyframeAt(time);
                        channel->copyKeyframe(srcFrame, time, cmd.data());
                        result = true;
                    }
                } else {
                    if (channel->keyframeAt(time) && !createdChannel) {
                        if (image->animationInterface()->currentTime() == time && channelId == KisKeyframeChannel::Content.id()) {

                            //shortcut: clearing the image instead
                            KisPaintDeviceSP device = node->paintDevice();
                            if (device) {
                                KisTransaction transaction(kundo2_i18n("Clear"), device, cmd.data());
                                device->clear();
                                (void) transaction.endAndTake(); // saved as 'parent'
                                result = true;
                            }
                        }
                    } else {
                        channel->addKeyframe(time, cmd.data());
                        result = true;
                    }
                }

                return result ? new KisCommandUtils::SkipFirstRedoWrapper(cmd.take()) : nullptr;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, dockWidget](){
                dockWidget->setFloating(!dockWidget->isFloating());
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (int groupNameRowNumber : m_d->model->m_groupNameRows.keys()) {
        if (groupNameRowNumber == -1) { continue; }
        setSpan(groupNameRowNumber, 0, 1, m_d->model->columnCount());
        setRowHeight(groupNameRowNumber, fontMetrics().lineSpacing() + 20);
        verticalHeader()->resizeSection(groupNameRowNumber, fontMetrics().lineSpacing() + 20);
    }
```

#### AUTO 


```{c}
const auto &overlayDevice
```

#### AUTO 


```{c}
auto iRowStart = cacheRowStartBegin;
```

#### AUTO 


```{c}
const auto alpha = a * uint16Max;
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& row: m_array) {
        for (auto& patch: row) {
            delete patch;
        }
    }
```

#### AUTO 


```{c}
auto it = d->colors.begin();
```

#### AUTO 


```{c}
auto end = proposedPaths.size(), i = 0;
```

#### RANGE FOR STATEMENT 


```{c}
for (KisGradientChooser *chooser : globalChoosers) {
            chooser->m_d->updatePresetChooser(false);
        }
```

#### CONST EXPRESSION 


```{c}
static constexpr double showControlsAreaRadius {4.0};
```

#### AUTO 


```{c}
auto it = rects.begin();
```

#### AUTO 


```{c}
auto tailIt = moveMap.find(lastFrame);
```

#### AUTO 


```{c}
auto it = m_d->executedCommands.rbegin();
```

#### LAMBDA EXPRESSION 


```{c}
[interface]() {
        interface->KisStrokeStrategyUndoCommandBased::finishStrokeCallback();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const KoGradientStop& stop : stops)
    {
        reversedStops.push_front(KoGradientStop(1 - stop.first, stop.second));
    }
```

#### AUTO 


```{c}
auto neighbourIt = it.symmetricControl();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                m_d->currentTransformArgs = m_d->initialTransformArgs;
                KisStrokeStrategyUndoCommandBased::finishStrokeCallback();
            }
```

#### CONST EXPRESSION 


```{c}
constexpr int maxPatchSize = 512;
```

#### AUTO 


```{c}
auto setColorFn = [dialog, segments, this]() mutable
                        {
                            KoColor color;
                            color.fromQColor(dialog->currentColor());
                            if (m_selectedHandle.index == 0) {
                                segments[0]->setStartType(COLOR_ENDPOINT);
                                segments[0]->setStartColor(color);
                            } else {
                                segments[m_selectedHandle.index - 1]->setEndType(COLOR_ENDPOINT);
                                segments[m_selectedHandle.index - 1]->setEndColor(color);
                                if (m_selectedHandle.index < segments.size()) {
                                    segments[m_selectedHandle.index]->setStartType(COLOR_ENDPOINT);
                                    segments[m_selectedHandle.index]->setStartColor(color);
                                }
                            }
                            emit selectedHandleChanged();
                            emit updateRequested();
                        };
```

#### LAMBDA EXPRESSION 


```{c}
[&](int size) {
        QPixmap pix(size, size);
        pix.fill(Qt::black);
        QPainter p;
        p.begin(&pix);
        const int itemSize = size / 2 - 1;
        p.fillRect(1, 1, itemSize, itemSize, activeWindow.background());
        p.fillRect(1 + itemSize, 1, itemSize, itemSize, activeButton.background());
        p.fillRect(1, 1 + itemSize, itemSize, itemSize, activeView.background());
        p.fillRect(1 + itemSize, 1 + itemSize, itemSize, itemSize, activeSelection.background());
        p.end();
        result.addPixmap(pix);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : selected.indexes())
        model->setData(index.sibling(index.row(), ColumnCheck), Qt::Checked, Qt::CheckStateRole);
```

#### RANGE FOR STATEMENT 


```{c}
for (QDomElement el: elements) {
            double compare = el.attribute(attr).toDouble();
            QVERIFY2(fabs(mainValue - compare) < 1.0
                    , QString("XML LAB parsing has too high of a difference when roundtripping channel %1: %2")
                     .arg(attr).arg(mainValue - compare).toLatin1());
        }
```

#### AUTO 


```{c}
auto dstIt = m_nodes.begin() + rightColumn;
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {
            QRect updateRect =
                m_d->cancelledUpdates->updateRect |
                m_d->nextExternalUpdateRect;

            if (m_d->levelOfDetail <= 0) {
                updateRect |= m_d->cancelledUpdates->cancelledLod0UpdateRect;
            }

            if (!updateRect.isEmpty()) {
                m_d->node->setDirty(updateRect);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& touchpoint: ev.touchPoints()) {
        s << "id: " << touchpoint.id() << " ";
        s << "hires: " << qSetFieldWidth(8) << touchpoint.screenPos().x() << qSetFieldWidth(0) << "," << qSetFieldWidth(8) << touchpoint.screenPos().y() << qSetFieldWidth(0) << " ";
        s << "prs: " << touchpoint.pressure() << " ";
        s << "rot: "<< touchpoint.rotation() << "; ";
    }
```

#### AUTO 


```{c}
auto &bin
```

#### RANGE FOR STATEMENT 


```{c}
for (PSDLayerRecord *layerRecord : layers) {
                layerRecord->writePixelData(io, compressionType);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    DeformOption option;
                    option.readOptionSetting(prop->settings().data());
                    prop->setValue(int(option.deform_action - 1));
                }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        d->ui->bnPasteReferenceImage->setEnabled(KisClipboard::instance()->hasClip() || KisClipboard::instance()->hasUrls());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    CurveOption option;
                    option.readOptionSetting(prop->settings().data());

                    prop->setValue(option.curve_paint_connection_line);
                }
```

#### AUTO 


```{c}
auto it = mesh.find(index);
```

#### LAMBDA EXPRESSION 


```{c}
[state, this, someDabsAreStillInQueue] () {
                    Q_FOREACH(const QRect &rc, state->allDirtyRects) {
                        state->painter->addDirtyRect(rc);
                    }

                    state->painter->setAverageOpacity(state->dabsQueue.last().averageOpacity);

                    const int updateRenderingTime = state->dabRenderingTimer.elapsed();
                    const qreal dabRenderingTime = m_dabExecutor->averageDabRenderingTime();

                    m_avgNumDabs(state->dabsQueue.size());

                    const qreal currentUpdateTimePerDab = qreal(updateRenderingTime) / state->dabsQueue.size();
                    m_avgUpdateTimePerDab(currentUpdateTimePerDab);

                    /**
                     * NOTE: using currentUpdateTimePerDab in the calculation for the next update time instead
                     *       of the average one makes rendering speed about 40% faster. It happens because the
                     *       adaptation period is shorter than if it used
                     */
                    const qreal totalRenderingTimePerDab = dabRenderingTime + currentUpdateTimePerDab;

                    const int approxDabRenderingTime =
                        qreal(totalRenderingTimePerDab) * m_avgNumDabs.rollingMean() / m_idealNumRects;

                    m_currentUpdatePeriod =
                        someDabsAreStillInQueue ? m_minUpdatePeriod :
                        qBound(m_minUpdatePeriod, int(1.5 * approxDabRenderingTime), m_maxUpdatePeriod);


                    { // debug chunk
//                        ENTER_FUNCTION() << ppVar(state->allDirtyRects.size()) << ppVar(state->dabsQueue.size()) << ppVar(dabRenderingTime) << ppVar(updateRenderingTime);
//                        ENTER_FUNCTION() << ppVar(m_currentUpdatePeriod) << ppVar(someDabsAreStillInQueue);
                    }

                    // release all the dab devices
                    state->dabsQueue.clear();

                    m_updateSharedState.clear();
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KoColorSet *palette : m_d->doc->paletteList()) {
        if (!palette->isGlobal()) {
            if (!store->open(m_d->imageName + PALETTE_PATH + palette->filename())) {
                m_d->errorMessages << i18n("could not save palettes");
                return false;
            }
            store->write(palette->toByteArray());
            store->close();
            res = true;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QUrl url : urls) {

                    if (!url.isLocalFile()) {
                        // download the file and substitute the url
                        KisRemoteFileFetcher fetcher;
                        tmp = new QTemporaryFile();
                        tmp->setAutoRemove(true);
                        if (!fetcher.fetchFile(url, tmp)) {
                            qDebug() << "Fetching" << url << "failed";
                            continue;
                        }
                        url = url.fromLocalFile(tmp->fileName());
                    }
                    if (url.isLocalFile()) {
                        if (action == insertAsNewLayer || action == insertManyLayers) {
                            d->viewManager->imageManager()->importImage(url);
                            activateWindow();
                        }
                        else if (action == insertAsNewFileLayer || action == insertManyFileLayers) {
                            KisNodeCommandsAdapter adapter(viewManager());
                            KisFileLayer *fileLayer = new KisFileLayer(image(), "", url.toLocalFile(),
                                                                       KisFileLayer::None, image()->nextLayerName(), OPACITY_OPAQUE_U8);
                            adapter.addNode(fileLayer, viewManager()->activeNode()->parent(), viewManager()->activeNode());
                        }
                        else if (action == openInNewDocument || action == openManyDocuments) {
                            if (mainWindow()) {
                                mainWindow()->openDocument(url, KisMainWindow::None);
                            }
                        }
                        else if (action == insertAsReferenceImage || action == insertAsReferenceImages) {
                            auto *reference = KisReferenceImage::fromFile(url.toLocalFile(), d->viewConverter, this);

                            if (reference) {
                                reference->setPosition(d->viewConverter.imageToDocument(cursorPos));
                                d->referenceImagesDecoration->addReferenceImage(reference);

                                KoToolManager::instance()->switchToolRequested("ToolReferenceImages");
                            }
                        }

                    }
                    delete tmp;
                    tmp = 0;
                }
```

#### AUTO 


```{c}
auto commentTester = new QAbstractItemModelTester(m_commentModel, this);
```

#### AUTO 


```{c}
auto *reference = new KisReferenceImage();
```

#### RANGE FOR STATEMENT 


```{c}
for(KoGamutMaskShape* shape: *shapeVector) {
        shape->paintStroke(painter, viewConverter);
    }
```

#### AUTO 


```{c}
auto converted = KisTransformMaskParamsFactoryRegistry::instance()->animateParams(m_d->params);
```

#### AUTO 


```{c}
const auto image = document->savingImage();
```

#### AUTO 


```{c}
auto *layout = KisWindowLayoutResource::fromCurrentWindows(name, KisPart::instance()->mainWindows(), showImageInAllWindows, primaryWorkspaceFollowsFocus, thisWindow);
```

#### AUTO 


```{c}
auto index = m_d->currentArgs.meshTransform()->hitTestPatch(mousePos, &localPatchPos);
```

#### AUTO 


```{c}
auto it = std::min_element(foundResources.begin(), foundResources.end(),
                               [] (const QPair<KoResourceSP, int> &lhs,
                               const QPair<KoResourceSP, int> &rhs) {return lhs.second < rhs.second;});
```

#### LAMBDA EXPRESSION 


```{c}
[state] () {
                state->activeTransaction.reset(new KisTransaction(state->filteredMainDev));
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            Q_FOREACH (KisTransformMask *mask, m_d->transformMaskCacheHash.keys()) {
                mask->overrideStaticCacheDevice(0);
                mask->threadSafeForceStaticImageUpdate();
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[lastChangedFrame](const int &arg1, const int &arg2)
                {
                    return std::abs(arg1 - lastChangedFrame) < std::abs(arg2 - lastChangedFrame);
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KoColorSetSP palette : m_d->doc->paletteList()) {
        qDebug() << "saving palette..." << palette->storageLocation() << palette->filename();
        if (!store->open(m_d->imageName + PALETTE_PATH + palette->filename())) {
            m_d->errorMessages << i18n("could not save palettes");
            return false;
        }
        QByteArray ba = palette->toByteArray();
        if (!ba.isEmpty()) {
            store->write(ba);
        } else {
            qWarning() << "Cannot save the palette to a byte array:" << palette->name();
        }
        store->close();
        res = true;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        Q_FOREACH(KisNodeSP node, m_nodes) {
            KisLayerUtils::forceAllDelayedNodesUpdate(node);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[filter] (const Private::PriorityPair &a) { return a.second == filter; }
```

#### LAMBDA EXPRESSION 


```{c}
[this, filename] (KoResourceSP res) {
                                   return res->resourceType().first == this->m_resourceType &&
                                       (res->filename() == filename ||
                                        QFileInfo(res->filename()).fileName() == filename);
                               }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QRectF & a, const QRectF & b) -> bool
                    {
                        if (a.x() == b.x()) {
                            return a.x() < b.x();
                        }
                        return a.y() < b.y();
                    }
```

#### AUTO 


```{c}
const auto hasReferenceImageSelected = [&]() {
        KisReferenceImagesLayerSP refLayer = view->document()->referenceImagesLayer();
        return refLayer && refLayer->shapeManager()->selection()->count();
    };
```

#### AUTO 


```{c}
inline auto set_one(const batch<T, A> &src, const batch_bool<T, A> &mask) noexcept
{
    return xsimd::select(mask, xsimd::batch<T, A>(1), src);
}
```

#### AUTO 


```{c}
auto fuzzyCompare = [epsilon] (float a, float b) -> bool {
            return (qAbs(a - b) < epsilon); };
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    DynaOption option;
                    option.readOptionSetting(prop->settings().data());
                    option.dyna_diameter = prop->value().toInt();
                    option.writeOptionSetting(prop->settings().data());
                }
```

#### AUTO 


```{c}
auto rc = dirtyRegion.begin();
```

#### AUTO 


```{c}
auto checkUnmultipliedColorsConsistent = [this, i](const T *d) {
                    const T alpha = std::abs(d[this->poses()[i]]);

                    if (alpha >= static_cast<T>(0.01)) {
                        return true;
                    } else {
                        for (size_t i = 0; i < this->nbColorsSamples(); i++) {
                            if (!qFuzzyCompare(T(d[i] * alpha), d[i])) {
                                return false;
                            }
                        }
                        return true;
                    }
                };
```

#### AUTO 


```{c}
auto it = m_objects.end();
```

#### LAMBDA EXPRESSION 


```{c}
[] (const QTransform &t1, const QTransform &t2) {
                       return KisAlgebra2D::fuzzyMatrixCompare(t1, t2, 1e-6);
                   }
```

#### AUTO 


```{c}
auto *widget = new QWidget(this);
```

#### AUTO 


```{c}
auto existing = std::find(m_columns.begin(), m_columns.end(), proportionalT);
```

#### AUTO 


```{c}
auto i = minIndex;
```

#### LAMBDA EXPRESSION 


```{c}
[](const int& a, const int& b){
        return a < b;
    }
```

#### AUTO 


```{c}
const auto strEnd = str.cend();
```

#### LAMBDA EXPRESSION 


```{c}
[lineWidth](KoShapeStrokeSP stroke) {
            stroke->setColor(Qt::transparent);
            stroke->setLineWidth(lineWidth);

     }
```

#### AUTO 


```{c}
auto it = beginPatches();
```

#### AUTO 


```{c}
const auto dstPixelSize = rgbaFloat32bitcolorSpace->pixelSize();
```

#### AUTO 


```{c}
auto name = config->getString("pattern", "Disney_noisecolor2");
```

#### CONST EXPRESSION 


```{c}
constexpr int ALPHA = 63;
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        m_d->updatesFacade->disableDirtyRequests();
        m_d->updatesDisabled = true;

        Q_FOREACH (KisNodeSP node, m_d->processedNodes) {
            m_d->prevDirtyRects[node] = node->extent();
        }
    }
```

#### AUTO 


```{c}
auto sampleIterator =
            std::upper_bound(samples.begin(), samples.end(), SampleInfo{0.0, randomValue, 0.0},
                [](const SampleInfo &a, const SampleInfo &b) -> bool {  return a.cdfAtX < b.cdfAtX; }
            );
```

#### LAMBDA EXPRESSION 


```{c}
[&](qint32 start) {
        QAtomicInt *newBuffer = new QAtomicInt[m_capacity];

        for (qint32 i = 0; i < oldCapacity; ++i) {
            newBuffer[start + i].store(m_buffer[i].load());
        }

        delete[] m_buffer;
        m_buffer = newBuffer;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Shape* shape : topLevelShapeList) {
            QVERIFY(test.contains(shape->name()) == true);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& rc: region) {
        using namespace KritaUtils;

        if (f->allowsSplittingIntoPatches()) {
            using KritaUtils::optimalPatchSize;
            using KritaUtils::splitRectIntoPatches;

            QVector<QRect> tiles = splitRectIntoPatches(rc, optimalPatchSize());

            for(const auto& tile: tiles) {
                KisProcessingInformation dstCfg(dev, tile.topLeft(), KisSelectionSP());
                addJobConcurrent(jobsData, [=]() {
                    const_cast<QSharedPointer<bool> &>(cookie).clear();

                    f->generate(dstCfg, tile.size(), filterConfig, helper->updater());

                    // HACK ALERT!!!
                    // this avoids cyclic loop with KisRecalculateGeneratorLayerJob::run()
                    const_cast<KisGeneratorLayerSP &>(layer)->setDirtyWithoutUpdate({tile});
                });
            }
        } else {
            KisProcessingInformation dstCfg(dev, rc.topLeft(), KisSelectionSP());

            addJobConcurrent(jobsData, [=]() {
                const_cast<QSharedPointer<bool>&>(cookie).clear();

                f->generate(dstCfg, rc.size(), filterConfig, helper->updater());

                // HACK ALERT!!!
                // this avoids cyclic loop with KisRecalculateGeneratorLayerJob::run()
                const_cast<KisGeneratorLayerSP &>(layer)->setDirtyWithoutUpdate({rc});
            });
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QUrl url : urls) {

                    QScopedPointer<QTemporaryFile> tmp(new QTemporaryFile());
                    tmp->setAutoRemove(true);

                    if (!url.isLocalFile()) {
                        // download the file and substitute the url
                        KisRemoteFileFetcher fetcher;

                        if (!fetcher.fetchFile(url, tmp.data())) {
                            qWarning() << "Fetching" << url << "failed";
                            continue;
                        }
                        url = url.fromLocalFile(tmp->fileName());
                    }

                    if (url.isLocalFile()) {
                        if (action == insertAsNewLayer || action == insertManyLayers) {
                            kisview->mainWindow()->viewManager()->imageManager()->importImage(url);
                            kisview->activateWindow();
                        }
                        else if (action == insertAsNewFileLayer || action == insertManyFileLayers) {
                            KisNodeCommandsAdapter adapter(kisview->mainWindow()->viewManager());
                            QFileInfo fileInfo(url.toLocalFile());

                            QString type = KisMimeDatabase::mimeTypeForFile(url.toLocalFile());
                            QStringList mimes =
                                KisImportExportManager::supportedMimeTypes(KisImportExportManager::Import);

                            if (!mimes.contains(type)) {
                                QString msg =
                                    KisImportExportErrorCode(ImportExportCodes::FileFormatNotSupported).errorMessage();
                                QMessageBox::warning(
                                    kisview, i18nc("@title:window", "Krita"),
                                    i18n("Could not open %2.\nReason: %1.", msg, url.toDisplayString()));
                                continue;
                            }

                            KisFileLayer *fileLayer = new KisFileLayer(kisview->image(), "", url.toLocalFile(),
                                                                       KisFileLayer::None, fileInfo.fileName(), OPACITY_OPAQUE_U8);
                            adapter.addNode(fileLayer, kisview->mainWindow()->viewManager()->activeNode()->parent(), kisview->mainWindow()->viewManager()->activeNode());
                        }
                        else if (action == openInNewDocument || action == openManyDocuments) {
                            if (kisview->mainWindow()) {
                                kisview->mainWindow()->openDocument(url.toLocalFile(), KisMainWindow::None);
                            }
                        }
                        else if (action == insertAsReferenceImage || action == insertAsReferenceImages) {
                            auto *reference = KisReferenceImage::fromFile(url.toLocalFile(), *kisview->viewConverter(), kisview);

                            if (reference) {
                                reference->setPosition((*kisview->viewConverter()).imageToDocument(QCursor::pos()));
                                kisview->canvasBase()->referenceImagesDecoration()->addReferenceImage(reference);

                                KoToolManager::instance()->switchToolRequested("ToolReferenceImages");
                            }
                        }

                    }
                }
```

#### AUTO 


```{c}
const auto conversionFlags =
        KoColorConversionTransformation::internalConversionFlags();
```

#### LAMBDA EXPRESSION 


```{c}
[this](){clone(false);}
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
                        if (selection) {
                            return selection->selectedExactRect();
                        } else {
                            return node->exactBounds();
                        }
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& corner: cornerHandles) {
        const QPointF point = t.map(corner.pos);
        if (corner.type == KoShapeMeshGradientHandles::Handle::BezierHandle) {
            helper.drawConnectionLine(gradientHandles.getAttachedCorner(corner), point);
            helper.drawHandleSmallCircle(point);
        } else if (corner.type == KoShapeMeshGradientHandles::Handle::Corner) {
            helper.drawHandleCircle(point);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const RecorderProfile &profile : profiles) {
            ui->comboProfile->addItem(profile.name);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](qreal zoomDelta){
        qreal currentZoomLevel = m_d->horizontalHeader->zoom();
        m_d->horizontalHeader->setZoom(currentZoomLevel + zoomDelta);
        slotUpdateInfiniteFramesCount();
        slotUpdateHorizontalScrollbarSize();
        viewport()->update();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this,
                              argsAreInitialized]() mutable {
        QRect srcRect;

        if (m_d->selection) {
            srcRect = m_d->selection->selectedExactRect();
        } else {
            srcRect = QRect();
            Q_FOREACH (KisNodeSP node, m_d->processedNodes) {
                // group layers may have a projection of layers
                // that are locked and will not be transformed
                if (node->inherits("KisGroupLayer")) continue;

                if (const KisTransformMask *mask = dynamic_cast<const KisTransformMask*>(node.data())) {
                    srcRect |= mask->sourceDataBounds();
                } else if (const KisSelectionMask *mask = dynamic_cast<const KisSelectionMask*>(node.data())) {
                    srcRect |= mask->selection()->selectedExactRect();
                } else if (const KisTransparencyMask *mask = dynamic_cast<const KisTransparencyMask*>(node.data())) {
                    srcRect |= mask->selection()->selectedExactRect();
                } else {
                    srcRect |= node->exactBounds();
                }
            }
        }

        TransformTransactionProperties transaction(srcRect, &m_d->initialTransformArgs, m_d->rootNode, m_d->processedNodes);
        if (!argsAreInitialized) {
            m_d->initialTransformArgs = KisTransformUtils::resetArgsForMode(m_d->mode, m_d->filterId, transaction);
        }

        m_d->previewLevelOfDetail = calculatePreferredLevelOfDetail(srcRect);

        if (m_d->previewLevelOfDetail > 0) {
            for (auto it = m_d->prevDirtyRects.begin(); it != m_d->prevDirtyRects.end(); ++it) {
                KisLodTransform t(m_d->previewLevelOfDetail);
                m_d->prevDirtyPreviewRects[it.key()] = t.map(it.value());
            }
        }

        Q_EMIT sigTransactionGenerated(transaction, m_d->initialTransformArgs, this);
    }
```

#### AUTO 


```{c}
auto it = rtree.qbegin(boost::geometry::index::nearest(searchColor, colorCount));
```

#### RANGE FOR STATEMENT 


```{c}
for (auto row : rows) {
            row *= invM33;
        }
```

#### AUTO 


```{c}
auto *cfg = new KisCrossChannelFilterConfiguration(m_virtualChannels.count(), m_dev->colorSpace());
```

#### LAMBDA EXPRESSION 


```{c}
[this, oldRoot, newRoot] (KisNodeSP node) {
                    if (node->isFakeNode() && node->parent() == oldRoot) {
                        addCommand(new KisImageLayerAddCommand(m_info->image,
                                                               node->clone(),
                                                               newRoot,
                                                               KisNodeSP(),
                                                               false, false));

                    }
                }
```

#### AUTO 


```{c}
auto tailIt = moveMap.find(previousFrame);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const KisPaintInformation &pi1, const KisPaintInformation &pi2) {
                    paintLine(pi1, pi2);
                }
```

#### AUTO 


```{c}
auto actionRegistry = KisActionRegistry::instance();
```

#### AUTO 


```{c}
const auto status = manager.importDocument(inputFileName, {});
```

#### LAMBDA EXPRESSION 


```{c}
[&]() -> std::unique_ptr<KisMetaData::Store> {
            KisExifInfoVisitor exivInfoVisitor;
            exivInfoVisitor.visit(image->rootLayer().data());
            if (exivInfoVisitor.metaDataCount() == 1) {
                return std::make_unique<KisMetaData::Store>(*exivInfoVisitor.exifInfo());
            } else {
                return {};
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &position: positions) {
            SvgMeshPath path = mesharray->getPath(position);
            painterPath = QPainterPath();
            painterPath.moveTo(path[0]);
            painterPath.cubicTo(path[1], path[2], path[3]);
            result << painterPath;
        }
```

#### AUTO 


```{c}
auto i = channelDict.constBegin();
```

#### LAMBDA EXPRESSION 


```{c}
[this] (KoShapeStrokeSP stroke) {
            stroke->setLineWidth(lineWidth());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KisBaseNode::Property &prop : props) {
        if (prop.id == KisLayerPropertiesIcons::colorizeEditKeyStrokes.id()) {
            return prop.state.toBool();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](qreal zoomValue){
                                                                KisConfig cfg(false);
                                                                cfg.setTimelineZoom(zoomValue);
                                                            }
```

#### LAMBDA EXPRESSION 


```{c}
[messageBoxWarningText]() {
            QMessageBox::warning(KisPart::instance()->currentMainwindow(), i18nc("@title:window", "Krita"), messageBoxWarningText);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            KisStrokeStrategyUndoCommandBased::finishStrokeCallback();
        }
```

#### AUTO 


```{c}
const auto tileWidth = it->numContiguousColumns(dev->x());
```

#### LAMBDA EXPRESSION 


```{c}
LAZY_STATIC_CATEGORY_DISPLAY_NAME("misc")
```

#### RANGE FOR STATEMENT 


```{c}
for (const KisMetaData::Value &it : value.asArray()) {
        v.push_back(static_cast<uint8_t>(it.asVariant().toInt(0)));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[image, frames] () {
                bool result = false;

                QScopedPointer<KUndo2Command> cmd(new KUndo2Command());

                Q_FOREACH (const FrameItem &item, frames) {
                    const int time = item.time;
                    KisNodeSP node = item.node;
                    KisKeyframeChannel *channel;
                    if (node) {
                        channel = node->getKeyframeChannel(item.channel);
                    }
                    if (!channel) continue;

                    KisKeyframeSP keyframe = channel->keyframeAt(time);
                    if (!keyframe) continue;

                    channel->deleteKeyframe(keyframe, cmd.data());

                    result = true;
                }

                return result ? new KisCommandUtils::SkipFirstRedoWrapper(cmd.take()) : 0;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[includedShapes] (KoShape *shape) {
            // included shapes are guaranteed to be visible
            return includedShapes.find(shape) != end(includedShapes);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &directory : directories) {
        QDir(directory).removeRecursively();
    }
```

#### AUTO 


```{c}
auto it = pointsMap.constBegin();
```

#### AUTO 


```{c}
auto setColorFn = [dialog, stops, this]() mutable
                          {
                              stops[m_selectedStop].type = COLORSTOP;
                              stops[m_selectedStop].color = dialog->getCurrentColor();
                              m_gradient->setStops(stops);
                              emit sigSelectedStop(m_selectedStop);
                              emit updateRequested();
                          };
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        m_treeView->viewport()->update();
        reselectFirst();
    }
```

#### LAMBDA EXPRESSION 


```{c}
LAZY_STATIC_CATEGORY_DISPLAY_NAME("arithmetic")
```

#### RANGE FOR STATEMENT 


```{c}
for (const Exiv2::Exifdatum &it : exifData) {
        const uint16_t tag = it.tag();

        if (tag == Exif::Image::StripOffsets || tag == Exif::Image::RowsPerStrip || tag == Exif::Image::StripByteCounts
            || tag == Exif::Image::JPEGInterchangeFormat || tag == Exif::Image::JPEGInterchangeFormatLength || it.tagName() == "0x0000") {
            dbgMetaData << it.key().c_str() << " is ignored";
        } else if (tag == Exif::Photo::MakerNote) {
            store->addEntry({makerNoteSchema, "RawData", exivValueToKMDValue(it.getValue(), false)});
        } else if (tag == Exif::Image::DateTime) { // load as xmp:ModifyDate
            store->addEntry({xmpSchema, "ModifyDate", exivValueToKMDValue(it.getValue(), false)});
        } else if (tag == Exif::Image::ImageDescription) { // load as "dc:description"
            store->addEntry({dcSchema, "description", exivValueToKMDValue(it.getValue(), false)});
        } else if (tag == Exif::Image::Software) { // load as "xmp:CreatorTool"
            store->addEntry({xmpSchema, "CreatorTool", exivValueToKMDValue(it.getValue(), false)});
        } else if (tag == Exif::Image::Artist) { // load as dc:creator
            QList<KisMetaData::Value> creators = {exivValueToKMDValue(it.getValue(), false)};
            store->addEntry({dcSchema, "creator", {creators, KisMetaData::Value::OrderedArray}});
        } else if (tag == Exif::Image::Copyright) { // load as dc:rights
            store->addEntry({dcSchema, "rights", exivValueToKMDValue(it.getValue(), false)});
        } else if (it.groupName() == "Image") {
            // Tiff tags
            const QString fixedTN(it.tagName().c_str());
            if (tag == Exif::Image::ExifTag || tag == Exif::Image::GPSTag) {
                dbgMetaData << "Ignoring " << it.key().c_str();
            } else if (KisMetaData::Entry::isValidName(fixedTN)) {
                store->addEntry({tiffSchema, fixedTN, exivValueToKMDValue(it.getValue(), false)});
            } else {
                dbgMetaData << "Invalid tag name: " << fixedTN;
            }
        } else if (it.groupName() == "Photo") {
            // Exif tags
            KisMetaData::Value metaDataValue;
            if (tag == Exif::Photo::ExifVersion || tag == Exif::Photo::FlashpixVersion) {
                metaDataValue = exifVersionToKMDValue(it.getValue());
            } else if (tag == Exif::Photo::FileSource) {
                metaDataValue = KisMetaData::Value(3);
            } else if (tag == Exif::Photo::SceneType) {
                metaDataValue = KisMetaData::Value(1);
            } else if (tag == Exif::Photo::ComponentsConfiguration) {
                metaDataValue = exifArrayToKMDIntOrderedArray(it.getValue());
            } else if (tag == Exif::Photo::OECF) {
                metaDataValue = exifOECFToKMDOECFStructure(it.getValue(), byteOrder);
            } else if (tag == Exif::Photo::DateTimeDigitized || tag == Exif::Photo::DateTimeOriginal) {
                metaDataValue = exivValueToKMDValue(it.getValue(), false);
            } else if (tag == Exif::Photo::DeviceSettingDescription) {
                metaDataValue = deviceSettingDescriptionExifToKMD(it.getValue());
            } else if (tag == Exif::Photo::CFAPattern) {
                metaDataValue = cfaPatternExifToKMD(it.getValue(), byteOrder);
            } else if (tag == Exif::Photo::Flash) {
                metaDataValue = flashExifToKMD(it.getValue());
            } else if (tag == Exif::Photo::UserComment) {
                if (it.getValue()->typeId() != Exiv2::undefined) {
                    KisMetaData::Value vUC = exivValueToKMDValue(it.getValue(), false);
                    Q_ASSERT(vUC.type() == KisMetaData::Value::Variant);
                    QVariant commentVar = vUC.asVariant();
                    QString comment;
                    if (commentVar.type() == QVariant::String) {
                        comment = commentVar.toString();
                    } else if (commentVar.type() == QVariant::ByteArray) {
                        const QByteArray commentString = commentVar.toByteArray();
                        comment = QString::fromLatin1(commentString.constData(), commentString.size());
                    } else {
                        warnKrita << "KisExifIO: Unhandled UserComment value type.";
                    }
                    KisMetaData::Value vcomment(comment);
                    vcomment.addPropertyQualifier("xml:lang", KisMetaData::Value("x-default"));
                    QList<KisMetaData::Value> alt;
                    alt.append(vcomment);
                    metaDataValue = KisMetaData::Value(alt, KisMetaData::Value::LangArray);
                }
            } else {
                bool forceSeq = false;
                KisMetaData::Value::ValueType arrayType = KisMetaData::Value::UnorderedArray;
                if (tag == Exif::Photo::ISOSpeedRatings) {
                    forceSeq = true;
                    arrayType = KisMetaData::Value::OrderedArray;
                }
                metaDataValue = exivValueToKMDValue(it.getValue(), forceSeq, arrayType);
            }
            if (tag == Exif::Photo::InteroperabilityTag
                || metaDataValue.type() == KisMetaData::Value::Invalid) { // InteroperabilityTag isn't useful for XMP, 0xea1d isn't a valid Exif tag
                warnMetaData << "Ignoring " << it.key().c_str();
            } else {
                store->addEntry({exifSchema, it.tagName().c_str(), metaDataValue});
            }
        } else if (it.groupName() == "Thumbnail") {
            dbgMetaData << "Ignoring thumbnail tag :" << it.key().c_str();
        } else if (it.groupName() == "GPSInfo") {
            store->addEntry({exifSchema, it.tagName().c_str(), exivValueToKMDValue(it.getValue(), false)});
        } else {
            dbgMetaData << "Unknown exif tag, cannot load:" << it.key().c_str();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const KisKeyframeChannel *channel, int time) {
        const KisScalarKeyframeChannel* chan = dynamic_cast<const KisScalarKeyframeChannel*>(channel);
        chan->sigChannelUpdated(
                    chan->affectedFrames(time),
                    chan->affectedRect(time)
                    );
    }
```

#### AUTO 


```{c}
auto valueForId = [] (const QString &id, const KisBaseNode::PropertyList &list) {
        QVariant value;
        Q_FOREACH (const KisBaseNode::Property &prop, list) {
            if (prop.id == id) {
                value = prop.state;
                break;
            }

        }
        return value;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
                    const auto nextKeyframe = frames->nextKeyframeTime(i);
                    if (nextKeyframe == -1) {
                        return static_cast<uint32_t>(image->animationInterface()->fullClipRange().end() - i);
                    } else {
                        return static_cast<uint32_t>(frames->nextKeyframeTime(i) - i);
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KoGradientStop &stopGradientStop : gradient->stops()) {
            stops << toQGradientStop(stopGradientStop.color, stopGradientStop.type, stopGradientStop.position, canvasResourcesInterface);
        }
```

#### AUTO 


```{c}
auto segmentIt = mesh.beginSegments();
```

#### AUTO 


```{c}
const auto src4 = zip_hi(t2, t4);
```

#### CONST EXPRESSION 


```{c}
static constexpr double MAX_CHANNEL_L = 100;
```

#### LAMBDA EXPRESSION 


```{c}
[this] (int col, int row) {
                            KisTileSP tile = dm.getTile(col, row, true);
                            tile->lockForWrite();
                            tile->unlockForWrite();
                        }
```

#### AUTO 


```{c}
auto needCreateProofingTransform =
        [this] () {
            return !m_d->proofingTransform &&
                m_d->proofingConfig &&
                m_d->proofingConfig->conversionFlags.testFlag(KoColorConversionTransformation::SoftProofing);
        };
```

#### AUTO 


```{c}
const auto& shape
```

#### AUTO 


```{c}
auto translatedMode =
                KisQmicSimpleConvertor::stringToBlendingMode(modeStr);
```

#### AUTO 


```{c}
auto rowIt = it;
```

#### AUTO 


```{c}
const auto x = match.captured(1).toInt();
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                KisDuplicateOptionProperties option;
                option.readOptionSetting(prop->settings().data());

                prop->setValue(option.duplicate_healing);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto pi : vector) {
            pi.setCanvasRotation(rotation);
            pi.setCanvasMirroredH(mirrorX);
            pi.setCanvasMirroredV(mirrorY);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[sharedData, deviceList, levelOfDetail] () mutable {
        Q_FOREACH (KisPaintDeviceSP device, deviceList) {
            sharedData->insert(device, toQShared(device->createLodDataStruct(levelOfDetail)));
        }
    }
```

#### AUTO 


```{c}
auto *dstPixel = reinterpret_cast<KoRgbF32Traits::Pixel *>(dst);
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
                f->generate(dstCfg, rc.size(), filterConfig, helper->updater());

                // HACK ALERT!!!
                // this avoids cyclic loop with KisRecalculateGeneratorLayerJob::run()
                const_cast<KisGeneratorLayerSP &>(layer)->setDirtyWithoutUpdate({rc});

                const_cast<QSharedPointer<bool>&>(cookie).clear();
            }
```

#### AUTO 


```{c}
auto f = [](qreal t1, qreal t2, qreal t3, qreal t4, qreal sign) -> qreal
        {
            return (t1 + sign * t2) / t3 + t4;
        };
```

#### AUTO 


```{c}
const auto src3 = zip_lo(t2, t4);
```

#### LAMBDA EXPRESSION 


```{c}
[](const KisKeyframeChannel *channel, int time) {
        KIS_SAFE_ASSERT_RECOVER_RETURN(channel);
        const KisScalarKeyframeChannel* scalarChan = dynamic_cast<const KisScalarKeyframeChannel*>(channel);
        KIS_SAFE_ASSERT_RECOVER_RETURN(scalarChan);
        scalarChan->sigChannelUpdated(
                    scalarChan->affectedFrames(time),
                    scalarChan->affectedRect(time) );
    }
```

#### LAMBDA EXPRESSION 


```{c}
[interface]() {
            interface->KisStrokeStrategyUndoCommandBased::cancelStrokeCallback();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QString &family : familiesList) {
            family = family.trimmed();
            if ((family.startsWith('\"') && family.endsWith('\"')) ||
                (family.startsWith('\'') && family.endsWith('\''))) {

                family = family.mid(1, family.size() - 2);
            }
        }
```

#### AUTO 


```{c}
auto it = cache->constFind(fragment);
```

#### AUTO 


```{c}
auto boxSize = box.size();
```

#### LAMBDA EXPRESSION 


```{c}
[this](QAction* triggered){
        exportCompositions->setDefaultAction(triggered);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () mutable {
        KisNodeSP node = m_resources->currentNode();
        KisPaintDeviceSP paintDevice = node->paintDevice();
        KisPaintDeviceSP targetDevice = paintDevice;
        KisSelectionSP selection =  m_resources->activeSelection();
        bool hasIndirectPainting = supportsIndirectPainting() && m_resources->needsIndirectPainting();
        const QString indirectCompositeOp = m_resources->indirectPaintingCompositeOp();

        if (hasIndirectPainting) {
            KisIndirectPaintingSupport *indirect =
                dynamic_cast<KisIndirectPaintingSupport*>(node.data());

            if (indirect) {
                targetDevice = paintDevice->createCompositionSourceDevice();
                targetDevice->setParentNode(node);
                indirect->setCurrentColor(m_resources->currentFgColor());
                indirect->setTemporaryTarget(targetDevice);

                indirect->setTemporaryCompositeOp(m_resources->compositeOpId());
                indirect->setTemporaryOpacity(m_resources->opacity());
                indirect->setTemporarySelection(selection);

                QBitArray channelLockFlags = m_resources->channelLockFlags();
                indirect->setTemporaryChannelFlags(channelLockFlags);
            }
            else {
                hasIndirectPainting = false;
            }
        }

        QScopedPointer<KisInterstrokeDataFactory> interstrokeDataFactory(
            KisPaintOpRegistry::instance()->createInterstrokeDataFactory(m_resources->currentPaintOpPreset()));

        KIS_SAFE_ASSERT_RECOVER(!interstrokeDataFactory || !hasIndirectPainting) {
            interstrokeDataFactory.reset();
        }

        QScopedPointer<KisInterstrokeDataTransactionWrapperFactory> wrapper;

        if (interstrokeDataFactory) {
            wrapper.reset(new KisInterstrokeDataTransactionWrapperFactory(
                              interstrokeDataFactory.take(),
                              supportsContinuedInterstrokeData()));
        }

        m_transaction.reset(new KisTransaction(KUndo2MagicString(), targetDevice, nullptr,
                                               -1,
                                               wrapper.take()));

        // WARNING: masked brush cannot work without indirect painting mode!
        KIS_SAFE_ASSERT_RECOVER_NOOP(!(supportsMaskingBrush() &&
                                       m_resources->needsMaskingBrushRendering()) || hasIndirectPainting);

        if (hasIndirectPainting &&
            supportsMaskingBrush() &&
            m_resources->needsMaskingBrushRendering()) {

            const QString compositeOpId =
                m_resources->currentPaintOpPreset()->settings()->maskingBrushCompositeOp();

            m_maskingBrushRenderer.reset(new KisMaskingBrushRenderer(targetDevice, compositeOpId));

            initPainters(m_maskingBrushRenderer->strokeDevice(),
                         m_maskingBrushRenderer->maskDevice(),
                         selection,
                         hasIndirectPainting,
                         indirectCompositeOp);

        } else {
            initPainters(targetDevice, nullptr, selection, hasIndirectPainting, indirectCompositeOp);
        }

        m_targetDevice = targetDevice;
        m_activeSelection = selection;

        // sanity check: selection should be applied only once
        if (selection && !m_strokeInfos.isEmpty()) {
            KisIndirectPaintingSupport *indirect =
                dynamic_cast<KisIndirectPaintingSupport*>(node.data());
            KIS_ASSERT_RECOVER_RETURN(hasIndirectPainting || m_strokeInfos.first()->painter->selection());
            KIS_ASSERT_RECOVER_RETURN(!hasIndirectPainting || !indirect->temporarySelection() || !m_strokeInfos.first()->painter->selection());
        }
    }
```

#### AUTO 


```{c}
auto function = std::bind(&KisColorSelectorBase::slotUpdateColorAndPreview, this, _1);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &groupName : groupNames) {
            if (groupName == KoColorSet::GLOBAL_GROUP_NAME) { continue; }
            QDomElement gl = doc.createElement(KPL_GROUP_TAG);
            gl.setAttribute(KPL_GROUP_NAME_ATTR, groupName);
            root.appendChild(gl);
            saveKplGroup(doc, gl, colorSet->getGroup(groupName), colorSpaces);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& map: d->ditherOps) {
        qDeleteAll(map);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]{ this->sortByValue(SORT_ASCENDING); }
```

#### AUTO 


```{c}
auto debugEvent = [&]() {
        if (KisTabletDebugger::instance()->debugEnabled()) {
            QString pre = QString("[BLOCKED]");
            QMouseEvent *ev = static_cast<QMouseEvent*>(event);
            dbgTablet << KisTabletDebugger::instance()->eventToString(*ev,pre);
        }
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this](qreal zoomValue){
        m_d->zoomSaveCompressor->start(zoomValue);
    }
```

#### AUTO 


```{c}
const auto r = doc2->importDocument(outputFileName);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            KisStrokeStrategyUndoCommandBased::cancelStrokeCallback();
        }
```

#### CONST EXPRESSION 


```{c}
static constexpr float MIN_CHANNEL_L = 0;
```

#### LAMBDA EXPRESSION 


```{c}
[] (KisNodeSP node) {
            const bool normalCompositeMode = node->compositeOpId() == COMPOSITE_OVER;

            KisLayer *layer = dynamic_cast<KisLayer*>(node.data());
            const bool hasInheritAlpha = layer && layer->alphaChannelDisabled();
            return !normalCompositeMode && !hasInheritAlpha;
        }
```

#### AUTO 


```{c}
const auto actionName = idx.data().toString().splitRef(QLatin1Char(':')).at(1);
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
                    const auto frameData = frames->keyframeAt<KisRasterKeyframe>(i);
                    KisPaintDeviceSP dev =
                        new KisPaintDevice(*image->projection(), KritaUtils::DeviceCopyMode::CopySnapshot);
                    frameData->writeFrameToDevice(dev);
                    QByteArray p(static_cast<int>(cs->pixelSize()) * bounds.width() * bounds.height(), 0x0);
                    dev->readBytes(reinterpret_cast<quint8 *>(p.data()), image->bounds());
                    return p;
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        QRect handlesRect;

        Q_FOREACH(KisNodeSP node, m_nodes) {
            saveInitialNodeOffsets(node);
            handlesRect |= KisLayerUtils::recursiveTightNodeVisibleBounds(node);
        }

        KisStrokeStrategyUndoCommandBased::initStrokeCallback();

        emit this->sigHandlesRectCalculated(handlesRect);
        m_updateTimer.start();
    }
```

#### AUTO 


```{c}
auto constControlIt1 = mesh.constFind(ControlPointIndex(NodeIndex(0,0), ControlType::Node));
```

#### AUTO 


```{c}
auto it = std::max_element(topLevelShapes.constBegin(), topLevelShapes.constEnd(), KoShape::compareShapeZIndex);
```

#### AUTO 


```{c}
auto gradientStops = grad.stops();
```

#### AUTO 


```{c}
auto controlIt = mesh.find(ControlPointIndex(NodeIndex(0,0), ControlType::Node));
```

#### AUTO 


```{c}
auto *selectNewLayer = new KisLayerUtils::KeepNodesSelectedCommand(
        nodeManager->selectedNodes(),
        {currentNode},
        nodeManager->activeNode(),
        currentNode,
        d->m_image,
        true);
```

#### AUTO 


```{c}
auto entry = m_rows[index.row()];
```

#### AUTO 


```{c}
const auto i
```

#### AUTO 


```{c}
const auto bounds = image->bounds();
```

#### RANGE FOR STATEMENT 


```{c}
for(KoGamutMaskShape* shape: *shapeVector) {
        shape->paintStroke(painter, viewConverter, rotation());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[] (const QPair<KoResourceSP, int> &lhs,
                               const QPair<KoResourceSP, int> &rhs) {return lhs.second < rhs.second;}
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    HatchingOption option;
                    option.readOptionSetting(prop->settings().data());
                    prop->setValue(option.thickness);
                }
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    ParticleOption option;
                    option.readOptionSetting(prop->settings().data());
                    prop->setValue(option.particle_scale_y);
                }
```

#### AUTO 


```{c}
const auto x = rc.x();
```

#### LAMBDA EXPRESSION 


```{c}
[&] (KisFreehandStrokeInfo *data) {
        data->painter->paintPolygon(points);
    }
```

#### AUTO 


```{c}
auto it = m_updateData->begin();
```

#### LAMBDA EXPRESSION 


```{c}
[=](bool checked) {
            newsWidget->toggleNewsLanguage(code, checked);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
                if (selection) {
                    return selection->selectedExactRect();
                } else {
                    return node->exactBounds();
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QRect &vRect) {
        if (!m_d->isBatchUpdateActive) {
            // TODO: Implement info->dirtyViewportRect() for KisOpenGLCanvas2 to avoid updating whole canvas
            if (m_d->currentCanvasIsOpenGL) {
                m_d->savedUpdateRect |= vRect;

                // we already had a compression in frameRenderStartCompressor, so force the update directly
                slotDoCanvasUpdate();
            } else if (/* !m_d->currentCanvasIsOpenGL && */ !vRect.isEmpty()) {
                m_d->savedUpdateRect |= m_d->coordinatesConverter->viewportToWidget(vRect).toAlignedRect();

                // we already had a compression in frameRenderStartCompressor, so force the update directly
                slotDoCanvasUpdate();
            }
        }
    }
```

#### AUTO 


```{c}
const auto& patch
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
            prop->setValue(prop->settings()->paintOpOpacity());
        }
```

#### AUTO 


```{c}
const auto v4 = xsimd::bitwise_cast<uint_v>(xsimd::nearbyint_as_int(alpha));
```

#### LAMBDA EXPRESSION 


```{c}
LAZY_STATIC_CATEGORY_DISPLAY_NAME("dark")
```

#### AUTO 


```{c}
const auto dataStride = width - columnsToWork;
```

#### AUTO 


```{c}
auto estimateSegment =
            [&resultParam,
             &resultSegment,
             &resultDistance,
             &resultRemovedNodeIndex] (const KisBezierTransformMesh::segment_iterator &segment,
                               const QPoint &removedNodeOffset,
                               const QPointF &pt,
                               KisBezierTransformMesh &mesh)
        {
            if (segment != mesh.endSegments()) {

                qreal distance = 0.0;
                qreal param = KisBezierUtils::nearestPoint({segment.p0(), segment.p1(), segment.p2(), segment.p3()}, pt, &distance);

                if (distance < resultDistance) {
                    resultDistance = distance;
                    resultParam = param;
                    resultSegment = segment;
                    resultRemovedNodeIndex = segment.firstNodeIndex() + removedNodeOffset;
                }
            }
        };
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &groupName : getGroupNames()) {
        if (d->groups.contains(groupName)) {
            if ((int)y < d->groups[groupName].rowCount()) {
                return d->groups[groupName].getEntry(x, y);
            } else {
                y -= d->groups[groupName].rowCount();
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[srcDstPairs, copy, moveEmptyFrames] () -> KUndo2Command* {
                bool result = false;

                QScopedPointer<KUndo2Command> cmd(new KUndo2Command());

                using MoveChain = QList<FrameItem>;
                QHash<FrameItem, MoveChain> moveMap;
                Q_FOREACH (const FrameMovePair &pair, srcDstPairs) {
                    moveMap.insert(pair.first, {pair.second});
                }

                auto it = moveMap.begin();
                while (it != moveMap.end()) {
                    MoveChain &chain = it.value();
                    const FrameItem &previousFrame = chain.last();

                    auto tailIt = moveMap.find(previousFrame);

                    if (tailIt == it || tailIt == moveMap.end()) {
                        ++it;
                        continue;
                    }

                    chain.append(tailIt.value());
                    tailIt = moveMap.erase(tailIt);
                    // no incrementing! we are going to check the new tail now!
                }

                for (it = moveMap.begin(); it != moveMap.end(); ++it) {
                    MoveChain &chain = it.value();
                    chain.prepend(it.key());
                    KIS_SAFE_ASSERT_RECOVER(chain.size() > 1) { continue; }

                    bool isCycle = false;
                    if (chain.last() == chain.first()) {
                        isCycle = true;
                        chain.takeLast();
                    }

                    auto frameIt = chain.rbegin();

                    FrameItem dstItem = *frameIt++;

                    while (frameIt != chain.rend()) {
                        FrameItem srcItem = *frameIt++;

                        if (!isCycle) {
                            moveOneFrameItem(srcItem, dstItem, copy, moveEmptyFrames, cmd.data());
                        } else {
                            swapOneFrameItem(srcItem, dstItem, cmd.data());
                        }

                        dstItem = srcItem;
                        result = true;
                    }
                }

                return result ? new KisCommandUtils::SkipFirstRedoWrapper(cmd.take()) : nullptr;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (cmsFloat32Number value : inputValues) {
        cmsFloat32Number cValue = value;

        /*
         * sRGB
         * for 1  >  Lc  >=  β
         *  V = α * Lc( 1÷2.4 ) − ( α − 1 )
         * for β  >  Lc  >=  0
         *  V = 12.92 * Lc
         */

        if (value > 0.0031308){
            cValue = 1.055 * powf(value, 1/2.4) - (.055) ;
        } else if (value < 0.0031308 && value > 0.0){
            cValue = 12.92 * value;
        } else {
            cValue = 0.0;
        }

        /*
        double lValue;
        if (cValue > 0.04045){
            lValue = powf((cValue)*1/1.055 + (.055/1.055), 2.4);
        } else {
            lValue = cValue * 1/12.92;
        }
        */

        cmsFloat32Number lValue = cmsEvalToneCurveFloat(curve, cValue);
        QVERIFY2(fabs(lValue - value) < 0.000001, QString("Values don't match for sRGB: %1 %2").arg(value).arg(lValue).toLatin1());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &node : *nodes) {
                if (node && node->paintDevice()) {
                    KisSelectionSP selection =
                        p->m_viewManager->image()->globalSelection();

                    QRect cropRect = [&]() {
                        if (selection) {
                            return selection->selectedExactRect();
                        } else {
                            return node->exactBounds();
                        }
                    }();

                    size.setWidth(std::max(size.width(), cropRect.width()));
                    size.setHeight(std::max(size.height(), cropRect.height()));
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[image, node, channelId, time, copy] () mutable -> KUndo2Command* {
                bool result = false;

                QScopedPointer<KUndo2Command> cmd(new KUndo2Command());

                KisKeyframeChannel *channel = node->getKeyframeChannel(channelId);
                quint8 originalOpacity = node->opacity();
                bool createdChannel = false;

                if (!channel) {
                    node->enableAnimation();
                    channel = node->getKeyframeChannel(channelId, true);
                    if (!channel) return nullptr;

                    createdChannel = true;
                }

                if (copy && channel->activeKeyframeAt(time)) {
                    if (!channel->keyframeAt(time)) {
                        channel->copyKeyframe(channel->activeKeyframeTime(time), time, cmd.data());
                        result = true;
                    }
                } else {
                    if (channel->keyframeAt(time) && !createdChannel) {
                        if (image->animationInterface()->currentTime() == time && channelId == KisKeyframeChannel::Raster.id()) {

                            //shortcut: clearing the image instead
                            KisPaintDeviceSP device = node->paintDevice();
                            if (device) {
                                const QRect dirtyRect = device->extent();

                                KisTransaction transaction(kundo2_i18n("Clear"), device, cmd.data());
                                device->clear();
                                (void) transaction.endAndTake(); // saved as 'parent'

                                node->setDirty(dirtyRect);

                                result = true;
                            }
                        }
                    } else {
                        channel->addKeyframe(time, cmd.data());
                        result = true;
                    }
                }

                // when a new opacity keyframe is created, the opacity is set to 0
                // this makes sure to use the opacity that was previously used
                // maybe there is a better way to do this
                node->setOpacity(originalOpacity);

                return result ? new KisCommandUtils::SkipFirstRedoWrapper(cmd.take()) : nullptr;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () { return this->brush()->userEffectiveSize(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QRect &vRect) {
        if (!m_d->isBatchUpdateActive) {
            // TODO: Implement info->dirtyViewportRect() for KisOpenGLCanvas2 to avoid updating whole canvas
            if (m_d->currentCanvasIsOpenGL) {
                m_d->savedUpdateRect = QRect();

                // we already had a compression in frameRenderStartCompressor, so force the update directly
                slotDoCanvasUpdate();
            } else if (/* !m_d->currentCanvasIsOpenGL && */ !vRect.isEmpty()) {
                m_d->savedUpdateRect = m_d->coordinatesConverter->viewportToWidget(vRect).toAlignedRect();

                // we already had a compression in frameRenderStartCompressor, so force the update directly
                slotDoCanvasUpdate();
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(KoGamutMaskShape* shape: *shapeVector) {
        shape->paintStroke(painter);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractButton *button : m_d->colorButtonGroup->buttons()) {
            button->installEventFilter(m_d->dragFilter);
        }
```

#### AUTO 


```{c}
auto insertIt = std::upper_bound(indexedSiblings.begin(),
                                     indexedSiblings.end(),
                                     IndexedShape(m_d->container));
```

#### AUTO 


```{c}
auto node1 = doc->image()->root()->firstChild();
```

#### AUTO 


```{c}
auto *removeLayerCmd = new KisLayerUtils::SimpleRemoveLayers(extraNodes, d->m_image);
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    CurveOption option;
                    option.readOptionSetting(prop->settings().data());
                    option.curve_stroke_history_size = prop->value().toInt();
                    option.writeOptionSetting(prop->settings().data());
                }
```

#### AUTO 


```{c}
auto rserver = KisResourceServerProvider::instance()->workspaceServer();
```

#### AUTO 


```{c}
auto it = begin;
```

#### DECLTYPE 


```{c}
typedef decltype(rect.x()) CoordType;
```

#### LAMBDA EXPRESSION 


```{c}
[] (KisDabRenderingJobSP job, int seqNo) {
                             return job->seqNo < seqNo;
                         }
```

#### AUTO 


```{c}
auto getChildContent_i18n = [=](QString node){return quietlyTranslate(getChildContent(actionXml, node));};
```

#### RANGE FOR STATEMENT 


```{c}
for (const KXMLGUIClient *c : clients) {
        if (!c) {
            continue;
        }
        if (auto collection = c->actionCollection()) {
            actionCollections.append(collection);
            actionsCount += collection->count();
        }
    }
```

#### AUTO 


```{c}
auto it = nonCancellableFinishJobs.begin();
```

#### LAMBDA EXPRESSION 


```{c}
[image] (KisNodeSP node) {
                                               node->setImage(image);
                                           }
```

#### RANGE FOR STATEMENT 


```{c}
for(KoShape* sh: shapes) {
        KoGamutMaskShape* maskShape = new KoGamutMaskShape(sh);
        targetVector.append(maskShape);
    }
```

#### AUTO 


```{c}
auto referenceImageLayer = document()->referenceImagesLayer();
```

#### RANGE FOR STATEMENT 


```{c}
for (KoGradientSegment *segment : gradient->segments()) {
            QGradientStop stop;
            
            stop = toQGradientStop(segment->startColor(), segment->startType(), segment->startOffset(), canvasResourcesInterface);
            if (!qFuzzyCompare(stop.first, lastStop.first) || stop.second != lastStop.second) {
                stops << stop;
                lastStop = stop;
            }
            
            stop = toQGradientStop(segment->endColor(), segment->endType(), segment->endOffset(), canvasResourcesInterface);
            if (!qFuzzyCompare(stop.first, lastStop.first) || stop.second != lastStop.second) {
                stops << stop;
                lastStop = stop;
            }
        }
```

#### AUTO 


```{c}
auto it = m_nodes.begin() + column;
```

#### LAMBDA EXPRESSION 


```{c}
[this, levelOfDetail, updateData, useHoldUI, commandGroup]() {

        fetchAllUpdateRequests(levelOfDetail, updateData);

        executeAndAddCommand(new KisDisableDirtyRequestsCommand(m_d->updatesFacade, KisUpdateCommandEx::FINALIZING), commandGroup, KisStrokeJobData::BARRIER);
        executeAndAddCommand(new KisUpdateCommandEx(m_d->updateDataForUndo, m_d->updatesFacade, KisUpdateCommandEx::FINALIZING, m_d->commandUpdatesBlockerCookie), commandGroup, KisStrokeJobData::BARRIER);

        if (useHoldUI) {
            executeAndAddCommand(new KisHoldUIUpdatesCommand(m_d->updatesFacade, KisCommandUtils::FlipFlopCommand::FINALIZING), commandGroup, KisStrokeJobData::BARRIER);
        }

        /**
         * We also emit the updates manually, because KisUpdateCommandEx is
         * still blocked by m_d->commandUpdatesBlockerCookie (for easy undo
         * purposes)
         */
        for (auto it = updateData->begin(); it != updateData->end(); ++it) {
            KisTransformMask *transformMask = dynamic_cast<KisTransformMask*>(it->first.data());

            if (transformMask &&
                    ((levelOfDetail <= 0 && !transformMask->transformParams()->isAffine()) ||
                     (levelOfDetail <= 0 && m_d->previewLevelOfDetail > 0))) {
                transformMask->threadSafeForceStaticImageUpdate();
            } else {
                m_d->updatesFacade->refreshGraphAsync(it->first, it->second);
            }

        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[shared, progress](){
                shared->filter()->processImpl(shared->filterDevice, shared->processRect,
                                         shared->filterConfig().data(),
                                         progress->updater());
            }
```

#### AUTO 


```{c}
auto end = adapters.constEnd();
```

#### LAMBDA EXPRESSION 


```{c}
[](bool dropFrames){
            KisConfig cfg(false);
            if (dropFrames != cfg.animationDropFrames()) {
                cfg.setAnimationDropFrames(dropFrames);
                //updatePlaybackStatistics();
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](qreal){
        viewport()->update();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[] (QString a) {Q_UNUSED(a); return false;}
```

#### AUTO 


```{c}
auto it = rhs.m_abrBrushes->begin();
```

#### AUTO 


```{c}
auto it = subChunks.begin();
```

#### LAMBDA EXPRESSION 


```{c}
[&extraNodesToRemove] (KisNodeSP node) {
                                            extraNodesToRemove.insert(node);
                                        }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
                QString finalFileName = QString(m_recordPath % "_%1.webm").arg(++m_recordCounter, 7, 10, QChar('0'));
                Encoder* m_encoder = new Encoder();
                m_encoder->init(finalFileName.toStdString().c_str(), m_canvas->image()->width(),
                                m_canvas->image()->height());

                while (!m_shouldStop) {
                    m_fullSemaphore->wait();

                    Payload &p = m_queue[m_tail];

                    if (p.m_command == Payload::Command::Finish) {
                        break;
                    }

                    m_encoder->pushFrame(p.m_data);

                    m_tail = (m_tail + 1) % 5;

                    m_emptySemaphore->notify();
                    static int counter = 0;
                    infoPlugins << "Frame pushed" << counter++;
                }

                if (m_encoder) {
                    m_encoder->finish();
                    delete m_encoder;
                    m_encoder = nullptr;
                }
                infoPlugins << "Thread closed";
            }
```

#### AUTO 


```{c}
auto pixmap = [&](int size) {
        QPixmap pix(size, size);
        pix.fill(Qt::black);
        QPainter p;
        p.begin(&pix);
        const int itemSize = size / 2 - 1;
        p.fillRect(1, 1, itemSize, itemSize, activeWindow.background());
        p.fillRect(1 + itemSize, 1, itemSize, itemSize, activeButton.background());
        p.fillRect(1, 1 + itemSize, itemSize, itemSize, activeView.background());
        p.fillRect(1 + itemSize, 1 + itemSize, itemSize, itemSize, activeSelection.background());
        p.end();
        result.addPixmap(pix);
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &text : list) {
                QRect r = option.fontMetrics.boundingRect(text);
                r.setWidth(r.width() + 8);
                r.setHeight(r.height() + 4);
                btns.append({r, text});
            }
```

#### LAMBDA EXPRESSION 


```{c}
[node, selection] () {
                        KisPaintDeviceSP device = node->paintDevice();

                        KisTransaction transaction(kundo2_noi18n("internal-clear-command"), device);

                        QRect dirtyRect;
                        if (selection) {
                            dirtyRect = selection->selectedRect();
                            device->clearSelection(selection);
                        } else {
                            dirtyRect = device->extent();
                            device->clear();
                        }

                        device->setDirty(dirtyRect);
                        return transaction.endAndTake();
                    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KisNodeSP node) {
                                                 return
                                                     !KisLayerUtils::checkIsCloneOf(node, m_nodes) &&
                                                     node->isEditable(false);
                                             }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (int col, int row) {
                            KisTileSP tile = dm.getTile(col, row, false);
                            tile->lockForRead();
                            tile->unlockForRead();
                        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& patch: row) {
            m_array.last().append(new SvgMeshPatch(*patch));
        }
```

#### CONST EXPRESSION 


```{c}
constexpr int SPLASH_HEIGHT_LOADING = 480;
```

#### CONST EXPRESSION 


```{c}
constexpr int valueRole = Qt::UserRole + 1;
```

#### AUTO 


```{c}
auto offsetSegment =
            [this] (KisBezierTransformMesh::segment_iterator it,
                    qreal t,
                    const QPointF &offset) {

            QPointF offsetP1;
            QPointF offsetP2;

            std::tie(offsetP1, offsetP2) =
                KisBezierUtils::offsetSegment(t, offset);


            smartMoveControl(*m_d->currentArgs.meshTransform(), it.itP1().controlIndex(), offsetP1, KisSmartMoveMeshControlMode::MoveSymmetricLock, m_d->currentArgs.meshScaleHandles());
            smartMoveControl(*m_d->currentArgs.meshTransform(), it.itP2().controlIndex(), offsetP2, KisSmartMoveMeshControlMode::MoveSymmetricLock, m_d->currentArgs.meshScaleHandles());
        };
```

#### AUTO 


```{c}
auto it = std::find_if(m_cachedResources.begin(),
                               m_cachedResources.end(),
                               [this, md5] (KoResourceSP res) {
                                   return res->resourceType().first == this->m_resourceType &&
                                       res->md5Sum() == md5;
                               });
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    KisSprayOptionProperties option;
                    option.readOptionSetting(prop->settings().data());

                    prop->setValue(int(option.particleCount()));
                }
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    BrushSizeOption option;
                    option.readOptionSetting(prop->settings().data());

                    prop->setValue(int(option.brush_rotation));
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KoResource *r : rlist) {
        nameSet.insert(r->filename());
    }
```

#### AUTO 


```{c}
auto it = std::unique(rects.begin(), rects.end());
```

#### AUTO 


```{c}
auto searchType = KoResourcePaths::Recursive | KoResourcePaths::NoDuplicates;
```

#### LAMBDA EXPRESSION 


```{c}
[this, applyTransform]() {
        Q_FOREACH (KisSelectionSP selection, m_deactivatedSelections) {
            selection->setVisible(true);
        }

        if (m_deactivatedOverlaySelectionMask) {
            m_deactivatedOverlaySelectionMask->selection()->setVisible(true);
            m_deactivatedOverlaySelectionMask->setDirty();
        }

        if (applyTransform) {
            KisStrokeStrategyUndoCommandBased::finishStrokeCallback();
        } else {
            KisStrokeStrategyUndoCommandBased::cancelStrokeCallback();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, dirtyRects] () {
                this->targetNode()->setDirty(dirtyRects);
            }
```

#### AUTO 


```{c}
auto source = config.resourcesInterface()->source<KoPattern>(ResourceType::Patterns);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            Q_FOREACH (KisTransformMask *mask, transformMaskCacheHash.keys()) {
                mask->overrideStaticCacheDevice(0);
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[processResults](){
       processResults->finish = true;
    }
```

#### AUTO 


```{c}
auto *plugin = m_pluginManager->plugin(row);
```

#### AUTO 


```{c}
auto restoreTemporaryHiddenNodes = [this] () {
        Q_FOREACH (KisNodeSP node, m_hiddenProjectionLeaves) {
            node->projectionLeaf()->setTemporaryHiddenFromRendering(false);
            if (KisDelayedUpdateNodeInterface *delayedNode = dynamic_cast<KisDelayedUpdateNodeInterface*>(node.data())) {
                delayedNode->forceUpdateTimedNode();
            } else {
                node->setDirty();
            }
        }
    };
```

#### LAMBDA EXPRESSION 


```{c}
[&jobsData](KisNodeSP node) {
                            jobsData << new Private::AdditionalProcessNode(node);
                        }
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    KisDuplicateOptionProperties option;
                    option.readOptionSetting(prop->settings().data());
                    option.duplicate_healing = prop->value().toBool();
                    option.writeOptionSetting(prop->settings().data());
                }
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    KisSprayOptionProperties option;
                    option.readOptionSetting(prop->settings().data());

                    prop->setValue(int(option.particleCount));
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &name) {
            QStringList possibleNames;
            possibleNames << name;
            possibleNames << QDir::cleanPath(QDir(m_context.xmlBaseDir()).absoluteFilePath(name));
            for (QString fileName : possibleNames) {
                QFile file(fileName);
                if (file.exists()) {
                    file.open(QIODevice::ReadOnly);
                    return file.readAll();
                }
            }
            return QByteArray();
        }
```

#### AUTO 


```{c}
auto saturationIterator = oldSaturations.begin();
```

#### AUTO 


```{c}
auto it = finishedJobIt + 1;
```

#### LAMBDA EXPRESSION 


```{c}
[dialog, segments, this]() mutable
                      {
                          if (m_selectedHandle.index == 0) {
                              segments[0]->setStartType(COLOR_ENDPOINT);
                              segments[0]->setStartColor(dialog->getCurrentColor());
                          } else {
                              segments[m_selectedHandle.index - 1]->setEndType(COLOR_ENDPOINT);
                              segments[m_selectedHandle.index - 1]->setEndColor(dialog->getCurrentColor());
                              if (m_selectedHandle.index < segments.size()) {
                                  segments[m_selectedHandle.index]->setStartType(COLOR_ENDPOINT);
                                  segments[m_selectedHandle.index]->setStartColor(dialog->getCurrentColor());
                              }
                          }
                          emit selectedHandleChanged();
                          emit updateRequested();
                      }
```

#### AUTO 


```{c}
auto it = m_d->cachedPaintDevices.begin();
```

#### AUTO 


```{c}
auto it = rangeBegin;
```

#### RANGE FOR STATEMENT 


```{c}
for(QModelIndex index: list) {
        bool active = index.data(Qt::UserRole + KisAllResourcesModel::ResourceActive).toBool();
        allActive = allActive && active;
        allInactive = allInactive && !active;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&numFetches](const QString &name) {
            numFetches++;
            QString fileName = TestUtil::fetchDataFileLazy(name);
            if (fileName.isEmpty()) {
                fileName = TestUtil::fetchDataFileLazy("icc/" + name);
            }
            QFile file(fileName);
            KIS_ASSERT(file.exists());
            file.open(QIODevice::ReadOnly);
            return file.readAll();
        }
```

#### AUTO 


```{c}
auto memorySegment
```

#### LAMBDA EXPRESSION 


```{c}
[sharedState, sharedWriteLock, dst, parentCommand, transactionText, timedID] () {
            Q_UNUSED(sharedWriteLock); // just a RAII holder object for the lock

            /**
             * Move tool may not have an undo adapter
             */
             if (parentCommand) {
                 sharedState->transaction.reset(
                     new KisTransaction(transactionText, dst, parentCommand, timedID));
             }
        }
```

#### CONST EXPRESSION 


```{c}
static constexpr int showControlsTimerDuration{200};
```

#### AUTO 


```{c}
const auto *frames = image->projection()->keyframeChannel();
```

#### AUTO 


```{c}
auto hoveredProperty = d->propForMousePos(index, helpEvent->pos(), newOption);
```

#### AUTO 


```{c}
auto sensor
```

#### AUTO 


```{c}
auto fuzzyCompareLine = [&] (QLineF a, QLineF b) -> bool {
            return fuzzyComparePoint(a.p1(), b.p1()) && fuzzyComparePoint(a.p2(), b.p2()); };
```

#### AUTO 


```{c}
const auto width = image->m_width;
```

#### LAMBDA EXPRESSION 


```{c}
[dockWidget](){
                dockWidget->setFloating(!dockWidget->isFloating());
            }
```

#### LAMBDA EXPRESSION 


```{c}
[&newNodes](KisNodeSP node) { newNodes << node; }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        // When dealing with animated transform mask layers, create keyframe and save the command for undo.
        Q_FOREACH (KisNodeSP node, m_d->processedNodes) {
            if (KisTransformMask* transformMask = dynamic_cast<KisTransformMask*>(node.data())) {
                QSharedPointer<KisInitializeTransformMaskKeyframesCommand> addKeyCommand(new KisInitializeTransformMaskKeyframesCommand(transformMask,
                                                                                                                                        KisTransformMaskParamsInterfaceSP(
                                                                                                                                            new KisTransformMaskAdapter(m_d->initialTransformArgs))));
                runAndSaveCommand( addKeyCommand, KisStrokeJobData::CONCURRENT, KisStrokeJobData::NORMAL);
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {
            return !m_d->proofingTransform &&
                m_d->proofingConfig &&
                m_d->proofingConfig->conversionFlags.testFlag(KoColorConversionTransformation::SoftProofing);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    KisCurveOptionProperties option;
                    option.readOptionSetting(prop->settings().data());

                    prop->setValue(option.curve_stroke_history_size);
                }
```

#### AUTO 


```{c}
auto pointIt = subpath->constBegin();
```

#### LAMBDA EXPRESSION 


```{c}
[this, previousLevelsCurves]()
        {
            // We mantain a pointer to the active levels info in m_levelsCurves
            // so we use this loop instead of the asignment operator to avoid
            // invalidation of the pointer
            for (int i = 0; i < m_levelsCurves.size(); ++i) {
                m_levelsCurves[i] = previousLevelsCurves[i];
            }
            updateWidgets();
            emit sigConfigurationItemChanged();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    ExperimentOption option;
                    option.readOptionSetting(prop->settings().data());
                    option.displacement = prop->value().toInt();
                    option.writeOptionSetting(prop->settings().data());
                }
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    KisSprayProperties option;
                    option.readOptionSetting(prop->settings().data());

                    prop->setValue(option.spacing);
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KoColorSet *palette : m_d->doc->paletteList()) {
        if (!palette->isGlobal()) {
            QDomElement eFile =  doc.createElement("palette");
            eFile.setAttribute("filename", palette->filename());
            ePalette.appendChild(eFile);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        if (m_d->previewLevelOfDetail > 0) {
            QVector<KisStrokeJobData*> lodSyncJobs;
            KisSyncLodCacheStrokeStrategy::createJobsData(lodSyncJobs,
                                                          m_d->imageRoot,
                                                          m_d->previewLevelOfDetail,
                                                          m_d->devicesCacheHash.values() +
                                                          m_d->transformMaskCacheHash.values());

            for (auto it = lodSyncJobs.begin(); it != lodSyncJobs.end(); ++it) {
                (*it)->setLevelOfDetailOverride(m_d->previewLevelOfDetail);
            }

            addMutatedJobs(lodSyncJobs);
        }
    }
```

#### AUTO 


```{c}
auto *layerNameCmd =
                    KisQmicImportTools::applyLayerNameChanges(*d->m_images[i],
                                                              paintLayer.data(),
                                                              d->m_selection);
```

#### LAMBDA EXPRESSION 


```{c}
[&] (const QPointF &globalPoint, const QPointF &expectedLocalPoint) {
        const qreal eps = 1e-3;
        const QPointF local = KisBezierUtils::calculateLocalPos(patch.points, globalPoint);

        bool result = true;

        if (!KisAlgebra2D::fuzzyPointCompare(local, expectedLocalPoint, eps)) {
            qDebug() << "Failed to find local point:" << ppVar(globalPoint) << ppVar(local) << ppVar(expectedLocalPoint);
            result = false;
        }

        return result;
    }
```

#### AUTO 


```{c}
auto *buf = xsimd::vector_aligned_malloc<quint8>(vectorInc);
```

#### RANGE FOR STATEMENT 


```{c}
for (KisOptionCollectionWidgetWrapper *widgetWrapper : m_d->widgetWrappers) {
        widgetWrapper->setWidgetMargin(margin);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    prop->settings()->setPaintOpOpacity(prop->value().toReal());
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KisCubicCurve &curve : configBC->curves()) {
        isIdentityList.append(curve.isIdentity());
    }
```

#### AUTO 


```{c}
auto nextIt = nextRowExtra.begin();
```

#### LAMBDA EXPRESSION 


```{c}
[this](){
        QGuiApplication::clipboard()->setText(m_page->txtBugInfo->toPlainText());
        m_page->txtBugInfo->selectAll(); // feedback
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    KisSprayProperties option;
                    option.readOptionSetting(prop->settings().data());
                    option.coverage = prop->value().toReal();
                    option.writeOptionSetting(prop->settings().data());
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &text : list) {
                QRect r = option.fontMetrics.boundingRect(text);
                r.setWidth(r.width() + 8);
                btns.append({r, text});
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KisLevelsCurve &levelsCurve : config_->levelsCurves()) {
            isIdentityList.append(levelsCurve.isIdentity());
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&](KoCanvasResource::CanvasResourceId res, KoFlake::FillVariant fill) {
        KoShapeFillWrapper wrapper(currentShapes(), fill);
        if (!wrapper.color().isValid()) {
            return;
        }
        KoColor color;
        color.fromQColor(wrapper.color());
        uploadColorToResourceManager(res, fill, color);
    }
```

#### AUTO 


```{c}
const auto fileInfo = QFileInfo(resource->filename());
```

#### LAMBDA EXPRESSION 


```{c}
[this, applyTransform]() {
        Q_FOREACH (KisSelectionSP selection, m_deactivatedSelections) {
            selection->setVisible(true);
        }

        Q_FOREACH (KisNodeSP node, m_hiddenProjectionLeaves) {
            node->projectionLeaf()->setTemporaryHiddenFromRendering(false);
            if (!applyTransform) {
                node->setDirty();
            }
        }

        if (m_deactivatedOverlaySelectionMask) {
            m_deactivatedOverlaySelectionMask->selection()->setVisible(true);
            m_deactivatedOverlaySelectionMask->setDirty();
        }

        if (applyTransform) {
            KisStrokeStrategyUndoCommandBased::finishStrokeCallback();
        } else {
            KisStrokeStrategyUndoCommandBased::cancelStrokeCallback();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            m_d->commandUpdatesBlockerCookie.reset();
            undoTransformCommands(0);
            undoAllCommands();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &node : *nodes) {
         if (node && node->paintDevice()) {
            KisSelectionSP selection = p->m_viewManager->image()->globalSelection();

            QRect cropRect = [&]() {
                if (selection) {
                    return selection->selectedExactRect();
                } else {
                    return node->exactBounds();
                }
            }();

            dbgPlugins << "Converting node" << node->name() << cropRect;

            const QRectF mappedRect = KisAlgebra2D::mapToRect(cropRect).mapRect(rc);
            const QRect resultRect = mappedRect.toAlignedRect();

            QString noParenthesisName(node->name());
            noParenthesisName.replace(QChar('('), QChar(21)).replace(QChar(')'), QChar(22));

            const auto translatedMode = KisQmicSimpleConvertor::blendingModeToString(node->compositeOpId());

            const QString name = QString("mode(%1),opacity(%2),pos(%3,%4),name(%5)")
                               .arg(translatedMode)
                               .arg(node->percentOpacity())
                               .arg(cropRect.x())
                               .arg(cropRect.y())
                               .arg(noParenthesisName);

            auto m = KisQMicImageSP::create(name, resultRect.width(), resultRect.height(), 4);
            p->m_sharedMemorySegments << m;

            {
                QMutexLocker lock(&m->m_mutex);

                KisQmicSimpleConvertor::convertToGmicImageFast(
                    node->paintDevice(),
                    *m.data(),
                    resultRect);
            }

            message << m;
        }
    }
```

#### AUTO 


```{c}
auto resultIt = beginIt;
```

#### AUTO 


```{c}
auto metaDataStore = [&]() -> std::unique_ptr<KisMetaData::Store> {
            KisExifInfoVisitor exivInfoVisitor;
            exivInfoVisitor.visit(image->rootLayer().data());
            if (exivInfoVisitor.metaDataCount() == 1) {
                return std::make_unique<KisMetaData::Store>(*exivInfoVisitor.exifInfo());
            } else {
                return {};
            }
        }();
```

#### LAMBDA EXPRESSION 


```{c}
[](KoShape *s){ return 100.0 * (1.0 - s->transparency()); }
```

#### LAMBDA EXPRESSION 


```{c}
[&](KisNodeSP item) {
                    auto *paintLayer =
                        dynamic_cast<KisPaintLayer *>(item.data());
                    if (paintLayer
                        && paintLayer->visible(false) == visibility) {
                        r->append(item);
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (QWindow* window: QGuiApplication::topLevelWindows()) {
        if (window->geometry().topLeft() != QPoint(0, 0)) {
            // We are using reversed values. Because geometry returned is not the updated one,
            // but the previous one.
            int screenHeight = screen->geometry().width();
            int screenWidth = screen->geometry().height();

            // scaling
            int new_x = (window->position().x() * screenWidth) / screenHeight;
            int new_y = (window->position().y() * screenHeight) / screenWidth;

            // window width or height shouldn't change
            int winWidth = window->geometry().width();
            int winHeight = window->geometry().height();

            // Try best to not let the window go beyond screen.
            if (new_x > screenWidth - winWidth) {
                new_x = screenWidth - winWidth;
                if (new_x < 0)
                    new_x = 0;
            }
            if (new_y > screenHeight - winHeight) {
                new_y = screenHeight - winHeight;
                if (new_y < 0)
                    new_y = 0;
            }

            window->setPosition(QPoint(new_x, new_y));
        }
    }
```

#### AUTO 


```{c}
auto it = subtasks.begin();
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    ParticleOption option;
                    option.readOptionSetting(prop->settings().data());

                    prop->setValue(int(option.particle_iterations));
                }
```

#### AUTO 


```{c}
auto rserver = KisResourceServerProvider::instance()->workspaceServer(false);
```

#### LAMBDA EXPRESSION 


```{c}
[image, node, channelId, time, copy] () mutable -> KUndo2Command* {
                bool result = false;

                QScopedPointer<KUndo2Command> cmd(new KUndo2Command());

                KisKeyframeChannel *channel = node->getKeyframeChannel(channelId);
                quint8 originalOpacity = node->opacity();
                bool createdChannel = false;

                if (!channel) {
                    node->enableAnimation();
                    channel = node->getKeyframeChannel(channelId, true);
                    if (!channel) return nullptr;

                    createdChannel = true;
                }

                if (copy) {
                    if (!channel->keyframeAt(time)) {
                        KisKeyframeSP srcFrame = channel->activeKeyframeAt(time);
                        channel->copyKeyframe(srcFrame, time, cmd.data());
                        result = true;
                    }
                } else {
                    if (channel->keyframeAt(time) && !createdChannel) {
                        if (image->animationInterface()->currentTime() == time && channelId == KisKeyframeChannel::Content.id()) {

                            //shortcut: clearing the image instead
                            KisPaintDeviceSP device = node->paintDevice();
                            if (device) {
                                const QRect dirtyRect = device->extent();

                                KisTransaction transaction(kundo2_i18n("Clear"), device, cmd.data());
                                device->clear();
                                (void) transaction.endAndTake(); // saved as 'parent'

                                node->setDirty(dirtyRect);

                                result = true;
                            }
                        }
                    } else {
                        channel->addKeyframe(time, cmd.data());
                        result = true;
                    }
                }

                // when a new opacity keyframe is created, the opacity is set to 0
                // this makes sure to use the opacity that was previously used
                // maybe there is a better way to do this
                node->setOpacity(originalOpacity);

                return result ? new KisCommandUtils::SkipFirstRedoWrapper(cmd.take()) : nullptr;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
            prop->setValue(prop->settings()->paintOpFlow());
        }
```

#### AUTO 


```{c}
auto writeFunc = [this] (int col, int row) {
                            KisTileSP tile = dm.getTile(col, row, true);
                            tile->lockForWrite();
                            tile->unlockForWrite();
                        };
```

#### AUTO 


```{c}
auto setColorFn = [dialog, stops, this]() mutable
                      {
                          stops[m_selectedStop].type = COLORSTOP;
                          stops[m_selectedStop].color = dialog->getCurrentColor();
                          m_gradient->setStops(stops);
                          emit sigSelectedStop(m_selectedStop);
                          emit updateRequested();
                      };
```

#### RANGE FOR STATEMENT 


```{c}
for (QLineF &line: m_snapLines) {
                painter.drawLine(line);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    GridOption option;
                    option.readOptionSetting(prop->settings().data());

                    prop->setValue(int(option.grid_division_level));
                }
```

#### AUTO 


```{c}
auto minDimension(Size size) -> decltype(size.width()) {
    return qMin(size.width(), size.height());
}
```

#### RANGE FOR STATEMENT 


```{c}
for (auto action : actionList) {
        temp.push_back({action.first, action.second, 0});
    }
```

#### AUTO 


```{c}
ORDER_BY(isHDRFormat(lhs.format), isHDRFormat(rhs.format))
```

#### AUTO 


```{c}
auto it = m_d->shapes.begin();
```

#### AUTO 


```{c}
auto it5 = forest.insert(childEnd(it3), 5);
```

#### AUTO 


```{c}
auto it = m_fileEntries.constBegin();
```

#### LAMBDA EXPRESSION 


```{c}
[minPixel, scale](quint8 pixel) {
                                       return (quint8((pixel - minPixel) * scale));
                                   }
```

#### AUTO 


```{c}
const auto isAvailable = [](KisNodeSP node) -> bool {
        auto *paintLayer = dynamic_cast<KisPaintLayer *>(node.data());
        return paintLayer && paintLayer->visible(false);
    };
```

#### AUTO 


```{c}
auto it = beginSegments();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        Q_FOREACH (KisSelectionSP selection, this->deactivatedSelections) {
            selection->setVisible(true);
        }

        if (deactivatedOverlaySelectionMask) {
            deactivatedOverlaySelectionMask->selection()->setVisible(true);
            deactivatedOverlaySelectionMask->setDirty();
        }
    }
```

#### AUTO 


```{c}
auto it = std::begin(jobs);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        Q_FOREACH (KisSelectionSP selection, m_d->deactivatedSelections) {
            selection->setVisible(true);
        }

        if (m_d->deactivatedOverlaySelectionMask) {
            m_d->deactivatedOverlaySelectionMask->selection()->setVisible(true);
            m_d->deactivatedOverlaySelectionMask->setDirty();
        }
    }
```

#### AUTO 


```{c}
auto ds = w->dockerState();
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        QString name;
        auto rserver = KisResourceServerProvider::instance()->workspaceServer();

        KisWorkspaceResourceSP workspace(new KisWorkspaceResource(""));
        workspace->setDockerState(m_this->saveState());
        d->viewManager->canvasResourceProvider()->notifySavingWorkspace(workspace);
        workspace->setValid(true);
        QString saveLocation = rserver->saveLocation();

        QFileInfo fileInfo(saveLocation + "/" + name + workspace->defaultFileExtension());

        KisResourceModel resourceModel(ResourceType::Workspaces);

        workspace->setFilename(fileInfo.fileName());
        workspace->setName(name);

        KisResourceUserOperations::addResourceWithUserInput(this, &resourceModel, workspace);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        auto info{std::make_unique<JxlBasicInfo>()};
        JxlEncoderInitBasicInfo(info.get());
        info->xsize = static_cast<uint32_t>(bounds.width());
        info->ysize = static_cast<uint32_t>(bounds.height());
        {
            if (cs->colorDepthId() == Integer8BitsColorDepthID) {
                info->bits_per_sample = 8;
                info->exponent_bits_per_sample = 0;
                info->alpha_bits = 8;
                info->alpha_exponent_bits = 0;
            } else if (cs->colorDepthId() == Integer16BitsColorDepthID) {
                info->bits_per_sample = 16;
                info->exponent_bits_per_sample = 0;
                info->alpha_bits = 16;
                info->alpha_exponent_bits = 0;
#ifdef HAVE_OPENEXR
            } else if (cs->colorDepthId() == Float16BitsColorDepthID) {
                info->bits_per_sample = 16;
                info->exponent_bits_per_sample = 5;
                info->alpha_bits = 16;
                info->alpha_exponent_bits = 5;
#endif
            } else if (cs->colorDepthId() == Float32BitsColorDepthID) {
                info->bits_per_sample = 32;
                info->exponent_bits_per_sample = 8;
                info->alpha_bits = 32;
                info->alpha_exponent_bits = 8;
            }
        }
        if (cs->colorModelId() == RGBAColorModelID) {
            info->num_color_channels = 3;
            info->num_extra_channels = 1;
        } else if (cs->colorModelId() == GrayAColorModelID) {
            info->num_color_channels = 1;
            info->num_extra_channels = 1;
        } else if (cs->colorModelId() == CMYKAColorModelID) {
            info->num_color_channels = 4;
            info->num_extra_channels = 1;
        }
        info->uses_original_profile = JXL_TRUE;
        if (image->animationInterface()->hasAnimation() && cfg->getBool("haveAnimation", true)) {
            info->have_animation = JXL_TRUE;
            info->animation.have_timecodes = JXL_FALSE;
            info->animation.num_loops = 0;
            info->animation.tps_numerator = 1;
            info->animation.tps_denominator = static_cast<uint32_t>(image->animationInterface()->framerate());
        }
        return info;
    }
```

#### AUTO 


```{c}
auto& v
```

#### AUTO 


```{c}
auto setColorFn = [this, dialog]() { q->setColor(dialog->getCurrentColor()); };
```

#### AUTO 


```{c}
const auto translatedMode = KisQmicSimpleConvertor::blendingModeToString(node->compositeOpId());
```

#### AUTO 


```{c}
const auto v1 = xsimd::bitwise_cast<uint_v>(xsimd::nearbyint_as_int(c1));
```

#### LAMBDA EXPRESSION 


```{c}
[&] (KisFreehandStrokeInfo *data) {
        data->painter->paintRect(rect);
    }
```

#### AUTO 


```{c}
auto manager = shapeManager();
```

#### AUTO 


```{c}
auto value = [&](const uint8_t *img, int stride, int x, int y, int ch) {
                uint8_t source = img[(y * stride) + (x * channels) + ch];
                return linearizeValueAsNeeded(float(source) / 255.0f, linearizePolicy);
            };
```

#### RANGE FOR STATEMENT 


```{c}
for (const KisMetaData::Value &v : settings) {
        const QString str = v.asVariant().toString();
        QByteArray setting = codec->fromUnicode(str);
        array.append(setting);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, time](const KisScalarKeyframe* key){
                                     Q_UNUSED(key);
                                     emit sigKeyframeChanged(this, time);
                                 }
```

#### AUTO 


```{c}
auto it = d->actionInfoList.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Private::transform_unit &t : transforms) {
             m_transform = t.transform * m_transform;
         }
```

#### LAMBDA EXPRESSION 


```{c}
[keyframeTime, &nextKeyframeTime] (KisNodeSP node)
    {
        if (node->isAnimated()) {
            KisKeyframeChannel *keyframeChannel = node->paintDevice()->keyframeChannel();

            int nextKeyframeTimeQuery = keyframeChannel->nextKeyframeTime(keyframeTime);
            if (keyframeChannel->keyframeAt(nextKeyframeTimeQuery)) {
                if (nextKeyframeTime == INT_MAX) {
                    nextKeyframeTime = nextKeyframeTimeQuery;
                } else {
                    nextKeyframeTime = qMin(nextKeyframeTime, nextKeyframeTimeQuery);
                }
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&exactBounds] (KisNodeSP node) {
            exactBounds |= node->projectionPlane()->tightUserVisibleBounds();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& v : w) {
            //compensated summation to increase accuracy
            float v1 = v * scale + dif;
            float v2 = std::round(v1);
            dif = v1 - v2;
            weights.push_back(v2);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QObject *action, int from = 0) -> int {
        for (int i = from; i < actions.size(); i++) {
            if (actions[i] == action) {
                return i;
            }
        }
        return -1;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=] () {
            this->mergeToLayerUnthreaded(layer, parentCommand, transactionText, timedID);
        }
```

#### CONST EXPRESSION 


```{c}
constexpr int successMessageTimeout = 1000;
```

#### AUTO 


```{c}
const auto &path
```

#### AUTO 


```{c}
auto translatedMode = KisQmicSimpleConvertor::blendingModeToString(node->compositeOpId());
```

#### AUTO 


```{c}
auto it = d->strategies.begin();
```

#### AUTO 


```{c}
auto addFilterItem = [&](const FilterData &filterData) {
        if (retFilterList.contains(filterData.fullLine)) {
            debugWidgetUtils << "KoFileDialog: Duplicated filter" << filterData.fullLine;
            return;
        }
        retFilterList.append(filterData.fullLine);
        // the "simplified" version that comes to "onFilterSelect" when details are disabled
        retFilterToSuffixMap.insert(filterData.descriptionOnly, filterData.defaultSuffix);
        // "full version" that comes when details are enabled
        retFilterToSuffixMap.insert(filterData.fullLine, filterData.defaultSuffix);
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const KoColorSpace *colorSpace : colorSpaces) {
        QString fn = QFileInfo(colorSpace->profile()->fileName()).fileName();
        if (!store->open(fn)) { return false; }
        QByteArray profileRawData = colorSpace->profile()->rawData();
        if (!store->write(profileRawData)) { return false; }
        if (!store->close()) { return false; }
        QDomElement el = doc.createElement("Profile");
        el.setAttribute("filename", fn);
        el.setAttribute("name", colorSpace->profile()->name());
        el.setAttribute("colorModelId", colorSpace->colorModelId().id());
        el.setAttribute("colorDepthId", colorSpace->colorDepthId().id());
        profileElement.appendChild(el);

    }
```

#### LAMBDA EXPRESSION 


```{c}
[state] () {
                state->activeTransaction.reset();
                normalizeAlpha8Device(state->filteredMainDev, state->boundingRect);
                state->activeTransaction.reset(new KisTransaction(state->filteredMainDev));
            }
```

#### AUTO 


```{c}
const auto nodesCount = d->m_nodes->size();
```

#### AUTO 


```{c}
auto layer = qobject_cast<KisLayer*>(active.data());
```

#### RANGE FOR STATEMENT 


```{c}
for (QString attr : attributes) {
        double mainValue = elements.first().attribute(attr).toDouble();
        for (QDomElement el: elements) {
            double compare = el.attribute(attr).toDouble();
            QVERIFY2(fabs(mainValue - compare) < 1.0
                    , QString("XML LAB parsing has too high of a difference when roundtripping channel %1: %2")
                     .arg(attr).arg(mainValue - compare).toLatin1());
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&] (QLineF a, QLineF b) -> bool {
            return fuzzyComparePoint(a.p1(), b.p1()) && fuzzyComparePoint(a.p2(), b.p2()); }
```

#### AUTO 


```{c}
auto constControlIt2 = std::as_const(mesh).beginControlPoints();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        Q_FOREACH (KisNodeSP node, m_d->processedNodes) {
            KisDecoratedNodeInterface *decoratedNode = dynamic_cast<KisDecoratedNodeInterface*>(node.data());
            if (decoratedNode && decoratedNode->decorationsVisible()) {
                decoratedNode->setDecorationsVisible(false);
                m_d->disabledDecoratedNodes << decoratedNode;
            }
        }
    }
```

#### AUTO 


```{c}
auto maxMatches = sizeof(matches);
```

#### AUTO 


```{c}
auto result = JXL_ENC_NEED_MORE_OUTPUT;
```

#### AUTO 


```{c}
auto reqIt = fullRefreshRequests.begin();
```

#### LAMBDA EXPRESSION 


```{c}
[=](const QRect & geometry){
                         delete QTAB;
                         QTAB = QWindowsTabletSupport::create();
                     }
```

#### AUTO 


```{c}
const auto src2 = zip_hi(t1, t3);
```

#### AUTO 


```{c}
auto finishedJobIt =
        std::lower_bound(m_d->jobs.begin(), m_d->jobs.end(), seqNo,
                         [] (KisDabRenderingJobSP job, int seqNo) {
                             return job->seqNo < seqNo;
                         });
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool){
        if (m_d->canvas) {
            m_d->canvas->animationPlayer()->nextFrame();
        }
    }
```

#### AUTO 


```{c}
const auto t4 = zip_hi(b, d);
```

#### LAMBDA EXPRESSION 


```{c}
[=] { q->slotButtonClicked(key); }
```

#### AUTO 


```{c}
const auto shortcutString = index.data().toString();
```

#### RANGE FOR STATEMENT 


```{c}
for (const SwatchInfoType &info : infoList) {
        if (activeSwatch == info.swatch && enableTransparency) {
            colors.transparentIndex = i;
        }
        colors.colors << info.swatch.color();
        i++;
    }
```

#### AUTO 


```{c}
auto enableAction = [this] (const QString &id, bool value) {
        KisAction *action = m_d->actionMan->actionByName(id);
        KIS_SAFE_ASSERT_RECOVER_RETURN(action);
        action->setEnabled(value);
    };
```

#### LAMBDA EXPRESSION 


```{c}
[&result] (KoAbstractGradientSP gradient) {
        if (gradient) {
            result << gradient->requiredCanvasResources();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[] (QString a) {
        if (a == "testpattern.png") return true;
        if (a == "testpattern.0000.png") return true;
        if (a == "testpattern.0001.png") return true;
        if (a == "testpattern.0002.png") return true;
        if (a == "testpattern.0003.png") return true;
        if (a == "testpattern.0004.png") return true;
        if (a == "testpattern.0005.png") return true;
        if (a == "testpattern.0006.png") return true;
        if (a == "testpattern.0007.png") return true;
        if (a == "testpattern.0008.png") return true;
        if (a == "testpattern.0009.png") return true;
        if (a == "testpattern.0010.png") return true;
        return false;
    }
```

#### AUTO 


```{c}
const auto it = d->ditherOps.constFind(depth);
```

#### AUTO 


```{c}
const auto *profile = KoColorSpaceRegistry::instance()->createColorProfile(d.m_colorID.id(),
                                                                                           d.m_depthID.id(),
                                                                                           icc_profile);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &pair : m_d->asyncRenderers) {
        if (pair.renderer->isActive()) {
            pair.renderer->cancelCurrentFrameRendering(cancelReason);
        }
        KIS_SAFE_ASSERT_RECOVER_NOOP(!pair.renderer->isActive());
    }
```

#### AUTO 


```{c}
const auto tileHeight =
        static_cast<size_t>(it->numContiguousRows(dev->y()));
```

#### RANGE FOR STATEMENT 


```{c}
for(KoGamutMaskShape* shape: *shapeVector) {
        if (shape->coordIsClear(coord) == true) {
            return true;
        }
    }
```

#### AUTO 


```{c}
const auto &data = m_lut3dTexIDs[idx];
```

#### AUTO 


```{c}
const auto &existingStyle = cleanedStyles.find(style->psdUuid());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &position: positions) {
            SvgMeshPath path = mesharray->getPath(position);
            std::transform(path.begin(), path.end(), path.begin(), [&t](QPointF &point) { return t.map(point); });
            painterPath = QPainterPath();
            painterPath.moveTo(path[0]);
            painterPath.cubicTo(path[1], path[2], path[3]);
            result << painterPath;
        }
```

#### AUTO 


```{c}
auto copyGradientResource = [&](KoAbstractGradientSP dst, KoAbstractGradientSP src) {
            QBuffer buf;
            buf.open(QIODevice::ReadWrite);
            src->saveToDevice(&buf);
            buf.seek(0);
            dst->loadFromDevice(&buf, KisGlobalResourcesInterface::instance());
            buf.close();
        };
```

#### RANGE FOR STATEMENT 


```{c}
for (QString str : list) {
                if (str.toLower() == symbol.toLower()) {
                    newSymb = str; //official symbol may contain capitals letters, so better take the official version.
                    break;
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[gradient, transform] (KoShapeStrokeSP stroke) {
                QBrush newBrush = *gradient;
                newBrush.setTransform(transform);

                stroke->setLineBrush(newBrush);
                stroke->setColor(Qt::transparent);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[&lastKeyframeTime] (KisNodeSP node)
    {
        if (node->isAnimated()) {
            KisKeyframeChannel *keyframeChannel = node->paintDevice()->keyframeChannel();

            if (!keyframeChannel)
                return;

            lastKeyframeTime = qMax(keyframeChannel->lastKeyframeTime(), lastKeyframeTime);
        }
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr double MIN_CHANNEL_AB = -128;
```

#### LAMBDA EXPRESSION 


```{c}
[this](){
        if (m_d->mainWindow) {
            QDockWidget *docker = m_d->mainWindow->dockWidget("OnionSkinsDocker");
            if (docker) {
                docker->setVisible(!docker->isVisible());
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& handle: sh.handles()) {
                const QPointF handlePoint = converter->documentToView(handle.pos);
                const qreal distanceSq = kisSquareDistance(viewPoint, handlePoint);

                if (distanceSq < distanceThresholdSq && distanceSq < minDistanceSq) {
                    result = handle;
                    minDistanceSq = distanceSq;
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
                if (d.m_colorID == RGBAColorModelID && d.m_depthID == Integer8BitsColorDepthID) {
                    return &::imageOutRgbCallback<KoBgrU8Traits>;
                } else if (d.m_colorID == RGBAColorModelID && d.m_depthID == Integer16BitsColorDepthID) {
                    return &::imageOutRgbCallback<KoBgrU16Traits>;
                } else if (d.m_pixelFormat.data_type == JXL_TYPE_UINT8) {
                    return &::imageOutSizedCallback<uint8_t>;
                } else if (d.m_pixelFormat.data_type == JXL_TYPE_UINT16) {
                    return &::imageOutSizedCallback<uint16_t>;
                } else {
                    return &::imageOutSizedCallback<float>;
                }
            }
```

#### AUTO 


```{c}
const auto src1 = zip_lo(t1, t3);
```

#### AUTO 


```{c}
auto newShortcuts = preferredShortcuts(info);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KoGradientStop& stop : stops) {
        const float value = evenDistribution ? (float)stopIndex / (float)(stopCount - 1) : stop.second.toQColor().valueF();
        const float position = ascending ? value : 1.f - value;

        if (ascending) {
            sortedStops.push_back(KoGradientStop(position, stop.second));
        } else {
            sortedStops.push_front(KoGradientStop(position, stop.second));
        }

        stopIndex++;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&](KoAbstractGradientSP dst, KoAbstractGradientSP src) {
            QBuffer buf;
            buf.open(QIODevice::ReadWrite);
            src->saveToDevice(&buf);
            buf.seek(0);
            dst->loadFromDevice(&buf, KisGlobalResourcesInterface::instance());
            buf.close();
        }
```

#### AUTO 


```{c}
auto activeWindow = qApp->activeWindow();
```

#### AUTO 


```{c}
auto debugEvent = [&](int i) {
        if (KisTabletDebugger::instance()->debugEnabled()) {
            QString pre = QString("[BLOCKED %1:]").arg(i);
            QMouseEvent *ev = static_cast<QMouseEvent*>(event);
            dbgTablet << KisTabletDebugger::instance()->eventToString(*ev, pre);
        }
    };
```

#### AUTO 


```{c}
auto imageSP = image.toStrongRef();
```

#### LAMBDA EXPRESSION 


```{c}
[](const std::pair<KisNodeSP, QRect> &lhs, const std::pair<KisNodeSP, QRect> &rhs) { return lhs.first.data() < rhs.first.data(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &node : nodes) {
        auto layer = qobject_cast<KisPaintLayer*>(node.data());
        if (layer) {
            layer->setAlphaLocked(!isAlphaLocked);
        }
    }
```

#### AUTO 


```{c}
const auto& handle
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : indexes)
        totalSize += model->data(index, valueRole).toULongLong();
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    KisPressurePaintThicknessOption option;
                    option.readOptionSetting(prop->settings().data());
                    option.setThicknessMode(KisPressurePaintThicknessOption::ThicknessMode(prop->value().toInt() + 1));
                    option.writeOptionSetting(prop->settings().data());
                }
```

#### AUTO 


```{c}
const auto nextKeyframe = frames->nextKeyframeTime(i);
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    prop->settings()->setPaintOpSize(prop->value().toReal());
                }
```

#### AUTO 


```{c}
auto checkAndRecover = [this](KoCanvasResource::CanvasResourceId res,
                               KoFlake::FillVariant var) {
        if (d->overriddenColorFromProvider[var]) {
            d->canvas->resourceManager()->setResource(
                res, QVariant::fromValue(*d->overriddenColorFromProvider[var]));
            d->overriddenColorFromProvider[var] = boost::none;
        }
    };
```

#### LAMBDA EXPRESSION 


```{c}
[dialog, stops, this]() mutable
                          {
                              stops[m_selectedStop].type = COLORSTOP;
                              stops[m_selectedStop].color = dialog->getCurrentColor();
                              m_gradient->setStops(stops);
                              emit sigSelectedStop(m_selectedStop);
                              emit updateRequested();
                          }
```

#### DECLTYPE 


```{c}
typedef decltype(Rect().size()) Size;
```

#### CONST EXPRESSION 


```{c}
static constexpr int camel_bonus = 30;
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString& path){
        KisConfig cfg(false);
        cfg.setFFMpegLocation(KisFFMpegWrapper::findFFMpeg(path)["path"].toString());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &groupName : colorSet->getGroupNames()) {
        colorSet->getGroup(groupName)->setRowCount(dlg.groupRowNumber(groupName));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (KisNodeSP node) {
                    KisDecoratedNodeInterface *decoratedNode = dynamic_cast<KisDecoratedNodeInterface*>(node.data());
                    if (decoratedNode && decoratedNode->decorationsVisible()) {
                        decoratedNode->setDecorationsVisible(false, false);
                        m_d->disabledDecoratedNodes.append(node);
                    }
                }
```

#### LAMBDA EXPRESSION 


```{c}
[&numLayers, &hasNonNormalLayers, &hasTransparentLayer, image] (KisNodeSP node) {
                if (!node->inherits("KisLayer")) return;

                numLayers++;

                if (node->exactBounds().isEmpty()) return;

                // this is only an approximation! it is not exact!
                if (!hasTransparentLayer &&
                    node->exactBounds() != image->bounds()) {

                    hasTransparentLayer = true;
                }

                if (!hasNonNormalLayers &&
                    node->compositeOpId() != COMPOSITE_OVER) {

                    hasNonNormalLayers = true;
                }
            }
```

#### AUTO 


```{c}
auto translatedMode = KisQmicSimpleConvertor::stringToBlendingMode(modeStr);
```

#### AUTO 


```{c}
auto *filter = new KisKineticScrollerEventFilter(gestureType, scrollArea);
```

#### AUTO 


```{c}
auto it = std::find(svgFontWeights.begin(), svgFontWeights.end(), newWeight);
```

#### AUTO 


```{c}
auto currentPointerIt = penPointers.find(penInfo.pointerInfo.pointerId);
```

#### LAMBDA EXPRESSION 


```{c}
[](KoShape *shape) {
        return shape->isShapeEditable();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this,
                              argsAreInitialized]() mutable {
        QRect srcRect;

        if (m_selection) {
            srcRect = m_selection->selectedExactRect();
        } else {
            srcRect = QRect();
            Q_FOREACH (KisNodeSP node, m_processedNodes) {
                // group layers may have a projection of layers
                // that are locked and will not be transformed
                if (node->inherits("KisGroupLayer")) continue;

                if (const KisTransformMask *mask = dynamic_cast<const KisTransformMask*>(node.data())) {
                    srcRect |= mask->sourceDataBounds();
                } else if (const KisSelectionMask *mask = dynamic_cast<const KisSelectionMask*>(node.data())) {
                    srcRect |= mask->selection()->selectedExactRect();
                } else {
                    srcRect |= node->exactBounds();
                }
            }
        }

        TransformTransactionProperties transaction(srcRect, &m_initialTransformArgs, m_rootNode, m_processedNodes);
        if (!argsAreInitialized) {
            m_initialTransformArgs = KisTransformUtils::resetArgsForMode(m_mode, m_filterId, transaction);
        }

        Q_EMIT this->sigTransactionGenerated(transaction, m_initialTransformArgs, this);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        executeAndAddCommand(new KisDisableDirtyRequestsCommand(m_d->updatesFacade, KisDisableDirtyRequestsCommand::INITIALIZING), Clear, KisStrokeJobData::BARRIER);

        Q_FOREACH (KisNodeSP node, m_d->processedNodes) {
            m_d->prevDirtyRects[node] = node->extent();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        // When dealing with animated transform mask layers, create keyframe and save the command for undo.
        Q_FOREACH (KisNodeSP node, m_d->processedNodes) {
            if (KisTransformMask* transformMask = dynamic_cast<KisTransformMask*>(node.data())) {
                QSharedPointer<KisInitializeTransformMaskKeyframesCommand> addKeyCommand(new KisInitializeTransformMaskKeyframesCommand(transformMask));
                runAndSaveCommand( addKeyCommand, KisStrokeJobData::CONCURRENT, KisStrokeJobData::NORMAL);
            }
        }
    }
```

#### AUTO 


```{c}
auto *reference = dynamic_cast<KisReferenceImage*>(shape);
```

#### AUTO 


```{c}
auto it = m_rowGroupNameMap.begin();
```

#### LAMBDA EXPRESSION 


```{c}
[affected, offset, cmd] (KisNodeSP node) {
                const int startFrame = affected.start();
                if (node->isAnimated()) {
                    KisKeyframeChannel *keyframeChannel = node->paintDevice()->keyframeChannel();
                    if (keyframeChannel) {
                        if (offset > 0) {
                            int timeIter = affected.isInfinite() ?
                                                    keyframeChannel->lastKeyframeTime()
                                                  : keyframeChannel->activeKeyframeTime(affected.end());

                            KisKeyframeSP iterEnd = keyframeChannel->keyframeAt(keyframeChannel->previousKeyframeTime(startFrame));

                            while (keyframeChannel->keyframeAt(timeIter) &&
                                   keyframeChannel->keyframeAt(timeIter) != iterEnd) {
                                keyframeChannel->moveKeyframe(timeIter, timeIter + offset, cmd);
                                timeIter = keyframeChannel->previousKeyframeTime(timeIter);
                            }

                        } else {
                            int timeIter = keyframeChannel->keyframeAt(startFrame) ? startFrame : keyframeChannel->nextKeyframeTime(startFrame);

                            KisKeyframeSP iterEnd = affected.isInfinite() ?
                                                        nullptr
                                                      : keyframeChannel->keyframeAt(keyframeChannel->nextKeyframeTime(affected.end()));

                            while (keyframeChannel->keyframeAt(timeIter) != iterEnd) {
                                keyframeChannel->moveKeyframe(timeIter, timeIter + offset, cmd);
                                timeIter = keyframeChannel->nextKeyframeTime(timeIter);
                            }
                        }
                    }
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &loader : offers) {
        auto *factory = qobject_cast<KPluginFactory *>(loader->instance());
        if (!factory) {
            warnPlugins << "(GMic) This is not a Krita plugin: " << loader->fileName() << loader->errorString();

            continue;
        }

        auto *pluginBase = factory->create<QObject>(this);

        plugin = qobject_cast<KisQmicPluginInterface *>(pluginBase);

        if (!plugin) {
            warnPlugins << "(GMic) This is not a valid GMic-Qt plugin: " << loader->fileName();

            continue;
        }

        break;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            changeLayoutDir(Qt::LeftToRight);
        }
```

#### AUTO 


```{c}
auto kisCanvas = dynamic_cast<KisCanvas2*>(canvas());
```

#### AUTO 


```{c}
auto it = updateData->begin();
```

#### AUTO 


```{c}
auto *frameSettings = JxlEncoderFrameSettingsCreate(enc.get(), nullptr);
```

#### LAMBDA EXPRESSION 


```{c}
[this](){
        if (m_d->image) {
            const int currentFrame = m_d->image->animationInterface()->currentUITime();
            if(!isFrameCached(currentFrame)) {
                KisPart::instance()->prioritizeFrameForCache(m_d->image, currentFrame);
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const KisKeyframeChannel *channel, int time) {
        channel->sigChannelUpdated(
                   channel->affectedFrames(time),
                   channel->affectedRect(time)
                   );
    }
```

#### LAMBDA EXPRESSION 


```{c}
[mean, m_c1, m_c2](double x)
        {
            const double shiftedX = x - mean;
            return 2.0 * x * m_c1 * std::exp(-(shiftedX * shiftedX / m_c2));
        }
```

#### LAMBDA EXPRESSION 


```{c}
[canvasResourcesInterface, localResourcesSnapshot] (KoAbstractGradientSP gradient) {
            if (gradient && !gradient->requiredCanvasResources().isEmpty()) {

                /**
                 * Since we haven't cloned the required resources when putting them
                 * into the local storage (which is rather questionable), we need to
                 * clone the gradients explicitly before modification.
                 */

                KoAbstractGradientSP clonedGradient =
                    gradient->cloneAndBakeVariableColors(canvasResourcesInterface);

                localResourcesSnapshot->removeResource(gradient);
                localResourcesSnapshot->addResource(clonedGradient);
            }
        }
```

#### DECLTYPE 


```{c}
typedef typeof(((elf_aux_entry*) 0)->a_un.a_val) elf_aux_val_t;
```

#### CONST EXPRESSION 


```{c}
static constexpr double MAX_CHANNEL_CMYK = 100;
```

#### AUTO 


```{c}
auto source = KisGlobalResourcesInterface::instance()->source<KoPattern>(ResourceType::Patterns);
```

#### RANGE FOR STATEMENT 


```{c}
for (cmsFloat32Number value : inputValues) {
        cmsFloat32Number cValue = value;

        /*
         * SMPTE 240M
         * for 1  >=  Lc  >=  β
         *  V = α * Lc^0.45 − ( α − 1 )
         * for β  >  Lc  >=  0
         * V = 4.0 * Lc
         */

        if (value > 0.0228){
            cValue = 1.1115 * powf(value, 0.45) - (.1115) ;
        } else if (value < 0.0228 && value > 0.0){
            cValue = 4.0 * value;
        } else {
            cValue = 0.0;
        }

        /*
        double lValue;
        if (cValue > 0.0913){
            lValue = powf((.1115+cValue)*1/1.1115, 1/ 0.45);
        } else {
            lValue = cValue * 1/4.0;
        }
        */

        cmsFloat32Number lValue = cmsEvalToneCurveFloat(curve, cValue);
        QVERIFY2(fabs(lValue - value) < 0.000001, QString("Values don't match for SMPTE 240M: %1 %2").arg(value).arg(lValue).toLatin1());
    }
```

#### AUTO 


```{c}
auto it = data->m_currentFrame->createHLineIteratorNG(static_cast<int>(x),
                                                          static_cast<int>(y),
                                                          static_cast<int>(data->m_info.xsize));
```

#### AUTO 


```{c}
auto it = keyStrokes.begin();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        /**
             * We must ensure that the currently selected subtree
             * has finished all its updates.
             */
        KisLayerUtils::forceAllDelayedNodesUpdate(m_s->rootNode);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        Q_FOREACH (KisDecoratedNodeInterface *decoratedNode, m_d->disabledDecoratedNodes) {
            decoratedNode->setDecorationsVisible(true);
        }
        m_d->disabledDecoratedNodes.clear();
    }
```

#### AUTO 


```{c}
const auto cacheRowStartBegin = cacheRowStart.begin();
```

#### LAMBDA EXPRESSION 


```{c}
[&elapsedTimer] () { elapsedTimer.restart(); }
```

#### LAMBDA EXPRESSION 


```{c}
[] (const std::pair<KisNodeSP, QRect> &update) {return update.first; }
```

#### AUTO 


```{c}
auto cg = KSharedConfig::openConfig(path)->group(QStringLiteral("Shortcuts"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &path: paths) {
        m_array[path.row][path.col]->setStopColor(path.segmentType, color);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &path: paths) {
            helper.drawPath(path);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KoColorSetSP palette : m_d->doc->paletteList()) {
        // Ensure stored palettes are KPL.
        palette->setPaletteType(KoColorSet::KPL);
        QDomElement eFile =  doc.createElement("palette");
        eFile.setAttribute("filename", palette->filename());
        ePalette.appendChild(eFile);
    }
```

#### AUTO 


```{c}
auto it = beginControlPoints();
```

#### RANGE FOR STATEMENT 


```{c}
for (int k : c.keys()) {
            if (k >= newRowCount) {
                c.remove(k);
                m_colorCount--;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (KisBezierTransformMesh::segment_iterator it,
                    qreal t,
                    qreal distance,
                    const QPointF &offset) {

            QPointF offsetP1;
            QPointF offsetP2;

            std::tie(offsetP1, offsetP2) =
                KisBezierUtils::offsetSegment(t, (1.0 - distance) * offset);


            smartMoveControl(*m_d->currentArgs.meshTransform(), it.itP1().controlIndex(), offsetP1, KisSmartMoveMeshControlMode::MoveSymmetricLock);
            smartMoveControl(*m_d->currentArgs.meshTransform(), it.itP2().controlIndex(), offsetP2, KisSmartMoveMeshControlMode::MoveSymmetricLock);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QUrl url : urls) {

                    if (!url.isLocalFile()) {
                        // download the file and substitute the url
                        KisRemoteFileFetcher fetcher;
                        QScopedPointer<QTemporaryFile> tmp(new QTemporaryFile());
                        tmp->setAutoRemove(true);
                        if (!fetcher.fetchFile(url, tmp.data())) {
                            qWarning() << "Fetching" << url << "failed";
                            continue;
                        }
                        url = url.fromLocalFile(tmp->fileName());
                    }
                    if (url.isLocalFile()) {
                        if (action == insertAsNewLayer || action == insertManyLayers) {
                            kisview->mainWindow()->viewManager()->imageManager()->importImage(url);
                            kisview->activateWindow();
                        }
                        else if (action == insertAsNewFileLayer || action == insertManyFileLayers) {
                            KisNodeCommandsAdapter adapter(kisview->mainWindow()->viewManager());
                            QFileInfo fileInfo(url.toLocalFile());
                            KisFileLayer *fileLayer = new KisFileLayer(kisview->image(), "", url.toLocalFile(),
                                                                       KisFileLayer::None, fileInfo.fileName(), OPACITY_OPAQUE_U8);
                            adapter.addNode(fileLayer, kisview->mainWindow()->viewManager()->activeNode()->parent(), kisview->mainWindow()->viewManager()->activeNode());
                        }
                        else if (action == openInNewDocument || action == openManyDocuments) {
                            if (kisview->mainWindow()) {
                                kisview->mainWindow()->openDocument(url.toLocalFile(), KisMainWindow::None);
                            }
                        }
                        else if (action == insertAsReferenceImage || action == insertAsReferenceImages) {
                            auto *reference = KisReferenceImage::fromFile(url.toLocalFile(), *kisview->viewConverter(), kisview);

                            if (reference) {
                                reference->setPosition((*kisview->viewConverter()).imageToDocument(QCursor::pos()));
                                kisview->canvasBase()->referenceImagesDecoration()->addReferenceImage(reference);

                                KoToolManager::instance()->switchToolRequested("ToolReferenceImages");
                            }
                        }

                    }
                }
```

#### AUTO 


```{c}
auto* reference = KisReferenceImage::fromXml(child);
```

#### LAMBDA EXPRESSION 


```{c}
[]() {
                return KisSuspendResumePair(
                    new KisTestingStrokeStrategy("resu_u_", false, true, true),
                    QList<KisStrokeJobData*>());
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction* action: collection->actions()) {
            QString actionName = KLocalizedString::removeAcceleratorMarker(action->text());
            QStandardItem* item = new QStandardItem(action->icon(), actionName);
            QStandardItem* actionNameItem = new QStandardItem(action->objectName());
            m_model->appendRow(QList<QStandardItem*>() << item << actionNameItem);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        if (!d->m_newNodes->isEmpty()) {
            return d->m_newNodes->last()->prevSibling();
        } else {
            return d->m_nodes->last()->prevSibling();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const RecorderProfile &profile : value) {
        outValue += QString(profile.name).replace(cleanUp, " ") % "|"
                % QString(profile.extension).replace(cleanUp, " ") % "|"
                % QString(profile.arguments).replace("\n", "\\n").replace("|", " ") % "\n";
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](qreal overscroll){
       qreal currentOffset = m_d->verticalHeader->valueOffset();
       m_d->verticalHeader->setValueOffset(currentOffset - overscroll * m_d->verticalHeader->step() * 0.25);
       viewport()->update();
    }
```

#### AUTO 


```{c}
const auto callback = [&]() {
                if (d.m_colorID == RGBAColorModelID && d.m_depthID == Integer8BitsColorDepthID) {
                    return &::imageOutRgbCallback<KoBgrU8Traits>;
                } else if (d.m_colorID == RGBAColorModelID && d.m_depthID == Integer16BitsColorDepthID) {
                    return &::imageOutRgbCallback<KoBgrU16Traits>;
                } else if (d.m_pixelFormat.data_type == JXL_TYPE_UINT8) {
                    return &::imageOutSizedCallback<uint8_t>;
                } else if (d.m_pixelFormat.data_type == JXL_TYPE_UINT16) {
                    return &::imageOutSizedCallback<uint16_t>;
                } else {
                    return &::imageOutSizedCallback<float>;
                }
            }();
```

#### AUTO 


```{c}
auto sendTabletEvent = [&](QTabletEvent::Type t){
            handleTabletEvent(w, localPosDip, globalPosDip, currentDevice, currentPointerType,
                               button, buttons, pressureNew, tiltX, tiltY, tangentialPressure, rotation, z,
                               m_devices.at(m_currentDevice).uniqueId, keyboardModifiers, t);
        };
```

#### AUTO 


```{c}
const auto root = d->m_nodes->at(0);
```

#### AUTO 


```{c}
const auto nameWithoutSuffix = QFileInfo(resource->name()).baseName();
```

#### AUTO 


```{c}
auto it = rects.constBegin();
```

#### AUTO 


```{c}
auto *watcher = dynamic_cast<QFutureWatcher<IconFetchResult> *>(QObject::sender());
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    ParticleOption option;
                    option.readOptionSetting(prop->settings().data());

                    prop->setValue(int(option.particle_count));
                }
```

#### LAMBDA EXPRESSION 


```{c}
LAZY_STATIC_CATEGORY_DISPLAY_NAME("binary")
```

#### LAMBDA EXPRESSION 


```{c}
[](KoShape *shape) {
        return shape->isEditable();
    }
```

#### THREAD 


```{c}
std::thread* m_thread = nullptr;
```

#### AUTO 


```{c}
const auto numContiguousImageRows =
            static_cast<size_t>(it->numContiguousRows(imageY));
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        Q_FOREACH (KisNodeSP node, m_s->processedNodes) {
            KisDecoratedNodeInterface *decoratedNode = dynamic_cast<KisDecoratedNodeInterface*>(node.data());
            if (decoratedNode && decoratedNode->decorationsVisible()) {
                decoratedNode->setDecorationsVisible(false);
                m_disabledDecoratedNodes << decoratedNode;
            }
        }
    }
```

#### AUTO 


```{c}
auto result = map.erase(i - 2);
```

#### AUTO 


```{c}
auto *layout = KisWindowLayoutResource::fromCurrentWindows(name, KisPart::instance()->mainWindows());
```

#### RANGE FOR STATEMENT 


```{c}
for (KoColorSet const * &palette : doc->paletteList()) {
        KoColorSet *newPalette = new KoColorSet(palette->filename());
        store->open(m_d->imageName + PALETTE_PATH + palette->filename());
        QByteArray data = store->read(store->size());
        newPalette->fromByteArray(data);
        newPalette->setIsGlobal(false);
        newPalette->setIsEditable(true);
        delete palette;
        palette = newPalette;
        pServer->addResource(newPalette);
        store->close();
    }
```

#### AUTO 


```{c}
auto rowBegin = rowsBuf.begin();
```

#### LAMBDA EXPRESSION 


```{c}
LAZY_STATIC_CATEGORY_DISPLAY_NAME("hsi")
```

#### AUTO 


```{c}
auto pattern = rserver->resource("", "", name);
```

#### AUTO 


```{c}
const auto *gimg = d->m_images[index];
```

#### LAMBDA EXPRESSION 


```{c}
[](char c) {return c == 0;}
```

#### RANGE FOR STATEMENT 


```{c}
for (QUrl url : urls) {

                    QScopedPointer<QTemporaryFile> tmp(new QTemporaryFile());
                    tmp->setAutoRemove(true);

                    if (!url.isLocalFile()) {
                        // download the file and substitute the url
                        KisRemoteFileFetcher fetcher;

                        if (!fetcher.fetchFile(url, tmp.data())) {
                            qWarning() << "Fetching" << url << "failed";
                            continue;
                        }
                        url = url.fromLocalFile(tmp->fileName());
                    }

                    if (url.isLocalFile()) {
                        if (action == insertAsNewLayer || action == insertManyLayers) {
                            kisview->mainWindow()->viewManager()->imageManager()->importImage(url);
                            kisview->activateWindow();
                        }
                        else if (action == insertAsNewFileLayer || action == insertManyFileLayers) {
                            KisNodeCommandsAdapter adapter(kisview->mainWindow()->viewManager());
                            QFileInfo fileInfo(url.toLocalFile());

                            QString type = KisMimeDatabase::mimeTypeForFile(url.toLocalFile());
                            QStringList mimes =
                                KisImportExportManager::supportedMimeTypes(KisImportExportManager::Import);

                            if (!mimes.contains(type)) {
                                QString msg =
                                    KisImportExportErrorCode(ImportExportCodes::FileFormatNotSupported).errorMessage();
                                QMessageBox::warning(
                                    kisview, i18nc("@title:window", "Krita"),
                                    i18n("Could not open %2.\nReason: %1.", msg, url.toDisplayString()));
                                continue;
                            }

                            KisFileLayer *fileLayer = new KisFileLayer(kisview->image(), "", url.toLocalFile(),
                                                                       KisFileLayer::None, fileInfo.fileName(), OPACITY_OPAQUE_U8);
                            adapter.addNode(fileLayer, kisview->mainWindow()->viewManager()->activeNode()->parent(), kisview->mainWindow()->viewManager()->activeNode());
                        }
                        else if (action == openInNewDocument || action == openManyDocuments) {
                            if (kisview->mainWindow()) {
                                kisview->mainWindow()->openDocument(url.toLocalFile(), KisMainWindow::None);
                            }
                        }
                        else if (action == insertAsReferenceImage || action == insertAsReferenceImages) {
                            auto *reference = KisReferenceImage::fromFile(url.toLocalFile(), *kisview->viewConverter(), kisview);

                            if (reference) {
                                const auto pos = kisview->canvasBase()->coordinatesConverter()->widgetToImage(eventPos);
                                reference->setPosition((*kisview->viewConverter()).imageToDocument(pos));
                                kisview->canvasBase()->referenceImagesDecoration()->addReferenceImage(reference);

                                KoToolManager::instance()->switchToolRequested("ToolReferenceImages");
                            }
                        }

                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &image : gmicImages) {
        QString layerName = image->m_layerName;
        int spectrum = image->m_spectrum;
        int width = image->m_width;
        int height = image->m_height;

        dbgPlugins << "Received image: " << (quintptr)image.data() << layerName << width << height;

        gmic_image<float> *gimg = nullptr;

        {
            QMutexLocker lock(&image->m_mutex);

            dbgPlugins << "Memory segment" << (quintptr)image.data() << image->size() << (quintptr)image->constData() << (quintptr)image->m_data;
            gimg = new gmic_image<float>();
            gimg->assign(width, height, 1, spectrum);
            gimg->name = layerName;

            gimg->_data = new float[width * height * spectrum * sizeof(float)];
            dbgPlugins << "width" << width << "height" << height << "size" << width * height * spectrum * sizeof(float) << "shared memory size" << image->size();
            memcpy(gimg->_data, image->constData(), width * height * spectrum * sizeof(float));

            dbgPlugins << "created gmic image" << gimg->name << gimg->_width << gimg->_height;

        }
        images.append(gimg);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    CurveOption option;
                    option.readOptionSetting(prop->settings().data());

                    prop->setValue(option.curve_stroke_history_size);
                }
```

#### AUTO 


```{c}
auto animFunction =
        [this]() -> void
        {
            int animationDuration;
            qreal animationStartValue;

            if (m_areControlsHidden) {
                if (m_showControlsAnimation.state() == QVariantAnimation::Running) {
                    m_showControlsAnimation.stop();
                    animationDuration =
                        static_cast<int>(std::round((1.0 - m_showControlsAnimation.currentValue().toReal()) * showControlsAnimationDuration));
                    animationStartValue = m_showControlsAnimation.currentValue().toReal();
                } else {
                    animationDuration = showControlsAnimationDuration;
                    animationStartValue = 0.0;
                }
            } else {
                animationDuration = 1;
                animationStartValue = 1.0;
            }

            m_areControlsHidden = false;
            m_showControlsAnimation.setStartValue(animationStartValue);
            m_showControlsAnimation.setEndValue(1.0);
            m_showControlsAnimation.setDuration(animationDuration);
            m_showControlsAnimation.start();
        };
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    KisCurveOptionProperties option;
                    option.readOptionSetting(prop->settings().data());
                    option.curve_line_width = prop->value().toInt();
                    option.writeOptionSetting(prop->settings().data());
                }
```

#### AUTO 


```{c}
auto result = map.insert(i, KisSharedPtr<Wrapper>(new Wrapper(i, 0, 0, 0)));
```

#### LAMBDA EXPRESSION 


```{c}
[](const FilterData &a, const FilterData &b) {
        return a.descriptionOnly < b.descriptionOnly;
    }
```

#### AUTO 


```{c}
auto pattern = source.resourceForName(patternName);
```

#### LAMBDA EXPRESSION 


```{c}
[targetFrame, cmd](KisNodeSP node){
                if (node->supportsKeyframeChannel(KisKeyframeChannel::Raster.id())) {
                    KisKeyframeChannel* chan = node->getKeyframeChannel(KisKeyframeChannel::Raster.id(), true);
                    chan->addKeyframe(targetFrame, cmd);
                }
            }
```

#### AUTO 


```{c}
auto it = m_d->keyStrokes.begin();
```

#### AUTO 


```{c}
auto source = resourcesInterface->source<KoPattern>(m_texturePatternLink.type);
```

#### RANGE FOR STATEMENT 


```{c}
for (Node* n : nodeList) {
            QVERIFY(test.contains(n->name()) == true);
            delete n;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Private::Column &c : d->colorMatrix) {
        if (c.isEmpty()) { continue; }
        if (y < c.lastKey()) {
            y = c.lastKey();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& corner: cornerHandles) {
        if (corner.type == KoShapeMeshGradientHandles::Handle::BezierHandle) {
            helper.drawHandleSmallCircle(t.map(corner.pos));
        } else if (corner.type == KoShapeMeshGradientHandles::Handle::Corner) {
            helper.drawHandleRect(t.map(corner.pos));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &groupName : d->groupNames) {
        if ((int)y < d->groups[groupName].rowCount()) {
            return d->groups[groupName].getEntry(x, y);
        } else {
            y -= d->groups[groupName].rowCount();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    DynaOption option;
                    option.readOptionSetting(prop->settings().data());

                    prop->setValue(int(option.dyna_angle));
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& i: controlPoints) {
        path.cubicTo(i[1], i[2], i[3]);
    }
```

#### CONST EXPRESSION 


```{c}
constexpr const char *currentUnderlyingStyleNameProperty = "currentUnderlyingStyleName";
```

#### AUTO 


```{c}
const auto alpha = a * uint8Max;
```

#### AUTO 


```{c}
auto &handle
```

#### AUTO 


```{c}
const auto numContiguousImageRows = it->numContiguousRows(imageY);
```

#### LAMBDA EXPRESSION 


```{c}
[this](QAbstractButton *button, bool checked) {
            emit buttonToggled(dynamic_cast<KoGroupButton *>(button), checked);
            emit buttonToggled(m_d->buttonGroup->id(button), checked);
        }
```

#### AUTO 


```{c}
auto it9 = forest.insert(childEnd(it8), 9);
```

#### AUTO 


```{c}
auto prevIt = begin(), it = next(prevIt);
```

#### AUTO 


```{c}
auto schemeFileLocations = KisKShortcutSchemesHelper::schemeFileLocations();
```

#### LAMBDA EXPRESSION 


```{c}
[&] (const QPointF &offset) {

                    while (1) {
                        rc.translate(offset);
                        QRectF widgetRc = m_d->coordinatesConverter->imageToWidget(rc);

                        widgetRc &= widgetRect;

                        if (widgetRc.isEmpty()) {
                            break;
                        } else {
                            updateRects.append(widgetRc.toAlignedRect());
                        }
                    }
                }
```

#### AUTO 


```{c}
const auto data = io->readAll();
```

#### LAMBDA EXPRESSION 


```{c}
[&linearizedNodes](KisNodeSP node) {
                                               linearizedNodes.enqueue(node);
                                           }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
                    f->generate(dstCfg, tile.size(), filterConfig, helper->updater());

                    // HACK ALERT!!!
                    // this avoids cyclic loop with KisRecalculateGeneratorLayerJob::run()
                    const_cast<KisGeneratorLayerSP &>(layer)->setDirtyWithoutUpdate({tile});

                    const_cast<QSharedPointer<bool> &>(cookie).clear();
                }
```

#### AUTO 


```{c}
auto tester = new QAbstractItemModelTester(&tagModel);
```

#### AUTO 


```{c}
auto checkExists =
        [&typedResources] (const QString &filename) {
            return typedResources.contains(filename);
        };
```

#### AUTO 


```{c}
const auto height = image->m_height;
```

#### AUTO 


```{c}
auto it = samples.begin();
```

#### AUTO 


```{c}
auto numContiguousColumns =
                qMin(static_cast<size_t>(it->numContiguousColumns(rc.x() + x)),
                     optimalBufferSize);
```

#### AUTO 


```{c}
const auto floatPixelSize = rgbaFloat32bitcolorSpace->pixelSize();
```

#### AUTO 


```{c}
const auto convertedTileY = tileHeight - rowsToWork;
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool){
        if (m_d->canvas) {
            m_d->canvas->animationPlayer()->nextKeyframe();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto& tile: tiles) {
                KisProcessingInformation dstCfg(dev, tile.topLeft(), KisSelectionSP());
                addJobConcurrent(jobsData, [=]() {
                    const_cast<QSharedPointer<bool> &>(cookie).clear();

                    f->generate(dstCfg, tile.size(), filterConfig, helper->updater());

                    // HACK ALERT!!!
                    // this avoids cyclic loop with KisRecalculateGeneratorLayerJob::run()
                    const_cast<KisGeneratorLayerSP &>(layer)->setDirtyWithoutUpdate({tile});
                });
            }
```

#### AUTO 


```{c}
auto rc = updateRegion.begin();
```

#### AUTO 


```{c}
auto resourceServer = KoResourceServerProvider::patternServer();
```

#### LAMBDA EXPRESSION 


```{c}
[sharedWriteLock] () {
            sharedWriteLock->relock();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, filterIcon, filterEnabledIcon](){
        if(layerFilterWidget->isCurrentlyFiltering()) {
            m_wdgLayerBox->bnLayerFilters->setIcon(filterEnabledIcon);
        } else {
            m_wdgLayerBox->bnLayerFilters->setIcon(filterIcon);
        }

        m_wdgLayerBox->bnLayerFilters->setSelectedColors(QList<int>::fromSet(layerFilterWidget->getActiveColors()));
        m_wdgLayerBox->bnLayerFilters->setTextFilter(layerFilterWidget->hasTextFilter());
    }
```

#### AUTO 


```{c}
const auto defaultActionTypes = KisShortcutsEditor::WidgetAction \
                                | KisShortcutsEditor::WindowAction  \
                                | KisShortcutsEditor::ApplicationAction;
```

#### AUTO 


```{c}
const auto v3 = xsimd::bitwise_cast<uint_v>(xsimd::nearbyint_as_int(c3));
```

#### AUTO 


```{c}
auto it = std::lower_bound(fontStretches.begin(), fontStretches.end(), stretch);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Column &c : m_colorMatrix) {
        if (c.isEmpty()) { continue; }
        if (y < c.lastKey()) {
            y = c.lastKey();
        }
    }
```

#### AUTO 


```{c}
auto it = channels.begin();
```

#### AUTO 


```{c}
const auto& p
```

#### AUTO 


```{c}
const auto availOut = JxlDecoderReleaseBoxBuffer(dec.get());
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &handle: result) {
        handle.pos = t.map(handle.pos);
    }
```

#### AUTO 


```{c}
const auto channelSize = sizeof(float);
```

#### AUTO 


```{c}
auto conflictIt = l.conflictWithGroup.begin();
```

#### AUTO 


```{c}
const auto &pair
```

#### RANGE FOR STATEMENT 


```{c}
for (const SwatchInfoType &info : group->infoList()) {
        const KoColorProfile *profile = info.swatch.color().colorSpace()->profile();
        // Only save non-builtin profiles.=
        if (!profile->fileName().isEmpty()) {
            bool alreadyIncluded = false;
            Q_FOREACH(const KoColorSpace* colorSpace, colorSetSet) {
                if (colorSpace->profile()->fileName() == profile->fileName()) {
                    alreadyIncluded = true;
                    break;
                }
            }
            if(!alreadyIncluded) {
                colorSetSet.insert(info.swatch.color().colorSpace());
            }
        }
        QDomElement swatchEle = doc.createElement(KPL_SWATCH_TAG);
        swatchEle.setAttribute(KPL_SWATCH_NAME_ATTR, info.swatch.name());
        swatchEle.setAttribute(KPL_SWATCH_ID_ATTR, info.swatch.id());
        swatchEle.setAttribute(KPL_SWATCH_SPOT_ATTR, info.swatch.spotColor() ? "true" : "false");
        swatchEle.setAttribute(KPL_SWATCH_BITDEPTH_ATTR, info.swatch.color().colorSpace()->colorDepthId().id());
        info.swatch.color().toXML(doc, swatchEle);

        QDomElement positionEle = doc.createElement(KPL_SWATCH_POS_TAG);
        positionEle.setAttribute(KPL_SWATCH_ROW_ATTR, info.row);
        positionEle.setAttribute(KPL_SWATCH_COL_ATTR, info.column);
        swatchEle.appendChild(positionEle);

        groupEle.appendChild(swatchEle);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const KisTimeSpan &affectedTimeSpan, const QRect &affectedArea){
            if (!m_blockOpacityUpdate) {
                updateUI(); // TODO: Make sure this is doing something useful.
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=](QString node){return actionXml.firstChildElement(node).text();}
```

#### LAMBDA EXPRESSION 


```{c}
[srcDstPairs, parentCommand]() -> KUndo2Command*
        {
            QScopedPointer<KUndo2Command> cmd(new KUndo2Command());

            foreach (const FrameMovePair &move, srcDstPairs) {
                KisRasterKeyframeChannel *srcRasterChan = dynamic_cast<KisRasterKeyframeChannel*>(move.first.node->getKeyframeChannel(move.first.channel));
                KisRasterKeyframeChannel *dstRasterChan = dynamic_cast<KisRasterKeyframeChannel*>(move.second.node->getKeyframeChannel(move.second.channel));

                if (!srcRasterChan || !dstRasterChan) {
                    continue;
                }

                if (srcRasterChan == dstRasterChan) {
                    srcRasterChan->cloneKeyframe(move.first.time, move.second.time, cmd.data());
                } else {
                    KisKeyframeChannel::copyKeyframe(srcRasterChan, move.first.time, dstRasterChan, move.second.time, cmd.data());
                }
            }

            return cmd.take();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    KisBrushSizeOptionProperties option;
                    option.readOptionSetting(prop->settings().data());
                    option.brush_rotation = prop->value().toInt();
                    option.writeOptionSetting(prop->settings().data());
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &name : d->groupNames) {
        res += d->groups[name].rowCount();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (KoShapeStrokeSP stroke) {
            stroke->setLineStyle(lineStyle(), lineDashes());
        }
```

#### AUTO 


```{c}
auto it = newFrames.upperBound(time);
```

#### LAMBDA EXPRESSION 


```{c}
[affected, offset, cmd] (KisNodeSP node) {
                const int startFrame = affected.start();
                if (node->isAnimated()) {
                    Q_FOREACH(KisKeyframeChannel* keyframeChannel, node->keyframeChannels()) {
                        if (keyframeChannel) {
                            if (offset > 0) {
                                int timeIter = affected.isInfinite() ?
                                                        keyframeChannel->lastKeyframeTime()
                                                      : keyframeChannel->activeKeyframeTime(affected.end());

                                KisKeyframeSP iterEnd = keyframeChannel->keyframeAt(keyframeChannel->previousKeyframeTime(startFrame));

                                while (keyframeChannel->keyframeAt(timeIter) &&
                                       keyframeChannel->keyframeAt(timeIter) != iterEnd) {
                                    keyframeChannel->moveKeyframe(timeIter, timeIter + offset, cmd);
                                    timeIter = keyframeChannel->previousKeyframeTime(timeIter);
                                }

                            } else {
                                int timeIter = keyframeChannel->keyframeAt(startFrame) ? startFrame : keyframeChannel->nextKeyframeTime(startFrame);

                                KisKeyframeSP iterEnd = affected.isInfinite() ?
                                                            nullptr
                                                          : keyframeChannel->keyframeAt(keyframeChannel->nextKeyframeTime(affected.end()));

                                while (keyframeChannel->keyframeAt(timeIter) != iterEnd) {
                                    keyframeChannel->moveKeyframe(timeIter, timeIter + offset, cmd);
                                    timeIter = keyframeChannel->nextKeyframeTime(timeIter);
                                }
                            }
                        }
                    }
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this]{ this->sortByHue(SORT_ASCENDING); }
```

#### LAMBDA EXPRESSION 


```{c}
[] (const QPointF &pt) {
                    return pt.y();
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        QMenu* menu = dynamic_cast<QMenu*>(parentWidget());
        if (menu) {
            menu->close();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &resname : names) {
        if (QFile(resname).exists()) {
            QIcon icon(resname);
            s_icons.insert(icon.cacheKey(), name);
            return icon;
        }
    }
```

#### AUTO 


```{c}
auto it = s_instance->d->resourceModels.begin();
```

#### AUTO 


```{c}
auto getChildContent_i18n = [=](QString node){return quietlyTranslate(getChild(actionXml, node));};
```

#### AUTO 


```{c}
auto verIt = iter->versions();
```

#### AUTO 


```{c}
auto it = nodesToRemove.begin();
```

#### AUTO 


```{c}
auto it = references.begin();
```

#### AUTO 


```{c}
auto it = m_collections.constBegin();
```

#### AUTO 


```{c}
auto dec = JxlDecoderMake(nullptr);
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
            KisNodeListSP r(new QList<KisNodeSP>());
            KisLayerUtils::recursiveApplyNodes(currentNode,
                                               [&](KisNodeSP item) {
                                                   r->append(item);
                                               });
            return r;
        }
```

#### AUTO 


```{c}
const auto spectrum = image->m_spectrum;
```

#### LAMBDA EXPRESSION 


```{c}
[this](){
        const KoColorSet* const palette = static_cast<const KoColorSet*>(m_paletteWidget->currentResource());
        alphaIndexSpinBox->setMaximum(palette ? int(palette->colorCount() - 1) : 0);
        alphaIndexSpinBox->setValue(std::min(alphaIndexSpinBox->value(), alphaIndexSpinBox->maximum()));
    }
```

#### CONST EXPRESSION 


```{c}
constexpr double maximumAngleDeviationToSkip{M_PI / 1000.0};
```

#### AUTO 


```{c}
const auto v3 = (xsimd::nearbyint_as_int(c2) & mask) << 8;
```

#### AUTO 


```{c}
auto schemeFileLocations = KShortcutSchemesHelper::schemeFileLocations();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() -> void
        {
            int animationDuration;
            qreal animationStartValue;

            if (m_areControlsHidden) {
                if (m_showControlsAnimation.state() == QVariantAnimation::Running) {
                    m_showControlsAnimation.stop();
                    animationDuration =
                        static_cast<int>(std::round((1.0 - m_showControlsAnimation.currentValue().toReal()) * showControlsAnimationDuration));
                    animationStartValue = m_showControlsAnimation.currentValue().toReal();
                } else {
                    animationDuration = showControlsAnimationDuration;
                    animationStartValue = 0.0;
                }
            } else {
                animationDuration = 1;
                animationStartValue = 1.0;
            }

            m_areControlsHidden = false;
            m_showControlsAnimation.setStartValue(animationStartValue);
            m_showControlsAnimation.setEndValue(1.0);
            m_showControlsAnimation.setDuration(animationDuration);
            m_showControlsAnimation.start();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (int channel : channels) {
        if (channel < 0 || channel >= nChannels || m_d->histogramChannelShapeInfo.contains(channel)) {
            continue;
        }
        histogram->setChannel(channel);
        const quint32 highest = histogram->calculations().getHighest();
        QPair<QPolygonF, QPolygonF> shapes = Private::computeHistogramShape(histogram, channel, highest);
        const QPair<QColor, QPainter::CompositionMode> channelPaintingInfo =
            Private::computeChannelPaintigInfo(colorSpace, channel);
        const qreal linearBestCutOffHeight = Private::bestCutOffHeight(shapes.first);
        const qreal logarithmicBestCutOffHeight = Private::bestCutOffHeight(shapes.second);

        Private::smoothHistogramShape(shapes.first);
        Private::smoothHistogramShape(shapes.second);
        Private::simplifyHistogramShape(shapes.first);
        Private::simplifyHistogramShape(shapes.second);

        m_d->histogramChannelShapeInfo.insert(
            channel,
            {
                shapes.first,
                shapes.second,
                highest,
                linearBestCutOffHeight,
                logarithmicBestCutOffHeight,
                channelPaintingInfo.first,
                channelPaintingInfo.second
            }
        );
    }
```

#### AUTO 


```{c}
const auto height = static_cast<size_t>(gmicImage.m_height);
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    DuplicateOption option;
                    option.readOptionSetting(prop->settings().data());
                    option.duplicate_healing = prop->value().toBool();
                    option.writeOptionSetting(prop->settings().data());
                }
```

#### AUTO 


```{c}
auto *channel = layer->getKeyframeChannel(KisKeyframeChannel::Raster.id(), true);
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    CurveOption option;
                    option.readOptionSetting(prop->settings().data());

                    prop->setValue(option.curve_line_width);
                }
```

#### AUTO 


```{c}
auto it = childBegin(tree);
```

#### LAMBDA EXPRESSION 


```{c}
[this, dialog]() { q->setColor(dialog->getCurrentColor()); }
```

#### AUTO 


```{c}
auto *dstPtr = reinterpret_cast<quint16 *>(dst);
```

#### LAMBDA EXPRESSION 


```{c}
[](KoShape *s) { return 1.0 - s->transparency(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](qreal zoomDelta){
        if (m_d->curvesView) {
            m_d->curvesView->changeZoom(Qt::Horizontal, zoomDelta);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                KisDuplicateOptionProperties option;
                option.readOptionSetting(prop->settings().data());
                option.duplicate_healing = prop->value().toBool();
                option.writeOptionSetting(prop->settings().data());
            }
```

#### LAMBDA EXPRESSION 


```{c}
[shared, progress](){
                    shared->filter()->processImpl(shared->filterDevice, shared->processRect,
                                             shared->filterConfig().data(),
                                             progress->updater());
                }
```

#### AUTO 


```{c}
auto it = std::find(strokesQueue.begin(), strokesQueue.end(), finishingStroke);
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    DynaOption option;
                    option.readOptionSetting(prop->settings().data());
                    option.dyna_angle = prop->value().toInt();
                    option.writeOptionSetting(prop->settings().data());
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        Q_FOREACH (KisDecoratedNodeInterface *decoratedNode, m_disabledDecoratedNodes) {
            decoratedNode->setDecorationsVisible(true);
        }
        m_disabledDecoratedNodes.clear();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        QString name;
        name = QInputDialog::getText(this, i18nc("@title:window", "New Workspace..."),
                                                                i18nc("@label:textbox", "Name:"));
        if (name.isEmpty()) {
            return;
        }

        KisWorkspaceResourceSP workspace(new KisWorkspaceResource(""));
        workspace->setDockerState(m_this->saveState());
        workspace->setImage(layoutThumbnail());
        workspace->setValid(true);

        // this line must happen before we save the workspace to resource folder or other places
        // because it mostly just triggers palettes to be saved into the workspace
        d->viewManager->canvasResourceProvider()->notifySavingWorkspace(workspace);
        workspace->setValid(true);

        workspace->setFilename(name.replace(" ", "_") + workspace->defaultFileExtension());
        workspace->setName(name);

        KisResourceUserOperations::addResourceWithUserInput(this, workspace);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[resourceIdToIgnore] (QVector<KoResourceSP> list) {
        int sumHere = 0;
        if (resourceIdToIgnore < 0) {
            return list.size();
        }

        for (int i = 0; i < list.size(); i++) {
            if (list[i]->resourceId() != resourceIdToIgnore) {
                sumHere++;
            }
        }
        return sumHere;
    }
```

#### AUTO 


```{c}
auto preAdjustSegment = [] (Mesh<NodeArg, PatchArg> &mesh,
                                    SegmentIterator it,
                                    const QPointF &normalizedOffset) {

            if (it == mesh.endSegments()) return;

            const QPointF base1 = it.p3() - it.p0();
            const QPointF base2 = it.p3() - it.p0() - normalizedOffset;

            {
                const QPointF control = it.p1() - it.p0();
                const qreal dist0 = KisAlgebra2D::norm(base1);
                const qreal dist1 = KisAlgebra2D::dotProduct(base2, base1) / dist0;
                const qreal coeff = dist1 / dist0;

                it.p1() = it.p0() + coeff * (control);
            }
            {
                const QPointF control = it.p2() - it.p3();
                const qreal dist0 = KisAlgebra2D::norm(base1);
                const qreal dist1 = KisAlgebra2D::dotProduct(base2, base1) / dist0;
                const qreal coeff = dist1 / dist0;

                it.p2() = it.p3() + coeff * (control);
            }
        };
```

#### LAMBDA EXPRESSION 


```{c}
[index, Model] {Model->insertItem(index, true); }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractButton *button : m_d->colorButtonGroup->buttons()) {
        button->setChecked(false);
    }
```

#### AUTO 


```{c}
auto it = d->csMap.find(idsToCacheName(csID, profileName));
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    KisBrushBasedPaintOpSettings *s =
                        dynamic_cast<KisBrushBasedPaintOpSettings*>(prop->settings().data());

                    const qreal angleResult = kisRadiansToDegrees(s->angle());
                    prop->setValue(angleResult);
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto sensor : m_curveOption->activeSensors()) {
            sensor->setCurve(currentCurve);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    ParticleOption option;
                    option.readOptionSetting(prop->settings().data());
                    prop->setValue(option.particle_weight);
                }
```

#### AUTO 


```{c}
auto it = rowNumberList.rbegin();
```

#### AUTO 


```{c}
auto it = std::upper_bound(fontStretches.rbegin(),
                                       fontStretches.rend(),
                                       context.currentGC()->font.stretch(),
                                       std::greater<int>());
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QItemSelection& newSelection, const QItemSelection& /*oldSelection*/) {
            if (newSelection.count() == 0) {
                activeDataChanged(QModelIndex());
            } else {
                activeDataChanged(selectionModel()->currentIndex());
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[firstFrameOfScene, timeOfNextScene, command] (KisNodeSP node){
                if (node->isAnimated()) {
                    Q_FOREACH(KisKeyframeChannel* keyframeChannel, node->keyframeChannels()) {
                        int timeIter = keyframeChannel->keyframeAt(firstFrameOfScene)
                                                                    ? firstFrameOfScene
                                                                    : keyframeChannel->nextKeyframeTime(firstFrameOfScene);

                        while (keyframeChannel->keyframeAt(timeIter) && timeIter < timeOfNextScene) {
                            keyframeChannel->removeKeyframe(timeIter, command);
                            timeIter = keyframeChannel->nextKeyframeTime(timeIter);
                        }
                    }
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    ParticleOption option;
                    option.readOptionSetting(prop->settings().data());
                    option.particle_count = prop->value().toInt();
                    option.writeOptionSetting(prop->settings().data());
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (KoShape* sh: shapeLayer->shapes()) {
            KoShape* newShape = sh->cloneShape();
            KoShapeStrokeSP border(new KoShapeStroke(0.5f, Qt::white));
            newShape->setStroke(border);
            newShape->setBackground(QSharedPointer<KoColorBackground>(new KoColorBackground(QColor(255,255,255,0))));
            newShapes.append(newShape);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](double)
            {
                return 1.0;
            }
```

#### AUTO 


```{c}
auto it = std::lower_bound(m_stops.begin(), m_stops.end(), KoGradientStop(t, KoColor(), COLORSTOP), [](const KoGradientStop& a, const KoGradientStop& b) {
            return a.position < b.position;
            });
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            Q_FOREACH (KisTransformMask *mask, transformMaskCacheHash.keys()) {
                mask->threadSafeForceStaticImageUpdate();
            }
        }
```

#### AUTO 


```{c}
auto it = std::find_if(m_jobsQueue.begin(), m_jobsQueue.end(),
        [] (KisStrokeJob *job) {
            return job->isOwnJob();
        });
```

#### AUTO 


```{c}
const auto& touchpoint
```

#### AUTO 


```{c}
const auto *xmpBackend = KisMetadataBackendRegistry::instance()->value("xmp");
```

#### AUTO 


```{c}
auto it = std::next(beginIt);
```

#### AUTO 


```{c}
auto cprim = [] (qreal x) { return int(x / 0.00002); };
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    KisSprayOptionProperties option;
                    option.readOptionSetting(prop->settings().data());

                    prop->setValue(option.spacing());
                }
```

#### AUTO 


```{c}
auto act = m_proxyModel->data(m_treeView->currentIndex(), Qt::UserRole).value<QAction *>();
```

#### AUTO 


```{c}
const auto t2 = zip_hi(a, b);
```

#### RANGE FOR STATEMENT 


```{c}
for (QUrl url : urls) {

                    if (!url.isLocalFile()) {
                        // download the file and substitute the url
                        KisRemoteFileFetcher fetcher;
                        tmp = new QTemporaryFile();
                        tmp->setAutoRemove(true);
                        if (!fetcher.fetchFile(url, tmp)) {
                            qDebug() << "Fetching" << url << "failed";
                            continue;
                        }
                        url = url.fromLocalFile(tmp->fileName());
                    }
                    if (url.isLocalFile()) {
                        if (action == insertAsNewLayer || action == insertManyLayers) {
                            d->viewManager->imageManager()->importImage(url);
                            activateWindow();
                        }
                        else if (action == insertAsNewFileLayer || action == insertManyFileLayers) {
                            KisNodeCommandsAdapter adapter(viewManager());
                            KisFileLayer *fileLayer = new KisFileLayer(image(), "", url.toLocalFile(),
                                                                       KisFileLayer::None, image()->nextLayerName(), OPACITY_OPAQUE_U8);
                            adapter.addNode(fileLayer, viewManager()->activeNode()->parent(), viewManager()->activeNode());
                        }
                        else if (action == openInNewDocument || action == openManyDocuments) {
                            if (mainWindow()) {
                                mainWindow()->openDocument(url, KisMainWindow::None);
                            }
                        }
                        else if (action == insertAsReferenceImage || action == insertAsReferenceImages) {
                            auto *reference = KisReferenceImage::fromFile(url.toLocalFile(), d->viewConverter);
                            reference->setPosition(d->viewConverter.imageToDocument(cursorPos));
                            d->referenceImagesDecoration->addReferenceImage(reference);

                            KoToolManager::instance()->switchToolRequested("ToolReferenceImages");
                        }

                    }
                    delete tmp;
                    tmp = 0;
                }
```

#### LAMBDA EXPRESSION 


```{c}
[cs, op, srcPtr, dstPtr, numTestablePixels] (int badPixelPos,
            const quint8 *goodSrc,
            const quint8 *goodDst,
            const quint8 *badSrc,
            const quint8 *badDst,
            quint8 opacity,
            quint8 *expectedDst) {

        quint8 *badPixelDstPtr = dstPtr + badPixelPos * cs->pixelSize();

        for (int i = 0; i < numTestablePixels; i++) {
            if (i != badPixelPos) {
                memcpy(srcPtr + cs->pixelSize() * i, goodSrc, cs->pixelSize());
                memcpy(dstPtr + cs->pixelSize() * i, goodDst, cs->pixelSize());
            } else {
                memcpy(srcPtr + cs->pixelSize() * i, badSrc, cs->pixelSize());
                memcpy(dstPtr + cs->pixelSize() * i, badDst, cs->pixelSize());
            }
        }

        op->composite(dstPtr, numPixels * cs->pixelSize(),
                      srcPtr, numPixels * cs->pixelSize(),
                      0, 0,
                      1, numTestablePixels, opacity);

        if (memcmp(badPixelDstPtr, expectedDst, cs->pixelSize()) != 0) {
            qDebug() << "badPixelPos" << badPixelPos;
            qDebug() << "opacity" << opacity;
            qDebug() << "oriS" << badSrc[0] << badSrc[1] << badSrc[2] << badSrc[3];
            qDebug() << "oriS" << badDst[0] << badDst[1] << badDst[2] << badDst[3];
            qDebug() << "expD" << expectedDst[0] << expectedDst[1] << expectedDst[2] << expectedDst[3];
            qDebug() << "dst1" << badPixelDstPtr[0] << badPixelDstPtr[1] << badPixelDstPtr[2] << badPixelDstPtr[3];
            QFAIL("Failed to compose pixels");
        }
    }
```

#### AUTO 


```{c}
auto i = m_channelFFT.begin();
```

#### AUTO 


```{c}
const auto *backend = KisMetadataBackendRegistry::instance()->value("exif");
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& p: patches) {
                    fillPatch(p, type);
                    delete p;
                }
```

#### LAMBDA EXPRESSION 


```{c}
[m_c1](double x)
            {
                return std::exp(-(x * x / m_c1));
            }
```

#### LAMBDA EXPRESSION 


```{c}
[&](boost::optional<QRectF>& to) {
                    double x = scaling.width() * attrMap.namedItem("x").nodeValue().toDouble();
                    double y = scaling.height() * attrMap.namedItem("y").nodeValue().toDouble();
                    double width = scaling.width() * attrMap.namedItem("width").nodeValue().toDouble();
                    double height = scaling.height() * attrMap.namedItem("height").nodeValue().toDouble();
                    to = QRectF(x,y, width, height);
                }
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    DeformOption option;
                    option.readOptionSetting(prop->settings().data());
                    option.deform_action = prop->value().toInt() + 1;
                    option.writeOptionSetting(prop->settings().data());
                }
```

#### AUTO 


```{c}
auto *data = static_cast<JPEGXLImportData *>(that);
```

#### AUTO 


```{c}
auto sizeFilteredById = [resourceIdToIgnore] (QVector<KoResourceSP> list) {
        int sumHere = 0;
        if (resourceIdToIgnore < 0) {
            return list.size();
        }

        for (int i = 0; i < list.size(); i++) {
            if (list[i]->resourceId() != resourceIdToIgnore) {
                sumHere++;
            }
        }
        return sumHere;
    };
```

#### AUTO 


```{c}
auto *currentPixel = pixels.data();
```

#### AUTO 


```{c}
auto it = state->dabsQueue.begin();
```

#### LAMBDA EXPRESSION 


```{c}
[this](){
       this->reset();
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr float MAX_CHANNEL_L = 100;
```

#### AUTO 


```{c}
auto *nextButton = new QPushButton(">>", widget);
```

#### AUTO 


```{c}
auto it = profileMap.constBegin();
```

#### LAMBDA EXPRESSION 


```{c}
[curve, repeat](double x)
        { 
            const double sx = x * static_cast<double>(repeat);
            return 2.0 * x * curve.value(sx - std::floor(sx));
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        auto info{std::make_unique<JxlBasicInfo>()};
        JxlEncoderInitBasicInfo(info.get());
        info->xsize = static_cast<uint32_t>(bounds.width());
        info->ysize = static_cast<uint32_t>(bounds.height());
        {
            if (cs->colorDepthId() == Integer8BitsColorDepthID) {
                info->bits_per_sample = 8;
                info->exponent_bits_per_sample = 0;
                info->alpha_bits = 8;
                info->alpha_exponent_bits = 0;
            } else if (cs->colorDepthId() == Integer16BitsColorDepthID) {
                info->bits_per_sample = 16;
                info->exponent_bits_per_sample = 0;
                info->alpha_bits = 16;
                info->alpha_exponent_bits = 0;
#ifdef HAVE_OPENEXR
            } else if (cs->colorDepthId() == Float16BitsColorDepthID) {
                info->bits_per_sample = 16;
                info->exponent_bits_per_sample = 5;
                info->alpha_bits = 16;
                info->alpha_exponent_bits = 5;
#endif
            } else if (cs->colorDepthId() == Float32BitsColorDepthID) {
                info->bits_per_sample = 32;
                info->exponent_bits_per_sample = 8;
                info->alpha_bits = 32;
                info->alpha_exponent_bits = 8;
            }
        }
        if (cs->colorModelId() == RGBAColorModelID) {
            info->num_color_channels = 3;
            info->num_extra_channels = 1;
        } else if (cs->colorModelId() == GrayAColorModelID) {
            info->num_color_channels = 1;
            info->num_extra_channels = 1;
        } else if (cs->colorModelId() == CMYKAColorModelID) {
            info->num_color_channels = 4;
            info->num_extra_channels = 1;
        }
        info->uses_original_profile = JXL_TRUE;
        if (image->animationInterface()->hasAnimation() && cfg->getBool("haveAnimation", true)) {
            info->have_animation = JXL_TRUE;
            info->animation.have_timecodes = JXL_FALSE;
            info->animation.num_loops = 0;
            // Unlike WebP, JXL does allow for setting proper framerates.
            info->animation.tps_numerator =
                static_cast<uint32_t>(image->animationInterface()->framerate());
            info->animation.tps_denominator = 1;
        }
        return info;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        /**
             * We must request shape layers to rerender areas outside image bounds
             */
        KisLayerUtils::forceAllHiddenOriginalsUpdate(m_s->rootNode);
    }
```

#### AUTO 


```{c}
auto *addLayerCmd = new KisImageLayerAddCommand(
                        m_image, paintLayer, parent, aboveThis, false, true);
```

#### LAMBDA EXPRESSION 


```{c}
[&](QString label, int& index) -> bool {
                    if (attribute.value().startsWith(label)) {
                        if (attribute.value() == label) {
                            index = 0;
                            return true;
                        }

                        QString indexString = attribute.value().remove(0, label.length());
                        bool ok = false;
                        index = indexString.toInt(&ok);
                        if (ok) {
                            if (!elementMap.contains(index))
                                elementMap.insert(index, ExportPageShot());
                            return true;
                        }
                    }
                    return false;
                }
```

#### LAMBDA EXPRESSION 


```{c}
[&](QByteArray arr) {
            QString out = QString(arr);
            QStringList integerOuts = out.split("\n", QString::SkipEmptyParts);
            Q_FOREACH(const QString& str, integerOuts){
                bool ok = false;
                const int value = str.toUInt(&ok);
                if (ok) {
                    frameTimeList.push_back(value);
                }
            }
        }
```

#### AUTO 


```{c}
auto function = std::bind(&KisColorSelector::slotUpdateColorAndPreview, this, _1);
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {
            runAndSaveCommand(toQShared(new KisUpdateCommandEx(m_updateData, m_updatesFacade, KisUpdateCommandEx::INITIALIZING)), KisStrokeJobData::BARRIER, KisStrokeJobData::NORMAL);
            m_updatesDisabled = true;
            m_updatesFacade->disableDirtyRequests();
        }
```

#### AUTO 


```{c}
auto source = m_d->cachedFlattenedPattern.source<KoPattern>(ResourceType::Patterns);
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
            KisNodeListSP r(new QList<KisNodeSP>());
            KisLayerUtils::recursiveApplyNodes(
                image->root(),
                [&](KisNodeSP item) {
                    auto *paintLayer =
                        dynamic_cast<KisPaintLayer *>(item.data());
                    if (paintLayer
                        && paintLayer->visible(false) == visibility) {
                        r->append(item);
                    }
                });
            return r;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](qreal zoomDelta){
        const qreal currentZoomLevel = m_d->verticalHeader->scale();
        m_d->verticalHeader->setScale(currentZoomLevel + zoomDelta / m_d->verticalHeader->step());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[image, node, channelId, time, copy] () mutable -> KUndo2Command* {
                bool result = false;

                QScopedPointer<KUndo2Command> cmd(new KUndo2Command());

                KisKeyframeChannel *channel = node->getKeyframeChannel(channelId);
                quint8 originalOpacity = node->opacity();
                bool createdChannel = false;

                // Try get channel...
                if (!channel) {
                    node->enableAnimation();
                    channel = node->getKeyframeChannel(channelId, true);
                    if (!channel) return nullptr;

                    createdChannel = true;
                }

                if (copy && channel->activeKeyframeAt(time)) {
                    if (!channel->keyframeAt(time)) {
                        channel->copyKeyframe(channel->activeKeyframeTime(time), time, cmd.data());
                        result = true;
                    }
                } else {
                    if (channel->keyframeAt(time) && !createdChannel) { // Overwrite existing...
                        if (image->animationInterface()->currentTime() == time && channelId == KisKeyframeChannel::Raster.id()) {

                            //shortcut: clearing the image instead
                            KisPaintDeviceSP device = node->paintDevice();
                            if (device) {
                                const QRect dirtyRect = device->extent();

                                KisTransaction transaction(kundo2_i18n("Clear"), device, cmd.data());
                                device->clear();
                                (void) transaction.endAndTake(); // saved as 'parent'

                                node->setDirty(dirtyRect);

                                result = true;
                            }
                        }
                    } else { // Make new...
                        KisKeyframeSP previousKey = channel->activeKeyframeAt(time);

                        channel->addKeyframe(time, cmd.data());

                        // Use color label of previous key, if exists...
                        if (previousKey && channel->keyframeAt(time)) {
                            channel->keyframeAt(time)->setColorLabel(previousKey->colorLabel());
                        }

                        result = true;
                    }
                }

                // when a new opacity keyframe is created, the opacity is set to 0
                // this makes sure to use the opacity that was previously used
                // maybe there is a better way to do this
                node->setOpacity(originalOpacity);

                return result ? new KisCommandUtils::SkipFirstRedoWrapper(cmd.take()) : nullptr;
        }
```

#### AUTO 


```{c}
auto path = dlg.selectedFiles().first();
```

#### LAMBDA EXPRESSION 


```{c}
LAZY_STATIC_CATEGORY_DISPLAY_NAME("hsv")
```

#### LAMBDA EXPRESSION 


```{c}
[this, editor, index](int)
                                        {
                                            handleEditorContainer->insertWidget(index, editor);
                                            handleEditorContainer->setCurrentIndex(index);
                                        }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto *i : m_lineList) {
        i->updateSettings();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    KisSprayOptionProperties option;
                    option.readOptionSetting(prop->settings().data());

                    prop->setValue(option.spacing);
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (KoResourceSP res) {
                                   return res->resourceType().first == this->m_resourceType;
                               }
```

#### AUTO 


```{c}
auto it = groups.begin();
```

#### AUTO 


```{c}
auto *page = new QWidget(this);
```

#### LAMBDA EXPRESSION 


```{c}
[] (const KisBaseNode::Property &prop) {
            return prop.id == KisLayerPropertiesIcons::layerError.id();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](QtMsgType type, const QMessageLogContext &context, const QString &msg) {
                Q_UNUSED(type)
                Q_UNUSED(context)
                qpaDetectionLog.append(msg);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[](qreal t1, qreal t2, qreal t3, qreal t4, qreal sign) -> qreal
        {
            return (t1 + sign * t2) / t3 + t4;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto menuAction : qAsConst(menuActions)) {
                if (menuAction) {
                    list.append({KLocalizedString::removeAcceleratorMarker(act->text()), menuAction});
                }
            }
```

#### AUTO 


```{c}
auto rect = prepareRegion.begin();
```

#### CONST EXPRESSION 


```{c}
static constexpr const int ICON_SIZE_LENGTH = 48;
```

#### LAMBDA EXPRESSION 


```{c}
[this, sharedData]() {
        KisNodeList filteredRoots = KisLayerUtils::sortAndFilterMergableInternalNodes(m_processedNodes, true);
        Q_FOREACH (KisNodeSP root, filteredRoots) {
            sharedData->addUpdate(root, root->projectionPlane()->tightUserVisibleBounds());
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&minPixel, &maxPixel](quint8 pixel) {
                                        if (pixel > maxPixel) {
                                            maxPixel = pixel;
                                        }
                                        if (pixel < minPixel) {
                                            minPixel = pixel;
                                        }
                                    }
```

#### AUTO 


```{c}
auto lastValueToKeep = samples.end();
```

#### DECLTYPE 


```{c}
typedef __typeof__(((elf_aux_entry*) 0)->a_un.a_val) elf_aux_val_t;
```

#### AUTO 


```{c}
auto *kisPart = KisPart::instance();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        /**
          * We must ensure that the currently selected subtree
          * has finished all its updates.
          */
        KisLayerUtils::forceAllDelayedNodesUpdate(m_d->rootNode);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](quint8 v) {
            return v < MASK_CLEAR;
        }
```

#### AUTO 


```{c}
auto valIt = allValues.constBegin();
```

#### AUTO 


```{c}
auto *reference = KisReferenceImage::fromFile(url.toLocalFile(), d->viewConverter);
```

#### AUTO 


```{c}
const auto &loader
```

#### AUTO 


```{c}
auto neighbourIt = mesh.find(ControlPointIndex(index.nodeIndex, type));
```

#### AUTO 


```{c}
auto bytesRead = psdreadBytes(device, S);
```

#### AUTO 


```{c}
const auto list = [&shortcutString] {
#if QT_VERSION < QT_VERSION_CHECK(5, 15, 0)
                auto list = shortcutString.split(QLatin1Char('+'), QString::SkipEmptyParts);
#else
                auto list = shortcutString.split(QLatin1Char('+'), Qt::SkipEmptyParts);
#endif
                if (shortcutString.endsWith(QLatin1String("+"))) {
                    list.append(QStringLiteral("+"));
                }
                return list;
            }();
```

#### RANGE FOR STATEMENT 


```{c}
for (Path p : currentPaths) {
            Node* endNode = p.endNode();
            for (Vertex* v : endNode->outputVertexes) {
                if (!p.contains(v->dstNode) &&  v->dstNode->isInitialized) {
                    Path newP = p;  // Candidate
                    newP.appendVertex(v);
                    Node* newEndNode = newP.endNode();
                    if (newEndNode == dstNode) {
                        if (pQC.isGoodPath(newP)) { // Victory
                            newP.isGood = true;
                            return newP;
                        } else if (pQC.lessWorseThan(newP, currentBestPath)) {
                            Q_ASSERT(newP.startNode()->id() == currentBestPath.startNode()->id());
                            Q_ASSERT(newP.endNode()->id() == currentBestPath.endNode()->id());
                            // Can we do better than dumping memory values???
                            // warnPigment << pQC.lessWorseThan(newP, currentBestPath) << " " << newP << "  " << currentBestPath;
                            currentBestPath = newP;
                        }
                    } else {
                        // This is an incomplete path. Check if there's a better way to get to its endpoint.
                        if (node2path.contains(newEndNode)) {
                            Path p2 = node2path[newEndNode];
                            if (pQC.lessWorseThan(newP, p2)) {
                                node2path[ newEndNode ] = newP;
                                possiblePaths.append(newP);
                            }
                        } else {
                            node2path[ newEndNode ] = newP;
                            possiblePaths.append(newP);
                        }
                    }
                }
            }
            possiblePaths.removeAll(p); // Remove from list of remaining paths
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Vertex* v : endNode->outputVertexes) {
                if (!p.contains(v->dstNode) &&  v->dstNode->isInitialized) {
                    Path newP = p;  // Candidate
                    newP.appendVertex(v);
                    Node* newEndNode = newP.endNode();
                    if (newEndNode == dstNode) {
                        if (pQC.isGoodPath(newP)) { // Victory
                            newP.isGood = true;
                            return newP;
                        } else if (pQC.lessWorseThan(newP, currentBestPath)) {
                            Q_ASSERT(newP.startNode()->id() == currentBestPath.startNode()->id());
                            Q_ASSERT(newP.endNode()->id() == currentBestPath.endNode()->id());
                            // Can we do better than dumping memory values???
                            // warnPigment << pQC.lessWorseThan(newP, currentBestPath) << " " << newP << "  " << currentBestPath;
                            currentBestPath = newP;
                        }
                    } else {
                        // This is an incomplete path. Check if there's a better way to get to its endpoint.
                        if (node2path.contains(newEndNode)) {
                            Path p2 = node2path[newEndNode];
                            if (pQC.lessWorseThan(newP, p2)) {
                                node2path[ newEndNode ] = newP;
                                possiblePaths.append(newP);
                            }
                        } else {
                            node2path[ newEndNode ] = newP;
                            possiblePaths.append(newP);
                        }
                    }
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KisNodeSP node) {
                  return !node->userLocked();
                }
```

#### RANGE FOR STATEMENT 


```{c}
for(KoGamutMaskShape* shape: *shapeVector) {
        shape->paint(painter);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    HatchingOption option;
                    option.readOptionSetting(prop->settings().data());
                    prop->setValue(option.angle);
                }
```

#### AUTO 


```{c}
const auto &lang
```

#### AUTO 


```{c}
auto it = d->groups[g.key()].begin();
```

#### RANGE FOR STATEMENT 


```{c}
for(FakeReplyData& replyData: replyDataList) {
        feedList << replyData.url.toString();
        nam->setReplyData(replyData);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, modifiers] (Qt::Key key, Qt::KeyboardModifier modifier) {
        return m_d->keys.contains(key) == bool(modifiers & modifier);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    ExperimentOption option;
                    option.readOptionSetting(prop->settings().data());
                    option.smoothing = prop->value().toInt();
                    option.writeOptionSetting(prop->settings().data());
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this](){
        noiseSeedLineEdit->setText(QString::number(rand()));
    }
```

#### AUTO 


```{c}
auto addPoint = [&points](const QPoint &point) -> void { points.append(point); };
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    KisBrushBasedPaintOpSettings *s =
                        dynamic_cast<KisBrushBasedPaintOpSettings*>(prop->settings().data());

                    const qreal value = s->autoSpacingActive() ?
                        s->autoSpacingCoeff() : s->spacing();
                    prop->setValue(value);
                }
```

#### AUTO 


```{c}
auto iterateThroughRects =
                [&] (const QPointF &offset) {

                    while (1) {
                        rc.translate(offset);
                        QRectF widgetRc = m_d->coordinatesConverter->imageToWidget(rc);

                        widgetRc &= widgetRect;

                        if (widgetRc.isEmpty()) {
                            break;
                        } else {
                            updateRects.append(widgetRc.toAlignedRect());
                        }
                    }
                };
```

#### LAMBDA EXPRESSION 


```{c}
[&](KisNodeSP item) {
                                                   r->append(item);
                                               }
```

#### AUTO 


```{c}
auto isNodeWeird = [] (KisNodeSP node) {
            const bool normalCompositeMode = node->compositeOpId() == COMPOSITE_OVER;

            KisLayer *layer = dynamic_cast<KisLayer*>(node.data());
            const bool hasInheritAlpha = layer && layer->alphaChannelDisabled();
            return !normalCompositeMode && !hasInheritAlpha;
        };
```

#### LAMBDA EXPRESSION 


```{c}
[image, node, channelId, time, copy] () mutable -> KUndo2Command* {
                bool result = false;

                QScopedPointer<KUndo2Command> cmd(new KUndo2Command());

                KisKeyframeChannel *channel = node->getKeyframeChannel(channelId);
                bool isScalar = (channelId != KisKeyframeChannel::Raster.id());
                quint8 originalOpacity = node->opacity();
                bool createdChannel = false;

                // Try get channel...
                if (!channel) {
                    node->enableAnimation();
                    channel = node->getKeyframeChannel(channelId, true);
                    if (!channel) return nullptr;

                    createdChannel = true;
                }

                if (copy && channel->activeKeyframeAt(time)) {
                    if (!channel->keyframeAt(time)) {
                        channel->copyKeyframe(channel->activeKeyframeTime(time), time, cmd.data());
                        result = true;
                    }
                } else {
                    if (channel->keyframeAt(time) && !createdChannel) { // Overwrite existing...
                        if (image->animationInterface()->currentTime() == time && channelId == KisKeyframeChannel::Raster.id()) {

                            //shortcut: clearing the image instead
                            KisPaintDeviceSP device = node->paintDevice();
                            if (device) {
                                const QRect dirtyRect = device->extent();

                                KisTransaction transaction(kundo2_i18n("Clear"), device, cmd.data());
                                device->clear();
                                (void) transaction.endAndTake(); // saved as 'parent'

                                node->setDirty(dirtyRect);

                                result = true;
                            }
                        }
                    } else { // Make new...
                        KisKeyframeSP previousKey = channel->activeKeyframeAt(time);

                        if (isScalar && previousKey) {
                            KisScalarKeyframeChannel* scalarChannel = static_cast<KisScalarKeyframeChannel*>(channel);
                            const qreal value = scalarChannel->valueAt(time); //Get interpolated value.
                            scalarChannel->addScalarKeyframe(time, value, cmd.data());
                        } else {
                            channel->addKeyframe(time, cmd.data());
                        }

                        // Use color label of previous key, if exists...
                        if (previousKey && channel->keyframeAt(time)) {
                            channel->keyframeAt(time)->setColorLabel(previousKey->colorLabel());
                        }

                        result = true;
                    }
                }

                // when a new opacity keyframe is created, the opacity is set to 0
                // this makes sure to use the opacity that was previously used
                // maybe there is a better way to do this
                node->setOpacity(originalOpacity);

                return result ? new KisCommandUtils::SkipFirstRedoWrapper(cmd.take()) : nullptr;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Private::Column &c : d->colorMatrix) {
        int i = 0;
        for (const KisSwatch &s : c.values()) {
            SwatchInfo info = {d->name, s, c.keys()[i++], column};
            res.append(info);
        }
        column++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& patch: row) {
            delete patch;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    DynaOption option;
                    option.readOptionSetting(prop->settings().data());

                    prop->setValue(option.dyna_diameter);
                }
```

#### LAMBDA EXPRESSION 


```{c}
[] (qreal x) { return int(x / 0.00002); }
```

#### AUTO 


```{c}
const auto nPixels = tileWidth * tileHeight;
```

#### AUTO 


```{c}
auto waitForImage = [] (KisImageSP image) {
        KisMainWindow *window = KisPart::instance()->currentMainwindow();
        if (window) {
            if (window->viewManager()) {
                window->viewManager()->blockUntilOperationsFinishedForced(image);
            }
        }
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this, args]() {
        m_d->currentTransformArgs = args;
        m_d->updateTimer.restart();
        // sanity check that no job has been squeezed inbetween
        KIS_SAFE_ASSERT_RECOVER_RETURN(!m_d->pendingUpdateArgs);
    }
```

#### AUTO 


```{c}
const auto t1 = batch<T, A>::load(srcPtr, U{});
```

#### AUTO 


```{c}
auto *dstPixel = reinterpret_cast<RGBPixel *>(dst);
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    KisPressurePaintThicknessOption option;
                    option.readOptionSetting(prop->settings().data());

                    prop->setValue(int(option.getThicknessMode()) - 1);
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this, i](const T *d) {
                    const T alpha = std::abs(d[this->poses()[i]]);

                    if (alpha >= static_cast<T>(0.01)) {
                        return true;
                    } else {
                        for (size_t i = 0; i < this->nbColorsSamples(); i++) {
                            if (!qFuzzyCompare(T(d[i] * alpha), d[i])) {
                                return false;
                            }
                        }
                        return true;
                    }
                }
```

#### AUTO 


```{c}
const auto numContiguousImageColumns =
                static_cast<size_t>(it->numContiguousColumns(imageX));
```

#### LAMBDA EXPRESSION 


```{c}
[&](JxlEncoderFrameSettingId id, int v) {
            // https://github.com/libjxl/libjxl/issues/1210
            if (id == JXL_ENC_FRAME_SETTING_RESAMPLING && v == -1)
                return true;
            if (JxlEncoderFrameSettingsSetOption(frameSettings, id, v) != JXL_ENC_SUCCESS) {
                errFile << "JxlEncoderSetFrameLossless failed";
                return false;
            }
            return true;
        }
```

#### AUTO 


```{c}
auto applyChangeToStrokes(ModifyFunction modifyFunction)
        -> decltype(modifyFunction(KoShapeStrokeSP()), void())
{
    KoCanvasController* canvasController = KoToolManager::instance()->activeCanvasController();
    KoSelection *selection = canvasController->canvas()->shapeManager()->selection();

    if (!selection) return;

    QList<KoShape*> shapes = selection->selectedEditableShapes();

    KUndo2Command *command = KoFlake::modifyShapesStrokes(shapes, modifyFunction);

    if (command) {
        canvasController->canvas()->addCommand(command);
    }
}
```

#### AUTO 


```{c}
auto it = std::find_if(Private::caches.begin(), Private::caches.end(),
                           [image] (KisAnimationFrameCache *cache) { return cache->image() == image; });
```

#### AUTO 


```{c}
const auto collection
```

#### AUTO 


```{c}
const auto pixelFormat = [&]() {
        JxlPixelFormat pixelFormat{};
        if (cs->colorDepthId() == Integer8BitsColorDepthID) {
            pixelFormat.data_type = JXL_TYPE_UINT8;
        } else if (cs->colorDepthId() == Integer16BitsColorDepthID) {
            pixelFormat.data_type = JXL_TYPE_UINT16;
#ifdef HAVE_OPENEXR
        } else if (cs->colorDepthId() == Float16BitsColorDepthID) {
            pixelFormat.data_type = JXL_TYPE_FLOAT16;
#endif
        } else if (cs->colorDepthId() == Float32BitsColorDepthID) {
            pixelFormat.data_type = JXL_TYPE_FLOAT;
        }
        if (cs->colorModelId() == RGBAColorModelID) {
            pixelFormat.num_channels = 4;
        } else if (cs->colorModelId() == GrayAColorModelID) {
            pixelFormat.num_channels = 2;
        } else if (cs->colorModelId() == CMYKAColorModelID) {
            pixelFormat.num_channels = 5;
        }
        return pixelFormat;
    }();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &action : m_deferedActions) {
                action();
            }
```

#### LAMBDA EXPRESSION 


```{c}
[shared, progress](){
                        shared->filter()->processImpl(shared->filterDevice, shared->processRect,
                                                      shared->filterConfig().data(),
                                                      progress->updater());
                    }
```

#### AUTO 


```{c}
const auto *layer = dynamic_cast<KisLayer *>(node);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        m_updatesFacade->disableDirtyRequests();
        m_updatesDisabled = true;

        for (auto it = std::make_reverse_iterator(m_transformCommands.end());
             it != std::make_reverse_iterator(m_transformCommands.begin());
             ++it) {

            executeCommand(*it, true);
        }
        m_transformCommands.clear();

        KIS_SAFE_ASSERT_RECOVER_RETURN(m_pendingUpdateArgs);
        m_currentTransformArgs = *m_pendingUpdateArgs;
        m_pendingUpdateArgs = boost::none;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[url](const KisRecentFilesEntry &item) {
        return item.m_url == url;
    }
```

#### CONST EXPRESSION 


```{c}
constexpr int shlobj_KF_FLAG_RETURN_FILTER_REDIRECTION_TARGET = 0x00040000;
```

#### RANGE FOR STATEMENT 


```{c}
for (QPointer<KisView> view : KisPart::instance()->views()) {
            if (view && view->document() == document->document()) {
                KisProcessingApplicator::runSingleCommandStroke(view->image(), view->canvasBase()->shapeController()->removeShape(d->shape));
                view->image()->waitForDone();
                removeStatus = true;
                break;
            }
        }
```

#### AUTO 


```{c}
auto occurrence
```

#### AUTO 


```{c}
const auto *defaults = dynamic_cast<const KisMultiChannelFilterConfiguration*>(defaultConfiguration.data());
```

#### LAMBDA EXPRESSION 


```{c}
[this, args, levelOfDetail, updateData, useHoldUI, commandGroup]() {

        // it has its own dirty requests blocking inside
        undoTransformCommands(levelOfDetail);

        if (useHoldUI) {
            executeAndAddCommand(new KisHoldUIUpdatesCommand(m_d->updatesFacade, KisCommandUtils::FlipFlopCommand::INITIALIZING), commandGroup, KisStrokeJobData::BARRIER);
        }

        executeAndAddCommand(new KisUpdateCommandEx(updateData, m_d->updatesFacade, KisUpdateCommandEx::INITIALIZING, m_d->commandUpdatesBlockerCookie), commandGroup, KisStrokeJobData::BARRIER);
        executeAndAddCommand(new KisDisableDirtyRequestsCommand(m_d->updatesFacade, KisUpdateCommandEx::INITIALIZING), commandGroup, KisStrokeJobData::BARRIER);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
            m_this->restoreWorkspace(w);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[root, &nodesToHide, &rootNeedsCarefulRemoval] (KisNodeSP node) {
                                        if (!node->isEditable(false)) {
                                            while (node != root) {
                                                nodesToHide.insert(node);
                                                node = node->parent();
                                                KIS_SAFE_ASSERT_RECOVER_BREAK(node);
                                            }
                                            nodesToHide.insert(root);
                                            rootNeedsCarefulRemoval = true;
                                        }
                                    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {
                            this->issueSetDirtySignals();
                        }
```

#### AUTO 


```{c}
auto it = d->availableColorspaces.find(profile->name());
```

#### AUTO 


```{c}
auto tryIssueCanvasUpdates = [this](const QRect &vRect) {
        if (!m_d->isBatchUpdateActive) {
            // TODO: Implement info->dirtyViewportRect() for KisOpenGLCanvas2 to avoid updating whole canvas
            if (m_d->currentCanvasIsOpenGL) {
                m_d->savedUpdateRect = QRect();

                // we already had a compression in frameRenderStartCompressor, so force the update directly
                slotDoCanvasUpdate();
            } else if (/* !m_d->currentCanvasIsOpenGL && */ !vRect.isEmpty()) {
                m_d->savedUpdateRect = m_d->coordinatesConverter->viewportToWidget(vRect).toAlignedRect();

                // we already had a compression in frameRenderStartCompressor, so force the update directly
                slotDoCanvasUpdate();
            }
        }
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &resname : names) {
        if (QFile(resname).exists()) {
            QIcon icon(resname);
            return icon;
        }
    }
```

#### AUTO 


```{c}
auto found = std::find_if(m_entries.constBegin(), m_entries.constEnd(), [url](const KisRecentFilesEntry &item) {
        return item.m_url == url;
    });
```

#### AUTO 


```{c}
const auto numChannels = gmicImage._spectrum;
```

#### LAMBDA EXPRESSION 


```{c}
[&numFetches](const QString &name) {
            numFetches++;
            const QString fileName = TestUtil::fetchDataFileLazy(name);
            QFile file(fileName);
            KIS_ASSERT(file.exists());
            file.open(QIODevice::ReadOnly);
            return file.readAll();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](qreal overscroll){
        m_d->horizontalHeader->setPixelOffset(m_d->horizontalHeader->offset() + overscroll);
        slotUpdateInfiniteFramesCount();
        slotUpdateHorizontalScrollbarSize();
        viewport()->update();
    }
```

#### AUTO 


```{c}
auto stroke
```

#### AUTO 


```{c}
auto *rServer = KoResourceServerProvider::instance()->seExprScriptServer();
```

#### AUTO 


```{c}
auto end = m_d->dataObjects.end();
```

#### AUTO 


```{c}
auto it = spy.begin();
```

#### LAMBDA EXPRESSION 


```{c}
[](quint8 & v) {
            v = (v < MASK_CLEAR) ? MASK_SET : MASK_CLEAR;
        }
```

#### AUTO 


```{c}
auto columnsToWork =
                qMin(numContiguousImageColumns, columnsRemaining);
```

#### LAMBDA EXPRESSION 


```{c}
[](const KColorSchemeModelData & first, const KColorSchemeModelData & second) {
        return first.name < second.name;
    }
```

#### AUTO 


```{c}
const auto prefix = fileInfo.dir();
```

#### LAMBDA EXPRESSION 


```{c}
[image, node, channelId, time, copy] () mutable -> KUndo2Command* {
                bool result = false;

                QScopedPointer<KUndo2Command> cmd(new KUndo2Command());

                KisKeyframeChannel *channel = node->getKeyframeChannel(channelId);
                bool createdChannel = false;

                if (!channel) {
                    node->enableAnimation();
                    channel = node->getKeyframeChannel(channelId, true);
                    if (!channel) return nullptr;

                    createdChannel = true;
                }

                if (copy) {
                    if (!channel->keyframeAt(time)) {
                        KisKeyframeSP srcFrame = channel->activeKeyframeAt(time);
                        channel->copyKeyframe(srcFrame, time, cmd.data());
                        result = true;
                    }
                } else {
                    if (channel->keyframeAt(time) && !createdChannel) {
                        if (image->animationInterface()->currentTime() == time && channelId == KisKeyframeChannel::Content.id()) {

                            //shortcut: clearing the image instead
                            KisPaintDeviceSP device = node->paintDevice();
                            if (device) {
                                const QRect dirtyRect = device->extent();

                                KisTransaction transaction(kundo2_i18n("Clear"), device, cmd.data());
                                device->clear();
                                (void) transaction.endAndTake(); // saved as 'parent'

                                node->setDirty(dirtyRect);

                                result = true;
                            }
                        }
                    } else {
                        channel->addKeyframe(time, cmd.data());
                        result = true;
                    }
                }

                return result ? new KisCommandUtils::SkipFirstRedoWrapper(cmd.take()) : nullptr;
        }
```

#### AUTO 


```{c}
auto numContiguousColumns =
                    qMin(static_cast<size_t>(it->numContiguousColumns(x)),
                         optimalBufferSize);
```

#### AUTO 


```{c}
auto it = sharedData->begin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &groupName : m_colorSet->getGroupNames()) {
        m_groupNameRows[row] = groupName;
        row += m_colorSet->getGroup(groupName)->rowCount();
        row += 1; // row for group name
    }
```

#### AUTO 


```{c}
auto readOldFunc = [this] (int col, int row) {
                            KisTileSP tile = dm.getOldTile(col, row);
                            tile->lockForRead();
                            tile->unlockForRead();
                        };
```

#### RANGE FOR STATEMENT 


```{c}
for (const VirtualChannelInfo &channelInfo : m_virtualChannels) {
                    if (channelInfo.type() == VirtualChannelInfo::REAL && !channelInfo.isAlpha()) {
                        channels.append(channelInfo.pixelIndex());
                    }
                }
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    DuplicateOption option;
                    option.readOptionSetting(prop->settings().data());
                    option.duplicate_move_source_point = prop->value().toBool();
                    option.writeOptionSetting(prop->settings().data());
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this](qreal value){
        m_d->horizontalHeader->setPixelOffset(value);
        slotUpdateInfiniteFramesCount();
        viewport()->update();
    }
```

#### AUTO 


```{c}
auto checkIsIgnoreEpic = [](const QString &arg) {
            // List according to https://dev.epicgames.com/docs/services/en-US/Interfaces/Auth/index.html#epicgameslauncher
            static const QStringList epicIgnoreArgsStart = {
                QStringLiteral("AUTH_PASSWORD="),
                QStringLiteral("AUTH_LOGIN="),
                QStringLiteral("AUTH_TYPE="),
                QStringLiteral("epicapp="),
                QStringLiteral("epicenv="),
                QStringLiteral("epicusername="),
                QStringLiteral("epicuserid="),
                QStringLiteral("epiclocale="),
                QStringLiteral("epicsandboxid="),
            };
            static const QStringList epicIgnoreArgsExact = {
                QStringLiteral("EpicPortal"),
            };
            QStringRef argDashless(&arg);
            // Strip leading dashes.
            while (argDashless.startsWith('-')) {
                argDashless = argDashless.mid(1);
            }
            Q_FOREACH(const auto &argToIgnore, epicIgnoreArgsStart) {
                if (argDashless.startsWith(argToIgnore, Qt::CaseInsensitive)) {
                    return true;
                }
            }
            Q_FOREACH(const auto &argToIgnore, epicIgnoreArgsExact) {
                if (argDashless.compare(argToIgnore, Qt::CaseInsensitive) == 0) {
                    return true;
                }
            }
            return false;
        };
```

#### LAMBDA EXPRESSION 


```{c}
[] (KisColorfulBrush *colorfulBrush, bool forceColorToAlpha) {
        /**
         * In Krita versions before 4.4 series "ColorAsMask" could
         * be overridden to false when the brush had no **color**
         * inside. That changed in Krita 4.4.x series, when
         * "brushApplication" replaced all the automatic heuristics
         */
        return (colorfulBrush && colorfulBrush->hasColorAndTransparency() && !forceColorToAlpha) ? IMAGESTAMP : ALPHAMASK;
    }
```

#### AUTO 


```{c}
const auto outputFileName = TestUtil::fetchDataFileLazy("/results/hdr_cosmos01000_cicp9-16-0_lossless.kra");
```

#### AUTO 


```{c}
auto *reference = KisReferenceImage::fromFile(filename, *kisCanvas->coordinatesConverter());
```

#### AUTO 


```{c}
auto isValidLabel = [&](QString label, int& index) -> bool {
                    if (attribute.value().startsWith(label)) {
                        QString indexString = attribute.value().remove(0, label.length());
                        bool ok = false;
                        index = indexString.toInt(&ok);
                        if (ok) {
                            if (!elementMap.contains(index))
                                elementMap.insert(index, ExportLayoutElement());
                            return true;
                        }
                    }
                    return false;
                };
```

#### AUTO 


```{c}
const auto *filter
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const QString &id, bool value) {
        KisAction *action = m_d->actionMan->actionByName(id);
        KIS_SAFE_ASSERT_RECOVER_RETURN(action);
        action->setEnabled(value);
    }
```

#### AUTO 


```{c}
auto *buf = reinterpret_cast<uint_v *>(xsimd::vector_aligned_malloc<typename uint_v::value_type>(vectorSize));
```

#### LAMBDA EXPRESSION 


```{c}
[](bool forgettable) {
                Q_UNUSED(forgettable);
                return KisSuspendResumePair(
                    new KisTestingStrokeStrategy(QLatin1String("sync_u_"), false, true, true),
                    QList<KisStrokeJobData*>());
            }
```

#### AUTO 


```{c}
const auto poses = [&]() -> std::array<quint8, 5> {
                if (sample_format == SAMPLEFORMAT_IEEEFP) {
                    return {0, 1, 2, 3};
                } else {
                    return {2, 1, 0, 3};
                }
            }();
```

#### LAMBDA EXPRESSION 


```{c}
[&typedResources] (const QString &filename) {
            return typedResources.contains(filename);
        }
```

#### AUTO 


```{c}
auto cg = KConfigGroup(KSharedConfig::openConfig("kritashortcutsrc"), "Shortcuts");
```

#### AUTO 


```{c}
const auto isUniformRGBValue = [&](){
        if (isAllGray) {
            bool firstSample = true;
            int value = 0;
            for (int row = 0; row < image.height(); row++) {
                for (int column = 0; column < image.width(); column++) {
                    if (firstSample) {
                        value = qBlue(image.pixel(column, row));
                        firstSample = false;
                    } else {
                        if (value != qBlue(image.pixel(column, row))) {
                            return false;
                        }
                    }
                }
            }
            return true;
        }
        return false;
    };
```

#### AUTO 


```{c}
const auto& i
```

#### AUTO 


```{c}
auto sbTester = new QAbstractItemModelTester(m_storyboardModel, this);
```

#### AUTO 


```{c}
auto *dstPtr = static_cast<T *>(dst);
```

#### AUTO 


```{c}
const auto setSetting = [&](JxlEncoderFrameSettingId id, int v) {
            // https://github.com/libjxl/libjxl/issues/1210
            if (id == JXL_ENC_FRAME_SETTING_RESAMPLING && v == -1)
                return true;
            if (JxlEncoderFrameSettingsSetOption(frameSettings, id, v) != JXL_ENC_SUCCESS) {
                errFile << "JxlEncoderSetFrameLossless failed";
                return false;
            }
            return true;
        };
```

#### AUTO 


```{c}
auto iconIt = icons.constBegin();
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool){
            if (!m_canvas) return;

            QModelIndex currentSelection = m_ui->sceneView->currentIndex();
            if (currentSelection.parent().isValid()) {
                currentSelection = currentSelection.parent();
            }

            if (currentSelection.isValid()) {
                int row = currentSelection.row();
                KisRemoveStoryboardCommand *command = new KisRemoveStoryboardCommand(row, m_storyboardModel->getData().at(row), m_storyboardModel.data());

                m_storyboardModel->removeItem(currentSelection, command);
                m_storyboardModel->pushUndoCommand(command);
            }
        }
```

#### AUTO 


```{c}
auto pi
```

#### AUTO 


```{c}
auto rc = processRegion.begin();
```

#### LAMBDA EXPRESSION 


```{c}
[](T *d) { return !(std::abs(d[3]) < std::numeric_limits<T>::epsilon()); }
```

#### AUTO 


```{c}
const auto rlast = rend - 1;
```

#### RANGE FOR STATEMENT 


```{c}
for (cmsFloat32Number value : inputValues) {
        cmsFloat32Number cValue = value;

        // Prophoto RGB according to css 4 specs.

        if (value > 1.0/512.0){
            cValue = powf(value, 1/1.8) ;
        } else if (value < 0.0228 && value > 0.0){
            cValue = 16.0 * value;
        }

        /*
        double lValue;
        if (cValue > 16.0/512.0){
            lValue = powf(cValue, 1.8);
        } else {
            lValue = cValue * 1/16.0;
        }
        */

        cmsFloat32Number lValue = cmsEvalToneCurveFloat(curve, cValue);
        QVERIFY2(fabs(lValue - value) < 0.000001, QString("Values don't match for ProPhoto: %1 %2").arg(value).arg(lValue).toLatin1());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, applyTransform]() {
        Q_FOREACH (KisSelectionSP selection, m_deactivatedSelections) {
            selection->setVisible(true);
        }

        Q_FOREACH (KisNodeSP node, m_hiddenProjectionLeaves) {
            node->projectionLeaf()->setTemporaryHiddenFromRendering(false);
        }

        if (applyTransform) {
            KisStrokeStrategyUndoCommandBased::finishStrokeCallback();
        } else {
            KisStrokeStrategyUndoCommandBased::cancelStrokeCallback();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (int index : value) {
        writeValue.append(index);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    ExperimentOption option;
                    option.readOptionSetting(prop->settings().data());

                    prop->setValue(int(option.smoothing));
                }
```

#### CONST EXPRESSION 


```{c}
constexpr int fixedPaintTimerInterval = 20;
```

#### RANGE FOR STATEMENT 


```{c}
for (heif_item_id id : metadata_IDs) {

          if (handle.get_metadata_type(id) == "Exif") {
            // Read exif information

            std::vector<uint8_t> exif_data = handle.get_metadata(id);

            if (exif_data.size()>4) {
              size_t skip = ((exif_data[0]<<24) | (exif_data[1]<<16) | (exif_data[2]<<8) | exif_data[3]) + 4;

              if (exif_data.size()>skip) {
                  KisMetaData::IOBackend *exifIO = KisMetadataBackendRegistry::instance()->value("exif");

                  // Copy the exif data into the byte array
                  QByteArray ba(reinterpret_cast<char *>(exif_data.data() + skip),
                                static_cast<int>(exif_data.size() - skip));
                  QBuffer buf(&ba);
                  exifIO->loadFrom(layer->metaData(), &buf);
              }
            }
          }

          if (handle.get_metadata_type(id) == "mime" &&
              handle.get_metadata_content_type(id) == "application/rdf+xml") {
            // Read XMP information

            std::vector<uint8_t> xmp_data = handle.get_metadata(id);

            KisMetaData::IOBackend *xmpIO = KisMetadataBackendRegistry::instance()->value("xmp");

            // Copy the xmp data into the byte array
            QByteArray ba(reinterpret_cast<char *>(xmp_data.data()), static_cast<int>(xmp_data.size()));
            QBuffer buf(&ba);
            xmpIO->loadFrom(layer->metaData(), &buf);
          }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KisNodeSP node) {
            // TODO: check isolation
            return
                    !KisLayerUtils::checkIsCloneOf(node, m_nodes) &&
                    node->isEditable(true);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        QMutexLocker l(&m_dirtyRectsMutex);

        m_updatesFacade->enableDirtyRequests();
        m_updatesDisabled = false;
        m_updateTimer.start();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, sharedData]() {
        KisNodeList filteredRoots = KisLayerUtils::sortAndFilterMergableInternalNodes(m_processedNodes, true);
        Q_FOREACH (KisNodeSP root, filteredRoots) {
            sharedData->push_back(std::make_pair(root, root->extent()));
        }
    }
```

#### AUTO 


```{c}
auto r = options.widget->style()->subElementRect(QStyle::SE_ItemViewItemText, &options, options.widget);
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {
            return this->canvas ? this->canvas->inputActionGroupsMask() : AllActionGroup;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(KisView *view: KisPart::instance()->views()) {
        if (view->document() == m_maskDocument) {
            view->activateWindow();
            break;
        }
    }
```

#### AUTO 


```{c}
ORDER_BY(!isFallbackOnly(lhs.rendererId()), !isFallbackOnly(rhs.rendererId()))
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    KisCurveOptionProperties option;
                    option.readOptionSetting(prop->settings().data());
                    prop->setValue(option.curve_curves_opacity * 100.0);
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this, initialTransformArgs, argsAreInitialized]() mutable {
        QRect srcRect;

        if (m_selection) {
            srcRect = m_selection->selectedExactRect();
        } else {
            srcRect = QRect();
            Q_FOREACH (KisNodeSP node, m_processedNodes) {
                // group layers may have a projection of layers
                // that are locked and will not be transformed
                if (node->inherits("KisGroupLayer")) continue;

                if (const KisTransformMask *mask = dynamic_cast<const KisTransformMask*>(node.data())) {
                    srcRect |= mask->sourceDataBounds();
                } else {
                    srcRect |= node->exactBounds();
                }
            }
        }

        TransformTransactionProperties transaction(srcRect, &initialTransformArgs, m_rootNode, m_processedNodes);
        if (!argsAreInitialized) {
            initialTransformArgs = KisTransformUtils::resetArgsForMode(m_mode, m_filterId, transaction);
        }

        this->m_initialTransformArgs = initialTransformArgs;
        emit this->sigTransactionGenerated(transaction, initialTransformArgs, this);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (int index : indices) {
        m_d->colorButtonGroup->button(index)->setChecked(true);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[] (KisNodeSP node) {
                         return bool(dynamic_cast<KisDelayedUpdateNodeInterface*>(node.data()));
                     }
```

#### AUTO 


```{c}
auto noResourcesExisting = [] (QString a) {Q_UNUSED(a); return false;};
```

#### AUTO 


```{c}
auto isValidLabel = [&](QString label, int& index) -> bool {
                    if (attribute.value().startsWith(label)) {
                        if (attribute.value() == label) {
                            index = 0;
                            return true;
                        }

                        QString indexString = attribute.value().remove(0, label.length());
                        bool ok = false;
                        index = indexString.toInt(&ok);
                        if (ok) {
                            if (!elementMap.contains(index))
                                elementMap.insert(index, ExportPageShot());
                            return true;
                        }
                    }
                    return false;
                };
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
            prop->setValue(prop->settings()->paintOpSize());
        }
```

#### AUTO 


```{c}
const auto columnsToWork =
                qMin(numContiguousImageColumns, columnsRemaining);
```

#### AUTO 


```{c}
auto findItem = m_iconCacheMap.find(result.m_documentUrl);
```

#### LAMBDA EXPRESSION 


```{c}
[this, index] {model()->removeRows(index.row(), 1); }
```

#### LAMBDA EXPRESSION 


```{c}
[image, node, channelId, time, copy] () mutable -> KUndo2Command* {
                bool success = false;

                QScopedPointer<KUndo2Command> cmd(new KUndo2Command());

                KisKeyframeChannel *channel = node->getKeyframeChannel(channelId);
                quint8 originalOpacity = node->opacity();

                // Try get channel...
                bool channelCreated = false;
                if (!channel) {
                    node->enableAnimation();
                    channel = node->getKeyframeChannel(channelId, true);

                    if (!channel) return nullptr;

                    channelCreated = true;
                }

                bool shouldPreserveCanvas = channelCreated && time == 0;

                if ((copy || shouldPreserveCanvas) && channel->activeKeyframeAt(time)) {
                    if (!channel->keyframeAt(time)) {
                        channel->copyKeyframe(channel->activeKeyframeTime(time), time, cmd.data());
                        success = true;
                    }
                } else {
                    bool clearExistingFrame = channel->keyframeAt(time) && !channelCreated;
                    if (clearExistingFrame) { // Overwrite existing keyframe with a new blank one...
                        KIS_SAFE_ASSERT_RECOVER_RETURN_VALUE(image->animationInterface()->currentTime() == time, nullptr);
                        KIS_SAFE_ASSERT_RECOVER_RETURN_VALUE(channelId == KisKeyframeChannel::Raster.id(), nullptr);

                        // Clear the frame...
                        KisPaintDeviceSP device = node->paintDevice();
                        if (device) {
                            const QRect dirtyRect = device->extent();

                            KisTransaction transaction(kundo2_i18n("Clear"), device, cmd.data());
                            device->clear();
                            (void) transaction.endAndTake(); // saved as 'parent'

                            node->setDirty(dirtyRect);

                            success = true;
                        }
                    } else { // Make a regular new blank keyframe...
                        KisKeyframeSP previousKey = channel->activeKeyframeAt(time);

                        bool isScalar = (channelId != KisKeyframeChannel::Raster.id());
                        if (isScalar && previousKey) {
                            KisScalarKeyframeChannel* scalarChannel = static_cast<KisScalarKeyframeChannel*>(channel);
                            const qreal value = scalarChannel->valueAt(time); //Get interpolated value.
                            scalarChannel->addScalarKeyframe(time, value, cmd.data());
                        } else {
                            channel->addKeyframe(time, cmd.data());
                        }

                        // Use color label of previous key, if exists...
                        if (previousKey && channel->keyframeAt(time)) {
                            channel->keyframeAt(time)->setColorLabel(previousKey->colorLabel());
                        }

                        success = true;
                    }
                }

                // when a new opacity keyframe is created, the opacity is set to 0
                // this makes sure to use the opacity that was previously used
                // maybe there is a better way to do this
                node->setOpacity(originalOpacity);

                return success ? new KisCommandUtils::SkipFirstRedoWrapper(cmd.take()) : nullptr;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    ExperimentOption option;
                    option.readOptionSetting(prop->settings().data());
                    option.speed = prop->value().toInt();
                    option.writeOptionSetting(prop->settings().data());
                }
```

#### AUTO 


```{c}
auto offsetSegment =
            [this] (KisBezierTransformMesh::segment_iterator it,
                    qreal t,
                    qreal distance,
                    const QPointF &offset) {

            QPointF offsetP1;
            QPointF offsetP2;

            std::tie(offsetP1, offsetP2) =
                KisBezierUtils::offsetSegment(t, (1.0 - distance) * offset);


            smartMoveControl(*m_d->currentArgs.meshTransform(), it.itP1().controlIndex(), offsetP1, KisSmartMoveMeshControlMode::MoveSymmetricLock);
            smartMoveControl(*m_d->currentArgs.meshTransform(), it.itP2().controlIndex(), offsetP2, KisSmartMoveMeshControlMode::MoveSymmetricLock);
        };
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        Q_FOREACH (KisNodeSP node, m_d->processedNodes) {
            m_d->prevDirtyRects.addUpdate(node, node->projectionPlane()->tightUserVisibleBounds());
        }

        m_d->initialUpdatesBeforeClear = m_d->prevDirtyRects.compressed();
        m_d->updateDataForUndo.reset(new KisBatchNodeUpdate(m_d->initialUpdatesBeforeClear));

        executeAndAddCommand(new KisUpdateCommandEx(m_d->updateDataForUndo, m_d->updatesFacade, KisUpdateCommandEx::INITIALIZING, m_d->commandUpdatesBlockerCookie), Clear, KisStrokeJobData::BARRIER);
        executeAndAddCommand(new KisDisableDirtyRequestsCommand(m_d->updatesFacade, KisDisableDirtyRequestsCommand::INITIALIZING), Clear, KisStrokeJobData::BARRIER);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const quint8 *src, int srcRowStride,
                            quint8 *dst, int dstRowStride,
                            int numRows, int numColumns) {

                    m_d->scaler->convertU8ToU16(src, srcRowStride,
                                                dst, dstRowStride,
                                                numRows, numColumns);
                }
```

#### LAMBDA EXPRESSION 


```{c}
[](QAction * action) {
        // hint for the style to synchronize the color scheme with the window manager/compositor
        qApp->setProperty("KDE_COLOR_SCHEME_PATH", action->data());
        qApp->setPalette(KColorScheme::createApplicationPalette(KSharedConfig::openConfig(action->data().toString())));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        QRect handlesRect;

        Q_FOREACH(KisNodeSP node, m_nodes) {
            saveInitialNodeOffsets(node);
            handlesRect |= KisLayerUtils::recursiveNodeExactBounds(node);
        }

        KisStrokeStrategyUndoCommandBased::initStrokeCallback();

        emit this->sigHandlesRectCalculated(handlesRect);
        m_updateTimer.start();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (KoShapeStrokeSP stroke) {

        stroke->setCapStyle(static_cast<Qt::PenCapStyle>(d->capNJoinMenu->capGroup->checkedId()));
        stroke->setJoinStyle(static_cast<Qt::PenJoinStyle>(d->capNJoinMenu->joinGroup->checkedId()));
        stroke->setMiterLimit(miterLimit());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &row : rows) {
            row *= invM33;
        }
```

#### CONST EXPRESSION 


```{c}
constexpr int defaultColumnMargin = 16;
```

#### AUTO 


```{c}
const auto v1 = (xsimd::nearbyint_as_int(alpha)) << 24;
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool toggled)
        {
            if (toggled) {
                setColorType(KisGradientWidgetsUtils::Foreground);
            }
            emit colorTypeChanged(KisGradientWidgetsUtils::Foreground);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        QString name = QInputDialog::getText(this, i18nc("@title:window", "New Workspace..."),
                                             i18nc("@label:textbox", "Name:"));
        if (name.isEmpty()) return;
        auto rserver = KisResourceServerProvider::instance()->workspaceServer();

        KisWorkspaceResource* workspace = new KisWorkspaceResource("");
        workspace->setDockerState(m_this->saveState());
        d->viewManager->canvasResourceProvider()->notifySavingWorkspace(workspace);
        workspace->setValid(true);
        QString saveLocation = rserver->saveLocation();

        bool newName = false;
        if(name.isEmpty()) {
            newName = true;
            name = i18n("Workspace");
        }
        QFileInfo fileInfo(saveLocation + name + workspace->defaultFileExtension());

        int i = 1;
        while (fileInfo.exists()) {
            fileInfo.setFile(saveLocation + name + QString("%1").arg(i) + workspace->defaultFileExtension());
            i++;
        }
        workspace->setFilename(fileInfo.filePath());
        if(newName) {
            name = i18n("Workspace %1", i);
        }
        workspace->setName(name);
        rserver->addResource(workspace);
    }
```

#### AUTO 


```{c}
const auto *iptcBackend = KisMetadataBackendRegistry::instance()->value("iptc");
```

#### RANGE FOR STATEMENT 


```{c}
for (const SwatchInfoType &info : infoList) {
            const KisSwatch &swatch = info.swatch;
            QString name = swatch.name();
            if (!swatch.id().isEmpty()){
                name = swatch.id() + " - " + swatch.name();
            }
            addSqueezedItem(QIcon(createColorSquare(swatch)), name);
            posIdxMap[SwatchPosType(info.column, info.row)] = count() - 1;
            m_idxSwatchMap.push_back(swatch);
        }
```

#### AUTO 


```{c}
const auto it = prev(upper_bound(m_rows.begin(), m_rows.end(), proportionalT));
```

#### LAMBDA EXPRESSION 


```{c}
[this, copyContent] () {
                KisDataManagerSP newDm =
                    copyContent ?
                    new KisDataManager(*this->dataManager()) :
                    new KisDataManager(this->dataManager()->pixelSize(), this->dataManager()->defaultPixel());
                return new SwitchDataManager(this, this->dataManager(), newDm);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (QToolButton *button : buttons) {
        button->setParent(buttonContainer);
        buttonGroup->addButton(button, id++);
        layout->addWidget(button);
    }
```

#### AUTO 


```{c}
auto autoFillIt = m_d->oldAutoFillMarkers.begin();
```

#### AUTO 


```{c}
ORDER_BY(!isBlacklisted(lhs.rendererId()), !isBlacklisted(rhs.rendererId()))
```

#### CONST EXPRESSION 


```{c}
static constexpr float MIN_CHANNEL_AB = -128;
```

#### AUTO 


```{c}
auto *reference = KisReferenceImage::fromFile(filename, *kisCanvas->coordinatesConverter(), canvas()->canvasWidget());
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    KisBrushBasedPaintOpSettings *s =
                        dynamic_cast<KisBrushBasedPaintOpSettings*>(prop->settings().data());

                    s->setAngle(kisDegreesToRadians(prop->value().toReal()));
                }
```

#### AUTO 


```{c}
auto lum = [] (qreal x) { return int(x / 0.0001); };
```

#### LAMBDA EXPRESSION 


```{c}
[]() {
                return KisSuspendResumePair(
                    new KisTestingStrokeStrategy(QLatin1String("resu_u_"), false, true, true),
                    QList<KisStrokeJobData*>());
            }
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    CurveOption option;
                    option.readOptionSetting(prop->settings().data());
                    option.curve_paint_connection_line = prop->value().toBool();
                    option.writeOptionSetting(prop->settings().data());
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (StoryboardItemSP item : m_d->doc->getStoryboardItemList()) {
        QDomElement eItem =  item->toXML(doc);
        eItemList.appendChild(eItem);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](QString node){return quietlyTranslate(getChildContent(actionXml, node));}
```

#### AUTO 


```{c}
auto *referencesLayer = dynamic_cast<KisReferenceImagesLayer*>(layer)
```

#### AUTO 


```{c}
const auto greenOffset =
        static_cast<size_t>(gmicImage._width) * gmicImage._height;
```

#### AUTO 


```{c}
auto func = [&](qint64 & eraseSum, qint64 & insertSum) {
        for (qint32 i = 1; i < numCycles + 1; ++i) {
            auto type = i % numTypes;

            switch (type) {
            case 0: {
                auto result = map.erase(i - 1);
                if (result.data()) {
                    eraseSum += result->member();
                }
                break;
            }
            case 1: {
                bool newTile = false;
                auto result = map.getLazy(i, KisSharedPtr<Wrapper>(new Wrapper()), newTile);
                if (result.data()) {
                    insertSum += result->member();
                }
                break;
            }
            }
        }
    };
```

#### AUTO 


```{c}
auto it = std::make_reverse_iterator(m_d->strokesQueue.constEnd());
```

#### AUTO 


```{c}
const auto strs = index.data().toString().split(QLatin1Char(':'));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &groupName : d->groupNames) {
        if (yInGroup < d->groups[groupName].rowCount()) {
            nameGroupFoundIn = groupName;
            break;
        } else {
            yInGroup -= d->groups[groupName].rowCount();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto controls : m_widget->wdgControls->findChildren<ExprControl *>()) {
        for (auto wdg : controls->findChildren<QCheckBox *>(QString(), Qt::FindDirectChildrenOnly)) {
            wdg->setCheckState(Qt::Unchecked);
            wdg->setVisible(false);
        }
    }
```

#### AUTO 


```{c}
auto it = texturingModes.begin();
```

#### AUTO 


```{c}
auto setColorFn = [dialog, segments, this]() mutable
                        {
                            if (m_selectedHandle.index == 0) {
                                segments[0]->setStartType(COLOR_ENDPOINT);
                                segments[0]->setStartColor(dialog->getCurrentColor());
                            } else {
                                segments[m_selectedHandle.index - 1]->setEndType(COLOR_ENDPOINT);
                                segments[m_selectedHandle.index - 1]->setEndColor(dialog->getCurrentColor());
                                if (m_selectedHandle.index < segments.size()) {
                                    segments[m_selectedHandle.index]->setStartType(COLOR_ENDPOINT);
                                    segments[m_selectedHandle.index]->setStartColor(dialog->getCurrentColor());
                                }
                            }
                            emit selectedHandleChanged();
                            emit updateRequested();
                        };
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {
            return this->canvas ? this->canvas->inputActionGroupsMaskInterface()->inputActionGroupsMask() : AllActionGroup;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (KisKActionCollection* collection: sortedCollections) {
        for (QAction* action: collection->actions()) {
            QString actionName = KLocalizedString::removeAcceleratorMarker(action->text());
            QStandardItem* item = new QStandardItem(action->icon(), actionName);
            QStandardItem* actionNameItem = new QStandardItem(action->objectName());
            m_model->appendRow(QList<QStandardItem*>() << item << actionNameItem);
        }
    }
```

#### AUTO 


```{c}
auto cs = m_canvas->image()->colorSpace();
```

#### AUTO 


```{c}
auto maxDimension(Size size) -> decltype(size.width()) {
    return qMax(size.width(), size.height());
}
```

#### AUTO 


```{c}
auto lockedPropertiesKeys = m_lockedProperties->lockedProperties()->getPropertiesKeys();
```

#### AUTO 


```{c}
auto it = undoUpdates.begin();
```

#### AUTO 


```{c}
const auto setFrameLossless = [&](bool v) {
            if (JxlEncoderSetFrameLossless(frameSettings, v ? JXL_TRUE : JXL_FALSE) != JXL_ENC_SUCCESS) {
                errFile << "JxlEncoderSetFrameLossless failed";
                return false;
            }
            return true;
        };
```

#### LAMBDA EXPRESSION 


```{c}
[this, initialTransformArgs, argsAreInitialized]() mutable {
        QRect srcRect;

        if (m_selection) {
            srcRect = m_selection->selectedExactRect();
        } else {
            srcRect = QRect();
            Q_FOREACH (KisNodeSP node, m_processedNodes) {
                // group layers may have a projection of layers
                // that are locked and will not be transformed
                if (node->inherits("KisGroupLayer")) continue;

                if (const KisTransformMask *mask = dynamic_cast<const KisTransformMask*>(node.data())) {
                    srcRect |= mask->sourceDataBounds();
                } else if (const KisSelectionMask *mask = dynamic_cast<const KisSelectionMask*>(node.data())) {
                    srcRect |= mask->selection()->selectedExactRect();
                } else {
                    /// We shouldn't include masks or layer styles into the handles rect,
                    /// in the end, we process the paint device only
                    srcRect |= node->paintDevice() ? node->paintDevice()->exactBounds() : node->exactBounds();
                }
            }
        }

        TransformTransactionProperties transaction(srcRect, &initialTransformArgs, m_rootNode, m_processedNodes);
        if (!argsAreInitialized) {
            initialTransformArgs = KisTransformUtils::resetArgsForMode(m_mode, m_filterId, transaction, 0);
        }

        this->m_initialTransformArgs = initialTransformArgs;
        emit this->sigTransactionGenerated(transaction, initialTransformArgs, this);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QRect &vRect) {
        if (!m_d->isBatchUpdateActive) {
            // TODO: Implement info->dirtyViewportRect() for KisOpenGLCanvas2 to avoid updating whole canvas
            if (m_d->currentCanvasIsOpenGL) {
                m_d->savedCanvasProjectionUpdateRect |= vRect;

                // we already had a compression in frameRenderStartCompressor, so force the update directly
                slotDoCanvasUpdate();
            } else if (/* !m_d->currentCanvasIsOpenGL && */ !vRect.isEmpty()) {
                m_d->savedCanvasProjectionUpdateRect |= m_d->coordinatesConverter->viewportToWidget(vRect).toAlignedRect();

                // we already had a compression in frameRenderStartCompressor, so force the update directly
                slotDoCanvasUpdate();
            }
        }
    }
```

#### AUTO 


```{c}
auto end = m_d->commands.constEnd();
```

#### RANGE FOR STATEMENT 


```{c}
for (KoColorSetSP cs : oldPaletteList) {
        m_rServer->removeResourceFromServer(cs);
    }
```

#### AUTO 


```{c}
auto dst = node->paintDevice();
```

#### AUTO 


```{c}
auto pattern = rserver->resourceByName(name);
```

#### AUTO 


```{c}
auto listifiedShortcut = property("defaultShortcuts").value<QList<QKeySequence> >();
```

#### AUTO 


```{c}
auto* key = static_cast<QKeyEvent*>(event);
```

#### AUTO 


```{c}
auto it = std::find_if(m_cachedResources.begin(),
                               m_cachedResources.end(),
                               [this, md5] (KoResourceSP res) {
                                   return res->resourceType().first == this->m_resourceType &&
                                       res->md5() == md5;
                               });
```

#### LAMBDA EXPRESSION 


```{c}
[](const KisUniformPaintOpProperty *prop) {
                    KisSprayProperties option;
                    option.readOptionSetting(prop->settings().data());
                    return !option.useDensity;
                }
```

#### LAMBDA EXPRESSION 


```{c}
[&](qint64 & eraseSum, qint64 & insertSum) {
        for (qint32 i = 1; i < numCycles + 1; ++i) {
            auto type = i % numTypes;

            switch (type) {
            case 0: {
                auto result = map.erase(i - 2);
                if (result.data()) {
                    eraseSum += result->member();
                }
                break;
            }
            case 1: {
                auto result = map.insert(i, KisSharedPtr<Wrapper>(new Wrapper(i, 0, 0, 0)));
                if (result.data()) {
                    insertSum -= result->member();
                }
                insertSum += i;
                break;
            }
            case 2: {
                map.get(i - 1);
                break;
            }
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](qreal zoomDelta){
        if (m_d->curvesView) {
            m_d->curvesView->changeZoom(Qt::Vertical, zoomDelta);
        }
    }
```

#### AUTO 


```{c}
auto width = result.width();
```

#### CONST EXPRESSION 


```{c}
static constexpr int max_leading_letter_penalty = -15;
```

#### AUTO 


```{c}
auto it = std::find_if(m_cachedResources.begin(),
                               m_cachedResources.end(),
                               [this, name] (KoResourceSP res) {
                                   return res->resourceType().first == this->m_resourceType &&
                                       res->name() == name;
                               });
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    KisSprayOptionProperties option;
                    option.readOptionSetting(prop->settings().data());
                    option.particleCount = prop->value().toInt();
                    option.writeOptionSetting(prop->settings().data());
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (QRect &rc : rects) {
        state->painter->mirrorRect(direction, &rc);

        jobs.append(
            new KisRunnableStrokeJobData(
                [rc, state] () {
                    state->painter->bltFixed(rc, state->dabsQueue);
                },
                KisStrokeJobData::CONCURRENT));
    }
```

#### AUTO 


```{c}
auto it = updates.begin();
```

#### AUTO 


```{c}
auto rowEnd = std::upper_bound(rowBegin, rowsBuf.end(),
                                       QRect(rowBegin->x(),
                                             rowBegin->y() + gridSize - 1,
                                             1,1),
                                       VerticalSplitPolicy::rowIsLess);
```

#### CONST EXPRESSION 


```{c}
constexpr double showControlsAreaRadiusSquared = showControlsAreaRadius * showControlsAreaRadius;
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    BrushSizeOption option;
                    option.readOptionSetting(prop->settings().data());
                    option.brush_rotation = prop->value().toInt();
                    option.writeOptionSetting(prop->settings().data());
                }
```

#### LAMBDA EXPRESSION 


```{c}
[]() {
                auto header = std::make_unique<JxlFrameHeader>();
                JxlEncoderInitFrameHeader(header.get());
                return header;
            }
```

#### AUTO 


```{c}
const auto &shape
```

#### AUTO 


```{c}
auto patternIt = pattern.cbegin();
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    ParticleOption option;
                    option.readOptionSetting(prop->settings().data());
                    prop->setValue(option.particle_gravity);
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &pair : m_d->asyncRenderers) {
            if (!pair.renderer->isActive()) {
                const int currentDirtyFrame = m_d->stillDirtyFrames.takeFirst();

                initializeRendererForFrame(pair.renderer.get(), pair.image, currentDirtyFrame);
                pair.renderer->startFrameRegeneration(pair.image, currentDirtyFrame, m_d->regionOfInterest);
                hadWorkOnPreviousCycle = true;
                m_d->framesInProgress.append(currentDirtyFrame);
                break;
            }
        }
```

#### AUTO 


```{c}
auto *newParameters = dynamic_cast<KisTransformMaskAdapter*>(m_params.data());
```

#### LAMBDA EXPRESSION 


```{c}
[] (KisKeyframeSP lhs, KisKeyframeSP rhs) {
                return lhs->time() > rhs->time();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &style : allStyles) {
        FillStylesCorrector::correct(style.data());

        if (allStyles.count(style->psdUuid()) > 1) {
            const auto &existingStyle = cleanedStyles.find(style->psdUuid());

            if (existingStyle != cleanedStyles.end()) {
                if (existingStyle.value()->name() != style->name()) {
                    qWarning() << "Duplicated UUID" << style->psdUuid() << "for styles" << style->name() << "and"
                               << existingStyle.value()->name();
                    style->setMD5Sum("");
                    style->setUuid(QUuid::createUuid());
                } else {
                    qWarning() << "Duplicated style" << style->name();
                    continue;
                }
            }
        }

        style->setValid(!style->isEmpty());

        style->setFilename(style->uuid().toString());

        cleanedStyles.insert(style->psdUuid(), style);
    }
```

#### AUTO 


```{c}
const auto numChannels = gmicImage.m_spectrum;
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &fileName) {
            QFile file(fileName);
            if (!file.exists()) return QByteArray();

            file.open(QIODevice::ReadOnly);
            return file.readAll();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[id] (const KoID &item) { return item.id() == id; }
```

#### LAMBDA EXPRESSION 


```{c}
[this]{ this->sortByValue(SORT_ASCENDING | EVEN_DISTRIBUTION);}
```

#### AUTO 


```{c}
const auto channelPtrEnd = channelPtr.end();
```

#### LAMBDA EXPRESSION 


```{c}
[stops, this]()
                                             {
                                                 m_gradient->setStops(stops);
                                                 emit sigSelectedStop(m_selectedStop);
                                                 emit updateRequested();
                                             }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &name) {
            const QString fileName = m_context.xmlBaseDir() + QDir::separator() + name;
            QFile file(fileName);
            if (!file.exists()) {
                return QByteArray();
            }
            file.open(QIODevice::ReadOnly);
            return file.readAll();
        }
```

#### AUTO 


```{c}
auto *block = new PSDResourceBlock();
```

#### RANGE FOR STATEMENT 


```{c}
for(const KoGradientStop & stop: m_stops) {
        QDomElement stopEl = doc.createElement("stop");
        stopEl.setAttribute("stop-color", stop.color.toSVG11(&profiles));
        stopEl.setAttribute("offset", QString().setNum(stop.position));
        stopEl.setAttribute("stop-opacity", stop.color.opacityF());
        stopEl.setAttribute("krita:stop-type", stop.typeString());
        gradient.appendChild(stopEl);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractButton *button : m_d->colorButtonGroup->buttons()) {
        if (button->isChecked()) {
            indices << m_d->colorButtonGroup->id(button);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
LAZY_STATIC_CATEGORY_DISPLAY_NAME("mix")
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : deselected.indexes())
        model->setData(index.sibling(index.row(), ColumnCheck), Qt::Unchecked, Qt::CheckStateRole);
```

#### AUTO 


```{c}
auto patchIt = m_d->currentArgs.meshTransform()->find(*m_d->hoveredPatch);
```

#### LAMBDA EXPRESSION 


```{c}
[this, levelOfDetail, updateData, useHoldUI, commandGroup]() {

        fetchAllUpdateRequests(levelOfDetail, updateData);

        executeAndAddCommand(new KisDisableDirtyRequestsCommand(m_d->updatesFacade, KisUpdateCommandEx::FINALIZING), commandGroup, KisStrokeJobData::BARRIER);
        executeAndAddCommand(new KisUpdateCommandEx(updateData, m_d->updatesFacade, KisUpdateCommandEx::FINALIZING, m_d->commandUpdatesBlockerCookie), commandGroup, KisStrokeJobData::BARRIER);

        if (useHoldUI) {
            executeAndAddCommand(new KisHoldUIUpdatesCommand(m_d->updatesFacade, KisCommandUtils::FlipFlopCommand::FINALIZING), commandGroup, KisStrokeJobData::BARRIER);
        }

        /**
         * We also emit the updates manually, because KisUpdateCommandEx is
         * still blocked by m_d->commandUpdatesBlockerCookie (for easy undo
         * purposes)
         */
        for (auto it = updateData->begin(); it != updateData->end(); ++it) {
            m_d->updatesFacade->refreshGraphAsync(it->first, it->second);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &pair : blendingModeMap) {
        result.emplace(pair.second, pair.first);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KisKXMLGUIClient *c : clients) {
        if (!c) {
            continue;
        }
        if (auto collection = c->actionCollection()) {
            actionCollections.append(collection);
            actionsCount += collection->count();
        }
    }
```

#### AUTO 


```{c}
auto &pair
```

#### AUTO 


```{c}
const auto *dataPlane = reinterpret_cast<const quint8 *>(dataPlanes[0].constData());
```

#### CONST EXPRESSION 


```{c}
constexpr int patchStep = 64;
```

#### AUTO 


```{c}
auto setColorFn = [dialog, this]() { q->setColor(dialog->getCurrentColor()); };
```

#### AUTO 


```{c}
const auto offers = KoJsonTrader::instance()->query("Krita/GMic", QString());
```

#### AUTO 


```{c}
const auto renderingIntent =
        KoColorConversionTransformation::internalRenderingIntent();
```

#### CONST EXPRESSION 


```{c}
static constexpr float MAX_CHANNEL_CMYK = 100;
```

#### AUTO 


```{c}
auto sessionMode = cfg.sessionOnStartup();
```

#### LAMBDA EXPRESSION 


```{c}
[&deviceList](KisNodeSP node) {
                            deviceList << node->getLodCapableDevices();
                        }
```

#### AUTO 


```{c}
auto& patch
```

#### LAMBDA EXPRESSION 


```{c}
[&linearizedNodes](KisNodeSP node) {
            linearizedNodes.enqueue(node);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &resname : names) {
        if (QFile(resname).exists()) {
            QIcon icon(resname);
            s_icons.insert(icon.cacheKey(), name);
            s_cache.insert(name, icon);
            return icon;
        }
    }
```

#### AUTO 


```{c}
auto it = allFiles.begin();
```

#### LAMBDA EXPRESSION 


```{c}
[this](){
        QMessageBox::warning(this, i18nc("@title:window", "Krita"), i18n("Your FFMpeg version does not support this format"));
    }
```

#### AUTO 


```{c}
auto *nextOut = reinterpret_cast<uint8_t *>(compressed.data());
```

#### DECLTYPE 


```{c}
typedef decltype(Rect().top()) ValueType;
```

#### LAMBDA EXPRESSION 


```{c}
[&result, mode, root] (KisNodeSP node) {
        if (node->isEditable(node == root) &&
                (!node->inherits("KisShapeLayer") || mode == ToolTransformArgs::FREE_TRANSFORM) &&
                !node->inherits("KisFileLayer") &&
                !node->inherits("KisColorizeMask") &&
                (!node->inherits("KisTransformMask") || node == root)) {

                result << node;
            }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](){return new KisTestingStrokeStrategy("susp_u_", false, true, true);}
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    KisSprayProperties option;
                    option.readOptionSetting(prop->settings().data());
                    option.particleCount = prop->value().toInt();
                    option.writeOptionSetting(prop->settings().data());
                }
```

#### AUTO 


```{c}
const auto basicInfo = [&]() {
        auto info{std::make_unique<JxlBasicInfo>()};
        JxlEncoderInitBasicInfo(info.get());
        info->xsize = static_cast<uint32_t>(bounds.width());
        info->ysize = static_cast<uint32_t>(bounds.height());
        {
            if (cs->colorDepthId() == Integer8BitsColorDepthID) {
                info->bits_per_sample = 8;
                info->exponent_bits_per_sample = 0;
                info->alpha_bits = 8;
                info->alpha_exponent_bits = 0;
            } else if (cs->colorDepthId() == Integer16BitsColorDepthID) {
                info->bits_per_sample = 16;
                info->exponent_bits_per_sample = 0;
                info->alpha_bits = 16;
                info->alpha_exponent_bits = 0;
#ifdef HAVE_OPENEXR
            } else if (cs->colorDepthId() == Float16BitsColorDepthID) {
                info->bits_per_sample = 16;
                info->exponent_bits_per_sample = 5;
                info->alpha_bits = 16;
                info->alpha_exponent_bits = 5;
#endif
            } else if (cs->colorDepthId() == Float32BitsColorDepthID) {
                info->bits_per_sample = 32;
                info->exponent_bits_per_sample = 8;
                info->alpha_bits = 32;
                info->alpha_exponent_bits = 8;
            }
        }
        if (cs->colorModelId() == RGBAColorModelID) {
            info->num_color_channels = 3;
            info->num_extra_channels = 1;
        } else if (cs->colorModelId() == GrayAColorModelID) {
            info->num_color_channels = 1;
            info->num_extra_channels = 1;
        } else if (cs->colorModelId() == CMYKAColorModelID) {
            info->num_color_channels = 4;
            info->num_extra_channels = 1;
        }
        info->uses_original_profile = JXL_TRUE;
        if (image->animationInterface()->hasAnimation() && cfg->getBool("haveAnimation", true)) {
            info->have_animation = JXL_TRUE;
            info->animation.have_timecodes = JXL_FALSE;
            info->animation.num_loops = 0;
            // Unlike WebP, JXL does allow for setting proper framerates.
            info->animation.tps_numerator =
                static_cast<uint32_t>(image->animationInterface()->framerate());
            info->animation.tps_denominator = 1;
        }
        return info;
    }();
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    DynaOption option;
                    option.readOptionSetting(prop->settings().data());
                    prop->setValue(option.dyna_drag);
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KoColorSetSP palette : m_d->doc->paletteList()) {
        // Ensure stored palettes are KPL.
        palette->setPaletteType(KoColorSet::KPL);

        if (!store->open(m_d->imageName + PALETTE_PATH + palette->filename())) {
            m_d->errorMessages << i18n("could not save palettes");
            return false;
        }

        QByteArray ba = palette->toByteArray();

        if (!ba.isEmpty()) {
            store->write(ba);
        } else {
            qWarning() << "Cannot save the palette to a byte array:" << palette->name();
        }
        store->close();
        res = true;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    KisBrushBasedPaintOpSettings *s =
                        dynamic_cast<KisBrushBasedPaintOpSettings*>(prop->settings().data());

                    if (s->autoSpacingActive()) {
                        s->setAutoSpacing(true, prop->value().toReal());
                    } else {
                        s->setSpacing(prop->value().toReal());
                    }
                }
```

#### AUTO 


```{c}
auto it = mutatedJobs.begin();
```

#### AUTO 


```{c}
auto source = resourcesInterface()->source<KoAbstractGradient>(ResourceType::Gradients);
```

#### LAMBDA EXPRESSION 


```{c}
[sharedState, sharedWriteLock, dst, undoAdapter, transactionText, timedID] () {
            Q_UNUSED(sharedWriteLock); // just a RAII holder object for the lock

            /**
             * Move tool may not have an undo adapter
             */
             if (undoAdapter) {
                 sharedState->transaction.reset(
                     new KisTransaction(transactionText, dst, nullptr, timedID));
             }
        }
```

#### AUTO 


```{c}
auto filterContainer(C &container, KeepIfFunction keepIf)
        -> decltype(bool(keepIf(container[0])), void()) {

        auto newEnd = std::remove_if(container.begin(), container.end(), [keepIf] (typename C::reference p) { return !keepIf(p); });
        while (newEnd != container.end()) {
           newEnd = container.erase(newEnd);
        }
}
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {
        return !m_filename.isEmpty() ? m_filename : i18nc("placeholder test for a warning when not file is set in the file layer", "<No file name is set>");
    }
```

#### LAMBDA EXPRESSION 


```{c}
[]() {
            return KisSuspendResumePair(
                new KisTestingStrokeStrategy("susp_u_", false, true, true),
                QList<KisStrokeJobData*>());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &lang : newsLangs) {
        QAction *langItem = newsOptionsMenu->addAction(lang.name);
        langItem->setCheckable(true);
        // We can copy `code` into the lambda because its backing string is a
        // static string literal.
        const QString code = lang.siteCode;
        connect(langItem, &QAction::toggled, [=](bool checked) {
            newsWidget->toggleNewsLanguage(code, checked);
        });

        // Set the initial checked state.
        if (enabledNewsLangs->contains(code)) {
            langItem->setChecked(true);
        }

        // Connect this lambda after setting the initial checked state because
        // we don't want to overwrite the config when doing the initial setup.
        connect(langItem, &QAction::toggled, [=](bool checked) {
            KisConfig cfg(false);
            // It is safe to modify `enabledNewsLangs` here, because the slots
            // are called synchronously on the UI thread so there is no need
            // for explicit synchronization.
            if (checked) {
                enabledNewsLangs->insert(QString(code));
            } else {
                enabledNewsLangs->remove(QString(code));
            }
            cfg.writeList(newsLangConfigName, enabledNewsLangs->values());
        });
    }
```

#### AUTO 


```{c}
auto i = std::partition(m_uses.begin(), m_uses.end(),
                                [&](const El& e) -> bool {return e.m_key != id;});
```

#### LAMBDA EXPRESSION 


```{c}
[this, previousLevelsCurve]()
        {
            *m_activeLevelsCurve = previousLevelsCurve;
            updateWidgets();
            emit sigConfigurationUpdated();
        }
```

#### AUTO 


```{c}
const auto tileWidth =
        static_cast<size_t>(it->numContiguousColumns(dst->x()));
```

#### AUTO 


```{c}
inline auto set_zero(const batch<T, A> &src, const batch_bool<T, A> &mask) noexcept;
```

#### AUTO 


```{c}
auto dlgImageSize = new DlgImageSize(box, m_document->image()->width(), m_document->image()->height(), m_document->image()->yRes());
```

#### AUTO 


```{c}
auto sendProximityEvent = [&](QEvent::Type type) {
        QPointF emptyPos;
        qreal zero = 0.0;
        QTabletEvent e(type, emptyPos, emptyPos, 0, m_devices.at(m_currentDevice).currentPointerType,
                       zero, 0, 0, zero, zero, 0, Qt::NoModifier,
                       m_devices.at(m_currentDevice).uniqueId, Qt::NoButton, (Qt::MouseButtons)0);
        qApp->sendEvent(qApp->activeWindow(), &e);
    };
```

#### AUTO 


```{c}
auto pos = static_cast<size_t>(y) * gmicImage._width
                + static_cast<size_t>(x);
```

#### AUTO 


```{c}
auto it = tailSubtreeBegin(pos);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            notifyAllCommandsDone();
            m_d->commands.clear();
        }
```

#### AUTO 


```{c}
auto it = dirtyRects.begin();
```

#### RANGE FOR STATEMENT 


```{c}
for (cmsFloat32Number value : inputValues) {
        cmsFloat32Number cValue = value;

        /*
         * Rec 709
         * for 1  >=  Lc  >=  β
         *  V = α * Lc^0.45 − ( α − 1 )
         * for β  >  Lc  >=  0
         * V = 4.500 * Lc
         */

        if (value > 0.018){
            cValue = 1.099 * powf(value, 0.45) - (.099) ;
        } else if (value < 0.018 && value > 0.0){
            cValue = 4.5 * value;
        } else {
            cValue = 0.0;
        }



        /*
         * double lValue;
        if (cValue > 0.081){
            lValue = powf((.099+cValue)*1/1.099, 1/ 0.45);
        } else {
            lValue = cValue * 1/4.5;
        }
        */
        cmsFloat32Number lValue = cmsEvalToneCurveFloat(curve, cValue);
        QVERIFY2(fabs(lValue - value) < 0.000001, QString("Values don't match for rec 709: %1 %2").arg(value).arg(lValue).toLatin1());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() { return new T(p1, p2, p3); }
```

#### LAMBDA EXPRESSION 


```{c}
[this, earliestFrame, frameAssociates](KisNodeSP node) {
            if (!node->isAnimated() || !node->paintDevice())
                return;

            KisRasterKeyframeChannel* rasterChan = node->paintDevice()->keyframeChannel();

            if (!rasterChan)
                return;

            // Gather all original keyframes and their associated time values.
            QHash<int, KisKeyframeSP> originalKeyframes;
            Q_FOREACH( const int& time, rasterChan->allKeyframeTimes()) {
                if (time >= earliestFrame && rasterChan->keyframeAt(time)) {
                    originalKeyframes.insert(time, rasterChan->keyframeAt(time));
                    rasterChan->removeKeyframe(time);
                }
            }

            //Now lets re-sort the raster channels...
            int intendedSceneFrameTime = earliestFrame;
            for (int i = 0; i < rowCount(); i++) {
                QModelIndex sceneIndex = index(i, 0);
                const int srcFrame = index(StoryboardItem::FrameNumber, 0, sceneIndex).data().toInt();
                Q_FOREACH( const int& associateFrameOffset, frameAssociates.values(sceneIndex) ) {
                    if (!originalKeyframes.contains(srcFrame + associateFrameOffset))
                        continue;

                    rasterChan->insertKeyframe(intendedSceneFrameTime + associateFrameOffset,
                                               originalKeyframes.value(srcFrame + associateFrameOffset));
                }

                intendedSceneFrameTime += index(StoryboardItem::DurationFrame, 0, sceneIndex).data().toInt()
                                        + index(StoryboardItem::DurationSecond, 0, sceneIndex).data().toInt() * getFramesPerSecond();
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, args, levelOfDetail]() {
        m_d->updatesFacade->disableDirtyRequests();
        m_d->updatesDisabled = true;
        undoTransformCommands(levelOfDetail);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KoColorSet *cs : oldPaletteList) {
        m_rServer->removeResourceFromServer(cs);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const KisKeyframeChannel*, int time){
        if (m_d->canvas && m_d->canvas->image()) {
            KisImageAnimationInterface* animInterface = m_d->canvas->image()->animationInterface();
            KisConfig cfg(true);
            if (animInterface && cfg.adaptivePlaybackRange()) {
                KisTimeSpan desiredPlaybackRange = animInterface->fullClipRange();
                desiredPlaybackRange.include(time);
                animInterface->setFullClipRange(desiredPlaybackRange);
            }

        }
    }
```

#### AUTO 


```{c}
const auto pos = this->canvasBase()->coordinatesConverter()->widgetToImage(imgCursorPos);
```

#### RANGE FOR STATEMENT 


```{c}
for (QPointF dPos : m_subbrOriginalLocations) {
                // Show subbrush reference locations while in add mode
                if (m_addSubbrushesMode) {
                    path.addEllipse(dPos, 10, 10);
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[] (qreal x) { return int(x / 0.0001); }
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    DynaOption option;
                    option.readOptionSetting(prop->settings().data());
                    option.dyna_drag = prop->value().toReal();
                    option.writeOptionSetting(prop->settings().data());
                }
```

#### AUTO 


```{c}
auto runner = JxlResizableParallelRunnerMake(nullptr);
```

#### AUTO 


```{c}
auto it = rbegin;
```

#### AUTO 


```{c}
auto it = m_d->dataObjects.begin();
```

#### LAMBDA EXPRESSION 


```{c}
[cmd](KisNodeSP node){
                if (node->supportsKeyframeChannel(KisKeyframeChannel::Raster.id())) {
                    KisKeyframeChannel* chan = node->getKeyframeChannel(KisKeyframeChannel::Raster.id(), true);

                    if (chan->keyframeAt(0)) {
                        return;
                    }

                    chan->addKeyframe(0, cmd);
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &key : map.keys()) {
        QVariant v = map.value(key);

        if (v.isValid() && v.type() == QVariant::UserType && v.userType() == qMetaTypeId<KoColor>()) {
            map[key] = QVariant::fromValue(v.value<KoColor>().toXML());
        }
    }
```

#### AUTO 


```{c}
auto uploadData = [this, tryIssueCanvasUpdates](const QVector<KisUpdateInfoSP> &infoObjects) {
        QVector<QRect> viewportRects = m_d->canvasWidget->updateCanvasProjection(infoObjects);
        const QRect vRect = std::accumulate(viewportRects.constBegin(), viewportRects.constEnd(),
                                            QRect(), std::bit_or<QRect>());

        tryIssueCanvasUpdates(vRect);
    };
```

#### LAMBDA EXPRESSION 


```{c}
[keepIf] (typename C::reference p) { return !keepIf(p); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QModelIndex &/*parent*/, int first, int last) {
        for (int i = first; i <= last; i++) {
            QStandardItem *item = d->recentFilesModel.model().item(i);
            QUrl url = item->data().toUrl();
            QIcon icon = item->icon();
            if (url.isValid() && !icon.isNull()) {
                d->recentFiles->setUrlIcon(url, icon);
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[stops, this]()
                                        {
                                            m_gradient->setStops(stops);
                                            emit sigSelectedStop(m_selectedStop);
                                            emit updateRequested();
                                        }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString &suffix : extensions.split(":")) {
            mimeTypes << KisMimeDatabase::mimeTypeForSuffix(suffix);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (AuxiliaryPoint &point : auxiliaryPoints) {
        point.macrocellPixelIndex = point.microcellPixelIndex * numberOfMicrocells + point.microcellIndex;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(QString& feedUrl: feedList) {
        rssModel->addFeed(feedUrl);
    }
```

#### AUTO 


```{c}
auto pykritaModule = PyInit_pykrita();
```

#### RANGE FOR STATEMENT 


```{c}
for (const KisSwatchGroup::SwatchInfo &info : d->groups[groupName].infoList()) {
            QColor c = info.swatch.color().toQColor();
            gc.fillRect(info.column * 4, (lastRow + info.row) * 4, 4, 4, c);
            lastRowGroup = qMax(lastRowGroup, info.row);
        }
```

#### AUTO 


```{c}
auto layer = qobject_cast<KisLayer*>(node.data());
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& row: m_array) {
        for (auto& patch: row) {
            patch->setTransform(matrix);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (PythonPlugin &plugin : m_plugins) {
        dbgScript << "Trying to load plugin" << plugin.moduleName()
                  << ". Enabled:" << plugin.isEnabled()
                  << ". Broken: " << plugin.isBroken();

        if (plugin.m_enabled && !plugin.isBroken()) {
            loadModule(plugin);
        }
    }
```

#### AUTO 


```{c}
auto testSegment =
                [&nearestSegment,
                 &nearestSegmentSignificance,
                 &nearestSegmentDistance,
                 &nearestSegmentDistanceSignificance,
                 &nearestSegmentParam,
                 centerDistance,
                 this] (KisBezierTransformMesh::segment_iterator it, qreal param) {

            const QPointF movedPoint = KisBezierUtils::bezierCurve(it.p0(), it.p1(), it.p2(), it.p3(), param);
            const qreal distance = kisDistance(m_d->mouseClickPos, movedPoint);

            if (distance < nearestSegmentDistance) {
                const qreal proportion = KisBezierUtils::curveProportionByParam(it.p0(), it.p1(), it.p2(), it.p3(), param, 0.1);

                qreal distanceSignificance =
                    centerDistance / (centerDistance + distance);

                if (distanceSignificance > 0.6) {
                    distanceSignificance = std::min(1.0, linearReshapeFunc(distanceSignificance, 0.6, 0.75, 0.6, 1.0));
                }

                const qreal directionSignificance =
                    1.0 - std::min(1.0, std::abs(proportion - 0.5) / 0.4);

                nearestSegmentDistance = distance;
                nearestSegment = it;
                nearestSegmentParam = param;
                nearestSegmentSignificance = m_d->mode != Private::OVER_PATCH_LOCKED ? distanceSignificance * directionSignificance : 0;
                nearestSegmentDistanceSignificance = distanceSignificance;
            }
        };
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool){
        if (m_d->canvas) {
            m_d->canvas->animationPlayer()->playPause();
        }
    }
```

#### AUTO 


```{c}
auto it = std::lower_bound(fontWeights.begin(), fontWeights.end(), weight);
```

#### AUTO 


```{c}
auto viewElement = root.firstChildElement("view");
```

#### RANGE FOR STATEMENT 


```{c}
for(const KoGradientStop& stop : stops) {
        reversedStops.push_front(KoGradientStop(1 - stop.position, stop.color, stop.type));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QScreen *a, const QScreen *b) {
            QRect aRect = a->geometry();
            QRect bRect = b->geometry();

            if (aRect.y() == bRect.y()) return aRect.x() < bRect.x();
            return (aRect.y() < bRect.y());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QLayoutItem *item : qAsConst(m_items))
        size = size.expandedTo(item->minimumSize());
```

#### LAMBDA EXPRESSION 


```{c}
[dialog, segments, this]() mutable
                        {
                            if (m_selectedHandle.index == 0) {
                                segments[0]->setStartType(COLOR_ENDPOINT);
                                segments[0]->setStartColor(dialog->getCurrentColor());
                            } else {
                                segments[m_selectedHandle.index - 1]->setEndType(COLOR_ENDPOINT);
                                segments[m_selectedHandle.index - 1]->setEndColor(dialog->getCurrentColor());
                                if (m_selectedHandle.index < segments.size()) {
                                    segments[m_selectedHandle.index]->setStartType(COLOR_ENDPOINT);
                                    segments[m_selectedHandle.index]->setStartColor(dialog->getCurrentColor());
                                }
                            }
                            emit selectedHandleChanged();
                            emit updateRequested();
                        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KisMetaData::Entry &entry : *store) {
        try {
            dbgMetaData << "Trying to save: " << entry.name() << " of " << entry.schema()->prefix() << ":" << entry.schema()->uri();
            QString exivKey;
            if (entry.schema()->uri() == KisMetaData::Schema::TIFFSchemaUri) {
                exivKey = "Exif.Image." + entry.name();
            } else if (entry.schema()->uri() == KisMetaData::Schema::EXIFSchemaUri) { // Distinguish between exif and gps
                if (entry.name().left(3) == "GPS") {
                    exivKey = "Exif.GPSInfo." + entry.name();
                } else {
                    exivKey = "Exif.Photo." + entry.name();
                }
            } else if (entry.schema()->uri() == KisMetaData::Schema::DublinCoreSchemaUri) {
                if (entry.name() == "description") {
                    exivKey = "Exif.Image.ImageDescription";
                } else if (entry.name() == "creator") {
                    exivKey = "Exif.Image.Artist";
                } else if (entry.name() == "rights") {
                    exivKey = "Exif.Image.Copyright";
                }
            } else if (entry.schema()->uri() == KisMetaData::Schema::XMPSchemaUri) {
                if (entry.name() == "ModifyDate") {
                    exivKey = "Exif.Image.DateTime";
                } else if (entry.name() == "CreatorTool") {
                    exivKey = "Exif.Image.Software";
                }
            } else if (entry.schema()->uri() == KisMetaData::Schema::MakerNoteSchemaUri) {
                if (entry.name() == "RawData") {
                    exivKey = "Exif.Photo.MakerNote";
                }
            }
            dbgMetaData << "Saving " << entry.name() << " to " << exivKey;
            if (exivKey.isEmpty()) {
                dbgMetaData << entry.qualifiedName() << " is unsavable to EXIF";
            } else {
                Exiv2::ExifKey exifKey(qPrintable(exivKey));
                Exiv2::Value* v = 0;
                if (exivKey == "Exif.Photo.ExifVersion" || exivKey == "Exif.Photo.FlashpixVersion") {
                    v = kmdValueToExifVersion(entry.value());
                } else if (exivKey == "Exif.Photo.FileSource") {
                    char s[] = { 0x03 };
                    v = new Exiv2::DataValue((const Exiv2::byte*)s, 1);
                } else if (exivKey == "Exif.Photo.SceneType") {
                    char s[] = { 0x01 };
                    v = new Exiv2::DataValue((const Exiv2::byte*)s, 1);
                } else if (exivKey == "Exif.Photo.ComponentsConfiguration") {
                    v = kmdIntOrderedArrayToExifArray(entry.value());
                } else if (exivKey == "Exif.Image.Artist") { // load as dc:creator
                    KisMetaData::Value creator = entry.value();
                    if (entry.value().asArray().size() > 0) {
                        creator = entry.value().asArray()[0];
                    }
#if !EXIV2_TEST_VERSION(0,21,0)
                    v = kmdValueToExivValue(creator, Exiv2::ExifTags::tagType(exifKey.tag(), exifKey.ifdId()));
#else
                    v = kmdValueToExivValue(creator, exifKey.defaultTypeId());
#endif
                } else if (exivKey == "Exif.Photo.OECF") {
                    v = kmdOECFStructureToExifOECF(entry.value());
                } else if (exivKey == "Exif.Photo.DeviceSettingDescription") {
                    v = deviceSettingDescriptionKMDToExif(entry.value());
                } else if (exivKey == "Exif.Photo.CFAPattern") {
                    v = cfaPatternKMDToExif(entry.value());
                } else if (exivKey == "Exif.Photo.Flash") {
                    v = flashKMDToExif(entry.value());
                } else if (exivKey == "Exif.Photo.UserComment") {
                    Q_ASSERT(entry.value().type() == KisMetaData::Value::LangArray);
                    QMap<QString, KisMetaData::Value> langArr = entry.value().asLangArray();
                    if (langArr.contains("x-default")) {
#if !EXIV2_TEST_VERSION(0,21,0)
                        v = kmdValueToExivValue(langArr.value("x-default"), Exiv2::ExifTags::tagType(exifKey.tag(), exifKey.ifdId()));
#else
                        v = kmdValueToExivValue(langArr.value("x-default"), exifKey.defaultTypeId());
#endif
                    } else if (langArr.size() > 0) {
#if !EXIV2_TEST_VERSION(0,21,0)
                        v = kmdValueToExivValue(langArr.begin().value(), Exiv2::ExifTags::tagType(exifKey.tag(), exifKey.ifdId()));
#else
                        v = kmdValueToExivValue(langArr.begin().value(), exifKey.defaultTypeId());
#endif
                    }
                } else {
                    dbgMetaData << exifKey.tag();
#if !EXIV2_TEST_VERSION(0,21,0)
                    v = kmdValueToExivValue(entry.value(), Exiv2::ExifTags::tagType(exifKey.tag(), exifKey.ifdId()));
#else
                    v = kmdValueToExivValue(entry.value(), exifKey.defaultTypeId());
#endif
                }
                if (v && v->typeId() != Exiv2::invalidTypeId) {
                    dbgMetaData << "Saving key" << exivKey << " of KMD value" << entry.value();
                    exifData.add(exifKey, v);
                } else {
                    dbgMetaData << "No exif value was created for" << entry.qualifiedName() << " as" << exivKey;// << " of KMD value" << entry.value();
                }
            }
        } catch (Exiv2::AnyError& e) {
            dbgMetaData << "exiv error " << e.what();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&](size_t i, typename T::value_type) {
            return static_cast<typename T::value_type>(src[i]);
        }
```

#### AUTO 


```{c}
auto *adapterParams = dynamic_cast<KisTransformMaskAdapter*>(params.data());
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                KisStrokeStrategyUndoCommandBased::cancelStrokeCallback();
            }
```

#### AUTO 


```{c}
auto uploadColorFromShape = [&](KoCanvasResource::CanvasResourceId res, KoFlake::FillVariant fill) {
        KoShapeFillWrapper wrapper(currentShapes(), fill);
        if (!wrapper.color().isValid()) {
            return;
        }
        KoColor color;
        color.fromQColor(wrapper.color());
        uploadColorToResourceManager(res, fill, color);
    };
```

#### LAMBDA EXPRESSION 


```{c}
[&](const uint8_t *img, int stride, int x, int y, int ch) {
                uint8_t source = img[(y * stride) + (x * channels) + ch];
                return linearizeValueAsNeeded(float(source) / 255.0f, linearizePolicy);
            }
```

#### AUTO 


```{c}
auto adapter = interface->source<KisPSDLayerStyle>(ResourceType::LayerStyles);
```

#### LAMBDA EXPRESSION 


```{c}
[this](KisNodeSP node) {
                                                 return !KisLayerUtils::checkIsCloneOf(node, m_nodes);
                                             }
```

#### LAMBDA EXPRESSION 


```{c}
[](const KisUniformPaintOpProperty *prop) {
                    KisSprayOptionProperties option;
                    option.readOptionSetting(prop->settings().data());
                    return option.useDensity;
                }
```

#### LAMBDA EXPRESSION 


```{c}
[affected, offset] (KisNodeSP node) {
                const int startFrame = affected.start();
                if (node->isAnimated()) {
                    KisKeyframeChannel *keyframeChannel = node->paintDevice()->keyframeChannel();
                    if (keyframeChannel) {
                        if (offset > 0) {
                            int timeIter = affected.isInfinite() ?
                                                    keyframeChannel->lastKeyframeTime()
                                                  : keyframeChannel->activeKeyframeTime(affected.end());

                            KisKeyframeSP iterEnd = keyframeChannel->keyframeAt(keyframeChannel->previousKeyframeTime(startFrame));

                            while (keyframeChannel->keyframeAt(timeIter) &&
                                   keyframeChannel->keyframeAt(timeIter) != iterEnd) {
                                keyframeChannel->moveKeyframe(timeIter, timeIter + offset);
                                timeIter = keyframeChannel->previousKeyframeTime(timeIter);
                            }

                        } else {
                            int timeIter = keyframeChannel->keyframeAt(startFrame) ? startFrame : keyframeChannel->nextKeyframeTime(startFrame);

                            KisKeyframeSP iterEnd = affected.isInfinite() ?
                                                        nullptr
                                                      : keyframeChannel->keyframeAt(keyframeChannel->nextKeyframeTime(affected.end()));

                            while (keyframeChannel->keyframeAt(timeIter) != iterEnd) {
                                keyframeChannel->moveKeyframe(timeIter, timeIter + offset);
                                timeIter = keyframeChannel->nextKeyframeTime(timeIter);
                            }
                        }
                    }
                }
            }
```

#### AUTO 


```{c}
const auto inputFileName =
        TestUtil::fetchDataFileLazy("/sources/animated/animation_test.jxl");
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        QString name = QInputDialog::getText(this, i18nc("@title:window", "New Workspace..."),
                                             i18nc("@label:textbox", "Name:"));
        if (name.isEmpty()) return;
        auto rserver = KisResourceServerProvider::instance()->workspaceServer();

        KisWorkspaceResourceSP workspace(new KisWorkspaceResource(""));
        workspace->setDockerState(m_this->saveState());
        d->viewManager->canvasResourceProvider()->notifySavingWorkspace(workspace);
        workspace->setValid(true);
        QString saveLocation = rserver->saveLocation();

        bool newName = false;
        if(name.isEmpty()) {
            newName = true;
            name = i18n("Workspace");
        }
        QFileInfo fileInfo(saveLocation + name + workspace->defaultFileExtension());

        int i = 1;
        while (fileInfo.exists()) {
            fileInfo.setFile(saveLocation + name + QString("%1").arg(i) + workspace->defaultFileExtension());
            i++;
        }
        workspace->setFilename(fileInfo.filePath());
        if(newName) {
            name = i18n("Workspace %1", i);
        }
        workspace->setName(name);
        rserver->addResource(workspace);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, md5] (KoResourceSP res) {
                                   return res->resourceType().first == this->m_resourceType &&
                                       res->md5() == md5;
                               }
```

#### AUTO 


```{c}
auto onlyFirstVersionExists = [] (QString a) {
        return a == "testpattern.png" || a == "testpattern.0000.png";
    };
```

#### AUTO 


```{c}
const auto prevScript = m_currentPreset->script();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                Q_FOREACH (KisTransformMask *mask, m_d->transformMaskCacheHash.keys()) {
                    mask->overrideStaticCacheDevice(0);
                }

                /**
                 * Transform masks don't have internal state switch for LoD mode,
                 * therefore all the preview transformations must be cancelled
                 * before applying the final command
                 */
                undoTransformCommands(m_d->previewLevelOfDetail);
            }
```

#### CONST EXPRESSION 


```{c}
static constexpr int feedbackLineWidth{2};
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &loader : offers) {
        auto *factory = qobject_cast<KPluginFactory *>(loader->instance());
        if (!factory) {
            warnPlugins << "(GMic) This is not a Krita plugin: " << loader->fileName() << loader->errorString();

            continue;
        }

        auto *pluginBase = factory->create<QObject>();

        plugin = qobject_cast<KisQmicPluginInterface *>(pluginBase);

        if (!plugin) {
            warnPlugins << "(GMic) This is not a valid GMic-Qt plugin: " << loader->fileName();

            continue;
        }

        break;
    }
```

#### AUTO 


```{c}
auto tryIssueCanvasUpdates = [this](const QRect &vRect) {
        if (!m_d->isBatchUpdateActive) {
            // TODO: Implement info->dirtyViewportRect() for KisOpenGLCanvas2 to avoid updating whole canvas
            if (m_d->currentCanvasIsOpenGL) {
                m_d->savedUpdateRect |= vRect;

                // we already had a compression in frameRenderStartCompressor, so force the update directly
                slotDoCanvasUpdate();
            } else if (/* !m_d->currentCanvasIsOpenGL && */ !vRect.isEmpty()) {
                m_d->savedUpdateRect |= m_d->coordinatesConverter->viewportToWidget(vRect).toAlignedRect();

                // we already had a compression in frameRenderStartCompressor, so force the update directly
                slotDoCanvasUpdate();
            }
        }
    };
```

#### AUTO 


```{c}
const auto c3ca = ((v4 & mask) << 16) | (v3 & mask);
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {
                                            this->tryDoUpdate(true);
                                        }
```

#### AUTO 


```{c}
auto reallocFunc = [&](qint32 start) {
        QAtomicInt *newBuffer = new QAtomicInt[m_capacity];

        for (qint32 i = 0; i < oldCapacity; ++i) {
            newBuffer[start + i].store(m_buffer[i].load());
        }

        delete[] m_buffer;
        m_buffer = newBuffer;
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (QString groupName : d->groupNames) {
        int lastRowGroup = 0;
        for (const KisSwatchGroup::SwatchInfo &info : d->groups[groupName].infoList()) {
            lastRowGroup = qMax(lastRowGroup, info.row);
        }
        rows += (lastRowGroup + 1);
    }
```

#### AUTO 


```{c}
auto height = result.height();
```

#### AUTO 


```{c}
auto testBadPixel = [cs, op, srcPtr, dstPtr, numTestablePixels] (int badPixelPos,
            const quint8 *goodSrc,
            const quint8 *goodDst,
            const quint8 *badSrc,
            const quint8 *badDst,
            quint8 opacity,
            quint8 *expectedDst) {

        quint8 *badPixelDstPtr = dstPtr + badPixelPos * cs->pixelSize();

        for (int i = 0; i < numTestablePixels; i++) {
            if (i != badPixelPos) {
                memcpy(srcPtr + cs->pixelSize() * i, goodSrc, cs->pixelSize());
                memcpy(dstPtr + cs->pixelSize() * i, goodDst, cs->pixelSize());
            } else {
                memcpy(srcPtr + cs->pixelSize() * i, badSrc, cs->pixelSize());
                memcpy(dstPtr + cs->pixelSize() * i, badDst, cs->pixelSize());
            }
        }

        op->composite(dstPtr, numPixels * cs->pixelSize(),
                      srcPtr, numPixels * cs->pixelSize(),
                      0, 0,
                      1, numTestablePixels, opacity);

        if (memcmp(badPixelDstPtr, expectedDst, cs->pixelSize()) != 0) {
            qDebug() << "badPixelPos" << badPixelPos;
            qDebug() << "opacity" << opacity;
            qDebug() << "oriS" << badSrc[0] << badSrc[1] << badSrc[2] << badSrc[3];
            qDebug() << "oriS" << badDst[0] << badDst[1] << badDst[2] << badDst[3];
            qDebug() << "expD" << expectedDst[0] << expectedDst[1] << expectedDst[2] << expectedDst[3];
            qDebug() << "dst1" << badPixelDstPtr[0] << badPixelDstPtr[1] << badPixelDstPtr[2] << badPixelDstPtr[3];
            QFAIL("Failed to compose pixels");
        }
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto i : times) {
                frameHeader->duration = [&]() {
                    const auto nextKeyframe = frames->nextKeyframeTime(i);
                    if (nextKeyframe == -1) {
                        return static_cast<uint32_t>(image->animationInterface()->fullClipRange().end() - i);
                    } else {
                        return static_cast<uint32_t>(frames->nextKeyframeTime(i) - i);
                    }
                }();

                if (JxlEncoderSetFrameHeader(frameSettings, frameHeader.get()) != JXL_ENC_SUCCESS) {
                    errFile << "JxlEncoderSetFrameHeader failed";
                    return ImportExportCodes::InternalError;
                }

                QByteArray pixels{[&]() {
                    const auto frameData = frames->keyframeAt<KisRasterKeyframe>(i);
                    KisPaintDeviceSP dev =
                        new KisPaintDevice(*image->projection(), KritaUtils::DeviceCopyMode::CopySnapshot);
                    frameData->writeFrameToDevice(dev);
                    QByteArray p(static_cast<int>(cs->pixelSize()) * bounds.width() * bounds.height(), 0x0);
                    dev->readBytes(reinterpret_cast<quint8 *>(p.data()), image->bounds());
                    return p;
                }()};

                // BGRA -> RGBA
                if (cs->colorModelId() == RGBAColorModelID
                    && (cs->colorDepthId() == Integer8BitsColorDepthID
                        || cs->colorDepthId() == Integer16BitsColorDepthID)) {
                    swapRgb(cs, pixels);
                }

                if (JxlEncoderAddImageFrame(frameSettings,
                                            &pixelFormat,
                                            pixels.data(),
                                            static_cast<size_t>(pixels.size()))
                    != JXL_ENC_SUCCESS) {
                    errFile << "JxlEncoderAddImageFrame @" << i << "failed";
                    return ImportExportCodes::InternalError;
                }
            }
```

#### AUTO 


```{c}
auto endIt = KisRegion::mergeSparseRects(rects.begin(), rects.end());
```

#### AUTO 


```{c}
auto testBadPixel = [cs, op, srcPtr, dstPtr, numTestablePixels] (int badPixelPos,
            const quint8 *goodSrc,
            const quint8 *goodDst,
            const quint8 *badSrc,
            const quint8 *badDst,
            quint8 opacity,
            quint8 *expectedDst) {

        quint8 *badPixelDstPtr = dstPtr + badPixelPos * cs->pixelSize();

        for (int i = 0; i < numTestablePixels; i++) {
            if (i != badPixelPos) {
                memcpy(srcPtr + cs->pixelSize() * i, goodSrc, cs->pixelSize());
                memcpy(dstPtr + cs->pixelSize() * i, goodDst, cs->pixelSize());
            } else {
                memcpy(srcPtr + cs->pixelSize() * i, badSrc, cs->pixelSize());
                memcpy(dstPtr + cs->pixelSize() * i, badDst, cs->pixelSize());
            }
        }

        op->composite(dstPtr, numTestablePixels * cs->pixelSize(),
                      srcPtr, numTestablePixels * cs->pixelSize(),
                      0, 0,
                      1, numTestablePixels, opacity);

        if (memcmp(badPixelDstPtr, expectedDst, cs->pixelSize()) != 0) {
            qDebug() << "badPixelPos" << badPixelPos;
            qDebug() << "opacity" << opacity;
            qDebug() << "oriS" << badSrc[0] << badSrc[1] << badSrc[2] << badSrc[3];
            qDebug() << "oriD" << badDst[0] << badDst[1] << badDst[2] << badDst[3];
            qDebug() << "expD" << expectedDst[0] << expectedDst[1] << expectedDst[2] << expectedDst[3];
            qDebug() << "dst1" << badPixelDstPtr[0] << badPixelDstPtr[1] << badPixelDstPtr[2] << badPixelDstPtr[3];
#if HAVE_VC
            QFAIL("Failed to compose pixels");
#else
            qWarning() << "Skipping failed test when Vc library is not used";
#endif
        }
    };
```

#### LAMBDA EXPRESSION 


```{c}
[optionalFolderCheck, resourceType] (KoResourceSP res) {
        if (optionalFolderCheck.isEmpty()) return;

        const QString filePath = optionalFolderCheck + "/" + resourceType + "/" + res->filename();

        if (!QFileInfo(filePath).exists()) {
            qWarning() << "Couldn't find a file in the resource storage:";
            qWarning() << "    " << ppVar(res->filename());
            qWarning() << "    " << ppVar(optionalFolderCheck);
            qWarning() << "    " << ppVar(filePath);
        }

        QVERIFY(QFileInfo(filePath).exists());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
            emit sigRemoveTagFromSelection(m_tag);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[] (KisImageSP image) {
        KisMainWindow *window = KisPart::instance()->currentMainwindow();
        if (window) {
            if (window->viewManager()) {
                window->viewManager()->blockUntilOperationsFinishedForced(image);
            }
        }
    }
```

#### AUTO 


```{c}
auto newEnd = std::unique(container.begin(), container.end());
```

#### AUTO 


```{c}
auto markerIt = m_d->oldMarkers.begin();
```

#### AUTO 


```{c}
auto itL = linkChunk.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (QPair<int, int> p : testSwatches.keys()) {
        QCOMPARE(testSwatches[p], g.getEntry(p.first, p.second));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&](const El& e) -> bool {return e.m_key != id;}
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    KisBrushBasedPaintOpSettings *s =
                        dynamic_cast<KisBrushBasedPaintOpSettings*>(prop->settings().data());
                    if (s) {
                        if (s->autoSpacingActive()) {
                            s->setAutoSpacing(true, prop->value().toReal());
                        } else {
                            s->setSpacing(prop->value().toReal());
                        }
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KoColorSetSP palette : m_d->doc->paletteList()) {
        // Ensure stored palettes are KPL.
        palette->setPaletteType(KoColorSet::KPL);

        if (!store->open(m_d->imageName + PALETTE_PATH + palette->filename())) {
            m_d->errorMessages << i18n("could not save palettes");
            return false;
        }

        QByteArray ba = palette->toByteArray();

        qDebug() << "Storing palette inside document" << palette->colorCount();

        if (!ba.isEmpty()) {
            store->write(ba);
        } else {
            qWarning() << "Cannot save the palette to a byte array:" << palette->name();
        }
        store->close();
        res = true;
    }
```

#### AUTO 


```{c}
auto it = std::find_if(m_cachedResources.begin(),
                               m_cachedResources.end(),
                               [this, filename] (KoResourceSP res) {
                                   return res->resourceType().first == this->m_resourceType &&
                                       (res->filename() == filename ||
                                        QFileInfo(res->filename()).fileName() == filename);
                               });
```

#### AUTO 


```{c}
const auto list = shortcutString.split(QLatin1Char('+'));
```

#### AUTO 


```{c}
const auto pos = this->canvasBase()->coordinatesConverter()->widgetToImage(event->pos());
```

#### LAMBDA EXPRESSION 


```{c}
[endType1, endType2, color1, color2, segments, this]()
                                             {
                                                 if (m_selectedHandle.index == 0) {
                                                     segments[0]->setStartType(endType1);
                                                     segments[0]->setStartColor(color1);
                                                 } else {
                                                     segments[m_selectedHandle.index - 1]->setEndType(endType1);
                                                     segments[m_selectedHandle.index - 1]->setEndColor(color1);
                                                     if (m_selectedHandle.index < segments.size()) {
                                                         segments[m_selectedHandle.index]->setStartType(endType2);
                                                         segments[m_selectedHandle.index]->setStartColor(color2);
                                                     }
                                                 }
                                                 emit selectedHandleChanged();
                                                 emit updateRequested();
                                             }
```

#### LAMBDA EXPRESSION 


```{c}
[targetFrame, cmd](KisNodeSP node){
            if (node->supportsKeyframeChannel(KisKeyframeChannel::Raster.id())
             && node->isEditable(true)) {

                KisKeyframeChannel* chan = node->getKeyframeChannel(KisKeyframeChannel::Raster.id(), true);
                const int activeFrameTime = chan->activeKeyframeTime(targetFrame);
                chan->copyKeyframe(activeFrameTime, targetFrame, cmd);
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](const KisUniformPaintOpProperty *prop) {
                    ExperimentOption option;
                    option.readOptionSetting(prop->settings().data());
                    return option.isSmoothingEnabled;
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (QLayoutItem *item : qAsConst(m_items)) {
        int nextX = x + item->sizeHint().width() + spacing();
        if (nextX - spacing() > effectiveRect.right() && lineHeight > 0) {
            x = effectiveRect.x();
            y = y + lineHeight + spacing();
            nextX = x + item->sizeHint().width() + spacing();
            lineHeight = 0;
        }

        if (!testOnly) {
            item->setGeometry(QRect(QPoint(x, y), item->sizeHint()));
        }

        x = nextX;
        lineHeight = qMax(lineHeight, item->sizeHint().height());
    }
```

#### AUTO 


```{c}
auto gradient = static_cast<const KoAbstractGradient *>(dynamic_cast<const KritaGradientMapFilterConfiguration *>(config)->gradient());
```

#### LAMBDA EXPRESSION 


```{c}
[rc, state] () {
                state->painter->bltFixed(rc, state->dabsQueue);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    prop->setValue(prop->settings()->paintOpSize());
                }
```

#### AUTO 


```{c}
auto resource = new KisSeExprScript(TestUtil::fetchDataFileLazy("Disney_noisecolor2.kse"));
```

#### LAMBDA EXPRESSION 


```{c}
[&] (KisFreehandStrokeInfo *data) {
        data->painter->paintEllipse(rect);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString &arguments) {
        settingsDialog.setPreview(d->ffmpegPath % " -y " % d->applyVariables(arguments).replace("\n", " ")
                % " " % d->videoFilePath);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &btn : btns) {
                painter->setPen(Qt::NoPen);
                const QRect &rect = btn.first;

                QRect buttonRect(x, y, rect.width(), rect.height());

                // draw rounded rect shadow
                auto shadowRect = buttonRect.translated(0, 1);
                painter->setBrush(option.palette.shadow());
                painter->drawRoundedRect(shadowRect, 3, 3);

                // draw rounded rect itself
                painter->setBrush(option.palette.button());
                painter->drawRoundedRect(buttonRect, 3, 3);

                // draw text inside rounded rect
                painter->setPen(option.palette.buttonText().color());
                painter->drawText(buttonRect, Qt::AlignCenter, btn.second);

                // draw '+'
                if (i + 1 < total) {
                    x += rect.width() + 5;
                    painter->drawText(QPoint(x, plusY + (rect.height() / 2)), QString("+"));
                    x += plusRect.width() + 5;
                }
                i++;
            }
```

#### AUTO 


```{c}
auto it = m_stops.begin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto action : collectionActions) {
            // sanity + empty check ensures displayable actions and removes ourself
            // from the action list
            if (action && !action->text().isEmpty()) {
                actionList.append({componentName, action});
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    KisSprayOptionProperties option;
                    option.readOptionSetting(prop->settings().data());
                    option.spacing = prop->value().toReal();
                    option.writeOptionSetting(prop->settings().data());
                }
```

#### AUTO 


```{c}
const auto pos = this->viewConverter()->imageToDocument(imgCursorPos).toPoint();
```

#### LAMBDA EXPRESSION 


```{c}
[this](QUrl url) {
        this->removeRecentUrl(url);
    }
```

#### AUTO 


```{c}
const auto v2 = xsimd::bitwise_cast<uint_v>(xsimd::nearbyint_as_int(c2));
```

#### AUTO 


```{c}
auto it = m_d->currentArgs.meshTransform()->find(*m_d->hoveredControl);
```

#### LAMBDA EXPRESSION 


```{c}
[this](QStandardItem *item) {
        QUrl url = item->data().toUrl();
        QIcon icon = item->icon();
        if (url.isValid() && !icon.isNull()) {
            d->recentFiles->setUrlIcon(url, icon);
        }
    }
```

#### AUTO 


```{c}
auto referenceImageLayer = document->referenceImagesLayer();
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {
        Q_FOREACH (KisNodeSP node, m_hiddenProjectionLeaves) {
            node->projectionLeaf()->setTemporaryHiddenFromRendering(false);
            if (KisDelayedUpdateNodeInterface *delayedNode = dynamic_cast<KisDelayedUpdateNodeInterface*>(node.data())) {
                delayedNode->forceUpdateTimedNode();
            } else {
                node->setDirty();
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QString groupName : groupNames) {
        int lastRowGroup = 0;
        for (const KisSwatchGroup::SwatchInfo &info : groups[groupName].infoList()) {
            lastRowGroup = qMax(lastRowGroup, info.row);
        }
        rows += (lastRowGroup + 1);
    }
```

#### AUTO 


```{c}
auto it = renderersToTest.begin();
```

#### LAMBDA EXPRESSION 


```{c}
[this, tryIssueCanvasUpdates](const QVector<KisUpdateInfoSP> &infoObjects) {
        QVector<QRect> viewportRects = m_d->canvasWidget->updateCanvasProjection(infoObjects);
        const QRect vRect = std::accumulate(viewportRects.constBegin(), viewportRects.constEnd(),
                                            QRect(), std::bit_or<QRect>());

        tryIssueCanvasUpdates(vRect);
    }
```

#### AUTO 


```{c}
auto conv = KoColorSpaceRegistry::instance()->createColorConverter(src, cs, KoColorConversionTransformation::internalRenderingIntent(), KoColorConversionTransformation::internalConversionFlags());
```

#### LAMBDA EXPRESSION 


```{c}
[image, node, channelId, time, copy] () mutable -> KUndo2Command* {
                bool result = false;

                QScopedPointer<KUndo2Command> cmd(new KUndo2Command());

                KisKeyframeChannel *channel = node->getKeyframeChannel(channelId);
                bool isScalar = (channelId != KisKeyframeChannel::Raster.id());
                quint8 originalOpacity = node->opacity();
                bool createdChannel = false;

                // Try get channel...
                if (!channel) {
                    node->enableAnimation();
                    channel = node->getKeyframeChannel(channelId, true);
                    if (!channel) return nullptr;

                    createdChannel = true;
                }

                if (copy && channel->activeKeyframeAt(time)) {
                    if (!channel->keyframeAt(time)) {
                        channel->copyKeyframe(channel->activeKeyframeTime(time), time, cmd.data());
                        result = true;
                    }
                } else {
                    if (channel->keyframeAt(time) && !createdChannel) { // Overwrite existing...
                        if (image->animationInterface()->currentTime() == time && channelId == KisKeyframeChannel::Raster.id()) {

                            //shortcut: clearing the image instead
                            KisPaintDeviceSP device = node->paintDevice();
                            if (device) {
                                const QRect dirtyRect = device->extent();

                                KisTransaction transaction(kundo2_i18n("Clear"), device, cmd.data());
                                device->clear();
                                (void) transaction.endAndTake(); // saved as 'parent'

                                node->setDirty(dirtyRect);

                                result = true;
                            }
                        }
                    } else { // Make new...
                        KisKeyframeSP previousKey = channel->activeKeyframeAt(time);

                        if (isScalar) {
                            KisScalarKeyframeChannel* scalarChannel = static_cast<KisScalarKeyframeChannel*>(channel);
                            const qreal value = scalarChannel->valueAt(time); //Get interpolated value.
                            scalarChannel->addScalarKeyframe(time, value, cmd.data());
                        } else {
                            channel->addKeyframe(time, cmd.data());
                        }

                        // Use color label of previous key, if exists...
                        if (previousKey && channel->keyframeAt(time)) {
                            channel->keyframeAt(time)->setColorLabel(previousKey->colorLabel());
                        }

                        result = true;
                    }
                }

                // when a new opacity keyframe is created, the opacity is set to 0
                // this makes sure to use the opacity that was previously used
                // maybe there is a better way to do this
                node->setOpacity(originalOpacity);

                return result ? new KisCommandUtils::SkipFirstRedoWrapper(cmd.take()) : nullptr;
        }
```

#### AUTO 


```{c}
auto info{std::make_unique<JxlBasicInfo>()};
```

#### AUTO 


```{c}
auto it = m_d->currentArgs.meshTransform()->beginSegments();
```

#### RANGE FOR STATEMENT 


```{c}
for (const FlattenedNode &item : nodes) {
                KisNodeSP node = item.node;

                PSDLayerRecord *layerRecord = new PSDLayerRecord(m_header);
                layers.append(layerRecord);

                const QRect maskRect;

                const bool nodeVisible = node->visible();
                const KoColorSpace *colorSpace = node->colorSpace();
                const quint8 nodeOpacity = node->opacity();
                const quint8 nodeClipping = 0;
                const KisPaintLayer *paintLayer = qobject_cast<KisPaintLayer *>(node.data());
                const bool alphaLocked = (paintLayer && paintLayer->alphaLocked());
                const QString nodeCompositeOp = node->compositeOpId();

                const KisGroupLayer *groupLayer = qobject_cast<KisGroupLayer *>(node.data());
                const bool nodeIsPassThrough = groupLayer && groupLayer->passThroughMode();

                QDomDocument stylesXmlDoc = fetchLayerStyleXmlData(node);

                if (mergedPatternsXmlDoc.isNull() && !stylesXmlDoc.isNull()) {
                    mergedPatternsXmlDoc = stylesXmlDoc;
                } else if (!mergedPatternsXmlDoc.isNull() && !stylesXmlDoc.isNull()) {
                    mergePatternsXMLSection(stylesXmlDoc, mergedPatternsXmlDoc);
                }

                bool nodeIrrelevant = false;
                QString nodeName;
                KisPaintDeviceSP layerContentDevice;
                psd_section_type sectionType;

                if (item.type == FlattenedNode::RASTER_LAYER) {
                    nodeIrrelevant = false;
                    nodeName = node->name();
                    layerContentDevice = node->projection();
                    sectionType = psd_other;
                } else {
                    nodeIrrelevant = true;
                    nodeName = item.type == FlattenedNode::SECTION_DIVIDER ? QString("</Layer group>") : node->name();
                    layerContentDevice = 0;
                    sectionType = item.type == FlattenedNode::SECTION_DIVIDER ? psd_bounding_divider
                        : item.type == FlattenedNode::FOLDER_OPEN             ? psd_open_folder
                                                                              : psd_closed_folder;
                }

                // === no access to node anymore

                QRect layerRect;

                if (layerContentDevice) {
                    QRect rc = layerContentDevice->exactBounds();
                    rc = rc.normalized();

                    // keep to the max of photoshop's capabilities
                    // XXX: update this to PSB
                    if (rc.width() > 30000)
                        rc.setWidth(30000);
                    if (rc.height() > 30000)
                        rc.setHeight(30000);

                    layerRect = rc;
                }

                layerRecord->top = layerRect.y();
                layerRecord->left = layerRect.x();
                layerRecord->bottom = layerRect.y() + layerRect.height();
                layerRecord->right = layerRect.x() + layerRect.width();

                // colors + alpha channel
                // note: transparency mask not included
                layerRecord->nChannels = static_cast<quint16>(colorSpace->colorChannelCount() + 1);

                ChannelInfo *info = new ChannelInfo;
                info->channelId = -1; // For the alpha channel, which we always have in Krita, and should be saved first in
                layerRecord->channelInfoRecords << info;

                // the rest is in display order: rgb, cmyk, lab...
                for (quint32 i = 0; i < colorSpace->colorChannelCount(); ++i) {
                    info = new ChannelInfo;
                    info->channelId = static_cast<qint16>(i); // 0 for red, 1 = green, etc
                    layerRecord->channelInfoRecords << info;
                }

                layerRecord->blendModeKey = composite_op_to_psd_blendmode(nodeCompositeOp);
                layerRecord->isPassThrough = nodeIsPassThrough;
                layerRecord->opacity = nodeOpacity;
                layerRecord->clipping = nodeClipping;

                layerRecord->transparencyProtected = alphaLocked;
                layerRecord->visible = nodeVisible;
                layerRecord->irrelevant = nodeIrrelevant;

                layerRecord->layerName = nodeName.isEmpty() ? i18n("Unnamed Layer") : nodeName;

                layerRecord->write(io, layerContentDevice, nullptr, QRect(), sectionType, stylesXmlDoc, node->inherits("KisGroupLayer"));
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KisSwatch &s : c.values()) {
            SwatchInfo i = {m_name, s, c.keys()[row++], column};
            res.append(i);
        }
```

#### AUTO 


```{c}
auto it10 = forest.insert(childEnd(it8), 10);
```

#### AUTO 


```{c}
auto propertizedShortcut = qVariantFromValue(QList<QKeySequence>() << info.defaultShortcut);
```

#### AUTO 


```{c}
auto &action
```

#### AUTO 


```{c}
const auto idx = sourceModel()->index(sourceRow, 0, sourceParent);
```

#### AUTO 


```{c}
auto enc = JxlEncoderMake(nullptr);
```

#### AUTO 


```{c}
const auto numPixels = static_cast<size_t>(pixels.size()) / cs->pixelSize();
```

#### AUTO 


```{c}
auto it = adapters.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const KoGradientStop &stopGradientStop : gradient->stops()) {
            if (qFuzzyCompare(stopGradientStop.position, lastStopPosition)) {
                stops << toQGradientStop(
                    stopGradientStop.color, stopGradientStop.type, stopGradientStop.position + 0.000001,
                    canvasResourcesInterface
                );
                lastStopPosition = stopGradientStop.position + 0.000001;
            } else {
                stops << toQGradientStop(
                    stopGradientStop.color, stopGradientStop.type, stopGradientStop.position,
                    canvasResourcesInterface
                );
                lastStopPosition = stopGradientStop.position;
            }
        }
```

#### AUTO 


```{c}
auto begin = m_objects.begin();
```

#### CONST EXPRESSION 


```{c}
constexpr int errorMessageTimeout = 5000;
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    KisDuplicateOptionProperties option;
                    option.readOptionSetting(prop->settings().data());

                    prop->setValue(option.duplicate_healing);
                }
```

#### CONST EXPRESSION 


```{c}
static constexpr const char *HalftoneMode_Intensity = "intensity";
```

#### LAMBDA EXPRESSION 


```{c}
[uuid] (KisNodeSP node) {
                return node->uuid() == uuid;
            }
```

#### AUTO 


```{c}
auto* referencesLayer = dynamic_cast<KisReferenceImagesLayer*>(layer)
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {
                                this->tryDoUpdate(true);
                            }
```

#### AUTO 


```{c}
auto it = values.begin();
```

#### AUTO 


```{c}
auto it6 = forest.insert(childEnd(it5), 6);
```

#### LAMBDA EXPRESSION 


```{c}
[this](){ setEnabled(true); }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {
            {
                /// Here is a bit of code-duplication from
                /// InplaceTransformStrokeStrategy. This code reduced the
                /// amount of updates we do in the course of transformation.
                /// Basically, we find the minimum set of parents for the
                /// selected layers and do full refresh for them

                KisNodeList filteredNodes = m_processedNodes;
                KisLayerUtils::sortAndFilterMergableInternalNodes(filteredNodes);

                KisUpdateCommandEx::SharedData newUpdateData;

                Q_FOREACH (KisNodeSP root, filteredNodes) {
                    QRect dirtyRect;

                    for (auto it = m_updateData->begin(); it != m_updateData->end(); ++it) {
                        if (it->first == root || KisLayerUtils::checkIsChildOf(it->first, {root})) {
                            dirtyRect |= it->second;
                        }
                    }
                    newUpdateData.push_back(std::make_pair(root, dirtyRect));
                }

                *m_updateData = newUpdateData;
            }

            m_updatesFacade->enableDirtyRequests();
            m_updatesDisabled = false;
            runAndSaveCommand(toQShared(new KisUpdateCommandEx(m_updateData, m_updatesFacade, KisUpdateCommandEx::FINALIZING)), KisStrokeJobData::BARRIER, KisStrokeJobData::NORMAL);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](const KoGradientStop& a, const KoGradientStop& b) {
            return a.position < b.position;
            }
```

#### AUTO 


```{c}
auto preset = rserver->resourceByName(m_currentPreset->name());
```

#### RANGE FOR STATEMENT 


```{c}
for (const Exiv2::Exifdatum &it : exifData) {
        const uint16_t tag = it.tag();

        if (tag == Exif::Image::StripOffsets || tag == Exif::Image::RowsPerStrip || tag == Exif::Image::StripByteCounts
            || tag == Exif::Image::JPEGInterchangeFormat || tag == Exif::Image::JPEGInterchangeFormatLength || it.tagName() == "0x0000") {
            dbgMetaData << it.key().c_str() << " is ignored";
        } else if (tag == Exif::Photo::MakerNote) {
            store->addEntry({makerNoteSchema, "RawData", exivValueToKMDValue(it.getValue(), false)});
        } else if (tag == Exif::Image::DateTime) { // load as xmp:ModifyDate
            store->addEntry({xmpSchema, "ModifyDate", exivValueToKMDValue(it.getValue(), false)});
        } else if (tag == Exif::Image::ImageDescription) { // load as "dc:description"
            store->addEntry({dcSchema, "description", exivValueToKMDValue(it.getValue(), false)});
        } else if (tag == Exif::Image::Software) { // load as "xmp:CreatorTool"
            store->addEntry({xmpSchema, "CreatorTool", exivValueToKMDValue(it.getValue(), false)});
        } else if (tag == Exif::Image::Artist) { // load as dc:creator
            QList<KisMetaData::Value> creators = {exivValueToKMDValue(it.getValue(), false)};
            store->addEntry({dcSchema, "creator", {creators, KisMetaData::Value::OrderedArray}});
        } else if (tag == Exif::Image::Copyright) { // load as dc:rights
            store->addEntry({dcSchema, "rights", exivValueToKMDValue(it.getValue(), false)});
        } else if (it.groupName() == "Image") {
            // Tiff tags
            const QLatin1String fixedTN(it.tagName().c_str());
            if (tag == Exif::Image::ExifTag || tag == Exif::Image::GPSTag) {
                dbgMetaData << "Ignoring " << it.key().c_str();
            } else if (KisMetaData::Entry::isValidName(fixedTN)) {
                store->addEntry({tiffSchema, fixedTN, exivValueToKMDValue(it.getValue(), false)});
            } else {
                dbgMetaData << "Invalid tag name: " << fixedTN;
            }
        } else if (it.groupName() == "Photo") {
            // Exif tags
            KisMetaData::Value metaDataValue;
            if (tag == Exif::Photo::ExifVersion || tag == Exif::Photo::FlashpixVersion) {
                metaDataValue = exifVersionToKMDValue(it.getValue());
            } else if (tag == Exif::Photo::FileSource) {
                metaDataValue = KisMetaData::Value(3);
            } else if (tag == Exif::Photo::SceneType) {
                metaDataValue = KisMetaData::Value(1);
            } else if (tag == Exif::Photo::ComponentsConfiguration) {
                metaDataValue = exifArrayToKMDIntOrderedArray(it.getValue());
            } else if (tag == Exif::Photo::OECF) {
                metaDataValue = exifOECFToKMDOECFStructure(it.getValue(), byteOrder);
            } else if (tag == Exif::Photo::DateTimeDigitized || tag == Exif::Photo::DateTimeOriginal) {
                metaDataValue = exivValueToKMDValue(it.getValue(), false);
            } else if (tag == Exif::Photo::DeviceSettingDescription) {
                metaDataValue = deviceSettingDescriptionExifToKMD(it.getValue());
            } else if (tag == Exif::Photo::CFAPattern) {
                metaDataValue = cfaPatternExifToKMD(it.getValue(), byteOrder);
            } else if (tag == Exif::Photo::Flash) {
                metaDataValue = flashExifToKMD(it.getValue());
            } else if (tag == Exif::Photo::UserComment) {
                if (it.getValue()->typeId() != Exiv2::undefined) {
                    KisMetaData::Value vUC = exivValueToKMDValue(it.getValue(), false);
                    Q_ASSERT(vUC.type() == KisMetaData::Value::Variant);
                    QVariant commentVar = vUC.asVariant();
                    QString comment;
                    if (commentVar.type() == QVariant::String) {
                        comment = commentVar.toString();
                    } else if (commentVar.type() == QVariant::ByteArray) {
                        const QByteArray commentString = commentVar.toByteArray();
                        comment = QString::fromLatin1(commentString.constData(), commentString.size());
                    } else {
                        warnKrita << "KisExifIO: Unhandled UserComment value type.";
                    }
                    KisMetaData::Value vcomment(comment);
                    vcomment.addPropertyQualifier("xml:lang", KisMetaData::Value("x-default"));
                    QList<KisMetaData::Value> alt;
                    alt.append(vcomment);
                    metaDataValue = KisMetaData::Value(alt, KisMetaData::Value::LangArray);
                }
            } else {
                bool forceSeq = false;
                KisMetaData::Value::ValueType arrayType = KisMetaData::Value::UnorderedArray;
                if (tag == Exif::Photo::ISOSpeedRatings) {
                    forceSeq = true;
                    arrayType = KisMetaData::Value::OrderedArray;
                }
                metaDataValue = exivValueToKMDValue(it.getValue(), forceSeq, arrayType);
            }
            if (tag == Exif::Photo::InteroperabilityTag
                || metaDataValue.type() == KisMetaData::Value::Invalid) { // InteroperabilityTag isn't useful for XMP, 0xea1d isn't a valid Exif tag
                warnMetaData << "Ignoring " << it.key().c_str();
            } else {
                store->addEntry({exifSchema, it.tagName().c_str(), metaDataValue});
            }
        } else if (it.groupName() == "Thumbnail") {
            dbgMetaData << "Ignoring thumbnail tag :" << it.key().c_str();
        } else if (it.groupName() == "GPSInfo") {
            store->addEntry({exifSchema, it.tagName().c_str(), exivValueToKMDValue(it.getValue(), false)});
        } else {
            dbgMetaData << "Unknown exif tag, cannot load:" << it.key().c_str();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        Q_FOREACH (KisSelectionSP selection, m_deactivatedSelections) {
            selection->setVisible(true);
        }

        if (m_deactivatedOverlaySelectionMask) {
            m_deactivatedOverlaySelectionMask->selection()->setVisible(true);
            m_deactivatedOverlaySelectionMask->setDirty();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        if (m_initialTransformArgs.isIdentity()) {
            KisStrokeStrategyUndoCommandBased::cancelStrokeCallback();
        } else {
            KisStrokeStrategyUndoCommandBased::finishStrokeCallback();
        }
    }
```

#### CONST EXPRESSION 


```{c}
constexpr int halfPatchStep= patchStep >> 1;
```

#### AUTO 


```{c}
const auto *const cs = image->colorSpace();
```

#### LAMBDA EXPRESSION 


```{c}
[index, pModel] {pModel->insertItem(index, true); }
```

#### AUTO 


```{c}
auto trySendTabletEvent = [&](QTabletEvent::Type t){
            // First, try sending a tablet event.
            QTabletEvent e(t, localPosDip, globalPosDip, currentDevice, currentPointerType,
                           pressureNew, tiltX, tiltY, tangentialPressure, rotation, z,
                           keyboardModifiers, tabletData.uniqueId, button, buttons);
            qApp->sendEvent(w, &e);

            if (e.isAccepted()) {
                globalEventEater->activate();
            }
            else {
                // Turn off eventEater send a synthetic mouse event.
                globalEventEater->deactivate();
                QMouseEvent m(mouseEventType(t), localPosDip, button, buttons, keyboardModifiers);
                qApp->sendEvent(w, &e);
            }
        };
```

#### LAMBDA EXPRESSION 


```{c}
[&]()
    {
        QStringList mimeTypes = KisResourceLoaderRegistry::instance()->mimeTypes(ResourceType::Workspaces);

        KoFileDialog dialog(0, KoFileDialog::OpenFile, "OpenDocument");
        dialog.setMimeTypeFilters(mimeTypes);
        dialog.setCaption(i18nc("@title:window", "Choose File to Add"));
        QString filename = dialog.filename();

        KisResourceUserOperations::importResourceFileWithUserInput(this, "", ResourceType::Workspaces, filename);
    }
```

#### AUTO 


```{c}
auto it = std::find_if(ids.begin(), ids.end(),
                           [id] (const KoID &item) { return item.id() == id; });
```

#### LAMBDA EXPRESSION 


```{c}
[interface]() {
                interface->KisStrokeStrategyUndoCommandBased::finishStrokeCallback();
            }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        QString name;
        name = QInputDialog::getText(this, i18nc("@title:window", "New Workspace..."),
                                                                i18nc("@label:textbox", "Name:"));
        if (name.isEmpty()) {
            return;
        }

        auto rserver = KisResourceServerProvider::instance()->workspaceServer();

        KisWorkspaceResourceSP workspace(new KisWorkspaceResource(""));
        workspace->setDockerState(m_this->saveState());

        // this line must happen before we save the workspace to resource folder or other places
        // because it mostly just triggers palettes to be saved into the workspace
        d->viewManager->canvasResourceProvider()->notifySavingWorkspace(workspace);
        workspace->setValid(true);
        QString saveLocation = rserver->saveLocation();

        QFileInfo fileInfo(saveLocation + "/" + name + workspace->defaultFileExtension());

        workspace->setFilename(fileInfo.fileName());
        workspace->setName(name);

        KisResourceUserOperations::addResourceWithUserInput(this, workspace);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (heif_item_id id : metadata_IDs) {

          if (handle.get_metadata_type(id) == "Exif") {
            // Read exif information

            std::vector<uint8_t> exif_data = handle.get_metadata(id);

            if (exif_data.size()>4) {
              uint32_t skip = ((exif_data[0]<<24) | (exif_data[1]<<16) | (exif_data[2]<<8) | exif_data[3]) + 4;

              if (exif_data.size()>skip) {
                KisMetaData::IOBackend* exifIO = KisMetaData::IOBackendRegistry::instance()->value("exif");

                // Copy the exif data into the byte array
                QByteArray ba;
                ba.append((char*)(exif_data.data()+skip), exif_data.size()-skip);
                QBuffer buf(&ba);
                exifIO->loadFrom(layer->metaData(), &buf);
              }
            }
          }

          if (handle.get_metadata_type(id) == "mime" &&
              handle.get_metadata_content_type(id) == "application/rdf+xml") {
            // Read XMP information

            std::vector<uint8_t> xmp_data = handle.get_metadata(id);

            KisMetaData::IOBackend* xmpIO = KisMetaData::IOBackendRegistry::instance()->value("xmp");

            // Copy the xmp data into the byte array
            QByteArray ba;
            ba.append((char*)(xmp_data.data()), xmp_data.size());

            QBuffer buf(&ba);
            xmpIO->loadFrom(layer->metaData(), &buf);
          }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    DeformOption option;
                    option.readOptionSetting(prop->settings().data());
                    option.deform_amount = prop->value().toReal();
                    option.writeOptionSetting(prop->settings().data());
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVariant &item : readValue) {
        result.insert(item.toInt());
    }
```

#### AUTO 


```{c}
auto it = std::upper_bound(fontWeights.begin(),
                                       fontWeights.end(),
                                       context.currentGC()->font.weight());
```

#### RANGE FOR STATEMENT 


```{c}
for (KoColorSet *cs : m_activeDocument->paletteList()) {
            m_rServer->addResource(cs);
        }
```

#### AUTO 


```{c}
auto source = resourcesInterface->source<KoPattern>(ResourceType::Patterns);
```

#### LAMBDA EXPRESSION 


```{c}
[&] (KisFreehandStrokeInfo *data) {
        data->painter->paintAt(pi, data->dragDistance);
    }
```

#### AUTO 


```{c}
auto it = d->groups.begin();
```

#### AUTO 


```{c}
auto it2 = forest.insert(childEnd(it0), 2);
```

#### RANGE FOR STATEMENT 


```{c}
for (double value : inputValuesRaw) {
        double cValue = value;
        /*
         * SMPTE_ST_428_1
         * V= (48 * Lo / 52.37)^(1/2.6)
         *
         */

        //cValue = powf(48 * value/ 52.37, (1/2.6)) ;

        cValue = applySMPTE_ST_428Curve(value);

        double lValue = (52.37/48.0 * powf( cValue , 2.6 ));

        //Not possible in icc v4

        QVERIFY2(fabs(lValue - value) < 0.000001, QString("Values don't match for SMPTE ST 428 1: %1 %2").arg(value).arg(lValue).toLatin1());

    }
```

#### AUTO 


```{c}
auto index = m_d->currentArgs.meshTransform()->hitTestControlPoint(mousePos, grabRadius);
```

#### AUTO 


```{c}
const auto patternEnd = pattern.cend();
```

#### AUTO 


```{c}
auto i = actionInfoList.begin();
```

#### AUTO 


```{c}
auto unmultipliedColorsConsistent = [](T *d) { return !(std::abs(d[3]) < std::numeric_limits<T>::epsilon()); };
```

#### LAMBDA EXPRESSION 


```{c}
[&linearizedNodes, &rhs, this](KisNodeSP node) {
                                               KisNodeSP refNode = linearizedNodes.dequeue();
                                               if (rhs.d->preActivatedNode.data() == refNode.data()) {
                                                   d->preActivatedNode = node;
                                               }
                                           }
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    ExperimentOption option;
                    option.readOptionSetting(prop->settings().data());

                    prop->setValue(int(option.displacement));
                }
```

#### AUTO 


```{c}
const auto y = match.captured(2).toInt();
```

#### RANGE FOR STATEMENT 


```{c}
for (QRect &rc : rects) {
        state->painter->mirrorRect(direction, &rc);

        KritaUtils::addJobConcurrent(jobs,
            [rc, state] () {
                state->painter->bltFixed(rc, state->dabsQueue);
            }
        );
    }
```

#### LAMBDA EXPRESSION 


```{c}
[] (bool forgettable) {
                Q_UNUSED(forgettable);
                return KisLodSyncPair(
                    new KisTestingStrokeStrategy(QLatin1String("sync_u_"), false, true, true),
                    QList<KisStrokeJobData*>());
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (QUrl url : data->urls()) { // do copy it
                QScopedPointer<QTemporaryFile> tmp(new QTemporaryFile());
                tmp->setAutoRemove(true);

                if (!url.isLocalFile()) {
                    // download the file and substitute the url
                    KisRemoteFileFetcher fetcher;
                    tmp->setFileName(url.fileName());

                    if (!fetcher.fetchFile(url, tmp.data())) {
                        qWarning() << "Fetching" << url << "failed";
                        continue;
                    }
                    url = QUrl::fromLocalFile(tmp->fileName());
                }

                if (url.isLocalFile()) {
                    if (action == KisCanvasDrop::INSERT_MANY_LAYERS) {
                        this->mainWindow()->viewManager()->imageManager()->importImage(url);
                        this->activateWindow();
                    } else if (action == KisCanvasDrop::INSERT_MANY_FILE_LAYERS
                               || action == KisCanvasDrop::INSERT_AS_NEW_FILE_LAYER) {
                        KisNodeCommandsAdapter adapter(this->mainWindow()->viewManager());
                        QFileInfo fileInfo(url.toLocalFile());

                        QString type = KisMimeDatabase::mimeTypeForFile(url.toLocalFile());
                        QStringList mimes = KisImportExportManager::supportedMimeTypes(KisImportExportManager::Import);

                        if (!mimes.contains(type)) {
                            QString msg =
                                KisImportExportErrorCode(ImportExportCodes::FileFormatNotSupported).errorMessage();
                            QMessageBox::warning(this,
                                                 i18nc("@title:window", "Krita"),
                                                 i18n("Could not open %2.\nReason: %1.", msg, url.toDisplayString()));
                            continue;
                        }

                        KisFileLayer *fileLayer = new KisFileLayer(this->image(),
                                                                   "",
                                                                   url.toLocalFile(),
                                                                   KisFileLayer::None,
                                                                   fileInfo.fileName(),
                                                                   OPACITY_OPAQUE_U8);

                        KisLayerSP above = this->mainWindow()->viewManager()->activeLayer();
                        KisNodeSP parent = above ? above->parent() : this->mainWindow()->viewManager()->image()->root();

                        adapter.addNode(fileLayer, parent, above);
                    } else if (action == KisCanvasDrop::OPEN_IN_NEW_DOCUMENT
                               || action == KisCanvasDrop::OPEN_MANY_DOCUMENTS) {
                        if (this->mainWindow()) {
                            this->mainWindow()->openDocument(url.toLocalFile(), KisMainWindow::None);
                        }
                    } else if (action == KisCanvasDrop::INSERT_AS_REFERENCE_IMAGES
                               || action == KisCanvasDrop::INSERT_AS_REFERENCE_IMAGE) {
                        auto *reference = KisReferenceImage::fromFile(url.toLocalFile(), *this->viewConverter(), this);

                        if (reference) {
                            const auto pos = this->canvasBase()->coordinatesConverter()->widgetToImage(imgCursorPos);
                            reference->setPosition((*this->viewConverter()).imageToDocument(pos));
                            this->canvasBase()->referenceImagesDecoration()->addReferenceImage(reference);

                            KoToolManager::instance()->switchToolRequested("ToolReferenceImages");
                        }
                    }
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[] (const QPointF &pt) {
                    return pt.x();
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (KisShortcutConfiguration * const shortcut : shortcuts) {
            dbgUI << "Adding shortcut" << shortcut->keys() << "for action" << shortcut->action()->name();
            switch(shortcut->type()) {
            case KisShortcutConfiguration::KeyCombinationType:
                d->addKeyShortcut(shortcut->action(), shortcut->mode(), shortcut->keys());
                break;
            case KisShortcutConfiguration::MouseButtonType:
                d->addStrokeShortcut(shortcut->action(), shortcut->mode(), shortcut->keys(), shortcut->buttons());
                break;
            case KisShortcutConfiguration::MouseWheelType:
                d->addWheelShortcut(shortcut->action(), shortcut->mode(), shortcut->keys(), shortcut->wheel());
                break;
            case KisShortcutConfiguration::GestureType:
                if (!d->addNativeGestureShortcut(shortcut->action(), shortcut->mode(), shortcut->gesture())) {
                    d->addTouchShortcut(shortcut->action(), shortcut->mode(), shortcut->gesture());
                }
                break;
            default:
                break;
            }
        }
```

#### AUTO 


```{c}
auto it = d->subtasks.begin();
```

#### RANGE FOR STATEMENT 


```{c}
for (KisSwatchGroup &g : d->groups.values()) {
        colorCount += g.colorCount();
    }
```

#### AUTO 


```{c}
const auto tileRowStride =
                (tileWidth - columnsToWork) * floatPixelSize;
```

#### LAMBDA EXPRESSION 


```{c}
[this,
                              argsAreInitialized]() mutable {
        QRect srcRect;

        KisPaintDeviceSP externalSource =
            m_d->externalSource ? m_d->externalSource :
            (argsAreInitialized && m_d->initialTransformArgs.externalSource()) ?
                m_d->initialTransformArgs.externalSource() : 0;

        if (externalSource) {
            // Start the transformation around the visible pixels of the external image
            srcRect = externalSource->exactBounds();
        } else if (m_d->selection) {
            srcRect = m_d->selection->selectedExactRect();
        } else {
            srcRect = QRect();
            Q_FOREACH (KisNodeSP node, m_d->processedNodes) {
                // group layers may have a projection of layers
                // that are locked and will not be transformed
                if (node->inherits("KisGroupLayer")) continue;

                if (const KisTransformMask *mask = dynamic_cast<const KisTransformMask*>(node.data())) {
                    srcRect |= mask->sourceDataBounds();
                } else if (const KisSelectionMask *mask = dynamic_cast<const KisSelectionMask*>(node.data())) {
                    srcRect |= mask->selection()->selectedExactRect();
                } else if (const KisTransparencyMask *mask = dynamic_cast<const KisTransparencyMask*>(node.data())) {
                    srcRect |= mask->selection()->selectedExactRect();
                } else {
                    /// We shouldn't include masks or layer styles into the handles rect,
                    /// in the end, we process the paint device only
                    srcRect |= node->paintDevice() ? node->paintDevice()->exactBounds() : node->exactBounds();
                }
            }
        }

        TransformTransactionProperties transaction(srcRect, &m_d->initialTransformArgs, m_d->rootNode, m_d->processedNodes);
        if (!argsAreInitialized) {
            m_d->initialTransformArgs = KisTransformUtils::resetArgsForMode(m_d->mode, m_d->filterId, transaction, m_d->externalSource);
        }
        m_d->externalSource.clear();

        const QRect imageBoundsRect = m_d->imageRoot->projection()->defaultBounds()->bounds();
        m_d->previewLevelOfDetail = calculatePreferredLevelOfDetail(srcRect & imageBoundsRect);

        if (m_d->previewLevelOfDetail > 0) {
            for (auto it = m_d->prevDirtyRects.begin(); it != m_d->prevDirtyRects.end(); ++it) {
                KisLodTransform t(m_d->previewLevelOfDetail);
                m_d->prevDirtyPreviewRects.addUpdate(it->first, t.map(it->second));
            }
        }

        Q_EMIT sigTransactionGenerated(transaction, m_d->initialTransformArgs, this);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const AuxiliaryMicrocell &a, const AuxiliaryMicrocell &b) {
            return a.index < b.index;
        }
```

#### AUTO 


```{c}
const auto *channel1 = layer1->getKeyframeChannel(KisKeyframeChannel::Raster.id());
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {}
```

#### AUTO 


```{c}
auto hasIcon = index.data(Qt::DecorationRole).value<QIcon>().isNull();
```

#### AUTO 


```{c}
auto availOut = static_cast<size_t>(compressed.size());
```

#### LAMBDA EXPRESSION 


```{c}
[epsilon] (float a, float b) -> bool {
            return (qAbs(a - b) < epsilon); }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (int col, int row) {
                            KisTileSP tile = dm.getOldTile(col, row);
                            tile->lockForRead();
                            tile->unlockForRead();
                        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QPair<int, int> p : testSwatches.keys()) {
        if (p.first < 10) {
            keptCount++;
            QCOMPARE(testSwatches[p], g.getEntry(p.first, p.second));
        }
    }
```

#### AUTO 


```{c}
const auto& map
```

#### AUTO 


```{c}
const auto a = batch<T, A>::load(srcPtr, U{});
```

#### AUTO 


```{c}
const auto widthBound = qAbs(bounds.width());
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &pair : m_d->asyncRenderers) {
        KIS_SAFE_ASSERT_RECOVER_NOOP(!pair.renderer->isActive());
        if (viewManager) {
            viewManager->blockUntilOperationsFinishedForced(pair.image);
        } else {
            pair.image->barrierLock(true);
            pair.image->unlock();
        }

    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action: actionCollection->actions()) {
        actionsSnapshot->addAction(action->objectName(), action);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, earliestFrame, frameAssociates](KisNodeSP node) {
            if (!node->isAnimated() || !node->paintDevice())
                return;

            KisRasterKeyframeChannel* rasterChan = node->paintDevice()->keyframeChannel();

            if (!rasterChan)
                return;

            // Gather all original keyframes and their associated time values.
            QHash<int, KisKeyframeSP> originalKeyframes;
            Q_FOREACH( const int& time, rasterChan->allKeyframeTimes()) {
                if (time >= earliestFrame && rasterChan->keyframeAt(time)) {
                    originalKeyframes.insert(time, rasterChan->keyframeAt(time));
                    rasterChan->removeKeyframe(time);
                }
            }

            //Now lets re-sort the raster channels...
            int intendedSceneFrameTime = earliestFrame;
            for (int i = 0; i < rowCount(); i++) {
                QModelIndex sceneIndex = index(i, 0);
                const int srcFrame = index(StoryboardItem::FrameNumber, 0, sceneIndex).data().toInt();
                Q_FOREACH( const int& associateFrameOffset, frameAssociates.values(sceneIndex) ) {
                    if (!originalKeyframes.contains(srcFrame + associateFrameOffset))
                        continue;

                    rasterChan->insertKeyframe(intendedSceneFrameTime + associateFrameOffset,
                                               originalKeyframes.value(srcFrame + associateFrameOffset));
                }

                intendedSceneFrameTime += data(sceneIndex, TotalSceneDurationInFrames).toInt();
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const FlattenedNode &item : nodes) {
                KisNodeSP node = item.node;

                PSDLayerRecord *layerRecord = new PSDLayerRecord(m_header);
                layers.append(layerRecord);

                const bool nodeVisible = node->visible();
                const KoColorSpace *colorSpace = node->colorSpace();
                const quint8 nodeOpacity = node->opacity();
                const quint8 nodeClipping = 0;
                const int nodeLabelColor = node->colorLabelIndex();
                const KisPaintLayer *paintLayer = qobject_cast<KisPaintLayer *>(node.data());
                const bool alphaLocked = (paintLayer && paintLayer->alphaLocked());
                const QString nodeCompositeOp = node->compositeOpId();

                const KisGroupLayer *groupLayer = qobject_cast<KisGroupLayer *>(node.data());
                const bool nodeIsPassThrough = groupLayer && groupLayer->passThroughMode();

                QDomDocument stylesXmlDoc = fetchLayerStyleXmlData(node);

                if (mergedPatternsXmlDoc.isNull() && !stylesXmlDoc.isNull()) {
                    mergedPatternsXmlDoc = stylesXmlDoc;
                } else if (!mergedPatternsXmlDoc.isNull() && !stylesXmlDoc.isNull()) {
                    mergePatternsXMLSection(stylesXmlDoc, mergedPatternsXmlDoc);
                }

                bool nodeIrrelevant = false;
                QString nodeName;
                KisPaintDeviceSP layerContentDevice;
                psd_section_type sectionType;

                if (item.type == FlattenedNode::RASTER_LAYER) {
                    nodeIrrelevant = false;
                    nodeName = node->name();
                    layerContentDevice = node->projection();
                    sectionType = psd_other;
                } else {
                    nodeIrrelevant = true;
                    nodeName = item.type == FlattenedNode::SECTION_DIVIDER ? QString("</Layer group>") : node->name();
                    layerContentDevice = 0;
                    sectionType = item.type == FlattenedNode::SECTION_DIVIDER ? psd_bounding_divider
                        : item.type == FlattenedNode::FOLDER_OPEN             ? psd_open_folder
                                                                              : psd_closed_folder;
                }

                // === no access to node anymore

                QRect layerRect;

                if (layerContentDevice) {
                    QRect rc = layerContentDevice->exactBounds();
                    rc = rc.normalized();

                    // keep to the max of photoshop's capabilities
                    // XXX: update this to PSB
                    if (rc.width() > 30000)
                        rc.setWidth(30000);
                    if (rc.height() > 30000)
                        rc.setHeight(30000);

                    layerRect = rc;
                }

                layerRecord->top = layerRect.y();
                layerRecord->left = layerRect.x();
                layerRecord->bottom = layerRect.y() + layerRect.height();
                layerRecord->right = layerRect.x() + layerRect.width();

                // colors + alpha channel
                // note: transparency mask not included
                layerRecord->nChannels = static_cast<quint16>(colorSpace->colorChannelCount() + 1);

                ChannelInfo *info = new ChannelInfo;
                info->channelId = -1; // For the alpha channel, which we always have in Krita, and should be saved first in
                layerRecord->channelInfoRecords << info;

                // the rest is in display order: rgb, cmyk, lab...
                for (quint32 i = 0; i < colorSpace->colorChannelCount(); ++i) {
                    info = new ChannelInfo;
                    info->channelId = static_cast<qint16>(i); // 0 for red, 1 = green, etc
                    layerRecord->channelInfoRecords << info;
                }

                layerRecord->blendModeKey = composite_op_to_psd_blendmode(nodeCompositeOp);
                layerRecord->isPassThrough = nodeIsPassThrough;
                layerRecord->opacity = nodeOpacity;
                layerRecord->clipping = nodeClipping;

                layerRecord->transparencyProtected = alphaLocked;
                layerRecord->visible = nodeVisible;
                layerRecord->irrelevant = nodeIrrelevant;
                layerRecord->labelColor = nodeLabelColor;

                layerRecord->layerName = nodeName.isEmpty() ? i18n("Unnamed Layer") : nodeName;

                layerRecord->write(io, layerContentDevice, nullptr, QRect(), sectionType, stylesXmlDoc, node->inherits("KisGroupLayer"));
            }
```

#### LAMBDA EXPRESSION 


```{c}
[color] (KoShapeStrokeSP stroke) {
                stroke->setLineBrush(Qt::NoBrush);
                stroke->setColor(color.isValid() ? color : Qt::transparent);

            }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto memorySegment : p->m_sharedMemorySegments) {
        dbgPlugins << "detaching" << (quintptr)memorySegment.data();
        memorySegment.clear();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (cmsFloat32Number value : inputValues) {
        cmsFloat32Number cValue = value;

        /*
         * Logarithmic 100
         * for Lc between 1 and 0.01:
         *  V = 1.0 + Log10( Lc ) ÷ 2
         * for Lc below 0.01:
         *  V = 0.0
         */

        if (value > 0.01){
            cValue = 1.0+log10(value) *.5 ;
        } else{
            cValue = 0.0;
        }

        /*
        double lValue = powf(10.0, (cValue - 1.0) * 2 );
        if (cValue == 0) {
            lValue = 0;
        }
        */
        cmsFloat32Number lValue = cmsEvalToneCurveFloat(curve, cValue);

        if (value > cmsFloat32Number(0.01)) {
            QVERIFY2(fabs(lValue - value) < 0.000001, QString("Values don't match for log 100: %1 %2").arg(value).arg(lValue).toLatin1());
        }
    }
```

#### AUTO 


```{c}
auto checkUnmultipliedColorsConsistent = [this](const T *d) {
                        const T alpha = std::abs(d[3]);

                        if (alpha >= static_cast<T>(0.01)) {
                            return true;
                        } else {
                            for (size_t i = 0; i < this->nbColorsSamples(); i++) {
                                if (!qFuzzyCompare(T(d[i] * alpha), d[i])) {
                                    return false;
                                }
                            }
                            return true;
                        }
                    };
```

#### AUTO 


```{c}
auto prioritizeCache = [this](){
        if (m_d->image) {
            const int currentFrame = m_d->image->animationInterface()->currentUITime();
            if(!isFrameCached(currentFrame)) {
                KisPart::instance()->prioritizeFrameForCache(m_d->image, currentFrame);
            }
        }
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &transactionPtr : m_d->overlayTransactions) {
        // the transactions are assigned as children to m_d->changeOverlayCommand
        (void) transactionPtr->endAndTake();
    }
```

#### AUTO 


```{c}
auto it = moveMap.begin();
```

#### LAMBDA EXPRESSION 


```{c}
[this, shared, progress](){
            // Switch time if necessary..
            if (shared->shouldSwitchTime()) {
                runAndSaveCommand( toQShared( new KisLayerUtils::SwitchFrameCommand(shared->image(), shared->frameTime(), false, shared->storage()) )
                                   , KisStrokeJobData::BARRIER, KisStrokeJobData::NORMAL);
            }

            // Copy snapshot of targetDevice for filter processing..
            shared->filterDevice = new KisPaintDevice(*shared->targetDevice());

            // Update all necessary rect data based on contents of frame..
            shared->filterDeviceBounds = shared->filterDevice->exactBounds();

            if (shared->filter()->needsTransparentPixels(shared->filterConfig().data(), shared->targetDevice()->colorSpace())) {
                shared->filterDeviceBounds |= shared->targetDevice()->defaultBounds()->bounds();
            }

            shared->processRect = shared->filter()->changedRect(shared->filterDeviceBounds, shared->filterConfig(), shared->levelOfDetail());
            shared->processRect &= shared->targetDevice()->defaultBounds()->bounds();

            //If we're dealing with some kind of transparency mask, we will create a compositionSourceDevice instead.
            //  Carry over from commit ca810f85 ...
            if (shared->selection() ||
                    (shared->targetDevice()->colorSpace() != shared->targetDevice()->compositionSourceColorSpace() &&
                    *shared->targetDevice()->colorSpace() != *shared->targetDevice()->compositionSourceColorSpace())) {

                shared->filterDevice = shared->targetDevice()->createCompositionSourceDevice(shared->targetDevice());

                if (shared->selection()) {
                    shared->filterDeviceBounds &= shared->selection()->selectedRect();
                }
            }

            // Filter device needs a transaction to prevent grid-patch artifcacts from multithreaded read/write.
            shared->filterDeviceTransaction.reset(new KisTransaction(shared->filterDevice));


            // Actually process the device

            QVector<KisRunnableStrokeJobData*> processJobs;

            if (shared->filter()->supportsThreading()) {
                // Split stroke into patches...
                QSize size = KritaUtils::optimalPatchSize();
                QVector<QRect> patches = KritaUtils::splitRectIntoPatches(shared->processRect, size);

                Q_FOREACH (const QRect &patch, patches) {
                    addJobConcurrent(processJobs, [patch, shared, progress](){
                        shared->filter()->processImpl(shared->filterDevice, patch,
                                                      shared->filterConfig().data(),
                                                      progress->updater());
                    });
                }
            } else {
                addJobSequential(processJobs, [shared, progress](){
                    shared->filter()->processImpl(shared->filterDevice, shared->processRect,
                                             shared->filterConfig().data(),
                                             progress->updater());
                });
            }

            runnableJobsInterface()->addRunnableJobs(processJobs);

        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto wdg : controls->findChildren<QCheckBox *>(QString(), Qt::FindDirectChildrenOnly)) {
            wdg->setCheckState(Qt::Unchecked);
            wdg->setVisible(false);
        }
```

#### AUTO 


```{c}
auto fileNameOrPlaceholder =
    [this] () {
        return !m_filename.isEmpty() ? m_filename : i18nc("placeholder test for a warning when not file is set in the file layer", "<No file name is set>");
    };
```

#### LAMBDA EXPRESSION 


```{c}
[&](const uint8_t *img, int stride, int x, int y, int ch) {
                uint16_t source = reinterpret_cast<const uint16_t *>(img)[y * (stride / 2) + (x * channels) + ch];
                if (luma == 10) {
                    return linearizeValueAsNeeded(float(0x03ff & (source)) * multiplier10bit, linearizePolicy);
                } else if (luma == 12) {
                    return linearizeValueAsNeeded(float(0x0fff & (source)) * multiplier12bit, linearizePolicy);
                } else {
                    return linearizeValueAsNeeded(float(source) * multiplier16bit, linearizePolicy);
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for(KoShape* sh: rhs->koShapes()) {
        newShapes.append(sh->cloneShape());
    }
```

#### AUTO 


```{c}
auto it = m_symbols.begin();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &node : *nodes) {
         if (node && node->paintDevice()) {
            KisSelectionSP selection = p->m_viewManager->image()->globalSelection();

            QRect cropRect = [&]() {
                if (selection) {
                    return selection->selectedExactRect();
                } else {
                    return node->exactBounds();
                }
            }();

            dbgPlugins << "Converting node" << node->name() << cropRect;

            const QRectF mappedRect = KisAlgebra2D::mapToRect(cropRect).mapRect(rc);
            const QRect resultRect = mappedRect.toAlignedRect();

            QString noParenthesisName(node->name());
            noParenthesisName.replace(QChar('('), QChar(21)).replace(QChar(')'), QChar(22));

            const auto translatedMode = KisQmicSimpleConvertor::blendingModeToString(node->compositeOpId());

            const QString name = QString("mode(%1),opacity(%2),pos(%3,%4),name(%5)")
                               .arg(translatedMode)
                               .arg(node->percentOpacity())
                               .arg(cropRect.x())
                               .arg(cropRect.y())
                               .arg(noParenthesisName);

            auto m = KisQMicImageSP::create(name, resultRect.width(), resultRect.height(), 4);
            p->m_sharedMemorySegments << m;

            {
                QMutexLocker lock(&m->m_mutex);

                gmic_image<float> img;
                img.assign(static_cast<unsigned int>(resultRect.width()),
                           static_cast<unsigned int>(resultRect.height()),
                           1,
                           4);

                img._data = m->m_data;
                img._is_shared = true;

                KisQmicSimpleConvertor::convertToGmicImageFast(
                    node->paintDevice(),
                    img,
                    resultRect);
            }

            message << m;
        }
    }
```

#### AUTO 


```{c}
auto source = resourcesInterface->source<ResourceType>(m_type);
```

#### AUTO 


```{c}
auto modifyShapesStrokes(QList<KoShape*> shapes, ModifyFunction modifyFunction)
        -> decltype(modifyFunction(KoShapeStrokeSP()), (KUndo2Command*)(0))
    {
        if (shapes.isEmpty()) return 0;

        QList<KoShapeStrokeModelSP> newStrokes;

        Q_FOREACH(KoShape *shape, shapes) {
            KoShapeStrokeSP shapeStroke = shape->stroke() ?
                qSharedPointerDynamicCast<KoShapeStroke>(shape->stroke()) :
                KoShapeStrokeSP();

            KoShapeStrokeSP newStroke =
                toQShared(shapeStroke ?
                              new KoShapeStroke(*shapeStroke) :
                              new KoShapeStroke());

            modifyFunction(newStroke);

            newStrokes << newStroke;
        }

        return new KoShapeStrokeCommand(shapes, newStrokes);
}
```

#### AUTO 


```{c}
auto newPos = forest.move(it3, it9);
```

#### LAMBDA EXPRESSION 


```{c}
[this, previousLevelsCurves]()
        {
            // We mantain a pointer to the active levels info in m_levelsCurves
            // so we use this loop instead of the asignment operator to avoid
            // invalidation of the pointer
            for (int i = 0; i < m_levelsCurves.size(); ++i) {
                m_levelsCurves[i] = previousLevelsCurves[i];
            }
            updateWidgets();
            emit sigConfigurationUpdated();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[sharedState, sharedWriteLock, dst, undoAdapter, transactionText, timedID] () {
            Q_UNUSED(sharedWriteLock); // just a RAII holder object for the lock

            /**
             * Scratchpad may not have an undo adapter
             */
             if (undoAdapter) {
                 sharedState->transaction.reset(
                     new KisTransaction(transactionText, dst, nullptr, timedID));
             }
        }
```

#### AUTO 


```{c}
auto image = std::make_shared<KisImageInterface>(this->viewManager().data());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &path: paths) {
        m_array[path.row][path.col]->modifyCorner(path.segmentType, delta);
    }
```

#### AUTO 


```{c}
const auto it = m_columns.begin() + leftColumn;
```

#### LAMBDA EXPRESSION 


```{c}
[] (quint8 value) {
                    return value > 0 ? 255 : value;
                }
```

#### AUTO 


```{c}
const auto suffix = fileInfo.suffix();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto i : times) {
                frameHeader->duration = [&]() {
                    const auto nextKeyframe = frames->nextKeyframeTime(i);
                    if (nextKeyframe == -1) {
                        return static_cast<uint32_t>(
                            image->animationInterface()->fullClipRange().end()
                            - i + 1);
                    } else {
                        return static_cast<uint32_t>(frames->nextKeyframeTime(i) - i);
                    }
                }();
                frameHeader->is_last = 0;

                if (JxlEncoderSetFrameHeader(frameSettings, frameHeader.get()) != JXL_ENC_SUCCESS) {
                    errFile << "JxlEncoderSetFrameHeader failed";
                    return ImportExportCodes::InternalError;
                }

                QByteArray pixels{[&]() {
                    const auto frameData = frames->keyframeAt<KisRasterKeyframe>(i);
                    KisPaintDeviceSP dev =
                        new KisPaintDevice(*image->projection(), KritaUtils::DeviceCopyMode::CopySnapshot);
                    frameData->writeFrameToDevice(dev);
                    QByteArray p(static_cast<int>(cs->pixelSize()) * bounds.width() * bounds.height(), 0x0);
                    dev->readBytes(reinterpret_cast<quint8 *>(p.data()), image->bounds());
                    return p;
                }()};

                // BGRA -> RGBA
                if (cs->colorModelId() == RGBAColorModelID
                    && (cs->colorDepthId() == Integer8BitsColorDepthID
                        || cs->colorDepthId() == Integer16BitsColorDepthID)) {
                    swapRgb(cs, pixels);
                }

                if (JxlEncoderAddImageFrame(frameSettings,
                                            &pixelFormat,
                                            pixels.data(),
                                            static_cast<size_t>(pixels.size()))
                    != JXL_ENC_SUCCESS) {
                    errFile << "JxlEncoderAddImageFrame @" << i << "failed";
                    return ImportExportCodes::InternalError;
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    DeformOption option;
                    option.readOptionSetting(prop->settings().data());
                    prop->setValue(option.deform_amount);
                }
```

#### AUTO 


```{c}
const auto b = batch<T, A>::load(srcPtr + batch<T, A>::size, U{});
```

#### RANGE FOR STATEMENT 


```{c}
for (Payload& p : m_queue) {
            delete[] p.m_data;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Column &c : m_colorMatrix) {
        int row = 0;
        for (const KisSwatch &s : c.values()) {
            SwatchInfo i = {m_name, s, c.keys()[row++], column};
            res.append(i);
        }
        column++;
    }
```

#### AUTO 


```{c}
ORDER_BY(lhs.rendererId() == m_preferredRendererByUser,
                     rhs.rendererId() == m_preferredRendererByUser)
```

#### AUTO 


```{c}
auto newEnd = std::remove_if(container.begin(), container.end(), std::unary_negate<decltype(keepIf)>(keepIf));
```

#### LAMBDA EXPRESSION 


```{c}
[image, frames] () {
                bool result = false;

                QScopedPointer<KUndo2Command> cmd(new KUndo2Command());

                Q_FOREACH (const FrameItem &item, frames) {
                    const int time = item.time;
                    KisNodeSP node = item.node;
                    KisKeyframeChannel *channel = 0;
                    if (node) {
                        channel = node->getKeyframeChannel(item.channel);
                    }
                    if (!channel) continue;

                    KisKeyframeSP keyframe = channel->keyframeAt(time);
                    if (!keyframe) continue;

                    channel->deleteKeyframe(keyframe, cmd.data());

                    result = true;
                }

                return result ? new KisCommandUtils::SkipFirstRedoWrapper(cmd.take()) : 0;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[cs, op, srcPtr, dstPtr, numTestablePixels] (int badPixelPos,
            const quint8 *goodSrc,
            const quint8 *goodDst,
            const quint8 *badSrc,
            const quint8 *badDst,
            quint8 opacity,
            quint8 *expectedDst) {

        quint8 *badPixelDstPtr = dstPtr + badPixelPos * cs->pixelSize();

        for (int i = 0; i < numTestablePixels; i++) {
            if (i != badPixelPos) {
                memcpy(srcPtr + cs->pixelSize() * i, goodSrc, cs->pixelSize());
                memcpy(dstPtr + cs->pixelSize() * i, goodDst, cs->pixelSize());
            } else {
                memcpy(srcPtr + cs->pixelSize() * i, badSrc, cs->pixelSize());
                memcpy(dstPtr + cs->pixelSize() * i, badDst, cs->pixelSize());
            }
        }

        op->composite(dstPtr, numTestablePixels * cs->pixelSize(),
                      srcPtr, numTestablePixels * cs->pixelSize(),
                      0, 0,
                      1, numTestablePixels, opacity);

        if (memcmp(badPixelDstPtr, expectedDst, cs->pixelSize()) != 0) {
            qDebug() << "badPixelPos" << badPixelPos;
            qDebug() << "opacity" << opacity;
            qDebug() << "oriS" << badSrc[0] << badSrc[1] << badSrc[2] << badSrc[3];
            qDebug() << "oriD" << badDst[0] << badDst[1] << badDst[2] << badDst[3];
            qDebug() << "expD" << expectedDst[0] << expectedDst[1] << expectedDst[2] << expectedDst[3];
            qDebug() << "dst1" << badPixelDstPtr[0] << badPixelDstPtr[1] << badPixelDstPtr[2] << badPixelDstPtr[3];
#if HAVE_VC
            QFAIL("Failed to compose pixels");
#else
            qWarning() << "Skipping failed test when Vc library is not used";
#endif
        }
    }
```

#### AUTO 


```{c}
auto it = schemeEntries.constBegin();
```

#### LAMBDA EXPRESSION 


```{c}
[color] (const KeyStroke &s) {
                         return s.color == color;
                     }
```

#### AUTO 


```{c}
const auto tileRowStride =
                (static_cast<size_t>(tileWidth) - columnsToWork) * dstPixelSize;
```

#### AUTO 


```{c}
auto hoveredProperty = d->propForMousePos(index, helpEvent->pos(), option);
```

#### RANGE FOR STATEMENT 


```{c}
for (KisHalftoneConfigPageWidget *configPageWidget : m_channelWidgets) {
        if (configPageWidget) {
            configPageWidget->setView(view);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        QMutexLocker l(&m_d->dirtyRectsMutex);

        m_d->updatesFacade->enableDirtyRequests();
        m_d->updatesDisabled = false;

        m_d->updateTimer.start();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& patch: row) {
            patch->setTransform(matrix);
        }
```

#### AUTO 


```{c}
auto value =
                [&](const uint8_t *img, int stride, int x, int y) {
                    if (luma == 8) {
                        return linearizeValueAsNeeded(float(img[y * (stride) + x]) / 255.0f, linearizePolicy);
                    } else {
                        uint16_t source = reinterpret_cast<const uint16_t *>(img)[y * (stride / 2) + x];
                        if (luma == 10) {
                            return linearizeValueAsNeeded(float(0x03ff & (source)) * multiplier10bit, linearizePolicy);
                        } else if (luma == 12) {
                            return linearizeValueAsNeeded(float(0x0fff & (source)) * multiplier12bit, linearizePolicy);
                        } else {
                            return linearizeValueAsNeeded(float(source) * multiplier16bit, linearizePolicy);
                        }
                    }
                };
```

#### AUTO 


```{c}
auto newParentIt = parentIt;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto collection : actionCollections) {

        if (collection->componentName().contains("disposable")) {
            m_disposableActionCollections << collection;
        }

        const QList<QAction *> collectionActions = collection->actions();
        const QString componentName = collection->componentDisplayName();
        for (const auto action : collectionActions) {
            // sanity + empty check ensures displayable actions and removes ourself
            // from the action list
            if (action && action->isEnabled() && !action->text().isEmpty()) {
                actionList.append({componentName, action});
            }
        }
    }
```

#### AUTO 


```{c}
auto *layoutManager = KisWindowLayoutManager::instance();
```

#### LAMBDA EXPRESSION 


```{c}
[this] (KoShapeStrokeSP stroke) {
        stroke->setLineWidth(lineWidth());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KoColorProfile* profile : d->profileMap) {
        bool colorantMatch = (colorants.isEmpty() || colorantType != PRIMARIES_UNSPECIFIED);
        bool colorantTypeMatch = (colorantType == PRIMARIES_UNSPECIFIED);
        bool transferMatch = (transferType == 2);
        if (colorantType != PRIMARIES_UNSPECIFIED) {
            if (int(profile->getColorPrimaries()) == colorantType) {
                colorantTypeMatch = true;
            }
        }
        if (transferType != TRC_UNSPECIFIED) {
            if (int(profile->getTransferCharacteristics()) == transferType) {
                transferMatch = true;
            }
        }

        if (!colorants.isEmpty() && colorantType == PRIMARIES_UNSPECIFIED) {
            QVector<qreal> wp = profile->getWhitePointxyY();
            if (profile->hasColorants() && colorants.size() == 8) {
                QVector<qreal> col = profile->getColorantsxyY();
                if (col.size() < 8 || wp.size() < 2) {
                    // too few colorants, skip.
                    continue;
                }
                QVector<double> compare = {wp[0], wp[1], col[0], col[1], col[3], col[4], col[6], col[7]};

                for (int i = 0; i < compare.size(); i++) {
                    colorantMatch = std::fabs(compare[i] - colorants[i]) < error;
                    if (!colorantMatch) {
                        break;
                    }
                }
            } else {
                if (wp.size() < 2 || colorants.size() < 2) {
                    // too few colorants, skip.
                    continue;
                }
                if (std::fabs(wp[0] - colorants[0]) < error && std::fabs(wp[1] - colorants[1]) < error) {
                    colorantMatch = true;
                }
            }
        }

        if (transferMatch && colorantMatch && colorantTypeMatch) {
            profiles.push_back(profile);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[srcFrames, dstFrames, copy] () -> KUndo2Command* {
                bool result = false;

                QScopedPointer<KUndo2Command> cmd(new KUndo2Command());

                for (int i = 0; i < srcFrames.size(); i++) {
                    const int srcTime = srcFrames[i].time;
                    KisNodeSP srcNode = srcFrames[i].node;
                    KisKeyframeChannel *srcChannel = srcNode->getKeyframeChannel(srcFrames[i].channel);

                    const int dstTime = dstFrames[i].time;
                    KisNodeSP dstNode = dstFrames[i].node;
                    KisKeyframeChannel *dstChannel = dstNode->getKeyframeChannel(dstFrames[i].channel, true);

                    if (srcNode == dstNode) {
                        if (!srcChannel) continue;

                        KisKeyframeSP srcKeyframe = srcChannel->keyframeAt(srcTime);
                        if (srcKeyframe) {
                            if (copy) {
                                srcChannel->copyKeyframe(srcKeyframe, dstTime, cmd.data());
                            } else {
                                srcChannel->moveKeyframe(srcKeyframe, dstTime, cmd.data());
                            }
                        }
                    } else {
                        if (!srcChannel|| !dstChannel) continue;

                        KisKeyframeSP srcKeyframe = srcChannel->keyframeAt(srcTime);
                        if (!srcKeyframe) continue;

                        dstChannel->copyExternalKeyframe(srcChannel, srcTime, dstTime, cmd.data());

                        if (!copy) {
                            srcChannel->deleteKeyframe(srcKeyframe, cmd.data());
                        }
                    }

                    result = true;
                }

                return result ? new KisCommandUtils::SkipFirstRedoWrapper(cmd.take()) : 0;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[] (const QPointF &pt) {
                return pt.y();
            }
```

#### AUTO 


```{c}
auto menuAction
```

#### AUTO 


```{c}
auto insertedIt = m_rows.insert(next(it), absProportionalT);
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {
                return filterManager->isIdle();
            }
```

#### AUTO 


```{c}
const auto *layer = dynamic_cast<const KisLayer *>(node.data());
```

#### LAMBDA EXPRESSION 


```{c}
[&nodesList, refImage, this] (KisNodeSP node) mutable {
        if (acceptNode(node)) {
            KisNodeSP copy = node->clone();

            if (copy.isNull()) {
                return;
            }

            if (node->inherits("KisLayer")) {
                KisLayer* layerCopy = dynamic_cast<KisLayer*>(copy.data());
                layerCopy->setChannelFlags(QBitArray());
            }

            copy->setCompositeOpId(COMPOSITE_OVER);

            bool success = refImage->addNode(copy, refImage->root());

            if (!success) {
                return;
            }
            nodesList << copy;
        }

    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &type: resourceTypes) {
            res = modelsPerResourceType[type]->resourceForId(id);
            if (!res.isNull()) {
                resModel = modelsPerResourceType[type];
                resourceTypeHere = type;
                break;
            }
        }
```

#### AUTO 


```{c}
auto collection = c->actionCollection()
```

#### AUTO 


```{c}
auto it = jobs.begin();
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    HatchingOption option;
                    option.readOptionSetting(prop->settings().data());
                    option.angle = prop->value().toReal();
                    option.writeOptionSetting(prop->settings().data());
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &node : *nodes) {
         if (node && node->paintDevice()) {
            QRect cropRect;

            KisSelectionSP selection = p->m_viewManager->image()->globalSelection();

            if (selection) {
                cropRect = selection->selectedExactRect();
            } else {
                cropRect = node->exactBounds();
            }

            dbgPlugins << "Converting node" << node->name() << cropRect;

            const QRectF mappedRect = KisAlgebra2D::mapToRect(cropRect).mapRect(rc);
            const QRect resultRect = mappedRect.toAlignedRect();

            QString noParenthesisName(node->name());
            noParenthesisName.replace(QChar('('), QChar(21)).replace(QChar(')'), QChar(22));

            const auto translatedMode = KisQmicSimpleConvertor::blendingModeToString(node->compositeOpId());

            const QString name = QString("mode(%1),opacity(%2),pos(%3,%4),name(%5)")
                               .arg(translatedMode)
                               .arg(node->percentOpacity())
                               .arg(cropRect.x())
                               .arg(cropRect.y())
                               .arg(noParenthesisName);

            auto m = KisQMicImageSP::create(name, resultRect.width(), resultRect.height(), 4);
            p->m_sharedMemorySegments << m;

            {
                QMutexLocker lock(&m->m_mutex);

                gmic_image<float> img;
                img.assign(resultRect.width(), resultRect.height(), 1, 4);

                img._data = m->m_data;
                img._is_shared = true;

                KisQmicSimpleConvertor::convertToGmicImageFast(node->paintDevice(), &img, resultRect);
            }

            message << m;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        Q_FOREACH(KisNodeSP node, m_nodes) {
            KisLayerUtils::forceAllHiddenOriginalsUpdate(node);
        }
    }
```

#### AUTO 


```{c}
auto it = std::make_reverse_iterator(commands.end());
```

#### AUTO 


```{c}
auto layer = qobject_cast<KisPaintLayer*>(node.data());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &word : errorWords) {
            if (line.contains(word)) {
                errorMessage += line % "\n";
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(KoShape* sh: rhs.koShapes()) {
        newShapes.append(sh->cloneShape());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &line : stdoutLines) {
        dbgFile << "ffmpeg probe stdout" << line;
       QRegularExpression videoInfoInputRX("Duration: (\\d+):(\\d+):([\\d\\.]+),");
    
        QRegularExpressionMatch durationMatch = videoInfoInputRX.match(line);
        if (ffmpegFormatJsonObj.value("duration").isUndefined() && durationMatch.hasMatch()) {
            ffmpegFormatJsonObj["duration"] = QString::number( (durationMatch.captured(1).toInt() * 60 * 60)
                                                             + (durationMatch.captured(2).toInt() * 60) 
                                                             + durationMatch.captured(3).toFloat()
                                                             );
        } else {
            QRegularExpression videoInfoStreamRX(
                QString("Stream #(\\d+):(\\d+)(?:[ ]*?\\((\\w+)\\)|): Video: (\\w+?)(?:[ ]*?\\((.+?)\\)|),[ ]*?")
                        .append("(\\w+?)(?:[ ]*?\\((.+?)\\)|),[ ]*?")
                        .append("(\\d+)x(\\d+)([ ]*?\\[.+?\\]|.*?),[ ]*?")
                        .append("([\\d\\.]+) fps, (.+?) tbr, (.+?) tbn, (.+?) tbc")
            );
            
            QRegularExpressionMatch streamMatch = videoInfoStreamRX.match(line);
            
            if (streamMatch.hasMatch() && ffmpegStreamsJsonArr[streamMatch.captured(1).toInt()].isUndefined() ) {
                int index = streamMatch.captured(1).toInt();
                QJsonObject ffmpegJsonOnStreamObj;
                
                ffmpegJsonOnStreamObj["index"] = index;
                ffmpegJsonOnStreamObj["codec_name"] = streamMatch.captured(4);
                ffmpegJsonOnStreamObj["profile"] = streamMatch.captured(5);
                ffmpegJsonOnStreamObj["pix_fmt"] = streamMatch.captured(6);
                ffmpegJsonOnStreamObj["width"] = streamMatch.captured(8).toInt();
                ffmpegJsonOnStreamObj["height"] = streamMatch.captured(9).toInt();
                
                ffmpegJsonOnStreamObj["codec_type"] = "video";
                
                if (streamMatch.captured(11).toFloat() > 0)
                    ffmpegJsonOnStreamObj["r_frame_rate"] = QString::number(streamMatch.captured(11).toFloat() * 10000).append(QString("/10000"));

                ffmpegJsonObj["error"] = 0;
                
                dbgFile << "ffmpegProbe stream:" << ffmpegJsonOnStreamObj;
                
                ffmpegStreamsJsonArr.insert(index, ffmpegJsonOnStreamObj);
                
            } else {
                
                QRegularExpression videoInfoFrameRX("^(\\w+?)=([\\w\\./:]+?)$");
                QRegularExpressionMatch frameMatch = videoInfoFrameRX.match(line);

                if (frameMatch.hasMatch()) ffmpegProgressJsonObj[frameMatch.captured(1)] = frameMatch.captured(2);
    
            }
        }
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr int showControlsTimerDuration{500};
```

#### CONST EXPRESSION 


```{c}
static constexpr int NumberOfBuffers = 2;
```

#### RANGE FOR STATEMENT 


```{c}
for (KisSwatchGroup &g : d->groups.values()) {
        g.setColumnCount(columns);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](int value)
        {
            KisSignalsBlocker blocker(m_page.thresholdGradient);
            m_page.thresholdGradient->setThreshold(static_cast<qreal>(value) / 255.0);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &i: openGLCheckResult->extensions()) {
            debugOut << "\n    " << QString::fromLatin1(i);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    ExperimentOption option;
                    option.readOptionSetting(prop->settings().data());

                    prop->setValue(int(option.speed));
                }
```

#### AUTO 


```{c}
auto getChildContent_i18n = [=](QString node){return quietlyTranslate(getChildContent(node));};
```

#### AUTO 


```{c}
auto row = index.row();
```

#### AUTO 


```{c}
auto parentIt = d->oldParents.begin();
```

#### AUTO 


```{c}
auto &w
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            Q_FOREACH (KisTransformMask *mask, m_d->transformMaskCacheHash.keys()) {
                mask->overrideStaticCacheDevice(0);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QString key : m_metadata.keys()) {

        QDomElement e = doc.createElement("metadata");
        e.setAttribute("name", QString(key.toLatin1()));
        QVariant v = m_metadata.value(key);
        e.setAttribute("type", v.typeName());

        QString attrName = "value";
        if(v.type() == QVariant::String ) {
            e.setAttribute(attrName, v.toString());
            e.setAttribute("type", "string");
        } else if(v.type() == QVariant::Int ) {
            e.setAttribute(attrName, v.toInt());
        } else if(v.type() == QVariant::Double ) {
            e.setAttribute(attrName, v.toDouble());
        } else  if(v.type() == QVariant::Bool ) {
            e.setAttribute(attrName, v.toBool());
        } else {
            qWarning() << "no KoColor serialization for QVariant type:" << v.type();
        }
        colorElt.appendChild(e);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            changeLayoutDir(Qt::RightToLeft);
        }
```

#### AUTO 


```{c}
auto *layout = new QHBoxLayout(widget);
```

#### LAMBDA EXPRESSION 


```{c}
[sharedData] () mutable {
        auto it = sharedData->begin();
        auto end = sharedData->end();

        for (; it != end; ++it) {
            KisPaintDeviceSP dev = it.key();
            dev->uploadLodDataStruct(it.value().data());
        }
    }
```

#### AUTO 


```{c}
const auto profile = image->profile()->rawData();
```

#### LAMBDA EXPRESSION 


```{c}
[&](int i) {
        if (i >= d->m_nodes->size()) {
            return d->m_newNodes->at(i - d->m_nodes->size());
        } else {
            return d->m_nodes->at(i);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[index, pModel] {pModel->insertItem(index, false); }
```

#### AUTO 


```{c}
auto addCanvasResources = [&result] (KoAbstractGradientSP gradient) {
        if (gradient) {
            result << gradient->requiredCanvasResources();
        }
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (QRect &rect: m_snapRects) {
                QPainterPath circle;
                circle.addEllipse(rect);
                if (circle.contains(point)) {
                    m_snapRotation = true;
                    m_rotationSnapAngle = i * 15;
                    break;
                }
                i++;
            }
```

#### AUTO 


```{c}
auto it = m_objects.begin();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        m_q->saveEntries(KSharedConfig::openConfig()->group("RecentFiles"));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, dialog]()
                          {
                              KoColor c;
                              c.fromQColor(dialog->currentColor());
                              q->setColor(c);
                          }
```

#### LAMBDA EXPRESSION 


```{c}
[&](QTabletEvent::Type t){
            handleTabletEvent(w, localPosDip, globalPosDip, currentDevice, currentPointerType,
                               button, buttons, pressureNew, tiltX, tiltY, tangentialPressure, rotation, z,
                               m_devices.at(m_currentDevice).uniqueId, keyboardModifiers, t);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() { m_this->restoreWorkspace(ds); }
```

#### LAMBDA EXPRESSION 


```{c}
[updatesFacade, batchUpdateStarted] () {
        updatesFacade->notifyBatchUpdateEnded();
        *batchUpdateStarted = false;
    }
```

#### AUTO 


```{c}
auto resourceSourceAdapter = resourcesInterface->source<KoPattern>(ResourceType::Patterns);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        QRect handlesRect;

        Q_FOREACH(KisNodeSP node, m_nodes) {
            saveInitialNodeOffsets(node);
            handlesRect |= KisLayerUtils::recursiveTightNodeVisibleBounds(node);
        }

        KisStrokeStrategyUndoCommandBased::initStrokeCallback();

        if (m_updatesEnabled) {
            KisLodTransform t(m_nodes.first()->image()->currentLevelOfDetail());
            handlesRect = t.mapInverted(handlesRect);

            emit this->sigHandlesRectCalculated(handlesRect);
        }

        m_updateTimer.start();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KisHalftoneConfigPageWidget *configPageWidget : m_channelWidgets) {
        if (configPageWidget) {
            configPageWidget->setCanvasResourcesInterface(canvasResourcesInterface);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[] (Mesh<NodeArg, PatchArg> &mesh,
                                    SegmentIterator it,
                                    const QPointF &normalizedOffset) {

            if (it == mesh.endSegments()) return;

            const QPointF base1 = it.p3() - it.p0();
            const QPointF base2 = it.p3() - it.p0() - normalizedOffset;

            {
                const QPointF control = it.p1() - it.p0();
                const qreal dist0 = KisAlgebra2D::norm(base1);
                const qreal dist1 = KisAlgebra2D::dotProduct(base2, base1) / dist0;
                const qreal coeff = dist1 / dist0;

                it.p1() = it.p0() + coeff * (control);
            }
            {
                const QPointF control = it.p2() - it.p3();
                const qreal dist0 = KisAlgebra2D::norm(base1);
                const qreal dist1 = KisAlgebra2D::dotProduct(base2, base1) / dist0;
                const qreal coeff = dist1 / dist0;

                it.p2() = it.p3() + coeff * (control);
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&resultParam,
             &resultSegment,
             &resultDistance,
             &resultRemovedNodeIndex] (const KisBezierTransformMesh::segment_iterator &segment,
                               const QPoint &removedNodeOffset,
                               const QPointF &pt,
                               KisBezierTransformMesh &mesh)
        {
            if (segment != mesh.endSegments()) {

                qreal distance = 0.0;
                qreal param = KisBezierUtils::nearestPoint({segment.p0(), segment.p1(), segment.p2(), segment.p3()}, pt, &distance);

                if (distance < resultDistance) {
                    resultDistance = distance;
                    resultParam = param;
                    resultSegment = segment;
                    resultRemovedNodeIndex = segment.firstNodeIndex() + removedNodeOffset;
                }
            }
        }
```

#### AUTO 


```{c}
const auto t1 = zip_lo(a, c);
```

#### LAMBDA EXPRESSION 


```{c}
[](const KisUniformPaintOpProperty *prop) {
                    KisSprayOptionProperties option;
                    option.readOptionSetting(prop->settings().data());
                    return option.useDensity();
                }
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    KisSmudgeOption option;
                    option.readOptionSetting(prop->settings().data());
                    option.setMode(KisSmudgeOption::Mode(prop->value().toInt()));
                    option.writeOptionSetting(prop->settings().data());
                }
```

#### AUTO 


```{c}
auto sendTabletEvent = [&](QTabletEvent::Type t){
            handleTabletEvent(w, localPosF, globalPosF, currentDevice, currentPointerType,
                              button, buttons, pressureNew, tiltX, tiltY, tangentialPressure, rotation, z,
                              m_devices.at(m_currentDevice).uniqueId, keyboardModifiers, t);
        };
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    KisCurveOptionProperties option;
                    option.readOptionSetting(prop->settings().data());

                    prop->setValue(option.curve_line_width);
                }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
            KisNodeList result;
            const auto minIndex = d->m_images.size();
            for (auto i = minIndex; i < d->m_nodes->size(); i++) {
                result.append(d->m_nodes->at(i));
            }
            return result;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, shared](){
            // We will first apply the transaction to the temporary filterDevice
            runAndSaveCommand(toQShared(shared->filterDeviceTransaction->endAndTake()), KisStrokeJobData::BARRIER, KisStrokeJobData::NORMAL);
            shared->filterDeviceTransaction.reset();

            if (!shared->filterDeviceBounds.intersects(
                    shared->filter()->neededRect(shared->processRect, shared->filterConfig().data(), shared->levelOfDetail()))) {
                return;
            }

            // Make a transaction, change the target device, and "end" transaction.
            // Should be useful for undoing later.
            QScopedPointer<KisTransaction> workingTransaction( new KisTransaction(shared->targetDevice(), AUTOKEY_DISABLED) );
            KisPainter::copyAreaOptimized(shared->processRect.topLeft(), shared->filterDevice, shared->targetDevice(), shared->processRect, shared->selection());
            runAndSaveCommand( toQShared(workingTransaction->endAndTake()), KisStrokeJobData::BARRIER, KisStrokeJobData::EXCLUSIVE );

            if (shared->shouldRedraw()) {
                QRect extraUpdateRect;
                qSwap(extraUpdateRect, m_d->nextExternalUpdateRect);

                shared->node()->setDirty(shared->processRect | extraUpdateRect);

               /**
                * Save the last update to be able to restore the
                * original state on the cancellation (even when
                * the cancellation step is explicitly prohibited)
                */
                m_d->nextExternalUpdateRect = shared->processRect;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QDomElement el: elements) {
            double compare = el.attribute(attr).toDouble();
            QVERIFY2(fabs(mainValue - compare) < 0.01
                     , QString("XML CMYK parsing has too high of a difference when roundtripping channel %1: %2")
                     .arg(attr).arg(mainValue - compare).toLatin1());
        }
```

#### AUTO 


```{c}
auto it = rhs.m_visibilityMap.constBegin();
```

#### LAMBDA EXPRESSION 


```{c}
[zIndexOffset] (KoShape *shape) {
                        KoShapeReorderCommand::IndexedShape indexedShape(shape);
                        indexedShape.zIndex += zIndexOffset;
                        return indexedShape;
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &line : stdoutLines) {
        dbgFile << "ffmpeg probe stdout" << line;
       QRegularExpression videoInfoInputRX("Duration: (\\d+):(\\d+):([\\d\\.]+),");
    
        QRegularExpressionMatch durationMatch = videoInfoInputRX.match(line);
        if (ffmpegFormatJsonObj.value("duration").isUndefined() && durationMatch.hasMatch()) {
            ffmpegFormatJsonObj["duration"] = QString::number( (durationMatch.captured(1).toInt() * 60 * 60)
                                                             + (durationMatch.captured(2).toInt() * 60) 
                                                             + durationMatch.captured(3).toFloat()
                                                             );
        } else {
            QRegularExpression videoInfoStreamRX(
                QString("Stream #(\\d+):(\\d+)(?:[ ]*?\\((\\w+)\\)|): Video: (\\w+?)(?:[ ]*?\\((.+?)\\)|),[ ]*?")
                        .append("(\\w+?)(?:[ ]*?\\((.+?)\\)|),[ ]*?")
                        .append("(\\d+)x(\\d+)([ ]*?\\[.+?\\]|.*?),[ ]*?")
                        .append("(?:([\\d\\.]+) fps,|) (\\S+?) tbr, (.+?) tbn, (.+?) tbc")
            );
            
            QRegularExpressionMatch streamMatch = videoInfoStreamRX.match(line);
            
            if (streamMatch.hasMatch() && ffmpegStreamsJsonArr[streamMatch.captured(1).toInt()].isUndefined() ) {
                int index = streamMatch.captured(1).toInt();
                QJsonObject ffmpegJsonOnStreamObj;
                
                ffmpegJsonOnStreamObj["index"] = index;
                ffmpegJsonOnStreamObj["codec_name"] = streamMatch.captured(4);
                ffmpegJsonOnStreamObj["profile"] = streamMatch.captured(5);
                ffmpegJsonOnStreamObj["pix_fmt"] = streamMatch.captured(6);
                ffmpegJsonOnStreamObj["width"] = streamMatch.captured(8).toInt();
                ffmpegJsonOnStreamObj["height"] = streamMatch.captured(9).toInt();
                
                ffmpegJsonOnStreamObj["codec_type"] = "video";
                
                if (streamMatch.captured(11).toFloat() > 0) {
                    float fps = streamMatch.captured(11).toFloat();

                    ffmpegProgressJsonObj["ffmpeg_fps"] = QString::number(fps);
                    ffmpegJsonOnStreamObj["r_frame_rate"] = QString::number( fps * 10000 ).append(QString("/10000"));
                } else {
                    ffmpegProgressJsonObj["ffmpeg_fps"] = 0;
                }

                ffmpegJsonObj["error"] = 0;
                
                dbgFile << "ffmpegProbe stream:" << ffmpegJsonOnStreamObj;
                
                ffmpegStreamsJsonArr.insert(index, ffmpegJsonOnStreamObj);
                
            } else {
                
                QRegularExpression videoInfoFrameRX("^(\\w+?)=([\\w\\./:]+?)$");
                QRegularExpressionMatch frameMatch = videoInfoFrameRX.match(line);

                if (frameMatch.hasMatch()) ffmpegProgressJsonObj[frameMatch.captured(1)] = frameMatch.captured(2);
    
            }
        }
    }
```

#### AUTO 


```{c}
const auto *rgbaFloat32bitcolorSpace =
        KoColorSpaceRegistry::instance()->colorSpace(
            RGBAColorModelID.id(),
            Float32BitsColorDepthID.id(),
            KoColorSpaceRegistry::instance()->rgb8()->profile());
```

#### AUTO 


```{c}
auto channelIndex = gmicImage.m_spectrum;
```

#### AUTO 


```{c}
auto it = mergedNodes.begin();
```

#### RANGE FOR STATEMENT 


```{c}
for (QUrl url : urls) {

                    if (!url.isLocalFile()) {
                        // download the file and substitute the url
                        KisRemoteFileFetcher fetcher;
                        tmp = new QTemporaryFile();
                        tmp->setAutoRemove(true);
                        if (!fetcher.fetchFile(url, tmp)) {
                            qWarning() << "Fetching" << url << "failed";
                            continue;
                        }
                        url = url.fromLocalFile(tmp->fileName());
                    }
                    if (url.isLocalFile()) {
                        if (action == insertAsNewLayer || action == insertManyLayers) {
                            d->viewManager->imageManager()->importImage(url);
                            activateWindow();
                        }
                        else if (action == insertAsNewFileLayer || action == insertManyFileLayers) {
                            KisNodeCommandsAdapter adapter(viewManager());
                            QFileInfo fileInfo(url.toLocalFile());
                            KisFileLayer *fileLayer = new KisFileLayer(image(), "", url.toLocalFile(),
                                                                       KisFileLayer::None, fileInfo.fileName(), OPACITY_OPAQUE_U8);
                            adapter.addNode(fileLayer, viewManager()->activeNode()->parent(), viewManager()->activeNode());
                        }
                        else if (action == openInNewDocument || action == openManyDocuments) {
                            if (mainWindow()) {
                                mainWindow()->openDocument(url, KisMainWindow::None);
                            }
                        }
                        else if (action == insertAsReferenceImage || action == insertAsReferenceImages) {
                            auto *reference = KisReferenceImage::fromFile(url.toLocalFile(), d->viewConverter, this);

                            if (reference) {
                                reference->setPosition(d->viewConverter.imageToDocument(cursorPos));
                                d->referenceImagesDecoration->addReferenceImage(reference);

                                KoToolManager::instance()->switchToolRequested("ToolReferenceImages");
                            }
                        }

                    }
                    delete tmp;
                    tmp = 0;
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { Q_UNUSED(this) }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &node : nodes) {
        KisLayerPropertiesIcons::setNodePropertyAutoUndo(node, KisLayerPropertiesIcons::locked, !isLocked, m_d->view->image());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KoResource *r : m_d->rAdapter->resources()) {
        if (r != colorSet && r->filename() == dlg.filename()) {
            QMessageBox msgFilenameDuplicate;
            msgFilenameDuplicate.setWindowTitle(i18n("Duplicate filename"));
            msgFilenameDuplicate.setText(i18n("Duplicate filename! Palette not saved."));
            msgFilenameDuplicate.exec();
            return;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        QRect handlesRect;

        Q_FOREACH(KisNodeSP node, m_nodes) {
            saveInitialNodeOffsets(node);
            handlesRect |= KisLayerUtils::recursiveTightNodeVisibleBounds(node);
        }

        KisStrokeStrategyUndoCommandBased::initStrokeCallback();

        if (m_updatesEnabled) {
            KisLodTransform t(m_nodes.first()->projection());
            handlesRect = t.mapInverted(handlesRect);

            emit this->sigHandlesRectCalculated(handlesRect);
        }

        m_updateTimer.start();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &name) {
            const QString fileName = m_context.xmlBaseDir() + QDir::separator() + name;
            QFile file(fileName);
            KIS_SAFE_ASSERT_RECOVER_RETURN_VALUE(file.exists(), QByteArray());
            file.open(QIODevice::ReadOnly);
            return file.readAll();
        }
```

#### AUTO 


```{c}
auto columnIt = newColumn.begin();
```

#### AUTO 


```{c}
auto legacyBrushApplication = [] (KisColorfulBrush *colorfulBrush, bool forceColorToAlpha) {
        /**
         * In Krita versions before 4.4 series "ColorAsMask" could
         * be overridden to false when the brush had no **color**
         * inside. That changed in Krita 4.4.x series, when
         * "brushApplication" replaced all the automatic heuristics
         */
        return (colorfulBrush && colorfulBrush->hasColorAndTransparency() && !forceColorToAlpha) ? IMAGESTAMP : ALPHAMASK;
    };
```

#### RANGE FOR STATEMENT 


```{c}
for(KoShape* sh: rhs.koShapes()) {
            newShapes.append(sh->cloneShape());
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        QString name;
        name = QInputDialog::getText(this, i18nc("@title:window", "New Workspace..."),
                                                                i18nc("@label:textbox", "Name:"));
        if (name.isEmpty()) {
            return;
        }

        KisWorkspaceResourceSP workspace(new KisWorkspaceResource(""));
        workspace->setDockerState(m_this->saveState());
        workspace->setImage(layoutThumbnail());
        workspace->setValid(true);

        // this line must happen before we save the workspace to resource folder or other places
        // because it mostly just triggers palettes to be saved into the workspace
        d->viewManager->canvasResourceProvider()->notifySavingWorkspace(workspace);
        workspace->setValid(true);

        workspace->setFilename(name + workspace->defaultFileExtension());
        workspace->setName(name);

        KisResourceUserOperations::addResourceWithUserInput(this, workspace);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        JxlPixelFormat pixelFormat{};
        if (cs->colorDepthId() == Integer8BitsColorDepthID) {
            pixelFormat.data_type = JXL_TYPE_UINT8;
        } else if (cs->colorDepthId() == Integer16BitsColorDepthID) {
            pixelFormat.data_type = JXL_TYPE_UINT16;
#ifdef HAVE_OPENEXR
        } else if (cs->colorDepthId() == Float16BitsColorDepthID) {
            pixelFormat.data_type = JXL_TYPE_FLOAT16;
#endif
        } else if (cs->colorDepthId() == Float32BitsColorDepthID) {
            pixelFormat.data_type = JXL_TYPE_FLOAT;
        }
        if (cs->colorModelId() == RGBAColorModelID) {
            pixelFormat.num_channels = 4;
        } else if (cs->colorModelId() == GrayAColorModelID) {
            pixelFormat.num_channels = 2;
        } else if (cs->colorModelId() == CMYKAColorModelID) {
            pixelFormat.num_channels = 5;
        }
        return pixelFormat;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QLineF &line: m_snapLines) {
        qreal penWidth = BORDER_WIDTH / 2;
        QPointF point1 = drawPointOnAngle(i * 15, m_popupPaletteSize / 2 - m_rotationTrackSize + penWidth);
        point1 += QPointF(m_popupPaletteSize / 2, m_popupPaletteSize / 2);
        QPointF point2 = drawPointOnAngle(i * 15, m_popupPaletteSize / 2 - BORDER_WIDTH - penWidth);
        point2 += QPointF(m_popupPaletteSize / 2, m_popupPaletteSize / 2);
        line = QLineF(point1, point2);
        i++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KisLazyFillTools::KeyStroke keystroke : mask->fetchKeyStrokesDirect()) {
        if (kc == keystroke.color) {
            KisPaintDeviceSP dev = keystroke.dev;

            if (!dev) return ba;

            ba.resize(w * h * dev->pixelSize());
            dev->readBytes(reinterpret_cast<quint8*>(ba.data()), x, y, w, h);
            return ba;
        }
    }
```

#### AUTO 


```{c}
ORDER_BY(lhs.renderableType() == m_preferredRendererByQt,
                 rhs.renderableType() == m_preferredRendererByQt)
```

#### RANGE FOR STATEMENT 


```{c}
for(KoGamutMaskShape* maskShape: d->maskShapes) {
        shapes.append(maskShape->koShape());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KoGradientSegment *segment : gradient->segments()) {
            KoGradientStop stop;
            
            stop = toKoGradientStop(segment->startColor(), segment->startType(), segment->startOffset(), canvasResourcesInterface);
            stop.color.convertTo(stopGradient->colorSpace());
            if (!qFuzzyCompare(stop.position, lastStop.position) || stop.type != lastStop.type || stop.color != lastStop.color) {
                stops << stop;
                lastStop.type = stop.type;
                lastStop.color = stop.color;
                lastStop.position = stop.position;
            }
            
            stop = toKoGradientStop(segment->endColor(), segment->endType(), segment->endOffset(), canvasResourcesInterface);
            stop.color.convertTo(stopGradient->colorSpace());
            if (!qFuzzyCompare(stop.position, lastStop.position) || stop.type != lastStop.type || stop.color != lastStop.color) {
                stops << stop;
                lastStop.type = stop.type;
                lastStop.color = stop.color;
                lastStop.position = stop.position;
            }
        }
```

#### AUTO 


```{c}
auto i = rhs.m_generatorConfigurations.constBegin();
```

#### AUTO 


```{c}
auto type = i % numTypes;
```

#### LAMBDA EXPRESSION 


```{c}
[state, &dab, direction] () {
                    state->painter->mirrorDab(direction, &dab);
                }
```

#### AUTO 


```{c}
ORDER_BY(isPreferredColorSpace(lhs.colorSpace()),
                 isPreferredColorSpace(rhs.colorSpace()))
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto collection : actionCollections) {

        if (collection->componentName().contains("disposable")) {
            m_disposableActionCollections << collection;
        }

        const QList<QAction *> collectionActions = collection->actions();
        const QString componentName = collection->componentDisplayName();
        for (const auto action : collectionActions) {
            // sanity + empty check ensures displayable actions and removes ourself
            // from the action list
            if (action && !action->text().isEmpty()) {
                actionList.append({componentName, action});
            }
        }
    }
```

#### AUTO 


```{c}
auto * newEngineAction = newPresetBrushEnginesMenu->addAction(sortedBrushEnginesList[j].name);
```

#### AUTO 


```{c}
auto rectIter = diff.begin();
```

#### CONST EXPRESSION 


```{c}
static constexpr int separator_bonus = 30;
```

#### AUTO 


```{c}
auto jobs = KisGeneratorStrokeStrategy::createJobsData(this, cookie, f, originalDevice, processRegion, filterConfig);
```

#### AUTO 


```{c}
static auto reverseModeMap = reverseMap();
```

#### AUTO 


```{c}
auto header = std::make_unique<JxlFrameHeader>();
```

#### AUTO 


```{c}
auto it = std::lower_bound(m_stops.begin(),  m_stops.end(), KoGradientStop(t, KoColor()), [](const KoGradientStop &a, const KoGradientStop &b){
            return a.first < b.first;
        });
```

#### AUTO 


```{c}
auto *dst = reinterpret_cast<channels_type *>(it->rawData());
```

#### AUTO 


```{c}
const auto it = m_rows.begin() + topRow;
```

#### AUTO 


```{c}
const auto tileHeight =
        static_cast<size_t>(it->numContiguousRows(dst->y()));
```

#### AUTO 


```{c}
auto it = m_d->commands.begin();
```

#### AUTO 


```{c}
auto it = shapes.begin() + 1;
```

#### AUTO 


```{c}
ORDER_BY(lhs.renderableType() == m_preferredRendererByHDR,
                     rhs.renderableType() == m_preferredRendererByHDR)
```

#### LAMBDA EXPRESSION 


```{c}
[this, args, levelOfDetail, updateData, useHoldUI, commandGroup]() {

        // it has its own dirty requests blocking inside
        undoTransformCommands(levelOfDetail);

        if (useHoldUI) {
            executeAndAddCommand(new KisHoldUIUpdatesCommand(m_d->updatesFacade, KisCommandUtils::FlipFlopCommand::INITIALIZING), commandGroup, KisStrokeJobData::BARRIER);
        }

        executeAndAddCommand(new KisDisableDirtyRequestsCommand(m_d->updatesFacade, KisUpdateCommandEx::INITIALIZING), commandGroup, KisStrokeJobData::BARRIER);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[curve, repeat](double x)
        { 
            const double sx = x * static_cast<double>(repeat);
            return curve.value(sx - std::floor(sx));
        }
```

#### AUTO 


```{c}
auto it = s_instance->d->tagResourceModels.begin();
```

#### AUTO 


```{c}
auto controls
```

#### AUTO 


```{c}
auto *reference = KisReferenceImage::fromFile(url.toLocalFile(), *this->viewConverter(), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (QUrl url : urls) {

                    if (!url.isLocalFile()) {
                        // download the file and substitute the url
                        KisRemoteFileFetcher fetcher;
                        tmp = new QTemporaryFile();
                        tmp->setAutoRemove(true);
                        if (!fetcher.fetchFile(url, tmp)) {
                            qDebug() << "Fetching" << url << "failed";
                            continue;
                        }
                        url = url.fromLocalFile(tmp->fileName());
                    }
                    if (url.isLocalFile()) {
                        if (action == insertAsNewLayer || action == insertManyLayers) {
                            d->viewManager->imageManager()->importImage(url);
                            activateWindow();
                        }
                        else if (action == insertAsNewFileLayer || action == insertManyFileLayers) {
                            KisNodeCommandsAdapter adapter(viewManager());
                            KisFileLayer *fileLayer = new KisFileLayer(image(), "", url.toLocalFile(),
                                                                       KisFileLayer::None, image()->nextLayerName(), OPACITY_OPAQUE_U8);
                            adapter.addNode(fileLayer, viewManager()->activeNode()->parent(), viewManager()->activeNode());
                        }
                        else {
                            Q_ASSERT(action == openInNewDocument || action == openManyDocuments);
                            if (mainWindow()) {
                                mainWindow()->openDocument(url, KisMainWindow::None);
                            }
                        }
                    }
                    delete tmp;
                    tmp = 0;
                }
```

#### AUTO 


```{c}
auto resourcesFactory =
        [baseBrush, settings, painter] () {
            KisDabCacheUtils::DabRenderingResources *resources =
                new KisBrushOpResources(settings, painter);
            resources->brush = baseBrush->clone().dynamicCast<KisBrush>();

            return resources;
        };
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        QMutexLocker l(&m_dirtyRectsMutex);

        m_updatesFacade->enableDirtyRequests();
        m_updatesDisabled = false;

        Q_FOREACH (KisNodeSP node, m_processedNodes) {
            m_updatesFacade->refreshGraphAsync(node, m_dirtyRects[node] | m_prevDirtyRects[node]);
        }

        m_prevDirtyRects.clear();
        m_dirtyRects.swap(m_prevDirtyRects);
        m_updateTimer.restart();

        // sanity check that no job has been squeezed inbetween
        KIS_SAFE_ASSERT_RECOVER_RETURN(!m_pendingUpdateArgs);
    }
```

#### AUTO 


```{c}
auto workspaces = KisResourceServerProvider::instance()->workspaceServer()->resources();
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    ParticleOption option;
                    option.readOptionSetting(prop->settings().data());
                    option.particle_weight = prop->value().toReal();
                    option.writeOptionSetting(prop->settings().data());
                }
```

#### AUTO 


```{c}
const auto minIndex = d->m_images.size();
```

#### LAMBDA EXPRESSION 


```{c}
[this, shared, progress](){
            // Switch time if necessary..
            if (shared->shouldSwitchTime()) {
                runAndSaveCommand( toQShared( new KisLayerUtils::SwitchFrameCommand(shared->image(), shared->frameTime(), false, shared->storage()) )
                                   , KisStrokeJobData::BARRIER, KisStrokeJobData::NORMAL);
            }

            // Copy snapshot of targetDevice for filter processing..
            shared->filterDevice = new KisPaintDevice(*shared->targetDevice());

            // Update all necessary rect data based on contents of frame..
            shared->filterDeviceBounds = shared->filterDevice->exactBounds();

            if (shared->filter()->needsTransparentPixels(shared->filterConfig().data(), shared->targetDevice()->colorSpace())) {
                shared->filterDeviceBounds |= shared->targetDevice()->defaultBounds()->bounds();
            }

            shared->processRect = shared->filter()->changedRect(shared->filterDeviceBounds, shared->filterConfig(), shared->levelOfDetail());
            shared->processRect &= shared->targetDevice()->defaultBounds()->bounds();

            //If we're dealing with some kind of transparency mask, we will create a compositionSourceDevice instead.
            //  Carry over from commit ca810f85 ...
            if (shared->selection() ||
                    (shared->targetDevice()->colorSpace() != shared->targetDevice()->compositionSourceColorSpace() &&
                    *shared->targetDevice()->colorSpace() != *shared->targetDevice()->compositionSourceColorSpace())) {

                shared->filterDevice = shared->targetDevice()->createCompositionSourceDevice(shared->targetDevice());

                if (shared->selection()) {
                    shared->filterDeviceBounds &= shared->selection()->selectedRect();
                }
            }

            // Filter device needs a transaction to prevent grid-patch artifcacts from multithreaded read/write.
            shared->filterDeviceTransaction.reset(new KisTransaction(shared->filterDevice));


            // Actually process the device

            QVector<KisRunnableStrokeJobData*> processJobs;

            if (shared->filter()->supportsThreading()) {
                // Split stroke into patches...
                QSize size = KritaUtils::optimalPatchSize();
                QVector<QRect> patches = KritaUtils::splitRectIntoPatches(shared->processRect, size);

                Q_FOREACH (const QRect &patch, patches) {
                    if (!patch.isEmpty()) {
                        addJobConcurrent(processJobs, [patch, shared, progress](){
                            shared->filter()->processImpl(shared->filterDevice, patch,
                                                          shared->filterConfig().data(),
                                                          progress->updater());
                        });
                    }
                }
            } else {
                if (!shared->processRect.isEmpty()) {
                    addJobSequential(processJobs, [shared, progress](){
                        shared->filter()->processImpl(shared->filterDevice, shared->processRect,
                                                      shared->filterConfig().data(),
                                                      progress->updater());
                    });
                }
            }

            runnableJobsInterface()->addRunnableJobs(processJobs);

        }
```

#### LAMBDA EXPRESSION 


```{c}
[&exactBounds] (KisNodeSP node) {
            exactBounds |= node->exactBounds();
        }
```

#### AUTO 


```{c}
auto wdg
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool){
        if (m_d->canvas) {
            m_d->canvas->animationPlayer()->previousKeyframe();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (cmsFloat32Number value : inputValues) {
        cmsFloat32Number cValue = value;

        /*
         * logarithmic_100_sqrt10
         * for Lc between 1 and Sqrt( 10 ) ÷ 1000
         *  V = 1.0 + Log10( Lc ) ÷ 2.5
         * for Lc below Sqrt( 10 ) ÷ 1000
         *  V = 0.0
         */

        if (value > (sqrt(10)/1000)){
            cValue = 1.0+log10(value) * (1/2.5) ;
        } else{
            cValue = 0.0;
        }

        /*

        double lValue = powf(10.0, (cValue - 1.0) * 2.5 );
        if (cValue == 0) {
            lValue = 0;
        }

        */

        cmsFloat32Number lValue = cmsEvalToneCurveFloat(curve, cValue);
        if (value > cmsFloat32Number(sqrt(10)/1000)) {
            QVERIFY2(fabs(lValue - value) < 0.000001, QString("Values don't match for log 100 sqrt: %1 %2").arg(value).arg(lValue).toLatin1());
        }

    }
```

#### AUTO 


```{c}
auto it = std::make_reverse_iterator(m_d->commands.end());
```

#### RANGE FOR STATEMENT 


```{c}
for (QUrl url : data->urls()) { // do copy it
                QScopedPointer<QTemporaryFile> tmp(new QTemporaryFile());
                tmp->setAutoRemove(true);

                if (!url.isLocalFile()) {
                    // download the file and substitute the url
                    KisRemoteFileFetcher fetcher;
                    tmp->setFileName(url.fileName());

                    if (!fetcher.fetchFile(url, tmp.data())) {
                        qWarning() << "Fetching" << url << "failed";
                        continue;
                    }
                    url = QUrl::fromLocalFile(tmp->fileName());
                }

                if (url.isLocalFile()) {
                    if (action == KisCanvasDrop::INSERT_MANY_LAYERS) {
                        this->mainWindow()->viewManager()->imageManager()->importImage(url);
                        this->activateWindow();
                    } else if (action == KisCanvasDrop::INSERT_MANY_FILE_LAYERS
                               || action == KisCanvasDrop::INSERT_AS_NEW_FILE_LAYER) {
                        KisNodeCommandsAdapter adapter(this->mainWindow()->viewManager());
                        QFileInfo fileInfo(url.toLocalFile());

                        QString type = KisMimeDatabase::mimeTypeForFile(url.toLocalFile());
                        QStringList mimes = KisImportExportManager::supportedMimeTypes(KisImportExportManager::Import);

                        if (!mimes.contains(type)) {
                            QString msg =
                                KisImportExportErrorCode(ImportExportCodes::FileFormatNotSupported).errorMessage();
                            QMessageBox::warning(this,
                                                 i18nc("@title:window", "Krita"),
                                                 i18n("Could not open %2.\nReason: %1.", msg, url.toDisplayString()));
                            continue;
                        }

                        KisFileLayer *fileLayer = new KisFileLayer(this->image(),
                                                                   "",
                                                                   url.toLocalFile(),
                                                                   KisFileLayer::None,
                                                                   fileInfo.fileName(),
                                                                   OPACITY_OPAQUE_U8);

                        KisLayerSP above = this->mainWindow()->viewManager()->activeLayer();
                        KisNodeSP parent = above ? above->parent() : this->mainWindow()->viewManager()->image()->root();

                        adapter.addNode(fileLayer, parent, above);
                    } else if (action == KisCanvasDrop::OPEN_IN_NEW_DOCUMENT
                               || action == KisCanvasDrop::OPEN_MANY_DOCUMENTS) {
                        if (this->mainWindow()) {
                            this->mainWindow()->openDocument(url.toLocalFile(), KisMainWindow::None);
                        }
                    } else if (action == KisCanvasDrop::INSERT_AS_REFERENCE_IMAGES
                               || action == KisCanvasDrop::INSERT_AS_REFERENCE_IMAGE) {
                        auto *reference = KisReferenceImage::fromFile(url.toLocalFile(), *this->viewConverter(), this);

                        if (reference) {
                            const auto pos = this->canvasBase()->coordinatesConverter()->widgetToImage(event->pos());
                            reference->setPosition((*this->viewConverter()).imageToDocument(pos));
                            this->canvasBase()->referenceImagesDecoration()->addReferenceImage(reference);

                            KoToolManager::instance()->switchToolRequested("ToolReferenceImages");
                        }
                    }
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (ColorPrimaries check: primariesList) {
                colorantsForType(check, compare);
                if (compare.size() <8) {
                    KIS_SAFE_ASSERT_RECOVER(compare.size() < 8) { continue; }
                    //too few colorants, skip.
                }
                match = true;
                for (int i=0; i<colorants.size(); i++) {
                    match = std::fabs(colorants[i] - compare[i]) < 0.00001;
                    if (!match) {
                        break;
                    }
                }
                if (match) {
                    primaries = check;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for(const KoGradientStop& stop : stops) {
        reversedStops.push_front(KoGradientStop(1 - stop.first, stop.second));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QPoint &point : enclosingPoints) {
        // Continue if the region under the point was already filled
        if (*(resultMask->pixel(point).data()) == MAX_SELECTED) {
            continue;
        }
        KisPixelSelectionSP mask = new KisPixelSelection(new KisSelectionDefaultBounds(resultMask));
        KisScanlineFill gc(referenceDevice, point, enclosingMaskRect);
        gc.setThreshold(q->fillThreshold());
        gc.setOpacitySpread(q->opacitySpread());
        // Use the enclosing mask as boundary so that we don't fill
        // potentially large regions in the outside
        gc.fillSelectionUntilColorWithBoundary(mask, color, enclosingMask);
        resultMask->applySelection(mask, SELECTION_ADD);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KoShape *shape: m_selectedMask->koShapes()) {
        KoShape* newShape = shape->cloneShape();
        newShape->setStroke(KoShapeStrokeModelSP());
        newShape->setBackground(QSharedPointer<KoColorBackground>(new KoColorBackground(QColor(255,255,255))));
        shapeLayer->addShape(newShape);
    }
```

#### AUTO 


```{c}
const auto *channel1 =
        layer1->getKeyframeChannel(KisKeyframeChannel::Raster.id());
```

#### LAMBDA EXPRESSION 


```{c}
[image, frames] () {
                bool result = false;

                QScopedPointer<KUndo2Command> cmd(new KUndo2Command());

                Q_FOREACH (const FrameItem &item, frames) {
                    const int time = item.time;
                    KisNodeSP node = item.node;

                    KisKeyframeChannel *channel = node->getKeyframeChannel(item.channel);

                    if (!channel) continue;

                    KisKeyframeSP keyframe = channel->keyframeAt(time);
                    if (!keyframe) continue;

                    channel->deleteKeyframe(keyframe, cmd.data());

                    result = true;
                }

                return result ? new KisCommandUtils::SkipFirstRedoWrapper(cmd.take()) : 0;
        }
```

#### AUTO 


```{c}
auto cIt = c.begin();
```

#### LAMBDA EXPRESSION 


```{c}
[rc, state] () {
                    state->painter->bltFixed(rc, state->dabsQueue);
                }
```

#### LAMBDA EXPRESSION 


```{c}
[&](const uint8_t *img, int stride, int x, int y) {
                    if (luma == 8) {
                        return linearizeValueAsNeeded(float(img[y * (stride) + x]) / 255.0f, linearizePolicy);
                    } else {
                        uint16_t source = reinterpret_cast<const uint16_t *>(img)[y * (stride / 2) + x];
                        if (luma == 10) {
                            return linearizeValueAsNeeded(float(0x03ff & (source)) * multiplier10bit, linearizePolicy);
                        } else if (luma == 12) {
                            return linearizeValueAsNeeded(float(0x0fff & (source)) * multiplier12bit, linearizePolicy);
                        } else {
                            return linearizeValueAsNeeded(float(source) * multiplier16bit, linearizePolicy);
                        }
                    }
                }
```

#### LAMBDA EXPRESSION 


```{c}
[srcDstPairs, parentCommand]() -> KUndo2Command*
        {
            Q_UNUSED(parentCommand);
            QScopedPointer<KUndo2Command> cmd(new KUndo2Command());

            foreach (const FrameMovePair &move, srcDstPairs) {
                KisRasterKeyframeChannel *srcRasterChan = dynamic_cast<KisRasterKeyframeChannel*>(move.first.node->getKeyframeChannel(move.first.channel));
                KisRasterKeyframeChannel *dstRasterChan = dynamic_cast<KisRasterKeyframeChannel*>(move.second.node->getKeyframeChannel(move.second.channel));

                if (!srcRasterChan || !dstRasterChan) {
                    continue;
                }

                if (srcRasterChan == dstRasterChan) {
                    srcRasterChan->cloneKeyframe(move.first.time, move.second.time, cmd.data());
                } else {
                    KisKeyframeChannel::copyKeyframe(srcRasterChan, move.first.time, dstRasterChan, move.second.time, cmd.data());
                }
            }

            return cmd.take();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &groupName : m_model->colorSet()->getGroupNames()) {
        const KisSwatchGroup *group = m_model->colorSet()->getGroup(groupName);
        for (const SwatchInfoType &info : group->infoList()) {
            infoList.append(info);
        }
    }
```

#### AUTO 


```{c}
const auto rowsToWork =
            qMin(numContiguousImageRows, static_cast<qint32>(rowsRemaining));
```

#### RANGE FOR STATEMENT 


```{c}
for (QWindow* window: QGuiApplication::topLevelWindows()) {
        // Android: we shouldn't transform Window managers independent of its child
        if ((window->type() == Qt::Popup)
            && (window->flags() & Qt::FramelessWindowHint) == 0
            && (window->geometry().topLeft() != QPoint(0, 0))) {
            // We are using reversed values. Because geometry returned is not the updated
            // one, but the previous one.
            int screenHeight = screen->geometry().width();
            int screenWidth = screen->geometry().height();

            // scaling
            int new_x = (window->position().x() * screenWidth) / screenHeight;
            int new_y = (window->position().y() * screenHeight) / screenWidth;

            // window width or height shouldn't change
            int winWidth = window->geometry().width();
            int winHeight = window->geometry().height();

            // Try best to not let the window go beyond screen.
            if (new_x > screenWidth - winWidth) {
                new_x = screenWidth - winWidth;
                if (new_x < 0)
                    new_x = 0;
            }
            if (new_y > screenHeight - winHeight) {
                new_y = screenHeight - winHeight;
                if (new_y < 0)
                    new_y = 0;
            }

            window->setPosition(QPoint(new_x, new_y));
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&](int i) {
        if (KisTabletDebugger::instance()->debugEnabled()) {
            QString pre = QString("[BLOCKED %1:]").arg(i);
            QMouseEvent *ev = static_cast<QMouseEvent*>(event);
            dbgTablet << KisTabletDebugger::instance()->eventToString(*ev, pre);
        }
    }
```

#### AUTO 


```{c}
auto tester = new QAbstractItemModelTester(&model, QAbstractItemModelTester::FailureReportingMode::QtTest);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KisSwatchGroup::SwatchInfo &currInfo : group->infoList()) {
            KoColor color = currInfo.swatch.color();
            if (useGivenColorSpace == true && compare.colorSpace() != color.colorSpace()) {
                color.convertTo(compare.colorSpace());

            } else if (compare.colorSpace() != color.colorSpace()) {
                compare.convertTo(color.colorSpace());
            }
            testPercentage = (255 - compare.colorSpace()->difference(compare.data(), color.data()));
            if (testPercentage > highestPercentage)
            {
                highestPercentage = testPercentage;
                res = currInfo;
            }
        }
```

#### AUTO 


```{c}
auto it = std::make_reverse_iterator(m_transformCommands.end());
```

#### AUTO 


```{c}
const auto dstTileIndex =
                convertedTileX + convertedTileY * tileWidth;
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            for (auto it = std::make_reverse_iterator(m_transformCommands.end());
                 it != std::make_reverse_iterator(m_transformCommands.begin());
                 ++it) {

                executeCommand(*it, true);
            }
            m_transformCommands.clear();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, interface]() {
            notifyAllCommandsDone(interface);
        }
```

#### AUTO 


```{c}
auto it = forest.insert(childBegin(forest), 3);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &line : stdoutLines) {
        dbgFile << "ffmpeg probe stdout" << line;
        QRegularExpression videoInfoInputRX("Duration: (\\d+):(\\d+):([\\d\\.]+),");
        QRegularExpressionMatch durationMatch = videoInfoInputRX.match(line);

        if (ffmpegFormatJsonObj.value("duration").isUndefined() && durationMatch.hasMatch()) {
            ffmpegFormatJsonObj["duration"] = QString::number( (durationMatch.captured(1).toInt() * 60 * 60)
                                                             + (durationMatch.captured(2).toInt() * 60) 
                                                             + durationMatch.captured(3).toFloat()
                                                             );
        } else {
            QRegularExpression videoInfoStreamRX(
                QString("Stream #(\\d+):(\\d+)(?:[ ]*?\\((\\w+)\\)|): Video: (\\w+?)(?:[ ]*?\\((.+?)\\)|),[ ]*?")
                        .append("(\\w+?)(?:[ ]*?\\((.+?)\\)|),[ ]*?")
                        .append("(\\d+)x(\\d+)([ ]*?\\[.+?\\]|.*?),[ ]*?")
                        .append("(?:([\\d\\.]+) fps,|) (\\S+?) tbr, (.+?) tbn, (.+?) tbc")
            );
            
            QRegularExpressionMatch streamMatch = videoInfoStreamRX.match(line);
            
            if (streamMatch.hasMatch() && ffmpegStreamsJsonArr[streamMatch.captured(1).toInt()].isUndefined() ) {
                int index = streamMatch.captured(1).toInt();
                QJsonObject ffmpegJsonOnStreamObj;
                
                ffmpegJsonOnStreamObj["index"] = index;
                ffmpegJsonOnStreamObj["codec_name"] = streamMatch.captured(4);
                ffmpegJsonOnStreamObj["profile"] = streamMatch.captured(5);
                ffmpegJsonOnStreamObj["pix_fmt"] = streamMatch.captured(6);
                ffmpegJsonOnStreamObj["width"] = streamMatch.captured(8).toInt();
                ffmpegJsonOnStreamObj["height"] = streamMatch.captured(9).toInt();
                
                ffmpegJsonOnStreamObj["codec_type"] = "video";
                
                if (streamMatch.captured(11).toFloat() > 0) {
                    float fps = streamMatch.captured(11).toFloat();

                    ffmpegProgressJsonObj["ffmpeg_fps"] = QString::number(fps);
                    ffmpegJsonOnStreamObj["r_frame_rate"] = QString::number( fps * 10000 ).append(QString("/10000"));
                } else {
                    ffmpegProgressJsonObj["ffmpeg_fps"] = 0;
                }

                ffmpegJsonObj["error"] = FFProbeErrorCodes::NONE;
                
                dbgFile << "ffmpegProbe stream:" << ffmpegJsonOnStreamObj;
                
                ffmpegStreamsJsonArr.insert(index, ffmpegJsonOnStreamObj);
                
            } else {
                
                QRegularExpression videoInfoFrameRX("^(\\w+?)=([\\w\\./:]+?)$");
                QRegularExpressionMatch frameMatch = videoInfoFrameRX.match(line);

                if (frameMatch.hasMatch()) ffmpegProgressJsonObj[frameMatch.captured(1)] = frameMatch.captured(2);
    
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](qreal angle) { slotSliderChanged(static_cast<int>(angle)); }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() { updateWindowMenu(); }
```

#### LAMBDA EXPRESSION 


```{c}
[](QString type) {
        return (type.startsWith("image/")
                || (type.startsWith("application/") &&
                    !type.startsWith("application/x-spriter")));
    }
```

#### AUTO 


```{c}
const auto original = index.data().toString();
```

#### LAMBDA EXPRESSION 


```{c}
LAZY_STATIC_CATEGORY_DISPLAY_NAME("light")
```

#### RANGE FOR STATEMENT 


```{c}
for (KisLazyFillTools::KeyStroke keystroke : mask->fetchKeyStrokesDirect()) {
        if (kc == keystroke.color) {
            KisPaintDeviceSP dev = keystroke.dev;

            if (!dev) return false;
            if (value.length() <  w * h * (int)dev->colorSpace()->pixelSize()) {
                qWarning() << "ColorizeMask::setKeyStrokePixelData: not enough data to write to the paint device";
                return false;
            }
            dev->writeBytes((const quint8*)value.constData(), x, y, w, h);
            return true;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](QAbstractButton* btn){
       return (btn->isChecked());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                Q_FOREACH (KisTransformMask *mask, m_d->transformMaskCacheHash.keys()) {
                    mask->overrideStaticCacheDevice(0);
                }

                /**
                 * Transform masks don't have internal state switch for LoD mode,
                 * therefore all the preview transformations must be cancelled
                 * before applying the final command
                 */
                m_d->updatesFacade->disableDirtyRequests();
                m_d->updatesDisabled = true;
                undoTransformCommands(m_d->previewLevelOfDetail);
                m_d->updatesFacade->enableDirtyRequests();
                m_d->updatesDisabled = false;
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KisLevelsCurve &levelsCurve : levelsCurves) {
            minBlackPoint = qMin(levelsCurve.inputBlackPoint(), minBlackPoint);
            maxWhitePoint = qMax(levelsCurve.inputWhitePoint(), maxWhitePoint);
        }
```

#### AUTO 


```{c}
auto dstPtrValue = reinterpret_cast<uintptr_t>(dst);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        Q_FOREACH (KUndo2CommandSP cmd, m_clearCommands) {
            notifyCommandDone(cmd, KisStrokeJobData::CONCURRENT, KisStrokeJobData::NORMAL);
        }

        notifyCommandDone(toQShared(new KUndo2Command()), KisStrokeJobData::SEQUENTIAL, KisStrokeJobData::NORMAL);

        Q_FOREACH (KUndo2CommandSP cmd, m_transformCommands) {
            notifyCommandDone(cmd, KisStrokeJobData::CONCURRENT, KisStrokeJobData::NORMAL);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {
            m_updatesFacade->enableDirtyRequests();
            m_updatesDisabled = false;

            m_updateData->compress();
            runAndSaveCommand(toQShared(new KisUpdateCommandEx(m_updateData, m_updatesFacade, KisUpdateCommandEx::FINALIZING)), KisStrokeJobData::BARRIER, KisStrokeJobData::NORMAL);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KoColorSetSP palette : m_d->doc->paletteList()) {
        QDomElement eFile =  doc.createElement("palette");
        eFile.setAttribute("filename", palette->filename());
        ePalette.appendChild(eFile);
    }
```

#### AUTO 


```{c}
auto *session = rserver->resourceByName(sessionName);
```

#### AUTO 


```{c}
auto &m_options = m_page->m_options;
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &node : nodes) {
        auto layer = qobject_cast<KisLayer*>(node.data());
        if (layer) {
            layer->disableAlphaChannel(!isAlphaDisabled);
            node->setDirty();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        KisStrokeStrategyUndoCommandBased::finishStrokeCallback();
    }
```

#### AUTO 


```{c}
const auto validation =
        JxlSignatureCheck(reinterpret_cast<const uint8_t *>(data.constData()), static_cast<size_t>(data.size()));
```

#### AUTO 


```{c}
const auto tgt = d.m_forcedConversion ? JXL_COLOR_PROFILE_TARGET_DATA : JXL_COLOR_PROFILE_TARGET_ORIGINAL;
```

#### AUTO 


```{c}
auto &node
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        QString name = QInputDialog::getText(this, i18nc("@title:window", "New Workspace..."),
                                             i18nc("@label:textbox", "Name:"));
        if (name.isEmpty()) return;
        auto rserver = KisResourceServerProvider::instance()->workspaceServer();

        KisWorkspaceResourceSP workspace(new KisWorkspaceResource(""));
        workspace->setDockerState(m_this->saveState());
        d->viewManager->resourceProvider()->notifySavingWorkspace(workspace);
        workspace->setValid(true);
        QString saveLocation = rserver->saveLocation();

        bool newName = false;
        if(name.isEmpty()) {
            newName = true;
            name = i18n("Workspace");
        }
        QFileInfo fileInfo(saveLocation + name + workspace->defaultFileExtension());

        int i = 1;
        while (fileInfo.exists()) {
            fileInfo.setFile(saveLocation + name + QString("%1").arg(i) + workspace->defaultFileExtension());
            i++;
        }
        workspace->setFilename(fileInfo.filePath());
        if(newName) {
            name = i18n("Workspace %1", i);
        }
        workspace->setName(name);
        rserver->addResource(workspace);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&] (KisFreehandStrokeInfo *data) {
        data->painter->drawPainterPath(path, pen);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto arg : occurrence.ids) {
                message = message.arg(QString::fromStdString(arg));
            }
```

#### LAMBDA EXPRESSION 


```{c}
[] (const KoGradientStop &stop) {
                         return stop.type != COLORSTOP;
                     }
```

#### RANGE FOR STATEMENT 


```{c}
for (QRect &rect: m_snapRects) {
        QPointF point(drawPointOnAngle(i * 15, m_popupPaletteSize / 2 - BORDER_WIDTH - m_snapRadius/2));
        point += QPointF(m_popupPaletteSize / 2 - m_snapRadius, m_popupPaletteSize / 2 - m_snapRadius);
        rect = QRect(point.x(), point.y(), m_snapRadius*2, m_snapRadius*2);
        i++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractButton *button : m_d->colorButtonGroup->buttons()) {
        qobject_cast<KisColorLabelButton*>(button)->setSelectionVisType(
            static_cast<KisColorLabelButton::SelectionIndicationType>(type)
        );
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool){
        if (m_d->canvas) {
            m_d->canvas->animationPlayer()->previousUnfilteredKeyframe();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {
            {
                /// Here is a bit of code-duplication from
                /// InplaceTransformStrokeStrategy. This code reduced the
                /// amount of updates we do in the course of transformation.
                /// Basically, we find the minimum set of parents for the
                /// selected layers and do full refresh for them

                KisNodeList filteredNodes = m_processedNodes;
                KisLayerUtils::sortAndFilterMergableInternalNodes(filteredNodes);

                KisUpdateCommandEx::SharedData newUpdateData;

                Q_FOREACH (KisNodeSP root, filteredNodes) {
                    QRect dirtyRect;

                    for (auto it = m_updateData->begin(); it != m_updateData->end(); ++it) {
                        if (KisLayerUtils::checkIsChildOf(it->first, {root})) {
                            dirtyRect |= it->second;
                        }
                    }
                    newUpdateData.push_back(std::make_pair(root, dirtyRect));
                }

                *m_updateData = newUpdateData;
            }

            m_updatesFacade->enableDirtyRequests();
            m_updatesDisabled = false;
            runAndSaveCommand(toQShared(new KisUpdateCommandEx(m_updateData, m_updatesFacade, KisUpdateCommandEx::FINALIZING)), KisStrokeJobData::BARRIER, KisStrokeJobData::NORMAL);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, sharedState, sharedWriteLock, undoAdapter, cleanResources] () {
            Q_UNUSED(sharedWriteLock); // just a RAII holder object for the lock

            if (cleanResources) {
                releaseResources();
            }

            if (sharedState->transaction) {
                sharedState->transaction->commit(undoAdapter);
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
            m_this->restoreWorkspace(resource->id());
        }
```

#### AUTO 


```{c}
auto *addKeyframeCommand = new KisScalarKeyframeChannel::AddKeyframeCommand(
                channel, index.column(), value.toReal(), command);
```

#### AUTO 


```{c}
auto it = propertyFrequency.constBegin();
```

#### AUTO 


```{c}
auto it = update.begin();
```

#### AUTO 


```{c}
const auto inputFileName = TestUtil::fetchDataFileLazy("/sources/netflix/hdr_cosmos01000_cicp9-16-0_lossless.jxl");
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &directory : directories) {
        qDebug() << "REMOVING " <<  directory;
        QDir(directory).removeRecursively();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&deviceList](KisNodeSP node) {
             deviceList << node->getLodCapableDevices();
        }
```

#### AUTO 


```{c}
const auto *src = static_cast<const channels_type *>(pixels);
```

#### LAMBDA EXPRESSION 


```{c}
[this](qreal value)
        {
            KisSignalsBlocker blocker(m_page.intThreshold);
            m_page.intThreshold->setValue(static_cast<int>(qRound(value * 255.0)));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QPointF dPos : m_subbrOriginalLocations) {
            QPointF resPos = dPos-m_axesPoint; // Calculate the difference between subbrush reference position and "origin" reference
            m.translate(resPos.x(), resPos.y());
            transformations << m;
            m.reset();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    DuplicateOption option;
                    option.readOptionSetting(prop->settings().data());

                    prop->setValue(option.duplicate_move_source_point);
                }
```

#### AUTO 


```{c}
auto readFunc = [this] (int col, int row) {
                            KisTileSP tile = dm.getTile(col, row, false);
                            tile->lockForRead();
                            tile->unlockForRead();
                        };
```

#### AUTO 


```{c}
auto it = std::begin(jobsOrder.jobs);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &groupName : m_model->colorSet()->getGroupNames()) {
        QVector<SwatchInfoType> infoList;
        PosIdxMapType posIdxMap;
        const KisSwatchGroup *group = m_model->colorSet()->getGroup(groupName);
        for (const SwatchInfoType &info : group->infoList()) {
            infoList.append(info);
        }
        std::sort(infoList.begin(), infoList.end(), swatchInfoLess);
        for (const SwatchInfoType &info : infoList) {
            const KisSwatch &swatch = info.swatch;
            QString name = swatch.name();
            if (!swatch.id().isEmpty()){
                name = swatch.id() + " - " + swatch.name();
            }
            addSqueezedItem(QIcon(createColorSquare(swatch)), name);
            posIdxMap[SwatchPosType(info.column, info.row)] = count() - 1;
            m_idxSwatchMap.push_back(swatch);
        }
        m_groupMapMap[group->name()] = posIdxMap;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QPointF &p1, const QPointF &p2) ->bool
                     {
                         return p1.y() > p2.y();
                     }
```

#### LAMBDA EXPRESSION 


```{c}
[] (const QPointF &pt) {
                return pt.x();
            }
```

#### AUTO 


```{c}
const auto pos = static_cast<size_t>(y) * gmicImage._width
                    + static_cast<size_t>(x);
```

#### AUTO 


```{c}
const auto devIt = penDevices.find(penInfo.pointerInfo.sourceDevice);
```

#### LAMBDA EXPRESSION 


```{c}
[srcDstPairs, copy, moveEmptyFrames] () -> KUndo2Command* {
                bool result = false;

                QScopedPointer<KUndo2Command> cmd(new KUndo2Command());

                using MoveChain = QList<FrameItem>;
                QHash<FrameItem, MoveChain> moveMap;
                Q_FOREACH (const FrameMovePair &pair, srcDstPairs) {
                    moveMap.insert(pair.first, {pair.second});
                }

                auto it = moveMap.begin();
                while (it != moveMap.end()) {
                    MoveChain &chain = it.value();
                    const FrameItem &previousFrame = chain.last();

                    auto tailIt = moveMap.find(previousFrame);

                    if (tailIt == it || tailIt == moveMap.end()) {
                        ++it;
                        continue;
                    }

                    chain.append(tailIt.value());
                    tailIt = moveMap.erase(tailIt);
                    // no incrementing! we are going to check the new tail now!
                }

                for (it = moveMap.begin(); it != moveMap.end(); ++it) {
                    MoveChain &chain = it.value();
                    chain.prepend(it.key());
                    KIS_SAFE_ASSERT_RECOVER(chain.size() > 1) { continue; }

                    bool isCycle = false;
                    if (chain.last() == chain.first()) {
                        isCycle = true;
                        chain.takeLast();
                    }

                    auto frameIt = chain.rbegin();

                    FrameItem dstItem = *frameIt++;

                    while (frameIt != chain.rend()) {
                        FrameItem srcItem = *frameIt++;

                        if (!isCycle) {
                            moveOneFrameItem(srcItem, dstItem, copy, moveEmptyFrames, cmd.data());
                        } else {
                            swapOneFrameItem(srcItem, dstItem, cmd.data());
                        }

                        dstItem = srcItem;
                        result = true;
                    }
                }

                return result ? new KisCommandUtils::SkipFirstRedoWrapper(cmd.take()) : 0;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto *i : m_lineList) {
        result.append(i->configuration());
        result.append(';');
    }
```

#### LAMBDA EXPRESSION 


```{c}
[m_c1](double x)
            {
                const double xx = 1.0 - x;
                return 2.0 * x * std::exp(-(xx * xx / m_c1));
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            Q_FOREACH (KisTransformMask *mask, m_d->transformMaskCacheHash.keys()) {
                mask->threadSafeForceStaticImageUpdate();
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[index, Model] {
            int row = index.row();
            KisRemoveStoryboardCommand *command = new KisRemoveStoryboardCommand(row, Model->getData().at(row), Model);
            Model->removeItem(index, command);
            Model->pushUndoCommand(command);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KoColorSpace *colorSpace : colorSpaces) {
        QString fn = QFileInfo(colorSpace->profile()->fileName()).fileName();
        if (!store->open(fn)) { return false; }
        QByteArray profileRawData = colorSpace->profile()->rawData();
        if (!store->write(profileRawData)) { return false; }
        if (!store->close()) { return false; }
        QDomElement el = doc.createElement(KPL_PALETTE_PROFILE_TAG);
        el.setAttribute(KPL_PALETTE_FILENAME_ATTR, fn);
        el.setAttribute(KPL_PALETTE_NAME_ATTR, colorSpace->profile()->name());
        el.setAttribute(KPL_COLOR_MODEL_ID_ATTR, colorSpace->colorModelId().id());
        el.setAttribute(KPL_COLOR_DEPTH_ID_ATTR, colorSpace->colorDepthId().id());
        profileElement.appendChild(el);

    }
```

#### CONST EXPRESSION 


```{c}
static constexpr int minimumDragDistanceSquared{minimumDragDistance * minimumDragDistance};
```

#### LAMBDA EXPRESSION 


```{c}
[](KisNodeSP node) {
                  return !node->userLocked();
                }
```

#### CONST EXPRESSION 


```{c}
static constexpr bool isInherited = std::is_convertible<T*, KisShared*>::value;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &overlayDevice : m_d->overlays) {
        m_d->overlayTransactions.emplace_back(new KisTransaction(overlayDevice, m_d->rootTransactionData.data()));
    }
```

#### CONST EXPRESSION 


```{c}
constexpr int halfPatchStep = patchStep >> 1;
```

#### AUTO 


```{c}
auto it = csMap.find(idsToCacheName(csID, profileName));
```

#### LAMBDA EXPRESSION 


```{c}
[=](QString node){return quietlyTranslate(getChildContent(node));}
```

#### AUTO 


```{c}
auto *reference = KisReferenceImage::fromFile(url.toLocalFile(), *kisview->viewConverter(), kisview);
```

#### AUTO 


```{c}
auto *layerNameCmd = KisQmicImportTools::applyLayerNameChanges(*d->m_images[i], paintLayer.data());
```

#### AUTO 


```{c}
auto popupObject = dynamic_cast<QObject*>(d->popupWidget);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &action : m_pendingActions) {
                action();
            }
```

#### LAMBDA EXPRESSION 


```{c}
[&jobs](KisNodeSP node) {
             KritaUtils::addJobConcurrent(jobs, [node] () mutable {
                 node->syncLodCache();
             });
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto *filter: m_filterRegistryModel.enabledFilters()) {
        enabledFilters += filter->id() + ',';
    }
```

#### LAMBDA EXPRESSION 


```{c}
[firstFrameOfScene, lastFrameOfScene, command] (KisNodeSP node){
            if (node->isAnimated()) {
                KisKeyframeChannel *keyframeChannel = node->paintDevice()->keyframeChannel();

                int timeIter = keyframeChannel->keyframeAt(firstFrameOfScene)
                                                            ? firstFrameOfScene
                                                            : keyframeChannel->nextKeyframeTime(firstFrameOfScene);

                while (keyframeChannel->keyframeAt(timeIter) && timeIter <= lastFrameOfScene) {
                    keyframeChannel->removeKeyframe(timeIter, command);
                    timeIter = keyframeChannel->nextKeyframeTime(timeIter);
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &image : layers) {
        QString layerName = image->m_layerName;
        const auto spectrum = image->m_spectrum;
        const auto width = image->m_width;
        const auto height = image->m_height;

        dbgPlugins << "Received image: " << static_cast<void *>(image.data())
                   << layerName << width << height;

        gmic_image<float> *gimg = nullptr;

        {
            QMutexLocker lock(&image->m_mutex);

            dbgPlugins << "Memory segment" << static_cast<void *>(image.data())
                       << image->size()
                       << static_cast<const void *>(image->constData())
                       << static_cast<void *>(image->m_data);
            gimg = new gmic_image<float>();
            gimg->assign(static_cast<unsigned int>(width),
                         static_cast<unsigned int>(height),
                         1,
                         static_cast<unsigned int>(spectrum));
            gimg->name = layerName;

            gimg->_data =
                new float[static_cast<size_t>(width * height * spectrum)
                          * sizeof(float)];
            dbgPlugins << "width" << width << "height" << height << "size"
                       << static_cast<size_t>(width * height * spectrum)
                    * sizeof(float)
                       << "shared memory size" << image->size();
            memcpy(gimg->_data,
                   image->constData(),
                   static_cast<size_t>(width * height * spectrum)
                       * sizeof(float));

            dbgPlugins << "created gmic image" << gimg->name << gimg->_width << gimg->_height;
        }
        images.append(gimg);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, levelOfDetail]() {
        updatesFacade->enableDirtyRequests();
        updatesDisabled = false;
        postAllUpdates(levelOfDetail);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[targetFrame, cmd](KisNodeSP node){
            if (node->supportsKeyframeChannel(KisKeyframeChannel::Raster.id())) {
                KisKeyframeChannel* chan = node->getKeyframeChannel(KisKeyframeChannel::Raster.id(), true);
                chan->addKeyframe(targetFrame, cmd);
            }
        }
```

#### AUTO 


```{c}
auto config = KSharedConfig::openConfig(path);
```

#### RANGE FOR STATEMENT 


```{c}
for (KisRenderedDab &dab : state->dabsQueue) {
        jobs.append(
            new KisRunnableStrokeJobData(
                [state, &dab, direction] () {
                    state->painter->mirrorDab(direction, &dab);
                },
                KisStrokeJobData::CONCURRENT));
    }
```

#### AUTO 


```{c}
auto it4 = forest.insert(childEnd(it0), 4);
```

#### LAMBDA EXPRESSION 


```{c}
[interface]() {
                interface->KisStrokeStrategyUndoCommandBased::cancelStrokeCallback();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KisLevelsCurve &levelsCurve : m_levelsCurves) {
        previousLevelsCurves.append(levelsCurve);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        /**
             * We must ensure that the currently selected subtree
             * has finished all its updates.
             */
        KisLayerUtils::forceAllDelayedNodesUpdate(m_rootNode);
    }
```

#### AUTO 


```{c}
auto *layerNameCmd =
            KisQmicImportTools::applyLayerNameChanges(*gimg,
                                                      node.data(),
                                                      selection);
```

#### AUTO 


```{c}
auto it = find(index);
```

#### AUTO 


```{c}
auto clickedProperty = d->propForMousePos(index, mouseEvent->pos(), newOption);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &word : errorWords) {
            if (line.contains(word)) {
                m_errorMessage += line % "\n";
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KisTextureUniform &uniform : m_lut3dUniforms) {
        const int m_handle = program->uniformLocation(uniform.m_name);

        const OCIO::GpuShaderDesc::UniformData &m_data = uniform.m_data;

        // Update value.
        if (m_data.m_getDouble) {
            program->setUniformValue(m_handle, static_cast<const GLfloat>(m_data.m_getDouble()));
        } else if (m_data.m_getBool) {
            program->setUniformValue(m_handle, static_cast<const GLfloat>(m_data.m_getBool() ? 1.0f : 0.0f));
        } else if (m_data.m_getFloat3) {
            program->setUniformValue(m_handle,
                                     m_data.m_getFloat3()[0],
                                     m_data.m_getFloat3()[1],
                                     m_data.m_getFloat3()[2]);
        } else if (m_data.m_vectorFloat.m_getSize && m_data.m_vectorFloat.m_getVector) {
            program->setUniformValueArray(m_handle,
                                          m_data.m_vectorFloat.m_getVector(),
                                          m_data.m_vectorFloat.m_getSize(),
                                          1);
        } else if (m_data.m_vectorInt.m_getSize && m_data.m_vectorInt.m_getVector) {
            program->setUniformValueArray(m_handle, m_data.m_vectorInt.m_getVector(), m_data.m_vectorInt.m_getSize());
        } else {
            errOpenGL << "Uniform" << uniform.m_name << "is not linked to any value";
            continue;
        }
    }
```

#### AUTO 


```{c}
auto tester = new QAbstractItemModelTester(&model);
```

#### AUTO 


```{c}
auto *referenceImagesLayer = dynamic_cast<KisReferenceImagesLayer*>(node.data());
```

#### AUTO 


```{c}
const auto it = prev(upper_bound(m_columns.begin(), m_columns.end(), proportionalT));
```

#### CONST EXPRESSION 


```{c}
constexpr const int visibleRecentItemsCount = 5;
```

#### LAMBDA EXPRESSION 


```{c}
[state, this] () {
                    Q_FOREACH(const QRect &rc, state->allDirtyRects) {
                        state->painter->addDirtyRect(rc);
                    }

                    state->painter->setAverageOpacity(state->dabsQueue.last().averageOpacity);

                    const int updateRenderingTime = state->dabRenderingTimer.elapsed();
                    const int dabRenderingTime = m_dabExecutor->averageDabRenderingTime() / 1000;
                    m_avgNumDabs(state->dabsQueue.size());

                    QVector<KisFixedPaintDeviceSP> recycledDevices;
                    for (auto it = state->dabsQueue.begin(); it != state->dabsQueue.end(); ++it) {
                        // we don't need to check for uniqueness, it is done by the queue
                        recycledDevices << it->device;
                        it->device.clear();
                    }
                    m_dabExecutor->recyclePaintDevicesForCache(recycledDevices);



                    const int approxDabRenderingTime = qreal(dabRenderingTime) / m_idealNumRects * m_avgNumDabs.rollingMean();

                    m_currentUpdatePeriod = qBound(20, int(1.5 * (approxDabRenderingTime + updateRenderingTime)), 100);


                    { // debug chunk
//                        const int updateRenderingTime = state->dabRenderingTimer.nsecsElapsed() / 1000;
//                        const int dabRenderingTime = m_dabExecutor->averageDabRenderingTime();
//                        ENTER_FUNCTION() << ppVar(state->allDirtyRects.size()) << ppVar(state->dabsQueue.size()) << ppVar(dabRenderingTime) << ppVar(updateRenderingTime);
//                        ENTER_FUNCTION() << ppVar(m_currentUpdatePeriod);
                    }

                    m_updateSharedState.clear();
                }
```

#### AUTO 


```{c}
const auto pos = kisview->canvasBase()->coordinatesConverter()->widgetToImage(eventPos);
```

#### LAMBDA EXPRESSION 


```{c}
[&] (KisFreehandStrokeInfo *data) {
        data->painter->paintLine(pi1, pi2, data->dragDistance);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QAction* modeAction){
                    if (!modeAction) return;
                    KisImageConfig  imageCfg(false);
                    if (modeAction == autoKeyBlank) {
                        imageCfg.setAutoKeyModeDuplicate(false);
                    } else if (modeAction == autoKeyDuplicate) {
                        imageCfg.setAutoKeyModeDuplicate(true);
                    }
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const bool state){
        if (d->currentFilter) {
            d->uiFilterDialog.pushButtonCreateMaskEffect->setEnabled(!state && d->currentFilter->supportsAdjustmentLayers());
        }
    }
```

#### AUTO 


```{c}
auto converted = KisTransformMaskParamsFactoryRegistry::instance()->animateParams(m_d->params, this);
```

#### AUTO 


```{c}
auto i = channelPtrBegin;
```

#### AUTO 


```{c}
auto ar = KisActionRegistry::instance();
```

#### AUTO 


```{c}
auto it = preserved.constBegin();
```

#### AUTO 


```{c}
const auto &position
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    ParticleOption option;
                    option.readOptionSetting(prop->settings().data());
                    option.particle_iterations = prop->value().toInt();
                    option.writeOptionSetting(prop->settings().data());
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (Vertex* v : endNode->outputVertexes) {
                if (v->dstNode->isInitialized && !p.contains(v->dstNode)) {
                    Path newP = p;  // Candidate
                    newP.appendVertex(v);
                    Node* newEndNode = v->dstNode;
                    if (newEndNode == dstNode) {
                        if (pQC.isGoodPath(newP)) { // Victory
                            newP.isGood = true;
                            return newP;
                        } else if (pQC.lessWorseThan(newP, currentBestPath)) {
                            if (newP.startNode() && newP.endNode() && currentBestPath.startNode() && currentBestPath.endNode()) {
                                Q_ASSERT(newP.startNode()->id() == currentBestPath.startNode()->id());
                                Q_ASSERT(newP.endNode()->id() == currentBestPath.endNode()->id());
                                // Can we do better than dumping memory values???
                                // warnPigment << pQC.lessWorseThan(newP, currentBestPath) << " " << newP << "  " << currentBestPath;
                                currentBestPath = newP;
                            }
                        }
                    } else {
                        // This is an incomplete path. Check if there's a better way to get to its endpoint.
                        Node2PathHash::Iterator it = node2path.find(newEndNode);
                        if (it != node2path.end()) {
                            Path &p2 = it.value();
                            if (pQC.lessWorseThan(newP, p2)) {
                                p2 = newP;
                                possiblePaths.append(newP);
                            }
                        } else {
                            node2path.insert(newEndNode, newP);
                            possiblePaths.append(newP);
                        }
                    }
                }
            }
```

#### AUTO 


```{c}
const auto &i
```

#### AUTO 


```{c}
auto *factory = qobject_cast<KPluginFactory *>(loader->instance());
```

#### RANGE FOR STATEMENT 


```{c}
for (const SnapshotDirInfo &info : snapshots) {
        QStandardItem *nameCol = new QStandardItem(info.name);
        nameCol->setData(info.path, valueRole);
        model->appendRow({
            new CheckedIconItem(info.thumbnail, ui->treeDirectories->iconSize()),
            nameCol,
#if (QT_VERSION >= QT_VERSION_CHECK(5, 10, 0))
            new DataSortedItem(locale.formattedDataSize(info.size), info.size),
#else
            new DataSortedItem(qlocale_formattedDataSize(info.size), info.size),
#endif
            new DataSortedItem(info.dateTime.toString(dateFormat), info.dateTime.toMSecsSinceEpoch())
        });
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KisSwatchGroup::SwatchInfo &info : groups[groupName].infoList()) {
            QColor c = info.swatch.color().toQColor();
            gc.fillRect(info.column * 4, (lastRow + info.row) * 4, 4, 4, c);
            lastRowGroup = qMax(lastRowGroup, info.row);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (KisShortcutConfiguration * const shortcut : shortcuts) {
            dbgUI << "Adding shortcut" << shortcut->keys() << "for action" << shortcut->action()->name();
            switch(shortcut->type()) {
            case KisShortcutConfiguration::KeyCombinationType:
                d->addKeyShortcut(shortcut->action(), shortcut->mode(), shortcut->keys());
                break;
            case KisShortcutConfiguration::MouseButtonType:
                d->addStrokeShortcut(shortcut->action(), shortcut->mode(), shortcut->keys(), shortcut->buttons());
                break;
            case KisShortcutConfiguration::MouseWheelType:
                d->addWheelShortcut(shortcut->action(), shortcut->mode(), shortcut->keys(), shortcut->wheel());
                break;
            case KisShortcutConfiguration::GestureType:
                d->addTouchShortcut(shortcut->action(), shortcut->mode(), shortcut->gesture());
                break;
            default:
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KoGradientSegment *segment : segments) {
        KoGradientSegment *newSegment =
            new KoGradientSegment(
                segment->interpolation(),
                segment->colorInterpolation(),
                KoGradientSegmentEndpoint(
                    segment->startOffset(),
                    segment->startColor().convertedTo(colorSpace()),
                    segment->startType()
                ),
                KoGradientSegmentEndpoint(
                    segment->endOffset(),
                    segment->endColor().convertedTo(colorSpace()),
                    segment->endType()
                ),
                segment->middleOffset()
            );
        m_segments.append(newSegment);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KisRenderedDab &dab : state->dabsQueue) {
        const bool skipMirrorPixels = prevDabDevice && prevDabDevice == dab.device;

        KritaUtils::addJobConcurrent(jobs,
            [state, &dab, direction, skipMirrorPixels] () {
                state->painter->mirrorDab(direction, &dab, skipMirrorPixels);
            }
        );

        prevDabDevice = dab.device;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &pair : blendingModeMap) {
        result.emplace(pair.second, pair.first);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, popupMenu](){
            if (popupMenu) {
                QPoint stylusOffset;
                QScopedPointer<SinglePressEventEater> eventEater;

                if (m_requestedWithStylus) {
                    eventEater.reset(new SinglePressEventEater());
                    popupMenu->installEventFilter(eventEater.data());
                    stylusOffset += QPoint(10,10);
                }

                popupMenu->exec(QCursor::pos() + stylusOffset);
                popupMenu->clear();
            }
        }
```

#### AUTO 


```{c}
auto it = m_groupNameRows.keys().rbegin();
```

#### LAMBDA EXPRESSION 


```{c}
[this, initialTransformArgs, argsAreInitialized]() mutable {
        QRect srcRect;

        if (m_selection) {
            srcRect = m_selection->selectedExactRect();
        } else {
            srcRect = QRect();
            Q_FOREACH (KisNodeSP node, m_processedNodes) {
                // group layers may have a projection of layers
                // that are locked and will not be transformed
                if (node->inherits("KisGroupLayer")) continue;

                if (const KisTransformMask *mask = dynamic_cast<const KisTransformMask*>(node.data())) {
                    srcRect |= mask->sourceDataBounds();
                } else if (const KisSelectionMask *mask = dynamic_cast<const KisSelectionMask*>(node.data())) {
                    srcRect |= mask->selection()->selectedExactRect();
                } else {
                    srcRect |= node->exactBounds();
                }
            }
        }

        TransformTransactionProperties transaction(srcRect, &initialTransformArgs, m_rootNode, m_processedNodes);
        if (!argsAreInitialized) {
            initialTransformArgs = KisTransformUtils::resetArgsForMode(m_mode, m_filterId, transaction);
        }

        this->m_initialTransformArgs = initialTransformArgs;
        emit this->sigTransactionGenerated(transaction, initialTransformArgs, this);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(KoGamutMaskShape* shape: *shapeVector) {
        shape->paint(painter, viewConverter, rotation());
    }
```

#### AUTO 


```{c}
const auto schemeEntries = config->group(QStringLiteral("Shortcuts")).entryMap();
```

#### RANGE FOR STATEMENT 


```{c}
for (QString def : colorDefinitions) {
        if (def.toLower() == "currentcolor") {
            parsed = current;
        } else if (QColor::isValidColor(def)) {
            parsed.fromQColor(QColor(def));
        } else if (def.toLower().startsWith("rgb")) {
            QString parse = def.trimmed();
            QStringList colors = parse.split(',');
            QString r = colors[0].right((colors[0].length() - 4)).trimmed();
            QString g = colors[1].trimmed();
            QString b = colors[2].left((colors[2].length() - 1)).trimmed();

            if (r.contains('%')) {
                r = r.left(r.length() - 1);
                r = QString::number(int((double(255 * r.toDouble()) / 100.0)));
            }

            if (g.contains('%')) {
                g = g.left(g.length() - 1);
                g = QString::number(int((double(255 * g.toDouble()) / 100.0)));
            }

            if (b.contains('%')) {
                b = b.left(b.length() - 1);
                b = QString::number(int((double(255 * b.toDouble()) / 100.0)));
            }
            parsed.fromQColor(QColor(r.toInt(), g.toInt(), b.toInt()));

        } else if (def.toLower().startsWith("icc-color")) {
            QStringList values = def.split(",");
            QString iccprofilename = values.first().split("(").last();
            values.removeFirst();

            // svg11 docs say that searching the name should be caseinsentive.
            QStringList entry = QStringList(profileList.keys()).filter(iccprofilename, Qt::CaseInsensitive);
            if (entry.empty()) {
                continue;
            }
            const KoColorProfile *profile = profileList.value(entry.first());
            if (!profile) {
                continue;
            }
            QString colormodel = profile->colorModelID();
            QString depth = "F32";
            if (colormodel == LABAColorModelID.id()) {
                // let our xml handling deal with lab
                QVector<float> labV(3);
                for (int i = 0; i < values.size(); i++) {
                    if (i<labV.size()) {
                        QString entry = values.at(i);
                        entry = entry.split(")").first();
                        labV[i] = entry.toDouble();
                    }
                }
                QString lab = QString("<Lab space='%1' L='%2' a='%3' b='%4' />")
                        .arg(profile->name())
                        .arg(labV[0])
                        .arg(labV[1])
                        .arg(labV[2]);
                QDomDocument doc;
                doc.setContent(lab);
                parsed = KoColor::fromXML(doc.documentElement(), "U16");
                continue;
            } else if (colormodel == CMYKAColorModelID.id()) {
                depth = "U16";
            } else if (colormodel == XYZAColorModelID.id()) {
                // Inkscape decided to have X and Z go from 0 to 2, and I can't for the live of me figure out why.
                // So we're just not parsing XYZ.
                continue;
            }
            const KoColorSpace * cs = KoColorSpaceRegistry::instance()->colorSpace(colormodel, depth, profile);
            if (!cs) {
                continue;
            }
            parsed = KoColor(cs);
            QVector<float> channelValues(parsed.colorSpace()->channelCount());
            channelValues.fill(0.0);
            channelValues[parsed.colorSpace()->alphaPos()] = 1.0;
            for (int channel = 0; channel < values.size(); channel++) {
                int location = KoChannelInfo::displayPositionToChannelIndex(channel, parsed.colorSpace()->channels());
                QString entry = values.at(channel);
                entry = entry.split(")").first();
                channelValues[location] = entry.toFloat();
            }
            parsed.colorSpace()->fromNormalisedChannelsValue(parsed.data(), channelValues);
        }
    }
```

#### AUTO 


```{c}
const auto onionSkinOn = KisLayerPropertiesIcons::getProperty(KisLayerPropertiesIcons::onionSkins, true);
```

#### LAMBDA EXPRESSION 


```{c}
[](KisNodeSP node){
                KisPaintLayer* paintLayer = qobject_cast<KisPaintLayer*>(node.data());
                if (paintLayer && paintLayer->onionSkinEnabled()) {
                    paintLayer->flushOnionSkinCache();
                }
            }
```

#### AUTO 


```{c}
ORDER_BY(lhs.renderableType() == m_preferredRendererByUser,
                     rhs.renderableType() == m_preferredRendererByUser)
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    KisBrushSizeOptionProperties option;
                    option.readOptionSetting(prop->settings().data());

                    prop->setValue(int(option.brush_rotation));
                }
```

#### AUTO 


```{c}
auto frameIt = chain.rbegin();
```

#### AUTO 


```{c}
auto screens = QGuiApplication::screens();
```

#### LAMBDA EXPRESSION 


```{c}
[](const AuxiliaryPoint &a, const AuxiliaryPoint &b) {
                if (qFuzzyCompare(a.valueAtCorner, b.valueAtCorner)) {
                    if (qFuzzyCompare(a.valueAtCenter, b.valueAtCenter)) {
                        if (qFuzzyCompare(a.distanceToCenter, b.distanceToCenter)) {
                            if (qFuzzyCompare(a.distanceToCorner, b.distanceToCorner)) {
                                return a.microcellPixelIndex < b.microcellPixelIndex;
                            }
                            return a.distanceToCorner < b.distanceToCorner;
                        }
                        return a.distanceToCenter < b.distanceToCenter;
                    }
                    return a.valueAtCenter < b.valueAtCenter;
                }
                return a.valueAtCorner < b.valueAtCorner;
            }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto *i : m_lineList) {
        connect(this, SIGNAL(setGradient(bool)),  i, SLOT(setGradient(bool)),  Qt::UniqueConnection);
        connect(this, SIGNAL(setPatches(bool)),   i, SLOT(setPatches(bool)),   Qt::UniqueConnection);
        connect(this, SIGNAL(setLineHeight(int)), i, SLOT(setLineHeight(int)), Qt::UniqueConnection);
        connect(this, SIGNAL(setPatchCount(int)), i, SLOT(setPatchCount(int)), Qt::UniqueConnection);
    }
```

#### AUTO 


```{c}
auto result = endPatches();
```

#### AUTO 


```{c}
auto otherEnd = otherCommands.constEnd();
```

#### RANGE FOR STATEMENT 


```{c}
for (KActionCollection* collection: sortedCollections) {
        for (QAction* action: collection->actions()) {
            QString actionName = KLocalizedString::removeAcceleratorMarker(action->text());
            QStandardItem* item = new QStandardItem(action->icon(), actionName);
            QStandardItem* actionNameItem = new QStandardItem(action->objectName());
            m_model->appendRow(QList<QStandardItem*>() << item << actionNameItem);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[processResults](const QString& errMsg){
        processResults->finish = true;
        processResults->error = errMsg;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QPoint &point : enclosingPoints) {
        // Continue if the region under the point was already filled
        if (*(resultMask->pixel(point).data()) == MAX_SELECTED) {
            continue;
        }
        KisPixelSelectionSP mask = new KisPixelSelection(new KisSelectionDefaultBounds(resultMask));
        KisScanlineFill gc(referenceDevice, point, enclosingMaskRect);
        gc.setThreshold(q->fillThreshold());
        gc.setOpacitySpread(q->opacitySpread());
        // Use the enclosing mask as boundary so that we don't fill
        // potentially large regions in the outside
        gc.fillSelectionUntilColorOrTransparentWithBoundary(mask, color, enclosingMask);
        resultMask->applySelection(mask, SELECTION_ADD);
    }
```

#### AUTO 


```{c}
auto reqIt = noFilthyRequests.begin();
```

#### AUTO 


```{c}
auto animFunction =
        [this]() -> void
        {
            int animationDuration;
            qreal animationStartValue;

            if (!m_areControlsHidden) {
                if (m_showControlsAnimation.state() == QVariantAnimation::Running) {
                    m_showControlsAnimation.stop();
                    animationDuration =
                        static_cast<int>(std::round(m_showControlsAnimation.currentValue().toReal() * showControlsAnimationDuration));
                    animationStartValue = m_showControlsAnimation.currentValue().toReal();
                } else {
                    animationDuration = showControlsAnimationDuration;
                    animationStartValue = 1.0;
                }
            } else {
                animationDuration = 1;
                animationStartValue = 0.0;
            }

            m_areControlsHidden = true;
            m_showControlsAnimation.setStartValue(animationStartValue);
            m_showControlsAnimation.setEndValue(0.0);
            m_showControlsAnimation.setDuration(animationDuration);
            m_showControlsAnimation.start();
        };
```

#### AUTO 


```{c}
auto addHandleRectFunc =
        [&](const QPointF &pt) {
            handles.addRect(
                KisTransformUtils::handleRect(KisTransformUtils::handleVisualRadius,
                                              m_d->handlesTransform,
                                              m_d->transaction.originalRect(), pt)
                .translated(pt));
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &w : workspaces) {
        auto action = workspaceMenu->addAction(w->name());
        auto ds = w->dockerState();
        connect(action, &QAction::triggered, this, [=]() { m_this->restoreWorkspace(ds); });
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        /**
         * We must ensure that the currently selected subtree
         * has finished all its updates.
         */
        KisLayerUtils::forceAllDelayedNodesUpdate(m_rootNode);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const KisKeyframeChannel*, int time){
        if (m_d->canvas && m_d->canvas->image()) {
            KisImageAnimationInterface* animInterface = m_d->canvas->image()->animationInterface();
            KisConfig cfg(true);
            if (animInterface && cfg.adaptivePlaybackRange()) {
                KisTimeSpan desiredPlaybackRange = animInterface->fullClipRange();
                desiredPlaybackRange.include(time);
                animInterface->setFullClipRange(desiredPlaybackRange);
            }
        }
    }
```

#### AUTO 


```{c}
auto it = d->priorityEventFilter.begin();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &node : nodes) {
        node->setUserLocked(!isLocked);
    }
```

#### AUTO 


```{c}
const auto callPos = QCursor::pos();
```

#### LAMBDA EXPRESSION 


```{c}
[&](){
        if (isAllGray) {
            bool firstSample = true;
            int value = 0;
            for (int row = 0; row < image.height(); row++) {
                for (int column = 0; column < image.width(); column++) {
                    if (firstSample) {
                        value = qBlue(image.pixel(column, row));
                        firstSample = false;
                    } else {
                        if (value != qBlue(image.pixel(column, row))) {
                            return false;
                        }
                    }
                }
            }
            return true;
        }
        return false;
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr int maximumNumberOfSimplifiedPoints = 3;
```

#### CONST EXPRESSION 


```{c}
constexpr int minPatchSize = 128;
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        /**
             * We must request shape layers to rerender areas outside image bounds
             */
        KisLayerUtils::forceAllHiddenOriginalsUpdate(m_rootNode);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&t](QPointF &point) { return t.map(point); }
```

#### LAMBDA EXPRESSION 


```{c}
[&](QEvent::Type type) {
        QPointF emptyPos;
        qreal zero = 0.0;
        QTabletEvent e(type, emptyPos, emptyPos, 0, m_devices.at(m_currentDevice).currentPointerType,
                       zero, 0, 0, zero, zero, 0, Qt::NoModifier,
                       m_devices.at(m_currentDevice).uniqueId, Qt::NoButton, (Qt::MouseButtons)0);
        qApp->sendEvent(qApp, &e);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString & groupName : m_colorSet->getGroupNames()) {
        KisSwatchGroup *group = m_colorSet->getGroup(groupName);
        m_groups[groupName] = GroupInfoType(groupName, group->rowCount());
        m_original->groups[groupName] = GroupInfoType(groupName, group->rowCount());
        m_ui->cbxGroup->addItem(groupName);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&lastKeyframeTime] (KisNodeSP node)
    {
        if (node->isAnimated() && node->supportsKeyframeChannel(KisKeyframeChannel::Raster.id())) {
            KisKeyframeChannel* channel = node->getKeyframeChannel(KisKeyframeChannel::Raster.id(), false);

            if (!channel) {
                return;
            }

            lastKeyframeTime = qMax(channel->lastKeyframeTime(), lastKeyframeTime);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &w : workspaces) {
        auto action = workspaceMenu->addAction(w->name());
        connect(action, &QAction::triggered, this, [=]() {
            m_this->restoreWorkspace(w);
        });
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    GridOption option;
                    option.readOptionSetting(prop->settings().data());
                    option.grid_division_level = prop->value().toInt();
                    option.writeOptionSetting(prop->settings().data());
                }
```

#### AUTO 


```{c}
auto resource = new KisWindowLayoutResource(filename);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KisMetaData::Entry &entry : *store) {
        try {
            dbgMetaData << "Trying to save: " << entry.name() << " of " << entry.schema()->prefix() << ":"
                        << entry.schema()->uri();
            QString exivKey;
            if (entry.schema()->uri() == KisMetaData::Schema::TIFFSchemaUri) {
                exivKey = "Exif.Image." + entry.name();
            } else if (entry.schema()->uri()
                       == KisMetaData::Schema::EXIFSchemaUri) { // Distinguish between exif and gps
                if (entry.name().left(3) == "GPS") {
                    exivKey = "Exif.GPSInfo." + entry.name();
                } else {
                    exivKey = "Exif.Photo." + entry.name();
                }
            } else if (entry.schema()->uri() == KisMetaData::Schema::DublinCoreSchemaUri) {
                if (entry.name() == "description") {
                    exivKey = "Exif.Image.ImageDescription";
                } else if (entry.name() == "creator") {
                    exivKey = "Exif.Image.Artist";
                } else if (entry.name() == "rights") {
                    exivKey = "Exif.Image.Copyright";
                }
            } else if (entry.schema()->uri() == KisMetaData::Schema::XMPSchemaUri) {
                if (entry.name() == "ModifyDate") {
                    exivKey = "Exif.Image.DateTime";
                } else if (entry.name() == "CreatorTool") {
                    exivKey = "Exif.Image.Software";
                }
            } else if (entry.schema()->uri() == KisMetaData::Schema::MakerNoteSchemaUri) {
                if (entry.name() == "RawData") {
                    exivKey = "Exif.Photo.MakerNote";
                }
            }
            dbgMetaData << "Saving " << entry.name() << " to " << exivKey;
            if (exivKey.isEmpty()) {
                dbgMetaData << entry.qualifiedName() << " is unsavable to EXIF";
            } else {
                Exiv2::ExifKey exifKey(qPrintable(exivKey));
                Exiv2::Value *v = 0;
                if (exivKey == "Exif.Photo.ExifVersion" || exivKey == "Exif.Photo.FlashpixVersion") {
                    v = kmdValueToExifVersion(entry.value());
                } else if (exivKey == "Exif.Photo.FileSource") {
                    char s[] = {0x03};
                    v = new Exiv2::DataValue((const Exiv2::byte *)s, 1);
                } else if (exivKey == "Exif.Photo.SceneType") {
                    char s[] = {0x01};
                    v = new Exiv2::DataValue((const Exiv2::byte *)s, 1);
                } else if (exivKey == "Exif.Photo.ComponentsConfiguration") {
                    v = kmdIntOrderedArrayToExifArray(entry.value());
                } else if (exivKey == "Exif.Image.Artist") { // load as dc:creator
                    KisMetaData::Value creator = entry.value();
                    if (entry.value().asArray().size() > 0) {
                        creator = entry.value().asArray()[0];
                    }
#if !EXIV2_TEST_VERSION(0, 21, 0)
                    v = kmdValueToExivValue(creator, Exiv2::ExifTags::tagType(exifKey.tag(), exifKey.ifdId()));
#else
                    v = kmdValueToExivValue(creator, exifKey.defaultTypeId());
#endif
                } else if (exivKey == "Exif.Photo.OECF") {
                    v = kmdOECFStructureToExifOECF(entry.value());
                } else if (exivKey == "Exif.Photo.DeviceSettingDescription") {
                    v = deviceSettingDescriptionKMDToExif(entry.value());
                } else if (exivKey == "Exif.Photo.CFAPattern") {
                    v = cfaPatternKMDToExif(entry.value());
                } else if (exivKey == "Exif.Photo.Flash") {
                    v = flashKMDToExif(entry.value());
                } else if (exivKey == "Exif.Photo.UserComment") {
                    Q_ASSERT(entry.value().type() == KisMetaData::Value::LangArray);
                    QMap<QString, KisMetaData::Value> langArr = entry.value().asLangArray();
                    if (langArr.contains("x-default")) {
#if !EXIV2_TEST_VERSION(0, 21, 0)
                        v = kmdValueToExivValue(langArr.value("x-default"),
                                                Exiv2::ExifTags::tagType(exifKey.tag(), exifKey.ifdId()));
#else
                        v = kmdValueToExivValue(langArr.value("x-default"), exifKey.defaultTypeId());
#endif
                    } else if (langArr.size() > 0) {
#if !EXIV2_TEST_VERSION(0, 21, 0)
                        v = kmdValueToExivValue(langArr.begin().value(),
                                                Exiv2::ExifTags::tagType(exifKey.tag(), exifKey.ifdId()));
#else
                        v = kmdValueToExivValue(langArr.begin().value(), exifKey.defaultTypeId());
#endif
                    }
                } else {
                    dbgMetaData << exifKey.tag();
#if !EXIV2_TEST_VERSION(0, 21, 0)
                    v = kmdValueToExivValue(entry.value(), Exiv2::ExifTags::tagType(exifKey.tag(), exifKey.ifdId()));
#else
                    v = kmdValueToExivValue(entry.value(), exifKey.defaultTypeId());
#endif
                }
                if (v && v->typeId() != Exiv2::invalidTypeId) {
                    dbgMetaData << "Saving key" << exivKey << " of KMD value" << entry.value();
                    exifData.add(exifKey, v);
                } else {
                    dbgMetaData << "No exif value was created for" << entry.qualifiedName() << " as"
                                << exivKey; // << " of KMD value" << entry.value();
                }
            }
        } catch (Exiv2::AnyError &e) {
            dbgMetaData << "exiv error " << e.what();
        }
    }
```

#### AUTO 


```{c}
auto workspaces = KisResourceServerProvider::instance()->workspaceServer(false)->resources();
```

#### AUTO 


```{c}
auto strNextChar = std::next(str);
```

#### RANGE FOR STATEMENT 


```{c}
for (Private::Column &c : d->colorMatrix) {
        for (int k : c.keys()) {
            if (k >= newRowCount) {
                c.remove(k);
                d->colorCount--;
            }
        }
    }
```

#### AUTO 


```{c}
auto it = m_d->newFrames.upperBound(range.start());
```

#### AUTO 


```{c}
auto insertedIt = m_columns.insert(next(it), absProportinalT);
```

#### AUTO 


```{c}
auto checkAndSet = [this](KoCanvasResource::CanvasResourceId res,
                              KoFlake::FillVariant var, KoColor &color) {
        if (!d->overriddenColorFromProvider[var]) {
            d->overriddenColorFromProvider[var] =
                d->canvas->resourceManager()->resource(res).value<KoColor>();
        }

        /**
         * Don't let opacity leak to our resource manager system
         *
         * NOTE: theoretically, we could guarantee it on a level of the
         * resource manager itself,
         */
        color.setOpacity(OPACITY_OPAQUE_U8);
        d->canvas->resourceManager()->setResource(res, QVariant::fromValue(color));
    };
```

#### CONST EXPRESSION 


```{c}
static constexpr double touchDragDistanceSquared {touchDragDistance * touchDragDistance};
```

#### AUTO 


```{c}
const auto srcTileRowStride =
                (static_cast<size_t>(tileWidth) - columnsToWork) * srcPixelSize;
```

#### AUTO 


```{c}
auto fetchFunc =
        [&result, mode, root] (KisNodeSP node) {
        if (node->isEditable(node == root) &&
                (!node->inherits("KisShapeLayer") || mode == ToolTransformArgs::FREE_TRANSFORM) &&
                !node->inherits("KisFileLayer") &&
                !node->inherits("KisColorizeMask") &&
                (!node->inherits("KisTransformMask") || node == root)) {

                result << node;
            }
    };
```

#### AUTO 


```{c}
_cimg_constructor_cpp11(repeat_values)
```

#### LAMBDA EXPRESSION 


```{c}
[this, name] (KoResourceSP res) {
                                   return res->resourceType().first == this->m_resourceType &&
                                       res->name() == name;
                               }
```

#### RANGE FOR STATEMENT 


```{c}
for (int channel : channels) {
        if (!histogramChannelShapeInfo.contains(channel)) {
            continue;
        }

        const HistogramShapeInfo &info = histogramChannelShapeInfo[channel];
        Private::paintHistogramShape(
            image,
            logarithmic ? info.logarithmicHistogram : info.linearHistogram,
            logarithmic
                ? scale * std::log(info.highest + 1.0) / std::log(overallHighest + 1.0)
                : scale * info.highest / overallHighest,
            info.color.isValid() ? info.color : defaultColor,
            info.compositionMode
        );
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const KisKeyframeChannel *channel, int time) {
        channel->sigChannelUpdated(
                    channel->affectedFrames(time),
                    channel->affectedRect(time)
                    );
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            QVector<KisStrokeJobData*> lodSyncJobs;
            KisSyncLodCacheStrokeStrategy::createJobsData(lodSyncJobs,
                                                          m_s->imageRoot,
                                                          m_s->previewLevelOfDetail,
                                                          m_s->devicesCacheHash.values() +
                                                          m_s->transformMaskCacheHash.values());

            for (auto it = lodSyncJobs.begin(); it != lodSyncJobs.end(); ++it) {
                (*it)->setLevelOfDetailOverride(m_s->previewLevelOfDetail);
            }

            addMutatedJobs(lodSyncJobs);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KoColorSet *palette : m_d->doc->paletteList()) {
        if (!palette->isGlobal()) {
            if (!store->open(m_d->imageName + PALETTE_PATH + palette->filename())) {
                m_d->errorMessages << i18n("could not save palettes");
                return false;
            }
            QByteArray ba = palette->toByteArray();
            if (!ba.isEmpty()) {
                store->write(ba);
            } else {
                qWarning() << "Cannot save the palette to a byte array:" << palette->name();
            }
            store->close();
            res = true;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KoShape *shape) {
        m_originalColor = canvas()->resourceManager()->foregroundColor();
        KoShapeFillWrapper wrapper(shape, KoFlake::Fill);
        KoColor color;
        color.fromQColor(wrapper.color());
        canvas()->resourceManager()->setForegroundColor(color);
    }
```

#### AUTO 


```{c}
auto it = lodSyncJobs.begin();
```

#### AUTO 


```{c}
const auto &child
```

#### AUTO 


```{c}
inline auto set_one(const batch<T, A> &src, const batch_bool<T, A> &mask) noexcept;
```

#### LAMBDA EXPRESSION 


```{c}
[&range, time] (const KisNode *node) {
            if (node->visible()) {
                range |= calculateNodeIdenticalFrames(node, time);
            }
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr int removeStopDistance{32};
```

#### LAMBDA EXPRESSION 


```{c}
[frames]() {
            QScopedPointer<KUndo2Command> cmd(new KUndo2Command());

            foreach (const FrameItem &frameItem, frames) {
                KisRasterKeyframeChannel *rasterChan = dynamic_cast<KisRasterKeyframeChannel*>(frameItem.node->getKeyframeChannel(frameItem.channel));
                if (!rasterChan) {
                    continue;
                }

                rasterChan->makeUnique(frameItem.time, cmd.data());
            }

            return cmd.take();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&linearizedNodes, &rhs, this](KisNodeSP node) {
            KisNodeSP refNode = linearizedNodes.dequeue();
            if (rhs.d->preActivatedNode.data() == refNode.data()) {
                d->preActivatedNode = node;
            }
        }
```

#### AUTO 


```{c}
auto srcPtrValue = reinterpret_cast<uintptr_t>(src);
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
            prop->settings()->setPaintOpFlow(prop->value().toReal());
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, i](T *d) { return !(std::abs(d[this->poses()[i]]) < std::numeric_limits<T>::epsilon()); }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractButton *button : m_d->colorButtonGroup->buttons()) {
        newLayout->addWidget(button);
    }
```

#### AUTO 


```{c}
auto it = uniqueKeyframesInSelection.begin();
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &name) {
            const QString fileName = m_context.xmlBaseDir() + '/' + name;
            QFile file(fileName);
            if (!file.exists()) {
                return QByteArray();
            }
            file.open(QIODevice::ReadOnly);
            return file.readAll();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (KoResource *r : m_rServer->resources()) {
        KoColorSet *c = static_cast<KoColorSet*>(r);
        if (!c->isGlobal()) {
            m_rServer->removeResourceFromServer(c);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(KoGamutMaskShape* shape: *shapeVector) {
        if (shape->coordIsClear(coord, viewConverter, rotation()) == true) {
            return true;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[state, &dab, direction, skipMirrorPixels] () {
                state->painter->mirrorDab(direction, &dab, skipMirrorPixels);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QTouchEvent::TouchPoint &touchPoint : te->touchPoints()) {
                    if (touchPoint.id() == m_touchPointId) {
                        if (touchPoint.state() != Qt::TouchPointReleased) {
                            return true;
                        }
                        break;
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (QUrl url : urls) {

                    if (!url.isLocalFile()) {
                        // download the file and substitute the url
                        KisRemoteFileFetcher fetcher;
                        tmp = new QTemporaryFile();
                        tmp->setAutoRemove(true);
                        if (!fetcher.fetchFile(url, tmp)) {
                            qWarning() << "Fetching" << url << "failed";
                            continue;
                        }
                        url = url.fromLocalFile(tmp->fileName());
                    }
                    if (url.isLocalFile()) {
                        if (action == insertAsNewLayer || action == insertManyLayers) {
                            d->viewManager->imageManager()->importImage(url);
                            activateWindow();
                        }
                        else if (action == insertAsNewFileLayer || action == insertManyFileLayers) {
                            KisNodeCommandsAdapter adapter(viewManager());
                            QFileInfo fileInfo(url.toLocalFile());
                            KisFileLayer *fileLayer = new KisFileLayer(image(), "", url.toLocalFile(),
                                                                       KisFileLayer::None, fileInfo.fileName(), OPACITY_OPAQUE_U8);
                            adapter.addNode(fileLayer, viewManager()->activeNode()->parent(), viewManager()->activeNode());
                        }
                        else if (action == openInNewDocument || action == openManyDocuments) {
                            if (mainWindow()) {
                                mainWindow()->openDocument(url.toLocalFile(), KisMainWindow::None);
                            }
                        }
                        else if (action == insertAsReferenceImage || action == insertAsReferenceImages) {
                            auto *reference = KisReferenceImage::fromFile(url.toLocalFile(), d->viewConverter, this);

                            if (reference) {
                                reference->setPosition(d->viewConverter.imageToDocument(cursorPos));
                                d->referenceImagesDecoration->addReferenceImage(reference);

                                KoToolManager::instance()->switchToolRequested("ToolReferenceImages");
                            }
                        }

                    }
                    delete tmp;
                    tmp = 0;
                }
```

#### LAMBDA EXPRESSION 


```{c}
[](KisNodeSP p) {
        bool onionSkinProp = p->nodeProperties().boolProperty("onionskin", false);
        return onionSkinProp;
    }
```

#### AUTO 


```{c}
auto *cfg = new KisCrossChannelFilterConfiguration(m_virtualChannels.count(), m_dev->colorSpace(), KisGlobalResourcesInterface::instance());
```

#### AUTO 


```{c}
auto strIt = str.cbegin();
```

#### AUTO 


```{c}
auto it = std::next(m_d->overlays.begin());
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractButton *button : m_d->colorButtonGroup->buttons()) {
            button->removeEventFilter(m_d->dragFilter);
        }
```

#### AUTO 


```{c}
auto shadowRect = buttonRect.translated(0, 1);
```

#### AUTO 


```{c}
auto testBadPixel = [cs, op, srcPtr, dstPtr, numTestablePixels] (int badPixelPos,
            const quint8 *goodSrc,
            const quint8 *goodDst,
            const quint8 *badSrc,
            const quint8 *badDst,
            quint8 opacity,
            quint8 *expectedDst) {

        quint8 *badPixelDstPtr = dstPtr + badPixelPos * cs->pixelSize();

        for (int i = 0; i < numTestablePixels; i++) {
            if (i != badPixelPos) {
                memcpy(srcPtr + cs->pixelSize() * i, goodSrc, cs->pixelSize());
                memcpy(dstPtr + cs->pixelSize() * i, goodDst, cs->pixelSize());
            } else {
                memcpy(srcPtr + cs->pixelSize() * i, badSrc, cs->pixelSize());
                memcpy(dstPtr + cs->pixelSize() * i, badDst, cs->pixelSize());
            }
        }

        op->composite(dstPtr, numTestablePixels * cs->pixelSize(),
                      srcPtr, numTestablePixels * cs->pixelSize(),
                      0, 0,
                      1, numTestablePixels, opacity);

        if (memcmp(badPixelDstPtr, expectedDst, cs->pixelSize()) != 0) {
            qDebug() << "badPixelPos" << badPixelPos;
            qDebug() << "opacity" << opacity;
            qDebug() << "oriS" << badSrc[0] << badSrc[1] << badSrc[2] << badSrc[3];
            qDebug() << "oriD" << badDst[0] << badDst[1] << badDst[2] << badDst[3];
            qDebug() << "expD" << expectedDst[0] << expectedDst[1] << expectedDst[2] << expectedDst[3];
            qDebug() << "dst1" << badPixelDstPtr[0] << badPixelDstPtr[1] << badPixelDstPtr[2] << badPixelDstPtr[3];
#if HAVE_XSIMD
            QFAIL("Failed to compose pixels");
#else
            qWarning() << "Skipping failed test when xsimd library is not used";
#endif
        }
    };
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                KisDuplicateOptionProperties option;
                option.readOptionSetting(prop->settings().data());
                option.duplicate_move_source_point = prop->value().toBool();
                option.writeOptionSetting(prop->settings().data());
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (KisFilterConfigurationSP filterConfig : m_generatorConfigurations) {
        resourcesList += filterConfig->linkedResources(globalResourcesInterface);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](double x)
            {
                return 2.0 * x;
            }
```

#### AUTO 


```{c}
const auto pos = y * gmicImage.m_width + x;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QGradientStop &qGradientStop : gradient) {
            KoGradientStop stop;
            stop.type = COLORSTOP;
            stop.position = qGradientStop.first;
            stop.color = KoColor(qGradientStop.second, stopGradient->colorSpace());
            stops << stop;
        }
```

#### AUTO 


```{c}
auto *pluginBase = factory->create<QObject>(this);
```

#### CONST EXPRESSION 


```{c}
static constexpr float MAX_CHANNEL_AB = +127;
```

#### RANGE FOR STATEMENT 


```{c}
for (QUrl url : urls) {

                    if (!url.isLocalFile()) {
                        // download the file and substitute the url
                        KisRemoteFileFetcher fetcher;
                        tmp = new QTemporaryFile();
                        tmp->setAutoRemove(true);
                        if (!fetcher.fetchFile(url, tmp)) {
                            qWarning() << "Fetching" << url << "failed";
                            continue;
                        }
                        url = url.fromLocalFile(tmp->fileName());
                    }
                    if (url.isLocalFile()) {
                        if (action == insertAsNewLayer || action == insertManyLayers) {
                            d->viewManager->imageManager()->importImage(url);
                            activateWindow();
                        }
                        else if (action == insertAsNewFileLayer || action == insertManyFileLayers) {
                            KisNodeCommandsAdapter adapter(viewManager());
                            KisFileLayer *fileLayer = new KisFileLayer(image(), "", url.toLocalFile(),
                                                                       KisFileLayer::None, image()->nextLayerName(), OPACITY_OPAQUE_U8);
                            adapter.addNode(fileLayer, viewManager()->activeNode()->parent(), viewManager()->activeNode());
                        }
                        else if (action == openInNewDocument || action == openManyDocuments) {
                            if (mainWindow()) {
                                mainWindow()->openDocument(url, KisMainWindow::None);
                            }
                        }
                        else if (action == insertAsReferenceImage || action == insertAsReferenceImages) {
                            auto *reference = KisReferenceImage::fromFile(url.toLocalFile(), d->viewConverter, this);

                            if (reference) {
                                reference->setPosition(d->viewConverter.imageToDocument(cursorPos));
                                d->referenceImagesDecoration->addReferenceImage(reference);

                                KoToolManager::instance()->switchToolRequested("ToolReferenceImages");
                            }
                        }

                    }
                    delete tmp;
                    tmp = 0;
                }
```

#### AUTO 


```{c}
auto windowElement = element.firstChildElement("window");
```

#### LAMBDA EXPRESSION 


```{c}
[](const KisKeyframeChannel *channel, int time) {
        const KisScalarKeyframeChannel* chan = dynamic_cast<const KisScalarKeyframeChannel*>(channel);
        KIS_SAFE_ASSERT_RECOVER_RETURN(chan);
        chan->sigChannelUpdated(
                    chan->affectedFrames(time),
                    chan->affectedRect(time)
                    );
    }
```

#### AUTO 


```{c}
auto *frame = dynamic_cast<KisRasterKeyframeChannel *>(channel);
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
                    const auto nextKeyframe = frames->nextKeyframeTime(i);
                    if (nextKeyframe == -1) {
                        return static_cast<uint32_t>(
                            image->animationInterface()->fullClipRange().end()
                            - i + 1);
                    } else {
                        return static_cast<uint32_t>(frames->nextKeyframeTime(i) - i);
                    }
                }
```

#### AUTO 


```{c}
auto resourceSourceAdapter = resourcesInterface->source<KisBrush>(ResourceType::Brushes);
```

#### LAMBDA EXPRESSION 


```{c}
[dabRects] (const QRect &rc) {
            Q_FOREACH (const QRect &dab, dabRects) {
                if (dab.intersects(rc)) {
                    return true;
                }
            }
            return false;
        }
```

#### AUTO 


```{c}
auto it = originalInfoObjects.constBegin();
```

#### AUTO 


```{c}
const auto &urls = data.urls();
```

#### AUTO 


```{c}
const auto pos = y * gmicImage._width + x;
```

#### AUTO 


```{c}
auto it = m_rects.begin();
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool){
        if (m_d->canvas) {
            m_d->canvas->animationPlayer()->nextMatchingKeyframe();
        }
    }
```

#### AUTO 


```{c}
auto action = workspaceMenu->addAction(w->name());
```

#### AUTO 


```{c}
const auto width = static_cast<size_t>(gmicImage._width);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Handle &handle : sortedHandles_) {
        const int handleX = static_cast<int>(qRound(handle.position * static_cast<qreal>(gradientRect_.width() - 1))) + halfHandleWidth;
        const QRect handleRect(handleX - halfHandleWidth, gradientRect_.bottom() + 1, handleWidth, handleHeight);
        paintHandle(painter, handleRect, handle);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    ParticleOption option;
                    option.readOptionSetting(prop->settings().data());
                    option.particle_scale_y = prop->value().toReal();
                    option.writeOptionSetting(prop->settings().data());
                }
```

#### LAMBDA EXPRESSION 


```{c}
[] (QString a) {
        return a == "testpattern.png" || a == "testpattern.0000.png";
    }
```

#### LAMBDA EXPRESSION 


```{c}
[] (KisNodeSP node) {
            KisDelayedUpdateNodeInterface *delayedUpdate =
                    dynamic_cast<KisDelayedUpdateNodeInterface*>(node.data());
            if (delayedUpdate) {
                delayedUpdate->forceUpdateTimedNode();
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const KisTimeSpan&, const QRect&){
            this->clearChangedFlag();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (KisBezierTransformMesh::segment_iterator it,
                    qreal t,
                    const QPointF &offset) {

            QPointF offsetP1;
            QPointF offsetP2;

            std::tie(offsetP1, offsetP2) =
                KisBezierUtils::offsetSegment(t, offset);


            smartMoveControl(*m_d->currentArgs.meshTransform(), it.itP1().controlIndex(), offsetP1, KisSmartMoveMeshControlMode::MoveSymmetricLock, m_d->currentArgs.meshScaleHandles());
            smartMoveControl(*m_d->currentArgs.meshTransform(), it.itP2().controlIndex(), offsetP2, KisSmartMoveMeshControlMode::MoveSymmetricLock, m_d->currentArgs.meshScaleHandles());
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](KisNodeSP node) -> bool {
        auto *paintLayer = dynamic_cast<KisPaintLayer *>(node.data());
        return paintLayer && paintLayer->visible(false);
    }
```

#### AUTO 


```{c}
const auto rowsToWork = qMin(numContiguousImageRows, rowsRemaining);
```

#### RANGE FOR STATEMENT 


```{c}
for (const SwatchInfoType &info : group->infoList()) {
        const KoColorProfile *profile = info.swatch.color().colorSpace()->profile();
        // Only save non-builtin profiles.=
        if (!profile->fileName().isEmpty()) {
            colorSetSet.insert(info.swatch.color().colorSpace());
        }
        QDomElement swatchEle = doc.createElement(KPL_SWATCH_TAG);
        swatchEle.setAttribute(KPL_SWATCH_NAME_ATTR, info.swatch.name());
        swatchEle.setAttribute(KPL_SWATCH_ID_ATTR, info.swatch.id());
        swatchEle.setAttribute(KPL_SWATCH_SPOT_ATTR, info.swatch.spotColor() ? "true" : "false");
        swatchEle.setAttribute(KPL_SWATCH_BITDEPTH_ATTR, info.swatch.color().colorSpace()->colorDepthId().id());
        info.swatch.color().toXML(doc, swatchEle);

        QDomElement positionEle = doc.createElement(KPL_SWATCH_POS_TAG);
        positionEle.setAttribute(KPL_SWATCH_ROW_ATTR, info.row);
        positionEle.setAttribute(KPL_SWATCH_COL_ATTR, info.column);
        swatchEle.appendChild(positionEle);

        groupEle.appendChild(swatchEle);
    }
```

#### AUTO 


```{c}
ORDER_BY(!isHDRFormat(lhs.format), !isHDRFormat(rhs.format))
```

#### RANGE FOR STATEMENT 


```{c}
for (QString attr : attributes) {
        double mainValue = elements.first().attribute(attr).toDouble();
        for (QDomElement el: elements) {
            double compare = el.attribute(attr).toDouble();
            QVERIFY2(fabs(mainValue - compare) < 0.01
                     , QString("XML CMYK parsing has too high of a difference when roundtripping channel %1: %2")
                     .arg(attr).arg(mainValue - compare).toLatin1());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QPoint &point : enclosingPoints) {
        // Continue if the region under the point was already filled
        if (*(resultMask->pixel(point).data()) == MAX_SELECTED) {
            continue;
        }
        KisPixelSelectionSP mask = new KisPixelSelection(new KisSelectionDefaultBounds(resultMask));
        KisScanlineFill gc(referenceDevice, point, enclosingMaskRect);
        gc.setThreshold(q->fillThreshold());
        gc.setOpacitySpread(q->opacitySpread());
        // Use the enclosing mask as boundary so that we don't fill
        // potentially large regions on the outside
        gc.fillSelectionWithBoundary(mask, enclosingMask);
        resultMask->applySelection(mask, SELECTION_ADD);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool){
            if (!m_canvas) return;

            QModelIndex currentSelection = m_ui->sceneView->currentIndex();
            if (currentSelection.parent().isValid()) {
                currentSelection = currentSelection.parent();
            }

            m_storyboardModel->insertItem(currentSelection, true);
        }
```

#### AUTO 


```{c}
auto list = shortcutString.split(QLatin1Char('+'), Qt::SkipEmptyParts);
```

#### AUTO 


```{c}
auto layer = referenceImagesLayer();
```

#### RANGE FOR STATEMENT 


```{c}
for (const KoColorSetSP palette : m_d->doc->paletteList()) {
        qDebug() << "saving palette..." << palette->storageLocation() << palette->filename();
        // Ensure stored palettes are KPL.
        palette->setPaletteType(KoColorSet::KPL);
        if (!store->open(m_d->imageName + PALETTE_PATH + palette->filename())) {
            m_d->errorMessages << i18n("could not save palettes");
            return false;
        }
        QByteArray ba = palette->toByteArray();
        if (!ba.isEmpty()) {
            store->write(ba);
        } else {
            qWarning() << "Cannot save the palette to a byte array:" << palette->name();
        }
        store->close();
        res = true;
    }
```

#### AUTO 


```{c}
auto it = rhs.m_abrBrushes.begin();
```

#### AUTO 


```{c}
auto debugTabletEvent = [&](int i) {
        if (KisTabletDebugger::instance()->debugEnabled()) {
            QString pre = QString("[BLOCKED %1:]").arg(i);
            QTabletEvent *ev = static_cast<QTabletEvent*>(event);
            dbgTablet << KisTabletDebugger::instance()->eventToString(*ev, pre);
        }
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (KisFrameDataSerializer::FrameTile &tile : frame.frameTiles) {
        const int numPixels = tile.rect.width() * tile.rect.height();
        qint32 *pixelPtr = reinterpret_cast<qint32*>(tile.data.data());

        for (int j = 0; j < numPixels; j++) {
            if (rnd.generateNormalized() < portion) {
                (*pixelPtr) = 0;
            }

            pixelPtr++;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QItemSelection& newSelection, const QItemSelection& oldSelection) {
            if (newSelection.count() == 0) {
                activeDataChanged(QModelIndex());
            } else {
                activeDataChanged(selectionModel()->currentIndex());
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[] (quint8 value) {
                    return value < 255 ? 0 : value;
                }
```

#### AUTO 


```{c}
auto m = KisQMicImageSP::create(name, resultRect.width(), resultRect.height(), 4);
```

#### AUTO 


```{c}
auto root = forest.insert(childBegin(forest), 0);
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    prop->setValue(prop->settings()->paintOpOpacity());
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QJsonValueRef &streamItemRef : ffprobeStreams) {
            QJsonObject streamItemObj = streamItemRef.toObject();

            if ( streamItemObj["codec_type"].toString() == "video" ) {
                videoInfoData.stream = streamItemObj["index"].toInt();
                break;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {
            m_d->heightMap = new KisPaintDevice(*m_d->filteredSource);
        }
```

#### AUTO 


```{c}
auto it = indexes.begin();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto occurrence : errors) {
            QString message = ErrorMessages::message(occurrence.error);
            for (auto arg : occurrence.ids) {
                message = message.arg(QString::fromStdString(arg));
            }
            m_widget->txtEditor->addError(occurrence.startPos, occurrence.endPos, message);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractButton *b : m_d->buttonGroup->buttons()) {
        list.append(dynamic_cast<KoGroupButton *>(b));
    }
```

#### AUTO 


```{c}
auto k = m_channelFFT.begin();
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    KisBrushBasedPaintOpSettings *s =
                        dynamic_cast<KisBrushBasedPaintOpSettings*>(prop->settings().data());

                    prop->setValue(s->autoSpacingActive());
                }
```

#### LAMBDA EXPRESSION 


```{c}
[&](QTabletEvent::Type t){
            // First, try sending a tablet event.
            QTabletEvent e(t, localPosDip, globalPosDip, currentDevice, currentPointerType,
                           pressureNew, tiltX, tiltY, tangentialPressure, rotation, z,
                           keyboardModifiers, tabletData.uniqueId, button, buttons);
            qApp->sendEvent(w, &e);

            if (e.isAccepted()) {
                globalEventEater->activate();
            }
            else {
                // Turn off eventEater send a synthetic mouse event.
                globalEventEater->deactivate();
                QMouseEvent m(mouseEventType(t), localPosDip, button, buttons, keyboardModifiers);
                qApp->sendEvent(w, &e);
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    CurveOption option;
                    option.readOptionSetting(prop->settings().data());
                    option.curve_line_width = prop->value().toInt();
                    option.writeOptionSetting(prop->settings().data());
                }
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    HatchingOption option;
                    option.readOptionSetting(prop->settings().data());
                    prop->setValue(option.separation);
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this, scroller](){
                slotUpdateInfiniteFramesCount();
                scroller->resendPrepareEvent();
            }
```

#### LAMBDA EXPRESSION 


```{c}
[=](bool checked) {
            KisConfig cfg(false);
            // It is safe to modify `enabledNewsLangs` here, because the slots
            // are called synchronously on the UI thread so there is no need
            // for explicit synchronization.
            if (checked) {
                enabledNewsLangs->insert(QString(code));
            } else {
                enabledNewsLangs->remove(QString(code));
            }
            cfg.writeList(newsLangConfigName, enabledNewsLangs->toList());
        }
```

#### CONST EXPRESSION 


```{c}
constexpr int SPLASH_HEIGHT_ABOUT = 320;
```

#### AUTO 


```{c}
auto uploadColorToResourceManager = [this](KoShape *shape) {
        m_originalColor = canvas()->resourceManager()->foregroundColor();
        KoShapeFillWrapper wrapper(shape, KoFlake::Fill);
        KoColor color;
        color.fromQColor(wrapper.color());
        canvas()->resourceManager()->setForegroundColor(color);
    };
```

#### LAMBDA EXPRESSION 


```{c}
[&nodesToRemove] (KisNodeDummy *dummy) {
                    nodesToRemove << dummy->node();
                }
```

#### AUTO 


```{c}
auto it = forest.insert(childBegin(root), 4);
```

#### AUTO 


```{c}
auto it = d->points.begin();
```

#### RANGE FOR STATEMENT 


```{c}
for (QStandardItem *item : items) {
        m_recentFilesModel.appendRow(item);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool){
        if (m_d->canvas) {
            m_d->canvas->animationPlayer()->previousFrame();
        }
    }
```

#### AUTO 


```{c}
const auto plusRect = option.fontMetrics.boundingRect(QLatin1Char('+'));
```

#### CONST EXPRESSION 


```{c}
static constexpr int showControlsTimerDuration {500};
```

#### CONST EXPRESSION 


```{c}
static constexpr double touchDragDistanceSquared{touchDragDistance * touchDragDistance};
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    KisSprayProperties option;
                    option.readOptionSetting(prop->settings().data());
                    prop->setValue(option.coverage);
                }
```

#### AUTO 


```{c}
const auto dataIdx = dataX + dataY * width;
```

#### AUTO 


```{c}
const auto height = static_cast<size_t>(gmicImage._height);
```

#### LAMBDA EXPRESSION 


```{c}
[tag](KisTagSP tagFromResource) { return tagFromResource->url() == tag->url(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QAction *action, const QKeySequence &seq) {
            if (action != m_action) {
                return;
            }
            setKeySequence(seq);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &resname : names) {
        if (QFile(resname).exists()) {
            QIcon icon(resname);
            s_icons.insert(icon.cacheKey(), name);
#if defined CACHE_ICONS
            s_cache.insert(name, icon);
#endif
            return icon;
        }
    }
```

#### AUTO 


```{c}
auto getFont = [&context] () {
        return context.currentGC()->textProperties.generateFont();
    };
```

#### AUTO 


```{c}
auto row
```

#### AUTO 


```{c}
auto end = sharedData->end();
```

#### AUTO 


```{c}
auto *addLayerCmd = new KisImageLayerAddCommand(d->m_image, paintLayer, parent, aboveThis, true, true);
```

#### AUTO 


```{c}
const auto t2 = batch<T, A>::load(srcPtr + batch<T, A>::size, U{});
```

#### AUTO 


```{c}
auto nodeIt = m_d->currentArgs.meshTransform()->find(index);
```

#### LAMBDA EXPRESSION 


```{c}
[this, index, Model] {Model->insertItem(index, true); }
```

#### RANGE FOR STATEMENT 


```{c}
for (QUrl url : urls) {

                    QScopedPointer<QTemporaryFile> tmp(new QTemporaryFile());
                    tmp->setAutoRemove(true);

                    if (!url.isLocalFile()) {
                        // download the file and substitute the url
                        KisRemoteFileFetcher fetcher;

                        if (!fetcher.fetchFile(url, tmp.data())) {
                            qWarning() << "Fetching" << url << "failed";
                            continue;
                        }
                        url = url.fromLocalFile(tmp->fileName());
                    }

                    if (url.isLocalFile()) {
                        if (action == insertAsNewLayer || action == insertManyLayers) {
                            kisview->mainWindow()->viewManager()->imageManager()->importImage(url);
                            kisview->activateWindow();
                        }
                        else if (action == insertAsNewFileLayer || action == insertManyFileLayers) {
                            KisNodeCommandsAdapter adapter(kisview->mainWindow()->viewManager());
                            QFileInfo fileInfo(url.toLocalFile());

                            QString type = KisMimeDatabase::mimeTypeForFile(url.toLocalFile());
                            QStringList mimes =
                                KisImportExportManager::supportedMimeTypes(KisImportExportManager::Import);

                            if (!mimes.contains(type)) {
                                QString msg =
                                    KisImportExportErrorCode(ImportExportCodes::FileFormatNotSupported).errorMessage();
                                QMessageBox::warning(
                                    kisview, i18nc("@title:window", "Krita"),
                                    i18n("Could not open %2.\nReason: %1.", msg, url.toDisplayString()));
                                continue;
                            }

                            KisFileLayer *fileLayer = new KisFileLayer(kisview->image(), "", url.toLocalFile(),
                                                                       KisFileLayer::None, fileInfo.fileName(), OPACITY_OPAQUE_U8);

                            KisLayerSP above = kisview->mainWindow()->viewManager()->activeLayer();
                            KisNodeSP parent = above ? above->parent() : kisview->mainWindow()->viewManager()->image()->root();

                            adapter.addNode(fileLayer, parent, above);
                        }
                        else if (action == openInNewDocument || action == openManyDocuments) {
                            if (kisview->mainWindow()) {
                                kisview->mainWindow()->openDocument(url.toLocalFile(), KisMainWindow::None);
                            }
                        }
                        else if (action == insertAsReferenceImage || action == insertAsReferenceImages) {
                            auto *reference = KisReferenceImage::fromFile(url.toLocalFile(), *kisview->viewConverter(), kisview);

                            if (reference) {
                                const auto pos = kisview->canvasBase()->coordinatesConverter()->widgetToImage(eventPos);
                                reference->setPosition((*kisview->viewConverter()).imageToDocument(pos));
                                kisview->canvasBase()->referenceImagesDecoration()->addReferenceImage(reference);

                                KoToolManager::instance()->switchToolRequested("ToolReferenceImages");
                            }
                        }

                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (KoResourceSP r : m_rServer->resources()) {
        KoColorSetSP c = r.staticCast<KoColorSet>();
        if (!c->isGlobal()) {
            m_rServer->removeResourceFromServer(c);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    KisSprayProperties option;
                    option.readOptionSetting(prop->settings().data());
                    option.spacing = prop->value().toReal();
                    option.writeOptionSetting(prop->settings().data());
                }
```

#### AUTO 


```{c}
const auto v4 = (xsimd::nearbyint_as_int(c3) & mask);
```

#### AUTO 


```{c}
const auto &image
```

#### LAMBDA EXPRESSION 


```{c}
[&]() -> KisNodeManager * {
        KisMainWindow *mainWin = KisPart::instance()->currentMainwindow();
        if (!mainWin)
            return nullptr;
        KisViewManager *viewManager = mainWin->viewManager();
        if (!viewManager)
            return nullptr;
        if (viewManager->document()->image() != d->m_image)
            return nullptr;
        return viewManager->nodeManager();
    }
```

#### AUTO 


```{c}
auto &c = level.conflictWithGroup;
```

#### LAMBDA EXPRESSION 


```{c}
[state, &dab, direction, skipMirrorPixels] () {
                    state->painter->mirrorDab(direction, &dab, skipMirrorPixels);
                }
```

#### AUTO 


```{c}
auto clickedProperty = d->propForMousePos(index, mouseEvent->pos(), option);
```

#### AUTO 


```{c}
const auto heightBound = qAbs(bounds.height());
```

#### AUTO 


```{c}
auto nextChunk = std::upper_bound(m_it, m_end, *m_it, VersionedResourceEntry::KeyLess());
```

#### AUTO 


```{c}
auto sessionElement = root.firstChildElement("session");
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &child: childrenWidgets) {
        child->setAttribute(Qt::WA_AcceptTouchEvents, true);
        child->installEventFilter(this);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() -> void
        {
            int animationDuration;
            qreal animationStartValue;

            if (!m_areControlsHidden) {
                if (m_showControlsAnimation.state() == QVariantAnimation::Running) {
                    m_showControlsAnimation.stop();
                    animationDuration =
                        static_cast<int>(std::round(m_showControlsAnimation.currentValue().toReal() * showControlsAnimationDuration));
                    animationStartValue = m_showControlsAnimation.currentValue().toReal();
                } else {
                    animationDuration = showControlsAnimationDuration;
                    animationStartValue = 1.0;
                }
            } else {
                animationDuration = 1;
                animationStartValue = 0.0;
            }

            m_areControlsHidden = true;
            m_showControlsAnimation.setStartValue(animationStartValue);
            m_showControlsAnimation.setEndValue(0.0);
            m_showControlsAnimation.setDuration(animationDuration);
            m_showControlsAnimation.start();
        }
```

#### AUTO 


```{c}
auto constControlIt2 = std::as_const(mesh).find(ControlPointIndex(NodeIndex(0,0), ControlType::Node));
```

#### LAMBDA EXPRESSION 


```{c}
[this, initialTransformArgs, argsAreInitialized]() mutable {
        QRect srcRect;

        if (m_selection) {
            srcRect = m_selection->selectedExactRect();
        } else {
            srcRect = QRect();
            Q_FOREACH (KisNodeSP node, m_processedNodes) {
                // group layers may have a projection of layers
                // that are locked and will not be transformed
                if (node->inherits("KisGroupLayer")) continue;

                if (const KisTransformMask *mask = dynamic_cast<const KisTransformMask*>(node.data())) {
                    srcRect |= mask->sourceDataBounds();
                } else {
                    srcRect |= node->exactBounds();
                }
            }
        }

        TransformTransactionProperties transaction(srcRect, &initialTransformArgs, m_rootNode, m_processedNodes);
        if (!argsAreInitialized) {
            initialTransformArgs = KisTransformUtils::resetArgsForMode(m_mode, m_filterId, transaction);
        }

        emit this->sigTransactionGenerated(transaction, initialTransformArgs);
    }
```

#### AUTO 


```{c}
auto legacyBrushApplication = [] (KisColorfulBrush *colorfulBrush, bool forceColorToAlpha) {
        /**
         * In Krita versions before 4.4 series "ColorAsMask" could
         * be overridden to false when the brush had no **color**
         * inside. That changed in Krita 4.4.x series, when
         * "brushApplication" replaced all the automatic heuristics
         */
        return colorfulBrush && colorfulBrush->hasColorAndTransparency() && !forceColorToAlpha ? IMAGESTAMP : ALPHAMASK;
    };
```

#### AUTO 


```{c}
auto i = 0;
```

#### LAMBDA EXPRESSION 


```{c}
[&linearizedSrcNodes, processedNodes] (KisNodeSP node) {
                    KisNodeSP srcNode = linearizedSrcNodes.dequeue();

                    if (!processedNodes.contains(srcNode)) {
                        node->setVisible(false);
                    }
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this, editor, index](int)
                                        {
                                            stopEditorContainer->insertWidget(index, editor);
                                            stopEditorContainer->setCurrentIndex(index);
                                        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {
        KisNodeSP node = m_resources->currentNode();
        const int time = node->paintDevice()->defaultBounds()->currentTime();

        KisRasterKeyframeChannel* channel = dynamic_cast<KisRasterKeyframeChannel*>(node->getKeyframeChannel(KisKeyframeChannel::Raster.id()));
        if (channel)
        {
            KisKeyframeSP keyframe = channel->keyframeAt(time);
            if (!keyframe && m_autokeyMode != KisAutoKey::NONE) {
                int activeKeyTime = channel->activeKeyframeTime(time);

                const QRect originalDirtyRect = node->exactBounds();
                m_autokeyCommand.reset(new KUndo2Command());

                KUndo2Command *keyframeCommand = new  KisCommandUtils::SkipFirstRedoWrapper(nullptr, m_autokeyCommand.data());

                if (m_autokeyMode == KisAutoKey::DUPLICATE) {
                    channel->copyKeyframe(activeKeyTime, time, keyframeCommand);
                } else { // Otherwise, create a fresh keyframe.
                    new UpdateNode(node, originalDirtyRect, UpdateNode::INITIALIZING, keyframeCommand);
                    channel->addKeyframe(time, keyframeCommand);
                    node->setDirty(originalDirtyRect);
                    new UpdateNode(node, originalDirtyRect, UpdateNode::FINALIZING, keyframeCommand);
                }

                keyframe = channel->keyframeAt(time);
                KIS_SAFE_ASSERT_RECOVER_RETURN(keyframe);

                // Use the same color label as previous keyframe...
                KisKeyframeSP previousKey = channel->keyframeAt(activeKeyTime);
                if (previousKey) {
                    keyframe->setColorLabel(previousKey->colorLabel());
                }
            }
        }
    }
```

#### AUTO 


```{c}
auto fetchFunc =
        [&result, mode, root] (KisNodeSP node) {
        if (node->isEditable(node == root) &&
                (!node->inherits("KisShapeLayer") || mode == ToolTransformArgs::FREE_TRANSFORM) &&
                !node->inherits("KisFileLayer") &&
                (!node->inherits("KisTransformMask") || node == root)) {

                result << node;
            }
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool dropFrames){
            KisConfig cfg(false);
            if (dropFrames != cfg.animationDropFrames()) {
                cfg.setAnimationDropFrames(dropFrames);
                updatePlaybackStatistics();
            }
        }
```

#### AUTO 


```{c}
auto it = std::make_reverse_iterator(m_clearCommands.end());
```

#### AUTO 


```{c}
const auto greenOffset =
        static_cast<size_t>(gmicImage.m_width) * gmicImage.m_height;
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    KisDuplicateOptionProperties option;
                    option.readOptionSetting(prop->settings().data());
                    option.duplicate_move_source_point = prop->value().toBool();
                    option.writeOptionSetting(prop->settings().data());
                }
```

#### AUTO 


```{c}
auto rectIter = rectsToRead.begin();
```

#### RANGE FOR STATEMENT 


```{c}
for (StoryboardComment comment: m_d->doc->getStoryboardCommentsList()) {
        QDomElement commentElement = doc.createElement("storyboardcomment");
        commentElement.setAttribute("name", comment.name);
        commentElement.setAttribute("visibility", comment.visibility);
        eCommentList.appendChild(commentElement);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        KisReferenceImagesLayerSP refLayer = view->document()->referenceImagesLayer();
        return refLayer && refLayer->shapeManager()->selection()->count();
    }
```

#### AUTO 


```{c}
auto *resInfo = new RESN_INFO_1005();
```

#### AUTO 


```{c}
const auto opacity = opacityRe.cap(1).toUInt();
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool toggled)
        {
            if (toggled) {
                setColorType(KisGradientWidgetsUtils::Background);
            }
            emit colorTypeChanged(KisGradientWidgetsUtils::Background);
        }
```

#### CONST EXPRESSION 


```{c}
static constexpr int first_letter_bonus = 15;
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            notifyAllCommandsDone();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            undoTransformCommands(0);
            undoAllCommands();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, index, Model] {Model->insertItem(index, false); }
```

#### LAMBDA EXPRESSION 


```{c}
[](KoShape *s){
            auto *r = dynamic_cast<KisReferenceImage*>(s);
            KIS_SAFE_ASSERT_RECOVER_RETURN_VALUE(r, 0.0);
            return 100.0 * r->saturation();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const T *d) {
                        const T alpha = std::abs(d[3]);

                        if (alpha >= static_cast<T>(0.01)) {
                            return true;
                        } else {
                            for (size_t i = 0; i < this->nbColorsSamples(); i++) {
                                if (!qFuzzyCompare(T(d[i] * alpha), d[i])) {
                                    return false;
                                }
                            }
                            return true;
                        }
                    }
```

#### AUTO 


```{c}
auto source = resourcesInterface->source<KoPattern>(m_patternLink.type);
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    prop->settings()->setPaintOpFlow(prop->value().toReal());
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &colorLabelStr : colorLabelsStr) {
            bool ok;
            const int colorLabel = colorLabelStr.toInt(&ok);
            if (ok) {
                m_selectedColorLabels << colorLabel;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (KisSwatchGroup &g : d->groups.values()) { // Q_FOREACH doesn't accept non const refs
        g.setColumnCount(columns);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QString key: profiles.keys()) {
            const KoColorProfile * profile = profiles.value(key);

            QDomElement profileEl = doc.createElement("color-profile");
            profileEl.setAttribute("name", key);
            QString val = profile->uniqueId().toHex();
            profileEl.setAttribute("local", val);
            profileEl.setAttribute("xlink:href", profile->fileName());
            defs.appendChild(profileEl);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[index, Model] {Model->insertItem(index, false); }
```

#### AUTO 


```{c}
auto *animatedParameters = dynamic_cast<KisAnimatedTransformMaskParameters*>(m_oldParams.data());
```

#### AUTO 


```{c}
auto it = m_commands.rbegin();
```

#### LAMBDA EXPRESSION 


```{c}
[](const SampleInfo &a, const SampleInfo &b) -> bool {  return a.cdfAtX < b.cdfAtX; }
```

#### AUTO 


```{c}
auto extractRect = [&](boost::optional<QRectF>& to) {
                    double x = scaling.width() * attrMap.namedItem("x").nodeValue().toDouble();
                    double y = scaling.height() * attrMap.namedItem("y").nodeValue().toDouble();
                    double width = scaling.width() * attrMap.namedItem("width").nodeValue().toDouble();
                    double height = scaling.height() * attrMap.namedItem("height").nodeValue().toDouble();
                    to = QRectF(x,y, width, height);
                };
```

#### RANGE FOR STATEMENT 


```{c}
for (KisRenderedDab &dab : state->dabsQueue) {
        const bool skipMirrorPixels = prevDabDevice && prevDabDevice == dab.device;

        jobs.append(
            new KisRunnableStrokeJobData(
                [state, &dab, direction, skipMirrorPixels] () {
                    state->painter->mirrorDab(direction, &dab, skipMirrorPixels);
                },
                KisStrokeJobData::CONCURRENT));

        prevDabDevice = dab.device;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&] (KisFreehandStrokeInfo *data) {
        data->painter->setBackgroundColor(customColor);
        data->painter->fillPainterPath(path);
        data->painter->drawPainterPath(path, pen);
    }
```

#### AUTO 


```{c}
auto it = m_segments.begin();
```

#### AUTO 


```{c}
auto endIt = mergeSparseRects(m_rects.begin(), m_rects.end());
```

#### CONST EXPRESSION 


```{c}
constexpr char pathSeparator = ':';
```

#### RANGE FOR STATEMENT 


```{c}
for (const RecorderProfile &profile : value) {
        const RecorderProfile &defaultProfile = ::defaultProfiles[index];
        if (profile != defaultProfile) {
            editedProfilesIndexes.insert(index);
        } else {
            editedProfilesIndexes.remove(index);
        }

        outValue += QString(profile.name).replace(cleanUp, " ") % "|"
                % QString(profile.extension).replace(cleanUp, " ") % "|"
                % QString(profile.arguments).replace("\n", "\\n").replace("|", " ") % "\n";

        ++index;
    }
```

#### AUTO 


```{c}
auto it2 = std::next(it1);
```

#### AUTO 


```{c}
auto iFFt = m_channelFFT.constBegin();
```

#### LAMBDA EXPRESSION 


```{c}
[&] (KisFreehandStrokeInfo *data) {
        data->painter->paintBezierCurve(pi1, control1, control2, pi2, data->dragDistance);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&clonedTimes, time](const KisNode* node){
            clonedTimes += KisRasterKeyframeChannel::clonesOf(node, time);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            m_updatesFacade->enableDirtyRequests();
            m_updatesDisabled = false;

            Q_FOREACH (KisNodeSP node, m_processedNodes) {
                m_updatesFacade->refreshGraphAsync(node, m_dirtyRects[node] | m_prevDirtyRects[node]);
            }

            m_prevDirtyRects.clear();
            m_dirtyRects.swap(m_prevDirtyRects);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (KoShapeStrokeSP stroke) {
        stroke->setLineStyle(lineStyle(), lineDashes());
    }
```

#### AUTO 


```{c}
const auto status = manager.importDocument(inputFileName, QString());
```

#### CONST EXPRESSION 


```{c}
static constexpr const char *HalftoneMode_IndependentChannels = "independent_channels";
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &action : actions) {
                action();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (heif_item_id id : metadata_IDs) {

          if (handle.get_metadata_type(id) == "Exif") {
            // Read exif information

            std::vector<uint8_t> exif_data = handle.get_metadata(id);

            if (exif_data.size()>4) {
              size_t skip = ((exif_data[0]<<24) | (exif_data[1]<<16) | (exif_data[2]<<8) | exif_data[3]) + 4;

              if (exif_data.size()>skip) {
                KisMetaData::IOBackend* exifIO = KisMetaData::IOBackendRegistry::instance()->value("exif");

                // Copy the exif data into the byte array
                QByteArray ba(reinterpret_cast<char *>(exif_data.data()+skip), static_cast<int>(exif_data.size()-skip));
                QBuffer buf(&ba);
                exifIO->loadFrom(layer->metaData(), &buf);
              }
            }
          }

          if (handle.get_metadata_type(id) == "mime" &&
              handle.get_metadata_content_type(id) == "application/rdf+xml") {
            // Read XMP information

            std::vector<uint8_t> xmp_data = handle.get_metadata(id);

            KisMetaData::IOBackend* xmpIO = KisMetaData::IOBackendRegistry::instance()->value("xmp");

            // Copy the xmp data into the byte array
            QByteArray ba(reinterpret_cast<char *>(xmp_data.data()), static_cast<int>(xmp_data.size()));
            QBuffer buf(&ba);
            xmpIO->loadFrom(layer->metaData(), &buf);
          }
        }
```

#### AUTO 


```{c}
auto it = std::upper_bound(fontStretches.begin(),
                                       fontStretches.end(),
                                       context.currentGC()->font.stretch());
```

#### AUTO 


```{c}
auto gradient = static_cast<const KoAbstractGradient *>(dynamic_cast<const KritaGradientMapFilterConfiguration *>(config.data())->gradient());
```

#### LAMBDA EXPRESSION 


```{c}
[node] () mutable {
                 node->syncLodCache();
             }
```

#### LAMBDA EXPRESSION 


```{c}
[&result, mode, root] (KisNodeSP node) {
        if (node->isEditable(node == root) &&
                (!node->inherits("KisShapeLayer") || mode == ToolTransformArgs::FREE_TRANSFORM) &&
                !node->inherits("KisFileLayer") &&
                (!node->inherits("KisTransformMask") || node == root)) {

                result << node;
            }
    }
```

#### AUTO 


```{c}
auto it = m_nodes.begin();
```

#### AUTO 


```{c}
const auto y = rc.y();
```

#### LAMBDA EXPRESSION 


```{c}
[m_c1](double x)
            {
                const double xx = 1.0 - x;
                return std::exp(-(xx * xx / m_c1));
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& shape: selectedShapes) {
        QSizeF size = shape->boundingRect().size();
        if (size.height() > maxSize.height()) {
            maxSize.rheight() = size.height();
        }
        if (size.width() > maxSize.width()) {
            maxSize.rwidth() = size.width();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    KisSmudgeOption option;
                    option.readOptionSetting(prop->settings().data());

                    prop->setValue(option.getSmearAlpha());
                }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() -> std::array<quint8, 5> {
                if (sample_format == SAMPLEFORMAT_IEEEFP) {
                    return {0, 1, 2, 3};
                } else {
                    return {2, 1, 0, 3};
                }
            }
```

#### AUTO 


```{c}
const auto rbegin = penInfoArray.rbegin();
```

#### LAMBDA EXPRESSION 


```{c}
[this](QAction* triggered) {
        m_d->collapsedButton->setDefaultAction(triggered);
    }
```

#### AUTO 


```{c}
const auto& rc
```

#### RANGE FOR STATEMENT 


```{c}
for (KoColorSet * &cs : m_activeDocument->paletteList()) {
            KoColorSet *tmpAddr = cs;
            cs = new KoColorSet(*cs);
            m_rServer->removeResourceFromServer(tmpAddr);
        }
```

#### AUTO 


```{c}
auto setColorFn = [dialog, segments, this]() mutable
                      {
                          if (m_selectedHandle.index == 0) {
                              segments[0]->setStartType(COLOR_ENDPOINT);
                              segments[0]->setStartColor(dialog->getCurrentColor());
                          } else {
                              segments[m_selectedHandle.index - 1]->setEndType(COLOR_ENDPOINT);
                              segments[m_selectedHandle.index - 1]->setEndColor(dialog->getCurrentColor());
                              if (m_selectedHandle.index < segments.size()) {
                                  segments[m_selectedHandle.index]->setStartType(COLOR_ENDPOINT);
                                  segments[m_selectedHandle.index]->setStartColor(dialog->getCurrentColor());
                              }
                          }
                          emit selectedHandleChanged();
                          emit updateRequested();
                      };
```

#### AUTO 


```{c}
const auto prettyFilename = createPrettyFilenameFromName(res);
```

#### AUTO 


```{c}
auto it = std::find(fontStretchNames.begin(), fontStretchNames.end(), value);
```

#### LAMBDA EXPRESSION 


```{c}
[updateData] () {
                updateData->processUnhandledUpdates();
                return nullptr;
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (QUrl url : urls) {

                    QScopedPointer<QTemporaryFile> tmp(new QTemporaryFile());
                    tmp->setAutoRemove(true);

                    if (!url.isLocalFile()) {
                        // download the file and substitute the url
                        KisRemoteFileFetcher fetcher;

                        if (!fetcher.fetchFile(url, tmp.data())) {
                            qWarning() << "Fetching" << url << "failed";
                            continue;
                        }
                        url = url.fromLocalFile(tmp->fileName());
                    }

                    if (url.isLocalFile()) {
                        if (action == insertAsNewLayer || action == insertManyLayers) {
                            kisview->mainWindow()->viewManager()->imageManager()->importImage(url);
                            kisview->activateWindow();
                        }
                        else if (action == insertAsNewFileLayer || action == insertManyFileLayers) {
                            KisNodeCommandsAdapter adapter(kisview->mainWindow()->viewManager());
                            QFileInfo fileInfo(url.toLocalFile());
                            KisFileLayer *fileLayer = new KisFileLayer(kisview->image(), "", url.toLocalFile(),
                                                                       KisFileLayer::None, fileInfo.fileName(), OPACITY_OPAQUE_U8);
                            adapter.addNode(fileLayer, kisview->mainWindow()->viewManager()->activeNode()->parent(), kisview->mainWindow()->viewManager()->activeNode());
                        }
                        else if (action == openInNewDocument || action == openManyDocuments) {
                            if (kisview->mainWindow()) {
                                kisview->mainWindow()->openDocument(url.toLocalFile(), KisMainWindow::None);
                            }
                        }
                        else if (action == insertAsReferenceImage || action == insertAsReferenceImages) {
                            auto *reference = KisReferenceImage::fromFile(url.toLocalFile(), *kisview->viewConverter(), kisview);

                            if (reference) {
                                reference->setPosition((*kisview->viewConverter()).imageToDocument(QCursor::pos()));
                                kisview->canvasBase()->referenceImagesDecoration()->addReferenceImage(reference);

                                KoToolManager::instance()->switchToolRequested("ToolReferenceImages");
                            }
                        }

                    }
                }
```

#### LAMBDA EXPRESSION 


```{c}
[&range, time] (const KisNode *node) {
            if (node->visible()) {
                range &= calculateNodeIdenticalFrames(node, time);
            }
    }
```

#### AUTO 


```{c}
auto it = commands.begin();
```

#### RANGE FOR STATEMENT 


```{c}
for (QUrl url : urls) {

                    if (!url.isLocalFile()) {
                        // download the file and substitute the url
                        KisRemoteFileFetcher fetcher;
                        tmp = new QTemporaryFile();
                        tmp->setAutoRemove(true);
                        if (!fetcher.fetchFile(url, tmp)) {
                            qDebug() << "Fetching" << url << "failed";
                            continue;
                        }
                        url = url.fromLocalFile(tmp->fileName());
                    }
                    if (url.isLocalFile()) {
                        if (action == insertAsNewLayer || action == insertManyLayers) {
                            d->viewManager->imageManager()->importImage(url);
                            activateWindow();
                        }
                        else if (action == insertAsNewFileLayer || action == insertManyFileLayers) {
                            KisNodeCommandsAdapter adapter(viewManager());
                            KisFileLayer *fileLayer = new KisFileLayer(image(), "", url.toLocalFile(),
                                                                       KisFileLayer::None, image()->nextLayerName(), OPACITY_OPAQUE_U8);
                            adapter.addNode(fileLayer, viewManager()->activeNode()->parent(), viewManager()->activeNode());
                        }
                        else {
                            Q_ASSERT(action == openInNewDocument || action == openManyDocuments);
                            if (mainWindow()) {
                                mainWindow()->openDocument(url);
                            }
                        }
                    }
                    delete tmp;
                    tmp = 0;
                }
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    HatchingOption option;
                    option.readOptionSetting(prop->settings().data());
                    option.separation = prop->value().toReal();
                    option.writeOptionSetting(prop->settings().data());
                }
```

#### LAMBDA EXPRESSION 


```{c}
[idleDelay, &elapsedTimer]() {
            return elapsedTimer.elapsed() > idleDelay;
        }
```

#### AUTO 


```{c}
auto it = m_dependencyFromTarget.find(targetKey);
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
                    const_cast<QSharedPointer<bool> &>(cookie).clear();

                    f->generate(dstCfg, tile.size(), filterConfig, helper->updater());

                    // HACK ALERT!!!
                    // this avoids cyclic loop with KisRecalculateGeneratorLayerJob::run()
                    const_cast<KisGeneratorLayerSP &>(layer)->setDirtyWithoutUpdate({tile});
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            changeLayoutDir(Qt::LayoutDirectionAuto);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QTouchEvent::TouchPoint &touchPoint : te->touchPoints()) {
                if (touchPoint.id() == m_touchPointId) {
                    // If the touch point wasn't moved, this event wasn't
                    // generated from our touch point
                    if (touchPoint.state() == Qt::TouchPointStationary) {
                        return true;
                    }
                    currentPosition = touchPoint.pos();
                    break;
                }
            }
```

#### AUTO 


```{c}
auto it = std::upper_bound(fontStretches.rbegin(),
                                       fontStretches.rend(),
                                       propertyOrDefault(KoSvgTextProperties::FontStretchId).toInt(),
                                       std::greater<int>());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &name : getGroupNames()) {
        res += d->groups[name].rowCount();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KoCanvasResource::CanvasResourceId res,
                               KoFlake::FillVariant var) {
        if (d->overriddenColorFromProvider[var]) {
            d->canvas->resourceManager()->setResource(
                res, QVariant::fromValue(*d->overriddenColorFromProvider[var]));
            d->overriddenColorFromProvider[var] = boost::none;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (double value : inputValuesRaw) {
        double cValue = value;
        /*
         * HLG
         * for 1  >=  Lc > 1 ÷ 12
         *  V= a * Ln( 12 * Lc − b ) + c
         * for 1 ÷ 12  >=  Lc  >=  0
         *  V = Sqrt( 3 ) * Lc^0.5
         *
         * where...
         * a = 0.17883277
         * b = 0.28466892
         * c = 0.55991073
         *
         */

        double a = 0.17883277;
        double b = 0.28466892;
        double c = 0.55991073;


        if (value > 1.0/12.0) {
            cValue = a*log(12*value-b) + c;
        } else {
            cValue = sqrt(3) * powf(value, 0.5);
        }

        double cValue2 = applyHLGCurve(value);


        double lValue = (exp(((cValue2 - c) / a)) + b) / 12.0;
        if (cValue2 <= 0.5) {
            lValue = powf(cValue2, 2.0) / 3.0;
        }

        double lValue2 = removeHLGCurve(cValue);

        //Not possible in icc v4
        QVERIFY2(fabs(lValue - value) < 0.000001, QString("Values don't match for HLG: %1 %2").arg(value).arg(lValue).toLatin1());
        QVERIFY2(fabs(lValue2 - value) < 0.000001, QString("Values don't match for HLG, 2: %1 %2").arg(value).arg(lValue2).toLatin1());

    }
```

#### AUTO 


```{c}
auto arg
```

#### RANGE FOR STATEMENT 


```{c}
for (KoGradientSegment *segment : gradient->segments()) {
            QGradientStop stop;
            
            stop = toQGradientStop(
                segment->startColor(), segment->startType(), segment->startOffset(),
                canvasResourcesInterface
            );
            if (qFuzzyCompare(stop.first, lastStop.first)) {
                if (stop.second != lastStop.second) {
                    stop.first = stop.first + 0.000001;
                    stops << stop;
                    lastStop = stop;
                }
            } else {
                stops << stop;
                lastStop = stop;
            }
            
            stop = toQGradientStop(
                segment->endColor(), segment->endType(), segment->endOffset(),
                canvasResourcesInterface
            );
            if (qFuzzyCompare(stop.first, lastStop.first)) {
                if (stop.second != lastStop.second) {
                    stop.first = stop.first + 0.000001;
                    stops << stop;
                    lastStop = stop;
                }
            } else {
                stops << stop;
                lastStop = stop;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&]()
    {
        QStringList mimeTypes = KisResourceLoaderRegistry::instance()->mimeTypes(ResourceType::Workspaces);
        KoFileDialog dialog(0, KoFileDialog::OpenFile, "OpenDocument");
        dialog.setMimeTypeFilters(mimeTypes);
        dialog.setCaption(i18nc("@title:window", "Choose File to Add"));
        QString filename = dialog.filename();

        KoResourceSP resource = d->workspacemodel->importResourceFile(filename, false);
        if (resource.isNull() && KisResourceOverwriteDialog::resourceExistsInResourceFolder(ResourceType::Workspaces, filename)) {
            if (KisResourceOverwriteDialog::userAllowsOverwrite(this, filename)) {
                KoResourceSP resource = d->workspacemodel->importResourceFile(filename, true);
            }
        }

    }
```

#### AUTO 


```{c}
const auto pos = static_cast<size_t>(y) * gmicImage.m_width
                    + static_cast<size_t>(x);
```

#### LAMBDA EXPRESSION 


```{c}
[](KisNodeSP node) -> bool { return dynamic_cast<KisReferenceImagesLayer *>(node.data()); }
```

#### AUTO 


```{c}
const auto *srcPtr = static_cast<const T *>(src);
```

#### AUTO 


```{c}
auto it = newFrames.lowerBound(range.start());
```

#### AUTO 


```{c}
auto constControlIt1 = mesh.constBeginControlPoints();
```

#### RANGE FOR STATEMENT 


```{c}
for (const PSDResourceBlock *block : resources) {
        if (!block->write(buf)) {
            error = block->error;
            return false;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    KisSprayProperties option;
                    option.readOptionSetting(prop->settings().data());

                    prop->setValue(int(option.particleCount));
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (KoGradientSegment *segment : gradient->segments()) {
            KoGradientStop stop;
            
            stop = toKoGradientStop(
                segment->startColor(), segment->startType(), segment->startOffset(),
                canvasResourcesInterface
            );
            stop.color.convertTo(stopGradient->colorSpace());
            if (!qFuzzyCompare(stop.position, lastStop.position) || stop.type != lastStop.type || stop.color != lastStop.color) {
                stops << stop;
                lastStop.type = stop.type;
                lastStop.color = stop.color;
                lastStop.position = stop.position;
            }
            
            stop = toKoGradientStop(
                segment->endColor(), segment->endType(), segment->endOffset(),
                canvasResourcesInterface
            );
            stop.color.convertTo(stopGradient->colorSpace());
            if (!qFuzzyCompare(stop.position, lastStop.position) || stop.type != lastStop.type || stop.color != lastStop.color) {
                stops << stop;
                lastStop.type = stop.type;
                lastStop.color = stop.color;
                lastStop.position = stop.position;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    DynaOption option;
                    option.readOptionSetting(prop->settings().data());
                    option.dyna_mass = prop->value().toReal();
                    option.writeOptionSetting(prop->settings().data());
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this, previousLevelsCurve]()
        {
            *m_activeLevelsCurve = previousLevelsCurve;
            updateWidgets();
            emit sigConfigurationItemChanged();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KoGradientStop& stop : stops) {
        const float value = evenDistribution ? (float)stopIndex / (float)(stopCount - 1) : qMax(0.0, stop.color.toQColor().hueF());
        const float position = ascending ? value : 1.f - value;

        if (ascending) {
            sortedStops.push_back(KoGradientStop(position, stop.color, stop.type));
        } else {
            sortedStops.push_front(KoGradientStop(position, stop.color, stop.type));
        }

        stopIndex++;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&context] () {
        return context.currentGC()->textProperties.generateFont();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[targetFrame, cmd](KisNodeSP node){
            if (node->supportsKeyframeChannel(KisKeyframeChannel::Raster.id())) {
                KisKeyframeChannel* chan = node->getKeyframeChannel(KisKeyframeChannel::Raster.id(), true);
                const int activeFrameTime = chan->activeKeyframeTime(targetFrame);
                chan->copyKeyframe(activeFrameTime, targetFrame, cmd);
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        // When dealing with animated transform mask layers, create keyframe and save the command for undo.
        Q_FOREACH (KisNodeSP node, m_processedNodes) {
            if (KisTransformMask* transformMask = dynamic_cast<KisTransformMask*>(node.data())) {
                QSharedPointer<KisInitializeTransformMaskKeyframesCommand> addKeyCommand(new KisInitializeTransformMaskKeyframesCommand(transformMask, transformMask->transformParams()));
                runAndSaveCommand( addKeyCommand, KisStrokeJobData::CONCURRENT, KisStrokeJobData::NORMAL);
            }
        }
    }
```

#### AUTO 


```{c}
const auto action
```

#### AUTO 


```{c}
const auto name = nameRe.cap(1);
```

#### LAMBDA EXPRESSION 


```{c}
[this](){
        const KoColorSetSP palette = m_paletteWidget->currentResource().staticCast<KoColorSet>();
        alphaIndexSpinBox->setMaximum(palette ? int(palette->colorCount() - 1) : 0);
        alphaIndexSpinBox->setValue(std::min(alphaIndexSpinBox->value(), alphaIndexSpinBox->maximum()));
    }
```

#### AUTO 


```{c}
auto it = map->find(index);
```

#### CONST EXPRESSION 


```{c}
constexpr const int maxRecentItemsCount = 5;
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        /**
         * We must request shape layers to rerender areas outside image bounds
         */
        KisLayerUtils::forceAllHiddenOriginalsUpdate(m_rootNode);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QString groupName : d->groupNames) {
        int lastRowGroup = 0;
        for (const KisSwatchGroup::SwatchInfo &info : d->groups[groupName].infoList()) {
            QColor c = info.swatch.color().toQColor();
            gc.fillRect(info.column * 4, (lastRow + info.row) * 4, 4, 4, c);
            lastRowGroup = qMax(lastRowGroup, info.row);
        }
        lastRow += (lastRowGroup + 1);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KoColor color : mask->keyStrokesColors().colors) {
        colorList.append(new ManagedColor(color));
    }
```

#### AUTO 


```{c}
auto result = map.getLazy(i, KisSharedPtr<Wrapper>(new Wrapper()), newTile);
```

#### AUTO 


```{c}
auto it = savedUndoRects.begin();
```

#### AUTO 


```{c}
auto *cmd = new KisCommandUtils::CompositeCommand();
```

#### AUTO 


```{c}
auto pluginManager = pluginManagerInstance.data();
```

#### LAMBDA EXPRESSION 


```{c}
[](const KisUniformPaintOpProperty *prop) {
                    KisSprayProperties option;
                    option.readOptionSetting(prop->settings().data());
                    return option.useDensity;
                }
```

#### AUTO 


```{c}
const auto t3 = batch<T, A>::load(srcPtr + batch<T, A>::size * 2, U{});
```

#### AUTO 


```{c}
auto rc = dirtyCacheRegion.begin();
```

#### LAMBDA EXPRESSION 


```{c}
[] (KisColorfulBrush *colorfulBrush, bool forceColorToAlpha) {
        /**
         * In Krita versions before 4.4 series "ColorAsMask" could
         * be overridden to false when the brush had no **color**
         * inside. That changed in Krita 4.4.x series, when
         * "brushApplication" replaced all the automatic heuristics
         */
        return colorfulBrush && colorfulBrush->hasColorAndTransparency() && !forceColorToAlpha ? IMAGESTAMP : ALPHAMASK;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(KoGamutMaskShape* shape: *shapeVector) {
        shape->paint(painter, viewConverter);
    }
```

#### AUTO 


```{c}
const auto& row
```

#### LAMBDA EXPRESSION 


```{c}
[this](qreal zoomDelta){
        const qreal currentZoomLevel = m_d->verticalHeader->scale();
        m_d->verticalHeader->setScale(currentZoomLevel + zoomDelta / m_d->verticalHeader->step());
        viewport()->update();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[]() {
        if (!QCoreApplication::instance()) {
            warnResource << "QCoreApplication not valid when initializing resourceTypeNameMap in" << __FILE__ << "line" << __LINE__;
        }
        QMap<QString, QString> typeMap;
        typeMap[ResourceType::PaintOpPresets] = ResourceName::PaintOpPresets.toString();
        typeMap[ResourceType::Brushes] = ResourceName::Brushes.toString();
        typeMap[ResourceType::Gradients] = ResourceName::Gradients.toString();
        typeMap[ResourceType::Palettes] = ResourceName::Palettes.toString();
        typeMap[ResourceType::Patterns] = ResourceName::Patterns.toString();
        typeMap[ResourceType::Workspaces] = ResourceName::Workspaces.toString();
        typeMap[ResourceType::Symbols] = ResourceName::Symbols.toString();
        typeMap[ResourceType::WindowLayouts] = ResourceName::WindowLayouts.toString();
        typeMap[ResourceType::Sessions] = ResourceName::Sessions.toString();
        typeMap[ResourceType::GamutMasks] = ResourceName::GamutMasks.toString();
        typeMap[ResourceType::SeExprScripts] = ResourceName::SeExprScripts.toString();
        typeMap[ResourceType::FilterEffects] = ResourceName::FilterEffects.toString();
        typeMap[ResourceType::TaskSets] = ResourceName::TaskSets.toString();
        typeMap[ResourceType::LayerStyles] = ResourceName::LayerStyles.toString();
        return typeMap;
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr int minimumDragDistance{4};
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    KisCurveOptionProperties option;
                    option.readOptionSetting(prop->settings().data());
                    option.curve_paint_connection_line = prop->value().toBool();
                    option.writeOptionSetting(prop->settings().data());
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : brokenUrls) {
        m_mainWindow->removeRecentUrl(url);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Column &c : m_colorMatrix) {
        for (int k : c.keys()) {
            if (k >= newRowCount) {
                c.remove(k);
                m_colorCount--;
            }
        }
    }
```

#### AUTO 


```{c}
auto tester = new QAbstractItemModelTester(m_storyboardModel, 0);
```

#### LAMBDA EXPRESSION 


```{c}
[] (KisNodeSP node)
            {
                quint32 transparencyMasks = 0;
                KisNodeSP mask;

                for (mask = node->firstChild(); mask != 0; mask = mask->nextSibling()) {
                    if (mask->inherits("KisTransparencyMask")) {
                        transparencyMasks += 1;
                        if (transparencyMasks > 1) {
                            return true;
                        }
                    }
                }
                    
                return false;
            }
```

#### LAMBDA EXPRESSION 


```{c}
[] (const KisBrush* brush)
                       {
                           return new KisQImagePyramid(brush->brushTipImage());
                       }
```

#### AUTO 


```{c}
auto transform = SvgTransformParser(elem.attribute("transform")).transform();
```

#### AUTO 


```{c}
auto it = children.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (Vertex* v : endNode->outputVertexes) {
                if (v->dstNode->isInitialized && !p.contains(v->dstNode)) {
                    Path newP = p;  // Candidate
                    newP.appendVertex(v);
                    Node* newEndNode = v->dstNode;
                    if (newEndNode == dstNode) {
                        if (pQC.isGoodPath(newP)) { // Victory
                            newP.isGood = true;
                            return newP;
                        } else if (pQC.lessWorseThan(newP, currentBestPath)) {
                            Q_ASSERT(newP.startNode()->id() == currentBestPath.startNode()->id());
                            Q_ASSERT(newP.endNode()->id() == currentBestPath.endNode()->id());
                            // Can we do better than dumping memory values???
                            // warnPigment << pQC.lessWorseThan(newP, currentBestPath) << " " << newP << "  " << currentBestPath;
                            currentBestPath = newP;
                        }
                    } else {
                        // This is an incomplete path. Check if there's a better way to get to its endpoint.
                        Node2PathHash::Iterator it = node2path.find(newEndNode);
                        if (it != node2path.end()) {
                            Path &p2 = it.value();
                            if (pQC.lessWorseThan(newP, p2)) {
                                p2 = newP;
                                possiblePaths.append(newP);
                            }
                        } else {
                            node2path.insert(newEndNode, newP);
                            possiblePaths.append(newP);
                        }
                    }
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this, sharedState, sharedWriteLock, cleanResources] () {
            Q_UNUSED(sharedWriteLock); // just a RAII holder object for the lock

            if (cleanResources) {
                releaseResources();
            }

            if (sharedState->transaction) {
                // the internal command is stored using
                // the link to the parent command
                (void) sharedState->transaction->endAndTake();
            }
        }
```

#### AUTO 


```{c}
auto *session = new KisSessionResource(QString());
```

#### AUTO 


```{c}
auto it = m_d->originalPoints.begin();
```

#### AUTO 


```{c}
auto testBadPixel = [cs, op, srcPtr, dstPtr, numTestablePixels] (int badPixelPos,
            const quint8 *goodSrc,
            const quint8 *goodDst,
            const quint8 *badSrc,
            const quint8 *badDst,
            quint8 opacity,
            quint8 *expectedDst) {

        quint8 *badPixelDstPtr = dstPtr + badPixelPos * cs->pixelSize();

        for (int i = 0; i < numTestablePixels; i++) {
            if (i != badPixelPos) {
                memcpy(srcPtr + cs->pixelSize() * i, goodSrc, cs->pixelSize());
                memcpy(dstPtr + cs->pixelSize() * i, goodDst, cs->pixelSize());
            } else {
                memcpy(srcPtr + cs->pixelSize() * i, badSrc, cs->pixelSize());
                memcpy(dstPtr + cs->pixelSize() * i, badDst, cs->pixelSize());
            }
        }

        op->composite(dstPtr, numTestablePixels * cs->pixelSize(),
                      srcPtr, numTestablePixels * cs->pixelSize(),
                      0, 0,
                      1, numTestablePixels, opacity);

        if (memcmp(badPixelDstPtr, expectedDst, cs->pixelSize()) != 0) {
            qDebug() << "badPixelPos" << badPixelPos;
            qDebug() << "opacity" << opacity;
            qDebug() << "oriS" << badSrc[0] << badSrc[1] << badSrc[2] << badSrc[3];
            qDebug() << "oriS" << badDst[0] << badDst[1] << badDst[2] << badDst[3];
            qDebug() << "expD" << expectedDst[0] << expectedDst[1] << expectedDst[2] << expectedDst[3];
            qDebug() << "dst1" << badPixelDstPtr[0] << badPixelDstPtr[1] << badPixelDstPtr[2] << badPixelDstPtr[3];
            QFAIL("Failed to compose pixels");
        }
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this, levelOfDetail, updateData, useHoldUI, commandGroup]() {

        fetchAllUpdateRequests(levelOfDetail, updateData);

        executeAndAddCommand(new KisDisableDirtyRequestsCommand(m_d->updatesFacade, KisUpdateCommandEx::FINALIZING), commandGroup, KisStrokeJobData::BARRIER);
        executeAndAddCommand(new KisUpdateCommandEx(m_d->updateDataForUndo, m_d->updatesFacade, KisUpdateCommandEx::FINALIZING, m_d->commandUpdatesBlockerCookie), commandGroup, KisStrokeJobData::BARRIER);

        if (useHoldUI) {
            executeAndAddCommand(new KisHoldUIUpdatesCommand(m_d->updatesFacade, KisCommandUtils::FlipFlopCommand::FINALIZING), commandGroup, KisStrokeJobData::BARRIER);
        }

        /**
         * We also emit the updates manually, because KisUpdateCommandEx is
         * still blocked by m_d->commandUpdatesBlockerCookie (for easy undo
         * purposes)
         */
        for (auto it = updateData->begin(); it != updateData->end(); ++it) {
            m_d->updatesFacade->refreshGraphAsync(it->first, it->second);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[index, pModel] {
            int row = index.row();
            KisRemoveStoryboardCommand *command = new KisRemoveStoryboardCommand(row, pModel->getData().at(row), pModel);
            pModel->removeItem(index, command);
            pModel->pushUndoCommand(command);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&] (const QPointF &pt, const QPointF &expectedNearestPoint) {
        const qreal eps = 1e-3;

        const qreal t = KisBezierUtils::nearestPoint(controlPoints, pt);
        const QPointF nearestPoint = bezierCurve(controlPoints, t);

        bool result = true;

        if (!KisAlgebra2D::fuzzyPointCompare(nearestPoint, expectedNearestPoint, eps)) {
            qDebug() << "Failed to find nearest point:" << ppVar(pt) << ppVar(nearestPoint) << ppVar(expectedNearestPoint);
            result = false;
        }

        return result;
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr double showControlsAnimationDuration{150.0};
```

#### AUTO 


```{c}
auto it = m_edgeBins.constBegin();
```

#### AUTO 


```{c}
auto verifyPoint = [&] (const QPointF &globalPoint, const QPointF &expectedLocalPoint) {
        const qreal eps = 1e-3;
        const QPointF local = KisBezierUtils::calculateLocalPos(patch.points, globalPoint);

        bool result = true;

        if (!KisAlgebra2D::fuzzyPointCompare(local, expectedLocalPoint, eps)) {
            qDebug() << "Failed to find local point:" << ppVar(globalPoint) << ppVar(local) << ppVar(expectedLocalPoint);
            result = false;
        }

        return result;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[nodesToHide](KisNodeSP node) {
                                                     return !nodesToHide.contains(node);
                                                 }
```

#### RANGE FOR STATEMENT 


```{c}
for (int channel : m_d->channelsToPaint) {
        if (!m_d->histogramChannelShapeInfo.contains(channel)) {
            continue;
        }

        const qreal channelBestCutOffHeight =
            isLogarithmic()
            ? m_d->histogramChannelShapeInfo[channel].logarithmicBestCutOffHeight
            : m_d->histogramChannelShapeInfo[channel].linearBestCutOffHeight;
        const qreal channelHighest = static_cast<qreal>(m_d->histogramChannelShapeInfo[channel].highest);

        if (channelBestCutOffHeight * channelHighest > bestCutOffHeight * fittedChannelHighest) {
            bestCutOffHeight = channelBestCutOffHeight;
            fittedChannelHighest = channelHighest;
        }

        if (channelHighest > overallHighest) {
            overallHighest = channelHighest;
        }
    }
```

#### AUTO 


```{c}
const auto opacity = opacityRe.cap(1).toFloat();
```

#### LAMBDA EXPRESSION 


```{c}
[](bool forgettable) {
                Q_UNUSED(forgettable);
                return KisSuspendResumePair(
                    new KisTestingStrokeStrategy("sync_u_", false, true, true),
                    QList<KisStrokeJobData*>());
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KoAbstractGradientSP resource) { gradientSelected(resource); }
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
            prop->settings()->setPaintOpOpacity(prop->value().toReal());
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    ParticleOption option;
                    option.readOptionSetting(prop->settings().data());
                    option.particle_gravity = prop->value().toReal();
                    option.writeOptionSetting(prop->settings().data());
                }
```

#### AUTO 


```{c}
auto it = m_d->currentArgs.meshTransform()->find(*m_d->hoveredSegment);
```

#### LAMBDA EXPRESSION 


```{c}
[this, levelOfDetail]() {
        m_d->updatesFacade->enableDirtyRequests();
        m_d->updatesDisabled = false;
        postAllUpdates(levelOfDetail);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    KisCurveOptionProperties option;
                    option.readOptionSetting(prop->settings().data());
                    option.curve_curves_opacity = prop->value().toReal() / 100.0;
                    option.writeOptionSetting(prop->settings().data());
                }
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    KisGridOpProperties option;
                    option.readOptionSetting(prop->settings().data());
                    option.grid_division_level = prop->value().toInt();
                    option.writeOptionSetting(prop->settings().data());
                }
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    KisSmudgeOption option;
                    option.readOptionSetting(prop->settings().data());

                    prop->setValue(int(option.getMode()));
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this, applyTransform]() {
        Q_FOREACH (KisNodeSP node, m_hiddenProjectionLeaves) {
            node->projectionLeaf()->setTemporaryHiddenFromRendering(false);
            if (!applyTransform) {
                node->setDirty();
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QPoint &point : enclosingPoints) {
        // Continue if the region under the point was already filled
        if (*(resultMask->pixel(point).data()) == MIN_SELECTED) {
            continue;
        }
        KisScanlineFill gc(resultMask, point, enclosingMaskRect);
        gc.clearNonZeroComponent();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[frameItems, valueOffset] () -> KUndo2Command* {

                QScopedPointer<KUndo2Command> cmd(new KUndo2Command());

                bool result = false;

                Q_FOREACH (const FrameItem &item, frameItems) {
                    const int time = item.time;
                    KisNodeSP node = item.node;

                    KisKeyframeChannel *channel = node->getKeyframeChannel(item.channel);

                    if (!channel) continue;

                    KisScalarKeyframeSP scalarKeyframe = channel->keyframeAt(time).dynamicCast<KisScalarKeyframe>();

                    if (!scalarKeyframe) continue;

                    const qreal currentValue = scalarKeyframe->value();
                    //TODO Undo considerations.
                    scalarKeyframe->setValue(currentValue + valueOffset, cmd.data());
                    result = true;
                }

                return result ? new KisCommandUtils::SkipFirstRedoWrapper(cmd.take()) : 0;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=] () {
            this->mergeToLayerUnthreaded(layer, undoAdapter, transactionText, timedID);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QString){
                    QFile loggingFile(m_processSettings.logPath);
                    QString targetPath = m_processSettings.outputFile + ".log";
                    
                    if (QFile::exists(targetPath)) {
                        QFile existingFile(targetPath);
                        existingFile.remove();
                    }
                    
                    loggingFile.copy(targetPath);
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this,
                              argsAreInitialized]() mutable {
        QRect srcRect;

        if (m_s->selection) {
            srcRect = m_s->selection->selectedExactRect();
        } else {
            srcRect = QRect();
            Q_FOREACH (KisNodeSP node, m_s->processedNodes) {
                // group layers may have a projection of layers
                // that are locked and will not be transformed
                if (node->inherits("KisGroupLayer")) continue;

                if (const KisTransformMask *mask = dynamic_cast<const KisTransformMask*>(node.data())) {
                    srcRect |= mask->sourceDataBounds();
                } else if (const KisSelectionMask *mask = dynamic_cast<const KisSelectionMask*>(node.data())) {
                    srcRect |= mask->selection()->selectedExactRect();
                } else {
                    srcRect |= node->exactBounds();
                }
            }
        }

        TransformTransactionProperties transaction(srcRect, &m_s->initialTransformArgs, m_s->rootNode, m_s->processedNodes);
        if (!argsAreInitialized) {
            m_s->initialTransformArgs = KisTransformUtils::resetArgsForMode(m_s->mode, m_s->filterId, transaction);
        }

        Q_EMIT sigTransactionGenerated(transaction, m_s->initialTransformArgs, this);
    }
```

#### AUTO 


```{c}
ORDER_BY(lhs.rendererId() == m_preferredRendererByQt,
                 rhs.rendererId() == m_preferredRendererByQt)
```

#### AUTO 


```{c}
const auto *srcPixel = reinterpret_cast<const RGBPixel *>(src);
```

#### AUTO 


```{c}
auto *reference = KisReferenceImage::fromFile(url.toLocalFile(), d->viewConverter, this);
```

#### LAMBDA EXPRESSION 


```{c}
[baseBrush, settings, painter] () {
            KisDabCacheUtils::DabRenderingResources *resources =
                new KisBrushOpResources(settings, painter);
            resources->brush = baseBrush->clone().dynamicCast<KisBrush>();

            return resources;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(KoGamutMaskShape* shape: *shapeVector) {
        if (shape->coordIsClear(coord, viewConverter) == true) {
            return true;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &groupName : m_colorSet->getGroupNames()) {
        m_rowGroupNameMap[row] = groupName;
        row += m_colorSet->getGroup(groupName)->rowCount();
        row += 1; // row for group name
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    HatchingOption option;
                    option.readOptionSetting(prop->settings().data());
                    option.thickness = prop->value().toReal();
                    option.writeOptionSetting(prop->settings().data());
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KoColorSetSP palette : m_d->doc->paletteList()) {
        if (!palette->isGlobal()) {
            if (!store->open(m_d->imageName + PALETTE_PATH + palette->filename())) {
                m_d->errorMessages << i18n("could not save palettes");
                return false;
            }
            QByteArray ba = palette->toByteArray();
            if (!ba.isEmpty()) {
                store->write(ba);
            } else {
                qWarning() << "Cannot save the palette to a byte array:" << palette->name();
            }
            store->close();
            res = true;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&](int i) {
        if (KisTabletDebugger::instance()->debugEnabled()) {
            QString pre = QString("[BLOCKED %1:]").arg(i);
            QTouchEvent *ev = static_cast<QTouchEvent*>(event);
            dbgTablet << KisTabletDebugger::instance()->eventToString(*ev, pre);
        }
    }
```

#### AUTO 


```{c}
auto otherIt = otherCommands.constBegin();
```

#### AUTO 


```{c}
auto toolManager = KoToolManager::instance();
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
                const_cast<QSharedPointer<bool>&>(cookie).clear();

                f->generate(dstCfg, rc.size(), filterConfig, helper->updater());

                // HACK ALERT!!!
                // this avoids cyclic loop with KisRecalculateGeneratorLayerJob::run()
                const_cast<KisGeneratorLayerSP &>(layer)->setDirtyWithoutUpdate({rc});
            }
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    KisBrushBasedPaintOpSettings *s =
                        dynamic_cast<KisBrushBasedPaintOpSettings*>(prop->settings().data());
                    if (s) {
                        const qreal value = s->autoSpacingActive() ?
                            s->autoSpacingCoeff() : s->spacing();
                        prop->setValue(value);
                    }
                }
```

#### LAMBDA EXPRESSION 


```{c}
[&]()
    {
        QStringList mimeTypes = KisResourceLoaderRegistry::instance()->mimeTypes(ResourceType::Workspaces);

        KoFileDialog dialog(0, KoFileDialog::OpenFile, "OpenDocument");
        dialog.setMimeTypeFilters(mimeTypes);
        dialog.setCaption(i18nc("@title:window", "Choose File to Add"));
        QString filename = dialog.filename();

        KisResourceModel resourceModel(ResourceType::Workspaces);
        KisResourceUserOperations::importResourceFileWithUserInput(this, &resourceModel, "", ResourceType::Workspaces, filename);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    KisDuplicateOptionProperties option;
                    option.readOptionSetting(prop->settings().data());

                    prop->setValue(option.duplicate_move_source_point);
                }
```

#### LAMBDA EXPRESSION 


```{c}
[](const KisUniformPaintOpProperty *prop) -> bool {
                    ExperimentOption option;
                    option.readOptionSetting(prop->settings().data());
                    return option.isSpeedEnabled;
                }
```

#### LAMBDA EXPRESSION 


```{c}
[m_c1](double x)
            {
                return 2.0 * x * std::exp(-(x * x / m_c1));
            }
```

#### AUTO 


```{c}
auto action
```

#### RANGE FOR STATEMENT 


```{c}
for (const KisSwatchGroup::SwatchInfo &info : global().infoList()) {
        QColor c = info.swatch.color().toQColor();
        gc.fillRect(info.column * 4, info.row * 4, 4, 4, c);
    }
```

#### AUTO 


```{c}
auto rserver = KoResourceServerProvider::instance()->seExprScriptServer();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        Q_FOREACH (KisSelectionSP selection, m_d->deactivatedSelections) {
            selection->setVisible(true);
        }

        if (m_d->deactivatedOverlaySelectionMask) {
            m_d->deactivatedOverlaySelectionMask->selection()->setVisible(true);
            m_d->deactivatedOverlaySelectionMask->setDirty();
        }

        m_d->commandUpdatesBlockerCookie.reset();
    }
```

#### CONST EXPRESSION 


```{c}
constexpr int shlobj_KF_FLAG_FORCE_APP_DATA_REDIRECTION = 0x00080000;
```

#### RANGE FOR STATEMENT 


```{c}
for (Shape* shape : shapes) {
        KoShape *originalShape = shape->shape();

        if (originalShape && originalShape->parent() == container) {
            originalShapes << originalShape;
        } else {
            qWarning() << "Attempt to add an invalid shape.";
            return 0;
        }
    }
```

#### AUTO 


```{c}
auto *paintLayer = dynamic_cast<KisPaintLayer *>(node.data());
```

#### AUTO 


```{c}
auto layer = qobject_cast<KisPaintLayer*>(active.data());
```

#### LAMBDA EXPRESSION 


```{c}
LAZY_STATIC_CATEGORY_DISPLAY_NAME("modulo")
```

#### LAMBDA EXPRESSION 


```{c}
[](const KisUniformPaintOpProperty *prop) {
                    KisSprayOptionProperties option;
                    option.readOptionSetting(prop->settings().data());
                    return !option.useDensity;
                }
```

#### LAMBDA EXPRESSION 


```{c}
[](KoShape *shape) {
        return shape->isVisible();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto collection : actionCollections) {

        if (collection->componentName() == "layeractions") {
            m_layerActions = collection;
        }

        const QList<QAction *> collectionActions = collection->actions();
        const QString componentName = collection->componentDisplayName();
        for (const auto action : collectionActions) {
            // sanity + empty check ensures displayable actions and removes ourself
            // from the action list
            if (action && !action->text().isEmpty()) {
                actionList.append({componentName, action});
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {
                                        this->issueSetDirtySignals();
                                    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &profileStr : profilesList) {
        // take saved profile in case it's edited.. or something bad happen
        if (editedIndexes.contains(index) || index >= ::defaultProfiles.size()) {
            const QStringList& profileList = profileStr.split("|");
            if (profileList.size() == 3) {
                profiles.append({profileList[0], profileList[1], QString(profileList[2]).replace("\\n", "\n")});
            }
        } else {
            // use default profile to make it possible to upgrade
            profiles.append(::defaultProfiles[index]);
        }

        ++index;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto action : collectionActions) {
            // sanity + empty check ensures displayable actions and removes ourself
            // from the action list
            if (action && action->isEnabled() && !action->text().isEmpty()) {
                actionList.append({componentName, action});
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[colorBeforeColorDialogChanges, this](){ q->setColor(colorBeforeColorDialogChanges); }
```

#### AUTO 


```{c}
auto uploadColorToResourceManager = [this](KoCanvasResource::CanvasResourceId res,
                              KoFlake::FillVariant var, KoColor &color) {
        if (!d->overriddenColorFromProvider[var]) {
            d->overriddenColorFromProvider[var] =
                d->canvas->resourceManager()->resource(res).value<KoColor>();
        }

        /**
         * Don't let opacity leak to our resource manager system
         *
         * NOTE: theoretically, we could guarantee it on a level of the
         * resource manager itself,
         */
        color.setOpacity(OPACITY_OPAQUE_U8);
        d->canvas->resourceManager()->setResource(res, QVariant::fromValue(color));
    };
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        QString name;
        name = QInputDialog::getText(this, i18nc("@title:window", "New Workspace..."),
                                                                i18nc("@label:textbox", "Name:"));

        auto rserver = KisResourceServerProvider::instance()->workspaceServer();

        KisWorkspaceResourceSP workspace(new KisWorkspaceResource(""));
        workspace->setDockerState(m_this->saveState());

        // this line must happen before we save the workspace to resource folder or other places
        // because it mostly just triggers palettes to be saved into the workspace
        d->viewManager->canvasResourceProvider()->notifySavingWorkspace(workspace);
        workspace->setValid(true);
        QString saveLocation = rserver->saveLocation();

        QFileInfo fileInfo(saveLocation + "/" + name + workspace->defaultFileExtension());

        workspace->setFilename(fileInfo.fileName());
        workspace->setName(name);

        KisResourceUserOperations::addResourceWithUserInput(this, workspace);
    }
```

#### AUTO 


```{c}
auto it = attributes.constBegin();
```

#### AUTO 


```{c}
auto *i
```

#### AUTO 


```{c}
auto constSegmentIt1 = mesh.constBeginSegments();
```

#### LAMBDA EXPRESSION 


```{c}
[frameItems, valueOffset] () -> KUndo2Command* {

                QScopedPointer<KUndo2Command> cmd(new KUndo2Command());

                bool result = false;

                Q_FOREACH (const FrameItem &item, frameItems) {
                    const int time = item.time;
                    KisNodeSP node = item.node;

                    KisKeyframeChannel *channel = node->getKeyframeChannel(item.channel);

                    if (!channel) continue;

                    KisKeyframeSP keyframe = channel->keyframeAt(time);
                    if (!keyframe) continue;

                    const qreal currentValue = channel->scalarValue(keyframe);
                    channel->setScalarValue(keyframe, currentValue + valueOffset, cmd.data());
                    result = true;
                }

                return result ? new KisCommandUtils::SkipFirstRedoWrapper(cmd.take()) : 0;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[image, frames] () {
                bool result = false;

                QScopedPointer<KUndo2Command> cmd(new KUndo2Command());

                Q_FOREACH (const FrameItem &item, frames) {
                    const int time = item.time;
                    KisNodeSP node = item.node;
                    KisKeyframeChannel *channel = 0;
                    if (node) {
                        channel = node->getKeyframeChannel(item.channel);
                    }
                    if (!channel) continue;

                    KisKeyframeSP keyframe = channel->keyframeAt(time);
                    if (!keyframe) continue;

                    channel->removeKeyframe(time, cmd.data());

                    result = true;
                }

                return result ? new KisCommandUtils::SkipFirstRedoWrapper(cmd.take()) : 0;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
                    if (selection) {
                        return selection->selectedExactRect();
                    } else {
                        return activeLayer->exactBounds();
                    }
                }
```

#### LAMBDA EXPRESSION 


```{c}
[&] (KisFreehandStrokeInfo *data) {
        data->painter->paintPainterPath(path);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    KisCurveOptionProperties option;
                    option.readOptionSetting(prop->settings().data());

                    prop->setValue(option.curve_paint_connection_line);
                }
```

#### AUTO 


```{c}
auto resources = source.resources(m_texturePatternLink.md5, m_texturePatternLink.filename, m_texturePatternLink.name);
```

#### AUTO 


```{c}
auto defaultCurves = defaults->curves();
```

#### LAMBDA EXPRESSION 


```{c}
[]() {
            return KisSuspendResumePair(
                new KisTestingStrokeStrategy("resu_u_", false, true, true),
                QList<KisStrokeJobData*>());
        }
```

#### AUTO 


```{c}
auto it = m_d->prevDirtyRects.begin();
```

#### AUTO 


```{c}
auto it = std::find_if(m_cachedResources.begin(),
                               m_cachedResources.end(),
                               [this] (KoResourceSP res) {
                                   return res->resourceType().first == this->m_resourceType;
                               });
```

#### LAMBDA EXPRESSION 


```{c}
[] (KisNodeSP node) {
                KisDelayedUpdateNodeInterface *delayedUpdate =
                    dynamic_cast<KisDelayedUpdateNodeInterface*>(node.data());

                return delayedUpdate ? delayedUpdate->hasPendingTimedUpdates() : false;
            }
```

#### LAMBDA EXPRESSION 


```{c}
[baseBrush, settings, painter] () {
            KisDabCacheUtils::DabRenderingResources *resources =
                new KisBrushOpResources(settings, painter);
            resources->brush = baseBrush->clone();

            return resources;
        }
```

#### AUTO 


```{c}
auto menu = act->menu()
```

#### AUTO 


```{c}
const auto indexOf = [&](const QObject *action, int from = 0) -> int {
        for (int i = from; i < actions.size(); i++) {
            if (actions[i] == action) {
                return i;
            }
        }
        return -1;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this](QByteArray stderrBuffer){
                QString line = stderrBuffer;
                QFile loggingFile(m_processSettings.logPath);
                if (loggingFile.open(QIODevice::WriteOnly | QIODevice::Append)) {
                    loggingFile.write(stderrBuffer);
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QAbstractButton *button, bool state)
            {
                const int index = m_d->colorButtonGroup->id(button);
                emit buttonToggled(index, state);
                if (m_d->colorButtonGroup->exclusive()) {
                    if (!state) {
                        return;
                    }
                    emit currentIndexChanged(index);
                } else {
                    emit selectionChanged();
                }
            }
```

#### AUTO 


```{c}
const auto dstNumChannels = rgbaFloat32bitcolorSpace->channelCount();
```

#### AUTO 


```{c}
auto *reference = KisReferenceImage::fromFile(url.toLocalFile());
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            QWindow *mainWinHandle = this->window()->windowHandle();
            if (mainWinHandle) {
                return mainWinHandle->screen();
            }
            return QApplication::primaryScreen();
        }
```

#### AUTO 


```{c}
const auto currentToolHasSelection =
        view->canvasBase()->toolProxy()->hasSelection();
```

#### AUTO 


```{c}
auto it = points.begin();
```

#### LAMBDA EXPRESSION 


```{c}
[](quint8 & v) {
            v = (v > MASK_CLEAR) ? MASK_SET : MASK_CLEAR;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &pair : m_d->asyncRenderers) {
            if (!pair.renderer->isActive()) {
                const int currentDirtyFrame = m_d->stillDirtyFrames.takeFirst();
                pair.renderer->startFrameRegeneration(pair.image, currentDirtyFrame);
                hadWorkOnPreviousCycle = true;
                m_d->framesInProgress.append(currentDirtyFrame);
                break;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            /**
             * In case we are doing a continued action, we need to
             * set initial update to the "very initial" state that
             * was present before the previous stroke. So here we
             * just override the rect calculated before
             */
            KisBatchNodeUpdate updates;

            Q_FOREACH (KisNodeSP node, m_d->processedNodes) {
                updates.addUpdate(node, node->projectionPlane()->tightUserVisibleBounds());
            }

            m_d->initialUpdatesBeforeClear = updates.compressed();
            *m_d->updateDataForUndo = m_d->initialUpdatesBeforeClear;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool){
        if (m_d->canvas) {
            m_d->canvas->animationPlayer()->stop();
        }
    }
```

#### AUTO 


```{c}
auto pointIt = uniquePoints.begin();
```

#### LAMBDA EXPRESSION 


```{c}
[](const KoGradientStop &a, const KoGradientStop &b){
            return a.first < b.first;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Path &p : currentPaths) {
            const Node* endNode = p.endNode();
            for (Vertex* v : endNode->outputVertexes) {
                if (v->dstNode->isInitialized && !p.contains(v->dstNode)) {
                    Path newP = p;  // Candidate
                    newP.appendVertex(v);
                    Node* newEndNode = v->dstNode;
                    if (newEndNode == dstNode) {
                        if (pQC.isGoodPath(newP)) { // Victory
                            newP.isGood = true;
                            return newP;
                        } else if (pQC.lessWorseThan(newP, currentBestPath)) {
                            Q_ASSERT(newP.startNode()->id() == currentBestPath.startNode()->id());
                            Q_ASSERT(newP.endNode()->id() == currentBestPath.endNode()->id());
                            // Can we do better than dumping memory values???
                            // warnPigment << pQC.lessWorseThan(newP, currentBestPath) << " " << newP << "  " << currentBestPath;
                            currentBestPath = newP;
                        }
                    } else {
                        // This is an incomplete path. Check if there's a better way to get to its endpoint.
                        Node2PathHash::Iterator it = node2path.find(newEndNode);
                        if (it != node2path.end()) {
                            Path &p2 = it.value();
                            if (pQC.lessWorseThan(newP, p2)) {
                                p2 = newP;
                                possiblePaths.append(newP);
                            }
                        } else {
                            node2path.insert(newEndNode, newP);
                            possiblePaths.append(newP);
                        }
                    }
                }
            }
            possiblePaths.removeAll(p); // Remove from list of remaining paths
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (double value : inputValuesRaw) {
        double cValue = value;

        /*
         * TRC_ITU_R_BT_1361
         * Extended historical gamut system.
         *
         * for 1.33 > Lc >= β (0.018)
         *  V = α * Lc^0.45 − ( α − 1 )
         * for for β > Lc >= −γ (-0.0045)
         *  V = 4.500 * Lc
         * for −γ >= Lc >= −0.25
         *  V = −( α * ( −4 * Lc )^0.45 − ( α − 1 ) ) ÷ 4
         *
         * reverse:
         * ( (1.0 / 1.099) * Lc + (0.099 / 1.099) ) ^ (1/0.45)
         * Lc* (1/4.5)
         * -(4/1.099)*(Lc*-.25)^(1/0.45)???
         */


        if (value > 0.018){
            cValue = 1.099 * powf(value, 0.45) - (.099) ;
        } else if (value < 0.018 && value > -0.0045){
            cValue = 4.5 * value;
        } else {
            cValue = -(1.099 * powf(-4 * value, 0.45) - (.099)) * 0.25 ;
        }

        double lValue;
        if (cValue > 0.018){
            lValue = powf((.099/1.099)+(cValue*1/1.099), 1/ 0.45);
        } else if (cValue < -0.0045) {
            lValue = powf( (cValue * 4 / -1.099 ) - (0.099 / -1.099), 1/ 0.45) * -.25;
        } else {
            lValue = cValue * 1/4.5;
        }
        // This is not possible in ICC v4.

        QVERIFY2(fabs(lValue - value) < 0.001, QString("Values don't match for bt. 1361: %1 %2").arg(value).arg(lValue).toLatin1());
    }
```

#### AUTO 


```{c}
auto newEnd = std::remove_if(container.begin(), container.end(), [keepIf] (typename C::reference p) { return !keepIf(p); });
```

#### AUTO 


```{c}
auto applyChangeToStrokes(KoCanvasBase *canvas, ModifyFunction modifyFunction)
        -> decltype(modifyFunction(KoShapeStrokeSP()), void())
{
    KoSelection *selection = canvas->selectedShapesProxy()->selection();

    if (!selection) return;

    QList<KoShape*> shapes = selection->selectedEditableShapes();

    KUndo2Command *command = KoFlake::modifyShapesStrokes(shapes, modifyFunction);

    if (command) {
        canvas->addCommand(command);
    }
}
```

#### AUTO 


```{c}
auto &row
```

#### LAMBDA EXPRESSION 


```{c}
[this](int handleIndex, qreal position)
        {
            if (handleIndex == m_handles.first().index) {
                emit blackPointChanged(position);
            } else if (handleIndex == m_handles.last().index) {
                emit whitePointChanged(position);
            }
        }
```

#### AUTO 


```{c}
auto it = m_d->decorations.begin();
```

#### LAMBDA EXPRESSION 


```{c}
[&](const int ist, const int max) {
        progress.setMaximum(max);
        progress.setValue(ist);
        progress.setLabelText(i18nc("Fetching remote image", "Downloading image from %1... (%2 / %3)")
                                  .arg(remote.host())
                                  .arg(loc.formattedDataSize(ist))
                                  .arg(loc.formattedDataSize(max)));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const FlattenedNode &item : nodes) {
                KisNodeSP node = item.node;

                PSDLayerRecord *layerRecord = new PSDLayerRecord(m_header);
                layers.append(layerRecord);

                const QRect maskRect;

                const bool nodeVisible = node->visible();
                const KoColorSpace *colorSpace = node->colorSpace();
                const quint8 nodeOpacity = node->opacity();
                const quint8 nodeClipping = 0;
                const int nodeLabelColor = node->colorLabelIndex();
                const KisPaintLayer *paintLayer = qobject_cast<KisPaintLayer *>(node.data());
                const bool alphaLocked = (paintLayer && paintLayer->alphaLocked());
                const QString nodeCompositeOp = node->compositeOpId();

                const KisGroupLayer *groupLayer = qobject_cast<KisGroupLayer *>(node.data());
                const bool nodeIsPassThrough = groupLayer && groupLayer->passThroughMode();

                QDomDocument stylesXmlDoc = fetchLayerStyleXmlData(node);

                if (mergedPatternsXmlDoc.isNull() && !stylesXmlDoc.isNull()) {
                    mergedPatternsXmlDoc = stylesXmlDoc;
                } else if (!mergedPatternsXmlDoc.isNull() && !stylesXmlDoc.isNull()) {
                    mergePatternsXMLSection(stylesXmlDoc, mergedPatternsXmlDoc);
                }

                bool nodeIrrelevant = false;
                QString nodeName;
                KisPaintDeviceSP layerContentDevice;
                psd_section_type sectionType;

                if (item.type == FlattenedNode::RASTER_LAYER) {
                    nodeIrrelevant = false;
                    nodeName = node->name();
                    layerContentDevice = node->projection();
                    sectionType = psd_other;
                } else {
                    nodeIrrelevant = true;
                    nodeName = item.type == FlattenedNode::SECTION_DIVIDER ? QString("</Layer group>") : node->name();
                    layerContentDevice = 0;
                    sectionType = item.type == FlattenedNode::SECTION_DIVIDER ? psd_bounding_divider
                        : item.type == FlattenedNode::FOLDER_OPEN             ? psd_open_folder
                                                                              : psd_closed_folder;
                }

                // === no access to node anymore

                QRect layerRect;

                if (layerContentDevice) {
                    QRect rc = layerContentDevice->exactBounds();
                    rc = rc.normalized();

                    // keep to the max of photoshop's capabilities
                    // XXX: update this to PSB
                    if (rc.width() > 30000)
                        rc.setWidth(30000);
                    if (rc.height() > 30000)
                        rc.setHeight(30000);

                    layerRect = rc;
                }

                layerRecord->top = layerRect.y();
                layerRecord->left = layerRect.x();
                layerRecord->bottom = layerRect.y() + layerRect.height();
                layerRecord->right = layerRect.x() + layerRect.width();

                // colors + alpha channel
                // note: transparency mask not included
                layerRecord->nChannels = static_cast<quint16>(colorSpace->colorChannelCount() + 1);

                ChannelInfo *info = new ChannelInfo;
                info->channelId = -1; // For the alpha channel, which we always have in Krita, and should be saved first in
                layerRecord->channelInfoRecords << info;

                // the rest is in display order: rgb, cmyk, lab...
                for (quint32 i = 0; i < colorSpace->colorChannelCount(); ++i) {
                    info = new ChannelInfo;
                    info->channelId = static_cast<qint16>(i); // 0 for red, 1 = green, etc
                    layerRecord->channelInfoRecords << info;
                }

                layerRecord->blendModeKey = composite_op_to_psd_blendmode(nodeCompositeOp);
                layerRecord->isPassThrough = nodeIsPassThrough;
                layerRecord->opacity = nodeOpacity;
                layerRecord->clipping = nodeClipping;

                layerRecord->transparencyProtected = alphaLocked;
                layerRecord->visible = nodeVisible;
                layerRecord->irrelevant = nodeIrrelevant;
                layerRecord->labelColor = nodeLabelColor;

                layerRecord->layerName = nodeName.isEmpty() ? i18n("Unnamed Layer") : nodeName;

                layerRecord->write(io, layerContentDevice, nullptr, QRect(), sectionType, stylesXmlDoc, node->inherits("KisGroupLayer"));
            }
```

#### LAMBDA EXPRESSION 


```{c}
[cs, op, srcPtr, dstPtr, numTestablePixels] (int badPixelPos,
            const quint8 *goodSrc,
            const quint8 *goodDst,
            const quint8 *badSrc,
            const quint8 *badDst,
            quint8 opacity,
            quint8 *expectedDst) {

        quint8 *badPixelDstPtr = dstPtr + badPixelPos * cs->pixelSize();

        for (int i = 0; i < numTestablePixels; i++) {
            if (i != badPixelPos) {
                memcpy(srcPtr + cs->pixelSize() * i, goodSrc, cs->pixelSize());
                memcpy(dstPtr + cs->pixelSize() * i, goodDst, cs->pixelSize());
            } else {
                memcpy(srcPtr + cs->pixelSize() * i, badSrc, cs->pixelSize());
                memcpy(dstPtr + cs->pixelSize() * i, badDst, cs->pixelSize());
            }
        }

        op->composite(dstPtr, numTestablePixels * cs->pixelSize(),
                      srcPtr, numTestablePixels * cs->pixelSize(),
                      0, 0,
                      1, numTestablePixels, opacity);

        if (memcmp(badPixelDstPtr, expectedDst, cs->pixelSize()) != 0) {
            qDebug() << "badPixelPos" << badPixelPos;
            qDebug() << "opacity" << opacity;
            qDebug() << "oriS" << badSrc[0] << badSrc[1] << badSrc[2] << badSrc[3];
            qDebug() << "oriS" << badDst[0] << badDst[1] << badDst[2] << badDst[3];
            qDebug() << "expD" << expectedDst[0] << expectedDst[1] << expectedDst[2] << expectedDst[3];
            qDebug() << "dst1" << badPixelDstPtr[0] << badPixelDstPtr[1] << badPixelDstPtr[2] << badPixelDstPtr[3];
            QFAIL("Failed to compose pixels");
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KisSwatch &s : c.values()) {
            SwatchInfo info = {d->name, s, c.keys()[i++], column};
            res.append(info);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (KoResourceSP res) {
                return res->resourceType().first == this->m_resourceType;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    ExperimentOption option;
                    option.readOptionSetting(prop->settings().data());

                    prop->setValue(option.hardEdge);
                }
```

#### AUTO 


```{c}
auto it = rhs.m_collapsedMap.constBegin();
```

#### AUTO 


```{c}
auto it = std::upper_bound(fontStretches.begin(),
                                       fontStretches.end(),
                                       propertyOrDefault(KoSvgTextProperties::FontStretchId).toInt());
```

#### LAMBDA EXPRESSION 


```{c}
[this](KoCanvasResource::CanvasResourceId res,
                              KoFlake::FillVariant var, KoColor &color) {
        if (!d->overriddenColorFromProvider[var]) {
            d->overriddenColorFromProvider[var] =
                d->canvas->resourceManager()->resource(res).value<KoColor>();
        }

        /**
         * Don't let opacity leak to our resource manager system
         *
         * NOTE: theoretically, we could guarantee it on a level of the
         * resource manager itself,
         */
        color.setOpacity(OPACITY_OPAQUE_U8);
        d->canvas->resourceManager()->setResource(res, QVariant::fromValue(color));
    }
```

#### AUTO 


```{c}
auto debugTouchEvent = [&](int i) {
        if (KisTabletDebugger::instance()->debugEnabled()) {
            QString pre = QString("[BLOCKED %1:]").arg(i);
            QTouchEvent *ev = static_cast<QTouchEvent*>(event);
            dbgTablet << KisTabletDebugger::instance()->eventToString(*ev, pre);
        }
    };
```

#### AUTO 


```{c}
auto func = [&](qint64 & eraseSum, qint64 & insertSum) {
        for (qint32 i = 1; i < numCycles + 1; ++i) {
            auto type = i % numTypes;

            switch (type) {
            case 0: {
                auto result = map.erase(i - 2);
                if (result.data()) {
                    eraseSum += result->member();
                }
                break;
            }
            case 1: {
                auto result = map.insert(i, KisSharedPtr<Wrapper>(new Wrapper(i, 0, 0, 0)));
                if (result.data()) {
                    insertSum -= result->member();
                }
                insertSum += i;
                break;
            }
            case 2: {
                map.get(i - 1);
                break;
            }
            }
        }
    };
```

#### CONST EXPRESSION 


```{c}
static constexpr int unmatched_letter_penalty = -1;
```

#### AUTO 


```{c}
const auto activeLayer = nodes->last();
```

#### AUTO 


```{c}
auto setColorFn = [this, dialog]()
                          {
                              KoColor c;
                              c.fromQColor(dialog->currentColor());
                              q->setColor(c);
                          };
```

#### LAMBDA EXPRESSION 


```{c}
[this] (KoShapeStrokeSP stroke) {

            stroke->setCapStyle(static_cast<Qt::PenCapStyle>(d->capNJoinMenu->capGroup->checkedId()));
            stroke->setJoinStyle(static_cast<Qt::PenJoinStyle>(d->capNJoinMenu->joinGroup->checkedId()));
            stroke->setMiterLimit(miterLimit());
        }
```

#### AUTO 


```{c}
ORDER_BY(lhs.rendererId() == m_preferredRendererByHDR,
                     rhs.rendererId() == m_preferredRendererByHDR)
```

#### CONST EXPRESSION 


```{c}
static constexpr const char *HalftoneMode_Alpha = "alpha";
```

#### AUTO 


```{c}
auto conv = KoColorSpaceRegistry::instance()->createColorConverter(src, dst, KoColorConversionTransformation::internalRenderingIntent(), KoColorConversionTransformation::internalConversionFlags());
```

#### AUTO 


```{c}
auto existing = std::find(m_rows.begin(), m_rows.end(), proportionalT);
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    CurveOption option;
                    option.readOptionSetting(prop->settings().data());
                    option.curve_curves_opacity = prop->value().toReal() / 100.0;
                    option.writeOptionSetting(prop->settings().data());
                }
```

#### AUTO 


```{c}
auto it = m_d->properties.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &node : nodes) {
        KisLayerPropertiesIcons::setNodePropertyAutoUndo(node, KisLayerPropertiesIcons::visible, !isVisible, m_d->view->image());
    }
```

#### LAMBDA EXPRESSION 


```{c}
LAZY_STATIC_CATEGORY_DISPLAY_NAME("negative")
```

#### LAMBDA EXPRESSION 


```{c}
[](const QPointF &point, const QPointF &edgeStart, const QPointF &edgeDirection) -> bool
    {
        const qreal r = (point.x() - edgeStart.x()) * edgeDirection.y() - (point.y() - edgeStart.y()) * edgeDirection.x();
        return (r == 0.0) && ((edgeDirection.y() == 0.0 && edgeDirection.x() > 0.0) || (edgeDirection.y() > 0.0));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &arg) {
            // List according to https://dev.epicgames.com/docs/services/en-US/Interfaces/Auth/index.html#epicgameslauncher
            static const QStringList epicIgnoreArgsStart = {
                QStringLiteral("AUTH_PASSWORD="),
                QStringLiteral("AUTH_LOGIN="),
                QStringLiteral("AUTH_TYPE="),
                QStringLiteral("epicapp="),
                QStringLiteral("epicenv="),
                QStringLiteral("epicusername="),
                QStringLiteral("epicuserid="),
                QStringLiteral("epiclocale="),
                QStringLiteral("epicsandboxid="),
            };
            static const QStringList epicIgnoreArgsExact = {
                QStringLiteral("EpicPortal"),
            };
            QStringRef argDashless(&arg);
            // Strip leading dashes.
            while (argDashless.startsWith('-')) {
                argDashless = argDashless.mid(1);
            }
            Q_FOREACH(const auto &argToIgnore, epicIgnoreArgsStart) {
                if (argDashless.startsWith(argToIgnore, Qt::CaseInsensitive)) {
                    return true;
                }
            }
            Q_FOREACH(const auto &argToIgnore, epicIgnoreArgsExact) {
                if (argDashless.compare(argToIgnore, Qt::CaseInsensitive) == 0) {
                    return true;
                }
            }
            return false;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](){return new KisTestingStrokeStrategy("resu_u_", false, true, true);}
```

#### AUTO 


```{c}
auto vertexIndexMap = get(boost::vertex_index, graph);
```

#### AUTO 


```{c}
auto it = std::make_reverse_iterator(strokesQueue.end());
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                KisStrokeStrategyUndoCommandBased::finishStrokeCallback();
            }
```

#### AUTO 


```{c}
auto capacityMap = MakeComplexCapacityMap(graph, mainImage, aLabelImage, bLabelImage);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &generatorId : m_generatorIds) {
        KisGeneratorSP generator = KisGeneratorRegistry::instance()->get(generatorId);
        ui()->comboBoxGenerator->addItem(generator->name());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool){
        if (m_d->canvas) {
            m_d->canvas->animationPlayer()->nextUnfilteredKeyframe();
        }
    }
```

#### CONST EXPRESSION 


```{c}
constexpr int SPACING = 6;
```

#### AUTO 


```{c}
auto it = m_d->currentArgs.meshTransform()->beginControlPoints();
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        if (KisTabletDebugger::instance()->debugEnabled()) {
            QString pre = QString("[BLOCKED]");
            QMouseEvent *ev = static_cast<QMouseEvent*>(event);
            dbgTablet << KisTabletDebugger::instance()->eventToString(*ev,pre);
        }
    }
```

#### AUTO 


```{c}
auto *dstTileIt = tileItStart;
```

#### AUTO 


```{c}
auto verifyPoint = [&] (const QPointF &pt, const QPointF &expectedNearestPoint) {
        const qreal eps = 1e-3;

        const qreal t = KisBezierUtils::nearestPoint(controlPoints, pt);
        const QPointF nearestPoint = bezierCurve(controlPoints, t);

        bool result = true;

        if (!KisAlgebra2D::fuzzyPointCompare(nearestPoint, expectedNearestPoint, eps)) {
            qDebug() << "Failed to find nearest point:" << ppVar(pt) << ppVar(nearestPoint) << ppVar(expectedNearestPoint);
            result = false;
        }

        return result;
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (int channel : channels) {
        if (!histogramChannelShapeInfo.contains(channel)) {
            continue;
        }

        const qreal channelHighest = static_cast<qreal>(histogramChannelShapeInfo[channel].highest);
        if (channelHighest > overallHighest) {
            overallHighest = channelHighest;
        }
    }
```

#### AUTO 


```{c}
const auto t1 = zip_lo(a, b);
```

#### AUTO 


```{c}
auto it = level.conflictWithGroup.begin();
```

#### LAMBDA EXPRESSION 


```{c}
[mean, m_c1, m_c2](double x)
        {
            const double shiftedX = x - mean;
            return m_c1 * std::exp(-(shiftedX * shiftedX / m_c2));
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    DuplicateOption option;
                    option.readOptionSetting(prop->settings().data());

                    prop->setValue(option.duplicate_healing);
                }
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                KisDuplicateOptionProperties option;
                option.readOptionSetting(prop->settings().data());

                prop->setValue(option.duplicate_move_source_point);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString & arguments) {
        settingsDialog.setPreview(d->ffmpegPath % " -y " % d->applyVariables(arguments).replace("\n", " ")
                                  % " \"" % d->videoFilePath % "\"");
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        QPushButton *loggingButton = button(User3);
        if (loggingButton->isChecked()) {
            enableLogging();
        } else {
            disableLogging();
        }
    }
```

#### AUTO 


```{c}
const auto dataStride = (width - columnsToWork);
```

#### LAMBDA EXPRESSION 


```{c}
[image] (KisAnimationFrameCache *cache) { return cache->image() == image; }
```

#### LAMBDA EXPRESSION 


```{c}
[&](int index) {
                const int deflate = kComboBoxCompressionType->findData(2);
                const int lzw = kComboBoxCompressionType->findData(3);
                kComboBoxPredictor->setEnabled(index == deflate
                                               || index == lzw);
            }
```

#### AUTO 


```{c}
const auto channelPtrBegin = channelPtr.begin();
```

#### AUTO 


```{c}
const auto *data = event->mimeData();
```

#### LAMBDA EXPRESSION 


```{c}
[] (KisNodeSP node) {
            KisCroppedOriginalLayerInterface *croppedUpdate =
                    dynamic_cast<KisCroppedOriginalLayerInterface*>(node.data());
            if (croppedUpdate) {
                croppedUpdate->forceUpdateHiddenAreaOnOriginal();
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    ParticleOption option;
                    option.readOptionSetting(prop->settings().data());
                    prop->setValue(option.particle_scale_x);
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (int k : c.keys()) {
            if (k >= newRowCount) {
                c.remove(k);
                d->colorCount--;
            }
        }
```

#### AUTO 


```{c}
ORDER_BY(isPreferredColorSpace(lhs.format.colorSpace()),
                 isPreferredColorSpace(rhs.format.colorSpace()))
```

#### LAMBDA EXPRESSION 


```{c}
[parentCommand, undoAdapter] () {
                parentCommand->redo();

                if (undoAdapter) {
                    undoAdapter->addCommand(parentCommand);
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        /**
          * We must request shape layers to rerender areas outside image bounds
          */
        KisLayerUtils::forceAllHiddenOriginalsUpdate(m_d->rootNode);
    }
```

#### AUTO 


```{c}
const auto gpu =
        m_processor->getOptimizedLegacyGPUProcessor(OCIO::OptimizationFlags::OPTIMIZATION_DEFAULT, lut3DEdgeSize);
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
            prop->settings()->setPaintOpSize(prop->value().toReal());
        }
```

#### LAMBDA EXPRESSION 


```{c}
[state] () {
                state->filteredMainDevSavedCopy = new KisPaintDevice(*state->filteredMainDev);
                state->activeTransaction.reset(new KisTransaction(state->filteredMainDev));
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                    emit requestExplicitUpdateOutline();
                }
```

#### AUTO 


```{c}
auto it = m_d->transformedPoints.begin();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &node : nodes) {
        node->setVisible(!isVisible);
        node->setDirty();
    }
```

#### AUTO 


```{c}
auto subpathIt = d->subpaths.constBegin();
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QCursor &c) { this->BaseClass::useCursor(c); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &shape: m_d->shapes) {
            Q_UNUSED(shape);
            KoMeshGradientBackground *newBackground =
                new KoMeshGradientBackground(gradient, transform);

            newBackgrounds << toQShared(newBackground);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const VirtualChannelInfo &virtualChannelInfo : m_virtualChannels) {
        if (virtualChannelInfo.type() == VirtualChannelInfo::REAL && !virtualChannelInfo.isAlpha()) {
            channelsHistograms.append({m_channelsHistogram.data(), virtualChannelInfo.pixelIndex()});
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&](int i) {
        if (KisTabletDebugger::instance()->debugEnabled()) {
            QString pre = QString("[BLOCKED %1:]").arg(i);
            QTabletEvent *ev = static_cast<QTabletEvent*>(event);
            dbgTablet << KisTabletDebugger::instance()->eventToString(*ev, pre);
        }
    }
```

#### AUTO 


```{c}
auto index = m_d->currentArgs.meshTransform()->hitTestNode(mousePos, grabRadius);
```

#### AUTO 


```{c}
const auto *cfg = dynamic_cast<const KisCrossChannelFilterConfiguration*>(config.data());
```

#### AUTO 


```{c}
auto it = beginIt;
```

#### LAMBDA EXPRESSION 


```{c}
[firstFrameOfScene, timeOfNextScene, command] (KisNodeSP node){
                if (node->isAnimated() && node->isEditable(true)) {
                    Q_FOREACH(KisKeyframeChannel* keyframeChannel, node->keyframeChannels()) {
                        int timeIter = keyframeChannel->keyframeAt(firstFrameOfScene)
                                                                    ? firstFrameOfScene
                                                                    : keyframeChannel->nextKeyframeTime(firstFrameOfScene);

                        while (keyframeChannel->keyframeAt(timeIter) && timeIter < timeOfNextScene) {
                            keyframeChannel->removeKeyframe(timeIter, command);
                            timeIter = keyframeChannel->nextKeyframeTime(timeIter);
                        }
                    }
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    prop->setValue(prop->settings()->paintOpFlow());
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (KoColorSetSP cs : m_activeDocument->paletteList()) {
            m_rServer->addResource(cs);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
                auto t = frames->allKeyframeTimes().toList();
                std::sort(t.begin(), t.end());
                return t;
            }
```

#### AUTO 


```{c}
auto constSegmentIt2 = std::as_const(mesh).beginSegments();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &colorLabelStr : colorLabelsStr) {
        bool ok;
        const int colorLabel = colorLabelStr.toInt(&ok);
        if (ok) {
            colorLabels << colorLabel;
        }
    }
```

#### AUTO 


```{c}
const auto convertedTileX =
                tileWidth - static_cast<qint32>(columnsToWork);
```

#### AUTO 


```{c}
auto getChildContent      = [=](QString node){return actionXml.firstChildElement(node).text();};
```

#### LAMBDA EXPRESSION 


```{c}
[this, shared](){
            // We will first apply the transaction to the temporary filterDevice
            runAndSaveCommand(toQShared(shared->filterDeviceTransaction->endAndTake()), KisStrokeJobData::BARRIER, KisStrokeJobData::NORMAL);
            shared->filterDeviceTransaction.reset();

            if (!shared->filterDeviceBounds.intersects(
                    shared->filter()->neededRect(shared->processRect, shared->filterConfig().data(), shared->levelOfDetail()))) {
                return;
            }

            // Make a transaction, change the target device, and "end" transaction.
            // Should be useful for undoing later.
            QScopedPointer<KisTransaction> workingTransaction( new KisTransaction(shared->targetDevice()) );
            KisPainter::copyAreaOptimized(shared->processRect.topLeft(), shared->filterDevice, shared->targetDevice(), shared->processRect, shared->selection());
            runAndSaveCommand( toQShared(workingTransaction->endAndTake()), KisStrokeJobData::BARRIER, KisStrokeJobData::EXCLUSIVE );

            if (shared->shouldRedraw()) {
                QRect extraUpdateRect;
                qSwap(extraUpdateRect, m_d->nextExternalUpdateRect);

                shared->node()->setDirty(shared->processRect | extraUpdateRect);

               /**
                * Save the last update to be able to restore the
                * original state on the cancellation (even when
                * the cancellation step is explicitly prohibited)
                */
                m_d->nextExternalUpdateRect = shared->processRect;
            }
        }
```

#### AUTO 


```{c}
auto it = colorSpaceFactoryRegistry.constBegin();
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    ExperimentOption option;
                    option.readOptionSetting(prop->settings().data());

                    prop->setValue(option.windingFill);
                }
```

#### AUTO 


```{c}
inline auto rend(Cont &cont) -> decltype(declval<Cont>().rend()) {
    return cont.rend();
}
```

#### AUTO 


```{c}
auto it = std::upper_bound(fontWeights.rbegin(),
                                       fontWeights.rend(),
                                       context.currentGC()->font.weight(),
                                       std::greater<int>());
```

#### LAMBDA EXPRESSION 


```{c}
[] (qreal x, qreal y) { return qFuzzyCompare(x, y); }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QPair<int, qreal> &a, const QPair<int, qreal> &b)
            {
                return a.second < b.second;
            }
```

#### AUTO 


```{c}
const auto times = [&]() {
                auto t = frames->allKeyframeTimes().toList();
                std::sort(t.begin(), t.end());
                return t;
            }();
```

#### LAMBDA EXPRESSION 


```{c}
[]() {
                return KisSuspendResumePair(
                    new KisTestingStrokeStrategy("susp_u_", false, true, true),
                    QList<KisStrokeJobData*>());
            }
```

#### AUTO 


```{c}
auto itemIt = items.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (QString groupName : groupNames) {
        int lastRowGroup = 0;
        for (const KisSwatchGroup::SwatchInfo &info : groups[groupName].infoList()) {
            QColor c = info.swatch.color().toQColor();
            gc.fillRect(info.column * 4, (lastRow + info.row) * 4, 4, 4, c);
            lastRowGroup = qMax(lastRowGroup, info.row);
        }
        lastRow += (lastRowGroup + 1);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[index, pModel] {
           int row = index.row();
           KisDuplicateStoryboardCommand *command = new KisDuplicateStoryboardCommand(row, pModel);
           command->redo();
           pModel->pushUndoCommand(command);
        }
```

#### AUTO 


```{c}
const auto tileHeight = it->numContiguousRows(dev->y());
```

#### AUTO 


```{c}
const auto tileRowStride =
                (tileWidth - columnsToWork) * dstPixelSize;
```

#### AUTO 


```{c}
auto savedEvent = d->eventEater.savedEvent;
```

#### AUTO 


```{c}
auto m = KisQMicImageSP::create(node->name(), resultRect.width(), resultRect.height(), 4);
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractButton *button : m_d->colorButtonGroup->buttons()) {
        qobject_cast<KisColorLabelButton*>(button)->setSize(static_cast<uint>(size));
    }
```

#### AUTO 


```{c}
auto itB = chunkB.constBegin();
```

#### AUTO 


```{c}
auto it = std::find_if(m_cachedResources.begin(),
                               m_cachedResources.end(),
                               [this] (KoResourceSP res) {
                return res->resourceType().first == this->m_resourceType;
    });
```

#### AUTO 


```{c}
auto it = std::upper_bound(fontWeights.begin(),
                                       fontWeights.end(),
                                       propertyOrDefault(FontWeightId).toInt());
```

#### LAMBDA EXPRESSION 


```{c}
[](const QPair<int, qreal> &a, const QPair<int, qreal> &b)
                    {
                        return a.second < b.second;
                    }
```

#### AUTO 


```{c}
auto rangeBegin = updates.begin();
```

#### LAMBDA EXPRESSION 


```{c}
[] (const std::vector<NodeKey> &expectedPath) {

        const KoColorConversionSystem *system = KoColorSpaceRegistry::instance()->colorConversionSystem();

        Path path =
            system->findBestPath(expectedPath.front(), expectedPath.back());

        std::vector<NodeKey> realPath;

        Q_FOREACH (const Vertex *vertex, path.vertexes) {
            if (!vertex->srcNode->isEngine) {
                realPath.push_back(vertex->srcNode->key());
            }
        }
        realPath.push_back(path.vertexes.last()->dstNode->key());

        return realPath;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    ExperimentOption option;
                    option.readOptionSetting(prop->settings().data());
                    option.hardEdge = prop->value().toBool();
                    option.writeOptionSetting(prop->settings().data());
                }
```

#### AUTO 


```{c}
const auto basicInfo = [&]() {
        auto info{std::make_unique<JxlBasicInfo>()};
        JxlEncoderInitBasicInfo(info.get());
        info->xsize = static_cast<uint32_t>(bounds.width());
        info->ysize = static_cast<uint32_t>(bounds.height());
        {
            if (cs->colorDepthId() == Integer8BitsColorDepthID) {
                info->bits_per_sample = 8;
                info->exponent_bits_per_sample = 0;
                info->alpha_bits = 8;
                info->alpha_exponent_bits = 0;
            } else if (cs->colorDepthId() == Integer16BitsColorDepthID) {
                info->bits_per_sample = 16;
                info->exponent_bits_per_sample = 0;
                info->alpha_bits = 16;
                info->alpha_exponent_bits = 0;
#ifdef HAVE_OPENEXR
            } else if (cs->colorDepthId() == Float16BitsColorDepthID) {
                info->bits_per_sample = 16;
                info->exponent_bits_per_sample = 5;
                info->alpha_bits = 16;
                info->alpha_exponent_bits = 5;
#endif
            } else if (cs->colorDepthId() == Float32BitsColorDepthID) {
                info->bits_per_sample = 32;
                info->exponent_bits_per_sample = 8;
                info->alpha_bits = 32;
                info->alpha_exponent_bits = 8;
            }
        }
        if (cs->colorModelId() == RGBAColorModelID) {
            info->num_color_channels = 3;
            info->num_extra_channels = 1;
        } else if (cs->colorModelId() == GrayAColorModelID) {
            info->num_color_channels = 1;
            info->num_extra_channels = 1;
        } else if (cs->colorModelId() == CMYKAColorModelID) {
            info->num_color_channels = 4;
            info->num_extra_channels = 1;
        }
        info->uses_original_profile = JXL_TRUE;
        if (image->animationInterface()->hasAnimation() && cfg->getBool("haveAnimation", true)) {
            info->have_animation = JXL_TRUE;
            info->animation.have_timecodes = JXL_FALSE;
            info->animation.num_loops = 0;
            info->animation.tps_numerator = 1;
            info->animation.tps_denominator = static_cast<uint32_t>(image->animationInterface()->framerate());
        }
        return info;
    }();
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QModelIndex &parent, int first, int last) {
        for (int i = first; i <= last; i++) {
            QStandardItem *item = d->recentFilesModel.model().item(i);
            QUrl url = item->data().toUrl();
            QIcon icon = item->icon();
            if (url.isValid() && !icon.isNull()) {
                d->recentFiles->setUrlIcon(url, icon);
            }
        }
    }
```

#### AUTO 


```{c}
auto unmultipliedColorsConsistent = [this, i](T *d) { return !(std::abs(d[this->poses()[i]]) < std::numeric_limits<T>::epsilon()); };
```

#### LAMBDA EXPRESSION 


```{c}
[&](bool v) {
            if (JxlEncoderSetFrameLossless(frameSettings, v ? JXL_TRUE : JXL_FALSE) != JXL_ENC_SUCCESS) {
                errFile << "JxlEncoderSetFrameLossless failed";
                return false;
            }
            return true;
        }
```

#### AUTO 


```{c}
auto applyChangeToStrokes(KoCanvasBase *canvas, ModifyFunction modifyFunction)
-> decltype(modifyFunction(KoShapeStrokeSP()), void())
{
    KoSelection *selection = canvas->selectedShapesProxy()->selection();

    if (!selection) return;

    QList<KoShape*> shapes = selection->selectedEditableShapes();

    KUndo2Command *command = KoFlake::modifyShapesStrokes(shapes, modifyFunction);

    if (command) {
        canvas->addCommand(command);
    }
}
```

#### AUTO 


```{c}
auto result = endControlPoints();
```

#### AUTO 


```{c}
auto firstTenVersionExists = [] (QString a) {
        if (a == "testpattern.png") return true;
        if (a == "testpattern.0000.png") return true;
        if (a == "testpattern.0001.png") return true;
        if (a == "testpattern.0002.png") return true;
        if (a == "testpattern.0003.png") return true;
        if (a == "testpattern.0004.png") return true;
        if (a == "testpattern.0005.png") return true;
        if (a == "testpattern.0006.png") return true;
        if (a == "testpattern.0007.png") return true;
        if (a == "testpattern.0008.png") return true;
        if (a == "testpattern.0009.png") return true;
        if (a == "testpattern.0010.png") return true;
        return false;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[](KisNodeSP node) -> bool {
                return !node->supportsLodMoves();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Path &p : currentPaths) {
            const Node* endNode = p.endNode();
            for (Vertex* v : endNode->outputVertexes) {
                if (v->dstNode->isInitialized && !p.contains(v->dstNode)) {
                    Path newP = p;  // Candidate
                    newP.appendVertex(v);
                    Node* newEndNode = v->dstNode;
                    if (newEndNode == dstNode) {
                        if (pQC.isGoodPath(newP)) { // Victory
                            newP.isGood = true;
                            return newP;
                        } else if (pQC.lessWorseThan(newP, currentBestPath)) {
                            if (newP.startNode() && newP.endNode() && currentBestPath.startNode() && currentBestPath.endNode()) {
                                Q_ASSERT(newP.startNode()->id() == currentBestPath.startNode()->id());
                                Q_ASSERT(newP.endNode()->id() == currentBestPath.endNode()->id());
                                // Can we do better than dumping memory values???
                                // warnPigment << pQC.lessWorseThan(newP, currentBestPath) << " " << newP << "  " << currentBestPath;
                                currentBestPath = newP;
                            }
                        }
                    } else {
                        // This is an incomplete path. Check if there's a better way to get to its endpoint.
                        Node2PathHash::Iterator it = node2path.find(newEndNode);
                        if (it != node2path.end()) {
                            Path &p2 = it.value();
                            if (pQC.lessWorseThan(newP, p2)) {
                                p2 = newP;
                                possiblePaths.append(newP);
                            }
                        } else {
                            node2path.insert(newEndNode, newP);
                            possiblePaths.append(newP);
                        }
                    }
                }
            }
            possiblePaths.removeAll(p); // Remove from list of remaining paths
        }
```

#### AUTO 


```{c}
auto layer = m_document->referenceImagesLayer();
```

#### LAMBDA EXPRESSION 


```{c}
[doc] (KisNodeSP node) {
            if (KisNodeFilterInterface *layer = dynamic_cast<KisNodeFilterInterface*>(node.data())) {
                KisFilterConfigurationSP filterConfig = layer->filter();
                if (!filterConfig) return;

                QList<KoResourceLoadResult> linkedResources = filterConfig->linkedResources(KisGlobalResourcesInterface::instance());

                Q_FOREACH (const KoResourceLoadResult &result, linkedResources) {
                    KIS_SAFE_ASSERT_RECOVER(result.type() != KoResourceLoadResult::EmbeddedResource) { continue; }

                    KoResourceSP resource = result.resource();

                    if (!resource) {
                        qWarning() << "WARNING: KisDocument::lockAndCloneForSaving failed to fetch a resource" << result.signature();
                        continue;
                    }

                    QBuffer buf;
                    buf.open(QBuffer::WriteOnly);

                    KisResourceModel model(resource->resourceType().first);
                    bool res = model.exportResource(resource, &buf);

                    buf.close();

                    if (!res) {
                        qWarning() << "WARNING: KisDocument::lockAndCloneForSaving failed to export resource" << result.signature();
                        continue;
                    }

                    buf.open(QBuffer::ReadOnly);

                    res = doc->d->linkedResourceStorage->importResource(resource->resourceType().first + "/" + resource->filename(), &buf);

                    buf.close();

                    if (!res) {
                        qWarning() << "WARNING: KisDocument::lockAndCloneForSaving failed to import resource" << result.signature();
                        continue;
                    }
                }

            }
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr double touchDragDistance {8.0};
```

#### AUTO 


```{c}
auto sizePolicy = this->sizePolicy();
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    KisSprayOptionProperties option;
                    option.readOptionSetting(prop->settings().data());
                    prop->setValue(option.coverage);
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (Payload& p : m_queue) {
                p.m_data = new uint8_t[m_canvas->image()->width() * m_canvas->image()->height() * 4];
            }
```

#### LAMBDA EXPRESSION 


```{c}
[](KisUniformPaintOpProperty *prop) {
                    KisSprayOptionProperties option;
                    option.readOptionSetting(prop->settings().data());
                    prop->setValue(option.coverage());
                }
```

#### CONST EXPRESSION 


```{c}
static constexpr int levelOfPressureResolution = 1024;
```

#### LAMBDA EXPRESSION 


```{c}
[minPixel, scale](quint8 pixel) {
                                       return pow2(255 - quint8((pixel - minPixel) * scale)) / 255;
                                   }
```

#### LAMBDA EXPRESSION 


```{c}
[=](bool checked) {
            KisConfig cfg(false);
            // It is safe to modify `enabledNewsLangs` here, because the slots
            // are called synchronously on the UI thread so there is no need
            // for explicit synchronization.
            if (checked) {
                enabledNewsLangs->insert(QString(code));
            } else {
                enabledNewsLangs->remove(QString(code));
            }
            cfg.writeList(newsLangConfigName, enabledNewsLangs->values());
        }
```

#### AUTO 


```{c}
auto levelIt = group.levels.begin();
```

#### AUTO 


```{c}
auto it1 = rects.begin();
```

#### LAMBDA EXPRESSION 


```{c}
[&](QEvent::Type type) {
        QPointF emptyPos;
        qreal zero = 0.0;
        QTabletEvent e(type, emptyPos, emptyPos, 0, m_devices.at(m_currentDevice).currentPointerType,
                       zero, 0, 0, zero, zero, 0, Qt::NoModifier,
                       m_devices.at(m_currentDevice).uniqueId, Qt::NoButton, (Qt::MouseButtons)0);
        qApp->sendEvent(qApp->activeWindow(), &e);
    }
```

#### AUTO 


```{c}
auto preset = rserver->resource("", "", m_currentPreset->name());
```

#### AUTO 


```{c}
auto tool = toolManager->toolById(canvas(), toolManager->activeToolId());
```

#### AUTO 


```{c}
const auto pickAboveThis = [&]() {
        if (!d->m_newNodes->isEmpty()) {
            return d->m_newNodes->last()->prevSibling();
        } else {
            return d->m_nodes->last()->prevSibling();
        }
    };
```

#### AUTO 


```{c}
auto *tileItStart = convertedTile.data();
```

#### AUTO 


```{c}
auto path = QFileDialog::getOpenFileName(m_dialog,
                                             i18n("Import Shortcuts"),
                                             QDir::currentPath(),
                                             i18n("Shortcuts (*.shortcuts)"));
```

#### AUTO 


```{c}
auto it8 = forest.insert(childEnd(forest), 8);
```

#### CONST EXPRESSION 


```{c}
constexpr int waitThreadTimeoutMs = 5000;
```

#### LAMBDA EXPRESSION 


```{c}
[&pointIndex, &visitor](const QPoint &point) -> void
                {
                    if (pointIndex > 0) {
                        visitor(point);
                    }
                    ++pointIndex;
                }
```

#### AUTO 


```{c}
auto bakeGradient = [canvasResourcesInterface, localResourcesSnapshot] (KoAbstractGradientSP gradient) {
            if (gradient && !gradient->requiredCanvasResources().isEmpty()) {

                /**
                 * Since we haven't cloned the required resources when putting them
                 * into the local storage (which is rather questionable), we need to
                 * clone the gradients explicitly before modification.
                 */

                KoAbstractGradientSP clonedGradient =
                    gradient->cloneAndBakeVariableColors(canvasResourcesInterface);

                localResourcesSnapshot->removeResource(gradient);
                localResourcesSnapshot->addResource(clonedGradient);
            }
        };
```

#### RANGE FOR STATEMENT 


```{c}
for (KisLevelsCurve &levelsCurve : levelsCurves) {
            levelsCurve.setInputBlackPoint(minBlackPoint);
            levelsCurve.setInputWhitePoint(maxWhitePoint);
        }
```

#### CONST EXPRESSION 


```{c}
static constexpr double showControlsAreaRadius{4.0};
```

#### LAMBDA EXPRESSION 


```{c}
[affected, offset, cmd] (KisNodeSP node) {
                const int startFrame = affected.start();
                if (node->isAnimated()) {
                    Q_FOREACH(KisKeyframeChannel* keyframeChannel, node->keyframeChannels()) {
                        if (keyframeChannel) {
                            if (offset > 0) {
                                int timeIter = affected.isInfinite() ?
                                                        keyframeChannel->lastKeyframeTime()
                                                      : keyframeChannel->activeKeyframeTime(affected.end());

                                KisKeyframeSP iterEnd = keyframeChannel->keyframeAt(keyframeChannel->previousKeyframeTime(startFrame));

                                while (keyframeChannel->keyframeAt(timeIter) &&
                                       keyframeChannel->keyframeAt(timeIter) != iterEnd) {
                                    keyframeChannel->moveKeyframe(timeIter, timeIter + offset, cmd);
                                    timeIter = keyframeChannel->previousKeyframeTime(timeIter);
                                }

                            } else {
                                ENTER_FUNCTION() << ppVar(startFrame);
                                int timeIter = keyframeChannel->keyframeAt(startFrame) ? startFrame : keyframeChannel->nextKeyframeTime(startFrame);

                                KisKeyframeSP iterEnd = affected.isInfinite() ?
                                                            nullptr
                                                          : keyframeChannel->keyframeAt(keyframeChannel->nextKeyframeTime(affected.end()));

                                while (keyframeChannel->keyframeAt(timeIter) != iterEnd) {
                                    keyframeChannel->moveKeyframe(timeIter, timeIter + offset, cmd);
                                    timeIter = keyframeChannel->nextKeyframeTime(timeIter);
                                }
                            }
                        }
                    }
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[dialog, stops, this]() mutable
                      {
                          stops[m_selectedStop].type = COLORSTOP;
                          stops[m_selectedStop].color = dialog->getCurrentColor();
                          m_gradient->setStops(stops);
                          emit sigSelectedStop(m_selectedStop);
                          emit updateRequested();
                      }
```

#### AUTO 


```{c}
auto pixmap = icon.pixmap(m_preview->width(), m_preview->height());
```

#### CONST EXPRESSION 


```{c}
constexpr int appmodel_PACKAGE_FULL_NAME_MAX_LENGTH = 127;
```

#### LAMBDA EXPRESSION 


```{c}
[this]()
            {
                KisNodeSP selectionMask = locateSelectionMaskUnderCursor(m_currentPos, m_currentModifiers);
                if (selectionMask) {
                    this->useCursor(KisCursor::moveSelectionCursor());
                } else {
                    this->resetCursorStyle();
                }
            }
```

#### AUTO 


```{c}
const auto *srcPixel =
            reinterpret_cast<const KoRgbF32Traits::Pixel *>(src);
```

#### AUTO 


```{c}
auto it = frame.frameTiles.begin();
```

#### LAMBDA EXPRESSION 


```{c}
[this, args]() {
        m_s->currentTransformArgs = args;
        m_updateTimer.restart();
        // sanity check that no job has been squeezed inbetween
        KIS_SAFE_ASSERT_RECOVER_RETURN(!m_pendingUpdateArgs);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&points](const QPoint &point) -> void { points.append(point); }
```

#### LAMBDA EXPRESSION 


```{c}
[](float i) -> float {
            if (std::numeric_limits<V>::min() > i) {
                return 0;
            } else if (std::numeric_limits<V>::max() < i) {
                return 0;
            } else {
                return static_cast<V>(i);
            }
        }
```

#### AUTO 


```{c}
auto it = typedResources.begin();
```

#### AUTO 


```{c}
const auto t4 = batch<T, A>::load(srcPtr + batch<T, A>::size * 3, U{});
```

#### AUTO 


```{c}
auto it = parentProperties.m_d->properties.constBegin();
```

#### AUTO 


```{c}
auto &transactionPtr
```

#### AUTO 


```{c}
inline auto set_zero(const batch<T, A> &src, const batch_bool<T, A> &mask) noexcept
{
    return xsimd::select(mask, xsimd::batch<T, A>(0), src);
}
```

#### AUTO 


```{c}
auto root = renderTree.insert(childBegin(renderTree), shape);
```

#### LAMBDA EXPRESSION 


```{c}
[] (KisNodeSP node) {
            return bool(dynamic_cast<T*>(node.data()));
        }
```

#### AUTO 


```{c}
const auto pixelSize = rgbaFloat32bitcolorSpace->pixelSize();
```

#### LAMBDA EXPRESSION 


```{c}
[this](KisNodeSP node) {
                                                 return
                                                     !KisLayerUtils::checkIsCloneOf(node, m_nodes) &&
                                                     node->isEditable();
                                             }
```

#### RANGE FOR STATEMENT 


```{c}
for (QString fileName : possibleNames) {
                QFile file(fileName);
                if (file.exists()) {
                    file.open(QIODevice::ReadOnly);
                    return file.readAll();
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[](const Handle &lhs, const Handle &rhs)
        {
            return qFuzzyCompare(lhs.position, rhs.position) ? lhs.index < rhs.index : lhs.position < rhs.position;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &pair : m_d->asyncRenderers) {
            if (!pair.renderer->isActive()) {
                const int currentDirtyFrame = m_d->stillDirtyFrames.takeFirst();

                initializeRendererForFrame(pair.renderer.get(), pair.image, currentDirtyFrame);
                pair.renderer->startFrameRegeneration(pair.image, currentDirtyFrame);
                hadWorkOnPreviousCycle = true;
                m_d->framesInProgress.append(currentDirtyFrame);
                break;
            }
        }
```

#### CONST EXPRESSION 


```{c}
constexpr bool withAllSupportedEntry = true;
```

#### AUTO 


```{c}
const auto &btn
```

#### RANGE FOR STATEMENT 


```{c}
for (const KisMetaData::Value &it : values) {
        dataIt[0] = it.asRational().numerator;
        dataIt[1] = it.asRational().denominator;
        dataIt += 2;
    }
```

#### AUTO 


```{c}
auto row = rowsToWork;
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
            KisNodeListSP r(new QList<KisNodeSP>());
            KisLayerUtils::recursiveApplyNodes(
                currentNode,
                [&](KisNodeSP item) {
                    auto *paintLayer =
                        dynamic_cast<KisPaintLayer *>(item.data());
                    if (paintLayer
                        && paintLayer->visible(false) == visibility) {
                        r->append(item);
                    }
                });
            return r;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, md5] (KoResourceSP res) {
                                   return res->resourceType().first == this->m_resourceType &&
                                       res->md5Sum() == md5;
                               }
```

#### AUTO 


```{c}
auto it = m_d->selectedNodes.begin();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &node : nodes) {
        auto layer = qobject_cast<KisPaintLayer*>(node.data());
        if (layer) {
            KisLayerPropertiesIcons::setNodePropertyAutoUndo(node, KisLayerPropertiesIcons::alphaLocked, !isAlphaLocked, m_d->view->image());
        }
    }
```

#### AUTO 


```{c}
auto *pluginBase = factory->create<QObject>();
```

#### AUTO 


```{c}
inline auto rbegin(Cont &cont) -> decltype(declval<Cont>().rbegin()) {
    return cont.rbegin();
}
```

#### LAMBDA EXPRESSION 


```{c}
[] (KisStrokeJob *job) {
            return job->isOwnJob();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {
        KisNodeSP node = m_resources->currentNode();
        const int time = node->paintDevice()->defaultBounds()->currentTime();
        const bool isLodNMode = node->paintDevice()->defaultBounds()->currentLevelOfDetail() > 0;

        KisRasterKeyframeChannel* channel = dynamic_cast<KisRasterKeyframeChannel*>(node->getKeyframeChannel(KisKeyframeChannel::Raster.id()));
        if (channel) {
            KisKeyframeSP keyframe = channel->keyframeAt(time);
            if (!keyframe && m_autokeyMode != KisAutoKey::NONE) {

                /**
                 * In instant preview mode we just reuse the LodN plane.
                 * If autokey mode is "blank", then we just clear the LodN
                 * plane.
                 */
                if (!isLodNMode) {
                    int activeKeyTime = channel->activeKeyframeTime(time);

                    m_autokeyCommand.reset(new KUndo2Command());

                    KUndo2Command *keyframeCommand = new  KisCommandUtils::SkipFirstRedoWrapper(nullptr, m_autokeyCommand.data());

                    if (m_autokeyMode == KisAutoKey::DUPLICATE) {
                        channel->copyKeyframe(activeKeyTime, time, keyframeCommand);
                    } else { // Otherwise, create a fresh keyframe.
                        channel->addKeyframe(time, keyframeCommand);
                    }

                    keyframe = channel->keyframeAt(time);
                    KIS_SAFE_ASSERT_RECOVER_RETURN(keyframe);

                    // Use the same color label as previous keyframe...
                    KisKeyframeSP previousKey = channel->keyframeAt(activeKeyTime);
                    if (previousKey) {
                        keyframe->setColorLabel(previousKey->colorLabel());
                    }
                } else {
                    if (m_autokeyMode == KisAutoKey::BLANK) {
                        const QRect originalDirtyRect = node->exactBounds();
                        KisTransaction transaction(node->paintDevice());
                        node->paintDevice()->clear();
                        node->setDirty(originalDirtyRect);
                        m_autokeyCommand.reset(transaction.endAndTake());
                    }
                }
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const KisKeyframeChannel* channel, int time) {
        this->slotKeyframeChanged(channel, time);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        Q_FOREACH (KisNodeSP node, m_s->processedNodes) {
            m_s->prevDirtyRects[node] = node->extent();

            if (m_s->previewLevelOfDetail > 0) {
                KisLodTransform t(m_s->previewLevelOfDetail);
                m_s->prevDirtyPreviewRects[node] = t.map(node->extent());
            }

        }

        m_s->updatesFacade->disableDirtyRequests();
        m_s->updatesDisabled = true;
    }
```

#### AUTO 


```{c}
auto sendTabletEvent = [&](QTabletEvent::Type t){
            handleTabletEvent(w, localPosF, globalPosF, currentDevice, currentPointerType,
                              button, buttons, pressureNew, tiltX, tiltY, tangentialPressure, rotation, z,
                              m_devices.at(m_currentDevice).uniqueId, keyboardModifiers, t, packet.pkTime);
        };
```

#### LAMBDA EXPRESSION 


```{c}
[state] () {
                state->activeTransaction.reset();
            }
```

#### LAMBDA EXPRESSION 


```{c}
[] (const QModelIndex &lhs, const QModelIndex &rhs) {
                  return lhs.column() > rhs.column();
              }
```

#### AUTO 


```{c}
auto *r = dynamic_cast<KisReferenceImage*>(s);
```

#### AUTO 


```{c}
const auto t3 = zip_lo(b, d);
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {
        emit sigFinished(m_d->prefilterOnly);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& rc: region) {
        if (f->allowsSplittingIntoPatches()) {
            QVector<QRect> tiles = splitRectIntoPatches(rc, optimalPatchSize());

            for(const auto& tile: tiles) {
                KisProcessingInformation dstCfg(dev, tile.topLeft(), KisSelectionSP());
                addJobConcurrent(jobsData, [=]() {
                    const_cast<QSharedPointer<bool> &>(cookie).clear();

                    f->generate(dstCfg, tile.size(), filterConfig, helper->updater());

                    // HACK ALERT!!!
                    // this avoids cyclic loop with KisRecalculateGeneratorLayerJob::run()
                    const_cast<KisGeneratorLayerSP &>(layer)->setDirtyWithoutUpdate({tile});
                });
            }
        } else {
            KisProcessingInformation dstCfg(dev, rc.topLeft(), KisSelectionSP());

            addJobSequential(jobsData, [=]() {
                const_cast<QSharedPointer<bool>&>(cookie).clear();

                f->generate(dstCfg, rc.size(), filterConfig, helper->updater());

                // HACK ALERT!!!
                // this avoids cyclic loop with KisRecalculateGeneratorLayerJob::run()
                const_cast<KisGeneratorLayerSP &>(layer)->setDirtyWithoutUpdate({rc});
            });
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool toggled)
        {
            if (toggled) {
                setColorType(KisGradientWidgetsUtils::Custom);
            }
            emit colorTypeChanged(KisGradientWidgetsUtils::Custom);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](KisNodeSP node) {
                KisLayer *layer = dynamic_cast<KisLayer*>(node.data());
                return layer ? layer->channelFlags() : QBitArray();
            }
```

#### AUTO 


```{c}
const auto srcPixelSize = dev->pixelSize();
```

#### AUTO 


```{c}
const auto data_i = uint_v::load(static_cast<const typename uint_v::value_type *>(data), U{});
```

#### AUTO 


```{c}
auto shouldIncludeShape =
        [includedShapes] (KoShape *shape) {
            // included shapes are guaranteed to be visible
            return includedShapes.find(shape) != end(includedShapes);
        };
```

#### CONST EXPRESSION 


```{c}
static constexpr int leading_letter_penalty = -5;
```

#### AUTO 


```{c}
auto it = std::make_reverse_iterator(nodesToRemove.end());
```

#### RANGE FOR STATEMENT 


```{c}
for (Shape* shape : shapeList) {
            QVERIFY(test.contains(shape->name()) == true);
            delete shape;
        }
```

#### AUTO 


```{c}
auto *layout = static_cast<KisWindowLayoutResource*>(resource);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        m_d->strokeCompletionHasBeenStarted = true;

        QVector<KisStrokeJobData *> nonCancellableFinishJobs;

        finalizeStrokeImpl(nonCancellableFinishJobs, true);

        KritaUtils::addJobBarrier(nonCancellableFinishJobs, [this]() {
            KisStrokeStrategyUndoCommandBased::finishStrokeCallback();
        });

        for (auto it = nonCancellableFinishJobs.begin(); it != nonCancellableFinishJobs.end(); ++it) {
            (*it)->setCancellable(false);
        }

        this->addMutatedJobs(nonCancellableFinishJobs);

    }
```

#### LAMBDA EXPRESSION 


```{c}
[saveLocation] (const QString &filename) {
                             return QFileInfo(saveLocation + "/" + filename).exists();
                         }
```

#### LAMBDA EXPRESSION 


```{c}
[&] { fillProfile(defaultProfile); }
```

#### AUTO 


```{c}
auto requestedPath = QProcessEnvironment::systemEnvironment().value("KRITA_PLUGIN_PATH");
```

#### AUTO 


```{c}
auto * paintLayer = dynamic_cast<KisPaintLayer*>(item.data());
```

#### LAMBDA EXPRESSION 


```{c}
[this](){ QGuiApplication::clipboard()->setText(m_page->txtBugInfo->toPlainText()); }
```

#### LAMBDA EXPRESSION 


```{c}
[movePairs, copy] () -> KUndo2Command* {
                bool result = false;

                QScopedPointer<KUndo2Command> cmd(new KUndo2Command());

                using MoveChain = QList<FrameItem>;


                QHash<FrameItem, MoveChain> moveMap;
                Q_FOREACH (const FrameMovePair &pair, movePairs) {
                    moveMap.insert(pair.first, {pair.second});
                }

                auto it = moveMap.begin();
                while (it != moveMap.end()) {
                    MoveChain &chain = it.value();
                    const FrameItem &lastFrame = chain.last();

                    auto tailIt = moveMap.find(lastFrame);

                    if (tailIt == it || tailIt == moveMap.end()) {
                        ++it;
                        continue;
                    }

                    chain.append(tailIt.value());
                    tailIt = moveMap.erase(tailIt);
                    // no incrementing! we are going to check the new tail now!
                }

                for (it = moveMap.begin(); it != moveMap.end(); ++it) {
                    MoveChain &chain = it.value();
                    chain.prepend(it.key());
                    KIS_SAFE_ASSERT_RECOVER(chain.size() > 1) { continue; }

                    bool isCycle = false;
                    if (chain.last() == chain.first()) {
                        isCycle = true;
                        chain.takeLast();
                    }

                    auto frameIt = chain.rbegin();

                    FrameItem dstItem = *frameIt++;

                    while (frameIt != chain.rend()) {
                        FrameItem srcItem = *frameIt++;

                        if (!isCycle) {
                            moveOneFrameItem(srcItem, dstItem, copy, cmd.data());
                        } else {
                            swapOneFrameItem(srcItem, dstItem, cmd.data());
                        }

                        dstItem = srcItem;
                        result = true;
                    }
                }

                return result ? new KisCommandUtils::SkipFirstRedoWrapper(cmd.take()) : 0;
        }
```

#### AUTO 


```{c}
auto constSegmentIt2 = std::as_const(mesh).find(SegmentIndex(NodeIndex(0,0), 1));
```

#### LAMBDA EXPRESSION 


```{c}
[=]() { return new T(p1); }
```

#### LAMBDA EXPRESSION 


```{c}
[dialog, segments, this]() mutable
                        {
                            KoColor color;
                            color.fromQColor(dialog->currentColor());
                            if (m_selectedHandle.index == 0) {
                                segments[0]->setStartType(COLOR_ENDPOINT);
                                segments[0]->setStartColor(color);
                            } else {
                                segments[m_selectedHandle.index - 1]->setEndType(COLOR_ENDPOINT);
                                segments[m_selectedHandle.index - 1]->setEndColor(color);
                                if (m_selectedHandle.index < segments.size()) {
                                    segments[m_selectedHandle.index]->setStartType(COLOR_ENDPOINT);
                                    segments[m_selectedHandle.index]->setStartColor(color);
                                }
                            }
                            emit selectedHandleChanged();
                            emit updateRequested();
                        }
```

#### AUTO 


```{c}
auto fuzzyComparePoint = [&] (QPointF a, QPointF b) -> bool {
            return fuzzyCompare(a.x(), b.x()) && fuzzyCompare(a.y(), b.y()); };
```

#### AUTO 


```{c}
auto *dst = reinterpret_cast<Pixel *>(it->rawData());
```

#### AUTO 


```{c}
auto i = d->actionCollections.constBegin();
```

#### LAMBDA EXPRESSION 


```{c}
[this](qreal overscroll){
       qreal currentOffset = m_d->verticalHeader->valueOffset();
       m_d->verticalHeader->setValueOffset(currentOffset - overscroll * m_d->verticalHeader->step() * 0.25);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        QMutexLocker l(&m_d->dirtyRectsMutex);

        executeAndAddCommand(new KisDisableDirtyRequestsCommand(m_d->updatesFacade, KisDisableDirtyRequestsCommand::FINALIZING), Clear, KisStrokeJobData::BARRIER);

        m_d->updateTimer.start();
    }
```

#### AUTO 


```{c}
auto frameHeader = []() {
                auto header = std::make_unique<JxlFrameHeader>();
                JxlEncoderInitFrameHeader(header.get());
                return header;
            }();
```

#### AUTO 


```{c}
auto rectIter = borderRegion.begin();
```

#### AUTO 


```{c}
const auto c1c2 = ((v2 & mask) << 16) | (v1 & mask);
```

#### LAMBDA EXPRESSION 


```{c}
[priority] (const Private::PriorityPair &a) { return a.first > priority; }
```

#### AUTO 


```{c}
const auto inputFileName = TestUtil::fetchDataFileLazy("/sources/DX-MON/loading_16.jxl");
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool){
        if (m_d->canvas) {
            m_d->canvas->animationPlayer()->previousMatchingKeyframe();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, gradient] (KoShapeStrokeSP stroke) {
                m_d->applyFillGradientStops(stroke, gradient);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KisAutoLevels::ChannelHistogram &channelHistogram : channelsHistograms) {
        shadowsOutput.append(shadowsNormalizedColor[channelHistogram.channel]);
        highlightsOutput.append(highlightsNormalizedColor[channelHistogram.channel]);
        midtonesOutput.append(midtonesNormalizedColor[channelHistogram.channel]);
    }
```

#### AUTO 


```{c}
const auto *frames = projection->paintDevice()->keyframeChannel();
```

#### AUTO 


```{c}
auto clients = guiFactory()->clients();
```

#### AUTO 


```{c}
auto verifyFileExists = [optionalFolderCheck, resourceType] (KoResourceSP res) {
        if (optionalFolderCheck.isEmpty()) return;

        const QString filePath = optionalFolderCheck + "/" + resourceType + "/" + res->filename();

        if (!QFileInfo(filePath).exists()) {
            qWarning() << "Couldn't find a file in the resource storage:";
            qWarning() << "    " << ppVar(res->filename());
            qWarning() << "    " << ppVar(optionalFolderCheck);
            qWarning() << "    " << ppVar(filePath);
        }

        QVERIFY(QFileInfo(filePath).exists());
    };
```

