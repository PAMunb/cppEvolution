#### AUTO 


```{c}
const auto modelListActions = m_modelList->actionCollection()->actions();
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction* action : modelListActions) {
        actionCollection()->addAction(action->objectName(), action);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& ext : extList) {
        if (fileName.endsWith(ext, Qt::CaseInsensitive)) {
            return true;
        }
    }
```

