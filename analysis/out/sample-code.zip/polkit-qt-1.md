#### AUTO 


```{c}
const auto &value = entry.second;
```

#### AUTO 


```{c}
const auto &entry
```

#### AUTO 


```{c}
const auto &key = entry.first;
```

#### AUTO 


```{c}
auto ret = polkit_details_new();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &entry: details.toStdMap()) {
        const auto &key = entry.first;
        const auto &value = entry.second;

        polkit_details_insert(ret, key.toUtf8().constData(), value.toUtf8().data());
    }
```

#### AUTO 


```{c}
auto pk_details = Authority::Private::convertDetailsMap(details);
```

