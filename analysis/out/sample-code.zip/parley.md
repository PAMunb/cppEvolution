#### RANGE FOR STATEMENT 


```{c}
for (int i : translationIndices) {
            // generate text string representation
            m_text.append(expression->translation(i)->text());
            m_text.append(" - ");

            // fill in word types independent of pointers
            KEduVocWordType *type = expression->translation(i)->wordType();

            if (type) { // check if it has a type != 0
                exp.wordTypes[i].grammarType = expression->translation(i)->wordType()->wordType();

                // this may seem weird, but the root element is "word types" so no need to copy that one.
                while (type->parent()) {
                    exp.wordTypes[i].wordType.prepend(type->name());
                    type = static_cast<KEduVocWordType *>(type->parent());
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QPair<QString, QRect> rect : qAsConst(m_rects)) {
        if (!m_rects.isEmpty() && rect == m_rects[0]) {
            QMargins margins = contentMargins();
            rect.second =
                QRect(QPoint(margins.left(), margins.top()), rect.second.size() - QSize(margins.right() + margins.left(), margins.bottom() + margins.top()));
        }
        renderRect(rect.first, rect.second, &p, fastScale);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &tenseName : tenses) {
            tenseList->addItem(QStringLiteral("%1").arg(i++, 2).append(TENSE_TAG).append(tenseName));
            tenseIndex.append(i);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &choice : qAsConst(choices)) {
                    m_choicesModel->insertRow(multipleChoiceListView->model()->rowCount());
                    m_choicesModel->setData(m_choicesModel->index(multipleChoiceListView->model()->rowCount() - 1), choice);
                }
```

#### LAMBDA EXPRESSION 


```{c}
[=] {practiceModeSelected(Prefs::EnumPracticeMode::ComparisonPractice);}
```

#### RANGE FOR STATEMENT 


```{c}
for (int k : translationIndices) {
        vlist.push_back(QVariant(k));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (TestEntry *entry : qAsConst(m_allTestEntries)) {
        if (entry->correctAtFirstAttempt()) {
            count++;
        }
    }
```

#### AUTO 


```{c}
auto iter = m_conjugationLineEdits.cbegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &filename : filenames) {
        QFileInfo info(filename);
        m_timestamps.append(info.lastModified());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (int entry : qAsConst(m_entries)) {
        if (m_gradeChanged) {
            m_doc->entry(entry)->translation(m_translationTo).gradeFrom(m_translationFrom).setGrade(gradebox->currentIndex());
        }
        if (m_totalCountChanged) {
            m_doc->entry(entry)->translation(m_translationTo).gradeFrom(m_translationFrom).setPracticeCount(totalCountEdit->value());
        }
        if (m_wrongCountChanged) {
            m_doc->entry(entry)->translation(m_translationTo).gradeFrom(m_translationFrom).setBadCount(badCountEdit->value());
        }
        if (m_practiceDateChanged) {
            m_doc->entry(entry)->translation(m_translationTo).gradeFrom(m_translationFrom).setPracticeDate(queryDateEdit->dateTime());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : indexes) {
        mimeData->addContainer(static_cast<KEduVocContainer *>(index.internalPointer()));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &entry : entries) {
        if (entry.status() != KNS3::Entry::Installed) {
            continue;
        }
        ++numberInstalled;
        // check mime type and if kvtml, open it
        const QStringList installedFiles = entry.installedFiles();
        for (const QString &file : installedFiles) {
            QMimeType mimeType = db.mimeTypeForFile(file);
            qDebug() << "KNS2 file of mime type:" << db.mimeTypeForFile(file).name();
            if (mimeType.inherits(QStringLiteral("application/x-kvtml"))) {
                ParleyMainWindow::instance()->addRecentFile(QUrl::fromLocalFile(file), QString()); ///@todo: title!
                fileName = file;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KEduVocContainer *child : childContainers) {
        lessonsList << static_cast<KEduVocLesson *>(child);
        lessonsList += flattenLessons(static_cast<KEduVocLesson *>(child));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (CollectionWidget *cw : qAsConst(m_collectionWidgets)) {
        cw->updateDue();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &ext : qAsConst(extensions)) {
        QString s = m_latexFilename;
        s.replace(QLatin1String(".eps"), ext);
        QFile f(s);
        f.remove();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=] {
            slotPracticeButtonClicked(urlString);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (KEduVocExpression *entry : entries) {
        KEduVocTranslation &translation(*entry->translation(translationIndex));
        evaluateWord(translation, translation.text());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &tense : conjugationTenses) {
        if (m_tenses.contains(tense)) {
            const QList<KEduVocWordFlags> pronouns = translation->getConjugation(tense).keys();
            for (const KEduVocWordFlags &pronoun : pronouns) {
                KEduVocText grade = translation->getConjugation(tense).conjugation(pronoun);
                if (!isBlocked(&(grade))) {
                    // just need to find any form that is not blocked for generating test entries
                    // exact filtering is done later in conjugationTestEntries
                    return false;
                }
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=] {
            slotRemoveButtonClicked(urlString);
        }
```

#### AUTO 


```{c}
auto statisticsModel = qobject_cast<StatisticsModel *>(model());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : qAsConst(themesAvailable)) {
        QString themePath = lookupDirectory + '/' + file;
        KGameTheme *atheme = new KGameTheme(groupName);

        if (atheme->load(themePath)) {
            QString themeName = atheme->themeProperty(QStringLiteral("Name"));
            // Add underscores to avoid duplicate names.
            while (themeMap.contains(themeName))
                themeName += '_';
            themeMap.insert(themeName, atheme);
            QListWidgetItem *item = new QListWidgetItem(themeName, ui.themeList);

            // Find if this is our currently configured theme
            if (themePath == initialSelection) {
                initialFound = true;
                ui.themeList->setCurrentItem(item);
                _k_updatePreview();
            }
        } else {
            delete atheme;
        }
    }
```

#### AUTO 


```{c}
auto container = doc.wordTypeContainer()->childOfType(KEduVocWordFlag::Verb);
```

#### RANGE FOR STATEMENT 


```{c}
for (KEduVocExpression *entry : qAsConst(m_currentSelection[setNo])) {
                // Set the from and to translation for the entry itself.
                TestEntry *testEntry = new TestEntry(entry);

                testEntry->setLanguageFrom(from);
                testEntry->setLanguageTo(to);

                randomizedInsert(testEntries, testEntry);
            }
```

#### AUTO 


```{c}
auto iter = m_DeclensionLineEdits.begin();
```

#### RANGE FOR STATEMENT 


```{c}
for (KEduVocContainer *child : qAsConst(list)) {
        KEduVocWordType *wt = static_cast<KEduVocWordType *>(child);
        if (name == wt->name())
            return wt;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[word, language, filePath]() {
        QProcess process;
        process.start(QStringLiteral("trans"),
                      {"-l",
                       "en", // output language of CLI
                       "-t",
                       language,
                       word,
                       "-no-translate",
                       "-download-audio-as",
                       filePath});
        process.waitForFinished();
        return process.error() != QProcess::ProcessError::FailedToStart && process.exitCode() == 0;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const TestEntry *entry : qAsConst(m_allTestEntries)) {
        int languageTo = entry->languageTo();
        KEduVocExpression *exp = entry->entry();

        int grade = exp->translation(languageTo)->grade();
        int pregrade = exp->translation(languageTo)->preGrade();
        if (exp->translation(languageTo)->text().isEmpty()) {
            wc.invalid++;
        } else if (pregrade > 0) {
            wc.pregrades[pregrade]++;
            wc.initialWords++;
            wc.grades[0]++;
        } else {
            wc.grades[grade]++;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KEduVocWordFlags &key : qAsConst(m_pronounFlags)) {
        KEduVocTranslation *translation = m_current->entry()->translation(m_current->languageTo());
        if (translation) {
            KEduVocConjugation conjugationToUpdate = translation->getConjugation(m_currentTense);
            conjugationToUpdate.conjugation(key).incPracticeCount();
            conjugationToUpdate.conjugation(key).setPracticeDate(QDateTime::currentDateTime());

            updateGrade(conjugationToUpdate.conjugation(key),
                        m_frontend->resultState() == AbstractFrontend::AnswerCorrect,
                        m_current->statisticBadCount() == 0);

            translation->setConjugation(m_currentTense, conjugationToUpdate);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &tenseName : tenses) {
        tenseItem = new QTreeWidgetItem(m_treeWidget);
        tenseItem->setText(0, tenseName);
        if (activeTenses.contains(tenseName)) {
            tenseItem->setCheckState(0, Qt::Checked);
            m_checkStates[tenseItem] = Qt::Checked;
        } else {
            tenseItem->setCheckState(0, Qt::Unchecked);
            m_checkStates[tenseItem] = Qt::Unchecked;
        }
        tenseItem->setFlags(Qt::ItemIsEnabled | Qt::ItemIsSelectable | Qt::ItemIsUserCheckable);
        m_treeWidget->addTopLevelItem(tenseItem);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KEduVocExpression *entry : qAsConst(m_entries[setNo])) {
        if (entry->lesson()->inPractice()) {
            m_entriesLesson[setNo].insert(entry);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KEduVocExpression *entry : qAsConst(m_entries[setNo])) {
            if (entry->translation(m_toTranslation)->wordType()) {
                if (entry->translation(m_toTranslation)->wordType()->inPractice()) {
                    m_entriesWordType[setNo].insert(entry);
                }
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=] {practiceModeSelected(Prefs::EnumPracticeMode::GenderPractice);}
```

#### RANGE FOR STATEMENT 


```{c}
for (KEduVocExpression *entry : qAsConst(m_entries[setNo])) {
        int grade = entry->translation(m_toTranslation)->grade();
        if (grade >= Prefs::practiceMinimumGrade() && grade <= Prefs::practiceMaximumGrade()) {
            m_entriesMinMaxGrade[setNo].insert(entry);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=] {practiceModeSelected(Prefs::EnumPracticeMode::ExampleSentencesPractice);}
```

#### AUTO 


```{c}
auto iter = mimeEntry.wordTypes.cbegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (QChar ch : qAsConst(chars)) {
        m_mixedSolution.append(ch);
        m_positions.append(QRandomGenerator::global()->bounded(8));
    }
```

#### AUTO 


```{c}
auto iter = m_DeclensionLineEdits.cbegin();
```

#### LAMBDA EXPRESSION 


```{c}
[=] {
        practiceModeSelected(Prefs::EnumPracticeMode::FlashCardsPractice);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QString pp : qAsConst(data.personalPronouns)) {
        if (data.personalPronouns.size() == 1) {
            pp += " (" + data.tense + ')';
        }
        m_personWidgets.at(i)->person->setText(pp);
        m_personWidgets.at(i)->person->setFont(m_solutionFont);
        m_personWidgets.at(i)->input->clear();
        m_personWidgets.at(i)->input->setPalette(QApplication::palette());
        m_personWidgets.at(i)->input->setFont(m_solutionFont);
        m_personWidgets.at(i)->solution->clear();
        m_personWidgets.at(i)->solution->setFont(m_solutionFont);
        connect(m_personWidgets.at(i)->input, &QLineEdit::returnPressed, this, &ConjugationModeWidget::nextConjugationForm);
        ++i;
    }
```

#### AUTO 


```{c}
auto result = m_translator.translateAsync(word, fromLanguage, targetLanguage);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &filename : files) {
            if (filename.endsWith(QLatin1String(".desktop"))) {
                filenames << dir + '/' + filename;
            }
        }
```

#### AUTO 


```{c}
auto container = doc.wordTypeContainer()->childOfType(KEduVocWordFlag::Noun | KEduVocWordFlag::Masculine);
```

#### RANGE FOR STATEMENT 


```{c}
for (QPushButton *pushButton : qAsConst(m_choiceButtons)) {
            pushButton->setStyleSheet(defaultStyleSheet);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=] {
        practiceModeSelected(Prefs::EnumPracticeMode::WrittenPractice);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (int k : translationIndices) {
        if (m_expression->translation(k))
            translations.push_back(m_expression->translation(k));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVariant &ventry : qAsConst(entries)) {
        QObject *obj = qvariant_cast<QObject *>(ventry);
        Expression *entry = dynamic_cast<Expression *>(obj);
        if (entry)
            m_lesson->appendEntry(entry->kEduVocExpression());
        //                 qDebug() << entry->translationTexts();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : qAsConst(indexes)) {
        //             qDebug() << index.row() << index.data(Qt::DisplayRole);
        KEduVocExpression *expr = qvariant_cast<KEduVocExpression *>(index.data(VocabularyModel::EntryRole));
        kentries << expr;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=] {
        practiceModeSelected(Prefs::EnumPracticeMode::ExampleSentencesPractice);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KEduVocTranslation *tr : qAsConst(ktranslations)) {
        //             Translation transltion(tr);
        //             qDebug() << entry.translationTexts();
        QObject *obj = new Translation(tr);
        translations << QVariant::fromValue(obj);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KEduVocContainer *child : childContainers) {
            list += flattenContainer(child);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (KEduVocExpression *entry : qAsConst(m_entries[setNo])) {
        if (entry->translation(m_toTranslation)->badCount() >= Prefs::practiceMinimumWrongCount()
            && entry->translation(m_toTranslation)->badCount() <= Prefs::practiceMaximumWrongCount()) {
            m_entriesTimesWrong[setNo].insert(entry);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KEduVocExpression *entry : qAsConst(m_entries[setNo])) {
            if (!isConjugationBlocked(entry->translation(m_toTranslation))) {
                m_entriesNotBlocked[setNo].insert(entry);
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=] {m_vocabularyView->checkSpelling(i);}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &typeName : wordType) {
                    qDebug() << mimeEntry.wordTypes.value(translation).wordType;
                    KEduVocContainer *childType = type->childContainer(typeName);
                    if (!childType) {
                        // the doc does not contain the right word type - create it
                        childType = new KEduVocWordType(typeName);
                        type->appendChildContainer(childType);
                    }
                    type = static_cast<KEduVocWordType *>(childType);
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (KEduVocExpression *entry : qAsConst(entries)) {
                static_cast<KEduVocLesson *>(parent.internalPointer())->appendEntry(new KEduVocExpression(*entry));
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (KEduVocExpression *entry : qAsConst(m_entries[setNo])) {
        if (entry->translation(m_toTranslation)->practiceCount() >= Prefs::practiceMinimumTimesAsked()
            && entry->translation(m_toTranslation)->practiceCount() <= Prefs::practiceMaximumTimesAsked()) {
            m_entriesTimesPracticed[setNo].insert(entry);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KEduVocExpression *entry : qAsConst(m_entries[setNo])) {
            int grade = entry->translation(m_toTranslation)->grade();

            const QDateTime &date = entry->translation(m_toTranslation)->practiceDate();

            const QDateTime &expireDate = QDateTime::currentDateTime().addSecs(-Prefs::expireItem(grade));

            if (date < expireDate && grade > 0) {
                // decrease the grade
                entry->translation(m_toTranslation)->decGrade();

                // prevent from endless dropping
                // use blockItem() time to prevent blocking after expiring
                entry->translation(m_toTranslation)->setPracticeDate(QDateTime::currentDateTime().addSecs(-Prefs::blockItem(grade - 1)));
                counter++;
            }
        }
```

#### AUTO 


```{c}
const auto &entry
```

#### LAMBDA EXPRESSION 


```{c}
[word, sourceLanguage, targetLanguage]() {
        return TranslateShellAdapter::translate(word, sourceLanguage, targetLanguage);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=] {
        practiceModeSelected(Prefs::EnumPracticeMode::ConjugationPractice);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (TestEntry *entry : qAsConst(m_allTestEntries)) {
        if (entry->statisticCount() == 0) {
            count++;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KEduVocContainer *container : containerList) {
            // no way to move a word type to a lesson for now
            if (container->containerType() != m_type) {
                return false;
            }

            if (action == Qt::MoveAction || action == Qt::CopyAction) {
                qDebug() << "Move container: " << container->name();
                KEduVocContainer *parentContainer = 0;

                if (parent.isValid()) {
                    parentContainer = static_cast<KEduVocContainer *>(parent.internalPointer());
                }
                if (!parentContainer) {
                    // drop into root
                    parentContainer = rootContainer();
                } else {
                    // make sure a container cannot be dropped into one of its child containers!
                    KEduVocContainer *childTest = parentContainer;
                    while (childTest != 0) {
                        if (childTest == container) {
                            qDebug() << "Cannot drop a container into one of its child containers!";
                            return false;
                        }
                        childTest = childTest->parent();
                    }
                }

                QModelIndex oldParent = index(container->parent());

                beginRemoveRows(oldParent, container->row(), container->row());
                container->parent()->removeChildContainer(container->row());
                endRemoveRows();

                // if we get to choose, append seems sane.
                if (row < 0) {
                    row = parentContainer->childContainerCount();
                }

                // use index because we sometimes reparent to the root container instead of dropping into nowhere
                beginInsertRows(index(parentContainer), row, row);
                parentContainer->insertChildContainer(row, container);
                endInsertRows();

                return true;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (KEduVocTranslation *synonym : qAsConst(synonyms)) {
                displayElements.append(synonym->text());
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (QPushButton *pushButton : qAsConst(m_choiceButtons)) {
        pushButton->setText(data.choices[j]);
        pushButton->setToolTip(data.choices[j]);
        pushButton->setFont(m_solutionFont);
        j++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QChar ch : qAsConst(m_mixedSolution)) {
        int pos = enteredChars.indexOf(ch);
        if (pos != -1) {
            p.setPen(scheme.foreground(KColorScheme::InactiveText).color());
            enteredChars.remove(pos, 1);
        } else {
            p.setPen(defaultPen);
        }
        p.drawText(charWidth + charWidth * i * 2, charHeight + int(m_positions.at(i) * charHeight * 0.25), ch);
        i++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (TestEntry *entry : allTestEntries) {
        QTableWidgetItem *itemFrom = new QTableWidgetItem(entry->entry()->translation(entry->TestEntry::languageFrom())->text());
        QTableWidgetItem *itemTo = new QTableWidgetItem(entry->entry()->translation(entry->languageTo())->text());
        if (entry->statisticGoodCount() > 0) {
            itemTo->setForeground(correctPalette.windowText());
        }

        QTableWidgetItem *itemUserAnswer = new QTableWidgetItem(entry->userAnswers().join(QStringLiteral("; ")));
        itemUserAnswer->setForeground(wrongPalette.windowText());

        SortedAttemptTableWidgetItem *itemAttempts = new SortedAttemptTableWidgetItem();
        itemAttempts->setData(Qt::DisplayRole, entry->statisticCount());
        itemAttempts->setData(Qt::UserRole, entry->statisticBadCount());
        itemAttempts->setTextAlignment(Qt::AlignRight);

        itemFrom->setFlags(flags);
        itemTo->setFlags(flags);
        itemUserAnswer->setFlags(flags);
        itemAttempts->setFlags(flags);

        if (entry->correctAtFirstAttempt()) {
            itemUserAnswer->setIcon(QIcon::fromTheme(QStringLiteral("dialog-ok-apply")));
        } else if (entry->statisticGoodCount() > 0) {
            itemUserAnswer->setIcon(QIcon::fromTheme(QStringLiteral("task-attempt")));
        } else if (entry->statisticCount() > 0) {
            itemUserAnswer->setIcon(QIcon::fromTheme(QStringLiteral("dialog-error")));
        } else {
            itemUserAnswer->setIcon(QIcon::fromTheme(QStringLiteral("task-attempt")));
        }

        tableWidget->setItem(i, 0, itemAttempts);
        tableWidget->setItem(i, 1, itemFrom);
        tableWidget->setItem(i, 2, itemTo);
        tableWidget->setItem(i, 3, itemUserAnswer);
        ++i;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &dir : qAsConst(basedirs)) {
            ret << (dir + "/plugins");
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (KEduVocTranslation *antonym : qAsConst(antonyms)) {
                displayElements.append(antonym->text());
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : installedFiles) {
            QMimeType mimeType = db.mimeTypeForFile(file);
            qDebug() << "KNS2 file of mime type:" << db.mimeTypeForFile(file).name();
            if (mimeType.inherits(QStringLiteral("application/x-kvtml"))) {
                ParleyMainWindow::instance()->addRecentFile(QUrl::fromLocalFile(file), QString()); ///@todo: title!
                fileName = file;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (KEduVocExpression *entry : qAsConst(m_entries[setNo])) {
            KEduVocTranslation *translation = entry->translation(m_toTranslation);
            KEduVocText comparative = translation->comparativeForm();
            KEduVocText superlative = translation->superlativeForm();
            if (!isBlocked(&(comparative)) || !isBlocked(&(superlative))) {
                m_entriesNotBlocked[setNo].insert(entry);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (KToolBar *toolbar : toolbars) {
        if (toolbar && toolbar->objectName() == name) {
            toolbar->show();
        } else if (toolbar) {
            toolbar->hide();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KEduVocExpression *expr : qAsConst(kentries)) {
        //             Expression entry(expr);
        //             qDebug() << entry.translationTexts();
        QObject *obj = new Expression(expr);
        entries << QVariant::fromValue(obj);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (int j : translationIndices) {
            if (m_entry->translation(j)->imageUrl().isEmpty()) {
                m_entry->translation(j)->setImageUrl(imageUrlRequester->url());
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (TestEntry *entry : allTestEntries) {
        table->appendRows(1);
        int newRow = table->rows() - 1;
        table->cellAt(newRow, 0).firstCursorPosition().insertText(QString::number(entry->statisticCount()));
        table->cellAt(newRow, 1).firstCursorPosition().insertText(entry->entry()->translation(entry->languageFrom())->text());
        table->cellAt(newRow, 2).firstCursorPosition().insertText(entry->entry()->translation(entry->languageTo())->text());
        table->cellAt(newRow, 3).firstCursorPosition().insertText(entry->userAnswers().join(QStringLiteral("; ")));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KEduVocExpression *entry : qAsConst(m_entries[setNo])) {
            if (!isBlocked(entry->translation(m_toTranslation))) {
                m_entriesNotBlocked[setNo].insert(entry);
                // debugEntry("Not blocked:", entry,
                //           entry->translation(m_fromTranslation),
                //           entry->translation(m_toTranslation));
            } else {
                // debugEntry("Blocked:", entry,
                //           entry->translation(m_fromTranslation),
                //           entry->translation(m_toTranslation));
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (int entry : qAsConst(m_entries)) {
            // grade
            KEduVocExpression *currentEntry = m_doc->entry(entry);
            if (firstEntry->translation(m_translationTo).gradeFrom(m_translationFrom).grade()
                != currentEntry->translation(m_translationTo).gradeFrom(m_translationFrom).grade()) {
                gradebox->setCurrentIndex(-1);
            }
            // date
            if (firstEntry->translation(m_translationTo).gradeFrom(m_translationFrom).practiceDate()
                != currentEntry->translation(m_translationTo).gradeFrom(m_translationFrom).practiceDate()) {
                queryDateEdit->setDate(queryDateEdit->minimumDate());
                queryDateEdit->setTime(queryDateEdit->minimumTime());
            }

            // total count
            if (firstEntry->translation(m_translationTo).gradeFrom(m_translationFrom).practiceCount()
                != currentEntry->translation(m_translationTo).gradeFrom(m_translationFrom).practiceCount()) {
                totalCountEdit->clear();
            }

            // wrong count
            if (firstEntry->translation(m_translationTo).gradeFrom(m_translationFrom).badCount()
                != currentEntry->translation(m_translationTo).gradeFrom(m_translationFrom).badCount()) {
                badCountEdit->clear();
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (KPluginInfo &info : pluginsInfoList) {
        info.load(cfg);
        if (info.isPluginEnabled())
            enabledScripts.push_back(info.entryPath());
        //         qDebug() << inf.name() << inf.isPluginEnabled() << inf.pluginName();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KEduVocWordFlags &person : qAsConst(m_pronounFlags)) {
        // FIXME: Used to be m_practiceOptions.languageTo()
        pp.append(m_doc->identifier(Prefs::learningLanguage()).personalPronouns().personalPronoun(person));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QPushButton *pushButton : qAsConst(m_choiceButtons)) {
        pushButton->setEnabled(false);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KEduVocExpression *expression : qAsConst(expressions)) {
        MimeExpression exp;
        // deep copy
        exp.expression = KEduVocExpression(*expression);

        // copy word types
        // this sucks but there is not really a better was. copying pointers is not a good idea because copy and paste can be done between different documents.
        const QList<int> translationIndices = expression->translationIndices();
        for (int i : translationIndices) {
            // generate text string representation
            m_text.append(expression->translation(i)->text());
            m_text.append(" - ");

            // fill in word types independent of pointers
            KEduVocWordType *type = expression->translation(i)->wordType();

            if (type) { // check if it has a type != 0
                exp.wordTypes[i].grammarType = expression->translation(i)->wordType()->wordType();

                // this may seem weird, but the root element is "word types" so no need to copy that one.
                while (type->parent()) {
                    exp.wordTypes[i].wordType.prepend(type->name());
                    type = static_cast<KEduVocWordType *>(type->parent());
                }
            }
        }
        m_expressions.append(exp);
        m_text.append('\n');
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &tense : conjugationTenses) {
                // Only include tenses which are both non-empty and which should be practiced
                if (!m_tenses.contains(tense)) {
                    continue;
                }
                KEduVocConjugation conjugation = entry->translation(m_toTranslation)->getConjugation(tense);
                if (conjugation.isEmpty()) {
                    continue;
                }

                bool blocked = true;
                const QList<KEduVocWordFlags> pronouns = conjugation.keys();
                for (const KEduVocWordFlags &pronoun : pronouns) {
                    KEduVocText *grade = &conjugation.conjugation(pronoun);
                    if (ignoreBlocked || !isBlocked(grade)) {
                        blocked = false;

                        if (mode == M_SEPARATE) {
                            TestEntry *testEntry = new TestEntry(entry);
                            testEntry->setConjugationTense(tense);
                            testEntry->setLanguageTo(m_toTranslation);
                            testEntry->setLanguageFrom(m_fromTranslation);
                            QList<KEduVocWordFlags> list;
                            list << pronoun;
                            testEntry->setConjugationPronouns(list);
                            randomizedInsert(testEntries, testEntry);
                        }
                    }
                }

                if (!blocked && mode == M_COMPLETE) {
                    TestEntry *testEntry = new TestEntry(entry);
                    testEntry->setConjugationTense(tense);
                    testEntry->setConjugationPronouns(pronouns);
                    testEntry->setLanguageTo(m_toTranslation);
                    testEntry->setLanguageFrom(m_fromTranslation);
                    randomizedInsert(testEntries, testEntry);
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (KEduVocTranslation *synonym : synonyms) {
        if (synonym->text() == answer || (Prefs::ignoreCapitalizationMistakes() && isCapitalizationMistake(synonym->text(), answer))
            || (Prefs::ignoreAccentMistakes() && isAccentMistake(synonym->text(), answer))
            || (Prefs::ignorePunctuationMistakes() && isPunctuationMistake(synonym->text(), answer))) {
            qDebug() << "Synonym entered: " << synonym->text() << " answer: " << answer;
            m_correctedAnswer = synonym->text();
            m_error |= TestEntry::Synonym;
            // only return true if accept these kinds of mistakes
            // otherwise just set the error flag
            if (Prefs::countSynonymsAsCorrect()) {
                return true;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KEduVocWordFlags pronoun : conjugationPronouns) {
            result = minMaxFunc(result, gradeFunc(conj.conjugation(pronoun)));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (KEduVocWordFlags key : qAsConst(m_pronounFlags)) {
        min_preGrade = qMin(m_conjugation.conjugation(key).preGrade(), min_preGrade);
    }
```

#### AUTO 


```{c}
const auto &translation
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &translation : translationList) {
                if (!entries.contains(translation->entry())) {
                    entries << translation->entry();
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (QPushButton *pushButton : qAsConst(m_choiceButtons)) {
            pushButton->setChecked(false);
            pushButton->setEnabled(true);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=] {
        practiceModeSelected(Prefs::EnumPracticeMode::MultipleChoicePractice);
    }
```

#### AUTO 


```{c}
auto translationResult = mTranslationShellAdapter.translate("parley", "en", "de");
```

#### AUTO 


```{c}
const auto entries = KNS3::QtQuickDialogWrapper(QStringLiteral("parley.knsrc")).exec();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QLocale &myLocale : qAsConst(allLocales)) {
        if (!myLocale.nativeLanguageName().isEmpty() && !myLocale.nativeCountryName().isEmpty()) {
            languageCodeMap[myLocale.nativeLanguageName() + " (" + myLocale.nativeCountryName() + ')'] = myLocale.name();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : indexes) {
        lesson->appendEntry(qvariant_cast<KEduVocExpression *>(index.data(VocabularyModel::EntryRole)));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (TestEntry *entry : qAsConst(m_allTestEntries)) {
        qDebug() << " asked: " << entry->statisticCount() << " +" << entry->statisticGoodCount() << " -" << entry->statisticBadCount()
                 << "Entry: " << entry->entry()->translation(0)->text();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KEduVocWordFlags &pronoun : pronouns) {
                KEduVocText grade = translation->getConjugation(tense).conjugation(pronoun);
                if (!isBlocked(&(grade))) {
                    // just need to find any form that is not blocked for generating test entries
                    // exact filtering is done later in conjugationTestEntries
                    return false;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &tense : conjugationTenses) {
                if (!translation->getConjugation(tense).isEmpty()) {
                    existing_tenses << tense;
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[=] {
        practiceModeSelected(Prefs::EnumPracticeMode::MixedLettersPractice);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &dir : qAsConst(dirs)) {
        const QStringList files = QDir(dir).entryList(QDir::Files);
        for (const QString &filename : files) {
            if (filename.endsWith(QLatin1String(".desktop"))) {
                filenames << dir + '/' + filename;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KEduVocExpression *entry : entries) {
        KEduVocTranslation &translation(*entry->translation(translationIndex));
        if (isValidForProcessing(translation, wordTypeToProcess)) {
            switch (wordTypeToProcess) {
            case KEduVocWordFlag::Noun: {
                KEduVocText article = translation.article();
                evaluateWord(article, translation.text());
            } break;
            case KEduVocWordFlag::Verb: {
                QStringList conjugationTenses = translation.conjugationTenses();
                for (const QString &activeTense : qAsConst(activeConjugationTenses)) {
                    if (conjugationTenses.contains(activeTense)) {
                        KEduVocConjugation conj = translation.getConjugation(activeTense);
                        const QList<KEduVocWordFlags> keys = conj.keys();
                        for (KEduVocWordFlags key : keys) {
                            KEduVocText person = conj.conjugation(key);
                            evaluateWord(person, person.text());
                        }
                    }
                }
            } break;
            case KEduVocWordFlag::Adjective | KEduVocWordFlag::Adverb: {
                KEduVocText comparative = translation.comparativeForm();
                evaluateWord(comparative, comparative.text());
                KEduVocText superlative = translation.superlativeForm();
                evaluateWord(superlative, superlative.text());
            } break;
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=] {practiceModeSelected(Prefs::EnumPracticeMode::ConjugationPractice);}
```

#### RANGE FOR STATEMENT 


```{c}
for (const KEduVocWordFlags &pronoun : pronouns) {
                    KEduVocText *grade = &conjugation.conjugation(pronoun);
                    if (ignoreBlocked || !isBlocked(grade)) {
                        blocked = false;

                        if (mode == M_SEPARATE) {
                            TestEntry *testEntry = new TestEntry(entry);
                            testEntry->setConjugationTense(tense);
                            testEntry->setLanguageTo(m_toTranslation);
                            testEntry->setLanguageFrom(m_fromTranslation);
                            QList<KEduVocWordFlags> list;
                            list << pronoun;
                            testEntry->setConjugationPronouns(list);
                            randomizedInsert(testEntries, testEntry);
                        }
                    }
                }
```

#### LAMBDA EXPRESSION 


```{c}
[=] {slotPracticeButtonClicked(urlString);}
```

#### LAMBDA EXPRESSION 


```{c}
[=] {
            m_vocabularyView->checkSpelling(i);
        }
```

#### AUTO 


```{c}
auto container = doc.wordTypeContainer()->childOfType(KEduVocWordFlag::Noun
                                                                  | KEduVocWordFlag::Masculine);
```

#### AUTO 


```{c}
auto iter = languageCodeMap.cbegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (KEduVocExpression *entry : qAsConst(m_currentSelection[i])) {
            const QStringList conjugationTenses = entry->translation(m_toTranslation)->conjugationTenses();
            for (const QString &tense : conjugationTenses) {
                // Only include tenses which are both non-empty and which should be practiced
                if (!m_tenses.contains(tense)) {
                    continue;
                }
                KEduVocConjugation conjugation = entry->translation(m_toTranslation)->getConjugation(tense);
                if (conjugation.isEmpty()) {
                    continue;
                }

                bool blocked = true;
                const QList<KEduVocWordFlags> pronouns = conjugation.keys();
                for (const KEduVocWordFlags &pronoun : pronouns) {
                    KEduVocText *grade = &conjugation.conjugation(pronoun);
                    if (ignoreBlocked || !isBlocked(grade)) {
                        blocked = false;

                        if (mode == M_SEPARATE) {
                            TestEntry *testEntry = new TestEntry(entry);
                            testEntry->setConjugationTense(tense);
                            testEntry->setLanguageTo(m_toTranslation);
                            testEntry->setLanguageFrom(m_fromTranslation);
                            QList<KEduVocWordFlags> list;
                            list << pronoun;
                            testEntry->setConjugationPronouns(list);
                            randomizedInsert(testEntries, testEntry);
                        }
                    }
                }

                if (!blocked && mode == M_COMPLETE) {
                    TestEntry *testEntry = new TestEntry(entry);
                    testEntry->setConjugationTense(tense);
                    testEntry->setConjugationPronouns(pronouns);
                    testEntry->setLanguageTo(m_toTranslation);
                    testEntry->setLanguageFrom(m_fromTranslation);
                    randomizedInsert(testEntries, testEntry);
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (KEduVocContainer *child : qAsConst(list)) {
        strList << child->name();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &script : qAsConst(scripts)) {
        // create a new Script and add it to the m_scripts list
        Script *s = new Script(getScriptFileName(script));
        s->addObjects(m_scriptObjects);
        s->activate();
        m_scripts.push_back(s);
        if (!s->isActivated()) {
            failed << getScriptFileName(script); // TODO: real name?
            errorDetails << s->errorMessage();
            disablePlugin(script);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=] {
        practiceModeSelected(Prefs::EnumPracticeMode::ComparisonPractice);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &line : qAsConst(lines)) {
            // split at tabs or semicolon:
#if QT_VERSION < QT_VERSION_CHECK(5, 15, 0)
            m_model->appendEntry(new KEduVocExpression(line.split(QRegExp(QStringLiteral("[\t;]")), QString::KeepEmptyParts)));
#else
            m_model->appendEntry(new KEduVocExpression(line.split(QRegExp(QStringLiteral("[\t;]")), Qt::KeepEmptyParts)));
#endif
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=] {practiceModeSelected(Prefs::EnumPracticeMode::MixedLettersPractice);}
```

#### RANGE FOR STATEMENT 


```{c}
for (const VocabularyMimeData::MimeExpression &mimeEntry : qAsConst(expressionList)) {
            KEduVocExpression *pasteExpression = new KEduVocExpression(mimeEntry.expression);
            m_model->appendEntry(pasteExpression);

            // find word type (create if not found)
            KEduVocWordType *type = m_doc->wordTypeContainer();
            for (auto iter = mimeEntry.wordTypes.cbegin(); iter != mimeEntry.wordTypes.cend(); ++iter) {
                const int translation = iter.key();
                // append if needed
                const QStringList wordType = mimeEntry.wordTypes.value(translation).wordType;
                for (const QString &typeName : wordType) {
                    qDebug() << mimeEntry.wordTypes.value(translation).wordType;
                    KEduVocContainer *childType = type->childContainer(typeName);
                    if (!childType) {
                        // the doc does not contain the right word type - create it
                        childType = new KEduVocWordType(typeName);
                        type->appendChildContainer(childType);
                    }
                    type = static_cast<KEduVocWordType *>(childType);
                }
                pasteExpression->translation(translation)->setWordType(type);
                // check for special type stuff
                if (type->wordType() != mimeEntry.wordTypes.value(translation).grammarType) {
                    if (type->wordType() == KEduVocWordFlag::NoInformation) {
                        type->setWordType(mimeEntry.wordTypes.value(translation).grammarType);
                    }
                }
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=] {slotRemoveButtonClicked(urlString);}
```

#### LAMBDA EXPRESSION 


```{c}
[=] {practiceModeSelected(Prefs::EnumPracticeMode::MultipleChoicePractice);}
```

#### RANGE FOR STATEMENT 


```{c}
for (T *t : qAsConst(objList)) {
        QObject *obj = new S(t);
        list.push_back(QVariant::fromValue(obj));
    }
```

#### CONST EXPRESSION 


```{c}
constexpr int MAX_NUMBER_OF_NEW_WORDS = 5;
```

#### RANGE FOR STATEMENT 


```{c}
for (const KEduVocWordFlags &key : qAsConst(m_pronounFlags)) {
        if (answers.at(i) == m_conjugation.conjugation(key).text()) {
            ++numRight;
        } else {
            qDebug() << "dec grade for " << m_conjugation.conjugation(key).text();
            allCorrect = false;
        }
        ++i;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[lineedit, watcher]() {
                if (!watcher->future().result().m_error && !watcher->future().result().m_suggestions.isEmpty()) {
                    QCompleter *completer = new QCompleter(watcher->future().result().m_suggestions, lineedit);
                    completer->setCaseSensitivity(Qt::CaseInsensitive);
                    completer->setCompletionMode(QCompleter::UnfilteredPopupCompletion);
                    lineedit->setCompleter(completer);
                }
                watcher->deleteLater();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (int k : translationIndices) {
        if (m_expression->translation(k))
            list << m_expression->translation(k)->text();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KEduVocExpression *entry : qAsConst(m_entries[setNo])) {
            KEduVocText article = entry->translation(m_toTranslation)->article();
            if (!isBlocked(&article)) {
                m_entriesNotBlocked[setNo].insert(entry);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &edge : qAsConst(edges)) {
        ScaleBase scaleBase;
        Edge alignEdge;
        if (edge == QLatin1String("top")) {
            alignEdge = Top;
            scaleBase = Horizontal;
        } else if (edge == QLatin1String("bottom")) {
            alignEdge = Bottom;
            scaleBase = Horizontal;
        } else if (edge == QLatin1String("right")) {
            alignEdge = Right;
            scaleBase = Vertical;
        } else {
            alignEdge = Left;
            scaleBase = Vertical;
        }
        for (int inside = 1; inside >= 0; inside--) {
            renderItem(name,
                       QString(inside ? "inside" : "border") + '-' + edge,
                       rect,
                       p,
                       fastScale,
                       scaleBase,
                       Qt::IgnoreAspectRatio,
                       alignEdge,
                       Centered,
                       inside);
            renderItem(name,
                       QString(inside ? "inside" : "border") + '-' + edge + "-ratio",
                       rect,
                       p,
                       fastScale,
                       scaleBase,
                       Qt::KeepAspectRatio,
                       alignEdge,
                       Centered,
                       inside);
            renderItem(name,
                       QString(inside ? "inside" : "border") + '-' + edge + "-noscale",
                       rect,
                       p,
                       fastScale,
                       NoScale,
                       Qt::IgnoreAspectRatio,
                       alignEdge,
                       Centered,
                       inside);
            renderItem(name,
                       QString(inside ? "inside" : "border") + '-' + edge + "-repeat",
                       rect,
                       p,
                       fastScale,
                       scaleBase,
                       Qt::IgnoreAspectRatio,
                       alignEdge,
                       Repeated,
                       inside);
            renderItem(name,
                       QString(inside ? "inside" : "border") + '-' + edge + '-' + (scaleBase == Vertical ? "top" : "left"),
                       rect,
                       p,
                       fastScale,
                       NoScale,
                       Qt::IgnoreAspectRatio,
                       alignEdge,
                       LeftTop,
                       inside);
            renderItem(name,
                       QString(inside ? "inside" : "border") + '-' + edge + '-' + (scaleBase == Vertical ? "bottom" : "right"),
                       rect,
                       p,
                       fastScale,
                       NoScale,
                       Qt::IgnoreAspectRatio,
                       alignEdge,
                       RightBottom,
                       inside);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QPushButton *pushButton : qAsConst(m_choiceButtons)) {
        if (pushButton->isChecked())
            return i;
        i++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KEduVocExpression *exp : entries) {
            for (int lang = 0; lang < m_doc->identifierCount(); lang++) {
                if (exp->translation(lang)->conjugationTenses().contains(t)) {
                    KMessageBox::information(this,
                                             i18n("The selected user defined tense could not be deleted\nbecause it is in use."),
                                             i18n("Deleting Tense Description"));
                    return;
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : indexes) {
        lesson->appendEntry(qvariant_cast<KEduVocExpression*> (index.data(VocabularyModel::EntryRole)));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : selectedIndexes) {
        rows.insert(index.row());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (TestEntry *entry : qAsConst(m_allTestEntries)) {
        if (entry->statisticBadCount()) {
            count++;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KEduVocTranslation *translation : qAsConst(m_translations)) {
        if (!expressions.contains(translation->entry())) {
            expressions.append(translation->entry());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &dir : qAsConst(themePaths)) {
        QDirIterator it(dir, QStringList() << QStringLiteral("*.desktop"), QDir::NoFilter, QDirIterator::Subdirectories);
        while (it.hasNext()) {
            it.next();
            themesAvailable.append(it.fileName());
        }
    }
```

#### AUTO 


```{c}
auto container = doc.wordTypeContainer()->childOfType(KEduVocWordFlag::Adjective);
```

#### LAMBDA EXPRESSION 


```{c}
[=] {practiceModeSelected(Prefs::EnumPracticeMode::FlashCardsPractice);}
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &translation : translationList) {
                translation->setWordType(static_cast<KEduVocWordType *>(parent.internalPointer()));
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (KEduVocTranslation *translation : qAsConst(list)) {
            int row = m_listModel->rowCount();
            m_listModel->insertRow(row);
            m_listModel->setData(m_listModel->index(row), translation->text());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (KEduVocContainer *container : list) {
        if (container->name() == name) {
            return container;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &activeTense : qAsConst(activeConjugationTenses)) {
                    if (conjugationTenses.contains(activeTense)) {
                        KEduVocConjugation conj = translation.getConjugation(activeTense);
                        const QList<KEduVocWordFlags> keys = conj.keys();
                        for (KEduVocWordFlags key : keys) {
                            KEduVocText person = conj.conjugation(key);
                            evaluateWord(person, person.text());
                        }
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (KEduVocWordFlags key : qAsConst(m_pronounFlags)) {
        min_grade = qMin(m_conjugation.conjugation(key).grade(), min_grade);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KEduVocWordFlags &key : qAsConst(m_pronounFlags)) {
        answers.append(m_conjugation.conjugation(key).text());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=] {
        practiceModeSelected(Prefs::EnumPracticeMode::GenderPractice);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KGameTheme *theme : qAsConst(themeMap)) {
            if (theme->path().endsWith(defaultPath)) {
                const QList<QListWidgetItem *> itemList = ui.themeList->findItems(theme->themeProperty(QStringLiteral("Name")), Qt::MatchExactly);
                // never can be != 1 but better safe than sorry
                if (itemList.count() == 1) {
                    ui.themeList->setCurrentItem(itemList.first());
                    _k_updatePreview();
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (KEduVocWordFlags key : keys) {
                            KEduVocText person = conj.conjugation(key);
                            evaluateWord(person, person.text());
                        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *child : qAsConst(synonymWidgets)) {
        m_ui->synonymList->removeWidget(child);
        delete child;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &choice : qAsConst(choices)) {
        int position = QRandomGenerator::global()->bounded(m_choices.count() + 1);
        m_choices.insert(position, choice);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QList<KNSCore::Entry> &changedEntries) {
        if (!changedEntries.isEmpty()) {
            findThemes(ui.kcfg_Theme->text());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Script *s : qAsConst(m_scripts)) {
        if (s)
            delete s;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : qAsConst(indexes)) {
        if (VocabularyModel::columnType(index.column()) == VocabularyModel::Translation) {
            KEduVocExpression *expr = qvariant_cast<KEduVocExpression *>(index.data(VocabularyModel::EntryRole));
            ktranslations << expr->translation(VocabularyModel::translation(index.column()));
        }
        //             qDebug() << index.row() << index.data(Qt::DisplayRole);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : qAsConst(sortedIndexes)) {
        // only add if it's a translation. other cells like word type are being ignored for now.
        if (columnType(index.column()) == Translation) {
            translations.append(m_container->entry(index.row(), m_recursive)->translation(translation(index.column())));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QChar ch : qAsConst(m_solution)) {
        chars.append(ch);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=] {practiceModeSelected(Prefs::EnumPracticeMode::WrittenPractice);}
```

