#### AUTO 


```{c}
auto config = new EncoderLameConfig();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &path : libraryPaths) {
        QDir dir(path);
        if (!dir.exists()) {
            // qCDebug(AUDIOCD_KIO_LOG) << "Library path" << path << "does not exist";
            continue;
        }

        dir.setFilter(QDir::Files);
        const QFileInfoList files = dir.entryInfoList();

        for (const QFileInfo &fi : std::as_const(files)) {
            if (fi.fileName().contains(QRegularExpression(QStringLiteral("^libaudiocd_encoder_.*.so$")))) {
                QString fileName = fi.baseName();

                if (foundEncoders.contains(fileName)) {
                    qCWarning(AUDIOCD_KIO_LOG) << "Encoder" << fileName << "found in multiple locations";
                    continue;
                }
                foundEncoders.append(fileName);

                QFunctionPointer function = loadPlugin(fi.absoluteFilePath());
                if (function) {
                    void (*functionPointer)(KIO::SlaveBase *, QList<AudioCDEncoder *> &) =
                        (void (*)(KIO::SlaveBase * slave, QList<AudioCDEncoder *> & encoders)) function;
                    functionPointer(slave, encoders);
                }
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QFileInfo &fi : qAsConst(files)) {
            if (fi.fileName().contains(QRegularExpression(QLatin1String("^libaudiocd_encoder_.*.so$")))) {
                QString fileName = fi.baseName();

                if (foundEncoders.contains(fileName)) {
                    qCWarning(AUDIOCD_KIO_LOG) << "Encoder" << fileName << "found in multiple locations";
                    continue;
                }
                foundEncoders.append(fileName);

                QFunctionPointer function = loadPlugin(fi.absoluteFilePath());
                if (function) {
                    void (*functionPointer) (KIO::SlaveBase *, QList<AudioCDEncoder*>&) =
                        (void (*)(KIO::SlaveBase *slave, QList<AudioCDEncoder *>&encoders)) function;
                    functionPointer(slave, encoders);
                }
            }
        }
```

#### AUTO 


```{c}
const auto libraryPaths{QCoreApplication::libraryPaths()};
```

#### AUTO 


```{c}
auto buffer = new FLAC__int32[frames * 2];
```

#### AUTO 


```{c}
auto config = new EncoderOpusConfig();
```

#### AUTO 


```{c}
auto config = new EncoderVorbisConfig();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &path : QCoreApplication::libraryPaths()) {
        QDir dir(path);
        if (!dir.exists()) {
            //qCDebug(AUDIOCD_KIO_LOG) << "Library path" << path << "does not exist";
            continue;
        }

        dir.setFilter(QDir::Files);
        const QFileInfoList files = dir.entryInfoList();

        for (const QFileInfo &fi : qAsConst(files)) {
            if (fi.fileName().contains(QRegularExpression(QLatin1String("^libaudiocd_encoder_.*.so$")))) {
                QString fileName = fi.baseName();

                if (foundEncoders.contains(fileName)) {
                    qCWarning(AUDIOCD_KIO_LOG) << "Encoder" << fileName << "found in multiple locations";
                    continue;
                }
                foundEncoders.append(fileName);

                QFunctionPointer function = loadPlugin(fi.absoluteFilePath());
                if (function) {
                    void (*functionPointer) (KIO::SlaveBase *, QList<AudioCDEncoder*>&) =
                        (void (*)(KIO::SlaveBase *slave, QList<AudioCDEncoder *>&encoders)) function;
                    functionPointer(slave, encoders);
                }
            }
        }
    }
```

#### AUTO 


```{c}
auto *d = (EncoderFLAC::Private *)client_data;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &deviceName : deviceNames) {
			const QString &device = KCompactDisc::urlToDevice(KCompactDisc::cdromDeviceUrl(deviceName));
			QUrl targetUrl = url;
			QUrlQuery targetQuery;
			targetQuery.addQueryItem(QStringLiteral("device"), device);
			targetUrl.setQuery(targetQuery);

			app_dir(entry, escapePath(device), 2+encoders.count());
			entry.fastInsert(KIO::UDSEntry::UDS_TARGET_URL, targetUrl.url());
			entry.fastInsert(KIO::UDSEntry::UDS_DISPLAY_NAME, deviceName);
			listEntry(entry);
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &deviceName : deviceNames) {
            const QString &device = KCompactDisc::urlToDevice(KCompactDisc::cdromDeviceUrl(deviceName));
            QUrl targetUrl = url;
            QUrlQuery targetQuery;
            targetQuery.addQueryItem(QStringLiteral("device"), device);
            targetUrl.setQuery(targetQuery);

            app_dir(entry, escapePath(device), 2 + encoders.count());
            entry.fastInsert(KIO::UDSEntry::UDS_TARGET_URL, targetUrl.url());
            entry.fastInsert(KIO::UDSEntry::UDS_DISPLAY_NAME, deviceName);
            listEntry(entry);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QFileInfo &fi : std::as_const(files)) {
            if (fi.fileName().contains(QRegularExpression(QStringLiteral("^libaudiocd_encoder_.*.so$")))) {
                QString fileName = fi.baseName();

                if (foundEncoders.contains(fileName)) {
                    qCWarning(AUDIOCD_KIO_LOG) << "Encoder" << fileName << "found in multiple locations";
                    continue;
                }
                foundEncoders.append(fileName);

                QFunctionPointer function = loadPlugin(fi.absoluteFilePath());
                if (function) {
                    void (*functionPointer)(KIO::SlaveBase *, QList<AudioCDEncoder *> &) =
                        (void (*)(KIO::SlaveBase * slave, QList<AudioCDEncoder *> & encoders)) function;
                    functionPointer(slave, encoders);
                }
            }
        }
```

