#### LAMBDA EXPRESSION 


```{c}
[=]() { m_editor->selectStitch(Editor::StitchQuarter); }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() { m_editor->selectStitch(Editor::StitchFull); }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {m_editor->renderBackstitchesAs(Configuration::EnumRenderer_RenderBackstitchesAs::BlackWhiteSymbols);}
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {m_editor->renderBackstitchesAs(Configuration::EnumRenderer_RenderBackstitchesAs::ColorLines);}
```

#### AUTO 


```{c}
auto backgroundImageIterator = m_document->backgroundImages().backgroundImages();
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {m_editor->renderStitchesAs(Configuration::EnumRenderer_RenderStitchesAs::BlackWhiteSymbols);}
```

#### AUTO 


```{c}
auto backgroundImages = m_document->backgroundImages().backgroundImages();
```

#### LAMBDA EXPRESSION 


```{c}
[=]() { m_editor->selectStitch(Editor::StitchSmallFull); }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {m_editor->renderStitchesAs(Configuration::EnumRenderer_RenderStitchesAs::ColorSymbols);}
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {m_editor->renderKnotsAs(Configuration::EnumRenderer_RenderKnotsAs::ColorBlocksSymbols);}
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {m_editor->selectTool(Editor::ToolFillRectangle);}
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {m_editor->selectTool(Editor::ToolDraw);}
```

#### LAMBDA EXPRESSION 


```{c}
[=]() { m_editor->selectStitch(Editor::StitchSmallHalf); }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {m_editor->selectTool(Editor::ToolFillPolygon);}
```

#### RANGE FOR STATEMENT 


```{c}
for (Knot *knot : m_knots) {
            knot->colorIndex = m_replacementIndex;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() { m_editor->selectStitch(Editor::StitchFrenchKnot); }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {m_editor->renderStitchesAs(Configuration::EnumRenderer_RenderStitchesAs::ColorBlocks);}
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {m_editor->renderKnotsAs(Configuration::EnumRenderer_RenderKnotsAs::BlackWhiteSymbols);}
```

#### RANGE FOR STATEMENT 


```{c}
for (auto backgroundImage : backgroundImages.m_backgroundImages) {
        stream << *backgroundImage;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {m_editor->renderStitchesAs(Configuration::EnumRenderer_RenderStitchesAs::ColorBlocksSymbols);}
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {m_editor->selectTool(Editor::ToolBackstitch);}
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {m_editor->selectTool(Editor::ToolFillEllipse);}
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {m_editor->renderKnotsAs(Configuration::EnumRenderer_RenderKnotsAs::ColorBlocks);}
```

#### RANGE FOR STATEMENT 


```{c}
for (Backstitch *backstitch : m_backstitches) {
            backstitch->colorIndex = m_replacementIndex;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {m_editor->selectTool(Editor::ToolColorPicker);}
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {m_editor->selectTool(Editor::ToolSelect);}
```

#### AUTO 


```{c}
auto backgroundImage = backgroundImageIterator.next();
```

#### AUTO 


```{c}
auto backgroundImage = backgroundImages.next();
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {m_editor->renderKnotsAs(Configuration::EnumRenderer_RenderKnotsAs::ColorSymbols);}
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {m_editor->selectTool(Editor::ToolAlphabet);}
```

#### AUTO 


```{c}
auto backgroundImage
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {m_editor->selectTool(Editor::ToolErase);}
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {m_editor->selectTool(Editor::ToolPaint);}
```

#### LAMBDA EXPRESSION 


```{c}
[=]() { m_editor->selectStitch(Editor::StitchHalf); }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {m_editor->selectTool(Editor::ToolEllipse);}
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {m_editor->selectTool(Editor::ToolRectangle);}
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {m_editor->selectTool(Editor::ToolText);}
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {m_editor->renderStitchesAs(Configuration::EnumRenderer_RenderStitchesAs::Stitches);}
```

#### RANGE FOR STATEMENT 


```{c}
for (Stitch *stitch : m_stitches) {
            stitch->colorIndex = m_replacementIndex;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() { m_editor->selectStitch(Editor::Stitch3Quarter); }
```

