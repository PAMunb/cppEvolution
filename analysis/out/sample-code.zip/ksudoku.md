#### RANGE FOR STATEMENT 


```{c}
for (QString s : splitData) {
	--cellCount;
	data << s.toInt();
	if(cellCount <= 0) {
	    break;
	}
    }
```

#### AUTO 


```{c}
auto *dialog = new KConfigDialog(this, QStringLiteral("settings"), Settings::self());
```

#### RANGE FOR STATEMENT 


```{c}
for (const int cell : qAsConst(mUnusedCells)) {
	    flagsList.append (mNeighbourFlags.at (cell));
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &s : splitData) {
	--cellCount;
	data << s.toInt();
	if(cellCount <= 0) {
	    break;
	}
    }
```

#### AUTO 


```{c}
auto* theme
```

#### LAMBDA EXPRESSION 


```{c}
[this](const KgTheme* theme) {
		loadTheme(theme);
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const int group : groupList) {
	    if (mask & usedGroups.at (group)) {
		return false;
	    }
	    usedGroups [group] |= mask;
	}
```

#### LAMBDA EXPRESSION 


```{c}
[this, i] { Q_EMIT enterValue(i + 1); }
```

#### RANGE FOR STATEMENT 


```{c}
for (DLXNode * node : std::as_const(solution)) {
	    int rowNumDLX = node->value;
	    mBoardValues [rowNumDLX/order] = (rowNumDLX % order) + 1;
	}
```

#### AUTO 


```{c}
auto *graph = new SKGraph(order, TypeRoxdoku);
```

#### AUTO 


```{c}
auto* enableMessagesAct = new QAction(i18n("Enable all messages"),this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const int cell : std::as_const(mUnusedCells)) {
	    flagsList.append (mNeighbourFlags.at (cell));
	}
```

#### LAMBDA EXPRESSION 


```{c}
[this, i] { enterValue(i + 1); }
```

#### AUTO 


```{c}
auto* view = new KsView(game, m_gameActions, this);
```

#### LAMBDA EXPRESSION 


```{c}
[this, i] { markValue(i + 1); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const int cell : cage) {
		    contentStr += QString::number(cell) + ' ';
		}
```

#### AUTO 


```{c}
auto game = currentGame();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QFileInfo &configFileInfo : qAsConst(filepaths)) {
		const QDir variantDir = configFileInfo.dir();
		KConfig variantConfig(configFileInfo.filePath(), KConfig::SimpleConfig);
		KConfigGroup group = variantConfig.group ("KSudokuVariant");

		variantName = group.readEntry("Name", i18n("Missing Variant Name")); // Translated.
		variantDescr = group.readEntry("Description", ""); // Translated.
		variantIcon = group.readEntry("Icon", "ksudoku-ksudoku_9x9");
		const QString variantDataFile = group.readEntry("FileName", "");
		if(variantDataFile == QLatin1String("")) continue;

		variantDataPath = variantDir.filePath(variantDataFile);

		variant = new CustomGame(variantName, QUrl::fromLocalFile(variantDataPath), m_gameVariants);
		variant->setDescription(variantDescr);
		variant->setIcon(variantIcon);
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const int unb : std::as_const(unusedNeighbours)) {
            flags = mNeighbourFlags.at (unb);
	    if (flags == 15) {
		// Choose a cell that has been surrounded and isolated.
		index = unb;
		break;
	    }
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const int n : std::as_const(mUnusedCells)) {
	    switch (mNeighbourFlags.at (n)){
	    case 7:
	    case 11:
	    case 13:
	    case 14:
		index = n;		// Enclosed on three sides: start here.
		chosenSize = qrand() % (maxSize - 1) + 2;
#ifdef MATHDOKU_LOG
		qCDebug(KSudokuLog) << "CHOSE CUL-DE-SAC" << mNeighbourFlags.at (n)
		       << "at" << index;
#endif
		break;
	    case 15:
		index = n;		// Isolated cell: size 1 is forced.
		chosenSize = 1;
#ifdef MATHDOKU_LOG
		qCDebug(KSudokuLog) << "CHOSE ISOLATED" << mNeighbourFlags.at (n)
		       << "at" << index;
#endif
		break;
	    default:
		break;
	    }
	    if (index >= 0) {
		break;
	    }
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QFileInfo &configFileInfo : qAsConst(filepaths)) {
		const QDir variantDir = configFileInfo.dir();
		KConfig variantConfig(configFileInfo.filePath(), KConfig::SimpleConfig);
		KConfigGroup group = variantConfig.group ("KSudokuVariant");

		variantName = group.readEntry("Name", i18n("Missing Variant Name")); // Translated.
		variantDescr = group.readEntry("Description", ""); // Translated.
		variantIcon = group.readEntry("Icon", "ksudoku-ksudoku_9x9");
		const QString variantDataFile = group.readEntry("FileName", "");
		if(variantDataFile == "") continue;

		variantDataPath = variantDir.filePath(variantDataFile);

		variant = new CustomGame(variantName, QUrl::fromLocalFile(variantDataPath), m_gameVariants);
		variant->setDescription(variantDescr);
		variant->setIcon(variantIcon);
	}
```

#### AUTO 


```{c}
auto* puzzle = new Puzzle(m_graph, false);
```

#### RANGE FOR STATEMENT 


```{c}
for (const int cell : clique) {
                    mRows[cell*order + val] = 0;	// Drop row.
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (int group : groupList) {
        m_requiredGroupValues [group] &= bitPattern;

	QVector<int> cellList = m_graph->clique (group);
        for (int n = 0; n < m_order; n++) {
	    int cell = cellList.at (n);
            m_validCellValues [cell] &= bitPattern;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const int group : groups) {
#ifdef DLX_LOG
                qCDebug(KSudokuLog) << "EXCLUDE CONSTRAINT" << (boardArea+group*order+val);
#endif
                mColumns[boardArea + group*order + val] = nullptr;
                const QVector<int> clique = graph->clique (group);
                for (const int cell : clique) {
                    mRows[cell*order + val] = nullptr;	// Drop row.
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (GroupGraphicsItem* item : qAsConst(m_groups)) {
		item->setHighlight(pos, m_highlightsOn);
	}
```

#### AUTO 


```{c}
auto * symmetryBox = new QComboBox (this);
```

#### AUTO 


```{c}
auto* puzzle = new Puzzle(m_graph, true);
```

#### AUTO 


```{c}
auto *graph = new SKGraph(order, TypeSudoku);
```

#### RANGE FOR STATEMENT 


```{c}
for (GroupGraphicsItem* item : std::as_const(m_groups)) {
		item->setHighlight(pos, m_highlightsOn);
	}
```

#### AUTO 


```{c}
const auto* collection = dynamic_cast<const GameVariantCollection*>(index.model());
```

#### RANGE FOR STATEMENT 


```{c}
for (DLXNode * colDLX : std::as_const(mColumns)) {
        mEndColNum++;
        // If the constraint is not excluded, put an empty column in the matrix.
        if (colDLX != 0) {
            DLXNode * node = allocNode();
            mColumns[mEndColNum] = node;
            initNode (node);
            addAtRight (node, mCorner);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (ksudoku::GroupGraphicsItem* group : std::as_const(m_groups)) {
		group->resize(grid, m_highlightsOn);
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const int group : cliqueList) {
		    // Poss values go from 0 to (order - 1) in DLX (so -1 here).
		    addNode (rowNumDLX, nCages + group * order + possVal - 1);
		    counter++;
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& gamevariantdir : gamevariantdirs) {
		const auto fileNames = QDir(gamevariantdir).entryInfoList(QStringList() << QStringLiteral("*.desktop"), QDir::Files | QDir::Readable | QDir::NoDotAndDotDot);
		filepaths.append(fileNames);
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const int group : groups) {
                    // Mark possibly-satisfied constraints for row, column, etc.
                    addNode (rowNumDLX, boardArea + group*order + possValue);
                }
```

#### AUTO 


```{c}
auto* gameVariant = static_cast<GameVariant*>(index.internalPointer());
```

#### AUTO 


```{c}
auto *widget = new KSudoku;
```

#### RANGE FOR STATEMENT 


```{c}
for (DLXNode * colDLX : std::as_const(mColumns)) {
        mEndColNum++;
        // If the constraint is not excluded, put an empty column in the matrix.
        if (colDLX != nullptr) {
            DLXNode * node = allocNode();
            mColumns[mEndColNum] = node;
            initNode (node);
            addAtRight (node, mCorner);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto* theme : themes) {
		if (theme->identifier() == themeIdentifier) {
		    provider->setCurrentTheme(theme);
		    loadTheme(theme);
		    break;
		}
	}
```

#### AUTO 


```{c}
auto* graph = new SKGraph(order, TypeCustom);
```

#### RANGE FOR STATEMENT 


```{c}
for (const int cell : clique) {
                    mRows[cell*order + val] = nullptr;	// Drop row.
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this, i] { Q_EMIT markValue(i + 1); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const int cell : cage) {
#ifdef DLX_LOG
		    fprintf (stderr, "%d:%d ", cell,
			    mPossibilities->at (comboValues));
#endif
		    // Record the sequence of cell-numbers, for use in hints.
		    if (mSolutionMoves) {
			mSolutionMoves->append (cell);
		    }
		    mBoardValues [cell] = mPossibilities->at (comboValues);
		    comboValues++;
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& s : cells) {
	cage << s.toInt();
	size--;
	if (size <= 0) {
	    break;
	}
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const int cell : cage) {
	    if (cellPosY(cell) > topY) {
		continue;		// Below the best so far.
	    }
	    else if ((cellPosY(cell) == topY) && (cellPosX(cell) > leftX)) {
		continue;		// Same height as best but to the right.
	    }
	    newCage->cageTopLeft = cell;
	    topY  = cellPosY(cell);
	    leftX = cellPosX(cell);
	}
```

#### LAMBDA EXPRESSION 


```{c}
[this, i] { selectValue(i + 1); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const int n : qAsConst(mUnusedCells)) {
	    switch (mNeighbourFlags.at (n)){
	    case 7:
	    case 11:
	    case 13:
	    case 14:
		index = n;		// Enclosed on three sides: start here.
		chosenSize = qrand() % (maxSize - 1) + 2;
#ifdef MATHDOKU_LOG
		qCDebug(KSudokuLog) << "CHOSE CUL-DE-SAC" << mNeighbourFlags.at (n)
		       << "at" << index;
#endif
		break;
	    case 15:
		index = n;		// Isolated cell: size 1 is forced.
		chosenSize = 1;
#ifdef MATHDOKU_LOG
		qCDebug(KSudokuLog) << "CHOSE ISOLATED" << mNeighbourFlags.at (n)
		       << "at" << index;
#endif
		break;
	    default:
		break;
	    }
	    if (index >= 0) {
		break;
	    }
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const int group : groups) {
#ifdef DLX_LOG
                qCDebug(KSudokuLog) << "EXCLUDE CONSTRAINT" << (boardArea+group*order+val);
#endif
                mColumns[boardArea + group*order + val] = 0;
                const QVector<int> clique = graph->clique (group);
                for (const int cell : clique) {
                    mRows[cell*order + val] = 0;	// Drop row.
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (DLXNode * colDLX : qAsConst(mColumns)) {
        mEndColNum++;
        // If the constraint is not excluded, put an empty column in the matrix.
        if (colDLX != 0) {
            DLXNode * node = allocNode();
            mColumns[mEndColNum] = node;
            initNode (node);
            addAtRight (node, mCorner);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const int cell : cage) {
            contentStr += QString::number(cell) + QLatin1Char(' ');
		}
```

#### LAMBDA EXPRESSION 


```{c}
[this, i] { Q_EMIT selectValue(i + 1); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QFileInfo &configFileInfo : std::as_const(filepaths)) {
		const QDir variantDir = configFileInfo.dir();
		KConfig variantConfig(configFileInfo.filePath(), KConfig::SimpleConfig);
		KConfigGroup group = variantConfig.group ("KSudokuVariant");

		variantName = group.readEntry("Name", i18n("Missing Variant Name")); // Translated.
		variantDescr = group.readEntry("Description", ""); // Translated.
		variantIcon = group.readEntry("Icon", "ksudoku-ksudoku_9x9");
		const QString variantDataFile = group.readEntry("FileName", "");
		if(variantDataFile == QLatin1String("")) continue;

		variantDataPath = variantDir.filePath(variantDataFile);

		variant = new CustomGame(variantName, QUrl::fromLocalFile(variantDataPath), m_gameVariants);
		variant->setDescription(variantDescr);
		variant->setIcon(variantIcon);
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (int g : cliqueList) {
		m_cellCliques [index] = g;
		index++;
	    }
```

#### RANGE FOR STATEMENT 


```{c}
for (DLXNode * node : qAsConst(solution)) {
	    int rowNumDLX = node->value;
	    mBoardValues [rowNumDLX/order] = (rowNumDLX % order) + 1;
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const int cell : cage ) {
		int possVal = possibilities->at (index);
		// qCDebug(KSudokuLog) << "    Cell" << cell << "possVal" << possVal;
		const QList<int> cliqueList = graph->cliqueList (cell);
		for (const int group : cliqueList) {
		    // Poss values go from 0 to (order - 1) in DLX (so -1 here).
		    addNode (rowNumDLX, nCages + group * order + possVal - 1);
		    counter++;
		}
		index++;
	    }
```

#### AUTO 


```{c}
auto* gameConfig = new GameConfig();
```

#### AUTO 


```{c}
auto * dialog = new QPrintDialog(m_printer, m_parent);
```

#### RANGE FOR STATEMENT 


```{c}
for (ksudoku::GroupGraphicsItem* group : qAsConst(m_groups)) {
		group->resize(grid, m_highlightsOn);
	}
```

#### AUTO 


```{c}
const auto fileNames = QDir(gamevariantdir).entryInfoList(QStringList() << QStringLiteral("*.desktop"), QDir::Files | QDir::Readable | QDir::NoDotAndDotDot);
```

#### RANGE FOR STATEMENT 


```{c}
for (const int unb : qAsConst(unusedNeighbours)) {
            flags = mNeighbourFlags.at (unb);
	    if (flags == 15) {
		// Choose a cell that has been surrounded and isolated.
		index = unb;
		break;
	    }
	}
```

#### AUTO 


```{c}
auto* puzzle = new Puzzle(graph, hasSolution);
```

#### AUTO 


```{c}
auto * board = new SudokuBoard (m_graph);
```

