#### AUTO 


```{c}
auto propElement =
        setElement.appendChild(document.createElementNS(QStringLiteral("DAV:"), QStringLiteral("prop")));
```

#### AUTO 


```{c}
auto protocol = mCollection.url().protocol();
```

#### AUTO 


```{c}
auto mkcalElement = document.createElementNS(QStringLiteral("DAV:"), QStringLiteral("mkcalendar"));
```

#### AUTO 


```{c}
auto itemFetchJob = new KDAV2::DavItemFetchJob(item);
```

#### AUTO 


```{c}
auto collectionDeleteJob = new KDAV2::DavCollectionDeleteJob(testCollectionUrl);
```

#### AUTO 


```{c}
auto resourceTypeElement = propElement.appendChild(
        document.createElementNS(QStringLiteral("DAV:"), QStringLiteral("resourcetype")));
```

#### LAMBDA EXPRESSION 


```{c}
[=] (QNetworkReply::NetworkError error) {
        qWarning() << "Error " << error << reply->errorString();
    }
```

#### AUTO 


```{c}
auto job = DavManager::self()->createCreateJob(mItem.data(), itemUrl(), mItem.contentType().toLatin1());
```

#### AUTO 


```{c}
auto request = reply->request();
```

#### LAMBDA EXPRESSION 


```{c}
[=] (QNetworkReply::NetworkError error) {
        qCWarning(KDAV2_LOG) << "Error " << error << reply->errorString();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto rawHeaderItem : req.rawHeaderList()) {
        qCDebug(KDAV2_LOG) << "   " << rawHeaderItem << ": " << req.rawHeader(rawHeaderItem);
    }
```

#### AUTO 


```{c}
auto job = DavManager::self()->createMkColJob(collectionUrl());
```

#### AUTO 


```{c}
auto url = mUrl;
```

#### AUTO 


```{c}
auto reply = mWebDav->get(url.path(), {{"User-Agent", "KDAV2"}});
```

#### AUTO 


```{c}
auto job = DavManager::self()->createGetJob(mItem.url().url());
```

#### AUTO 


```{c}
auto url = assembleUrl(storedJob->url(), storedJob->getLocationHeader());
```

#### AUTO 


```{c}
auto itemListJob = new KDAV2::DavItemsListJob(collectionUrl, cache);
```

#### AUTO 


```{c}
auto job = DavManager::self()->createMkCalendarJob(collectionUrl(), document);
```

#### LAMBDA EXPRESSION 


```{c}
[&] {
                // check for the valid propstat, without giving up on first error
                const QDomNodeList propstats = responseElement.elementsByTagNameNS(QStringLiteral("DAV:"), QStringLiteral("propstat"));
                for (int i = 0; i < propstats.length(); ++i) {
                    const QDomElement propstatCandidate = propstats.item(i).toElement();
                    const QDomElement statusElement = Utils::firstChildElementNS(propstatCandidate, QStringLiteral("DAV:"), QStringLiteral("status"));
                    if (statusElement.text().contains(QLatin1String("200"))) {
                        return propstatCandidate;
                    }
                }
                return QDomElement{};
            }
```

#### AUTO 


```{c}
auto job = protocol->useReport() ?
                DavManager::self()->createReportJob(url, props) :
                DavManager::self()->createPropFindJob(url, props);
```

#### AUTO 


```{c}
auto *storedJob        = qobject_cast<DavJob *>(job);
```

#### AUTO 


```{c}
auto setElement = mkcalElement.appendChild(
        document.createElementNS(QStringLiteral("DAV:"), QStringLiteral("set")));
```

#### AUTO 


```{c}
auto deleteJob = new KDAV::DavItemDeleteJob(item);
```

#### AUTO 


```{c}
auto job = DavManager::self()->createPropPatchJob(mUrl.url(), mQuery);
```

#### AUTO 


```{c}
auto url = mUrl.url();
```

#### LAMBDA EXPRESSION 


```{c}
[=] () {
        //This is a workaround for QNetworkAccessManager::setRedirectPolicy(QNetworkRequest::UserVerifiedRedirectPolicy),
        //which does not seem to work with multiple redirects.
        const auto possibleRedirectUrl = reply->attribute(QNetworkRequest::RedirectionTargetAttribute).toUrl();
        if(!possibleRedirectUrl.isEmpty()) {
            qCDebug(KDAV2_LOG) << "Redirecting to " << possibleRedirectUrl;
            auto request = reply->request();
            request.setUrl(possibleRedirectUrl);
            reply->disconnect(this);

            //Set in QWebdav
            const auto requestData = reply->property("requestData").toByteArray();
            d->data.clear();

            auto redirectReply = [&] {
                if (reply->property("isPut").toBool()) {
                    return DavManager::networkAccessManager()->put(request, requestData);
                }
                return DavManager::networkAccessManager()->sendCustomRequest(request, request.attribute(QNetworkRequest::CustomVerbAttribute).toByteArray(), requestData);
            }();
            redirectReply->setProperty("requestData", requestData);
            connectToReply(redirectReply);
            return;
        }

        //Could have changed due to redirects
        d->url = reply->url();

        d->doc.setContent(d->data, true);

        if (KDAV2_LOG().isDebugEnabled()) {
            QTextStream stream(stdout, QIODevice::WriteOnly);
            d->doc.save(stream, 2);
        }

        d->responseCode = reply->error();
        d->httpStatusCode = reply->attribute(QNetworkRequest::HttpStatusCodeAttribute).toInt();
        if (d->responseCode) {
            setError(KJob::UserDefinedError);
            setErrorText(reply->errorString());
        } else if (d->httpStatusCode >= 400) {
            qWarning() << "No error set even though we clearly have an http error?" << d->responseCode << d->httpStatusCode;
            Q_ASSERT(false);
            setError(KJob::UserDefinedError);
            setErrorText(reply->errorString());
        }
        emitResult();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&] {
        QDomElement responseElement = Utils::firstChildElementNS(multistatusElement, QStringLiteral("DAV:"), QStringLiteral("response"));
        while (!responseElement.isNull()) {

            const QDomElement propstatElement = [&] {
                // check for the valid propstat, without giving up on first error
                const QDomNodeList propstats = responseElement.elementsByTagNameNS(QStringLiteral("DAV:"), QStringLiteral("propstat"));
                for (int i = 0; i < propstats.length(); ++i) {
                    const QDomElement propstatCandidate = propstats.item(i).toElement();
                    const QDomElement statusElement = Utils::firstChildElementNS(propstatCandidate, QStringLiteral("DAV:"), QStringLiteral("status"));
                    if (statusElement.text().contains(QLatin1String("200"))) {
                        return propstatCandidate;
                    }
                }
                return QDomElement{};
            }();

            if (propstatElement.isNull()) {
                responseElement = Utils::nextSiblingElementNS(responseElement, QStringLiteral("DAV:"), QStringLiteral("response"));
                continue;
            }

            // extract home sets
            const QDomElement propElement = Utils::firstChildElementNS(propstatElement, QStringLiteral("DAV:"), QStringLiteral("prop"));

            // Trying to get the principal url, given either by current-user-principal or principal-URL
            QDomElement urlHolder = Utils::firstChildElementNS(propElement, QStringLiteral("DAV:"), QStringLiteral("current-user-principal"));
            if (urlHolder.isNull()) {
                urlHolder = Utils::firstChildElementNS(propElement, QStringLiteral("DAV:"), QStringLiteral("principal-URL"));
            }

            if (!urlHolder.isNull()) {
                // Getting the href that will be used for the next round
                const QDomElement hrefElement = Utils::firstChildElementNS(urlHolder, QStringLiteral("DAV:"), QStringLiteral("href"));
                if (!hrefElement.isNull()) {
                    return hrefElement.text();
                }
            }

            responseElement = Utils::nextSiblingElementNS(responseElement, QStringLiteral("DAV:"), QStringLiteral("response"));
        }
        return QString{};
    }
```

#### AUTO 


```{c}
auto *deleteJob = qobject_cast<DavJob*>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &item : itemListJob->changedItems()) {
                qDebug() << item.url().url() << item.contentType() << item.data();
                auto itemFetchJob = new KDAV2::DavItemFetchJob(item);
                itemFetchJob->exec();
                const auto fetchedItem = itemFetchJob->item();
                qDebug() << fetchedItem.contentType() << fetchedItem.data();

                auto itemsFetchJob = new KDAV2::DavItemsFetchJob(collectionUrl, QStringList() << item.url().toDisplayString());
                itemsFetchJob->exec();
                if (itemsFetchJob->item(item.url().toDisplayString()).contentType() != fetchedItem.contentType()) {       //itemsfetchjob do not get contentType
                    qDebug() << "Fetched same item but got different contentType:" << itemsFetchJob->item(item.url().toDisplayString()).contentType();
                }

                if (itemsFetchJob->item(item.url().toDisplayString()).data() != fetchedItem.data()) {
                    qDebug() << "Fetched same item but got different data:" << itemsFetchJob->item(item.url().toDisplayString()).data();
                }

                cache->setEtag(item.url().toDisplayString(), item.etag());
            }
```

#### AUTO 


```{c}
const auto &rawHeaderItem
```

#### AUTO 


```{c}
const auto &collection
```

#### AUTO 


```{c}
auto reply =  QNetworkAccessManager::put(req, data);
```

#### AUTO 


```{c}
auto reply = sendCustomRequest(req, method.toLatin1(), outgoingData);
```

#### AUTO 


```{c}
auto reply = mWebDav->proppatch(url.path(), document.toByteArray());
```

#### AUTO 


```{c}
auto reply = mWebDav->mkdir(url.path());
```

#### LAMBDA EXPRESSION 


```{c}
[&] {
                if (reply->property("isPut").toBool()) {
                    return DavManager::networkAccessManager()->put(request, requestData);
                }
                return DavManager::networkAccessManager()->sendCustomRequest(request, request.attribute(QNetworkRequest::CustomVerbAttribute).toByteArray(), requestData);
            }
```

#### AUTO 


```{c}
auto collectionDeleteJob = new KDAV2::DavCollectionDeleteJob(collectionUrl);
```

#### AUTO 


```{c}
auto job = DavManager::self()->createPropFindJob(
        mCollection.url().url(), builder->buildQuery(), /* depth = */ QStringLiteral{"0"});
```

#### AUTO 


```{c}
const auto rawHeaderItem
```

#### AUTO 


```{c}
auto deleteJob = static_cast<DavJob *>(job);
```

#### AUTO 


```{c}
auto collectionDeleteJob = new KDAV::DavCollectionDeleteJob(collectionUrl);
```

#### AUTO 


```{c}
auto davJob = qobject_cast<DavJob *>(job);
```

#### AUTO 


```{c}
auto *storedJob = static_cast<DavJob*>(job);
```

#### LAMBDA EXPRESSION 


```{c}
[&] {
            // check for the valid propstat, without giving up on first error
            const QDomNodeList propstats = responseElement.elementsByTagNameNS(QStringLiteral("DAV:"), QStringLiteral("propstat"));
            for (int i = 0; i < propstats.length(); ++i) {
                const QDomElement propstatCandidate = propstats.item(i).toElement();
                const QDomElement statusElement = Utils::firstChildElementNS(propstatCandidate, QStringLiteral("DAV:"), QStringLiteral("status"));
                if (statusElement.text().contains(QLatin1String("200"))) {
                    return propstatCandidate;
                }
            }
            return QDomElement{};
        }
```

#### AUTO 


```{c}
auto itemListJob = new KDAV2::DavItemsListJob(collectionUrl);
```

#### AUTO 


```{c}
auto _url = url;
```

#### AUTO 


```{c}
auto compElement = document.createElementNS(
            QStringLiteral("urn:ietf:params:xml:ns:caldav"), QStringLiteral("comp"));
```

#### AUTO 


```{c}
auto job = DavManager::self()->createMkColJob(collectionUrl(), document);
```

#### AUTO 


```{c}
const auto *davJob = qobject_cast<DavCollectionFetchJob *>(job);
```

#### AUTO 


```{c}
auto job = new KDAV::DavItemsListJob(davUrl, cache);
```

#### AUTO 


```{c}
auto job = new KDAV2::DavItemsListJob(davUrl, cache);
```

#### AUTO 


```{c}
auto redirectReply = [&] {
                if (reply->property("isPut").toBool()) {
                    return DavManager::networkAccessManager()->put(request, requestData);
                }
                return DavManager::networkAccessManager()->sendCustomRequest(request, request.attribute(QNetworkRequest::CustomVerbAttribute).toByteArray(), requestData);
            }();
```

#### AUTO 


```{c}
const auto url = d->mUrl.url();
```

#### AUTO 


```{c}
auto individualFetchJob = new DavCollectionFetchJob(collection, this);
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto collection : job->collections()) {
        qDebug() << collection.displayName() << "PRIVS: " << collection.privileges();
        auto collectionUrl = collection.url();
        int anz = -1;
        {
            auto itemListJob = new KDAV2::DavItemsListJob(collectionUrl);
            itemListJob->exec();
            anz = itemListJob->items().size();
            qDebug() << "items:" << itemListJob->items().size();
            for (const auto &item : itemListJob->items()) {
                qDebug() << item.url().url() << item.contentType() << item.data();
                auto itemFetchJob = new KDAV2::DavItemFetchJob(item);
                itemFetchJob->exec();
                const auto fetchedItem = itemFetchJob->item();
                qDebug() << fetchedItem.contentType() << fetchedItem.data();

                auto itemsFetchJob = new KDAV2::DavItemsFetchJob(collectionUrl, QStringList() << item.url().toDisplayString());
                itemsFetchJob->exec();
                if (itemsFetchJob->item(item.url().toDisplayString()).contentType() != fetchedItem.contentType()) {       //itemsfetchjob do not get contentType
                    qDebug() << "Fetched same item but got different contentType:" << itemsFetchJob->item(item.url().toDisplayString()).contentType();
                }

                if (itemsFetchJob->item(item.url().toDisplayString()).data() != fetchedItem.data()) {
                    qDebug() << "Fetched same item but got different data:" << itemsFetchJob->item(item.url().toDisplayString()).data();
                }
            }
        }
        {
            qDebug() << "second run: (should be empty).";
            auto itemListJob = new KDAV2::DavItemsListJob(collectionUrl);
            itemListJob->exec();
            if (itemListJob->items().size() != anz) {
                qDebug() << "Items have added/deleted on server.";
            }
        }
    }
```

#### AUTO 


```{c}
auto modifyJob = new KDAV2::DavItemModifyJob(item);
```

#### AUTO 


```{c}
auto url = existingUrl;
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &collection : job->collections()) {
        qInfo() << collection.displayName() << "PRIVS: " << collection.privileges();
        auto collectionUrl = collection.url();
        int anz = -1;
        {
            auto itemListJob = new KDAV2::DavItemsListJob(collectionUrl);
            itemListJob->exec();
            anz = itemListJob->items().size();
            qInfo() << "items:" << itemListJob->items().size();
            for (const auto &item : itemListJob->items()) {
                qInfo() << item.url().url() << item.contentType() << item.data();
                auto itemFetchJob = new KDAV2::DavItemFetchJob(item);
                itemFetchJob->exec();
                const auto fetchedItem = itemFetchJob->item();
                qInfo() << fetchedItem.contentType() << fetchedItem.data();

                auto itemsFetchJob = new KDAV2::DavItemsFetchJob(collectionUrl, QStringList() << item.url().toDisplayString());
                itemsFetchJob->exec();
                if (itemsFetchJob->item(item.url().toDisplayString()).contentType() != fetchedItem.contentType()) {       //itemsfetchjob do not get contentType
                    qInfo() << "Fetched same item but got different contentType:" << itemsFetchJob->item(item.url().toDisplayString()).contentType();
                }

                if (itemsFetchJob->item(item.url().toDisplayString()).data() != fetchedItem.data()) {
                    qInfo() << "Fetched same item but got different data:" << itemsFetchJob->item(item.url().toDisplayString()).data();
                }
            }
        }
        {
            qInfo() << "second run: (should be empty).";
            auto itemListJob = new KDAV2::DavItemsListJob(collectionUrl);
            itemListJob->exec();
            if (itemListJob->items().size() != anz) {
                qInfo() << "Items have added/deleted on server.";
            }
        }
    }
```

#### AUTO 


```{c}
auto *job = new DavCollectionsFetchJob(davUrl);
```

#### AUTO 


```{c}
auto it = headers.constBegin();
```

#### AUTO 


```{c}
auto job = new KDAV2::DavItemsListJob(davUrl);
```

#### AUTO 


```{c}
const auto &item
```

#### AUTO 


```{c}
auto collectionModifyJob = new KDAV::DavCollectionModifyJob(testCollectionUrl);
```

#### AUTO 


```{c}
auto davJob = static_cast<DavJob *>(job);
```

#### LAMBDA EXPRESSION 


```{c}
[=] () {
        d->doc.setContent(d->data, true);

        if (KDAV2_LOG().isDebugEnabled()) {
            QTextStream stream(stdout, QIODevice::WriteOnly);
            d->doc.save(stream, 2);
        }

        d->responseCode = reply->error();
        if (reply->error()) {
            setError(KJob::UserDefinedError);
            setErrorText(reply->errorString());
        }
        emitResult();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=] () {
        //This is a workaround for QNetworkAccessManager::setRedirectPolicy(QNetworkRequest::UserVerifiedRedirectPolicy),
        //which does not seem to work with multiple redirects.
        const auto possibleRedirectUrl = reply->attribute(QNetworkRequest::RedirectionTargetAttribute).toUrl();
        if(!possibleRedirectUrl.isEmpty()) {
            qCDebug(KDAV2_LOG) << "Redirecting to " << possibleRedirectUrl;
            auto request = reply->request();
            request.setUrl(possibleRedirectUrl);
            reply->disconnect(this);

            //Set in QWebdav
            const auto requestData = reply->property("requestData").toByteArray();
            d->data.clear();

            auto redirectReply = [&] {
                if (reply->property("isPut").toBool()) {
                    return DavManager::networkAccessManager()->put(request, requestData);
                }
                return DavManager::networkAccessManager()->sendCustomRequest(request, request.attribute(QNetworkRequest::CustomVerbAttribute).toByteArray(), requestData);
            }();
            redirectReply->setProperty("requestData", requestData);
            connectToReply(redirectReply);
            return;
        }

        //Could have changed due to redirects
        d->url = reply->url();

        d->doc.setContent(d->data, true);

        if (KDAV2_LOG().isDebugEnabled()) {
            QTextStream stream(stdout, QIODevice::WriteOnly);
            d->doc.save(stream, 2);
        }

        d->responseCode = reply->error();
        d->httpStatusCode = reply->attribute(QNetworkRequest::HttpStatusCodeAttribute).toInt();
        if (d->responseCode) {
            setError(KJob::UserDefinedError);
            setErrorText(reply->errorString());
        }
        emitResult();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto collection : job->collections()) {
        qInfo() << collection.displayName() << "PRIVS: " << collection.privileges();
        auto collectionUrl = collection.url();
        int anz = -1;
        {
            auto itemListJob = new KDAV2::DavItemsListJob(collectionUrl);
            itemListJob->exec();
            anz = itemListJob->items().size();
            qInfo() << "items:" << itemListJob->items().size();
            for (const auto &item : itemListJob->items()) {
                qInfo() << item.url().url() << item.contentType() << item.data();
                auto itemFetchJob = new KDAV2::DavItemFetchJob(item);
                itemFetchJob->exec();
                const auto fetchedItem = itemFetchJob->item();
                qInfo() << fetchedItem.contentType() << fetchedItem.data();

                auto itemsFetchJob = new KDAV2::DavItemsFetchJob(collectionUrl, QStringList() << item.url().toDisplayString());
                itemsFetchJob->exec();
                if (itemsFetchJob->item(item.url().toDisplayString()).contentType() != fetchedItem.contentType()) {       //itemsfetchjob do not get contentType
                    qInfo() << "Fetched same item but got different contentType:" << itemsFetchJob->item(item.url().toDisplayString()).contentType();
                }

                if (itemsFetchJob->item(item.url().toDisplayString()).data() != fetchedItem.data()) {
                    qInfo() << "Fetched same item but got different data:" << itemsFetchJob->item(item.url().toDisplayString()).data();
                }
            }
        }
        {
            qInfo() << "second run: (should be empty).";
            auto itemListJob = new KDAV2::DavItemsListJob(collectionUrl);
            itemListJob->exec();
            if (itemListJob->items().size() != anz) {
                qInfo() << "Items have added/deleted on server.";
            }
        }
    }
```

#### AUTO 


```{c}
const auto collection
```

#### AUTO 


```{c}
const auto requestData = reply->property("requestData").toByteArray();
```

#### AUTO 


```{c}
auto job = new KDAV::DavItemFetchJob(item);
```

#### AUTO 


```{c}
auto job = new KDAV2::DavItemFetchJob(item);
```

#### AUTO 


```{c}
auto *storedJob = qobject_cast<DavJob*>(job);
```

#### AUTO 


```{c}
auto mkcolElement = document.createElementNS(QStringLiteral("DAV:"), QStringLiteral("mkcol"));
```

#### AUTO 


```{c}
auto colorElement = propElement.appendChild(document.createElementNS(
            QStringLiteral("http://apple.com/ns/ical/"), QStringLiteral("calendar-color")));
```

#### AUTO 


```{c}
auto createJob = new KDAV2::DavItemCreateJob(item);
```

#### AUTO 


```{c}
auto compSetElement = propElement.appendChild(document.createElementNS(
        QStringLiteral("urn:ietf:params:xml:ns:caldav"), QStringLiteral("supported-calendar-component-set")));
```

#### AUTO 


```{c}
auto job = DavManager::self()->createPropFindJob(
        mCollection.url().url(), builder->buildQuery(), /* depth = */ 0);
```

#### AUTO 


```{c}
auto davJob = static_cast<DavJob*>(job);
```

#### AUTO 


```{c}
const auto fetchedItem = itemFetchJob->item();
```

#### AUTO 


```{c}
auto collectionCreateJob = new KDAV2::DavCollectionCreateJob(testCollection);
```

#### AUTO 


```{c}
auto collectionFetchJob = new KDAV2::DavCollectionFetchJob(testCollection);
```

#### AUTO 


```{c}
auto setElement = mkcolElement.appendChild(
        document.createElementNS(QStringLiteral("DAV:"), QStringLiteral("set")));
```

#### AUTO 


```{c}
auto job = DavManager::self()->createModifyJob(mItem.data(), itemUrl(), mItem.contentType().toUtf8(), mItem.etag().toUtf8());
```

#### AUTO 


```{c}
auto collectionModifyJob = new KDAV2::DavCollectionModifyJob(testCollectionUrl);
```

#### AUTO 


```{c}
auto supportedComp = mCollection.contentTypes();
```

#### AUTO 


```{c}
auto job = DavManager::self()->createPropFindJob(
        mCollection.url().url(), builder->buildQuery(), /* depth = */ QStringLiteral("0"));
```

#### AUTO 


```{c}
const auto location = storedJob->getLocationHeader();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &item : itemListJob->items()) {
                qDebug() << item.url().url() << item.contentType() << item.data();
                auto itemFetchJob = new KDAV2::DavItemFetchJob(item);
                itemFetchJob->exec();
                const auto fetchedItem = itemFetchJob->item();
                qDebug() << fetchedItem.contentType() << fetchedItem.data();

                auto itemsFetchJob = new KDAV2::DavItemsFetchJob(collectionUrl, QStringList() << item.url().toDisplayString());
                itemsFetchJob->exec();
                if (itemsFetchJob->item(item.url().toDisplayString()).contentType() != fetchedItem.contentType()) {       //itemsfetchjob do not get contentType
                    qDebug() << "Fetched same item but got different contentType:" << itemsFetchJob->item(item.url().toDisplayString()).contentType();
                }

                if (itemsFetchJob->item(item.url().toDisplayString()).data() != fetchedItem.data()) {
                    qDebug() << "Fetched same item but got different data:" << itemsFetchJob->item(item.url().toDisplayString()).data();
                }
            }
```

#### AUTO 


```{c}
auto reply = mWebDav->report(url.path(), document.toByteArray(), depth.toInt());
```

#### AUTO 


```{c}
auto createJob = new KDAV::DavItemCreateJob(item);
```

#### LAMBDA EXPRESSION 


```{c}
[=] (const QString &error) {
        qWarning() << "Got error " << error;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto collection : job->collections()) {
        qDebug() << collection.displayName() << "PRIVS: " << collection.privileges();
        auto collectionUrl = collection.url();
        std::shared_ptr<KDAV2::EtagCache> cache(new KDAV2::EtagCache());
        int anz = -1;
        //Get all items in a collection add them to cache and make sure, that afterward no item is changed
        {
            auto itemListJob = new KDAV2::DavItemsListJob(collectionUrl, cache);
            itemListJob->exec();
            anz = itemListJob->items().size();
            qDebug() << "items:" << itemListJob->items().size();
            qDebug() << "changed Items:" << itemListJob->changedItems().size();
            qDebug() << "deleted Items:" << itemListJob->deletedItems();
            for (const auto &item : itemListJob->changedItems()) {
                qDebug() << item.url().url() << item.contentType() << item.data();
                auto itemFetchJob = new KDAV2::DavItemFetchJob(item);
                itemFetchJob->exec();
                const auto fetchedItem = itemFetchJob->item();
                qDebug() << fetchedItem.contentType() << fetchedItem.data();

                auto itemsFetchJob = new KDAV2::DavItemsFetchJob(collectionUrl, QStringList() << item.url().toDisplayString());
                itemsFetchJob->exec();
                if (itemsFetchJob->item(item.url().toDisplayString()).contentType() != fetchedItem.contentType()) {       //itemsfetchjob do not get contentType
                    qDebug() << "Fetched same item but got different contentType:" << itemsFetchJob->item(item.url().toDisplayString()).contentType();
                }

                if (itemsFetchJob->item(item.url().toDisplayString()).data() != fetchedItem.data()) {
                    qDebug() << "Fetched same item but got different data:" << itemsFetchJob->item(item.url().toDisplayString()).data();
                }

                cache->setEtag(item.url().toDisplayString(), item.etag());
            }
            cache->setEtag(QStringLiteral("invalid"),QStringLiteral("invalid"));
        }
        {
            qDebug() << "second run: (should be empty).";
            auto itemListJob = new KDAV2::DavItemsListJob(collectionUrl, cache);
            itemListJob->exec();
            if (itemListJob->items().size() != anz) {
                qDebug() << "Items have added/deleted on server.";
            }
            if (itemListJob->changedItems().size() != 0) {
                qDebug() << "Items have changed on server.";
            }
            if (itemListJob->deletedItems() != QStringList() << QStringLiteral("invalid")) {
                qDebug() << "more items deleted:" << itemListJob->deletedItems();
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=] (QNetworkReply::NetworkError error) {
        qCWarning(KDAV2_LOG) << "Network error:" << error << "Message:" << reply->errorString() << "HTTP Status code:" << reply->attribute(QNetworkRequest::HttpStatusCodeAttribute).toInt() << "\nAvailable data:" << reply->readAll();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=] () {
        d->doc.setContent(d->data, true);
        d->responseCode = reply->error();
        if (reply->error()) {
            setError(KJob::UserDefinedError);
            setErrorText(reply->errorString());
        }
        emitResult();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=] (const QUrl &url) {
        qWarning() << "Redirected: " << url;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &header : allHeaders) {
        if (header.startsWith(QStringLiteral("etag:"), Qt::CaseInsensitive)) {
            etag = header.section(QLatin1Char(' '), 1);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=] () {
        qCDebug(KDAV2_LOG) << "Metadata changed: " << reply->rawHeaderPairs();
        d->location = reply->rawHeader("Location");
        d->etag = reply->rawHeader("ETag");
        //"text/x-vcard; charset=utf-8" -> "text/x-vcard"
        d->contentType = reply->rawHeader("Content-Type").split(';').first();
    }
```

#### AUTO 


```{c}
auto reply = mWebDav->mkdir(url.path(), document.toByteArray());
```

#### AUTO 


```{c}
const auto possibleRedirectUrl = reply->attribute(QNetworkRequest::RedirectionTargetAttribute).toUrl();
```

#### AUTO 


```{c}
auto reply = mWebDav->propfind(url.path(), document.toByteArray(), depth.toInt());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &header : allHeaders) {
        if (header.startsWith(QLatin1String("location:"), Qt::CaseInsensitive)) {
            location = header.section(QLatin1Char(' '), 1);
        }
    }
```

#### AUTO 


```{c}
auto collectionUrl = collection.url();
```

#### AUTO 


```{c}
auto collectionModifyJob = new KDAV::DavCollectionModifyJob(collectionUrl);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &rawHeaderItem : req.rawHeaderList()) {
        qCDebug(KDAV2_LOG) << "   " << rawHeaderItem << ": " << req.rawHeader(rawHeaderItem);
    }
```

#### AUTO 


```{c}
auto *deleteJob = qobject_cast<DavJob *>(job);
```

#### LAMBDA EXPRESSION 


```{c}
[=] () {
        // qWarning() << "Metadata changed: " << reply->rawHeaderPairs();
        d->location = reply->rawHeader("Location");
        d->etag = reply->rawHeader("ETag");
        //"text/x-vcard; charset=utf-8" -> "text/x-vcard"
        d->contentType = reply->rawHeader("Content-Type").split(';').first();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : items) {
        if (!contains(item.remoteId())) {
            setEtagInternal(item.remoteId(), item.remoteRevision());
        }
    }
```

#### AUTO 


```{c}
auto reply = mWebDav->put(url.path(), data, {{"Content-Type", contentType}, {"If-Match", etag}});
```

#### LAMBDA EXPRESSION 


```{c}
[=] () {
        d->data.append(reply->readAll());
    }
```

#### AUTO 


```{c}
auto *job = new KDAV2::DavCollectionsFetchJob(davUrl);
```

#### AUTO 


```{c}
auto *job = new KDAV::DavCollectionsFetchJob(davUrl);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &item : itemListJob->items()) {
                qInfo() << item.url().url() << item.contentType() << item.data();
                auto itemFetchJob = new KDAV2::DavItemFetchJob(item);
                itemFetchJob->exec();
                const auto fetchedItem = itemFetchJob->item();
                qInfo() << fetchedItem.contentType() << fetchedItem.data();

                auto itemsFetchJob = new KDAV2::DavItemsFetchJob(collectionUrl, QStringList() << item.url().toDisplayString());
                itemsFetchJob->exec();
                if (itemsFetchJob->item(item.url().toDisplayString()).contentType() != fetchedItem.contentType()) {       //itemsfetchjob do not get contentType
                    qInfo() << "Fetched same item but got different contentType:" << itemsFetchJob->item(item.url().toDisplayString()).contentType();
                }

                if (itemsFetchJob->item(item.url().toDisplayString()).data() != fetchedItem.data()) {
                    qInfo() << "Fetched same item but got different data:" << itemsFetchJob->item(item.url().toDisplayString()).data();
                }
            }
```

#### AUTO 


```{c}
auto result = QStringLiteral("There was an error when modifying the properties");
```

#### AUTO 


```{c}
auto reply = mWebDav->put(url.path(), data, {{"Content-Type", contentType}, {"If-None-Match", "*"}});
```

#### AUTO 


```{c}
auto displayNameElement = propElement.appendChild(
            document.createElementNS(QStringLiteral("DAV:"), QStringLiteral("displayname")));
```

#### AUTO 


```{c}
auto modifyJob = new KDAV::DavItemModifyJob(item);
```

#### AUTO 


```{c}
auto job = DavManager::self()->createPropFindJob(url, collectionQuery);
```

#### AUTO 


```{c}
auto reply = mWebDav->remove(url.path());
```

#### LAMBDA EXPRESSION 


```{c}
[=] (QNetworkReply::NetworkError error) {
        qCWarning(KDAV2_LOG) << "Error " << error << reply->errorString() << "HTTP Status code " << reply->attribute(QNetworkRequest::HttpStatusCodeAttribute).toInt();
        qCWarning(KDAV2_LOG) << "Error " << reply->readAll();
    }
```

#### AUTO 


```{c}
auto reply = mWebDav->mkcalendar(url.path(), document.toByteArray());
```

#### AUTO 


```{c}
auto storedJob = static_cast<DavJob*>(job);
```

#### AUTO 


```{c}
auto deleteJob = new KDAV2::DavItemDeleteJob(item);
```

#### AUTO 


```{c}
auto itemsFetchJob = new KDAV2::DavItemsFetchJob(collectionUrl, QStringList() << item.url().toDisplayString());
```

#### AUTO 


```{c}
auto url = davUrl.url();
```

#### LAMBDA EXPRESSION 


```{c}
[=] (const QUrl &url) {
        qCWarning(KDAV2_LOG) << "Redirected: " << url;
    }
```

