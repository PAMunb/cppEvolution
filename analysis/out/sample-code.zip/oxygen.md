#### LAMBDA EXPRESSION 


```{c}
[b]() { b->update(); }
```

#### AUTO 


```{c}
auto setPageIcon = []( KPageWidgetItem* page, const QString& iconName )
        {
            #if OXYGEN_USE_KDE4
            page->setIcon( KIcon( iconName ) );
            #else
            page->setIcon( QIcon::fromTheme( iconName ) );
            #endif
        };
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &item : m_queue)
            { if (item.first == key) return item.second; }
```

#### AUTO 


```{c}
auto view( _pageDialog.data()->findChild<QAbstractItemView*>() );
```

#### RANGE FOR STATEMENT 


```{c}
for ( QMdiSubWindow *window : children )
            {
                simulator().click( window );
                simulator().slide( window, QPoint( 20, 20 ) );
                simulator().slide( window, QPoint( -20, -20 ) );
            }
```

#### RANGE FOR STATEMENT 


```{c}
for ( QObject *child : children )
        {
            if( FrameShadowBase* shadow = qobject_cast<FrameShadowBase*>(child) )
            {
                shadow->hide();
                shadow->setParent(0);
                shadow->deleteLater();
            }
        }
```

#### AUTO 


```{c}
const auto viewItemOption = qstyleoption_cast<const QStyleOptionViewItem*>( option );
```

#### RANGE FOR STATEMENT 


```{c}
for( auto&& item:items )
        {


            // get header and widget
            auto header = item->header();
            auto demoWidget( qobject_cast<DemoWidget*>( item->widget() ) );
            if( !demoWidget ) continue;

            // do not add oneself to the list
            if( qobject_cast<BenchmarkWidget*>( demoWidget ) ) continue;

            // add checkbox
            QCheckBox* checkbox( new QCheckBox( this ) );
            checkbox->setText( header );

            const bool hasBenchmark( demoWidget->metaObject()->indexOfSlot( "benchmark()" ) >= 0 );
            checkbox->setEnabled( hasBenchmark );
            checkbox->setChecked( hasBenchmark );

            if( hasBenchmark )
            { connect( this, SIGNAL(runBenchmark()), demoWidget, SLOT(benchmark()) ); }

            ui.verticalLayout->addWidget( checkbox );

            _items.append( ItemPair(checkbox, item) );

            connect( checkbox, SIGNAL(toggled(bool)), SLOT(updateButtonState()) );

        }
```

#### RANGE FOR STATEMENT 


```{c}
for( auto item:items )
        {
            connect( shortcut, SIGNAL(activated()), item->widget(), SLOT(benchmark()) );
            connect( this, SIGNAL(abortSimulations()), &static_cast<DemoWidget*>(item->widget())->simulator(), SLOT(abort()) );
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( AnimationConfigItem* item : children )
        {
            item->QWidget::setEnabled( false );
            connect( animationsEnabled(), SIGNAL(toggled(bool)), item, SLOT(setEnabled(bool)) );
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const Value &value : std::as_const(_data) )
        { if( value ) out.insert( value.data()->target().data() ); }
```

#### AUTO 


```{c}
auto d = qobject_cast<Decoration*>(decoration)
```

#### RANGE FOR STATEMENT 


```{c}
for ( QWidget *widget :  otherWidgets )
            { registerWidget( widget ); }
```

#### AUTO 


```{c}
const auto pixmap = menuItemOption->icon.pixmap( iconSize, iconMode, iconState );
```

#### AUTO 


```{c}
const auto v2 = qstyleoption_cast<const QStyleOptionDockWidget*>( option );
```

#### AUTO 


```{c}
const auto frameOption = qstyleoption_cast<const QStyleOptionFrame*>( option );
```

#### RANGE FOR STATEMENT 


```{c}
for ( const InternalSettingsPtr &exception : std::as_const(_exceptions) )
        {

            writeConfig( exception.data(), config.data(), exceptionGroupName( index ) );
            ++index;

        }
```

#### AUTO 


```{c}
const auto tabOptV3 = qstyleoption_cast<const QStyleOptionTab*>( option );
```

#### RANGE FOR STATEMENT 


```{c}
for ( QToolButton *button : std::as_const(_toolButtons) )
        { button->setIconSize( QSize( sizes[index], sizes[index] ) ); }
```

#### RANGE FOR STATEMENT 


```{c}
for ( QObject *child : children )
        {
            if( FrameShadowBase* shadow = qobject_cast<FrameShadowBase*>(child) )
            {
                shadow->hide();
                shadow->setParent(nullptr);
                shadow->deleteLater();
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( AnimationConfigItem* item : children )
        {
            if( item != _progressBarBusyAnimations )
            {
                item->QWidget::setEnabled( false );
                connect( animationsEnabled(), SIGNAL(toggled(bool)), item, SLOT(setEnabled(bool)) );
            }
        }
```

#### AUTO 


```{c}
const auto topWidgets = qApp->topLevelWidgets();
```

#### AUTO 


```{c}
auto *c = QX11Info::connection();
```

#### RANGE FOR STATEMENT 


```{c}
for ( QObject *child : children )
        {
            if( MdiWindowShadow* shadow = qobject_cast<MdiWindowShadow*>(child) )
            { if( shadow->widget() == object ) return shadow; }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            // read in the configuration
            setInitialized( false );
            readConfig();
            setInitialized( true );
            emit recreateDecorations();
        }
```

#### AUTO 


```{c}
auto internalSettings
```

#### AUTO 


```{c}
const auto clientPtr = d->client().toStrongRef();
```

#### RANGE FOR STATEMENT 


```{c}
for ( QWidget *widget : otherWidgets )
            { registerWidget( widget ); }
```

#### AUTO 


```{c}
const auto tabOptionV3 = qstyleoption_cast<const QStyleOptionTab*>( tabOption );
```

#### RANGE FOR STATEMENT 


```{c}
for ( KConfigSkeletonItem *item : skelItems )
        {
            if( !groupName.isEmpty() ) item->setGroup( groupName );
            item->readConfig( config );
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( AnimationConfigItem* item : children )
        { if( item->configurationWidget()->isVisible() ) item->configurationButton()->setChecked( false ); }
```

#### RANGE FOR STATEMENT 


```{c}
for ( auto internalSettings : std::as_const(m_exceptions) )
        {

            // discard disabled exceptions
            if( !internalSettings->enabled() ) continue;

            // discard exceptions with empty exception pattern
            if( internalSettings->exceptionPattern().isEmpty() ) continue;

            /*
            decide which value is to be compared
            to the regular expression, based on exception type
            */
            QString value;
            switch( internalSettings->exceptionType() )
            {
                case InternalSettings::ExceptionWindowTitle:
                {
                    value = windowTitle.isEmpty() ? (windowTitle = clientPtr->caption()):windowTitle;
                    break;
                }

                default:
                case InternalSettings::ExceptionWindowClassName:
                {
                    if( className.isEmpty() )
                    {
                        // retrieve class name
                        KWindowInfo info( clientPtr->windowId(), 0, NET::WM2WindowClass );
                        QString window_className( QString::fromUtf8(info.windowClassName()) );
                        QString window_class( QString::fromUtf8(info.windowClassClass()) );
                        className = window_className + QStringLiteral(" ") + window_class;
                    }

                    value = className;
                    break;
                }

            }

            // check matching
            if(value.contains(QRegularExpression( internalSettings->exceptionPattern() )))
            { return internalSettings; }

        }
```

#### RANGE FOR STATEMENT 


```{c}
for( auto&& item:_items )
        {
            if( item.first->isEnabled() && item.first->isChecked() )
            {
                enabled = true;
                break;
            }
        }
```

#### AUTO 


```{c}
const auto frameOption( qstyleoption_cast<const QStyleOptionFrame*>( option ) );
```

#### AUTO 


```{c}
auto demoWidget( qobject_cast<DemoWidget*>( item->widget() ) );
```

#### RANGE FOR STATEMENT 


```{c}
for ( const SlabRect &slab : std::as_const(slabs) )
        { renderSlab( painter, slab, palette.color( QPalette::Window ), NoFill ); }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const WidgetPointer &widget : std::as_const(_pendingWidgets) )
            { if( widget ) update( widget.data() ); }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const int iconSize : s_iconSizes )
                {

                    QPixmap pixmap(  iconSize, iconSize );
                    pixmap.fill( Qt::transparent );
                    QPainter painter( &pixmap );
                    painter.setRenderHints( QPainter::Antialiasing );
                    painter.setWindow( rect );
                    painter.setBrush( Qt::NoBrush );

                    painter.translate( QRectF( rect ).center() );

                    const bool reverseLayout( option && option->direction == Qt::RightToLeft );
                    QPolygonF arrow = genericArrow( reverseLayout ? ArrowLeft:ArrowRight, ArrowTiny );

                    const qreal width( 1.1 );
                    painter.translate( 0, 0.5 );
                    painter.setBrush( Qt::NoBrush );
                    painter.setPen( QPen( _helper->calcLightColor( buttonColor ), width, Qt::SolidLine, Qt::RoundCap, Qt::RoundJoin ) );
                    painter.drawPolyline( arrow );

                    painter.translate( 0,-1 );
                    painter.setBrush( Qt::NoBrush );
                    painter.setPen( QPen( iconColor, width, Qt::SolidLine, Qt::RoundCap, Qt::RoundJoin ) );
                    painter.drawPolyline( arrow );
                    painter.end();
                    icon.addPixmap( pixmap );

                }
```

#### AUTO 


```{c}
const auto children = findChildren<AnimationConfigItem*>();
```

#### RANGE FOR STATEMENT 


```{c}
for ( const BaseEngine::Pointer &engine : std::as_const(_engines) )
        { if( engine && engine.data()->unregisterWidget( widget ) ) break; }
```

#### LAMBDA EXPRESSION 


```{c}
[this, widget] { _shadows.remove( widget ); }
```

#### RANGE FOR STATEMENT 


```{c}
for ( QObject *child : children )
        { if( qobject_cast<QToolButton*>( child ) ) childAddedEvent( child ); }
```

#### AUTO 


```{c}
auto&& item
```

#### RANGE FOR STATEMENT 


```{c}
for ( QObject* child : children )
        {
            if( QTabBar* tabbar = qobject_cast<QTabBar*>( child ) )
            {
                selectTab( tabbar, index, delay );
                break;
            }
        }
```

#### AUTO 


```{c}
const auto progressBarOption2 = qstyleoption_cast<const QStyleOptionProgressBar*>( option );
```

#### AUTO 


```{c}
auto selectionMenu = manager->createSchemeSelectionMenu(this);
```

#### AUTO 


```{c}
const auto otherWidgets = other->registeredWidgets();
```

#### AUTO 


```{c}
auto header = item->header();
```

#### AUTO 


```{c}
const auto clientPtr = decoration()->client().toStrongRef();
```

#### AUTO 


```{c}
const auto skelItems = skeleton->items();
```

#### AUTO 


```{c}
const auto children = object->parent()->children();
```

#### RANGE FOR STATEMENT 


```{c}
for ( QObject* child : children )
        {
            if( child->inherits( "KLineEditButton" ) )
            {
                _hasClearButton = true;
                _clearButtonRect = static_cast<QWidget*>(child)->geometry();
                break;
            }
        }
```

#### AUTO 


```{c}
const auto children = _toolBar->findChildren<QToolButton*>();
```

#### AUTO 


```{c}
auto manager = new KColorSchemeManager( parent );
```

#### AUTO 


```{c}
auto widget( static_cast<QWidget*>( object ) );
```

#### RANGE FOR STATEMENT 


```{c}
for ( SlabRect slab : std::as_const(slabs) )
        {
            adjustSlabRect( slab, tabWidgetRect, documentMode, verticalTabs );
            renderSlab( painter, slab, color, NoFill );
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto &item : m_queue)
            { f(item.second); }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const DataMap<MenuDataV2>::Value &value : std::as_const(_data) )
            { if( value ) value.data()->setFollowMouseDuration( duration ); }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString &exception : whiteList )
        {
            ExceptionId id( exception );
            if( !id.className().isEmpty() )
            { _whiteList.insert( ExceptionId( exception ) ); }
        }
```

#### AUTO 


```{c}
const auto tabOption( qstyleoption_cast<const QStyleOptionTab*>( option ) );
```

#### RANGE FOR STATEMENT 


```{c}
for ( const DataMap<MenuBarDataV2>::Value &value : std::as_const(_data) )
            { if( value ) value.data()->setFollowMouseDuration( duration ); }
```

#### AUTO 


```{c}
const auto iconSize = pixelMetric(QStyle::PM_SmallIconSize, nullptr, widget);
```

#### RANGE FOR STATEMENT 


```{c}
for ( QWidget *widget : widgets )
                {
                    // get all toolbuttons
                    const auto children = widget->children();
                    for ( QObject *child : children )
                    {
                        if( QToolButton* toolButton = qobject_cast<QToolButton*>( child ) )
                        { _widgetStateEngine->registerWidget( toolButton, AnimationHover ); }
                    }
                }
```

#### AUTO 


```{c}
auto setPageIcon = []( KPageWidgetItem* page, const QString& iconName )
        {
            page->setIcon( QIcon::fromTheme( iconName ) );
        };
```

#### AUTO 


```{c}
auto parent( parentWidget() );
```

#### AUTO 


```{c}
auto item( _items[index] );
```

#### RANGE FOR STATEMENT 


```{c}
for ( QObject *child : children )
                    {
                        if( QToolButton* toolButton = qobject_cast<QToolButton*>( child ) )
                        { _widgetStateEngine->registerWidget( toolButton, AnimationHover ); }
                    }
```

#### AUTO 


```{c}
const auto widgets = _widgetStateEngine->registeredWidgets( AnimationHover|AnimationFocus );
```

#### AUTO 


```{c}
auto client = decoration->client().data();
```

#### AUTO 


```{c}
auto c = decoration->client().data();
```

#### AUTO 


```{c}
const auto children = tabwidget->children();
```

#### AUTO 


```{c}
const auto &item
```

#### RANGE FOR STATEMENT 


```{c}
for ( QObject *child : children )
        {
            if( FrameShadowBase* shadow = qobject_cast<FrameShadowBase *>(child) )
            { shadow->setHasContrast( value ); }
        }
```

#### AUTO 


```{c}
auto cookie = xcb_query_tree_unchecked(c, current);
```

#### AUTO 


```{c}
const auto children = widget->children();
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QKeySequence &sequence : shortcuts )
        { connect( new QShortcut( sequence, this ), SIGNAL(activated()), SLOT(close()) ); }
```

#### AUTO 


```{c}
const auto progressBarOption2( qstyleoption_cast<const QStyleOptionProgressBar*>( option ) );
```

#### AUTO 


```{c}
auto d( qobject_cast<Decoration*>( decoration().data() ) );
```

#### RANGE FOR STATEMENT 


```{c}
for ( const Value &value : std::as_const(_enableData) )
            { if( value ) out.insert( value.data()->target().data() ); }
```

#### RANGE FOR STATEMENT 


```{c}
for ( QEvent* event : std::as_const(_pendingEvents) )
                {

                    if( event->type() == QEvent::MouseMove )
                    {
                        QPoint position( static_cast<QMouseEvent*>( event )->pos() );
                        moveCursor( _pendingWidget.data()->mapToGlobal( position ) );
                    }

                    postQEvent( _pendingWidget.data(), event );
                    postDelay( 150 );

                }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const ExceptionId &id : std::as_const(_blackList) )
        {
            if( !id.appName().isEmpty() && id.appName() != appName ) continue;
            if( id.className() == QStringLiteral( "*" ) && !id.appName().isEmpty() )
            {
                // if application name matches and all classes are selected
                // disable the grabbing entirely
                setEnabled( false );
                return true;
            }
            if( widget->inherits( id.className().toLatin1().data() ) ) return true;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[]( KPageWidgetItem* page, const QString& iconName )
        {
            page->setIcon( QIcon::fromTheme( iconName ) );
        }
```

#### AUTO 


```{c}
const auto clientPtr = decoration->client().toStrongRef();
```

#### RANGE FOR STATEMENT 


```{c}
for ( QAbstractButton* button : children )
            { simulator().click( button ); }
```

#### RANGE FOR STATEMENT 


```{c}
for( auto item:items )
        {
            if( item->widget()->metaObject()->indexOfSlot( "benchmark()" ) >= 0 )
            { connect( shortcut, SIGNAL(activated()), item->widget(), SLOT(benchmark()) ); }
            connect( this, SIGNAL(abortSimulations()), &static_cast<DemoWidget*>(item->widget())->simulator(), SLOT(abort()) );
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const Value& value : *this )
            { if( value ) value.data()->setDuration( duration ); }
```

#### AUTO 


```{c}
const auto v2 = qstyleoption_cast<const QStyleOptionToolBox*>( option );
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QLine &tickLine : std::as_const(tickLines) )
                    {
                        if( horizontal ) painter->drawLine( tickLine.translated( upsideDown ? (rect.width() - position) : position, 0 ) );
                        else painter->drawLine( tickLine.translated( 0, upsideDown ? (rect.height() - position):position ) );
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const DataMap<ToolBarData>::Value &value : std::as_const(_data) )
            { if( value ) value.data()->setFollowMouseDuration( duration ); }
```

#### RANGE FOR STATEMENT 


```{c}
for ( QToolButton *button : children )
            { simulator().click( button ); }
```

#### RANGE FOR STATEMENT 


```{c}
for ( QObject *child : children )
        {
            if( FrameShadowBase* shadow = qobject_cast<FrameShadowBase *>(child) )
            { shadow->updateGeometry(); }
        }
```

#### AUTO 


```{c}
auto item
```

#### RANGE FOR STATEMENT 


```{c}
for ( const DataMap<ScrollBarData>::Value &data : std::as_const(_data) )
            { if( data ) data.data()->setEnabled( value ); }
```

#### AUTO 


```{c}
const auto iconRect = centerRect( rect, iconSize, iconSize );
```

#### AUTO 


```{c}
const auto scheme( currentSchemeName() );
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString &style : std::as_const(availableStyles) )
    {
        QAction *a = new QAction( style, stylesGroup );
        a->setCheckable( true );
        a->setData( style );
        if ( m_widgetStyle.compare(style, Qt::CaseInsensitive ) == 0 )
        {
            a->setChecked( true );
            if (setStyle)
            {
                // selectedStyleName was not empty and the
                // the style exists: activate it.
                activateStyle( style );
            }
        }
        stylesAction->addAction( a );
    }
```

#### AUTO 


```{c}
auto children = object->parent()->children();
```

#### AUTO 


```{c}
const auto children = tabBar->children();
```

#### LAMBDA EXPRESSION 


```{c}
[&]( QAction *a ) { activateStyle(a->data().toString()); }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const ExceptionId &id : std::as_const(_whiteList) )
        {
            if( !id.appName().isEmpty() && id.appName() != appName ) continue;
            if( widget->inherits( id.className().toLatin1().data() ) ) return true;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( QObject *child : children )
        {
            if( FrameShadowBase* shadow = qobject_cast<FrameShadowBase *>(child) )
            { shadow->raise(); }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( QObject* childObject : children )
        {
            QWidget* child( qobject_cast<QWidget*>( childObject ) );
            if( !(child && child->isVisible()) ) continue;

            if( isOpaque( child ) )
            {

                const QPoint offset( child->mapTo( parent, QPoint( 0, 0 ) ) );
                if( child->mask().isEmpty() )
                {
                    const QRect rect( child->rect().translated( offset ).adjusted( 1, 1, -1, -1 ) );
                    region -= rect;

                }  else region -= child->mask().translated( offset );

            } else { trimBlurRegion( parent, child, region ); }

        }
```

#### RANGE FOR STATEMENT 


```{c}
for( QWidget* widget : _widgets )
        { installShadows( widget ); }
```

#### LAMBDA EXPRESSION 


```{c}
[]( KPageWidgetItem* page, const QString& iconName )
        {
            #if OXYGEN_USE_KDE4
            page->setIcon( KIcon( iconName ) );
            #else
            page->setIcon( QIcon::fromTheme( iconName ) );
            #endif
        }
```

#### AUTO 


```{c}
const auto &key
```

#### AUTO 


```{c}
const auto children = ui.mdiArea->findChildren<QMdiSubWindow*>();
```

#### RANGE FOR STATEMENT 


```{c}
for ( QWidget *child : children )
        {
            if( child->parent() == viewport && child->backgroundRole() == QPalette::Window )
            { child->setAutoFillBackground( false ); }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QObject *child : children )
        {
            const QToolButton* toolButton( qobject_cast<const QToolButton*>( child ) );
            if( toolButton && toolButton->isVisible() ) mask -= toolButton->geometry();
        }
```

#### AUTO 


```{c}
auto child
```

#### AUTO 


```{c}
const auto view = qobject_cast<const QAbstractItemView *>( widget );
```

#### RANGE FOR STATEMENT 


```{c}
for ( const Value &value : *this )
            { if( value ) value.data()->setEnabled( enabled ); }
```

#### AUTO 


```{c}
const  auto tabOptionV3 = qstyleoption_cast<const QStyleOptionTab*>( option );
```

#### RANGE FOR STATEMENT 


```{c}
for ( QObject *child : children )
        {
            if( FrameShadowBase* shadow = qobject_cast<FrameShadowBase *>(child) )
            { shadow->update();}
        }
```

#### AUTO 


```{c}
const auto tabOptionV3( qstyleoption_cast<const QStyleOptionTab*>( option ) );
```

#### AUTO 


```{c}
auto hole = _widget->frameGeometry().adjusted(1, 1, -1, -1 );
```

#### AUTO 


```{c}
const auto children = dialog.findChildren<QAbstractScrollArea*>();
```

#### RANGE FOR STATEMENT 


```{c}
for ( QWidget* widget : topWidgets )
        { widget->update(); }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const int iconSize : s_iconSizes )
                {
                    QPixmap pixmap( iconSize, iconSize );
                    pixmap.fill( Qt::transparent );
                    QPainter painter( &pixmap );
                    painter.setRenderHints( QPainter::Antialiasing );
                    painter.setWindow( rect );
                    painter.setBrush( Qt::NoBrush );

                    painter.translate( QRectF( rect ).center() );

                    QPolygonF arrow = genericArrow( ArrowDown, ArrowTiny );

                    const qreal width( 1.1 );
                    painter.translate( 0, 0.5 );
                    painter.setBrush( Qt::NoBrush );
                    painter.setPen( QPen( _helper->calcLightColor( buttonColor ), width, Qt::SolidLine, Qt::RoundCap, Qt::RoundJoin ) );
                    painter.drawPolyline( arrow );

                    painter.translate( 0,-1 );
                    painter.setBrush( Qt::NoBrush );
                    painter.setPen( QPen( iconColor, width, Qt::SolidLine, Qt::RoundCap, Qt::RoundJoin ) );
                    painter.drawPolyline( arrow );
                    painter.end();

                    icon.addPixmap( pixmap );

                }
```

#### RANGE FOR STATEMENT 


```{c}
for ( QWidget *widget : topWidgets )
        {
            // make sure widget has a valid WId
            if( !(widget->testAttribute(Qt::WA_WState_Created) || widget->internalWinId() ) ) continue;

            // make sure widget has a decoration
            if( !_helper->hasDecoration( widget ) ) continue;

            // update flags
            _helper->setHasBackgroundGradient( widget->winId(), true );
        }
```

#### AUTO 


```{c}
const auto progressBarOption = qstyleoption_cast<const QStyleOptionProgressBar*>( option );
```

#### RANGE FOR STATEMENT 


```{c}
for ( QObject *child : children )
        {
            if( FrameShadowBase* shadow = qobject_cast<FrameShadowBase *>(child) )
            { shadow->updateGeometry( rect ); }
        }
```

#### AUTO 


```{c}
const auto& palette( option->palette );
```

#### AUTO 


```{c}
const auto children = target->children();
```

#### AUTO 


```{c}
auto buttonBox = new QDialogButtonBox( QDialogButtonBox::Ok, Qt::Horizontal );
```

#### RANGE FOR STATEMENT 


```{c}
for ( const Event& event : std::as_const(_events) )
        {
            if( _aborted )
            {
                _events.clear();
                return;
            }

            processEvent( event );
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const Value &value : std::as_const(_focusData) )
            { if( value ) out.insert( value.data()->target().data() ); }
```

#### AUTO 


```{c}
auto selectionMenu = manager->createSchemeSelectionMenu( scheme, this );
```

#### RANGE FOR STATEMENT 


```{c}
for ( QWidget *widget : widgets)
                {
                    if( qobject_cast<QToolButton*>( widget ) && qobject_cast<QToolBar*>( widget->parentWidget() ) )
                    { _widgetStateEngine->unregisterWidget( widget ); }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for ( QToolButton *button : std::as_const(_toolButtons) )
        {
            switch( index )
            {
                default:
                case 0: button->setToolButtonStyle( Qt::ToolButtonIconOnly ); break;
                case 1: button->setToolButtonStyle( Qt::ToolButtonTextOnly ); break;
                case 2: button->setToolButtonStyle( Qt::ToolButtonTextBesideIcon ); break;
                case 3: button->setToolButtonStyle( Qt::ToolButtonTextUnderIcon ); break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString &exception : blackList )
        {
            ExceptionId id( exception );
            if( !id.className().isEmpty() )
            { _blackList.insert( ExceptionId( exception ) ); }
        }
```

#### AUTO 


```{c}
auto windowShadow( new MdiWindowShadow( widget->parentWidget(), _shadowTiles ) );
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            _shadowCache.invalidateCaches();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( QObject *child : children )
        {
            if( FrameShadowBase* shadow = qobject_cast<FrameShadowBase *>(child) )
            { shadow->updateState( focus, hover, opacity, mode ); }
        }
```

#### AUTO 


```{c}
const auto shortcuts = KStandardShortcut::quit();
```

#### RANGE FOR STATEMENT 


```{c}
for ( const Value &value : std::as_const(_hoverData) )
            { if( value ) out.insert( value.data()->target().data() ); }
```

#### AUTO 


```{c}
auto d = qobject_cast<Decoration*>(decoration());
```

#### AUTO 


```{c}
auto &item
```

#### AUTO 


```{c}
const auto *clientP = decoration->client().toStrongRef().data();
```

#### AUTO 


```{c}
const auto children = ui.toolBox->findChildren<QAbstractButton*>();
```

#### RANGE FOR STATEMENT 


```{c}
for ( QPushButton* button : std::as_const(_pushButtons) )
        { button->setFlat( value ); }
```

#### RANGE FOR STATEMENT 


```{c}
for ( auto internalSettings : std::as_const(m_exceptions) )
        {

            // discard disabled exceptions
            if( !internalSettings->enabled() ) continue;

            // discard exceptions with empty exception pattern
            if( internalSettings->exceptionPattern().isEmpty() ) continue;

            /*
            decide which value is to be compared
            to the regular expression, based on exception type
            */
            QString value;
            switch( internalSettings->exceptionType() )
            {
                case InternalSettings::ExceptionWindowTitle:
                {
                    value = windowTitle.isEmpty() ? (windowTitle = clientPtr->caption()):windowTitle;
                    break;
                }

                default:
                case InternalSettings::ExceptionWindowClassName:
                {
                    if( className.isEmpty() )
                    {
                        // retrieve class name
                        KWindowInfo info( clientPtr->windowId(), {}, NET::WM2WindowClass );
                        QString window_className( QString::fromUtf8(info.windowClassName()) );
                        QString window_class( QString::fromUtf8(info.windowClassClass()) );
                        className = window_className + QStringLiteral(" ") + window_class;
                    }

                    value = className;
                    break;
                }

            }

            // check matching
            if(value.contains(QRegularExpression( internalSettings->exceptionPattern() )))
            { return internalSettings; }

        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( QAbstractButton *button : children )
            { simulator().click( button ); }
```

#### LAMBDA EXPRESSION 


```{c}
[value] (Value item) { item->setMaxCost( value );}
```

#### RANGE FOR STATEMENT 


```{c}
for ( auto child : children )
    {
        child->adjustSize();
        child->viewport()->adjustSize();
    }
```

#### AUTO 


```{c}
auto subwindow( qobject_cast<QMdiSubWindow*>( widget ) );
```

#### RANGE FOR STATEMENT 


```{c}
for ( auto internalSettings : std::as_const(m_exceptions) )
        {

            // discard disabled exceptions
            if( !internalSettings->enabled() ) continue;

            // discard exceptions with empty exception pattern
            if( internalSettings->exceptionPattern().isEmpty() ) continue;

            /*
            decide which value is to be compared
            to the regular expression, based on exception type
            */
            QString value;
            switch( internalSettings->exceptionType() )
            {
                case InternalSettings::ExceptionWindowTitle:
                {
                    value = windowTitle.isEmpty() ? (windowTitle = client->caption()):windowTitle;
                    break;
                }

                default:
                case InternalSettings::ExceptionWindowClassName:
                {
                    if( className.isEmpty() )
                    {
                        // retrieve class name
                        KWindowInfo info( client->windowId(), 0, NET::WM2WindowClass );
                        QString window_className( QString::fromUtf8(info.windowClassName()) );
                        QString window_class( QString::fromUtf8(info.windowClassClass()) );
                        className = window_className + QStringLiteral(" ") + window_class;
                    }

                    value = className;
                    break;
                }

            }

            // check matching
            if(value.contains(QRegularExpression( internalSettings->exceptionPattern() )))
            { return internalSettings; }

        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const auto &key : keys )
        {
            KConfigSkeletonItem* item( skeleton->findItem( key ) );
            if( !item ) continue;

            if( !groupName.isEmpty() ) item->setGroup( groupName );
            KConfigGroup configGroup( config, item->group() );
            configGroup.writeEntry( item->key(), item->property() );

        }
```

#### AUTO 


```{c}
auto benchmarkWidget( new BenchmarkWidget() );
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QColor & color : std::as_const(colors) )
        {
            painter->setPen( color );
            painter->drawPath( path );
            painter->translate( 0,-1 );
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool hovered){
            if( buttonAnimationsEnabled() && hasDecoration() ) {
                _glowAnimation->setDirection( hovered ? Animation::Forward : Animation::Backward );
                    if( !isAnimated() ) _glowAnimation->start();
            }
        }
```

