#### AUTO 


```{c}
auto act = new QAction(QIcon::fromTheme(QStringLiteral("format-fill-color")), i18n("Text Background Color..."), this);
```

#### LAMBDA EXPRESSION 


```{c}
[this, urlLabel]() {
        slotSelectNote(urlLabel->url());
    }
```

#### AUTO 


```{c}
auto vbox = new QVBoxLayout(this);
```

#### AUTO 


```{c}
auto *attr = new NoteAlarmAttribute();
```

#### AUTO 


```{c}
auto noteNetworkConfigWidget = new NoteNetworkConfigWidget(this);
```

#### AUTO 


```{c}
auto *helpMenu = new KHelpMenu(this, aboutData, true);
```

#### AUTO 


```{c}
auto *eda = new Akonadi::EntityDisplayAttribute();
```

#### AUTO 


```{c}
auto *attribute
        = mItem.attribute<NoteShared::NoteDisplayAttribute>(Akonadi::Item::AddIfMissing);
```

#### AUTO 


```{c}
auto getNewTheme = new QToolButton;
```

#### AUTO 


```{c}
auto *job = new Akonadi::CollectionModifyJob(col);
```

#### AUTO 


```{c}
auto removeAlarm = new QAction(QIcon::fromTheme(QStringLiteral("edit-delete")), i18n("Remove Alarm"), entriesContextMenu);
```

#### AUTO 


```{c}
auto *lay = new QVBoxLayout(this);
```

#### AUTO 


```{c}
auto *header = new KMime::Headers::Generic("X-Cursor-Position");
```

#### AUTO 


```{c}
auto *attribute = item.attribute<NoteShared::NoteAlarmAttribute>(Akonadi::Item::AddIfMissing);
```

#### AUTO 


```{c}
const auto attr = mItem.attribute<NoteShared::NoteAlarmAttribute>();
```

#### AUTO 


```{c}
auto headerLayout = new QBoxLayout(headerLayoutDirection);
```

#### AUTO 


```{c}
auto *job = new Akonadi::ItemDeleteJob(lst);
```

#### AUTO 


```{c}
auto attr = item.attribute<NoteShared::NoteDisplayAttribute>(Akonadi::Item::AddIfMissing);
```

#### AUTO 


```{c}
auto *searchLine = new QLineEdit(this);
```

#### AUTO 


```{c}
auto *note = new KNote(m_noteGUI, item, mDebugAkonadiSearch);
```

#### AUTO 


```{c}
auto *job = new Akonadi::CollectionModifyJob(col, this);
```

#### AUTO 


```{c}
auto label = new QLabel(this);
```

#### AUTO 


```{c}
auto *layout = new QVBoxLayout;
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : lst) {
        action->setShortcutContext(Qt::WidgetWithChildrenShortcut);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &contact : std::as_const(contacts)) {
            const QString email = contact.fullEmail();
            if (email.isEmpty()) {
                attendees.append(contact.realName() + QLatin1String("<>"));
            } else {
                attendees.append(email);
            }
        }
```

#### AUTO 


```{c}
auto obj = new KNotePrintObject(mNotes.value(akonadiId)->item());
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Collection &col : collections) {
        if (!col.contentMimeTypes().contains(Akonadi::NoteUtils::noteMimeType())) {
            continue;
        }
        auto job = new Akonadi::ItemFetchJob(col, mSession);
        job->setDeliveryOption(Akonadi::ItemFetchJob::EmitItemsInBatches);
        job->fetchScope().fetchAttribute<NoteShared::NoteAlarmAttribute>();
        job->fetchScope().fetchAttribute<NoteShared::NoteLockAttribute>();
        job->fetchScope().fetchAttribute<NoteShared::NoteDisplayAttribute>();
        job->fetchScope().fetchAttribute<NoteShared::NoteAlarmAttribute>();
        job->fetchScope().fetchFullPayload(true);
        connect(job, &Akonadi::ItemFetchJob::itemsReceived, this, [this](const Akonadi::Item::List &items) {
            for (const Akonadi::Item &item : items) {
                slotItemAdded(item);
            }
        });
    }
```

#### AUTO 


```{c}
auto *attribute
                = item.attribute<NoteShared::NoteAlarmAttribute>(Akonadi::Item::AddIfMissing);
```

#### AUTO 


```{c}
auto tabWidget = new QTabWidget;
```

#### AUTO 


```{c}
auto *attribute = mItem.attribute<NoteShared::NoteDisplayAttribute>(Akonadi::Item::AddIfMissing);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : items) {
        createNote(item);
    }
```

#### AUTO 


```{c}
auto obj = new KNotePrintObject(note);
```

#### AUTO 


```{c}
auto action = new QAction(replaceText.replace(QLatin1String("&"), QStringLiteral("&&")), this);
```

#### AUTO 


```{c}
const auto item = mModelProxy->data(child, Akonadi::EntityTreeModel::ItemRole).value<Akonadi::Item>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &note : std::as_const(mNotes)) {
        createItem(note);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KComboBox *combo : comboboxs) {
            QFont font = combo->font();
            font.setPointSize(7);
            combo->setFont(font);
            combo->setFixedHeight(14);
        }
```

#### AUTO 


```{c}
auto *tab = new QTabWidget(this);
```

#### AUTO 


```{c}
auto helpMenu = new KHelpMenu(this, aboutData, true);
```

#### RANGE FOR STATEMENT 


```{c}
for (KNotePrintObject *n : lst) {
        notes << QVariant::fromValue(n);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : qAsConst(mListItem)) {
        const auto *attrAlarm = item.attribute<NoteShared::NoteAlarmAttribute>();
        if (attrAlarm) {
            if (attrAlarm->dateTime() < QDateTime::currentDateTime()) {
                lst.append(item);
            }
        }
    }
```

#### AUTO 


```{c}
auto job = new Akonadi::AgentInstanceCreateJob(notesType);
```

#### AUTO 


```{c}
auto noteItem = static_cast<KNotesIconViewItem *>(item);
```

#### AUTO 


```{c}
auto buttonBox = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (QListWidgetItem *item : lst) {
        Akonadi::Item::Id akonadiId = item->data(AkonadiId).toLongLong();
        if (akonadiId != -1) {
            KNotePrintObject *obj = new KNotePrintObject(mNotes.value(akonadiId)->item());
            lstPrintObj.append(obj);
        }
    }
```

#### AUTO 


```{c}
auto label_TitleFont = new QLabel(i18n("Title font:"), this);
```

#### AUTO 


```{c}
auto document = new QTextDocument(this);
```

#### AUTO 


```{c}
const auto noteMessage = item.payload<KMime::Message::Ptr>();
```

#### AUTO 


```{c}
auto searchLine = new QLineEdit(this);
```

#### AUTO 


```{c}
auto kcfg_SystemTrayShowNotes = new QCheckBox(i18n("Show number of notes in tray icon"), this);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        editNote();
    }
```

#### AUTO 


```{c}
auto buttonBox = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel | QDialogButtonBox::RestoreDefaults, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (KNotePrintObject *n : lst) {
        notes << QVariant::fromValue(static_cast<QObject *>(n));
    }
```

#### AUTO 


```{c}
auto atHBoxLayout = new QHBoxLayout(at);
```

#### AUTO 


```{c}
auto fetchCollection = qobject_cast<Akonadi::CollectionFetchJob *>(job);
```

#### AUTO 


```{c}
const auto bg = qvariant_cast<QColor>(md->colorData());
```

#### AUTO 


```{c}
const auto lst = actionCollection->actions();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : items) {
        if (!item.hasPayload<KMime::Message::Ptr>()) {
            continue;
        }
        mNotesWidget->notesView()->addNote(item);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QListWidgetItem *item : lst) {
        KNotesIconViewItem *knivi = static_cast<KNotesIconViewItem *>(item);
        items.append(knivi);
    }
```

#### AUTO 


```{c}
auto buttonBox = new QDialogButtonBox(QDialogButtonBox::Close, this);
```

#### AUTO 


```{c}
const auto *attr = collection.attribute<NoteShared::ShowFolderNotesAttribute>();
```

#### AUTO 


```{c}
auto *modify = new Akonadi::ItemModifyJob(item);
```

#### AUTO 


```{c}
auto label_at = new QRadioButton(i18n("Alarm &at:"), at);
```

#### AUTO 


```{c}
auto *iconView = new KNotesIconViewItem(item, this);
```

#### AUTO 


```{c}
auto modify = new Akonadi::ItemModifyJob(item);
```

#### AUTO 


```{c}
const auto noteMessage = mItem.payload<KMime::Message::Ptr>();
```

#### AUTO 


```{c}
const auto iconView = dynamic_cast<const KNotesIconViewItem *>(item);
```

#### AUTO 


```{c}
auto modifyAlarm = new QAction(i18n("Modify Alarm..."), entriesContextMenu);
```

#### AUTO 


```{c}
const auto *iconView = dynamic_cast<const KNotesIconViewItem *>(item);
```

#### AUTO 


```{c}
auto *attribute = mItem.attribute<NoteShared::NoteAlarmAttribute>(Akonadi::Item::AddIfMissing);
```

#### AUTO 


```{c}
auto *gripLayout = new QHBoxLayout;
```

#### AUTO 


```{c}
auto mainLayout = new QHBoxLayout(this);
```

#### AUTO 


```{c}
auto item = mNoteTreeModel->data(child, Akonadi::EntityTreeModel::ItemRole).value<Akonadi::Item>();
```

#### AUTO 


```{c}
auto *kcfg_MailAction = new QLineEdit(this);
```

#### AUTO 


```{c}
auto itemFetchJob = static_cast<Akonadi::ItemFetchJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &directory : std::as_const(themesDirectories)) {
        QDirIterator dirIt(directory, QStringList(), QDir::AllDirs | QDir::NoDotAndDotDot);
        QStringList alreadyLoadedThemeName;
        while (dirIt.hasNext()) {
            dirIt.next();
            const QString themeInfoFile = dirIt.filePath() + QLatin1String("/theme.desktop");
            KConfig config(themeInfoFile);
            KConfigGroup group(&config, QStringLiteral("Desktop Entry"));
            QString name = group.readEntry("Name", QString());
            if (name.isEmpty()) {
                continue;
            }
            if (alreadyLoadedThemeName.contains(name)) {
                int i = 2;
                const QString originalName(name);
                while (alreadyLoadedThemeName.contains(name)) {
                    name = originalName + QStringLiteral(" (%1)").arg(i);
                    ++i;
                }
            }
            const QString printThemePath(dirIt.filePath() + QLatin1Char('/'));
            if (!printThemePath.isEmpty()) {
                alreadyLoadedThemeName << name;
                addItem(name, printThemePath);
            }
        }
    }
```

#### AUTO 


```{c}
auto *attr = item.attribute<NoteShared::NoteDisplayAttribute>();
```

#### AUTO 


```{c}
auto *layout = new QVBoxLayout(page);
```

#### AUTO 


```{c}
auto vbox = new QVBoxLayout;
```

#### AUTO 


```{c}
auto layout = new QGridLayout(this);
```

#### AUTO 


```{c}
auto buttonBox = new QDialogButtonBox(readOnly ? QDialogButtonBox::Close : QDialogButtonBox::Ok | QDialogButtonBox::Cancel, this);
```

#### AUTO 


```{c}
auto *attr = item.attribute<NoteShared::NoteDisplayAttribute>(Akonadi::Item::AddIfMissing);
```

#### AUTO 


```{c}
auto *layout = new QGridLayout(this);
```

#### AUTO 


```{c}
auto label_PrintAction = new QLabel(i18n("Theme:"), this);
```

#### AUTO 


```{c}
auto socket = new QSslSocket;
```

#### AUTO 


```{c}
auto *attr
            = mItem.attribute<NoteShared::NoteDisplayAttribute>(Akonadi::Item::AddIfMissing);
```

#### AUTO 


```{c}
auto srv = idx.data(KDNSSD::ServiceModel::ServicePtrRole).value<KDNSSD::RemoteService::Ptr>();
```

#### AUTO 


```{c}
auto act = new QAction(QIcon::fromTheme(QStringLiteral("configure")), i18n("Preferences KNotes..."), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &metaData : availablePlugins) {
        addModule(metaData);
    }
```

#### AUTO 


```{c}
auto collectionWidget = new QWidget;
```

#### AUTO 


```{c}
auto *tabWidget = new QTabWidget;
```

#### AUTO 


```{c}
auto recv = new NoteShared::NotesNetworkReceiver(s);
```

#### AUTO 


```{c}
auto layout = new QVBoxLayout;
```

#### AUTO 


```{c}
auto showNote = new QAction(i18n("Show Note..."), entriesContextMenu);
```

#### AUTO 


```{c}
auto *e = (QMouseEvent *)ev;
```

#### AUTO 


```{c}
const auto *attr = mItem.attribute<NoteShared::NoteAlarmAttribute>();
```

#### AUTO 


```{c}
auto he = static_cast<QHelpEvent *>(e);
```

#### AUTO 


```{c}
auto message = item.payload<KMime::Message::Ptr>();
```

#### AUTO 


```{c}
auto dialog = new KNoteConfigDialog(i18n("Settings"), widget());
```

#### AUTO 


```{c}
const auto comboboxs = m_tool->findChildren<KComboBox *>();
```

#### AUTO 


```{c}
auto *atHBoxLayout = new QHBoxLayout(at);
```

#### AUTO 


```{c}
auto label = static_cast<KUrlLabel *>(obj);
```

#### AUTO 


```{c}
auto deleteJob = new Akonadi::ItemDeleteJob(Akonadi::Item(id), this);
```

#### AUTO 


```{c}
auto eda = new Akonadi::EntityDisplayAttribute();
```

#### AUTO 


```{c}
auto attribute = mItem.attribute<NoteShared::NoteDisplayAttribute>(Akonadi::Item::AddIfMissing);
```

#### AUTO 


```{c}
auto hbox = new QHBoxLayout;
```

#### AUTO 


```{c}
auto accountWidget = new QWidget;
```

#### AUTO 


```{c}
auto *attr = item.attribute<NoteShared::NoteAlarmAttribute>();
```

#### AUTO 


```{c}
auto *item = new QListWidgetItem(this);
```

#### AUTO 


```{c}
auto manageAccountWidget = new Akonadi::ManageAccountWidget(this);
```

#### AUTO 


```{c}
auto *layout = new QVBoxLayout(this);
```

#### AUTO 


```{c}
auto attribute = mItem.attribute<NoteShared::NoteAlarmAttribute>(Akonadi::Item::AddIfMissing);
```

#### AUTO 


```{c}
auto *dlg = new NotesAgentNoteDialog;
```

#### AUTO 


```{c}
auto tab = new QTabWidget(this);
```

#### AUTO 


```{c}
auto w = new QWidget;
```

#### AUTO 


```{c}
auto *createJob = qobject_cast<Akonadi::AgentInstanceCreateJob *>(job);
```

#### AUTO 


```{c}
auto lab = new QLabel(i18n("Themes:"));
```

#### AUTO 


```{c}
auto lay = new QVBoxLayout(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (QListWidgetItem *item : lst) {
        auto knivi = static_cast<KNotesIconViewItem *>(item);
        items.append(knivi);
    }
```

#### AUTO 


```{c}
auto newStuffDialog = new KNS3::QtQuickDialogWrapper(QStringLiteral("kwinswitcher.knsrc"));
```

#### AUTO 


```{c}
auto label = new QLabel(i18n("No notes found"), this);
```

#### AUTO 


```{c}
auto syncJob = new Akonadi::ResourceSynchronizationJob(instance, this);
```

#### AUTO 


```{c}
auto attribute = item.attribute<NoteShared::NoteAlarmAttribute>(Akonadi::Item::AddIfMissing);
```

#### AUTO 


```{c}
auto label_Port = new QLabel(i18n("&Port:"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &note : notes) {
        if (mNotes.contains(note)) {
            continue;
        }
        createItem(note);
        mNotes.append(note);
    }
```

#### AUTO 


```{c}
auto *lay = new QVBoxLayout(w);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {newNote(); }
```

#### AUTO 


```{c}
auto *attr = collection.attribute<NoteShared::ShowFolderNotesAttribute>();
```

#### AUTO 


```{c}
auto *job = new Akonadi::ItemModifyJob(mItem);
```

#### AUTO 


```{c}
auto *hbox = new QHBoxLayout;
```

#### AUTO 


```{c}
auto note = new KNote(m_noteGUI, item, mDebugAkonadiSearch);
```

#### AUTO 


```{c}
auto *job = new Akonadi::AgentInstanceCreateJob(notesType);
```

#### AUTO 


```{c}
auto job = new Akonadi::CollectionFetchJob(Akonadi::Collection::root(), Akonadi::CollectionFetchJob::Recursive, mSession);
```

#### AUTO 


```{c}
const auto &contact
```

#### AUTO 


```{c}
auto *knotesItem = static_cast<KNotesIconViewItem *>(item);
```

#### AUTO 


```{c}
auto group = new QGroupBox(i18n("Scheduled Alarm"), page);
```

#### AUTO 


```{c}
auto *attribute
        = item.attribute<NoteShared::NoteDisplayAttribute>(Akonadi::Item::AddIfMissing);
```

#### AUTO 


```{c}
const auto *attr = item.attribute<NoteDisplayAttribute>();
```

#### AUTO 


```{c}
auto user1Button = new QPushButton;
```

#### AUTO 


```{c}
auto session = new Akonadi::Session("KNotes Session", this);
```

#### RANGE FOR STATEMENT 


```{c}
for (KNotesIconViewItem *item : items) {
        auto *i = new QListWidgetItem(this);
        if (item->readOnly()) {
            i->setText(item->realName() + QLatin1Char(' ') + i18n("(note locked, it will not removed)"));
            i->setForeground(Qt::red);
        } else {
            i->setText(item->realName());
        }
    }
```

#### AUTO 


```{c}
auto *modifyJob = qobject_cast<Akonadi::CollectionModifyJob *>(job);
```

#### AUTO 


```{c}
auto kcfg_MailAction = new QLineEdit(this);
```

#### AUTO 


```{c}
auto job = new Akonadi::ItemDeleteJob(note->item());
```

#### AUTO 


```{c}
auto mainLayout = new QVBoxLayout(this);
```

#### AUTO 


```{c}
auto group = new QActionGroup(this);
```

#### LAMBDA EXPRESSION 


```{c}
[newStuffDialog, this]() {
        if (!newStuffDialog->changedEntries().isEmpty()) {
            mSelectTheme->loadThemes();
        }
        newStuffDialog->deleteLater();
    }
```

#### AUTO 


```{c}
auto contextMenu = new QMenu(widget());
```

#### AUTO 


```{c}
auto e = (QMouseEvent *)ev;
```

#### AUTO 


```{c}
auto attr = mItem.attribute<NoteShared::NoteDisplayAttribute>(Akonadi::Item::AddIfMissing);
```

#### AUTO 


```{c}
auto *mimeTypeProxy = new Akonadi::CollectionFilterProxyModel(this);
```

#### AUTO 


```{c}
const auto attr = item.attribute<NoteShared::NoteDisplayAttribute>();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { newNote(); }
```

#### AUTO 


```{c}
const auto attr = item.attribute<NoteDisplayAttribute>();
```

#### AUTO 


```{c}
auto outgoing = new QGroupBox(i18n("Outgoing Notes"));
```

#### AUTO 


```{c}
auto label_Font = new QLabel(i18n("Text font:"), this);
```

#### AUTO 


```{c}
auto *layout = new QGridLayout(w);
```

#### AUTO 


```{c}
auto iconView = new KNotesIconViewItem(item, this);
```

#### AUTO 


```{c}
const auto collection = data(index, Akonadi::EntityTreeModel::CollectionRole).value<Akonadi::Collection>();
```

#### AUTO 


```{c}
auto job = new Akonadi::ItemFetchJob(col, mSession);
```

#### AUTO 


```{c}
auto *fetchCollection = new Akonadi::CollectionFetchJob(col, Akonadi::CollectionFetchJob::Base);
```

#### AUTO 


```{c}
auto *knoteItem = static_cast<KNotesIconViewItem *>(item);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        newNote();
    }
```

#### AUTO 


```{c}
auto *attr
        = item.attribute<NoteShared::NoteDisplayAttribute>(Akonadi::Item::AddIfMissing);
```

#### AUTO 


```{c}
auto col = idx.data(Akonadi::EntityTreeModel::CollectionRole).value<Akonadi::Collection>();
```

#### AUTO 


```{c}
auto at = new QWidget;
```

#### AUTO 


```{c}
auto deleteJob = new Akonadi::ItemDeleteJob(lst, this);
```

#### AUTO 


```{c}
auto *recv = new NoteShared::NotesNetworkReceiver(s);
```

#### AUTO 


```{c}
auto action = new QAction(QIcon::fromTheme(QStringLiteral("document-new")), i18n("New"), this);
```

#### AUTO 


```{c}
auto pageVBoxLayout = new QVBoxLayout(page);
```

#### AUTO 


```{c}
auto action = new QAction(QIcon::fromTheme(QStringLiteral("document-new")), i18n("New Note"), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &note : notes) {
        if (d->mNotes.contains(note)) {
            continue;
        }
        createItem(note);
        d->mNotes.append(note);
    }
```

#### AUTO 


```{c}
auto *attr = new NoteDisplayAttribute();
```

#### AUTO 


```{c}
auto entriesContextMenu = new QMenu(this);
```

#### AUTO 


```{c}
auto label_MailAction = new QLabel(i18n("&Mail action:"), this);
```

#### AUTO 


```{c}
auto *deleteJob = new Akonadi::ItemDeleteJob(lst, this);
```

#### AUTO 


```{c}
auto *job = new Akonadi::ItemFetchJob(item, this);
```

#### AUTO 


```{c}
auto *fetchJob = qobject_cast<Akonadi::ItemFetchJob *>(job);
```

#### AUTO 


```{c}
auto label_Height = new QLabel(i18n("Default &height:"), this);
```

#### AUTO 


```{c}
auto *mainLayout = new QVBoxLayout(this);
```

#### AUTO 


```{c}
auto w = new QWidget(this);
```

#### AUTO 


```{c}
auto *label = static_cast<KUrlLabel *>(obj);
```

#### AUTO 


```{c}
auto label_BgColor = new QLabel(i18n("&Background color:"), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (KNotesIconViewItem *item : items) {
        QListWidgetItem *i = new QListWidgetItem(this);
        if (item->readOnly()) {
            i->setText(item->realName() + QLatin1Char(' ') + i18n("(note locked, it will not removed)"));
            i->setForeground(Qt::red);
        } else {
            i->setText(item->realName());
        }
    }
```

#### AUTO 


```{c}
auto lab = new QLabel(i18n("Printing theme:"));
```

#### RANGE FOR STATEMENT 


```{c}
for (QListWidgetItem *item : lst) {
            listPrintObj.append(new KNotePrintObject(static_cast<KNotesIconViewItem *>(item)->item()));
        }
```

#### AUTO 


```{c}
auto *job = new Akonadi::ItemFetchJob(col);
```

#### AUTO 


```{c}
auto *job = new Akonadi::ItemModifyJob(item);
```

#### AUTO 


```{c}
auto job = new Akonadi::ItemDeleteJob(lstItem);
```

#### RANGE FOR STATEMENT 


```{c}
for (QListWidgetItem *item : lst) {
        Akonadi::Item::Id akonadiId = item->data(AkonadiId).toLongLong();
        if (akonadiId != -1) {
            auto obj = new KNotePrintObject(mNotes.value(akonadiId)->item());
            lstPrintObj.append(obj);
        }
    }
```

#### AUTO 


```{c}
auto *creator = new NoteShared::LocalResourceCreator(this);
```

#### AUTO 


```{c}
auto lay = new QVBoxLayout(w);
```

#### AUTO 


```{c}
auto *job = new NoteShared::CreateNewNoteJob(this, nullptr);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::AgentInstance &instance : instances) {
        if (instance.type().identifier() == akonadiNotesInstanceName()) {
            found = true;
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : lst) {
                    QAction *toChange = i.value()->actionCollection()->action(action->objectName());
                    if (toChange) {
                        toChange->setShortcuts(action->shortcuts());
                    }
                }
```

#### AUTO 


```{c}
auto *separator = new QAction(m_toDesktop);
```

#### AUTO 


```{c}
auto message = mItem.payload<KMime::Message::Ptr>();
```

#### AUTO 


```{c}
const auto c
```

#### AUTO 


```{c}
auto howItWorks = new QLabel(i18n("<a href=\"whatsthis\">How does this work?</a>"));
```

#### AUTO 


```{c}
auto label = new QLabel(i18n("Select recipient:"), this);
```

#### AUTO 


```{c}
auto *itemFetchJob = static_cast<Akonadi::ItemFetchJob *>(job);
```

#### AUTO 


```{c}
auto job = new Akonadi::ItemCreateJob(newItem, col, this);
```

#### AUTO 


```{c}
auto sender = new NoteShared::NotesNetworkSender(socket);
```

#### AUTO 


```{c}
auto attr = item.attribute<NoteShared::NoteDisplayAttribute>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Collection &col : collections) {
        if (!col.contentMimeTypes().contains(Akonadi::NoteUtils::noteMimeType())) {
            continue;
        }
        auto job = new Akonadi::ItemFetchJob(col, mSession);
        job->setDeliveryOption(Akonadi::ItemFetchJob::EmitItemsInBatches);
        job->fetchScope().fetchAttribute<NoteShared::NoteAlarmAttribute>();
        job->fetchScope().fetchAttribute<NoteShared::NoteLockAttribute>();
        job->fetchScope().fetchAttribute<NoteShared::NoteDisplayAttribute>();
        job->fetchScope().fetchAttribute<NoteShared::NoteAlarmAttribute>();
        job->fetchScope().fetchFullPayload(true);
        connect(job, &Akonadi::ItemFetchJob::itemsReceived,
                this, [this](const Akonadi::Item::List &items) {
            for (const Akonadi::Item &item : items) {
                slotItemAdded(item);
            }
        });
    }
```

#### AUTO 


```{c}
auto *pageVBoxLayout = new QVBoxLayout(page);
```

#### AUTO 


```{c}
auto attr = item.attribute<NoteShared::NoteAlarmAttribute>();
```

#### AUTO 


```{c}
auto dialog = new KNoteConfigDialog(i18n("Settings"), this);
```

#### AUTO 


```{c}
auto vboxAccountWidget = new QVBoxLayout;
```

#### AUTO 


```{c}
auto label = new QLabel(page);
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
            newNote();
        }
```

#### AUTO 


```{c}
auto *knivi = static_cast<KNotesIconViewItem *>(item);
```

#### AUTO 


```{c}
auto *i = new QListWidgetItem(this);
```

#### AUTO 


```{c}
auto gripLayout = new QHBoxLayout;
```

#### AUTO 


```{c}
auto *attr = mItem.attribute<NoteShared::NoteDisplayAttribute>(Akonadi::Item::AddIfMissing);
```

#### AUTO 


```{c}
auto *knoteItem = static_cast<KNotesIconViewItem *>(mNotesWidget->notesView()->currentItem());
```

#### AUTO 


```{c}
auto knotesItem = static_cast<KNotesIconViewItem *>(item);
```

#### AUTO 


```{c}
auto *hbl = new QHBoxLayout();
```

#### AUTO 


```{c}
auto *fe = static_cast<QFocusEvent *>(ev);
```

#### AUTO 


```{c}
auto knoteItem = static_cast<KNotesIconViewItem *>(mNotesWidget->notesView()->currentItem());
```

#### AUTO 


```{c}
auto mimeTypeProxy = new Akonadi::CollectionFilterProxyModel(this);
```

#### AUTO 


```{c}
auto *user1Button = new QPushButton;
```

#### AUTO 


```{c}
auto attr = new NoteDisplayAttribute();
```

#### AUTO 


```{c}
auto attribute = item.attribute<NoteShared::NoteDisplayAttribute>(Akonadi::Item::AddIfMissing);
```

#### AUTO 


```{c}
auto incoming = new QGroupBox(i18n("Incoming Notes"));
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Akonadi::Item::List &items) {
                    for (const Akonadi::Item &item : items) {
                        slotItemAdded(item);
                    }
                }
```

#### AUTO 


```{c}
auto parentCollection = mNoteTreeModel->data(child, Akonadi::EntityTreeModel::ParentCollectionRole).value<Akonadi::Collection>();
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Akonadi::Item::List &items) {
            for (const Akonadi::Item &item : items) {
                slotItemAdded(item);
            }
        }
```

#### AUTO 


```{c}
auto tmpLayout = new QHBoxLayout;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &cmd : cmd_list) {
        if (cmd == QLatin1String("%f")) {
            mail << message;
        } else if (cmd == QLatin1String("%t")) {
            mail << i18n("Note: \"%1\"", title);
        } else {
            mail << cmd;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QListWidgetItem *item : lst) {
        auto *knivi = static_cast<KNotesIconViewItem *>(item);
        items.append(knivi);
    }
```

#### AUTO 


```{c}
auto job = new Akonadi::ItemFetchJob(col);
```

#### AUTO 


```{c}
auto job = new Akonadi::ItemModifyJob(mItem);
```

#### AUTO 


```{c}
auto lab = new QLabel(i18nc("@label:textbox", "Search notes:"), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : std::as_const(mListItem)) {
        const auto attrAlarm = item.attribute<NoteShared::NoteAlarmAttribute>();
        if (attrAlarm) {
            if (attrAlarm->dateTime() < QDateTime::currentDateTime()) {
                lst.append(item);
            }
        }
    }
```

#### AUTO 


```{c}
const auto service = Akonadi::ServerManager::agentServiceName(Akonadi::ServerManager::Resource, instance.identifier());
```

#### AUTO 


```{c}
auto attr = new NoteAlarmAttribute();
```

#### AUTO 


```{c}
auto item = new QListWidgetItem(mListNotes);
```

#### AUTO 


```{c}
auto *attribute = item.attribute<NoteShared::NoteDisplayAttribute>(Akonadi::Item::AddIfMissing);
```

#### AUTO 


```{c}
auto *lay = new QHBoxLayout(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (KNotesIconViewItem *item : items) {
        auto i = new QListWidgetItem(this);
        if (item->readOnly()) {
            i->setText(item->realName() + QLatin1Char(' ') + i18n("(note locked, it will not removed)"));
            i->setForeground(Qt::red);
        } else {
            i->setText(item->realName());
        }
    }
```

#### AUTO 


```{c}
auto createJob = qobject_cast<Akonadi::AgentInstanceCreateJob *>(job);
```

#### AUTO 


```{c}
auto hbl = new QHBoxLayout();
```

#### AUTO 


```{c}
auto knivi = static_cast<KNotesIconViewItem *>(item);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Collection &col : collections) {
        if (!col.contentMimeTypes().contains(Akonadi::NoteUtils::noteMimeType())) {
            continue;
        }
        auto job = new Akonadi::ItemFetchJob(col, mSession);
        job->setDeliveryOption(Akonadi::ItemFetchJob::EmitItemsInBatches);
        job->fetchScope().fetchAttribute<NoteShared::NoteAlarmAttribute>();
        job->fetchScope().fetchAttribute<NoteShared::NoteLockAttribute>();
        job->fetchScope().fetchAttribute<NoteShared::NoteDisplayAttribute>();
        job->fetchScope().fetchAttribute<NoteShared::NoteAlarmAttribute>();
        job->fetchScope().fetchFullPayload(true);
        connect(job, &Akonadi::ItemFetchJob::itemsReceived,
                this, [this](const Akonadi::Item::List &items) {
                    for (const Akonadi::Item &item : items) {
                        slotItemAdded(item);
                    }
                });
    }
```

#### AUTO 


```{c}
auto modifyJob = new Akonadi::CollectionModifyJob(col);
```

#### AUTO 


```{c}
auto hrd = noteMessage->headerByType("X-Cursor-Position")
```

#### AUTO 


```{c}
auto deleteJob = new Akonadi::ItemDeleteJob(lstItem, this);
```

#### AUTO 


```{c}
const auto n = c.toCaseFolded();
```

#### AUTO 


```{c}
auto *attribute
                = mItem.attribute<NoteShared::NoteAlarmAttribute>(Akonadi::Item::AddIfMissing);
```

#### AUTO 


```{c}
auto *lay = new QHBoxLayout;
```

#### AUTO 


```{c}
auto noteMessage = item.payload<KMime::Message::Ptr>();
```

#### AUTO 


```{c}
auto createJob = new Akonadi::ItemCreateJob(newItem, col, this);
```

#### AUTO 


```{c}
auto noteMessage = note.payload<KMime::Message::Ptr>();
```

#### RANGE FOR STATEMENT 


```{c}
for (QListWidgetItem *item : lstItems) {
        const Akonadi::Item::Id akonadiId = item->data(AkonadiId).toLongLong();
        if (akonadiId != -1) {
            lst.append(Akonadi::Item(akonadiId));
        }
    }
```

#### AUTO 


```{c}
const auto *attrAlarm = item.attribute<NoteShared::NoteAlarmAttribute>();
```

#### AUTO 


```{c}
auto action = new QAction(QIcon::fromTheme(QStringLiteral("knotes_date")), i18n("Insert Date"), this);
```

#### AUTO 


```{c}
auto *headerLayout = new QBoxLayout(headerLayoutDirection);
```

#### LAMBDA EXPRESSION 


```{c}
[this, item]() {
            Q_EMIT noteSelected(mNoteList->itemId(item));
        }
```

#### AUTO 


```{c}
auto *sender = new NoteShared::NotesNetworkSender(socket);
```

#### AUTO 


```{c}
auto layout = new QVBoxLayout(page);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : qAsConst(mListItem)) {
        const auto attrAlarm = item.attribute<NoteShared::NoteAlarmAttribute>();
        if (attrAlarm) {
            if (attrAlarm->dateTime() < QDateTime::currentDateTime()) {
                lst.append(item);
            }
        }
    }
```

#### AUTO 


```{c}
auto label_TabSize = new QLabel(i18n("&Tab size:"), this);
```

#### AUTO 


```{c}
auto job = new Akonadi::CollectionFetchJob(Akonadi::Collection::root(),
                                               Akonadi::CollectionFetchJob::Recursive,
                                               mSession);
```

#### AUTO 


```{c}
const auto lstItems = selectedItems();
```

#### AUTO 


```{c}
auto label = new QLabel(i18n("Select which KNotes folders to show:"));
```

#### AUTO 


```{c}
auto *noteNetworkConfigWidget = new NoteNetworkConfigWidget(this);
```

#### AUTO 


```{c}
auto urlLabel = new KUrlLabel(QString::number(item.id()), subStr, this);
```

#### AUTO 


```{c}
auto dlg = new NotesAgentNoteDialog;
```

#### AUTO 


```{c}
auto lab = new QLabel(i18n("The following notes triggered alarms:"), this);
```

#### AUTO 


```{c}
auto *item = new QListWidgetItem(mListNotes);
```

#### AUTO 


```{c}
auto *vbox = new QVBoxLayout(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : items) {
                slotItemAdded(item);
            }
```

#### AUTO 


```{c}
auto lay = new QHBoxLayout;
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : items) {
                        slotItemAdded(item);
                    }
```

#### AUTO 


```{c}
auto *syncJob = new Akonadi::ResourceSynchronizationJob(instance, this);
```

#### AUTO 


```{c}
auto *entriesContextMenu = new QMenu(this);
```

#### AUTO 


```{c}
auto *tmpLayout = new QHBoxLayout;
```

#### AUTO 


```{c}
auto label_FgColor = new QLabel(i18n("&Text color:"), this);
```

#### AUTO 


```{c}
auto *contextMenu = new QMenu(widget());
```

#### AUTO 


```{c}
auto label_DefaultTitle = new QLabel(i18n("Default Title:"), this);
```

#### AUTO 


```{c}
auto creator = new NoteShared::LocalResourceCreator(this);
```

#### AUTO 


```{c}
auto job = new Akonadi::ItemFetchJob(item, this);
```

#### AUTO 


```{c}
auto *vboxAccountWidget = new QVBoxLayout;
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : qAsConst(mListItem)) {
        const NoteShared::NoteAlarmAttribute *attrAlarm = item.attribute<NoteShared::NoteAlarmAttribute>();
        if (attrAlarm) {
            if (attrAlarm->dateTime() < QDateTime::currentDateTime()) {
                lst.append(item);
            }
        }
    }
```

#### AUTO 


```{c}
const auto lst = actionCollection()->actions();
```

#### LAMBDA EXPRESSION 


```{c}
[this, urlLabel]() {
        slotPopupMenu(urlLabel->url()); }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *act : lst) {
        act->setShortcutContext(Qt::WidgetWithChildrenShortcut);
    }
```

#### AUTO 


```{c}
auto layout = new QGridLayout(w);
```

#### AUTO 


```{c}
auto *manageAccountWidget = new Akonadi::ManageAccountWidget(this);
```

#### AUTO 


```{c}
auto job = new NoteShared::CreateNewNoteJob(this, widget());
```

#### RANGE FOR STATEMENT 


```{c}
for (QListWidgetItem *item : mListNotes->selectedItems()) {
        Akonadi::Item::Id akonadiId = item->data(AkonadiId).toLongLong();
        if (akonadiId != -1) {
            lst.append(QString::number(akonadiId));
        }
    }
```

#### AUTO 


```{c}
auto job = new Akonadi::ItemDeleteJob(lst);
```

#### LAMBDA EXPRESSION 


```{c}
[this, urlLabel]() {
        slotSelectNote(urlLabel->url()); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &directory : qAsConst(themesDirectories)) {
        QDirIterator dirIt(directory, QStringList(), QDir::AllDirs | QDir::NoDotAndDotDot);
        QStringList alreadyLoadedThemeName;
        while (dirIt.hasNext()) {
            dirIt.next();
            const QString themeInfoFile = dirIt.filePath() + QLatin1String("/theme.desktop");
            KConfig config(themeInfoFile);
            KConfigGroup group(&config, QStringLiteral("Desktop Entry"));
            QString name = group.readEntry("Name", QString());
            if (name.isEmpty()) {
                continue;
            }
            if (alreadyLoadedThemeName.contains(name)) {
                int i = 2;
                const QString originalName(name);
                while (alreadyLoadedThemeName.contains(name)) {
                    name = originalName + QStringLiteral(" (%1)").arg(i);
                    ++i;
                }
            }
            const QString printThemePath(dirIt.filePath() + QLatin1Char('/'));
            if (!printThemePath.isEmpty()) {
                alreadyLoadedThemeName << name;
                addItem(name, printThemePath);
            }
        }
    }
```

#### AUTO 


```{c}
auto *fetchCollection = qobject_cast<Akonadi::CollectionFetchJob *>(job);
```

#### AUTO 


```{c}
auto job = new Akonadi::CollectionModifyJob(col);
```

#### AUTO 


```{c}
auto label_SenderID = new QLabel(i18n("&Sender ID:"));
```

#### AUTO 


```{c}
auto *obj = new KNotePrintObject(note);
```

#### AUTO 


```{c}
auto header = new KMime::Headers::Generic("X-Cursor-Position");
```

#### AUTO 


```{c}
auto *noteItem = static_cast<KNotesIconViewItem *>(item);
```

#### AUTO 


```{c}
auto page = new QWidget(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { editNote(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &note : qAsConst(d->mNotes)) {
        createItem(note);
    }
```

#### AUTO 


```{c}
auto *job = new Akonadi::ItemCreateJob(newItem, col, this);
```

#### AUTO 


```{c}
auto *mainLayout = new QHBoxLayout(this);
```

#### AUTO 


```{c}
auto fetchJob = qobject_cast<Akonadi::ItemFetchJob *>(job);
```

#### AUTO 


```{c}
auto modifyJob = qobject_cast<Akonadi::CollectionModifyJob *>(job);
```

#### AUTO 


```{c}
auto job = new NoteShared::CreateNewNoteJob(this, this);
```

#### AUTO 


```{c}
auto action = new QAction(i18n("No Notes"), this);
```

#### AUTO 


```{c}
auto config = KConfig(QStringLiteral("akonadi_indexing_agent"));
```

#### AUTO 


```{c}
auto job = new NoteShared::CreateNewNoteJob(this, nullptr);
```

#### AUTO 


```{c}
auto lay = new QHBoxLayout(this);
```

#### AUTO 


```{c}
auto *group = new QActionGroup(this);
```

#### AUTO 


```{c}
auto button = new QPushButton(i18n("&Select All"), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &metaData : availablePlugins) {
#if KCMUTILS_VERSION >= QT_VERSION_CHECK(5, 84, 0)
        addModule(metaData);
#else
        addModule(metaData.pluginId());
#endif
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto c : str) {
        // case folding
        const auto n = c.toCaseFolded();

        // if the character has a canonical decomposition use that and skip the
        // combining diacritic markers following it
        // see https://en.wikipedia.org/wiki/Unicode_equivalence
        // see https://en.wikipedia.org/wiki/Combining_character
        if (n.decompositionTag() == QChar::Canonical) {
            out.push_back(n.decomposition().at(0));
        }
        // handle compatibility compositions such as ligatures
        // see https://en.wikipedia.org/wiki/Unicode_compatibility_characters
        else if (n.decompositionTag() == QChar::Compat && n.isLetter() && n.script() == QChar::Script_Latin) {
            out.append(n.decomposition());
        } else {
            out.push_back(n);
        }
    }
```

#### AUTO 


```{c}
const auto *attr = item.attribute<NoteShared::NoteDisplayAttribute>();
```

#### AUTO 


```{c}
auto *job = new NoteShared::CreateNewNoteJob(this, this);
```

#### AUTO 


```{c}
auto i = new QListWidgetItem(this);
```

#### AUTO 


```{c}
auto job = new Akonadi::ItemModifyJob(item);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &note : std::as_const(d->mNotes)) {
        createItem(note);
    }
```

#### AUTO 


```{c}
auto attr = collection.attribute<NoteShared::ShowFolderNotesAttribute>();
```

#### RANGE FOR STATEMENT 


```{c}
for (KNotesIconViewItem *item : items) {
        QListWidgetItem *i = new QListWidgetItem(this);
        if (item->readOnly()) {
            i->setText(item->realName() + QLatin1Char(' ') + i18n("(note locked, it will not removed)"));
            i->setTextColor(Qt::red);
        } else {
            i->setText(item->realName());
        }
    }
```

#### AUTO 


```{c}
auto layout = new QVBoxLayout(this);
```

#### AUTO 


```{c}
auto none = new QRadioButton(i18n("&No alarm"));
```

#### AUTO 


```{c}
auto fe = static_cast<QFocusEvent *>(ev);
```

#### AUTO 


```{c}
auto fetchCollection = new Akonadi::CollectionFetchJob(col, Akonadi::CollectionFetchJob::Base);
```

#### AUTO 


```{c}
auto knoteItem = static_cast<KNotesIconViewItem *>(item);
```

#### AUTO 


```{c}
auto *vbox = new QVBoxLayout;
```

#### AUTO 


```{c}
auto label_Width = new QLabel(i18n("Default &width:"), this);
```

#### AUTO 


```{c}
auto buttonBox = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel | QDialogButtonBox::Help, this);
```

#### AUTO 


```{c}
auto *job = new NoteShared::CreateNewNoteJob(this, widget());
```

#### AUTO 


```{c}
auto mdl = new KDNSSD::ServiceModel(new KDNSSD::ServiceBrowser(QStringLiteral("_knotes._tcp"), true), this);
```

#### LAMBDA EXPRESSION 


```{c}
[this, urlLabel]() {
        slotPopupMenu(urlLabel->url());
    }
```

#### AUTO 


```{c}
auto *getNewTheme = new QToolButton;
```

#### AUTO 


```{c}
auto noteMessage = mItem.payload<KMime::Message::Ptr>();
```

#### AUTO 


```{c}
auto item = new QListWidgetItem(this);
```

#### AUTO 


```{c}
auto menu = new KHelpMenu(this, KAboutData::applicationData(), false);
```

#### AUTO 


```{c}
auto job = new Akonadi::CollectionModifyJob(col, this);
```

#### AUTO 


```{c}
auto *document = new QTextDocument(this);
```

#### AUTO 


```{c}
auto lab = new QLabel(i18np("Do you really want to delete this note?", "Do you really want to delete these %1 notes?", items.count()), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &directory : qAsConst(themesDirectories)) {
        QDirIterator dirIt(directory, QStringList(), QDir::AllDirs | QDir::NoDotAndDotDot);
        QStringList alreadyLoadedThemeName;
        while (dirIt.hasNext()) {
            dirIt.next();
            const QString themeInfoFile = dirIt.filePath() + QDir::separator() + QLatin1String("theme.desktop");
            KConfig config(themeInfoFile);
            KConfigGroup group(&config, QStringLiteral("Desktop Entry"));
            QString name = group.readEntry("Name", QString());
            if (name.isEmpty()) {
                continue;
            }
            if (alreadyLoadedThemeName.contains(name)) {
                int i = 2;
                const QString originalName(name);
                while (alreadyLoadedThemeName.contains(name)) {
                    name = originalName + QStringLiteral(" (%1)").arg(i);
                    ++i;
                }
            }
            const QString printThemePath(dirIt.filePath() + QDir::separator());
            if (!printThemePath.isEmpty()) {
                alreadyLoadedThemeName << name;
                addItem(name, printThemePath);
            }
        }
    }
```

#### AUTO 


```{c}
auto *he = static_cast< QHelpEvent * >(e);
```

#### AUTO 


```{c}
const auto attrAlarm = item.attribute<NoteShared::NoteAlarmAttribute>();
```

#### AUTO 


```{c}
const auto attr = collection.attribute<NoteShared::ShowFolderNotesAttribute>();
```

#### AUTO 


```{c}
auto about = new KAboutData(QStringLiteral("kcmknotessummary"),
                                i18n("kcmknotessummary"),
                                QString(),
                                i18n("Notes Summary Configuration Dialog"),
                                KAboutLicense::GPL,
                                i18n("Copyright � 2013-2021 Laurent Montel <montel@kde.org>"));
```

