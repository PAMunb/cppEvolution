#### AUTO 


```{c}
auto  proc = static_cast<QProcess*>(sender());
```

#### AUTO 


```{c}
auto item = static_cast<KTimerJobItem*>(i);
```

#### AUTO 


```{c}
auto tray = new KStatusNotifierItem(this);
```

#### AUTO 


```{c}
auto item = new KTimerJobItem( job, m_list );
```

#### AUTO 


```{c}
auto item = static_cast<KTimerJobItem*>(job->user());
```

#### AUTO 


```{c}
auto proc = new QProcess;
```

#### AUTO 


```{c}
auto item = static_cast<KTimerJobItem*>(m_list->currentItem());
```

#### AUTO 


```{c}
auto job = new KTimerJob;
```

#### AUTO 


```{c}
auto item = static_cast<KTimerJobItem*>(m_list->topLevelItem(num));
```

#### AUTO 


```{c}
auto timer = new KTimerPref;
```

