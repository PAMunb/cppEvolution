#### RANGE FOR STATEMENT 


```{c}
for (KGpgNode *nd : ndlist) {
		KGpgKeyNode *ki = nd->toKeyNode();

		if (ki->getType() & ITYPE_SECRET) {
			secList += ki->getNameComment();
		} else if (ki != terminalkey) {
			keysToDelete += ki->getNameComment();
			deleteIds << ki->getId();
			delkeys << ki;
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (KGpgNode *nd : ndlist) {
				int r = members.removeAll(nd);
				Q_ASSERT(r == 1);
				Q_UNUSED(r);
			}
```

#### LAMBDA EXPRESSION 


```{c}
[transaction](int result) {
		QCOMPARE(transaction->getImportedKeys().size(), 1);
		QString keyID = QLatin1String("BA7695F3C550DF14");
		QVERIFY(transaction->getImportedKeys().first().startsWith(keyID));
		QCOMPARE(result, static_cast<int>(KGpgTransaction::TS_OK));
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (KGpgNode *child: qAsConst(children))
		child->setParent(nullptr);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KGpgSignableNode *nd : qAsConst(m_alreadyIds))
				if (nd->getEmail().isEmpty())
					ids << i18nc("%1 is the key id, %2 is the name and comment of the key or uid",
							"%1: %2", nd->getId(), nd->getNameComment());
				else
					ids << i18nc("%1 is the key id, %2 is the name and comment of the key or uid, %3 is the email address of the uid",
							"%1: %2 &lt;%3&gt;", nd->getId(), nd->getNameComment(), nd->getEmail());
```

#### AUTO 


```{c}
const auto ndlist = iview->selectedNodes(&same, &tp);
```

#### RANGE FOR STATEMENT 


```{c}
for (KGpgNode *nd : ndlist) {
			allunksig = nd->toSignNode()->isUnknown();
			if (!allunksig)
				break;
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (KGpgRefNode *rn : refs)
		ret.append(rn->toSignNode());
```

#### LAMBDA EXPRESSION 


```{c}
[&] (const QString & text) {
		if (text.isEmpty())
			m_listpop->kLVsearch->selectionModel()->clearSelection();
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (KGpgNode *nd : ndlist) {
		if (!nd->hasChildren())
			continue;

		KGpgExpandableNode *exnd = nd->toExpandableNode();
		if (!exnd->wasExpanded()) {
			unksig = true;
			break;
		}
		getMissingSigs(l, exnd);
		if (!l.isEmpty()) {
			unksig = true;
			break;
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (KGpgRefNode *rn : refs)
		ret.append(rn->toGroupMemberNode());
```

#### RANGE FOR STATEMENT 


```{c}
for (KGpgSignNode *snode : qAsConst(m_signids)) {
			if (sigid == snode->getId().right(snlen)) {
				signode = snode;
				break;
			}
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &group : groups) {
		const QStringList parts = group.split(QLatin1Char(':'));
		if (parts.count() < 2)
			continue;
		const QString groupName = parts.first();
		new KGpgGroupNode(this, groupName, parts.at(1).split(QLatin1Char(';'), Qt::SkipEmptyParts));
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (KGpgKeyNode *nd : members)
		new KGpgGroupMemberNode(this, nd);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &line : log) {
		if (!line.startsWith(QLatin1String("[GNUPG:] ")))
			continue;

		const QString msg = line.mid(9);

		if (!useGoodSig && msg.startsWith(QLatin1String("VALIDSIG "))) {
			// from GnuPG source, doc/DETAILS:
			//   VALIDSIG    <fingerprint in hex> <sig_creation_date> <sig-timestamp>
			//                <expire-timestamp> <sig-version> <reserved> <pubkey-algo>
			//                <hash-algo> <sig-class> <primary-key-fpr>
			const QStringList vsig = msg.mid(9).split(QLatin1Char(' '), Qt::SkipEmptyParts);
			Q_ASSERT(vsig.count() >= 10);

			const KGpgKeyNode *node = model->findKeyNode(vsig[9]);

			if (node != nullptr) {
				// ignore for now if this is signed with the primary id (vsig[0] == vsig[9]) or not
				if (node->getEmail().isEmpty())
					result += xi18nc("@info Good signature from: NAME , Key ID: HEXID",
							"<para>Good signature from:<nl/><emphasis strong='true'>%1</emphasis><nl/>Key ID: %2<nl/></para>",
							node->getName(), vsig[9]);
				else
					result += xi18nc("@info Good signature from: NAME <EMAIL>, Key ID: HEXID",
							"<para>Good signature from:<nl/><emphasis strong='true'>%1 <email>%2</email></emphasis><nl/>Key ID: %3</para>",
							node->getName(), node->getEmail(), vsig[9]);

				result += sigTimeMessage(vsig[2]);
			} else {
				// this should normally never happen, but one could delete
				// the key just after the verification. Brute force solution:
				// do the whole report generation again, but this time make
				// sure GOODSIG is used.
				return getReport(log, nullptr);
			}
		} else if (msg.startsWith(QLatin1String("UNEXPECTED")) ||
				msg.startsWith(QLatin1String("NODATA"))) {
			result += xi18nc("@info", "No signature found.") + QLatin1Char('\n');
		} else if (useGoodSig && msg.startsWith(QLatin1String("GOODSIG "))) {
            int sigpos = msg.indexOf( QLatin1Char(' ') , 8);
			const QString keyid = msg.mid(8, sigpos - 8);

			// split the name/email pair to give translators more power to handle this
			QString email;
			QString name = msg.mid(sigpos + 1);

			int oPos = name.indexOf(QLatin1Char('<'));
			int cPos = name.indexOf(QLatin1Char('>'));
			if ((oPos >= 0) && (cPos >= 0)) {
				email = name.mid(oPos + 1, cPos - oPos - 1);
				name = name.left(oPos).simplified();
			}

			if (email.isEmpty())
				result += xi18nc("@info", "<para>Good signature from:<nl/><emphasis strong='true'>%1</emphasis><nl/>Key ID: %2<nl/></para>",
						name, keyid);
			else
				result += xi18nc("@info Good signature from: NAME <EMAIL>, Key ID: HEXID",
						"<para>Good signature from:<nl/><emphasis strong='true'>%1 <email>%2</email></emphasis><nl/>Key ID: %3<nl/></para>",
						name, email, keyid);
			if (!sigtime.isEmpty()) {
				result += sigTimeMessage(sigtime);
				sigtime.clear();
			}
		} else if (msg.startsWith(QLatin1String("SIG_ID "))) {
			const QStringList parts = msg.simplified().split(QLatin1Char(' '));
			if (parts.count() > 2)
				sigtime = parts[2];
		} else if (msg.startsWith(QLatin1String("BADSIG"))) {
            int sigpos = msg.indexOf( QLatin1Char(' '), 7);
			result += xi18nc("@info", "<para><emphasis strong='true'>BAD signature</emphasis> from:<nl/> %1<nl/>Key ID: %2<nl/><nl/><emphasis strong='true'>The file is corrupted</emphasis></para>",
					msg.mid(sigpos + 1), msg.mid(7, sigpos - 7));
		} else  if (msg.startsWith(QLatin1String("TRUST_UNDEFINED"))) {
			result += xi18nc("@info", "<para>The signature is valid, but the key is untrusted</para>");
		} else if (msg.startsWith(QLatin1String("TRUST_ULTIMATE"))) {
			result += xi18nc("@info", "<para>The signature is valid, and the key is ultimately trusted</para>");
		}
	}
```

#### AUTO 


```{c}
const auto indexList = persistentIndexList();
```

#### RANGE FOR STATEMENT 


```{c}
for (KGpgGroupMemberNode *gref : grefs) {
		KGpgGroupNode *group = gref->getParentKeyNode();

		bool deleteWholeGroup = (group->getChildCount() == 1) &&
				(group->getChild(0)->toGroupMemberNode() == gref);
		if (deleteWholeGroup)
			deleteWholeGroup = (KMessageBox::questionYesNo(this,
					i18n("You are removing the last key from key group %1.<br/>Do you want to delete the group, too?", group->getName()),
					i18n("Delete key")) == KMessageBox::Yes);

		if (!deleteWholeGroup) {
			imodel->deleteFromGroup(group, gref);
		} else {
			group->remove();
			imodel->delNode(group);
			groupDeleted = true;
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : qAsConst(m_decryptionFailed))
				failedFiles.append(url.toDisplayString());
```

#### RANGE FOR STATEMENT 


```{c}
for (const KGpgNode *nd : ndlist)
			if (nd->getType() == ITYPE_GROUP) {
				invalidDelete = true;
				break;
			}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &changed : keyIds) {
			const KGpgKeyNode *node = model->findKeyNode(changed);
			QString line;

			if (node == Q_NULLPTR) {
				line = changed;
			} else {
				if (node->getEmail().isEmpty())
					line = xi18nc("@item ID: Name", "%1: %2", node->getFingerprint(), node->getName());
				else
					line = xi18nc("@item ID: Name <Email>", "%1: %2 <email>%3</email>", node->getFingerprint(), node->getName(), node->getEmail());
			}

			result.append(QLatin1String(" ") + line + QLatin1String("\n"));
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &str : getMessages())
		if (str.startsWith(QLatin1String("[GNUPG:] IMPORTED ")))
			res << str.mid(18);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &s : algorithms) {
		QString t = s.trimmed();
		if (t == QLatin1String("?"))
			continue;
		ret << t;
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const KGpgNode *nd : node->getChildren()) {
			found = (nd->getId() == keys.at(i)->getId());
			if (found)
				break;
		}
```

#### LAMBDA EXPRESSION 


```{c}
[transaction, key](int result) {
		QCOMPARE(transaction->getImportedKeys().size(), 1);
		QString keyID = QLatin1String("BA7695F3C550DF14");
		QVERIFY(transaction->getImportedKeys().first().startsWith(keyID));
		QCOMPARE(result, static_cast<int>(KGpgTransaction::TS_OK));
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (int *ref : qAsConst(d->m_argRefs)) {
		if (*ref >= pos)
			*ref += move;
	}
```

#### AUTO 


```{c}
const auto tmplist = iview->selectedNodes(nullptr, &tp);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &keyresult : log) {
		if (!keyresult.startsWith(QLatin1String("[GNUPG:] IMPORT_OK ")))
			continue;

		QStringList rc(keyresult.mid(19).split(QLatin1Char( ' ' )));
		if (rc.count() < 2) {
			kDebug(2100) << "unexpected syntax:" << keyresult;
			continue;
		}

		resultcodes[rc.at(1)] = rc.at(0).toUInt();
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (KgpgCore::KgpgKey key : publiclist) {
		int index = issec.indexOf(key.fullId());

		if (index >= 0) {
			key.setSecret(true);
			issec.removeAt(index);
			secretlist.removeAt(index);
		}

		KGpgKeyNode *nd = new KGpgKeyNode(this, key);
		Q_EMIT newKeyNode(nd);
	}
```

#### LAMBDA EXPRESSION 


```{c}
[transaction](int result) {
		QCOMPARE(transaction->getImportedKeys().size(), 1);
		QString keyID = QLatin1String("BA7695F3C550DF14");
		QVERIFY(transaction->getImportedKeys().first().startsWith(keyID));
		QCOMPARE(result, KGpgTransaction::TS_OK);
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &id : members)
		if (id.startsWith(QLatin1String("0x")))
			new KGpgGroupMemberNode(this, id.mid(2));
		else
			new KGpgGroupMemberNode(this, id);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &str : log) {
		line++;
		if (!str.startsWith(QLatin1String("[GNUPG:] IMPORT_RES ")))
			continue;

		const QStringList rstr = str.mid(20).simplified().split(QLatin1Char(' '));

		bool syn = (rstr.count() >= RESULT_PARTS_MIN);

		for (int i = std::min<int>(rstr.count(), RESULT_PARTS_MAX) - 1; (i >= 0) && syn; i--) {
			rcode[i] += rstr.at(i).toULong(&syn);
			fine |= (rcode[i] != 0);
		}

		if (!syn)
			return xi18nc("@info", "The import result string has an unsupported format in line %1.<nl/>Please see the detailed log for more information.", line);
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &line : getMessages())
		if (!line.startsWith(QLatin1String("[GNUPG:] "))) {
			result.append(line);
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (KGpgNode *child: children)
		child->setParent(Q_NULLPTR);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &arg : positionalArguments)
			urlList.append(QUrl::fromLocalFile(arg));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &group : groups) {
		const QStringList parts = group.split(QLatin1Char(':'));
		if (parts.count() < 2)
			continue;
		const QString groupName = parts.first();
		new KGpgGroupNode(this, groupName, parts.at(1).split(QLatin1Char(';')));
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &idx : indexList) {
		KGpgNode *n = nodeForIndex(idx);

		if (n != nd)
			continue;

		changePersistentIndex(idx, QModelIndex());
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const KGpgSignNode *snode : signids) {
		Q_ASSERT(signids.at(0)->getParentKeyNode() == snode->getParentKeyNode());
	}
```

#### LAMBDA EXPRESSION 


```{c}
[](int result) { QCOMPARE(result, static_cast<int>(KGpgVerify::TS_MISSING_KEY)); }
```

#### AUTO 


```{c}
const auto nodes = selectedNodes();
```

#### AUTO 


```{c}
const auto ndlist = iview->selectedNodes(&sametype, &itype);
```

#### LAMBDA EXPRESSION 


```{c}
[](const KGpgSignableNode *s, const KGpgSignableNode *t) { return *t < *s; }
```

#### AUTO 


```{c}
auto downloadJob = KIO::storedGet(url);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &idx : indexes) {
		if (idx.column() != 0)
			continue;
		KGpgNode *nd = iproxy->nodeForIndex(idx);
		if (nd->getType() == ITYPE_GROUP)
			selectedKeys << nd->getName();
		else
			selectedKeys << nd->getId();
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const KGpgNode *child : children) {
		switch (child->getType()) {
		case KgpgCore::ITYPE_UID:
		case KgpgCore::ITYPE_UAT:
			if (child->getId() == idxstr)
				return child->toSignableNode();
			break;
		default:
			continue;
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const KGpgNode *n : qAsConst(children))
		if (n->getType() == ITYPE_SIGN)
			m_signs++;
```

#### RANGE FOR STATEMENT 


```{c}
for (KGpgSignNode *sn : tmp) {
			bool found = false;
			const QString snid(sn->getId());

			for (const KGpgSignNode *retsn : qAsConst(ret)) {
				found = (retsn->getId() == snid);
				if (found)
					break;
			}

			if (!found)
				ret << sn;
		}
```

#### LAMBDA EXPRESSION 


```{c}
[transaction, key](int result) {
		QCOMPARE(transaction->getImportedKeys().size(), 1);
		QString keyID = QLatin1String("BA7695F3C550DF14");
		QVERIFY(transaction->getImportedKeys().first().startsWith(keyID));
		QCOMPARE(result, KGpgTransaction::TS_OK);
	}
```

#### AUTO 


```{c}
const auto k
```

#### RANGE FOR STATEMENT 


```{c}
for (KGpgSignNode *snode : qAsConst(m_signids)) {
			if (snode->getId().rightRef(snlen).compare(sigid) == 0) {
				signode = snode;
				break;
			}
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &arg : positionalArguments)
			urlList.append(QUrl::fromLocalFile(workingDirectory.absoluteFilePath(arg)));
```

#### LAMBDA EXPRESSION 


```{c}
[group] (const KGpgNode *nd) { return nd->getParentKeyNode() != group; }
```

#### AUTO 


```{c}
auto it = ++m_uids.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (KGpgSignNode *sn : tmp) {
			bool found = false;
			const QString snid(sn->getId());

			foreach (const KGpgSignNode *retsn, ret) {
				found = (retsn->getId() == snid);
				if (found)
					break;
			}

			if (!found)
				ret << sn;
		}
```

#### LAMBDA EXPRESSION 


```{c}
[](int result) {
		// QEXPECT_FAIL("", "Test is broken. Possible bug!", Continue);
		QCOMPARE(result, KGpgTransaction::TS_OK);
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : d->m_sources)
		arch->addLocalDirectory(url.path(), url.fileName());
```

#### RANGE FOR STATEMENT 


```{c}
for (QString rawmsg : messages)
			msglist << rawmsg.replace(QLatin1Char('<'), QLatin1String("&lt;"));
```

#### LAMBDA EXPRESSION 


```{c}
[transaction](int result) {
		QCOMPARE(transaction->getImportedIds(-1).size(), 1);
		QString fingerprint = QLatin1String("FBAF08DD7D9D0921C15DDA9FBA7695F3C550DF14");
		QVERIFY(transaction->getImportedIds(-1).first().compare(fingerprint) == 0);
		QCOMPARE(result, static_cast<int>(KGpgTransaction::TS_OK));
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const KGpgNode *nd : keys) {
			found = (node->getChild(i)->getId() == nd->getId());
			if (found)
				break;
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : indexes)
		ids << m_resultmodel.idForIndex(index);
```

#### LAMBDA EXPRESSION 


```{c}
[transaction](int result) {
		QCOMPARE(transaction->getImportedKeys().size(), 1);
		QString keyID = QLatin1String("BA7695F3C550DF14");
		QString duplicateMsg =
			QLatin1String("IMPORT_OK 0 FBAF08DD7D9D0921C15DDA9FBA7695F3C550DF14");
		qDebug() << "MESSAGES: " << transaction->getMessages();
		QVERIFY(transaction->getImportedKeys().first().startsWith(keyID));
		QVERIFY(transaction->getMessages()
				.join(QLatin1Char(' '))
				.contains(duplicateMsg));
		QEXPECT_FAIL("", "Test is broken. Possible bug!", Continue);
		QCOMPARE(result, KGpgTransaction::TS_OK);
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (KGpgNode *child: children)
		child->setParent(nullptr);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &line : getMessages())
		if (!line.startsWith(QLatin1String("[GNUPG:] ")))
			result.append(line);
```

#### AUTO 


```{c}
const auto grefs = node->getGroupRefs();
```

#### LAMBDA EXPRESSION 


```{c}
[](const KGpgNode *n) { return n->getType() == ITYPE_SIGN; }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto k : ndlist)
		klist << k->getId();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &changed : keyIds) {
			const KGpgKeyNode *node = model->findKeyNode(changed);
			QString line;

			if (node == nullptr) {
				line = changed;
			} else {
				if (node->getEmail().isEmpty())
					line = xi18nc("@item ID: Name", "%1: %2", node->getFingerprint(), node->getName());
				else
					line = xi18nc("@item ID: Name <Email>", "%1: %2 <email>%3</email>", node->getFingerprint(), node->getName(), node->getEmail());
			}

			result.append(QLatin1Char(' ') + line + QLatin1String("\n"));
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &group : groups) {
		const QStringList parts = group.split(QLatin1Char(':'));
		if (parts.count() < 2)
			continue;
		const QString groupName = parts.first();
#if QT_VERSION < QT_VERSION_CHECK(5, 15, 0)
		new KGpgGroupNode(this, groupName, parts.at(1).split(QLatin1Char(';'), QString::SkipEmptyParts));
#else
		new KGpgGroupNode(this, groupName, parts.at(1).split(QLatin1Char(';'), Qt::SkipEmptyParts));
#endif
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (KGpgNode *nd : ndlist)
		removeFromGroups(nd->toKeyNode());
```

#### RANGE FOR STATEMENT 


```{c}
for (KgpgCore::KgpgKey key : publiclist) {
		int index = issec.indexOf(key.fullId());
		if (index != -1) {
			key.setSecret(true);
			issec.removeAt(index);
		}

		for (int j = 0; j < nodes.count(); j++) {
			KGpgKeyNode *nd = nodes.at(j);
			if (nd->getId() == key.fullId()) {
				nodes.removeAt(j);
				nd->setKey(key);
				break;
			}
		}
	}
```

#### AUTO 


```{c}
const auto algorithms = getGpgStatusLine(binary, QLatin1String("Pubkey:")).split(QLatin1Char(','));
```

#### RANGE FOR STATEMENT 


```{c}
for (KGpgNode *item : keysList) {
		if (item->getType() == ITYPE_GROUP)
		{
			for (int j = 0; j < item->getChildCount(); j++)
				keyIDS << item->getChild(j)->getId();

			continue;
		}

		if (item->getType() & ITYPE_PAIR) {
			keyIDS << item->getId();
		} else {
			KMessageBox::sorry(this, i18n("You can only refresh primary keys. Please check your selection."));
			return;
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (KGpgNode *nd : tmplist) {
		switch (nd->getType()) {
		case KgpgCore::ITYPE_PAIR:
		case KgpgCore::ITYPE_PUBLIC: {
			KGpgKeyNode *knd = qobject_cast<KGpgKeyNode *>(nd);
			if (!knd->wasExpanded())
				knd->getChildCount();
			}
		}
		slist.append(nd->toSignableNode());
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (KGpgRefNode *nd : qAsConst(m_refs))
		nd->unRef(root);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KGpgNode *node : qAsConst(children)) {
		if ((node->getType() & ITYPE_PAIR) == 0) {
			++i;
			continue;
		}

		const KGpgKeyNode *key = node->toKeyNode();

		if (key->compareId(keyId))
			return i;
		++i;
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &line : log) {
		if (!line.startsWith(QLatin1String("[GNUPG:] ")))
			continue;

		const QString msg = line.mid(9);

		if (!useGoodSig && msg.startsWith(QLatin1String("VALIDSIG "))) {
			// from GnuPG source, doc/DETAILS:
			//   VALIDSIG    <fingerprint in hex> <sig_creation_date> <sig-timestamp>
			//                <expire-timestamp> <sig-version> <reserved> <pubkey-algo>
			//                <hash-algo> <sig-class> <primary-key-fpr>
			const QStringList vsig = msg.mid(9).split(QLatin1Char(' '), QString::SkipEmptyParts);
			Q_ASSERT(vsig.count() >= 10);

			const KGpgKeyNode *node = model->findKeyNode(vsig[9]);

			if (node != nullptr) {
				// ignore for now if this is signed with the primary id (vsig[0] == vsig[9]) or not
				if (node->getEmail().isEmpty())
					result += xi18nc("@info Good signature from: NAME , Key ID: HEXID",
							"<para>Good signature from:<nl/><emphasis strong='true'>%1</emphasis><nl/>Key ID: %2<nl/></para>",
							node->getName(), vsig[9]);
				else
					result += xi18nc("@info Good signature from: NAME <EMAIL>, Key ID: HEXID",
							"<para>Good signature from:<nl/><emphasis strong='true'>%1 <email>%2</email></emphasis><nl/>Key ID: %3</para>",
							node->getName(), node->getEmail(), vsig[9]);

				result += sigTimeMessage(vsig[2]);
			} else {
				// this should normally never happen, but one could delete
				// the key just after the verification. Brute force solution:
				// do the whole report generation again, but this time make
				// sure GOODSIG is used.
				return getReport(log, nullptr);
			}
		} else if (msg.startsWith(QLatin1String("UNEXPECTED")) ||
				msg.startsWith(QLatin1String("NODATA"))) {
			result += xi18nc("@info", "No signature found.") + QLatin1Char('\n');
		} else if (useGoodSig && msg.startsWith(QLatin1String("GOODSIG "))) {
            int sigpos = msg.indexOf( QLatin1Char(' ') , 8);
			const QString keyid = msg.mid(8, sigpos - 8);

			// split the name/email pair to give translators more power to handle this
			QString email;
			QString name = msg.mid(sigpos + 1);

			int oPos = name.indexOf(QLatin1Char('<'));
			int cPos = name.indexOf(QLatin1Char('>'));
			if ((oPos >= 0) && (cPos >= 0)) {
				email = name.mid(oPos + 1, cPos - oPos - 1);
				name = name.left(oPos).simplified();
			}

			if (email.isEmpty())
				result += xi18nc("@info", "<para>Good signature from:<nl/><emphasis strong='true'>%1</emphasis><nl/>Key ID: %2<nl/></para>",
						name, keyid);
			else
				result += xi18nc("@info Good signature from: NAME <EMAIL>, Key ID: HEXID",
						"<para>Good signature from:<nl/><emphasis strong='true'>%1 <email>%2</email></emphasis><nl/>Key ID: %3<nl/></para>",
						name, email, keyid);
			if (!sigtime.isEmpty()) {
				result += sigTimeMessage(sigtime);
				sigtime.clear();
			}
		} else if (msg.startsWith(QLatin1String("SIG_ID "))) {
			const QStringList parts = msg.simplified().split(QLatin1Char(' '));
			if (parts.count() > 2)
				sigtime = parts[2];
		} else if (msg.startsWith(QLatin1String("BADSIG"))) {
            int sigpos = msg.indexOf( QLatin1Char(' '), 7);
			result += xi18nc("@info", "<para><emphasis strong='true'>BAD signature</emphasis> from:<nl/> %1<nl/>Key ID: %2<nl/><nl/><emphasis strong='true'>The file is corrupted</emphasis></para>",
					msg.mid(sigpos + 1), msg.mid(7, sigpos - 7));
		} else  if (msg.startsWith(QLatin1String("TRUST_UNDEFINED"))) {
			result += xi18nc("@info", "<para>The signature is valid, but the key is untrusted</para>");
		} else if (msg.startsWith(QLatin1String("TRUST_ULTIMATE"))) {
			result += xi18nc("@info", "<para>The signature is valid, and the key is ultimately trusted</para>");
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : m_decryptionFailed)
				failedFiles.append(url.toDisplayString());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &line : log) {
		if (!line.startsWith(QLatin1String("[GNUPG:] ")))
			continue;

		const QString msg = line.mid(9);

		if (!useGoodSig && msg.startsWith(QLatin1String("VALIDSIG "))) {
			// from GnuPG source, doc/DETAILS:
			//   VALIDSIG    <fingerprint in hex> <sig_creation_date> <sig-timestamp>
			//                <expire-timestamp> <sig-version> <reserved> <pubkey-algo>
			//                <hash-algo> <sig-class> <primary-key-fpr>
#if QT_VERSION < QT_VERSION_CHECK(5, 15, 0)
			const QStringList vsig = msg.mid(9).split(QLatin1Char(' '), QString::SkipEmptyParts);
#else
			const QStringList vsig = msg.mid(9).split(QLatin1Char(' '), Qt::SkipEmptyParts);
#endif
			Q_ASSERT(vsig.count() >= 10);

			const KGpgKeyNode *node = model->findKeyNode(vsig[9]);

			if (node != nullptr) {
				// ignore for now if this is signed with the primary id (vsig[0] == vsig[9]) or not
				if (node->getEmail().isEmpty())
					result += xi18nc("@info Good signature from: NAME , Key ID: HEXID",
							"<para>Good signature from:<nl/><emphasis strong='true'>%1</emphasis><nl/>Key ID: %2<nl/></para>",
							node->getName(), vsig[9]);
				else
					result += xi18nc("@info Good signature from: NAME <EMAIL>, Key ID: HEXID",
							"<para>Good signature from:<nl/><emphasis strong='true'>%1 <email>%2</email></emphasis><nl/>Key ID: %3</para>",
							node->getName(), node->getEmail(), vsig[9]);

				result += sigTimeMessage(vsig[2]);
			} else {
				// this should normally never happen, but one could delete
				// the key just after the verification. Brute force solution:
				// do the whole report generation again, but this time make
				// sure GOODSIG is used.
				return getReport(log, nullptr);
			}
		} else if (msg.startsWith(QLatin1String("UNEXPECTED")) ||
				msg.startsWith(QLatin1String("NODATA"))) {
			result += xi18nc("@info", "No signature found.") + QLatin1Char('\n');
		} else if (useGoodSig && msg.startsWith(QLatin1String("GOODSIG "))) {
            int sigpos = msg.indexOf( QLatin1Char(' ') , 8);
			const QString keyid = msg.mid(8, sigpos - 8);

			// split the name/email pair to give translators more power to handle this
			QString email;
			QString name = msg.mid(sigpos + 1);

			int oPos = name.indexOf(QLatin1Char('<'));
			int cPos = name.indexOf(QLatin1Char('>'));
			if ((oPos >= 0) && (cPos >= 0)) {
				email = name.mid(oPos + 1, cPos - oPos - 1);
				name = name.left(oPos).simplified();
			}

			if (email.isEmpty())
				result += xi18nc("@info", "<para>Good signature from:<nl/><emphasis strong='true'>%1</emphasis><nl/>Key ID: %2<nl/></para>",
						name, keyid);
			else
				result += xi18nc("@info Good signature from: NAME <EMAIL>, Key ID: HEXID",
						"<para>Good signature from:<nl/><emphasis strong='true'>%1 <email>%2</email></emphasis><nl/>Key ID: %3<nl/></para>",
						name, email, keyid);
			if (!sigtime.isEmpty()) {
				result += sigTimeMessage(sigtime);
				sigtime.clear();
			}
		} else if (msg.startsWith(QLatin1String("SIG_ID "))) {
			const QStringList parts = msg.simplified().split(QLatin1Char(' '));
			if (parts.count() > 2)
				sigtime = parts[2];
		} else if (msg.startsWith(QLatin1String("BADSIG"))) {
            int sigpos = msg.indexOf( QLatin1Char(' '), 7);
			result += xi18nc("@info", "<para><emphasis strong='true'>BAD signature</emphasis> from:<nl/> %1<nl/>Key ID: %2<nl/><nl/><emphasis strong='true'>The file is corrupted</emphasis></para>",
					msg.mid(sigpos + 1), msg.mid(7, sigpos - 7));
		} else  if (msg.startsWith(QLatin1String("TRUST_UNDEFINED"))) {
			result += xi18nc("@info", "<para>The signature is valid, but the key is untrusted</para>");
		} else if (msg.startsWith(QLatin1String("TRUST_ULTIMATE"))) {
			result += xi18nc("@info", "<para>The signature is valid, and the key is ultimately trusted</para>");
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &keyresult : log) {
		if (!keyresult.startsWith(QLatin1String("[GNUPG:] IMPORT_OK ")))
			continue;

		QStringList rc(keyresult.mid(19).split(QLatin1Char( ' ' )));
		if (rc.count() < 2) {
			qCDebug(KGPG_LOG_GENERAL) << "unexpected syntax:" << keyresult;
			continue;
		}

		resultcodes[rc.at(1)] = rc.at(0).toUInt();
	}
```

#### LAMBDA EXPRESSION 


```{c}
[](int result) { QCOMPARE(result, static_cast<int>(KGpgVerify::TS_BAD_SIGNATURE)); }
```

#### LAMBDA EXPRESSION 


```{c}
[](int result) { QCOMPARE(result, KGpgVerify::TS_BAD_SIGNATURE); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KGpgNode *ch : nd->getChildren()) {
		if (ch->hasChildren()) {
			getMissingSigs(missingKeys, ch->toExpandableNode());
			continue;
		} else if (ch->getType() == ITYPE_SIGN) {
			if (ch->toSignNode()->isUnknown())
				missingKeys << ch->getId();
		}
	}
```

#### AUTO 


```{c}
auto statJob = KIO::stat(url, KIO::StatJob::DestinationSide, 0);
```

#### LAMBDA EXPRESSION 


```{c}
[transaction](int result) {
		QCOMPARE(transaction->getImportedKeys().size(), 1);
		QString keyID = QLatin1String("BA7695F3C550DF14");
		QString duplicateMsg = QLatin1String("IMPORT_OK 0 FBAF08DD7D9D0921C15DDA9FBA7695F3C550DF14");
		qDebug() << "MESSAGES: " << transaction->getMessages();
		QVERIFY(transaction->getImportedKeys().first().startsWith(keyID));
		QVERIFY(transaction->getMessages().join(QLatin1Char(' ')).contains(duplicateMsg));
		QEXPECT_FAIL("", "Test is broken. Possible bug!", Continue);
		QCOMPARE(result, static_cast<int>(KGpgTransaction::TS_OK));
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const KGpgNode *child : children) {
		KGpgSignNode::List tmp;

		switch (child->getType()) {
		case KgpgCore::ITYPE_UID:
		case KgpgCore::ITYPE_UAT:
			if (child->getId() == idxstr)
				return child->toSignableNode();
			break;
		default:
			continue;
		}
	}
```

#### AUTO 


```{c}
const auto nodes = iview->selectedNodes();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &line : log) {
		if (!line.startsWith(QLatin1String("[GNUPG:] ")))
			continue;

		const QString msg = line.mid(9);

		if (!useGoodSig && msg.startsWith(QLatin1String("VALIDSIG "))) {
			// from GnuPG source, doc/DETAILS:
			//   VALIDSIG    <fingerprint in hex> <sig_creation_date> <sig-timestamp>
			//                <expire-timestamp> <sig-version> <reserved> <pubkey-algo>
			//                <hash-algo> <sig-class> <primary-key-fpr>
			const QStringList vsig = msg.mid(9).split(QLatin1Char(' '), QString::SkipEmptyParts);
			Q_ASSERT(vsig.count() >= 10);

			const KGpgKeyNode *node = model->findKeyNode(vsig[9]);

			if (node != nullptr) {
				// ignore for now if this is signed with the primary id (vsig[0] == vsig[9]) or not
				if (node->getEmail().isEmpty())
					result += xi18nc("@info Good signature from: NAME , Key ID: HEXID",
							"<para>Good signature from:<nl/><emphasis strong='true'>%1</emphasis><nl/>Key ID: %2<nl/></para>",
							node->getName(), vsig[9]);
				else
					result += xi18nc("@info Good signature from: NAME <EMAIL>, Key ID: HEXID",
							"<para>Good signature from:<nl/><emphasis strong='true'>%1 <email>%2</email></emphasis><nl/>Key ID: %3</para>",
							node->getName(), node->getEmail(), vsig[9]);

				result += sigTimeMessage(vsig[2]);
			} else {
				// this should normally never happen, but one could delete
				// the key just after the verification. Brute force solution:
				// do the whole report generation again, but this time make
				// sure GOODSIG is used.
				return getReport(log, nullptr);
			}
		} else if (msg.startsWith(QLatin1String("UNEXPECTED")) ||
				msg.startsWith(QLatin1String("NODATA"))) {
			result += xi18nc("@info", "No signature found.") + QLatin1Char('\n');
		} else if (useGoodSig && msg.startsWith(QLatin1String("GOODSIG "))) {
			int sigpos = msg.indexOf( ' ' , 8);
			const QString keyid = msg.mid(8, sigpos - 8);

			// split the name/email pair to give translators more power to handle this
			QString email;
			QString name = msg.mid(sigpos + 1);

			int oPos = name.indexOf(QLatin1Char('<'));
			int cPos = name.indexOf(QLatin1Char('>'));
			if ((oPos >= 0) && (cPos >= 0)) {
				email = name.mid(oPos + 1, cPos - oPos - 1);
				name = name.left(oPos).simplified();
			}

			if (email.isEmpty())
				result += xi18nc("@info", "<para>Good signature from:<nl/><emphasis strong='true'>%1</emphasis><nl/>Key ID: %2<nl/></para>",
						name, keyid);
			else
				result += xi18nc("@info Good signature from: NAME <EMAIL>, Key ID: HEXID",
						"<para>Good signature from:<nl/><emphasis strong='true'>%1 <email>%2</email></emphasis><nl/>Key ID: %3<nl/></para>",
						name, email, keyid);
			if (!sigtime.isEmpty()) {
				result += sigTimeMessage(sigtime);
				sigtime.clear();
			}
		} else if (msg.startsWith(QLatin1String("SIG_ID "))) {
			const QStringList parts = msg.simplified().split(QLatin1Char(' '));
			if (parts.count() > 2)
				sigtime = parts[2];
		} else if (msg.startsWith(QLatin1String("BADSIG"))) {
			int sigpos = msg.indexOf( ' ', 7);
			result += xi18nc("@info", "<para><emphasis strong='true'>BAD signature</emphasis> from:<nl/> %1<nl/>Key ID: %2<nl/><nl/><emphasis strong='true'>The file is corrupted</emphasis></para>",
					msg.mid(sigpos + 1), msg.mid(7, sigpos - 7));
		} else  if (msg.startsWith(QLatin1String("TRUST_UNDEFINED"))) {
			result += xi18nc("@info", "<para>The signature is valid, but the key is untrusted</para>");
		} else if (msg.startsWith(QLatin1String("TRUST_ULTIMATE"))) {
			result += xi18nc("@info", "<para>The signature is valid, and the key is ultimately trusted</para>");
		}
	}
```

#### LAMBDA EXPRESSION 


```{c}
[transaction]() {
		QVERIFY(transaction->getImportedKeys().size() == 1);
		QString keyID = QLatin1String("BA7695F3C550DF14");
		QVERIFY(transaction->getImportedKeys().first().startsWith(keyID));
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const KGpgSignNode *retsn : qAsConst(ret)) {
				found = (retsn->getId() == snid);
				if (found)
					break;
			}
```

#### RANGE FOR STATEMENT 


```{c}
for (KGpgNode *child : children) {
		switch (child->getType()) {
		case KgpgCore::ITYPE_UID:
		case KgpgCore::ITYPE_UAT:
			break;
		default:
			continue;
		}

		const KGpgSignNode::List tmp = child->toSignableNode()->getSignatures();

		for (KGpgSignNode *sn : tmp) {
			bool found = false;
			const QString snid(sn->getId());

			foreach (const KGpgSignNode *retsn, ret) {
				found = (retsn->getId() == snid);
				if (found)
					break;
			}

			if (!found)
				ret << sn;
		}
	}
```

#### LAMBDA EXPRESSION 


```{c}
[](int result) { QCOMPARE(result, static_cast<int>(KGpgTransaction::TS_OK)); }
```

#### LAMBDA EXPRESSION 


```{c}
[transaction](int result) {
		QString msg =
			QLatin1String("IMPORT_OK 1 FBAF08DD7D9D0921C15DDA9FBA7695F3C550DF14");
		QVERIFY(transaction->getMessages().join(QLatin1Char(' ')).contains(msg));
		QCOMPARE(result, KGpgTransaction::TS_OK);
	}
```

#### LAMBDA EXPRESSION 


```{c}
[](int result) { QCOMPARE(result, KGpgTransaction::TS_OK); }
```

#### AUTO 


```{c}
auto statJob = KIO::statDetails(url, KIO::StatJob::DestinationSide, {});
```

#### RANGE FOR STATEMENT 


```{c}
for (KGpgKeyNode *kn : keys)
			imodel->delNode(kn);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QChar &ch : capString) {
		switch (ch.toLatin1()) {
		case 's':
		case 'S':
			if (upper != ch.isUpper())
				continue;
			ret |= SKT_SIGNATURE;
			break;
		case 'e':
		case 'E':
			if (upper != ch.isUpper())
				continue;
			ret |= SKT_ENCRYPTION;
			break;
		case 'a':
		case 'A':
			if (upper != ch.isUpper())
				continue;
			ret |= SKT_AUTHENTICATION;
			break;
		case 'c':
		case 'C':
			if (upper != ch.isUpper())
				continue;
			ret |= SKT_CERTIFICATION;
			break;
		case 'D':	// disabled key
		case '?':	// unknown to GnuPG
			continue;
		default:
			qCDebug(KGPG_LOG_GENERAL) << "unknown capability letter" << ch
			<< "in cap string" << capString;
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const KgpgKey &key : *this)
        res << key.fullId();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &str : log) {
		if (!str.startsWith(QLatin1String("[GNUPG:] IMPORT_OK ")))
			continue;

		QString tmpstr(str.mid(19).simplified());

		int space = tmpstr.indexOf(QLatin1Char( ' ' ));
		if (space <= 0) {
			qCDebug(KGPG_LOG_GENERAL) << __LINE__ << "invalid format:" << str;
			continue;
		}

		bool ok;
		unsigned char code = tmpstr.leftRef(space).toUInt(&ok);
		if (!ok) {
			qCDebug(KGPG_LOG_GENERAL) << __LINE__ << "invalid format:" << str << space << tmpstr.leftRef(space - 1);
			continue;
		}

		if ((reason == -1) || ((reason == 0) && (code == 0)) || ((reason & code) != 0))
			res << tmpstr.mid(space + 1);
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const KGpgGroupNode *gnd : groups)
		groupNames << gnd->getName();
```

#### RANGE FOR STATEMENT 


```{c}
for (const KGpgNode *nd : qAsConst(nodes))
		ids << nd->getId();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : qAsConst(urlList)) {
			QMimeDatabase db;
			if (db.mimeTypeForUrl(url).name() == QLatin1String( "inode/directory" )) {
				directoryInside = true;
				break;
			}
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (KGpgNode *n : tmplist) {
			const KGpgKeyNode *nd = n->toKeyNode();

			if (nd->getEmail().isEmpty())
				signKeyList += i18nc("Name: ID", "%1: %2", nd->getName(), nd->getBeautifiedFingerprint());
			else
				signKeyList += i18nc("Name (Email): ID", "%1 (%2): %3", nd->getName(), nd->getEmail(), nd->getBeautifiedFingerprint());

			signList.append(n->toSignableNode());
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &hintName : hintNames()) {
				const KGpgTransaction::ts_hintType h = static_cast<KGpgTransaction::ts_hintType>(i++);
				if (!line.startsWith(hintName))
					continue;

				matched = true;

				bool r;
				const int skip = hintName.length();
				if (line.length() == skip) {
					r = m_parent->hintLine(h, QString());
				} else {
					r = m_parent->hintLine(h, line.mid(skip + 1).trimmed());
				}

				if (!r) {
					m_parent->setSuccess(KGpgTransaction::TS_MSG_SEQUENCE);
					sendQuit();
				}

				break;
			}
```

#### AUTO 


```{c}
const auto ndlist = iview->selectedNodes(&same, &pt);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &line : getMessages())
		if (!line.startsWith(QLatin1String("[GNUPG:] "))) {
			result.append(line);
			txtlength += line.length() + 1;
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (const KGpgSignableNode *nd : qAsConst(m_noEncIds))
				if (nd->getEmail().isEmpty())
					ids << i18nc("%1 is the key id, %2 is the name and comment of the key or uid",
							"%1: %2", nd->getId(), nd->getNameComment());
				else
					ids << i18nc("%1 is the key id, %2 is the name and comment of the key or uid, %3 is the email address of the uid",
							"%1: %2 &lt;%3&gt;", nd->getId(), nd->getNameComment(), nd->getEmail());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &changed : keyIds) {
			const KGpgKeyNode *node = model->findKeyNode(changed);
			QString line;

			if (node == nullptr) {
				line = changed;
			} else {
				if (node->getEmail().isEmpty())
					line = xi18nc("@item ID: Name", "%1: %2", node->getFingerprint(), node->getName());
				else
					line = xi18nc("@item ID: Name <Email>", "%1: %2 <email>%3</email>", node->getFingerprint(), node->getName(), node->getEmail());
			}

			result.append(QLatin1String(" ") + line + QLatin1String("\n"));
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &u : qAsConst(m_tempfiles))
		QFile::remove(u);
```

#### AUTO 


```{c}
auto job = new KIO::ApplicationLauncherJob(helpCenter);
```

#### LAMBDA EXPRESSION 


```{c}
[](int result) {
		QCOMPARE(result, static_cast<int>(KGpgTransaction::TS_OK));
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &s : args) {
		tmp.insert(tmppos++, s);
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const KgpgKey &k : publiclist) {
		QString s;

		if (k.email().isEmpty())
			s = i18nc("Name: ID", "%1: %2", k.name(), k.id());
		else
			s = i18nc("Name (Email): ID", "%1 (%2): %3", k.name(), k.email(), k.id());

		CBdefault->addItem(s, k.fingerprint());
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : qAsConst(m_inpfiles)) {
		if (url.isLocalFile()) {
			locfiles.append(url.toLocalFile());
		} else {
			QTemporaryFile tmpFile;
			tmpFile.open();

			auto copyJob = KIO::file_copy(url, QUrl::fromLocalFile(tmpFile.fileName()));
			copyJob->exec();
			if (!copyJob->error()) {
				tmpFile.setAutoRemove(false);
				m_tempfiles.append(tmpFile.fileName());
			} else {
				m_messages.append(copyJob->errorString());
				cleanUrls();
				setSuccess(TS_KIO_FAILED);
				return false;
			}
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (KGpgRefNode *nd : m_refs) {
		if (nd->getType() & type)
			ret.append(nd);
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (KGpgNode *nd : tmplist) {
			const KGpgKeyNode *pnd = (nd->getType() & (ITYPE_UID | ITYPE_UAT)) ?
					nd->getParentKeyNode()->toKeyNode() : nd->toKeyNode();

			if (nd->getEmail().isEmpty())
				signKeyList += i18nc("Name: ID", "%1: %2",
					nd->getName(), pnd->getBeautifiedFingerprint());
			else
				signKeyList += i18nc("Name (Email): ID", "%1 (%2): %3",
					nd->getName(), nd->getEmail(), pnd->getBeautifiedFingerprint());

			signList.append(nd->toSignableNode());
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (const KGpgNode *nd : exportList)
		idlist << nd->getId();
```

#### LAMBDA EXPRESSION 


```{c}
[transaction](int result) {
		QCOMPARE(transaction->getImportedIds(0).size(), 1);
		QString fingerprint = QLatin1String("FBAF08DD7D9D0921C15DDA9FBA7695F3C550DF14");
		QVERIFY(transaction->getImportedIds(0).first().compare(fingerprint) == 0);
		QCOMPARE(result, KGpgTransaction::TS_OK);
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const KGpgKeyNode *key : keys)
		ret << key->getFingerprint();
```

#### RANGE FOR STATEMENT 


```{c}
for (const KgpgCore::KgpgKey &key : qAsConst(secretlist))
		new KGpgOrphanNode(this, key);
```

#### LAMBDA EXPRESSION 


```{c}
[transaction](int result) {
		QString msg = QLatin1String("IMPORT_OK 1 FBAF08DD7D9D0921C15DDA9FBA7695F3C550DF14");
		QVERIFY(transaction->getMessages().join(QLatin1Char(' ')).contains(msg));
		QCOMPARE(result, static_cast<int>(KGpgTransaction::TS_OK));
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const KgpgKeySub &k : qAsConst(*d->gpgsublist))
		if (k.type() & SKT_ENCRYPTION)
			return k.algorithm();
```

#### RANGE FOR STATEMENT 


```{c}
for (const KGpgNode *nd : sel) {
		if (nd->hasChildren()) {
			getMissingSigs(missingKeys, nd->toExpandableNode());
		} else if (nd->getType() == ITYPE_SIGN) {
			const KGpgSignNode *sn = nd->toSignNode();

			if (sn->isUnknown())
				missingKeys << sn->getId();
		}
	}
```

#### AUTO 


```{c}
auto it = std::find_if(d->gpgsublist->cbegin(), d->gpgsublist->cend(),
			[](const KgpgKeySub &k) { return k.type() & SKT_ENCRYPTION; });
```

#### AUTO 


```{c}
const auto exportList = iview->selectedNodes();
```

#### RANGE FOR STATEMENT 


```{c}
for (KGpgGroupMemberNode *gnd : refs)
		ret.append(gnd->getParentKeyNode());
```

#### RANGE FOR STATEMENT 


```{c}
for (const KgpgKeySub &k : list) {
		if (k.type() & SKT_ENCRYPTION) {
			// if the first encryption subkey is expired
			// check if there is one that is not
			if (k.trust() > TRUST_EXPIRED)
				return &k;
			if (enc == nullptr)
				enc = &k;
		}
	}
```

#### LAMBDA EXPRESSION 


```{c}
[](int result) { QCOMPARE(result, KGpgVerify::TS_MISSING_KEY); }
```

#### LAMBDA EXPRESSION 


```{c}
[transaction](int result) {
		QCOMPARE(transaction->getImportedIds(-1).size(), 1);
		QString fingerprint = QLatin1String("FBAF08DD7D9D0921C15DDA9FBA7695F3C550DF14");
		QVERIFY(transaction->getImportedIds(-1).first().compare(fingerprint) == 0);
		QCOMPARE(result, KGpgTransaction::TS_OK);
	}
```

#### AUTO 


```{c}
auto *job = new KIO::OpenUrlJob(QUrl(url));
```

#### LAMBDA EXPRESSION 


```{c}
[transaction]() {
		QString keyID = QLatin1String("7882C615210F1022");
		QVERIFY(transaction->missingId().compare(keyID) == 0);
	}
```

#### LAMBDA EXPRESSION 


```{c}
[](int result) { QCOMPARE(result, static_cast<int>(KGpgAddUid::TS_INVALID_EMAIL)); }
```

#### RANGE FOR STATEMENT 


```{c}
for (KGpgNode *child : children) {
		switch (child->getType()) {
		case KgpgCore::ITYPE_UID:
		case KgpgCore::ITYPE_UAT:
			break;
		default:
			continue;
		}

		const KGpgSignNode::List tmp = child->toSignableNode()->getSignatures();

		for (KGpgSignNode *sn : tmp) {
			bool found = false;
			const QString snid(sn->getId());

			for (const KGpgSignNode *retsn : qAsConst(ret)) {
				found = (retsn->getId() == snid);
				if (found)
					break;
			}

			if (!found)
				ret << sn;
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (KgpgCore::KgpgKey key : publiclist) {
		int index = issec.indexOf(key.fullId());

		if (index >= 0) {
			key.setSecret(true);
			issec.removeAt(index);
			secretlist.removeAt(index);
		}

		KGpgKeyNode *nd = new KGpgKeyNode(this, key);
		emit newKeyNode(nd);
	}
```

#### AUTO 


```{c}
const auto ndlist = iview->selectedNodes(nullptr, &tp);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &str : log) {
		line++;
		if (!str.startsWith(QLatin1String("[GNUPG:] IMPORT_RES ")))
			continue;

		const QStringList rstr = str.mid(20).simplified().split(QLatin1Char(' '));

		fine = (rstr.count() >= RESULT_PARTS_MIN);

		const int parts = qBound<int>(RESULT_PARTS_MIN, rstr.count(), RESULT_PARTS_MAX);

		for (int i = parts - 1; (i >= 0) && fine; i--)
			rcode[i] += rstr.at(i).toULong(&fine);

		if (!fine)
			return xi18nc("@info", "The import result string has an unsupported format in line %1.<nl/>Please see the detailed log for more information.", line);
	}
```

#### AUTO 


```{c}
const auto sel = iview->selectedNodes();
```

#### AUTO 


```{c}
const auto keysList = iview->selectedNodes();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &str : log) {
		if (!str.startsWith(QLatin1String("[GNUPG:] IMPORT_OK ")))
			continue;

		QString tmpstr(str.mid(19).simplified());

		int space = tmpstr.indexOf(QLatin1Char( ' ' ));
		if (space <= 0) {
			qCDebug(KGPG_LOG_GENERAL) << __LINE__ << "invalid format:" << str;
			continue;
		}

		bool ok;
		unsigned char code = tmpstr.left(space).toUInt(&ok);
		if (!ok) {
			qCDebug(KGPG_LOG_GENERAL) << __LINE__ << "invalid format:" << str << space << tmpstr.left(space - 1);
			continue;
		}

		if ((reason == -1) || ((reason == 0) && (code == 0)) || ((reason & code) != 0))
			res << tmpstr.mid(space + 1);
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const KGpgNode *nd : nodes) {
		if (nd->getEmail().isEmpty())
			continue;

		maillist << QLatin1Char('"') + nd->getName() + QLatin1String("\" <") + nd->getEmail() + QLatin1Char('>');
	}
```

#### LAMBDA EXPRESSION 


```{c}
[transaction](int result) {
		QCOMPARE(transaction->getImportedIds(0).size(), 1);
		QString fingerprint = QLatin1String("FBAF08DD7D9D0921C15DDA9FBA7695F3C550DF14");
		QVERIFY(transaction->getImportedIds(0).first().compare(fingerprint) == 0);
		QCOMPARE(result, static_cast<int>(KGpgTransaction::TS_OK));
	}
```

#### LAMBDA EXPRESSION 


```{c}
[](const KGpgNode *nd) { return nd->getType() == ITYPE_GROUP; }
```

#### RANGE FOR STATEMENT 


```{c}
for (KGpgNode *kn : children) {
		if (kn->getType() == KgpgCore::ITYPE_SIGN)
			ret << kn->toSignNode();
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (QString rawmsg : messages)
		msglist << rawmsg.replace(QLatin1Char('<'), QLatin1String("&lt;"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : qAsConst(urlList)) {
					QFile qfile(url.path());
					if (qfile.open(QIODevice::ReadOnly)) {
						const int probelen = 4096;
						QTextStream t(&qfile);
						QString probetext(t.read(probelen));
						qfile.close();

						if (KGpgImport::isKey(probetext, probetext.length() == probelen))
							haskeys = true;
						else
							hastext = true;
					}
				}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &str : log) {
		if (!str.startsWith(QLatin1String("[GNUPG:] IMPORT_OK ")))
			continue;

		QString tmpstr(str.mid(19).simplified());

		int space = tmpstr.indexOf(QLatin1Char( ' ' ));
		if (space <= 0) {
			kDebug(2100) << __LINE__ << "invalid format:" << str;
			continue;
		}

		bool ok;
		unsigned char code = tmpstr.left(space).toUInt(&ok);
		if (!ok) {
			kDebug(2100) << __LINE__ << "invalid format:" << str << space << tmpstr.left(space - 1);
			continue;
		}

		if ((reason == -1) || ((reason == 0) && (code == 0)) || ((reason & code) != 0))
			res << tmpstr.mid(space + 1);
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &group : groups) {
		const QStringList parts = group.split(QLatin1Char(':'));
		if (parts.count() < 2)
			continue;
		const QString groupName = parts.first();
		new KGpgGroupNode(this, groupName, parts.at(1).split(QLatin1Char(';'), QString::SkipEmptyParts));
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &uid : m_userIds)
			ret << QLatin1String( "--recipient" ) << uid;
```

#### RANGE FOR STATEMENT 


```{c}
for (KGpgNode *nd : ndlist) {
		if (nd->getTrust() >= mintrust) {
			keysList.append(nd->toKeyNode());
		} else {
			badkeys += i18nc("<Name> (<Email>) ID: <KeyId>", "%1 (%2) ID: %3",
					nd->getName(), nd->getEmail(), nd->getId());
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (KGpgKeyNode *kn : m_delkey->keys)
			imodel->delNode(kn);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KGpgNode *nd : ndlist)
				if (nd->getParentKeyNode() != group) {
					invalidDelete = true;
					break;
				}
```

#### AUTO 


```{c}
auto copyJob = KIO::file_copy(url, QUrl::fromLocalFile(tmpFile.fileName()));
```

#### AUTO 


```{c}
const auto keys = m_delkey->keys();
```

#### LAMBDA EXPRESSION 


```{c}
[](const KgpgKeySub &k) { return k.type() & SKT_ENCRYPTION; }
```

#### AUTO 


```{c}
auto uploadJob = KIO::storedPut(cod->fromUnicode(m_editor->toPlainText()), m_docname, -1);
```

#### AUTO 


```{c}
const auto groups = node->getGroups();
```

