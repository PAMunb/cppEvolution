#### RANGE FOR STATEMENT 


```{c}
for (Package *package : d->packages) {
        if (package->installedFilesList().contains(file)) {
            return package;
        }
    }
```

#### AUTO 


```{c}
auto I = list->begin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Package *package: d->packages) {
        if ((package->state() & states)) {
            packageCount++;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& file : partsDir.entryList(QStringList() << "*.list")) {
        load(partsDir.filePath(file));
    }
```

#### AUTO 


```{c}
auto i = changes.constBegin();
```

#### AUTO 


```{c}
auto it = fetcher.ItemsBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &pkg : packageNames) {
        packages.insert(pkg, 0);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SourceEntry &item : entries(entryForFile)) {
        if (entry == item) {
            return;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (SourceEntry &entry : d->list) {
        QString file = files[entry.file()];

        // Compose file
        QString data = entry.toString() + '\n';
        file.append(data);
        files[entry.file()] = file;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto depGroup : depList) {
        for (auto dep : depGroup) {
            QCOMPARE(dep.packageName(), field.split(':').first());
            QCOMPARE(dep.multiArchAnnotation(), QStringLiteral("any"));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto dep : depGroup) {
            QCOMPARE(dep.packageName(), field.split(':').first());
            QCOMPARE(dep.multiArchAnnotation(), QStringLiteral("any"));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &option : options) {
            QStringList parts = option.split('=');

            if (parts.size() != 2) {
                isValid = false;
                return;
            }

            QString key = parts.at(0);
            QString value = parts.at(1);

            if (key != QLatin1String("arch")) {
                isValid = false;
                return;
            }

            architectures = value.split(',');
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &sourceFile : this->sourceFiles()) {
        qDebug() << "Writing file " << sourceFile << " with: " << this->dataForSourceFile(sourceFile);
        if (! d->worker->writeFileToDisk(this->dataForSourceFile(sourceFile), sourceFile)) {
            qWarning() << "Failed to write the file to disk (dbus call failed)!";
        }
    }
```

#### AUTO 


```{c}
auto changes = m_backend->stateChanges(m_oldCacheState, excluded);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& file : partsDir.entryList(QStringList() << "*.list")) {
        load(file);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const ChangelogEntry &entry : entries()) {
        int res = Package::compareVersion(entry.version(), version);

        // Add entries newer than the given version
        if (res > 0) {
            newEntries << entry;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QString package : actionPackages.split(QLatin1String("), "))) {
                if (!package.endsWith(QLatin1Char(')'))) {
                    package.append(QLatin1Char(')'));
                }

                switch (action) {
                case Package::ToInstall:
                    installedPackages << package;
                    break;
                case Package::ToUpgrade:
                    upgradedPackages << package;
                    break;
                case Package::ToDowngrade:
                    downgradedPackages << package;
                    break;
                case Package::ToRemove:
                    removedPackages << package;
                    break;
                case Package::ToPurge:
                    purgedPackages << package;
                    break;
                default:
                    break;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (Package *package : d->packages) {
        if (package->state() & (Package::ToInstall | Package::ToReInstall |
                                Package::ToUpgrade | Package::ToDowngrade |
                                Package::ToRemove | Package::ToPurge)) {
            markedPackages << package;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &filePathEntry : filePathList) {
        addSourcesFile(filePathEntry);
    }
```

#### AUTO 


```{c}
auto MD5HashString = rec.Hashes().find("MD5Sum");
```

#### RANGE FOR STATEMENT 


```{c}
for (QApt::Package *package : m_foundCodecs) {
        package->setInstall();
    }
```

#### AUTO 


```{c}
auto dep
```

#### AUTO 


```{c}
auto i = fetcher.ItemsBegin();
```

#### AUTO 


```{c}
auto depGroup = depList.first();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto depGroup : depList) {
        for (auto dep : depGroup) {
            QCOMPARE(dep.packageName(), field);
            QVERIFY(dep.multiArchAnnotation().isEmpty());
        }
    }
```

#### AUTO 


```{c}
auto trustIter = trustCache->constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Package *package : packages) {
        std::string fullName = package->packageIterator()->FullName();
        packageList.insert(QString::fromStdString(fullName), Package::ToRemove);
    }
```

#### AUTO 


```{c}
auto it = iconsList.begin();
```

#### AUTO 


```{c}
auto hashes = rec.Hashes();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &packageString : m_trans->packages().keys()) {
        pkgCache::PkgIterator iter = (*m_cache)->FindPkg(packageString.toStdString());

        if (!iter)
            continue; // Package not found

        pkgCache::VerIterator ver = (*m_cache)->GetCandidateVer(iter);

        if (!ver || !ver.Downloadable() || !ver.Arch())
            continue; // Virtual package or not downloadable or broken

        // Obtain package info
        pkgCache::VerFileIterator vf = ver.FileList();
        pkgRecords::Parser &rec = m_records->Lookup(ver.FileList());

        // Try to cross match against the source list
        if (!m_cache->GetSourceList()->FindIndex(vf.File(), index))
            continue;

        string fileName = rec.FileName();
        string MD5sum = rec.MD5Hash();

        if (fileName.empty()) {
            m_trans->setError(QApt::NotFoundError);
            m_trans->setErrorDetails(packageString);
            delete acquire;
            return;
        }

        new pkgAcqFile(&fetcher,
                       index->ArchiveURI(fileName),
                       MD5sum,
                       ver->Size,
                       index->ArchiveInfo(ver),
                       ver.ParentPkg().Name(),
                       m_trans->filePath().toStdString(), "");
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Package *package : d->packages) {
        if (package->state() & Package::Upgradeable) {
            upgradeablePackages << package;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& file : partsDir.entryList(QStringList() << "*.list")) {
        addSourcesFile(partsDir.filePath(file));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &pinName : pinFiles) {
        QString pinPath;
        // Make all paths absolute
        if (!pinName.startsWith(QLatin1Char('/'))) {
            pinPath = dir % pinName;
        } else {
            pinPath = pinName;
        }

        if (!QFile::exists(pinPath))
                continue;

        FileFd Fd(pinPath.toUtf8().data(), FileFd::ReadOnly);

        pkgTagFile tagFile(&Fd);
        if (_error->PendingError()) {
            continue;
        }

        pkgTagSection tags;
        while (tagFile.Step(tags)) {
            string name = tags.FindS("Package");
            Package *pkg = package(QLatin1String(name.c_str()));
            if (pkg) {
                pkg->setPinned(true);
            }
        }
    }
```

#### AUTO 


```{c}
auto mapIter = m_trans->packages().constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &packageStr : packageStrs) {
        pkg = m_backend->package(packageStr);

        if (pkg)
            packages.append(pkg);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &pinName : pinFiles) {
            QString pinPath;
            if (!pinName.startsWith(QLatin1Char('/'))) {
                pinPath = dir % pinName;
            } else {
                pinPath = pinName;
            }

            if (!QFile::exists(pinPath))
                continue;

            // Open to get a file name
            QTemporaryFile tempFile;
            if (!tempFile.open()) {
                return false;
            }
            tempFile.close();

            QString tempFileName = tempFile.fileName();
            FileFd out(tempFileName.toUtf8().toStdString(), FileFd::WriteOnly|FileFd::Create|FileFd::Empty);
            if (!out.IsOpen()) {
                return false;
            }

            FileFd Fd(pinPath.toUtf8().data(), FileFd::ReadOnly);

            pkgTagFile tagFile(&Fd);
            if (_error->PendingError()) {
                return false;
            }

            pkgTagSection tags;
            while (tagFile.Step(tags)) {
                QString name = QLatin1String(tags.FindS("Package").c_str());

                if (name.isEmpty()) {
                    return false;
                }

                // Include all but the matching name in the new pinfile
                if (name != package->name()) {
                    tags.Write(out, TFRewritePackageOrder, {});
                    out.Write("\n", 1);
                }
            }
            out.Close();

            if (!tempFile.open()) {
                return false;
            }

            pinDocument = tempFile.readAll();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Package *package : d->packages) {
        int flags = package->state();
        std::string fullName = package->packageIterator().FullName();
        // Cannot have any of these flags simultaneously
        int status = flags & (Package::IsManuallyHeld |
                              Package::NewInstall |
                              Package::ToReInstall |
                              Package::ToUpgrade |
                              Package::ToDowngrade |
                              Package::ToRemove);
        switch (status) {
        case Package::IsManuallyHeld:
            packageList.insert(QString::fromStdString(fullName), Package::Held);
            break;
        case Package::NewInstall:
            if (!(flags & Package::IsAuto)) {
                packageList.insert(QString::fromStdString(fullName), Package::ToInstall);
            }
            break;
        case Package::ToReInstall:
            packageList.insert(QString::fromStdString(fullName), Package::ToReInstall);
            break;
        case Package::ToUpgrade:
            packageList.insert(QString::fromStdString(fullName), Package::ToUpgrade);
            break;
        case Package::ToDowngrade:
            packageList.insert(QString(QString::fromStdString(fullName)) % ',' % package->availableVersion(), Package::ToDowngrade);
            break;
        case Package::ToRemove:
            if(flags & Package::ToPurge) {
                packageList.insert(QString::fromStdString(fullName), Package::ToPurge);
            } else {
                packageList.insert(QString::fromStdString(fullName), Package::ToRemove);
            }
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Package *package : d->packages) {
        if ((package->state() & states)) {
            packageCount++;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &stanza : stanzas) {
        const HistoryItem historyItem(stanza);
        if (historyItem.isValid()) {
            historyItemList << historyItem;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Transaction *trans : m_queue) {
        if (trans->transactionId() == id) {
            transaction = trans;
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &pinName : pinFiles) {
            QString pinPath;
            if (!pinName.startsWith(QLatin1Char('/'))) {
                pinPath = dir % pinName;
            } else {
                pinPath = pinName;
            }

            if (!QFile::exists(pinPath))
                continue;

            // Open to get a file name
            QTemporaryFile tempFile;
            if (!tempFile.open()) {
                return false;
            }
            tempFile.close();

            QString tempFileName = tempFile.fileName();
            FILE *out = fopen(tempFileName.toUtf8(), "w");
            if (!out) {
                return false;
            }

            FileFd Fd(pinPath.toUtf8().data(), FileFd::ReadOnly);

            pkgTagFile tagFile(&Fd);
            if (_error->PendingError()) {
                return false;
            }

            pkgTagSection tags;
            while (tagFile.Step(tags)) {
                QString name = QLatin1String(tags.FindS("Package").c_str());

                if (name.isEmpty()) {
                    return false;
                }

                // Include all but the matching name in the new pinfile
                if (name != package->name()) {
                    TFRewriteData tfrd;
                    tfrd.Tag = 0;
                    tfrd.Rewrite = 0;
                    tfrd.NewTag = 0;
                    TFRewrite(out, tags, TFRewritePackageOrder, &tfrd);
                    fprintf(out, "\n");
                }
            }

            if (!tempFile.open()) {
                return false;
            }

            pinDocument = tempFile.readAll();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &option : options) {
            QStringList parts = option.split('=');

            if (parts.size() != 2) {
                isValid = false;
                return;
            }

            QString key = parts.at(0);
            if (key != QLatin1String("arch")) {
                isValid = false;
                return;
            }

            QString value = parts.at(1);
            architectures = value.split(',');
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QApt::Package *package : packages) {
            item = new QStandardItem;
            item->setText(package->name());
            item->setEditable(false);
            item->setIcon(QIcon("muon"));

            root->appendRow(item);
        }
```

#### AUTO 


```{c}
auto depGroup = depList.at(i);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &sourceFile : this->sourceFiles()) {
        qDebug() << "Writing file " << sourceFile << " with: " << this->dataForSourceFile(sourceFile);
        if (d->worker->writeFileToDisk(this->dataForSourceFile(sourceFile), sourceFile)) {
            qWarning() << "Failed to write the file to disk (dbus call failed)!";
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QApt::SourceEntry &one : entries ) {
        qDebug() << "Entry " << one.toString();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QApt::Package *package : m_backend->markedPackages()) {
        nameList << package->name();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (std::string &arch : archs)
    {
         archList.append(QString::fromStdString(arch));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Package *package : packages) {
        std::string fullName = package->packageIterator()->FullName();
        packageList.insert(QString::fromStdString(fullName), Package::ToInstall);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (AptLock *lock : m_locks) {
        if (lock->acquire()) {
            qDebug() << "locked?" << lock->isLocked();
            continue;
        }

        // Couldn't get lock
        m_trans->setIsPaused(true);
        m_trans->setStatus(QApt::WaitingLockStatus);

        while (!lock->isLocked() && m_trans->isPaused() && !m_trans->isCancelled()) {
            // Wait 3 seconds and try again
            sleep(3);
            lock->acquire();
        }

        m_trans->setIsPaused(false);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &packageString : m_trans->packages().keys()) {
        pkgCache::PkgIterator iter = (*m_cache)->FindPkg(packageString.toStdString());

        if (!iter)
            continue; // Package not found

        pkgCache::VerIterator ver = (*m_cache)->GetCandidateVersion(iter);

        if (!ver || !ver.Downloadable() || !ver.Arch())
            continue; // Virtual package or not downloadable or broken

        // Obtain package info
        pkgCache::VerFileIterator vf = ver.FileList();
        pkgRecords::Parser &rec = m_records->Lookup(ver.FileList());

        // Try to cross match against the source list
        if (!m_cache->GetSourceList()->FindIndex(vf.File(), index))
            continue;

        std::string fileName = rec.FileName();
        auto hashes = rec.Hashes();

        if (fileName.empty()) {
            m_trans->setError(QApt::NotFoundError);
            m_trans->setErrorDetails(packageString);
            delete acquire;
            return;
        }

        new pkgAcqFile(&fetcher,
                       index->ArchiveURI(fileName),
                       hashes,
                       ver->Size,
                       index->ArchiveInfo(ver),
                       ver.ParentPkg().Name(),
                       m_trans->filePath().toStdString(), "");
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Package *package : d->packages) {
        int flags = package->state();
        std::string fullName = package->packageIterator()->FullName();
        // Cannot have any of these flags simultaneously
        int status = flags & (Package::Held |
                              Package::NewInstall |
                              Package::ToReInstall |
                              Package::ToUpgrade |
                              Package::ToDowngrade |
                              Package::ToRemove);
        switch (status) {
           case Package::NewInstall:
               packageList.insert(fullName.c_str(), Package::ToInstall);
               break;
           case Package::ToReInstall:
               packageList.insert(fullName.c_str(), Package::ToReInstall);
               break;
           case Package::ToUpgrade:
               packageList.insert(fullName.c_str(), Package::ToUpgrade);
               break;
           case Package::ToDowngrade:
               packageList.insert(QString(fullName.c_str()) % ',' % package->availableVersion(), Package::ToDowngrade);
               break;
           case Package::ToRemove:
               if(flags & Package::ToPurge) {
                   packageList.insert(fullName.c_str(), Package::ToPurge);
               } else {
                   packageList.insert(fullName.c_str(), Package::ToRemove);
               }
               break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Transaction *trans : m_pending) {
        if (trans->transactionId() == id) {
            transaction = trans;
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &dir : dirs) {
        m_locks << new AptLock(dir);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QString &sourcesFile : sourceFiles()) {
        d->list[sourcesFile].removeAll(entry);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &stanza : entryTexts) {
        ChangelogEntry entry(stanza, d->sourcePackage);

        entries << entry;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &sourceFile : sourceFiles()) {
        qDebug() << "Writing file " << sourceFile << " with: " << dataForSourceFile(sourceFile);
        if (! d->worker->writeFileToDisk(dataForSourceFile(sourceFile), sourceFile)) {
            qWarning() << "Failed to write the file to disk (dbus call failed)!";
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &sourceFile : d->sourceFiles) {
        toReturn += sourceFile + '\n';
        for (const QApt::SourceEntry &sourceEntry : entries(sourceFile)) {
            toReturn += sourceEntry.toString() + '\n';
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &stanza : stanzas) {
        const HistoryItem historyItem(stanza);
        if (historyItem.isValid())
            historyItemList << historyItem;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Package *package : packages) {
        std::string fullName = package->packageIterator().FullName();
        packageList.insert(QString::fromStdString(fullName), Package::ToInstall);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QApt::SourceEntry &sourceEntry : this->entries(sourceFile)) {
            toReturn += sourceEntry.toString() + "\n";
        }
```

#### AUTO 


```{c}
auto depGroup
```

#### AUTO 


```{c}
auto iter = files.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const SourceEntry &listEntry : this->entries(sourceFile)) {
        to_return.append(listEntry.toString() + '\n');
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &pinName : pinFiles) {
        // Make all paths absolute
        QString pinPath = pinName.startsWith('/') ? pinName : dir % pinName;

        if (!QFile::exists(pinPath))
                continue;

        FileFd Fd(pinPath.toUtf8().data(), FileFd::ReadOnly);

        pkgTagFile tagFile(&Fd);
        if (_error->PendingError()) {
            _error->Discard();
            continue;
        }

        pkgTagSection tags;
        while (tagFile.Step(tags)) {
            string name = tags.FindS("Package");
            Package *pkg = package(QLatin1String(name.c_str()));
            if (pkg)
                pkg->setPinned(true);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Package *package : d->packages) {
        if (package->staticState() & Package::Upgradeable) {
            upgradeablePackages << package;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &pinName : pinFiles) {
        // Make all paths absolute
        QString pinPath = pinName.startsWith('/') ? pinName : dir % pinName;

        if (!QFile::exists(pinPath))
                continue;

        FileFd Fd(pinPath.toUtf8().data(), FileFd::ReadOnly);

        pkgTagFile tagFile(&Fd);
        if (_error->PendingError()) {
            _error->Discard();
            continue;
        }

        pkgTagSection tags;
        while (tagFile.Step(tags)) {
            std::string name = tags.FindS("Package");
            Package *pkg = package(QLatin1String(name.c_str()));
            if (pkg)
                pkg->setPinned(true);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (SourceEntry &entry : d->list) {
        QString file = files[entry.file()];

        // Compose file
        QString data = entry.toString() + '\n';
        file.append(data);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QApt::Package *package : packages) {
            item = new QStandardItem;
            item->setText(package->name());
            item->setEditable(false);
            item->setIcon(KIcon("muon"));

            root->appendRow(item);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QApt::Package *package : packages) {
            item = new QStandardItem;
            item->setText(package->name());
            item->setEditable(false);
            item->setIcon(QIcon::fromTheme("muon"));

            root->appendRow(item);
        }
```

#### AUTO 


```{c}
auto depList = DependencyInfo::parseDepends(field, depType);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Package *package : d->packages) {
        int flags = package->state();
        std::string fullName = package->packageIterator()->FullName();
        // Cannot have any of these flags simultaneously
        int status = flags & (Package::ToKeep |
                              Package::NewInstall |
                              Package::ToReInstall |
                              Package::ToUpgrade |
                              Package::ToDowngrade |
                              Package::ToRemove);
        switch (status) {
           case Package::ToKeep:
               if (flags & Package::Held) {
                   packageList.insert(fullName.c_str(), Package::Held);
               }
               break;
           case Package::NewInstall:
               packageList.insert(fullName.c_str(), Package::ToInstall);
               break;
           case Package::ToReInstall:
               packageList.insert(fullName.c_str(), Package::ToReInstall);
               break;
           case Package::ToUpgrade:
               packageList.insert(fullName.c_str(), Package::ToUpgrade);
               break;
           case Package::ToDowngrade:
               packageList.insert(QString(fullName.c_str()) % ',' % package->availableVersion(), Package::ToDowngrade);
               break;
           case Package::ToRemove:
               if(flags & Package::ToPurge) {
                   packageList.insert(fullName.c_str(), Package::ToPurge);
               } else {
                   packageList.insert(fullName.c_str(), Package::ToRemove);
               }
               break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QApt::SourceEntry &sourceEntry : entries(sourceFile)) {
            toReturn += sourceEntry.toString() + '\n';
        }
```

#### AUTO 


```{c}
auto VF = Ver.FileList();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& file : sourceFiles) {
        if ( ! file.isNull() && ! file.isEmpty() ) {
            load(file);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &sourceFile : d->sourceFiles) {
        toReturn += sourceFile + "\n";
        for (const QApt::SourceEntry &sourceEntry : this->entries(sourceFile)) {
            toReturn += sourceEntry.toString() + "\n";
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &packageStr : packageStrs) {
        pkg = m_backend->package(packageStr);

        if (pkg)
            packages.append(pkg);
        else {
            QString text = i18nc("@label",
                                 "The package \"%1\" has not been found among your software sources. "
                                 "Therefore, it cannot be installed. ",
                                 packageStr);
            QString title = i18nc("@title:window", "Package Not Found");
            KMessageBox::error(this, text, title);
            close();
        }
    }
```

#### AUTO 


```{c}
auto mapIter = actionMap.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Package *package : d->packages) {
        int flags = package->state();
        std::string fullName = package->packageIterator()->FullName();
        // Cannot have any of these flags simultaneously
        int status = flags & (Package::ToKeep |
                              Package::NewInstall |
                              Package::ToReInstall |
                              Package::ToUpgrade |
                              Package::ToDowngrade |
                              Package::ToRemove);
        switch (status) {
           case Package::NewInstall:
               packageList.insert(fullName.c_str(), Package::ToInstall);
               break;
           case Package::ToReInstall:
               packageList.insert(fullName.c_str(), Package::ToReInstall);
               break;
           case Package::ToUpgrade:
               packageList.insert(fullName.c_str(), Package::ToUpgrade);
               break;
           case Package::ToDowngrade:
               packageList.insert(QString(fullName.c_str()) % ',' % package->availableVersion(), Package::ToDowngrade);
               break;
           case Package::ToRemove:
               if(flags & Package::ToPurge) {
                   packageList.insert(fullName.c_str(), Package::ToPurge);
               } else {
                   packageList.insert(fullName.c_str(), Package::ToRemove);
               }
               break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Transaction *trans : m_queue)
        queued << trans->transactionId();
```

#### AUTO 


```{c}
auto Ver = d->packageIter.VersionList();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : logFiles) {
        fullPath = directoryPath % '/' % file;
        if (fullPath.contains(QLatin1String("history"))) {
            if (fullPath.endsWith(QLatin1String(".gz"))) {
                QProcess gunzip;
                gunzip.start(QLatin1String("gunzip"), QStringList() << QLatin1String("-c") << fullPath);
                gunzip.waitForFinished();

                data.append(gunzip.readAll());
            } else {
                QFile historyFile(fullPath);

                if (historyFile.open(QIODevice::ReadOnly | QIODevice::Text)) {
                    data.append(historyFile.readAll());
                }
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SourceEntryList &oneList : d->list.values()) {
        to_return.append(oneList);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &pinName : pinFiles) {
            QString pinPath;
            if (!pinName.startsWith(QLatin1Char('/'))) {
                pinPath = dir % pinName;
            } else {
                pinPath = pinName;
            }

            if (!QFile::exists(pinPath))
                continue;

            // Open to get a file name
            QTemporaryFile tempFile;
            if (!tempFile.open()) {
                return false;
            }
            tempFile.close();

            QString tempFileName = tempFile.fileName();
            FILE *out = fopen(tempFileName.toStdString().c_str(),"w");
            if (!out) {
                return false;
            }

            FileFd Fd(pinPath.toUtf8().data(), FileFd::ReadOnly);

            pkgTagFile tagFile(&Fd);
            if (_error->PendingError()) {
                return false;
            }

            pkgTagSection tags;
            while (tagFile.Step(tags)) {
                QString name = QLatin1String(tags.FindS("Package").c_str());

                if (name.isEmpty()) {
                    return false;
                }

                // Include all but the matching name in the new pinfile
                if (name != package->name()) {
                    TFRewriteData tfrd;
                    tfrd.Tag = 0;
                    tfrd.Rewrite = 0;
                    tfrd.NewTag = 0;
                    TFRewrite(out, tags, TFRewritePackageOrder, &tfrd);
                    fprintf(out, "\n");
                }
            }

            if (!tempFile.open()) {
                return false;
            }

            pinDocument = tempFile.readAll();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (qreal modifier : modifiers) {
            m_steps.append((qreal)begin + ((qreal)end - (qreal)begin) * modifier);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QApt::SourceEntry &one : entries ) {
        qDebug() << one.file() << ": Entry " << one.toString();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SourceEntry &listEntry : entries(sourceFile)) {
        to_return.append(listEntry.toString() + '\n');
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &pinName : pinFiles) {
            QString pinPath;
            if (!pinName.startsWith(QLatin1Char('/'))) {
                pinPath = dir % pinName;
            } else {
                pinPath = pinName;
            }

            if (!QFile::exists(pinPath))
                continue;

            // Open to get a file name
            QTemporaryFile tempFile;
            if (!tempFile.open()) {
                return false;
            }
            tempFile.close();

            QString tempFileName = tempFile.fileName();
            FILE *out = fopen(tempFileName.toUtf8(), "w");
            if (!out) {
                return false;
            }

            FileFd Fd(pinPath.toUtf8().data(), FileFd::ReadOnly);

            pkgTagFile tagFile(&Fd);
            if (_error->PendingError()) {
                fclose(out);
                return false;
            }

            pkgTagSection tags;
            while (tagFile.Step(tags)) {
                QString name = QLatin1String(tags.FindS("Package").c_str());

                if (name.isEmpty()) {
                    return false;
                }

                // Include all but the matching name in the new pinfile
                if (name != package->name()) {
                    TFRewriteData tfrd;
                    tfrd.Tag = 0;
                    tfrd.Rewrite = 0;
                    tfrd.NewTag = 0;
                    TFRewrite(out, tags, TFRewritePackageOrder, &tfrd);
                    fprintf(out, "\n");
                }
            }
            fclose(out);

            if (!tempFile.open()) {
                return false;
            }

            pinDocument = tempFile.readAll();
        }
```

#### AUTO 


```{c}
auto iter = changes.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (std::string &arch : archs)
         archList.append(QString::fromStdString(arch));
```

#### RANGE FOR STATEMENT 


```{c}
for (const SourceEntry &item : this->entries(entryForFile)) {
        if (entry == item) {
            return;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : sourceFiles) {
        if (!file.isNull() && !file.isEmpty() ) {
            load(file);
        }
    }
```

#### AUTO 


```{c}
auto iter = propertyMap.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Package *package : packages) {
        std::string fullName = package->packageIterator().FullName();
        packageList.insert(QString::fromStdString(fullName), Package::ToRemove);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (AptLock *lock : m_locks) {
        lock->release();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Package *pkg: d->packages) {
        state.append(pkg->state());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SourceEntry &item : this->entries()) {
        if (entry == item)
            return;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& file : partsDir.entryList(QStringList() << "*.list")) {
        sourceFiles.append(partsDir.filePath(file));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto dep : depGroup) {
            QCOMPARE(dep.packageName(), field);
            QVERIFY(dep.multiArchAnnotation().isEmpty());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Package *package : d->packages) {
        int flags = package->state();
        std::string fullName = package->packageIterator().FullName();
        // Cannot have any of these flags simultaneously
        int status = flags & (Package::IsManuallyHeld |
                              Package::NewInstall |
                              Package::ToReInstall |
                              Package::ToUpgrade |
                              Package::ToDowngrade |
                              Package::ToRemove);
        switch (status) {
        case Package::IsManuallyHeld:
            packageList.insert(fullName.c_str(), Package::Held);
            break;
        case Package::NewInstall:
            if (!(flags & Package::IsAuto)) {
                packageList.insert(fullName.c_str(), Package::ToInstall);
            }
            break;
        case Package::ToReInstall:
            packageList.insert(fullName.c_str(), Package::ToReInstall);
            break;
        case Package::ToUpgrade:
            packageList.insert(fullName.c_str(), Package::ToUpgrade);
            break;
        case Package::ToDowngrade:
            packageList.insert(QString(fullName.c_str()) % ',' % package->availableVersion(), Package::ToDowngrade);
            break;
        case Package::ToRemove:
            if(flags & Package::ToPurge) {
                packageList.insert(fullName.c_str(), Package::ToPurge);
            } else {
                packageList.insert(fullName.c_str(), Package::ToRemove);
            }
            break;
        }
    }
```

