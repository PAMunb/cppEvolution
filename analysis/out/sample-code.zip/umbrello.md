#### AUTO 


```{c}
auto label = new QLabel(i18n("Stereotype name:"));
```

#### AUTO 


```{c}
auto func_name(int x, int y) -> int;
```

#### AUTO 


```{c}
auto* core = qobject_cast<TestCore*>(Core::m_self);
```

#### AUTO 


```{c}
auto classContext = classDec->internalContext();
```

#### AUTO 


```{c}
const auto& typeToImport
```

#### DECLTYPE 


```{c}
decltype((c)) f = c;
```

#### AUTO 


```{c}
auto some_strange_callable_type = std::bind(&some_function, _2, _1, some_object);
```

#### AUTO 


```{c}
auto folder = item->folder();
```

#### AUTO 


```{c}
auto a = v[0];
```

#### AUTO 


```{c}
auto doc = documentationForUrl(url, url.toString());
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString& match) {
                return QStringLiteral("List[%1]").arg(fixTypeName(match));
            }
```

#### AUTO 


```{c}
const auto& fixer
```

#### AUTO 


```{c}
auto features = TopDUContext::AllDeclarationsAndContexts;
```

#### AUTO 


```{c}
auto declarations = currentContext()->parentContext()->localDeclarations();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& typeToImport: findIncludeVector) {
        for (const auto& type: typeToImport.types) {
            if (fixedTypeName.contains(type)) {
                return typeToImport.import;
            }
        }
    }
```

#### AUTO 


```{c}
const auto document = IndexedString(QUrl(QStringLiteral("file:///internal/BigTestFile.php")));
```

#### AUTO 


```{c}
auto SomeStruct::func_name(int x, int y) -> int {
    return x + y;
}
```

#### AUTO 


```{c}
const auto& type
```

#### DECLTYPE 


```{c}
decltype(0) g;
```

#### AUTO 


```{c}
auto doc = documentationForUrl(url, QString());
```

#### DECLTYPE 


```{c}
decltype(some_int) other_integer_variable = 5;
```

#### CONST EXPRESSION 


```{c}
constexpr double earth_gravitational_acceleration = 9.8;
```

#### AUTO 


```{c}
static const auto constructId = IndexedIdentifier(Identifier(QStringLiteral("__construct")));
```

#### LAMBDA EXPRESSION 


```{c}
[phpSupport] {
            qCDebug(PHP) << "Initializing internal function file" << internalFunctionFile();
            ParseJob internalJob(internalFunctionFile(), phpSupport);
            internalJob.setMinimumFeatures(TopDUContext::AllDeclarationsAndContexts);
            internalJob.run({}, nullptr);
            Q_ASSERT(internalJob.success());
        }
```

#### AUTO 


```{c}
auto trait = dynamic_cast<TraitMemberAliasDeclaration*>(declaration)
```

#### AUTO 


```{c}
auto phpLangPlugin = ICore::self()->languageController()->language(QStringLiteral("Php"));
```

#### AUTO 


```{c}
const auto name = m_content.midRef(nameStart, pos - nameStart);
```

#### AUTO 


```{c}
auto features = TopDUContext::AllDeclarationsContextsAndUses;
```

#### CONST EXPRESSION 


```{c}
constexpr ConstExprConstructorDeclaration(QString &param);
```

#### AUTO 


```{c}
auto* n = new IndexedContainer(*this);
```

#### AUTO 


```{c}
auto superclass = std::next(std::begin(superclasses));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& fixer: fixContainerTypes) {
        auto result = fixer.re.match(string).captured(1);
        if (!result.isEmpty()) {
            return fixer.fix(result);
        }
    }
```

#### AUTO 


```{c}
auto it2 = tempStorage.rbegin();
```

#### AUTO 


```{c}
auto other_variable = 5;
```

#### AUTO 


```{c}
auto &dec
```

#### AUTO 


```{c}
auto imports = currentContext()->parentContext()->importedParentContexts();
```

#### AUTO 


```{c}
auto label = new QLabel(i18n("Object name:"));
```

#### AUTO 


```{c}
static const auto destructId = IndexedIdentifier(Identifier(QStringLiteral("__destruct")));
```

#### RANGE FOR STATEMENT 


```{c}
for( const DUContext::Import& ctx : imports ) {
            DUContext* import = ctx.context(topContext());
            if(import->type() == DUContext::Class) {
                ClassDeclaration* importedClass = dynamic_cast<ClassDeclaration*>(import->owner());
                if(importedClass) {
                    if(importedClass->prettyName().str() == "ArrayAccess" && importedClass->classType() == ClassDeclarationData::ClassType::Interface && !import->parentContext()->owner()) {
                        arrayAccess = importedClass;
                    }
                }
            }
        }
```

#### AUTO 


```{c}
const auto indexed = indexedIdentifier();
```

#### DECLTYPE 


```{c}
decltype(v[1]) b = 1;
```

#### AUTO 


```{c}
auto top = file.topContext();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& type: typeToImport.types) {
            if (fixedTypeName.contains(type)) {
                return typeToImport.import;
            }
        }
```

#### AUTO 


```{c}
auto member = dynamic_cast<TraitMemberAliasDeclaration*>(m_declaration.data())
```

#### LAMBDA EXPRESSION 


```{c}
[core]() {
            core->d->languageController->backgroundParser()->resume();
        }
```

#### AUTO 


```{c}
auto adding_func(const Lhs &lhs, const Rhs &rhs) -> decltype(lhs+rhs) {return lhs + rhs;}
```

#### CONST EXPRESSION 


```{c}
constexpr double moon_gravitational_acceleration = earth_gravitational_acceleration / 6.0;
```

#### AUTO 


```{c}
const auto &phpSupport = languageSupport();
```

#### AUTO 


```{c}
auto context = dynamic_cast<Php::CodeCompletionContext*>(m_completionContext.data());
```

#### RANGE FOR STATEMENT 


```{c}
for(auto &dec : declarations) {
                if(dec->isFunctionDeclaration()) {
                    QualifiedIdentifier func = dec->qualifiedIdentifier();
                    QString funcname = func.last().identifier().str();
                    if(funcname == "offsetexists" || funcname == "offsetget" || funcname == "offsetset" || funcname == "offsetunset") {
                        noOfFunc++;
                    }
                }
            }
```

#### AUTO 


```{c}
const auto fixedTypeName = fixTypeName(string);
```

#### AUTO 


```{c}
auto projects = ICore::self()->projectController()->projects();
```

#### AUTO 


```{c}
auto member = dynamic_cast<TraitMethodAliasDeclaration*>(m_declaration.data())
```

#### AUTO 


```{c}
auto scope = context;
```

#### AUTO 


```{c}
auto c = 0;
```

#### AUTO 


```{c}
auto d = c;
```

#### DECLTYPE 


```{c}
decltype(c) e;
```

#### AUTO 


```{c}
auto result = fixer.re.match(string).captured(1);
```

