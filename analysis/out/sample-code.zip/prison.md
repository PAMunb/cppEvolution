#### AUTO 


```{c}
const auto img = code.paintImage({200, 200});
```

#### AUTO 


```{c}
auto stuffedData = bitStuffAndPad(inputData, (*propIt).codeWordSize);
```

#### AUTO 


```{c}
const auto &dblCode
```

#### AUTO 


```{c}
const auto majIdx = index / 8;
```

#### AUTO 


```{c}
const auto w_max = std::max(implicitWidth(), width());
```

#### AUTO 


```{c}
const auto matrix = writer.encode(input, 4, 1);
```

#### AUTO 


```{c}
const auto h_max = std::max(implicitHeight(), height());
```

#### LAMBDA EXPRESSION 


```{c}
[](aztec_code_t sym) {
        return sym.mode != Binary;
    }
```

#### AUTO 


```{c}
const auto img = m_barcode->toImage(m_barcode->minimumSize());
```

#### RANGE FOR STATEMENT 


```{c}
for (auto m : format_map) {
        if (m.format & formats) {
            f |= m.zxFormat;
        }
    }
```

#### AUTO 


```{c}
const auto x = (i % 2 == 0) ? x1 : x2;
```

#### AUTO 


```{c}
const auto x2 = x1 + 1;
```

#### AUTO 


```{c}
const auto isReallyBinary = std::any_of(b.begin(), b.end(), [](unsigned char c) {
            return std::iscntrl(c) && !std::isspace(c);
        });
```

#### AUTO 


```{c}
const auto segmentLength = FullMaxSize - 2 * y1 - 2 - (gridInMiddle ? 1 : 0);
```

#### AUTO 


```{c}
const auto img = code.paintImage({});
```

#### AUTO 


```{c}
const auto result = QImage(img, code->width+2*margin, code->width+2*margin, QImage::Format_ARGB32).copy();
```

#### AUTO 


```{c}
const auto binEndIt = std::find_if(it, end, [](aztec_code_t sym) {
        return sym.mode != Binary;
    });
```

#### AUTO 


```{c}
const auto trailingBits = res.size() % codeWordSize;
```

#### AUTO 


```{c}
const auto hasWideChars = std::any_of(zxRes.text().begin(), zxRes.text().end(), [](auto c) {
            return c > 255;
        });
```

#### AUTO 


```{c}
const auto propIt = std::lower_bound(aztec_layer_properties, aztec_layer_properties + 4, layerCount, [](const aztec_layer_property_t &lhs, int rhs) {
            return lhs.layer < rhs;
        });
```

#### AUTO 


```{c}
const auto b = m_content.toByteArray();
```

#### AUTO 


```{c}
const auto subIdx = m_size % 8;
```

#### AUTO 


```{c}
const auto res = rs.encode(input);
```

#### AUTO 


```{c}
const auto minIdx = index % 8;
```

#### AUTO 


```{c}
const auto binEndIt = std::find_if(it, end, [](aztec_code_t sym) { return sym.mode != Binary; });
```

#### AUTO 


```{c}
const auto inputData = aztecEncode(data().toLatin1());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &dblCode : aztec_code_double_symbols) {
                if (dblCode.c1 != c1 || dblCode.c2 != c2) {
                    continue;
                }
                codes.push_back(dblCode.sym);
                ++i;
                found = true;
            }
```

#### AUTO 


```{c}
auto it = data.begin();
```

#### AUTO 


```{c}
const auto scale = std::min(w_max / implicitWidth(), h_max / implicitHeight());
```

#### LAMBDA EXPRESSION 


```{c}
[](auto c) {
            return c < 20 && c != 0x0a && c != 0x0d;
        }
```

#### AUTO 


```{c}
const auto minSize = FullMaxSize - 2 * offset;
```

#### LAMBDA EXPRESSION 


```{c}
[](auto c) {
            return c > 255;
        }
```

#### AUTO 


```{c}
const auto segmentLength = CompactMaxSize - 2 * y1 - 2;
```

#### AUTO 


```{c}
const auto rsData = rs.encode(stuffedData);
```

#### LAMBDA EXPRESSION 


```{c}
[](auto c) {
            return c < 0x20 && c != 0x0a && c != 0x0d;
        }
```

#### AUTO 


```{c}
const auto img = m_barcode->toImage(QSizeF(w_max, h_max));
```

#### AUTO 


```{c}
const auto res= code.bitStuffAndPad(input, codeWordSize);
```

#### AUTO 


```{c}
auto y = i / 2 + y1;
```

#### AUTO 


```{c}
const auto p = zxRes.position();
```

#### AUTO 


```{c}
const auto width = bits.size() + 2 * QuietZone;
```

#### AUTO 


```{c}
const auto rsWordCount = availableBits / (*propIt).codeWordSize - codewordCount;
```

#### AUTO 


```{c}
const auto size = frameDataSize();
```

#### AUTO 


```{c}
const auto res = code.bitStuffAndPad(input, codeWordSize);
```

#### AUTO 


```{c}
auto m = result[m_symCount - 1] ^ input.valueAtMSB(i * m_symSize, m_symSize);
```

#### AUTO 


```{c}
auto backIt = it;
```

#### AUTO 


```{c}
const auto h_max = std::max(minimumHeight(), height());
```

#### LAMBDA EXPRESSION 


```{c}
[](const aztec_layer_property_t &lhs, int rhs) {
            return lhs.layer < rhs;
        }
```

#### AUTO 


```{c}
const auto x = (w_max - img.width()) / 2;
```

#### AUTO 


```{c}
const auto hasControlChars = std::any_of(zxRes.text().begin(), zxRes.text().end(), [](auto c) {
            return c < 0x20 && c != 0x0a && c != 0x0d;
        });
```

#### AUTO 


```{c}
const auto c2 = data.at(index + 1);
```

#### AUTO 


```{c}
const auto offset = aztecCompactLayerOffset[layerCount - 1];
```

#### AUTO 


```{c}
const auto bits = encode(data().isEmpty() ? byteArrayData() : data().toLatin1());
```

#### AUTO 


```{c}
const auto it = std::find_if(std::begin(format_map), std::end(format_map), [format](auto m) {
        return m.zxFormat == format;
    });
```

#### AUTO 


```{c}
auto res = ScanResultPrivate::get(scanResult);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QVideoFrame &frame) {
        d->newFrame(frame, frame.surfaceFormat().scanLineDirection() == QVideoFrameFormat::BottomToTop);
    }
```

#### AUTO 


```{c}
const auto y = (h_max - img.height()) / 2;
```

#### AUTO 


```{c}
auto newMode = aztecCodeLatchTo(currentMode, Binary, &result);
```

#### AUTO 


```{c}
const auto x = (width() - w) / 2;
```

#### AUTO 


```{c}
const auto x2 = gridInMiddle ? x1 + 2 : x1 + 1;
```

#### AUTO 


```{c}
const auto v = code.aztecEncode(input);
```

#### AUTO 


```{c}
const auto nextB = isInCodeSetB(data.at(index));
```

#### AUTO 


```{c}
const auto op = opForData(data, i, currentSet);
```

#### AUTO 


```{c}
auto it = codes.begin();
```

#### AUTO 


```{c}
const auto rsWordCount =  availableBits / (*propIt).codeWordSize - codewordCount;
```

#### LAMBDA EXPRESSION 


```{c}
[](unsigned char c) {
            return std::iscntrl(c) && !std::isspace(c);
        }
```

#### AUTO 


```{c}
const auto latchCode = aztec_latch_codes[currentMode][targetMode];
```

#### AUTO 


```{c}
const auto bits = encode(data().toLatin1());
```

#### AUTO 


```{c}
const auto v = code.encode(input);
```

#### AUTO 


```{c}
const auto gridInMiddle = (x1 - FullRadius) % FullGridInterval == 0;
```

#### AUTO 


```{c}
const auto b = byteArrayData();
```

#### AUTO 


```{c}
const auto minSize = CompactMaxSize - 2 * offset;
```

#### AUTO 


```{c}
const auto newMode = aztecNextMode(currentMode, it, codes.end(), tryShift);
```

#### AUTO 


```{c}
const auto x1 = aztecFullLayerOffset[layer];
```

#### AUTO 


```{c}
const auto hasControlChars = std::any_of(zxRes.text().begin(), zxRes.text().end(), [](auto c) {
            return c < 20 && c != 0x0a && c != 0x0d;
        });
```

#### AUTO 


```{c}
const auto op = opForData(data, 0, CodeSetUnknown);
```

#### AUTO 


```{c}
auto currentSet = op.set;
```

#### AUTO 


```{c}
const auto dblCode = aztec_code_double_symbols[j];
```

#### AUTO 


```{c}
const auto logmod = (1 << m_symSize) - 1;
```

#### AUTO 


```{c}
const auto offset = aztecFullLayerOffset[layerCount - 1];
```

#### AUTO 


```{c}
const auto moduleSize = size.width() / width;
```

#### AUTO 


```{c}
const auto symbol = symbolForCharacter(data, i, op.set);
```

#### AUTO 


```{c}
const auto size = m_barcode->preferredSize(QGuiApplication::primaryScreen()->devicePixelRatio());
```

#### AUTO 


```{c}
auto m
```

#### LAMBDA EXPRESSION 


```{c}
[](aztec_code_t sym) { return sym.mode != Binary; }
```

#### AUTO 


```{c}
const auto result =
        QImage(img, code->width + 2 * margin, code->width + 2 * margin, QImage::Format_ARGB32).copy();
```

#### AUTO 


```{c}
const auto x1 = aztecCompactLayerOffset[layer];
```

#### AUTO 


```{c}
const auto img = code->toImage(code->preferredSize(1));
```

#### AUTO 


```{c}
const auto nextA = isInCodeSetA(data.at(index));
```

#### AUTO 


```{c}
const auto inputData = aztecEncode(data().isEmpty() ? byteArrayData() : data().toLatin1());
```

#### AUTO 


```{c}
const auto y = (height() - h) / 2;
```

#### AUTO 


```{c}
const auto c1 = data.at(index);
```

#### AUTO 


```{c}
const auto length = std::distance(it, binEndIt);
```

#### AUTO 


```{c}
auto it = modeData.begin();
```

#### LAMBDA EXPRESSION 


```{c}
[format](auto m) {
        return m.zxFormat == format;
    }
```

#### AUTO 


```{c}
const auto img = code->toImage(code->minimumSize());
```

#### AUTO 


```{c}
const auto w_max = std::max(minimumWidth(), width());
```

#### AUTO 


```{c}
auto i = 1;
```

#### AUTO 


```{c}
const auto srcRect = img->rect().adjusted(offset, offset, -offset, -offset);
```

#### AUTO 


```{c}
const auto h = scale * implicitHeight();
```

#### AUTO 


```{c}
auto it = begin;
```

#### AUTO 


```{c}
auto it = nextSym;
```

#### AUTO 


```{c}
const auto y1 = x1;
```

#### LAMBDA EXPRESSION 


```{c}
[this](const ScanResult &result) {
            d->setResult(this, result);
        }
```

#### AUTO 


```{c}
const auto w = scale * implicitWidth();
```

