#### RANGE FOR STATEMENT 


```{c}
for(Peer::Ptr p: qAsConst(d->peer_map))
			p->setGroupIDs(up, down);
```

#### RANGE FOR STATEMENT 


```{c}
for (QString tr : QUrlQuery(url).allQueryItemValues("tr", QUrl::FullyDecoded))
        result << QUrl(tr.replace(QLatin1Char('+'), QLatin1Char(' ')));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString & ip: ips)
			d->listen(ip,port);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString & s : dfiles)
        {
            // add a TorrentFile to the list
            Uint64 fs = bt::FileSize(target + dir + s);
            TorrentFile f(0, cnt, dir + s, tot_size, fs, chunk_size);
            files.append(f);
            // update total size
            tot_size += fs;
            cnt++;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const net::ServerSocket::Ptr& sock : qAsConst(d->sockets))
            sock->moveToThread(d->utp_thread);
```

#### RANGE FOR STATEMENT 


```{c}
for (WebSeed* ws : qAsConst(webseeds))
        ws->reset();
```

#### RANGE FOR STATEMENT 


```{c}
for (Peer::Ptr peer : qAsConst(d->peer_map)) {
        if (peer->isSeeder())
            peer->kill();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Peer::Ptr p : qAsConst(d->peer_map)) {
        if (!p->isKilled()) {
            p->setPexEnabled(on);
            bt::Uint16 port = ServerInterface::getPort();
            p->sendExtProtHandshake(port, d->tor.getMetaData().size(), d->partial_seed);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (net::ServerSocket::Ptr sock: qAsConst(d->sockets))
				sock->setWriteNotificationsEnabled(true);
```

#### RANGE FOR STATEMENT 


```{c}
for (Uint32 fidx : qAsConst(files)) {
        TorrentFile &tf = tor.getFile(fidx);
        if (!tf.isPreExistingFile())
            return false;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (WebSeed* ws : qAsConst(webseeds)) {
        rate += ws->getDownloadRate();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const UPnPService &os : qAsConst(d->services)) {
        if (s.servicetype == os.servicetype)
            return;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Peer::Ptr peer : qAsConst(peer_map)) {
        if (peer->getStats().aca_score <= -5.0 && peer->getStats().aca_score > -50.0) {
            Out(SYS_GEN | LOG_DEBUG) << "Killing bad peer, to make room for other peers" << endl;
            peer->kill();
            return true;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Peer::Ptr& peer : ppl)
            tmon->peerAdded(peer.data());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& s: sl)
            enc.write(s.toUtf8());
```

#### RANGE FOR STATEMENT 


```{c}
for (WebSeed* ws : qAsConst(webseeds)) {
        ws->onExcluded(from, to);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (WebSeed* ws: qAsConst(webseeds))
			{
				ws->cancel();
			}
```

#### RANGE FOR STATEMENT 


```{c}
for (const UPnPService& s : qAsConst(services))
        {
            if(s.servicetype.contains("WANIPConnection") || s.servicetype.contains("WANPPPConnection"))
            {
                QString action = "GetExternalIPAddress";
                QString comm = SOAP::createCommand(action, s.servicetype);
                HTTPRequest* r = sendSoapQuery(comm, s.servicetype + "#" + action, s.controlurl);
                connect(r, SIGNAL(result(HTTPRequest*)), parent, SLOT(getExternalIPResult(HTTPRequest*)));
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl& url : qAsConst(custom_trackers))
			stream << url.toDisplayString() << ::endl;
```

#### RANGE FOR STATEMENT 


```{c}
for(Peer::Ptr peer: qAsConst(peer_map))
		{
			if(peer->getStats().aca_score <= -5.0 && peer->getStats().aca_score > -50.0)
			{
				Out(SYS_GEN | LOG_DEBUG) << "Killing bad peer, to make room for other peers" << endl;
				peer->kill();
				return true;
			}
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (const UPnPService &s : qAsConst(d->services)) {
        if (s.servicetype.contains("WANIPConnection") || s.servicetype.contains("WANPPPConnection")) {
            d->forward(&s, port);
            found = true;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (ExitOperation* op: qAsConst(exit_ops))
			delete op;
```

#### RANGE FOR STATEMENT 


```{c}
for (Peer::Ptr p : qAsConst(d->peer_map)) {
        const net::Address &addr = p->getAddress();
        addPotentialPeer(addr, false);
        p->kill();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (PeerInterface *p : qAsConst(peers)) {
        sendChunk(p);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const bt::DHTNode & n : qAsConst(nodes))
            curr_task->addDHTNode(n.ip, n.port);
```

#### RANGE FOR STATEMENT 


```{c}
for (const BlockListInterface *bl : qAsConst(blocklists)) {
        if (bl->blocked(addr))
            return false;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (WebSeed* ws: qAsConst(webseeds))
				{
					if (ws->inCurrentRange(p.getIndex()))
						ws->chunkDownloaded(p.getIndex());
				}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString & addr : ips) {
        d->listen(addr);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &s : subdirs) {
        QString sd = dir + s;
        if (!sd.endsWith(bt::DirSeparator()))
            sd += bt::DirSeparator();
        buildFileList(sd);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Peer::Ptr& p : qAsConst(d->peer_map)) {
            const net::Address & addr = p->getAddress();
            out << addr.toString() << " " << (unsigned short)addr.port() << Qt::endl;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &key : qAsConst(keys)) {
            QVERIFY(st.hasKey(key));
            QVERIFY(st.readString(key) == values[idx++]);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BlockListInterface* bl : qAsConst(blocklists)) {
        if (bl->blocked(addr))
            return false;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Forwarding& fwd : qAsConst(d->fwds)) {
        visitor->forwarding(fwd.port, fwd.pending_req != 0, fwd.service);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(Peer::Ptr p: qAsConst(d->peer_map))
		{
			p->unpause();
			if(p->hasWantedChunks(d->wanted_chunks))  // send interested when it has wanted chunks
				p->sendInterested();
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (const Peer::Ptr& p : qAsConst(d->peer_map)) {
        if (p->getPeerID() == peer_id)
            return true;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (net::ServerSocket::Ptr sock : qAsConst(d->sockets)) {
        sock->setReadNotificationsEnabled(true);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (net::ServerSocket::Ptr sock : qAsConst(d->sockets))
            sock->setWriteNotificationsEnabled(true);
```

#### RANGE FOR STATEMENT 


```{c}
for (WebSeed* ws: qAsConst(webseeds))
		{
			if (ws->getUrl() == url)
				return 0;
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (Uint32 fidx : qAsConst(files)) {
        TorrentFile& tf = tor.getFile(fidx);
        if (!tf.isPreExistingFile())
            return false;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &u: qAsConst(webseeds))
            {
                enc.write(u.toDisplayString().toUtf8());
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (WebSeed* ws : qAsConst(webseeds))
        ws->cancel();
```

#### RANGE FOR STATEMENT 


```{c}
for (UnackedPacket &pkt : unacked_packets) {
            if (!pkt.retransmitted || now - pkt.send_time > conn->currentTimeout()) {
                conn->retransmit(pkt.packet, pkt.seq_nr);
                pkt.send_time = bt::Now();
                pkt.retransmitted = true;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (net::ServerSocket::Ptr sock : qAsConst(d->sockets))
                sock->setWriteNotificationsEnabled(true);
```

#### RANGE FOR STATEMENT 


```{c}
for (const UPnPService& s : qAsConst(d->services))
        {
            if(s.servicetype.contains("WANIPConnection") || s.servicetype.contains("WANPPPConnection"))
            {
                d->forward(&s, port);
                found = true;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (WebSeed* ws: qAsConst(webseeds))
		{
			if (ws->isUserCreated())
				out << ws->getUrl().toDisplayString() << ::endl;
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (UPnPRouter* r: qAsConst(d->routers))
		{
			fout << r->getServer() << Qt::endl;
			fout << r->getLocation().toString() << Qt::endl;
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (WebSeed* ws: qAsConst(webseeds))
		{
			if (ws->getUrl() == url && ws->isUserCreated())
			{
				PtrMap<Uint32,WebSeed>::iterator i = webseeds_chunks.begin();
				while (i != webseeds_chunks.end())
				{
					if (i->second == ws)
						i = webseeds_chunks.erase(i);
					else
						++i;
				}
				webseeds.removeAll(ws);
				delete ws;
				return true;
			}
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (const KBucket::Ptr &b : qAsConst(buckets)) {
        b->findKClosestNodes(kns);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (UnackedPacket & pkt : unacked_packets)
			{
				if (!pkt.retransmitted || now - pkt.send_time > conn->currentTimeout())
				{
					conn->retransmit(pkt.packet, pkt.seq_nr);
					pkt.send_time = bt::Now();
					pkt.retransmitted = true;
				}
			}
```

#### RANGE FOR STATEMENT 


```{c}
for (WebSeed *ws : qAsConst(webseeds)) {
        rate += ws->getDownloadRate();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KBucketEntry &i : qAsConst(entries)) {
        kns.tryInsert(i);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Peer::Ptr& peer : qAsConst(d->peer_map)) {
        if (!peer->isSeeder())
            cnt++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Forwarding &fwd : qAsConst(d->fwds)) {
        visitor->forwarding(fwd.port, fwd.pending_req != 0, fwd.service);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (WebSeed* ws: qAsConst(webseeds))
			{
				if (ws->busy() && ws->isEnabled())
				{
					ws->cancel();
				}
			}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString & addr: possible)
		{
			d->bind(net::Address(addr, p));
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (Peer::Ptr p : qAsConst(d->peer_map)) {
        if ((PieceDownloader*)p->getPeerDownloader() == pd)
            return p;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (WebSeed *ws : qAsConst(webseeds)) {
                // tell all webseeds a chunk is downloaded
                if (ws->inCurrentRange(c->getIndex()))
                    ws->chunkDownloaded(c->getIndex());
            }
```

#### AUTO 


```{c}
auto i = dlrate.begin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const mse::EncryptedPacketSocket::Ptr& s : qAsConst(p)) {
        newConnection(s);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Solid::Device &dev : devs) {
            const Solid::StorageAccess *sa = dev.as<Solid::StorageAccess>();
            if (sa->isAccessible()) {
                QVERIFY(bt::MountPoint(sa->filePath()) == sa->filePath());

                QString path = sa->filePath() + "/some/random/path/test.foobar";
                Out(SYS_GEN | LOG_DEBUG) << "Testing " << path << endl;
                QVERIFY(bt::MountPoint(path) == sa->filePath());
            }
        }
```

#### AUTO 


```{c}
auto i = children.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for(const Peer::Ptr& p: qAsConst(d->peer_map))
		{
			if(p->getPeerID() == peer_id)
				return true;
		}
```

#### RANGE FOR STATEMENT 


```{c}
for(Peer::Ptr p: qAsConst(d->peer_map))
		{
			const net::Address & addr = p->getAddress();
			addPotentialPeer(addr, false);
			p->kill();
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& t: qAsConst(trackers))
            {
                enc.beginList();
                enc.write(t.section(',', 0, 0).toUtf8());
                enc.write((Uint32)t.section(',', 1, 1).toInt());
                enc.end();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (WebSeed *ws : qAsConst(webseeds)) {
        if (ws->getUrl() == url && ws->isUserCreated()) {
            PtrMap<Uint32, WebSeed>::iterator i = webseeds_chunks.begin();
            while (i != webseeds_chunks.end()) {
                if (i->second == ws)
                    i = webseeds_chunks.erase(i);
                else
                    ++i;
            }
            webseeds.removeAll(ws);
            delete ws;
            return true;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &addr : possible) {
        d->bind(net::Address(addr, p));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QByteArray & b: qAsConst(unencoded_path))
		{
			path += codec->toUnicode(b);
			if (idx < unencoded_path.size() - 1)
				path += bt::DirSeparator();
			idx++;
		}
```

#### RANGE FOR STATEMENT 


```{c}
for(Peer::Ptr p: qAsConst(d->peer_map))
		{
			if(!p->isKilled())
			{
				p->setPexEnabled(on);
				bt::Uint16 port = ServerInterface::getPort();
				p->sendExtProtHandshake(port, d->tor.getMetaData().size(), d->partial_seed);
			}
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (const UPnPService& s : qAsConst(services))
        {
            if(s.servicetype.contains("WANIPConnection") || s.servicetype.contains("WANPPPConnection"))
            {
                QString action = "GetExternalIPAddress";
                QString comm = SOAP::createCommand(action, s.servicetype);
                HTTPRequest* r = sendSoapQuery(comm, s.servicetype + "#" + action, s.controlurl);
                connect(r, &HTTPRequest::result, parent, &UPnPRouter::getExternalIPResult);
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Peer::Ptr& p : qAsConst(d->peer_map)) {
        visitor.visit(p);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (HTTPRequest* r : qAsConst(active_reqs))
#endif   
        {
            r->deleteLater();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &s : names) {
        QByteArray encoded = QFile::encodeName(s);
        assembled += (encoded.length() < NAME_MAX) ? s : ShortenName(s, extra_number);
        if (cnt < names.count() - 1)
            assembled += QLatin1Char('/');
        cnt++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (PieceDownloader* pd : qAsConst(pdown))
        r += pd->getDownloadRate();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Forwarding& fwd : qAsConst(d->fwds))
        {
            visitor->forwarding(fwd.port, fwd.pending_req != 0, fwd.service);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Tracker* tracker: qAsConst(trackers))
		{
			tracker->stop();
			delete tracker;
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (WebSeed* ws : qAsConst(webseeds)) {
        WebSeedChunkDownload* cd = ws->currentChunkDownload();
        if (cd)
            tmon->downloadStarted(cd);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KBucketEntry& i: qAsConst(entries))
		{
			kns.tryInsert(i);
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (const Request & r : qAsConst(requests))
            peer->sendReject(r);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Forwarding& fw : qAsConst(fwds)) {
        if (fw.pending_req == r) {
            found = true;
            break;
        }
        idx++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &s : dfiles) {
        // add a TorrentFile to the list
        Uint64 fs = bt::FileSize(target + dir + s);
        TorrentFile f(nullptr, cnt, dir + s, tot_size, fs, chunk_size);
        files.append(f);
        // update total size
        tot_size += fs;
        cnt++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const bt::DHTNode & n: qAsConst(nodes))
				curr_task->addDHTNode(n.ip,n.port);
```

#### RANGE FOR STATEMENT 


```{c}
for(const Peer::Ptr& peer: qAsConst(d->peer_map))
		{
			if(peer->isSeeder())
				cnt++;
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& t: qAsConst(trackers))
                {
                    enc.beginList();
                    enc.write(t.toUtf8());
                    enc.end();
                }
```

#### AUTO 


```{c}
auto it = lst.begin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Peer::Ptr &peer : ppl)
            tmon->peerAdded(peer.data());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString & mp: mount_points)
        {
            if (path.startsWith(mp) && (mount_point.isEmpty() || mp.startsWith(mount_point)))
			{
				mount_point = mp;
			}
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (const UPnPService& os : qAsConst(d->services))
#endif
        {
            if(s.servicetype == os.servicetype)
                return;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (ExitOperation* op : qAsConst(exit_ops))
        delete op;
```

#### RANGE FOR STATEMENT 


```{c}
for (const utp::Connection::WPtr& conn : qAsConst(to_close)) {
        Connection::Ptr c = conn.toStrongRef();
        if (c)
            c->close();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (WebSeed* ws: qAsConst(webseeds))
			ws->reset();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QHostAddress &addr : addrs) {
            if (addr.protocol() == QAbstractSocket::IPv6Protocol && addr != QHostAddress::LocalHostIPv6
                && !addr.isInSubnet(QHostAddress(QStringLiteral("FE80::")), 64))
                return addr.toString();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const UPnPService& s : qAsConst(services)) {
        if (s.servicetype.contains("WANIPConnection") || s.servicetype.contains("WANPPPConnection")) {
            QString action = "GetExternalIPAddress";
            QString comm = SOAP::createCommand(action, s.servicetype);
            HTTPRequest* r = sendSoapQuery(comm, s.servicetype + "#" + action, s.controlurl);
            connect(r, &HTTPRequest::result, parent, &UPnPRouter::getExternalIPResult);
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Forwarding& fw : qAsConst(fwds))
        {
            if(fw.pending_req == r)
            {
                found = true;
                break;
            }
            idx++;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KBucket::Ptr &b : qAsConst(buckets)) {
        if (b->onTimeout(addr))
            return;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (PieceDownloader *pd : qAsConst(pdown)) {
        pd->release();
        sendCancels(pd);
        disconnect(pd, &PieceDownloader::timedout, this, &ChunkDownload::onTimeout);
        disconnect(pd, &PieceDownloader::rejected, this, &ChunkDownload::onRejected);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& s : subdirs) {
        QString sd = dir + s;
        if (!sd.endsWith(bt::DirSeparator()))
            sd += bt::DirSeparator();
        buildFileList(sd);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const Peer::Ptr& p: qAsConst(d->peer_map))
		{
			rate += p->getUploadRate();
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QHostAddress & addr: addrs)
			{
                if (addr.protocol() == QAbstractSocket::IPv6Protocol && addr != QHostAddress::LocalHostIPv6 && !addr.isInSubnet(QHostAddress(QStringLiteral("FE80::")), 64))
					return addr.toString();
			}
```

#### RANGE FOR STATEMENT 


```{c}
for (UPnPRouter* r: qAsConst(routers))
		{
			if (UrlCompare(r->getLocation(),location))
				return r;
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (const Solid::Device& dev: devs)
		{
			const Solid::StorageAccess* sa = dev.as<Solid::StorageAccess>();
			if (sa->isAccessible())
			{
				QVERIFY(bt::MountPoint(sa->filePath()) == sa->filePath());
			
				QString path = sa->filePath() + "/some/random/path/test.foobar";
				Out(SYS_GEN|LOG_DEBUG) << "Testing " << path << endl;
				QVERIFY(bt::MountPoint(path) == sa->filePath());
			}
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (WebSeed* ws : qAsConst(webseeds)) {
        if (ws->isUserCreated())
            out << ws->getUrl().toDisplayString() << Qt::endl;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Peer::Ptr &p : qAsConst(d->peer_map)) {
        visitor.visit(p);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &t : qAsConst(trackers)) {
            enc.beginList();
            enc.write(t.section(',', 0, 0).toUtf8());
            enc.write((Uint32)t.section(',', 1, 1).toInt());
            enc.end();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (WebSeed *ws : qAsConst(webseeds)) {
        if (ws->busy() && ws->inCurrentRange(chunk))
            return false;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (PieceDownloader* pd : qAsConst(piece_downloaders)) {
        if (!pd->isChoked()) {
            while (pd->canDownloadChunk()) {
                if (!downloadFrom(pd))
                    break;
                pd->setNearlyDone(false);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (UPnPRouter* r : qAsConst(d->routers)) {
        fout << r->getServer() << Qt::endl;
        fout << r->getLocation().toString() << Qt::endl;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (WebSeed* ws: qAsConst(webseeds))
		{
			ws->onExcluded(from,to);
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString & s : names) {
        QByteArray encoded = QFile::encodeName(s);
        if (encoded.length() >= NAME_MAX)
            return true;
        length += encoded.length();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : qAsConst(custom_trackers))
        stream << url.toDisplayString() << Qt::endl;
```

#### RANGE FOR STATEMENT 


```{c}
for (WebSeed* ws : qAsConst(webseeds)) {
        if (ws->getUrl() == url && ws->isUserCreated()) {
            PtrMap<Uint32, WebSeed>::iterator i = webseeds_chunks.begin();
            while (i != webseeds_chunks.end()) {
                if (i->second == ws)
                    i = webseeds_chunks.erase(i);
                else
                    ++i;
            }
            webseeds.removeAll(ws);
            delete ws;
            return true;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const KBucket::Ptr& b : qAsConst(buckets))
		{
			if(b->onTimeout(addr))
				return;
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (const TorrentFile& file : qAsConst(files))
            saveFile(enc, file);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &mp : mount_points) {
        if (path.startsWith(mp) && (mount_point.isEmpty() || mp.startsWith(mount_point))) {
            mount_point = mp;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (WebSeed* ws : qAsConst(webseeds)) {
        if (!ws->isEnabled())
            out << ws->getUrl().toDisplayString() << Qt::endl;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (WebSeed *ws : qAsConst(webseeds)) {
            ws->cancel();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (WebSeed *ws : qAsConst(webseeds)) {
        ws->onExcluded(from, to);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (WebSeed *ws : qAsConst(webseeds)) {
        WebSeedChunkDownload *cd = ws->currentChunkDownload();
        if (cd)
            tmon->downloadStarted(cd);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (WebSeed* ws : qAsConst(webseeds)) {
            if (!ws->busy() && ws->isEnabled() && ws->failedAttempts() < 3) {
                downloadFrom(ws);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(Peer::Ptr p: qAsConst(d->peer_map))
		{
			if((PieceDownloader*)p->getPeerDownloader() == pd)
				return p;
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (Peer::Ptr p : qAsConst(d->peer_map)) {
        if (p->getDownloadRate() == 0 && p->getUploadRate() == 0)
            p->kill();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Peer::Ptr& peer: ppl)
                tmon->peerAdded(peer.data());
```

#### RANGE FOR STATEMENT 


```{c}
for (HTTPRequest* r : qAsConst(active_reqs))
        {
            r->deleteLater();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(Peer::Ptr p: qAsConst(d->peer_map))
		{
			p->pause();
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& t : qAsConst(trackers)) {
                enc.beginList();
                enc.write(t.toUtf8());
                enc.end();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (Peer::Ptr p : ppl) {
        if (!poup && num_unchoked < num_slots) {
            p->sendUnchoke();
            num_unchoked++;
        } else if (num_unchoked < num_slots - 1 || p == poup) {
            p->sendUnchoke();
            if (p != poup)
                num_unchoked++;
        } else {
            p->choke();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (net::ServerSocket::Ptr sock: qAsConst(d->sockets))
			sock->setTOS(d->tos);
```

#### RANGE FOR STATEMENT 


```{c}
for (Peer::Ptr p: ppl)
		{
			if (!poup && num_unchoked < num_slots)
			{
				p->sendUnchoke();
				num_unchoked++;
			}
			else if (num_unchoked < num_slots - 1 || p == poup)
			{
				p->sendUnchoke();
				if (p != poup)
					num_unchoked++;
			}
			else
			{
				p->choke();
			}
		}
```

#### AUTO 


```{c}
auto i = data_packets.begin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const bt::DHTNode &n : qAsConst(nodes))
            curr_task->addDHTNode(n.ip, n.port);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : trackers_list) {
        Tracker *tracker;
        if (url.scheme() == QLatin1String("udp"))
            tracker = new UDPTracker(url, this, tor.getPeerID(), 0);
        else
            tracker = new HTTPTracker(url, this, tor.getPeerID(), 0);
        trackers << tracker;
        connect(tracker, &Tracker::peersReady, pman, &PeerManager::peerSourceReady);
        tracker->start();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Forwarding &fwd : qAsConst(d->fwds)) {
        visitor->forwarding(fwd.port, fwd.pending_req != nullptr, fwd.service);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DBItem & i : items) {
        //  Out(SYS_DHT|LOG_DEBUG) << "DHT: GetPeers returned item " << i->getAddress().toString() << endl;
        db->store(info_hash, i);
        // also add the items to the returned_items list
        returned_items.append(i);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray & b : qAsConst(unencoded_path)) {
        path += codec->toUnicode(b);
        if (idx < unencoded_path.size() - 1)
            path += bt::DirSeparator();
        idx++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (WebSeed* ws : qAsConst(webseeds)) {
            if (ws->busy() && ws->isEnabled()) {
                ws->cancel();
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString & addr: possible)
		{
			d->add(addr,p);
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (const DBItem &i : items) {
        //  Out(SYS_DHT|LOG_DEBUG) << "DHT: GetPeers returned item " << i->getAddress().toString() << endl;
        db->store(info_hash, i);
        // also add the items to the returned_items list
        returned_items.append(i);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (WebSeed *ws : qAsConst(webseeds)) {
            if (!ws->busy() && ws->isEnabled() && ws->failedAttempts() < 3) {
                downloadFrom(ws);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Peer::Ptr p : qAsConst(d->peer_map))
        p->setGroupIDs(up, down);
```

#### RANGE FOR STATEMENT 


```{c}
for (WebSeed *ws : qAsConst(webseeds)) {
        if (ws->getUrl() == url)
            return 0;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (WebSeed* ws: qAsConst(webseeds))
		{
			rate += ws->getDownloadRate();
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (UPnPRouter* r : qAsConst(routers)) {
        if (UrlCompare(r->getLocation(), location))
            return r;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (HTTPRequest* r : qAsConst(active_reqs)) {
        r->deleteLater();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Peer::Ptr p : qAsConst(d->peer_map)) {
        p->unpause();
        if (p->hasWantedChunks(d->wanted_chunks)) // send interested when it has wanted chunks
            p->sendInterested();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Peer::Ptr &p : qAsConst(d->peer_map)) {
            const net::Address &addr = p->getAddress();
            out << addr.toString() << " " << (unsigned short)addr.port() << Qt::endl;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const mse::EncryptedPacketSocket::Ptr &s : qAsConst(p)) {
        newConnection(s);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Uint32 file : qAsConst(files)) {
        Priority np = tor.getFile(file).getPriority();
        if (np > highest)
            highest = np;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Forwarding& fwd : qAsConst(d->fwds))
#endif   
        {
            visitor->forwarding(fwd.port, fwd.pending_req != 0, fwd.service);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (WebSeed* ws : qAsConst(webseeds)) {
        if (ws->getUrl() == url)
            return 0;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const UPnPService &s : qAsConst(services)) {
        if (s.servicetype.contains("WANIPConnection") || s.servicetype.contains("WANPPPConnection")) {
            QString action = "GetExternalIPAddress";
            QString comm = SOAP::createCommand(action, s.servicetype);
            HTTPRequest *r = sendSoapQuery(comm, s.servicetype + "#" + action, s.controlurl);
            connect(r, &HTTPRequest::result, parent, &UPnPRouter::getExternalIPResult);
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString & mp : mount_points) {
        if (path.startsWith(mp) && (mount_point.isEmpty() || mp.startsWith(mount_point))) {
            mount_point = mp;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (PieceDownloader* pd: qAsConst(pdown))
		{
			pd->release();
			sendCancels(pd);
			disconnect(pd,SIGNAL(timedout(bt::Request)),this,SLOT(onTimeout(bt::Request)));
			disconnect(pd,SIGNAL(rejected(bt::Request)),this,SLOT(onRejected(bt::Request)));
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (WebSeed* ws : qAsConst(webseeds)) {
        if (ws->busy() && ws->inCurrentRange(chunk))
            return false;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Request & r: qAsConst(requests))
				peer->sendReject(r);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &u: urls)
		{
			if (u.scheme() == QLatin1String("http"))
			{
				WebSeed* ws = new WebSeed(u,false,tor,cman);
				webseeds.append(ws);
				connect(ws, &WebSeed::chunkReady, this, &Downloader::onChunkReady);
				connect(ws, &WebSeed::chunkDownloadStarted, this, &Downloader::chunkDownloadStarted);
				connect(ws, &WebSeed::chunkDownloadFinished, this, &Downloader::chunkDownloadFinished);
			}
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (WebSeed* ws: qAsConst(webseeds))
		{
			if (ws->isUserCreated())
				out << ws->getUrl().toDisplayString() << Qt::endl;
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (net::ServerSocket::Ptr sock: qAsConst(sockets))
				if (sock->sendTo(buf,size,addr) == size)
					return true;
```

#### RANGE FOR STATEMENT 


```{c}
for (WebSeed *ws : qAsConst(webseeds)) {
            ws->update();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KBucket::Ptr& b : qAsConst(buckets)) {
            b->save(enc);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &data : qAsConst(invalid)) {
            bt::MagnetLink mlink(data);
            QVERIFY(!mlink.isValid());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (WebSeed* ws: qAsConst(webseeds))
				{
					if (ws->getUrl() == url)
					{
						ws->setEnabled(false);
						break;
					}
				}
```

#### RANGE FOR STATEMENT 


```{c}
for (UPnPRouter *r : qAsConst(routers)) {
        if (UrlCompare(r->getLocation(), location))
            return r;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KBucket::Ptr& b : qAsConst(buckets)) {
        if (b->needsToBeRefreshed()) {
            // the key needs to be the refreshed
            dht::Key m = dht::Key::mid(b->minKey(), b->maxKey());
            NodeLookup* nl = dh_table->refreshBucket(m, *b);
            if (nl)
                b->setRefreshTask(nl);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& ip : qAsConst(external_addresses)) {
        net::Address address(ip, port);
        if (address == addr)
            return true;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl& url : qAsConst(custom_trackers))
			stream << url.toDisplayString() << Qt::endl;
```

#### RANGE FOR STATEMENT 


```{c}
for (PieceDownloader* pd : qAsConst(piece_downloaders)) {
        pd->checkTimeouts();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString & ip : ips)
        d->listen(ip, port);
```

#### RANGE FOR STATEMENT 


```{c}
for (PieceDownloader* pd: qAsConst(piece_downloaders))
		{
			pd->checkTimeouts();
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (PieceDownloader* pd: qAsConst(piece_downloaders))
			if (pd)
				rate += pd->getDownloadRate();
```

#### RANGE FOR STATEMENT 


```{c}
for(Peer::Ptr peer: qAsConst(d->peer_map))
		{
			if(peer->isSeeder())
				peer->kill();
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QNetworkAddressEntry & entry : addrs) {
            QHostAddress addr = entry.ip();
            if (addr.protocol() == QAbstractSocket::IPv6Protocol && addr != QHostAddress::LocalHostIPv6 && !addr.isInSubnet(QHostAddress(QStringLiteral("FE80::")), 64))
                return addr.toString();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString & mount_point : qAsConst(mount_points)) {
        if (!IsMounted(mount_point))
            missing.append(mount_point);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Peer::Ptr peer : qAsConst(d->peer_map)) {
        if (!peer->isInterested() && (peer->getConnectTime().secsTo(now) > 30))
            peer->kill();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const Peer::Ptr& p: qAsConst(d->peer_map))
			{
				const net::Address & addr = p->getAddress();
				out << addr.toString() << " " << (unsigned short)addr.port() << ::endl;
			}
```

#### RANGE FOR STATEMENT 


```{c}
for (net::ServerSocket::Ptr sock : qAsConst(sockets)) {
            if (sock->sendTo((const bt::Uint8*)msg.data(), msg.size(), addr) == msg.size())
                break;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& s : subdirs)
        {
            QString sd = dir + s;
            if (!sd.endsWith(bt::DirSeparator()))
                sd += bt::DirSeparator();
            buildFileList(sd);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (PieceDownloader *pd : qAsConst(piece_downloaders))
        if (pd)
            rate += pd->getDownloadRate();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString & mount_point : qAsConst(mount_points)) {
        out << mount_point << Qt::endl;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (WebSeed* ws: qAsConst(webseeds))
			ws->cancel();
```

#### RANGE FOR STATEMENT 


```{c}
for (PeerInterface* p : qAsConst(peers)) {
        sendChunk(p);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (WebSeed* ws: qAsConst(webseeds))
		{
			WebSeedChunkDownload* cd = ws->currentChunkDownload();
			if (cd)
				tmon->downloadStarted(cd);
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &u : urls) {
        if (u.scheme() == QLatin1String("http")) {
            WebSeed* ws = new WebSeed(u, false, tor, cman);
            webseeds.append(ws);
            connect(ws, &WebSeed::chunkReady, this, &Downloader::onChunkReady);
            connect(ws, &WebSeed::chunkDownloadStarted, this, &Downloader::chunkDownloadStarted);
            connect(ws, &WebSeed::chunkDownloadFinished, this, &Downloader::chunkDownloadFinished);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString & addr : possible) {
        d->add(addr, p);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const TorrentFile &file : qAsConst(files))
            saveFile(enc, file);
```

#### RANGE FOR STATEMENT 


```{c}
for (PieceDownloader* pd: qAsConst(piece_downloaders))
		{
			if (!pd->isChoked())
			{
				while (pd->canDownloadChunk())
				{
					if (!downloadFrom(pd))
						break;
					pd->setNearlyDone(false);
				}
			}
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (const Peer::Ptr &peer : qAsConst(d->peer_map)) {
        if (peer->isSeeder())
            cnt++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &b : qAsConst(unencoded_path)) {
        path += codec->toUnicode(b);
        if (idx < unencoded_path.size() - 1)
            path += bt::DirSeparator();
        idx++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url: trackers_list)
		{
			Tracker* tracker;
			if (url.scheme() == QLatin1String("udp"))
				tracker = new UDPTracker(url,this,tor.getPeerID(),0);
			else
				tracker = new HTTPTracker(url,this,tor.getPeerID(),0);
			trackers << tracker;
			connect(tracker, &Tracker::peersReady, pman, &PeerManager::peerSourceReady);
			tracker->start();
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (UPnPRouter *r : qAsConst(d->routers)) {
        fout << r->getServer() << Qt::endl;
        fout << r->getLocation().toString() << Qt::endl;
    }
```

#### AUTO 


```{c}
auto i = files.begin();
```

#### RANGE FOR STATEMENT 


```{c}
for (Uint32 fidx: qAsConst(files))
        {
            TorrentFile& tf = tor.getFile(fidx);
            if (!tf.isPreExistingFile())
                return false;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Uint32 file: qAsConst(files))
        {
            Priority np = tor.getFile(file).getPriority();
            if (np > highest)
                highest = np;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Peer::Ptr peer : qAsConst(d->peer_map)) {
        peer->sendHave(index);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &ip : qAsConst(external_addresses)) {
        net::Address address(ip, port);
        if (address == addr)
            return true;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Tracker* tracker : qAsConst(trackers)) {
        tracker->stop();
        delete tracker;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString & addr: ips)
		{
			d->listen(addr);
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& s : names)
		{
			QByteArray encoded = QFile::encodeName(s);
			assembled += (encoded.length() < NAME_MAX) ? s
													   : ShortenName(s, extra_number);
			if (cnt < names.count() - 1)
				assembled += QLatin1Char('/');
			cnt++;
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString & data : qAsConst(invalid)) {
            bt::MagnetLink mlink(data);
            QVERIFY(!mlink.isValid());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(const Peer::Ptr& p: qAsConst(d->peer_map))
		{
			visitor.visit(p);
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (UPnPRouter* r: qAsConst(d->routers))
		{
			fout << r->getServer() << ::endl;
			fout << r->getLocation().toString() << ::endl;
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (const KBucket::Ptr& b : qAsConst(buckets)) {
        if (b->onTimeout(addr))
            return;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (WebSeed* ws : qAsConst(webseeds)) {
            ws->update();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &s : dfiles) {
        // add a TorrentFile to the list
        Uint64 fs = bt::FileSize(target + dir + s);
        TorrentFile f(0, cnt, dir + s, tot_size, fs, chunk_size);
        files.append(f);
        // update total size
        tot_size += fs;
        cnt++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KBucket::Ptr &b : qAsConst(buckets)) {
            b->save(enc);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (PeerInterface* p: qAsConst(peers))
		{
			sendChunk(p);
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (const KBucket::Ptr &b : qAsConst(buckets)) {
        if (b->needsToBeRefreshed()) {
            // the key needs to be the refreshed
            dht::Key m = dht::Key::mid(b->minKey(), b->maxKey());
            NodeLookup *nl = dh_table->refreshBucket(m, *b);
            if (nl)
                b->setRefreshTask(nl);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const UPnPService& os : qAsConst(d->services)) {
        if (s.servicetype == os.servicetype)
            return;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const mse::EncryptedPacketSocket::Ptr& s: qAsConst(p))
		{
			newConnection(s);
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString & key : qAsConst(keys)) {
            QVERIFY(st.hasKey(key));
            QVERIFY(st.readString(key) == values[idx++]);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KBucketEntry& i : qAsConst(entries)) {
        kns.tryInsert(i);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const KBucket::Ptr& b : qAsConst(buckets))
		{
			count += b->getNumEntries();
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (ExitOperation *op : qAsConst(exit_ops))
        delete op;
```

#### RANGE FOR STATEMENT 


```{c}
for(TestResource* r: qAsConst(tr))
					if (!r->acq)
						QVERIFY(r->groupName() == last_acquired_group);
```

#### RANGE FOR STATEMENT 


```{c}
for(QString tr: QUrlQuery(url).allQueryItemValues("tr", QUrl::FullyDecoded))
			result << QUrl(tr.replace(QLatin1Char('+'), QLatin1Char(' ')));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QHostAddress & addr : addrs) {
            if (addr.protocol() == QAbstractSocket::IPv6Protocol && addr != QHostAddress::LocalHostIPv6 && !addr.isInSubnet(QHostAddress(QStringLiteral("FE80::")), 64))
                return addr.toString();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Uint32 file : qAsConst(files)) {
        const TorrentFile& other = tor.getFile(file);
        if (file == tf->getIndex())
            continue;

        // This file needs to be downloaded, so we can't reset the chunk
        if (!other.doNotDownload()) {
            // Priority might need to be modified, so set it's priority
            // to the maximum of all the files who still need it
            setBorderChunkPriority(idx, other.getPriority());
            return false;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(net::ServerSocket::Ptr sock: qAsConst(sockets))
			{
				if (sock->sendTo((const bt::Uint8*)msg.data(), msg.size(), addr) == msg.size())
					break;
			}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QNetworkAddressEntry & entry : addr_list) {
        ips << entry.ip().toString();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Uint32 i : lp) {
        Uint32 cnt_i = downer->numDownloadersForChunk(i);
        if (cnt_i < cnt) {
            sel = i;
            cnt = cnt_i;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (WebSeed* ws : qAsConst(webseeds)) {
                if (ws->getUrl() == url) {
                    ws->setEnabled(false);
                    break;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (PieceDownloader* pd : qAsConst(pdown)) {
        pd->release();
        sendCancels(pd);
        disconnect(pd, &PieceDownloader::timedout, this, &ChunkDownload::onTimeout);
        disconnect(pd, &PieceDownloader::rejected, this, &ChunkDownload::onRejected);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &mount_point : qAsConst(mount_points)) {
        if (!IsMounted(mount_point))
            missing.append(mount_point);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (PieceDownloader *pd : qAsConst(piece_downloaders)) {
        pd->checkTimeouts();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const KBucket::Ptr& b : qAsConst(buckets))
		{
			b->findKClosestNodes(kns);
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &s : sl)
            path += s + bt::DirSeparator();
```

#### RANGE FOR STATEMENT 


```{c}
for (Tracker *tracker : qAsConst(trackers)) {
        tracker->stop();
        delete tracker;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString & mount_point: qAsConst(mount_points))
		{
			out << mount_point << ::endl;
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (PieceDownloader *pd : qAsConst(pdown))
        r += pd->getDownloadRate();
```

#### RANGE FOR STATEMENT 


```{c}
for(Peer::Ptr peer: qAsConst(d->peer_map))
		{
			peer->sendHave(index);
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (const TorrentFile& file: qAsConst(files))
                saveFile(enc, file);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& s : sl)
            path += s + bt::DirSeparator();
```

#### RANGE FOR STATEMENT 


```{c}
for (WebSeed* ws : qAsConst(webseeds)) {
                // tell all webseeds a chunk is downloaded
                if (ws->inCurrentRange(c->getIndex()))
                    ws->chunkDownloaded(c->getIndex());
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (WebSeed *ws : qAsConst(webseeds)) {
            if (ws->busy() && ws->isEnabled()) {
                ws->cancel();
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl& url : qAsConst(custom_trackers))
        stream << url.toDisplayString() << Qt::endl;
```

#### RANGE FOR STATEMENT 


```{c}
for (PieceDownloader* pd : qAsConst(piece_downloaders))
        if (pd)
            rate += pd->getDownloadRate();
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString& s : sl)
				path += s + bt::DirSeparator();
```

#### RANGE FOR STATEMENT 


```{c}
for (WebSeed* ws: qAsConst(webseeds))
		{
			if (!ws->isEnabled())
				out << ws->getUrl().toDisplayString() << Qt::endl;
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (TestResource* r : qAsConst(tr))
                    if (!r->acq)
                        QVERIFY(r->groupName() == last_acquired_group);
```

#### RANGE FOR STATEMENT 


```{c}
for (ReverseResolver* rr: qAsConst(todo_list))
			rr->deleteLater();
```

#### RANGE FOR STATEMENT 


```{c}
for (Uint32 file : qAsConst(files)) {
        const TorrentFile &other = tor.getFile(file);
        if (file == tf->getIndex())
            continue;

        // This file needs to be downloaded, so we can't reset the chunk
        if (!other.doNotDownload()) {
            // Priority might need to be modified, so set it's priority
            // to the maximum of all the files who still need it
            setBorderChunkPriority(idx, other.getPriority());
            return false;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (WebSeed *ws : qAsConst(webseeds)) {
        if (ws->getUrl() == url)
            return nullptr;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& s : names) {
        QByteArray encoded = QFile::encodeName(s);
        assembled += (encoded.length() < NAME_MAX) ? s
                     : ShortenName(s, extra_number);
        if (cnt < names.count() - 1)
            assembled += QLatin1Char('/');
        cnt++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const KBucket::Ptr& b : qAsConst(buckets))
		{
			if(b->needsToBeRefreshed())
			{
				// the key needs to be the refreshed
				dht::Key m = dht::Key::mid(b->minKey(), b->maxKey());
				NodeLookup* nl = dh_table->refreshBucket(m, *b);
				if(nl)
					b->setRefreshTask(nl);
			}
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QNetworkAddressEntry &entry : addr_list) {
        ips << entry.ip().toString();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (UnackedPacket & pkt : unacked_packets) {
            if (!pkt.retransmitted || now - pkt.send_time > conn->currentTimeout()) {
                conn->retransmit(pkt.packet, pkt.seq_nr);
                pkt.send_time = bt::Now();
                pkt.retransmitted = true;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &t : qAsConst(trackers)) {
                enc.beginList();
                enc.write(t.toUtf8());
                enc.end();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for(const Peer::Ptr& peer: qAsConst(d->peer_map))
		{
			if(!peer->isSeeder())
				cnt++;
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (net::ServerSocket::Ptr sock : qAsConst(sockets)) {
            if (sock->sendTo((const bt::Uint8 *)msg.data(), msg.size(), addr) == msg.size())
                break;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &s : sl)
        enc.write(s.toUtf8());
```

#### RANGE FOR STATEMENT 


```{c}
for (const Solid::Device &dev : devs) {
        const Solid::StorageAccess *sa = dev.as<Solid::StorageAccess>();
        if (!sa->filePath().isEmpty() && sa->isAccessible())
            result.insert(sa->filePath());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Peer::Ptr &peer : qAsConst(d->peer_map)) {
        if (!peer->isSeeder())
            cnt++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (WebSeed *ws : qAsConst(webseeds)) {
        if (ws->isUserCreated())
            out << ws->getUrl().toDisplayString() << Qt::endl;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString & data: qAsConst(invalid))
		{
			bt::MagnetLink mlink(data);
			QVERIFY(!mlink.isValid());
		}
```

#### RANGE FOR STATEMENT 


```{c}
for(CacheFile::Ptr cache_file: qAsConst(todo))
			{
				if(!isStopped())
				{
					cache_file->preallocate(this);
				}
				else
				{
					setNotFinished();
					break;
				}
			}
```

#### RANGE FOR STATEMENT 


```{c}
for (const UPnPService& s : qAsConst(d->services))
#endif   
        {
            if(s.servicetype.contains("WANIPConnection") || s.servicetype.contains("WANPPPConnection"))
            {
                d->forward(&s, port);
                found = true;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QNetworkAddressEntry & entry: addr_list)
		{
			ips << entry.ip().toString();
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& t : qAsConst(trackers)) {
            enc.beginList();
            enc.write(t.section(',', 0, 0).toUtf8());
            enc.write((Uint32)t.section(',', 1, 1).toInt());
            enc.end();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &mount_point : qAsConst(mount_points)) {
        out << mount_point << Qt::endl;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &u : urls) {
        if (u.scheme() == QLatin1String("http")) {
            WebSeed *ws = new WebSeed(u, false, tor, cman);
            webseeds.append(ws);
            connect(ws, &WebSeed::chunkReady, this, &Downloader::onChunkReady);
            connect(ws, &WebSeed::chunkDownloadStarted, this, &Downloader::chunkDownloadStarted);
            connect(ws, &WebSeed::chunkDownloadFinished, this, &Downloader::chunkDownloadFinished);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (HTTPRequest *r : qAsConst(active_reqs)) {
        r->deleteLater();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (PieceDownloader* pd: qAsConst(pdown))
		{
			pd->release();
			sendCancels(pd);
			disconnect(pd, &PieceDownloader::timedout, this, &ChunkDownload::onTimeout);
			disconnect(pd, &PieceDownloader::rejected, this, &ChunkDownload::onRejected);
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (const utp::Connection::WPtr &conn : qAsConst(to_close)) {
        Connection::Ptr c = conn.toStrongRef();
        if (c)
            c->close();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const net::ServerSocket::Ptr &sock : qAsConst(d->sockets))
            sock->moveToThread(d->utp_thread);
```

#### RANGE FOR STATEMENT 


```{c}
for (WebSeed* ws : qAsConst(webseeds)) {
                if (ws->inCurrentRange(p.getIndex()))
                    ws->chunkDownloaded(p.getIndex());
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Peer::Ptr& p : qAsConst(d->peer_map)) {
        rate += p->getUploadRate();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &s : names) {
        QByteArray encoded = QFile::encodeName(s);
        if (encoded.length() >= NAME_MAX)
            return true;
        length += encoded.length();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Peer::Ptr &p : qAsConst(d->peer_map)) {
        rate += p->getUploadRate();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (WebSeed* ws: qAsConst(webseeds))
			{
				ws->update();
			}
```

#### RANGE FOR STATEMENT 


```{c}
for (const DBItem & i : items)
		{
			//	Out(SYS_DHT|LOG_DEBUG) << "DHT: GetPeers returned item " << i->getAddress().toString() << endl;
			db->store(info_hash, i);
			// also add the items to the returned_items list
			returned_items.append(i);
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (Uint32 file: qAsConst(files))
        {
            const TorrentFile& other = tor.getFile(file);
            if (file == tf->getIndex())
                continue;

            // This file needs to be downloaded, so we can't reset the chunk
            if (!other.doNotDownload())
            {
                // Priority might need to be modified, so set it's priority
                // to the maximum of all the files who still need it
                setBorderChunkPriority(idx, other.getPriority());
                return false;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (WebSeed *ws : qAsConst(webseeds)) {
                if (ws->getUrl() == url) {
                    ws->setEnabled(false);
                    break;
                }
            }
```

#### AUTO 


```{c}
auto i = pdown.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (WebSeed* ws : qAsConst(webseeds)) {
            ws->cancel();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(Peer::Ptr peer: qAsConst(d->peer_map))
		{
			if(!peer->isInterested() && (peer->getConnectTime().secsTo(now) > 30))
				peer->kill();
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString & key: qAsConst(keys))
		{
			QVERIFY(st.hasKey(key));
			QVERIFY(st.readString(key) == values[idx++]);
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (WebSeed *ws : qAsConst(webseeds)) {
                if (ws->inCurrentRange(p.getIndex()))
                    ws->chunkDownloaded(p.getIndex());
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (WebSeed* ws: qAsConst(webseeds))
			{
				if (!ws->busy() && ws->isEnabled() && ws->failedAttempts() < 3)
				{
					downloadFrom(ws);
				}
			}
```

#### RANGE FOR STATEMENT 


```{c}
for (Peer::Ptr p : qAsConst(d->peer_map)) {
        p->pause();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Forwarding &fw : qAsConst(fwds)) {
        if (fw.pending_req == r) {
            found = true;
            break;
        }
        idx++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Solid::Device& dev : devs) {
            const Solid::StorageAccess* sa = dev.as<Solid::StorageAccess>();
            if (sa->isAccessible()) {
                QVERIFY(bt::MountPoint(sa->filePath()) == sa->filePath());

                QString path = sa->filePath() + "/some/random/path/test.foobar";
                Out(SYS_GEN | LOG_DEBUG) << "Testing " << path << endl;
                QVERIFY(bt::MountPoint(path) == sa->filePath());
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : trackers_list) {
        Tracker* tracker;
        if (url.scheme() == QLatin1String("udp"))
            tracker = new UDPTracker(url, this, tor.getPeerID(), 0);
        else
            tracker = new HTTPTracker(url, this, tor.getPeerID(), 0);
        trackers << tracker;
        connect(tracker, &Tracker::peersReady, pman, &PeerManager::peerSourceReady);
        tracker->start();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &addr : ips) {
        d->listen(addr);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const UPnPService& s : qAsConst(d->services)) {
        if (s.servicetype.contains("WANIPConnection") || s.servicetype.contains("WANPPPConnection")) {
            d->forward(&s, port);
            found = true;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (PieceDownloader *pd : qAsConst(piece_downloaders)) {
        if (!pd->isChoked()) {
            while (pd->canDownloadChunk()) {
                if (!downloadFrom(pd))
                    break;
                pd->setNearlyDone(false);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &u : qAsConst(webseeds)) {
            enc.write(u.toDisplayString().toUtf8());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Solid::Device& dev: devs)
		{
			const Solid::StorageAccess* sa = dev.as<Solid::StorageAccess>();
			if(!sa->filePath().isEmpty() && sa->isAccessible())
				result.insert(sa->filePath());
		}
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString & mount_point: qAsConst(mount_points))
		{
			out << mount_point << Qt::endl;
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (const Arg & a : args)
        comm += "<" + a.element + ">" + a.value + "</" + a.element + ">";
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &ip : ips)
        d->listen(ip, port);
```

#### RANGE FOR STATEMENT 


```{c}
for (WebSeed* ws: qAsConst(webseeds))
		{
			if (!ws->isEnabled())
				out << ws->getUrl().toDisplayString() << ::endl;
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (const net::ServerSocket::Ptr& sock: qAsConst(d->sockets))
				sock->moveToThread(d->utp_thread);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Solid::Device& dev : devs) {
        const Solid::StorageAccess* sa = dev.as<Solid::StorageAccess>();
        if (!sa->filePath().isEmpty() && sa->isAccessible())
            result.insert(sa->filePath());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &addr : possible) {
        d->add(addr, p);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QNetworkAddressEntry &entry : addrs) {
            QHostAddress addr = entry.ip();
            if (addr.protocol() == QAbstractSocket::IPv6Protocol && addr != QHostAddress::LocalHostIPv6
                && !addr.isInSubnet(QHostAddress(QStringLiteral("FE80::")), 64))
                return addr.toString();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString & s : names)
		{
			QByteArray encoded = QFile::encodeName(s);
			if (encoded.length() >= NAME_MAX)
				return true;
			length += encoded.length();
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (WebSeed* ws: qAsConst(webseeds))
		{
			if (ws->busy() && ws->inCurrentRange(chunk))
				return false;
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (WebSeed *ws : qAsConst(webseeds))
        ws->reset();
```

#### AUTO 


```{c}
auto i = subdirs.begin();
```

#### RANGE FOR STATEMENT 


```{c}
for (net::ServerSocket::Ptr sock : qAsConst(d->sockets))
        sock->setTOS(d->tos);
```

#### RANGE FOR STATEMENT 


```{c}
for (const UPnPService& s : qAsConst(services))
#endif   
        {
            if(s.servicetype.contains("WANIPConnection") || s.servicetype.contains("WANPPPConnection"))
            {
                QString action = "GetExternalIPAddress";
                QString comm = SOAP::createCommand(action, s.servicetype);
                HTTPRequest* r = sendSoapQuery(comm, s.servicetype + "#" + action, s.controlurl);
                connect(r, SIGNAL(result(HTTPRequest*)), parent, SLOT(getExternalIPResult(HTTPRequest*)));
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KBucket::Ptr& b : qAsConst(buckets)) {
        count += b->getNumEntries();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (net::ServerSocket::Ptr sock : qAsConst(sockets))
            if (sock->sendTo(buf, size, addr) == size)
                return true;
```

#### RANGE FOR STATEMENT 


```{c}
for(Peer::Ptr p: qAsConst(d->peer_map))
		{
			if(p->getDownloadRate() == 0 && p->getUploadRate() == 0)
				p->kill();
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (net::ServerSocket::Ptr sock: qAsConst(d->sockets))
		{
			sock->setReadNotificationsEnabled(true);
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString & addr : possible) {
        d->bind(net::Address(addr, p));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url: trackers_list)
		{
			Tracker* tracker;
			if (url.scheme() == QLatin1String("udp"))
				tracker = new UDPTracker(url,this,tor.getPeerID(),0);
			else
				tracker = new HTTPTracker(url,this,tor.getPeerID(),0);
			trackers << tracker;
			connect(tracker,SIGNAL(peersReady(PeerSource*)),pman,SLOT(peerSourceReady(PeerSource*)));
			tracker->start();
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QNetworkAddressEntry & entry: addrs)
			{
				QHostAddress addr = entry.ip();
				if (addr.protocol() == QAbstractSocket::IPv6Protocol && addr != QHostAddress::LocalHostIPv6 && !addr.isInSubnet(QHostAddress(QStringLiteral("FE80::")), 64))
					return addr.toString();
			}
```

#### RANGE FOR STATEMENT 


```{c}
for (net::ServerSocket::Ptr sock: qAsConst(d->sockets))
			sock->setWriteNotificationsEnabled(true);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KBucket::Ptr &b : qAsConst(buckets)) {
        count += b->getNumEntries();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (WebSeed *ws : qAsConst(webseeds))
        ws->cancel();
```

#### RANGE FOR STATEMENT 


```{c}
for (const KBucket::Ptr& b : qAsConst(buckets)) {
        b->findKClosestNodes(kns);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (WebSeed* ws : qAsConst(webseeds)) {
        ws->setGroupIDs(up, down);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (WebSeed *ws : qAsConst(webseeds)) {
        ws->setGroupIDs(up, down);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const utp::Connection::WPtr& conn: qAsConst(to_close))
		{
			Connection::Ptr c = conn.toStrongRef();
			if (c)
				c->close();
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (const Peer::Ptr &p : qAsConst(d->peer_map)) {
        if (p->getPeerID() == peer_id)
            return true;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (WebSeed* ws: qAsConst(webseeds))
				{
					// tell all webseeds a chunk is downloaded
					if (ws->inCurrentRange(c->getIndex()))
						ws->chunkDownloaded(c->getIndex());
				}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString & s : dfiles) {
        // add a TorrentFile to the list
        Uint64 fs = bt::FileSize(target + dir + s);
        TorrentFile f(0, cnt, dir + s, tot_size, fs, chunk_size);
        files.append(f);
        // update total size
        tot_size += fs;
        cnt++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (WebSeed *ws : qAsConst(webseeds)) {
        if (!ws->isEnabled())
            out << ws->getUrl().toDisplayString() << Qt::endl;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString& ip: qAsConst(external_addresses))
        {
            net::Address address(ip, port);
            if(address == addr)
                return true;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(Peer::Ptr peer: qAsConst(d->peer_map))
			{
				peer->sendExtProtHandshake(port, d->tor.getMetaData().size(), d->partial_seed);
			}
```

#### RANGE FOR STATEMENT 


```{c}
for (const Arg & a: args)
			comm += "<" + a.element + ">" + a.value + "</" + a.element + ">";
```

#### RANGE FOR STATEMENT 


```{c}
for (Peer::Ptr peer : qAsConst(d->peer_map)) {
            peer->sendExtProtHandshake(port, d->tor.getMetaData().size(), d->partial_seed);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (WebSeed* ws: qAsConst(webseeds))
		{
			ws->setGroupIDs(up,down);
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (TestResource *r : qAsConst(tr))
                    if (!r->acq)
                        QVERIFY(r->groupName() == last_acquired_group);
```

#### RANGE FOR STATEMENT 


```{c}
for (CacheFile::Ptr cache_file : qAsConst(todo)) {
            if (!isStopped()) {
                cache_file->preallocate(this);
            } else {
                setNotFinished();
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& s : sl)
        enc.write(s.toUtf8());
```

#### RANGE FOR STATEMENT 


```{c}
for (const Arg &a : args)
        comm += "<" + a.element + ">" + a.value + "</" + a.element + ">";
```

#### RANGE FOR STATEMENT 


```{c}
for(const KBucket::Ptr& b : qAsConst(buckets))
			{
				b->save(enc);
			}
```

#### RANGE FOR STATEMENT 


```{c}
for(const Peer::Ptr& p: qAsConst(d->peer_map))
			{
				const net::Address & addr = p->getAddress();
				out << addr.toString() << " " << (unsigned short)addr.port() << Qt::endl;
			}
```

#### RANGE FOR STATEMENT 


```{c}
for (ReverseResolver* rr : qAsConst(todo_list))
        rr->deleteLater();
```

#### RANGE FOR STATEMENT 


```{c}
for (Peer::Ptr p : qAsConst(d->peer_map)) {
        const net::Address & addr = p->getAddress();
        addPotentialPeer(addr, false);
        p->kill();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (ReverseResolver *rr : qAsConst(todo_list))
        rr->deleteLater();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Peer::Ptr& peer : qAsConst(d->peer_map)) {
        if (peer->isSeeder())
            cnt++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Request &r : qAsConst(requests))
            peer->sendReject(r);
```

#### RANGE FOR STATEMENT 


```{c}
for (PieceDownloader* pd: qAsConst(pdown))
			r += pd->getDownloadRate();
```

#### RANGE FOR STATEMENT 


```{c}
for (Uint32 i : lp)
		{
			Uint32 cnt_i = downer->numDownloadersForChunk(i);
			if (cnt_i < cnt)
			{
				sel = i;
				cnt = cnt_i;
			}
		}
```

#### RANGE FOR STATEMENT 


```{c}
for(const BlockListInterface* bl: qAsConst(blocklists))
        {
            if(bl->blocked(addr))
                return false;
        }
```

#### AUTO 


```{c}
auto it = lines.begin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const UPnPService& os : qAsConst(d->services))
        {
            if(s.servicetype == os.servicetype)
                return;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString & mount_point: qAsConst(mount_points))
		{
			if(!IsMounted(mount_point))
				missing.append(mount_point);
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (Peer::Ptr p : qAsConst(d->peer_map)) {
        if ((PieceDownloader *)p->getPeerDownloader() == pd)
            return p;
    }
```

