#### RANGE FOR STATEMENT 


```{c}
for (const QString& groupName : groups) {
            KConfigGroup cgServerGroup(KSharedConfig::openConfig()->group(groupName));
            Konversation::ServerGroupSettingsPtr serverGroup(new Konversation::ServerGroupSettings);
            serverGroup->setName(cgServerGroup.readEntry("Name"));
            serverGroup->setSortIndex(groups.at(index).section(QLatin1Char(' '), -1).toInt());
            serverGroup->setIdentityId(Preferences::identityByName(cgServerGroup.readEntry("Identity"))->id());
            serverGroup->setConnectCommands(cgServerGroup.readEntry("ConnectCommands"));
            serverGroup->setAutoConnectEnabled(cgServerGroup.readEntry("AutoConnect", false));
            serverGroup->setNotificationsEnabled(cgServerGroup.readEntry("EnableNotifications", true));
            serverGroup->setExpanded(cgServerGroup.readEntry("Expanded", false));

#if QT_VERSION < QT_VERSION_CHECK(5, 15, 0)
            notifyList.insert((*serverGroup).id(), cgServerGroup.readEntry("NotifyList", QString()).split(QLatin1Char(' '), QString::SkipEmptyParts));
#else
            notifyList.insert((*serverGroup).id(), cgServerGroup.readEntry("NotifyList", QString()).split(QLatin1Char(' '), Qt::SkipEmptyParts));
#endif

            const QStringList serverNames = cgServerGroup.readEntry("ServerList", QStringList());
            for (const QString& serverName : serverNames) {
                KConfigGroup cgServer(KSharedConfig::openConfig()->group(serverName));
                server.setHost(cgServer.readEntry("Server"));
                server.setPort(cgServer.readEntry<int>("Port", 0));
                server.setPassword(cgServer.readEntry("Password"));
                server.setSSLEnabled(cgServer.readEntry("SSLEnabled", false));
                server.setBypassProxy(cgServer.readEntry("BypassProxy", false));
                serverGroup->addServer(server);
            }

            //config->setGroup(groupName);
            const QStringList autoJoinChannels = cgServerGroup.readEntry("AutoJoinChannels", QStringList());

            for (const QString& channelName : autoJoinChannels) {
                KConfigGroup cgJoin(KSharedConfig::openConfig()->group(channelName));

                if (!cgJoin.readEntry("Name").isEmpty())
                {
                    channel.setName(cgJoin.readEntry("Name"));
                    channel.setPassword(cgJoin.readEntry("Password"));
                    serverGroup->addChannel(channel);
                }
            }

            //config->setGroup(groupName);
            const QStringList channelHistoryList = cgServerGroup.readEntry("ChannelHistory", QStringList());
            channelHistory.clear();

            for (const QString& channelName : channelHistoryList) {
                KConfigGroup cgChanHistory(KSharedConfig::openConfig()->group(channelName));

                if (!cgChanHistory.readEntry("Name").isEmpty())
                {
                    channel.setName(cgChanHistory.readEntry("Name"));
                    channel.setPassword(cgChanHistory.readEntry("Password"));
                    channel.setNotificationsEnabled(cgChanHistory.readEntry("EnableNotifications", true));
                    channelHistory.append(channel);
                }
            }

            serverGroup->setChannelHistory(channelHistory);

            serverGroups.insert(serverGroup->id(), serverGroup);
            sgKeys.append(serverGroup->id());

            index++;
        }
```

#### AUTO 


```{c}
auto *ev=new KNotification(QStringLiteral("notify"));
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction* action : qAsConst(self()->m_sharedDccActions))
        action->setEnabled(connected);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl& url : list) {
        ConnectionSettings settings;

        decodeIrcUrl(url.url(), settings);

        qCDebug(KONVERSATION_LOG) << settings.name() << " - "
                 << settings.server().host() << settings.server().port()
                 << settings.server().password() << " - "
                 << (settings.serverGroup()?settings.serverGroup()->name():QString());

        QString sname = (settings.serverGroup() ? settings.serverGroup()->name()
            : (settings.server().host() + QLatin1Char(':') + QString::number(settings.server().port())));

        if (!serverChannels.contains(sname))
            serverConnections[sname] = settings;

        serverChannels[sname] += settings.oneShotChannelList();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (int encServer : encServers) {
        Konversation::ServerGroupSettingsPtr sgsp = Preferences::serverGroupById(encServer);

        if ( sgsp )  // sgsp == 0 when the entry is of QuickConnect or something?
        {
            const QStringList encChannels = Preferences::channelEncodingsChannelList(encServer);
            //ditto //encChannels.sort();
            for (const QString& encChannel : encChannels) {
                QString enc = Preferences::channelEncoding(encServer, encChannel);
                QString key = QLatin1Char(' ') + encChannel;
                if (sgKeys.contains(encServer))
                    key.prepend(QStringLiteral("ServerGroup ") + QString::number(sgKeys.indexOf(encServer)));
                else
                    key.prepend(sgsp->name());
                cgEncoding.writeEntry(key, enc);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& script : qAsConst(scripts)) {
        aliasList.append(QStringLiteral("%1 /exec %1").arg(script));

        // FIXME: Historically, defaultAliasList() is primarily used to dynamically
        // compile a list of installed scripts and generate appropriate aliases for
        // them. It's not only used when the alias preferences are reset or initia-
        // lized, but also on application start. The following crudely adds two
        // aliases when the 'media' script is found, to provide easy access to its
        // capability to differentiate  between audio and video media. This method
        // needs at the very least to be split up in two, or scripts may in the
        // future determine what aliases they want to add.
        if (script == QLatin1String("media"))
        {
            aliasList.append(QStringLiteral("audio /exec media audio"));
            aliasList.append(QStringLiteral("video /exec media video"));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : qAsConst(indexesToRemove)) {
                indexes.removeOne(index);
            }
```

#### AUTO 


```{c}
auto* action = new QAction(showURLmenu);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QChar mode : qAsConst(modeString)) {
            const QString modeAsString(mode);

            QStandardItem *item = nullptr;
            if (!Preferences::self()->useLiteralModes() && getChannelModesHash().contains(mode))
                item = new QStandardItem(i18nc("<mode character> (<mode description>)","%1 (%2)", mode, getChannelModesHash().value(mode)));
            else
                item = new QStandardItem(modeAsString);
            item->setData(modeAsString);
            item->setCheckable(true);
            item->setEditable(false);

            auto* secondItem = new QStandardItem();
            secondItem->setEditable(true);

            const QList<QStandardItem *> newRow { item, secondItem };
            modesModel->invisibleRootItem()->appendRow(newRow);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &mode : removable) {
            m_modeList.removeOne(mode);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Query* lookQuery : qAsConst(m_queryList)) {
        if(lookQuery->getName().toLower()==wanted) return lookQuery;
    }
```

#### AUTO 


```{c}
auto* channel = static_cast<Channel*>(m_tabWidget->currentWidget());
```

#### AUTO 


```{c}
auto *manager = new KNSCore::DownloadManager(QStringLiteral("konversation_nicklist_theme.knsrc"), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &lin : lines) {
                    emit receivedRawLine(lin);
                }
```

#### AUTO 


```{c}
auto* toggleMenuBarAction = qobject_cast<KToggleAction*>(actionCollection->action(QStringLiteral("options_show_menubar")));
```

#### AUTO 


```{c}
auto *tFilledRectangle = new QListWidgetItem(QString(), m_formOptionListWidget, QListWidgetItem::UserType +1);
```

#### AUTO 


```{c}
auto* label = static_cast<TopicHistoryLabel*>(widgets[0]);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QRect& rect : region) {
                tPaint.drawPixmap(rect, *m_imagePixmap, rect);

                tPaint.drawPixmap(rect, *m_overlayPixmap, rect);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& channelName : autoJoinChannels) {
                KConfigGroup cgJoin(KSharedConfig::openConfig()->group(channelName));

                if (!cgJoin.readEntry("Name").isEmpty())
                {
                    channel.setName(cgJoin.readEntry("Name"));
                    channel.setPassword(cgJoin.readEntry("Password"));
                    serverGroup->addChannel(channel);
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (Server *server : serverList) {
      if (server->getServerGroup())
        m_networkNameCombo->addItem(server->getServerGroup()->name(), server->getServerGroup()->id());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &rowIndex : rowIndices) {
                Transfer *rowTransfer = qobject_cast<Transfer*>(rowIndex.data(TransferListModel::TransferPointer).value<QObject*>());
                if (rowTransfer == transfer)
                {
                    return rowIndex;
                }
            }
```

#### AUTO 


```{c}
auto* router = qobject_cast<UPnP::UPnPRouter*>(this->sender());
```

#### RANGE FOR STATEMENT 


```{c}
for (Server* server : qAsConst(m_connectionList)) {
        serverList.append(server);
    }
```

#### AUTO 


```{c}
auto *forward = new Forwarding;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : rowIndices) {
                if (index.data(TransferListModel::TransferStatus).toInt() >= Transfer::Done)
                {
                    indexesToRemove.append(index);
                }
            }
```

#### CONST EXPRESSION 


```{c}
constexpr int MARGIN = 2;
```

#### RANGE FOR STATEMENT 


```{c}
for (QTreeWidgetItem* item : items) {
        if (indexOfTopLevelItem(item)<0) // is a child
        {
                children.append(item);
                parent = children.at(0)->parent();
                // make sure all the children have the same parent
                for (QTreeWidgetItem* child : qAsConst(children)) {
                    if (child->parent() != parent)
                        return true;
                }
        }
        else    t++;

        if (t > 0 && !children.isEmpty()) //make sure we don't have a top and a child selected
            return true;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Nick *nick : qAsConst(foundNicks)) {
        found.append(nick->getChannelNick()->getNickname());
    }
```

#### AUTO 


```{c}
auto *ircViewBox = new IRCViewBox(m_headerSplitter);
```

#### AUTO 


```{c}
auto *notification = new KNotification(QStringLiteral("dcctransfer_done"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QStringList &definition : autoreplaceList) {
    // cut definition apart in name and action, and create a new listview item
    QTreeWidgetItem* newItem=new QTreeWidgetItem(patternListView);
    newItem->setFlags(newItem->flags() &~ Qt::ItemIsDropEnabled);
    newItem->setCheckState(0, Qt::Unchecked);
    // Regular expression?
    if (definition.at(0)== QLatin1Char('1')) newItem->setCheckState(0, Qt::Checked);
    // direction input/output/both
    if (definition.at(1)== QLatin1Char('i'))
    {
        newItem->setText(1,directionCombo->itemText(DIRECTION_INPUT));
    }
    else if (definition.at(1)== QLatin1Char('o'))
    {
        newItem->setText(1,directionCombo->itemText(DIRECTION_OUTPUT));
    }
    else if (definition.at(1)==QLatin1String("io"))
    {
        newItem->setText(1,directionCombo->itemText(DIRECTION_BOTH));
    }
    // pattern
    newItem->setText(2,definition.at(2));
    // replacement
    newItem->setText(3,definition.at(3));
    // hidden column, so we are independent of the i18n()ed display string
    newItem->setText(4,definition.at(1));
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (Highlight* currentHighlight : highlightList) {
        auto *item = new HighlightViewItem(highlightListView,currentHighlight);
        item->setFlags(item->flags() &~ Qt::ItemIsDropEnabled);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& parameter : list) {
                // Try to remove current pattern.
                if (!Preferences::removeNotify(serverGroupId, parameter))
                {
                    // If remove failed, try to add it instead.
                    if (Preferences::addNotify(serverGroupId, parameter))
                        added << parameter;
                }
                else
                    removed << parameter;
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& lookChannel : qAsConst(channelList)) {
                    if (lookChannel.startsWith(QLatin1Char('*')) || lookChannel.startsWith(QLatin1Char('&')))
                    {
                        adminChannels.append(lookChannel.mid(1));
                        m_server->setChannelNick(lookChannel.mid(1), parameterList.value(1), 16);
                    }
                                                // See bug #97354 part 2
                    else if((lookChannel.startsWith(QLatin1Char('!')) || lookChannel.startsWith(QLatin1Char('~'))) && m_server->isAChannel(lookChannel.mid(1)))
                    {
                        ownerChannels.append(lookChannel.mid(1));
                        m_server->setChannelNick(lookChannel.mid(1), parameterList.value(1), 8);
                    }
                                                // See bug #97354 part 1
                    else if (lookChannel.startsWith(QLatin1String("@+")))
                    {
                        opChannels.append(lookChannel.mid(2));
                        m_server->setChannelNick(lookChannel.mid(2), parameterList.value(1), 4);
                    }
                    else if (lookChannel.startsWith(QLatin1Char('@')))
                    {
                        opChannels.append(lookChannel.mid(1));
                        m_server->setChannelNick(lookChannel.mid(1), parameterList.value(1), 4);
                    }
                    else if (lookChannel.startsWith(QLatin1Char('%')))
                    {
                        halfopChannels.append(lookChannel.mid(1));
                        m_server->setChannelNick(lookChannel.mid(1), parameterList.value(1), 2);
                    }
                    else if (lookChannel.startsWith(QLatin1Char('+')))
                    {
                        voiceChannels.append(lookChannel.mid(1));
                        m_server->setChannelNick(lookChannel.mid(1), parameterList.value(1), 1);
                    }
                    else
                    {
                        userChannels.append(lookChannel);
                        m_server->setChannelNick(lookChannel, parameterList.value(1), 0);
                    }
                }
```

#### AUTO 


```{c}
auto* headerWidget = new QWidget(m_headerSplitter);
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction* action : qAsConst(self()->m_sharedDccActions))
            action->setEnabled(connected);
```

#### AUTO 


```{c}
auto* highlightItem = dynamic_cast<HighlightViewItem*>(item);
```

#### AUTO 


```{c}
const auto rowIndices = rowIndexes();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& channelGroup : channelGroups) {
        KSharedConfig::openConfig()->deleteGroup(channelGroup);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString& alias : aliasList) {
            // cut alias pattern from definition
            QString aliasPattern(alias.section(QLatin1Char(' '), 0, 0));

            // cut first word from command line, so we do not wrongly find an alias
            // that starts with the same letters, like /m would override /me
            QString lineStart = line.section(QLatin1Char(' '), 0, 0);

            // pattern found?
            if (lineStart == Preferences::self()->commandChar() + aliasPattern)
            {
                QString aliasReplace = alias.section(QLatin1Char(' '),1);

                if (context)
                    aliasReplace = context->getServer()->parseWildcards(aliasReplace, context);

                if (!alias.contains(QLatin1String("%p")))
                    aliasReplace.append(QLatin1Char(' ') + line.section(QLatin1Char(' '), 1));

                // protect "%%"
                aliasReplace.replace(QStringLiteral("%%"),QStringLiteral("%\x01"));
                // replace %p placeholder with rest of line
                aliasReplace.replace(QStringLiteral("%p"), line.section(QLatin1Char(' '), 1));
                // restore "%<1>" as "%%"
                aliasReplace.replace(QStringLiteral("%\x01"),QStringLiteral("%%"));
                // modify line
                line=aliasReplace;
                // return "replaced"
                return true;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &line : lines) {
                m_chat->sendText(line);
                getTextView()->append(m_chat->ownNick(), line);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &entry : entries) {
            const QStringList installedFiles = entry.installedFiles();
            for (const QString &file : installedFiles) {
                // file strings are of pattern "[...]/konversation/themes/simpleminded/*"
                if (file.startsWith(dir)) {
                    // uninstall via KNS and be done
                    manager->uninstallEntry(entry);
                    isUninstalledByKNS = true;
                    break;
                }
            }
            if (isUninstalledByKNS) {
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (int row : rows) {
                    if (row == index.row())
                    {
                        selection.append(QItemSelectionRange(index));
                        break;
                    }
                }
```

#### AUTO 


```{c}
auto* dialog = new KBookmarkDialog(manager, Application::instance()->getMainWindow());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &cap : capsList) {
        nameValue = cap.split(QLatin1Char('='));

        if (nameValue.isEmpty())
            continue;

        if(nameValue.at(0) == QLatin1String("sasl"))
        {
            QString authCommand;

            if (getIdentity()) {
                // A username is optional SASL EXTERNAL and a client cert substitutes
                // for the password.
                if (getIdentity()->getAuthType() == QLatin1String("saslexternal")) {
                    authCommand = QStringLiteral("EXTERNAL");
                // PLAIN on the other hand requires both.
                } else if (getIdentity()->getAuthType() == QLatin1String("saslplain")
                    && !getIdentity()->getSaslAccount().isEmpty()
                    && !getIdentity()->getAuthPassword().isEmpty()) {
                    authCommand = QStringLiteral("PLAIN");
                }
            }

            if(!authCommand.isEmpty())
            {
                QStringList supportedSaslTypes;
                if(nameValue.size() > 1)
                    supportedSaslTypes = nameValue.at(1).split(QLatin1Char(','));

                supportedSaslTypes.removeDuplicates();

                if(!supportedSaslTypes.isEmpty() && !supportedSaslTypes.contains(authCommand))
                    getStatusView()->appendServerMessage(i18n("Error"), i18n("Server does not support %1 as SASL authentication mechanism, skipping SASL authentication.", authCommand));
                else
                    requestCaps.append (QStringLiteral("sasl"));
            }
        }
        else if(m_capabilityNames.contains(nameValue.at(0)))
        {
            requestCaps.append (nameValue.at(0));
        }

        // HACK: twitch.tv's IRC server doesn't handle WHO so
        // let's disable all WHO requests for servers that has
        // twitch.tv capabilities
        if (nameValue.at(0).startsWith(QLatin1String("twitch.tv"))) {
            m_whoRequestsDisabled = true;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (TransferRecv* it : qAsConst(m_recvItems)) {
                if ( ( it->getStatus() == Transfer::Queued || it->getStatus() == Transfer::WaitingRemote ) &&
                    it->getConnectionId() == connectionId &&
                    it->getPartnerNick() == partnerNick &&
                    it->getFileName() == fileName &&
                    it->isResumed() )
                {
                    transfer = it;
                    qDebug() << "Filename match: " << fileName << ", claimed port: " << ownPort << ", item port: " << transfer->getOwnPort();
                    // the port number can be changed behind NAT, so we pick an item which only the filename is correspondent in that case.
                    if ( transfer->getOwnPort() == ownPort )
                    {
                        break;
                    }
                }
            }
```

#### AUTO 


```{c}
auto* channelListPanel=new ChannelListPanel(m_tabWidget);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &uign : unignoreList) {
                // If pattern looks incomplete, try to complete it
                if (!uign.contains('!'))
                {
                    QString fixedPattern = uign;
                    fixedPattern += QLatin1String("!*");

                    bool success = false;

                    // Try to remove completed pattern
                    if (Preferences::removeIgnore(fixedPattern))
                    {
                        succeeded.append(fixedPattern);
                        success = true;
                    }

                    // Try to remove the incomplete version too, in case it was added via the GUI ...
                    // FIXME: Validate patterns in GUI?
                    if (Preferences::removeIgnore(uign))
                    {
                        succeeded.append(uign);
                        success = true;
                    }

                    if (!success)
                        failed.append(uign + "[!*]");
                }
                // Try to remove seemingly complete pattern
                else if (Preferences::removeIgnore(uign))
                    succeeded.append(uign);
                // Failed to remove given complete pattern
                else
                    failed.append(uign);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QChar mode : modeString) {
                    QString parameter;

                    if (mode != QLatin1Char('+')) {
                        if(!modesAre.isEmpty())
                            modesAre+=QStringLiteral(", ");

                        if (mode == QLatin1Char('k')) {
                            parameter=parameterList.value(parameterCount++);
                            message += QLatin1Char(' ') + parameter;
                            modesAre+=i18n("password protected");
                        }
                        else if (mode == QLatin1Char('l')) {
                            parameter=parameterList.value(parameterCount++);
                            message += QLatin1Char(' ') + parameter;
                            modesAre+=i18np("limited to %1 user", "limited to %1 users", parameter.toInt());
                        }
                        else if (channelModesHash.contains(mode)) {
                            modesAre += channelModesHash.value(mode);
                        }
                        else
                        {
                            modesAre += mode;
                        }
                        m_server->updateChannelModeWidgets(parameterList.value(1), mode.toLatin1(), parameter);
                    }
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString& channels) { sendJoinCommand(channels); }
```

#### RANGE FOR STATEMENT 


```{c}
for (int encServer : encServers) {
        Konversation::ServerGroupSettingsPtr sgsp = Preferences::serverGroupById(encServer);

        if ( sgsp )  // sgsp == 0 when the entry is of QuickConnect or something?
        {
            const QStringList encChannels = Preferences::channelEncodingsChannelList(encServer);
            //ditto //encChannels.sort();
            for (const QString& encChannel : encChannels) {
                QString enc = Preferences::channelEncoding(encServer, encChannel);
                QString key = QLatin1Char(' ') + encChannel;
                if (sgKeys.contains(encServer))
                    key.prepend(QStringLiteral("ServerGroup ") + QString::number(sgKeys.value(encServer)));
                else
                    key.prepend(sgsp->name());
                cgEncoding.writeEntry(key, enc);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &cap : capsList) {
        nameValue = cap.split(QChar('='));

        if (nameValue.isEmpty())
            continue;

        if(nameValue.at(0) == QLatin1String("sasl"))
        {
            QString authCommand;

            if (getIdentity()) {
                // A username is optional SASL EXTERNAL and a client cert substitutes
                // for the password.
                if (getIdentity()->getAuthType() == QLatin1String("saslexternal")) {
                    authCommand = QStringLiteral("EXTERNAL");
                // PLAIN on the other hand requires both.
                } else if (getIdentity()->getAuthType() == QLatin1String("saslplain")
                    && !getIdentity()->getSaslAccount().isEmpty()
                    && !getIdentity()->getAuthPassword().isEmpty()) {
                    authCommand = QStringLiteral("PLAIN");
                }
            }

            if(!authCommand.isEmpty())
            {
                QStringList supportedSaslTypes;
                if(nameValue.size() > 1)
                    supportedSaslTypes = nameValue.at(1).split(QChar(','));

                supportedSaslTypes.removeDuplicates();

                if(!supportedSaslTypes.isEmpty() && !supportedSaslTypes.contains(authCommand))
                    getStatusView()->appendServerMessage(i18n("Error"), i18n("Server does not support %1 as SASL authentication mechanism, skipping SASL authentication.", authCommand));
                else
                    requestCaps.append (QStringLiteral("sasl"));
            }
        }
        else if(m_capabilityNames.contains(nameValue.at(0)))
        {
            requestCaps.append (nameValue.at(0));
        }

        // HACK: twitch.tv's IRC server doesn't handle WHO so
        // let's disable all WHO requests for servers that has
        // twitch.tv capabilities
        if(nameValue.at(0).startsWith("twitch.tv"))
        {
            m_whoRequestsDisabled = true;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KConfigDialogManager* manager : qAsConst(d->managerForPage)) {
            manager->updateWidgets();
        }
```

#### AUTO 


```{c}
auto *mainWidget = new QWidget(this);
```

#### AUTO 


```{c}
const auto rowIndices = m_transferView->rowIndexes();
```

#### AUTO 


```{c}
auto* nickChangeDialog = getStatusView()->findChild<QInputDialog*>();
```

#### RANGE FOR STATEMENT 


```{c}
for (Server* server : qAsConst(m_connectionList)) {
        server->involuntaryQuit();
    }
```

#### AUTO 


```{c}
const auto serverList = serverGroupSettings->serverList();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& warningDialogDefinition : warningDialogDefinitions) {
        const QLatin1String flagName(warningDialogDefinition.flagName);
        const QString message = warningDialogDefinition.message.toString();

        auto *item = new QTreeWidgetItem(dialogListView);
        item->setText(0, message);
        item->setFlags(item->flags() | Qt::ItemIsUserCheckable);
        item->setData(0, WarningNameRole, flagName);

        if (flagName == QLatin1String("LargePaste"))
        {
            item->setCheckState(0, grp.readEntry(flagName, QString()).isEmpty() ? Qt::Checked : Qt::Unchecked);
        }
        else if (flagName == QLatin1String("Invitation"))
        {
            item->setCheckState(0, grp.readEntry(flagName, QStringLiteral("0")) == QLatin1Char('0') ? Qt::Checked : Qt::Unchecked);
        }
        else
        {
            item->setCheckState(0, grp.readEntry(flagName, true) ? Qt::Checked : Qt::Unchecked);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& command : qAsConst(m_autoJoinCommands)) {
            queue(command);
        }
```

#### AUTO 


```{c}
auto* channel = static_cast<Channel*>(context);
```

#### AUTO 


```{c}
auto* action = new QAction(text, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &uign : unignoreList) {
                // If pattern looks incomplete, try to complete it
                if (!uign.contains(QLatin1Char('!'))) {
                    QString fixedPattern = uign;
                    fixedPattern += QLatin1String("!*");

                    bool success = false;

                    // Try to remove completed pattern
                    if (Preferences::removeIgnore(fixedPattern))
                    {
                        succeeded.append(fixedPattern);
                        success = true;
                    }

                    // Try to remove the incomplete version too, in case it was added via the GUI ...
                    // FIXME: Validate patterns in GUI?
                    if (Preferences::removeIgnore(uign))
                    {
                        succeeded.append(uign);
                        success = true;
                    }

                    if (!success)
                        failed.append(uign + QLatin1String("[!*]"));
                }
                // Try to remove seemingly complete pattern
                else if (Preferences::removeIgnore(uign))
                    succeeded.append(uign);
                // Failed to remove given complete pattern
                else
                    failed.append(uign);
            }
```

#### AUTO 


```{c}
auto *item = new QTreeWidgetItem(dialogListView);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { setPasswordChanged(); }
```

#### AUTO 


```{c}
auto* action = new QAction(text, m_parent);
```

#### CONST EXPRESSION 


```{c}
constexpr int MARGIN = 4;
```

#### RANGE FOR STATEMENT 


```{c}
for (QTreeWidgetItem* item : items) {
        if (indexOfTopLevelItem(item)<0) // is a child
        {
                children.append(item);
                parent = children.at(0)->parent();
                // make sure all the children have the same parent
                for (int i=0; i < children.count(); i++)
                {
                    if (children.at(i)->parent() != parent)
                        return true;
                }
        }
        else    t++;

        if (t > 0 && children.count() > 0) //make sure we don't have a top and a child selected
            return true;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (NickInfoPtr nickInfo : qAsConst(m_allNicks)) {
        if(nickInfo->isChanged())
        {
            Q_EMIT nickInfoChanged(this, nickInfo);
            nickInfo->setChanged(false);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction* action : qAsConst(self()->m_sharedBasicNickActions))
        action->setEnabled(connected);
```

#### AUTO 


```{c}
auto* secondItem = new QStandardItem();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &lin : lines) {
                    Q_EMIT receivedRawLine(lin);
                }
```

#### AUTO 


```{c}
auto* filePathToolsFrame = new QFrame(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& identityGroup : identities) {
        KSharedConfig::openConfig()->deleteGroup(identityGroup);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (TransferSend* it : qAsConst(m_sendItems)) {
                if ( ( it->getStatus() == Transfer::Queued || it->getStatus() == Transfer::WaitingRemote ) &&
                    it->getConnectionId() == connectionId &&
                    it->getPartnerNick() == partnerNick &&
                    it->getFileName() == fileName &&
                    !it->isResumed() )
                {
                    transfer = it;
                    qDebug() << "Filename match: " << fileName << ", claimed port: " << ownPort << ", item port: " << transfer->getOwnPort();
                    // the port number can be changed behind NAT, so we pick an item which only the filename is correspondent in that case.
                    if ( transfer->getOwnPort() == ownPort )
                    {
                        break;
                    }
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction* action : qAsConst(self()->m_sharedNickSettingsActions))
            action->setVisible(false);
```

#### RANGE FOR STATEMENT 


```{c}
for (KonviSettingsPage *page : qAsConst(m_pages)) {
    // this is for the non KConfigXT parts to update the UI (like quick buttons)
    page->saveSettings();
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (QString& chatWindow : m_chatWindowList) {
        chatWindow = chatWindow.trimmed();
    }
```

#### AUTO 


```{c}
auto *item = new QTreeWidgetItem(buttonListView, QStringList {
            definition.section(QLatin1Char(','), 0, 0),
            definition.section(QLatin1Char(','), 1)
        });
```

#### RANGE FOR STATEMENT 


```{c}
for (QTreeWidgetItem* item : selected) {
            if (item->data(0,IsServer).toBool())
            {
                ConnectionSettings settings;
                ServerGroupSettingsPtr serverGroup = Preferences::serverGroupById(item->data(0,ServerGroupId).toInt());
                settings.setServerGroup(serverGroup);

                settings.setServer(serverGroup->serverByIndex(item->data(0,ServerId).toInt()));

                emit connectTo(Konversation::PromptToReuseConnection, settings);
            }
            else
                emit connectTo(Konversation::PromptToReuseConnection, item->data(0,ServerGroupId).toInt());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& button : buttons) {
        pattern = button.section(QLatin1Char(','), 1);

        if (pattern.contains(QLatin1String("%u")))
        {
            action = new QAction(button.section(QLatin1Char(','), 0, 0), m_quickButtonMenu);
            action->setData(pattern);
            m_quickButtonMenu->addAction(action);
        }
    }
```

#### AUTO 


```{c}
auto* view = static_cast<ChatWindow* >(m_tabWidget->widget(0));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& out : qAsConst(result.outputList)) {
                    append(m_server->getNickname(), out);
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : selectedRowIndices) {
                if (index.data(TransferListModel::TransferStatus).toInt() < Transfer::Done)
                {
                    auto *transfer = qobject_cast<Transfer*>(index.data(TransferListModel::TransferPointer).value<QObject*>());
                    if (transfer)
                    {
                        transfer->abort();
                    }
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& identityGroup : identityList) {
            IdentityPtr newIdentity(new Identity());
            KConfigGroup cgIdentity(KSharedConfig::openConfig()->group(identityGroup));

            newIdentity->setName(cgIdentity.readEntry("Name"));

            newIdentity->setIdent(cgIdentity.readEntry("Ident"));
            newIdentity->setRealName(cgIdentity.readEntry("Realname"));

            newIdentity->setNicknameList(cgIdentity.readEntry<QStringList>("Nicknames",QStringList()));

            newIdentity->setAuthType(cgIdentity.readEntry("AuthType", "nickserv"));
            newIdentity->setAuthPassword(cgIdentity.readEntry("Password"));
            newIdentity->setNickservNickname(cgIdentity.readEntry("Bot"));
            newIdentity->setNickservCommand(cgIdentity.readEntry("NickservCommand", "identify"));
            newIdentity->setSaslAccount(cgIdentity.readEntry("SaslAccount"));
            newIdentity->setPemClientCertFile(cgIdentity.readEntry<QUrl>("PemClientCertFile", QUrl()));

            newIdentity->setInsertRememberLineOnAway(cgIdentity.readEntry("InsertRememberLineOnAway", false));
            newIdentity->setRunAwayCommands(cgIdentity.readEntry("ShowAwayMessage", false));
            newIdentity->setAwayCommand(cgIdentity.readEntry("AwayMessage"));
            newIdentity->setReturnCommand(cgIdentity.readEntry("ReturnMessage"));
            newIdentity->setAutomaticAway(cgIdentity.readEntry("AutomaticAway", false));
            newIdentity->setAwayInactivity(cgIdentity.readEntry("AwayInactivity", 10));
            newIdentity->setAutomaticUnaway(cgIdentity.readEntry("AutomaticUnaway", false));

            newIdentity->setQuitReason(cgIdentity.readEntry("QuitReason"));
            newIdentity->setPartReason(cgIdentity.readEntry("PartReason"));
            newIdentity->setKickReason(cgIdentity.readEntry("KickReason"));

            newIdentity->setShellCommand(cgIdentity.readEntry("PreShellCommand"));

            newIdentity->setCodecName(cgIdentity.readEntry("Codec"));

            newIdentity->setAwayMessage(cgIdentity.readEntry("AwayReason"));
            newIdentity->setAwayNickname(cgIdentity.readEntry("AwayNick"));

            Preferences::addIdentity(newIdentity);

        }
```

#### AUTO 


```{c}
auto* btnSuggestNewName = new QPushButton(i18n("Suggest &New Filename"),filePathToolsFrame);
```

#### AUTO 


```{c}
auto* nickitem = static_cast<NicksOnlineItem*>(nickRoot);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : rowIndices) {
                QVariant pointer = index.data(TransferListModel::TransferPointer);
                if (selectedItems.contains(pointer))
                {
                    selectedItems.removeOne(pointer);
                    rows.append(index.row());
                    if (selectedItems.isEmpty())
                    {
                        break;
                    }
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& entry : allEntries) {
            if (themeDir->entry(entry + QLatin1String("/index.desktop")) == nullptr) {
                KMessageBox::error(nullptr,
                    i18n("Theme archive is invalid."),
                    i18n("Cannot Install Theme"),
                    KMessageBox::Notify
                    );
                break;
            }
            else
                themeDir->copyTo(themesDir);

        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget* widget : allChildWidgets)
        widget->installEventFilter(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (Channel* channel : qAsConst(channelMap)) {
                    if (channel->autoJoin())
                    {
                        before = channel->channelSettings();

                        break;
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (Ignore* item : ignoreList) {
        ignoreRe.setPattern(QRegularExpression::anchoredPattern(QRegularExpression::escape(
                                item->getName()).replace(QLatin1String("\\*"), QLatin1String("(.*)"))));

        if (ignoreRe.match(sender).hasMatch()) {
            if (item->getFlags() & type) {
                doIgnore = true;
            }

            if (item->getFlags() & Ignore::Exception) {
                return false;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& join : oneShotJoin) {
            queue(join);
        }
```

#### AUTO 


```{c}
auto* menu = qobject_cast<QMenu*>(m_window->guiFactory()->container(QStringLiteral("tabContextMenu"), m_window));
```

#### AUTO 


```{c}
auto* quickButton = new QuickButton(QString(), QString(), m_buttonsGrid);
```

#### AUTO 


```{c}
const auto currentChatItems = m_chatItems;
```

#### AUTO 


```{c}
auto *frame = new QWidget(q);
```

#### RANGE FOR STATEMENT 


```{c}
for (Server* server : serverList) {
        IdentityPtr identity = server->getIdentity();

        if (identityList.contains(identity->id()) && identity->getAutomaticUnaway()
            && server->isConnected() && server->isAway())
        {
            server->requestUnaway();
        }
    }
```

#### AUTO 


```{c}
auto* modesModel = static_cast<QStandardItemModel *>(m_ui.otherModesList->model());
```

#### RANGE FOR STATEMENT 


```{c}
for (Server* server : qAsConst(m_connectionList)) {
        if (server->getDisplayName() == name || server->getServerName() == name) {
            return server;
        }
    }
```

#### AUTO 


```{c}
auto *job = new KIO::OpenUrlJob(getFileURL());
```

#### RANGE FOR STATEMENT 


```{c}
for (QTreeWidgetItem* item : qAsConst(selectedItems)) {
            if (item == m_selectedItemPtr)
                m_selectedItemPtr = nullptr;

            rootItem->removeChild(item);
            if (item->data(0,IsServer).toBool())
            {
                Konversation::ServerGroupSettingsPtr serverGroup = Preferences::serverGroupById(item->data(0,ServerGroupId).toInt());
                serverGroup->removeServer(serverGroup->serverByIndex(item->data(0,ServerId).toInt()));
            }
            else
            {
                Preferences::removeServerGroup(item->data(0,ServerGroupId).toInt());
            }
            delete item;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (KonviSettingsPage *page : qAsConst(m_pages)) {
    page->restorePageToDefaults();
  }
```

#### AUTO 


```{c}
const auto oneShotChannelList = settings.oneShotChannelList();
```

#### AUTO 


```{c}
auto* ircBox = new IRCViewBox(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (Nick* nick : qAsConst(nicknameList)) {
                        if(nick->getChannelNick()->getNickname().startsWith(pattern, Preferences::self()->nickCompletionCaseSensitive() ? Qt::CaseSensitive : Qt::CaseInsensitive) &&
                          (nick->getChannelNick()->timeStamp() > timeStamp))
                        {
                            timeStamp = nick->getChannelNick()->timeStamp();
                            completionPosition = listPosition;
                        }
                        ++listPosition;
                    }
```

#### AUTO 


```{c}
auto* mainLayout = new QVBoxLayout(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& channelName : nickChannels) {
            const ChannelNickMap *channel = getChannelMembers(channelName);
            Q_ASSERT(channel);
            ChannelNickPtr member = (*channel)[lcNickname];
            Q_ASSERT(member);
            const_cast<ChannelNickMap *>(channel)->remove(lcNickname);
            const_cast<ChannelNickMap *>(channel)->insert(lcNewname, member);
        }
```

#### AUTO 


```{c}
auto* transfer = new TransferRecv(this);
```

#### AUTO 


```{c}
auto* channel=new Channel(m_tabWidget, name);
```

#### AUTO 


```{c}
auto* renameAct = new QAction(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction* action : qAsConst(m_sharedDccActions))
        m_textMenu->addAction(action);
```

#### RANGE FOR STATEMENT 


```{c}
for (QChar c : text) {
                    em = qMax(em, fontMetrics().horizontalAdvance(c));
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& serverSertting : serverList) {
            if (serverSertting.host().toLower() == server)
                serverGroups.append(serverGroupSettings);
        }
```

#### AUTO 


```{c}
auto* vboxLayout = new QVBoxLayout(m_vbox);
```

#### RANGE FOR STATEMENT 


```{c}
for (Server* server : serverList) {
        if (server->getDisplayName() == networkName)
        {
            NickInfoPtr nickInfo = server->getNickInfo(nickname);
            if (nickInfo) return nickInfo;
        }
    }
```

#### AUTO 


```{c}
auto* view = qobject_cast<ChatWindow*>(m_tabWidget->widget(newIndex));
```

#### AUTO 


```{c}
auto *job = new KIO::OpenUrlJob(QUrl(url));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& out : outputList) {
                    result.toServerList += QLatin1String("PRIVMSG ") + destination + QLatin1String(" :") + out;
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &rowIndex : rowIndices) {
                auto *rowTransfer = qobject_cast<Transfer*>(rowIndex.data(TransferListModel::TransferPointer).value<QObject*>());
                if (rowTransfer == transfer)
                {
                    return rowIndex;
                }
            }
```

#### AUTO 


```{c}
const auto& warningDialogDefinition
```

#### AUTO 


```{c}
auto* layout = new QGridLayout(mainWidget);
```

#### AUTO 


```{c}
auto* action = qobject_cast<KToggleAction*>(actionCollection()->action(QStringLiteral("hide_nicknamelist")));
```

#### RANGE FOR STATEMENT 


```{c}
for (QString line : multiline) {
            QString cChar(Preferences::self()->commandChar());
            // make sure that lines starting with command char get escaped
            if(line.startsWith(cChar)) line=cChar+line;
            sendText(line);
        }
```

#### AUTO 


```{c}
auto * action = qobject_cast<QAction*>(sender());
```

#### AUTO 


```{c}
auto* layout = new QGridLayout (m_buttonsGrid);
```

#### RANGE FOR STATEMENT 


```{c}
for (Server* server : serverList) {
        if (server->getIdentity()->id() == identityId && server->isConnected() && !server->isAway())
            server->requestAway();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction* action : qAsConst(m_sharedDccActions))
        m_nickMenu->addAction(action);
```

#### AUTO 


```{c}
auto* proxy = qobject_cast<QSortFilterProxyModel*>(m_urlTree->model());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& index : selectedIndexes) {
        if (index.isValid())
        {
            QUrl url(index.data().toString());
            QUrl targetUrl = QFileDialog::getSaveFileUrl(this, i18n("Save link as"), QUrl::fromLocalFile(url.fileName()));

            if (targetUrl.isEmpty() || !targetUrl.isValid())
                continue;

            KIO::copy(url, targetUrl);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& dir : qAsConst(m_dirs)) {
            KDesktopFile themeRC(dir);
            // get the name and comment from the theme
            themeName = themeRC.readName();
            themeComment = themeRC.readComment();

            // extract folder name
            themeDir = dir.section(QLatin1Char('/'),-2,-2);
            // is this our currently used theme?
            if (themeDir==currentTheme)
            {
                // remember for hasChanged()
                m_oldTheme=themeDir;
                // remember for updatePreview()
                currentThemeIndex = i;
            }

            if (themeDir==QLatin1String("oxygen"))
                m_defaultThemeIndex= i;

            // if there was a comment to the theme, add it to the listview entry string
            if(!themeComment.isEmpty())
                themeName = themeName + QLatin1String(" (") + themeComment + QLatin1Char(')');

            // insert entry into the listview
            iconThemeIndex->addItem(themeName);

            // increment index counter
            ++i;
        }
```

#### AUTO 


```{c}
auto* codecAction = qobject_cast<KSelectAction*>(actionCollection()->action(QStringLiteral("tab_encoding")));
```

#### RANGE FOR STATEMENT 


```{c}
for (Server* server : serverList)
        if (server) hosts << server->getServerName();
```

#### AUTO 


```{c}
auto* tab = static_cast<ChatWindow*>(m_tabWidget->widget(i));
```

#### AUTO 


```{c}
auto* proxyModel = new UrlSortFilterProxyModel(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& nick : oldList) {
            if (nick.toLower() != lowered)
                newList << nick;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (TransferSend* it : qAsConst(m_sendItems)) {
                if ( ( it->getStatus() == Transfer::Queued || it->getStatus() == Transfer::WaitingRemote ) &&
                    it->getConnectionId() == connectionId &&
                    it->getPartnerNick() == partnerNick &&
                    it->getFileName() == fileName &&
                    !it->isResumed() )
                {
                    transfer = it;
                    qCDebug(KONVERSATION_LOG) << "Filename match: " << fileName << ", claimed port: " << ownPort << ", item port: " << transfer->getOwnPort();
                    // the port number can be changed behind NAT, so we pick an item which only the filename is correspondent in that case.
                    if ( transfer->getOwnPort() == ownPort )
                    {
                        break;
                    }
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& channelName : channelHistoryList) {
                KConfigGroup cgChanHistory(KSharedConfig::openConfig()->group(channelName));

                if (!cgChanHistory.readEntry("Name").isEmpty())
                {
                    channel.setName(cgChanHistory.readEntry("Name"));
                    channel.setPassword(cgChanHistory.readEntry("Password"));
                    channel.setNotificationsEnabled(cgChanHistory.readEntry("EnableNotifications", true));
                    channelHistory.append(channel);
                }
            }
```

#### AUTO 


```{c}
auto* filePathToolsLayout = new QHBoxLayout(filePathToolsFrame);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : rowIndices) {
                if (index.data(TransferListModel::TransferStatus).toInt() >= Transfer::Done)
                {
                    selection.append(QItemSelectionRange(index));
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QSslError& error : errors) {
            errorReason += error.errorString() + QLatin1Char(' ');
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : installedFiles) {
                // file strings are of pattern "[...]/konversation/themes/simpleminded/*"
                if (file.startsWith(dir)) {
                    // uninstall via KNS and be done
                    manager->uninstallEntry(entry);
                    isUninstalledByKNS = true;
                    break;
                }
            }
```

#### AUTO 


```{c}
auto* selectAction = new KSelectAction(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& nick : actualList) {
        if (!lcPrevISON.contains(QLatin1Char(' ') + nick + QLatin1Char(' '), Qt::CaseInsensitive)) {
            setWatchedNickOnline(nick);
            nicksOnlineChanged = true;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QStringList& definition : autoreplaceList) {
        // split definition in parts
        QString regex=definition.at(0);
        QString direction=definition.at(1);
        QString pattern=definition.at(2);
        QString replacement=definition.at(3);

        QString isDirection=output ? QStringLiteral("o") : QStringLiteral("i");

        // only replace if this pattern is for the specific direction or both directions
        if (direction==isDirection || direction==QStringLiteral("io"))
        {
            // regular expression pattern?
            if (regex== QLatin1Char('1'))
            {
                // create regex from pattern
                const QRegularExpression needleReg(pattern);
                int index = 0;
                int newIndex = index;

                do {
                    QRegularExpressionMatch rmatch;
                    // find matches
                    index = line.indexOf(needleReg, index, &rmatch);

                    if (index != -1)
                    {
                        // remember captured patterns
                        const QStringList captures = rmatch.capturedTexts();
                        QString replaceWith = replacement;

                        replaceWith.replace(QStringLiteral("%%"),QStringLiteral("%\x01")); // escape double %
                        // replace %0-9 in regex groups
                        for (int capture=0;capture<captures.count();capture++)
                        {
                            QString search = QStringLiteral("%%1").arg(capture);
                            replaceWith.replace(search, captures[capture]);
                        }
                        //Explanation why this is important so we don't forget:
                        //If somebody has a regex that say has a replacement of url.com/%1/%2 and the
                        //regex can either match one or two patterns, if the 2nd pattern match is left,
                        //the url is invalid (url.com/match/%2). This is expected regex behavior I'd assume.
                        replaceWith.remove(QRegularExpression(QStringLiteral("%[0-9]")));

                        replaceWith.replace(QStringLiteral("%\x01"),QStringLiteral("%")); // return escaped % to normal
                        // allow for var expansion in autoreplace
                        replaceWith = Konversation::doVarExpansion(replaceWith);
                        // replace input with replacement
                        line.replace(index, captures[0].length(), replaceWith);

                        newIndex = index + replaceWith.length();

                        if (cursorPos > -1 && cursorPos >= index)
                        {
                            if (cursorPos < index + captures[0].length())
                                cursorPos = newIndex;
                            else
                            {
                                if (captures[0].length() > replaceWith.length())
                                    cursorPos -= captures[0].length() - replaceWith.length();
                                else
                                    cursorPos += replaceWith.length() - captures[0].length();
                            }
                        }

                        index = newIndex;
                    }
                } while (index >= 0 && index < line.length());
            }
            else
            {
                int index = line.indexOf(pattern);
                while (index>=0)
                {
                    int length,nextLength,patLen,repLen;
                    patLen=pattern.length();

                    repLen=replacement.length();
                    length=index;
                    length+=patLen;
                    nextLength=length;
                    //nextlength is used to account for the replacement taking up less space
                    QChar before,after;
                    if (index!=0) before = line.at(index-1);
                    if (line.length() > length) after = line.at(length);

                    if (index==0 || before.isSpace() || before.isPunct())
                    {
                        if (line.length() == length || after.isSpace() || after.isPunct())
                        {
                            // allow for var expansion in autoreplace
                            replacement = Konversation::doVarExpansion(replacement);
                            line.replace(index,patLen,replacement);
                            nextLength = index+repLen;
                        }
                    }

                    if (cursorPos > -1 && cursorPos >= index)
                    {
                        if (cursorPos < length)
                            cursorPos = nextLength;
                        else
                        {
                            if (patLen > repLen)
                                cursorPos -= patLen - repLen;
                            else
                                cursorPos += repLen - patLen;
                        }
                    }

                    index = line.indexOf(pattern, nextLength);
                }
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (TransferRecv* it : currentRecvItems) {
                if (
                    it->getStatus() == Transfer::Queued &&
                    it->getConnectionId() == connectionId &&
                    (nickEmpty || it->getPartnerNick() == partnerNick) &&
                    (fileEmpty || it->getFileName() == fileName)
                )
                {
                    it->start();
                }
            }
```

#### AUTO 


```{c}
auto* router = qobject_cast<UPnPRouter*>(this->sender());
```

#### AUTO 


```{c}
const auto lookChannelNickList = lookChannel->getNickList();
```

#### AUTO 


```{c}
auto *action = new QAction(i18n("&Unaway"),this);
```

#### RANGE FOR STATEMENT 


```{c}
for (ChatWindow *view : qAsConst(topLevelViews)) {
        m_tabWidget->insertTab(insertIndex(view), view, QIcon(), view->getName().replace(QLatin1Char('&'), QLatin1String("&&")));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, openChannelListString, openLogFileString]() {
        // Reset action names.
        actionCollection()->action(QStringLiteral("tab_notifications"))->setText(i18n("Enable Notifications"));
        actionCollection()->action(QStringLiteral("toggle_away"))->setText(i18n("Set &Away Globally"));
        actionCollection()->action(QStringLiteral("irc_colors"))->setText(i18n("&IRC Color..."));
        actionCollection()->action(QStringLiteral("insert_character"))->setText(i18n("Special &Character..."));
        actionCollection()->action(QStringLiteral("insert_marker_line"))->setText(i18n("&Marker Line"));
        actionCollection()->action(QStringLiteral("open_channel_list"))->setText(openChannelListString);
        actionCollection()->action(QStringLiteral("open_logfile"))->setText(openLogFileString);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& nick : nicksList)
        m_inputFilter.setAutomaticRequest(QStringLiteral("USERHOST"), nick, true);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& encChannel : encChannels) {
                QString enc = Preferences::channelEncoding(encServer, encChannel);
                QString key = QLatin1Char(' ') + encChannel;
                if (sgKeys.contains(encServer))
                    key.prepend(QStringLiteral("ServerGroup ") + QString::number(sgKeys.value(encServer)));
                else
                    key.prepend(sgsp->name());
                cgEncoding.writeEntry(key, enc);
            }
```

#### AUTO 


```{c}
auto* transfer = qobject_cast< TransferSend* > ( item );
```

#### RANGE FOR STATEMENT 


```{c}
for (Server* server : serverList) {
        IdentityPtr identity = server->getIdentity();
        int identityId = identity->id();

        // Only add idle timeouts for identities which have auto-away
        // enabled.
        if (m_identitiesWithIdleTimesOnAutoAway.contains(identityId))
            // Update the idle timeout for the current identity.
            implementUpdateIdleTimeout(identityId);
    }
```

#### AUTO 


```{c}
auto *dlg = new KShortcutsDialog(KShortcutsEditor::AllActions, KShortcutsEditor::LetterShortcutsAllowed, this);
```

#### AUTO 


```{c}
auto* view = static_cast<ChatWindow*>(m_tabWidget->widget(i));
```

#### AUTO 


```{c}
auto* awayAction = new KToggleAction(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& mode : m_modeList) {
        if (mode[0] == QLatin1Char('k')) password = mode.mid(1);
    }
```

#### AUTO 


```{c}
auto* hostNameLabel = new QLabel(i18n("&Server host:"), page);
```

#### AUTO 


```{c}
auto* commandLineBoxLayout = new QHBoxLayout(commandLineBox);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &uri : uris)
         addDccSend(nick, uri);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& identity : identities) {
            m_mainWidget->m_identityCBox->addItem(identity->getName());
        }
```

#### AUTO 


```{c}
auto* newItem = new QTreeWidgetItem(aliasListView, aliasListView->topLevelItemCount());
```

#### AUTO 


```{c}
auto *job = new KIO::OpenFileManagerWindowJob(nullptr);
```

#### AUTO 


```{c}
auto *ircViewBox = new IRCViewBox(chatSplitter);
```

#### RANGE FOR STATEMENT 


```{c}
for (NickInfoPtr nickInfo : qAsConst(m_allNicks)) {
        if(nickInfo->isChanged())
        {
            emit nickInfoChanged(this, nickInfo);
            nickInfo->setChanged(false);
        }
    }
```

#### AUTO 


```{c}
auto *mainLayout = new QVBoxLayout;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& out : outList) {
        Konversation::OutputFilterResult result = getOutputFilter()->parse(getNickname(), out, QString());
        queue(result.toServer);
    }
```

#### AUTO 


```{c}
auto* dragMoveEvent = static_cast<QDragMoveEvent*>(event);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl& dir : qAsConst(dirList)) {
                KIO::StatJob* statJob = KIO::statDetails(dir, KIO::StatJob::SourceSide, KIO::StatNoDetails);
                statJob->exec();
                if (statJob->error())
                {
                    KIO::MkdirJob* job = KIO::mkdir(dir, -1);
                    if (!job->exec())
                    {
                        return false;
                    }
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (Server* server : qAsConst(m_connectionList)) {
            if (server->getConnectionSettings().server() == settings.server()) {
                dupe = server;
                dupeType = SameServer;

                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : selectedRowIndices) {
                auto *transfer = qobject_cast<Transfer*>(index.data(TransferListModel::TransferPointer).value<QObject*>());
                if (transfer)
                {
                    openLocation(transfer);
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (Nick *nick : qAsConst(nicknameList)) {
        nick->getChannelNick()->lessActive();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QTreeWidgetItem* child : qAsConst(children)) {
                    if (child->parent() != parent)
                        return true;
                }
```

#### AUTO 


```{c}
auto* buttonBox = new QDialogButtonBox(this);
```

#### AUTO 


```{c}
auto* action = new QAction(icon, text, m_parent);
```

#### LAMBDA EXPRESSION 


```{c}
[] (const ServerGroupSettingsPtr &left, const ServerGroupSettingsPtr &right)
        {
            return left->sortIndex() < right->sortIndex();
        }
```

#### AUTO 


```{c}
const auto& id
```

#### RANGE FOR STATEMENT 


```{c}
for (Nick* nick : qAsConst(nicknameList)) {
        if(nick->getChannelNick()->isChanged())
        {
            nick->refresh();

            if(nick->getChannelNick() == m_ownChannelNick)
            {
                refreshModeButtons();
            }
        }
    }
```

#### AUTO 


```{c}
auto* nicknameList = new QListView(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (TransferSend* it : qAsConst(m_sendItems)) {
                if ( ( it->getStatus() == Transfer::Queued || it->getStatus() == Transfer::WaitingRemote ) &&
                    it->getConnectionId() == connectionId &&
                    it->getPartnerNick() == partnerNick &&
                    it->getFileName() == fileName )
                {
                    transfer = it;
                    qDebug() << "Filename match: " << fileName;
                    break;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (Server* server : qAsConst(m_connectionList)) {
        server->reconnectServer();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString& nick : nicks)
                Preferences::removeNotify(server->getServerGroup()->id(), nick);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& encChannel : encChannels) {
                QString enc = Preferences::channelEncoding(encServer, encChannel);
                QString key = QLatin1Char(' ') + encChannel;
                if (sgKeys.contains(encServer))
                    key.prepend(QStringLiteral("ServerGroup ") + QString::number(sgKeys.indexOf(encServer)));
                else
                    key.prepend(sgsp->name());
                cgEncoding.writeEntry(key, enc);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& server : qAsConst(m_serverList)) {
            m_mainWidget->m_serverLBox->addItem(server.host());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QString output : connectCommandsList) {
            output = output.simplified();
            OutputFilter::replaceAliases(output);
            Konversation::OutputFilterResult result = getOutputFilter()->parse(getNickname(),output,QString());
            queue(result.toServer);
        }
```

#### AUTO 


```{c}
auto* nicknameLabel=new QLabel(i18n("N&ickname:"), page);
```

#### RANGE FOR STATEMENT 


```{c}
for (Server* lookServer : serverList) {
        if (lserverOrGroup.isEmpty()
            || lookServer->getServerName().toLower()==lserverOrGroup
            || lookServer->getDisplayName().toLower()==lserverOrGroup)
        {
            nickInfo = lookServer->getNickInfo(ircnick);
            if (nickInfo)
                return nickInfo;         //If we found one
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& server : serverList) {
            // Produce a string representation of the server object
            QString name = server.host();

            if (server.port() != 6667)
                name += QLatin1Char(':') + QString::number(server.port());

            if (server.SSLEnabled())
                name += QLatin1String(" (SSL)");

            // Insert the server into the list, as child of the server group list item
            QTreeWidgetItem* serverItem = new ServerListItem(networkItem, QStringList { name });
            serverItem->setData(0,ServerGroupId,serverGroup->id());
            serverItem->setData(0,SortIndex,i);
            serverItem->setData(0,IsServer,true);
            serverItem->setData(0,ServerId,i);
            serverItem->setFirstColumnSpanned(true);
            // Initialize a pointer to the new location of the last edited server
            if (m_selectedItem && m_selectedServer == server)
                m_selectedItemPtr = serverItem;

            ++i;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (TransferSend* sendItem : currentSendItems) {
                sendItem->abort();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& nickname : watchList) {
        NickInfoPtr nickInfo = getOnlineNickInfo(networkName, nickname);

        if (nickInfo && nickInfo->getPrintedOnline())
        {
            // Nick is online.
            // Which server did NickInfo come from?
            Server* server=nickInfo->getServer();
            // Construct additional information string for nick.
            bool needWhois = false;
            QString nickAdditionalInfo = getNickAdditionalInfo(nickInfo, needWhois);
            // Add to network if not already added.
            QTreeWidgetItem* nickRoot = findItemChild(networkRoot, nickname, NicksOnlineItem::NicknameItem);
            if (!nickRoot)
                nickRoot = new NicksOnlineItem(NicksOnlineItem::NicknameItem, networkRoot, nickname, nickAdditionalInfo);
            auto* nickitem = static_cast<NicksOnlineItem*>(nickRoot);
            nickitem->setConnectionId(server->connectionId ());
            // Mark nick as online
            nickitem->setOffline(false);
            // Update icon
            nickitem->setIcon(nlvcNick, m_onlineIcon);
            nickRoot->setText(nlvcAdditionalInfo, nickAdditionalInfo);
            nickRoot->setText(nlvcServerName, serverName);
            // If no additional info available, request a WHOIS on the nick.
            if (!m_whoisRequested)
            {
                if (needWhois)
                {
                    requestWhois(networkName, nickname);
                    m_whoisRequested = true;
                }
            }

            const QStringList channelList = server->getNickChannels(nickname);

            for (const QString& channelName : channelList) {
                // Known channels where nickname is online and mode in each channel.
                // FIXME: If user connects to multiple servers in same network, the
                // channel info will differ between the servers, resulting in inaccurate
                // mode and led info displayed.

                ChannelNickPtr channelNick = server->getChannelNick(channelName, nickname);
                QString nickMode;
                if (channelNick->hasVoice()) nickMode = nickMode + i18n(" Voice");
                if (channelNick->isHalfOp()) nickMode = nickMode + i18n(" HalfOp");
                if (channelNick->isOp()) nickMode = nickMode + i18n(" Operator");
                if (channelNick->isOwner()) nickMode = nickMode + i18n(" Owner");
                if (channelNick->isAdmin()) nickMode = nickMode + i18n(" Admin");
                QTreeWidgetItem* channelItem = findItemChild(nickRoot, channelName, NicksOnlineItem::ChannelItem);
                if (!channelItem) channelItem = new NicksOnlineItem(NicksOnlineItem::ChannelItem,nickRoot,
                        channelName, nickMode);
                channelItem->setText(nlvcAdditionalInfo, nickMode);

                // Icon for mode of nick in each channel.
                Images::NickPrivilege nickPrivilege = Images::Normal;
                if (channelNick->hasVoice()) nickPrivilege = Images::Voice;
                if (channelNick->isHalfOp()) nickPrivilege = Images::HalfOp;
                if (channelNick->isOp()) nickPrivilege = Images::Op;
                if (channelNick->isOwner()) nickPrivilege = Images::Owner;
                if (channelNick->isAdmin()) nickPrivilege = Images::Admin;
                const bool isAway = (server->getJoinedChannelMembers(channelName) == nullptr);
                channelItem->setIcon(nlvcChannel,
                                     Application::instance()->images()->getNickIcon(nickPrivilege, isAway));
            }
            // Remove channel if nick no longer in it.
            for (int i = 0; i < nickRoot->childCount(); ++i)
            {
                QTreeWidgetItem* child = nickRoot->child(i);
                if (!channelList.contains(child->text(nlvcNick)))
                {
                    delete nickRoot->takeChild(i);
                    i--;
                }
            }
        }
        else
        {
            // Nick is offline.
            QTreeWidgetItem* nickRoot = findItemChild(networkRoot, nickname, NicksOnlineItem::NicknameItem);
            if (!nickRoot)
                nickRoot = new NicksOnlineItem(NicksOnlineItem::NicknameItem, networkRoot, nickname);
            // remove channels from the nick
            qDeleteAll(nickRoot->takeChildren());
            auto* nickitem = static_cast<NicksOnlineItem*>(nickRoot);
            nickitem->setConnectionId(servr->connectionId ());
            // Mark nick as offline
            nickitem->setOffline (true);
            // Update icon
            nickitem->setIcon(nlvcNick, m_offlineIcon);
            nickRoot->setText(nlvcServerName, serverName);
            nickRoot->setText(nlvcAdditionalInfo, QString());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& warningDialogDefinition : warningDialogDefinitions) {
        const QLatin1String flagName(warningDialogDefinition.flagName);
        const char * const message(warningDialogDefinition.message);
        const char * const ctx(warningDialogDefinition.context);

        QTreeWidgetItem *item = new QTreeWidgetItem(dialogListView);
        item->setText(0, i18nc(ctx, message));
        item->setFlags(item->flags() | Qt::ItemIsUserCheckable);
        item->setData(0, WarningNameRole, flagName);

        if (flagName == QLatin1String("LargePaste"))
        {
            item->setCheckState(0, grp.readEntry(flagName, QString()).isEmpty() ? Qt::Checked : Qt::Unchecked);
        }
        else if (flagName == QLatin1String("Invitation"))
        {
            item->setCheckState(0, grp.readEntry(flagName, QStringLiteral("0")) == QLatin1Char('0') ? Qt::Checked : Qt::Unchecked);
        }
        else
        {
            item->setCheckState(0, grp.readEntry(flagName, true) ? Qt::Checked : Qt::Unchecked);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QPair<QString, QString>& uri : channelsURI) {
        list << KBookmarkOwner::FutureBookmark(uri.first, QUrl(uri.second), QString());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : selectedRowIndices) {
                if (index.data(TransferListModel::TransferType).toInt() == Transfer::Send &&
                    index.data(TransferListModel::TransferStatus).toInt() >= Transfer::Done)
                {
                    Transfer *transfer = qobject_cast<Transfer*>(index.data(TransferListModel::TransferPointer).value<QObject*>());
                    if (!transfer)
                    {
                        continue;
                    }
                    transferList.append(transfer);
                }
            }
```

#### AUTO 


```{c}
auto* event = static_cast<QKeyEvent*>(e);
```

#### AUTO 


```{c}
auto* ircViewBox = new IRCViewBox(m_horizSplitter);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& searchProvider : searchProviders) {
                action = new QAction(searchProvider, m_webShortcutsMenu);
                action->setIcon(QIcon::fromTheme(filterData.iconNameForPreferredSearchProvider(searchProvider)));
                action->setData(filterData.queryForPreferredSearchProvider(searchProvider));
                connect(action, &QAction::triggered, this, &IrcContextMenus::processWebShortcutAction);
                m_webShortcutsMenu->addAction(action);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : selectedRowIndices) {
                if (index.data(TransferListModel::TransferType).toInt() == Transfer::Receive &&
                    index.data(TransferListModel::TransferStatus).toInt() == Transfer::Queued)
                {
                    auto *transfer = qobject_cast<Transfer*>(index.data(TransferListModel::TransferPointer).value<QObject*>());
                    if (transfer)
                    {
                        transfer->start();
                    }
                }
            }
```

#### AUTO 


```{c}
auto *tRectangle = new QListWidgetItem(QString(), m_formOptionListWidget, QListWidgetItem::UserType +1);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& nickName : qAsConst(m_watchList)) {
            if (m_server->getNickJoinedChannels(nickName).isEmpty()) {
                m_ISONList.append(nickName);
            }
        }
```

#### AUTO 


```{c}
auto* action = new QAction(icon, text, this);
```

#### AUTO 


```{c}
auto* channelListAction = qobject_cast<KToggleAction*>(actionCollection()->action(QStringLiteral("open_channel_list")));
```

#### AUTO 


```{c}
auto* view = static_cast<ChatWindow*>(m_tabWidget->widget(index));
```

#### AUTO 


```{c}
auto* selectedItem=dynamic_cast<IgnoreListViewItem*>(ignoreListView->currentItem());
```

#### AUTO 


```{c}
const auto* action = qobject_cast<const QAction*>(sender());
```

#### AUTO 


```{c}
auto* showURLmenu = new QMenu(i18n("Open URL"), menu);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& definition : buttonList) {
        auto *item = new QTreeWidgetItem(buttonListView, QStringList {
            definition.section(QLatin1Char(','), 0, 0),
            definition.section(QLatin1Char(','), 1)
        });

        item->setFlags(item->flags() &~ Qt::ItemIsDropEnabled);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Highlight* currentHighlight : highlightList) {
        HighlightViewItem *item = new HighlightViewItem(highlightListView,currentHighlight);
        item->setFlags(item->flags() &~ Qt::ItemIsDropEnabled);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& output : outList) {

        // encoding stuff is done in Server()
        Konversation::OutputFilterResult result = m_server->getOutputFilter()->parse(m_server->getNickname(), output, getName(), this);

        if(!result.output.isEmpty())
        {
            if(result.type == Konversation::Action) appendAction(m_server->getNickname(), result.output);
            else if(result.type == Konversation::Command) appendCommandMessage(result.typeString, result.output);
            else if(result.type == Konversation::Program) appendServerMessage(result.typeString, result.output);
            else if(result.type == Konversation::PrivateMessage) msgHelper(result.typeString, result.output);
            else if(!result.typeString.isEmpty()) appendQuery(result.typeString, result.output);
            else appendQuery(m_server->getNickname(), result.output);
        }
        else if (!result.outputList.isEmpty()) {
            if (result.type == Konversation::Message)
            {
                for (const QString& out : qAsConst(result.outputList)) {
                    appendQuery(m_server->getNickname(), out);
                }
            }
            else if (result.type == Konversation::Action)
            {
                for (int i = 0; i < result.outputList.count(); ++i)
                {
                    if (i == 0)
                        appendAction(m_server->getNickname(), result.outputList.at(i));
                    else
                        appendQuery(m_server->getNickname(), result.outputList.at(i));
                }
            }
        }

        // Send anything else to the server
        if (!result.toServerList.empty())
            m_server->queueList(result.toServerList);
        else
            m_server->queue(result.toServer);
    }
```

#### AUTO 


```{c}
const auto& server
```

#### AUTO 


```{c}
auto callWatcher = new QDBusPendingCallWatcher(listNamesCall, this);
```

#### AUTO 


```{c}
auto* action = qobject_cast<KToggleAction*>(actionCollection()->action(QStringLiteral("tab_notifications")));
```

#### AUTO 


```{c}
auto *job = new KIO::OpenUrlJob(QUrl::fromLocalFile(file), QStringLiteral("text/plain"));
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction* action : channelMenuActions)
        action->setEnabled(connected);
```

#### AUTO 


```{c}
auto* mainLayout = new QGridLayout(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (Query* query : qAsConst(m_queryList)) {
        query->sendText(text);
    }
```

#### AUTO 


```{c}
const auto* helpEvent = static_cast<QHelpEvent*>(event);
```

#### LAMBDA EXPRESSION 


```{c}
[=](const KNSCore::EntryInternal::List &entries) {
        bool isUninstalledByKNS = false;

        for (auto &entry : entries) {
            const QStringList installedFiles = entry.installedFiles();
            for (const QString &file : installedFiles) {
                // file strings are of pattern "[...]/konversation/themes/simpleminded/*"
                if (file.startsWith(dir)) {
                    // uninstall via KNS and be done
                    manager->uninstallEntry(entry);
                    isUninstalledByKNS = true;
                    break;
                }
            }
            if (isUninstalledByKNS) {
                break;
            }
        }

        if (isUninstalledByKNS) {
            loadSettings();
        } else {
            // manually installed, so delete manually
            KIO::DeleteJob* job = KIO::del(QUrl::fromLocalFile(dir));
            connect(job, &KIO::DeleteJob::result, this, &Theme_Config::postRemoveTheme);
        }

        manager->deleteLater();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Channel* channel : channelList) {
            if (channel->isJoined())
                joinedChannels.append(channel->getName());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& index : selectedIndexes)
        if (index.isValid()) urls << index.data().toString();
```

#### AUTO 


```{c}
auto *boxLayout = new QVBoxLayout(frame);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &removedIndex : qAsConst(indexesToRemove)) {
                    if (removedIndex.row() < index.row())
                    {
                        ++offset;
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& channel : qAsConst(m_changedChannels)) {
        if (m_joinedChannels.contains (channel))
        {
            Q_EMIT channelNickChanged(channel);

            for (ChannelNickPtr nick : qAsConst(*m_joinedChannels[channel])) {
                if(nick->isChanged())
                {
                    nick->setChanged(false);
                }
            }
        }
    }
```

#### AUTO 


```{c}
auto job = new KIO::CommandLauncherJob(QStringLiteral("kcmshell5"), {QStringLiteral("webshortcuts")});
```

#### AUTO 


```{c}
auto* inputBoxLayout = new QHBoxLayout(inputBox);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QStringList &definition : autoreplaceList) {
    // cut definition apart in name and action, and create a new listview item
    auto* newItem=new QTreeWidgetItem(patternListView);
    newItem->setFlags(newItem->flags() &~ Qt::ItemIsDropEnabled);
    newItem->setCheckState(0, Qt::Unchecked);
    // Regular expression?
    if (definition.at(0)== QLatin1Char('1')) newItem->setCheckState(0, Qt::Checked);
    // direction input/output/both
    if (definition.at(1)== QLatin1Char('i'))
    {
        newItem->setText(1,directionCombo->itemText(DIRECTION_INPUT));
    }
    else if (definition.at(1)== QLatin1Char('o'))
    {
        newItem->setText(1,directionCombo->itemText(DIRECTION_OUTPUT));
    }
    else if (definition.at(1)==QLatin1String("io"))
    {
        newItem->setText(1,directionCombo->itemText(DIRECTION_BOTH));
    }
    // pattern
    newItem->setText(2,definition.at(2));
    // replacement
    newItem->setText(3,definition.at(3));
    // hidden column, so we are independent of the i18n()ed display string
    newItem->setText(4,definition.at(1));
  }
```

#### LAMBDA EXPRESSION 


```{c}
[] (const ServerGroupSettingsPtr &left, const ServerGroupSettingsPtr &right)
            {
                return left->sortIndex() < right->sortIndex();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (QStandardItem* item : qAsConst(items))
                    item->setEnabled(m_isAnyTypeOfOp);
```

#### AUTO 


```{c}
const auto* view = static_cast<ChatWindow*>(m_tabWidget->widget(i));
```

#### AUTO 


```{c}
auto* statusView = static_cast<ChatWindow*>(parent.internalPointer());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : qAsConst(indexesToRemove)) {
                m_transferView->model()->removeRow(index.row(), QModelIndex());
                //needed, otherwise valid rows "can be treated" as invalid,
                //proxymodel does not keep up with changes
                m_transferView->updateModel();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (Chat* chatItem : currentChatItems) {
                chatItem->close();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (TransferRecv* it : m_recvItems) {
                if (it->getStatus() == Transfer::Transferring)
                    return true;
            }
```

#### AUTO 


```{c}
auto* inputBox=new QWidget(this);
```

#### AUTO 


```{c}
auto *chatcontainer = new DCC::ChatContainer(m_tabWidget,chat);
```

#### CONST EXPRESSION 


```{c}
constexpr int LED_ICON_SIZE = 14;
```

#### AUTO 


```{c}
auto* viewTree = qobject_cast<ViewTree*>(widget->parent());
```

#### RANGE FOR STATEMENT 


```{c}
for (TransferRecv* recvItem : currentRecvItems) {
                recvItem->abort();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& identity : identities) {
        if (identity->id() == id) {
            return identity;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=] { m_viewContainer->goToView(static_cast<int>(i - 1)); }
```

#### AUTO 


```{c}
auto* w = new QWidget(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& channel : qAsConst(m_channelList)) {
            m_mainWidget->m_channelLBox->addItem(channel.name());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const IdentityPtr &id : ids) {
            m_identityCBox->addItem(id->getName());
            m_identityList.append( IdentityPtr( id ) );
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QPersistentModelIndex& index : qAsConst(selectedIndices))
        if (index.isValid()) konvApp->getUrlModel()->removeRow(index.row());
```

#### AUTO 


```{c}
const auto currentSendItems = m_sendItems;
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction* action : qAsConst(m_sharedBasicNickActions))
        m_textMenu->addAction(action);
```

#### RANGE FOR STATEMENT 


```{c}
for (Server* server : serverList) {
                if ((server->getServerName() == serverName) &&
                    (server->getDisplayName() == networkName)) found = true;
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (QChar c : nickname) {
            nickvalue += c.unicode();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (int serverId : serverIds) {
            const QString codec = channelEncoding(serverId, channel);
            if(!codec.isEmpty())
                return codec;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& script : scripts) {
        if (!aliasList.contains(script)) {
            changed = true;
            aliasList.append(script);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : selectedRowIndices) {
                Transfer *transfer = qobject_cast<Transfer*>(index.data(TransferListModel::TransferPointer).value<QObject*>());
                if (transfer)
                {
                    openLocation(transfer);
                }
            }
```

#### AUTO 


```{c}
auto* st = static_cast<KIO::StoredTransferJob*>(j);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString& name) { sendJoinCommand(name); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& serverGroupSettings : serverGroupHash) {
        if (serverGroupSettings->name().toLower() == server.toLower())
            return true;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& definition : buttonList) {
        QTreeWidgetItem *item = new QTreeWidgetItem(buttonListView, QStringList {
            definition.section(QLatin1Char(','), 0, 0),
            definition.section(QLatin1Char(','), 1)
        });

        item->setFlags(item->flags() &~ Qt::ItemIsDropEnabled);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Channel* channel : qAsConst(m_channelList)) {
            tmpList << channel->channelSettings();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& serverGroup : serverGroupHash) {
        sortedServerGroupMap.insert(serverGroup->sortIndex(), serverGroup);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &dir : scriptDirs) {

        const QStringList scriptFiles = QDir(dir).entryList(QDir::Files | QDir::NoDotAndDotDot | QDir::Executable);

        for (const QString &script : scriptFiles) {
            scripts << script;
        }
    }
```

#### AUTO 


```{c}
auto* jc = new JapaneseCode();
```

#### RANGE FOR STATEMENT 


```{c}
for (ChatWindow *view : qAsConst(nonTopLevelViews)) {
        m_tabWidget->insertTab(insertIndex(view), view, QIcon(), view->getName().replace('&', QLatin1String("&&")));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction* action : qAsConst(self()->m_sharedDccActions))
        action->setVisible(showNickActions);
```

#### AUTO 


```{c}
auto *ev=new KNotification(QStringLiteral("query"));
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction* action : qAsConst(m_sharedNickSettingsActions))
        m_nickMenu->addAction(action);
```

#### AUTO 


```{c}
auto *treeWidgetItem = new QTreeWidgetItem(aliasListView, QStringList {
            item.section(QLatin1Char(' '), 0, 0),
            item.section(QLatin1Char(' '), 1)
        });
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& warningDialogDefinition : warningDialogDefinitions) {
        const QLatin1String flagName(warningDialogDefinition.flagName);
        const char * const message(warningDialogDefinition.message);
        const char * const ctx(warningDialogDefinition.context);

        auto *item = new QTreeWidgetItem(dialogListView);
        item->setText(0, i18nc(ctx, message));
        item->setFlags(item->flags() | Qt::ItemIsUserCheckable);
        item->setData(0, WarningNameRole, flagName);

        if (flagName == QLatin1String("LargePaste"))
        {
            item->setCheckState(0, grp.readEntry(flagName, QString()).isEmpty() ? Qt::Checked : Qt::Unchecked);
        }
        else if (flagName == QLatin1String("Invitation"))
        {
            item->setCheckState(0, grp.readEntry(flagName, QStringLiteral("0")) == QLatin1Char('0') ? Qt::Checked : Qt::Unchecked);
        }
        else
        {
            item->setCheckState(0, grp.readEntry(flagName, true) ? Qt::Checked : Qt::Unchecked);
        }
    }
```

#### AUTO 


```{c}
auto *transfer = qobject_cast<Transfer*>(index.data(TransferListModel::TransferPointer).value<QObject*>());
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction* action : qAsConst(m_sharedBasicNickActions))
        m_nickMenu->addAction(action);
```

#### RANGE FOR STATEMENT 


```{c}
for (Nick* nick : *this) {
        if (nick->getChannelNick()->getNickname()==nickname)
            return true;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& groupName : groups) {
            KConfigGroup cgServerGroup(KSharedConfig::openConfig()->group(groupName));
            Konversation::ServerGroupSettingsPtr serverGroup(new Konversation::ServerGroupSettings);
            serverGroup->setName(cgServerGroup.readEntry("Name"));
            serverGroup->setSortIndex(groups.at(index).section(QLatin1Char(' '), -1).toInt());
            serverGroup->setIdentityId(Preferences::identityByName(cgServerGroup.readEntry("Identity"))->id());
            serverGroup->setConnectCommands(cgServerGroup.readEntry("ConnectCommands"));
            serverGroup->setAutoConnectEnabled(cgServerGroup.readEntry("AutoConnect", false));
            serverGroup->setNotificationsEnabled(cgServerGroup.readEntry("EnableNotifications", true));
            serverGroup->setExpanded(cgServerGroup.readEntry("Expanded", false));

            notifyList.insert((*serverGroup).id(), cgServerGroup.readEntry("NotifyList", QString()).split(QLatin1Char(' '), QString::SkipEmptyParts));

            const QStringList serverNames = cgServerGroup.readEntry("ServerList", QStringList());
            for (const QString& serverName : serverNames) {
                KConfigGroup cgServer(KSharedConfig::openConfig()->group(serverName));
                server.setHost(cgServer.readEntry("Server"));
                server.setPort(cgServer.readEntry<int>("Port", 0));
                server.setPassword(cgServer.readEntry("Password"));
                server.setSSLEnabled(cgServer.readEntry("SSLEnabled", false));
                server.setBypassProxy(cgServer.readEntry("BypassProxy", false));
                serverGroup->addServer(server);
            }

            //config->setGroup(groupName);
            const QStringList autoJoinChannels = cgServerGroup.readEntry("AutoJoinChannels", QStringList());

            for (const QString& channelName : autoJoinChannels) {
                KConfigGroup cgJoin(KSharedConfig::openConfig()->group(channelName));

                if (!cgJoin.readEntry("Name").isEmpty())
                {
                    channel.setName(cgJoin.readEntry("Name"));
                    channel.setPassword(cgJoin.readEntry("Password"));
                    serverGroup->addChannel(channel);
                }
            }

            //config->setGroup(groupName);
            const QStringList channelHistoryList = cgServerGroup.readEntry("ChannelHistory", QStringList());
            channelHistory.clear();

            for (const QString& channelName : channelHistoryList) {
                KConfigGroup cgChanHistory(KSharedConfig::openConfig()->group(channelName));

                if (!cgChanHistory.readEntry("Name").isEmpty())
                {
                    channel.setName(cgChanHistory.readEntry("Name"));
                    channel.setPassword(cgChanHistory.readEntry("Password"));
                    channel.setNotificationsEnabled(cgChanHistory.readEntry("EnableNotifications", true));
                    channelHistory.append(channel);
                }
            }

            serverGroup->setChannelHistory(channelHistory);

            serverGroups.insert(serverGroup->id(), serverGroup);
            sgKeys.append(serverGroup->id());

            index++;
        }
```

#### AUTO 


```{c}
const auto& serverGroupSettings
```

#### AUTO 


```{c}
auto* notificationGroup = new KPageWidgetItem(new QWidget(this), i18n("Notifications"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& serverGroupGroup : serverGroupGroups) {
        KSharedConfig::openConfig()->deleteGroup(serverGroupGroup);
    }
```

#### AUTO 


```{c}
const auto& channel
```

#### AUTO 


```{c}
auto *item = new KPageWidgetItem(frame, itemName);
```

#### RANGE FOR STATEMENT 


```{c}
for (QString& s : list)
            sterilizeUnicode(s);
```

#### AUTO 


```{c}
auto it = forwards.begin();
```

#### AUTO 


```{c}
auto* item = new HighlightViewItem(highlightListView, newHighlight);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& mode : qAsConst(m_modeList)) {
        if (mode[0] == QLatin1Char('k'))
            k = mode;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { m_viewContainer->openChannelList(); }
```

#### AUTO 


```{c}
auto* dialog = new KBookmarkDialog(manager, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (QTreeWidgetItem* item : selected) {
            if (item->data(0,IsServer).toBool())
            {
                ConnectionSettings settings;
                ServerGroupSettingsPtr serverGroup = Preferences::serverGroupById(item->data(0,ServerGroupId).toInt());
                settings.setServerGroup(serverGroup);

                settings.setServer(serverGroup->serverByIndex(item->data(0,ServerId).toInt()));

                Q_EMIT connectTo(Konversation::PromptToReuseConnection, settings);
            }
            else
                Q_EMIT connectTo(Konversation::PromptToReuseConnection, item->data(0,ServerGroupId).toInt());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (int serverId : serverIds)
            setChannelEncoding(serverId, channel, encoding);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& prefsWatch : prefsWatchList) {
            ISONMap.insert(prefsWatch.toLower(), prefsWatch);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { refreshEnableModes(); }
```

#### LAMBDA EXPRESSION 


```{c}
[](KConfigDialogManager* manager) { return manager->isDefault(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (Query* lookQuery : m_queryList) {
        if(!nickList.contains(lookQuery->getName())) nickList.append(lookQuery->getName());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Channel* channel : qAsConst(m_channelList)) {
            channelList << channel->channelSettings();
        }
```

#### AUTO 


```{c}
const auto themeDirs = dir.entryList(QDir::AllDirs | QDir::NoDotAndDotDot);
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction* action : qAsConst(m_itemActions))
        action->setEnabled(enable);
```

#### CONST EXPRESSION 


```{c}
constexpr int DELAYED_SORT_TRIGGER = 10;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl& fileUrl : fileURLs) {
            addDccSend(recipient, fileUrl, dlg->passiveSend());
        }
```

#### AUTO 


```{c}
auto* selectedItem=dynamic_cast<IgnoreListViewItem*>(item);
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction* action : actions) {
            if (action->shortcuts().contains(QKeySequence(key)))
            {
                event->ignore();
                return false;
            }
        }
```

#### AUTO 


```{c}
auto *tAction = new QAction(m_dccModel->headerData(i, Qt::Horizontal, Qt::DisplayRole).toString(), &menu);
```

#### AUTO 


```{c}
const auto configurations = manager.allConfigurations();
```

#### RANGE FOR STATEMENT 


```{c}
for (KonviSettingsPage *page : qAsConst(m_pages)) {
    if (page->hasChanged())
    {
      m_modified = true;
//      qDebug() << "modified!";
      break;
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : selectedIndexes) {
                selectedItems.append(index.data(TransferListModel::TransferPointer));
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (Server* server : qAsConst(m_connectionList)) {
        if (server->getServerGroup() && settings.serverGroup()
            && server->getServerGroup() == settings.serverGroup())
        {
            dupe = server;
            dupeType = SameServerGroup;

            break;
        }
    }
```

#### AUTO 


```{c}
auto* proxy = qobject_cast<QSortFilterProxyModel*>(m_ui.topicHistoryView->model());
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction* action : nickMenuActions)
        action->setVisible(true);
```

#### AUTO 


```{c}
auto* ke = static_cast<QKeyEvent*>(e);
```

#### AUTO 


```{c}
auto* dialogLayout = new QVBoxLayout(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (Server* server : serverList)
        if (server && server->isConnected()) connectedHosts << server->getServerName();
```

#### AUTO 


```{c}
auto *q=new IRCQueue(this, Application::instance()->staticrates[i]);
```

#### RANGE FOR STATEMENT 


```{c}
for (ChannelNickPtr nick : qAsConst(*m_joinedChannels[channel])) {
                if(nick->isChanged())
                {
                    nick->setChanged(false);
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& channel : channelList) {
            const QString groupName = QStringLiteral("Channel %1").arg(index3);
            channels.append(groupName);
            KConfigGroup cgChannel(KSharedConfig::openConfig()->group(groupName));
            cgChannel.writeEntry("Name", channel.name());
            cgChannel.writeEntry("Password", channel.password());
            index3++;
        }
```

#### AUTO 


```{c}
const auto highlightList = Preferences::highlightList();
```

#### AUTO 


```{c}
auto* newItem=new QTreeWidgetItem(patternListView);
```

#### AUTO 


```{c}
auto* area = new QScrollArea(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (Channel* channel : qAsConst(m_channelList)) {
        channel->sendText(text);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &currentMode : modes) {
            mode = currentMode[0].toLatin1();
            switch(mode)
            {
                case 't':
                    m_ui.topicModeChBox->setChecked(true);
                    break;
                case 'n':
                    m_ui.messageModeChBox->setChecked(true);
                    break;
                case 'l':
                    m_ui.userLimitChBox->setChecked(true);
                    m_ui.userLimitEdit->setValue(currentMode.midRef(1).toInt());
                    break;
                case 'i':
                    m_ui.inviteModeChBox->setChecked(true);
                    break;
                case 'm':
                    m_ui.moderatedModeChBox->setChecked(true);
                    break;
                case 's':
                    m_ui.secretModeChBox->setChecked(true);
                    break;
                case 'k':
                    m_ui.keyModeChBox->setChecked(true);
                    m_ui.keyModeEdit->setText(currentMode.mid(1));
                    break;
                default:
                {
                    bool found = false;
                    QString modeString;
                    modeString = QLatin1Char(mode);

                    for (int i = 0; !found && i < modesModel->rowCount(); ++i)
                    {
                        QStandardItem *item = modesModel->item(i, 0);
                        if (item->data().toString() == modeString)
                        {
                            found = true;
                            item->setCheckState(Qt::Checked);
                            modesModel->item(i, 1)->setText(currentMode.mid(1));
                        }
                    }

                    break;
                }
            }
        }
```

#### CONST EXPRESSION 


```{c}
constexpr int DIRECTION_INPUT  = 1;
```

#### AUTO 


```{c}
auto* label = new TopicHistoryLabel();
```

#### RANGE FOR STATEMENT 


```{c}
for (Server* server : serverList)
        connections << QString::number(server->connectionId());
```

#### AUTO 


```{c}
auto* channel = static_cast<Channel*>(view);
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction* action : qAsConst(self()->m_sharedBasicNickActions))
        action->setVisible(showNickActions);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& groupName : groups) {
            KConfigGroup cgServerGroup(KSharedConfig::openConfig()->group(groupName));
            Konversation::ServerGroupSettingsPtr serverGroup(new Konversation::ServerGroupSettings);
            serverGroup->setName(cgServerGroup.readEntry("Name"));
            serverGroup->setSortIndex(groupName.section(QLatin1Char(' '), -1).toInt());
            serverGroup->setIdentityId(Preferences::identityByName(cgServerGroup.readEntry("Identity"))->id());
            serverGroup->setConnectCommands(cgServerGroup.readEntry("ConnectCommands"));
            serverGroup->setAutoConnectEnabled(cgServerGroup.readEntry("AutoConnect", false));
            serverGroup->setNotificationsEnabled(cgServerGroup.readEntry("EnableNotifications", true));
            serverGroup->setExpanded(cgServerGroup.readEntry("Expanded", false));

            notifyList.insert((*serverGroup).id(), cgServerGroup.readEntry("NotifyList", QString()).split(QLatin1Char(' '), Qt::SkipEmptyParts));

            const QStringList serverNames = cgServerGroup.readEntry("ServerList", QStringList());
            for (const QString& serverName : serverNames) {
                KConfigGroup cgServer(KSharedConfig::openConfig()->group(serverName));
                server.setHost(cgServer.readEntry("Server"));
                server.setPort(cgServer.readEntry<int>("Port", 0));
                server.setPassword(cgServer.readEntry("Password"));
                server.setSSLEnabled(cgServer.readEntry("SSLEnabled", false));
                server.setBypassProxy(cgServer.readEntry("BypassProxy", false));
                serverGroup->addServer(server);
            }

            //config->setGroup(groupName);
            const QStringList autoJoinChannels = cgServerGroup.readEntry("AutoJoinChannels", QStringList());

            for (const QString& channelName : autoJoinChannels) {
                KConfigGroup cgJoin(KSharedConfig::openConfig()->group(channelName));

                if (!cgJoin.readEntry("Name").isEmpty())
                {
                    channel.setName(cgJoin.readEntry("Name"));
                    channel.setPassword(cgJoin.readEntry("Password"));
                    serverGroup->addChannel(channel);
                }
            }

            //config->setGroup(groupName);
            const QStringList channelHistoryList = cgServerGroup.readEntry("ChannelHistory", QStringList());
            channelHistory.clear();

            for (const QString& channelName : channelHistoryList) {
                KConfigGroup cgChanHistory(KSharedConfig::openConfig()->group(channelName));

                if (!cgChanHistory.readEntry("Name").isEmpty())
                {
                    channel.setName(cgChanHistory.readEntry("Name"));
                    channel.setPassword(cgChanHistory.readEntry("Password"));
                    channel.setNotificationsEnabled(cgChanHistory.readEntry("EnableNotifications", true));
                    channelHistory.append(channel);
                }
            }

            serverGroup->setChannelHistory(channelHistory);

            serverGroups.insert(serverGroup->id(), serverGroup);
            sgKeys.append(serverGroup->id());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Forwarding *check : qAsConst(forwards)) {
                undoForward(check->port, check->proto);
            }
```

#### AUTO 


```{c}
auto *layout = new QHBoxLayout;
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString& recipient, const QUrl& url) { addDccSend(recipient, url); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& output : result.outputList)
            server->appendMessageToFrontmost(result.typeString, output);
```

#### RANGE FOR STATEMENT 


```{c}
for (const ChannelItem& item : m_channelMap) {
        if(item.checkState == Qt::Checked)
            channels.append(item.channel);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& argument : arguments)
        commandToServer(server, command.arg(argument), destination);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& channel : tmpList) {
        const QString channelName = channel.name();

        // Only add the channel to the JOIN command if it has a valid channel name.
        if (isAChannel(channelName)) {
            const QString password = channel.password().isEmpty() ? QStringLiteral(".") : channel.password();

            uint currentLength = getIdentity()->getCodec()->fromUnicode(channelName).length();
            currentLength += getIdentity()->getCodec()->fromUnicode(password).length();

            //channels.count() and passwords.count() account for the commas
            if (length + currentLength + 6 + channels.count() + passwords.count() >= 512) // 6: "JOIN " plus separating space between chans and pws.
            {
                while (!passwords.isEmpty() && passwords.last() == QLatin1Char('.')) passwords.pop_back();

                joinCommands << QStringLiteral("JOIN ") + channels.join(QLatin1Char(',')) + QLatin1Char(' ') + passwords.join(QLatin1Char(','));

                channels.clear();
                passwords.clear();

                length = 0;
            }

            length += currentLength;

            channels << channelName;
            passwords << password;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& historyChannel : m_channelHistory) {
            if (channel.name() == historyChannel.name()) {
                historyChannel.setPassword(channel.password());
                historyChannel.setNotificationsEnabled(channel.enableNotifications());
                return;
            }
        }
```

#### AUTO 


```{c}
auto *buttonBox = new QDialogButtonBox(QDialogButtonBox::Ok|QDialogButtonBox::Close);
```

#### RANGE FOR STATEMENT 


```{c}
for (Nick* lookNick : qAsConst(nicknameList)) {
        if(lookNick->getChannelNick()->loweredNickname() == nickname)
        {
            nick = lookNick;
            break;
        }
    }
```

#### AUTO 


```{c}
auto &entry
```

#### AUTO 


```{c}
auto* helpEvent = static_cast<QHelpEvent*>(event);
```

#### AUTO 


```{c}
auto *item = new HighlightViewItem(highlightListView,currentHighlight);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &rowIndex : rowIndices) {
                int status = rowIndex.data(TransferListModel::TransferStatus).toInt();
                if (status == Transfer::Transferring)
                {
                    dataChanged(rowIndex, index(rowIndex.row(), columnCount));
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction* action : qAsConst(m_sharedNickSettingsActions))
        m_textMenu->addAction(action);
```

#### AUTO 


```{c}
const auto actions = Application::instance()->getMainWindow()->actionCollection()->actions();
```

#### AUTO 


```{c}
auto* view = static_cast<ChatWindow*>(tab);
```

#### RANGE FOR STATEMENT 


```{c}
for (TransferSend* it : qAsConst(m_sendItems)) {
                if ( ( it->getStatus() == Transfer::Queued || it->getStatus() == Transfer::WaitingRemote ) &&
                    it->getConnectionId() == connectionId &&
                    it->getPartnerNick() == partnerNick &&
                    it->getFileName() == fileName )
                {
                    transfer = it;
                    qCDebug(KONVERSATION_LOG) << "Filename match: " << fileName;
                    break;
                }
            }
```

#### AUTO 


```{c}
const auto selectedRowIndices = m_transferView->selectedRows();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& uhost : uhosts) {
                    // extract nickname and hostmask from reply
                    QString nick(uhost.section(QLatin1Char('='),0,0));
                    QString mask(uhost.section(QLatin1Char('='),1));

                    // get away and IRC operator flags
                    bool away=(mask[0]==QLatin1Char('-'));
                    bool ircOp=(nick[nick.length()-1]==QLatin1Char('*'));

                    // cut flags from nick/hostmask
                    mask.remove(0, 1);
                    if (ircOp)
                    {
                        nick=nick.left(nick.length()-1);
                    }

                    // inform server of this user's data
                    emit userhost(nick,mask,away,ircOp);

                    // display message only if this was no automatic request
                    if (getAutomaticRequest(QStringLiteral("USERHOST"),nick)==0)
                    {
                        m_server->appendMessageToFrontmost(i18n("Userhost"),
                            i18nc("%1 = nick, %2 = shows if nick is op, %3 = hostmask, %4 = shows away", "%1%2 is %3%4.",
                            nick,
                            (ircOp) ? i18n(" (IRC Operator)") : QString()
                            ,mask,
                            (away) ? i18n(" (away)") : QString()), messageTags);
                    }

                    // was this an automatic request?
                    if (getAutomaticRequest(QStringLiteral("USERHOST"),nick)!=0)
                    {
                        setAutomaticRequest(QStringLiteral("USERHOST"),nick,false);
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (Highlight* highlight : highlightList) {
                highlightChatWindowList = highlight->getChatWindowList();
                if (highlightChatWindowList.isEmpty() ||
                    highlightChatWindowList.contains(m_chatWin->getName(), Qt::CaseInsensitive))
                {
                    bool patternFound = false;
                    if (highlight->getRegExp())
                    {
                        QRegExp needleReg(highlight->getPattern());
                        needleReg.setCaseSensitivity(Qt::CaseInsensitive);
                                                      // highlight regexp in text
                        patternFound = ((line.contains(needleReg)) ||
                                                      // highlight regexp in nickname
                            (whoSent.contains(needleReg)));

                        // remember captured patterns for later
                        captures = needleReg.capturedTexts();

                    }
                    else
                    {
                        QString needle = highlight->getPattern();
                                                      // highlight patterns in text
                        patternFound = ((line.contains(needle, Qt::CaseInsensitive)) ||
                                                      // highlight patterns in nickname
                            (whoSent.contains(needle, Qt::CaseInsensitive)));
                    }

                    if (patternFound)
                    {
                        matchedHighlight = highlight;
                        break;
                    }
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (Ignore* item : ignoreItems) {
        new IgnoreListViewItem(ignoreListView, item->getName(), item->getFlags());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& uhost : uhosts) {
                    // extract nickname and hostmask from reply
                    QString nick(uhost.section(QLatin1Char('='),0,0));
                    QString mask(uhost.section(QLatin1Char('='),1));

                    // get away and IRC operator flags
                    bool away=(mask[0]==QLatin1Char('-'));
                    bool ircOp=(nick[nick.length()-1]==QLatin1Char('*'));

                    // cut flags from nick/hostmask
                    mask.remove(0, 1);
                    if (ircOp)
                    {
                        nick=nick.left(nick.length()-1);
                    }

                    // inform server of this user's data
                    Q_EMIT userhost(nick,mask,away,ircOp);

                    // display message only if this was no automatic request
                    if (getAutomaticRequest(QStringLiteral("USERHOST"),nick)==0)
                    {
                        m_server->appendMessageToFrontmost(i18n("Userhost"),
                            i18nc("%1 = nick, %2 = shows if nick is op, %3 = hostmask, %4 = shows away", "%1%2 is %3%4.",
                            nick,
                            (ircOp) ? i18n(" (IRC Operator)") : QString()
                            ,mask,
                            (away) ? i18n(" (away)") : QString()), messageTags);
                    }

                    // was this an automatic request?
                    if (getAutomaticRequest(QStringLiteral("USERHOST"),nick)!=0)
                    {
                        setAutomaticRequest(QStringLiteral("USERHOST"),nick,false);
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : qAsConst(indexesToRemove)) {
                selectedIndexes.removeOne(index);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString& nick : nicks)
                Preferences::addNotify(server->getServerGroup()->id(), nick);
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction* action : qAsConst(self()->m_linkActions))
        action->setVisible(showLinkActions);
```

#### AUTO 


```{c}
const auto region = event->region();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& serverGroupSettings : serverGroupHash) {
        const auto serverList = serverGroupSettings->serverList();
        for (const auto& serverSertting : serverList) {
            if (serverSertting.host().toLower() == server)
                serverGroups.append(serverGroupSettings);
        }
    }
```

#### AUTO 


```{c}
auto* item = new QStandardItem(i18n("From"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& script : scripts) {
            if (!aliasList.contains(script)) {
                changed = true;
                aliasList.append(script);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& server : serverGroups) {
                if (server->autoConnectEnabled()) {
                    openServerList = false;
                    serversToAutoconnect << server;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : rowIndices) {
                for (int row : rows) {
                    if (row == index.row())
                    {
                        selection.append(QItemSelectionRange(index));
                        break;
                    }
                }
            }
```

#### AUTO 


```{c}
auto* awayAction = qobject_cast<KToggleAction*>(konvApp->getMainWindow()->actionCollection()->action(QStringLiteral("toggle_away")));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : qAsConst(indexes)) {
                if (index.data(TransferListModel::TransferStatus).toInt() >= Transfer::Done)
                {
                    indexesToRemove.append(index);
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (Nick* nick : qAsConst(nicknameList)) {
            if(nick->getChannelNick()->getHostmask().isEmpty())
            {
                if(limit--) nickString = nickString + nick->getChannelNick()->getNickname() + QLatin1Char(' ');
                else break;
            }
        }
```

#### AUTO 


```{c}
const auto ids = Preferences::identityList();
```

#### RANGE FOR STATEMENT 


```{c}
for (QString mask : users) {
        // first, set the ban mask to the specified nick
        // did we specify an option?
        if(!option.isEmpty())
        {
            // try to find specified nick on the channel
            Nick* targetNick=targetChannel->getNickByName(mask);
            // if we found the nick try to find their hostmask
            if(targetNick)
            {
                QString hostmask=targetNick->getChannelNick()->getHostmask();
                // if we found the hostmask, add it to the ban mask
                if(!hostmask.isEmpty())
                {
                    mask=targetNick->getChannelNick()->getNickname()+QLatin1Char('!')+hostmask;

                    // adapt ban mask to the option given
                    if(option==QStringLiteral("host"))
                        mask=QLatin1String("*!*@*.")+hostmask.section(QLatin1Char('.'),1);
                    else if(option==QStringLiteral("domain"))
                        mask=QLatin1String("*!*@")+hostmask.section(QLatin1Char('@'),1);
                    else if(option==QStringLiteral("userhost"))
                        mask=QLatin1String("*!")+hostmask.section(QLatin1Char('@'),0,0)+QLatin1String("@*.")+hostmask.section(QLatin1Char('.'),1);
                    else if(option==QStringLiteral("userdomain"))
                        mask=QLatin1String("*!")+hostmask.section(QLatin1Char('@'),0,0)+QLatin1Char('@')+hostmask.section(QLatin1Char('@'),1);
                }
            }
        }

        Konversation::OutputFilterResult result = getOutputFilter()->execBan(mask,channel);
        queue(result.toServer);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& server : serverList) {
            const QString groupName = QStringLiteral("Server %1").arg(index2);
            servers.append(groupName);
            KConfigGroup cgServer(KSharedConfig::openConfig()->group(groupName));
            cgServer.writeEntry("Server", server.host());
            cgServer.writeEntry("Port", server.port());
            cgServer.writeEntry("Password", server.password());
            cgServer.writeEntry("SSLEnabled", server.SSLEnabled());
            cgServer.writeEntry("BypassProxy", server.bypassProxy());
            index2++;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& serverGroup : serverGroups) {
        KSharedConfig::openConfig()->deleteGroup(serverGroup);
    }
```

#### AUTO 


```{c}
auto* nickLabel = new QLabel(i18n("&Nick:"), page);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& index : nonPersistentSelectedIndices)
        selectedIndices << index;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& dir : qAsConst(dirs)) {
            if (nickIconSet->load(dir)) {
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Channel* channel : channelList) {
                index = m_server->getViewContainer()->getViewIndex(channel);

                if (index && index > ownIndex) channelMap.insert(index, channel);
            }
```

#### AUTO 


```{c}
const auto nonPersistentSelectedIndices = m_urlTree->selectionModel()->selectedIndexes();
```

#### RANGE FOR STATEMENT 


```{c}
for (Server* server : qAsConst(m_connectionList)) {
        server->quitServer();
    }
```

#### AUTO 


```{c}
auto* autoJoinAction = qobject_cast<KToggleAction*>(actionCollection()->action(QStringLiteral("tab_autojoin")));
```

#### AUTO 


```{c}
auto* item = dynamic_cast<IgnoreListViewItem *>(root->child(i));
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction* action : qAsConst(self()->m_sharedBasicNickActions))
            action->setEnabled(connected);
```

#### AUTO 


```{c}
auto* notifyAction = qobject_cast<KToggleAction*>(actionCollection()->action(QStringLiteral("tab_notifications")));
```

#### LAMBDA EXPRESSION 


```{c}
[identityId](const ServerGroupSettingsPtr& serverGroup) {
                                            return (serverGroup->identityId() == identityId);
                                       }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Arg & a : args)
                comm += QLatin1Char('<') + a.element + QLatin1Char('>') + a.value + QLatin1String("</") + a.element + QLatin1Char('>');
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& channel : oneShotChannelList) {
                    dupe->sendJoinCommand(channel.name(), channel.password());
                }
```

#### AUTO 


```{c}
auto* newHighlight = new Highlight(i18n("New"), false, QColor("#ff0000"), QUrl(), QString(), QString(), true);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& server : serverGroups) {
            if (server->autoConnectEnabled()) {
                openServerList = false;
                serversToAutoconnect << server;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Channel* channel : channelList) {
            if (channel->joined())
                joinedChannels.append(channel->getName());
        }
```

#### AUTO 


```{c}
auto* action = new QAction(this);
```

#### AUTO 


```{c}
auto *tFilledEllipse = new QListWidgetItem(QString(), m_formOptionListWidget, QListWidgetItem::UserType +1);
```

#### AUTO 


```{c}
auto *buttonBox = new QDialogButtonBox(QDialogButtonBox::Ok|QDialogButtonBox::Cancel);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& themedir : themeDirs) {
            QFileInfo file(path + themedir + "/index.desktop");

            if(file.exists())
            {
                m_dirs.append(file.absoluteFilePath());
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const ChannelSettings& cs : qAsConst(channels)) {
            tmpList << cs;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& channel : qAsConst(m_channelHistory)) {
            if (channelName == channel.name()) {
                return channel;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& nick : nicks) {
        if (Preferences::isIgnored(nick))
            ++unignoreCounter;
        else
            ++ignoreCounter;

        if (serverGroupId != -1)
        {
            if (Preferences::isNotify(serverGroupId, nick))
                ++removeNotifyCounter;
            else
                ++addNotifyCounter;
        }
    }
```

#### AUTO 


```{c}
auto *tab = new QWidget(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& channel : channelHistoryList) {
            // TODO FIXME: is it just me or is this broken?
            const QString groupName = QStringLiteral("Channel %1").arg(index3);
            channelHistory.append(groupName);
            KConfigGroup cgChannelHistory(KSharedConfig::openConfig()->group(groupName));
            cgChannelHistory.writeEntry("Name", channel.name());
            cgChannelHistory.writeEntry("Password", channel.password());
            cgChannelHistory.writeEntry("EnableNotifications", channel.enableNotifications());
            index3++;
        }
```

#### AUTO 


```{c}
const auto& serverSertting
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& serverGroup : qAsConst(sortedServerGroupMap)) {
        const Konversation::ServerList serverList = serverGroup->serverList();
        servers.clear();
        servers.reserve(serverList.size());

        sgKeys.insert(serverGroup->id(), index);

        for (const auto& server : serverList) {
            const QString groupName = QStringLiteral("Server %1").arg(index2);
            servers.append(groupName);
            KConfigGroup cgServer(KSharedConfig::openConfig()->group(groupName));
            cgServer.writeEntry("Server", server.host());
            cgServer.writeEntry("Port", server.port());
            cgServer.writeEntry("Password", server.password());
            cgServer.writeEntry("SSLEnabled", server.SSLEnabled());
            cgServer.writeEntry("BypassProxy", server.bypassProxy());
            index2++;
        }

        const Konversation::ChannelList channelList = serverGroup->channelList();
        channels.clear();
        channels.reserve(channelList.size());

        for (const auto& channel : channelList) {
            const QString groupName = QStringLiteral("Channel %1").arg(index3);
            channels.append(groupName);
            KConfigGroup cgChannel(KSharedConfig::openConfig()->group(groupName));
            cgChannel.writeEntry("Name", channel.name());
            cgChannel.writeEntry("Password", channel.password());
            index3++;
        }

        const Konversation::ChannelList channelHistoryList = serverGroup->channelHistory();
        channelHistory.clear();
        channelHistory.reserve(channelHistoryList.size());

        for (const auto& channel : channelHistoryList) {
            // TODO FIXME: is it just me or is this broken?
            const QString groupName = QStringLiteral("Channel %1").arg(index3);
            channelHistory.append(groupName);
            KConfigGroup cgChannelHistory(KSharedConfig::openConfig()->group(groupName));
            cgChannelHistory.writeEntry("Name", channel.name());
            cgChannelHistory.writeEntry("Password", channel.password());
            cgChannelHistory.writeEntry("EnableNotifications", channel.enableNotifications());
            index3++;
        }

        QString sgn = QStringLiteral("ServerGroup %1").arg(index);
        KConfigGroup cgServerGroup(KSharedConfig::openConfig()->group(sgn));
        cgServerGroup.writeEntry("Name", serverGroup->name());
        cgServerGroup.writeEntry("Identity", serverGroup->identity()->getName());
        cgServerGroup.writeEntry("ServerList", servers);
        cgServerGroup.writeEntry("AutoJoinChannels", channels);
        cgServerGroup.writeEntry("ConnectCommands", serverGroup->connectCommands());
        cgServerGroup.writeEntry("AutoConnect", serverGroup->autoConnectEnabled());
        cgServerGroup.writeEntry("ChannelHistory", channelHistory);
        cgServerGroup.writeEntry("EnableNotifications", serverGroup->enableNotifications());
        cgServerGroup.writeEntry("Expanded", serverGroup->expanded());
        cgServerGroup.writeEntry("NotifyList",Preferences::notifyStringByGroupId(serverGroup->id()));
        index++;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](KConfigDialogManager* manager) { return manager->hasChanged(); }
```

#### AUTO 


```{c}
auto* networkNameLabel=new QLabel(i18n("&Network name:"), page);
```

#### RANGE FOR STATEMENT 


```{c}
for (Nick* nick : qAsConst(nicknameList)) {
        if (nick->isSelected())
            selectedNicks << nick->getChannelNick()->getNickname();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QChar m : modestring) {
        const char mode = m.toLatin1();
        QString parameter;

        // Check if this is a mode or a +/- qualifier
        if (mode=='+' || mode=='-')
        {
            plus=(mode=='+');
        }
        else
        {
            // Check if this was a parameter mode
            if (parameterModes.contains(QLatin1Char(mode)))
            {
                // Check if the mode actually wants a parameter. -k and -l do not!
                if (plus || (!plus && (mode!='k') && (mode!='l')))
                {
                    // Remember the mode parameter
                    parameter = parameterList.value(2+parameterIndex);
                    message += QLatin1Char(' ') + parameter;
                    // Switch to next parameter
                    ++parameterIndex;
                }
            }
            // Let the channel update its modes
            if (parameter.isEmpty())               // XXX Check this to ensure the braces are in the correct place
            {
                qCDebug(KONVERSATION_LOG)   << "in updateChannelMode.  sourceNick: '" << sourceNick << "'  parameterlist: '"
                    << parameterList.join(QLatin1String(", ")) << "'";
            }
            m_server->updateChannelMode(sourceNick, parameterList.value(0), mode, plus, parameter, messageTags);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &tag : tags) {
        QStringList tagList = tag.split(QLatin1Char('='));
        tagHash.insert(tagList.first(), tagList.last());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& soundDir : qAsConst(soundDirs)) {
            dir.setPath(soundDir);
            if ( dir.isReadable() && dir.count() > 2 )
            {
                soundURL->setStartDir(QUrl::fromLocalFile(soundDir));
                break;
            }
        }
```

#### AUTO 


```{c}
auto* ke = static_cast<QKeyEvent*>(event);
```

#### RANGE FOR STATEMENT 


```{c}
for (QPair<int, int> urlRange : urlRanges) {
        QString url = filteredLine.mid(urlRange.first, urlRange.second);

        QAction* action = new QAction(showURLmenu);
        action->setText(url);
        action->setData(url);

        showURLmenu->addAction(action);

        connect(action, &QAction::triggered, this, &ChannelListPanel::openURL);
    }
```

#### AUTO 


```{c}
auto* transfer = new TransferSend(this);
```

#### AUTO 


```{c}
const auto channelsURI = m_mainWindow->getViewContainer()->getChannelsURI();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& dir : qAsConst(dirs)) {
        if (iconSet.load(dir)) {
            break;
        }
    }
```

#### AUTO 


```{c}
auto* behaviorGroup = new KPageWidgetItem(new QWidget(this), i18n("Behavior"));
```

#### AUTO 


```{c}
auto* topicLayout = new QGridLayout(topicWidget);
```

#### AUTO 


```{c}
auto* autoConnectAction = qobject_cast<KToggleAction*>(actionCollection()->action(QStringLiteral("tab_autoconnect")));
```

#### AUTO 


```{c}
auto* viewToClose = qobject_cast<ChatWindow*>(m_tabWidget->widget(view));
```

#### AUTO 


```{c}
const auto& identity
```

#### RANGE FOR STATEMENT 


```{c}
for (TransferRecv* it : qAsConst(m_recvItems)) {
                if ( ( it->getStatus() == Transfer::Queued || it->getStatus() == Transfer::WaitingRemote ) &&
                    it->getConnectionId() == connectionId &&
                    it->getPartnerNick() == partnerNick &&
                    it->getFileName() == fileName &&
                    it->isResumed() )
                {
                    transfer = it;
                    qCDebug(KONVERSATION_LOG) << "Filename match: " << fileName << ", claimed port: " << ownPort << ", item port: " << transfer->getOwnPort();
                    // the port number can be changed behind NAT, so we pick an item which only the filename is correspondent in that case.
                    if ( transfer->getOwnPort() == ownPort )
                    {
                        break;
                    }
                }
            }
```

#### AUTO 


```{c}
auto *sortModel = new QSortFilterProxyModel(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (Server* server : serverList) {
        if (server->getDisplayName() == networkName)
        {
            server->requestWhois(nickname);
            return;
        }
    }
```

#### AUTO 


```{c}
auto* innerItemShowLauncherEntryCount = new KConfigSkeleton::ItemBool(currentGroup(), QStringLiteral("ShowLauncherEntryCount"), mShowLauncherEntryCount, true);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &mode : newModeList)
        {
            const QString modeString = mode.mid(1);
            const bool plus = mode.at(0) == QLatin1Char('+');
            const QStringList tmp = currentModeList.filter(QRegularExpression(QLatin1Char('^') + modeString));

            if(tmp.isEmpty() && plus)
            {
                m_channel->getServer()->queue(command.arg(m_channel->getName(), QStringLiteral("+"),
                                                          modeString.at(0), modeString.mid(1)));
            }
            else if(!tmp.isEmpty() && !plus)
            {
                //FIXME: Bahamuth requires the key parameter for -k, but ircd breaks on -l with limit number.
                //Hence two versions of this.
                if (modeString.at(0) == QLatin1Char('k')) {
                    m_channel->getServer()->queue(command.arg(m_channel->getName(), QStringLiteral("-"),
                                                              modeString.at(0), modeString.mid(1)));
                } else {
                    m_channel->getServer()->queue(command.arg(m_channel->getName(), QStringLiteral("-"),
                                                              modeString.at(0), QString()));
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Nick* lookNick : lookChannelNickList) {
            if (!nickList.contains(lookNick->getChannelNick()->getNickname()))
                nickList.append(lookNick->getChannelNick()->getNickname());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Server* server : serverList) {
            if (server->isAway())
                awayCount++;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &script : scriptFiles) {
            scripts << script;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Chat* it :qAsConst(m_chatItems)) {
                if (
                    it->status() == Chat::WaitingRemote &&
                    it->connectionId() == connectionId &&
                    it->partnerNick() == partnerNick &&
                    it->reverseToken() == token
                )
                {
                    chat = it;
                    break;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (Server* server : qAsConst(m_connectionList)) {
        server->reconnectInvoluntary();
    }
```

#### AUTO 


```{c}
auto* mimeData = new QMimeData;
```

#### AUTO 


```{c}
auto *ev=new KNotification(QStringLiteral("kick"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& output : outList) {
        // encoding stuff is done in Server()
        Konversation::OutputFilterResult result = m_server->getOutputFilter()->parse(m_server->getNickname(), output, QString(), this);

        if(!result.output.isEmpty())
        {
            if(result.type == Konversation::PrivateMessage) msgHelper(result.typeString, result.output);
            else appendServerMessage(result.typeString, result.output);
        }
        m_server->queue(result.toServer);
    }
```

#### AUTO 


```{c}
auto *end = new EditNotifyDialog(this, serverGroupId);
```

#### AUTO 


```{c}
auto* query=new Query(m_tabWidget, name);
```

#### AUTO 


```{c}
auto* btnDefaultName = new QPushButton(i18n("O&riginal Filename"),filePathToolsFrame);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& dir : qAsConst(dirs)) {
            if (iconSet.load(dir)) {
                break;
            }
        }
```

#### AUTO 


```{c}
auto *joinAction = new QAction(menu);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& channelName : channelList) {
                // Known channels where nickname is online and mode in each channel.
                // FIXME: If user connects to multiple servers in same network, the
                // channel info will differ between the servers, resulting in inaccurate
                // mode and led info displayed.

                ChannelNickPtr channelNick = server->getChannelNick(channelName, nickname);
                QString nickMode;
                if (channelNick->hasVoice()) nickMode = nickMode + i18n(" Voice");
                if (channelNick->isHalfOp()) nickMode = nickMode + i18n(" HalfOp");
                if (channelNick->isOp()) nickMode = nickMode + i18n(" Operator");
                if (channelNick->isOwner()) nickMode = nickMode + i18n(" Owner");
                if (channelNick->isAdmin()) nickMode = nickMode + i18n(" Admin");
                QTreeWidgetItem* channelItem = findItemChild(nickRoot, channelName, NicksOnlineItem::ChannelItem);
                if (!channelItem) channelItem = new NicksOnlineItem(NicksOnlineItem::ChannelItem,nickRoot,
                        channelName, nickMode);
                channelItem->setText(nlvcAdditionalInfo, nickMode);

                // Icon for mode of nick in each channel.
                Images::NickPrivilege nickPrivilege = Images::Normal;
                if (channelNick->hasVoice()) nickPrivilege = Images::Voice;
                if (channelNick->isHalfOp()) nickPrivilege = Images::HalfOp;
                if (channelNick->isOp()) nickPrivilege = Images::Op;
                if (channelNick->isOwner()) nickPrivilege = Images::Owner;
                if (channelNick->isAdmin()) nickPrivilege = Images::Admin;
                const bool isAway = (server->getJoinedChannelMembers(channelName) == nullptr);
                channelItem->setIcon(nlvcChannel,
                                     Application::instance()->images()->getNickIcon(nickPrivilege, isAway));
            }
```

#### AUTO 


```{c}
const auto allChildWidgets = findChildren<QWidget*>();
```

#### AUTO 


```{c}
auto* model = qobject_cast<QStandardItemModel*>(m_ui.otherModesList->model());
```

#### AUTO 


```{c}
auto* item = dynamic_cast<HighlightViewItem*>(highlightListView->topLevelItem(0));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& path : paths) {
        QDir dir(path);

        const auto themeDirs = dir.entryList(QDir::AllDirs | QDir::NoDotAndDotDot);
        for (const QString& themedir : themeDirs) {
            QFileInfo file(path + themedir + QLatin1String("/index.desktop"));

            if(file.exists())
            {
                m_dirs.append(file.absoluteFilePath());
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& id : ids) {
        if (id->getName() == id_name) {
            return sterilizeUnicode(id->getRealName());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (TransferRecv* it : qAsConst(m_recvItems)) {
                    if ( it->getStatus() == Transfer::Queued &&
                         it->getFileURL().adjusted(QUrl::RemoveFilename) == m_defaultIncomingFolder.adjusted(QUrl::RemoveFilename))
                    {
                        QUrl url = QUrl::fromLocalFile(Preferences::self()->dccPath().adjusted(QUrl::StripTrailingSlash).toString() + QDir::separator() + it->getFileURL().fileName());
                        it->setFileURL(url);

                        Q_EMIT fileURLChanged( it );
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (Server* server : serverList) {
        IdentityPtr identity = server->getIdentity();
        int identityId = identity->id();

        // Calculate the auto-away time in milliseconds.
        int identityIdleTime = minutesToMilliseconds(identity->getAwayInactivity());

        if (identity && identity->getAutomaticAway() && server->isConnected())
            newIdentityWithIdleTimeMapping[identityId] = identityIdleTime;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& id : ids) {
        if (id->getName() == id_name) {
            id->setRealName(sterilizeUnicode(name));
            return;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (TransferRecv* it : m_recvItems) {
                if ( ( it->getStatus() == Transfer::Connecting ||
                       it->getStatus() == Transfer::Transferring ) &&
                    it->getFileURL() == url )
                {
                    return true;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (QChar mode : sortingOrder) {
    QTreeWidgetItem *item = nullptr;
    // find appropriate description
    if (mode == QLatin1Char('-')) item = new QTreeWidgetItem(sortOrder, QStringList { mode, i18n("Normal Users") });
    if (mode == QLatin1Char('v')) item = new QTreeWidgetItem(sortOrder, QStringList { mode, i18n("Voice (+v)") });
    if (mode == QLatin1Char('h')) item = new QTreeWidgetItem(sortOrder, QStringList { mode, i18n("Halfops (+h)") });
    if (mode == QLatin1Char('o')) item = new QTreeWidgetItem(sortOrder, QStringList { mode, i18n("Operators (+o)") });
    if (mode == QLatin1Char('p')) item = new QTreeWidgetItem(sortOrder, QStringList { mode, i18n("Channel Admins (+p)") });
    if (mode == QLatin1Char('q')) item = new QTreeWidgetItem(sortOrder, QStringList { mode, i18n("Channel Owners (+q)") });
    item->setFlags(item->flags() &~ Qt::ItemIsDropEnabled);
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (Highlight* hl : hiList) {
        KConfigGroup grp = config->group(QStringLiteral("Highlight%1").arg(i));
        grp.writeEntry("Pattern", hl->getPattern());
        grp.writeEntry("RegExp", hl->getRegExp());
        grp.writeEntry("Color", hl->getColor());
        grp.writePathEntry("Sound", hl->getSoundURL().url());
        grp.writeEntry("AutoText", hl->getAutoText());
        grp.writeEntry("ChatWindows", hl->getChatWindows());
        grp.writeEntry("Notify", hl->getNotify());
        i++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& themedir : themeDirs) {
            QFileInfo file(path + themedir + QLatin1String("/index.desktop"));

            if(file.exists())
            {
                m_dirs.append(file.absoluteFilePath());
            }
        }
```

#### CONST EXPRESSION 


```{c}
constexpr int DIRECTION_OUTPUT = 0;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& id : ids) {
        identities.append(id->getName());
    }
```

#### AUTO 


```{c}
auto *ev=new KNotification(QStringLiteral("connectionFailure"));
```

#### AUTO 


```{c}
auto* socket = new QTcpServer( parent );
```

#### AUTO 


```{c}
auto* tab = static_cast<ChatWindow*>(m_tabWidget->widget(tabIndex));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& nick : nicks) {
                if (Preferences::isIgnored(nick))
                    selectedIgnoredNicks << nick;
            }
```

#### AUTO 


```{c}
auto it = spellCheckingLanguageEntries.begin(), end = spellCheckingLanguageEntries.end();
```

#### AUTO 


```{c}
auto *job = new KIO::ApplicationLauncherJob();
```

#### AUTO 


```{c}
const auto currentRecvItems = m_recvItems;
```

#### RANGE FOR STATEMENT 


```{c}
for (const Arg & a : args)
                comm += '<' + a.element + '>' + a.value + "</" + a.element + '>';
```

#### AUTO 


```{c}
auto* settingsLayout = new QVBoxLayout(settingsFrame);
```

#### AUTO 


```{c}
auto *ev=new KNotification(QStringLiteral("dccChat"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : selectedRowIndices) {
                if (index.data(TransferListModel::TransferType).toInt() == Transfer::Send ||
                    index.data(TransferListModel::TransferStatus).toInt() == Transfer::Done)
                {
                    auto *transfer = qobject_cast<Transfer*>(index.data(TransferListModel::TransferPointer).value<QObject*>());
                    if (transfer)
                    {
                        transfer->runFile();
                    }
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& identity : identityList) {
        KConfigGroup cgIdentity(KSharedConfig::openConfig()->group(QStringLiteral("Identity %1").arg(index)));

        cgIdentity.writeEntry("Name",identity->getName());
        cgIdentity.writeEntry("Ident",identity->getIdent());
        cgIdentity.writeEntry("Realname",identity->getRealName());
        cgIdentity.writeEntry("Nicknames",identity->getNicknameList());
        cgIdentity.writeEntry("AuthType",identity->getAuthType());
        cgIdentity.writeEntry("Password",identity->getAuthPassword());
        cgIdentity.writeEntry("Bot",identity->getNickservNickname());
        cgIdentity.writeEntry("NickservCommand",identity->getNickservCommand());
        cgIdentity.writeEntry("SaslAccount",identity->getSaslAccount());
        cgIdentity.writeEntry("PemClientCertFile", identity->getPemClientCertFile().toString());
        cgIdentity.writeEntry("InsertRememberLineOnAway", identity->getInsertRememberLineOnAway());
        cgIdentity.writeEntry("ShowAwayMessage",identity->getRunAwayCommands());
        cgIdentity.writeEntry("AwayMessage",identity->getAwayCommand());
        cgIdentity.writeEntry("ReturnMessage",identity->getReturnCommand());
        cgIdentity.writeEntry("AutomaticAway", identity->getAutomaticAway());
        cgIdentity.writeEntry("AwayInactivity", identity->getAwayInactivity());
        cgIdentity.writeEntry("AutomaticUnaway", identity->getAutomaticUnaway());
        cgIdentity.writeEntry("QuitReason",identity->getQuitReason());
        cgIdentity.writeEntry("PartReason",identity->getPartReason());
        cgIdentity.writeEntry("KickReason",identity->getKickReason());
        cgIdentity.writeEntry("PreShellCommand",identity->getShellCommand());
        cgIdentity.writeEntry("Codec",identity->getCodecName());
        cgIdentity.writeEntry("AwayReason",identity->getAwayMessage());
        cgIdentity.writeEntry("AwayNick", identity->getAwayNickname());
        index++;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](QWidget* w) {
        return w->hasFocus();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& server : qAsConst(serversToAutoconnect)) {
            m_connectionManager->connectTo(Konversation::CreateNewConnection, server->id());
        }
```

#### AUTO 


```{c}
auto* item = static_cast<NicksOnlineItem*>(networkRoot->child(j));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& output : outList){
        // encoding stuff is done in Server()
        Konversation::OutputFilterResult result = m_server->getOutputFilter()->parse(m_server->getNickname(), output, getName(), this);

        // Is there something we need to display for ourselves?
        if(!result.output.isEmpty())
        {
            if(result.type == Konversation::Action) appendAction(m_server->getNickname(), result.output);
            else if(result.type == Konversation::Command) appendCommandMessage(result.typeString, result.output);
            else if(result.type == Konversation::Program) appendServerMessage(result.typeString, result.output);
            else if(result.type == Konversation::PrivateMessage) msgHelper(result.typeString, result.output);
            else append(m_server->getNickname(), result.output);
        }
        else if (!result.outputList.isEmpty()) {
            if (result.type == Konversation::Message)
            {
                for (const QString& out : qAsConst(result.outputList)) {
                    append(m_server->getNickname(), out);
                }
            }
            else if (result.type == Konversation::Action)
            {
                for (int i = 0; i < result.outputList.count(); ++i)
                {
                    if (i == 0)
                        appendAction(m_server->getNickname(), result.outputList.at(i));
                    else
                        append(m_server->getNickname(), result.outputList.at(i));
                }
            }
        }

        // Send anything else to the server
        if (!result.toServerList.empty())
            m_server->queueList(result.toServerList);
        else
            m_server->queue(result.toServer);
    }
```

#### AUTO 


```{c}
auto* settingsFrame = new QFrame(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& nick : qAsConst(m_prevISONList)) {
        if (!lcActual.contains(QLatin1Char(' ') + nick + QLatin1Char(' '), Qt::CaseInsensitive)) {
            setNickOffline(nick);
            nicksOnlineChanged = true;
        }
    }
```

#### AUTO 


```{c}
const auto rowIndices = rowIndexes(0);
```

#### AUTO 


```{c}
const auto nickMenuActions = nickMenu->actions();
```

#### AUTO 


```{c}
auto* topicWidget = new QWidget(m_vertSplitter);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : rowIndices) {
                Transfer::Type type = (Transfer::Type)index.data(TransferListModel::TransferType).toInt();
                Transfer::Status status = (Transfer::Status)index.data(TransferListModel::TransferStatus).toInt();

                selectAll = true;
                selectAllCompleted |= (status >= Transfer::Done);

                if (selectionModel->isRowSelected(index.row(), QModelIndex()))
                {
                    accept |= (status == Transfer::Queued);

                    abort  |= (status < Transfer::Done);

                    clear  |= (status >= Transfer::Done);

                    info   |= (type == Transfer::Send ||
                        status == Transfer::Done);

                    open   |= (type == Transfer::Send ||
                        status == Transfer::Done);

                    openLocation = true;

                    resend |= (type == Transfer::Send &&
                        status >= Transfer::Done);
                }
            }
```

#### AUTO 


```{c}
auto* newItem = new QTreeWidgetItem(buttonListView, buttonListView->topLevelItemCount());
```

#### AUTO 


```{c}
auto* action = new QAction(m_parent);
```

#### AUTO 


```{c}
const auto& serverGroup
```

#### AUTO 


```{c}
auto* nickRoot = static_cast<NicksOnlineItem*>(nickitem->parent());
```

#### RANGE FOR STATEMENT 


```{c}
for (KonviSettingsPage *page : qAsConst(m_pages)) {
    if (page->hasChanged())
    {
      m_modified = true;
//      qCDebug(KONVERSATION_LOG) << "modified!";
      break;
    }
  }
```

#### AUTO 


```{c}
auto* modeBoxLayout = new QHBoxLayout(modeBox);
```

#### RANGE FOR STATEMENT 


```{c}
for (KonviSettingsPage *page : qAsConst(m_pages)) {
    page->loadSettings();
  }
```

#### AUTO 


```{c}
auto* statusView = new StatusPanel(m_tabWidget);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& index : selectedIndexes)
        if (index.isValid()) Application::openUrl(index.data().toString());
```

#### AUTO 


```{c}
auto* portLabel = new QLabel(i18n("&Port:"), page);
```

#### RANGE FOR STATEMENT 


```{c}
for (Server *server : serverList) {
          m_ui.networkNameCombo->addItem(i18nc("network (nickname)", "%1 (%2)", server->getDisplayName(), server->getNickname()),
                                         server->connectionId());
          connect(server, &Server::nicknameChanged, this, &JoinChannelDialog::slotNicknameChanged);
        }
```

#### AUTO 


```{c}
auto *tEllipse = new QListWidgetItem(QString(), m_formOptionListWidget, QListWidgetItem::UserType +1);
```

#### RANGE FOR STATEMENT 


```{c}
for (Server* server : serverList) {
        updateServerOnlineList(server);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Highlight* highlight : highlightList) {
                highlightChatWindowList = highlight->getChatWindowList();
                if (highlightChatWindowList.isEmpty() ||
                    highlightChatWindowList.contains(m_chatWin->getName(), Qt::CaseInsensitive))
                {
                    bool patternFound = false;
                    if (highlight->getRegExp())
                    {
                        const QRegularExpression needleReg(highlight->getPattern(),
                                                           QRegularExpression::CaseInsensitiveOption);
                        QRegularExpressionMatch rmatch;

                        patternFound = line.contains(needleReg, &rmatch)        // highlight regexp in text
                                       || whoSent.contains(needleReg, &rmatch); // highlight regexp in nickname

                        // remember captured patterns for later
                        captures = rmatch.capturedTexts();

                    }
                    else
                    {
                        QString needle = highlight->getPattern();
                                                      // highlight patterns in text
                        patternFound = ((line.contains(needle, Qt::CaseInsensitive)) ||
                                                      // highlight patterns in nickname
                            (whoSent.contains(needle, Qt::CaseInsensitive)));
                    }

                    if (patternFound)
                    {
                        matchedHighlight = highlight;
                        break;
                    }
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (Server* server : serverList)
        server->executeMultiServerCommand(command, parameter);
```

#### RANGE FOR STATEMENT 


```{c}
for (Channel* channel : qAsConst(m_channelList)) {
            channel->flushNickQueue();

            // All we do is notify that the nick has been renamed.. we haven't actually renamed it yet
            if (channel->getNickByName(nickname)) channel->nickRenamed(nickname, *nickInfo, messageTags);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QPair<int, int> pair : urlRanges) {
                    length = pair.first - startPos;

                    line += replaceFormattingCodes(text.mid(startPos, length));

                    startPos = pair.first + pair.second;

                    line += text.midRef(pair.first, pair.second);
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &string : currentBanList) {
    if (string.section(QLatin1Char(' '), 0, 0) == ban)
    {
      m_BanList.removeOne(string);

      Q_EMIT banRemoved(ban);
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (Nick* nick : qAsConst(nicknameList)) {
        if(nick->getChannelNick()->getNickInfo()->isChanged())
        {
            nick->refresh();
        }
    }
```

#### AUTO 


```{c}
auto *ev=new KNotification(QStringLiteral("mode"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : selectedRowIndices) {
                if (index.data(TransferListModel::TransferType).toInt() == Transfer::Receive &&
                    index.data(TransferListModel::TransferStatus).toInt() == Transfer::Queued)
                {
                    Transfer *transfer = qobject_cast<Transfer*>(index.data(TransferListModel::TransferPointer).value<QObject*>());
                    if (transfer)
                    {
                        transfer->start();
                    }
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction* action : qAsConst(m_listActions))
        action->setEnabled(enable);
```

#### AUTO 


```{c}
auto* interfaceGroup = new KPageWidgetItem(new QWidget(this), i18n("Interface"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& groupName : groups) {
            KConfigGroup cgServerGroup(KSharedConfig::openConfig()->group(groupName));
            Konversation::ServerGroupSettingsPtr serverGroup(new Konversation::ServerGroupSettings);
            serverGroup->setName(cgServerGroup.readEntry("Name"));
            serverGroup->setSortIndex(groupName.section(QLatin1Char(' '), -1).toInt());
            serverGroup->setIdentityId(Preferences::identityByName(cgServerGroup.readEntry("Identity"))->id());
            serverGroup->setConnectCommands(cgServerGroup.readEntry("ConnectCommands"));
            serverGroup->setAutoConnectEnabled(cgServerGroup.readEntry("AutoConnect", false));
            serverGroup->setNotificationsEnabled(cgServerGroup.readEntry("EnableNotifications", true));
            serverGroup->setExpanded(cgServerGroup.readEntry("Expanded", false));

#if QT_VERSION < QT_VERSION_CHECK(5, 15, 0)
            notifyList.insert((*serverGroup).id(), cgServerGroup.readEntry("NotifyList", QString()).split(QLatin1Char(' '), QString::SkipEmptyParts));
#else
            notifyList.insert((*serverGroup).id(), cgServerGroup.readEntry("NotifyList", QString()).split(QLatin1Char(' '), Qt::SkipEmptyParts));
#endif

            const QStringList serverNames = cgServerGroup.readEntry("ServerList", QStringList());
            for (const QString& serverName : serverNames) {
                KConfigGroup cgServer(KSharedConfig::openConfig()->group(serverName));
                server.setHost(cgServer.readEntry("Server"));
                server.setPort(cgServer.readEntry<int>("Port", 0));
                server.setPassword(cgServer.readEntry("Password"));
                server.setSSLEnabled(cgServer.readEntry("SSLEnabled", false));
                server.setBypassProxy(cgServer.readEntry("BypassProxy", false));
                serverGroup->addServer(server);
            }

            //config->setGroup(groupName);
            const QStringList autoJoinChannels = cgServerGroup.readEntry("AutoJoinChannels", QStringList());

            for (const QString& channelName : autoJoinChannels) {
                KConfigGroup cgJoin(KSharedConfig::openConfig()->group(channelName));

                if (!cgJoin.readEntry("Name").isEmpty())
                {
                    channel.setName(cgJoin.readEntry("Name"));
                    channel.setPassword(cgJoin.readEntry("Password"));
                    serverGroup->addChannel(channel);
                }
            }

            //config->setGroup(groupName);
            const QStringList channelHistoryList = cgServerGroup.readEntry("ChannelHistory", QStringList());
            channelHistory.clear();

            for (const QString& channelName : channelHistoryList) {
                KConfigGroup cgChanHistory(KSharedConfig::openConfig()->group(channelName));

                if (!cgChanHistory.readEntry("Name").isEmpty())
                {
                    channel.setName(cgChanHistory.readEntry("Name"));
                    channel.setPassword(cgChanHistory.readEntry("Password"));
                    channel.setNotificationsEnabled(cgChanHistory.readEntry("EnableNotifications", true));
                    channelHistory.append(channel);
                }
            }

            serverGroup->setChannelHistory(channelHistory);

            serverGroups.insert(serverGroup->id(), serverGroup);
            sgKeys.append(serverGroup->id());
        }
```

#### AUTO 


```{c}
auto* newItem=new Ignore(item->text(0),item->getFlags());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& channel : channelList) {
            if (!channels.isEmpty())
                channels += QLatin1String(", ");

            channels += channel.name();
        }
```

#### AUTO 


```{c}
auto* commandLineLayout = new QHBoxLayout(commandLineBox);
```

#### AUTO 


```{c}
auto* rawLog = new RawLog(m_tabWidget);
```

#### RANGE FOR STATEMENT 


```{c}
for (QPushButton* pushButton : qAsConst(m_toggleButtonHash)) {
                if (pushButton != button && pushButton->isChecked())
                {
                    pushButton->setChecked(false);
                    return;
                }
            }
```

#### AUTO 


```{c}
auto* historyView = static_cast<TopicHistoryView*>(itemView());
```

#### AUTO 


```{c}
auto* hack = const_cast<QStyleOptionViewItem*>(&option);
```

#### AUTO 


```{c}
auto* transferJob = qobject_cast<KIO::TransferJob*>(job);
```

#### AUTO 


```{c}
auto* view = static_cast<ChatWindow*>(idx.internalPointer());
```

#### AUTO 


```{c}
auto* transfer = qobject_cast< TransferRecv* > ( item );
```

#### AUTO 


```{c}
auto* layout = new QGridLayout(page);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& line : buffer) {
        if (!line.isEmpty())
            out.enqueue(line);
    }
```

#### AUTO 


```{c}
auto *item = new BanListViewItem(m_ui.banList, newban.section(QLatin1Char(' '), 0, 0), newban.section(QLatin1Char(' '), 1, 1).section(QLatin1Char('!'), 0, 0), newban.section(QLatin1Char(' '), 2 ,2).toUInt());
```

#### RANGE FOR STATEMENT 


```{c}
for (Nick* nick : *this) {
        newNick = nick->getChannelNick()->getNickname();

        if(!prefix.isEmpty() && newNick.contains(prefixCharacter))
        {
            newNick = newNick.section( prefixCharacter,1 );
        }

        if(newNick.contains(regexp))
        {
            foundNicks.append(nick);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (ChatWindow *view : qAsConst(nonTopLevelViews)) {
        m_tabWidget->insertTab(insertIndex(view), view, QIcon(), view->getName().replace(QLatin1Char('&'), QLatin1String("&&")));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &string : currentBanList) {
    if (string.section(QLatin1Char(' '), 0, 0) == ban)
    {
      m_BanList.removeOne(string);

      emit banRemoved(ban);
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& identity : identities) {
                m_mainWidget->m_identityCBox->addItem(identity->getName());
            }
```

#### AUTO 


```{c}
auto* view = static_cast<ChatWindow*>(m_tabWidget->widget(tabIndex));
```

#### RANGE FOR STATEMENT 


```{c}
for (Chat* it : qAsConst(m_chatItems)) {
                if (it->status() == Chat::WaitingRemote &&
                    it->connectionId() == connectionId &&
                    it->partnerNick() == partnerNick)
                {
                    chat = it;
                    break;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QNetworkConfiguration& conf : configurations) {
        kcfg_DccIPv4FallbackIface->addItem(conf.name());
    }
```

#### AUTO 


```{c}
auto* nickitem = dynamic_cast<NicksOnlineItem*>(item);
```

#### AUTO 


```{c}
auto* ircViewBox = new IRCViewBox(m_headerSplitter);
```

#### RANGE FOR STATEMENT 


```{c}
for (Transfer* transfer : qAsConst(transferList)) {
                TransferSend *newTransfer = Application::instance()->getDccTransferManager()->newUpload();

                newTransfer->setConnectionId(transfer->getConnectionId());
                newTransfer->setPartnerNick(transfer->getPartnerNick());
                newTransfer->setFileURL(transfer->getFileURL());
                newTransfer->setFileName(transfer->getFileName());
                newTransfer->setReverse(transfer->isReverse());

                if (newTransfer->queue())
                {
                    newTransfer->start();
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[msg, chatWin]{
            KWindowSystem::setCurrentXdgActivationToken(msg->xdgActivationToken());
            chatWin->activateView();
        }
```

#### AUTO 


```{c}
auto *menu = new QMenu(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : selectedRowIndices) {
                if (index.data(TransferListModel::TransferType).toInt() == Transfer::Send ||
                    index.data(TransferListModel::TransferStatus).toInt() == Transfer::Done)
                {
                    Transfer *transfer = qobject_cast<Transfer*>(index.data(TransferListModel::TransferPointer).value<QObject*>());
                    if (transfer)
                    {
                        transfer->runFile();
                    }
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (QString parameter : qAsConst(parameterList)) {
                    if (!parameter.contains(QLatin1Char('!')))
                        parameter += QLatin1String("!*");

                    Preferences::removeIgnore(parameter);
                    Preferences::addIgnore(parameter + QLatin1Char(',') + QString::number(value));
                }
```

#### AUTO 


```{c}
auto notifyFunction = static_cast<KConfigCompilerSignallingItem::NotifyFunction>(&Preferences::itemChanged);
```

#### AUTO 


```{c}
auto* nickListButtonsLayout = new QVBoxLayout(nickListButtons);
```

#### AUTO 


```{c}
auto* mainWidget = new QWidget(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (TransferRecv* it : qAsConst(m_recvItems)) {
                    if ( it->getStatus() == Transfer::Queued &&
                         it->getFileURL().adjusted(QUrl::RemoveFilename) == m_defaultIncomingFolder.adjusted(QUrl::RemoveFilename))
                    {
                        QUrl url = QUrl::fromLocalFile(Preferences::self()->dccPath().adjusted(QUrl::StripTrailingSlash).toString() + QDir::separator() + it->getFileURL().fileName());
                        it->setFileURL(url);

                        emit fileURLChanged( it );
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (ChatWindow* activeView : qAsConst(m_activeViewOrderList)) {
            if (activeView->currentTabNotification() < prev->currentTabNotification()) {
                view = activeView;
            }
        }
```

#### AUTO 


```{c}
auto* widget = static_cast<QWidget*>(idx.internalPointer());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& nickname : watchList) {
        NickInfoPtr nickInfo = getOnlineNickInfo(networkName, nickname);

        if (nickInfo && nickInfo->getPrintedOnline())
        {
            // Nick is online.
            // Which server did NickInfo come from?
            Server* server=nickInfo->getServer();
            // Construct additional information string for nick.
            bool needWhois = false;
            QString nickAdditionalInfo = getNickAdditionalInfo(nickInfo, needWhois);
            // Add to network if not already added.
            QTreeWidgetItem* nickRoot = findItemChild(networkRoot, nickname, NicksOnlineItem::NicknameItem);
            if (!nickRoot)
                nickRoot = new NicksOnlineItem(NicksOnlineItem::NicknameItem, networkRoot, nickname, nickAdditionalInfo);
            NicksOnlineItem* nickitem = dynamic_cast<NicksOnlineItem*>(nickRoot);
            nickitem->setConnectionId(server->connectionId ());
            // Mark nick as online
            nickitem->setOffline(false);
            // Update icon
            nickitem->setIcon(nlvcNick, m_onlineIcon);
            nickRoot->setText(nlvcAdditionalInfo, nickAdditionalInfo);
            nickRoot->setText(nlvcServerName, serverName);
            // If no additional info available, request a WHOIS on the nick.
            if (!m_whoisRequested)
            {
                if (needWhois)
                {
                    requestWhois(networkName, nickname);
                    m_whoisRequested = true;
                }
            }

            const QStringList channelList = server->getNickChannels(nickname);

            for (const QString& channelName : channelList) {
                // Known channels where nickname is online and mode in each channel.
                // FIXME: If user connects to multiple servers in same network, the
                // channel info will differ between the servers, resulting in inaccurate
                // mode and led info displayed.

                ChannelNickPtr channelNick = server->getChannelNick(channelName, nickname);
                QString nickMode;
                if (channelNick->hasVoice()) nickMode = nickMode + i18n(" Voice");
                if (channelNick->isHalfOp()) nickMode = nickMode + i18n(" HalfOp");
                if (channelNick->isOp()) nickMode = nickMode + i18n(" Operator");
                if (channelNick->isOwner()) nickMode = nickMode + i18n(" Owner");
                if (channelNick->isAdmin()) nickMode = nickMode + i18n(" Admin");
                QTreeWidgetItem* channelItem = findItemChild(nickRoot, channelName, NicksOnlineItem::ChannelItem);
                if (!channelItem) channelItem = new NicksOnlineItem(NicksOnlineItem::ChannelItem,nickRoot,
                        channelName, nickMode);
                channelItem->setText(nlvcAdditionalInfo, nickMode);

                // Icon for mode of nick in each channel.
                Images::NickPrivilege nickPrivilege = Images::Normal;
                if (channelNick->hasVoice()) nickPrivilege = Images::Voice;
                if (channelNick->isHalfOp()) nickPrivilege = Images::HalfOp;
                if (channelNick->isOp()) nickPrivilege = Images::Op;
                if (channelNick->isOwner()) nickPrivilege = Images::Owner;
                if (channelNick->isAdmin()) nickPrivilege = Images::Admin;
                const bool isAway = (server->getJoinedChannelMembers(channelName) == nullptr);
                channelItem->setIcon(nlvcChannel,
                                     Application::instance()->images()->getNickIcon(nickPrivilege, isAway));
            }
            // Remove channel if nick no longer in it.
            for (int i = 0; i < nickRoot->childCount(); ++i)
            {
                QTreeWidgetItem* child = nickRoot->child(i);
                if (!channelList.contains(child->text(nlvcNick)))
                {
                    delete nickRoot->takeChild(i);
                    i--;
                }
            }
        }
        else
        {
            // Nick is offline.
            QTreeWidgetItem* nickRoot = findItemChild(networkRoot, nickname, NicksOnlineItem::NicknameItem);
            if (!nickRoot)
                nickRoot = new NicksOnlineItem(NicksOnlineItem::NicknameItem, networkRoot, nickname);
            // remove channels from the nick
            qDeleteAll(nickRoot->takeChildren());
            NicksOnlineItem* nickitem = dynamic_cast<NicksOnlineItem*>(nickRoot);
            nickitem->setConnectionId(servr->connectionId ());
            // Mark nick as offline
            nickitem->setOffline (true);
            // Update icon
            nickitem->setIcon(nlvcNick, m_offlineIcon);
            nickRoot->setText(nlvcServerName, serverName);
            nickRoot->setText(nlvcAdditionalInfo, QString());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& dir : qAsConst(dirs)) {
        if (nickIconSet->load(dir)) {
            break;
        }
    }
```

#### AUTO 


```{c}
const auto channelMenuActions = channelMenu->actions();
```

#### AUTO 


```{c}
auto* panel=new KonsolePanel(m_tabWidget);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& path : paths) {
        QDir dir(path);

        const auto themeDirs = dir.entryList(QDir::AllDirs | QDir::NoDotAndDotDot);
        for (const QString& themedir : themeDirs) {
            QFileInfo file(path + themedir + "/index.desktop");

            if(file.exists())
            {
                m_dirs.append(file.absoluteFilePath());
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl& url : urls) {
        getConnectionManager()->connectTo(Konversation::SilentlyReuseConnection, url.toString());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Forwarding *check : qAsConst(forwards)) {
                    if (check->port == port && check->proto == proto)
                        forward = check;
                }
```

#### AUTO 


```{c}
auto* transferJob = static_cast<KIO::TransferJob*>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (QPair<int, int> pair : urlRanges) {
                    length = pair.first - startPos;

                    line += replaceFormattingCodes(text.mid(startPos, length));

                    startPos = pair.first + pair.second;

                    line += QStringView(text).mid(pair.first, pair.second);
                }
```

#### AUTO 


```{c}
auto* labelMessage = new QLabel(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { _k_updateButtons(); }
```

#### AUTO 


```{c}
auto* headerWidgetLayout = new QHBoxLayout(headerWidget);
```

#### RANGE FOR STATEMENT 


```{c}
for (Channel* channel : qAsConst(m_channelList)) {
        channel->flushNickQueue();
        // Check if nick is in this channel or not.
        if(channel->getNickByName(nickname))
            removeNickFromChannel(channel->getName(), nickname, reason, messageTags, true);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& server : qAsConst(serversToAutoconnect)) {
                m_connectionManager->connectTo(Konversation::CreateNewConnection, server->id());
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (Server *server : serverList) {
        int index = m_ui.networkNameCombo->findData(server->connectionId());
        m_ui.networkNameCombo->setItemText(index, i18nc("network (nickname)", "%1 (%2)", server->getDisplayName(), server->getNickname()));
      }
```

#### AUTO 


```{c}
auto& historyChannel
```

#### AUTO 


```{c}
auto* transfer = static_cast<TransferRecv*>(m_transfer);
```

#### AUTO 


```{c}
auto *rowTransfer = qobject_cast<Transfer*>(rowIndex.data(TransferListModel::TransferPointer).value<QObject*>());
```

#### AUTO 


```{c}
auto* trimExcessAction = new QAction(i18n("Delete excess text"), m_warning);
```

#### AUTO 


```{c}
auto* tabBar = qobject_cast<QTabBar*>(widget);
```

#### RANGE FOR STATEMENT 


```{c}
for (TransferSend* it : m_sendItems) {
                if (it->getStatus() == Transfer::Transferring)
                    return true;
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : qAsConst(indexes)) {
                int offset = 0;
                for (const QModelIndex &removedIndex : qAsConst(indexesToRemove)) {
                    if (removedIndex.row() < index.row())
                    {
                        ++offset;
                    }
                }
                toSelectList.append(index.row() - offset);
            }
```

#### AUTO 


```{c}
auto *scroll = new QScrollArea(q);
```

#### LAMBDA EXPRESSION 


```{c}
[&](Channel* chan) {
            return (chan->getName() == channelName);
          }
```

#### RANGE FOR STATEMENT 


```{c}
for (Channel* chan : channels) {
            if(chan->getName() == (*it).name())
              joined = true;
          }
```

#### AUTO 


```{c}
const auto buttons = Preferences::quickButtonList();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : selectedRowIndices) {
                if (index.data(TransferListModel::TransferStatus).toInt() < Transfer::Done)
                {
                    Transfer *transfer = qobject_cast<Transfer*>(index.data(TransferListModel::TransferPointer).value<QObject*>());
                    if (transfer)
                    {
                        transfer->abort();
                    }
                }
            }
```

#### AUTO 


```{c}
auto* closeBtn = new QToolButton(m_tabWidget);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& capability : capabilities) {
                    const int nameStart = capability.indexOf(re);
                    QString modifierString = capability.left(nameStart);
                    QString name = capability.mid(nameStart);

                    Server::CapModifiers modifiers = Server::NoModifiers;

                    if (modifierString.contains(QLatin1Char('-')))
                    {
                        modifiers = modifiers | Server::DisMod;
                        modifiers = modifiers ^ Server::NoModifiers;
                    }

                    if (modifierString.contains(QLatin1Char('=')))
                    {
                        modifiers = modifiers | Server::StickyMod;
                        modifiers = modifiers ^ Server::NoModifiers;
                    }

                    if (modifierString.contains(QLatin1Char('~')))
                    {
                        modifiers = modifiers | Server::AckMod;
                        modifiers = modifiers ^ Server::NoModifiers;
                    }

                    if (command == QLatin1String("ack"))
                        m_server->capAcknowledged(name, modifiers);
                    else
                        m_server->capDenied(name);
                }
```

#### AUTO 


```{c}
auto* commandLineBox=new QWidget(this);
```

#### AUTO 


```{c}
auto *that = const_cast<IrcViewMimeData *>(this);
```

#### AUTO 


```{c}
const auto ignoreList = Preferences::ignoreList();
```

#### RANGE FOR STATEMENT 


```{c}
for (Ignore *ignore : qAsConst(self()->mIgnoreList)) {
        if (ignore->getName().section(QLatin1Char('!'),0,0).toLower()==nickname.toLower())
        {
            return true;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Server* server : serverList)
        if (server->isConnected())
            server->requestAway(reason);
```

#### RANGE FOR STATEMENT 


```{c}
for (Ignore *ignore : qAsConst(self()->mIgnoreList)) {
        if (ignore->getName().toLower() == oldIgnore.toLower())
        {
            self()->mIgnoreList.removeOne(ignore);
            delete ignore;
            return true;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Chat* chat : m_chatItems) {
                if (chat->status() == Chat::Chatting)
                    return true;
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &currentMode : modes) {
            mode = currentMode[0].toLatin1();
            switch(mode)
            {
                case 't':
                    m_ui.topicModeChBox->setChecked(true);
                    break;
                case 'n':
                    m_ui.messageModeChBox->setChecked(true);
                    break;
                case 'l':
                    m_ui.userLimitChBox->setChecked(true);
                    m_ui.userLimitEdit->setValue(currentMode.midRef(1).toInt());
                    break;
                case 'i':
                    m_ui.inviteModeChBox->setChecked(true);
                    break;
                case 'm':
                    m_ui.moderatedModeChBox->setChecked(true);
                    break;
                case 's':
                    m_ui.secretModeChBox->setChecked(true);
                    break;
                case 'k':
                    m_ui.keyModeChBox->setChecked(true);
                    m_ui.keyModeEdit->setText(currentMode.mid(1));
                    break;
                default:
                {
                    bool found = false;
                    QString modeString;
                    modeString = mode;

                    for (int i = 0; !found && i < modesModel->rowCount(); ++i)
                    {
                        QStandardItem *item = modesModel->item(i, 0);
                        if (item->data().toString() == modeString)
                        {
                            found = true;
                            item->setCheckState(Qt::Checked);
                            modesModel->item(i, 1)->setText(currentMode.mid(1));
                        }
                    }

                    break;
                }
            }
        }
```

#### AUTO 


```{c}
auto* passwordLabel = new QLabel(i18n("P&assword:"), page);
```

#### CONST EXPRESSION 


```{c}
constexpr int DIRECTION_BOTH   = 2;
```

#### AUTO 


```{c}
auto* server = new Server(this, settings);
```

#### RANGE FOR STATEMENT 


```{c}
for (QPair<int, int> urlRange : urlRanges) {
        QString url = filteredLine.mid(urlRange.first, urlRange.second);

        auto* action = new QAction(showURLmenu);
        action->setText(url);
        action->setData(url);

        showURLmenu->addAction(action);

        connect(action, &QAction::triggered, this, &ChannelListPanel::openURL);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (TransferSend* it : qAsConst(m_sendItems)) {
                if (
                    it->getStatus() == Transfer::WaitingRemote &&
                    it->getConnectionId() == connectionId &&
                    it->getPartnerNick() == partnerNick &&
                    it->getFileName() == fileName &&
                    it->getFileSize() == fileSize &&
                    it->getReverseToken() == token
                )
                {
                    transfer = it;
                    break;
                }
            }
```

#### CONST EXPRESSION 


```{c}
constexpr float OSD_WINDOW_OPACITY = 0.8;
```

#### AUTO 


```{c}
auto* dateItem = new UrlDateItem(dateTime);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& warningDialogDefinition : warningDialogDefinitions) {
        const QLatin1String flagName(warningDialogDefinition.flagName);
#if KI18N_VERSION >= QT_VERSION_CHECK(5, 89, 0)
        const QString message = warningDialogDefinition.message.toString();
#else
        const char * const message(warningDialogDefinition.message);
        const char * const ctx(warningDialogDefinition.context);
#endif

        auto *item = new QTreeWidgetItem(dialogListView);
#if KI18N_VERSION >= QT_VERSION_CHECK(5, 89, 0)
        item->setText(0, message);
#else
        item->setText(0, i18nc(ctx, message));
#endif
        item->setFlags(item->flags() | Qt::ItemIsUserCheckable);
        item->setData(0, WarningNameRole, flagName);

        if (flagName == QLatin1String("LargePaste"))
        {
            item->setCheckState(0, grp.readEntry(flagName, QString()).isEmpty() ? Qt::Checked : Qt::Unchecked);
        }
        else if (flagName == QLatin1String("Invitation"))
        {
            item->setCheckState(0, grp.readEntry(flagName, QStringLiteral("0")) == QLatin1Char('0') ? Qt::Checked : Qt::Unchecked);
        }
        else
        {
            item->setCheckState(0, grp.readEntry(flagName, true) ? Qt::Checked : Qt::Unchecked);
        }
    }
```

#### AUTO 


```{c}
auto* logReader = new LogfileReader(m_tabWidget, file, caption);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& out : qAsConst(result.outputList)) {
                    appendQuery(m_server->getNickname(), out);
                }
```

#### AUTO 


```{c}
auto it = channelEncodingEntries.begin(), end = channelEncodingEntries.end();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& identity : identities) {
        if (identity->getName() == name) {
            return identity;
        }
    }
```

#### AUTO 


```{c}
const auto ignoreItems = Preferences::ignoreList();
```

#### AUTO 


```{c}
auto* item = dynamic_cast<HighlightViewItem*>(highlightListView->currentItem());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& channel : history) {
          const QString channelName = channel.name();
          // Don't add empty items to the combobox
          if (channelName.isEmpty())
            continue;

          const bool joined = std::any_of(channels.begin(), channels.end(), [&](Channel* chan) {
            return (chan->getName() == channelName);
          });

          if(!joined)
            channelHistory << channel.name();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const TransferItemData &item : m_transferList) {
                if (item.displayType == displaytype)
                {
                    ++count;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QChar a : allowed) {
                    if (!newModes.contains(a))
                        newModes.append(a);
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (Server* server : serverList)
        if (server->isConnected() && server->isAway())
            server->requestUnaway();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& channel : qAsConst(m_changedChannels)) {
        if (m_joinedChannels.contains (channel))
        {
            emit channelNickChanged(channel);

            for (ChannelNickPtr nick : qAsConst(*m_joinedChannels[channel])) {
                if(nick->isChanged())
                {
                    nick->setChanged(false);
                }
            }
        }
    }
```

#### AUTO 


```{c}
auto* view = qobject_cast<KonsolePanel*>(m_tabWidget->widget(popup));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& index : selectedIndexes)
            bookmarks << KBookmarkOwner::FutureBookmark(index.data().toString(), QUrl(index.data().toString()), QString());
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString &nick : m_nicknameLBox->items())
            {
                if(nick.contains(QLatin1Char(' ')))
                {
                    KMessageBox::error(this, i18n("Nicks must not contain spaces."));
                    bool block = m_identityCBox->blockSignals(true);
                    m_identityCBox->setCurrentIndex(m_identityCBox->findText(m_currentIdentity->getName()));
                    m_identityCBox->blockSignals(block);
                    tabWidget->setCurrentIndex(0);
                    m_nicknameLBox->lineEdit()->setFocus();
                    return false;
                }
            }
```

#### AUTO 


```{c}
auto* panel = static_cast<KonsolePanel*>(view);
```

#### AUTO 


```{c}
auto* confConnectionBehavior = new ConnectionBehavior_Config(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &currentMode : modes) {
            mode = currentMode[0].toLatin1();
            switch(mode)
            {
                case 't':
                    m_ui.topicModeChBox->setChecked(true);
                    break;
                case 'n':
                    m_ui.messageModeChBox->setChecked(true);
                    break;
                case 'l':
                    m_ui.userLimitChBox->setChecked(true);
#if QT_VERSION < QT_VERSION_CHECK(6, 0, 0)
                    m_ui.userLimitEdit->setValue(currentMode.midRef(1).toInt());
#else
                    m_ui.userLimitEdit->setValue(QStringView(currentMode).mid(1).toInt());
#endif
                    break;
                case 'i':
                    m_ui.inviteModeChBox->setChecked(true);
                    break;
                case 'm':
                    m_ui.moderatedModeChBox->setChecked(true);
                    break;
                case 's':
                    m_ui.secretModeChBox->setChecked(true);
                    break;
                case 'k':
                    m_ui.keyModeChBox->setChecked(true);
                    m_ui.keyModeEdit->setText(currentMode.mid(1));
                    break;
                default:
                {
                    bool found = false;
                    QString modeString;
                    modeString = QLatin1Char(mode);

                    for (int i = 0; !found && i < modesModel->rowCount(); ++i)
                    {
                        QStandardItem *item = modesModel->item(i, 0);
                        if (item->data().toString() == modeString)
                        {
                            found = true;
                            item->setCheckState(Qt::Checked);
                            modesModel->item(i, 1)->setText(currentMode.mid(1));
                        }
                    }

                    break;
                }
            }
        }
```

#### CONST EXPRESSION 


```{c}
constexpr int MAXHISTORY = 100;
```

#### AUTO 


```{c}
auto* chatSplitter = new QSplitter(Qt::Vertical);
```

#### RANGE FOR STATEMENT 


```{c}
for (Server *server : serverList) {
        if (m_ui.networkNameCombo->findData(server->connectionId()) == -1)
        {
          m_ui.networkNameCombo->addItem(i18nc("network (nickname)", "%1 (%2)", server->getDisplayName(), server->getNickname()),
                                         server->connectionId());
          connect(server, &Server::nicknameChanged, this, &JoinChannelDialog::slotNicknameChanged);
        }
      }
```

#### AUTO 


```{c}
const auto* tab = static_cast<ChatWindow*>(m_tabWidget->widget(i));
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { _k_settingsChangedSlot(); }
```

#### AUTO 


```{c}
auto* toggleChannelNickListsAction = new KToggleAction(this);
```

#### AUTO 


```{c}
auto* menu = new QMenu(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (QStandardItem* item : existing) {
        if (m_urlModel->item(item->row(), 0)->data(Qt::DisplayRole).toString() == origin)
            m_urlModel->removeRow(item->row());
    }
```

#### AUTO 


```{c}
auto *validator = new QRegularExpressionValidator(noSpaceRx, this);
```

#### AUTO 


```{c}
auto *modesModel = new QStandardItemModel(m_ui.otherModesList);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& serverName : serverNames) {
                KConfigGroup cgServer(KSharedConfig::openConfig()->group(serverName));
                server.setHost(cgServer.readEntry("Server"));
                server.setPort(cgServer.readEntry<int>("Port", 0));
                server.setPassword(cgServer.readEntry("Password"));
                server.setSSLEnabled(cgServer.readEntry("SSLEnabled", false));
                server.setBypassProxy(cgServer.readEntry("BypassProxy", false));
                serverGroup->addServer(server);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (Channel* lookChannel : m_channelList) {
        const auto lookChannelNickList = lookChannel->getNickList();
        for (Nick* lookNick : lookChannelNickList) {
            if (!nickList.contains(lookNick->getChannelNick()->getNickname()))
                nickList.append(lookNick->getChannelNick()->getNickname());
        }
    }
```

#### AUTO 


```{c}
auto* view = qobject_cast<ChatWindow*>(m_tabWidget->currentWidget());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& serverGroup : qAsConst(sortedServerGroupMap)) {
        const Konversation::ServerList serverList = serverGroup->serverList();
        servers.clear();
        servers.reserve(serverList.size());

        sgKeys.append(serverGroup->id());

        for (const auto& server : serverList) {
            const QString groupName = QStringLiteral("Server %1").arg(index2);
            servers.append(groupName);
            KConfigGroup cgServer(KSharedConfig::openConfig()->group(groupName));
            cgServer.writeEntry("Server", server.host());
            cgServer.writeEntry("Port", server.port());
            cgServer.writeEntry("Password", server.password());
            cgServer.writeEntry("SSLEnabled", server.SSLEnabled());
            cgServer.writeEntry("BypassProxy", server.bypassProxy());
            index2++;
        }

        const Konversation::ChannelList channelList = serverGroup->channelList();
        channels.clear();
        channels.reserve(channelList.size());

        for (const auto& channel : channelList) {
            const QString groupName = QStringLiteral("Channel %1").arg(index3);
            channels.append(groupName);
            KConfigGroup cgChannel(KSharedConfig::openConfig()->group(groupName));
            cgChannel.writeEntry("Name", channel.name());
            cgChannel.writeEntry("Password", channel.password());
            index3++;
        }

        const Konversation::ChannelList channelHistoryList = serverGroup->channelHistory();
        channelHistory.clear();
        channelHistory.reserve(channelHistoryList.size());

        for (const auto& channel : channelHistoryList) {
            // TODO FIXME: is it just me or is this broken?
            const QString groupName = QStringLiteral("Channel %1").arg(index3);
            channelHistory.append(groupName);
            KConfigGroup cgChannelHistory(KSharedConfig::openConfig()->group(groupName));
            cgChannelHistory.writeEntry("Name", channel.name());
            cgChannelHistory.writeEntry("Password", channel.password());
            cgChannelHistory.writeEntry("EnableNotifications", channel.enableNotifications());
            index3++;
        }

        QString sgn = QStringLiteral("ServerGroup %1").arg(QString::number(index).rightJustified(width,QLatin1Char('0')));
        KConfigGroup cgServerGroup(KSharedConfig::openConfig()->group(sgn));
        cgServerGroup.writeEntry("Name", serverGroup->name());
        cgServerGroup.writeEntry("Identity", serverGroup->identity()->getName());
        cgServerGroup.writeEntry("ServerList", servers);
        cgServerGroup.writeEntry("AutoJoinChannels", channels);
        cgServerGroup.writeEntry("ConnectCommands", serverGroup->connectCommands());
        cgServerGroup.writeEntry("AutoConnect", serverGroup->autoConnectEnabled());
        cgServerGroup.writeEntry("ChannelHistory", channelHistory);
        cgServerGroup.writeEntry("EnableNotifications", serverGroup->enableNotifications());
        cgServerGroup.writeEntry("Expanded", serverGroup->expanded());
        cgServerGroup.writeEntry("NotifyList",Preferences::notifyStringByGroupId(serverGroup->id()));
        index++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& channel : nickChannels) {
            removeChannelNick(channel, lcNickname);
        }
```

#### CONST EXPRESSION 


```{c}
constexpr int RADIUS = 4;
```

#### AUTO 


```{c}
auto it = serverGroupHash.cbegin(), end = serverGroupHash.cend();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &capString : qAsConst(capsList))
    {
        if (m_capabilityNames.contains(capString))
            m_capabilities &= ~(m_capabilityNames.value(capString));
    }
```

#### AUTO 


```{c}
auto* action = qobject_cast<KToggleAction*>(actionCollection()->action(QStringLiteral("open_channel_list")));
```

#### AUTO 


```{c}
auto* newEngine = new LedIconEngine(m_color, m_state);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : qAsConst(selectedIndexes)) {
                int offset = 0;
                for (const QModelIndex &removedIndex : qAsConst(indexesToRemove)) {
                    if (removedIndex.row() < index.row())
                    {
                        ++offset;
                    }
                }
                toSelectList.append(index.row() - offset);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : selectedRowIndices) {
                if (index.data(TransferListModel::TransferType).toInt() == Transfer::Send &&
                    index.data(TransferListModel::TransferStatus).toInt() >= Transfer::Done)
                {
                    auto *transfer = qobject_cast<Transfer*>(index.data(TransferListModel::TransferPointer).value<QObject*>());
                    if (!transfer)
                    {
                        continue;
                    }
                    transferList.append(transfer);
                }
            }
```

#### AUTO 


```{c}
auto it = encodingEntries.begin(), end = encodingEntries.end();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QChar a : allowed) {
                                if (!newModes.contains(a))
                                    newModes.append(a);
                            }
```

#### RANGE FOR STATEMENT 


```{c}
for (ChatWindow *view : qAsConst(topLevelViews)) {
        m_tabWidget->insertTab(insertIndex(view), view, QIcon(), view->getName().replace('&', QLatin1String("&&")));
    }
```

#### AUTO 


```{c}
const auto* nlItem = static_cast<const NicksOnlineItem*>(item);
```

#### AUTO 


```{c}
const auto& otherNick = static_cast<const Nick&>(other);
```

