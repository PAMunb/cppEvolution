#### LAMBDA EXPRESSION 


```{c}
[&set](const QString &, const QString &name)
		{
			set.insert(name);
		}
```

#### LAMBDA EXPRESSION 


```{c}
[&newTheme, theme](const QString &dir, const QString &name)
		{
			if (name == theme)
				newTheme = TokenTheme(name, dir);
		}
```

#### LAMBDA EXPRESSION 


```{c}
[&list](const QString &dir, const QString &name)
		{
			list.append(TokenTheme(name, dir));
		}
```

#### LAMBDA EXPRESSION 


```{c}
[this, command]() { buttonCommand(command); }
```

