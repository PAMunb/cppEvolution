#### LAMBDA EXPRESSION 


```{c}
[t](double s, const Periodic &p) {
        return s + p.a * std::cos(p.b_rad + p.c_rad * t);
    }
```

#### AUTO 


```{c}
const auto dLambda = 1 + (0.0334 * std::cos(W_rad)) + (0.0007 * std::cos(2 * W_rad));
```

#### AUTO 


```{c}
auto i = phaseChange.date.daysTo(dt);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &calendarType : qAsConst(m_fileCalendarTypes)) {

        // Cater for events defined in other Calendar Systems where request year could cover 2 or 3 event years
        // Perhaps also parse year before and year after to allow events to span years or shift to other year?
        setParseCalendar(calendarType);
        setParseStartEnd();

        // Generate all events for this calendar in the required year(s)
        for (m_parseYear = m_parseStartYear; m_parseYear <= m_parseEndYear; ++m_parseYear) {

            m_parseYearStart = m_parseCalendar.firstDayOfYear(m_parseYear);
            m_parseYearEaster = easter(m_parseYear);
            m_parseYearPascha = pascha(m_parseYear);

            std::istringstream iss2(std::string(m_scanData.data()));
            m_scanner->yyrestart(&iss2);

            m_parser->parse();
        }

    }
```

#### AUTO 


```{c}
const auto T = (jde0 - 2451545.0) / 36525;
```

#### RANGE FOR STATEMENT 


```{c}
for (const KHolidays::Holiday &holiday : holidays) {
            qDebug() << "Date = " << holiday.observedStartDate().toString(Qt::ISODate) << " Duration = " << holiday.duration() << " Name = " << holiday.name();
        }
```

#### AUTO 


```{c}
const auto hr = KHolidays::HolidayRegion(regionCode);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &phaseChange : phase_changes) {
        for (auto i = phaseChange.date.daysTo(dt); i > 0; --i) {
            QCOMPARE(LunarPhase::phaseAtDate(phaseChange.date.addDays(i)), phase);
        }
        dt = phaseChange.date;
        phase = phaseChange.phase;
        QCOMPARE(LunarPhase::phaseAtDate(dt), phase);
        QVERIFY(!LunarPhase::phaseNameAtDate(dt).isEmpty());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto season : { JuneSolstice, DecemberSolstice, MarchEquinox, SeptemberEquinox }) {
        if (seasonDate(season, date.year()) == date) {
            return season;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KHolidays::Holiday &holidayCat : m_resultListTemp) {
        for (const QString &mCategoryList : holidayCat.categoryList()) {
            if (mCategoryList == category) {
                m_resultList.append(holidayCat);
                break;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KHolidays::Holiday &holiday : holidays) {
            qDebug() << "Date = " << holiday.observedStartDate().toString(Qt::ISODate) << " Duration = " << holiday.duration() << " Name = " << holiday.name()
                     << " category = " << holiday.categoryList();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](QQmlEngine *engine, QJSEngine *) -> QJSValue {
            return engine->toScriptValue(LunarPhaseWrapper());
        }
```

#### LAMBDA EXPRESSION 


```{c}
[t](double s, const Periodic &p) { return s + p.a * std::cos(p.b_rad + p.c_rad * t); }
```

#### AUTO 


```{c}
const auto &phaseChange
```

#### CONST EXPRESSION 


```{c}
static constexpr const double Down = -1.0;
```

#### RANGE FOR STATEMENT 


```{c}
for (const KHolidays::Holiday &thisHoliday : qAsConst(m_resultList)) {
        if (thisHoliday.name() == eventName) {
            return thisHoliday.observedStartDate().toJulianDay();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KHolidays::Holiday &holiday : holidays) {
            qDebug() << "Date = " << holiday.observedStartDate().toString(Qt::ISODate)
                     << " Duration = " << holiday.duration()
                     << " Name = " << holiday.name();
        }
```

#### AUTO 


```{c}
const auto jde0 = meanJDE(season, year);
```

#### AUTO 


```{c}
const auto W_rad = W_deg * (M_PI / 180.0);
```

#### CONST EXPRESSION 


```{c}
constexpr double mmlongp = 349.383063;
```

#### CONST EXPRESSION 


```{c}
constexpr double PI = 3.14159265358979323846;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &calendarType : qAsConst(m_fileCalendarTypes)) {
        // Cater for events defined in other Calendar Systems where request year could cover 2 or 3 event years
        // Perhaps also parse year before and year after to allow events to span years or shift to other year?
        setParseCalendar(calendarType);
        setParseStartEnd();

        // Generate all events for this calendar in the required year(s)
        for (m_parseYear = m_parseStartYear; m_parseYear <= m_parseEndYear; ++m_parseYear) {
            m_parseYearStart = m_parseCalendar.firstDayOfYear(m_parseYear);
            m_parseYearEaster = easter(m_parseYear);
            m_parseYearPascha = pascha(m_parseYear);

            std::istringstream iss2(std::string(m_scanData.data()));
            m_scanner->yyrestart(&iss2);

            m_parser->parse();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto season : {JuneSolstice, DecemberSolstice, MarchEquinox, SeptemberEquinox}) {
        if (seasonDate(season, date.year()) == date) {
            return season;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KHolidays::Holiday &thisHoliday : std::as_const(m_resultList)) {
        if (thisHoliday.name() == eventName) {
            return thisHoliday.observedStartDate().toJulianDay();
        }
    }
```

#### AUTO 


```{c}
const auto dt = AstroSeasons::seasonDate(s, year);
```

#### LAMBDA EXPRESSION 


```{c}
[](QQmlEngine *engine, QJSEngine *) -> QJSValue {
        return engine->toScriptValue(SunRiseSetWrapper());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto s : {AstroSeasons::JuneSolstice, AstroSeasons::DecemberSolstice, AstroSeasons::MarchEquinox, AstroSeasons::SeptemberEquinox}) {
            const auto dt = AstroSeasons::seasonDate(s, year);
            if (dt >= startDate && dt <= endDate) {
                Holiday season;
                season.d->mDayType = Holiday::Workday;
                season.d->mObservedDate = dt;
                season.d->mDuration = 1;
                season.d->mName = AstroSeasons::seasonName(s);
                season.d->mCategoryList.append(QLatin1String("seasonal"));
                seasons_resultList.append(season);
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](QQmlEngine *engine, QJSEngine *) -> QJSValue {
        return engine->toScriptValue(LunarPhaseWrapper());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &regionCode : regionList) {
        QString regionCountry = KHolidays::HolidayRegion::countryCode(regionCode).toLower();
        QString regionSubdivisionCountry;
        if (regionCountry.split(QLatin1Char('-')).count() > 1) {
            regionSubdivisionCountry = regionCountry.split(QLatin1Char('-')).at(0);
        }
        QString regionLanguage = KHolidays::HolidayRegion::languageCode(regionCode).toLower();

        if (regionCountry == localeCountry && regionLanguage == localeLanguage) {
            countryAndLanguageMatch = regionCode;
            break; // exact match so don't look further
        } else if (regionCountry == localeCountry) {
            if (countryOnlyMatch.isEmpty()) {
                countryOnlyMatch = regionCode;
            }
        } else if (!regionSubdivisionCountry.isEmpty() &&
                   regionSubdivisionCountry == localeCountry &&
                   regionLanguage == localeLanguage) {
            if (subdivisionAndLanguageMatch.isEmpty()) {
                subdivisionAndLanguageMatch = regionCode;
            }
        } else if (!regionSubdivisionCountry.isEmpty() && regionSubdivisionCountry == localeCountry) {
            if (subdivisionOnlyMatch.isEmpty()) {
                subdivisionOnlyMatch = regionCode;
            }
        } else if (!localeLanguageCountry.isEmpty() &&
                   regionCountry == localeLanguageCountry &&
                   regionLanguage == localeLanguage) {
            if (languageCountryAndLanguageMatch.isEmpty()) {
                languageCountryAndLanguageMatch = regionCode;
            }
        } else if (!localeLanguageCountry.isEmpty() && regionCountry == localeLanguageCountry) {
            if (languageCountryOnlyMatch.isEmpty()) {
                languageCountryOnlyMatch = regionCode;
            }
        } else if (!regionSubdivisionCountry.isEmpty() &&
                   !localeLanguageCountry.isEmpty() &&
                   regionSubdivisionCountry == localeLanguageCountry &&
                   regionLanguage == localeLanguage) {
            if (languageSubdivisionAndLanguageMatch.isEmpty()) {
                languageSubdivisionAndLanguageMatch = regionCode;
            }
        } else if (!regionSubdivisionCountry.isEmpty() &&
                   !localeLanguageCountry.isEmpty() &&
                   regionSubdivisionCountry == localeLanguageCountry) {
            if (languageSubdivisionOnlyMatch.isEmpty()) {
                languageSubdivisionOnlyMatch = regionCode;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &regionCode : regionCodes) {
        KHolidays::HolidayRegion testRegion(regionCode);
        printMetadata(testRegion);
        parseRegionCalendarYear(testRegion, QDate::currentDate().year());
        qDebug() << "";
    }
```

#### AUTO 


```{c}
const auto idx = localeCountry.indexOf(QLatin1Char('-'));
```

#### RANGE FOR STATEMENT 


```{c}
for (auto s : {AstroSeasons::JuneSolstice, AstroSeasons::DecemberSolstice, AstroSeasons::MarchEquinox, AstroSeasons::SeptemberEquinox}) {
            const auto dt = AstroSeasons::seasonDate(s, year);
            if (dt >= startDate && dt <= endDate) {
                Holiday season;
                season.d->mDayType = Holiday::Workday;
                season.d->mObservedDate = dt;
                season.d->mDuration = 1;
                season.d->mName = AstroSeasons::seasonName(s);
                season.d->mCategoryList.append(QLatin1String("seasonal"));
                m_resultList.append(season);
            }
        }
```

#### AUTO 


```{c}
auto file = QStandardPaths::locate(QStandardPaths::GenericDataLocation,
                                       QLatin1String("kf5/libkholidays/plan2/holiday_") + mRegionCode);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto s : { AstroSeasons::JuneSolstice, AstroSeasons::DecemberSolstice, AstroSeasons::MarchEquinox, AstroSeasons::SeptemberEquinox }) {
             const auto dt = AstroSeasons::seasonDate(s, year);
             if (dt >= startDate && dt <= endDate) {
                Holiday season;
                season.d->mDayType = Holiday::Workday;
                season.d->mObservedDate = dt;
                season.d->mDuration = 1;
                season.d->mName = AstroSeasons::seasonName(s);
                season.d->mCategoryList.append(QLatin1String("seasonal"));
                m_resultList.append(season);
             }
         }
```

#### LAMBDA EXPRESSION 


```{c}
[](QQmlEngine *engine, QJSEngine *) -> QJSValue {
            return engine->toScriptValue(SunRiseSetWrapper());
        }
```

#### AUTO 


```{c}
const auto W_deg = 35999.373 * T + 2.47;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &regionCode : regionCodes) {
        KHolidays::HolidayRegion testRegion(regionCode);
        qDebug() << regionCode << " = " << testRegion.name();
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr const double CivilTwilight = -6.0;
```

#### CONST EXPRESSION 


```{c}
constexpr double epsilon = 1e-6;
```

#### AUTO 


```{c}
auto file = QStandardPaths::locate(QStandardPaths::GenericDataLocation, //
                                               QLatin1String("kf5/libkholidays/plan2/holiday_") + mRegionCode);
```

#### CONST EXPRESSION 


```{c}
constexpr double earthEcc = 0.016718;
```

#### CONST EXPRESSION 


```{c}
static constexpr const double Up = 1.0;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &regionCode : regionList) {
        const auto hr = KHolidays::HolidayRegion(regionCode);
        QString regionCountry = hr.countryCode().toLower();
        QString regionSubdivisionCountry;
        if (regionCountry.split(QLatin1Char('-')).count() > 1) {
            regionSubdivisionCountry = regionCountry.split(QLatin1Char('-')).at(0);
        } else {
            regionSubdivisionCountry = regionCountry;
        }
        QString regionLanguage = hr.languageCode().toLower();

        if (regionCountry == localeCountry && regionLanguage == localeLanguage) {
            // exact match so don't look further
            return regionCode;
        } else if (regionCountry == localeSubdivision && regionLanguage == localeLanguage) {
            countryAndLanguageMatch = regionCode;
        } else if (regionCountry == localeCountry) {
            if (countryOnlyMatch.isEmpty()) {
                countryOnlyMatch = regionCode;
            }
        } else if (!regionSubdivisionCountry.isEmpty() &&
                   regionSubdivisionCountry == localeSubdivision &&
                   regionLanguage == localeLanguage) {
            if (subdivisionAndLanguageMatch.isEmpty()) {
                subdivisionAndLanguageMatch = regionCode;
            }
        } else if (!regionSubdivisionCountry.isEmpty() && regionSubdivisionCountry == localeSubdivision) {
            if (subdivisionOnlyMatch.isEmpty()) {
                subdivisionOnlyMatch = regionCode;
            }
        } else if (!localeLanguageCountry.isEmpty() &&
                   regionCountry == localeLanguageCountry &&
                   regionLanguage == localeLanguage) {
            if (languageCountryAndLanguageMatch.isEmpty()) {
                languageCountryAndLanguageMatch = regionCode;
            }
        } else if (!localeLanguageCountry.isEmpty() && regionCountry == localeLanguageCountry) {
            if (languageCountryOnlyMatch.isEmpty()) {
                languageCountryOnlyMatch = regionCode;
            }
        } else if (!regionSubdivisionCountry.isEmpty() &&
                   !localeLanguageCountry.isEmpty() &&
                   regionSubdivisionCountry == localeLanguageCountry &&
                   regionLanguage == localeLanguage) {
            if (languageSubdivisionAndLanguageMatch.isEmpty()) {
                languageSubdivisionAndLanguageMatch = regionCode;
            }
        } else if (!regionSubdivisionCountry.isEmpty() &&
                   !localeLanguageCountry.isEmpty() &&
                   regionSubdivisionCountry == localeLanguageCountry) {
            if (languageSubdivisionOnlyMatch.isEmpty()) {
                languageSubdivisionOnlyMatch = regionCode;
            }
        }
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr const double Sunrise = -0.833;
```

#### CONST EXPRESSION 


```{c}
constexpr double elongp = 282.596403;
```

#### CONST EXPRESSION 


```{c}
constexpr double mmlong = 64.975464;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &regionCode : regionList) {
        const auto hr = KHolidays::HolidayRegion(regionCode);
        QString regionCountry = hr.countryCode().toLower();
        QString regionSubdivisionCountry;
        if (regionCountry.split(QLatin1Char('-')).count() > 1) {
            regionSubdivisionCountry = regionCountry.split(QLatin1Char('-')).at(0);
        } else {
            regionSubdivisionCountry = regionCountry;
        }
        QString regionLanguage = hr.languageCode().toLower();

        if (regionCountry == localeCountry && regionLanguage == localeLanguage) {
            // exact match so don't look further
            return regionCode;
        } else if (regionCountry == localeSubdivision && regionLanguage == localeLanguage) {
            countryAndLanguageMatch = regionCode;
        } else if (regionCountry == localeCountry) {
            if (countryOnlyMatch.isEmpty()) {
                countryOnlyMatch = regionCode;
            }
        } else if (!regionSubdivisionCountry.isEmpty() && regionSubdivisionCountry == localeSubdivision && regionLanguage == localeLanguage) {
            if (subdivisionAndLanguageMatch.isEmpty()) {
                subdivisionAndLanguageMatch = regionCode;
            }
        } else if (!regionSubdivisionCountry.isEmpty() && regionSubdivisionCountry == localeSubdivision) {
            if (subdivisionOnlyMatch.isEmpty()) {
                subdivisionOnlyMatch = regionCode;
            }
        } else if (!localeLanguageCountry.isEmpty() && regionCountry == localeLanguageCountry && regionLanguage == localeLanguage) {
            if (languageCountryAndLanguageMatch.isEmpty()) {
                languageCountryAndLanguageMatch = regionCode;
            }
        } else if (!localeLanguageCountry.isEmpty() && regionCountry == localeLanguageCountry) {
            if (languageCountryOnlyMatch.isEmpty()) {
                languageCountryOnlyMatch = regionCode;
            }
        } else if (!regionSubdivisionCountry.isEmpty() && !localeLanguageCountry.isEmpty() && regionSubdivisionCountry == localeLanguageCountry
                   && regionLanguage == localeLanguage) {
            if (languageSubdivisionAndLanguageMatch.isEmpty()) {
                languageSubdivisionAndLanguageMatch = regionCode;
            }
        } else if (!regionSubdivisionCountry.isEmpty() && !localeLanguageCountry.isEmpty() && regionSubdivisionCountry == localeLanguageCountry) {
            if (languageSubdivisionOnlyMatch.isEmpty()) {
                languageSubdivisionOnlyMatch = regionCode;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &mCategoryList : holidayCat.categoryList()) {
            if (mCategoryList == category) {
                m_resultList.append(holidayCat);
                break;
            }
        }
```

#### AUTO 


```{c}
auto season
```

#### AUTO 


```{c}
auto s
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &filename : files) {
        regionCodesList.append(filename.mid(filename.lastIndexOf(QLatin1String("holiday_")) + 8));
    }
```

#### AUTO 


```{c}
const auto S = periodicTerms(T);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &dir : std::as_const(dirs)) {
        QDirIterator it(dir, QStringList() << QStringLiteral("holiday_") + location + '*');
        while (it.hasNext()) {
            files.push_back(it.next());
        }
    }
```

#### CONST EXPRESSION 


```{c}
constexpr double elonge = 278.833540;
```

#### RANGE FOR STATEMENT 


```{c}
for (const KHolidays::Holiday &holiday : holidayList) {
            if (holiday.dayType() == Holiday::NonWorkday) {
                return true;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &regionCode : regionList) {
        QString regionCountry = KHolidays::HolidayRegion::countryCode(regionCode).toLower();
        QString regionSubdivisionCountry;
        if (regionCountry.split(QLatin1Char('-')).count() > 1) {
            regionSubdivisionCountry = regionCountry.split(QLatin1Char('-')).at(0);
        } else {
            regionSubdivisionCountry = regionCountry;
        }
        QString regionLanguage = KHolidays::HolidayRegion::languageCode(regionCode).toLower();

        if (regionCountry == localeCountry && regionLanguage == localeLanguage) {
            // exact match so don't look further
            return regionCode;
        } else if (regionCountry == localeSubdivision && regionLanguage == localeLanguage) {
            countryAndLanguageMatch = regionCode;
        } else if (regionCountry == localeCountry) {
            if (countryOnlyMatch.isEmpty()) {
                countryOnlyMatch = regionCode;
            }
        } else if (!regionSubdivisionCountry.isEmpty() &&
                   regionSubdivisionCountry == localeSubdivision &&
                   regionLanguage == localeLanguage) {
            if (subdivisionAndLanguageMatch.isEmpty()) {
                subdivisionAndLanguageMatch = regionCode;
            }
        } else if (!regionSubdivisionCountry.isEmpty() && regionSubdivisionCountry == localeSubdivision) {
            if (subdivisionOnlyMatch.isEmpty()) {
                subdivisionOnlyMatch = regionCode;
            }
        } else if (!localeLanguageCountry.isEmpty() &&
                   regionCountry == localeLanguageCountry &&
                   regionLanguage == localeLanguage) {
            if (languageCountryAndLanguageMatch.isEmpty()) {
                languageCountryAndLanguageMatch = regionCode;
            }
        } else if (!localeLanguageCountry.isEmpty() && regionCountry == localeLanguageCountry) {
            if (languageCountryOnlyMatch.isEmpty()) {
                languageCountryOnlyMatch = regionCode;
            }
        } else if (!regionSubdivisionCountry.isEmpty() &&
                   !localeLanguageCountry.isEmpty() &&
                   regionSubdivisionCountry == localeLanguageCountry &&
                   regionLanguage == localeLanguage) {
            if (languageSubdivisionAndLanguageMatch.isEmpty()) {
                languageSubdivisionAndLanguageMatch = regionCode;
            }
        } else if (!regionSubdivisionCountry.isEmpty() &&
                   !localeLanguageCountry.isEmpty() &&
                   regionSubdivisionCountry == localeLanguageCountry) {
            if (languageSubdivisionOnlyMatch.isEmpty()) {
                languageSubdivisionOnlyMatch = regionCode;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KHolidays::Holiday &holiday : holidays) {
            qDebug().nospace() << "Date = " << holiday.observedStartDate().toString(Qt::ISODate) << " Duration = " << holiday.duration()
                               << " Name = " << holiday.name().leftJustified(20, /*QChar fill=*/QLatin1Char(' '), /*bool truncate=*/false)
                               << " Category = " << holiday.categoryList();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &dir : dirs) {
        QDirIterator it(dir, QStringList() << QStringLiteral("holiday_") + location + '*');
        while (it.hasNext()) {
            files.push_back(it.next());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &dir : qAsConst(dirs)) {
        QDirIterator it(dir, QStringList() << QStringLiteral("holiday_") + location + '*');
        while (it.hasNext()) {
            files.push_back(it.next());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &calendarType : std::as_const(m_fileCalendarTypes)) {
        // Cater for events defined in other Calendar Systems where request year could cover 2 or 3 event years
        // Perhaps also parse year before and year after to allow events to span years or shift to other year?
        setParseCalendar(calendarType);
        setParseStartEnd();

        // Generate all events for this calendar in the required year(s)
        for (m_parseYear = m_parseStartYear; m_parseYear <= m_parseEndYear; ++m_parseYear) {
            m_parseYearStart = m_parseCalendar.firstDayOfYear(m_parseYear);
            m_parseYearEaster = easter(m_parseYear);
            m_parseYearPascha = pascha(m_parseYear);

            std::istringstream iss2(std::string(m_scanData.data()));
            m_scanner->yyrestart(&iss2);

            m_parser->parse();
        }
    }
```

