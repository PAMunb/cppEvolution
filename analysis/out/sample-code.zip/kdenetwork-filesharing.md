#### AUTO 


```{c}
const auto username = args.value(QStringLiteral("username")).toString();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &it : qAsConst(pathParts)) {
            currentPath.append(QStringLiteral("/") + it);
            fileInfo = QFileInfo(currentPath);
            if (!fileInfo.permission(permsForSharePath)) {
                addPath(fileInfo, permsForSharePath);
            }
            // check and store share path element's POSIX ACL
            if (getCompleteFileItem(currentPath).hasExtendedACL()) {
                m_filesWithPosixACL.append(currentPath);
            }
        }
```

#### AUTO 


```{c}
auto layout = new QVBoxLayout(m_page.get());
```

#### AUTO 


```{c}
auto layout = new QVBoxLayout(page);
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        connect(m_userManager, &UserManager::loaded, this, [this] {
            m_permissionsHelper->reload();
            setReady(true);
        });
        m_userManager->load();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
            setReady(true);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[item, this] {
            properties->setCurrentPage(item);
        }
```

#### AUTO 


```{c}
const auto everyoneUserName = QStringLiteral("Everyone");
```

#### AUTO 


```{c}
auto action = KAuth::Action(QStringLiteral("org.kde.filesharing.samba.isuserknown"));
```

#### AUTO 


```{c}
auto installTransaction = PackageKit::Daemon::installPackages(*pkgids);
```

#### LAMBDA EXPRESSION 


```{c}
[=] (bool checked) { setDirty(); }
```

#### AUTO 


```{c}
auto proc = new QProcess;
```

#### AUTO 


```{c}
auto widget = new QQuickWidget(m_page.get());
```

#### LAMBDA EXPRESSION 


```{c}
[=] (bool checked) {
                propertiesUi.tableView->setEnabled(checked && propertiesUi.sambaChk->isChecked());
                setDirty();
            }
```

#### AUTO 


```{c}
const auto &access = it.value();
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
            m_permissionsHelper->reload();
            setReady(true);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &name : nameList) {
            ++m_waitingForResolution;
            auto user = new User(name, this);
            connect(user, &User::resolved, this, [this] {
                if (--m_waitingForResolution <= 0) {
                    Q_EMIT loaded();
                }
            }, Qt::QueuedConnection /* queue to ensure even shortcut resolution goes through the loop */);
            m_users.append(user);
            if (user->name() == currentUserName) {
                m_currentUser = user;
            }
            user->resolve();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &affected : m_affectedPaths) {
        // do not break the loop to collecting all possible failed paths
        if (!QFile::setPermissions(affected.path, affected.newPerm)) {
            failedPaths += affected.path;
        }
    }
```

#### AUTO 


```{c}
auto user = new User(name, this);
```

#### AUTO 


```{c}
auto it = usersACEs.constBegin();
```

#### AUTO 


```{c}
auto proc = new QProcess(this);
```

#### LAMBDA EXPRESSION 


```{c}
[pkgids](PackageKit::Transaction::Info /*info*/, const QString &packageId) {
        pkgids->append(packageId);
    }
```

#### AUTO 


```{c}
const auto group = args.value(QStringLiteral("group")).toString();
```

#### AUTO 


```{c}
auto reply = ActionReply::HelperErrorReply();
```

#### AUTO 


```{c}
auto job = new KIO::CommandLauncherJob(QStringLiteral("kinfocenter"), {QStringLiteral("kcm_samba")});
```

#### AUTO 


```{c}
const auto match = expression.match(line);
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        auto proc = new QProcess;
        proc->setProgram(QStringLiteral("testparm"));
        proc->setArguments({QStringLiteral("--debuglevel=0"),
                            QStringLiteral("--suppress-prompt"),
                            QStringLiteral("--verbose"),
                            QStringLiteral("--parameter-name"),
                            QStringLiteral("usershare path")});
        connect(proc, QOverload<int, QProcess::ExitStatus>::of(&QProcess::finished), this, [this, proc](int exitCode) {
            proc->deleteLater();
            const QString path = QString::fromUtf8(proc->readAllStandardOutput().simplified());

            m_ready = true;
            Q_EMIT isReadyChanged();

            QFileInfo info(path);
            if (exitCode != 0 || path.isEmpty() || !info.exists()) {
                return; // usershares may be disabled or path is invalid :|
            }

            if (info.isWritable()) {
                m_isMember = true;
                Q_EMIT isMemberChanged();
            }

            m_targetGroup = info.group();
            Q_EMIT targetGroupChanged();

            if (m_targetGroup != QLatin1String("root") && m_targetGroup.contains(QLatin1String("samba"))) {
                m_canMakeMember = true;
                Q_EMIT canMakeMemberChanged();
            }
        });
        proc->start();
    }
```

#### AUTO 


```{c}
const auto password = args.value(QStringLiteral("password")).toString();
```

#### LAMBDA EXPRESSION 


```{c}
[this, job] {
        job->deleteLater();
        m_inSamba = job->data().value(QStringLiteral("exists"), false).toBool();
        Q_EMIT inSambaChanged();
        Q_EMIT resolved();
    }
```

#### AUTO 


```{c}
auto item = properties->addPage(m_page.get(), i18nc("@title:tab", "Share"));
```

#### LAMBDA EXPRESSION 


```{c}
[this, proc](int exitCode) {
            proc->deleteLater();
            const QString path = QString::fromUtf8(proc->readAllStandardOutput().simplified());

            m_ready = true;
            Q_EMIT isReadyChanged();

            QFileInfo info(path);
            if (exitCode != 0 || path.isEmpty() || !info.exists()) {
                return; // usershares may be disabled or path is invalid :|
            }

            if (info.isWritable()) {
                m_isMember = true;
                Q_EMIT isMemberChanged();
            }

            m_targetGroup = info.group();
            Q_EMIT targetGroupChanged();

            if (m_targetGroup != QLatin1String("root") && m_targetGroup.contains(QLatin1String("samba"))) {
                m_canMakeMember = true;
                Q_EMIT canMakeMemberChanged();
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[] {
                KToolInvocation::kdeinitExec(QStringLiteral("kcmshell5"), {QStringLiteral("smbstatus")});
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this, proc](int exitCode) {
        proc->deleteLater();
        const QByteArray output = proc->readAllStandardOutput().simplified();

        if (exitCode == 0 && output == QByteArrayLiteral("tdbsam")) {
            m_canManageSamba = true;
        }

        const QString currentUserName = KUser().loginName();
        const QStringList nameList = getUsersList();
        for (const auto &name : nameList) {
            ++m_waitingForResolution;
            auto user = new User(name, this);
            connect(user, &User::resolved, this, [this] {
                if (--m_waitingForResolution <= 0) {
                    Q_EMIT loaded();
                }
            }, Qt::QueuedConnection /* queue to ensure even shortcut resolution goes through the loop */);
            m_users.append(user);
            if (user->name() == currentUserName) {
                m_currentUser = user;
            }
            user->resolve();
        }
    }
```

#### AUTO 


```{c}
auto usersACEs = m_permissionModel->getUsersACEs();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &username : userNames) {
        if (username == QLatin1String("nobody")) {
            continue;
        }
        KUser user(username);
        const uid_t nativeId = user.userId().nativeId();
        if (nativeId >= defminuid && nativeId <= defmaxuid) {
            userList << username;
        }
    }
```

#### AUTO 


```{c}
auto action = KAuth::Action(QStringLiteral("org.kde.filesharing.samba.createuser"));
```

#### AUTO 


```{c}
auto widget = new QQuickWidget(page);
```

#### AUTO 


```{c}
auto job = KIO::stat(url);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &affected : m_affectedPaths) {
            if (!QFile::setPermissions(affected.path, affected.oldPerm)) {
                qWarning() << "SharePermissionsHelper::sharePermsChange: failed to restore permissions for " << affected.path;
            }
        }
```

#### AUTO 


```{c}
auto action = KAuth::Action(QStringLiteral("org.kde.filesharing.samba.addtogroup"));
```

#### AUTO 


```{c}
auto it = m_usersAcl.constBegin();
```

#### LAMBDA EXPRESSION 


```{c}
[this, job] {
        job->deleteLater();
        if (job->error() != KAuth::ExecuteJob::NoError) {
            Q_EMIT makeMemberError(job->errorString());
            return;
        }
        Q_EMIT madeMember();
    }
```

#### AUTO 


```{c}
auto i18nContext = new KLocalizedContext(widget->engine());
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        connect(m_userManager, &UserManager::loaded, this, [this] {
            setReady(true);
        });
        m_userManager->load();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=] { setDirty(); }
```

#### LAMBDA EXPRESSION 


```{c}
[] {
                KToolInvocation::kdeinitExec(QStringLiteral("kcmshell5"), QStringList() << QStringLiteral("smbstatus"));
            }
```

#### AUTO 


```{c}
const auto &it
```

#### AUTO 


```{c}
const auto user = args.value(QStringLiteral("user")).toString();
```

#### LAMBDA EXPRESSION 


```{c}
[this, job] {
        job->deleteLater();
        m_inSamba = job->data().value(QStringLiteral("created"), false).toBool();
        if (!m_inSamba) {
            Q_EMIT addToSambaError(job->data().value(QStringLiteral("stderr"), QString()).toString());
        }
        Q_EMIT inSambaChanged();
    }
```

#### AUTO 


```{c}
auto newPerm = oldPerm | requiredPermissions;
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
                if (--m_waitingForResolution <= 0) {
                    Q_EMIT loaded();
                }
            }
```

#### AUTO 


```{c}
auto oldPerm = fileInfo.permissions();
```

#### LAMBDA EXPRESSION 


```{c}
[this, pkgids](PackageKit::Transaction::Exit exit) {
        if (exit != PackageKit::Transaction::ExitSuccess) {
            setFailed(true);
            return;
        }
        auto installTransaction = PackageKit::Daemon::installPackages(*pkgids);
        connect(installTransaction, &PackageKit::Transaction::finished,
                this, &SambaInstaller::packageFinished);
    }
```

#### AUTO 


```{c}
const auto &name
```

#### AUTO 


```{c}
auto page = new QWidget(qobject_cast<KPropertiesDialog *>(parent));
```

#### AUTO 


```{c}
const auto &affected
```

#### AUTO 


```{c}
const auto &aceUser = it.key();
```

#### AUTO 


```{c}
const auto &affectedPath = parent->affectedPaths().at(row);
```

