#### RANGE FOR STATEMENT 


```{c}
for (Sprite *sprite : destroyedSprites) {
            sprite->resetTransform();
            sprite->setTransform(QTransform::fromScale(1 - value, 1 - value), true);
            sprite->setTransform(QTransform().rotate(value * 180), true);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &dir : dirs) {
        const QStringList fileNames = QDir(dir).entryList(QStringList() << QStringLiteral("*.desktop"));
        for (const QString &file : fileNames) {
            fileList.append(dir + QLatin1Char('/') + file);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Sprite *bot : std::as_const(m_bots)) {
            if (bot->spriteType() == Fastbot) {
                const QPoint offset(sign(m_hero->gridPos().x() - bot->gridPos().x()), sign(m_hero->gridPos().y() - bot->gridPos().y()));
                const QPoint target = bot->gridPos() + offset;
                if (spriteTypeAt(target) != Robot || !m_rules->fastEnemiesArePatient()) {
                    m_coordinator->slideSprite(bot, target);
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Sprite *junkheap : junkheaps) {
        destroyAllCollidingBots(junkheap, !m_heroIsDead);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QGraphicsItem *item : items) {
        Sprite *sprite = qgraphicsitem_cast<Sprite *>(item);
        if (sprite) {
            sprite->setRenderSize(m_cellSize);
            updateSpritePos(sprite, sprite->currentGridPos());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QGraphicsItem *item : itemsAtPos) {
        if (dynamic_cast<KGamePopupItem *>(item) != nullptr) {
            return true;
        }
    }
```

#### AUTO 


```{c}
const auto robotsAtPos = m_spriteMap.values(sprite->gridPos());
```

#### RANGE FOR STATEMENT 


```{c}
for (NumericDisplayItem *display : std::as_const(m_numericDisplays)) {
            display->setFont(font);
            displaySize = displaySize.expandedTo(display->preferredSize());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Sprite *sprite : std::as_const(neighbors)) {
            destroySprite(sprite);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, mapping] { m_coordinator->requestAction(mapping); }
```

#### AUTO 


```{c}
auto& sprites
```

#### RANGE FOR STATEMENT 


```{c}
for (NumericDisplayItem *display : qAsConst(m_numericDisplays)) {
            display->setRenderSize(displaySize);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Sprite *bot : qAsConst(m_bots)) {
        m_spriteMap.insert(bot->gridPos(), bot);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Sprite *bot : qAsConst(m_bots)) {
            const QPoint offset(sign(m_hero->gridPos().x() - bot->gridPos().x()), sign(m_hero->gridPos().y() - bot->gridPos().y()));
            m_coordinator->slideSprite(bot, bot->gridPos() + offset);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& sprites : {newSprites, slidingSprites, teleportingSprites}) {
            for (Sprite *sprite : sprites) {
                sprite->resetTransform();
                sprite->advanceGridPosQueue();
                updateSpritePos(sprite, sprite->currentGridPos());
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : fileNames) {
            const Ruleset *ruleset = Ruleset::load(file);
            if (ruleset) {
                QString name = ruleset->name();
                while (m_rulesetMap.contains(name)) {
                    name += QLatin1Char('_');
                }

                m_rulesetMap.insert(name, ruleset);

                QListWidgetItem *item = new QListWidgetItem(name, m_listWidget);
                if (file == Settings::ruleset()) {
                    m_listWidget->setCurrentItem(item);
                }
            } else {
                delete ruleset;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Sprite *junkheap : std::as_const(m_junkheaps)) {
        m_spriteMap.insert(junkheap->gridPos(), junkheap);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Sprite *junkheap : junkheaps) {
        destroySprite(junkheap);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &fileName : std::as_const(fileList)) {
        const Ruleset *ruleset = Ruleset::load(fileName);
        if (ruleset) {
            m_scoreDialog->addLocalizedConfigGroupName(qMakePair(ruleset->scoreGroupKey(), ruleset->name()));
        }
        delete ruleset;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (NumericDisplayItem *display : std::as_const(m_numericDisplays)) {
        if (display->isVisible()) {
            visibleDisplays << display;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Sprite *sprite : qAsConst(neighbors)) {
            destroySprite(sprite);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Sprite *junkheap : qAsConst(m_junkheaps)) {
        m_spriteMap.insert(junkheap->gridPos(), junkheap);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Sprite *sprite : teleportingSprites) {
            sprite->resetTransform();
            sprite->setTransform(QTransform::fromScale(scaleFactor, scaleFactor), true);
        }
```

#### AUTO 


```{c}
const auto items = ruleset->items();
```

#### RANGE FOR STATEMENT 


```{c}
for (NumericDisplayItem *display : std::as_const(m_numericDisplays)) {
            display->setRenderSize(displaySize);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Sprite *bot : qAsConst(m_bots)) {
            if (bot->spriteType() == Fastbot) {
                const QPoint offset(sign(m_hero->gridPos().x() - bot->gridPos().x()), sign(m_hero->gridPos().y() - bot->gridPos().y()));
                const QPoint target = bot->gridPos() + offset;
                if (spriteTypeAt(target) != Robot || !m_rules->fastEnemiesArePatient()) {
                    m_coordinator->slideSprite(bot, target);
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (NumericDisplayItem *display : qAsConst(m_numericDisplays)) {
        if (display->isVisible()) {
            visibleDisplays << display;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (NumericDisplayItem *display : std::as_const(visibleDisplays)) {
            display->setPos(displayXPos, yPos);
            yPos += displaySize.height() + spacing;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Sprite *bot : std::as_const(m_bots)) {
            const QPoint offset(sign(m_hero->gridPos().x() - bot->gridPos().x()), sign(m_hero->gridPos().y() - bot->gridPos().y()));
            m_coordinator->slideSprite(bot, bot->gridPos() + offset);
        }
```

#### AUTO 


```{c}
const auto items = this->items();
```

#### AUTO 


```{c}
const auto bots = m_bots;
```

#### RANGE FOR STATEMENT 


```{c}
for (Sprite *sprite : sprites) {
                sprite->resetTransform();
                sprite->advanceGridPosQueue();
                updateSpritePos(sprite, sprite->currentGridPos());
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (NumericDisplayItem *display : qAsConst(visibleDisplays)) {
            display->setPos(displayXPos, yPos);
            yPos += displaySize.height() + spacing;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (NumericDisplayItem *display : qAsConst(visibleDisplays)) {
            display->setPos(xPos, displayYPos);
            xPos += displaySize.width() + spacing;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Sprite *bot : std::as_const(m_bots)) {
        m_spriteMap.insert(bot->gridPos(), bot);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : fileNames) {
            fileList.append(dir + QLatin1Char('/') + file);
        }
```

#### AUTO 


```{c}
const auto itemsAtPos = items(position);
```

#### AUTO 


```{c}
const auto junkheaps = m_junkheaps;
```

#### RANGE FOR STATEMENT 


```{c}
for (Sprite *sprite : newSprites) {
            sprite->resetTransform();
            sprite->setTransform(QTransform::fromScale(value, value), true);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Sprite *sprite : slidingSprites) {
            QPointF posInGridCoordinates = value * QPointF(sprite->nextGridPos() - sprite->currentGridPos()) + sprite->currentGridPos();
            sprite->setPos(QPointF(posInGridCoordinates.x() * m_cellSize.width(), posInGridCoordinates.y() * m_cellSize.height()));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (NumericDisplayItem *display : qAsConst(m_numericDisplays)) {
            display->setFont(font);
            displaySize = displaySize.expandedTo(display->preferredSize());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &fileName : qAsConst(fileList)) {
        const Ruleset *ruleset = Ruleset::load(fileName);
        if (ruleset) {
            m_scoreDialog->addLocalizedConfigGroupName(qMakePair(ruleset->scoreGroupKey(), ruleset->name()));
        }
        delete ruleset;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KConfigSkeletonItem *item : items) {
            if (!maskedItems.contains(item->name())) {
                QString labelText = item->label().isEmpty() ? item->name() : item->label();
                labelText = i18nc("%1 is a pretranslated string that we're turning into a label", "%1:", labelText);

                QLabel *valueLabel = new QLabel();
                m_labels[ item->name() ] = valueLabel;
                layout->addRow(new QLabel(labelText), valueLabel);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Sprite *robot : robotsAtPos) {
        if (robot != sprite && (robot->spriteType() == Robot || robot->spriteType() == Fastbot)) {
            destroySprite(robot, calculatePoints);
            result = true;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Sprite *bot : bots) {
        destroySprite(bot, false);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QPoint &cell : cellsBehindNeighbor) {
                    if (spriteTypeAt(cell) == Fastbot) {
                        ++fastbotsFound;
                    } else if (spriteTypeAt(cell) == Robot) {
                        ++robotsFound;
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &dir : dirs) {
        const QStringList fileNames = QDir(dir).entryList(QStringList() << QStringLiteral("*.desktop"));
        for (const QString &file : fileNames) {
            const Ruleset *ruleset = Ruleset::load(file);
            if (ruleset) {
                QString name = ruleset->name();
                while (m_rulesetMap.contains(name)) {
                    name += QLatin1Char('_');
                }

                m_rulesetMap.insert(name, ruleset);

                QListWidgetItem *item = new QListWidgetItem(name, m_listWidget);
                if (file == Settings::ruleset()) {
                    m_listWidget->setCurrentItem(item);
                }
            } else {
                delete ruleset;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Sprite *sprite : teleportingSprites) {
                updateSpritePos(sprite, sprite->nextGridPos());
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (NumericDisplayItem *display : std::as_const(visibleDisplays)) {
            display->setPos(xPos, displayYPos);
            xPos += displaySize.width() + spacing;
        }
```

