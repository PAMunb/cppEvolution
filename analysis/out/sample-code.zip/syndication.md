#### AUTO 


```{c}
auto l = dir.entryList(QStringList(QStringLiteral("*.xml")), QDir::Files | QDir::Readable | QDir::NoSymLinks);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &cat : dcategories) {
        info += cat->debugInfo();
    }
```

#### AUTO 


```{c}
const auto unhandledElements = m_doc->unhandledElements();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &item : litems) {
        info += item.debugInfo();
    }
```

#### AUTO 


```{c}
auto it = encs.cbegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &cat : dcats) {
        info += cat.debugInfo();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &e : denclosures) {
        info += e->debugInfo();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const Syndication::RSS2::Item &entry) {
        return ItemRSS2ImplPtr(new ItemRSS2Impl(entry));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item &i : items) {
        SortItem item;
        item.item = i;
        item.index = uriSequence.indexOf(i.resource()->uri());
        toSort.append(item);
    }
```

#### AUTO 


```{c}
const auto &catPtr
```

#### LAMBDA EXPRESSION 


```{c}
[](const QDomElement &element) {
        return Enclosure(element);
    }
```

#### AUTO 


```{c}
const auto &author
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &author : dauthors) {
        info += author->debugInfo();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &person : people) {
        PersonPtr ptr = personFromString(person);
        if (!ptr->isNull()) {
            list.append(ptr);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &link : links) {
        if (link.rel() == QLatin1String("enclosure")) {
            list.append(EnclosureAtomImplPtr(new EnclosureAtomImpl(link)));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &author : dauthors) {
        info += author.debugInfo();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const Syndication::Atom::Person &person) {
        return PersonImplPtr(new PersonImpl(person.name(), person.uri(), person.email()));
    }
```

#### AUTO 


```{c}
const auto &cat
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &filename : std::as_const(filenames)) {
        QFile f(filename);

        if (!f.open(QIODevice::ReadOnly)) {
            continue;
        }

        DocumentSource src(f.readAll(), "http://libsyndicationtest");
        f.close();

        FeedPtr ptr(Syndication::parse(src));
        if (ptr) {
            totalLength += src.size();
            ++numberOfFiles;
            QString dbg = ptr->debugInfo();
        }

        // std::cerr << "size of debug output: " << dbg.length() << std::endl;
    }
```

#### AUTO 


```{c}
auto it = std::find_if(stmts.cbegin(), stmts.cend(), [&property](const StatementPtr &p) {
        return *(p->predicate()) == *property;
    });
```

#### RANGE FOR STATEMENT 


```{c}
for (const StatementPtr &stmtPtr : std::as_const(d->statements)) {
        info += QStringLiteral("<%1> <%2> ").arg(stmtPtr->subject()->uri(), stmtPtr->predicate()->uri());

        if (stmtPtr->object()->isLiteral()) {
            info += QStringLiteral("\"%1\"\n").arg(stmtPtr->asString());
        } else {
            info += QStringLiteral("<%1>\n").arg(stmtPtr->asResource()->uri());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const ResourcePtr &i : qAsConst(sorted)) {
        seq->append(i);
        // add rdf:about (type)
        model.addStatement(i, RDFVocab::self()->type(), RSSVocab::self()->item());

        // add to items sequence
        model.addStatement(seq, RDFVocab::self()->li(), i);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const Syndication::RSS2::Category &entry) {
        return CategoryRSS2ImplPtr(new CategoryRSS2Impl(entry));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const ResourcePtr &i : std::as_const(items)) {
        list.append(Item(i, doccpy));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const Syndication::RSS2::Category &c) {
        return CategoryRSS2ImplPtr(new CategoryRSS2Impl(c));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &p : stmts) {
        if (*(p->predicate()) == *property) {
            res.append(p);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&host](const QString &s) {
                return QUrl(s).host() == host;
            }
```

#### AUTO 


```{c}
const auto &stmt
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : l) {
        QTest::newRow(file.toLatin1().constData()) << QString(dirRss2.path() + QLatin1Char('/') +  file) << QString(dirRss2.path() + QLatin1Char('/') + file + QLatin1String(".expected"));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QDomElement &element) {
            return Person(element);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](const Syndication::Atom::Entry &entry) {
        return ItemAtomImplPtr(new ItemAtomImpl(entry));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Syndication::RSS2::Enclosure &e) {
        return EnclosureRSS2ImplPtr(new EnclosureRSS2Impl(m_item, e));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &item : itlist) {
        info += item.debugInfo();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SortItem &sortItem : std::as_const(toSort)) {
        items[i] = sortItem.item;
        i++;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QDomElement &element) {
        return Category(element);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : l) {
        QTest::newRow(file.toLatin1().constData()) << QString(dir.path() + QLatin1Char('/') +  file) << QString(dir.path() + QLatin1Char('/') + file + QLatin1String(".expected"));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &item : litems) {
            if (i++ >= nmax) {
                break;
            }
            titles += item.originalTitle();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const StatementPtr &stmtPtr : std::as_const(d->statements)) {
        if (*(stmtPtr->predicate()) == *(RDFVocab::self()->type()) //
            && *(stmtPtr->object()) == *type) {
            list.append(stmtPtr->subject());
        }
    }
```

#### AUTO 


```{c}
auto it = std::find_if(links.cbegin(), links.cend(), [](const Syndication::Atom::Link &link) {
        return link.rel() == QLatin1String("alternate");
    });
```

#### AUTO 


```{c}
const auto unhandledElements = m_item.unhandledElements();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &e : encs) {
        info += e.debugInfo();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            if (mReply->error() == QNetworkReply::NoError) {
                Q_EMIT dataRetrieved(mReply->readAll(), true);
            } else {
                Q_EMIT dataRetrieved({}, false);
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](const Syndication::Atom::Category &entry) {
        return CategoryAtomImplPtr(new CategoryAtomImpl(entry));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractParser *i : std::as_const(m_parserList)) {
        if (i->accept(source)) {
            SpecificDocumentPtr doc = i->parse(source);
            if (!doc->isValid()) {
                m_lastError = InvalidFormat;
                return FeedPtr();
            }

            return m_mappers[i->format()]->map(doc);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &filename : qAsConst(filenames)) {
        QFile f(filename);

        if (!f.open(QIODevice::ReadOnly)) {
            continue;
        }

        DocumentSource src(f.readAll(), "http://libsyndicationtest");
        f.close();

        FeedPtr ptr(Syndication::parse(src));
        if (ptr) {
            totalLength += src.size();
            ++numberOfFiles;
            QString dbg = ptr->debugInfo();
        }

        // std::cerr << "size of debug output: " << dbg.length() << std::endl;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : l) {
        QTest::newRow(file.toLatin1().constData()) << QString(dirRdf.path() + QLatin1Char('/') + file)
                                                   << QString(dirRdf.path() + QLatin1Char('/') + file + QLatin1String(".expected"));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const NodePtr &i : seqItems) {
                if (i->isResource()) {
                    uriSequence.append(i.staticCast<Resource>()->uri());
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &item : litems) {
            if (i++ >= nmax) {
                break;
            }
            desc += item.originalDescription();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : l) {
        QTest::newRow(file.toLatin1().constData()) << QString(dirRdf.path() + QLatin1Char('/') +  file) << QString(dirRdf.path() + QLatin1Char('/') + file + QLatin1String(".expected"));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &link : dlinks) {
        info += link.debugInfo();
    }
```

#### AUTO 


```{c}
auto it = std::find_if(weekDays.cbegin(), weekDays.cend(), [&day](const DayInfo &info) {
                return info.name == day;
            });
```

#### RANGE FOR STATEMENT 


```{c}
for (const ResourcePtr &i : qAsConst(sorted)) {
        seq->append(i);
        // add rdf:about (type)
        model.addStatement(i, RDFVocab::self()->type(), RSSVocab::self()->item());

        //add to items sequence
        model.addStatement(seq, RDFVocab::self()->li(), i);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const NodePtr &i : seqItems)
                if (i->isResource()) {
                    uriSequence.append(i.staticCast<Resource>()->uri());
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const StatementPtr &stmtPtr : qAsConst(d->statements)) {
        if (*(stmtPtr->predicate()) == *(RDFVocab::self()->type()) && *(stmtPtr->object()) == *type) {
            list.append(stmtPtr->subject());
        }
    }
```

#### AUTO 


```{c}
auto it = std::find_if(feeds.cbegin(), feeds.cend(), [&host](const QString &s) {
                return QUrl(s).host() == host;
            });
```

#### LAMBDA EXPRESSION 


```{c}
[](const QDomElement &element) {
        return Link(element);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const ResourcePtr &i : items) {
        QString numstr = i->property(itemIndex)->asString();
        bool ok = false;
        uint num = numstr.toUInt(&ok);
        if (ok) {
            sorted[num] = i;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : l) {
        QTest::newRow(file.toLatin1().constData()) << QString(dir.path() + QLatin1Char('/') + file)
                                                   << QString(dir.path() + QLatin1Char('/') + file + QLatin1String(".expected"));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &element : hours) {
            const int h = element.text().toInt(&ok);
            if (ok) {
                skipHours.insert(h);
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&doccpy](const QDomElement &element) {
        return Item(element, doccpy);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractParser *i : qAsConst(m_parserList)) {
        if (i->accept(source)) {
            SpecificDocumentPtr doc = i->parse(source);
            if (!doc->isValid()) {
                m_lastError = InvalidFormat;
                return FeedPtr();
            }

            return m_mappers[i->format()]->map(doc);
        }
    }
```

#### AUTO 


```{c}
const auto &person
```

#### RANGE FOR STATEMENT 


```{c}
for (const ResourcePtr &i : qAsConst(items)) {
        list.append(Item(i, doccpy));
    }
```

#### AUTO 


```{c}
auto it = cats.cbegin(), end = cats.cend();
```

#### LAMBDA EXPRESSION 


```{c}
[&feedAuthors](const QDomElement &element) {
        Entry entry(element);
        entry.setFeedAuthors(feedAuthors);
        return entry;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&property](const StatementPtr &p) {
        return *(p->predicate()) == *property;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &entry : dentries) {
        info += entry.debugInfo();
    }
```

#### AUTO 


```{c}
const auto &entry
```

#### LAMBDA EXPRESSION 


```{c}
[](const Syndication::RDF::Item &entry) {
        return ItemRDFImplPtr(new ItemRDFImpl(entry));
    }
```

#### AUTO 


```{c}
const auto unhandledElements = m_entry.unhandledElements();
```

#### AUTO 


```{c}
const auto &c
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                    if (mReply->error() == QNetworkReply::NoError) {
                        Q_EMIT dataRetrieved(mReply->readAll(), true);
                    } else {
                        Q_EMIT dataRetrieved({}, false);
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &stmt : statements) {
        const QString predUri = stmt->predicate()->uri();
        if (uris09.contains(predUri)) {
            model.addStatement(stmt->subject(), hash[predUri], stmt->object());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const ResourcePtr &i : std::as_const(sorted)) {
        seq->append(i);
        // add rdf:about (type)
        model.addStatement(i, RDFVocab::self()->type(), RSSVocab::self()->item());

        // add to items sequence
        model.addStatement(seq, RDFVocab::self()->li(), i);
    }
```

#### AUTO 


```{c}
const auto &element
```

#### RANGE FOR STATEMENT 


```{c}
for (const SortItem &sortItem : qAsConst(toSort)) {
        items[i] = sortItem.item;
        i++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : l) {
        QTest::newRow(file.toLatin1().constData()) << QString(dirRss2.path() + QLatin1Char('/') + file)
                                                   << QString(dirRss2.path() + QLatin1Char('/') + file + QLatin1String(".expected"));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QDomElement &i : unhandledElements) {
        ret.insert(i.namespaceURI() + i.localName(), i);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const StatementPtr &stmtPtr : qAsConst(d->statements)) {
        info += QStringLiteral("<%1> <%2> ").arg(stmtPtr->subject()->uri(), stmtPtr->predicate()->uri());

        if (stmtPtr->object()->isLiteral()) {
            info += QStringLiteral("\"%1\"\n").arg(stmtPtr->asString());
        } else {
            info += QStringLiteral("<%1>\n").arg(stmtPtr->asResource()->uri());
        }
    }
```

#### AUTO 


```{c}
const auto &item
```

#### AUTO 


```{c}
const auto &e
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &catPtr : dcategories) {
        info += catPtr->debugInfo();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &element : days) {
            const QString day = element.text();
            auto it = std::find_if(weekDays.cbegin(), weekDays.cend(), [&day](const DayInfo &info) {
                return info.name == day;
            });
            if (it != weekDays.cend()) {
                skipDays.insert(it->enumValue);
            }
        }
```

#### AUTO 


```{c}
const auto &link
```

#### LAMBDA EXPRESSION 


```{c}
[](const Syndication::Atom::Link &link) {
        return link.rel() == QLatin1String("alternate");
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &c : cats) {
        info += c.debugInfo();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&day](const DayInfo &info) {
                return info.name == day;
            }
```

#### LAMBDA EXPRESSION 


```{c}
[](const Syndication::Atom::Category &c) {
        return CategoryAtomImplPtr(new CategoryAtomImpl(c));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QDomElement &element) {
        return Person(element);
    }
```

#### AUTO 


```{c}
const auto &p
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &person : dcontri) {
        info += person.debugInfo();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &item : ditems) {
        info += item->debugInfo();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const StatementPtr &stmtPtr : qAsConst(d->statements)) {
        if (*(stmtPtr->predicate()) == *(RDFVocab::self()->type()) //
            && *(stmtPtr->object()) == *type) {
            list.append(stmtPtr->subject());
        }
    }
```

