#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &groupKey : std::as_const(groupKeyList)) {
        highscoreObject->setHighscoreGroup(QLatin1String(groupKey));
        player = highscoreObject->readEntry(0, QStringLiteral("LastPlayer")); // FIXME

        for (int i = 1; i <= 10; ++i) {
            KScoreDialog::FieldInfo score;
            for (int field = 1; field < fields; field = field * 2) {
                if (fields & field) {
                    score[field] = highscoreObject->readEntry(i, key[field], QStringLiteral("-"));
                }
            }
            scores[groupKey].append(score);
        }
    }
```

#### AUTO 


```{c}
const auto groupStrings = highscoreObject->groupList();
```

#### AUTO 


```{c}
const auto levels = difficulty->levels();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &x : sections) {
        sec = sec * 60 + x.toUInt();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &dir : dirs) {
		const QStringList fileNames = QDir(dir).entryList(QStringList() << QStringLiteral("*.desktop"));
		for (const QString &file : fileNames) {
			if (!themePaths.contains(file)) {
				themePaths.append(dir + '/' + file);
			}
		}
	}
```

#### AUTO 


```{c}
const auto themes = m_provider->themes();
```

#### RANGE FOR STATEMENT 


```{c}
for (KGameCanvasItem *el : std::as_const(m_items)) {
        if (el->m_changed) {
            el->updateChanges();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& dir : dirs) {
	    QDirIterator it(dir, QStringList() << QStringLiteral("*.desktop"), QDir::NoFilter, QDirIterator::Subdirectories);
	    while (it.hasNext()) {
                    QFileInfo fileInfo(it.next());
		    const QString filePath = QDir(dir).relativeFilePath(fileInfo.filePath());
		    themesAvailable.append(filePath);
	    }
    }
```

#### AUTO 


```{c}
const auto levels = diff->levels();
```

#### RANGE FOR STATEMENT 


```{c}
for (KGameRendererClient *requester : requesters) {
        requester->receivePixmap(pixmap);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->_k_updateProviderSelection(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const KgTheme* theme) { d->_k_updateListSelection(theme); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &groupKey : qAsConst(groupKeyList))
    {
        highscoreObject->setHighscoreGroup(QLatin1String( groupKey ));
        player = highscoreObject->readEntry(0, QStringLiteral( "LastPlayer" ));  //FIXME

        for (int i = 1; i <= 10; ++i)
        {
            KScoreDialog::FieldInfo score;
            for(int field = 1; field < fields; field = field * 2)
            {
                if (fields & field)
                {
                    score[field] = highscoreObject->readEntry(i, key[field], QStringLiteral("-"));
                }
            }
            scores[groupKey].append(score);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KgDifficultyLevel *level : levels) {
        selector->addItem(icon, level->title());
        menu->addAction(level->title());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KGameDifficulty::standardLevel level : std::as_const(m_standardLevels)) {
        if (level != KGameDifficulty::Configurable) {
            m_menu->addAction(standardLevelString(level).second);
            m_comboBox->addItem(QIcon::fromTheme(QStringLiteral("games-difficult")), standardLevelString(level).second);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &x : sections)
    {
        sec = sec * 60 + x.toUInt();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KgTheme *theme : std::as_const(themes)) {
        addTheme(theme);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KgTheme *theme : themes) {
        QListWidgetItem *item = new QListWidgetItem(theme->name(), m_list);
        item->setData(Qt::DecorationRole, m_provider->generatePreview(theme, Metrics::ThumbnailBaseSize));
        item->setData(KgThemeDelegate::DescriptionRole, theme->description());
        item->setData(KgThemeDelegate::AuthorRole, theme->author());
        item->setData(KgThemeDelegate::AuthorEmailRole, theme->authorEmail());
        item->setData(KgThemeDelegate::IdRole, theme->identifier());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KgDifficultyLevel* level : levels) {
        localizedLevelStrings.insert(level->key(), level->title());
        levelWeights.insert(level->hardness(), level->key());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KgDifficultyLevel *level : levels) {
        localizedLevelStrings.insert(level->key(), level->title());
        levelWeights.insert(level->hardness(), level->key());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const KgTheme *theme) { d->_k_setTheme(theme); }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->updateThemeName();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KgDifficultyLevel *level : std::as_const(d->m_levels)) {
        if (level->key() == key) {
            return d->m_currentLevel = level;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const KgTheme *theme) {
        d->_k_updateListSelection(theme);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& groupName : qAsConst(KgThemePrivate::s_configGroupNames)) {
		if (config.hasGroup(groupName))
		{
			group = config.group(groupName);
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const KgTheme *theme : std::as_const(d->m_themes)) {
            if (theme->identifier() == id) {
                return d->m_currentTheme = theme;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& base : dirs) {
		if (canonical.startsWith(base))
			return canonical.mid(base.length()+1);
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (QString group : groupList) {
        if(group.contains( QLatin1String( "KHighscore")) ) //If it's one of _our_ groups (KHighscore or KHighscore_xxx)
        {
            if(group == QLatin1String( "KHighscore" ))
                group.remove( QStringLiteral( "KHighscore" )); //Set to blank
            else
                group.remove( QStringLiteral( "KHighscore_" )); //Remove the KHighscore_ prefix
            highscoreGroupList << group;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &dir : dirs) {
		const QStringList fileNames = QDir(dir).entryList(QStringList() << QStringLiteral("*.desktop"));
		for (const QString &file : fileNames) {
			if (!themePaths.contains(file)) {
				themePaths.append(dir + QLatin1Char('/') + file);
			}
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const KgDifficultyLevel* level : levels) {
		selector->addItem(icon, level->title());
		menu->addAction(level->title());
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &groupName : std::as_const(keysToConfigure)) {
        setupGroup(groupName);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& groupName : qAsConst(Private::s_configGroupNames)) {
		if (config.hasGroup(groupName))
		{
			group = config.group(groupName);
		}
	}
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->updateThemeName(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (QString group : groupList) {
        if (group.contains(QLatin1String("KHighscore"))) // If it's one of _our_ groups (KHighscore or KHighscore_xxx)
        {
            if (group == QLatin1String("KHighscore"))
                group.remove(QStringLiteral("KHighscore")); // Set to blank
            else
                group.remove(QStringLiteral("KHighscore_")); // Remove the KHighscore_ prefix
            highscoreGroupList << group;
        }
    }
```

#### AUTO 


```{c}
const auto views = scene()->views();
```

#### RANGE FOR STATEMENT 


```{c}
for (const KgTheme* theme : themes) {
		if (theme->identifier() == selId)
		{
			m_provider->setCurrentTheme(theme);
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (KGameCanvasItem *el : std::as_const(m_items)) {
            m_child_rect |= el->rect();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KgDifficultyLevel *level : std::as_const(d->m_levels)) {
        if (level->isDefault()) {
            return d->m_currentLevel = level;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KgTheme* theme : themes) {
		QListWidgetItem* item = new QListWidgetItem(theme->name(), m_list);
		item->setData(Qt::DecorationRole,
			m_provider->generatePreview(theme, Metrics::ThumbnailBaseSize));
		item->setData(KgThemeDelegate::DescriptionRole, theme->description());
		item->setData(KgThemeDelegate::AuthorRole, theme->author());
		item->setData(KgThemeDelegate::AuthorEmailRole, theme->authorEmail());
		item->setData(KgThemeDelegate::IdRole, theme->identifier());
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &groupString : groupStrings) {
        groupKeyList << groupString.toUtf8(); // Convert all the QStrings to QByteArrays
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KGameRendererClient* requester : requesters) {
		requester->receivePixmap(pixmap);
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (KGameCanvasItem* el : qAsConst(m_items)) {
            m_child_rect |= el->rect();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : fileNames) {
            if (!themePaths.contains(file)) {
                themePaths.append(dir + QLatin1Char('/') + file);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &groupKey : groupKeys) {
        if( (scores[groupKey][0].value(Score)==QLatin1String( "-" )) && (scores.size() > 1) && (latest.first != groupKey) )
        {
            qCDebug(GAMES_HIGHSCORE) << "Removing group " << groupKey << " since it's unused.";
            scores.remove(groupKey);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KGameCanvasItem *el : std::as_const(m_items)) {
        if (el->m_visible) {
            el->m_last_rect = el->rect();
            el->paintInternal(painter, childRect(), childRect(), QPoint(), 1.0);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &groupKey : groupKeys) {
        if( (scores[groupKey][0].value(KScoreDialog::Score)==QLatin1String( "-" )) && (scores.size() > 1) && (latest.first != groupKey) )
        {
            qCDebug(GAMES_HIGHSCORE) << "Removing group " << groupKey << " since it's unused.";
            scores.remove(groupKey);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QList<KNSCore::Entry> &changedEntries) {
            if (!changedEntries.isEmpty()) {
                d->m_provider->rediscoverThemes();
                d->fillList();
            }
            // restore previous selection
            d->_k_updateListSelection(d->m_provider->currentTheme());
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->_k_showNewStuffDialog(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &base : dirs) {
        if (canonical.startsWith(base))
            return canonical.mid(base.length() + 1);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->_k_updateProviderSelection();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &s : qAsConst(m_customLevels)) {
			m_menu->addAction(s);
			m_comboBox->addItem(QIcon::fromTheme( QStringLiteral( "games-difficult" )), s);
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : qAsConst(themesAvailable))
    {
      const QString themePath = lookupDirectory + QLatin1Char( '/' ) + file;
      KGameTheme* atheme = new KGameTheme(groupName);

      if (atheme->load(themePath)) {
        QString themeName = atheme->themeProperty(QStringLiteral( "Name" ));
        //Add underscores to avoid duplicate names.
        while (themeMap.contains(themeName))
          themeName += QLatin1Char( '_' );
        themeMap.insert(themeName, atheme);
        QListWidgetItem * item = new QListWidgetItem(themeName, ui.themeList);

        //Find if this is our currently configured theme
        if (themePath==initialSelection) {
          initialFound = true;
          ui.themeList->setCurrentItem(item);
          _k_updatePreview();
        }
      } else {
        delete atheme;
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &groupName : std::as_const(KgThemePrivate::s_configGroupNames)) {
        if (config.hasGroup(groupName)) {
            group = config.group(groupName);
        }
    }
```

#### AUTO 


```{c}
const auto groupKeys = scores.keys();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &themePath : std::as_const(themePaths)) {
        const QFileInfo fi(themePath);
        if (d->m_discoveredThemes.contains(fi.fileName())) {
            continue;
        }
        d->m_discoveredThemes << fi.fileName();
        // the identifier is constructed such that it is compatible with
        // KGameTheme (e.g. "themes/default.desktop")

        const QByteArray id = relativeToApplications(themePath).toUtf8();
        // create theme
        KgTheme *theme;
        if (d->m_dtThemeClass) {
            theme = qobject_cast<KgTheme *>(d->m_dtThemeClass->newInstance(Q_ARG(QByteArray, id), Q_ARG(QObject *, this)));
            Q_ASSERT_X(theme, "KgThemeProvider::discoverThemes", "Could not create theme instance. Is your constructor Q_INVOKABLE?");
        } else {
            theme = new KgTheme(id, this);
        }
        // silently discard invalid theme files
        if (!theme->readFromDesktopFile(themePath)) {
            delete theme;
            continue;
        }
        // order default theme at the front (that's not necessarily needed by
        // KgThemeProvider, but nice for the theme selector)
        if (fi.fileName() == defaultFileName) {
            themes.prepend(theme);
            defaultTheme = theme;
        } else {
            themes.append(theme);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QByteArray &groupName : qAsConst(configGroupWeights))
    {
        int index = keysToConfigure.indexOf(groupName);
        if (index != -1)
        {
            setupGroup(groupName);
            keysToConfigure.removeAt(index);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &groupKey : qAsConst(groupKeyList))
    {
        highscoreObject->setHighscoreGroup(QLatin1String( groupKey ));
        player = highscoreObject->readEntry(0, QStringLiteral( "LastPlayer" ));  //FIXME

        for (int i = 1; i <= 10; ++i)
        {
            FieldInfo score;
            for(int field = 1; field < fields; field = field * 2)
            {
                if (fields & field)
                {
                    score[field] = highscoreObject->readEntry(i, key[field], QStringLiteral("-"));
                }
            }
            scores[groupKey].append(score);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KgTheme* theme : qAsConst(d->m_themes)) {
			if (theme->identifier() == id)
			{
				return d->m_currentTheme = theme;
			}
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (const KgTheme *theme : themes) {
        if (theme->identifier() == selId) {
            m_provider->setCurrentTheme(theme);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &s : std::as_const(m_customLevels)) {
            m_menu->addAction(s);
            m_comboBox->addItem(QIcon::fromTheme(QStringLiteral("games-difficult")), s);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (KGameDifficulty::standardLevel level : qAsConst(m_standardLevels)) {
		if (level!=KGameDifficulty::Configurable) {
			m_menu->addAction(standardLevelString(level).second);
			m_comboBox->addItem(QIcon::fromTheme( QStringLiteral( "games-difficult" )), standardLevelString(level).second);
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &groupName : qAsConst(keysToConfigure)) {
        setupGroup(groupName);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const KgTheme *theme) {
        d->_k_setTheme(theme);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : fileNames) {
			if (!themePaths.contains(file)) {
				themePaths.append(dir + QLatin1Char('/') + file);
			}
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (const KgDifficultyLevel* level : qAsConst(d->m_levels)) {
		if (level->key() == key)
		{
			return d->m_currentLevel = level;
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (KGameTheme* theme : qAsConst(themeMap)) {
        if (theme->path().endsWith(defaultPath))
        {
          const QList<QListWidgetItem *> itemList = ui.themeList->findItems(theme->themeProperty(QStringLiteral( "Name" )), Qt::MatchExactly);
          // never can be != 1 but better safe than sorry
          if (itemList.count() == 1)
          {
            ui.themeList->setCurrentItem(itemList.first());
            _k_updatePreview();
          }
        }
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (KgTheme* theme : qAsConst(themes))
	{
		addTheme(theme);
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (KGameCanvasItem* el : qAsConst(m_items)) {
        if (el->m_changed) {
            el->updateChanges();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QList<KNSCore::Entry> &changedEntries) {
                          if (!changedEntries.isEmpty()) {
                            d->m_provider->rediscoverThemes();
                            d->fillList();
                          }
                          // restore previous selection
                          d->_k_updateListSelection(
                              d->m_provider->currentTheme());
                        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString & groupString : groupStrings) {
        groupKeyList << groupString.toUtf8(); //Convert all the QStrings to QByteArrays
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KgDifficultyLevel* level : qAsConst(d->m_levels)) {
		if (level->isDefault())
		{
			return d->m_currentLevel = level;
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (QGraphicsView *view : views) {
        if (view->isVisible()) {
            sceneView = view;
            break;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[gameSequence]() {
                gameSequence->nextPlayer(gameSequence->currentPlayer());
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &groupName : std::as_const(configGroupWeights)) {
        int index = keysToConfigure.indexOf(groupName);
        if (index != -1) {
            setupGroup(groupName);
            keysToConfigure.removeAt(index);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &dir : dirs) {
        const QStringList fileNames = QDir(dir).entryList(QStringList() << QStringLiteral("*.desktop"));
        for (const QString &file : fileNames) {
            if (!themePaths.contains(file)) {
                themePaths.append(dir + QLatin1Char('/') + file);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : fileNames) {
			if (!themePaths.contains(file)) {
				themePaths.append(dir + '/' + file);
			}
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (KGameCanvasItem* el : qAsConst(m_items)) {
        if (el->m_visible) {
            el->m_last_rect = el->rect();
            el->paintInternal(painter, childRect(), childRect(), QPoint(), 1.0);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& themePath : qAsConst(themePaths)) {
		const QFileInfo fi(themePath);
		if (d->m_discoveredThemes.contains(fi.fileName()))
		{
			continue;
		}
		d->m_discoveredThemes << fi.fileName();
		//the identifier is constructed such that it is compatible with
		//KGameTheme (e.g. "themes/default.desktop")

		const QByteArray id = relativeToApplications(themePath).toUtf8();
		//create theme
		KgTheme* theme;
		if (d->m_dtThemeClass)
		{
			theme = qobject_cast<KgTheme*>(d->m_dtThemeClass->newInstance(
				Q_ARG(QByteArray, id), Q_ARG(QObject*, this)
			));
			Q_ASSERT_X(theme,
				"KgThemeProvider::discoverThemes",
				"Could not create theme instance. Is your constructor Q_INVOKABLE?"
			);
		}
		else
		{
			theme = new KgTheme(id, this);
		}
		//silently discard invalid theme files
		if (!theme->readFromDesktopFile(themePath))
		{
			delete theme;
			continue;
		}
		//order default theme at the front (that's not necessarily needed by
		//KgThemeProvider, but nice for the theme selector)
		if (fi.fileName() == defaultFileName)
		{
			themes.prepend(theme);
			defaultTheme = theme;
		}
		else
		{
			themes.append(theme);
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &groupKey : groupKeys) {
        if ((scores[groupKey][0].value(KScoreDialog::Score) == QLatin1String("-")) && (scores.size() > 1) && (latest.first != groupKey)) {
            qCDebug(GAMES_HIGHSCORE) << "Removing group " << groupKey << " since it's unused.";
            scores.remove(groupKey);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[gameSequence]() {
         gameSequence->nextPlayer(gameSequence->currentPlayer());
    }
```

