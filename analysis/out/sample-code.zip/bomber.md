#### RANGE FOR STATEMENT 


```{c}
for (Bomb * bomb : qAsConst(m_explodingBombs)) {
        bomb->advanceItem();
    }
```

#### AUTO 


```{c}
auto tile = new KGameRenderedItem(m_renderer, pixmap);
```

#### RANGE FOR STATEMENT 


```{c}
for (Bomb * bomb : std::as_const(m_explodingBombs)) {
        bomb->update();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Building * building : currentBuildings) {
        if (m_plane->nextBoundingRect().intersects(building->boundingRect()) && m_plane->state() == Explodable::State::Moving) {
            // Plane crashed into the building
            building->destoryTop();
            --m_buildingBlocks;
            crashed();
        }

        if (m_bomb != nullptr) {
            if (m_bomb->nextBoundingRect().intersects(building->boundingRect()) && m_bomb->state() == Explodable::State::Moving) {
                // Bomb hit a building
                building->destoryTop();
                --m_buildingBlocks;
                Q_EMIT onBombHit();
                bombHit(m_bomb, building->position().x(), Building::BUILD_BASE_LOCATION - (building->height()));
                m_bomb = nullptr;
            } else if (m_bomb->position().y() >= Building::BUILD_BASE_LOCATION + 1) {
                // Bomb hit the ground
                bombHit(m_bomb, (unsigned int)m_bomb->position().x(), Building::BUILD_BASE_LOCATION);
                m_bomb = nullptr;
            }
        }

        if (m_plane->state() == Explodable::State::Moving && m_buildingBlocks == 0) {
            Q_EMIT levelCleared();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KGameRenderedItem * tile : std::as_const(m_buildingTiles)) {
        m_board->removeItem(tile);
    }
```

#### AUTO 


```{c}
const auto items = m_board->items();
```

#### RANGE FOR STATEMENT 


```{c}
for (KGameRenderedItem * tile : std::as_const(m_buildingTiles)) {
        m_board->addItem(tile);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Bomb * bomb : qAsConst(m_explodingBombs)) {
        bomb->update();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KGameRenderedItem * tile : qAsConst(m_buildingTiles)) {
        tile->show();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Building * building : qAsConst(m_buildings)) {
        building->resize(m_tileSize);
    }
```

#### AUTO 


```{c}
const auto currentBuildings = m_buildings;
```

#### RANGE FOR STATEMENT 


```{c}
for (KGameRenderedItem * tile : std::as_const(m_buildingTiles)) {
        tile->show();
    }
```

#### AUTO 


```{c}
auto widget = new Bomber;
```

#### RANGE FOR STATEMENT 


```{c}
for (QGraphicsItem * item : items) {
                item->hide();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (Building * building : std::as_const(m_buildings)) {
        building->resize(m_tileSize);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KGameRenderedItem * tile : qAsConst(m_buildingTiles)) {
        m_board->addItem(tile);
    }
```

#### AUTO 


```{c}
auto building = new Building(m_renderer, this, i + 1, height);
```

#### RANGE FOR STATEMENT 


```{c}
for (QGraphicsItem * item : items) {
                item->show();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (KGameRenderedItem * tile : qAsConst(m_buildingTiles)) {
        m_board->removeItem(tile);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Bomb * bomb : std::as_const(m_explodingBombs)) {
        bomb->advanceItem();
    }
```

