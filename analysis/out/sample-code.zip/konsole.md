#### AUTO 


```{c}
const auto data = item->data(QuickCommandsModel::QuickCommandRole).value<QuickCommandData>();
```

#### AUTO 


```{c}
auto tabbedContainer = qobject_cast<Konsole::TabbedViewContainer*>(mainWindow->centralWidget());
```

#### RANGE FOR STATEMENT 


```{c}
for (const Profile::Ptr &profile : profiles) {
        if (profile->name() == profileName) {
            SessionManager::instance()->setSessionProfile(this, profile);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &spot : spots) {
        QRegion region;
        if (spot->type() == HotSpot::Link || spot->type() == HotSpot::EMailAddress || spot->type() == HotSpot::EscapedUrl) {
            QPair<QRegion, QRect> spotRegion = spot->region(td->fontWidth(), td->fontHeight(), td->columns(), td->contentRect());
            region = spotRegion.first;
            QRect r = spotRegion.second;

            // TODO: Move this paint code to HotSpot->drawHint();
            // TODO: Fix the Url Hints access from the Profile.
            if (_showUrlHint && spot->type() == HotSpot::Link) {
                if (urlNumber >= 0 && urlNumber < 10) {
                    // Position at the beginning of the URL
                    QRect hintRect(*region.begin());
                    hintRect.setWidth(r.height());
                    painter.fillRect(hintRect, QColor(0, 0, 0, 128));
                    painter.setPen(Qt::white);
                    painter.drawRect(hintRect.adjusted(0, 0, -1, -1));
                    painter.drawText(hintRect, Qt::AlignCenter, QString::number(urlNumber));
                }
                urlNumber += urlNumInc;
            }
        }

        if (spot->startLine() < 0 || spot->endLine() < 0) {
            qDebug() << "ERROR, invalid hotspot:";
            spot->debug();
        }

        for (int line = spot->startLine() ; line <= spot->endLine() ; line++) {
            int startColumn = 0;
            int endColumn = td->columns() - 1; // TODO use number of _columns which are actually
            // occupied on this line rather than the width of the
            // display in _columns

            // Check image size so _image[] is valid (see makeImage)
            if (endColumn >= td->columns() || line >= td->lines()) {
                break;
            }

            // ignore whitespace at the end of the lines
            while (td->getCursorCharacter(endColumn, line).isSpace() && endColumn > 0) {
                endColumn--;
            }

            // increment here because the column which we want to set 'endColumn' to
            // is the first whitespace character at the end of the line
            endColumn++;

            if (line == spot->startLine()) {
                startColumn = spot->startColumn();
            }
            if (line == spot->endLine()) {
                endColumn = spot->endColumn();
            }

            // TODO: resolve this comment with the new margin/center code
            // subtract one pixel from
            // the right and bottom so that
            // we do not overdraw adjacent
            // hotspots
            //
            // subtracting one pixel from all sides also prevents an edge case where
            // moving the mouse outside a link could still leave it underlined
            // because the check below for the position of the cursor
            // finds it on the border of the target area
            QRect r;
            r.setCoords(startColumn * td->fontWidth() + td->contentRect().left(),
                        line * td->fontHeight() + td->contentRect().top(),
                        endColumn * td->fontWidth() + td->contentRect().left() - 1,
                        (line + 1)* td->fontHeight() + td->contentRect().top() - 1);

            // Underline link hotspots
            // TODO: Fix accessing the urlHint here.
            // TODO: Move this code to UrlFilterHotSpot.
            const bool hasMouse = region.contains(td->mapFromGlobal(QCursor::pos()));
            if ((spot->type() == HotSpot::Link && _showUrlHint) || hasMouse) {
                QFontMetrics metrics(td->font());

                // find the baseline (which is the invisible line that the characters in the font sit on,
                // with some having tails dangling below)
                const int baseline = r.bottom() - metrics.descent();
                // find the position of the underline below that
                const int underlinePos = baseline + metrics.underlinePos();
                painter.drawLine(r.left() , underlinePos, r.right() , underlinePos);

                // Marker hotspots simply have a transparent rectangular shape
                // drawn on top of them
            } else if (spot->type() == HotSpot::Marker) {
                //TODO - Do not use a hardcoded color for this
                const bool isCurrentResultLine = (td->screenWindow()->currentResultLine() == (spot->startLine() + td->screenWindow()->currentLine()));
                QColor color = isCurrentResultLine ? QColor(255, 255, 0, 120) : QColor(255, 0, 0, 120);
                painter.fillRect(r, color);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QRect &rect : qAsConst(dirtyImageRegion)) {
        Q_EMIT drawContents(_image, paint, rect, false, _imageSize, _bidiEnabled, _lineProperties);
    }
```

#### AUTO 


```{c}
static auto movementKeysToPassAlong = QSet<int>{
        Qt::Key_PageUp, Qt::Key_PageDown, Qt::Key_Up, Qt::Key_Down
    };
```

#### LAMBDA EXPRESSION 


```{c}
[] (reflowData &change, qint64 index, bool lineflag) {
        change.index = index;
        change.lineFlag = lineflag;
    }
```

#### AUTO 


```{c}
static const auto isUnsafe = [](const QChar &c) {
        return (c.category() == QChar::Category::Other_Control && !whitelist.contains(c.unicode()));
    };
```

#### RANGE FOR STATEMENT 


```{c}
for(auto container : _viewSplitter->containers()) {
        container->tabBar()->setExpanding(!setTabWidthToText);
        container->tabBar()->update();
    }
```

#### AUTO 


```{c}
auto line = _lines.back().get();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Profile::Ptr &profile : profiles) {
        if (profile->name() == profileName) {
            ProfileManager::instance()->setDefaultProfile(profile);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *l: qAsConst(_layouts)) {
        int left = getLeftMargin(l);
        l->setColumnMinimumWidth(LABELS_COLUMN, maxRight - left);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool focused) {
        _hasCompositeFocus = focused;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto i : text)
        w += konsole_wcwidth(i.unicode());
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool) {
        kcfg_TabBarUserStyleSheetFile->setEnabled(kcfg_TabBarUseUserStyleSheet->isChecked() && !AlwaysHideTabBar->isChecked());
    }
```

#### CONST EXPRESSION 


```{c}
constexpr bool equalsFormat(const Character &other) const;
```

#### AUTO 


```{c}
const auto key
```

#### AUTO 


```{c}
const auto signal = action->data().value<int>();
```

#### LAMBDA EXPRESSION 


```{c}
[this, controller]{ activeViewChanged(controller); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QFont &f) { _terminalFont->setVTFont(f); }
```

#### AUTO 


```{c}
static const auto re = QRegularExpression(
        /* First part of the regexp means 'strings with spaces and starting with single quotes'
         * Second part means "Strings with double quotes"
         * Last part means "Everything else plus some special chars
         * This is much smaller, and faster, than the previous regexp
         * on the HotSpot creation we verify if this is indeed a file, so there's
         * no problem on testing on random words on the screen.
         */
            QStringLiteral(R"RX('[^'\n]+')RX")       // Matches everything between single quotes.
            + QStringLiteral(R"RX(|"[^\n"]+")RX")   // Matches everything inside double quotes
            // Matches a contiguous line of alphanumeric characters plus some special ones
            // defined in the profile. With a special case for strings starting with '/' which
            // denotes a path on Linux.
            // Takes into account line numbers:
            // - grep output with line numbers: "/path/to/file:123"
            // - compiler error output: ":/path/to/file:123:123"
            //
            // ([^\n/\[]/) to not match "https://", and urls starting with "[" are matched by the
            // next | branch (ctest stuff)
            + QStringLiteral(R"RX(|([^\n\s/\[]/)?[\p{L}\w%1]+(:\d+)?(:\d+:)?)RX").arg(wordCharacters)
            // - ctest error output: "[/path/to/file(123)]"
            + QStringLiteral(R"RX(|\[[/\w%1]+\(\d+\)\])RX").arg(wordCharacters),
        QRegularExpression::DontCaptureOption
    );
```

#### AUTO 


```{c}
const auto currentMergedRangesIt = mergedRanges.find(width);
```

#### AUTO 


```{c}
const auto isFavorite = ProfileManager::instance()->findFavorites().contains(profile);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &escapedUrl : urls) {
        if (escapedUrl.begin.row < sWindow->currentLine() || escapedUrl.end.row > sWindow->currentLine() + sWindow->windowLines()) {
            continue;
        }

        const int beginRow = escapedUrl.begin.row - sWindow->currentLine();
        const int endRow = escapedUrl.end.row - sWindow->currentLine();
        QSharedPointer<HotSpot> spot(
            // TODO:
            // This uses Column / Row while everything else uses Row/Column.
            // Move everything else to QPoint begin / QPoint End.
            new EscapeSequenceUrlHotSpot(beginRow, escapedUrl.begin.col,
                    endRow, escapedUrl.end.col,
                    escapedUrl.text,
                    escapedUrl.url
            )
        );

        addHotSpot(spot);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        Q_EMIT bellRequest(i18n("Bell in session '%1'", _nameTitle));
        this->setPendingNotification(Notification::Bell);
    }
```

#### AUTO 


```{c}
const auto signal = action->data().toInt();
```

#### RANGE FOR STATEMENT 


```{c}
for (uint cc : chars) {
        if (cc == DEL) {
            continue; // VT100: ignore.
        }

        // early out for displayable characters
        if (!getMode(MODE_Sixel) && getMode(MODE_Ansi) && tokenBufferPos == 0 && cc >= 32 && cc != (ESC + 128)) {
            _currentScreen->displayCharacter(applyCharset(cc));
            continue;
        }

        if (!getMode(MODE_Sixel) && ces(CTL)) {
            // ignore control characters in the text part of osc (aka OSC) "ESC]"
            // escape sequences; this matches what XTERM docs say
            // Allow BEL and ESC here, it will either end the text or be removed later.
            if ((osc || apc) && cc != 0x1b && cc != 0x07) {
                continue;
            }

            if (!osc && !apc) {
                // DEC HACK ALERT! Control Characters are allowed *within* esc sequences in VT100
                // This means, they do neither a resetTokenizer() nor a pushToToken(). Some of them, do
                // of course. Guess this originates from a weakly layered handling of the X-on
                // X-off protocol, which comes really below this level.
                if (cc == CNTL('X') || cc == CNTL('Z') || cc == ESC) {
                    resetTokenizer(); // VT100: CAN or SUB
                }
                if (cc != ESC) {
                    processToken(token_ctl(cc + '@'), 0, 0);
                    continue;
                }
            }
        }
        // advance the state
        addToCurrentToken(cc);

        uint *s = tokenBuffer;
        const int p = tokenBufferPos;

        if (getMode(MODE_Sixel) && processSixel(cc)) {
            continue;
        }

        if (getMode(MODE_Ansi)) {
            if (lec(1, 0, ESC)) {
                continue;
            }
            if (lec(1, 0, ESC + 128)) {
                s[0] = ESC;
                receiveChars(QVector<uint>{'['});
                continue;
            }
            if (les(2, 1, GRP)) {
                continue;
            }
            // Operating System Command
            if (p > 2 && s[1] == ']') {
                // <ESC> ']' ... <ESC> '\'
                if (s[p - 2] == ESC && s[p - 1] == '\\') {
                    // This runs two times per link, the first prepares the link to be read,
                    // the second finalizes it. The escape sequence is in two parts
                    //  start: '\e ] 8 ; <id-path> ; <url-part> \e \\'
                    //  end:   '\e ] 8 ; ; \e \\'
                    // GNU libtextstyle inserts the IDs, for instance; many examples
                    // do not.
                    if (s[2] == XTERM_EXTENDED::URL_LINK) {
                        // printf '\e]8;;https://example.com\e\\This is a link\e]8;;\e\\\n'
                        _currentScreen->urlExtractor()->toggleUrlInput();
                    }
                    processSessionAttributeRequest(p - 1);
                    resetTokenizer();
                    continue;
                }
                // <ESC> ']' ... <ESC> + one character for reprocessing
                if (s[p - 2] == ESC) {
                    processSessionAttributeRequest(p - 1);
                    resetTokenizer();
                    receiveChars(QVector<uint>{cc});
                    continue;
                }
                // <ESC> ']' ... <BEL>
                if (s[p - 1] == 0x07) {
                    processSessionAttributeRequest(p);
                    resetTokenizer();
                    continue;
                }
                // Special case: iterm file protocol is a long escape sequence
                if (tokenState == -1) {
                    tokenStateChange = "1337;File=:";
                    tokenState = 0;
                } else if (tokenState >= 0) {
                    if ((uint)tokenStateChange[tokenState] == s[p - 1]) {
                        tokenState++;
                        tokenPos = p;
                        if ((uint)tokenState == strlen(tokenStateChange)) {
                            tokenState = -2;
                            tokenData.clear();
                        }
                        continue;
                    }
                } else if (tokenState == -2) {
                    if (p - tokenPos == 4) {
                        tokenData.append(QByteArray::fromBase64(QString::fromUcs4(&tokenBuffer[tokenPos], 4).toLocal8Bit()));
                        tokenBufferPos -= 4;
                        continue;
                    }
                }
                // Special case: Session::Wallpaper is a long escape sequence
                if (tokenState == -1) {
                    tokenStateChange = "114502;,,";
                    tokenState = 0;
                } else if (tokenState >= 0) {
                    if ((uint)tokenStateChange[tokenState] == s[p - 1]) {
                        tokenState++;
                        tokenPos = p;
                        if ((uint)tokenState == strlen(tokenStateChange)) {
                            tokenState = -2;
                            tokenData.clear();
                        }
                        continue;
                    }
                } else if (tokenState == -2) {
                    if (p - tokenPos == 4) {
                        tokenData.append(QByteArray::fromBase64(QString::fromUcs4(&tokenBuffer[tokenPos], 4).toLocal8Bit()));
                        tokenBufferPos -= 4;
                        continue;
                    }
                }
            }
            // Application Program Command
            if (p > 2 && s[1] == '_') {
                // <ESC> '_' ... <ESC> '\'
                if (p > 3 && s[2] == 'G') {
                    if (tokenState == -1) {
                        tokenStateChange = ";";
                        tokenState = 0;
                    } else if (tokenState >= 0) {
                        if ((uint)tokenStateChange[tokenState] == s[p - 1]) {
                            tokenState++;
                            tokenPos = p;
                            if ((uint)tokenState == strlen(tokenStateChange)) {
                                tokenState = -2;
                                tokenData.clear();
                            }
                            continue;
                        }
                    } else if (tokenState == -2) {
                        if (p - tokenPos == 4) {
                            tokenData.append(QByteArray::fromBase64(QString::fromUcs4(&tokenBuffer[tokenPos], 4).toLocal8Bit()));
                            tokenBufferPos -= 4;
                            continue;
                        }
                    }
                }
                if (s[p - 1] == 0x07 || (s[p - 2] == ESC && s[p - 1] == '\\')) {
                    if (s[2] == 'G') {
                        // Graphics command
                        processGraphicsToken(p);
                        resetTokenizer();
                        continue;
                    }
                }
            }

            /* clang-format off */
        // <ESC> ']' ...
        if (osc         ) { continue; }
        if (apc         ) { continue; }
        if (p >= 3 && s[1] == '[') { // parsing a CSI sequence
            if (lec(3,2,'?')) { continue; }
            if (lec(3,2,'=')) { continue; }
            if (lec(3,2,'>')) { continue; }
            if (lec(3,2,'!')) { continue; }
            if (lec(3,2,SP )) { continue; }
            if (lec(4,3,SP )) { continue; }
            if (eps(    CPN)) { processToken(token_csi_pn(cc), argv[0],argv[1]);  resetTokenizer(); continue; }

            // resize = \e[8;<row>;<col>t
            if (eps(CPS)) {
                processToken(token_csi_ps(cc, argv[0]), argv[1], argv[2]);
                resetTokenizer();
                continue;
            }

            if (epe(   )) { processToken(token_csi_pe(cc), 0, 0); resetTokenizer(); continue; }

            if (esp (   )) { processToken(token_csi_sp(cc), 0, 0);           resetTokenizer(); continue; }
            if (epsp(   )) { processToken(token_csi_psp(cc, argv[0]), 0, 0); resetTokenizer(); continue; }

            if (ees(DIG)) { addDigit(cc-'0'); continue; }
            if (eec(';')) { addArgument();    continue; }
            if (ees(INT)) { continue; }
            if (p >= 3 && cc == 'y' && s[p - 2] == '*') { processChecksumRequest(argc, argv); resetTokenizer(); continue; }
            for (int i = 0; i <= argc; i++) {
                if (epp()) {
                    processToken(token_csi_pr(cc,argv[i]), 0, 0);
                } else if (eeq()) {
                    processToken(token_csi_pq(cc), 0, 0); // spec. case for ESC[=0c or ESC[=c
                } else if (egt()) {
                    processToken(token_csi_pg(cc), 0, 0); // spec. case for ESC[>0c or ESC[>c
                } else if (cc == 'm' && argc - i >= 4 && (argv[i] == 38 || argv[i] == 48) && argv[i+1] == 2)
                {
                    // ESC[ ... 48;2;<red>;<green>;<blue> ... m -or- ESC[ ... 38;2;<red>;<green>;<blue> ... m
                    i += 2;
                    processToken(token_csi_ps(cc, argv[i-2]), COLOR_SPACE_RGB, (argv[i] << 16) | (argv[i+1] << 8) | argv[i+2]);
                    i += 2;
                } else if (cc == 'm' && argc - i >= 2 && (argv[i] == 38 || argv[i] == 48) && argv[i+1] == 5) {
                    // ESC[ ... 48;5;<index> ... m -or- ESC[ ... 38;5;<index> ... m
                    i += 2;
                    processToken(token_csi_ps(cc, argv[i-2]), COLOR_SPACE_256, argv[i]);
                } else if (p < 2 || (charClass[s[p-2]] & (INT)) != (INT)) {
                    processToken(token_csi_ps(cc,argv[i]), 0, 0);
                }
            }
        } else {
            if (dcs) {
                // Check for Sixel DCS q
                if (p > 2 && cc == 'q') {
                    setMode(MODE_Sixel);
                    // This parameter appers to be ignored
                    // m_preserveBackground = argv[2] == 1;
                    resetTokenizer();
                }
                if (ccc(DIG)) { addDigit(cc-'0');}
                if (cc == ';') { addArgument();}
                continue;
            }
            if (lec(2,0,ESC)) { processToken(token_esc(s[1]), 0, 0);              resetTokenizer(); continue; }
            if (les(3,1,SCS)) { processToken(token_esc_cs(s[1],s[2]), 0, 0);      resetTokenizer(); continue; }
            if (lec(3,1,'#')) { processToken(token_esc_de(s[2]), 0, 0);           resetTokenizer(); continue; }
        }
        resetTokenizer();
        /* clang-format on */
        } else {
            // VT52 Mode
            if (lec(1, 0, ESC)) {
                continue;
            }
            if (les(1, 0, CHR)) {
                processToken(token_chr(), s[0], 0);
                resetTokenizer();
                continue;
            }
            if (lec(2, 1, 'Y')) {
                continue;
            }
            if (lec(3, 1, 'Y')) {
                continue;
            }
            if (p < 4) {
                processToken(token_vt52(s[1]), 0, 0);
                resetTokenizer();
                continue;
            }
            processToken(token_vt52(s[1]), s[2], s[3]);
            resetTokenizer();
            continue;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, openAction] {
        activate(openAction);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
            renameTab(_contextMenuTabIndex);
        }
```

#### AUTO 


```{c}
const auto fg = style->foregroundColor.color(colorTable);
```

#### AUTO 


```{c}
auto barLayout = new QHBoxLayout(this);
```

#### AUTO 


```{c}
auto controller = qobject_cast<SessionController *>(_navigation[currWidget]);
```

#### AUTO 


```{c}
const auto &choices = enumItem->choices();
```

#### AUTO 


```{c}
auto setActionFont = [sessionAction](bool isBold) {
                QFont actionFont = sessionAction->font();
                actionFont.setBold(isBold);
                sessionAction->setFont(actionFont);
            };
```

#### AUTO 


```{c}
auto profileList = new ProfileList(false, profileMenu);
```

#### AUTO 


```{c}
const auto shortcut = ProfileManager::instance()->shortcut(profile).toString();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *action : menu->actions()) {
        if (action->text().toLower().remove(QLatin1Char('&')).contains(i18n("open with"))) {
            menu->removeAction(action);
            menu->insertAction(firstAction, action);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        if (viewManager()) {
            viewManager()->saveLayoutFile();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QChar &c : text) {
        if (!isUnsafe(c)) {
            sanitized.append(c);
        }
    }
```

#### AUTO 


```{c}
auto controller = qobject_cast<SessionController*>(item);
```

#### AUTO 


```{c}
auto *model = qobject_cast<QStandardItemModel *>(_ui->keyBindingList->model());
```

#### AUTO 


```{c}
auto *parent_splitter = qobject_cast<ViewSplitter *>(parentWidget());
```

#### AUTO 


```{c}
const auto bgFactor = 1.6;
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QPoint &pos) {
        if (!ui->treeView->indexAt(pos).isValid()) {
            return;
        }

        QMenu *menu = new QMenu(this);
        auto action = new QAction(QStringLiteral("Remove"), ui->treeView);
        menu->addAction(action);

        connect(action, &QAction::triggered, this, &SSHManagerTreeWidget::triggerRemove);

        menu->popup(ui->treeView->viewport()->mapToGlobal(pos));
    }
```

#### AUTO 


```{c}
auto session = _sessionMap.take(terminal);
```

#### LAMBDA EXPRESSION 


```{c}
[&](int column) {
                    return _display->_image[_display->loc(column, y)].character <= 0x7e
                            || (_display->_image[_display->loc(column, y)].rendition & RE_EXTENDED_CHAR)
                            || (_display->_bidiEnabled && !doubleWidth);
                }
```

#### AUTO 


```{c}
const auto a = wcag20AdjustColorPart;
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &action : _contextPopupMenu->actions()) {
            if (action->objectName() == QLatin1String("view-readonly")) {
                _contextPopupMenu->removeAction(action);
                break;
            }
        }
```

#### AUTO 


```{c}
auto extChars = [this]() { return usedExtendedChars(); };
```

#### AUTO 


```{c}
auto optionsMenu = new QMenu(this);
```

#### AUTO 


```{c}
auto *session = static_cast<Session *>(index.internalPointer());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &value : parser.values(option)) {
            if (option == QLatin1String("workdir")) {
                m_commandLineArguments.insert(option, QDir(workingDir).absolutePath());
            } else {
                m_commandLineArguments.insert(option, value);
            }
        }
```

#### AUTO 


```{c}
auto testCharacters = new Character[text.size()];
```

#### LAMBDA EXPRESSION 


```{c}
[this](QPainter &paint, const QRect &rect, bool friendly) {
        emit drawContents(_image, paint, rect, friendly, _imageSize, _bidiEnabled, _lineProperties);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &profile : ProfileManager::instance()->allProfiles()) {
        addShortcutAction(profile);
    }
```

#### AUTO 


```{c}
auto fileHotspot = _currentlyHoveredHotspot.dynamicCast<FileFilter::HotSpot>();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        // Remove the read-only action when the popup closes
        for (auto &action : _contextPopupMenu->actions()) {
            if (action->objectName() == QStringLiteral("view-readonly")) {
                _contextPopupMenu->removeAction(action);
                break;
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&enable, &collection](const QString &actionName) {
        auto *action = collection->action(actionName);
        if (action != nullptr) {
            action->setEnabled(enable);
        }
    }
```

#### AUTO 


```{c}
auto *getNewButton = new KNSWidgets::Button(this);
```

#### AUTO 


```{c}
const auto gray = (i - 232) * 10 + 8;
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : actionsList) {
        action->setShortcutContext(Qt::WidgetWithChildrenShortcut);
    }
```

#### AUTO 


```{c}
auto detachAction = _contextPopupMenu->addAction(QIcon::fromTheme(QStringLiteral("tab-detach")), i18nc("@action:inmenu", "&Detach Tab"), this, [this] {
        Q_EMIT detachTab(_contextMenuTabIndex);
    });
```

#### AUTO 


```{c}
const auto &[group, oldName, newName]
```

#### AUTO 


```{c}
auto splitter = qobject_cast<ViewSplitter*>(terminalDisplay->parentWidget());
```

#### AUTO 


```{c}
auto mainWindow = app.newMainWindow();
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &url) {
            if (url == "#close") {
                _outputSuspendedLabel->setVisible(false);
            } else {
                QDesktopServices::openUrl(QUrl(url));
            }
        }
```

#### AUTO 


```{c}
auto copyAction = new QAction(_urlObject);
```

#### AUTO 


```{c}
auto item = d->model->itemFromIndex(sourceIdx);
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *menuItem : actions) {
        QString itemText = menuItem->text();
        menuItem->setData(itemText);
    }
```

#### AUTO 


```{c}
auto *splitter = qobject_cast<ViewSplitter*>(view->parentWidget());
```

#### LAMBDA EXPRESSION 


```{c}
[removing](int i) {
            return i - removing;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto* elm : old) {
            newActions.removeAll(elm);
        }
```

#### AUTO 


```{c}
auto swappedContext = _navigation[swappedWidget];
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : selected) {
        bool needTransparency = index.data(Qt::UserRole + 1).value<std::shared_ptr<const ColorScheme>>()->opacity() < 1.0;

        if (!needTransparency) {
            _appearanceUi->transparencyWarningWidget->setHidden(true);
        } else if (!KWindowSystem::compositingActive()) {
            _appearanceUi->transparencyWarningWidget->setText(
                i18n("This color scheme uses a transparent background"
                     " which does not appear to be supported on your"
                     " desktop"));
            _appearanceUi->transparencyWarningWidget->setHidden(false);
        } else if (!WindowSystemInfo::HAVE_TRANSPARENCY) {
            _appearanceUi->transparencyWarningWidget->setText(
                i18n("Konsole was started before desktop effects were enabled."
                     " You need to restart Konsole to see transparent background."));
            _appearanceUi->transparencyWarningWidget->setHidden(false);
        }
    }
```

#### AUTO 


```{c}
const auto readAndCheckConfigEntry = [&](const char *key, double min, double max) -> double {
        const double value = configGroup.readEntry(key, min);
        if (min > value || value > max) {
            qCDebug(ColorSchemeDebug) << QStringLiteral(
                    "Color scheme \"%1\": color index 2 has an invalid value: %3 = %4. "
                    "Allowed value range: %5 - %6. Using %7.")
                    .arg(name()).arg(index).arg(QLatin1String(key)).arg(value, 0, 'g', 1)
                    .arg(min, 0, 'g', 1).arg(max, 0, 'g', 1).arg(min, 0, 'g', 1);
            return min;
        }
        return value;
    };
```

#### AUTO 


```{c}
auto mainLayout = new QVBoxLayout;
```

#### AUTO 


```{c}
auto orientation = (jsonSplitter[QStringLiteral("Orientation")].toString() == QStringLiteral("Horizontal"))
        ? Qt::Horizontal : Qt::Vertical;
```

#### AUTO 


```{c}
auto *job = new KIO::ApplicationLauncherJob(service);
```

#### AUTO 


```{c}
const auto contextPopupMenuActions = _contextPopupMenu->actions();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        return _terminalColor->backgroundColor();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &dir : dirs) {
        const QStringList fileNames = QDir(dir).entryList(QStringList() << QStringLiteral("*.keytab"));
        for (const QString &file : fileNames) {
            list.append(dir + QLatin1Char('/') + file);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { return usedExtendedChars(); }
```

#### AUTO 


```{c}
auto wi = widthStats.constBegin();
```

#### AUTO 


```{c}
auto action = new QAction(QStringLiteral("Remove"), ui->treeView);
```

#### RANGE FOR STATEMENT 


```{c}
for (Session *session : qAsConst(_sessions)) {
        if (session->sessionId() == id) {
            return session;
        }
    }
```

#### AUTO 


```{c}
auto profile = SessionManager::instance()->sessionProfile(session());
```

#### AUTO 


```{c}
const auto normalWeight = m_parentDisplay->font().weight();
```

#### AUTO 


```{c}
auto * action = qobject_cast<QAction*>(sender());
```

#### AUTO 


```{c}
const auto backgroundAlpha = background.alphaF();
```

#### AUTO 


```{c}
const auto &choice
```

#### RANGE FOR STATEMENT 


```{c}
for (const Profile::PropertyInfo &info : Profile::DefaultProperties) {
        if (info.group != nullptr) {
            if (groupName == nullptr || qstrcmp(groupName, info.group) != 0) {
                group = config.group(info.group);
                groupName = info.group;
            }

            if (profile->isPropertySet(info.property)) {
                group.writeEntry(QLatin1String(info.name), profile->property<QVariant>(info.property));
            }
        }
    }
```

#### AUTO 


```{c}
auto suffix = ki18ncp("Unit of time", " second", " seconds");
```

#### RANGE FOR STATEMENT 


```{c}
for (const ColorScheme *scheme : schemeList) {
        QStandardItem *item = new QStandardItem(scheme->description());
        item->setData(QVariant::fromValue(scheme), Qt::UserRole + 1);
        item->setData(QVariant::fromValue(_profile->font()), Qt::UserRole + 2);
        item->setFlags(item->flags());

        // if selectedColorSchemeName is not empty then select that scheme
        // after saving the changes in the colorScheme editor
        if (selectedColorScheme == scheme) {
            selectedItem = item;
        }

        model->appendRow(item);
    }
```

#### AUTO 


```{c}
auto fileSpot = spot.dynamicCast<FileFilterHotSpot>();
```

#### AUTO 


```{c}
auto *copyInputToNoneAction = collection->add<KToggleAction>(QStringLiteral("copy-input-to-none"));
```

#### AUTO 


```{c}
auto ch = result[i];
```

#### LAMBDA EXPRESSION 


```{c}
[this, session]() {
                sessionTerminated(session);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (KXMLGUIClient *client : clientsList) {
        dialog.addCollection(client->actionCollection());
    }
```

#### AUTO 


```{c}
const auto &[pos, delta]
```

#### AUTO 


```{c}
const auto columns = profile->property<int>(Profile::TerminalColumns);
```

#### AUTO 


```{c}
const auto blend1 = alphaBlend(c1, colorTable[DEFAULT_FORE_COLOR]), blend2 = alphaBlend(c1, colorTable[DEFAULT_BACK_COLOR]);
```

#### AUTO 


```{c}
auto ldrawBackground = [this](QPainter &painter, const QRect &rect, const QColor &backgroundColor, bool useOpacitySetting) {
        _terminalPainter->drawBackground(painter, rect, backgroundColor, useOpacitySetting);
    };
```

#### AUTO 


```{c}
auto detachAction = _contextPopupMenu->addAction(
        QIcon::fromTheme(QStringLiteral("tab-detach")),
        i18nc("@action:inmenu", "&Detach Tab"), this,
        [this] { emit detachTab(this, widget(_contextMenuTabIndex)); }
    );
```

#### AUTO 


```{c}
const auto height = geometry().height();
```

#### AUTO 


```{c}
const auto *hostnameValidator = new QRegularExpressionValidator(hostnameRegex, this);
```

#### AUTO 


```{c}
auto *innerSplitter = qobject_cast<ViewSplitter *>(p);
```

#### LAMBDA EXPRESSION 


```{c}
[filename](const QString& s) { return filename.startsWith(s); }
```

#### LAMBDA EXPRESSION 


```{c}
[](const ExtractedUrl& url) {
            const bool toRemove = url.begin.row < 0;
            return toRemove;

        }
```

#### AUTO 


```{c}
const auto &displays = _views;
```

#### RANGE FOR STATEMENT 


```{c}
for (auto notification: availableNotifications) {
        setPendingNotification(notification, false);
    }
```

#### AUTO 


```{c}
auto *widget = splitter->widget(i);
```

#### AUTO 


```{c}
auto *enumItem = groupToConfigItemEnum(button->group());
```

#### AUTO 


```{c}
const auto oldActiveWindow = KWindowSystem::activeWindow();
```

#### AUTO 


```{c}
const auto match = FMT_RE.match(argv.value(1));
```

#### AUTO 


```{c}
auto historyTypeNone = new HistoryTypeNone();
```

#### LAMBDA EXPRESSION 


```{c}
[this](QPainter &paint, const QRect &rect, bool friendly) {
        _terminalPainter->drawContents(_image, paint, rect, friendly, _imageSize, _bidiEnabled, _lineProperties);
    }
```

#### AUTO 


```{c}
static const auto charToSequence = [](const QChar &c) {
        if (c.unicode() <= 0x1F) {
            return QStringLiteral("^%1").arg(QChar(u'@' + c.unicode()));
        } else if (c.unicode() == 0x7F) {
            return QStringLiteral("^?");
        } else if (c.unicode() >= 0x80 && c.unicode() <= 0x9F) {
            return QStringLiteral("^[%1").arg(QChar(u'@' + c.unicode() - 0x80));
        }
        return QString();
    };
```

#### AUTO 


```{c}
auto *maybeSplitter = qobject_cast<QSplitter*>(widget);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto iterator : group) {
        Session *s = iterator;

        if (s != session()) {
            _copyToGroup->removeSession(iterator);
        }
    }
```

#### AUTO 


```{c}
auto *job = new KIO::OpenUrlJob(QUrl(_url));
```

#### RANGE FOR STATEMENT 


```{c}
for (const std::shared_ptr<const ColorScheme> &scheme : schemeList) {
        QStandardItem *item = new QStandardItem(scheme->description());
        item->setData(QVariant::fromValue(scheme), Qt::UserRole + 1);
        item->setData(QVariant::fromValue(_profile->font()), Qt::UserRole + 2);
        item->setFlags(item->flags());

        // if selectedColorSchemeName is not empty then select that scheme
        // after saving the changes in the colorScheme editor
        if (selectedColorScheme == scheme) {
            selectedItem = item;
        }

        model->appendRow(item);
    }
```

#### AUTO 


```{c}
auto *session = SessionManager::instance()->createSession(profile);
```

#### LAMBDA EXPRESSION 


```{c}
[&](int column) {
                    return (_display->_image[loc(column, y)].rendition & ~RE_EXTENDED_CHAR)
                        == (currentRendition & ~RE_EXTENDED_CHAR);
                }
```

#### AUTO 


```{c}
auto it = tokens.constFind(wdirOptionName);
```

#### AUTO 


```{c}
auto *job = new KIO::OpenFileManagerWindowJob();
```

#### CONST EXPRESSION 


```{c}
static constexpr const int testStringSize = sizeof(testString) / sizeof(char) - 1;
```

#### AUTO 


```{c}
const auto width = event->size().width() - _scrollBar->geometry().width();
```

#### AUTO 


```{c}
auto pasteString = terminalClipboard::prepareStringForPasting(text, appendReturn, bracketedPasteMode());
```

#### AUTO 


```{c}
auto codecAction = new KCodecAction(this);
```

#### AUTO 


```{c}
const auto globalPos = parentWidget()->mapToGlobal(pos());
```

#### AUTO 


```{c}
auto session = new Session();
```

#### AUTO 


```{c}
auto setNewLine = [] (reflowData &change, qint64 index, bool lineflag) {
        change.index = index;
        change.lineFlag = lineflag;
    };
```

#### AUTO 


```{c}
auto buttonBox = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel | QDialogButtonBox::Apply);
```

#### RANGE FOR STATEMENT 


```{c}
for (QTableWidgetItem *item : qAsConst(uniqueList)) {
        // get the first item in the row which has the entry

        KeyboardTranslator::Entry existing = item->data(Qt::UserRole).
                                             value<KeyboardTranslator::Entry>();

        _translator->removeEntry(existing);

        _ui->keyBindingTable->removeRow(item->row());
    }
```

#### AUTO 


```{c}
const auto scrollBarWidth = _scrollBar->scrollBarPosition() != Enum::ScrollBarHidden
                                ? _scrollBar->width()
                                : 0;
```

#### AUTO 


```{c}
const auto options = QVector<QCommandLineOption>{
        {{QStringLiteral("profile")}, i18nc("@info:shell", "Name of profile to use for new Konsole instance"), QStringLiteral("name")},
        {{QStringLiteral("layout")}, i18nc("@info:shell", "json layoutfile to be loaded to use for new Konsole instance"), QStringLiteral("file")},
        {{QStringLiteral("fallback-profile")}, i18nc("@info:shell", "Use the internal FALLBACK profile")},
        {{QStringLiteral("workdir")}, i18nc("@info:shell", "Set the initial working directory of the new tab or window to 'dir'"), QStringLiteral("dir")},
        {{QStringLiteral("hold"), QStringLiteral("noclose")}, i18nc("@info:shell", "Do not close the initial session automatically when it ends.")},
        {{QStringLiteral("new-tab")}, i18nc("@info:shell", "Create a new tab in an existing window rather than creating a new window")},
        {{QStringLiteral("tabs-from-file")}, i18nc("@info:shell", "Create tabs as specified in given tabs configuration file"), QStringLiteral("file")},
        {{QStringLiteral("background-mode")},
         i18nc("@info:shell", "Start Konsole in the background and bring to the front when Ctrl+Shift+F12 (by default) is pressed")},
        {{QStringLiteral("separate"), QStringLiteral("nofork")}, i18nc("@info:shell", "Run in a separate process")},
        {{QStringLiteral("show-menubar")}, i18nc("@info:shell", "Show the menubar, overriding the default setting")},
        {{QStringLiteral("hide-menubar")}, i18nc("@info:shell", "Hide the menubar, overriding the default setting")},
        {{QStringLiteral("show-tabbar")}, i18nc("@info:shell", "Show the tabbar, overriding the default setting")},
        {{QStringLiteral("hide-tabbar")}, i18nc("@info:shell", "Hide the tabbar, overriding the default setting")},
        {{QStringLiteral("fullscreen")}, i18nc("@info:shell", "Start Konsole in fullscreen mode")},
        {{QStringLiteral("notransparency")}, i18nc("@info:shell", "Disable transparent backgrounds, even if the system supports them.")},
        {{QStringLiteral("list-profiles")}, i18nc("@info:shell", "List the available profiles")},
        {{QStringLiteral("list-profile-properties")}, i18nc("@info:shell", "List all the profile properties names and their type (for use with -p)")},
        {{QStringLiteral("p")}, i18nc("@info:shell", "Change the value of a profile property."), QStringLiteral("property=value")},
        {{QStringLiteral("e")},
         i18nc("@info:shell", "Command to execute. This option will catch all following arguments, so use it as the last option."),
         QStringLiteral("cmd")}};
```

#### AUTO 


```{c}
auto view = controller->view()
```

#### AUTO 


```{c}
auto current = property<int>(Profile::TextEditorCmd);
```

#### AUTO 


```{c}
const auto hasSameColors = [&](int column) {
                    return image[display->loc(column, y)].foregroundColor == currentForeground
                        && image[display->loc(column, y)].backgroundColor == currentBackground;
                };
```

#### AUTO 


```{c}
auto parentSplitter = qobject_cast<ViewSplitter*>(focusedTerminalDisplay->parent());
```

#### AUTO 


```{c}
const auto sessionsList = SessionManager::instance()->sessions();
```

#### AUTO 


```{c}
const auto newSize = static_cast<int>(oldSize * (1.0 + percentage / 100.0));
```

#### LAMBDA EXPRESSION 


```{c}
[type](const QSharedPointer<HotSpot> &s) {
        return s->type() == type;
    }
```

#### AUTO 


```{c}
const auto *enumItem = groupToConfigItemEnum(group);
```

#### AUTO 


```{c}
auto notification
```

#### AUTO 


```{c}
auto parentSplitter = qobject_cast<ViewSplitter *>(parent());
```

#### LAMBDA EXPRESSION 


```{c}
[this](QPainter &painter, bool friendly) {
        QPoint columnLines(_usedLines, _usedColumns);
        auto lfontget = [this]() {
            return _terminalFont->getVTFont();
        };
        auto lfontset = [this](const QFont &f) {
            _terminalFont->setVTFont(f);
        };

        _printManager->printContent(painter, friendly, columnLines, lfontget, lfontset);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool enable) {
        _fontChooser->setFont(_fontChooser->font(), !enable);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const EdgeDistance &left, const EdgeDistance &right) -> bool {
            return left.first < right.first;
        }
```

#### AUTO 


```{c}
const auto mimeData = event->mimeData();
```

#### AUTO 


```{c}
const auto hasSameLineDrawStatus = [&](int column) {
                    return LineBlockCharacters::canDraw(image[display->loc(column, y)].character)
                        == lineDraw;
                };
```

#### AUTO 


```{c}
const auto spots = hotSpots();
```

#### AUTO 


```{c}
auto newBuffer = new QString();
```

#### AUTO 


```{c}
auto *maybeSplitter = qobject_cast<ViewSplitter *>(widgetAt)
```

#### AUTO 


```{c}
auto *found = static_cast<const char *>(memchr(text, '\030', length));
```

#### AUTO 


```{c}
auto *splitter = qobject_cast<ViewSplitter *>(view->parentWidget());
```

#### LAMBDA EXPRESSION 


```{c}
[this](int idx) {
        emit detachTab(idx);
    }
```

#### AUTO 


```{c}
const auto mode = action->data().value<int>();
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool focused) { if (focused) { interactionHandler(); }}
```

#### LAMBDA EXPRESSION 


```{c}
[](const TerminalDisplay *display) {
        return display->hasFocus();
    }
```

#### AUTO 


```{c}
const auto uniqueSessions = QSet<Session*>::fromList(_viewManager->sessions());
```

#### AUTO 


```{c}
const auto newTranslator = new KeyboardTranslator(*_translator);
```

#### AUTO 


```{c}
auto terminaldisplayList = _viewContainer->widget(i)->findChildren<TerminalDisplay *>();
```

#### LAMBDA EXPRESSION 


```{c}
[this](QPainter &paint, const QRect &rect, bool friendly) {
        _terminalPainter->drawContents(paint, rect, friendly);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QPainter &painter, const QRect &rect, const QColor &backgroundColor, bool useOpacitySetting) {
        _terminalPainter->drawBackground(painter, rect, backgroundColor, useOpacitySetting);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &file : entry.installedFiles()) {
                if (ColorSchemeManager::instance()->loadColorScheme(file)) {
                    continue;
                }
                qWarning() << "Failed to load file" << file;
                ++failures;
            }
```

#### AUTO 


```{c}
auto profilePtr = SessionManager::instance()->sessionProfile(session);
```

#### AUTO 


```{c}
const auto &prop
```

#### AUTO 


```{c}
const auto hasSameColors = [&](int column) {
                    return _display->_image[loc(column, y)].foregroundColor == currentForeground
                        && _display->_image[loc(column, y)].backgroundColor == currentBackground;
                };
```

#### AUTO 


```{c}
auto choice = KMessageBox::questionYesNo(this,
                                                 i18n("There are some errors on the script, do you really want to execute it?"),
                                                 i18n("Shell Errors"),
                                                 KStandardGuiItem::yes(),
                                                 KStandardGuiItem::no(),
                                                 QStringLiteral("quick-commands-question"));
```

#### AUTO 


```{c}
auto newActions = popup->actions();
```

#### AUTO 


```{c}
auto *appearancePageItem = addPage(appearancePageWidget, appearancePageName);
```

#### LAMBDA EXPRESSION 


```{c}
[&](int column) {
                return image[display->loc(column, y)].foregroundColor == currentForeground
                    && image[display->loc(column, y)].backgroundColor == currentBackground;
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (TerminalDisplay *terminalDisplay : viewsList) {
        if (terminalDisplay != view()) {
            terminalDisplay->updateReadOnlyState(isReadOnly());
        }
        Q_EMIT readOnlyChanged(this);
    }
```

#### AUTO 


```{c}
auto tmp_line = std::make_unique<Character[]>(size);
```

#### AUTO 


```{c}
auto editAction = _contextPopupMenu->addAction(
        QIcon::fromTheme(QStringLiteral("edit-rename")),
        i18nc("@action:inmenu", "&Rename Tab..."), this,
        [this]{ renameTab(_contextMenuTabIndex); }
    );
```

#### AUTO 


```{c}
auto factory = new KXMLGUIFactory(clientBuilder(), _sessionDisplayConnection->view());
```

#### AUTO 


```{c}
auto *thisSplitter = qobject_cast<ViewSplitter *>(splitter());
```

#### LAMBDA EXPRESSION 


```{c}
[](CharacterProperties &prop, const EmojiDataEntry &entry) {
        prop.emoji |= entry.emoji();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[filename](const QString &s) {
            // early out if first char doesn't match
            if (!s.isEmpty() && filename.at(0) != s.at(0)) {
                return false;
            }

            const bool startsWith = filename.startsWith(s);
            if (startsWith) {
                // are we equal ?
                if (filename.size() == s.size()) {
                    return true;
                }
                int onePast = s.size();
                if (onePast < filename.size()) {
                    if (filename.at(onePast) == QLatin1Char(':') || filename.at(onePast) == QLatin1Char('/')) {
                        return true;
                    }
                }
            }
            return false;
        }
```

#### AUTO 


```{c}
auto options = new PrintOptions();
```

#### AUTO 


```{c}
auto maybeTerminalDisplay = qobject_cast<TerminalDisplay*>(widgetAt)
```

#### AUTO 


```{c}
auto profile = Profile::Ptr(new Profile());
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &range: ranges) {
        if(!rangesStats.contains(range.width))
            rangesStats.insert(range.width, 0);
        rangesStats[range.width]++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto sdsp :  _sessionMap) {
        TerminalDisplay *view = sdsp->session() ? sdsp->view() : nullptr;
        applyProfileToView(view, profile);
    }
```

#### AUTO 


```{c}
auto colorItemFaint = new QTableWidgetItem();
```

#### RANGE FOR STATEMENT 


```{c}
for (ScreenWindow *window : qAsConst(_windows)) {
            window->setScreen(_currentScreen);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Session *other : sessionsKeys) {
        if (!_sessions[other]) {
            other->emulation()->sendString(data);
        }
    }
```

#### AUTO 


```{c}
auto *innerSplitter = qobject_cast<ViewSplitter*>(p);
```

#### LAMBDA EXPRESSION 


```{c}
[](int start, int end) {
        return end - start;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        // Remove the read-only action when the popup closes
        for (auto &action : _contextPopupMenu->actions()) {
            if (action->objectName() == QLatin1String("view-readonly")) {
                _contextPopupMenu->removeAction(action);
                break;
            }
        }
    }
```

#### AUTO 


```{c}
auto [charLine, charColumn] = getCharacterPosition(ev->pos(), true);
```

#### AUTO 


```{c}
auto generalSettings = new GeneralSettings(settingsDialog);
```

#### AUTO 


```{c}
auto mainWindowLayout = new QVBoxLayout();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : selected) {
        bool needTransparency = index.data(Qt::UserRole + 1).value<const ColorScheme *>()->opacity() < 1.0;

        if (!needTransparency) {
            _appearanceUi->transparencyWarningWidget->setHidden(true);
        } else if (!KWindowSystem::compositingActive()) {
            _appearanceUi->transparencyWarningWidget->setText(i18n(
                                                        "This color scheme uses a transparent background"
                                                        " which does not appear to be supported on your"
                                                        " desktop"));
            _appearanceUi->transparencyWarningWidget->setHidden(false);
        } else if (!WindowSystemInfo::HAVE_TRANSPARENCY) {
            _appearanceUi->transparencyWarningWidget->setText(i18n(
                                                        "Konsole was started before desktop effects were enabled."
                                                        " You need to restart Konsole to see transparent background."));
            _appearanceUi->transparencyWarningWidget->setHidden(false);
        }
    }
```

#### AUTO 


```{c}
auto widgetAt = topLevelSplitter->widget(i);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &sessionName : group.groupList()) {
            SSHConfigurationData data;
            KConfigGroup sessionGroup = group.group(sessionName);
            data.host = sessionGroup.readEntry("hostname");
            data.name = sessionGroup.readEntry("identifier");
            data.port = sessionGroup.readEntry("port");
            data.profileName = sessionGroup.readEntry("profilename");
            data.sshKey = sessionGroup.readEntry("sshkey");
            data.useSshConfig = sessionGroup.readEntry<bool>("useSshConfig", false);
            data.importedFromSshConfig = sessionGroup.readEntry<bool>("importedFromSshConfig", false);
            addChildItem(data, groupName);
        }
```

#### AUTO 


```{c}
auto *keyboardPageWidget = new QWidget(this);
```

#### LAMBDA EXPRESSION 


```{c}
[display, triggerText] {
        Q_EMIT display->sendStringToEmu(triggerText);
    }
```

#### AUTO 


```{c}
auto *element
```

#### RANGE FOR STATEMENT 


```{c}
for(auto *filter : _filters) {
        QSharedPointer<Filter::HotSpot> spot = filter->hotSpotAt(line, column);
        if (spot != nullptr) {
           return spot;
        }
    }
```

#### AUTO 


```{c}
const auto items = QList<QStandardItem*> {
        _sessionModel->item(row, ProfileNameColumn),
        _sessionModel->item(row, FavoriteStatusColumn),
        _sessionModel->item(row, ShortcutColumn)
    };
```

#### AUTO 


```{c}
const auto icon = isFavorite ? QIcon::fromTheme(QStringLiteral("dialog-ok-apply")) :  QIcon();
```

#### RANGE FOR STATEMENT 


```{c}
for (TerminalDisplay* terminal : displays) {
        manager->attachView(terminal, sessionsMap[terminal]);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto page : confDialog->findChildren<KPageWidgetItem *>()) {
                if (page->name().contains(profilePageName)) {
                    confDialog->setCurrentPage(page);
                    break;
                }
            }
```

#### AUTO 


```{c}
auto end = qMin(start + count, length);
```

#### AUTO 


```{c}
const auto fg = style.foregroundColor.color(colorTable);
```

#### AUTO 


```{c}
const auto isDarwin = QOperatingSystemVersion::currentType() == QOperatingSystemVersion::MacOS;
```

#### AUTO 


```{c}
auto orientation = (jsonSplitter[QStringLiteral("Orientation")].toString() == QLatin1String("Horizontal"))
        ? Qt::Horizontal : Qt::Vertical;
```

#### CONST EXPRESSION 


```{c}
constexpr auto MASK_TIMEOUT = 500ms;
```

#### AUTO 


```{c}
const auto oldShortcut = shortcut(oldProfile);
```

#### AUTO 


```{c}
auto removedLines = _history->reflowLines(new_columns);
```

#### LAMBDA EXPRESSION 


```{c}
[this, properties] {
        m_terminalIcon->setPixmap(properties->icon().pixmap(QSize(22, 22)));
    }
```

#### AUTO 


```{c}
auto iter = QMapIterator<QPointer<Session>, ScreenWindowPtr>(_windows);
```

#### AUTO 


```{c}
auto container
```

#### AUTO 


```{c}
auto profileIt = findByName(it.value());
```

#### AUTO 


```{c}
const auto canBeGrouped = [&](int column) {
                return _image[loc(column, y)].character <= 0x7e
                       || (_image[loc(column, y)].rendition & RE_EXTENDED_CHAR)
                       || (_bidiEnabled && !doubleWidth);
            };
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &groupName : config.groupList()) {
        KConfigGroup group = config.group(groupName);
        addTopLevelItem(groupName);
        for (const QString &sessionName : group.groupList()) {
            SSHConfigurationData data;
            KConfigGroup sessionGroup = group.group(sessionName);
            data.host = sessionGroup.readEntry("hostname");
            data.name = sessionGroup.readEntry("identifier");
            data.port = sessionGroup.readEntry("port");
            data.profileName = sessionGroup.readEntry("profilename");
            data.sshKey = sessionGroup.readEntry("sshkey");
            data.useSshConfig = sessionGroup.readEntry<bool>("useSshConfig", false);
            data.importedFromSshConfig = sessionGroup.readEntry<bool>("importedFromSshConfig", false);
            addChildItem(data, groupName);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, readonly]() {
        _view->updateReadOnlyState(readonly);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        thumbnailRequested();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto & i : profile) {
        group->addProfile(i);
        QVERIFY(group->profiles().contains(i));
        QVERIFY(!group_const->profiles().contains(i));
    }
```

#### AUTO 


```{c}
auto loadedProfiles = _profiles.values();
```

#### LAMBDA EXPRESSION 


```{c}
[](int size) {
        static QVector<Character> characterBuffer(1024);
        if (characterBuffer.count() < size) {
            characterBuffer.resize(size);
        }

        return characterBuffer.data();
    }
```

#### AUTO 


```{c}
auto startCopy = _cells.begin() + startOfLine(lineNumber);
```

#### AUTO 


```{c}
auto nextSplitter = restoreSessionsSplitterRecurse(widgetJsonObject, manager, useSessionId);
```

#### AUTO 


```{c}
auto dialog = new EditProfileDialog(parent);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QChar &c : text) {
        if (!c.isPrint() && c != QLatin1Char('\t') && c != QLatin1Char('\n')) {
            QString description;
            switch(c.unicode()) {
            case '\x03':
                description = i18n("^C Interrupt: May abort the current process");
                break;
            case '\x04':
                description = i18n("^D End of transmission: May exit the current process");
                break;
            case '\x07':
                description = i18n("^G Bell: Will try to emit an audible warning");
                break;
            case '\x08':
                description = i18n("^H Backspace");
                break;
            case '\x13':
                description = i18n("^S Scroll lock: Locks terminal output");
                break;
            case '\x1a':
                description = i18n("^Z Suspend: Stops current process");
                break;
            case '\x1b':
                description = i18n("ESC: Used for special commands to the current process");
                break;
            default:
                description = ki18n("Other unprintable character (\\x%1)").subs(c.unicode(), 0, 16).toString();
                break;
            }
            unsafeCharacters.append(description);
        }
    }
```

#### AUTO 


```{c}
auto newScroll = std::make_unique<HistoryScrollFile>();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto entry : entries) {
            for (const auto &file : entry.installedFiles()) {
                if (ColorSchemeManager::colorSchemeNameFromPath(file) != name) {
                    continue;
                }
                // Make sure the manager can unload it before uninstalling it.
                if (ColorSchemeManager::instance()->unloadColorScheme(file)) {
                    manager->uninstallEntry(entry);
                    uninstalled = true;
                }
            }
            if (uninstalled) {
                break;
            }
        }
```

#### AUTO 


```{c}
auto action = actionCollection()->action(name)
```

#### LAMBDA EXPRESSION 


```{c}
[&](KJob *) {
            if (_job->isErrorPage())
                _eventLoop.exit(KIO::ERR_DOES_NOT_EXIST);
            else if (_job->error() != KJob::NoError)
                _eventLoop.exit(_job->error());
            else
                _data = _job->data();

            _eventLoop.exit(KJob::NoError);
        }
```

#### AUTO 


```{c}
const auto &url
```

#### AUTO 


```{c}
auto method = maximize ? &QWidget::hide : &QWidget::show;
```

#### LAMBDA EXPRESSION 


```{c}
[] (qint64 start, qint64 end) {
        return (int)((end - start) / sizeof(Character));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, session](const QString &text) {
        sessionProfileCommandReceived(session, text);
    }
```

#### AUTO 


```{c}
auto display = new TerminalDisplay(0);
```

#### RANGE FOR STATEMENT 


```{c}
for (TerminalDisplay *terminalDisplay : session->views()) {
            // Searching for opened profiles
            profileDialog = terminalDisplay->sessionController()->profileDialogPointer();
            if (profileDialog == nullptr) {
                continue;
            }
            for (const Profile::Ptr &profile : profiles) {
                if (profile->name() == profileDialog->lookupProfile()->name()
                    && profileDialog->isVisible()) {
                    // close opened edit dialog
                    profileDialog->close();
                }
            }
        }
```

#### AUTO 


```{c}
const auto shortcut = qobject_cast<FilteredKeySequenceEdit *>(editor)->keySequence().toString();
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *widget : qAsConst(_registeredWidgets)) {
            widget->removeAction(action);
        }
```

#### AUTO 


```{c}
const auto tempDirectories = QStandardPaths::standardLocations(QStandardPaths::TempLocation);
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &filePath) {
#if KIO_VERSION < QT_VERSION_CHECK(5, 71, 0)
        new KRun(QUrl::fromLocalFile(filePath), QApplication::activeWindow());
#else
        auto *job = new KIO::OpenUrlJob(QUrl::fromLocalFile(filePath));
        job->setUiDelegate(new KIO::JobUiDelegate(KJobUiDelegate::AutoHandlingEnabled, QApplication::activeWindow()));
        job->setRunExecutables(false); // Always open, e.g. shell scripts, as text
        job->start();
#endif
    }
```

#### AUTO 


```{c}
const auto hostnameRegex =
        QRegularExpression(QStringLiteral(R"(^[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$)"));
```

#### AUTO 


```{c}
auto testData = QFINDTESTDATA(QLatin1String("data/bookmarks.xml"));
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QFont font) {
            preview(Profile::Font, font);
            updateFontPreview(font);
        }
```

#### AUTO 


```{c}
const auto isSameScript = [&](int column) {
                    const QChar::Script script = QChar::script(baseCodePoint(_display->_image[_display->loc(column, y)]));
                    if (currentScript == QChar::Script_Common || script == QChar::Script_Common
                        || currentScript == QChar::Script_Inherited || script == QChar::Script_Inherited) {
                        return true;
                    }
                    return currentScript == script;
                };
```

#### AUTO 


```{c}
auto terminalDisplay = createView(session);
```

#### AUTO 


```{c}
const auto isSameScript = [&](int column) {
                const QChar::Script script = QChar::script(baseCodePoint(_image[loc(column, y)]));
                if (currentScript == QChar::Script_Common || script == QChar::Script_Common
                    || currentScript == QChar::Script_Inherited || script == QChar::Script_Inherited) {
                    return true;
                }
                return currentScript == script;
            };
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto dropWidget : widgets) {
        if (dropWidget->rect().contains(dropWidget->mapFromGlobal(currentPos))) {
            dropWidget->moveViewRequest(-1, id, this);
            removeView(widget(index));
        }
    }
```

#### AUTO 


```{c}
static const auto charToSequence = [](const QChar &c) {
        if (c.unicode() <= 0x1F) {
            return QStringLiteral("^%1").arg(QChar(u'@' + c.unicode()));
        } else if (c.unicode() == 0x7F) {
            return QStringLiteral("^?");
        } else if (c.unicode() >= 0x80 && c.unicode() <= 0x9F){
            return QStringLiteral("^[%1").arg(QChar(u'@' + c.unicode() - 0x80));
        }
        return QString();
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const Profile::Ptr &profile : favoriteProfiles) {
        favoriteChanged(profile, true);
    }
```

#### AUTO 


```{c}
static auto re = QRegularExpression(
        /* First part of the regexp means 'strings with spaces and starting with single quotes'
         * Second part means "Strings with double quotes"
         * Last part means "Everything else plus some special chars
         * This is much smaller, and faster, than the previous regexp
         * on the HotSpot creation we verify if this is indeed a file, so there's
         * no problem on testing on random words on the screen.
         */
        QLatin1String(R"('[^']+'|"[^"]+"|[\w.~:-]+)"),
        QRegularExpression::DontCaptureOption);
```

#### AUTO 


```{c}
auto *copyInputToAllTabsAction = collection->add<KToggleAction>(QStringLiteral("copy-input-to-all-tabs"));
```

#### LAMBDA EXPRESSION 


```{c}
[this, properties] {
        m_terminalTitle->setText(properties->title());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]{
        const int count = _viewContainer->count();
        foreach(QAction *action, _multiTabOnlyActions) {
            action->setEnabled(count > 1);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, i]() {
               switchToView(i);
           }
```

#### AUTO 


```{c}
auto &flag = _flags.last();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto sdsp : _sessionMap) {
        session = sdsp->view() == display ? sdsp->session() : nullptr;
        _sessionMap.removeOne(sdsp);
        if (session != nullptr) {
            if (session->views().count() == 0) {
                session->close();
            }
        }
    }
```

#### AUTO 


```{c}
auto r = region(td->terminalFont()->fontWidth(), td->terminalFont()->fontHeight(), td->columns(), td->contentRect()).first;
```

#### AUTO 


```{c}
static auto movementKeysToPassAlong = QSet<int>{Qt::Key_PageUp, Qt::Key_PageDown, Qt::Key_Up, Qt::Key_Down};
```

#### AUTO 


```{c}
auto *action
```

#### AUTO 


```{c}
auto lfontset = [this](const QFont &f) { setVTFont(f); };
```

#### AUTO 


```{c}
const auto &profile
```

#### RANGE FOR STATEMENT 


```{c}
for (Page &page : _pages) {
        page.needsUpdate = true;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto *layout: qAsConst(_layouts)) {
            int left = getLeftMargin(layout);
            for (int row = 0; row < layout->rowCount(); ++row) {
                QLayoutItem *layoutItem = layout->itemAtPosition(row, LABELS_COLUMN);
                if (layoutItem == nullptr) {
                    continue;
                }
                QWidget *widget = layoutItem->widget();
                if (widget == nullptr) {
                    continue;
                }
                const int idx = layout->indexOf(widget);
                int rows, cols, rowSpan, colSpan;
                layout->getItemPosition(idx, &rows, &cols, &rowSpan, &colSpan);
                if (colSpan > 1) {
                    continue;
                }

                const int right = left + widget->sizeHint().width();
                if (maxRight < right) {
                    maxRight = right;
                }
            }
        }
```

#### AUTO 


```{c}
const auto hasSameLineDrawStatus = [&](int column) {
                return LineBlockCharacters::canDraw(image[display->loc(column, y)].character) == lineDraw;
            };
```

#### RANGE FOR STATEMENT 


```{c}
for (const Filter::HotSpot *spot : spots) {
        urlNumber += urlNumInc;

        QRegion region;
        if (spot->type() == Filter::HotSpot::Link) {
            QRect r;
            if (spot->startLine() == spot->endLine()) {
                r.setCoords(spot->startColumn()*_fontWidth + _contentRect.left(),
                            spot->startLine()*_fontHeight + _contentRect.top(),
                            (spot->endColumn())*_fontWidth + _contentRect.left() - 1,
                            (spot->endLine() + 1)*_fontHeight + _contentRect.top() - 1);
                region |= r;
            } else {
                r.setCoords(spot->startColumn()*_fontWidth + _contentRect.left(),
                            spot->startLine()*_fontHeight + _contentRect.top(),
                            (_columns)*_fontWidth + _contentRect.left() - 1,
                            (spot->startLine() + 1)*_fontHeight + _contentRect.top() - 1);
                region |= r;
                for (int line = spot->startLine() + 1 ; line < spot->endLine() ; line++) {
                    r.setCoords(0 * _fontWidth + _contentRect.left(),
                                line * _fontHeight + _contentRect.top(),
                                (_columns)*_fontWidth + _contentRect.left() - 1,
                                (line + 1)*_fontHeight + _contentRect.top() - 1);
                    region |= r;
                }
                r.setCoords(0 * _fontWidth + _contentRect.left(),
                            spot->endLine()*_fontHeight + _contentRect.top(),
                            (spot->endColumn())*_fontWidth + _contentRect.left() - 1,
                            (spot->endLine() + 1)*_fontHeight + _contentRect.top() - 1);
                region |= r;
            }

            if (_showUrlHint && urlNumber < 10) {
                // Position at the beginning of the URL
                QRect hintRect(*region.begin());
                hintRect.setWidth(r.height());
                painter.fillRect(hintRect, QColor(0, 0, 0, 128));
                painter.setPen(Qt::white);
                painter.drawRect(hintRect.adjusted(0, 0, -1, -1));
                painter.drawText(hintRect, Qt::AlignCenter, QString::number(urlNumber));
            }
        }

        for (int line = spot->startLine() ; line <= spot->endLine() ; line++) {
            int startColumn = 0;
            int endColumn = _columns - 1; // TODO use number of _columns which are actually
            // occupied on this line rather than the width of the
            // display in _columns

            // Check image size so _image[] is valid (see makeImage)
            if (endColumn >= _columns || line >= _lines) {
                break;
            }

            // ignore whitespace at the end of the lines
            while (_image[loc(endColumn, line)].isSpace() && endColumn > 0) {
                endColumn--;
            }

            // increment here because the column which we want to set 'endColumn' to
            // is the first whitespace character at the end of the line
            endColumn++;

            if (line == spot->startLine()) {
                startColumn = spot->startColumn();
            }
            if (line == spot->endLine()) {
                endColumn = spot->endColumn();
            }

            // TODO: resolve this comment with the new margin/center code
            // subtract one pixel from
            // the right and bottom so that
            // we do not overdraw adjacent
            // hotspots
            //
            // subtracting one pixel from all sides also prevents an edge case where
            // moving the mouse outside a link could still leave it underlined
            // because the check below for the position of the cursor
            // finds it on the border of the target area
            QRect r;
            r.setCoords(startColumn * _fontWidth + _contentRect.left(),
                        line * _fontHeight + _contentRect.top(),
                        endColumn * _fontWidth + _contentRect.left() - 1,
                        (line + 1)*_fontHeight + _contentRect.top() - 1);
            // Underline link hotspots
            if (spot->type() == Filter::HotSpot::Link) {
                QFontMetrics metrics(font());

                // find the baseline (which is the invisible line that the characters in the font sit on,
                // with some having tails dangling below)
                const int baseline = r.bottom() - metrics.descent();
                // find the position of the underline below that
                const int underlinePos = baseline + metrics.underlinePos();
                if (_showUrlHint || region.contains(mapFromGlobal(QCursor::pos()))) {
                    painter.drawLine(r.left() , underlinePos ,
                                     r.right() , underlinePos);
                }

                // Marker hotspots simply have a transparent rectangular shape
                // drawn on top of them
            } else if (spot->type() == Filter::HotSpot::Marker) {
                //TODO - Do not use a hardcoded color for this
                const bool isCurrentResultLine = (_screenWindow->currentResultLine() == (spot->startLine() + _screenWindow->currentLine()));
                QColor color = isCurrentResultLine ? QColor(255, 255, 0, 120) : QColor(255, 0, 0, 120);
                painter.fillRect(r, color);
            }
        }
    }
```

#### AUTO 


```{c}
auto *separator = new QAction(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& jsonSplitter : jsonTabs) {
        auto topLevelSplitter = restoreSessionsSplitterRecurse(jsonSplitter.toObject(), this, true);
        _viewContainer->addSplitter(topLevelSplitter, _viewContainer->count());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        return getBackgroundColor();
    }
```

#### AUTO 


```{c}
const auto generatorName    = generator.left(sepPos);
```

#### AUTO 


```{c}
const auto item = priv->model->itemFromIndex(sourceIdx);
```

#### AUTO 


```{c}
auto page
```

#### AUTO 


```{c}
auto removedLines = _history->reflowLines(new_columns, &deltas);
```

#### AUTO 


```{c}
const auto mode = action->data().toInt();
```

#### AUTO 


```{c}
const auto colsSuffix = ki18ncp("Suffix of the number of rows (N rows)", " row", " rows");
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *mainWindowWidget : widgets) {
            auto *mainWindow = qobject_cast<MainWindow *>(mainWindowWidget);
            if ((mainWindow != nullptr) && mainWindow != this) {
                syncActiveShortcuts(mainWindow->actionCollection(), actionCollection());
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto **statusIcon: statusIcons) {
        *statusIcon = new QLabel(this);
        (*statusIcon)->setAlignment(Qt::AlignCenter);
        (*statusIcon)->setFixedSize(20, 20);
        (*statusIcon)->setVisible(false);

        m_boxLayout->addWidget(*statusIcon);
    }
```

#### AUTO 


```{c}
auto backgroundTimer = new QTimer(session());
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool) {
        const auto message = xi18nc("@info:tooltip",
                                    "When using this option, the scrollback data will be written unencrypted to temporary files. Those temporary files will be "
                                    "deleted automatically when Konsole is closed in a normal manner.<nl/>Use <emphasis>Settings ? Configure Konsole ? File "
                                    "Location</emphasis> to select the location of the temporary files.");
        const QPoint pos = QPoint(_ui->unlimitedHistoryWrapper->width() / 2, _ui->unlimitedHistoryWrapper->height());
        QWhatsThis::showText(_ui->unlimitedHistoryWrapper->mapToGlobal(pos), message, _ui->unlimitedHistoryWrapper);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (TerminalDisplay *display : _views) {
            if (display->hasFocus()) {
                hasFocus = true;
                break;
            }
        }
```

#### AUTO 


```{c}
const auto rowsSuffix = ki18ncp("Suffix of the number of rows (N rows). The leading space is needed to separate it from the number value.", " row", " rows");
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *l: qAsConst(_layouts)) {
            int left = getLeftMargin(l);
            l->setColumnMinimumWidth(LABELS_COLUMN, maxRight - left);
        }
```

#### AUTO 


```{c}
auto controller = terminalAt(_contextMenuTabIndex)->sessionController();
```

#### AUTO 


```{c}
const auto fgid = _shellProcess->foregroundProcessGroup();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            unpreview(Profile::Font);
            const QFont font = _profile->font();
            updateFontPreview(font);
        }
```

#### AUTO 


```{c}
auto newProfile = Profile::Ptr(new Profile(ProfileManager::instance()->fallbackProfile()));
```

#### AUTO 


```{c}
auto *curr_line = getCharacterBuffer(curr_linelen);
```

#### AUTO 


```{c}
auto &flag = _lineDatas.back().flag;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QRect &rect : region) {
            paint.fillRect(rect, dimColor);
        }
```

#### AUTO 


```{c}
auto findByName = [this, suffix](const QString &name) {
        return std::find_if(_profiles.cbegin(), _profiles.cend(), [&name, suffix](const Profile::Ptr &p) {
            return p->name() == name //
                || (p->name() + suffix) == name; // For backwards compatibility
        });
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &option : qAsConst(kdeProblematicOptions)) {
        if (arguments.contains(option)) {
            return true;
        }
    }
```

#### CONST EXPRESSION 


```{c}
friend constexpr bool operator==(const CharacterColor &a, const CharacterColor &b);
```

#### LAMBDA EXPRESSION 


```{c}
[](double v) { return 50.0 - qAbs(v - 50.0); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](int idx) {
        Q_EMIT detachTab(idx);
    }
```

#### AUTO 


```{c}
const auto message =
            xi18nc("@info:tooltip",
                   "When using this option, the scrollback data will be written unencrypted to temporary files. Those temporary files will be "
                   "deleted automatically when Konsole is closed in a normal manner.<nl/>Use <emphasis>Settings ? Configure Konsole ? Temporary "
                   "Files</emphasis> to select the location of the temporary files.");
```

#### LAMBDA EXPRESSION 


```{c}
[filename](const QString &s) { return filename.startsWith(s); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &p : params) {
            int eq = p.indexOf(QLatin1Char('='));
            if (eq > 0) {
                QString var = p.mid(0, eq);
                QString val = p.mid(eq + 1);
                if (var == QLatin1String("inline")) {
                    if (val != QLatin1String("1")) {
                        return;
                    }
                }
                if (var == QLatin1String("preserveAspectRatio")) {
                    if (val == QLatin1String("0")) {
                        keepAspect = 0;
                    }
                }
                if (var == QLatin1String("doNotMoveCursor")) {
                    if (val == QLatin1String("1")) {
                        moveCursor = false;
                    }
                }
                if (var == QLatin1String("width")) {
                    int unitPos = val.toStdString().find_first_not_of("0123456789");
#if QT_VERSION >= QT_VERSION_CHECK(6, 0, 0)
                    scaledWidth = QStringView(val).mid(0, unitPos).toInt();
#else
                    scaledWidth = val.midRef(0, unitPos).toInt();
#endif
                    if (unitPos == -1) {
                        scaledWidth *= _currentScreen->currentTerminalDisplay()->terminalFont()->fontWidth();
                    } else {
                        if (val.mid(unitPos) == QLatin1String("%")) {
                            scaledWidth *= _currentScreen->currentTerminalDisplay()->terminalFont()->fontWidth() * _currentScreen->getColumns() / 100;
                        }
                    }
                }
                if (var == QLatin1String("height")) {
                    int unitPos = val.toStdString().find_first_not_of("0123456789");
#if QT_VERSION >= QT_VERSION_CHECK(6, 0, 0)
                    scaledHeight = QStringView(val).mid(0, unitPos).toInt();
#else
                    scaledHeight = val.midRef(0, unitPos).toInt();
#endif
                    if (unitPos == -1) {
                        scaledHeight *= _currentScreen->currentTerminalDisplay()->terminalFont()->fontHeight();
                    } else {
                        if (val.mid(unitPos) == QLatin1String("%")) {
                            scaledHeight *= _currentScreen->currentTerminalDisplay()->terminalFont()->fontHeight() * _currentScreen->getLines() / 100;
                        }
                    }
                }
            }
        }
```

#### AUTO 


```{c}
auto options = QVector<QCommandLineOption> {
        { { QStringLiteral("profile") },
            i18nc("@info:shell", "Name of profile to use for new Konsole instance"),
            QStringLiteral("name")
        },
        { { QStringLiteral("fallback-profile") },
            i18nc("@info:shell", "Use the internal FALLBACK profile")
        },
        { { QStringLiteral("workdir") },
            i18nc("@info:shell", "Set the initial working directory of the new tab or window to 'dir'"),
            QStringLiteral("dir")
        },
        { { QStringLiteral("hold"), QStringLiteral("noclose") },
           i18nc("@info:shell", "Do not close the initial session automatically when it ends.")
        },
        {  {QStringLiteral("new-tab") },
            i18nc("@info:shell", "Create a new tab in an existing window rather than creating a new window")
        },
        { { QStringLiteral("tabs-from-file") },
            i18nc("@info:shell","Create tabs as specified in given tabs configuration"" file"),
            QStringLiteral("file")
        },
        { { QStringLiteral("background-mode") },
            i18nc("@info:shell", "Start Konsole in the background and bring to the front when Ctrl+Shift+F12 (by default) is pressed")
        },
        { { QStringLiteral("separate"), QStringLiteral("nofork") },
            i18nc("@info:shell", "Run in a separate process")
        },
        { { QStringLiteral("show-menubar") },
            i18nc("@info:shell", "Show the menubar, overriding the default setting")
        },
        { { QStringLiteral("hide-menubar") },
            i18nc("@info:shell", "Hide the menubar, overriding the default setting")
        },
        { { QStringLiteral("show-tabbar") },
            i18nc("@info:shell", "Show the tabbar, overriding the default setting")
        },
        { { QStringLiteral("hide-tabbar") },
            i18nc("@info:shell", "Hide the tabbar, overriding the default setting")
        },
        { { QStringLiteral("fullscreen") },
            i18nc("@info:shell", "Start Konsole in fullscreen mode")
        },
        { { QStringLiteral("notransparency") },
            i18nc("@info:shell", "Disable transparent backgrounds, even if the system supports them.")
        },
        { { QStringLiteral("list-profiles") },
            i18nc("@info:shell", "List the available profiles")
        },
        { { QStringLiteral("list-profile-properties") },
            i18nc("@info:shell", "List all the profile properties names and their type (for use with -p)")
        },
        { { QStringLiteral("p") },
            i18nc("@info:shell", "Change the value of a profile property."),
            QStringLiteral("property=value")
        },
        { { QStringLiteral("e") },
            i18nc("@info:shell", "Command to execute. This option will catch all following arguments, so use it as the last option."),
            QStringLiteral("cmd")
        }
    };
```

#### LAMBDA EXPRESSION 


```{c}
[newProfile]() {
        ProfileManager::instance()->addProfile(newProfile);
        ProfileManager::instance()->changeProfile(newProfile, newProfile->setProperties());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &hotSpot : hotSpots()) {
        QRect r;
        r.setLeft(hotSpot->startColumn());
        r.setTop(hotSpot->startLine());
        if (hotSpot->startLine() == hotSpot->endLine()) {
            r.setRight(hotSpot->endColumn());
            r.setBottom(hotSpot->endLine());
            region |= _terminalDisplay->imageToWidget(r);
        } else {
            r.setRight(_terminalDisplay->columns());
            r.setBottom(hotSpot->startLine());
            region |= _terminalDisplay->imageToWidget(r);

            r.setLeft(0);

            for (int line = hotSpot->startLine() + 1 ; line < hotSpot->endLine(); line++) {
                r.moveTop(line);
                region |= _terminalDisplay->imageToWidget(r);
            }

            r.moveTop(hotSpot->endLine());
            r.setRight(hotSpot->endColumn());
            region |= _terminalDisplay->imageToWidget(r);
        }
    }
```

#### AUTO 


```{c}
const auto rightSize = rightWidget ? rightWidget->sizeHint() : QSize(0, 0);
```

#### RANGE FOR STATEMENT 


```{c}
for (SessionController *controller : qAsConst(_allControllers)) {
        if ( (controller->profileDialogPointer() != nullptr)
             && controller->profileDialogPointer()->isVisible()
             && (controller->profileDialogPointer()->lookupProfile()
                 == SessionManager::instance()->sessionProfile(_session)) ) {
            controller->profileDialogPointer()->close();
        }
    }
```

#### AUTO 


```{c}
auto* terminalPart = factory->create<KParts::Part>(this);
```

#### AUTO 


```{c}
auto *currentDisplay = viewSplitter->findChild<TerminalDisplay*>();
```

#### RANGE FOR STATEMENT 


```{c}
for( auto *filter : _filters) {
        filter->process();
    }
```

#### AUTO 


```{c}
const auto options = QVector<QCommandLineOption>{
        {{QStringLiteral("profile")}, i18nc("@info:shell", "Name of profile to use for new Konsole instance"), QStringLiteral("name")},
        {{QStringLiteral("layout")}, i18nc("@info:shell", "json layoutfile to be loaded to use for new Konsole instance"), QStringLiteral("file")},
        {{QStringLiteral("fallback-profile")}, i18nc("@info:shell", "Use the internal FALLBACK profile")},
        {{QStringLiteral("workdir")}, i18nc("@info:shell", "Set the initial working directory of the new tab or window to 'dir'"), QStringLiteral("dir")},
        {{QStringLiteral("hold"), QStringLiteral("noclose")}, i18nc("@info:shell", "Do not close the initial session automatically when it ends.")},
        // BR: 373440
        {{QStringLiteral("new-tab")}, i18nc("@info:shell", "Create a new tab in an existing window rather than creating a new window ('Run all Konsole windows in a single process' must be enabled)")},
        {{QStringLiteral("tabs-from-file")}, i18nc("@info:shell", "Create tabs as specified in given tabs configuration file"), QStringLiteral("file")},
        {{QStringLiteral("background-mode")},
         i18nc("@info:shell", "Start Konsole in the background and bring to the front when Ctrl+Shift+F12 (by default) is pressed")},
        {{QStringLiteral("separate"), QStringLiteral("nofork")}, i18nc("@info:shell", "Run in a separate process")},
        {{QStringLiteral("show-menubar")}, i18nc("@info:shell", "Show the menubar, overriding the default setting")},
        {{QStringLiteral("hide-menubar")}, i18nc("@info:shell", "Hide the menubar, overriding the default setting")},
        {{QStringLiteral("show-tabbar")}, i18nc("@info:shell", "Show the tabbar, overriding the default setting")},
        {{QStringLiteral("hide-tabbar")}, i18nc("@info:shell", "Hide the tabbar, overriding the default setting")},
        {{QStringLiteral("fullscreen")}, i18nc("@info:shell", "Start Konsole in fullscreen mode")},
        {{QStringLiteral("notransparency")}, i18nc("@info:shell", "Disable transparent backgrounds, even if the system supports them.")},
        {{QStringLiteral("list-profiles")}, i18nc("@info:shell", "List the available profiles")},
        {{QStringLiteral("list-profile-properties")}, i18nc("@info:shell", "List all the profile properties names and their type (for use with -p)")},
        {{QStringLiteral("p")}, i18nc("@info:shell", "Change the value of a profile property."), QStringLiteral("property=value")},
        {{QStringLiteral("e")},
         i18nc("@info:shell", "Command to execute. This option will catch all following arguments, so use it as the last option."),
         QStringLiteral("cmd")}};
```

#### AUTO 


```{c}
auto newScheme = new ColorScheme(scheme);
```

#### AUTO 


```{c}
auto *new_line = getCharacterBuffer(curr_linelen + next_linelen);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QRect &rect : region) {
        dirtyImageRegion += widgetToImage(rect);
        emit drawBackground(paint, rect, _terminalColor->backgroundColor(), true /* use opacity setting */);
    }
```

#### AUTO 


```{c}
auto *historyItem
```

#### AUTO 


```{c}
auto match = std::find_if(_currentDirContents.cbegin(), _currentDirContents.cend(),
                                [filename](const QString &s) { return filename.startsWith(s); });
```

#### RANGE FOR STATEMENT 


```{c}
for (const int width : qAsConst(widthsSortOrder)) {
        const auto currentMergedRangesIt = mergedRanges.find(width);
        if (currentMergedRangesIt == mergedRanges.end() || currentMergedRangesIt.value().isEmpty())
            continue;
        for (const auto &range : currentMergedRangesIt.value()) {
            if (range.first != range.second)
                out << QString::asprintf("%06X..%06X ; %2d\n", range.first, range.second, int(width));
            else
                out << QString::asprintf("%06X         ; %2d\n", range.first, int(width));
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        if (viewManager()) { viewManager()->saveLayoutFile(); }
    }
```

#### AUTO 


```{c}
auto entries = fallback->entries();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Session *s : sessionsList) {
                    const QList<TerminalDisplay *> displayList = s->views();
                    for (const QPointer<TerminalDisplay> display : displayList) {
                        usedExtendedChars += display->screenWindow()->screen()->usedExtendedChars();
                    }
                }
```

#### AUTO 


```{c}
const auto foregroundAlpha = foreground.alphaF();
```

#### AUTO 


```{c}
const auto inverseForegroundAlpha = 1.0 - foregroundAlpha;
```

#### AUTO 


```{c}
auto reflowFile = std::make_unique<HistoryFile>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &searchProvider : searchProviders) {
                action = new QAction(searchProvider, _webSearchMenu);
                action->setIcon(QIcon::fromTheme(filterData.iconNameForPreferredSearchProvider(searchProvider)));
                action->setData(filterData.queryForPreferredSearchProvider(searchProvider));
                connect(action, &QAction::triggered, this, &Konsole::SessionController::handleWebShortcutAction);
                _webSearchMenu->addAction(action);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto *layout: qAsConst(_layouts)) {
        QWidget *widget = layout->parentWidget();
        Q_ASSERT(widget);
        do {
            QLayout *widgetLayout = widget->layout();
            if (widgetLayout != nullptr) {
                widgetLayout->update();
                widgetLayout->activate();
            }
            widget = widget->parentWidget();
        } while (widget != _refWidget && widget != nullptr);
    }
```

#### AUTO 


```{c}
const auto hasSameWidth = [&](int column) {
                    const int characterLoc = qMin(loc(column, y) + 1, _display->_imageSize - 1);
                    return (_display->_image[characterLoc].character == 0) == doubleWidth;
                };
```

#### AUTO 


```{c}
auto localPos = currentDragTarget->mapFromParent(ev->pos());
```

#### AUTO 


```{c}
auto *mimeData = new QMimeData();
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto dropWidget : _containers) {
        if (dropWidget->rect().contains(dropWidget->mapFromGlobal(currentPos))) {
            if (dropWidget != parent()) {
                return true;
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&](int column) {
                const int characterLoc = qMin(display->loc(column, y) + 1, imageSize - 1);
                return (image[characterLoc].character == 0) == doubleWidth;
            }
```

#### AUTO 


```{c}
auto *currentDisplay = qobject_cast<TerminalDisplay*>(activeContainer->currentWidget());
```

#### AUTO 


```{c}
auto neu = popup->actions();
```

#### AUTO 


```{c}
auto* copyInputToSelectedTabsAction = collection->add<KToggleAction>(QStringLiteral("copy-input-to-selected-tabs"));
```

#### LAMBDA EXPRESSION 


```{c}
[this] { closeTerminalTab(_contextMenuTabIndex); }
```

#### AUTO 


```{c}
auto *dialog = new HistorySizeDialog(QApplication::activeWindow());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &item : items) {
        result << expand(item);
    }
```

#### AUTO 


```{c}
const auto l1 = wcag20RelativeLuminosity(c1)+0.05, l2 = wcag20RelativeLuminosity(c2)+0.05;
```

#### AUTO 


```{c}
const auto rowsSuffix = ki18ncp("Suffix of the number of columns (N columns)", " column", " columns");
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *element : elements) {
        element->setEnabled(!isImported);
    }
```

#### AUTO 


```{c}
auto focusedWidget = qobject_cast<TerminalDisplay*>(focusWidget());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QPointer<TerminalDisplay> display : displayList) {
                        usedExtendedChars += display->screenWindow()->screen()->usedExtendedChars();
                    }
```

#### LAMBDA EXPRESSION 


```{c}
[mainWindow] {
        mainWindow->newTab();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool focused) {
        if (focused) {
            interactionHandler();
        }
    }
```

#### AUTO 


```{c}
const auto x = parentSize.width() - width;
```

#### AUTO 


```{c}
auto terminal = qobject_cast<TerminalDisplay*>(targetSplitter->widget(0));
```

#### AUTO 


```{c}
auto profile = SessionManager::instance()->sessionProfile(activeSession);
```

#### AUTO 


```{c}
auto setNewLine = [](reflowData &change, int index, LineProperty flag) {
        change.index.push_back(index);
        change.flags.push_back(flag);
    };
```

#### AUTO 


```{c}
auto *listHeader = profileListView->header();
```

#### LAMBDA EXPRESSION 


```{c}
[properties]{
        auto controller = qobject_cast<SessionController*>(properties);
        controller->closeSession();
    }
```

#### AUTO 


```{c}
auto backgroundTimer = new QTimer(_session);
```

#### LAMBDA EXPRESSION 


```{c}
[path, job, openUrl]() {
            if (job->error() != 0) {
                // TODO: use KMessageWidget (like the "terminal is read-only" message)
                KMessageBox::sorry(QApplication::activeWindow(),
                                   i18n("Could not open file with the text editor specified in the profile settings;\n"
                                        "it will be opened with the system default editor."));

                openUrl(path);
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            unpreview(Profile::Font);
            updateFontPreview(_profile->font());
        }
```

#### AUTO 


```{c}
auto controller = dynamic_cast<SessionController*>(item);
```

#### AUTO 


```{c}
auto ucs4 = text.toUcs4();
```

#### AUTO 


```{c}
const auto numStr = QStringView(value).right(1);
```

#### LAMBDA EXPRESSION 


```{c}
[&]{
        tooltipRequested();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *sessionAction : sessionActions) {
            _newTabMenuAction->menu()->addAction(sessionAction);

            auto setActionFont = [sessionAction](bool isBold) {
                QFont actionFont = sessionAction->font();
                actionFont.setBold(isBold);
                sessionAction->setFont(actionFont);
            };

            Profile::Ptr profile = ProfileManager::instance()->defaultProfile();
            if (profile && profile->name() == sessionAction->text().remove(QLatin1Char('&'))) {
                QIcon icon = KIconUtils::addOverlay(QIcon::fromTheme(profile->icon()), QIcon::fromTheme(QStringLiteral("emblem-favorite")), Qt::BottomRightCorner);
                sessionAction->setIcon(icon);
                setActionFont(true);
            } else {
                sessionAction->setIcon(QIcon::fromTheme(profile->icon()));
                setActionFont(false);
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](int index) {
        if (index != -1) {
            widget(index)->setFocus();
        } else {
            deleteLater();
        }
    }
```

#### AUTO 


```{c}
const auto oldGeometry = saveGeometry();
```

#### AUTO 


```{c}
auto *dialog = new EditProfileDialog(this);
```

#### AUTO 


```{c}
auto startPos = text - found;
```

#### AUTO 


```{c}
auto *terminalPart = factory->create<KParts::Part>(this);
```

#### AUTO 


```{c}
auto *childWidget = qobject_cast<QWidget *>(child);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &path : paths) {
        Profile::Ptr profile = loadProfile(path);
        if (profile && !defaultProfileFileName.isEmpty() && path.endsWith(QLatin1Char('/') + defaultProfileFileName)) {
            _defaultProfile = profile;
        }
    }
```

#### AUTO 


```{c}
auto cmdArgIter = CMD_SPLIT_RE.globalMatch(cmd);
```

#### RANGE FOR STATEMENT 


```{c}
for (const PropertyInfo &info : DefaultPropertyNames) {
        Property current = info.property;
        QVariant otherValue = profile->property<QVariant>(current);
        if (current == Name || current == Path) { // These are unique per Profile
            continue;
        }
        if (!differentOnly || property<QVariant>(current) != otherValue) {
            setProperty(current, otherValue);
        }
    }
```

#### AUTO 


```{c}
auto ldrawContents = [this](QPainter &paint, const QRect &rect, bool friendly) {
        emit drawContents(_image, paint, rect, friendly, _imageSize, _bidiEnabled, _fixedFont, _lineProperties);
    };
```

#### AUTO 


```{c}
auto [charLine, charColumn] = getCharacterPosition(ev->position().toPoint(), !_usesMouseTracking);
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        closeCurrentTab();
    }
```

#### AUTO 


```{c}
auto translator = std::unique_ptr<KeyboardTranslator>(new KeyboardTranslator(QStringLiteral("testtranslator")));
```

#### LAMBDA EXPRESSION 


```{c}
[this](){
            this->loadLayout(QStandardPaths::locate(QStandardPaths::GenericDataLocation, QStringLiteral("konsole/2x2-terminals.json"))); }
```

#### AUTO 


```{c}
auto splitview = qobject_cast<ViewSplitter*>(widget(index));
```

#### AUTO 


```{c}
auto *splitter = activeViewSplitter()
```

#### AUTO 


```{c}
auto text = filterRegularExpression().pattern();
```

#### AUTO 


```{c}
auto editAction = _contextPopupMenu->addAction(
        QIcon::fromTheme(QStringLiteral("edit-rename")),
        i18nc("@action:inmenu", "&Configure or Rename Tab..."), this,
        [this]{ renameTab(_contextMenuTabIndex); }
    );
```

#### AUTO 


```{c}
auto buttonBox = new QDialogButtonBox(QDialogButtonBox::Ok|QDialogButtonBox::Cancel);
```

#### AUTO 


```{c}
auto *splitter = qobject_cast<ViewSplitter *>(display->parent());
```

#### LAMBDA EXPRESSION 


```{c}
[&](int column) {
                    return (image[display->loc(column, y)].rendition & ~RE_EXTENDED_CHAR)
                        == (currentRendition & ~RE_EXTENDED_CHAR);
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &spot : spots) {
        QRegion region;
        if (spot->type() == HotSpot::Link || spot->type() == HotSpot::EMailAddress || spot->type() == HotSpot::EscapedUrl) {
            QPair<QRegion, QRect> spotRegion =
                spot->region(td->terminalFont()->fontWidth(), td->terminalFont()->fontHeight(), td->columns(), td->contentRect());
            region = spotRegion.first;
            QRect r = spotRegion.second;

            // TODO: Move this paint code to HotSpot->drawHint();
            // TODO: Fix the Url Hints access from the Profile.
            if (_showUrlHint && spot->type() == HotSpot::Link) {
                if (urlNumber >= 0 && urlNumber < 10) {
                    // Position at the beginning of the URL
                    QRect hintRect(*region.begin());
                    hintRect.setWidth(r.height());
                    painter.fillRect(hintRect, QColor(0, 0, 0, 128));
                    painter.setPen(Qt::white);
                    painter.drawRect(hintRect.adjusted(0, 0, -1, -1));
                    painter.drawText(hintRect, Qt::AlignCenter, QString::number(urlNumber));
                }
                urlNumber += urlNumInc;
            }
        }

        if (spot->startLine() < 0 || spot->endLine() < 0) {
            qDebug() << "ERROR, invalid hotspot:";
            spot->debug();
        }

        for (int line = spot->startLine(); line <= spot->endLine(); line++) {
            int startColumn = 0;
            int endColumn = td->columns() - 1; // TODO use number of _columns which are actually
            // occupied on this line rather than the width of the
            // display in _columns

            // Check image size so _image[] is valid (see makeImage)
            if (endColumn >= td->columns() || line >= td->lines()) {
                break;
            }

            // ignore whitespace at the end of the lines
            while (td->getCursorCharacter(endColumn, line).isSpace() && endColumn > 0) {
                endColumn--;
            }

            // increment here because the column which we want to set 'endColumn' to
            // is the first whitespace character at the end of the line
            endColumn++;

            if (line == spot->startLine()) {
                startColumn = spot->startColumn();
            }
            if (line == spot->endLine()) {
                endColumn = spot->endColumn();
            }

            // TODO: resolve this comment with the new margin/center code
            // subtract one pixel from
            // the right and bottom so that
            // we do not overdraw adjacent
            // hotspots
            //
            // subtracting one pixel from all sides also prevents an edge case where
            // moving the mouse outside a link could still leave it underlined
            // because the check below for the position of the cursor
            // finds it on the border of the target area
            QRect r;
            r.setCoords(startColumn * td->terminalFont()->fontWidth() + td->contentRect().left(),
                        line * td->terminalFont()->fontHeight() + td->contentRect().top(),
                        endColumn * td->terminalFont()->fontWidth() + td->contentRect().left() - 1,
                        (line + 1) * td->terminalFont()->fontHeight() + td->contentRect().top() - 1);

            // Underline link hotspots
            // TODO: Fix accessing the urlHint here.
            // TODO: Move this code to UrlFilterHotSpot.
            const bool hasMouse = region.contains(td->mapFromGlobal(QCursor::pos()));
            if ((spot->type() == HotSpot::Link && _showUrlHint) || hasMouse) {
                QFontMetrics metrics(td->font());

                // find the baseline (which is the invisible line that the characters in the font sit on,
                // with some having tails dangling below)
                const int baseline = r.bottom() - metrics.descent();
                // find the position of the underline below that
                const int underlinePos = baseline + metrics.underlinePos();
                painter.drawLine(r.left(), underlinePos, r.right(), underlinePos);

                // Marker hotspots simply have a transparent rectangular shape
                // drawn on top of them
            } else if (spot->type() == HotSpot::Marker) {
                // TODO - Do not use a hardcoded color for this
                const bool isCurrentResultLine = (td->screenWindow()->currentResultLine() == (spot->startLine() + td->screenWindow()->currentLine()));
                QColor color = isCurrentResultLine ? QColor(255, 255, 0, 120) : QColor(255, 0, 0, 120);
                painter.fillRect(r, color);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *widget : qAsConst(_registeredWidgets)) {
        widget->addAction(action);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (int& size : containerSizes) {
        size += perContainerDelta;
    }
```

#### AUTO 


```{c}
auto *advancedPageWidget = new QWidget(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            Q_EMIT finished(this);
        }
```

#### AUTO 


```{c}
auto display = new TerminalDisplay(nullptr);
```

#### AUTO 


```{c}
auto entry = translator->findEntry(Qt::Key_Backspace, nullptr);
```

#### AUTO 


```{c}
auto currentWidget = viewSplitterAt(currentIndex);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                return usedExtendedChars();
            }
```

#### AUTO 


```{c}
auto *selectionMenu = manager->createSchemeSelectionMenu(scheme, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto entry : changedEntries) {
        switch (entry.status()) {
        case KNS3::Entry::Installed:
            for (const auto &file : entry.installedFiles()) {
                if (ColorSchemeManager::instance()->loadColorScheme(file)) {
                    continue;
                }
                qWarning() << "Failed to load file" << file;
                ++failures;
            }
            if (failures == entry.installedFiles().size()) {
                _ui->colorSchemeMessageWidget->setText(
                            xi18nc("@info",
                                   "Scheme <resource>%1</resource> failed to load.",
                                   entry.name()));
                _ui->colorSchemeMessageWidget->animatedShow();
                QTimer::singleShot(8000,
                                   _ui->colorSchemeMessageWidget,
                                   &KMessageWidget::animatedHide);
            }
            break;
        case KNS3::Entry::Deleted:
            for (const auto &file : entry.uninstalledFiles()) {
                if (ColorSchemeManager::instance()->unloadColorScheme(file)) {
                    continue;
                }
                qWarning() << "Failed to unload file" << file;
                // If unloading fails we do not care. Iff the scheme failed here
                // it either wasn't loaded or was invalid to begin with.
            }
            break;
        case KNS3::Entry::Invalid:
        case KNS3::Entry::Installing:
        case KNS3::Entry::Downloadable:
        case KNS3::Entry::Updateable:
        case KNS3::Entry::Updating:
            // Not interesting.
            break;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](CharacterProperties &prop, const GenericWidthEntry &entry) {
                                             prop.customWidth = entry.width();
                                         }
```

#### AUTO 


```{c}
const auto message = i18nc("@info:whatsthis", "When using this option, the scrollback data will be written unencrypted to temporary files. Those temporary files will be deleted automatically when Konsole is closed in a normal manner.<br/>Use <i>Settings ? Configure Konsole ? File Location</i> to select the location of the temporary files.");
```

#### AUTO 


```{c}
auto behavior = QStyle::RequestSoftwareInputPanel(
                        style()->styleHint(QStyle::SH_RequestSoftwareInputPanel));
```

#### AUTO 


```{c}
auto *profileSettings = new ProfileSettings(confDialog);
```

#### RANGE FOR STATEMENT 


```{c}
for (TerminalDisplay *terminal : displays) {
        Session* session = forgetTerminal(terminal);
        detachedSessions[terminal] = session;
    }
```

#### AUTO 


```{c}
const auto actList = popup->actions();
```

#### AUTO 


```{c}
auto parser = new QCommandLineParser;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QRect &rect : qAsConst(dirtyImageRegion)) {
        drawContents(paint, rect);
    }
```

#### AUTO 


```{c}
auto it = entries.cbegin(), endIt = entries.cend();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { toggleActionsBasedOnState(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& dir : dirs) {
        const QStringList fileNames = QDir(dir).entryList(QStringList() << QStringLiteral("*.profile"));
        for (const QString& file : fileNames) {
            profiles.append(dir + QLatin1Char('/') + file);
        }
    }
```

#### AUTO 


```{c}
auto newSplitter = new ViewSplitter();
```

#### AUTO 


```{c}
const auto isEnabled = ProfileManager::instance()->findFavorites().contains(profile);
```

#### RANGE FOR STATEMENT 


```{c}
for (Session *session : completeGroup) {
            if (newGroup.contains(session) && !currentGroup.contains(session)) {
                _copyToGroup->addSession(session);
            } else if (!newGroup.contains(session) && currentGroup.contains(session)) {
                _copyToGroup->removeSession(session);
            }
        }
```

#### AUTO 


```{c}
auto terminal = qobject_cast<TerminalDisplay*>(currentWidget)
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &option : optionNames) {
        for (const QString &value : parser.values(option)) {
            if (option == QLatin1String("workdir")) {
                m_commandLineArguments.insert(option, QDir(workingDir).absolutePath());
            } else {
                m_commandLineArguments.insert(option, value);
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        const QString homeFolder = QStandardPaths::writableLocation(QStandardPaths::HomeLocation);
        const QString sshFile = QFileDialog::getOpenFileName(this, i18n("SSH Key"), homeFolder + QStringLiteral("/.ssh"));
        if (sshFile.isEmpty()) {
            return;
        }
        ui->sshkey->setText(sshFile);
    }
```

#### AUTO 


```{c}
auto* copyInputActions = collection->add<KSelectAction>(QStringLiteral("copy-input-to"));
```

#### AUTO 


```{c}
auto folder = root->child(i);
```

#### RANGE FOR STATEMENT 


```{c}
for(const QButtonGroup *group: qAsConst(_groups)) {
        auto *enumItem = groupToConfigItemEnum(group);
        if (enumItem == nullptr) {
            continue;
        }
        const auto *currentButton = group->checkedButton();
        if(currentButton == nullptr) {
            continue;
        }
        const int value = buttonToEnumValue(currentButton);
        if(value < 0) {
            continue;
        }

        if (!enumItem->isEqual(value)) {
            enumItem->setValue(value);
            updateConfig = true;
        }
    }
```

#### AUTO 


```{c}
auto name = colorSchemeNameFromPath(filePath);
```

#### AUTO 


```{c}
const auto isInsideDrawArea = [rectRight = rect.right()](int column) {
                return column <= rectRight;
            };
```

#### LAMBDA EXPRESSION 


```{c}
[&](int column) {
                return LineBlockCharacters::canDraw(_image[loc(column, y)].character)
                    == lineDraw;
            }
```

#### AUTO 


```{c}
const auto& option
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &name : names) {
        printf("%s\n", name.toLocal8Bit().constData());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto *buttonGroup: allButtonGroups) {
            if (buttonGroup->objectName().startsWith(ManagedNamePrefix)) {
                add(buttonGroup);
            }
        }
```

#### AUTO 


```{c}
auto splitter = qobject_cast<ViewSplitter*>(view->parentWidget());
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        _terminalColor->visualBell();
    }
```

#### AUTO 


```{c}
auto bookmarkManager = KBookmarkManager::managerForFile(testData, QStringLiteral("KonsoleTest"));
```

#### LAMBDA EXPRESSION 


```{c}
[currUrl](const QUrl &url) {
            return url == currUrl;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Profile::Ptr &groupProfile : profiles) {
            changeProfile(groupProfile, propertyMap, persistent);
        }
```

#### AUTO 


```{c}
auto *terminalDisplay
```

#### RANGE FOR STATEMENT 


```{c}
for (const QRect &rect : region) {
        dirtyImageRegion += widgetToImage(rect);
        drawBackground(paint, rect, getBackgroundColor(), true /* use opacity setting */);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[type](const QSharedPointer<HotSpot> &s) {
                return s->type() == type;
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *currentAction : currentActions) {
        widget->removeAction(currentAction);
    }
```

#### AUTO 


```{c}
const auto tabList = group.readEntry("Tabs", QByteArray("[]"));
```

#### AUTO 


```{c}
auto *splitter = qobject_cast<QSplitter*>(_viewContainer->widget(i));
```

#### AUTO 


```{c}
auto bm = QUrl::fromPercentEncoding(bm_url.toEncoded());
```

#### AUTO 


```{c}
auto explanation = runShell ? QStringLiteral("Output of 'ping localhost' should appear in a terminal below for 5 seconds")
                                : QStringLiteral("Output of 'ping localhost' should appear standalone below for 5 seconds");
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *tabOnlyAction : qAsConst(_multiTabOnlyActions)) {
        tabOnlyAction->setEnabled(count > 1);
    }
```

#### AUTO 


```{c}
const auto hasSameWidth = [&](int column) {
                    const int characterLoc = qMin(display->loc(column, y) + 1, imageSize - 1);
                    return (image[characterLoc].character == 0) == doubleWidth;
                };
```

#### RANGE FOR STATEMENT 


```{c}
for(auto *container : _viewSplitter->containers()) {
            container->setNavigationVisibility(navigationVisibility);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *act : currentActions) {
        addedActions.removeOne(act);
    }
```

#### AUTO 


```{c}
auto *showAllFontsLayout = new QHBoxLayout();
```

#### LAMBDA EXPRESSION 


```{c}
[](qint64 start, qint64 end) {
        return (int)((end - start) / sizeof(Character));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : entry.installedFiles()) {
                if (ColorSchemeManager::instance()->loadColorScheme(file)) {
                    continue;
                }
                qWarning() << "Failed to load file" << file;
                ++failures;
            }
```

#### AUTO 


```{c}
auto controller = dynamic_cast<SessionController*>(properties);
```

#### AUTO 


```{c}
auto *active = qobject_cast<TerminalDisplay*>(currentWidget());
```

#### LAMBDA EXPRESSION 


```{c}
[this]{ Q_EMIT newViewRequest(); }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QButtonGroup *group: qAsConst(_groups)) {
        if (group->checkedButton() == nullptr) {
            continue;
        }
        int value = buttonToEnumValue(group->checkedButton());
        const auto *enumItem = groupToConfigItemEnum(group);

        if (enumItem != nullptr && !enumItem->isEqual(value)) {
            return true;
        }
    }
```

#### AUTO 


```{c}
auto mainWindow = qobject_cast<Konsole::MainWindow *>(controller->view()->topLevelWidget());
```

#### AUTO 


```{c}
auto comment    = match.captured(commentGroupName);
```

#### AUTO 


```{c}
auto newView = createView(session);
```

#### AUTO 


```{c}
const auto contrastBG1 = wcag20Contrast(blend1, initialBG), contrastBG2 = wcag20Contrast(blend2, initialBG);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Session *session : sessionsList) {
        for (TerminalDisplay *terminalDisplay : session->views()) {
            // Searching for already open EditProfileDialog instances
            // for this profile
            profileDialog = terminalDisplay->sessionController()->profileDialogPointer();
            if (profileDialog == nullptr) {
                continue;
            }

            if (profile->name() == profileDialog->lookupProfile()->name()
                && profileDialog->isVisible()) {
                // close opened edit dialog
                profileDialog->close();
            }
        }
    }
```

#### AUTO 


```{c}
const auto &schema
```

#### LAMBDA EXPRESSION 


```{c}
[](const QChar &c) {
        if (c.unicode() <= 0x1F) {
            return QStringLiteral("^%1").arg(QChar(u'@' + c.unicode()));
        } else if (c.unicode() == 0x7F) {
            return QStringLiteral("^?");
        } else if (c.unicode() >= 0x80 && c.unicode() <= 0x9F) {
            return QStringLiteral("^[%1").arg(QChar(u'@' + c.unicode() - 0x80));
        }
        return QString();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QTableWidgetItem *item : selectedItems) {
        if (item->column() == 1) { // Select item at the first column
            item = _ui->keyBindingTable->item(item->row(), 0);
        }

        if (!uniqueList.contains(item)) {
            uniqueList.append(item);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const TerminalDisplay *display) { return display-> hasFocus(); }
```

#### AUTO 


```{c}
auto topLevelSplitter = restoreSessionsSplitterRecurse(jsonSplitter.toObject(), this, true);
```

#### AUTO 


```{c}
auto *editorCombo = _mouseUi->textEditorCombo;
```

#### AUTO 


```{c}
auto *dialog = new CopyInputDialog(view());
```

#### RANGE FOR STATEMENT 


```{c}
for (const Profile::PropertyInfo &info : Profile::DefaultPropertyNames) {
        if (info.group == nullptr) {
            continue;
        }
        if (groupName == nullptr || qstrcmp(groupName, info.group) != 0) {
            group = config.group(info.group);
            groupName = info.group;
        }

        const QString name(QLatin1String(info.name));

        if (group.hasKey(name)) {
            profile->setProperty(info.property, group.readEntry(name, QVariant(info.type)));
        }
    }
```

#### AUTO 


```{c}
const auto canBeGrouped = [&](int column) {
                return _image[loc(column, y)].character <= 0x7e || rtl;
            };
```

#### AUTO 


```{c}
const auto *rightWidget = cornerWidget(Qt::TopRightCorner);
```

#### AUTO 


```{c}
auto newSplitter = new ViewSplitter(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const PropertyInfo &propInfo : DefaultProperties) {
        setProperty(propInfo.property, propInfo.defaultValue);
    }
```

#### AUTO 


```{c}
auto* session = qobject_cast<Session*>(sender());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &groupName : config.groupList()) {
        config.deleteGroup(groupName);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, openAction]{ activate(openAction); }
```

#### AUTO 


```{c}
auto parentSplitter = qobject_cast<ViewSplitter*>(terminalDisplay->parentWidget());
```

#### AUTO 


```{c}
const auto pathForLine = [&](quint8 lineId) -> QPainterPath & {
        Q_ASSERT(getLineType(lineId) != LtNone);
        return getLineType(lineId) == LtHeavy ? heavyPath : lightPath;
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &&size : sizes) {
                size = sharedSize.height();
            }
```

#### AUTO 


```{c}
auto tmp_line = new Character[size];
```

#### AUTO 


```{c}
const auto start = QPoint(terminalDisplay->x(), terminalDisplay->y());
```

#### RANGE FOR STATEMENT 


```{c}
for (Session *session : qAsConst(_sessions)) {
        session->close();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[removing](int i) { return i - removing; }
```

#### LAMBDA EXPRESSION 


```{c}
[this, copyAction] {
        activate(copyAction);
    }
```

#### AUTO 


```{c}
const auto tabsSize = tabBar()->sizeHint();
```

#### AUTO 


```{c}
auto *toplevelSplitter = splitter->getToplevelSplitter();
```

#### AUTO 


```{c}
auto newScreenLines = new ImageLine[new_lines + 1];
```

#### AUTO 


```{c}
auto controller = dynamic_cast<SessionController *>(properties);
```

#### AUTO 


```{c}
const auto sourceIdx = priv->filterModel->mapToSource(ui->commandsTreeView->currentIndex());
```

#### AUTO 


```{c}
auto *maybeSplitter = qobject_cast<ViewSplitter*>(widget(i))
```

#### AUTO 


```{c}
const auto terminalSize = currentWidget() ? currentWidget()->sizeHint() : QSize(0, 0);
```

#### AUTO 


```{c}
auto setActionFontBold = [sessionAction](bool isBold) {
            QFont actionFont = sessionAction->font();
            actionFont.setBold(isBold);
            sessionAction->setFont(actionFont);
        };
```

#### AUTO 


```{c}
const auto rows = profile->property<int>(Profile::TerminalRows);
```

#### AUTO 


```{c}
auto *mousePageWidget = new QWidget(this);
```

#### AUTO 


```{c}
const auto &lineCharacter
```

#### AUTO 


```{c}
auto profilePage = new KPageWidgetItem(new ProfileSettings(confDialog), profilePageName);
```

#### AUTO 


```{c}
auto *plugin = factory->create<IKonsolePlugin>();
```

#### LAMBDA EXPRESSION 


```{c}
[&](int column) {
                    const int characterLoc = qMin(loc(column, y) + 1, _display->_imageSize - 1);
                    return (_display->_image[characterLoc].character == 0) == doubleWidth;
                }
```

#### AUTO 


```{c}
auto values = _screenLines[currentPos].mid(new_columns);
```

#### AUTO 


```{c}
auto session = controller->session();
```

#### AUTO 


```{c}
auto childViewSplitter = qobject_cast<ViewSplitter *>(child);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto c : reallyBigTextForReflow) {
        screen.displayCharacter(c.toLatin1());
    }
```

#### AUTO 


```{c}
auto it = args.begin() + 1;
```

#### AUTO 


```{c}
auto it = list.crbegin(), endIt = list.crend();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *terminaldisplay : terminaldisplayList) {
            ids.append(QString::number(terminaldisplay->sessionController()->session()->sessionId()));
        }
```

#### AUTO 


```{c}
auto newTranslator = new KeyboardTranslator(*editor->translator());
```

#### AUTO 


```{c}
auto &widthFromPropsRule = const_cast<uint8_t &>(props.widthFromPropsRule);
```

#### AUTO 


```{c}
auto sessionController = _currentTerminalDisplay->sessionController();
```

#### AUTO 


```{c}
auto *bellModeModel = new QStringListModel({i18n("System Bell"), i18n("System Notifications"), i18n("Visual Bell"), i18n("Ignore Bell Events")}, this);
```

#### AUTO 


```{c}
auto controller = qobject_cast<SessionController *>(item);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &session : sessionsList) {
        dialog->setWindowTitle(i18n("Save Output From %1", session->title(Session::NameRole)));

        int result = dialog->exec();

        if (result != QDialog::Accepted) {
            continue;
        }

        QUrl url = (dialog->selectedUrls()).at(0);

        if (!url.isValid()) {
            // UI:  Can we make this friendlier?
            KMessageBox::sorry(nullptr, i18n("%1 is an invalid URL, the output could not be saved.", url.url()));
            continue;
        }

        // Save selected URL for next time
        _saveDialogRecentURL = url.adjusted(QUrl::RemoveFilename | QUrl::StripTrailingSlash).toString();
        group.writePathEntry("Recent URLs", _saveDialogRecentURL);

        KIO::TransferJob *job = KIO::put(url,
                                         -1, // no special permissions
                                         // overwrite existing files
                                         // do not resume an existing transfer
                                         // show progress information only for remote
                                         // URLs
                                         KIO::Overwrite | (url.isLocalFile() ? KIO::HideProgressInfo : KIO::DefaultFlags)
                                         // a better solution would be to show progress
                                         // information after a certain period of time
                                         // instead, since the overall speed of transfer
                                         // depends on factors other than just the protocol
                                         // used
        );

        SaveJob jobInfo;
        jobInfo.session = session;
        jobInfo.lastLineFetched = -1; // when each request for data comes in from the KIO subsystem
        // lastLineFetched is used to keep track of how much of the history
        // has already been sent, and where the next request should continue
        // from.
        // this is set to -1 to indicate the job has just been started

        if (((dialog->selectedNameFilter()).contains(QLatin1String("html"), Qt::CaseInsensitive))
            || ((dialog->selectedFiles()).at(0).endsWith(QLatin1String("html"), Qt::CaseInsensitive))) {
            Profile::Ptr profile = SessionManager::instance()->sessionProfile(session);
            jobInfo.decoder = new HTMLDecoder(profile->colorScheme(), profile->font());
        } else {
            jobInfo.decoder = new PlainTextDecoder();
        }

        _jobSession.insert(job, jobInfo);

        connect(job, &KIO::TransferJob::dataReq, this, &Konsole::SaveHistoryTask::jobDataRequested);
        connect(job, &KIO::TransferJob::result, this, &Konsole::SaveHistoryTask::jobResult);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        startImportFromSshConfig();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[parentChildProcModifier = std::move(parentChildProcModifier)]() {
        if (parentChildProcModifier) {
            parentChildProcModifier();
        }

        // reset all signal handlers
        // this ensures that terminal applications respond to
        // signals generated via key sequences such as Ctrl+C
        // (which sends SIGINT)
        struct sigaction action;
        sigemptyset(&action.sa_mask);
        action.sa_handler = SIG_DFL;
        action.sa_flags = 0;
        for (int signal = 1; signal < NSIG; signal++) {
            sigaction(signal, &action, nullptr);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool) {
        kcfg_TabBarUserStyleSheetFile->setEnabled(kcfg_TabBarUseUserStyleSheet->isChecked()
                                                  && !AlwaysHideTabBar->isChecked());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto* elm : old) {
            neu.removeAll(elm);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        const QString tabTitle = dialog->tabTitleText();
        const QString remoteTabTitle = dialog->remoteTabTitleText();
        const QColor tabColor = dialog->color();

        if (tabTitle != sessionLocalTabTitleFormat) {
            session()->setTabTitleFormat(Session::LocalTabTitle, tabTitle);
            Q_EMIT tabRenamedByUser(true);
            // trigger an update of the tab text
            snapshot();
        }

        if(remoteTabTitle != sessionRemoteTabTitleFormat) {
            session()->setTabTitleFormat(Session::RemoteTabTitle, remoteTabTitle);
            Q_EMIT tabRenamedByUser(true);
            snapshot();
        }

        if (tabColor != sessionTabColor) {
            session()->setColor(tabColor);
            Q_EMIT tabColoredByUser(true);
            snapshot();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[rectRight = rect.right()](int column) {
                return column <= rectRight;
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (Session *session : qAsConst(_sessions)) {
            disconnect(session, nullptr, this, nullptr);
        }
```

#### AUTO 


```{c}
static auto re = QRegularExpression(
        /* First part of the regexp means 'strings with spaces and starting with single quotes'
         * Second part means "Strings with double quotes"
         * Last part means "Everything else plus some special chars
         * This is much smaller, and faster, than the previous regexp
         * on the HotSpot creation we verify if this is indeed a file, so there's
         * no problem on testing on random words on the screen.
         */
            QLatin1String("'[^']+'")             // Matches everything between single quotes.
            + QStringLiteral(R"RX(|"[^"]+")RX")      // Matches everything inside double quotes
            + QStringLiteral(R"RX(|[\w%1]+)RX").arg(wordCharacters) // matches a contiguous line of alphanumeric characters plus some special ones defined in the profile.
        ,
        QRegularExpression::DontCaptureOption);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Profile::Ptr &profile : qAsConst(_favorites)) {
        Q_ASSERT(_profiles.contains(profile) && profile);
        paths << normalizePath(profile->path());
    }
```

#### AUTO 


```{c}
auto *manager = new KNSCore::DownloadManager(QStringLiteral("konsole.knsrc"), this);
```

#### AUTO 


```{c}
auto it = std::find_if(allActions.cbegin(), allActions.cend(), [](QAction *action) {
            return action->objectName() == QLatin1String("plugins");
        });
```

#### RANGE FOR STATEMENT 


```{c}
for (const uint i : _decoder->toUnicode(text, length).toUcs4()) {
        receiveChar(i);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *terminalDisplay : tabTterminalDisplays) {
                if (terminalDisplay == historyItem) {
                    terminalDisplay->setFocus(Qt::OtherFocusReason);
                    return;
                }
            }
```

#### AUTO 


```{c}
auto *managerWidget = new SSHManagerTreeWidget();
```

#### AUTO 


```{c}
auto &flag = _flags.back();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QRect &rect : region) {
        dirtyImageRegion += widgetToImage(rect);
        _terminalPainter->drawBackground(paint, rect, _terminalColor->backgroundColor(), true /* use opacity setting */);
    }
```

#### AUTO 


```{c}
const auto & i
```

#### AUTO 


```{c}
const auto &bm_url = groupUrlList.at(i);
```

#### AUTO 


```{c}
const auto pathForLine = [&](quint8 lineId) -> QPainterPath& {
        Q_ASSERT(getLineType(lineId) != LtNone);
        return getLineType(lineId) == LtHeavy ? heavyPath : lightPath;
    };
```

#### AUTO 


```{c}
auto *newBuffer = dynamic_cast<CompactHistoryScroll *>(old.get())
```

#### LAMBDA EXPRESSION 


```{c}
[this, copyAction]{ activate(copyAction); }
```

#### AUTO 


```{c}
const auto enumItem = groupToConfigItemEnum(group);
```

#### AUTO 


```{c}
const auto hasSameLineDrawStatus = [&](int column) {
                return LineBlockCharacters::canDraw(_image[loc(column, y)].character)
                    == lineDraw;
            };
```

#### AUTO 


```{c}
auto match = std::find_if(_currentDirContents.cbegin(), _currentDirContents.cend(), [&filename](const QString &s) {
            return filename == s // It's a direct child file or dir
                || filename.startsWith(s + QLatin1Char{':'}) // filename:lineNumber (output of grep -n)
                || filename.startsWith(s + QLatin1Char{'/'}); // It's inside a child dir
        });
```

#### AUTO 


```{c}
auto state = EditProfileDialog::ExistingProfile;
```

#### AUTO 


```{c}
const auto hasSameRendition = [&](int column) {
                return (image[display->loc(column, y)].rendition & ~RE_EXTENDED_CHAR) == (currentRendition & ~RE_EXTENDED_CHAR);
            };
```

#### AUTO 


```{c}
auto profileSettings = new ProfileSettings(settingsDialog);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &url : _history) {
        url.begin.row -= lines;
        url.end.row -= lines;
   }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        Q_EMIT bellRequest(i18n("Bell in '%1' (Session '%2')", _displayTitle, _nameTitle));
        this->setPendingNotification(Notification::Bell);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool checked) {
        updateTempProfileProperty(Profile::InvertSelectionColors, checked);
    }
```

#### AUTO 


```{c}
auto splitter
```

#### AUTO 


```{c}
auto layout = new QVBoxLayout;
```

#### AUTO 


```{c}
const auto colsSuffix = ki18ncp("Suffix of the number of columns (N columns)", " column", " columns");
```

#### AUTO 


```{c}
auto scrollBackType = profile->property<int>(Profile::HistoryMode);
```

#### AUTO 


```{c}
auto profileIt = std::find_if(_shortcuts.begin(), _shortcuts.end(), [&profile](const ShortcutData &data) {
        return data.profileKey == profile;
    });
```

#### LAMBDA EXPRESSION 


```{c}
[this]{
        if (currentThumbnailHotspot != reinterpret_cast<qintptr>(this)) {
            return;
        }

        thumbnailRequested();
    }
```

#### AUTO 


```{c}
auto tripleClickMode = profile->property<int>(Profile::TripleClickMode);
```

#### RANGE FOR STATEMENT 


```{c}
for(auto tabWidget : currentSplitter->findChildren<TabbedViewContainer*>()) {
        if (tabWidget != myContainer && tabWidget->count()) {
            tabWidget->setCurrentIndex(0);
        }
    }
```

#### AUTO 


```{c}
const auto canBeGrouped = [&](int column) {
                return image[display->loc(column, y)].character <= 0x7e || (image[display->loc(column, y)].rendition & RE_EXTENDED_CHAR)
                    || (bidiEnabled && !doubleWidth);
            };
```

#### AUTO 


```{c}
const auto isBold = [boldWeight](const QFont &font) { return font.weight() >= boldWeight; };
```

#### AUTO 


```{c}
auto controller = splitter->activeTerminalDisplay()->sessionController();
```

#### LAMBDA EXPRESSION 


```{c}
[](QTextStream &, const QVector<CharacterProperties> &, const QVector<CharacterWidth> &,
                               const QMap<QString, QString> &)->bool {return true;}
```

#### AUTO 


```{c}
auto *profilePage = new KPageWidgetItem(new ProfileSettings(confDialog), profilePageName);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &entry : changedEntries) {
        switch (entry.status()) {
        case KNS3::Entry::Installed:
            for (const auto &file : entry.installedFiles()) {
                if (ColorSchemeManager::instance()->loadColorScheme(file)) {
                    continue;
                }
                qWarning() << "Failed to load file" << file;
                ++failures;
            }
            if (failures == entry.installedFiles().size()) {
                _appearanceUi->colorSchemeMessageWidget->setText(
                            xi18nc("@info",
                                   "Scheme <resource>%1</resource> failed to load.",
                                   entry.name()));
                _appearanceUi->colorSchemeMessageWidget->animatedShow();
                QTimer::singleShot(8000,
                                   _appearanceUi->colorSchemeMessageWidget,
                                   &KMessageWidget::animatedHide);
            }
            break;
        case KNS3::Entry::Deleted:
            for (const auto &file : entry.uninstalledFiles()) {
                if (ColorSchemeManager::instance()->unloadColorScheme(file)) {
                    continue;
                }
                qWarning() << "Failed to unload file" << file;
                // If unloading fails we do not care. Iff the scheme failed here
                // it either wasn't loaded or was invalid to begin with.
            }
            break;
        case KNS3::Entry::Invalid:
        case KNS3::Entry::Installing:
        case KNS3::Entry::Downloadable:
        case KNS3::Entry::Updateable:
        case KNS3::Entry::Updating:
            // Not interesting.
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto key: obsoleteKeys) {
        if (configGroup.hasKey(key)) {
            configGroup.deleteEntry(key);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](QAction *action) {
            return action->objectName() == QLatin1String("plugins");
        }
```

#### AUTO 


```{c}
static const auto lightnessWeightsFunc = [](double v) { return 50.0 - qAbs(v - 50.0); };
```

#### AUTO 


```{c}
const auto localInnerRef = match.capturedRef(innerGroupName);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &action : _contextPopupMenu->actions()) {
            if (action->objectName() == QStringLiteral("view-readonly")) {
                _contextPopupMenu->removeAction(action);
                break;
            }
        }
```

#### AUTO 


```{c}
auto p = qApp->palette();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Profile::Ptr &oldProfile : availableProfiles) {
                if (oldProfile->path() == origPath) {
                    // assign the same shortcut of the old profile to
                    // the newly renamed profile
                    const auto oldShortcut = shortcut(oldProfile);
                    if (deleteProfile(oldProfile)) {
                        setShortcut(profile, oldShortcut);
                    }
                }
            }
```

#### AUTO 


```{c}
auto currentTitle = tabBar()->tabText(currentIndex);
```

#### LAMBDA EXPRESSION 


```{c}
[](reflowData &change, int index, LineProperty flag) {
        change.index.append(index);
        change.flags.append(flag);
    }
```

#### AUTO 


```{c}
const auto text = _screenWindow->selectedText(currentDecodingOptions());
```

#### AUTO 


```{c}
auto *focusEvent = static_cast<QFocusEvent *>(event);
```

#### AUTO 


```{c}
auto terminalContainers = _viewContainer->findChildren<TerminalDisplay*>();
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool) {
        const auto message =
            xi18nc("@info:tooltip",
                   "When using this option, the scrollback data will be written unencrypted to temporary files. Those temporary files will be "
                   "deleted automatically when Konsole is closed in a normal manner.<nl/>Use <emphasis>Settings ? Configure Konsole ? Temporary "
                   "Files</emphasis> to select the location of the temporary files.");
        const QPoint pos = QPoint(_ui->unlimitedHistoryWrapper->width() / 2, _ui->unlimitedHistoryWrapper->height());
        QWhatsThis::showText(_ui->unlimitedHistoryWrapper->mapToGlobal(pos), message, _ui->unlimitedHistoryWrapper);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const TerminalDisplay *display: displays) {
        if (display->hasFocus()) {
            hasFocus = true;
            break;
        }
    }
```

#### AUTO 


```{c}
auto scheme = new ColorScheme();
```

#### AUTO 


```{c}
auto *display = qobject_cast<TerminalDisplay *>(view);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto sdsp : _sessionMap) {
        ids.append( QString::number( sdsp->session()->sessionId() ) );
    }
```

#### AUTO 


```{c}
auto splitterTerminal = qobject_cast<TerminalDisplay*>(targetSplitter->widget(0));
```

#### LAMBDA EXPRESSION 


```{c}
[&](int column) {
                const QChar::Script script = QChar::script(baseCodePoint(_image[loc(column, y)]));
                if (currentScript == QChar::Script_Common || script == QChar::Script_Common
                    || currentScript == QChar::Script_Inherited || script == QChar::Script_Inherited) {
                    return true;
                }
                return currentScript == script;
            }
```

#### AUTO 


```{c}
const auto rect = _overlayEdge == Qt::LeftEdge ? QRect(0, y, width() / 2, height())
            : _overlayEdge == Qt::TopEdge              ? QRect(0, y, width(), height() / 2)
            : _overlayEdge == Qt::RightEdge            ? QRect(width() - width() / 2, y, width() / 2, height())
                                                       : QRect(0, height() - height() / 2, width(), height() / 2);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        this->loadLayout(QStandardPaths::locate(QStandardPaths::GenericDataLocation, QStringLiteral("konsole/2x2-terminals.json")));
    }
```

#### AUTO 


```{c}
const auto hasSameWidth = [&](int column) {
                const int characterLoc = qMin(loc(column, y) + 1, _imageSize - 1);
                return (_image[characterLoc].character == 0) == doubleWidth;
            };
```

#### LAMBDA EXPRESSION 


```{c}
[&enable, &collection](const QString& actionName) {
        auto *action = collection->action(actionName);
        if (action != nullptr) {
            action->setEnabled(enable);
        }
    }
```

#### AUTO 


```{c}
const auto finalAlpha = foregroundAlpha + inverseBackgroundAlpha;
```

#### AUTO 


```{c}
auto *widget = new KMessageWidget(text, this);
```

#### AUTO 


```{c}
const auto handleWidth = parentSplitter->handleWidth() <= 1 ? 4 : parentSplitter->handleWidth();
```

#### AUTO 


```{c}
auto shape = profile->property<int>(Profile::CursorShape);
```

#### RANGE FOR STATEMENT 


```{c}
for (const TerminalDisplay *display : qAsConst(_views)) {
        if (display->hasFocus()) {
            hasFocus = true;
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : fileNames) {
            colorschemes.append(dir + QLatin1Char('/') + file);
        }
```

#### AUTO 


```{c}
const auto rowsSuffix = ki18ncp("Suffix of the number of rows (N rows)", " row", " rows");
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &[profile, keySeq] : _shortcuts) {
            shortcutGroup.writeEntry(keySeq.toString(), profile->name());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &sessionName : group.groupList()) {
            SSHConfigurationData data;
            KConfigGroup sessionGroup = group.group(sessionName);
            data.host = sessionGroup.readEntry("hostname");
            data.name = sessionGroup.readEntry("identifier");
            data.port = sessionGroup.readEntry("port");
            data.profileName = sessionGroup.readEntry("profileName");
            data.username = sessionGroup.readEntry("username");
            data.sshKey = sessionGroup.readEntry("sshkey");
            data.useSshConfig = sessionGroup.readEntry<bool>("useSshConfig", false);
            data.importedFromSshConfig = sessionGroup.readEntry<bool>("importedFromSshConfig", false);
            addChildItem(data, groupName);
        }
```

#### AUTO 


```{c}
auto topLevelSplitter = getToplevelSplitter();
```

#### LAMBDA EXPRESSION 


```{c}
[display, triggerText]{
        Q_EMIT display->sendStringToEmu(triggerText);}
```

#### AUTO 


```{c}
auto editAction = _contextPopupMenu->addAction(
        QIcon::fromTheme(QStringLiteral("edit-rename")),
        i18nc("@action:inmenu", "&Current Tab Settings..."), this,
        [this]{ renameTab(_contextMenuTabIndex); }
    );
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { return getVTFont(); }
```

#### LAMBDA EXPRESSION 


```{c}
[&filename](const QString &s) {
                                      return filename == s || // It's a direct child file or dir
                                             filename.startsWith(s + QLatin1Char{'/'}); // It's inside a child dir
                                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &file : entry.installedFiles()) {
                if (ColorSchemeManager::colorSchemeNameFromPath(file) != name) {
                    continue;
                }
                // Make sure the manager can unload it before uninstalling it.
                if (ColorSchemeManager::instance()->unloadColorScheme(file)) {
                    manager->uninstallEntry(entry);
                    uninstalled = true;
                }
            }
```

#### AUTO 


```{c}
auto *container = new TabbedViewContainer(_navigationPosition, this, _viewSplitter);
```

#### LAMBDA EXPRESSION 


```{c}
[this](QPainter &painter, bool friendly) {
        QPoint columnLines(_usedLines, _usedColumns);
        auto lfontget = [this]() { return _terminalFont->getVTFont(); };
        auto lfontset = [this](const QFont &f) { _terminalFont->setVTFont(f); };

        _printManager->printContent(painter, friendly, columnLines, lfontget, lfontset);
    }
```

#### AUTO 


```{c}
const auto displays = topLevelSplitter->findChildren<TerminalDisplay *>();
```

#### CONST EXPRESSION 


```{c}
friend constexpr bool operator!=(const CharacterColor &a, const CharacterColor &b);
```

#### LAMBDA EXPRESSION 


```{c}
[&](const char *key, double value) {
        const bool valueIsNull = qFuzzyCompare(value, 0.0);
        const bool keyExists = configGroup.hasKey(key);
        const bool keyExistsAndHasDifferentValue = !qFuzzyCompare(configGroup.readEntry(key, value),
                                                                  value);
        if ((!valueIsNull && !keyExists) || keyExistsAndHasDifferentValue) {
            configGroup.writeEntry(key, value);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto i : ucs4) {
        w += konsole_wcwidth(i);
    }
```

#### AUTO 


```{c}
auto profileMenu = new QMenu(_newTabButton);
```

#### RANGE FOR STATEMENT 


```{c}
for (int &size : containerSizes) {
        size += perContainerDelta;
    }
```

#### AUTO 


```{c}
auto profile = m_profiles.at(idx.row());
```

#### RANGE FOR STATEMENT 


```{c}
for (HotSpot *spot : hotspots) {
        if (spot->startLine() == line && spot->startColumn() > column) {
            continue;
        }
        if (spot->endLine() == line && spot->endColumn() < column) {
            continue;
        }

        return spot;
    }
```

#### AUTO 


```{c}
auto buttonBox = new QDialogButtonBox(dialog);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &spot : spots) {
            if (spot->type() == HotSpot::Link) {
                urlNumber++;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&](int column) {
                    return LineBlockCharacters::canDraw(_display->_image[loc(column, y)].character)
                        == lineDraw;
                }
```

#### AUTO 


```{c}
auto *tabsPageItem = addPage(tabsPageWidget, tabsPageName);
```

#### AUTO 


```{c}
auto ldrawBackground = [this](QPainter &painter, const QRect &rect, const QColor &backgroundColor, bool useOpacitySetting) {
        Q_EMIT drawBackground(painter, rect, backgroundColor, useOpacitySetting);
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool focused) {_hasCompositeFocus = focused;}
```

#### RANGE FOR STATEMENT 


```{c}
for (const Session *s : sessionsList) {
                        const QList<TerminalDisplay *> displayList = s->views();
                        for (const TerminalDisplay *display : displayList) {
                            usedExtendedChars += display->screenWindow()->screen()->usedExtendedChars();
                        }
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for (TerminalDisplay *view : qAsConst(_views)) {
        if (!view->isHidden() && view->lines() >= VIEW_LINES_THRESHOLD && view->columns() >= VIEW_COLUMNS_THRESHOLD) {
            minLines = (minLines == -1) ? view->lines() : qMin(minLines, view->lines());
            minColumns = (minColumns == -1) ? view->columns() : qMin(minColumns, view->columns());
            view->processFilters();
        }
    }
```

#### AUTO 


```{c}
auto charResult = new Character[text.size()];
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *container : _viewSplitter->containers()) {
        setContainerFeatures(container);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &prop : properties) {
        printf("%s\n", prop.c_str());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]{
        if (_previewJob == nullptr) {
            return;
        }
        if (!_thumbnailFinished) {
            QToolTip::showText(_thumbnailPos, i18n("Generating Thumbnail"), qApp->focusWidget());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (TerminalDisplay* view : session()->views()) {
        if (view != _view.data()) {
            view->updateReadOnlyState(isReadOnly());
        }
    }
```

#### AUTO 


```{c}
const auto spots = _filterChain->hotSpots();
```

#### LAMBDA EXPRESSION 


```{c}
[](reflowData &change, qint64 index, LineProperty lineflag) {
        change.index = index;
        change.lineFlag = lineflag;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const TerminalDisplay *terminalDisplay : views) {
        // ... and check whether a TerminalDisplay has the same
        // window as given in the parameter
        if (window == findWindow(terminalDisplay)) {
            return (true);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &range : *currentMergedRangesIt) {
            Q_ASSERT(range.first <= LAST_CODE_POINT);
            Q_ASSERT(range.second <= LAST_CODE_POINT);
            currentLut.append(Var(Var::Map{{QStringLiteral("first"), range.first}, {QStringLiteral("last"), range.second}}));
        }
```

#### AUTO 


```{c}
auto enableAction = [&enable, &collection](const QString &actionName) {
        auto *action = collection->action(actionName);
        if (action != nullptr) {
            action->setEnabled(enable);
        }
    };
```

#### LAMBDA EXPRESSION 


```{c}
[&](int column) {
                const QChar::Script script = QChar::script(baseCodePoint(image[display->loc(column, y)]));
                if (currentScript == QChar::Script_Common || script == QChar::Script_Common || currentScript == QChar::Script_Inherited
                    || script == QChar::Script_Inherited) {
                    return true;
                }
                return currentScript == script;
            }
```

#### AUTO 


```{c}
auto *viewToDetach = qobject_cast<TerminalDisplay *>(view);
```

#### RANGE FOR STATEMENT 


```{c}
for (const PropertyInfo &info : DefaultPropertyNames) {
        list.push_back(std::string(info.name) + " : " + QVariant(info.type).typeName());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const int i : {0, 1, 64, 127, 128, 215, 255}) {
        const QString name = QString::fromLatin1("color %1").arg(i);
        QTest::newRow(qPrintable(name)) << i << QColor(i >> 16, i >> 8, i);
    }
```

#### AUTO 


```{c}
auto swappedIcon = tabBar()->tabIcon(newIndex);
```

#### AUTO 


```{c}
auto hintSize = viewSplitter->size();
```

#### AUTO 


```{c}
auto *keyboardPageItem = addPage(keyboardPageWidget, keyboardPageName);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Profile::Ptr &profile : qAsConst(_profiles)) {
        if (profile->path() == path) {
            return profile;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto *buttonGroup: allButtonGroups) {
        if (buttonGroup->objectName().startsWith(ManagedNamePrefix)) {
            add(buttonGroup);
        }
    }
```

#### AUTO 


```{c}
auto config = KConfig(QStringLiteral("konsolequickcommandsconfig"), KConfig::OpenFlag::SimpleConfig);
```

#### LAMBDA EXPRESSION 


```{c}
[&](int column) {
                    return LineBlockCharacters::canDraw(_display->_image[_display->loc(column, y)].character)
                        == lineDraw;
                }
```

#### AUTO 


```{c}
auto iter = QMapIterator<QPointer<Session>,ScreenWindowPtr>(_windows);
```

#### AUTO 


```{c}
auto *data = _screenLines[screenLine].data();
```

#### AUTO 


```{c}
auto view = container->terminalAt(i);
```

#### AUTO 


```{c}
auto keySeqIt = std::find_if(_shortcuts.begin(), _shortcuts.end(), [&keySequence, &profile](const ShortcutData &data) {
        return data.profileKey != profile && data.keySeq == keySequence;
    });
```

#### LAMBDA EXPRESSION 


```{c}
[](std::vector<LineData> &change, unsigned int index, LineProperty flag) {
        change.push_back({index, flag});
    }
```

#### AUTO 


```{c}
const auto items = QList<QStandardItem*> {
        new QStandardItem(),
        new QStandardItem(),
        new QStandardItem(),
        new QStandardItem(),
    };
```

#### AUTO 


```{c}
const auto contrast1 = wcag20Contrast(fg, blend1), contrast2 = wcag20Contrast(fg, blend2);
```

#### AUTO 


```{c}
auto topLevelSplitter = qobject_cast<ViewSplitter *>(controller->view()->parentWidget())->getToplevelSplitter();
```

#### AUTO 


```{c}
auto child = topSplitter->childAt(newPoint);
```

#### RANGE FOR STATEMENT 


```{c}
for(const QButtonGroup *group: qAsConst(_groups)) {
            int value = buttonToEnumValue(group->checkedButton());
            const auto *enumItem = groupToConfigItemEnum(group);

            if(enumItem != nullptr && !enumItem->isEqual(value)) {
                return true;
            }
        }
```

#### AUTO 


```{c}
const auto removeLineType = [&packedLineTypes](quint8 lineId) -> void {
        lineId = LinesNum - 1 - lineId % LinesNum;
        packedLineTypes &= ~(3 << (2 * lineId));
    };
```

#### AUTO 


```{c}
auto *sWindow = _window->screenWindow();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : fileNames) {
            list.append(dir + QLatin1Char('/') + file);
        }
```

#### AUTO 


```{c}
auto currentTerminalDisplay = topLevelSplitter->activeTerminalDisplay();
```

#### AUTO 


```{c}
auto height = sizeHint().height();
```

#### AUTO 


```{c}
auto job = new KIO::CommandLauncherJob(QStringLiteral("kcmshell5"), {QStringLiteral("webshortcuts")});
```

#### AUTO 


```{c}
auto openAction = new QAction(_fileObject);
```

#### AUTO 


```{c}
auto partInfoSettings = new PartInfoSettings(settingsDialog);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                    return usedExtendedChars();
                }
```

#### AUTO 


```{c}
auto it = parts.crbegin(), endIt = parts.crend();
```

#### AUTO 


```{c}
auto lfontget = [this]() { return getVTFont(); };
```

#### LAMBDA EXPRESSION 


```{c}
[this, path, job]() {
        if (job->error() != 0) {
            // TODO: use KMessageWidget (like the "terminal is read-only" message)
            KMessageBox::sorry(QApplication::activeWindow(),
                i18n("Could not open file with the text editor specified in the profile settings;\n"
                     "it will be opened with the system default editor."));

            openWithSysDefaultApp(path);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, container]() {
        containerViewsChanged(container);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (uint cc : chars) {
        if (cc == DEL) {
            continue; // VT100: ignore.
        }

        // early out for displayable characters
        if (getMode(MODE_Ansi) && tokenBufferPos == 0 && cc >= 32 && cc != (ESC + 128)) {
            _currentScreen->displayCharacter(applyCharset(cc));
            continue;
        }

        if (ces(CTL)) {
            // ignore control characters in the text part of osc (aka OSC) "ESC]"
            // escape sequences; this matches what XTERM docs say
            // Allow BEL and ESC here, it will either end the text or be removed later.
            if (osc && cc != 0x1b && cc != 0x07) {
                continue;
            }

            if (!osc) {
                // DEC HACK ALERT! Control Characters are allowed *within* esc sequences in VT100
                // This means, they do neither a resetTokenizer() nor a pushToToken(). Some of them, do
                // of course. Guess this originates from a weakly layered handling of the X-on
                // X-off protocol, which comes really below this level.
                if (cc == CNTL('X') || cc == CNTL('Z') || cc == ESC) {
                    resetTokenizer(); // VT100: CAN or SUB
                }
                if (cc != ESC) {
                    processToken(token_ctl(cc + '@'), 0, 0);
                    continue;
                }
            }
        }
        // advance the state
        addToCurrentToken(cc);

        uint *s = tokenBuffer;
        const int p = tokenBufferPos;

        if (getMode(MODE_Ansi)) {
            if (lec(1, 0, ESC)) {
                continue;
            }
            if (lec(1, 0, ESC + 128)) {
                s[0] = ESC;
                receiveChars(QVector<uint>{'['});
                continue;
            }
            if (les(2, 1, GRP)) {
                continue;
            }
            // Operating System Command
            if (p > 2 && s[1] == ']') {
                // <ESC> ']' ... <ESC> '\'
                if (s[p - 2] == ESC && s[p - 1] == '\\') {
                    // This runs two times per link, the first prepares the link to be read,
                    // the second finalizes it. The escape sequence is in two parts
                    //  start: '\e ] 8 ; <id-path> ; <url-part> \e \\'
                    //  end:   '\e ] 8 ; ; \e \\'
                    // GNU libtextstyle inserts the IDs, for instance; many examples
                    // do not.
                    if (s[2] == XTERM_EXTENDED::URL_LINK) {
                        // printf '\e]8;;https://example.com\e\\This is a link\e]8;;\e\\\n'
                        _currentScreen->urlExtractor()->toggleUrlInput();
                    }
                    processSessionAttributeRequest(p - 1);
                    resetTokenizer();
                    continue;
                }
                // <ESC> ']' ... <ESC> + one character for reprocessing
                if (s[p - 2] == ESC) {
                    processSessionAttributeRequest(p - 1);
                    resetTokenizer();
                    receiveChars(QVector<uint>{cc});
                    continue;
                }
                // <ESC> ']' ... <BEL>
                if (s[p - 1] == 0x07) {
                    processSessionAttributeRequest(p);
                    resetTokenizer();
                    continue;
                }
            }

            /* clang-format off */
        // <ESC> ']' ...
        if (osc         ) { continue; }

        if (p >= 3 && s[1] == '[') { // parsing a CSI sequence
            if (lec(3,2,'?')) { continue; }
            if (lec(3,2,'=')) { continue; }
            if (lec(3,2,'>')) { continue; }
            if (lec(3,2,'!')) { continue; }
            if (lec(3,2,SP )) { continue; }
            if (lec(4,3,SP )) { continue; }
            if (eps(    CPN)) { processToken(token_csi_pn(cc), argv[0],argv[1]);  resetTokenizer(); continue; }

            // resize = \e[8;<row>;<col>t
            if (eps(CPS)) {
                processToken(token_csi_ps(cc, argv[0]), argv[1], argv[2]);
                resetTokenizer();
                continue;
            }

            if (epe(   )) { processToken(token_csi_pe(cc), 0, 0); resetTokenizer(); continue; }

            if (esp (   )) { processToken(token_csi_sp(cc), 0, 0);           resetTokenizer(); continue; }
            if (epsp(   )) { processToken(token_csi_psp(cc, argv[0]), 0, 0); resetTokenizer(); continue; }

            if (ees(DIG)) { addDigit(cc-'0'); continue; }
            if (eec(';')) { addArgument();    continue; }
            if (ees(INT)) { continue; }
            if (p >= 3 && cc == 'y' && s[p - 2] == '*') { processChecksumRequest(argc, argv); resetTokenizer(); continue; }
            for (int i = 0; i <= argc; i++) {
                if (epp()) {
                    processToken(token_csi_pr(cc,argv[i]), 0, 0);
                } else if (eeq()) {
                    processToken(token_csi_pq(cc), 0, 0); // spec. case for ESC[=0c or ESC[=c
                } else if (egt()) {
                    processToken(token_csi_pg(cc), 0, 0); // spec. case for ESC[>0c or ESC[>c
                } else if (cc == 'm' && argc - i >= 4 && (argv[i] == 38 || argv[i] == 48) && argv[i+1] == 2)
                {
                    // ESC[ ... 48;2;<red>;<green>;<blue> ... m -or- ESC[ ... 38;2;<red>;<green>;<blue> ... m
                    i += 2;
                    processToken(token_csi_ps(cc, argv[i-2]), COLOR_SPACE_RGB, (argv[i] << 16) | (argv[i+1] << 8) | argv[i+2]);
                    i += 2;
                } else if (cc == 'm' && argc - i >= 2 && (argv[i] == 38 || argv[i] == 48) && argv[i+1] == 5) {
                    // ESC[ ... 48;5;<index> ... m -or- ESC[ ... 38;5;<index> ... m
                    i += 2;
                    processToken(token_csi_ps(cc, argv[i-2]), COLOR_SPACE_256, argv[i]);
                } else if (p < 2 || (charClass[s[p-2]] & (INT)) != (INT)) {
                    processToken(token_csi_ps(cc,argv[i]), 0, 0);
                }
            }
        } else {
            if (dcs         ) { continue; /* TODO We don't xterm DCS, so we just eat it */ }
            if (lec(2,0,ESC)) { processToken(token_esc(s[1]), 0, 0);              resetTokenizer(); continue; }
            if (les(3,1,SCS)) { processToken(token_esc_cs(s[1],s[2]), 0, 0);      resetTokenizer(); continue; }
            if (lec(3,1,'#')) { processToken(token_esc_de(s[2]), 0, 0);           resetTokenizer(); continue; }
        }
        resetTokenizer();
        /* clang-format on */
        } else {
            // VT52 Mode
            if (lec(1, 0, ESC)) {
                continue;
            }
            if (les(1, 0, CHR)) {
                processToken(token_chr(), s[0], 0);
                resetTokenizer();
                continue;
            }
            if (lec(2, 1, 'Y')) {
                continue;
            }
            if (lec(3, 1, 'Y')) {
                continue;
            }
            if (p < 4) {
                processToken(token_vt52(s[1]), 0, 0);
                resetTokenizer();
                continue;
            }
            processToken(token_vt52(s[1]), s[2], s[3]);
            resetTokenizer();
            continue;
        }
    }
```

#### AUTO 


```{c}
auto *activeContainer= _viewSplitter->activeContainer();
```

#### LAMBDA EXPRESSION 


```{c}
[](const Profile::Ptr &p1, const Profile::Ptr &p2) {
        // Always put the Default/fallback profile at the top
        if (p1->isFallback()) {
            return true;
        } else if (p2->isFallback()) {
            return false;
        }

        return QString::localeAwareCompare(p1->name(), p2->name()) < 0;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&](const char *key, double min, double max) -> double {
        const double value = configGroup.readEntry(key, min);
        if (min > value || value > max) {
            qCDebug(ColorSchemeDebug) << QStringLiteral(
                                             "Color scheme \"%1\": color index 2 has an invalid value: %3 = %4. "
                                             "Allowed value range: %5 - %6. Using %7.")
                                             .arg(name())
                                             .arg(index)
                                             .arg(QLatin1String(key))
                                             .arg(value, 0, 'g', 1)
                                             .arg(min, 0, 'g', 1)
                                             .arg(max, 0, 'g', 1)
                                             .arg(min, 0, 'g', 1);
            return min;
        }
        return value;
    }
```

#### AUTO 


```{c}
auto parentSplitter = qobject_cast<ViewSplitter*>(parent());
```

#### RANGE FOR STATEMENT 


```{c}
for (const TerminalDisplay *terminalDisplay : views) {
        // ... and check whether a TerminalDisplay has the same
        // window as given in the parameter
        if (window == findWindow(terminalDisplay)) {
            return(true);
        }
    }
```

#### AUTO 


```{c}
auto *filter
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : selectedIndexes) {
        if (index.column() == ProfileModel::PROFILE) {
            list << index.data(ProfileModel::ProfilePtrRole).value<Profile::Ptr>();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]{
        emit newViewRequest(this);
    }
```

#### AUTO 


```{c}
auto lprintContent = [this](QPainter &painter, bool friendly) {
        QPoint columnLines(_usedLines, _usedColumns);
        auto lfontget = [this]() { return _terminalFont->getVTFont(); };
        auto lfontset = [this](const QFont &f) { _terminalFont->setVTFont(f); };

        _printManager->printContent(painter, friendly, columnLines, lfontget, lfontset);
    };
```

#### AUTO 


```{c}
auto fileHotspot = _currentlyHoveredHotspot.dynamicCast<FileFilterHotSpot>();
```

#### AUTO 


```{c}
auto list = manager->allProfiles();
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *menuItem : actions) {
        QString itemText = menuItem->data().toString();
        menuItem->setText(itemText);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &pair : environmentVariables) {
        // split on the first '=' character
        const int separator = pair.indexOf(QLatin1Char('='));

        if (separator >= 0) {
            QString variable = pair.left(separator);
            QString value = pair.mid(separator + 1);

            setEnv(variable, value);

            if (variable == QLatin1String("TERM")) {
                isTermEnvAdded = true;
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, readonly](const QString &name) {
        QAction *action = actionCollection()->action(name);
        if (action != nullptr) {
            action->setVisible(!readonly);
        }
    }
```

#### AUTO 


```{c}
auto currentWidget = widget(currentIndex);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &favorite : qAsConst(favoriteSet)) {
        Profile::Ptr profile = loadProfile(favorite);
        if (profile) {
            _favorites.insert(profile);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (TerminalDisplay *view : viewsList) {
        const QFont &viewCurFont = view->getVTFont();
        if (viewCurFont != _sessionProfiles[session]->font()) {
            zoomFontSizes.insert(view, viewCurFont);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &url : _history) {
        url.begin.row -= lines;
        url.end.row -= lines;
    }
```

#### AUTO 


```{c}
auto extChars = [this]() {
                return usedExtendedChars();
            };
```

#### RANGE FOR STATEMENT 


```{c}
for (const QChar &c : reallyBigTextForReflow) {
        screen.displayCharacter(c.toLatin1());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &i : profile) {
        i->setProperty(Profile::HistorySize, 1234);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (uint cc : chars) {
        if (cc == DEL) {
            continue; // VT100: ignore.
        }

        // early out for displayable characters
        if (!getMode(MODE_Sixel) && getMode(MODE_Ansi) && tokenBufferPos == 0 && cc >= 32 && cc != (ESC + 128)) {
            _currentScreen->displayCharacter(applyCharset(cc));
            continue;
        }

        if (ces(CTL)) {
            // ignore control characters in the text part of osc (aka OSC) "ESC]"
            // escape sequences; this matches what XTERM docs say
            // Allow BEL and ESC here, it will either end the text or be removed later.
            if ((osc || apc) && cc != 0x1b && cc != 0x07) {
                continue;
            }

            if (!osc && !apc) {
                // DEC HACK ALERT! Control Characters are allowed *within* esc sequences in VT100
                // This means, they do neither a resetTokenizer() nor a pushToToken(). Some of them, do
                // of course. Guess this originates from a weakly layered handling of the X-on
                // X-off protocol, which comes really below this level.
                if (cc == CNTL('X') || cc == CNTL('Z') || cc == ESC) {
                    resetTokenizer(); // VT100: CAN or SUB
                }
                if (cc != ESC) {
                    processToken(token_ctl(cc + '@'), 0, 0);
                    continue;
                }
            }
        }
        // advance the state
        addToCurrentToken(cc);

        uint *s = tokenBuffer;
        const int p = tokenBufferPos;

        if (getMode(MODE_Sixel) && processSixel(cc)) {
            continue;
        }

        if (getMode(MODE_Ansi)) {
            if (lec(1, 0, ESC)) {
                continue;
            }
            if (lec(1, 0, ESC + 128)) {
                s[0] = ESC;
                receiveChars(QVector<uint>{'['});
                continue;
            }
            if (les(2, 1, GRP)) {
                continue;
            }
            // Operating System Command
            if (p > 2 && s[1] == ']') {
                // <ESC> ']' ... <ESC> '\'
                if (s[p - 2] == ESC && s[p - 1] == '\\') {
                    // This runs two times per link, the first prepares the link to be read,
                    // the second finalizes it. The escape sequence is in two parts
                    //  start: '\e ] 8 ; <id-path> ; <url-part> \e \\'
                    //  end:   '\e ] 8 ; ; \e \\'
                    // GNU libtextstyle inserts the IDs, for instance; many examples
                    // do not.
                    if (s[2] == XTERM_EXTENDED::URL_LINK) {
                        // printf '\e]8;;https://example.com\e\\This is a link\e]8;;\e\\\n'
                        _currentScreen->urlExtractor()->toggleUrlInput();
                    }
                    processSessionAttributeRequest(p - 1);
                    resetTokenizer();
                    continue;
                }
                // <ESC> ']' ... <ESC> + one character for reprocessing
                if (s[p - 2] == ESC) {
                    processSessionAttributeRequest(p - 1);
                    resetTokenizer();
                    receiveChars(QVector<uint>{cc});
                    continue;
                }
                // <ESC> ']' ... <BEL>
                if (s[p - 1] == 0x07) {
                    processSessionAttributeRequest(p);
                    resetTokenizer();
                    continue;
                }
                // Special case: iterm file protocol is a long escape sequence
                if (tokenState == -1) {
                    tokenStateChange = "1337;File=:";
                    tokenState = 0;
                } else if (tokenState >= 0) {
                    if ((uint)tokenStateChange[tokenState] == s[p - 1]) {
                        tokenState++;
                        tokenPos = p;
                        if ((uint)tokenState == strlen(tokenStateChange)) {
                            tokenState = -2;
                            tokenData.clear();
                        }
                        continue;
                    }
                } else if (tokenState == -2) {
                    if (p - tokenPos == 4) {
                        tokenData.append(QByteArray::fromBase64(QString::fromUcs4(&tokenBuffer[tokenPos], 4).toLocal8Bit()));
                        tokenBufferPos -= 4;
                        continue;
                    }
                }
                // Special case: Session::Wallpaper is a long escape sequence
                if (tokenState == -1) {
                    tokenStateChange = "114502;,,";
                    tokenState = 0;
                } else if (tokenState >= 0) {
                    if ((uint)tokenStateChange[tokenState] == s[p - 1]) {
                        tokenState++;
                        tokenPos = p;
                        if ((uint)tokenState == strlen(tokenStateChange)) {
                            tokenState = -2;
                            tokenData.clear();
                        }
                        continue;
                    }
                } else if (tokenState == -2) {
                    if (p - tokenPos == 4) {
                        tokenData.append(QByteArray::fromBase64(QString::fromUcs4(&tokenBuffer[tokenPos], 4).toLocal8Bit()));
                        tokenBufferPos -= 4;
                        continue;
                    }
                }
            }
            // Application Program Command
            if (p > 2 && s[1] == '_') {
                // <ESC> '_' ... <ESC> '\'
                if (p > 3 && s[2] == 'G') {
                    if (tokenState == -1) {
                        tokenStateChange = ";";
                        tokenState = 0;
                    } else if (tokenState >= 0) {
                        if ((uint)tokenStateChange[tokenState] == s[p - 1]) {
                            tokenState++;
                            tokenPos = p;
                            if ((uint)tokenState == strlen(tokenStateChange)) {
                                tokenState = -2;
                                tokenData.clear();
                            }
                            continue;
                        }
                    } else if (tokenState == -2) {
                        if (p - tokenPos == 4) {
                            tokenData.append(QByteArray::fromBase64(QString::fromUcs4(&tokenBuffer[tokenPos], 4).toLocal8Bit()));
                            tokenBufferPos -= 4;
                            continue;
                        }
                    }
                }
                if (s[p - 1] == 0x07 || (s[p - 2] == ESC && s[p - 1] == '\\')) {
                    if (s[2] == 'G') {
                        // Graphics command
                        processGraphicsToken(p);
                        resetTokenizer();
                        continue;
                    }
                }
            }

            /* clang-format off */
        // <ESC> ']' ...
        if (osc         ) { continue; }
        if (apc         ) { continue; }
        if (p >= 3 && s[1] == '[') { // parsing a CSI sequence
            if (lec(3,2,'?')) { continue; }
            if (lec(3,2,'=')) { continue; }
            if (lec(3,2,'>')) { continue; }
            if (lec(3,2,'!')) { continue; }
            if (lec(3,2,SP )) { continue; }
            if (lec(4,3,SP )) { continue; }
            if (eps(    CPN)) { processToken(token_csi_pn(cc), argv[0],argv[1]);  resetTokenizer(); continue; }

            // resize = \e[8;<row>;<col>t
            if (eps(CPS)) {
                processToken(token_csi_ps(cc, argv[0]), argv[1], argv[2]);
                resetTokenizer();
                continue;
            }

            if (epe(   )) { processToken(token_csi_pe(cc), 0, 0); resetTokenizer(); continue; }

            if (esp (   )) { processToken(token_csi_sp(cc), 0, 0);           resetTokenizer(); continue; }
            if (epsp(   )) { processToken(token_csi_psp(cc, argv[0]), 0, 0); resetTokenizer(); continue; }

            if (ees(DIG)) { addDigit(cc-'0'); continue; }
            if (eec(';')) { addArgument();    continue; }
            if (ees(INT)) { continue; }
            if (p >= 3 && cc == 'y' && s[p - 2] == '*') { processChecksumRequest(argc, argv); resetTokenizer(); continue; }
            for (int i = 0; i <= argc; i++) {
                if (epp()) {
                    processToken(token_csi_pr(cc,argv[i]), 0, 0);
                } else if (eeq()) {
                    processToken(token_csi_pq(cc), 0, 0); // spec. case for ESC[=0c or ESC[=c
                } else if (egt()) {
                    processToken(token_csi_pg(cc), 0, 0); // spec. case for ESC[>0c or ESC[>c
                } else if (cc == 'm' && argc - i >= 4 && (argv[i] == 38 || argv[i] == 48) && argv[i+1] == 2)
                {
                    // ESC[ ... 48;2;<red>;<green>;<blue> ... m -or- ESC[ ... 38;2;<red>;<green>;<blue> ... m
                    i += 2;
                    processToken(token_csi_ps(cc, argv[i-2]), COLOR_SPACE_RGB, (argv[i] << 16) | (argv[i+1] << 8) | argv[i+2]);
                    i += 2;
                } else if (cc == 'm' && argc - i >= 2 && (argv[i] == 38 || argv[i] == 48) && argv[i+1] == 5) {
                    // ESC[ ... 48;5;<index> ... m -or- ESC[ ... 38;5;<index> ... m
                    i += 2;
                    processToken(token_csi_ps(cc, argv[i-2]), COLOR_SPACE_256, argv[i]);
                } else if (p < 2 || (charClass[s[p-2]] & (INT)) != (INT)) {
                    processToken(token_csi_ps(cc,argv[i]), 0, 0);
                }
            }
        } else {
            if (dcs) {
                // Check for Sixel DCS q
                if (p > 2 && cc == 'q') {
                    setMode(MODE_Sixel);
                    // This parameter appers to be ignored
                    // m_preserveBackground = argv[2] == 1;
                    resetTokenizer();
                }
                if (ccc(DIG)) { addDigit(cc-'0');}
                if (cc == ';') { addArgument();}
                continue;
            }
            if (lec(2,0,ESC)) { processToken(token_esc(s[1]), 0, 0);              resetTokenizer(); continue; }
            if (les(3,1,SCS)) { processToken(token_esc_cs(s[1],s[2]), 0, 0);      resetTokenizer(); continue; }
            if (lec(3,1,'#')) { processToken(token_esc_de(s[2]), 0, 0);           resetTokenizer(); continue; }
        }
        resetTokenizer();
        /* clang-format on */
        } else {
            // VT52 Mode
            if (lec(1, 0, ESC)) {
                continue;
            }
            if (les(1, 0, CHR)) {
                processToken(token_chr(), s[0], 0);
                resetTokenizer();
                continue;
            }
            if (lec(2, 1, 'Y')) {
                continue;
            }
            if (lec(3, 1, 'Y')) {
                continue;
            }
            if (p < 4) {
                processToken(token_vt52(s[1]), 0, 0);
                resetTokenizer();
                continue;
            }
            processToken(token_vt52(s[1]), s[2], s[3]);
            resetTokenizer();
            continue;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&](int column) {
                return _image[loc(column, y)].character <= 0x7e || rtl;
            }
```

#### AUTO 


```{c}
const auto leftSize = leftWidget != nullptr ? leftWidget->sizeHint() : QSize(0, 0);
```

#### AUTO 


```{c}
auto &[view, font]
```

#### RANGE FOR STATEMENT 


```{c}
for (const Profile::PropertyInfo &info : Profile::DefaultPropertyNames) {
        if (info.group != nullptr) {
            if (groupName == nullptr || qstrcmp(groupName, info.group) != 0) {
                group = config.group(info.group);
                groupName = info.group;
            }

            if (profile->isPropertySet(info.property)) {
                group.writeEntry(QLatin1String(info.name), profile->property<QVariant>(info.property));
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &i : profilelist) {
        if (i->name() == profile) {
            profileptr = i;
            break;
        }
    }
```

#### AUTO 


```{c}
auto it = std::upper_bound(std::begin(FontWeights), std::end(FontWeights), normalWeight);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &child : other.children) {
                children.append(child);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const PropertyInfo &info : DefaultProperties) {
        list.push_back(std::string(info.name) + " : " + info.defaultValue.typeName());
    }
```

#### AUTO 


```{c}
const auto canBeGrouped = [&](int column) {
                    return image[display->loc(column, y)].character <= 0x7e
                            || (image[display->loc(column, y)].rendition & RE_EXTENDED_CHAR)
                            || (bidiEnabled && !doubleWidth);
                };
```

#### AUTO 


```{c}
auto compactHistoryType = new CompactHistoryType(10);
```

#### AUTO 


```{c}
auto sharedSize = hintSize / sizes.size();
```

#### AUTO 


```{c}
auto *editor = qobject_cast<FilteredKeySequenceEdit *>(sender());
```

#### AUTO 


```{c}
auto buffer = new ushort[length + 1];
```

#### RANGE FOR STATEMENT 


```{c}
for(auto *filter : _filters) {
        filter->reset();
    }
```

#### AUTO 


```{c}
auto buttonBox = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel);
```

#### AUTO 


```{c}
auto match = std::find_if(std::begin(_currentDirContents), std::end(_currentDirContents),
        [filename](const QString& s) { return filename.startsWith(s); });
```

#### AUTO 


```{c}
auto [charLine, charColumn] = getCharacterPosition(pos, true);
```

#### AUTO 


```{c}
auto titleOption = QCommandLineOption({QStringLiteral("T")}, QStringLiteral("Debian policy compatibility, not used"), QStringLiteral("value"));
```

#### AUTO 


```{c}
auto *maybeSplitter = qobject_cast<QSplitter *>(widget);
```

#### AUTO 


```{c}
auto c1 = style.backgroundColor.color(colorTable);
```

#### AUTO 


```{c}
auto oldHistory = std::move(_history);
```

#### AUTO 


```{c}
const auto generatorParam   = sepPos >= 0 ? generator.mid(sepPos + 1) : QString();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            const QFont font = _fontDialog->font();
            preview(Profile::Font, font);
            updateTempProfileProperty(Profile::Font, font);
            updateFontPreview(font);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[currUrl] (const QUrl &url) { return url == currUrl; }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &url : urls) {
        if (url.isLocalFile()) {
            createSession(_viewManager->activeContainer(), defaultProfile, url.path());
        } else if (url.scheme() == QLatin1String("ssh")) {
            createSSHSession(_viewManager->activeContainer(), defaultProfile, url);
        }
    }
```

#### AUTO 


```{c}
auto reflowLineLen = [](qint64 start, qint64 end) {
        return (int)((end - start) / sizeof(Character));
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &spot : spots) {
        QRegion region;
        if (spot->type() == HotSpot::Link || spot->type() == HotSpot::EMailAddress || spot->type() == HotSpot::EscapedUrl) {
            QPair<QRegion, QRect> spotRegion = spot->region(td->terminalFont()->fontWidth(), td->terminalFont()->fontHeight(), td->columns(), td->contentRect());
            region = spotRegion.first;
            QRect r = spotRegion.second;

            // TODO: Move this paint code to HotSpot->drawHint();
            // TODO: Fix the Url Hints access from the Profile.
            if (_showUrlHint && spot->type() == HotSpot::Link) {
                if (urlNumber >= 0 && urlNumber < 10) {
                    // Position at the beginning of the URL
                    QRect hintRect(*region.begin());
                    hintRect.setWidth(r.height());
                    painter.fillRect(hintRect, QColor(0, 0, 0, 128));
                    painter.setPen(Qt::white);
                    painter.drawRect(hintRect.adjusted(0, 0, -1, -1));
                    painter.drawText(hintRect, Qt::AlignCenter, QString::number(urlNumber));
                }
                urlNumber += urlNumInc;
            }
        }

        if (spot->startLine() < 0 || spot->endLine() < 0) {
            qDebug() << "ERROR, invalid hotspot:";
            spot->debug();
        }

        for (int line = spot->startLine() ; line <= spot->endLine() ; line++) {
            int startColumn = 0;
            int endColumn = td->columns() - 1; // TODO use number of _columns which are actually
            // occupied on this line rather than the width of the
            // display in _columns

            // Check image size so _image[] is valid (see makeImage)
            if (endColumn >= td->columns() || line >= td->lines()) {
                break;
            }

            // ignore whitespace at the end of the lines
            while (td->getCursorCharacter(endColumn, line).isSpace() && endColumn > 0) {
                endColumn--;
            }

            // increment here because the column which we want to set 'endColumn' to
            // is the first whitespace character at the end of the line
            endColumn++;

            if (line == spot->startLine()) {
                startColumn = spot->startColumn();
            }
            if (line == spot->endLine()) {
                endColumn = spot->endColumn();
            }

            // TODO: resolve this comment with the new margin/center code
            // subtract one pixel from
            // the right and bottom so that
            // we do not overdraw adjacent
            // hotspots
            //
            // subtracting one pixel from all sides also prevents an edge case where
            // moving the mouse outside a link could still leave it underlined
            // because the check below for the position of the cursor
            // finds it on the border of the target area
            QRect r;
            r.setCoords(startColumn * td->terminalFont()->fontWidth() + td->contentRect().left(),
                        line * td->terminalFont()->fontHeight() + td->contentRect().top(),
                        endColumn * td->terminalFont()->fontWidth() + td->contentRect().left() - 1,
                        (line + 1)* td->terminalFont()->fontHeight() + td->contentRect().top() - 1);

            // Underline link hotspots
            // TODO: Fix accessing the urlHint here.
            // TODO: Move this code to UrlFilterHotSpot.
            const bool hasMouse = region.contains(td->mapFromGlobal(QCursor::pos()));
            if ((spot->type() == HotSpot::Link && _showUrlHint) || hasMouse) {
                QFontMetrics metrics(td->font());

                // find the baseline (which is the invisible line that the characters in the font sit on,
                // with some having tails dangling below)
                const int baseline = r.bottom() - metrics.descent();
                // find the position of the underline below that
                const int underlinePos = baseline + metrics.underlinePos();
                painter.drawLine(r.left() , underlinePos, r.right() , underlinePos);

                // Marker hotspots simply have a transparent rectangular shape
                // drawn on top of them
            } else if (spot->type() == HotSpot::Marker) {
                //TODO - Do not use a hardcoded color for this
                const bool isCurrentResultLine = (td->screenWindow()->currentResultLine() == (spot->startLine() + td->screenWindow()->currentLine()));
                QColor color = isCurrentResultLine ? QColor(255, 255, 0, 120) : QColor(255, 0, 0, 120);
                painter.fillRect(r, color);
            }
        }
    }
```

#### AUTO 


```{c}
auto startPos = found - text;
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool) {
                const QString message = i18nc("@info:whatsthis", "When using this option, the scrollback data will be saved to RAM. If you choose a huge value, your system may run out of free RAM and cause serious issues with your system.");
                const QPoint pos = QPoint(_ui->fixedSizeHistoryWrapper->width() / 2, _ui->fixedSizeHistoryWrapper->height());
                QWhatsThis::showText(_ui->fixedSizeHistoryWrapper->mapToGlobal(pos), message, _ui->fixedSizeHistoryWrapper);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &session : sessionsList) {
        dialog->setWindowTitle(i18n("Save Output From %1", session->title(Session::NameRole)));

        int result = dialog->exec();

        if (result != QDialog::Accepted) {
            continue;
        }

        QUrl url = (dialog->selectedUrls()).at(0);

        if (!url.isValid()) {
            // UI:  Can we make this friendlier?
            KMessageBox::sorry(nullptr , i18n("%1 is an invalid URL, the output could not be saved.", url.url()));
            continue;
        }

        // Save selected URL for next time
        _saveDialogRecentURL = url.adjusted(QUrl::RemoveFilename|QUrl::StripTrailingSlash).toString();
        group.writePathEntry("Recent URLs", _saveDialogRecentURL);

        KIO::TransferJob* job = KIO::put(url,
                                         -1,   // no special permissions
                                         // overwrite existing files
                                         // do not resume an existing transfer
                                         // show progress information only for remote
                                         // URLs
                                         KIO::Overwrite | (url.isLocalFile() ? KIO::HideProgressInfo : KIO::DefaultFlags)
                                         // a better solution would be to show progress
                                         // information after a certain period of time
                                         // instead, since the overall speed of transfer
                                         // depends on factors other than just the protocol
                                         // used
                                        );

        SaveJob jobInfo;
        jobInfo.session = session;
        jobInfo.lastLineFetched = -1;  // when each request for data comes in from the KIO subsystem
        // lastLineFetched is used to keep track of how much of the history
        // has already been sent, and where the next request should continue
        // from.
        // this is set to -1 to indicate the job has just been started

        if (((dialog->selectedNameFilter()).contains(QLatin1String("html"), Qt::CaseInsensitive)) ||
           ((dialog->selectedFiles()).at(0).endsWith(QLatin1String("html"), Qt::CaseInsensitive))) {
            Profile::Ptr profile = SessionManager::instance()->sessionProfile(session);
            jobInfo.decoder = new HTMLDecoder(profile->colorScheme(), profile->font());
        } else {
            jobInfo.decoder = new PlainTextDecoder();
        }

        _jobSession.insert(job, jobInfo);

        connect(job, &KIO::TransferJob::dataReq, this, &Konsole::SaveHistoryTask::jobDataRequested);
        connect(job, &KIO::TransferJob::result, this, &Konsole::SaveHistoryTask::jobResult);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *child: widget->children()) {
        auto *childWidget = qobject_cast<QWidget *>(child);
        if (childWidget) {
            registerWidgetAndChildren(childWidget);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *filter : _filters) {
        list.append(filter->hotSpots());
    }
```

#### AUTO 


```{c}
auto maybeTerminalDisplay = qobject_cast<TerminalDisplay*>(widget(i))
```

#### AUTO 


```{c}
auto *container
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &mime : mimeTypes) {
        fileFormats += QStringLiteral("*.%1 ").arg(QLatin1String(mime));
    }
```

#### AUTO 


```{c}
const auto profile = currentProfile();
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto c : reallyBigTextForReflow) {
        screen.displayCharacter(c.toLatin1());
    }
```

#### AUTO 


```{c}
auto [charLine, charColumn] = getCharacterPosition(mapFromGlobal(QCursor::pos()), !usesMouseTracking());
```

#### RANGE FOR STATEMENT 


```{c}
for (TerminalDisplay *terminal : terminalDisplays) {
        connectTerminalDisplay(terminal);
    }
```

#### AUTO 


```{c}
auto lprintContent = [this](QPainter &painter, bool friendly) {
        QPoint columnLines(_usedLines, _usedColumns);
        auto lfontget = [this]() {
            return _terminalFont->getVTFont();
        };
        auto lfontset = [this](const QFont &f) {
            _terminalFont->setVTFont(f);
        };

        _printManager->printContent(painter, friendly, columnLines, lfontget, lfontset);
    };
```

#### AUTO 


```{c}
auto other_pid = ev->mimeData()->data(dragId).toInt();
```

#### AUTO 


```{c}
auto *terminalDisplay = static_cast<TerminalDisplay *>(parent());
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *act : toRemove) {
                popup->removeAction(act);
            }
```

#### AUTO 


```{c}
auto *terminal = qobject_cast<TerminalDisplay *>(child)
```

#### LAMBDA EXPRESSION 


```{c}
[](CharacterProperties &prop, const UnicodeDataEntry &entry) { prop.category = entry.category(); }
```

#### AUTO 


```{c}
auto currentIcon = tabBar()->tabIcon(currentIndex);
```

#### AUTO 


```{c}
const auto terminalDisplays = viewSplitter->findChildren<TerminalDisplay *>();
```

#### LAMBDA EXPRESSION 


```{c}
[&](const char *key, double min, double max) -> double {
        const double value = configGroup.readEntry(key, min);
        if (min > value || value > max) {
            qCDebug(ColorSchemeDebug) << QStringLiteral(
                    "Color scheme \"%1\": color index 2 has an invalid value: %3 = %4. "
                    "Allowed value range: %5 - %6. Using %7.")
                    .arg(name()).arg(index).arg(QLatin1String(key)).arg(value, 0, 'g', 1)
                    .arg(min, 0, 'g', 1).arg(max, 0, 'g', 1).arg(min, 0, 'g', 1);
            return min;
        }
        return value;
    }
```

#### AUTO 


```{c}
const auto &i
```

#### RANGE FOR STATEMENT 


```{c}
for (auto terminal : terminals) {
        terminal->headerBar()->applyVisibilitySettings();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *qAction : actionsList) {
        if (QAction *destQAction = dest->action(qAction->objectName())) {
            destQAction->setShortcut(qAction->shortcut());
        }
    }
```

#### AUTO 


```{c}
const auto hasSameWidth = [imageSize, image, doubleWidth](int nextPos) {
                const int characterLoc = qMin(nextPos + 1, imageSize - 1);
                return (image[characterLoc].character == 0) == doubleWidth;
            };
```

#### AUTO 


```{c}
const auto &p
```

#### AUTO 


```{c}
auto *qcDockWidget = new QDockWidget(mainWindow);
```

#### AUTO 


```{c}
const auto dropWidget
```

#### AUTO 


```{c}
auto lprintContent = [this](QPainter &painter, bool friendly) {
        
        QPoint columnLines(_usedLines, _usedColumns);
        auto lfontget = [this]() { return getVTFont(); };
        auto lfontset = [this](const QFont &f) { setVTFont(f); };

        _printManager->printContent(painter, friendly, columnLines, lfontget, lfontset);
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &dir : dirs) {
        const QStringList fileNames = QDir(dir).entryList(QStringList() << QStringLiteral("*.profile"));
        for (const QString &file : fileNames) {
            profiles.append(dir + QLatin1Char('/') + file);
        }
    }
```

#### AUTO 


```{c}
auto viewSplitter = qobject_cast<ViewSplitter *>(currentWidget());
```

#### AUTO 


```{c}
auto scrollBarPosition = profile->property<int>(Profile::ScrollBarPosition);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto key : obsoleteKeys) {
        if (configGroup.hasKey(key)) {
            configGroup.deleteEntry(key);
        }
    }
```

#### AUTO 


```{c}
const auto colsSuffix = ki18ncp("Suffix of the number of columns (N columns). The leading space is needed to separate it from the number value.", " column", " columns");
```

#### RANGE FOR STATEMENT 


```{c}
for (Session *session : sessions) {
        connect(session, &Konsole::Session::finished, this, &Konsole::SessionListModel::sessionFinished);
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr const unsigned LinesNum = 4;
```

#### AUTO 


```{c}
auto profiles = Konsole::ProfileManager::instance()->allProfiles();
```

#### AUTO 


```{c}
auto* copyInputToNoneAction = collection->add<KToggleAction>(QStringLiteral("copy-input-to-none"));
```

#### AUTO 


```{c}
const auto mimeList = mdb.mimeTypesForFileName(path);
```

#### LAMBDA EXPRESSION 


```{c}
[this, readonly]() {
        view()->updateReadOnlyState(readonly);
    }
```

#### AUTO 


```{c}
auto toplevelSplitter = splitter->getToplevelSplitter();
```

#### AUTO 


```{c}
auto closeAction = _contextPopupMenu->addAction(QIcon::fromTheme(QStringLiteral("tab-close")), i18nc("@action:inmenu", "Close Tab"), this, [this] {
        closeTerminalTab(_contextMenuTabIndex);
    });
```

#### AUTO 


```{c}
auto *fileHotSpot = qobject_cast<FileFilterHotSpot *>(_currentHotSpot.get());
```

#### LAMBDA EXPRESSION 


```{c}
[this](const int index) {
        updateTempProfileProperty(Profile::TextEditorCmd, index);
        _mouseUi->textEditorCustomBtn->setEnabled(index == Enum::CustomTextEditor);
    }
```

#### AUTO 


```{c}
const auto getLineType = [&packedLineTypes](quint8 lineId) -> LineType {
        lineId = LinesNum - 1 - lineId % LinesNum;
        return LineType(packedLineTypes >> 2 * lineId & 3);
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool) {
        const QString message = i18nc("@info:whatsthis",
                                      "When using this option, the scrollback data will be saved to RAM. If you choose a huge value, your system may run out "
                                      "of free RAM and cause serious issues with your system.");
        const QPoint pos = QPoint(_ui->fixedSizeHistoryWrapper->width() / 2, _ui->fixedSizeHistoryWrapper->height());
        QWhatsThis::showText(_ui->fixedSizeHistoryWrapper->mapToGlobal(pos), message, _ui->fixedSizeHistoryWrapper);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &i : profile) {
        i = new Profile;
        QVERIFY(!i->asGroup());
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr const int RANGE_LUT_LIST_SIZE = �ranges-lut-list-size�;
```

#### AUTO 


```{c}
auto openUrl = [](const QString &filePath) {
#if KIO_VERSION < QT_VERSION_CHECK(5, 71, 0)
        new KRun(QUrl::fromLocalFile(filePath), QApplication::activeWindow());
#else
        auto *job = new KIO::OpenUrlJob(QUrl::fromLocalFile(filePath));
        job->setUiDelegate(new KIO::JobUiDelegate(KJobUiDelegate::AutoHandlingEnabled, QApplication::activeWindow()));
        job->setRunExecutables(false); // Always open, e.g. shell scripts, as text
        job->start();
#endif
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (uint c : chars) {
        c &= 0xff;
        switch (c) {
        case '\b':
            _currentScreen->backspace();
            break;
        case '\t':
            _currentScreen->tab();
            break;
        case '\n':
            _currentScreen->newLine();
            break;
        case '\r':
            _currentScreen->toStartOfLine();
            break;
        case 0x07:
            Q_EMIT bell();
            break;
        default:
            _currentScreen->displayCharacter(c);
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &s : _currentDirContents) {
        if (filename.startsWith(s)) {
            isChild = true;
            break;
        }
    }
```

#### AUTO 


```{c}
const auto startMapped = parentSplitter->mapTo(topSplitter, start);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QFont &f) { setVTFont(f); }
```

#### RANGE FOR STATEMENT 


```{c}
for (uint cc : chars) {
        if (cc == DEL) {
            continue; // VT100: ignore.
        }

        // early out for displayable characters
        if (!getMode(MODE_Sixel) && getMode(MODE_Ansi) && tokenBufferPos == 0 && cc >= 32 && cc != (ESC + 128)) {
            _currentScreen->displayCharacter(applyCharset(cc));
            continue;
        }

        if (!getMode(MODE_Sixel) && ces(CTL)) {
            // ignore control characters in the text part of osc (aka OSC) "ESC]"
            // escape sequences; this matches what XTERM docs say
            // Allow BEL and ESC here, it will either end the text or be removed later.
            if ((osc || apc) && cc != 0x1b && cc != 0x07) {
                continue;
            }

            if (!osc && !apc) {
                // DEC HACK ALERT! Control Characters are allowed *within* esc sequences in VT100
                // This means, they do neither a resetTokenizer() nor a pushToToken(). Some of them, do
                // of course. Guess this originates from a weakly layered handling of the X-on
                // X-off protocol, which comes really below this level.
                if (cc == CNTL('X') || cc == CNTL('Z') || cc == ESC) {
                    resetTokenizer(); // VT100: CAN or SUB
                }
                if (cc != ESC) {
                    processToken(token_ctl(cc + '@'), 0, 0);
                    continue;
                }
            }
        }
        // advance the state
        addToCurrentToken(cc);

        uint *s = tokenBuffer;
        const int p = tokenBufferPos;

        if (getMode(MODE_Sixel) && processSixel(cc)) {
            continue;
        }

        if (getMode(MODE_Ansi)) {
            if (lec(1, 0, ESC)) {
                continue;
            }
            if (lec(1, 0, ESC + 128)) {
                s[0] = ESC;
                receiveChars(QVector<uint>{'['});
                continue;
            }
            if (les(2, 1, GRP)) {
                continue;
            }
            // Operating System Command
            if (p > 2 && s[1] == ']') {
                // <ESC> ']' ... <ESC> '\'
                if (s[p - 2] == ESC && s[p - 1] == '\\') {
                    // This runs two times per link, the first prepares the link to be read,
                    // the second finalizes it. The escape sequence is in two parts
                    //  start: '\e ] 8 ; <id-path> ; <url-part> \e \\'
                    //  end:   '\e ] 8 ; ; \e \\'
                    // GNU libtextstyle inserts the IDs, for instance; many examples
                    // do not.
                    if (s[2] == XTERM_EXTENDED::URL_LINK) {
                        // printf '\e]8;;https://example.com\e\\This is a link\e]8;;\e\\\n'
                        _currentScreen->urlExtractor()->toggleUrlInput();
                    }
                    processSessionAttributeRequest(p - 1);
                    resetTokenizer();
                    continue;
                }
                // <ESC> ']' ... <ESC> + one character for reprocessing
                if (s[p - 2] == ESC) {
                    processSessionAttributeRequest(p - 1);
                    resetTokenizer();
                    receiveChars(QVector<uint>{cc});
                    continue;
                }
                // <ESC> ']' ... <BEL>
                if (s[p - 1] == 0x07) {
                    processSessionAttributeRequest(p);
                    resetTokenizer();
                    continue;
                }
                // Special case: iterm file protocol is a long escape sequence
                if (tokenState == -1) {
                    tokenStateChange = "1337;File=:";
                    tokenState = 0;
                } else if (tokenState >= 0) {
                    if ((uint)tokenStateChange[tokenState] == s[p - 1]) {
                        tokenState++;
                        tokenPos = p;
                        if ((uint)tokenState == strlen(tokenStateChange)) {
                            tokenState = -2;
                            tokenData.clear();
                        }
                        continue;
                    }
                } else if (tokenState == -2) {
                    if (p - tokenPos == 4) {
                        tokenData.append(QByteArray::fromBase64(QString::fromUcs4(&tokenBuffer[tokenPos], 4).toLocal8Bit()));
                        tokenBufferPos -= 4;
                        continue;
                    }
                }
                // Special case: Session::Wallpaper is a long escape sequence
                if (tokenState == -1) {
                    tokenStateChange = "114502;,,";
                    tokenState = 0;
                } else if (tokenState >= 0) {
                    if ((uint)tokenStateChange[tokenState] == s[p - 1]) {
                        tokenState++;
                        tokenPos = p;
                        if ((uint)tokenState == strlen(tokenStateChange)) {
                            tokenState = -2;
                            tokenData.clear();
                        }
                        continue;
                    }
                } else if (tokenState == -2) {
                    if (p - tokenPos == 4) {
                        tokenData.append(QByteArray::fromBase64(QString::fromUcs4(&tokenBuffer[tokenPos], 4).toLocal8Bit()));
                        tokenBufferPos -= 4;
                        continue;
                    }
                }
            }
            // Application Program Command
            if (p > 2 && s[1] == '_') {
                // <ESC> '_' ... <ESC> '\'
                if (p > 3 && s[2] == 'G') {
                    if (tokenState == -1) {
                        tokenStateChange = ";";
                        tokenState = 0;
                    } else if (tokenState >= 0) {
                        if ((uint)tokenStateChange[tokenState] == s[p - 1]) {
                            tokenState++;
                            tokenPos = p;
                            if ((uint)tokenState == strlen(tokenStateChange)) {
                                tokenState = -2;
                                tokenData.clear();
                            }
                            continue;
                        }
                    } else if (tokenState == -2) {
                        if (p - tokenPos == 4) {
                            tokenData.append(QByteArray::fromBase64(QString::fromUcs4(&tokenBuffer[tokenPos], 4).toLocal8Bit()));
                            tokenBufferPos -= 4;
                            continue;
                        }
                    }
                }
                if (s[p - 1] == 0x07 || (s[p - 2] == ESC && s[p - 1] == '\\')) {
                    if (s[2] == 'G') {
                        // Graphics command
                        processGraphicsToken(p);
                    }
                    resetTokenizer();
                    continue;
                }
            }

            /* clang-format off */
        // <ESC> ']' ...
        if (osc         ) { continue; }
        if (apc         ) { continue; }
        if (p >= 3 && s[1] == '[') { // parsing a CSI sequence
            if (lec(3,2,'?')) { continue; }
            if (lec(3,2,'=')) { continue; }
            if (lec(3,2,'>')) { continue; }
            if (lec(3,2,'!')) { continue; }
            if (lec(3,2,SP )) { continue; }
            if (lec(4,3,SP )) { continue; }
            if (eps(    CPN)) { processToken(token_csi_pn(cc), argv[0],argv[1]);  resetTokenizer(); continue; }

            // resize = \e[8;<row>;<col>t
            if (eps(CPS)) {
                processToken(token_csi_ps(cc, argv[0]), argv[1], argv[2]);
                resetTokenizer();
                continue;
            }

            if (epe(   )) { processToken(token_csi_pe(cc), 0, 0); resetTokenizer(); continue; }

            if (esp (   )) { processToken(token_csi_sp(cc), 0, 0);           resetTokenizer(); continue; }
            if (epsp(   )) { processToken(token_csi_psp(cc, argv[0]), 0, 0); resetTokenizer(); continue; }

            if (ees(DIG)) { addDigit(cc-'0'); continue; }
            if (eec(';')) { addArgument();    continue; }
            if (ees(INT)) { continue; }
            if (p >= 3 && cc == 'y' && s[p - 2] == '*') { processChecksumRequest(argc, argv); resetTokenizer(); continue; }
            for (int i = 0; i <= argc; i++) {
                if (epp()) {
                    processToken(token_csi_pr(cc,argv[i]), 0, 0);
                } else if (eeq()) {
                    processToken(token_csi_pq(cc), 0, 0); // spec. case for ESC[=0c or ESC[=c
                } else if (egt()) {
                    processToken(token_csi_pg(cc), 0, 0); // spec. case for ESC[>0c or ESC[>c
                } else if (cc == 'm' && argc - i >= 4 && (argv[i] == 38 || argv[i] == 48) && argv[i+1] == 2)
                {
                    // ESC[ ... 48;2;<red>;<green>;<blue> ... m -or- ESC[ ... 38;2;<red>;<green>;<blue> ... m
                    i += 2;
                    processToken(token_csi_ps(cc, argv[i-2]), COLOR_SPACE_RGB, (argv[i] << 16) | (argv[i+1] << 8) | argv[i+2]);
                    i += 2;
                } else if (cc == 'm' && argc - i >= 2 && (argv[i] == 38 || argv[i] == 48) && argv[i+1] == 5) {
                    // ESC[ ... 48;5;<index> ... m -or- ESC[ ... 38;5;<index> ... m
                    i += 2;
                    processToken(token_csi_ps(cc, argv[i-2]), COLOR_SPACE_256, argv[i]);
                } else if (p < 2 || (charClass[s[p-2]] & (INT)) != (INT)) {
                    processToken(token_csi_ps(cc,argv[i]), 0, 0);
                }
            }
        } else {
            if (dcs) {
                // Check for Sixel DCS q
                if (p > 2 && cc == 'q') {
                    setMode(MODE_Sixel);
                    // This parameter appears to be ignored
                    // m_preserveBackground = argv[2] == 1;
                    resetTokenizer();
                }
                if (ccc(DIG)) { addDigit(cc-'0');}
                if (cc == ';') { addArgument();}
                continue;
            }
            if (lec(2,0,ESC)) { processToken(token_esc(s[1]), 0, 0);              resetTokenizer(); continue; }
            if (les(3,1,SCS)) { processToken(token_esc_cs(s[1],s[2]), 0, 0);      resetTokenizer(); continue; }
            if (lec(3,1,'#')) { processToken(token_esc_de(s[2]), 0, 0);           resetTokenizer(); continue; }
        }
        resetTokenizer();
        /* clang-format on */
        } else {
            // VT52 Mode
            if (lec(1, 0, ESC)) {
                continue;
            }
            if (les(1, 0, CHR)) {
                processToken(token_chr(), s[0], 0);
                resetTokenizer();
                continue;
            }
            if (lec(2, 1, 'Y')) {
                continue;
            }
            if (lec(3, 1, 'Y')) {
                continue;
            }
            if (p < 4) {
                processToken(token_vt52(s[1]), 0, 0);
                resetTokenizer();
                continue;
            }
            processToken(token_vt52(s[1]), s[2], s[3]);
            resetTokenizer();
            continue;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, path, job]() {
        if (job->error() != 0) {
            // TODO: use KMessageWidget (like the "terminal is read-only" message)
            KMessageBox::sorry(QApplication::activeWindow(),
                i18n("Could not open file with the text editor specified in the profile settings;\n"
                     "it will be opened with the system default editor."));

            openWithSysDefaultEditor(path);
        }
    }
```

#### AUTO 


```{c}
auto *job = new KIO::OpenUrlJob(QUrl::fromLocalFile(filePath));
```

#### AUTO 


```{c}
auto topLevelWindow = QApplication::topLevelWidgets().at(0);
```

#### AUTO 


```{c}
const auto color = QColor(((u / 36) % 6) != 0 ? (40 * ((u / 36) % 6) + 55) : 0,
                      ((u / 6) % 6) != 0 ? (40 * ((u / 6) % 6) + 55) : 0,
                      ((u / 1) % 6) != 0 ? (40 * ((u / 1) % 6) + 55) : 0);
```

#### LAMBDA EXPRESSION 


```{c}
[=](const KNSCore::EntryInternal::List &entries) {
        const QString &name = selected.first().data(Qt::UserRole + 1).value<const ColorScheme *>()->name();
        Q_ASSERT(!name.isEmpty());
        bool uninstalled = false;
        // Check if the theme was installed by KNS, if so uninstall it through
        // there and unload it.
        for (auto entry : entries) {
            for (const auto &file : entry.installedFiles()) {
                if (ColorSchemeManager::colorSchemeNameFromPath(file) != name) {
                    continue;
                }
                // Make sure the manager can unload it before uninstalling it.
                if (ColorSchemeManager::instance()->unloadColorScheme(file)) {
                    manager->uninstallEntry(entry);
                    uninstalled = true;
                }
            }
            if (uninstalled) {
                break;
            }
        }

        // If KNS wasn't able to remove it is a custom theme and we'll drop
        // it manually.
        if (!uninstalled) {
            uninstalled = ColorSchemeManager::instance()->deleteColorScheme(name);
        }

        if (uninstalled) {
            _ui->colorSchemeList->model()->removeRow(selected.first().row());
        }

        manager->deleteLater();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, dropText] {
                Q_EMIT sendStringToEmu(dropText.toLocal8Bit());
            }
```

#### AUTO 


```{c}
auto closeButton = new QToolButton(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const PropertyInfo &info : Profile::DefaultPropertyNames) {
        // the profile group does not store a value for some properties
        // (eg. name, path) if even they are equal between profiles -
        //
        // the exception is when the group has only one profile in which
        // case it behaves like a standard Profile
        if (_profiles.count() > 1 && !canInheritProperty(info.property)) {
            continue;
        }

        QVariant value;
        for (int i = 0; i < _profiles.count(); i++) {
            QVariant profileValue = _profiles[i]->property<QVariant>(info.property);
            if (value.isNull()) {
                value = profileValue;
            } else if (value != profileValue) {
                value = QVariant();
                break;
            }
        }
        Profile::setProperty(info.property, value);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QButtonGroup *group: qAsConst(_groups)) {
        if (!group->checkedButton()) {
            continue;
        }
        int value = buttonToEnumValue(group->checkedButton());
        const auto *enumItem = groupToConfigItemEnum(group);

        if (enumItem != nullptr && !enumItem->isEqual(value)) {
            return true;
        }
    }
```

#### AUTO 


```{c}
const auto l1 = wcag20RelativeLuminosity(c1) + 0.05, l2 = wcag20RelativeLuminosity(c2) + 0.05;
```

#### LAMBDA EXPRESSION 


```{c}
[display, triggerText]{
        emit display->sendStringToEmu(triggerText);}
```

#### AUTO 


```{c}
auto line = _lines[lineNumber].get();
```

#### AUTO 


```{c}
const auto newPoint = QPoint(newX, newY);
```

#### AUTO 


```{c}
auto readonlyAction = collection->action(QStringLiteral("view-readonly"));
```

#### AUTO 


```{c}
const auto matchStyleSheet = QStringLiteral("QLineEdit{ background-color:%1 }")
                              .arg(backgroundBrush.brush(_searchEdit->palette()).color().name());
```

#### AUTO 


```{c}
auto r2 = a(r), g2 = a(g), b2 = a(b);
```

#### AUTO 


```{c}
auto [charLine, charColumn] = getCharacterPosition(mapFromGlobal(QCursor::pos()), !_usesMouseTracking);
```

#### AUTO 


```{c}
const auto &option
```

#### AUTO 


```{c}
const auto *window = qobject_cast<const KXmlGuiWindow *>(object);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto point : splitter->sizes()) {
            delta += point;
            QPoint thisPoint = orientation() == Qt::Horizontal ? QPoint(delta, 0) : QPoint(0, delta);

            QPoint splitterPos = splitter->mapToTopLevel(thisPoint);

            const int ourPos = orientation() == Qt::Horizontal ? splitterPos.x() : splitterPos.y();

            allSplitterSizes.push_back(ourPos);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        Q_EMIT newViewRequest();
    }
```

#### AUTO 


```{c}
auto *display = qobject_cast<TerminalDisplay *>(object)
```

#### AUTO 


```{c}
const auto &session
```

#### AUTO 


```{c}
auto &state = _tabIconState[topLevelSplitter];
```

#### RANGE FOR STATEMENT 


```{c}
for (int index: ColorIndexesForRandomization) {
                setRandomizationRange(index, MaxHue, MaxSaturation, 0.0);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (SessionController *controller : qAsConst(_allControllers)) {
        if ( (controller->profileDialogPointer() != nullptr)
             && controller->profileDialogPointer()->isVisible()
             && (controller->profileDialogPointer()->lookupProfile()
                 == SessionManager::instance()->sessionProfile(_sessionDisplayConnection->session())) ) {
            controller->profileDialogPointer()->close();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, action]() {
                    handleWebShortcutAction(action);
                }
```

#### AUTO 


```{c}
auto parentSplitter = qobject_cast<ViewSplitter *>(terminalDisplay->parentWidget());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &[profile, keySeq] : _shortcuts) {
        shortcutGroup.writeEntry(keySeq.toString(), profile->name());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &spot : spots) {
        QRegion region;
        if (spot->type() == HotSpot::Link || spot->type() == HotSpot::EMailAddress || spot->type() == HotSpot::EscapedUrl) {
            QPair<QRegion, QRect> spotRegion =
                spot->region(td->terminalFont()->fontWidth(), td->terminalFont()->fontHeight(), td->columns(), td->contentRect());
            region = spotRegion.first;
            QRect r = spotRegion.second;

            // TODO: Move this paint code to HotSpot->drawHint();
            // TODO: Fix the Url Hints access from the Profile.
            if (_showUrlHint && spot->type() == HotSpot::Link) {
                if (urlNumber >= 0 && urlNumber < 10) {
                    // Position at the beginning of the URL
                    QRect hintRect(*region.begin());
                    hintRect.setWidth(r.height());
                    painter.fillRect(hintRect, QColor(0, 0, 0, 128));
                    painter.setPen(Qt::white);
                    painter.drawRect(hintRect.adjusted(0, 0, -1, -1));
                    painter.drawText(hintRect, Qt::AlignCenter, QString::number(urlNumber));
                }
                urlNumber += urlNumInc;
            }
        }

        if (spot->startLine() < 0 || spot->endLine() < 0) {
            qDebug() << "ERROR, invalid hotspot:";
            spot->debug();
        }

        for (int line = spot->startLine(); line <= spot->endLine(); line++) {
            int startColumn = 0;
            int endColumn = td->columns() - 1; // TODO use number of _columns which are actually
            // occupied on this line rather than the width of the
            // display in _columns

            // FIXME: the left side condition is always false due to the
            //        endColumn assignment above
            // Check image size so _image[] is valid (see makeImage)
            if (endColumn >= td->columns() || line >= td->lines()) {
                break;
            }

            // ignore whitespace at the end of the lines
            while (td->getCursorCharacter(endColumn, line).isSpace() && endColumn > 0) {
                endColumn--;
            }

            // increment here because the column which we want to set 'endColumn' to
            // is the first whitespace character at the end of the line
            endColumn++;

            if (line == spot->startLine()) {
                startColumn = spot->startColumn();
            }
            if (line == spot->endLine()) {
                endColumn = spot->endColumn();
            }

            // TODO: resolve this comment with the new margin/center code
            // subtract one pixel from
            // the right and bottom so that
            // we do not overdraw adjacent
            // hotspots
            //
            // subtracting one pixel from all sides also prevents an edge case where
            // moving the mouse outside a link could still leave it underlined
            // because the check below for the position of the cursor
            // finds it on the border of the target area
            QRect r;
            r.setCoords(startColumn * td->terminalFont()->fontWidth() + td->contentRect().left(),
                        line * td->terminalFont()->fontHeight() + td->contentRect().top(),
                        endColumn * td->terminalFont()->fontWidth() + td->contentRect().left() - 1,
                        (line + 1) * td->terminalFont()->fontHeight() + td->contentRect().top() - 1);

            // Underline link hotspots
            // TODO: Fix accessing the urlHint here.
            // TODO: Move this code to UrlFilterHotSpot.
            const bool hasMouse = region.contains(td->mapFromGlobal(QCursor::pos()));
            if ((spot->type() == HotSpot::Link && _showUrlHint) || hasMouse) {
                QFontMetrics metrics(td->font());

                // find the baseline (which is the invisible line that the characters in the font sit on,
                // with some having tails dangling below)
                const int baseline = r.bottom() - metrics.descent();
                // find the position of the underline below that
                const int underlinePos = baseline + metrics.underlinePos();
                painter.drawLine(r.left(), underlinePos, r.right(), underlinePos);

                // Marker hotspots simply have a transparent rectangular shape
                // drawn on top of them
            } else if (spot->type() == HotSpot::Marker) {
                // TODO - Do not use a hardcoded color for this
                const bool isCurrentResultLine = (td->screenWindow()->currentResultLine() == (spot->startLine() + td->screenWindow()->currentLine()));
                QColor color = isCurrentResultLine ? QColor(255, 255, 0, 120) : QColor(255, 0, 0, 120);
                painter.fillRect(r, color);
            }
        }
    }
```

#### AUTO 


```{c}
auto openAction = new QAction(this);
```

#### AUTO 


```{c}
const auto hasSameColors = [&](int column) {
                    return _display->_image[_display->loc(column, y)].foregroundColor == currentForeground
                        && _display->_image[_display->loc(column, y)].backgroundColor == currentBackground;
                };
```

#### LAMBDA EXPRESSION 


```{c}
[&](int column) {
                    return _display->_image[_display->loc(column, y)].foregroundColor == currentForeground
                        && _display->_image[_display->loc(column, y)].backgroundColor == currentBackground;
                }
```

#### LAMBDA EXPRESSION 


```{c}
[&](int column) {
                    return LineBlockCharacters::canDraw(image[display->loc(column, y)].character)
                        == lineDraw;
                }
```

#### AUTO 


```{c}
auto *terminal = qobject_cast<TerminalDisplay*>(sender())
```

#### AUTO 


```{c}
auto layout = new QVBoxLayout(dialog.data());
```

#### AUTO 


```{c}
auto focusedTerminalDisplay = activeTerminalDisplay();
```

#### AUTO 


```{c}
const auto *data = _screenLines[line].data();
```

#### RANGE FOR STATEMENT 


```{c}
for (TerminalDisplay *view : viewsList) {
        const QFont viewCurFont = view->terminalFont()->getVTFont();
        if (viewCurFont != _sessionProfiles[session]->font()) {
            zoomFontSizes.push_back({view, viewCurFont});
        }
    }
```

#### AUTO 


```{c}
auto modeGroup = new QButtonGroup(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &groupName : config.groupList()) {
        KConfigGroup group = config.group(groupName);
        addTopLevelItem(groupName);
        for(const QString& sessionName : group.groupList()) {
            SSHConfigurationData data;
            KConfigGroup sessionGroup = group.group(sessionName);
            data.host = sessionGroup.readEntry("hostname");
            data.name = sessionGroup.readEntry("identifier");
            data.port = sessionGroup.readEntry("port");
            data.profileName = sessionGroup.readEntry("profilename");
            data.sshKey = sessionGroup.readEntry("sshkey");
            data.useSshConfig = sessionGroup.readEntry<bool>("useSshConfig", false);
            data.importedFromSshConfig = sessionGroup.readEntry<bool>("importedFromSshConfig", false);
            addChildItem(data, groupName);
        }
    }
```

#### AUTO 


```{c}
const auto localOuterRef = match.capturedRef(0);
```

#### AUTO 


```{c}
auto *scrollingPageWidget = new QWidget(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto *layout: qAsConst(_layouts)) {
            int left = getLeftMargin(layout);
            for (int row = 0; row < layout->rowCount(); ++row) {
                QLayoutItem *layoutItem = layout->itemAtPosition(row, LABELS_COLUMN);
                if (!layoutItem) {
                    continue;
                }
                QWidget *widget = layoutItem->widget();
                if (!widget) {
                    continue;
                }
                const int idx = layout->indexOf(widget);
                int rows, cols, rowSpan, colSpan;
                layout->getItemPosition(idx, &rows, &cols, &rowSpan, &colSpan);
                if (colSpan > 1) {
                    continue;
                }

                const int right = left + widget->sizeHint().width();
                if (maxRight < right) {
                    maxRight = right;
                }
            }
        }
```

#### AUTO 


```{c}
auto mimeData = new QMimeData;
```

#### AUTO 


```{c}
auto tabbedContainer = qobject_cast<Konsole::TabbedViewContainer *>(mainWindow->centralWidget());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &hotSpot : _filterChain->hotSpots()) {
        QRect r;
        r.setLeft(hotSpot->startColumn());
        r.setTop(hotSpot->startLine());
        if (hotSpot->startLine() == hotSpot->endLine()) {
            r.setRight(hotSpot->endColumn());
            r.setBottom(hotSpot->endLine());
            region |= imageToWidget(r);
        } else {
            r.setRight(_columns);
            r.setBottom(hotSpot->startLine());
            region |= imageToWidget(r);

            r.setLeft(0);

            for (int line = hotSpot->startLine() + 1 ; line < hotSpot->endLine(); line++) {
                r.moveTop(line);
                region |= imageToWidget(r);
            }

            r.moveTop(hotSpot->endLine());
            r.setRight(hotSpot->endColumn());
            region |= imageToWidget(r);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &[view, font] : zoomFontSizes) {
        view->terminalFont()->setVTFont(font);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QTableWidgetItem *item : selectedItems) {
        if (item->column() == 1) { //Select item at the first column
            item = _ui->keyBindingTable->item(item->row(), 0);
        }

        if (!uniqueList.contains(item)) {
            uniqueList.append(item);
        }
    }
```

#### AUTO 


```{c}
auto cmdArg = cmdArgIter.next();
```

#### AUTO 


```{c}
const auto jsonTabs = QJsonDocument::fromJson(tabList).array();
```

#### LAMBDA EXPRESSION 


```{c}
[](double v) {
            return 50.0 - qAbs(v - 50.0);
        }
```

#### AUTO 


```{c}
const auto removeLineType = [&packedLineTypes](quint8 lineId)->void {
        lineId = LinesNum - 1 - lineId % LinesNum;
        packedLineTypes &= ~(3 << (2 * lineId));
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &spot : spots) {
        QRegion region;
        if (spot->type() == HotSpot::Link || spot->type() == HotSpot::EMailAddress) {
            QRect r;
            if (spot->startLine() == spot->endLine()) {
                r.setCoords(spot->startColumn()*_fontWidth + _contentRect.left(),
                            spot->startLine()*_fontHeight + _contentRect.top(),
                            (spot->endColumn())*_fontWidth + _contentRect.left() - 1,
                            (spot->endLine() + 1)*_fontHeight + _contentRect.top() - 1);
                region |= r;
            } else {
                r.setCoords(spot->startColumn()*_fontWidth + _contentRect.left(),
                            spot->startLine()*_fontHeight + _contentRect.top(),
                            (_columns)*_fontWidth + _contentRect.left() - 1,
                            (spot->startLine() + 1)*_fontHeight + _contentRect.top() - 1);
                region |= r;
                for (int line = spot->startLine() + 1 ; line < spot->endLine() ; line++) {
                    r.setCoords(0 * _fontWidth + _contentRect.left(),
                                line * _fontHeight + _contentRect.top(),
                                (_columns)*_fontWidth + _contentRect.left() - 1,
                                (line + 1)*_fontHeight + _contentRect.top() - 1);
                    region |= r;
                }
                r.setCoords(0 * _fontWidth + _contentRect.left(),
                            spot->endLine()*_fontHeight + _contentRect.top(),
                            (spot->endColumn())*_fontWidth + _contentRect.left() - 1,
                            (spot->endLine() + 1)*_fontHeight + _contentRect.top() - 1);
                region |= r;
            }

            if (_showUrlHint && urlNumber >= 0 && urlNumber < 10 && spot->type() == HotSpot::Link) {
                // Position at the beginning of the URL
                QRect hintRect(*region.begin());
                hintRect.setWidth(r.height());
                painter.fillRect(hintRect, QColor(0, 0, 0, 128));
                painter.setPen(Qt::white);
                painter.drawRect(hintRect.adjusted(0, 0, -1, -1));
                painter.drawText(hintRect, Qt::AlignCenter, QString::number(urlNumber));

                urlNumber += urlNumInc;
            }
        }

        for (int line = spot->startLine() ; line <= spot->endLine() ; line++) {
            int startColumn = 0;
            int endColumn = _columns - 1; // TODO use number of _columns which are actually
            // occupied on this line rather than the width of the
            // display in _columns

            // Check image size so _image[] is valid (see makeImage)
            if (endColumn >= _columns || line >= _lines) {
                break;
            }

            // ignore whitespace at the end of the lines
            while (_image[loc(endColumn, line)].isSpace() && endColumn > 0) {
                endColumn--;
            }

            // increment here because the column which we want to set 'endColumn' to
            // is the first whitespace character at the end of the line
            endColumn++;

            if (line == spot->startLine()) {
                startColumn = spot->startColumn();
            }
            if (line == spot->endLine()) {
                endColumn = spot->endColumn();
            }

            // TODO: resolve this comment with the new margin/center code
            // subtract one pixel from
            // the right and bottom so that
            // we do not overdraw adjacent
            // hotspots
            //
            // subtracting one pixel from all sides also prevents an edge case where
            // moving the mouse outside a link could still leave it underlined
            // because the check below for the position of the cursor
            // finds it on the border of the target area
            QRect r;
            r.setCoords(startColumn * _fontWidth + _contentRect.left(),
                        line * _fontHeight + _contentRect.top(),
                        endColumn * _fontWidth + _contentRect.left() - 1,
                        (line + 1)*_fontHeight + _contentRect.top() - 1);
            // Underline link hotspots
            const bool hasMouse = region.contains(mapFromGlobal(QCursor::pos()));
            if ((spot->type() == HotSpot::Link && _showUrlHint) || hasMouse) {
                QFontMetrics metrics(font());

                // find the baseline (which is the invisible line that the characters in the font sit on,
                // with some having tails dangling below)
                const int baseline = r.bottom() - metrics.descent();
                // find the position of the underline below that
                const int underlinePos = baseline + metrics.underlinePos();
                painter.drawLine(r.left() , underlinePos, r.right() , underlinePos);

                // Marker hotspots simply have a transparent rectangular shape
                // drawn on top of them
            } else if (spot->type() == HotSpot::Marker) {
                //TODO - Do not use a hardcoded color for this
                const bool isCurrentResultLine = (_screenWindow->currentResultLine() == (spot->startLine() + _screenWindow->currentLine()));
                QColor color = isCurrentResultLine ? QColor(255, 255, 0, 120) : QColor(255, 0, 0, 120);
                painter.fillRect(r, color);
            }
        }
    }
```

#### AUTO 


```{c}
const auto hotspots = _hotspots.values(line);
```

#### AUTO 


```{c}
auto index = indexOf(controller->view());
```

#### AUTO 


```{c}
auto [error, errorString] = checkFields();
```

#### AUTO 


```{c}
auto dirtyMask = new char[columnsToUpdate + 2];
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &lineCharacter : putToScreen) {
        screen.displayCharacter(lineCharacter.toLatin1());
    }
```

#### AUTO 


```{c}
auto maybeTerminalDisplay = qobject_cast<TerminalDisplay *>(widget(i))
```

#### LAMBDA EXPRESSION 


```{c}
[this, action]() {
        toggleAllowMouseTracking(action);
    }
```

#### AUTO 


```{c}
const auto list = group.readPathEntry("Recent URLs", QStringList());
```

#### LAMBDA EXPRESSION 


```{c}
[](int total, LineData ld) {
            return total + ld.length;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(const int width: qAsConst(widthsSortOrder)) {
        const auto currentMergedRangesIt = mergedRanges.find(width);
        if(currentMergedRangesIt == mergedRanges.end() || currentMergedRangesIt.value().isEmpty())
            continue;
        for(const auto &range: currentMergedRangesIt.value()) {
            if(range.first != range.second)
                out << QString::asprintf("%06X..%06X ; %2d\n", range.first, range.second, int(width));
            else
                out << QString::asprintf("%06X         ; %2d\n", range.first, int(width));
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QPainter& painter, bool friendly) {
        printContent(painter, friendly);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[boldWeight](const QFont &font) {
        return font.weight() >= boldWeight;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& file : fileNames) {
            profiles.append(dir + QLatin1Char('/') + file);
        }
```

#### AUTO 


```{c}
auto bm = QUrl::fromPercentEncoding(bm_url.url().toUtf8());
```

#### AUTO 


```{c}
auto *generalPageWidget = new QWidget(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &entry : qAsConst(changedEntries)) {
        switch (entry.status()) {
        case KNS3::Entry::Installed:
            for (const auto &file : entry.installedFiles()) {
                if (ColorSchemeManager::instance()->loadColorScheme(file)) {
                    continue;
                }
                qWarning() << "Failed to load file" << file;
                ++failures;
            }
            if (failures == entry.installedFiles().size()) {
                _appearanceUi->colorSchemeMessageWidget->setText(
                            xi18nc("@info",
                                   "Scheme <resource>%1</resource> failed to load.",
                                   entry.name()));
                _appearanceUi->colorSchemeMessageWidget->animatedShow();
                QTimer::singleShot(8000,
                                   _appearanceUi->colorSchemeMessageWidget,
                                   &KMessageWidget::animatedHide);
            }
            break;
        case KNS3::Entry::Deleted:
            for (const auto &file : entry.uninstalledFiles()) {
                if (ColorSchemeManager::instance()->unloadColorScheme(file)) {
                    continue;
                }
                qWarning() << "Failed to unload file" << file;
                // If unloading fails we do not care. Iff the scheme failed here
                // it either wasn't loaded or was invalid to begin with.
            }
            break;
        case KNS3::Entry::Invalid:
        case KNS3::Entry::Installing:
        case KNS3::Entry::Downloadable:
        case KNS3::Entry::Updateable:
        case KNS3::Entry::Updating:
            // Not interesting.
            break;
        }
    }
```

#### AUTO 


```{c}
const auto dragId = QStringLiteral("konsole/terminal_display");
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &p : params) {
            int eq = p.indexOf(QLatin1Char('='));
            if (eq > 0) {
                QString var = p.mid(0, eq);
                QString val = p.mid(eq + 1);
                if (var == QLatin1String("inline")) {
                    if (val != QLatin1String("1")) {
                        return;
                    }
                }
                if (var == QLatin1String("preserveAspectRatio")) {
                    if (val == QLatin1String("0")) {
                        keepAspect = 0;
                    }
                }
                if (var == QLatin1String("width")) {
                    int unitPos = val.toStdString().find_first_not_of("0123456789");
                    scaledWidth = val.mid(0, unitPos).toInt();
                    if (unitPos == -1) {
                        scaledWidth *= _currentScreen->currentTerminalDisplay()->terminalFont()->fontWidth();
                    } else {
                        if (val.mid(unitPos) == QLatin1String("%")) {
                            scaledWidth *= _currentScreen->currentTerminalDisplay()->terminalFont()->fontWidth() * _currentScreen->getColumns() / 100;
                        }
                    }
                }
                if (var == QLatin1String("height")) {
                    int unitPos = val.toStdString().find_first_not_of("0123456789");
                    scaledHeight = val.mid(0, unitPos).toInt();
                    if (unitPos == -1) {
                        scaledHeight *= _currentScreen->currentTerminalDisplay()->terminalFont()->fontHeight();
                    } else {
                        if (val.mid(unitPos) == QLatin1String("%")) {
                            scaledHeight *= _currentScreen->currentTerminalDisplay()->terminalFont()->fontHeight() * _currentScreen->getLines() / 100;
                        }
                    }
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto splitter : splitters) {
            splitter->setVisible(true);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &schema : _allowedUriSchemas) {
        if (url.startsWith(schema)) {
            return;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &entry : qAsConst(changedEntries)) {
        switch (entry.status()) {
        case KNS3::Entry::Installed:
            for (const QString &file : entry.installedFiles()) {
                if (ColorSchemeManager::instance()->loadColorScheme(file)) {
                    continue;
                }
                qWarning() << "Failed to load file" << file;
                ++failures;
            }
            if (failures == entry.installedFiles().size()) {
                _appearanceUi->colorSchemeMessageWidget->setText(xi18nc("@info", "Scheme <resource>%1</resource> failed to load.", entry.name()));
                _appearanceUi->colorSchemeMessageWidget->animatedShow();
                QTimer::singleShot(8000, _appearanceUi->colorSchemeMessageWidget, &KMessageWidget::animatedHide);
            }
            break;
        case KNS3::Entry::Deleted:
            for (const auto &file : entry.uninstalledFiles()) {
                if (ColorSchemeManager::instance()->unloadColorScheme(file)) {
                    continue;
                }
                qWarning() << "Failed to unload file" << file;
                // If unloading fails we do not care. If the scheme failed here
                // it either wasn't loaded or was invalid to begin with.
            }
            break;
        case KNS3::Entry::Invalid:
        case KNS3::Entry::Installing:
        case KNS3::Entry::Downloadable:
        case KNS3::Entry::Updateable:
        case KNS3::Entry::Updating:
            // Not interesting.
            break;
        }
    }
```

#### AUTO 


```{c}
auto colorItem = new QTableWidgetItem();
```

#### AUTO 


```{c}
const auto fgFactor = 5.5;
```

#### AUTO 


```{c}
auto *settings = KonsoleSettings::self();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : selected) {
        bool needTransparency = index.data(Qt::UserRole + 1).value<const ColorScheme *>()->opacity() < 1.0;

        if (!needTransparency) {
            _appearanceUi->transparencyWarningWidget->setHidden(true);
        } else if (!KWindowSystem::compositingActive()) {
            _appearanceUi->transparencyWarningWidget->setText(
                i18n("This color scheme uses a transparent background"
                     " which does not appear to be supported on your"
                     " desktop"));
            _appearanceUi->transparencyWarningWidget->setHidden(false);
        } else if (!WindowSystemInfo::HAVE_TRANSPARENCY) {
            _appearanceUi->transparencyWarningWidget->setText(
                i18n("Konsole was started before desktop effects were enabled."
                     " You need to restart Konsole to see transparent background."));
            _appearanceUi->transparencyWarningWidget->setHidden(false);
        }
    }
```

#### AUTO 


```{c}
auto profile = SessionManager::instance()->sessionProfile(_sessionController->session());
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        QSet<Session *> newGroup = dialog->chosenSessions();
        newGroup.remove(session());

        const QSet<Session *> completeGroup = newGroup | currentGroup;
        for (Session *session : completeGroup) {
            if (newGroup.contains(session) && !currentGroup.contains(session)) {
                _copyToGroup->addSession(session);
            } else if (!newGroup.contains(session) && currentGroup.contains(session)) {
                _copyToGroup->removeSession(session);
            }
        }

        _copyToGroup->setMasterStatus(session(), true);
        _copyToGroup->setMasterMode(SessionGroup::CopyInputToAll);
        snapshot();
        Q_EMIT copyInputChanged(this);
    }
```

#### AUTO 


```{c}
auto scrollFullPage = profile->property<int>(Profile::ScrollFullPage);
```

#### AUTO 


```{c}
const auto y = _headerBar->isVisible() ? _headerBar->height() : 0;
```

#### RANGE FOR STATEMENT 


```{c}
for (const Profile::Ptr &profile : allProfiles) {
        if (!profile->isHidden()) {
            names.push_back(profile->name());
        }
    }
```

#### AUTO 


```{c}
auto entry
```

#### AUTO 


```{c}
auto *copyInputToSelectedTabsAction = collection->add<KToggleAction>(QStringLiteral("copy-input-to-selected-tabs"));
```

#### RANGE FOR STATEMENT 


```{c}
for (TerminalDisplay *view : session->views()) {
        view->screenWindow()->screen()->urlExtractor()->setAllowedLinkSchema(profile->escapedLinksSchema());
    }
```

#### AUTO 


```{c}
auto *activeButton = options.group->button(currentValue);
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        doPaste(terminalClipboard::pasteFromClipboard(), false);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto & i : profile)
        i->setProperty(Profile::HistorySize, 1234);
```

#### AUTO 


```{c}
const auto* hostnameValidator = new QRegularExpressionValidator(hostnameRegex, this);
```

#### AUTO 


```{c}
const auto defaultIcon = QIcon::fromTheme(QStringLiteral("utilities-terminal"));
```

#### LAMBDA EXPRESSION 


```{c}
[&keySequence, &profile](const ShortcutData &data) {
        return data.profileKey != profile && data.keySeq == keySequence;
    }
```

#### AUTO 


```{c}
auto ldrawContents = [this](QPainter &paint, const QRect &rect, bool friendly) {
        _terminalPainter->drawContents(_image, paint, rect, friendly, _imageSize, _bidiEnabled, _lineProperties);
    };
```

#### AUTO 


```{c}
auto *maybeTerminalDisplay = qobject_cast<TerminalDisplay*>(widget);
```

#### AUTO 


```{c}
auto *profilePage = new KPageWidgetItem(profileSettings, profilePageName);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &k : line) {
        if (!(k.equalsFormat(c))) {
            new_formatLength++; // format change detected
            c = k;
        }
    }
```

#### AUTO 


```{c}
const auto u = i - 16;
```

#### LAMBDA EXPRESSION 


```{c}
[](std::vector<LineData> &change, int length, LineProperty flag) {
        change.push_back({length, flag});
    }
```

#### AUTO 


```{c}
auto *hist_line = getCharacterBuffer(hist_linelen + _screenLines[0].count());
```

#### AUTO 


```{c}
auto urls = event->mimeData()->urls();
```

#### LAMBDA EXPRESSION 


```{c}
[](const ExtractedUrl &url) {
                                      const bool toRemove = url.begin.row < 0;
                                      return toRemove;
                                  }
```

#### AUTO 


```{c}
auto currentFlags = QAbstractTableModel::flags(idx);
```

#### AUTO 


```{c}
auto* terminal = qobject_cast<TerminalDisplay*>(child)
```

#### AUTO 


```{c}
auto *parentLayout = qobject_cast<QLayout *>(layout->parent());
```

#### AUTO 


```{c}
auto editor = new KeyBindingEditor;
```

#### AUTO 


```{c}
auto cmd        = match.captured(cmdGroupName);
```

#### AUTO 


```{c}
auto lgetBackgroundColor = [this]() {
        return getBackgroundColor();
    };
```

#### AUTO 


```{c}
auto cmd = match.captured(cmdGroupName);
```

#### AUTO 


```{c}
auto view = _sessionDisplayConnection->view();
```

#### AUTO 


```{c}
auto match = std::find_if(_currentDirContents.cbegin(), _currentDirContents.cend(),
                                  [&filename](const QString &s) {
                                      return filename == s // It's a direct child file or dir
                                            || filename.startsWith(s + QLatin1Char{':'}) // filename:lineNumber (output of grep -n)
                                            || filename.startsWith(s + QLatin1Char{'/'}); // It's inside a child dir
                                });
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &i : profile) {
        group->addProfile(i);
        QVERIFY(group->profiles().contains(i));
        QVERIFY(!group_const->profiles().contains(i));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QChar &c : text) {
        if (isUnsafe(c)) {
            const QString sequence = charToSequence(c);
            const QString description = characterDescriptions.value(c.unicode(), QString());
            QString entry = QStringLiteral("U+%1").arg(c.unicode(), 4, 16, QLatin1Char('0'));
            if(!sequence.isEmpty()) {
                entry += QStringLiteral("\t%1").arg(sequence);
            }
            if(!description.isEmpty()) {
                entry += QStringLiteral("\t%1").arg(description);
            }
            unsafeCharacters.append(entry);
        }
    }
```

#### AUTO 


```{c}
const auto tmpList = dir.entryList(QDir::Dirs | QDir::Files);
```

#### AUTO 


```{c}
auto behavior = QStyle::RequestSoftwareInputPanel(style()->styleHint(QStyle::SH_RequestSoftwareInputPanel));
```

#### AUTO 


```{c}
const auto isSameScript = [&](int column) {
                    const QChar::Script script = QChar::script(baseCodePoint(image[display->loc(column, y)]));
                    if (currentScript == QChar::Script_Common || script == QChar::Script_Common
                        || currentScript == QChar::Script_Inherited || script == QChar::Script_Inherited) {
                        return true;
                    }
                    return currentScript == script;
                };
```

#### AUTO 


```{c}
auto container = manager->activeContainer();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Profile::Ptr &profile : profiles) {
                    if (profile->name() == profileDialog->lookupProfile()->name()
                        && profileDialog->isVisible()) {
                        // close opened edit dialog
                        profileDialog->close();
                    }
                }
```

#### AUTO 


```{c}
auto *generalPage = new KPageWidgetItem(new GeneralSettings(confDialog), generalPageName);
```

#### AUTO 


```{c}
auto reader = new ProfileReader();
```

#### AUTO 


```{c}
const auto &state = _tabIconState[topLevelSplitter];
```

#### AUTO 


```{c}
const auto display = qobject_cast<TerminalDisplay*>(sender());
```

#### AUTO 


```{c}
auto cursorPos = mapFromGlobal(QCursor::pos());
```

#### LAMBDA EXPRESSION 


```{c}
[this, dlg]() {
            updateTempProfileProperty(Profile::TextEditorCmdCustom, dlg->textValue());
        }
```

#### AUTO 


```{c}
auto item = new QStandardItem();
```

#### AUTO 


```{c}
auto sourceIdx = priv->filterModel->mapToSource(idx);
```

#### LAMBDA EXPRESSION 


```{c}
[this]{ emit newViewRequest(); }
```

#### AUTO 


```{c}
const auto matchStyleSheet = QStringLiteral("QLineEdit{ background-color:%1 }").arg(backgroundBrush.brush(_searchEdit->palette()).color().name());
```

#### RANGE FOR STATEMENT 


```{c}
for (const Profile::Ptr &profile : qAsConst(profiles)) {
        addItems(profile);
    }
```

#### AUTO 


```{c}
auto *editor = qobject_cast<FilteredKeySequenceEdit*>(sender());
```

#### LAMBDA EXPRESSION 


```{c}
[&](int column) { return column <= rect.right(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool) {
                const auto message = i18nc("@info:whatsthis", "When using this option, the scrollback data will be written unencrypted to temporary files. Those temporary files will be deleted automatically when Konsole is closed in a normal manner.<br/>Use <i>Settings ? Configure Konsole ? File Location</i> to select the location of the temporary files.");
                const QPoint pos = QPoint(_ui->unlimitedHistoryWrapper->width() / 2, _ui->unlimitedHistoryWrapper->height());
                QWhatsThis::showText(_ui->unlimitedHistoryWrapper->mapToGlobal(pos), message, _ui->unlimitedHistoryWrapper);
            }
```

#### AUTO 


```{c}
const auto hostnameRegex = QRegularExpression(
        QStringLiteral(R"(^[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$)")
    );
```

#### LAMBDA EXPRESSION 


```{c}
[closeAction] {
        closeAction->setVisible(!KonsoleSettings::showQuickButtons());
    }
```

#### AUTO 


```{c}
const auto canBeGrouped = [&](int column) {
                    return _display->_image[loc(column, y)].character <= 0x7e
                            || (_display->_image[loc(column, y)].rendition & RE_EXTENDED_CHAR)
                            || (_display->_bidiEnabled && !doubleWidth);
                };
```

#### AUTO 


```{c}
const auto middleClickPasteMode = profile->property<int>(Profile::MiddleClickPasteMode);
```

#### LAMBDA EXPRESSION 


```{c}
[](double v) { return v; }
```

#### RANGE FOR STATEMENT 


```{c}
for (TerminalDisplay *terminalDisplay : viewsList) {
        if (terminalDisplay != _view) {
            terminalDisplay->updateReadOnlyState(isReadOnly());
        }
        emit readOnlyChanged(this);
    }
```

#### AUTO 


```{c}
const auto &escapedUrl
```

#### AUTO 


```{c}
auto data = ssh_item->data(SSHRole).value<SSHConfigurationData>();
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : actionsList) {
        if (action->data().value<Profile::Ptr>() == profile) {
            return action;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](int index) {
        if (index != -1) {
            widget(index)->setFocus();
        }
    }
```

#### AUTO 


```{c}
auto match = mit.next();
```

#### LAMBDA EXPRESSION 


```{c}
[this](QPainter &painter, const QRect &rect, const QColor &backgroundColor, bool useOpacitySetting) {
        Q_EMIT drawBackground(painter, rect, backgroundColor, useOpacitySetting);
    }
```

#### AUTO 


```{c}
auto shadowColor = p.color(QPalette::ColorRole::Shadow);
```

#### AUTO 


```{c}
auto terminal = qobject_cast<TerminalDisplay *>(currentWidget)
```

#### CONST EXPRESSION 


```{c}
static constexpr unsigned int CODE_POINTS_NUM = 0x110000;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QMimeType &mimeType : mimeDatabase.allMimeTypes()) {
        patterns.append(mimeType.globPatterns());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[path, job, openUrl]() {
            if (job->error()) {
                // TODO: use KMessageWidget (like the "terminal is read-only" message)
                KMessageBox::sorry(QApplication::activeWindow(),
                                   i18n("Could not open file with the text editor specified in the profile settings;\n"
                                        "it will be opened with the system default editor."));

                openUrl(path);
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&](int column) {
                return image[display->loc(column, y)].character <= 0x7e || (image[display->loc(column, y)].rendition & RE_EXTENDED_CHAR)
                    || (bidiEnabled && !doubleWidth);
            }
```

#### AUTO 


```{c}
auto viewSplitter = new ViewSplitter();
```

#### AUTO 


```{c}
auto view = _sessionMap.key(session);
```

#### AUTO 


```{c}
auto profile = profileIdItem->data().value<Profile::Ptr>();
```

#### AUTO 


```{c}
auto ldrawContents = [this](QPainter &paint, const QRect &rect, bool friendly) {
        _terminalPainter->drawContents(paint, rect, friendly);
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &groupName : config.groupList()) {
        KConfigGroup group = config.group(groupName);
        addTopLevelItem(groupName);
        for (const QString &commandGroup : group.groupList()) {
            QuickCommandData data;
            KConfigGroup element = group.group(commandGroup);
            data.name = element.readEntry("name");
            data.tooltip = element.readEntry("tooltip");
            data.command = element.readEntry("command");
            addChildItem(data, groupName);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { return _terminalFont->getVTFont(); }
```

#### AUTO 


```{c}
auto selection = ui->treeView->selectionModel()->selectedIndexes();
```

#### LAMBDA EXPRESSION 


```{c}
[&filename](const QString &s) {
                                      return filename == s // It's a direct child file or dir
                                            || filename.startsWith(s + QLatin1Char{':'}) // filename:lineNumber (output of grep -n)
                                            || filename.startsWith(s + QLatin1Char{'/'}); // It's inside a child dir
                                }
```

#### AUTO 


```{c}
auto actionEdit = new QAction(QStringLiteral("Edit"), ui->commandsTreeView);
```

#### AUTO 


```{c}
const auto fm = option.fontMetrics;
```

#### LAMBDA EXPRESSION 


```{c}
[profile]() {
        ProfileManager::instance()->addProfile(profile);
        ProfileManager::instance()->changeProfile(profile, profile->setProperties());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *filter : _filters) {
        filter->process();
    }
```

#### AUTO 


```{c}
const auto generatorName = generator.left(sepPos);
```

#### AUTO 


```{c}
auto it = std::find_if(_shortcuts.cbegin(), _shortcuts.cend(), [&profile](const ShortcutData &data) {
        return data.profileKey == profile;
    });
```

#### LAMBDA EXPRESSION 


```{c}
[&](int column) {
                const int characterLoc = qMin(loc(column, y) + 1, _imageSize - 1);
                return (_image[characterLoc].character == 0) == doubleWidth;
            }
```

#### AUTO 


```{c}
auto tabBarPage = new KPageWidgetItem(new TabBarSettings(confDialog), tabBarPageName);
```

#### AUTO 


```{c}
auto mimeData = new QMimeData();
```

#### AUTO 


```{c}
const auto droppedEdge = currentDragTarget->droppedEdge();
```

#### AUTO 


```{c}
auto *job = new KIO::OpenUrlJob(url);
```

#### AUTO 


```{c}
auto sdsp
```

#### AUTO 


```{c}
auto *action = new QAction(this);
```

#### AUTO 


```{c}
const auto urlList = rootGroup.groupUrlList();
```

#### AUTO 


```{c}
const auto idx = ui->commandsTreeView->currentIndex();
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &url) {
            QDesktopServices::openUrl(QUrl(url));
        }
```

#### AUTO 


```{c}
auto *parentWidget = layout->parentWidget();
```

#### LAMBDA EXPRESSION 


```{c}
[&](int column) {
                    return (_display->_image[_display->loc(column, y)].rendition & ~RE_EXTENDED_CHAR)
                        == (currentRendition & ~RE_EXTENDED_CHAR);
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this]{ renameTab(_contextMenuTabIndex); }
```

#### AUTO 


```{c}
auto editor = new FilteredKeySequenceEdit(parent);
```

#### AUTO 


```{c}
auto manager = window->findChild<ViewManager*>();
```

#### AUTO 


```{c}
auto *mousePageItem = addPage(mousePageWidget, mousePageName);
```

#### AUTO 


```{c}
auto *model = qobject_cast<QStandardItemModel *>(_keyboardUi->keyBindingList->model());
```

#### AUTO 


```{c}
auto warningButtonSizePolicy = _ui->fixedSizeHistoryWarningButton->sizePolicy();
```

#### LAMBDA EXPRESSION 


```{c}
[&profile](const ShortcutData &data) {
        return data.profileKey == profile;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]{
        emit newViewRequest();
    }
```

#### AUTO 


```{c}
const auto &jsonSplitter
```

#### LAMBDA EXPRESSION 


```{c}
[this](QPainter &painter, bool friendly) {
        
        QPoint columnLines(_usedLines, _usedColumns);
        auto lfontget = [this]() { return _terminalFont->getVTFont(); };
        auto lfontset = [this](const QFont &f) { _terminalFont->setVTFont(f); };

        _printManager->printContent(painter, friendly, columnLines, lfontget, lfontset);
    }
```

#### AUTO 


```{c}
auto *terminal = qobject_cast<TerminalDisplay *>(sender())
```

#### AUTO 


```{c}
auto *l
```

#### AUTO 


```{c}
auto switchToTabMapper = new QSignalMapper(this);
```

#### CONST EXPRESSION 


```{c}
static constexpr const int RANGE_LUT_LIST_SIZE = 4;
```

#### LAMBDA EXPRESSION 


```{c}
[this, path, job]() {
        if (job->error() != 0) {
            // TODO: use KMessageWidget (like the "terminal is read-only" message)
            KMessageBox::sorry(QApplication::activeWindow(),
                               i18n("Could not open file with the text editor specified in the profile settings;\n"
                                    "it will be opened with the system default editor."));

            openWithSysDefaultApp(path);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (ScreenWindow *window : qAsConst(_windows)) {
        delete window;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QPainter &painter,
            const QRect &rect, const QColor &backgroundColor, bool useOpacitySetting) {
        Q_EMIT drawBackground(painter, rect, backgroundColor, useOpacitySetting);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        if (viewManager()) {
            viewManager()->loadLayoutFile();
        }
    }
```

#### AUTO 


```{c}
const auto* window = qobject_cast<const KXmlGuiWindow*>(object);
```

#### AUTO 


```{c}
auto *container = new TabbedViewContainer(this, nullptr);
```

#### AUTO 


```{c}
const auto isInsideDrawArea = [&](int column) { return column <= rect.right(); };
```

#### AUTO 


```{c}
auto match = std::find_if(_currentDirContents.cbegin(), _currentDirContents.cend(),
                              [filename](const QString &s) { return filename.startsWith(s); });
```

#### AUTO 


```{c}
auto lambda = [this](QPainter& painter, bool friendly) {
        printContent(painter, friendly);
    };
```

#### LAMBDA EXPRESSION 


```{c}
[&](int column) {
                return LineBlockCharacters::canDraw(image[display->loc(column, y)].character) == lineDraw;
            }
```

#### AUTO 


```{c}
const auto initialBG = c1;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &session : sessionsList) {
        dialog->setWindowTitle(i18n("Save Output From %1", session->title(Session::NameRole)));

        int result = dialog->exec();

        if (result != QDialog::Accepted) {
            continue;
        }

        QUrl url = (dialog->selectedUrls()).at(0);

        if (!url.isValid()) {
            // UI:  Can we make this friendlier?
            KMessageBox::sorry(nullptr , i18n("%1 is an invalid URL, the output could not be saved.", url.url()));
            continue;
        }

        // Save selected URL for next time
        _saveDialogRecentURL = url.adjusted(QUrl::RemoveFilename|QUrl::StripTrailingSlash).toString();
        group.writePathEntry("Recent URLs", _saveDialogRecentURL);

        KIO::TransferJob* job = KIO::put(url,
                                         -1,   // no special permissions
                                         // overwrite existing files
                                         // do not resume an existing transfer
                                         // show progress information only for remote
                                         // URLs
                                         KIO::Overwrite | (url.isLocalFile() ? KIO::HideProgressInfo : KIO::DefaultFlags)
                                         // a better solution would be to show progress
                                         // information after a certain period of time
                                         // instead, since the overall speed of transfer
                                         // depends on factors other than just the protocol
                                         // used
                                        );

        SaveJob jobInfo;
        jobInfo.session = session;
        jobInfo.lastLineFetched = -1;  // when each request for data comes in from the KIO subsystem
        // lastLineFetched is used to keep track of how much of the history
        // has already been sent, and where the next request should continue
        // from.
        // this is set to -1 to indicate the job has just been started

        if (((dialog->selectedNameFilter()).contains(QLatin1String("html"), Qt::CaseInsensitive)) ||
           ((dialog->selectedFiles()).at(0).endsWith(QLatin1String("html"), Qt::CaseInsensitive))) {
            Profile::Ptr profile = SessionManager::instance()->sessionProfile(session);
            jobInfo.decoder = new HTMLDecoder(profile);
        } else {
            jobInfo.decoder = new PlainTextDecoder();
        }

        _jobSession.insert(job, jobInfo);

        connect(job, &KIO::TransferJob::dataReq, this, &Konsole::SaveHistoryTask::jobDataRequested);
        connect(job, &KIO::TransferJob::result, this, &Konsole::SaveHistoryTask::jobResult);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (TerminalDisplay *terminalDisplay : viewsList) {
        if (terminalDisplay != _view.data()) {
            terminalDisplay->updateReadOnlyState(isReadOnly());
        }
    }
```

#### AUTO 


```{c}
auto tabbedContainer = new TabbedViewContainer(_navigationPosition, this, _viewSplitter);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QObject *child: parentObj->children()) {
            if (!child->objectName().startsWith(ManagedNamePrefix)) {
                continue;
            }

            const char *className = child->metaObject()->className();
            if (qstrcmp(className, "QButtonGroup") == 0) {
                add(qobject_cast<const QButtonGroup *>(child));
            }
        }
```

#### AUTO 


```{c}
const auto lightnessIntervals = (minLightness < 50.0 && 50.0 < maxLightness)
        ? std::initializer_list<double>{minLightness, 50.0, maxLightness}
        : std::initializer_list<double>{minLightness, maxLightness};
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &searchProvider : searchProviders) {
                action = new QAction(searchProvider, _webSearchMenu);
                action->setIcon(QIcon::fromTheme(filterData.iconNameForPreferredSearchProvider(searchProvider)));
                action->setData(filterData.queryForPreferredSearchProvider(searchProvider));
                connect(action, &QAction::triggered, this, [this, action]() {
                    handleWebShortcutAction(action);
                });
                _webSearchMenu->addAction(action);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Profile::Ptr &profile) { newFromProfile(_viewManager->activeContainer(), profile);}
```

#### LAMBDA EXPRESSION 


```{c}
[=](const KNSCore::EntryInternal::List &entries) {
        const QString &name = selected.first().data(Qt::UserRole + 1).value<const ColorScheme *>()->name();
        Q_ASSERT(!name.isEmpty());
        bool uninstalled = false;
        // Check if the theme was installed by KNS, if so uninstall it through
        // there and unload it.
        for (auto &entry : entries) {
            for (const auto &file : entry.installedFiles()) {
                if (ColorSchemeManager::colorSchemeNameFromPath(file) != name) {
                    continue;
                }
                // Make sure the manager can unload it before uninstalling it.
                if (ColorSchemeManager::instance()->unloadColorScheme(file)) {
                    manager->uninstallEntry(entry);
                    uninstalled = true;
                }
            }
            if (uninstalled) {
                break;
            }
        }

        // If KNS wasn't able to remove it is a custom theme and we'll drop
        // it manually.
        if (!uninstalled) {
            uninstalled = ColorSchemeManager::instance()->deleteColorScheme(name);
        }

        if (uninstalled) {
            _appearanceUi->colorSchemeList->model()->removeRow(selected.first().row());
        }

        manager->deleteLater();
    }
```

#### AUTO 


```{c}
const auto tooltipString = QStringLiteral("<img src='data:image/png;base64, %0'>")
        .arg(QString::fromLocal8Bit(data.toBase64()));
```

#### AUTO 


```{c}
const auto shortcutString = index.data(Qt::DisplayRole).toString();
```

#### AUTO 


```{c}
const auto ranges = rangesFromWidths(widths);
```

#### AUTO 


```{c}
auto action
```

#### AUTO 


```{c}
const auto x = width() - scrollBarWidth - _searchBar->width();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        if (viewManager()) { viewManager()->loadLayoutFile(); }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&processChildren](ViewSplitter *viewSplitter) -> void {
        // divide the size of the parent widget by the amount of children splits
        auto hintSize = viewSplitter->size();
        auto sizes = viewSplitter->sizes();
        auto sharedSize = hintSize / sizes.size();
        if (viewSplitter->orientation() == Qt::Horizontal) {
            for (auto &&size : sizes) {
                size = sharedSize.width();
            }
        } else {
            for (auto &&size : sizes) {
                size = sharedSize.height();
            }
        }
        // set new sizes
        viewSplitter->setSizes(sizes);

        // set equal sizes for each splitter children
        for (auto &&child : viewSplitter->children()) {
            auto childViewSplitter = qobject_cast<ViewSplitter *>(child);
            if (childViewSplitter) {
                processChildren(childViewSplitter);
            }
        }
    }
```

#### AUTO 


```{c}
auto collection = sessionController->actionCollection();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Session *s : sessionsList) {
                    const QList<TerminalDisplay *> displayList = s->views();
                    for (const TerminalDisplay *display : displayList) {
                        usedExtendedChars += display->screenWindow()->screen()->usedExtendedChars();
                    }
                }
```

#### AUTO 


```{c}
auto profileMenu = new QMenu(this);
```

#### LAMBDA EXPRESSION 


```{c}
[](const EdgeDistance& left, const EdgeDistance& right) -> bool {
            return left.first < right.first;
        }
```

#### AUTO 


```{c}
auto actionDelete = new QAction(i18n("Delete"), ui->commandsTreeView);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QRect &rect : qAsConst(dirtyImageRegion)) {
        emit drawContents(_image, paint, rect, false, _imageSize, _bidiEnabled, _lineProperties);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &spot : spots) {
        QRegion region;
        if (spot->type() == HotSpot::Link || spot->type() == HotSpot::EMailAddress || spot->type() == HotSpot::EscapedUrl) {
            QRect r;
            if (spot->startLine() == spot->endLine()) {
                r.setCoords(spot->startColumn()*_fontWidth + _contentRect.left(),
                            spot->startLine()*_fontHeight + _contentRect.top(),
                            (spot->endColumn())*_fontWidth + _contentRect.left() - 1,
                            (spot->endLine() + 1)*_fontHeight + _contentRect.top() - 1);
                region |= r;
            } else {
                r.setCoords(spot->startColumn()*_fontWidth + _contentRect.left(),
                            spot->startLine()*_fontHeight + _contentRect.top(),
                            (_columns)*_fontWidth + _contentRect.left() - 1,
                            (spot->startLine() + 1)*_fontHeight + _contentRect.top() - 1);
                region |= r;
                for (int line = spot->startLine() + 1 ; line < spot->endLine() ; line++) {
                    r.setCoords(0 * _fontWidth + _contentRect.left(),
                                line * _fontHeight + _contentRect.top(),
                                (_columns)*_fontWidth + _contentRect.left() - 1,
                                (line + 1)*_fontHeight + _contentRect.top() - 1);
                    region |= r;
                }
                r.setCoords(0 * _fontWidth + _contentRect.left(),
                            spot->endLine()*_fontHeight + _contentRect.top(),
                            (spot->endColumn())*_fontWidth + _contentRect.left() - 1,
                            (spot->endLine() + 1)*_fontHeight + _contentRect.top() - 1);
                region |= r;
            }

            if (_showUrlHint && spot->type() == HotSpot::Link) {
                if (urlNumber >= 0 && urlNumber < 10) {
                    // Position at the beginning of the URL
                    QRect hintRect(*region.begin());
                    hintRect.setWidth(r.height());
                    painter.fillRect(hintRect, QColor(0, 0, 0, 128));
                    painter.setPen(Qt::white);
                    painter.drawRect(hintRect.adjusted(0, 0, -1, -1));
                    painter.drawText(hintRect, Qt::AlignCenter, QString::number(urlNumber));

                }
                urlNumber += urlNumInc;
            }
        }

        for (int line = spot->startLine() ; line <= spot->endLine() ; line++) {
            int startColumn = 0;
            int endColumn = _columns - 1; // TODO use number of _columns which are actually
            // occupied on this line rather than the width of the
            // display in _columns

            // Check image size so _image[] is valid (see makeImage)
            if (endColumn >= _columns || line >= _lines) {
                break;
            }

            // ignore whitespace at the end of the lines
            while (_image[loc(endColumn, line)].isSpace() && endColumn > 0) {
                endColumn--;
            }

            // increment here because the column which we want to set 'endColumn' to
            // is the first whitespace character at the end of the line
            endColumn++;

            if (line == spot->startLine()) {
                startColumn = spot->startColumn();
            }
            if (line == spot->endLine()) {
                endColumn = spot->endColumn();
            }

            // TODO: resolve this comment with the new margin/center code
            // subtract one pixel from
            // the right and bottom so that
            // we do not overdraw adjacent
            // hotspots
            //
            // subtracting one pixel from all sides also prevents an edge case where
            // moving the mouse outside a link could still leave it underlined
            // because the check below for the position of the cursor
            // finds it on the border of the target area
            QRect r;
            r.setCoords(startColumn * _fontWidth + _contentRect.left(),
                        line * _fontHeight + _contentRect.top(),
                        endColumn * _fontWidth + _contentRect.left() - 1,
                        (line + 1)*_fontHeight + _contentRect.top() - 1);

            // Underline link hotspots
            const bool hasMouse = region.contains(mapFromGlobal(QCursor::pos()));
            if ((spot->type() == HotSpot::Link && _showUrlHint) || hasMouse) {
                QFontMetrics metrics(font());

                // find the baseline (which is the invisible line that the characters in the font sit on,
                // with some having tails dangling below)
                const int baseline = r.bottom() - metrics.descent();
                // find the position of the underline below that
                const int underlinePos = baseline + metrics.underlinePos();
                painter.drawLine(r.left() , underlinePos, r.right() , underlinePos);

                // Marker hotspots simply have a transparent rectangular shape
                // drawn on top of them
            } else if (spot->type() == HotSpot::Marker) {
                //TODO - Do not use a hardcoded color for this
                const bool isCurrentResultLine = (_screenWindow->currentResultLine() == (spot->startLine() + _screenWindow->currentLine()));
                QColor color = isCurrentResultLine ? QColor(255, 255, 0, 120) : QColor(255, 0, 0, 120);
                painter.fillRect(r, color);
            } else if (spot->type() == HotSpot::EscapedUrl) {
                /* Always underline escaped links, it's the only way
                 *to recognize that this is not just random bytes in
                 * the screen. */
                QFontMetrics metrics(font());

                // find the baseline (which is the invisible line that the characters in the font sit on,
                // with some having tails dangling below)
                const int baseline = r.bottom() - metrics.descent();
                // find the position of the underline below that
                const int underlinePos = baseline + metrics.underlinePos();
                painter.drawLine(r.left() , underlinePos, r.right() , underlinePos);
            }
        }
    }
```

#### AUTO 


```{c}
auto entry = fallback->findEntry(Qt::Key_Tab, nullptr);
```

#### AUTO 


```{c}
const auto hasSameRendition = [&](int column) {
                    return (_display->_image[_display->loc(column, y)].rendition & ~RE_EXTENDED_CHAR)
                        == (currentRendition & ~RE_EXTENDED_CHAR);
                };
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *filter : _filters) {
        list.append(filter->hotSpots());
   }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto widgetJsonValue : splitterWidgets) {
        const auto widgetJsonObject = widgetJsonValue.toObject();
        const auto sessionIterator = widgetJsonObject.constFind(QStringLiteral("SessionRestoreId"));

        if (sessionIterator != widgetJsonObject.constEnd()) {
            Session *session = SessionManager::instance()->idToSession(sessionIterator->toInt());
            auto newView = manager->createView(session);
            currentSplitter->addWidget(newView);
        } else {
            auto nextSplitter = restoreSessionsSplitterRecurse(widgetJsonObject, manager);
            currentSplitter->addWidget(nextSplitter);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const int index) {
        updateTempProfileProperty(Profile::BellMode, index);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &range: *currentMergedRangesIt) {
            Q_ASSERT(range.first <= LAST_CODE_POINT);
            Q_ASSERT(range.second <= LAST_CODE_POINT);
            currentLut.append(Var(Var::Map {{QStringLiteral("first"), range.first}, {QStringLiteral("last"), range.second}}));
        }
```

#### AUTO 


```{c}
const auto *colors = model->data(selected.first(), Qt::UserRole + 1).value<const ColorScheme *>();
```

#### LAMBDA EXPRESSION 


```{c}
[this, suffix](const QString &name) {
        return std::find_if(_profiles.cbegin(), _profiles.cend(), [&name, suffix](const Profile::Ptr &p) {
            return p->name() == name //
                || (p->name() + suffix) == name; // For backwards compatibility
        });
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &jsonSplitter : jsonTabs) {
        auto topLevelSplitter = restoreSessionsSplitterRecurse(jsonSplitter.toObject(), this, true);
        _viewContainer->addSplitter(topLevelSplitter, _viewContainer->count());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : list) {
            if (url.isLocalFile()) {
                text += KShell::quoteArg(url.toLocalFile());
                text += QLatin1Char(' ');
            } else { // can users copy urls of both local and remote files at the same time?
                text = mimeData->text();
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &metaData : pluginMetaData) {
        KPluginLoader pluginLoader(metaData.fileName());
        KPluginFactory *factory = pluginLoader.factory();
        if (!factory) {
            continue;
        }

        auto *plugin = factory->create<IKonsolePlugin>();
        if (!plugin) {
            continue;
        }

        d->plugins.push_back(plugin);
    }
```

#### AUTO 


```{c}
const auto *enumItem = groupToConfigItemEnum(button->group());
```

#### AUTO 


```{c}
auto newScroll = std::make_unique<CompactHistoryScroll>(_maxLines);
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *sessionAction : sessionActions) {
            _newTabMenuAction->menu()->addAction(sessionAction);

            auto setActionFontBold = [sessionAction](bool isBold) {
                QFont actionFont = sessionAction->font();
                actionFont.setBold(isBold);
                sessionAction->setFont(actionFont);
            };

            Profile::Ptr profile = ProfileManager::instance()->defaultProfile();
            if (profile && profile->name() == sessionAction->text().remove(QLatin1Char('&'))) {
                QIcon icon = KIconUtils::addOverlay(QIcon::fromTheme(profile->icon()), QIcon::fromTheme(QStringLiteral("emblem-favorite")), Qt::BottomRightCorner);
                sessionAction->setIcon(icon);
                setActionFontBold(true);
            } else {
                setActionFontBold(false);
            }
        }
```

#### AUTO 


```{c}
auto *job = new KIO::OpenUrlJob(QUrl(url));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto *layout : qAsConst(_layouts)) {
        int left = getLeftMargin(layout);
        for (int row = 0; row < layout->rowCount(); ++row) {
            QLayoutItem *layoutItem = layout->itemAtPosition(row, LABELS_COLUMN);
            if (layoutItem == nullptr) {
                continue;
            }
            QWidget *widget = layoutItem->widget();
            if (widget == nullptr) {
                continue;
            }
            const int idx = layout->indexOf(widget);
            int rows, cols, rowSpan, colSpan;
            layout->getItemPosition(idx, &rows, &cols, &rowSpan, &colSpan);
            if (colSpan > 1) {
                continue;
            }

            const int right = left + widget->sizeHint().width();
            if (maxRight < right) {
                maxRight = right;
            }
        }
    }
```

#### AUTO 


```{c}
auto konsolePartPlugin = KPluginLoader::findPlugin(QStringLiteral("konsolepart"));
```

#### AUTO 


```{c}
auto generatorFunc = GENERATOR_FUNCS_MAP[generatorName];
```

#### RANGE FOR STATEMENT 


```{c}
for (const Session *session : SessionManager::instance()->sessions()) {
        for (TerminalDisplay *terminalDisplay : session->views()) {
            // Searching for opened profiles
            profileDialog = terminalDisplay->sessionController()->profileDialogPointer();
            if (profileDialog == nullptr) {
                continue;
            }
            for (const Profile::Ptr &profile : profiles) {
                if (profile->name() == profileDialog->lookupProfile()->name()
                    && profileDialog->isVisible()) {
                    // close opened edit dialog
                    profileDialog->close();
                }
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &option : qAsConst(qtProblematicOptions)) {
        if (arguments.contains(option)) {
            return true;
        }
    }
```

#### AUTO 


```{c}
const auto origClipRegion = painter.clipRegion();
```

#### RANGE FOR STATEMENT 


```{c}
for (uint cc : chars) {
        if (cc == DEL) {
            continue; // VT100: ignore.
        }

        // early out for displayable characters
        if (!getMode(MODE_Sixel) && getMode(MODE_Ansi) && tokenBufferPos == 0 && cc >= 32 && cc != (ESC + 128)) {
            _currentScreen->displayCharacter(applyCharset(cc));
            continue;
        }

        if (!getMode(MODE_Sixel) && ces(CTL)) {
            // ignore control characters in the text part of osc (aka OSC) "ESC]"
            // escape sequences; this matches what XTERM docs say
            // Allow BEL and ESC here, it will either end the text or be removed later.
            if ((osc || apc) && cc != 0x1b && cc != 0x07) {
                continue;
            }

            if (!osc && !apc) {
                // DEC HACK ALERT! Control Characters are allowed *within* esc sequences in VT100
                // This means, they do neither a resetTokenizer() nor a pushToToken(). Some of them, do
                // of course. Guess this originates from a weakly layered handling of the X-on
                // X-off protocol, which comes really below this level.
                if (cc == CNTL('X') || cc == CNTL('Z') || cc == ESC) {
                    resetTokenizer(); // VT100: CAN or SUB
                }
                if (cc != ESC) {
                    processToken(token_ctl(cc + '@'), 0, 0);
                    continue;
                }
            }
        }
        // advance the state
        addToCurrentToken(cc);

        uint *s = tokenBuffer;
        const int p = tokenBufferPos;

        if (getMode(MODE_Sixel) && processSixel(cc)) {
            continue;
        }

        if (getMode(MODE_Ansi)) {
            if (lec(1, 0, ESC)) {
                continue;
            }
            if (lec(1, 0, ESC + 128)) {
                s[0] = ESC;
                receiveChars(QVector<uint>{'['});
                continue;
            }
            if (les(2, 1, GRP)) {
                continue;
            }
            // Operating System Command
            if (p > 2 && s[1] == ']') {
                // <ESC> ']' ... <ESC> '\'
                if (s[p - 2] == ESC && s[p - 1] == '\\') {
                    // This runs two times per link, the first prepares the link to be read,
                    // the second finalizes it. The escape sequence is in two parts
                    //  start: '\e ] 8 ; <id-path> ; <url-part> \e \\'
                    //  end:   '\e ] 8 ; ; \e \\'
                    // GNU libtextstyle inserts the IDs, for instance; many examples
                    // do not.
                    if (s[2] == XTERM_EXTENDED::URL_LINK) {
                        // printf '\e]8;;https://example.com\e\\This is a link\e]8;;\e\\\n'
                        emit toggleUrlExtractionRequest();
                    }
                    processSessionAttributeRequest(p - 1);
                    resetTokenizer();
                    continue;
                }
                // <ESC> ']' ... <ESC> + one character for reprocessing
                if (s[p - 2] == ESC) {
                    processSessionAttributeRequest(p - 1);
                    resetTokenizer();
                    receiveChars(QVector<uint>{cc});
                    continue;
                }
                // <ESC> ']' ... <BEL>
                if (s[p - 1] == 0x07) {
                    processSessionAttributeRequest(p);
                    resetTokenizer();
                    continue;
                }
                // Special case: iterm file protocol is a long escape sequence
                if (tokenState == -1) {
                    tokenStateChange = "1337;File=:";
                    tokenState = 0;
                }
                if (tokenState >= 0) {
                    if ((uint)tokenStateChange[tokenState] == s[p - 1]) {
                        tokenState++;
                        tokenPos = p;
                        if ((uint)tokenState == strlen(tokenStateChange)) {
                            tokenState = -2;
                            tokenData.clear();
                        }
                        continue;
                    }
                } else if (tokenState == -2) {
                    if (p - tokenPos == 4) {
                        tokenData.append(QByteArray::fromBase64(QString::fromUcs4(&tokenBuffer[tokenPos], 4).toLocal8Bit()));
                        tokenBufferPos -= 4;
                        continue;
                    }
                }
            }
            // Privacy Message
            if (p > 2 && s[1] == '^') {
                if (s[p - 1] == 0x07 || (s[p - 2] == ESC && s[p - 1] == '\\')) {
                    resetTokenizer();
                    continue;
                }
            }
            // Application Program Command
            if (p > 2 && s[1] == '_') {
                // <ESC> '_' ... <ESC> '\'
                if (p > 3 && s[2] == 'G') {
                    if (tokenState == -1) {
                        tokenStateChange = ";";
                        tokenState = 0;
                    } else if (tokenState >= 0) {
                        if ((uint)tokenStateChange[tokenState] == s[p - 1]) {
                            tokenState++;
                            tokenPos = p;
                            if ((uint)tokenState == strlen(tokenStateChange)) {
                                tokenState = -2;
                                tokenData.clear();
                            }
                            continue;
                        }
                    } else if (tokenState == -2) {
                        if (p - tokenPos == 4) {
                            tokenData.append(QByteArray::fromBase64(QString::fromUcs4(&tokenBuffer[tokenPos], 4).toLocal8Bit()));
                            tokenBufferPos -= 4;
                            continue;
                        }
                    }
                }
                if (s[p - 1] == 0x07 || (s[p - 2] == ESC && s[p - 1] == '\\')) {
                    if (s[2] == 'G') {
                        // Graphics command
                        processGraphicsToken(p);
                    }
                    resetTokenizer();
                    continue;
                }
            }

            /* clang-format off */
        // <ESC> ']' ...
        if (osc         ) { continue; }
        if (pm          ) { continue; }
        if (apc         ) { continue; }
        if (p >= 3 && s[1] == '[') { // parsing a CSI sequence
            if (lec(3,2,'?')) { continue; }
            if (lec(3,2,'=')) { continue; }
            if (lec(3,2,'>')) { continue; }
            if (lec(3,2,'!')) { continue; }
            if (lec(3,2,SP )) { continue; }
            if (lec(4,3,SP )) { continue; }
            if (eps(    CPN)) { processToken(token_csi_pn(cc), argv[0],argv[1]);  resetTokenizer(); continue; }

            // resize = \e[8;<row>;<col>t
            if (eps(CPS)) {
                processToken(token_csi_ps(cc, argv[0]), argv[1], argv[2]);
                resetTokenizer();
                continue;
            }

            if (epe(   )) { processToken(token_csi_pe(cc), 0, 0); resetTokenizer(); continue; }

            if (esp (   )) { processToken(token_csi_sp(cc), 0, 0);           resetTokenizer(); continue; }
            if (epsp(   )) { processToken(token_csi_psp(cc, argv[0]), 0, 0); resetTokenizer(); continue; }

            if (ees(DIG)) { addDigit(cc-'0'); continue; }
            if (eec(';')) { addArgument();    continue; }
            if (ees(INT)) { continue; }
            if (p >= 3 && cc == 'y' && s[p - 2] == '*') { processChecksumRequest(argc, argv); resetTokenizer(); continue; }
            for (int i = 0; i <= argc; i++) {
                if (epp()) {
                    processToken(token_csi_pr(cc,argv[i]), i, 0);
                } else if (eeq()) {
                    processToken(token_csi_pq(cc), 0, 0); // spec. case for ESC[=0c or ESC[=c
                } else if (egt()) {
                    processToken(token_csi_pg(cc), 0, 0); // spec. case for ESC[>0c or ESC[>c
                } else if (cc == 'm' && argc - i >= 4 && (argv[i] == 38 || argv[i] == 48) && argv[i+1] == 2)
                {
                    // ESC[ ... 48;2;<red>;<green>;<blue> ... m -or- ESC[ ... 38;2;<red>;<green>;<blue> ... m
                    i += 2;
                    processToken(token_csi_ps(cc, argv[i-2]), COLOR_SPACE_RGB, (argv[i] << 16) | (argv[i+1] << 8) | argv[i+2]);
                    i += 2;
                } else if (cc == 'm' && argc - i >= 2 && (argv[i] == 38 || argv[i] == 48) && argv[i+1] == 5) {
                    // ESC[ ... 48;5;<index> ... m -or- ESC[ ... 38;5;<index> ... m
                    i += 2;
                    processToken(token_csi_ps(cc, argv[i-2]), COLOR_SPACE_256, argv[i]);
                } else if (p < 2 || (charClass[s[p-2]] & (INT)) != (INT)) {
                    processToken(token_csi_ps(cc,argv[i]), 0, 0);
                }
            }
        } else {
            if (dcs) {
                // Check for Sixel DCS q
                if (p > 2 && cc == 'q') {
                    setMode(MODE_Sixel);
                    // This parameter appears to be ignored
                    // m_preserveBackground = argv[2] == 1;
                    resetTokenizer();
                }
                if (ccc(DIG)) { addDigit(cc-'0');}
                if (cc == ';') { addArgument();}
                continue;
            }
            if (lec(2,0,ESC)) { processToken(token_esc(s[1]), 0, 0);              resetTokenizer(); continue; }
            if (les(3,1,SCS)) { processToken(token_esc_cs(s[1],s[2]), 0, 0);      resetTokenizer(); continue; }
            if (lec(3,1,'#')) { processToken(token_esc_de(s[2]), 0, 0);           resetTokenizer(); continue; }
        }
        resetTokenizer();
        /* clang-format on */
        } else {
            // VT52 Mode
            if (lec(1, 0, ESC)) {
                continue;
            }
            if (les(1, 0, CHR)) {
                processToken(token_chr(), s[0], 0);
                resetTokenizer();
                continue;
            }
            if (lec(2, 1, 'Y')) {
                continue;
            }
            if (lec(3, 1, 'Y')) {
                continue;
            }
            if (p < 4) {
                processToken(token_vt52(s[1]), 0, 0);
                resetTokenizer();
                continue;
            }
            processToken(token_vt52(s[1]), s[2], s[3]);
            resetTokenizer();
            continue;
        }
    }
```

#### AUTO 


```{c}
const auto mimeType = mdb.mimeTypeForFile(path);
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        QGuiApplication::clipboard()->setText(_filePath);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QRect &rect : region) {
        dirtyImageRegion += widgetToImage(rect);
        Q_EMIT drawBackground(paint, rect, _terminalColor->backgroundColor(), true /* use opacity setting */);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QPainter &painter,
            const QRect &rect, const QColor &backgroundColor, bool useOpacitySetting) {
        _terminalPainter->drawBackground(painter, rect, backgroundColor, useOpacitySetting);
    }
```

#### AUTO 


```{c}
auto to = std::make_move_iterator(_screenLines.begin() + srcY);
```

#### AUTO 


```{c}
auto *copyInputActions = collection->add<KSelectAction>(QStringLiteral("copy-input-to"));
```

#### RANGE FOR STATEMENT 


```{c}
for (Page &page: _pages) {
        page.needsUpdate = true;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &path : paths) {
        loadProfile(path);
    }
```

#### AUTO 


```{c}
const auto &range
```

#### LAMBDA EXPRESSION 


```{c}
[this ]{ activate(); }
```

#### AUTO 


```{c}
auto match      = matchIter.next();
```

#### AUTO 


```{c}
auto value = it.value();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &k : line) {
            if (!(k.equalsFormat(c))) {
                _formatLength++; // format change detected
                c = k;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Profile::Ptr &profile : _profiles) {
        if (profile->path() == path) {
            return profile;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        priv->shellCheckTimer.start(250);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *filter : _filters) {
        filter->reset();
    }
```

#### AUTO 


```{c}
auto &&child
```

#### AUTO 


```{c}
auto *job = new KIO::OpenUrlJob(currentUrl);
```

#### RANGE FOR STATEMENT 


```{c}
for (IKonsolePlugin *plugin : _plugins) {
        plugin->activeViewChanged(controller, this);
    }
```

#### AUTO 


```{c}
auto maybeTerminalDisplay = qobject_cast<TerminalDisplay *>(widgetAt)
```

#### AUTO 


```{c}
const auto canBeGrouped = [&](int column) {
                    return _display->_image[_display->loc(column, y)].character <= 0x7e
                            || (_display->_image[_display->loc(column, y)].rendition & RE_EXTENDED_CHAR)
                            || (_display->_bidiEnabled && !doubleWidth);
                };
```

#### AUTO 


```{c}
auto updateActionState = [this, readonly](const QString &name) {
        QAction *action = actionCollection()->action(name);
        if (action != nullptr) {
            action->setEnabled(!readonly);
        }
    };
```

#### AUTO 


```{c}
auto topLevelSplitter = parentSplitter->getToplevelSplitter();
```

#### AUTO 


```{c}
const auto lightPen = pen(paint, lightLineWidth);
```

#### AUTO 


```{c}
auto columns = profile->property<int>(Profile::TerminalColumns);
```

#### LAMBDA EXPRESSION 


```{c}
[&](int column) {
                return (image[display->loc(column, y)].rendition & ~RE_EXTENDED_CHAR) == (currentRendition & ~RE_EXTENDED_CHAR);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (TerminalDisplay *terminalDisplay : viewsList) {
        if (terminalDisplay != view()) {
            terminalDisplay->updateReadOnlyState(isReadOnly());
        }
        emit readOnlyChanged(this);
    }
```

#### AUTO 


```{c}
auto innerRef = QStringRef(&_text, localInnerRef.position(), localInnerRef.length());
```

#### AUTO 


```{c}
auto editor = new KeyBindingEditor(this);
```

#### AUTO 


```{c}
auto profile = SessionManager::instance()->sessionProfile(_sessionMap[currentDisplay]);
```

#### AUTO 


```{c}
auto endCopy = startCopy + count;
```

#### AUTO 


```{c}
auto tabBarSize = QSize(0, 0);
```

#### AUTO 


```{c}
const auto sourceIdx = priv->filterModel->mapToSource(idx);
```

#### LAMBDA EXPRESSION 


```{c}
[this](int idx) {
        emit detachTab(this, terminalAt(idx));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Profile::Ptr &existingProfile : existingProfiles) {
        if (existingProfile->name() != _profile->name()) {
            otherExistingProfileNames.append(existingProfile->name());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto option: options.buttons) {
        options.group->setId(option.button, option.value);
    }
```

#### AUTO 


```{c}
auto tabWidget
```

#### RANGE FOR STATEMENT 


```{c}
for (TerminalDisplay *view : sessionMapKeys) {
        applyProfileToView(view, profile);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &spot : _filterChain->hotSpots()) {
            if (spot->type() == HotSpot::Link) {
                hotspots.append(spot);
            }
        }
```

#### AUTO 


```{c}
auto dirModel = new QFileSystemModel(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const TerminalDisplay *display : qAsConst(_views)) {
            if (display->hasFocus()) {
                hasFocus = true;
                break;
            }
        }
```

#### AUTO 


```{c}
auto terminalContainers = _viewContainer->findChildren<TerminalDisplay *>();
```

#### AUTO 


```{c}
const auto readonlyActions = _contextPopupMenu->actions();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Profile::Ptr &profile : qAsConst(_profiles)) {
        const QString& path = profile->path();
        if (favoriteSet.contains(path)) {
            _favorites.insert(profile);
            favoriteSet.remove(path);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        m_session = nullptr;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        setHandleWidth(calculateHandleWidth(KonsoleSettings::self()->splitDragHandleSize()));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& widgetJsonValue : splitterWidgets) {
        const auto widgetJsonObject = widgetJsonValue.toObject();
        const auto sessionIterator = widgetJsonObject.constFind(QStringLiteral("SessionRestoreId"));

        if (sessionIterator != widgetJsonObject.constEnd()) {
            Session *session = SessionManager::instance()->idToSession(sessionIterator->toInt());
            auto newView = manager->createView(session);
            currentSplitter->addWidget(newView);
        } else {
            auto nextSplitter = restoreSessionsSplitterRecurse(widgetJsonObject, manager);
            currentSplitter->addWidget(nextSplitter);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        priv->filterModel->setFilterRegularExpression(ui->filterLine->text());
        priv->filterModel->invalidate();
    }
```

#### AUTO 


```{c}
auto mainWindowWidget = new QWidget(this);
```

#### AUTO 


```{c}
auto *view = qobject_cast<TerminalDisplay *>(container->widget(i));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &value : parser->values(option)) {
            m_commandLineArguments.insert(option, value);
        }
```

#### AUTO 


```{c}
auto manager = window->findChild<ViewManager *>();
```

#### AUTO 


```{c}
auto outerRef = QStringRef(&_text, localOuterRef.position(), localOuterRef.length());
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &child: other.children) {
                children.append(child);
            }
```

#### AUTO 


```{c}
const auto &hotSpot
```

#### AUTO 


```{c}
const auto hasSameColors = [&](int column) {
                return image[display->loc(column, y)].foregroundColor == currentForeground
                    && image[display->loc(column, y)].backgroundColor == currentBackground;
            };
```

#### AUTO 


```{c}
auto *wdg = widget(0);
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto& option : options) {
        option.button->setChecked(profile->property<bool>(option.property));
        connect(option.button, SIGNAL(toggled(bool)), this, option.slot);
    }
```

#### AUTO 


```{c}
auto currentWidget = terminalAt(currentIndex);
```

#### AUTO 


```{c}
auto *enumItem = dynamic_cast<KCoreConfigSkeleton::ItemEnum *>(item);
```

#### LAMBDA EXPRESSION 


```{c}
[display, triggerText]{
        display->sendStringToEmu(triggerText);}
```

#### AUTO 


```{c}
auto *advancedPageItem = addPage(advancedPageWidget, advancedPageName);
```

#### AUTO 


```{c}
const auto &[profile, keySeq]
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &spot : hotSpots()) {
        if (spot->type() == type) {
            hotspots.append(spot);
        }
    }
```

#### AUTO 


```{c}
auto tabBarSettings = new TabBarSettings(settingsDialog);
```

#### AUTO 


```{c}
static auto re = QRegularExpression(
        /* First part of the regexp means 'strings with spaces and starting with single quotes'
         * Second part means "Strings with double quotes"
         * Last part means "Everything else plus some special chars
         * This is much smaller, and faster, than the previous regexp
         * on the HotSpot creation we verify if this is indeed a file, so there's
         * no problem on testing on random words on the screen.
         */
            QLatin1String("'[^']+'")             // Matches everything between single quotes.
            + QStringLiteral(R"RX(|"[^"]+")RX")      // Matches everything inside double quotes
            + QStringLiteral(R"RX(|[\p{L}\w%1]+)RX").arg(wordCharacters) // matches a contiguous line of alphanumeric characters plus some special ones defined in the profile.
        ,
        QRegularExpression::DontCaptureOption);
```

#### AUTO 


```{c}
auto **statusIcon
```

#### AUTO 


```{c}
auto i = _graphicsPlacements.begin();
```

#### LAMBDA EXPRESSION 


```{c}
[&](quint8 top, quint8 right) { // ??
        pathForLine(top).moveTo(origin[top]);
        pathForLine(top).lineTo(center);
        pathForLine(top).lineTo(origin[right]);
    }
```

#### AUTO 


```{c}
const auto checkAndMaybeSaveValue = [&](const char *key, double value) {
        const bool valueIsNull = qFuzzyCompare(value, 0.0);
        const bool keyExists = configGroup.hasKey(key);
        const bool keyExistsAndHasDifferentValue = !qFuzzyCompare(configGroup.readEntry(key, value),
                                                                  value);
        if ((!valueIsNull && !keyExists) || keyExistsAndHasDifferentValue) {
            configGroup.writeEntry(key, value);
        }
    };
```

#### AUTO 


```{c}
auto *applyButton = _buttonBox->button(QDialogButtonBox::Apply);
```

#### AUTO 


```{c}
const auto sourceIdx = d->filterModel->mapToSource(selection.at(0));
```

#### AUTO 


```{c}
auto actionsList = _group->actions();
```

#### AUTO 


```{c}
const auto scrollBarWidth = _scrollbarLocation != Enum::ScrollBarHidden
                                ? _scrollBar->width()
                                : 0;
```

#### AUTO 


```{c}
const auto matchStyleSheet = QStringLiteral("QLineEdit{ background-color:%1 }")
                              .arg(backgroundBrush.brush(_searchEdit).color().name());
```

#### RANGE FOR STATEMENT 


```{c}
for (TerminalDisplay *terminal : displays) {
        manager->attachView(terminal, sessionsMap[terminal]);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&](int column) {
                    return image[display->loc(column, y)].foregroundColor == currentForeground
                        && image[display->loc(column, y)].backgroundColor == currentBackground;
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const WidthsRange &range : ranges) {
        if (range.cp.first != range.cp.last)
            out << QString::asprintf("%06X..%06X ; %2d\n", range.cp.first, range.cp.last, int(range.width));
        else
            out << QString::asprintf("%06X         ; %2d\n", range.cp.first, int(range.width));
    }
```

#### AUTO 


```{c}
const auto hasSameWidth = [imageSize, image, doubleWidth](int nextPos) {
                const int characterLoc = qMin(nextPos + 1, imageSize - 1);
                return image[characterLoc].isRightHalfOfDoubleWide() == doubleWidth;
            };
```

#### AUTO 


```{c}
static const auto lightnessWeightsFunc = [](double v) {
            return 50.0 - qAbs(v - 50.0);
        };
```

#### RANGE FOR STATEMENT 


```{c}
for (Session *session : qAsConst(_sessions)) {
        QString name = QLatin1String("Session") + QString::number(n);
        KConfigGroup group(config, name);

        group.writePathEntry("Profile",
                             _sessionProfiles.value(session)->path());
        session->saveSession(group);
        _restoreMapping.insert(session, n);
        n++;
    }
```

#### AUTO 


```{c}
auto *drag = new QDrag(this);
```

#### AUTO 


```{c}
auto closerToEdge = std::min<EdgeDistance>(
        {
            {cursorPos.x(), Qt::LeftEdge},
            {cursorPos.y(), Qt::TopEdge},
            {width() - cursorPos.x(), Qt::RightEdge},
            {height() - cursorPos.y(), Qt::BottomEdge}
        },
        [](const EdgeDistance& left, const EdgeDistance& right) -> bool {
            return left.first < right.first;
        }
    );
```

#### AUTO 


```{c}
const auto backgroundBrush = KStatefulBrush(KColorScheme::View, match ? KColorScheme::PositiveBackground : KColorScheme::NegativeBackground);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto splitter : splitters) {
        splitter->setVisible(true);
    }
```

#### AUTO 


```{c}
auto i
```

#### AUTO 


```{c}
auto sourceIdx = d->filterModel->mapToSource(idx);
```

#### AUTO 


```{c}
auto currentContext = _navigation[currentWidget];
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &name : listColorSchemes()) {
        std::shared_ptr<const ColorScheme> scheme = findColorScheme(colorSchemeNameFromPath(name));
        if (!scheme) {
            failed++;
            continue;
        }
        ret.append(scheme);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](Profile::Ptr profile) { emit newViewWithProfileRequest(this, profile); }
```

#### AUTO 


```{c}
auto *item = _config->findItem(key);
```

#### AUTO 


```{c}
auto action = new QAction(_group);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        const int scrollBarWidth = _scrollBar->isVisible() ? geometry().intersected(_scrollBar->geometry()).width() : 0;
        _verticalLayout->setContentsMargins(0, 0, scrollBarWidth, 0);
    }
```

#### AUTO 


```{c}
const auto re(QRegularExpression(QStringLiteral(R"foo((?:[:\(]?(\d+)(?::?|\)\]))(?:(\d+):)?$)foo")));
```

#### AUTO 


```{c}
auto lfontset = [this](const QFont &f) {
            _terminalFont->setVTFont(f);
        };
```

#### AUTO 


```{c}
auto setActionFontBold = [sessionAction](bool isBold) {
                QFont actionFont = sessionAction->font();
                actionFont.setBold(isBold);
                sessionAction->setFont(actionFont);
            };
```

#### RANGE FOR STATEMENT 


```{c}
for (unsigned int & glyphState : glyphStates)
        glyphState = 0;
```

#### AUTO 


```{c}
auto newProfile = Profile::Ptr(new Profile(profile));
```

#### AUTO 


```{c}
auto *child
```

#### LAMBDA EXPRESSION 


```{c}
[&out](const Character &i) { out += i.character; }
```

#### AUTO 


```{c}
auto *emptyMenuAct = new QAction(i18n("No plugins available"), this);
```

#### LAMBDA EXPRESSION 


```{c}
[]{
        qCDebug(KonsoleDebug) << "Error generating the preview" << _previewJob->errorString();
        QToolTip::hideText();
    }
```

#### AUTO 


```{c}
const auto color = QColor(((u / 36) % 6) != 0 ? (40 * ((u / 36) % 6) + 55) : 0,
                                  ((u / 6) % 6) != 0 ? (40 * ((u / 6) % 6) + 55) : 0,
                                  ((u / 1) % 6) != 0 ? (40 * ((u / 1) % 6) + 55) : 0);
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &child: element.children) {
                const int characterCountBetweenChildren = child.outer.position() - prevChildEndPosition;
                if(characterCountBetweenChildren > 0) {
                    // Add text between previous child (or inner beginning) and this child.
                    result += unescape(_text.midRef(prevChildEndPosition, characterCountBetweenChildren));
                } else if(characterCountBetweenChildren < 0) {
                    // Repeated item; they overlap and end1 > start2
                    result += unescape(element.inner.mid(prevChildEndPosition - element.inner.position()));
                    result += unescape(element.inner.left(child.outer.position() - element.inner.position()));
                }

                switch(data.dataType()) {
                case Var::DataType::Number:
                case Var::DataType::String:
                    generateRecursively(result, child, data);
                    consumedDataItems = 1; // Deepest child always consumes number/string
                    break;
                case Var::DataType::Vector:
                    if(!data.vec.isEmpty()) {
                        if(!child.hasName() && !child.isCommand() && consumedDataItems < data.vec.size()) {
                            consumedDataItems += generateRecursively(result, child, data[consumedDataItems]);
                        } else {
                            consumedDataItems += generateRecursively(result, child, data.vec.mid(consumedDataItems));
                        }
                    } else {
                        warn(child, QStringLiteral("no more items available in parent's list."));
                    }
                    break;
                case Var::DataType::Map:
                    if(!child.hasName()) {
                        consumedDataItems = generateRecursively(result, child, data);
                    } else if(data.map.contains(child.name)) {
                        generateRecursively(result, child, data.map[child.name]);
                        // Always consume, repeating doesn't change anything
                        consumedDataItems = 1;
                    } else {
                        warn(child, QStringLiteral("missing value for the element in parent's map."));
                    }
                    break;
                default:
                    break;
                }
                prevChildEndPosition = child.outer.position() + child.outer.length();
            }
```

#### AUTO 


```{c}
const auto& jsonSplitter
```

#### AUTO 


```{c}
auto activeContainer = _viewSplitter->activeContainer();
```

#### AUTO 


```{c}
auto swappedTitle = tabBar()->tabText(newIndex);
```

#### AUTO 


```{c}
const auto *opt = qstyleoption_cast<const QStyleOptionViewItem *>(&option);
```

#### AUTO 


```{c}
auto mainWidget = new QWidget(this);
```

#### AUTO 


```{c}
auto &url
```

#### AUTO 


```{c}
const auto hasSameRendition = [&](int column) {
                    return (_display->_image[loc(column, y)].rendition & ~RE_EXTENDED_CHAR)
                        == (currentRendition & ~RE_EXTENDED_CHAR);
                };
```

#### AUTO 


```{c}
const auto display = qobject_cast<TerminalDisplay *>(this->parent());
```

#### AUTO 


```{c}
const auto html = _screenWindow->selectedText(currentDecodingOptions() | Screen::ConvertToHtml);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : selectedIndexes) {
        if (index.column() == ProfileColumn) {
            list << index.data(ProfilePtrRole).value<Profile::Ptr>();
        }
    }
```

#### AUTO 


```{c}
const auto terminalSize = currentWidget() != nullptr ? currentWidget()->sizeHint() : QSize(0, 0);
```

#### AUTO 


```{c}
auto chars = new ushort[extendedCharLength + 1];
```

#### AUTO 


```{c}
auto setNewLine = [](std::vector<LineData> &change, int length, LineProperty flag) {
        change.push_back({length, flag});
    };
```

#### AUTO 


```{c}
const auto *layout
```

#### AUTO 


```{c}
auto chars = std::make_unique<uint[]>(extendedCharLength + 1);
```

#### RANGE FOR STATEMENT 


```{c}
for (uint cc : chars) {
        if (cc == DEL) {
            continue; // VT100: ignore.
        }

        // early out for displayable characters
        if (getMode(MODE_Ansi) && tokenBufferPos == 0 && cc >= 32 && cc != (ESC + 128)) {
            _currentScreen->displayCharacter(applyCharset(cc));
            continue;
        }

        if (ces(CTL)) {
            // ignore control characters in the text part of osc (aka OSC) "ESC]"
            // escape sequences; this matches what XTERM docs say
            // Allow BEL and ESC here, it will either end the text or be removed later.
            if (osc && cc != 0x1b && cc != 0x07) {
                continue;
            }

            if (!osc) {
                // DEC HACK ALERT! Control Characters are allowed *within* esc sequences in VT100
                // This means, they do neither a resetTokenizer() nor a pushToToken(). Some of them, do
                // of course. Guess this originates from a weakly layered handling of the X-on
                // X-off protocol, which comes really below this level.
                if (cc == CNTL('X') || cc == CNTL('Z') || cc == ESC) {
                    resetTokenizer(); // VT100: CAN or SUB
                }
                if (cc != ESC) {
                    processToken(token_ctl(cc + '@'), 0, 0);
                    continue;
                }
            }
        }
        // advance the state
        addToCurrentToken(cc);

        uint *s = tokenBuffer;
        const int p = tokenBufferPos;

        if (getMode(MODE_Ansi)) {
            if (lec(1, 0, ESC)) {
                continue;
            }
            if (lec(1, 0, ESC + 128)) {
                s[0] = ESC;
                receiveChars(QVector<uint>{'['});
                continue;
            }
            if (les(2, 1, GRP)) {
                continue;
            }
            // Operating System Command
            if (p > 2 && s[1] == ']') {
                // <ESC> ']' ... <ESC> '\'
                if (s[p - 2] == ESC && s[p - 1] == '\\') {
                    // This runs two times per link, the first prepares the link to be read,
                    // the second finalizes it. The escape sequence is in two parts
                    //  start: '\e ] 8 ; <id-path> ; <url-part> \e \\'
                    //  end:   '\e ] 8 ; ; \e \\'
                    // GNU libtextstyle inserts the IDs, for instance; many examples
                    // do not.
                    if (s[2] == XTERM_EXTENDED::URL_LINK) {
                        // printf '\e]8;;https://example.com\e\\This is a link\e]8;;\e\\\n'
                        _currentScreen->urlExtractor()->toggleUrlInput();
                    }
                    processSessionAttributeRequest(p - 1);
                    resetTokenizer();
                    continue;
                }
                // <ESC> ']' ... <ESC> + one character for reprocessing
                if (s[p - 2] == ESC) {
                    processSessionAttributeRequest(p - 1);
                    resetTokenizer();
                    receiveChars(QVector<uint>{cc});
                    continue;
                }
                // <ESC> ']' ... <BEL>
                if (s[p - 1] == 0x07) {
                    processSessionAttributeRequest(p);
                    resetTokenizer();
                    continue;
                }
            }

            /* clang-format off */
        // <ESC> ']' ...
        if (osc         ) { continue; }
        if (lec(3,2,'?')) { continue; }
        if (lec(3,2,'=')) { continue; }
        if (lec(3,2,'>')) { continue; }
        if (lec(3,2,'!')) { continue; }
        if (lec(3,2,SP )) { continue; }
        if (lec(4,3,SP )) { continue; }
        if (dcs         ) { continue; /* TODO We don't xterm DCS, so we just eat it */ }
        if (lec(2,0,ESC)) { processToken(token_esc(s[1]), 0, 0);              resetTokenizer(); continue; }
        if (les(3,1,SCS)) { processToken(token_esc_cs(s[1],s[2]), 0, 0);      resetTokenizer(); continue; }
        if (lec(3,1,'#')) { processToken(token_esc_de(s[2]), 0, 0);           resetTokenizer(); continue; }
        if (eps(    CPN)) { processToken(token_csi_pn(cc), argv[0],argv[1]);  resetTokenizer(); continue; }

        // resize = \e[8;<row>;<col>t
        if (eps(CPS)) {
            processToken(token_csi_ps(cc, argv[0]), argv[1], argv[2]);
            resetTokenizer();
            continue;
        }

        if (epe(   )) { processToken(token_csi_pe(cc), 0, 0); resetTokenizer(); continue; }

        if (esp (   )) { processToken(token_csi_sp(cc), 0, 0);           resetTokenizer(); continue; }
        if (epsp(   )) { processToken(token_csi_psp(cc, argv[0]), 0, 0); resetTokenizer(); continue; }

        if (ees(DIG)) { addDigit(cc-'0'); continue; }
        if (eec(';')) { addArgument();    continue; }
        if (ees(INT)) { continue; }
        if (p >= 3 && cc == 'y' && s[p - 2] == '*') { processChecksumRequest(argc, argv); resetTokenizer(); continue; }
        for (int i = 0; i <= argc; i++) {
            if (epp()) {
                processToken(token_csi_pr(cc,argv[i]), 0, 0);
            } else if (eeq()) {
                processToken(token_csi_pq(cc), 0, 0); // spec. case for ESC[=0c or ESC[=c
            } else if (egt()) {
                processToken(token_csi_pg(cc), 0, 0); // spec. case for ESC[>0c or ESC[>c
            } else if (cc == 'm' && argc - i >= 4 && (argv[i] == 38 || argv[i] == 48) && argv[i+1] == 2)
            {
                // ESC[ ... 48;2;<red>;<green>;<blue> ... m -or- ESC[ ... 38;2;<red>;<green>;<blue> ... m
                i += 2;
                processToken(token_csi_ps(cc, argv[i-2]), COLOR_SPACE_RGB, (argv[i] << 16) | (argv[i+1] << 8) | argv[i+2]);
                i += 2;
            } else if (cc == 'm' && argc - i >= 2 && (argv[i] == 38 || argv[i] == 48) && argv[i+1] == 5) {
                // ESC[ ... 48;5;<index> ... m -or- ESC[ ... 38;5;<index> ... m
                i += 2;
                processToken(token_csi_ps(cc, argv[i-2]), COLOR_SPACE_256, argv[i]);
            } else if (p < 2 || (charClass[s[p-2]] & (INT)) != (INT)) {
                processToken(token_csi_ps(cc,argv[i]), 0, 0);
            }
        }
        resetTokenizer();
        /* clang-format on */
        } else {
            // VT52 Mode
            if (lec(1, 0, ESC)) {
                continue;
            }
            if (les(1, 0, CHR)) {
                processToken(token_chr(), s[0], 0);
                resetTokenizer();
                continue;
            }
            if (lec(2, 1, 'Y')) {
                continue;
            }
            if (lec(3, 1, 'Y')) {
                continue;
            }
            if (p < 4) {
                processToken(token_vt52(s[1]), 0, 0);
                resetTokenizer();
                continue;
            }
            processToken(token_vt52(s[1]), s[2], s[3]);
            resetTokenizer();
            continue;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]{
        thumbnailRequested();
    }
```

#### AUTO 


```{c}
auto fallback = new FallbackKeyboardTranslator();
```

#### RANGE FOR STATEMENT 


```{c}
for (TerminalDisplay *view : session->views()) {
        view->screenWindow()->screen()->urlExtractor()->setAllowedLinkSchema(profile->escapedLinksSchema());
        view->screenWindow()->screen()->setReflowLines(profile->property<bool>(Profile::ReflowLines));
    }
```

#### AUTO 


```{c}
const auto backgroundBrush = KStatefulBrush(KColorScheme::View,
        match ? KColorScheme::PositiveBackground : KColorScheme::NegativeBackground);
```

#### AUTO 


```{c}
auto updateActionState = [this, readonly](const QString &name) {
        QAction *action = actionCollection()->action(name);
        if (action != nullptr) {
            action->setVisible(!readonly);
        }
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *child : widget->children()) {
        auto *childWidget = qobject_cast<QWidget *>(child);
        if (childWidget != nullptr) {
            registerWidgetAndChildren(childWidget);
        }
    }
```

#### AUTO 


```{c}
auto *parent_splitter = qobject_cast<ViewSplitter *>(parent());
```

#### AUTO 


```{c}
auto lgetBackgroundColor = [this]() {
        return _terminalColor->backgroundColor();
    };
```

#### AUTO 


```{c}
auto *action = qobject_cast<QAction*>(sender());
```

#### RANGE FOR STATEMENT 


```{c}
for (const Profile::Ptr &profile : profiles) {
        group->addProfile(profile);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        emit bellRequest(i18n("Bell in session '%1'", _nameTitle));
        this->setPendingNotification(Notification::Bell);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto notification : availableNotifications) {
        setPendingNotification(notification, false);
    }
```

#### AUTO 


```{c}
auto &k
```

#### AUTO 


```{c}
const auto &metaData
```

#### AUTO 


```{c}
auto &i
```

#### AUTO 


```{c}
auto testCharacters = convertToCharacter(text, renditions);
```

#### AUTO 


```{c}
auto *container = qobject_cast<TabbedViewContainer *>(sender());
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool) {
        const QString message = i18nc("@info:status", "By its very nature, a terminal program requires font characters that are equal width (monospace). Any non monospaced font may cause display issues. This should not be necessary except in rare cases.");
        const QPoint pos = QPoint(_showAllFonts->width() / 2, _showAllFonts->height());
        QWhatsThis::showText(_showAllFonts->mapToGlobal(pos), message, _showAllFonts);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto display : displays) {
        if (!display->sessionController()->isReadOnly()) {
            state.readOnly = false;
        }
        if (!display->sessionController()->isCopyInputActive()) {
            state.broadcast = false;
        }
    }
```

#### AUTO 


```{c}
auto item
```

#### AUTO 


```{c}
auto *session = qobject_cast<Session *>(sender());
```

#### AUTO 


```{c}
auto bm_url = groupUrlList.at(i);
```

#### RANGE FOR STATEMENT 


```{c}
for(auto terminal : terminalDisplays) {
        if (Q_LIKELY(currentActiveTerminal != terminal)) {
            (terminal->*method)();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &url : urls) {
        if (url.isLocalFile()) {
            createSession(defaultProfile, url.path());
        } else if (url.scheme() == QLatin1String("ssh")) {
            createSSHSession(defaultProfile, url);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &spot : hotspots) {
        if (spot->startLine() == line && spot->startColumn() > column) {
            continue;
        }
        if (spot->endLine() == line && spot->endColumn() < column) {
            continue;
        }

        return spot;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const WidthsRange &range: ranges) {
        if(range.cp.first != range.cp.last)
            out << QString::asprintf("%06X..%06X ; %2d\n", range.cp.first, range.cp.last, int(range.width));
        else
            out << QString::asprintf("%06X         ; %2d\n", range.cp.first, int(range.width));
    }
```

#### AUTO 


```{c}
auto option
```

#### RANGE FOR STATEMENT 


```{c}
for(const QButtonGroup *group: qAsConst(_groups)) {
            if (!group->checkedButton()) {
                continue;
            }
            int value = buttonToEnumValue(group->checkedButton());
            const auto *enumItem = groupToConfigItemEnum(group);

            if(enumItem != nullptr && !enumItem->isEqual(value)) {
                return true;
            }
        }
```

#### AUTO 


```{c}
auto data = item->data(SSHManagerModel::SSHRole).value<SSHConfigurationData>();
```

#### LAMBDA EXPRESSION 


```{c}
[](QTextStream &, const QVector<CharacterProperties> &, const QVector<CharacterWidth> &, const QMap<QString, QString> &) -> bool {
             return true;
         }
```

#### LAMBDA EXPRESSION 


```{c}
[imageSize, image, doubleWidth](int nextPos) {
                const int characterLoc = qMin(nextPos + 1, imageSize - 1);
                return (image[characterLoc].character == 0) == doubleWidth;
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const PropertyInfo &info : Profile::DefaultProperties) {
        // the profile group does not store a value for some properties
        // (eg. name, path) if even they are equal between profiles -
        //
        // the exception is when the group has only one profile in which
        // case it behaves like a standard Profile
        if (_profiles.count() > 1 && !canInheritProperty(info.property)) {
            continue;
        }

        QVariant value;
        for (int i = 0; i < _profiles.count(); i++) {
            QVariant profileValue = _profiles[i]->property<QVariant>(info.property);
            if (value.isNull()) {
                value = profileValue;
            } else if (value != profileValue) {
                value = QVariant();
                break;
            }
        }
        Profile::setProperty(info.property, value);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&](int column) {
                    const QChar::Script script = QChar::script(baseCodePoint(_display->_image[loc(column, y)]));
                    if (currentScript == QChar::Script_Common || script == QChar::Script_Common
                        || currentScript == QChar::Script_Inherited || script == QChar::Script_Inherited) {
                        return true;
                    }
                    return currentScript == script;
                }
```

#### AUTO 


```{c}
auto terminals = getToplevelSplitter()->findChildren<TerminalDisplay*>();
```

#### LAMBDA EXPRESSION 


```{c}
[&](int column) {
                return _image[loc(column, y)].foregroundColor == currentForeground
                    && _image[loc(column, y)].backgroundColor == currentBackground;
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (TerminalDisplay *display : _views) {
        if (display->hasFocus()) {
            hasFocus = true;
            break;
        }
    }
```

#### AUTO 


```{c}
auto spot = _filterChain->hotSpotAt(charLine, charColumn);
```

#### AUTO 


```{c}
const auto x = parentSize.width() - width();
```

#### LAMBDA EXPRESSION 


```{c}
[this] { Q_EMIT detachTab(_contextMenuTabIndex); }
```

#### AUTO 


```{c}
auto *item = _sessionModel->item(i, ProfileColumn);
```

#### LAMBDA EXPRESSION 


```{c}
[this, options](int value) {
        if (options.preview) {
            preview(options.profileProperty, value);
        }
        updateTempProfileProperty(options.profileProperty, value);
    }
```

#### AUTO 


```{c}
auto shortcut = ProfileManager::instance()->shortcut(profile);
```

#### AUTO 


```{c}
auto groupUrlList = bookmarkManager->root().groupUrlList();
```

#### AUTO 


```{c}
auto completer = new QCompleter(this);
```

#### AUTO 


```{c}
auto editor = new KKeySequenceWidget(aParent);
```

#### AUTO 


```{c}
const auto readAndCheckConfigEntry = [&](const char *key, double min, double max) -> double {
        const double value = configGroup.readEntry(key, min);
        if (min > value || value > max) {
            qCDebug(KonsoleDebug) << QStringLiteral(
                    "Color scheme \"%1\": color index 2 has an invalid value: %3 = %4. "
                    "Allowed value range: %5 - %6. Using %7.")
                    .arg(name()).arg(index).arg(QLatin1String(key)).arg(value, 0, 'g', 1)
                    .arg(min, 0, 'g', 1).arg(max, 0, 'g', 1).arg(min, 0, 'g', 1);
            return min;
        }
        return value;
    };
```

#### AUTO 


```{c}
auto translator = new KeyboardTranslator(name);
```

#### AUTO 


```{c}
auto manager = new KColorSchemeManager(parent);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QChar &c : text) {
                if (!isUnsafe(c)) {
                    sanitized.append(c);
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[](double v) {
            return v;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Session *session : SessionManager::instance()->sessions()) {
        const QList<TerminalDisplay *> viewsList = session->views();
        for (TerminalDisplay *terminalDisplay : viewsList) {
            // Searching for opened profiles
            profileDialog = terminalDisplay->sessionController()->profileDialogPointer();
            if (profileDialog != nullptr) {
                for (const Profile::Ptr &profile : profiles) {
                    if (profile->name() == profileDialog->lookupProfile()->name()
                        && profileDialog->isVisible()) {
                        // close opened edit dialog
                        profileDialog->close();
                    }
                }
            }
         }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QRect &rect : qAsConst(dirtyImageRegion)) {
        _terminalPainter->drawContents(paint, rect);
    }
```

#### AUTO 


```{c}
auto line = std::unique_ptr<CompactHistoryLine>(new (_blockList) CompactHistoryLine(cells, _blockList));
```

#### RANGE FOR STATEMENT 


```{c}
for (auto terminalDisplay : terminalDisplays) {
        terminalDisplay->setVisible(true);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto dropWidget : widgets) {
        if (dropWidget->rect().contains(dropWidget->mapFromGlobal(currentPos))) {
            emit dropWidget->moveViewRequest(-1, id);
            removeView(terminalAt(index));
        }
    }
```

#### AUTO 


```{c}
auto activeSplitter = _viewContainer->activeViewSplitter();
```

#### LAMBDA EXPRESSION 


```{c}
[imageSize, image, doubleWidth](int nextPos) {
                const int characterLoc = qMin(nextPos + 1, imageSize - 1);
                return image[characterLoc].isRightHalfOfDoubleWide() == doubleWidth;
            }
```

#### AUTO 


```{c}
auto hotSpotClick = _filterChain->hotSpotAt(charLine, charColumn);
```

#### AUTO 


```{c}
auto [cursorLine, cursorColumn] = td->getCharacterPosition(cursorPos, false);
```

#### AUTO 


```{c}
auto controller = static_cast<SessionController *>(sender());
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &&i : unicodeText) {
        receiveChar(i);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *action : popup->actions()) {
            if (action->text().toLower().remove(QLatin1Char('&')).contains(i18n("open with"))) {
                toDelete.append(action);
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&](int column) {
                    const int characterLoc = qMin(display->loc(column, y) + 1, imageSize - 1);
                    return (image[characterLoc].character == 0) == doubleWidth;
                }
```

#### AUTO 


```{c}
auto fallback = std::unique_ptr<FallbackKeyboardTranslator>(new FallbackKeyboardTranslator());
```

#### AUTO 


```{c}
const auto origPen = paint.pen();
```

#### AUTO 


```{c}
auto currentContext = currentWidget->sessionController();
```

#### LAMBDA EXPRESSION 


```{c}
[sessionAction](bool isBold) {
                QFont actionFont = sessionAction->font();
                actionFont.setBold(isBold);
                sessionAction->setFont(actionFont);
            }
```

#### AUTO 


```{c}
const auto headerHeight = _headerBar->isVisible() ? _headerBar->height() : 0;
```

#### AUTO 


```{c}
auto closerToEdge = std::min<EdgeDistance>(
        {{cursorPos.x(), Qt::LeftEdge}, {cursorPos.y(), Qt::TopEdge}, {width() - cursorPos.x(), Qt::RightEdge}, {height() - cursorPos.y(), Qt::BottomEdge}},
        [](const EdgeDistance &left, const EdgeDistance &right) -> bool {
            return left.first < right.first;
        });
```

#### AUTO 


```{c}
auto chars = new uint[extendedCharLength + 1];
```

#### AUTO 


```{c}
const auto pasteModes = QVector<RadioOption> {
        {_ui->pasteFromX11SelectionButton, Enum::PasteFromX11Selection, SLOT(pasteFromX11Selection())},
        {_ui->pasteFromClipboardButton, Enum::PasteFromClipboard, SLOT(pasteFromClipboard())}    };
```

#### AUTO 


```{c}
auto setupPage = _pages[current].setupPage;
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            _iPntSel = QPoint(-1, -1);
            _pntSel = QPoint(-1, -1);
            _tripleSelBegin = QPoint(-1, -1);
        }
```

#### AUTO 


```{c}
auto json = QJsonDocument::fromJson(jsonFile.readAll());
```

#### AUTO 


```{c}
auto [charLine, charColumn] = getCharacterPosition(position, false);
```

#### AUTO 


```{c}
auto c1 = style->backgroundColor.color(colorTable);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto sdsp : _sessionMap) {
        session = sdsp->view() == terminal ? sdsp->session() : nullptr;
        if (session != nullptr) {
            _sessionMap.removeOne(sdsp);
            disconnect(session, &Konsole::Session::finished, this, &Konsole::ViewManager::sessionFinished);
            break;
        }
    }
```

#### AUTO 


```{c}
auto splitter = restoreSessionsSplitterRecurse(json.object(), this, false);
```

#### AUTO 


```{c}
auto *oldBuffer = dynamic_cast<CompactHistoryScroll *>(old);
```

#### AUTO 


```{c}
auto scrollbarTerminal = qobject_cast<TerminalDisplay*>(child->parent());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &range : ranges) {
        if (!rangesStats.contains(range.width))
            rangesStats.insert(range.width, 0);
        rangesStats[range.width]++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Profile::PropertyInfo &info : Profile::DefaultProperties) {
        if (info.group == nullptr) {
            continue;
        }
        if (groupName == nullptr || qstrcmp(groupName, info.group) != 0) {
            group = config.group(info.group);
            groupName = info.group;
        }

        const QString name(QLatin1String(info.name));

        if (group.hasKey(name)) {
            profile->setProperty(info.property, group.readEntry(name, QVariant(info.defaultValue.type())));
        }
    }
```

#### AUTO 


```{c}
auto entry = translator->findEntry(Qt::Key_Backspace, Qt::NoModifier);
```

#### AUTO 


```{c}
auto parentSplitter = qobject_cast<ViewSplitter*>(parentWidget());
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *action : actList) {
                if (action->text().toLower().remove(QLatin1Char('&')).contains(i18n("open with"))) {
                    popup->removeAction(action);
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool) {
                const auto message = xi18nc("@info:tooltip", "When using this option, the scrollback data will be written unencrypted to temporary files. Those temporary files will be deleted automatically when Konsole is closed in a normal manner.<nl/>Use <emphasis>Settings ? Configure Konsole ? File Location</emphasis> to select the location of the temporary files.");
                const QPoint pos = QPoint(_ui->unlimitedHistoryWrapper->width() / 2, _ui->unlimitedHistoryWrapper->height());
                QWhatsThis::showText(_ui->unlimitedHistoryWrapper->mapToGlobal(pos), message, _ui->unlimitedHistoryWrapper);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &child : element.children) {
                const int characterCountBetweenChildren = child.outer.position() - prevChildEndPosition;
                if (characterCountBetweenChildren > 0) {
                    // Add text between previous child (or inner beginning) and this child.
                    result += unescape(_text.midRef(prevChildEndPosition, characterCountBetweenChildren));
                } else if (characterCountBetweenChildren < 0) {
                    // Repeated item; they overlap and end1 > start2
                    result += unescape(element.inner.mid(prevChildEndPosition - element.inner.position()));
                    result += unescape(element.inner.left(child.outer.position() - element.inner.position()));
                }

                switch (data.dataType()) {
                case Var::DataType::Number:
                case Var::DataType::String:
                    generateRecursively(result, child, data);
                    consumedDataItems = 1; // Deepest child always consumes number/string
                    break;
                case Var::DataType::Vector:
                    if (!data.vec.isEmpty()) {
                        if (!child.hasName() && !child.isCommand() && consumedDataItems < data.vec.size()) {
                            consumedDataItems += generateRecursively(result, child, data[consumedDataItems]);
                        } else {
                            consumedDataItems += generateRecursively(result, child, data.vec.mid(consumedDataItems));
                        }
                    } else {
                        warn(child, QStringLiteral("no more items available in parent's list."));
                    }
                    break;
                case Var::DataType::Map:
                    if (!child.hasName()) {
                        consumedDataItems = generateRecursively(result, child, data);
                    } else if (data.map.contains(child.name)) {
                        generateRecursively(result, child, data.map[child.name]);
                        // Always consume, repeating doesn't change anything
                        consumedDataItems = 1;
                    } else {
                        warn(child, QStringLiteral("missing value for the element in parent's map."));
                    }
                    break;
                default:
                    break;
                }
                prevChildEndPosition = child.outer.position() + child.outer.length();
            }
```

#### AUTO 


```{c}
const auto &spot
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &escapedUrl : urls) {
        if (escapedUrl.begin.row < sWindow->currentLine() || escapedUrl.end.row > sWindow->currentLine() + sWindow->windowLines()) {
            continue;
        }

        const int beginRow = escapedUrl.begin.row - sWindow->currentLine();
        const int endRow = escapedUrl.end.row - sWindow->currentLine();
        QSharedPointer<HotSpot> spot(
            // TODO:
            // This uses Column / Row while everything else uses Row/Column.
            // Move everything else to QPoint begin / QPoint End.
            new EscapeSequenceUrlHotSpot(beginRow, escapedUrl.begin.col, endRow, escapedUrl.end.col, escapedUrl.text, escapedUrl.url));

        addHotSpot(spot);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &groupName : config.groupList()) {
        KConfigGroup group = config.group(groupName);
        addTopLevelItem(groupName);
        for (const QString &sessionName : group.groupList()) {
            SSHConfigurationData data;
            KConfigGroup sessionGroup = group.group(sessionName);
            data.host = sessionGroup.readEntry("hostname");
            data.name = sessionGroup.readEntry("identifier");
            data.port = sessionGroup.readEntry("port");
            data.profileName = sessionGroup.readEntry("profileName");
            data.username = sessionGroup.readEntry("username");
            data.sshKey = sessionGroup.readEntry("sshkey");
            data.useSshConfig = sessionGroup.readEntry<bool>("useSshConfig", false);
            data.importedFromSshConfig = sessionGroup.readEntry<bool>("importedFromSshConfig", false);
            addChildItem(data, groupName);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QRect &rect : qAsConst(dirtyImageRegion)) {
        _terminalPainter->drawContents(_image, paint, rect, false, _imageSize, _bidiEnabled, _lineProperties);
    }
```

#### AUTO 


```{c}
const auto pasteModes = QVector<RadioOption> {
        {_mouseUi->pasteFromX11SelectionButton, Enum::PasteFromX11Selection, SLOT(pasteFromX11Selection())},
        {_mouseUi->pasteFromClipboardButton, Enum::PasteFromClipboard, SLOT(pasteFromClipboard())}    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const Profile::Ptr &profile : profiles) {
                if (profile->name() == profileDialog->lookupProfile()->name()
                    && profileDialog->isVisible()) {
                    // close opened edit dialog
                    profileDialog->close();
                }
            }
```

#### AUTO 


```{c}
auto terminalDisplay
```

#### AUTO 


```{c}
auto *hist_line = getCharacterBuffer(hist_lineLen + _screenLines[0].count());
```

#### AUTO 


```{c}
const auto color = QColor(((u / 36) % 6) ? (40 * ((u / 36) % 6) + 55) : 0,
                      ((u / 6) % 6) ? (40 * ((u / 6) % 6) + 55) : 0,
                      ((u / 1) % 6) ? (40 * ((u / 1) % 6) + 55) : 0);
```

#### AUTO 


```{c}
auto *newItem = new QStandardItem();
```

#### AUTO 


```{c}
auto item = display->sessionController();
```

#### LAMBDA EXPRESSION 


```{c}
[this, i]() { switchToView(i); }
```

#### AUTO 


```{c}
const auto item = d->model->itemFromIndex(sourceIdx);
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : qAsConst(_multiSplitterOnlyActions)) {
            action->setEnabled(splitCount > 1);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool) {
        const QString message = i18n("By its very nature, a terminal program requires font characters that are equal width (monospace). Any non monospaced font may cause display issues. This should not be necessary except in rare cases.");
        const QPoint pos = QPoint(_showAllFonts->width() / 2, _showAllFonts->height());
        QWhatsThis::showText(_showAllFonts->mapToGlobal(pos), message, _showAllFonts);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] { newTab(_viewManager->activeContainer());}
```

#### LAMBDA EXPRESSION 


```{c}
[&](int column) {
                    return _display->_image[loc(column, y)].character <= 0x7e
                            || (_display->_image[loc(column, y)].rendition & RE_EXTENDED_CHAR)
                            || (_display->_bidiEnabled && !doubleWidth);
                }
```

#### AUTO 


```{c}
auto *layout = new QVBoxLayout(this);
```

#### LAMBDA EXPRESSION 


```{c}
[](const QChar &c) {
        return (c.category() == QChar::Category::Other_Control && !whitelist.contains(c.unicode()));
    }
```

#### AUTO 


```{c}
auto *enumItem = groupToConfigItemEnum(group);
```

#### AUTO 


```{c}
auto urls = mimeData->urls();
```

#### LAMBDA EXPRESSION 


```{c}
[&packedLineTypes](quint8 lineId) -> LineType {
        lineId = LinesNum - 1 - lineId % LinesNum;
        return LineType(packedLineTypes >> 2 * lineId & 3);
    }
```

#### AUTO 


```{c}
auto point
```

#### AUTO 


```{c}
const auto libraryPaths = QCoreApplication::libraryPaths();
```

#### AUTO 


```{c}
auto setNewLine = [](reflowData &change, int index, LineProperty flag) {
        change.index.append(index);
        change.flags.append(flag);
    };
```

#### AUTO 


```{c}
auto terminal = qobject_cast<TerminalDisplay*>(child->parent());
```

#### AUTO 


```{c}
auto window = new MainWindow();
```

#### AUTO 


```{c}
auto cursor = td->cursor();
```

#### AUTO 


```{c}
auto *view = terminalAt(index);
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool) {
        const QString message = i18nc("@info:status",
                                      "By its very nature, a terminal program requires font characters that are equal width (monospace). Any non monospaced "
                                      "font may cause display issues. This should not be necessary except in rare cases.");
        const QPoint pos = QPoint(_showAllFonts->width() / 2, _showAllFonts->height());
        QWhatsThis::showText(_showAllFonts->mapToGlobal(pos), message, _showAllFonts);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QButtonGroup *group: qAsConst(_groups)) {
            auto *enumItem = groupToConfigItemEnum(group);
            if(!enumItem) {
                continue;
            }
            const auto *currentButton = group->checkedButton();
            if(!currentButton) {
                continue;
            }
            const int value = buttonToEnumValue(currentButton);
            if(value < 0) {
                continue;
            }

            if(!enumItem->isEqual(value)) {
                enumItem->setValue(value);
                updateConfig = true;
            }
        }
```

#### AUTO 


```{c}
auto *display = session->views().at(0);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        _possibleTripleClick = false;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](CharacterProperties &prop, const EastAsianWidthEntry &entry) {
                                               prop.eastAsianWidth = entry.eastAsianWidth();
                                           }
```

#### AUTO 


```{c}
const auto *portValidator = new QIntValidator(0, 49151, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (Session *session : qAsConst(_sessions)) {
        QString name = QLatin1String("Session") + QString::number(n);
        KConfigGroup group(config, name);

        group.writePathEntry("Profile", _sessionProfiles.value(session)->path());
        session->saveSession(group);
        _restoreMapping.insert(session, n);
        n++;
    }
```

#### AUTO 


```{c}
auto topSplitter = parentSplitter->getToplevelSplitter();
```

#### AUTO 


```{c}
auto currentActiveTerminal = viewSplitter->activeTerminalDisplay();
```

#### AUTO 


```{c}
auto view = container->widget(i);
```

#### AUTO 


```{c}
auto swappedWidget = terminalAt(newIndex);
```

#### AUTO 


```{c}
auto ldrawBackground = [this](QPainter &painter,
            const QRect &rect, const QColor &backgroundColor, bool useOpacitySetting) {
        emit drawBackground(painter, rect, backgroundColor, useOpacitySetting);
    };
```

#### AUTO 


```{c}
auto activeDisplay = splitter->activeTerminalDisplay();
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *sessionAction : sessionActions) {
            _newTabMenuAction->menu()->addAction(sessionAction);

            // NOTE: defaultProfile seems to not work here, sigh.
            Profile::Ptr profile = ProfileManager::instance()->defaultProfile();
            if (profile && profile->name() == sessionAction->text().remove(QLatin1Char('&'))) {
                QIcon icon(KIconLoader::global()->loadIcon(profile->icon(), KIconLoader::Small, 0, KIconLoader::DefaultState, QStringList(QStringLiteral("emblem-favorite"))));
                sessionAction->setIcon(icon);
                _newTabMenuAction->menu()->setDefaultAction(sessionAction);
                QFont actionFont = sessionAction->font();
                actionFont.setBold(true);
                sessionAction->setFont(actionFont);
            }
        }
```

#### AUTO 


```{c}
const auto display
```

#### AUTO 


```{c}
auto* editor = qobject_cast<KKeySequenceWidget*>(sender());
```

#### AUTO 


```{c}
auto last = _screenLines.back();
```

#### AUTO 


```{c}
auto contentSeparator = new QAction(popup);
```

#### AUTO 


```{c}
auto terminals = getToplevelSplitter()->findChildren<TerminalDisplay *>();
```

#### AUTO 


```{c}
auto reflowLineLen = [](int start, int end) {
        return end - start;
    };
```

#### AUTO 


```{c}
const auto* portValidator = new QIntValidator(0, 9999);
```

#### AUTO 


```{c}
auto targetSplitter = qobject_cast<QSplitter*>(child->parent());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QRect &rect : region) {
        if (drawDimmed) {
            paint.fillRect(rect, dimColor);
        }
    }
```

#### AUTO 


```{c}
auto parentChildProcModifier = KPtyProcess::childProcessModifier();
```

#### LAMBDA EXPRESSION 


```{c}
[this, properties] {
        m_terminalIcon->setPixmap(properties->icon().pixmap(QSize(22,22)));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *filter : _filters) {
        filter->setBuffer(buffer, linePositions);
    }
```

#### AUTO 


```{c}
auto* display = reinterpret_cast<TerminalDisplay*>(view);
```

#### AUTO 


```{c}
auto [charLine, charColumn] = getCharacterPosition(ev->pos(), !_usesMouseTracking);
```

#### AUTO 


```{c}
auto *currentWindow = qobject_cast<MainWindow *>(sender());
```

#### AUTO 


```{c}
auto view = splitview->activeTerminalDisplay();
```

#### AUTO 


```{c}
auto *action = qobject_cast<QAction *>(sender());
```

#### AUTO 


```{c}
auto *currentWindow = qobject_cast<MainWindow*>(sender());
```

#### AUTO 


```{c}
auto findIt = std::find_if(std::begin(profiles), std::end(profiles), [&profileToLoad](const Konsole::Profile::Ptr &pr) {
        return pr->name() == profileToLoad;
    });
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        this->loadLayout(QStandardPaths::locate(QStandardPaths::GenericDataLocation, QStringLiteral("konsole/1x2-terminals.json")));
    }
```

#### AUTO 


```{c}
const auto normalWeight = display->font().weight();
```

#### AUTO 


```{c}
auto action = collection->addAction(QStringLiteral("save-layout"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &hotSpot : hotSpots()) {
        QRect r;
        r.setLeft(hotSpot->startColumn());
        r.setTop(hotSpot->startLine());
        if (hotSpot->startLine() == hotSpot->endLine()) {
            r.setRight(hotSpot->endColumn());
            r.setBottom(hotSpot->endLine());
            region |= _terminalDisplay->imageToWidget(r);
        } else {
            r.setRight(_terminalDisplay->columns());
            r.setBottom(hotSpot->startLine());
            region |= _terminalDisplay->imageToWidget(r);

            r.setLeft(0);

            for (int line = hotSpot->startLine() + 1; line < hotSpot->endLine(); line++) {
                r.moveTop(line);
                region |= _terminalDisplay->imageToWidget(r);
            }

            r.moveTop(hotSpot->endLine());
            r.setRight(hotSpot->endColumn());
            region |= _terminalDisplay->imageToWidget(r);
        }
    }
```

#### AUTO 


```{c}
auto setNewLine = [] (reflowData &change, qint64 index, LineProperty lineflag) {
        change.index = index;
        change.lineFlag = lineflag;
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const QChar &c : text) {
        if (!c.isPrint() && c != QLatin1Char('\t') && c != QLatin1Char('\n')) {
            QString description;
            switch(c.unicode()) {
            case '\x03':
                description = i18n("^C Interrupt: May abort the current process");
                break;
            case '\x04':
                description = i18n("^D End of transmission: May exit the current process");
                break;
            case '\x07':
                description = i18n("^G Bell: Will try to emit an audible warning");
                break;
            case '\x08':
                description = i18n("^H Backspace");
                break;
            case '\x13':
                description = i18n("^S Scroll lock: Locks terminal output");
                break;
            case '\x1a':
                description = i18n("^Z Suspend: Stops current process");
                break;
            case '\x1b':
                description = i18n("ESC: Used for special commands to the current process");
                break;
            default:
                description = i18n("Other unprintable character (\\x%1)").arg(QString::number(c.unicode(), 16));
                break;
            }
            unsafeCharacters.append(description);
        }
    }
```

#### AUTO 


```{c}
const auto drawDoubleUpRightShorterLine = [&](quint8 top, quint8 right) { // ?
        lightPath.moveTo(origin[top] + dir[right] * doubleLinesDistance);
        lightPath.lineTo(center + (dir[right] + dir[top]) * doubleLinesDistance);
        lightPath.lineTo(origin[right] + dir[top] * doubleLinesDistance);
    };
```

#### AUTO 


```{c}
auto testData = QFINDTESTDATA(QStringLiteral("data/bookmarks.xml"));
```

#### AUTO 


```{c}
const auto scrollBarWidth = _scrollBar->scrollBarPosition() != Enum::ScrollBarHidden ? _scrollBar->width() : 0;
```

#### AUTO 


```{c}
const auto hasSameLineDrawStatus = [&](int column) {
                    return LineBlockCharacters::canDraw(_display->_image[_display->loc(column, y)].character)
                        == lineDraw;
                };
```

#### CONST EXPRESSION 


```{c}
static constexpr const int RANGE_LUT_LIST_SIZE = �ranges - lut - list - size�;
```

#### AUTO 


```{c}
auto *display = qobject_cast<TerminalDisplay*>(object)
```

#### RANGE FOR STATEMENT 


```{c}
for (TerminalDisplay *view : viewsList) {
        const QFont &viewCurFont = view->terminalFont()->getVTFont();
        if (viewCurFont != _sessionProfiles[session]->font()) {
            zoomFontSizes.insert(view, viewCurFont);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &url) {
                if (url == QLatin1String("#close")) {
                    _readOnlyMessageWidget->hide();
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this]{requestMoveToNewTab(this);}
```

#### AUTO 


```{c}
auto *tabsPageWidget = new QWidget(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &url) {
            QDesktopServices::openUrl(QUrl(url));
        }
```

#### AUTO 


```{c}
auto *widget = qApp->widgetAt(globalPos.x() + 10, globalPos.y() - 10);
```

#### RANGE FOR STATEMENT 


```{c}
for(auto terminalDisplay : _viewContainer->findChildren<TerminalDisplay*>()) {
        list.append(terminalDisplay->sessionController());
    }
```

#### AUTO 


```{c}
auto && i
```

#### AUTO 


```{c}
auto swappedWidget = widget(newIndex);
```

#### AUTO 


```{c}
auto setNewLine = [](reflowData &change, qint64 index, LineProperty lineflag) {
        change.index = index;
        change.lineFlag = lineflag;
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : selected) {
            setRowChecked(index.row(), checked);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] { emit detachTab(_contextMenuTabIndex); }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        Q_EMIT detachTab(_contextMenuTabIndex);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Filter::HotSpot *hotSpot : _filterChain->hotSpots()) {
        QRect r;
        r.setLeft(hotSpot->startColumn());
        r.setTop(hotSpot->startLine());
        if (hotSpot->startLine() == hotSpot->endLine()) {
            r.setRight(hotSpot->endColumn());
            r.setBottom(hotSpot->endLine());
            region |= imageToWidget(r);
        } else {
            r.setRight(_columns);
            r.setBottom(hotSpot->startLine());
            region |= imageToWidget(r);

            r.setLeft(0);

            for (int line = hotSpot->startLine() + 1 ; line < hotSpot->endLine(); line++) {
                r.moveTop(line);
                region |= imageToWidget(r);
            }

            r.moveTop(hotSpot->endLine());
            r.setRight(hotSpot->endColumn());
            region |= imageToWidget(r);
        }
    }
```

#### AUTO 


```{c}
auto testImage = new Character[testStringSize];
```

#### AUTO 


```{c}
auto widget = static_cast<TerminalDisplay*>(view);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto splitter : splitters) {
        if (splitter->orientation() != orientation()) {
            continue;
        }

        int delta = 0;
        for (auto point : splitter->sizes()) {
            delta += point;
            QPoint thisPoint = orientation() == Qt::Horizontal
                ? QPoint(delta, 0)
                : QPoint(0, delta);


            QPoint splitterPos = splitter->mapToTopLevel(thisPoint);

            const int ourPos = orientation() == Qt::Horizontal
                ? splitterPos.x()
                : splitterPos.y();

            allSplitterSizes.push_back(ourPos);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto session : group) {
        // First, ensure that the session is removed
        // (necessary to avoid duplicates on addSession()!)
        _copyToGroup->removeSession(session);

        // Add current session if it is displayed our window
        if (hasTerminalDisplayInSameWindow(session, myWindow)) {
            _copyToGroup->addSession(session);
        }
    }
```

#### AUTO 


```{c}
auto terminalDisplays = viewSplitter->findChildren<TerminalDisplay*>();
```

#### AUTO 


```{c}
const auto data = item->data(QuickCommandRole).value<QuickCommandData>();
```

#### AUTO 


```{c}
auto spot = hotSpotAt(charLine, charColumn);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &spot : spots) {
        QRegion region;
        if (spot->type() == HotSpot::Link || spot->type() == HotSpot::EMailAddress || spot->type() == HotSpot::EscapedUrl || spot->type() == HotSpot::File) {
            QPair<QRegion, QRect> spotRegion =
                spot->region(td->terminalFont()->fontWidth(), td->terminalFont()->fontHeight(), td->columns(), td->contentRect());
            region = spotRegion.first;
            QRect r = spotRegion.second;

            // TODO: Move this paint code to HotSpot->drawHint();
            // TODO: Fix the Url Hints access from the Profile.
            if (_showUrlHint && (spot->type() == HotSpot::Link || spot->type() == HotSpot::File)) {
                if (urlNumber >= 0 && urlNumber < 10) {
                    // Position at the beginning of the URL
                    QRect hintRect(*region.begin());
                    hintRect.setWidth(r.height());
                    painter.fillRect(hintRect, QColor(0, 0, 0, 128));
                    painter.setPen(Qt::white);
                    painter.drawRect(hintRect.adjusted(0, 0, -1, -1));
                    painter.drawText(hintRect, Qt::AlignCenter, QString::number(urlNumber));
                }
                urlNumber += urlNumInc;
            }
        }

        if (spot->startLine() < 0 || spot->endLine() < 0) {
            qDebug() << "ERROR, invalid hotspot:";
            spot->debug();
        }

        for (int line = spot->startLine(); line <= spot->endLine(); line++) {
            int startColumn = 0;
            int endColumn = td->columns() - 1; // TODO use number of _columns which are actually
            // occupied on this line rather than the width of the
            // display in _columns

            // FIXME: the left side condition is always false due to the
            //        endColumn assignment above
            // Check image size so _image[] is valid (see makeImage)
            if (endColumn >= td->columns() || line >= td->lines()) {
                break;
            }

            // ignore whitespace at the end of the lines
            while (td->getCursorCharacter(endColumn, line).isSpace() && endColumn > 0) {
                endColumn--;
            }

            // increment here because the column which we want to set 'endColumn' to
            // is the first whitespace character at the end of the line
            endColumn++;

            if (line == spot->startLine()) {
                startColumn = spot->startColumn();
            }
            if (line == spot->endLine()) {
                endColumn = spot->endColumn();
            }

            // TODO: resolve this comment with the new margin/center code
            // subtract one pixel from
            // the right and bottom so that
            // we do not overdraw adjacent
            // hotspots
            //
            // subtracting one pixel from all sides also prevents an edge case where
            // moving the mouse outside a link could still leave it underlined
            // because the check below for the position of the cursor
            // finds it on the border of the target area
            QRect r;
            r.setCoords(startColumn * td->terminalFont()->fontWidth() + td->contentRect().left(),
                        line * td->terminalFont()->fontHeight() + td->contentRect().top(),
                        endColumn * td->terminalFont()->fontWidth() + td->contentRect().left() - 1,
                        (line + 1) * td->terminalFont()->fontHeight() + td->contentRect().top() - 1);

            // Underline link hotspots
            // TODO: Fix accessing the urlHint here.
            // TODO: Move this code to UrlFilterHotSpot.
            const bool hasMouse = region.contains(td->mapFromGlobal(QCursor::pos()));
            if (((spot->type() == HotSpot::Link || spot->type() == HotSpot::File) && _showUrlHint) || hasMouse) {
                QFontMetrics metrics(td->font());

                // find the baseline (which is the invisible line that the characters in the font sit on,
                // with some having tails dangling below)
                const int baseline = r.bottom() - metrics.descent();
                // find the position of the underline below that
                const int underlinePos = baseline + metrics.underlinePos();
                painter.drawLine(r.left(), underlinePos, r.right(), underlinePos);

                // Marker hotspots simply have a transparent rectangular shape
                // drawn on top of them
            } else if (spot->type() == HotSpot::Marker) {
                // TODO - Do not use a hardcoded color for this
                const bool isCurrentResultLine = (td->screenWindow()->currentResultLine() == (spot->startLine() + td->screenWindow()->currentLine()));
                QColor color = isCurrentResultLine ? QColor(255, 255, 0, 120) : QColor(255, 0, 0, 120);
                painter.fillRect(r, color);
            }
        }
    }
```

#### AUTO 


```{c}
auto ldrawContents = [this](QPainter &paint, const QRect &rect, bool friendly) {
        Q_EMIT drawContents(_image, paint, rect, friendly, _imageSize, _bidiEnabled, _lineProperties);
    };
```

#### AUTO 


```{c}
const auto rowsSuffix =
        ki18ncp("Suffix of the number of rows (N rows). The leading space is needed to separate it from the number value.", " row", " rows");
```

#### AUTO 


```{c}
const auto *scheme = index.data(Qt::UserRole + 1).value<const ColorScheme *>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const int i : {0, 1, 64, 127, 128, 215, 255}) {
        const QString name = QStringLiteral("color %1").arg(i);
        QTest::newRow(qPrintable(name)) << i << QColor(i >> 16, i >> 8, i);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QTableWidgetItem *matchedItem : _ui->keyBindingTable->findItems(text, Qt::MatchContains)) {
        matchedRows.append(matchedItem->row());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (TerminalDisplay *terminal : displays) {
        Session *session = forgetTerminal(terminal);
        detachedSessions[terminal] = session;
    }
```

#### AUTO 


```{c}
auto ldrawContents = [this](QPainter &paint, const QRect &rect, bool friendly) {
        emit drawContents(_image, paint, rect, friendly, _imageSize, _bidiEnabled, _lineProperties);
    };
```

#### AUTO 


```{c}
auto detachAction = _contextPopupMenu->addAction(
        QIcon::fromTheme(QStringLiteral("tab-detach")),
        i18nc("@action:inmenu", "&Detach Tab"), this,
        [this] { emit detachTab(_contextMenuTabIndex); }
    );
```

#### AUTO 


```{c}
const auto *translator = model->data(selected.first(), Qt::UserRole + 1).value<const KeyboardTranslator *>();
```

#### AUTO 


```{c}
const auto isInsideDrawArea = [&](int column) {
                return column <= rect.right();
            };
```

#### AUTO 


```{c}
const auto hasSameRendition = [&](int column) {
                    return (image[display->loc(column, y)].rendition & ~RE_EXTENDED_CHAR)
                        == (currentRendition & ~RE_EXTENDED_CHAR);
                };
```

#### AUTO 


```{c}
auto *model = qobject_cast<QStandardItemModel *>(_ui->colorSchemeList->model());
```

#### AUTO 


```{c}
const auto colsSuffix =
        ki18ncp("Suffix of the number of columns (N columns). The leading space is needed to separate it from the number value.", " column", " columns");
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto widgetJsonValue : splitterWidgets) {
        const auto widgetJsonObject = widgetJsonValue.toObject();
        const auto sessionIterator = widgetJsonObject.constFind(QStringLiteral("SessionRestoreId"));

        if (sessionIterator != widgetJsonObject.constEnd()) {
            Session *session = useSessionId ? SessionManager::instance()->idToSession(sessionIterator->toInt()) : SessionManager::instance()->createSession();

            auto newView = manager->createView(session);
            currentSplitter->addWidget(newView);
        } else {
            auto nextSplitter = restoreSessionsSplitterRecurse(widgetJsonObject, manager, useSessionId);
            currentSplitter->addWidget(nextSplitter);
        }
    }
```

#### AUTO 


```{c}
auto comment = match.captured(commentGroupName);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto terminalDisplay : _viewContainer->findChildren<TerminalDisplay *>()) {
        list.append(terminalDisplay->sessionController());
    }
```

#### AUTO 


```{c}
const auto hSpots = hotSpots();
```

#### AUTO 


```{c}
auto tabBarWidget = new DetachableTabBar();
```

#### AUTO 


```{c}
const auto data = sshElement->data(SSHRole).value<SSHConfigurationData>();
```

#### AUTO 


```{c}
const auto widgetJsonValue
```

#### AUTO 


```{c}
auto temporaryFilesPage = new KPageWidgetItem(new TemporaryFilesSettings(confDialog), temporaryFilesPageName);
```

#### AUTO 


```{c}
auto controller = qobject_cast<SessionController*>(properties);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto && i : unicodeText)
        receiveChar(i.unicode());
```

#### AUTO 


```{c}
auto actionDelete = new QAction(QStringLiteral("Delete"), ui->commandsTreeView);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto & i : list) {
        // dis-regard the fallback profile
        if (i->path() == _fallbackProfile->path()) {
            continue;
        }

        if (i->menuIndexAsInt() == 0) {
            lackingIndices.append(i);
        } else {
            havingIndices.append(i);
        }
    }
```

#### AUTO 


```{c}
auto lprintContent = [this](QPainter &painter, bool friendly) {
        
        QPoint columnLines(_usedLines, _usedColumns);
        auto lfontget = [this]() { return _terminalFont->getVTFont(); };
        auto lfontset = [this](const QFont &f) { _terminalFont->setVTFont(f); };

        _printManager->printContent(painter, friendly, columnLines, lfontget, lfontset);
    };
```

#### AUTO 


```{c}
auto modifiers = profile->property<int>(Profile::UrlHintsModifiers);
```

#### AUTO 


```{c}
const auto& profile
```

#### AUTO 


```{c}
const auto positions = QVector<RadioOption>{ {_ui->scrollBarHiddenButton, Enum::ScrollBarHidden, SLOT(hideScrollBar())},
                                {_ui->scrollBarLeftButton, Enum::ScrollBarLeft, SLOT(showScrollBarLeft())},
                                {_ui->scrollBarRightButton, Enum::ScrollBarRight, SLOT(showScrollBarRight())}};
```

#### AUTO 


```{c}
auto newChild = new QStandardItem();
```

#### AUTO 


```{c}
auto group = konsoleConfig->group("SaveHistory Settings");
```

#### AUTO 


```{c}
auto drag = new QDrag(parent());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &metaData : pluginMetaData) {
        KPluginLoader pluginLoader(metaData.fileName());
        KPluginFactory *factory = pluginLoader.factory();
        if (!factory) {
            continue;
        }

        auto *plugin = factory->create<IKonsolePlugin>();
        if (!plugin) {
            continue;
        }

        d->plugins.push_back(plugin);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &file : entry.uninstalledFiles()) {
                if (ColorSchemeManager::instance()->unloadColorScheme(file)) {
                    continue;
                }
                qWarning() << "Failed to unload file" << file;
                // If unloading fails we do not care. If the scheme failed here
                // it either wasn't loaded or was invalid to begin with.
            }
```

#### AUTO 


```{c}
auto *manager = new KColorSchemeManager(parent);
```

#### AUTO 


```{c}
const auto currentPos = Coordinate{realCcolumn, _screen->getCursorX()};
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &choice : programs) {
        exec = checkProgram(choice);
        if (!exec.isEmpty()) {
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (uint cc : chars) {
        if (cc == DEL) {
            continue; // VT100: ignore.
        }

        if (ces(CTL)) {
            // ignore control characters in the text part of osc (aka OSC) "ESC]"
            // escape sequences; this matches what XTERM docs say
            // Allow BEL and ESC here, it will either end the text or be removed later.
            if (osc && cc != 0x1b && cc != 0x07) {
                continue;
            }

            if (!osc) {
                // DEC HACK ALERT! Control Characters are allowed *within* esc sequences in VT100
                // This means, they do neither a resetTokenizer() nor a pushToToken(). Some of them, do
                // of course. Guess this originates from a weakly layered handling of the X-on
                // X-off protocol, which comes really below this level.
                if (cc == CNTL('X') || cc == CNTL('Z') || cc == ESC) {
                    resetTokenizer(); // VT100: CAN or SUB
                }
                if (cc != ESC) {
                    processToken(token_ctl(cc + '@'), 0, 0);
                    continue;
                }
            }
        }
        // advance the state
        addToCurrentToken(cc);

        uint *s = tokenBuffer;
        const int p = tokenBufferPos;

        if (getMode(MODE_Ansi)) {
            if (lec(1, 0, ESC)) {
                continue;
            }
            if (lec(1, 0, ESC + 128)) {
                s[0] = ESC;
                receiveChars(QVector<uint>{'['});
                continue;
            }
            if (les(2, 1, GRP)) {
                continue;
            }
            // Operating System Command
            if (p > 2 && s[1] == ']') {
                // <ESC> ']' ... <ESC> '\'
                if (s[p - 2] == ESC && s[p - 1] == '\\') {
                    // This runs two times per link, the first prepares the link to be read,
                    // the second finalizes it. The escape sequence is in two parts
                    //  start: '\e ] 8 ; <id-path> ; <url-part> \e \\'
                    //  end:   '\e ] 8 ; ; \e \\'
                    // GNU libtextstyle inserts the IDs, for instance; many examples
                    // do not.
                    if (s[2] == XTERM_EXTENDED::URL_LINK) {
                        // printf '\e]8;;https://example.com\e\\This is a link\e]8;;\e\\\n'
                        _currentScreen->urlExtractor()->toggleUrlInput();
                    }
                    processSessionAttributeRequest(p - 1);
                    resetTokenizer();
                    continue;
                }
                // <ESC> ']' ... <ESC> + one character for reprocessing
                if (s[p - 2] == ESC) {
                    processSessionAttributeRequest(p - 1);
                    resetTokenizer();
                    receiveChars(QVector<uint>{cc});
                    continue;
                }
                // <ESC> ']' ... <BEL>
                if (s[p - 1] == 0x07) {
                    processSessionAttributeRequest(p);
                    resetTokenizer();
                    continue;
                }
            }

            /* clang-format off */
        // <ESC> ']' ...
        if (osc         ) { continue; }
        if (lec(3,2,'?')) { continue; }
        if (lec(3,2,'=')) { continue; }
        if (lec(3,2,'>')) { continue; }
        if (lec(3,2,'!')) { continue; }
        if (lec(3,2,SP )) { continue; }
        if (lec(4,3,SP )) { continue; }
        if (lun(       )) { processToken(token_chr(), applyCharset(cc), 0);   resetTokenizer(); continue; }
        if (dcs         ) { continue; /* TODO We don't xterm DCS, so we just eat it */ }
        if (lec(2,0,ESC)) { processToken(token_esc(s[1]), 0, 0);              resetTokenizer(); continue; }
        if (les(3,1,SCS)) { processToken(token_esc_cs(s[1],s[2]), 0, 0);      resetTokenizer(); continue; }
        if (lec(3,1,'#')) { processToken(token_esc_de(s[2]), 0, 0);           resetTokenizer(); continue; }
        if (eps(    CPN)) { processToken(token_csi_pn(cc), argv[0],argv[1]);  resetTokenizer(); continue; }

        // resize = \e[8;<row>;<col>t
        if (eps(CPS)) {
            processToken(token_csi_ps(cc, argv[0]), argv[1], argv[2]);
            resetTokenizer();
            continue;
        }

        if (epe(   )) { processToken(token_csi_pe(cc), 0, 0); resetTokenizer(); continue; }

        if (esp (   )) { processToken(token_csi_sp(cc), 0, 0);           resetTokenizer(); continue; }
        if (epsp(   )) { processToken(token_csi_psp(cc, argv[0]), 0, 0); resetTokenizer(); continue; }

        if (ees(DIG)) { addDigit(cc-'0'); continue; }
        if (eec(';')) { addArgument();    continue; }
        if (ees(INT)) { continue; }
        if (p >= 3 && cc == 'y' && s[p - 2] == '*') { processChecksumRequest(argc, argv); resetTokenizer(); continue; }
        for (int i = 0; i <= argc; i++) {
            if (epp()) {
                processToken(token_csi_pr(cc,argv[i]), 0, 0);
            } else if (eeq()) {
                processToken(token_csi_pq(cc), 0, 0); // spec. case for ESC[=0c or ESC[=c
            } else if (egt()) {
                processToken(token_csi_pg(cc), 0, 0); // spec. case for ESC[>0c or ESC[>c
            } else if (cc == 'm' && argc - i >= 4 && (argv[i] == 38 || argv[i] == 48) && argv[i+1] == 2)
            {
                // ESC[ ... 48;2;<red>;<green>;<blue> ... m -or- ESC[ ... 38;2;<red>;<green>;<blue> ... m
                i += 2;
                processToken(token_csi_ps(cc, argv[i-2]), COLOR_SPACE_RGB, (argv[i] << 16) | (argv[i+1] << 8) | argv[i+2]);
                i += 2;
            } else if (cc == 'm' && argc - i >= 2 && (argv[i] == 38 || argv[i] == 48) && argv[i+1] == 5) {
                // ESC[ ... 48;5;<index> ... m -or- ESC[ ... 38;5;<index> ... m
                i += 2;
                processToken(token_csi_ps(cc, argv[i-2]), COLOR_SPACE_256, argv[i]);
            } else if (p < 2 || (charClass[s[p-2]] & (INT)) != (INT)) {
                processToken(token_csi_ps(cc,argv[i]), 0, 0);
            }
        }
        resetTokenizer();
        /* clang-format on */
        } else {
            // VT52 Mode
            if (lec(1, 0, ESC)) {
                continue;
            }
            if (les(1, 0, CHR)) {
                processToken(token_chr(), s[0], 0);
                resetTokenizer();
                continue;
            }
            if (lec(2, 1, 'Y')) {
                continue;
            }
            if (lec(3, 1, 'Y')) {
                continue;
            }
            if (p < 4) {
                processToken(token_vt52(s[1]), 0, 0);
                resetTokenizer();
                continue;
            }
            processToken(token_vt52(s[1]), s[2], s[3]);
            resetTokenizer();
            continue;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *action : menu->actions()) {
        if (action->text().toLower().remove(QLatin1Char('&')).contains(i18n("open with"))) {
            toDelete.append(action);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](int idx) {
        emit detachTab(this, widget(idx));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto iterator : group) {
        Session* session = iterator;

        if (session != _sessionDisplayConnection->session()) {
            _copyToGroup->removeSession(iterator);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (TerminalDisplay *terminalDisplay : session->views()) {
            // Searching for already open EditProfileDialog instances
            // for this profile
            profileDialog = terminalDisplay->sessionController()->profileDialogPointer();
            if (profileDialog == nullptr) {
                continue;
            }

            if (profile->name() == profileDialog->lookupProfile()->name()
                && profileDialog->isVisible()) {
                // close opened edit dialog
                profileDialog->close();
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto editor : editorsList) {
        QString exec;
        QString displayName;
        QIcon icon;
        switch(editor) {
        case Enum::Kate:
            exec = QStringLiteral("kate");
            displayName = QStringLiteral("Kate");
            icon = QIcon::fromTheme(exec);
            break;
        case Enum::KWrite:
            exec = QStringLiteral("kwrite");
            displayName = QStringLiteral("KWrite");
            icon = QIcon::fromTheme(exec);
            break;
        case Enum::KDevelop:
            exec = QStringLiteral("kdevelop");
            displayName = QStringLiteral("KDevelop");
            icon = QIcon::fromTheme(exec);
            break;
        case Enum::QtCreator:
            exec = QStringLiteral("qtcreator");
            displayName = QStringLiteral("Qt Creator");
            icon = QIcon::fromTheme(exec);
            break;
        case Enum::Gedit:
            exec = QStringLiteral("gedit");
            displayName = QStringLiteral("Gedit");
            QIcon::fromTheme(QStringLiteral("org.gnome.gedit"));
            break;
        case Enum::gVim:
            exec = QStringLiteral("gvim");
            displayName = QStringLiteral("gVim");
            icon = QIcon::fromTheme(exec);
            break;
        case Enum::CustomTextEditor:
            displayName = QStringLiteral("Custom");
            icon = QIcon::fromTheme(QStringLiteral("system-run"));
            break;
        default:
            break;
        }

        editorCombo->addItem(icon, displayName);

        // For "CustomTextEditor" we don't check if the binary exists
        const bool isAvailable = editor == Enum::CustomTextEditor
                                 || !QStandardPaths::findExecutable(exec).isEmpty();
        // Make un-available editors look disabled in the combobox
        model->item(static_cast<int>(editor))->setEnabled(isAvailable);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &&child : viewSplitter->children()) {
            auto childViewSplitter = qobject_cast<ViewSplitter *>(child);
            if (childViewSplitter) {
                processChildren(childViewSplitter);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QButtonGroup *group : qAsConst(_groups)) {
        auto *enumItem = groupToConfigItemEnum(group);
        if (enumItem == nullptr) {
            continue;
        }
        const auto *currentButton = group->checkedButton();
        if (currentButton == nullptr) {
            continue;
        }
        const int value = buttonToEnumValue(currentButton);
        if (value < 0) {
            continue;
        }

        if (!enumItem->isEqual(value)) {
            enumItem->setValue(value);
            updateConfig = true;
        }
    }
```

#### AUTO 


```{c}
auto splitview = qobject_cast<ViewSplitter *>(widget(index));
```

#### AUTO 


```{c}
const auto hasSameWidth = [&](int column) {
                    const int characterLoc = qMin(_display->loc(column, y) + 1, _display->_imageSize - 1);
                    return (_display->_image[characterLoc].character == 0) == doubleWidth;
                };
```

#### AUTO 


```{c}
const auto hasSameColors = [&](int column) {
                return _image[loc(column, y)].foregroundColor == currentForeground
                    && _image[loc(column, y)].backgroundColor == currentBackground;
            };
```

#### AUTO 


```{c}
auto it = ids.cbegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (TerminalDisplay *view : session->views()) {
            view->screenWindow()->screen()->setReflowLines(enableReflowLines);
            view->screenWindow()->screen()->setEnableUrlExtractor(shouldEnableUrlExtractor);
            if (shouldEnableUrlExtractor) {
                view->screenWindow()->screen()->urlExtractor()->setAllowedLinkSchema(profile->escapedLinksSchema());
                connect(session->emulation(), &Emulation::toggleUrlExtractionRequest, view->screenWindow()->screen()->urlExtractor(), &EscapeSequenceUrlExtractor::toggleUrlInput);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *sessionAction : sessionActions) {
        _newTabMenuAction->menu()->addAction(sessionAction);

        auto setActionFontBold = [sessionAction](bool isBold) {
            QFont actionFont = sessionAction->font();
            actionFont.setBold(isBold);
            sessionAction->setFont(actionFont);
        };

        Profile::Ptr profile = ProfileManager::instance()->defaultProfile();
        if (profile && profile->name() == sessionAction->text().remove(QLatin1Char('&'))) {
            QIcon icon = KIconUtils::addOverlay(QIcon::fromTheme(profile->icon()), QIcon::fromTheme(QStringLiteral("emblem-favorite")), Qt::BottomRightCorner);
            sessionAction->setIcon(icon);
            setActionFontBold(true);
        } else {
            setActionFontBold(false);
        }
    }
```

#### AUTO 


```{c}
auto linkHandler = [this](const QString &url) {
                if (url == QLatin1String("#close")) {
                    _readOnlyMessageWidget->hide();
                }
            };
```

#### AUTO 


```{c}
auto *maybeTerminalDisplay = qobject_cast<TerminalDisplay *>(widget);
```

#### AUTO 


```{c}
const auto terminalDisplays = viewSplitter->findChildren<TerminalDisplay*>();
```

#### LAMBDA EXPRESSION 


```{c}
[&packedLineTypes](quint8 lineId)->void {
        lineId = LinesNum - 1 - lineId % LinesNum;
        packedLineTypes &= ~(3 << (2 * lineId));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (TerminalDisplay *terminalDisplay : viewsList) {
            // Searching for opened profiles
            profileDialog = terminalDisplay->sessionController()->profileDialogPointer();
            if (profileDialog != nullptr) {
                for (const Profile::Ptr &profile : profiles) {
                    if (profile->name() == profileDialog->lookupProfile()->name()
                        && profileDialog->isVisible()) {
                        // close opened edit dialog
                        profileDialog->close();
                    }
                }
            }
         }
```

#### AUTO 


```{c}
const auto updateStyleSheetFileEnable = [this](bool) {
        kcfg_TabBarUserStyleSheetFile->setEnabled(kcfg_TabBarUseUserStyleSheet->isChecked()
                                                  && !AlwaysHideTabBar->isChecked());
    };
```

#### AUTO 


```{c}
auto *sendSignalActions = collection->add<KSelectAction>(QStringLiteral("send-signal"));
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &button : group->buttons()) {
            if (button->objectName() == valueName) {
                currentButton = button;
                break;
            }
        }
```

#### AUTO 


```{c}
auto block = _blocks.begin();
```

#### AUTO 


```{c}
auto item = view->sessionController();
```

#### AUTO 


```{c}
auto job = new KIO::CommandLauncherJob(QStringLiteral("kcmshell5"), { QStringLiteral("webshortcuts") });
```

#### AUTO 


```{c}
auto reflowLineLen = [] (qint64 start, qint64 end) {
        return (int)((end - start) / sizeof(Character));
    };
```

#### AUTO 


```{c}
auto mit = ENTRY_RE.globalMatch(line);
```

#### AUTO 


```{c}
auto unsafeCharacters = terminalClipboard::checkForUnsafeCharacters(text);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto *layout : qAsConst(_layouts)) {
        QWidget *widget = layout->parentWidget();
        Q_ASSERT(widget);
        do {
            QLayout *widgetLayout = widget->layout();
            if (widgetLayout != nullptr) {
                widgetLayout->update();
                widgetLayout->activate();
            }
            widget = widget->parentWidget();
        } while (widget != _refWidget && widget != nullptr);
    }
```

#### AUTO 


```{c}
const auto oldDefault = _defaultProfile;
```

#### LAMBDA EXPRESSION 


```{c}
[sessionAction](bool isBold) {
            QFont actionFont = sessionAction->font();
            actionFont.setBold(isBold);
            sessionAction->setFont(actionFont);
        }
```

#### AUTO 


```{c}
const auto& possibility
```

#### AUTO 


```{c}
auto point = ev->pos() - m_startDrag;
```

#### CONST EXPRESSION 


```{c}
static constexpr const char testString[] = "abcdefghijklmnopqrstuvwxyz1234567890";
```

#### CONST EXPRESSION 


```{c}
static constexpr int MaxFontWeight = 99;
```

#### LAMBDA EXPRESSION 


```{c}
[this]{ emit newViewRequest(this); }
```

#### AUTO 


```{c}
auto splitter = viewSplitterAt(index);
```

#### AUTO 


```{c}
auto actionEdit = new QAction(i18n("Edit"), ui->commandsTreeView);
```

#### AUTO 


```{c}
auto *action = collection->action(actionName);
```

#### RANGE FOR STATEMENT 


```{c}
for (SessionController *controller : allControllers) {
            controller->reloadXML();
            if ((controller->factory() != nullptr) && controller != _pluggedController) {
                syncActiveShortcuts(controller->actionCollection(), _pluggedController->actionCollection());
            }
        }
```

#### AUTO 


```{c}
auto &currentLut = data[QStringLiteral("ranges-luts")].vec.last()[QStringLiteral("ranges")].vec;
```

#### AUTO 


```{c}
auto currentProfile = SessionManager::instance()->sessionProfile(display->session());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &range : qAsConst(ranges)) {
        if (range.width.isValid() && range.width != widthsSortOrder.last())
            mergedRanges[range.width].append({range.cp.first, range.cp.last});
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&](quint8 top, quint8 right) { // ?
        lightPath.moveTo(origin[top] + dir[right] * doubleLinesDistance);
        lightPath.lineTo(center + (dir[right] + dir[top]) * doubleLinesDistance);
        lightPath.lineTo(origin[right] + dir[top] * doubleLinesDistance);
    }
```

#### AUTO 


```{c}
auto historyTypeFile = new HistoryTypeFile();
```

#### LAMBDA EXPRESSION 


```{c}
[this](){
            this->loadLayout(QStandardPaths::locate(QStandardPaths::GenericDataLocation, QStringLiteral("konsole/1x2-terminals.json"))); }
```

#### AUTO 


```{c}
auto *maybeSplitter = qobject_cast<ViewSplitter *>(widget(i))
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &fileName : files) {
        qInfo().noquote() << QStringLiteral("Parsing as %1: %2").arg(fileTypeName).arg(fileName);
        QSharedPointer<QIODevice> source = nullptr;
        if (PROTOCOL_RE.match(fileName).hasMatch()) {
            source.reset(new KIODevice(QUrl(fileName)));
        } else {
            source.reset(new QFile(fileName));
        }

        if (!source->open(QIODevice::ReadOnly)) {
            qCritical() << QStringLiteral("Could not open %1: %2").arg(fileName).arg(source->errorString());
            exit(1);
        }
        UcdParser<EntryType> p(source.data());
        while (p.hasNext()) {
            const auto &e = p.next();
            for (uint cp = e.cp.first; cp <= e.cp.last; ++cp) {
                cb(props[cp], e);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QChar &c : text) {
                if (c.isPrint() || c == QLatin1Char('\t') || c == QLatin1Char('\n')) {
                    sanitized.append(c);
                }
            }
```

#### AUTO 


```{c}
auto *act
```

#### AUTO 


```{c}
auto sizes = viewSplitter->sizes();
```

#### AUTO 


```{c}
auto matchIter = RE.globalMatch(element.inner);
```

#### LAMBDA EXPRESSION 


```{c}
[&](quint8 lineId) -> QPainterPath& {
        Q_ASSERT(getLineType(lineId) != LtNone);
        return getLineType(lineId) == LtHeavy ? heavyPath : lightPath;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, controller] {
            activeViewChangedInternal(controller);
        }
```

#### AUTO 


```{c}
auto focusedWidget = focusWidget();
```

#### AUTO 


```{c}
const auto tooltipString = QStringLiteral("<img src='data:image/png;base64, %0'>").arg(QString::fromLocal8Bit(data.toBase64()));
```

#### AUTO 


```{c}
auto controller = dynamic_cast<SessionController *>(item);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &url) {
            if (url == QLatin1String("#close")) {
                _outputSuspendedMessageWidget->hide();
            } else {
                QDesktopServices::openUrl(QUrl(url));
            }
        }
```

#### AUTO 


```{c}
auto *scrollingPageItem = addPage(scrollingPageWidget, scrollingPageName);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &spot : spots) {
            if (spot->type() == Filter::HotSpot::Link) {
                urlNumber++;
            }
        }
```

#### AUTO 


```{c}
auto *display = reinterpret_cast<TerminalDisplay *>(view);
```

#### RANGE FOR STATEMENT 


```{c}
for (ViewProperties *view : views) {
        list << KBookmarkOwner::FutureBookmark(titleForView(view), urlForView(view), iconForView(view));
    }
```

#### AUTO 


```{c}
auto parentSplitter = qobject_cast<ViewSplitter *>(focusedTerminalDisplay->parent());
```

#### LAMBDA EXPRESSION 


```{c}
[this, dropText]{ emit sendStringToEmu(dropText.toLocal8Bit());}
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *action : newActions) {
                if (action->objectName() == QStringLiteral("openWith_submenu")) {
                    action->setText(i18n("Open Current Folder With"));
                }
            }
```

#### AUTO 


```{c}
const auto &e = p.next();
```

#### RANGE FOR STATEMENT 


```{c}
for(auto action : _contextPopupMenu->actions()) {
        if (action->objectName() == QStringLiteral("tab-detach")) {
            action->setEnabled( !isDarwin && count() > 1);
        }
    }
```

#### AUTO 


```{c}
auto selectionMenu = manager->createSchemeSelectionMenu(scheme, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto point : splitter->sizes()) {
            delta += point;
            QPoint thisPoint = orientation() == Qt::Horizontal
                ? QPoint(delta, 0)
                : QPoint(0, delta);


            QPoint splitterPos = splitter->mapToTopLevel(thisPoint);

            const int ourPos = orientation() == Qt::Horizontal
                ? splitterPos.x()
                : splitterPos.y();

            allSplitterSizes.push_back(ourPos);
        }
```

#### AUTO 


```{c}
auto terminal
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *menuItem : actions) {
        menuItem->setText(menuItem->text().replace(QLatin1Char('&'), QString()));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QButtonGroup *group : qAsConst(_groups)) {
        if (group->checkedButton() == nullptr) {
            continue;
        }
        int value = buttonToEnumValue(group->checkedButton());
        const auto *enumItem = groupToConfigItemEnum(group);

        if (enumItem != nullptr && !enumItem->isEqual(value)) {
            return true;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QChar &c : text) {
        if (isUnsafe(c)) {
            const QString sequence = charToSequence(c);
            const QString description = characterDescriptions.value(c.unicode(), QString());
            QString entry = QStringLiteral("U+%1").arg(c.unicode(), 4, 16, QLatin1Char('0'));
            if (!sequence.isEmpty()) {
                entry += QStringLiteral("\t%1").arg(sequence);
            }
            if (!description.isEmpty()) {
                entry += QStringLiteral("\t%1").arg(description);
            }
            unsafeCharacters.append(entry);
        }
    }
```

#### AUTO 


```{c}
const auto readAndCheckConfigEntry = [&](const char *key, double min, double max) -> double {
        const double value = configGroup.readEntry(key, min);
        if (min > value || value > max) {
            qCDebug(ColorSchemeDebug) << QStringLiteral(
                                             "Color scheme \"%1\": color index 2 has an invalid value: %3 = %4. "
                                             "Allowed value range: %5 - %6. Using %7.")
                                             .arg(name())
                                             .arg(index)
                                             .arg(QLatin1String(key))
                                             .arg(value, 0, 'g', 1)
                                             .arg(min, 0, 'g', 1)
                                             .arg(max, 0, 'g', 1)
                                             .arg(min, 0, 'g', 1);
            return min;
        }
        return value;
    };
```

#### AUTO 


```{c}
auto buffer = new uint[length + 1];
```

#### AUTO 


```{c}
auto writer = new ProfileWriter();
```

#### AUTO 


```{c}
auto splitterWidgets = jsonSplitter[QStringLiteral("Widgets")].toArray();
```

#### LAMBDA EXPRESSION 


```{c}
[](reflowData &change, int index, LineProperty flag) {
        change.index.push_back(index);
        change.flags.push_back(flag);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Profile::Ptr &profile : qAsConst(_profiles)) {
        profile->setProperty(p, value);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Profile::Ptr &profile : profiles) {
        if (profile != ProfileManager::instance()->defaultProfile()) {
            ProfileManager::instance()->deleteProfile(profile);
        }
    }
```

#### AUTO 


```{c}
auto profileMenu = new QMenu();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto iterator : group) {
        Session* session = iterator;

        if (session != _session) {
            _copyToGroup->removeSession(iterator);
        }
    }
```

#### AUTO 


```{c}
auto newView = manager->createView(session);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KeyboardTranslator::Entry &entry : entriesList) {
            writer.writeEntry(entry);
        }
```

#### AUTO 


```{c}
auto source = qobject_cast<TerminalDisplay *>(ev->source());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto *layout: qAsConst(_layouts)) {
        int left = getLeftMargin(layout);
        for (int row = 0; row < layout->rowCount(); ++row) {
            QLayoutItem *layoutItem = layout->itemAtPosition(row, LABELS_COLUMN);
            if (layoutItem == nullptr) {
                continue;
            }
            QWidget *widget = layoutItem->widget();
            if (widget == nullptr) {
                continue;
            }
            const int idx = layout->indexOf(widget);
            int rows, cols, rowSpan, colSpan;
            layout->getItemPosition(idx, &rows, &cols, &rowSpan, &colSpan);
            if (colSpan > 1) {
                continue;
            }

            const int right = left + widget->sizeHint().width();
            if (maxRight < right) {
                maxRight = right;
            }
        }
    }
```

#### AUTO 


```{c}
auto mainWindow = qobject_cast<Konsole::MainWindow*>(controller->view()->topLevelWidget());
```

#### CONST EXPRESSION 


```{c}
static constexpr int DIRECT_LUT_SIZE = 256;
```

#### AUTO 


```{c}
auto entry = fallback->findEntry(Qt::Key_Tab, Qt::NoModifier);
```

#### LAMBDA EXPRESSION 


```{c}
[this]{
       closeCurrentTab();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        if (_previewJob == nullptr) {
            return;
        }
        if (!_thumbnailFinished) {
            QToolTip::showText(_thumbnailPos, i18n("Generating Thumbnail"), qApp->focusWidget());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &fileName : fileNames) {
                targetFilePath = targetBasePath + fileName;
                if (!QFile::exists(targetFilePath)) {
                    QFile::copy(sourceBasePath + fileName, targetFilePath);
                }
            }
```

#### AUTO 


```{c}
const auto urls = sWindow->screen()->urlExtractor()->history();
```

#### AUTO 


```{c}
auto handleMultiTabActionsLambda = [=]{
        const int count = _viewContainer->count();
        foreach(QAction *action, _multiTabOnlyActions) {
            action->setEnabled(count > 1);
        }
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &dir : dirs) {
        const QStringList fileNames = QDir(dir).entryList(QStringList() << QStringLiteral("*.colorscheme"));
        for (const QString &file : fileNames) {
            colorschemes.append(dir + QLatin1Char('/') + file);
        }
    }
```

#### AUTO 


```{c}
auto *dialog = new EditProfileDialog(QApplication::activeWindow());
```

#### LAMBDA EXPRESSION 


```{c}
[this, profile]() {
        auto *dlg = new QInputDialog(static_cast<QWidget *>(this));
        dlg->setLabelText(
            i18n("The format is e.g. 'editorExec PATH:LINE:COLUMN'\n\n"
                 "PATH    will be replaced by the path to the text file\n"
                 "LINE    will be replaced by the line number\n"
                 "COLUMN  (optional) will be replaced by the column number\n"
                 "Note: you will need to replace 'PATH:LINE:COLUMN' by the actual\n"
                 "syntax the editor you want to use supports; e.g.:\n"
                 "gedit +LINE:COLUMN PATH\n\n"
                 "If PATH or LINE aren't present in the command, this setting\n"
                 "will be ignored and the file will be opened by the default text\n"
                 "editor."));
        const QString cmd = profile->customTextEditorCmd();
        dlg->setTextValue(cmd);
        dlg->setAttribute(Qt::WA_DeleteOnClose);
        dlg->setWindowTitle(i18n("Text Editor Custom Command"));

        QFontMetrics fm(font());
        const int width = qMin(fm.averageCharWidth() * cmd.size(), this->width());
        dlg->resize(width, dlg->height());

        connect(dlg, &QDialog::accepted, this, [this, dlg]() {
            updateTempProfileProperty(Profile::TextEditorCmdCustom, dlg->textValue());
        });

        dlg->show();
    }
```

#### AUTO 


```{c}
auto shape = static_cast<Enum::CursorShapeEnum>(currentProfile->property<int>(Profile::CursorShape));
```

#### RANGE FOR STATEMENT 


```{c}
for(auto terminal : terminals) {
        terminal->headerBar()->applyVisibilitySettings();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&](int column) {
                    const QChar::Script script = QChar::script(baseCodePoint(_display->_image[_display->loc(column, y)]));
                    if (currentScript == QChar::Script_Common || script == QChar::Script_Common
                        || currentScript == QChar::Script_Inherited || script == QChar::Script_Inherited) {
                        return true;
                    }
                    return currentScript == script;
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto terminal : viewSplitterAt(idx)->findChildren<TerminalDisplay *>()) {
        terminal->sessionController()->closeSession();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *qAction : source->actions()) {
        if (QAction *destQAction = dest->action(qAction->objectName())) {
            destQAction->setShortcut(qAction->shortcut());
        }
    }
```

#### AUTO 


```{c}
auto profileWriter = new ProfileWriter();
```

#### AUTO 


```{c}
auto view = widget(i);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QChar &c : text) {
        if (isUnsafe(c)) {
            const QString sequence = charToSequence(c);
            const QString description = characterDescriptions.value(c.unicode(), QString());
            QString entry = QStringLiteral("U+%1").arg(c.unicode(), 4, 16, QLatin1Char('0'));
            if(!sequence.isEmpty()) {
                entry += QStringLiteral("\t%1").arg(sequence);
            }
            if(!description.isEmpty()) {
                entry += QStringLiteral("\t%1").arg(description);
            }
            unsafeCharactersDescriptions.append(entry);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, controller]{ activeViewChangedInternal(controller); }
```

#### AUTO 


```{c}
auto &&i
```

#### RANGE FOR STATEMENT 


```{c}
for(auto action : _contextPopupMenu->actions()) {
        if (action->objectName() == QStringLiteral("tab-detach")) {
            action->setEnabled(count() > 1);
        }
    }
```

#### AUTO 


```{c}
auto factory = new KXMLGUIFactory(clientBuilder(), view());
```

#### AUTO 


```{c}
auto titleOption = QCommandLineOption({ QStringLiteral("T") },
                                          QStringLiteral("Debian policy compatibility, not used"),
                                          QStringLiteral("value"));
```

#### AUTO 


```{c}
auto getCharacterBuffer = [](int size) {
        static QVector<Character> characterBuffer(1024);
        if (characterBuffer.count() < size) {
            characterBuffer.resize(size);
        }

        return characterBuffer.data();
    };
```

#### AUTO 


```{c}
auto session
```

#### AUTO 


```{c}
auto actionRename = new QAction(i18n("Rename"), ui->commandsTreeView);
```

#### LAMBDA EXPRESSION 


```{c}
[&](int column) {
                    return _display->_image[loc(column, y)].foregroundColor == currentForeground
                        && _display->_image[loc(column, y)].backgroundColor == currentBackground;
                }
```

#### AUTO 


```{c}
auto config = KConfig(QStringLiteral("konsolesshconfig"), KConfig::OpenFlag::SimpleConfig);
```

#### RANGE FOR STATEMENT 


```{c}
for (TerminalDisplay *terminalDisplay : viewsList) {
        if (terminalDisplay != _view.data()) {
            terminalDisplay->updateReadOnlyState(isReadOnly());
        }
        emit readOnlyChanged(this);
    }
```

#### AUTO 


```{c}
auto window = new ScreenWindow(_currentScreen);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto i : text) {
        w += konsole_wcwidth(i.unicode());
    }
```

#### AUTO 


```{c}
auto match = matchIter.next();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &profile: profiles) {
        isNotDefault = isNotDefault && (profile != manager->defaultProfile());
        isDeletable = isDeletable && isProfileDeletable(profile);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (SessionController *controller : qAsConst(_allControllers)) {
        if ( (controller->profileDialogPointer() != nullptr)
             && controller->profileDialogPointer()->isVisible()
             && (controller->profileDialogPointer()->lookupProfile()
                 == SessionManager::instance()->sessionProfile(session())) ) {
            controller->profileDialogPointer()->close();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString& sessionName : group.groupList()) {
            SSHConfigurationData data;
            KConfigGroup sessionGroup = group.group(sessionName);
            data.host = sessionGroup.readEntry("hostname");
            data.name = sessionGroup.readEntry("identifier");
            data.port = sessionGroup.readEntry("port");
            data.profileName = sessionGroup.readEntry("profilename");
            data.sshKey = sessionGroup.readEntry("sshkey");
            data.useSshConfig = sessionGroup.readEntry<bool>("useSshConfig", false);
            data.importedFromSshConfig = sessionGroup.readEntry<bool>("importedFromSshConfig", false);
            addChildItem(data, groupName);
        }
```

#### AUTO 


```{c}
auto &action
```

#### LAMBDA EXPRESSION 


```{c}
[this, dropText]{ Q_EMIT sendStringToEmu(dropText.toLocal8Bit());}
```

#### AUTO 


```{c}
auto selection =  ui->treeView->selectionModel()->selectedIndexes();
```

#### RANGE FOR STATEMENT 


```{c}
for (TerminalDisplay *view : views) {
        const QFont &viewCurFont = view->getVTFont();
        if (viewCurFont != _sessionProfiles[session]->font()) {
            zoomFontSizes.insert(view, viewCurFont);
        }
    }
```

#### AUTO 


```{c}
auto delegate = new ColorSchemeViewDelegate(this);
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString &fileName: files) {
        qInfo().noquote() << QStringLiteral("Parsing as %1: %2").arg(fileTypeName).arg(fileName);
        QSharedPointer<QIODevice> source = nullptr;
        if(PROTOCOL_RE.match(fileName).hasMatch()) {
            source.reset(new KIODevice(QUrl(fileName)));
        } else {
            source.reset(new QFile(fileName));
        }

        if(!source->open(QIODevice::ReadOnly)) {
            qCritical() << QStringLiteral("Could not open %1: %2").arg(fileName).arg(source->errorString());
            exit(1);
        }
        UcdParser<EntryType> p(source.data());
        while(p.hasNext()) {
            const auto &e = p.next();
            for(uint cp = e.cp.first; cp <= e.cp.last; ++cp) {
                cb(props[cp], e);
            }
        }
    }
```

#### AUTO 


```{c}
auto thumbnailPage = new KPageWidgetItem(new ThumbnailsSettings(confDialog), thumbnailPageName);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &path : paths) {
        QFileInfo info(path);
        printf("%s\n", info.completeBaseName().toLocal8Bit().constData());
    }
```

#### AUTO 


```{c}
const auto heavyPen = pen(paint, heavyLineWidth);
```

#### LAMBDA EXPRESSION 


```{c}
[](CharacterProperties &prop, const GenericWidthEntry &entry) { prop.customWidth = entry.width(); }
```

#### AUTO 


```{c}
const auto currentPos = QCursor::pos();
```

#### AUTO 


```{c}
auto currentMergedRangesIt = mergedRanges.find(width);
```

#### AUTO 


```{c}
const auto *currentButton = group->checkedButton();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        this->loadLayout(QStandardPaths::locate(QStandardPaths::GenericDataLocation, QStringLiteral("konsole/2x1-terminals.json")));
    }
```

#### AUTO 


```{c}
const auto display = qobject_cast<TerminalDisplay *>(sender());
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QFont &font) {
            preview(Profile::Font, font);
            updateFontPreview(font);
        }
```

#### AUTO 


```{c}
auto* sendSignalActions = collection->add<KSelectAction>(QStringLiteral("send-signal"));
```

#### LAMBDA EXPRESSION 


```{c}
[&](int column) {
                return column <= rect.right();
            }
```

#### AUTO 


```{c}
auto *bookmarkMenu = new BookmarkMenu(manager, this, _menu, toplevel ? collection : nullptr);
```

#### AUTO 


```{c}
auto *maybeSplitter = qobject_cast<ViewSplitter*>(widgetAt)
```

#### AUTO 


```{c}
auto editor
```

#### AUTO 


```{c}
auto toVisibility = settings->splitViewVisibility();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &colorScheme : nativeColorSchemes) {
        if (!loadColorScheme(colorScheme)) {
            failed++;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *historyItem : _terminalDisplayHistory) {
            for (auto *terminalDisplay : tabTterminalDisplays) {
                if (terminalDisplay == historyItem) {
                    terminalDisplay->setFocus(Qt::OtherFocusReason);
                    return;
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &translatorPath : qAsConst(list)) {
        QString name = QFileInfo(translatorPath).completeBaseName();

        if (!_translators.contains(name)) {
            _translators.insert(name, nullptr);
        }
    }
```

#### AUTO 


```{c}
auto *currentSplitter = new ViewSplitter();
```

#### RANGE FOR STATEMENT 


```{c}
for (TerminalDisplay *view : qAsConst(_views)) {
        if (!view->isHidden() &&
                view->lines() >= VIEW_LINES_THRESHOLD &&
                view->columns() >= VIEW_COLUMNS_THRESHOLD) {
            minLines = (minLines == -1) ? view->lines() : qMin(minLines , view->lines());
            minColumns = (minColumns == -1) ? view->columns() : qMin(minColumns , view->columns());
            view->processFilters();
        }
    }
```

#### AUTO 


```{c}
auto* terminalDisplay = static_cast<TerminalDisplay*>(parent());
```

#### AUTO 


```{c}
auto focusedTerminalDisplay = qobject_cast<TerminalDisplay*>(focusedWidget);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& profile : ProfileManager::instance()->allProfiles()) {
        addShortcutAction(profile);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, session]() {
        sessionTerminated(session);
    }
```

#### AUTO 


```{c}
const auto updateStyleSheetFileEnable = [this](bool) {
        kcfg_TabBarUserStyleSheetFile->setEnabled(kcfg_TabBarUseUserStyleSheet->isChecked() && !AlwaysHideTabBar->isChecked());
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *sessionAction : sessionActions) {
            _newTabMenuAction->menu()->addAction(sessionAction);

            auto setActionFont = [sessionAction](bool isBold) {
                QFont actionFont = sessionAction->font();
                actionFont.setBold(isBold);
                sessionAction->setFont(actionFont);
            };

            Profile::Ptr profile = ProfileManager::instance()->defaultProfile();
            if (profile && profile->name() == sessionAction->text().remove(QLatin1Char('&'))) {
                QIcon icon(KIconLoader::global()->loadIcon(profile->icon(), KIconLoader::Small, 0, KIconLoader::DefaultState, QStringList(QStringLiteral("emblem-favorite"))));
                sessionAction->setIcon(icon);
                setActionFont(true);
            } else {
                sessionAction->setIcon(QIcon::fromTheme(profile->icon()));
                setActionFont(false);
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](CharacterProperties &prop, const UnicodeDataEntry &entry) {
                                            prop.category = entry.category();
                                        }
```

#### AUTO 


```{c}
const auto pageamounts = QVector<RadioOption>{
        {_scrollingUi->scrollHalfPage, Enum::ScrollPageHalf, SLOT(scrollHalfPage())},
        {_scrollingUi->scrollFullPage, Enum::ScrollPageFull, SLOT(scrollFullPage())}
    };
```

#### AUTO 


```{c}
const auto hasSameWidth = [&](int column) {
                const int characterLoc = qMin(display->loc(column, y) + 1, imageSize - 1);
                return (image[characterLoc].character == 0) == doubleWidth;
            };
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &entry : qAsConst(changedEntries)) {
        switch (entry.status()) {
        case KNS3::Entry::Installed:
            for (const auto &file : entry.installedFiles()) {
                if (ColorSchemeManager::instance()->loadColorScheme(file)) {
                    continue;
                }
                qWarning() << "Failed to load file" << file;
                ++failures;
            }
            if (failures == entry.installedFiles().size()) {
                _appearanceUi->colorSchemeMessageWidget->setText(
                            xi18nc("@info",
                                   "Scheme <resource>%1</resource> failed to load.",
                                   entry.name()));
                _appearanceUi->colorSchemeMessageWidget->animatedShow();
                QTimer::singleShot(8000,
                                   _appearanceUi->colorSchemeMessageWidget,
                                   &KMessageWidget::animatedHide);
            }
            break;
        case KNS3::Entry::Deleted:
            for (const auto &file : entry.uninstalledFiles()) {
                if (ColorSchemeManager::instance()->unloadColorScheme(file)) {
                    continue;
                }
                qWarning() << "Failed to unload file" << file;
                // If unloading fails we do not care. If the scheme failed here
                // it either wasn't loaded or was invalid to begin with.
            }
            break;
        case KNS3::Entry::Invalid:
        case KNS3::Entry::Installing:
        case KNS3::Entry::Downloadable:
        case KNS3::Entry::Updateable:
        case KNS3::Entry::Updating:
            // Not interesting.
            break;
        }
    }
```

#### AUTO 


```{c}
auto *controller = terminalDisplay->sessionController();
```

#### LAMBDA EXPRESSION 


```{c}
[&](int column) {
                return (_image[loc(column, y)].rendition & ~RE_EXTENDED_CHAR)
                    == (currentRendition & ~RE_EXTENDED_CHAR);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto *filter : _filters) {
        filter->setBuffer(buffer, linePositions);
    }
```

#### AUTO 


```{c}
auto* mouseEvent = static_cast<QMouseEvent*>(event);
```

#### AUTO 


```{c}
auto ucs4Str = str.toUcs4();
```

#### AUTO 


```{c}
auto iter_geq = std::lower_bound(
            sorted_array.begin(),
            sorted_array.end(),
            x
        );
```

#### LAMBDA EXPRESSION 


```{c}
[this, action]() {
        toggleReadOnly(action);
    }
```

#### AUTO 


```{c}
auto *keyEvent = static_cast<QKeyEvent *>(event);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QRect &rect : qAsConst(dirtyImageRegion)) {
        emit drawContents(_image, paint, rect, false, _imageSize, _bidiEnabled, _fixedFont, _lineProperties);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto dropWidget : widgets) {
        if (dropWidget->rect().contains(dropWidget->mapFromGlobal(currentPos))) {
            emit dropWidget->moveViewRequest(-1, id, this);
            removeView(widget(index));
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[mainWindow]{
        mainWindow->newTab();
    }
```

#### AUTO 


```{c}
auto session = _sessionDisplayConnection->session();
```

#### LAMBDA EXPRESSION 


```{c}
[]{ QToolTip::hideText(); }
```

#### AUTO 


```{c}
auto openAction = new QAction(_urlObject);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &entry : entries) {
            for (const auto &file : entry.installedFiles()) {
                if (ColorSchemeManager::colorSchemeNameFromPath(file) != name) {
                    continue;
                }
                // Make sure the manager can unload it before uninstalling it.
                if (ColorSchemeManager::instance()->unloadColorScheme(file)) {
                    manager->uninstallEntry(entry);
                    uninstalled = true;
                }
            }
            if (uninstalled) {
                break;
            }
        }
```

#### AUTO 


```{c}
const auto data = item->data(SSHManagerModel::SSHRole).value<SSHConfigurationData>();
```

#### RANGE FOR STATEMENT 


```{c}
for (ViewProperties* view : views) {
        list << KBookmarkOwner::FutureBookmark(titleForView(view), urlForView(view), iconForView(view));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](int index) {
        if (index != -1) {
            QWidget *view = widget(index);
            view->setFocus();
            updateTabHistory(view);
        } else {
            deleteLater();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *child: widget->children()) {
        auto *childWidget = qobject_cast<QWidget *>(child);
        if (childWidget != nullptr) {
            registerWidgetAndChildren(childWidget);
        }
    }
```

#### AUTO 


```{c}
auto viewSplitter = getToplevelSplitter();
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QPoint& pos){
        if (!ui->treeView->indexAt(pos).isValid()) {
            return;
        }

        QMenu *menu = new QMenu(this);
        auto action = new QAction(QStringLiteral("Remove"), ui->treeView);
        menu->addAction(action);

        connect(action, &QAction::triggered, this, &SSHManagerTreeWidget::triggerRemove);

        menu->popup(ui->treeView->viewport()->mapToGlobal(pos));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const PropertyInfo &info : DefaultProperties) {
        Property current = info.property;
        QVariant otherValue = profile->property<QVariant>(current);
        if (current == Name || current == Path) { // These are unique per Profile
            continue;
        }
        if (!differentOnly || property<QVariant>(current) != otherValue) {
            setProperty(current, otherValue);
        }
    }
```

#### AUTO 


```{c}
const auto inverseBackgroundAlpha = (backgroundAlpha * inverseForegroundAlpha);
```

#### AUTO 


```{c}
auto *root = invisibleRootItem();
```

#### AUTO 


```{c}
auto widgetAtPos = qApp->topLevelAt(event->globalPos());
```

#### AUTO 


```{c}
auto terminalSession = terminalDisplay->sessionController()->session();
```

#### AUTO 


```{c}
auto &button
```

#### AUTO 


```{c}
auto *plugin
```

#### AUTO 


```{c}
auto it = _entries.find(keyCode);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &[pos, delta] : deltas) {
            scrollPlacements(delta, INT64_MIN, pos);
        }
```

#### AUTO 


```{c}
auto *editor = new KeyBindingEditor(this);
```

#### AUTO 


```{c}
const auto *buttonGroup
```

#### AUTO 


```{c}
const auto options = QVector<QCommandLineOption>{
        {{QStringLiteral("profile")}, i18nc("@info:shell", "Name of profile to use for new Konsole instance"), QStringLiteral("name")},
        {{QStringLiteral("layout")}, i18nc("@info:shell", "json layoutfile to be loaded to use for new Konsole instance"), QStringLiteral("file")},
        {{QStringLiteral("fallback-profile")}, i18nc("@info:shell", "Use the internal FALLBACK profile")},
        {{QStringLiteral("workdir")}, i18nc("@info:shell", "Set the initial working directory of the new tab or window to 'dir'"), QStringLiteral("dir")},
        {{QStringLiteral("hold"), QStringLiteral("noclose")}, i18nc("@info:shell", "Do not close the initial session automatically when it ends.")},
        // BR: 373440
        {{QStringLiteral("new-tab")}, i18nc("@info:shell", "Create a new tab in an existing window rather than creating a new window ('Run all Konsole windows in a single process' must be enabled)")},
        {{QStringLiteral("tabs-from-file")}, i18nc("@info:shell", "Create tabs as specified in given tabs configuration file"), QStringLiteral("file")},
        {{QStringLiteral("background-mode")},
         i18nc("@info:shell", "Start Konsole in the background and bring to the front when Ctrl+Shift+F12 (by default) is pressed")},
        {{QStringLiteral("separate"), QStringLiteral("nofork")}, i18nc("@info:shell", "Run in a separate process")},
        {{QStringLiteral("show-menubar")}, i18nc("@info:shell", "Show the menubar, overriding the default setting")},
        {{QStringLiteral("hide-menubar")}, i18nc("@info:shell", "Hide the menubar, overriding the default setting")},
        {{QStringLiteral("show-tabbar")}, i18nc("@info:shell", "Show the tabbar, overriding the default setting")},
        {{QStringLiteral("hide-tabbar")}, i18nc("@info:shell", "Hide the tabbar, overriding the default setting")},
        {{QStringLiteral("fullscreen")}, i18nc("@info:shell", "Start Konsole in fullscreen mode")},
        {{QStringLiteral("notransparency")}, i18nc("@info:shell", "Disable transparent backgrounds, even if the system supports them.")},
        {{QStringLiteral("list-profiles")}, i18nc("@info:shell", "List the available profiles")},
        {{QStringLiteral("list-profile-properties")}, i18nc("@info:shell", "List all the profile properties names and their type (for use with -p)")},
        {{QStringLiteral("p")}, i18nc("@info:shell", "Change the value of a profile property."), QStringLiteral("property=value")},
        {{QStringLiteral("e")},
         i18nc("@info:shell", "Command to execute. This option will catch all following arguments, so use it as the last option."),
         QStringLiteral("cmd")},
        {{QStringLiteral("force-reuse")}, i18nc("@info:shell", "Force re-using the existing instance even if it breaks functionality, e. g. --new-tab. Mostly for debugging.")},
    };
```

#### AUTO 


```{c}
const auto options = QVector<QCommandLineOption> {
        { { QStringLiteral("profile") },
            i18nc("@info:shell", "Name of profile to use for new Konsole instance"),
            QStringLiteral("name")
        },
        { { QStringLiteral("fallback-profile") },
            i18nc("@info:shell", "Use the internal FALLBACK profile")
        },
        { { QStringLiteral("workdir") },
            i18nc("@info:shell", "Set the initial working directory of the new tab or window to 'dir'"),
            QStringLiteral("dir")
        },
        { { QStringLiteral("hold"), QStringLiteral("noclose") },
           i18nc("@info:shell", "Do not close the initial session automatically when it ends.")
        },
        {  {QStringLiteral("new-tab") },
            i18nc("@info:shell", "Create a new tab in an existing window rather than creating a new window")
        },
        { { QStringLiteral("tabs-from-file") },
            i18nc("@info:shell","Create tabs as specified in given tabs configuration"" file"),
            QStringLiteral("file")
        },
        { { QStringLiteral("background-mode") },
            i18nc("@info:shell", "Start Konsole in the background and bring to the front when Ctrl+Shift+F12 (by default) is pressed")
        },
        { { QStringLiteral("separate"), QStringLiteral("nofork") },
            i18nc("@info:shell", "Run in a separate process")
        },
        { { QStringLiteral("show-menubar") },
            i18nc("@info:shell", "Show the menubar, overriding the default setting")
        },
        { { QStringLiteral("hide-menubar") },
            i18nc("@info:shell", "Hide the menubar, overriding the default setting")
        },
        { { QStringLiteral("show-tabbar") },
            i18nc("@info:shell", "Show the tabbar, overriding the default setting")
        },
        { { QStringLiteral("hide-tabbar") },
            i18nc("@info:shell", "Hide the tabbar, overriding the default setting")
        },
        { { QStringLiteral("fullscreen") },
            i18nc("@info:shell", "Start Konsole in fullscreen mode")
        },
        { { QStringLiteral("notransparency") },
            i18nc("@info:shell", "Disable transparent backgrounds, even if the system supports them.")
        },
        { { QStringLiteral("list-profiles") },
            i18nc("@info:shell", "List the available profiles")
        },
        { { QStringLiteral("list-profile-properties") },
            i18nc("@info:shell", "List all the profile properties names and their type (for use with -p)")
        },
        { { QStringLiteral("p") },
            i18nc("@info:shell", "Change the value of a profile property."),
            QStringLiteral("property=value")
        },
        { { QStringLiteral("e") },
            i18nc("@info:shell", "Command to execute. This option will catch all following arguments, so use it as the last option."),
            QStringLiteral("cmd")
        }
    };
```

#### AUTO 


```{c}
auto backgroundTimer = new QTimer(_sessionDisplayConnection->session());
```

#### AUTO 


```{c}
const auto isBold = [boldWeight](const QFont &font) {
        return font.weight() >= boldWeight;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            return _terminalFont->getVTFont();
        }
```

#### AUTO 


```{c}
auto* elm
```

#### AUTO 


```{c}
constexpr auto MASK_TIMEOUT = 500ms;
```

#### RANGE FOR STATEMENT 


```{c}
for (int index : ColorIndexesForRandomization) {
                setRandomizationRange(index, MaxHue, MaxSaturation, 0.0);
            }
```

#### AUTO 


```{c}
auto copyAction = new QAction(this);
```

#### AUTO 


```{c}
const auto handleWidth = parentSplitter->handleWidth() + 3;
```

#### AUTO 


```{c}
auto *splitter = qobject_cast<QSplitter *>(_viewContainer->widget(i));
```

#### AUTO 


```{c}
auto *manager = ProfileManager::instance();
```

#### AUTO 


```{c}
auto lfontget = [this]() {
            return _terminalFont->getVTFont();
        };
```

#### AUTO 


```{c}
auto viewSplitter = qobject_cast<ViewSplitter*>(_viewContainer->currentWidget());
```

#### RANGE FOR STATEMENT 


```{c}
for (const Profile::Ptr &oldProfile : availableProfiles) {
                if (oldProfile->path() == origPath) {
                    // assign the same shortcut of the old profile to
                    // the newly renamed profile
                    const auto oldShortcut = shortcut(oldProfile);
                    if (deleteProfile(oldProfile)) {
                        setShortcut(newProfile, oldShortcut);
                    }
                }
            }
```

#### AUTO 


```{c}
const auto old = popup->actions();
```

#### AUTO 


```{c}
auto it = GENERATOR_FUNCS_MAP.constBegin();
```

#### AUTO 


```{c}
const auto rect = _overlayEdge == Qt::LeftEdge ? QRect(0, y, width() / 2, height())
                  : _overlayEdge == Qt::TopEdge ? QRect(0, y, width(), height() / 2)
                  : _overlayEdge == Qt::RightEdge ? QRect(width() - width() / 2, y, width() / 2, height())
                  : QRect(0, height() - height() / 2, width(), height() / 2);
```

#### AUTO 


```{c}
auto newLinePositions = new QList<int>();
```

#### AUTO 


```{c}
const auto displays = topLevelSplitter->findChildren<TerminalDisplay*>();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto & i : profile) {
        i = new Profile;
        QVERIFY(!i->asGroup());
    }
```

#### AUTO 


```{c}
auto controller = _navigation[widget(_contextMenuTabIndex)];
```

#### AUTO 


```{c}
const auto* action = qobject_cast<const QAction*>(sender());
```

#### LAMBDA EXPRESSION 


```{c}
[this, readonly](const QString &name) {
        QAction *action = actionCollection()->action(name);
        if (action != nullptr) {
            action->setEnabled(!readonly);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto sdsp : _sessionMap) {
        view = sdsp->session() == session ? sdsp->view() : nullptr;
        if (view != nullptr) {
            _sessionMap.removeOne(sdsp);
            break;
        }
    }
```

#### AUTO 


```{c}
auto iterator
```

#### AUTO 


```{c}
const auto message = xi18nc("@info:tooltip",
                                    "When using this option, the scrollback data will be written unencrypted to temporary files. Those temporary files will be "
                                    "deleted automatically when Konsole is closed in a normal manner.<nl/>Use <emphasis>Settings ? Configure Konsole ? File "
                                    "Location</emphasis> to select the location of the temporary files.");
```

#### LAMBDA EXPRESSION 


```{c}
[this, profile]() {
        auto *dlg = new QInputDialog(static_cast<QWidget *>(this));
        dlg->setLabelText(i18n("The format is e.g. 'editorExec PATH:LINE:COLUMN'\n\n"
                               "PATH    will be replaced by the path to the text file\n"
                               "LINE    will be replaced by the line number\n"
                               "COLUMN  (optional) will be replaced by the column number\n"
                               "Note: you will need to replace 'PATH:LINE:COLUMN' by the actual\n"
                               "syntax the editor you want to use supports; e.g.:\n"
                               "gedit +LINE:COLUMN PATH\n\n"
                               "If PATH or LINE aren't present in the command, this setting\n"
                               "will be ignored and the file will be opened by the default text\n"
                               "editor."));
        const QString cmd = profile->customTextEditorCmd();
        dlg->setTextValue(cmd);
        dlg->setAttribute(Qt::WA_DeleteOnClose);
        dlg->setWindowTitle(i18n("Text Editor Custom Command"));

        QFontMetrics fm(font());
        const int width = qMin(fm.averageCharWidth() * cmd.size(), this->width());
        dlg->resize(width, dlg->height());

        connect(dlg, &QDialog::accepted, this, [this, dlg]() {
            updateTempProfileProperty(Profile::TextEditorCmdCustom, dlg->textValue());
        });

        dlg->show();
    }
```

#### AUTO 


```{c}
auto buttonBox = new QDialogButtonBox(QDialogButtonBox::Ok|QDialogButtonBox::Cancel|QDialogButtonBox::Apply);
```

#### AUTO 


```{c}
const auto currentEditor = profile->property<int>(Profile::TextEditorCmd);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &[group, oldName, newName] : keys) {
        KConfigGroup cg = konsoleConfig->group(group);
        if (cg.exists() && cg.hasKey(oldName)) {
            const bool value = cg.readEntry(oldName, false);
            cg.deleteEntry(oldName);
            cg.writeEntry(newName, value);
        }
    }
```

#### AUTO 


```{c}
auto it = propertyMap.cbegin();
```

#### AUTO 


```{c}
auto values = _screenLines.at(currentPos).mid(new_columns);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        _bellMasked = false;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, i]() {
            switchToView(i);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto editor : editorsList) {
        QString exec;
        QString displayName;
        QIcon icon;
        switch (editor) {
        case Enum::Kate:
            exec = QStringLiteral("kate");
            displayName = QStringLiteral("Kate");
            icon = QIcon::fromTheme(exec);
            break;
        case Enum::KWrite:
            exec = QStringLiteral("kwrite");
            displayName = QStringLiteral("KWrite");
            icon = QIcon::fromTheme(exec);
            break;
        case Enum::KDevelop:
            exec = QStringLiteral("kdevelop");
            displayName = QStringLiteral("KDevelop");
            icon = QIcon::fromTheme(exec);
            break;
        case Enum::QtCreator:
            exec = QStringLiteral("qtcreator");
            displayName = QStringLiteral("Qt Creator");
            icon = QIcon::fromTheme(exec);
            break;
        case Enum::Gedit:
            exec = QStringLiteral("gedit");
            displayName = QStringLiteral("Gedit");
            QIcon::fromTheme(QStringLiteral("org.gnome.gedit"));
            break;
        case Enum::gVim:
            exec = QStringLiteral("gvim");
            displayName = QStringLiteral("gVim");
            icon = QIcon::fromTheme(exec);
            break;
        case Enum::CustomTextEditor:
            displayName = QStringLiteral("Custom");
            icon = QIcon::fromTheme(QStringLiteral("system-run"));
            break;
        default:
            break;
        }

        editorCombo->addItem(icon, displayName);

        // For "CustomTextEditor" we don't check if the binary exists
        const bool isAvailable = editor == Enum::CustomTextEditor || !QStandardPaths::findExecutable(exec).isEmpty();
        // Make un-available editors look disabled in the combobox
        model->item(static_cast<int>(editor))->setEnabled(isAvailable);
    }
```

#### AUTO 


```{c}
auto it = entries.cbegin(), itEnd = entries.cend();
```

#### LAMBDA EXPRESSION 


```{c}
[this](Profile::Ptr profile) { newFromProfile(_viewManager->activeContainer(), profile);}
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        QSet<Session*> newGroup = dialog->chosenSessions();
        newGroup.remove(session());

        const QSet<Session *> completeGroup = newGroup | currentGroup;
        for (Session *session : completeGroup) {
            if (newGroup.contains(session) && !currentGroup.contains(session)) {
                _copyToGroup->addSession(session);
            } else if (!newGroup.contains(session) && currentGroup.contains(session)) {
                _copyToGroup->removeSession(session);
            }
        }

        _copyToGroup->setMasterStatus(session(), true);
        _copyToGroup->setMasterMode(SessionGroup::CopyInputToAll);
        snapshot();
        Q_EMIT copyInputChanged(this);
    }
```

#### AUTO 


```{c}
auto filterProxyModel = new QSortFilterProxyModel(this);
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &lineCharacter : putToScreen) {
    screen.displayCharacter(lineCharacter.toLatin1());
  }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QPainter &painter, bool friendly) {
        
        QPoint columnLines(_usedLines, _usedColumns);
        auto lfontget = [this]() { return getVTFont(); };
        auto lfontset = [this](const QFont &f) { setVTFont(f); };

        _printManager->printContent(painter, friendly, columnLines, lfontget, lfontset);
    }
```

#### AUTO 


```{c}
const auto drawUpRight = [&](quint8 top, quint8 right) { // ??
        pathForLine(top).moveTo(origin[top]);
        pathForLine(top).lineTo(center);
        pathForLine(top).lineTo(origin[right]);
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (auto terminalDisplay : terminalDisplays) {
            terminalDisplay->setVisible(true);
        }
```

#### AUTO 


```{c}
auto topLevelSplitter = qobject_cast<ViewSplitter*>(controller->view()->parentWidget())->getToplevelSplitter();
```

#### AUTO 


```{c}
auto *session = createSession(profile, directory);
```

#### AUTO 


```{c}
auto newView = _viewManager->createView(session);
```

#### AUTO 


```{c}
auto sourceIdx = d->filterModel->mapToSource(selection.at(0));
```

#### AUTO 


```{c}
const auto property = it.key();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *plugin : d->plugins) {
        plugin->addMainWindow(window);
        internalPluginSubmenus.append(plugin->menuBarActions(window));
        window->addPlugin(plugin);
    }
```

#### AUTO 


```{c}
auto lfontget = [this]() { return _terminalFont->getVTFont(); };
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &action : _contextPopupMenu->actions()) {
            if (action->objectName() == QStringLiteral("edit-rename")) {
                action->setEnabled(!sessionController->isReadOnly());
                break;
            }
        }
```

#### AUTO 


```{c}
auto actionRename = new QAction(QStringLiteral("Rename"), ui->commandsTreeView);
```

#### AUTO 


```{c}
const auto idx = indexOf(widget);
```

#### AUTO 


```{c}
auto *bellModeModel = new QStringListModel({i18n("System Bell"), i18n("System Notifications"),
                                                i18n("Visual Bell"), i18n("Ignore Bell Events")},
                                               this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &commandGroup : group.groupList()) {
            QuickCommandData data;
            KConfigGroup element = group.group(commandGroup);
            data.name = element.readEntry("name");
            data.tooltip = element.readEntry("tooltip");
            data.command = element.readEntry("command");
            addChildItem(data, groupName);
        }
```

#### AUTO 


```{c}
auto controller = new SessionController(session, view, this);
```

#### AUTO 


```{c}
auto widget = new KMessageWidget(text);
```

#### AUTO 


```{c}
const auto scheme(currentSchemeName());
```

#### LAMBDA EXPRESSION 


```{c}
[] {
        qCDebug(KonsoleDebug) << "Error generating the preview" << _previewJob->errorString();
        QToolTip::hideText();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QTableWidgetItem *item : qAsConst(uniqueList)) {
        // get the first item in the row which has the entry

        KeyboardTranslator::Entry existing = item->data(Qt::UserRole).value<KeyboardTranslator::Entry>();

        _translator->removeEntry(existing);

        _ui->keyBindingTable->removeRow(item->row());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QRect &rect : qAsConst(dirtyImageRegion)) {
        _terminalPainter->drawContents(paint, rect, false);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &spot : spots) {
        urlNumber += urlNumInc;

        QRegion region;
        if (spot->type() == Filter::HotSpot::Link) {
            QRect r;
            if (spot->startLine() == spot->endLine()) {
                r.setCoords(spot->startColumn()*_fontWidth + _contentRect.left(),
                            spot->startLine()*_fontHeight + _contentRect.top(),
                            (spot->endColumn())*_fontWidth + _contentRect.left() - 1,
                            (spot->endLine() + 1)*_fontHeight + _contentRect.top() - 1);
                region |= r;
            } else {
                r.setCoords(spot->startColumn()*_fontWidth + _contentRect.left(),
                            spot->startLine()*_fontHeight + _contentRect.top(),
                            (_columns)*_fontWidth + _contentRect.left() - 1,
                            (spot->startLine() + 1)*_fontHeight + _contentRect.top() - 1);
                region |= r;
                for (int line = spot->startLine() + 1 ; line < spot->endLine() ; line++) {
                    r.setCoords(0 * _fontWidth + _contentRect.left(),
                                line * _fontHeight + _contentRect.top(),
                                (_columns)*_fontWidth + _contentRect.left() - 1,
                                (line + 1)*_fontHeight + _contentRect.top() - 1);
                    region |= r;
                }
                r.setCoords(0 * _fontWidth + _contentRect.left(),
                            spot->endLine()*_fontHeight + _contentRect.top(),
                            (spot->endColumn())*_fontWidth + _contentRect.left() - 1,
                            (spot->endLine() + 1)*_fontHeight + _contentRect.top() - 1);
                region |= r;
            }

            if (_showUrlHint && urlNumber < 10) {
                // Position at the beginning of the URL
                QRect hintRect(*region.begin());
                hintRect.setWidth(r.height());
                painter.fillRect(hintRect, QColor(0, 0, 0, 128));
                painter.setPen(Qt::white);
                painter.drawRect(hintRect.adjusted(0, 0, -1, -1));
                painter.drawText(hintRect, Qt::AlignCenter, QString::number(urlNumber));
            }
        }

        for (int line = spot->startLine() ; line <= spot->endLine() ; line++) {
            int startColumn = 0;
            int endColumn = _columns - 1; // TODO use number of _columns which are actually
            // occupied on this line rather than the width of the
            // display in _columns

            // Check image size so _image[] is valid (see makeImage)
            if (endColumn >= _columns || line >= _lines) {
                break;
            }

            // ignore whitespace at the end of the lines
            while (_image[loc(endColumn, line)].isSpace() && endColumn > 0) {
                endColumn--;
            }

            // increment here because the column which we want to set 'endColumn' to
            // is the first whitespace character at the end of the line
            endColumn++;

            if (line == spot->startLine()) {
                startColumn = spot->startColumn();
            }
            if (line == spot->endLine()) {
                endColumn = spot->endColumn();
            }

            // TODO: resolve this comment with the new margin/center code
            // subtract one pixel from
            // the right and bottom so that
            // we do not overdraw adjacent
            // hotspots
            //
            // subtracting one pixel from all sides also prevents an edge case where
            // moving the mouse outside a link could still leave it underlined
            // because the check below for the position of the cursor
            // finds it on the border of the target area
            QRect r;
            r.setCoords(startColumn * _fontWidth + _contentRect.left(),
                        line * _fontHeight + _contentRect.top(),
                        endColumn * _fontWidth + _contentRect.left() - 1,
                        (line + 1)*_fontHeight + _contentRect.top() - 1);
            // Underline link hotspots
            if (spot->type() == Filter::HotSpot::Link) {
                QFontMetrics metrics(font());

                // find the baseline (which is the invisible line that the characters in the font sit on,
                // with some having tails dangling below)
                const int baseline = r.bottom() - metrics.descent();
                // find the position of the underline below that
                const int underlinePos = baseline + metrics.underlinePos();
                if (_showUrlHint || region.contains(mapFromGlobal(QCursor::pos()))) {
                    painter.drawLine(r.left() , underlinePos ,
                                     r.right() , underlinePos);
                }

                // Marker hotspots simply have a transparent rectangular shape
                // drawn on top of them
            } else if (spot->type() == Filter::HotSpot::Marker) {
                //TODO - Do not use a hardcoded color for this
                const bool isCurrentResultLine = (_screenWindow->currentResultLine() == (spot->startLine() + _screenWindow->currentLine()));
                QColor color = isCurrentResultLine ? QColor(255, 255, 0, 120) : QColor(255, 0, 0, 120);
                painter.fillRect(r, color);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &range: qAsConst(ranges)) {
        if(range.width.isValid() && range.width != widthsSortOrder.last())
            mergedRanges[range.width].append({range.cp.first, range.cp.last});
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Session *session : uniqueSessions) {
        if ((session == nullptr) || !session->isForegroundProcessActive()) {
            continue;
        }

        const QString defaultProc = session->program().split(QLatin1Char('/')).last();
        const QString currentProc = session->foregroundProcessName().split(QLatin1Char('/')).last();

        if (currentProc.isEmpty()) {
            continue;
        }

        if (defaultProc != currentProc) {
            processesRunning.append(currentProc);
        }
    }
```

#### AUTO 


```{c}
auto historyScrollFile = std::unique_ptr<HistoryScrollFile>(new HistoryScrollFile());
```

#### AUTO 


```{c}
auto task = new SearchHistoryTask(this);
```

#### AUTO 


```{c}
const auto& widgetJsonValue
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QPoint &pos) {
        QModelIndex idx = ui->treeView->indexAt(pos);
        if (!idx.isValid()) {
            return;
        }

        if (idx.data(Qt::DisplayRole) == i18n("SSH Config")) {
            return;
        }

        auto sourceIdx = d->filterModel->mapToSource(idx);
        const bool isParent = sourceIdx.parent() == d->model->invisibleRootItem()->index();
        if (!isParent) {
            const auto item = d->model->itemFromIndex(sourceIdx);
            const auto data = item->data(SSHManagerModel::SSHRole).value<SSHConfigurationData>();
            if (data.importedFromSshConfig) {
                return;
            }
        }

        QMenu *menu = new QMenu(this);
        auto action = new QAction(QStringLiteral("Remove"), ui->treeView);
        menu->addAction(action);

        connect(action, &QAction::triggered, this, &SSHManagerTreeWidget::triggerRemove);

        menu->popup(ui->treeView->viewport()->mapToGlobal(pos));
    }
```

#### AUTO 


```{c}
auto r = of.redF(), g = of.greenF(), b = of.blueF();
```

#### CONST EXPRESSION 


```{c}
friend constexpr bool operator!=(const Character &a, const Character &b);
```

#### AUTO 


```{c}
const auto hasSameLineDrawStatus = [&](int column) {
                    return LineBlockCharacters::canDraw(_display->_image[loc(column, y)].character)
                        == lineDraw;
                };
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        if (isProfileNameValid()) {
            save();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &spot : _filterChain->hotSpots()) {
            if (spot->type() == Filter::HotSpot::Link) {
                hotspots.append(spot);
            }
        }
```

#### AUTO 


```{c}
auto compactHistoryScroll = std::unique_ptr<CompactHistoryScroll>(new CompactHistoryScroll(10));
```

#### AUTO 


```{c}
auto historyScrollNone = std::unique_ptr<HistoryScrollNone>(new HistoryScrollNone());
```

#### AUTO 


```{c}
auto sWindow = _window->screenWindow();
```

#### AUTO 


```{c}
auto currentValue = profile->property<int>(options.profileProperty);
```

#### LAMBDA EXPRESSION 


```{c}
[&](int column) {
                    const QChar::Script script = QChar::script(baseCodePoint(image[display->loc(column, y)]));
                    if (currentScript == QChar::Script_Common || script == QChar::Script_Common
                        || currentScript == QChar::Script_Inherited || script == QChar::Script_Inherited) {
                        return true;
                    }
                    return currentScript == script;
                }
```

#### CONST EXPRESSION 


```{c}
friend constexpr bool operator==(const Character &a, const Character &b);
```

#### AUTO 


```{c}
auto* data = _screenLines[screenLine].data();
```

#### AUTO 


```{c}
auto splitterSet = QSet<int>(std::begin(allSplitterSizes), std::end(allSplitterSizes));
```

#### AUTO 


```{c}
auto & i
```

#### AUTO 


```{c}
auto ldrawBackground = [this](QPainter &painter,
            const QRect &rect, const QColor &backgroundColor, bool useOpacitySetting) {
        Q_EMIT drawBackground(painter, rect, backgroundColor, useOpacitySetting);
    };
```

#### AUTO 


```{c}
auto explanation = runShell
        ? QStringLiteral("Output of 'ping localhost' should appear in a terminal below for 5 seconds")
        : QStringLiteral("Output of 'ping localhost' should appear standalone below for 5 seconds");
```

#### RANGE FOR STATEMENT 


```{c}
for(const QButtonGroup *group: qAsConst(_groups)) {
            auto *enumItem = groupToConfigItemEnum(group);
            if(enumItem == nullptr) {
                continue;
            }
            const auto *currentButton = group->checkedButton();
            if(currentButton == nullptr) {
                continue;
            }
            const int value = buttonToEnumValue(currentButton);
            if(value < 0) {
                continue;
            }

            if(!enumItem->isEqual(value)) {
                enumItem->setValue(value);
                updateConfig = true;
            }
        }
```

#### AUTO 


```{c}
auto currentWidget = childAt(ev->pos());
```

#### LAMBDA EXPRESSION 


```{c}
[&](quint8 lineId) -> QPainterPath & {
        Q_ASSERT(getLineType(lineId) != LtNone);
        return getLineType(lineId) == LtHeavy ? heavyPath : lightPath;
    }
```

#### AUTO 


```{c}
auto *dialog = new RenameTabDialog(QApplication::activeWindow());
```

#### AUTO 


```{c}
auto *container = new TabbedViewContainer(this, _viewSplitter);
```

#### AUTO 


```{c}
auto fileSpot = spot.dynamicCast<FileFilter::HotSpot>();
```

#### AUTO 


```{c}
auto factory = new KXMLGUIFactory(clientBuilder(), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &path : paths) {
        Profile::Ptr profile = loadProfile(path);
        if (profile && !defaultProfileFileName.isEmpty() && path.endsWith(defaultProfileFileName)) {
            _defaultProfile = profile;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&](int column) {
                return _image[loc(column, y)].character <= 0x7e
                       || (_image[loc(column, y)].rendition & RE_EXTENDED_CHAR)
                       || (_bidiEnabled && !doubleWidth);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const TerminalDisplay *display : displayList) {
                        usedExtendedChars += display->screenWindow()->screen()->usedExtendedChars();
                    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        const QString tabTitle = dialog->tabTitleText();
        const QString remoteTabTitle = dialog->remoteTabTitleText();
        const QColor tabColor = dialog->color();

        if (tabTitle != sessionLocalTabTitleFormat) {
            session()->setTabTitleFormat(Session::LocalTabTitle, tabTitle);
            Q_EMIT tabRenamedByUser(true);
            // trigger an update of the tab text
            snapshot();
        }

        if (remoteTabTitle != sessionRemoteTabTitleFormat) {
            session()->setTabTitleFormat(Session::RemoteTabTitle, remoteTabTitle);
            Q_EMIT tabRenamedByUser(true);
            snapshot();
        }

        if (tabColor != sessionTabColor) {
            session()->setColor(tabColor);
            Q_EMIT tabColoredByUser(true);
            snapshot();
        }
    }
```

#### AUTO 


```{c}
auto *dlg = new QInputDialog(static_cast<QWidget *>(this));
```

#### RANGE FOR STATEMENT 


```{c}
for(const QButtonGroup *group: qAsConst(_groups)) {
        auto *enumItem = groupToConfigItemEnum(group);
        if(enumItem == nullptr) {
            continue;
        }

        int value = enumItem->value();
        const QString &valueName = enumItem->choices().at(value).name;
        QAbstractButton *currentButton = nullptr;
        for(auto &button: group->buttons()) {
            if(button->objectName() == valueName) {
                currentButton = button;
                break;
            }
        }
        if(currentButton == nullptr) {
            return;
        }
        currentButton->setChecked(true);
        changed = true;
    }
```

#### AUTO 


```{c}
auto match = std::find_if(_currentDirContents.cbegin(), _currentDirContents.cend(), [filename](const QString &s) {
            // early out if first char doesn't match
            if (!s.isEmpty() && filename.at(0) != s.at(0)) {
                return false;
            }

            const bool startsWith = filename.startsWith(s);
            if (startsWith) {
                // are we equal ?
                if (filename.size() == s.size()) {
                    return true;
                }
                int onePast = s.size();
                if (onePast < filename.size()) {
                    if (filename.at(onePast) == QLatin1Char(':') || filename.at(onePast) == QLatin1Char('/')) {
                        return true;
                    }
                }
            }
            return false;
        });
```

#### RANGE FOR STATEMENT 


```{c}
for (const TerminalDisplay *display : displayList) {
                            usedExtendedChars += display->screenWindow()->screen()->usedExtendedChars();
                        }
```

#### AUTO 


```{c}
auto startCopy = _cells.begin() + startOfLine(lineNumber) + startColumn;
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        toggleActionsBasedOnState();
    }
```

#### AUTO 


```{c}
auto parentSplitter = qobject_cast<ViewSplitter *>(parentWidget());
```

#### AUTO 


```{c}
auto validator = new QRegularExpressionValidator(regExp, this);
```

#### LAMBDA EXPRESSION 


```{c}
[] (reflowData &change, qint64 index, LineProperty lineflag) {
        change.index = index;
        change.lineFlag = lineflag;
    }
```

#### AUTO 


```{c}
auto newProfile = Profile::Ptr(new Profile(ProfileManager::instance()->builtinProfile()));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &translatorName : translatorNames) {
        const KeyboardTranslator *translator = _keyManager->findTranslator(translatorName);
        if (translator == nullptr) {
            continue;
        }

        QStandardItem *item = new QStandardItem(translator->description());
        item->setEditable(false);
        item->setData(QVariant::fromValue(translator), Qt::UserRole + 1);
        item->setData(QVariant::fromValue(_keyManager->findTranslatorPath(translatorName)), Qt::ToolTipRole);
        item->setData(QVariant::fromValue(_profile->font()), Qt::UserRole + 2);
        item->setIcon(QIcon::fromTheme(QStringLiteral("preferences-desktop-keyboard")));

        if (selectKeyBindingsName == translatorName) {
            selectedItem = item;
        }

        model->appendRow(item);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto terminal : terminals) {
            terminal->headerBar()->setVisible(true);
        }
```

#### AUTO 


```{c}
auto* editor = qobject_cast<FilteredKeySequenceEdit*>(sender());
```

#### AUTO 


```{c}
const auto pageamounts = QVector<RadioOption>{
        {_ui->scrollHalfPage, Enum::ScrollPageHalf, SLOT(scrollHalfPage())},
        {_ui->scrollFullPage, Enum::ScrollPageFull, SLOT(scrollFullPage())}
    };
```

#### AUTO 


```{c}
const auto *leftWidget = cornerWidget(Qt::TopLeftCorner);
```

#### AUTO 


```{c}
const auto isSameScript = [&](int column) {
                    const QChar::Script script = QChar::script(baseCodePoint(_display->_image[loc(column, y)]));
                    if (currentScript == QChar::Script_Common || script == QChar::Script_Common
                        || currentScript == QChar::Script_Inherited || script == QChar::Script_Inherited) {
                        return true;
                    }
                    return currentScript == script;
                };
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &option : options) {
        parser->addOption(option);
    }
```

#### AUTO 


```{c}
auto &&size
```

#### AUTO 


```{c}
auto demo = new demo_konsolepart();
```

#### AUTO 


```{c}
auto widget = static_cast<QWidget*>(view);
```

#### AUTO 


```{c}
const auto* portValidator = new QIntValidator(0, 49151);
```

#### AUTO 


```{c}
auto terminalDisplay = activeTerminalDisplay();
```

#### LAMBDA EXPRESSION 


```{c}
[this, profile]() {
        auto *dlg = new QInputDialog(static_cast<QWidget *>(this));
        dlg->setLabelText(i18n("The format is e.g. 'eidtorExec PATH:LINE:COLUMN'\n\n"
                               "PATH    will be replaced by the path to the text file\n"
                               "LINE    will be replaced by the line number\n"
                               "COLUMN  (optional) will be replaced by the column number\n"
                               "Note: you will need to replace 'PATH:LINE:COLUMN' by the actual\n"
                               "syntax the editor you want to use supports; e.g.:\n"
                               "gedit +LINE:COLUMN PATH\n\n"
                               "If PATH or LINE aren't present in the command, this setting\n"
                               "will be ignored and the file will be opened by the default text\n"
                               "editor."));
        const QString cmd = profile->customTextEditorCmd();
        dlg->setTextValue(cmd);
        dlg->setAttribute(Qt::WA_DeleteOnClose);
        dlg->setWindowTitle(i18n("Text Editor Custom Command"));

        QFontMetrics fm(font());
        const int width = qMin(fm.averageCharWidth() * cmd.size(), this->width());
        dlg->resize(width, dlg->height());

        connect(dlg, &QDialog::accepted, this, [this, dlg]() {
            updateTempProfileProperty(Profile::TextEditorCmdCustom, dlg->textValue());
        });

        dlg->show();
    }
```

#### AUTO 


```{c}
auto &entry
```

#### LAMBDA EXPRESSION 


```{c}
[this, dialog]() {
        scrollBackOptionsChanged(dialog->mode(), dialog->lineCount());
    }
```

#### AUTO 


```{c}
auto editAction =
        _contextPopupMenu->addAction(QIcon::fromTheme(QStringLiteral("edit-rename")), i18nc("@action:inmenu", "&Configure or Rename Tab..."), this, [this] {
            renameTab(_contextMenuTabIndex);
        });
```

#### AUTO 


```{c}
auto *qcWidget = new QuickCommandsWidget(mainWindow);
```

#### AUTO 


```{c}
auto factory = new KXMLGUIFactory(clientBuilder(), _view);
```

#### AUTO 


```{c}
auto titleOption = QCommandLineOption(QStringList() << QStringLiteral("T"),
                                          QStringLiteral("Debian policy compatibility, not used"),
                                          QStringLiteral("value"));
```

#### LAMBDA EXPRESSION 


```{c}
[](CharacterProperties &prop, const EmojiDataEntry &entry) { prop.emoji |= entry.emoji(); }
```

#### AUTO 


```{c}
const auto data = eChild->data(SSHManagerModel::Roles::SSHRole).value<SSHConfigurationData>();
```

#### LAMBDA EXPRESSION 


```{c}
[&](KJob *) {
            if(_job->isErrorPage())
                _eventLoop.exit(KIO::ERR_DOES_NOT_EXIST);
            else if(_job->error() != KJob::NoError)
                _eventLoop.exit(_job->error());
            else
                _data = _job->data();

            _eventLoop.exit(KJob::NoError);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QMimeType &mimeType : allMimeTypes) {
            patterns.append(mimeType.globPatterns());
        }
```

#### AUTO 


```{c}
const auto widgets = window->findChildren<TabbedViewContainer*>();
```

#### LAMBDA EXPRESSION 


```{c}
[this, dropText]{ sendStringToEmu(dropText.toLocal8Bit());}
```

#### AUTO 


```{c}
auto &spot
```

#### LAMBDA EXPRESSION 


```{c}
[this]{ delete clientBuilder(); }
```

#### LAMBDA EXPRESSION 


```{c}
[&name, suffix](const Profile::Ptr &p) {
            return p->name() == name //
                || (p->name() + suffix) == name; // For backwards compatibility
        }
```

#### AUTO 


```{c}
const auto& bm_url = groupUrlList.at(i);
```

#### AUTO 


```{c}
auto tabTterminalDisplays = toplevelSplitter->findChildren<TerminalDisplay *>();
```

#### AUTO 


```{c}
auto nextSplitter = restoreSessionsSplitterRecurse(widgetJsonObject, manager);
```

#### AUTO 


```{c}
const auto profiles = selectedProfiles();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &entry : qAsConst(changedEntries)) {
        switch (entry.status()) {
        case KNS3::Entry::Installed:
            for (const auto &file : entry.installedFiles()) {
                if (ColorSchemeManager::instance()->loadColorScheme(file)) {
                    continue;
                }
                qWarning() << "Failed to load file" << file;
                ++failures;
            }
            if (failures == entry.installedFiles().size()) {
                _appearanceUi->colorSchemeMessageWidget->setText(xi18nc("@info", "Scheme <resource>%1</resource> failed to load.", entry.name()));
                _appearanceUi->colorSchemeMessageWidget->animatedShow();
                QTimer::singleShot(8000, _appearanceUi->colorSchemeMessageWidget, &KMessageWidget::animatedHide);
            }
            break;
        case KNS3::Entry::Deleted:
            for (const auto &file : entry.uninstalledFiles()) {
                if (ColorSchemeManager::instance()->unloadColorScheme(file)) {
                    continue;
                }
                qWarning() << "Failed to unload file" << file;
                // If unloading fails we do not care. If the scheme failed here
                // it either wasn't loaded or was invalid to begin with.
            }
            break;
        case KNS3::Entry::Invalid:
        case KNS3::Entry::Installing:
        case KNS3::Entry::Downloadable:
        case KNS3::Entry::Updateable:
        case KNS3::Entry::Updating:
            // Not interesting.
            break;
        }
    }
```

#### AUTO 


```{c}
auto next_pos = mapToParent(p);
```

#### AUTO 


```{c}
auto iter_geq = std::lower_bound(sorted_array.begin(), sorted_array.end(), x);
```

#### AUTO 


```{c}
auto it = findProfile(profile);
```

#### AUTO 


```{c}
auto swappedWidget = viewSplitterAt(newIndex);
```

#### AUTO 


```{c}
auto *listHeader = profilesList->header();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &spot : spots) {
        QRegion region;
        if (spot->type() == Filter::HotSpot::Link || spot->type() == Filter::HotSpot::EMailAddress) {
            QRect r;
            if (spot->startLine() == spot->endLine()) {
                r.setCoords(spot->startColumn()*_fontWidth + _contentRect.left(),
                            spot->startLine()*_fontHeight + _contentRect.top(),
                            (spot->endColumn())*_fontWidth + _contentRect.left() - 1,
                            (spot->endLine() + 1)*_fontHeight + _contentRect.top() - 1);
                region |= r;
            } else {
                r.setCoords(spot->startColumn()*_fontWidth + _contentRect.left(),
                            spot->startLine()*_fontHeight + _contentRect.top(),
                            (_columns)*_fontWidth + _contentRect.left() - 1,
                            (spot->startLine() + 1)*_fontHeight + _contentRect.top() - 1);
                region |= r;
                for (int line = spot->startLine() + 1 ; line < spot->endLine() ; line++) {
                    r.setCoords(0 * _fontWidth + _contentRect.left(),
                                line * _fontHeight + _contentRect.top(),
                                (_columns)*_fontWidth + _contentRect.left() - 1,
                                (line + 1)*_fontHeight + _contentRect.top() - 1);
                    region |= r;
                }
                r.setCoords(0 * _fontWidth + _contentRect.left(),
                            spot->endLine()*_fontHeight + _contentRect.top(),
                            (spot->endColumn())*_fontWidth + _contentRect.left() - 1,
                            (spot->endLine() + 1)*_fontHeight + _contentRect.top() - 1);
                region |= r;
            }

            if (_showUrlHint && urlNumber >= 0 && urlNumber < 10 && spot->type() == Filter::HotSpot::Link) {
                // Position at the beginning of the URL
                QRect hintRect(*region.begin());
                hintRect.setWidth(r.height());
                painter.fillRect(hintRect, QColor(0, 0, 0, 128));
                painter.setPen(Qt::white);
                painter.drawRect(hintRect.adjusted(0, 0, -1, -1));
                painter.drawText(hintRect, Qt::AlignCenter, QString::number(urlNumber));

                urlNumber += urlNumInc;
            }
        }

        for (int line = spot->startLine() ; line <= spot->endLine() ; line++) {
            int startColumn = 0;
            int endColumn = _columns - 1; // TODO use number of _columns which are actually
            // occupied on this line rather than the width of the
            // display in _columns

            // Check image size so _image[] is valid (see makeImage)
            if (endColumn >= _columns || line >= _lines) {
                break;
            }

            // ignore whitespace at the end of the lines
            while (_image[loc(endColumn, line)].isSpace() && endColumn > 0) {
                endColumn--;
            }

            // increment here because the column which we want to set 'endColumn' to
            // is the first whitespace character at the end of the line
            endColumn++;

            if (line == spot->startLine()) {
                startColumn = spot->startColumn();
            }
            if (line == spot->endLine()) {
                endColumn = spot->endColumn();
            }

            // TODO: resolve this comment with the new margin/center code
            // subtract one pixel from
            // the right and bottom so that
            // we do not overdraw adjacent
            // hotspots
            //
            // subtracting one pixel from all sides also prevents an edge case where
            // moving the mouse outside a link could still leave it underlined
            // because the check below for the position of the cursor
            // finds it on the border of the target area
            QRect r;
            r.setCoords(startColumn * _fontWidth + _contentRect.left(),
                        line * _fontHeight + _contentRect.top(),
                        endColumn * _fontWidth + _contentRect.left() - 1,
                        (line + 1)*_fontHeight + _contentRect.top() - 1);
            // Underline link hotspots
            const bool hasMouse = region.contains(mapFromGlobal(QCursor::pos()));
            if ((spot->type() == Filter::HotSpot::Link && _showUrlHint) || hasMouse) {
                QFontMetrics metrics(font());

                // find the baseline (which is the invisible line that the characters in the font sit on,
                // with some having tails dangling below)
                const int baseline = r.bottom() - metrics.descent();
                // find the position of the underline below that
                const int underlinePos = baseline + metrics.underlinePos();
                painter.drawLine(r.left() , underlinePos, r.right() , underlinePos);

                // Marker hotspots simply have a transparent rectangular shape
                // drawn on top of them
            } else if (spot->type() == Filter::HotSpot::Marker) {
                //TODO - Do not use a hardcoded color for this
                const bool isCurrentResultLine = (_screenWindow->currentResultLine() == (spot->startLine() + _screenWindow->currentLine()));
                QColor color = isCurrentResultLine ? QColor(255, 255, 0, 120) : QColor(255, 0, 0, 120);
                painter.fillRect(r, color);
            }
        }
    }
```

#### AUTO 


```{c}
const auto message = xi18nc("@info:tooltip", "When using this option, the scrollback data will be written unencrypted to temporary files. Those temporary files will be deleted automatically when Konsole is closed in a normal manner.<nl/>Use <emphasis>Settings ? Configure Konsole ? File Location</emphasis> to select the location of the temporary files.");
```

#### LAMBDA EXPRESSION 


```{c}
[this]{
        m_terminalActivity->setPixmap(QPixmap());
    }
```

#### AUTO 


```{c}
auto other_pid = event->mimeData()->data(dragId).toInt();
```

#### LAMBDA EXPRESSION 


```{c}
[this]{
        if (!_previewJob) {
            return;
        }
        if (!_thumbnailFinished) {
            QToolTip::showText(_thumbnailPos, i18n("Generating Thumbnail"), qApp->focusWidget());
        }
    }
```

#### AUTO 


```{c}
auto viewSplitter = qobject_cast<ViewSplitter*>(currentWidget());
```

#### AUTO 


```{c}
const auto pid = processId();
```

#### AUTO 


```{c}
auto focusWatcher = new CompositeWidgetFocusWatcher(this, this);
```

#### AUTO 


```{c}
const auto mergedRanges = mergedRangesFromWidths(widths, widthsSortOrder);
```

#### LAMBDA EXPRESSION 


```{c}
[](QAction *a, QAction *b) {
        // Remove '&', which is added by KAcceleratorManager
        const QString aName = a->text().remove(QLatin1Char('&'));
        const QString bName = b->text().remove(QLatin1Char('&'));

        if (aName == QLatin1String("Default")) {
            return true;
        } else if (bName == QLatin1String("Default")) {
            return false;
        }

        return QString::localeAwareCompare(aName, bName) < 0;
    }
```

#### AUTO 


```{c}
auto setNewLine = [](std::vector<LineData> &change, unsigned int index, LineProperty flag) {
        change.push_back({index, flag});
    };
```

#### AUTO 


```{c}
auto *generalPageItem = addPage(generalPageWidget, generalPageName);
```

#### AUTO 


```{c}
auto *thisSplitter = qobject_cast<ViewSplitter*>(splitter());
```

#### AUTO 


```{c}
const auto allButtonGroups = parentObj->findChildren<QButtonGroup *>();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &&i : unicodeText) {
        receiveChar(i.unicode());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, container]() {
               containerViewsChanged(container);
           }
```

#### RANGE FOR STATEMENT 


```{c}
for (Session *session : qAsConst(_sessions)) {
        if (_sessionProfiles[session] == profile) {
            applyProfile(session, profile, modifiedPropertiesOnly);
        }
    }
```

#### AUTO 


```{c}
auto *mainWindow = qobject_cast<MainWindow *>(mainWindowWidget);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *action : _contextPopupMenu->actions()) {
            if (action->objectName() == QStringLiteral("edit-rename")) {
                action->setEnabled(!sessionController->isReadOnly());
                break;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &url) {
            if (url == QLatin1String("#close")) {
                _outputSuspendedLabel->setVisible(false);
            } else {
                QDesktopServices::openUrl(QUrl(url));
            }
        }
```

#### AUTO 


```{c}
auto wi = rangesStats.constBegin();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            _iPntSel = QPoint();
            _pntSel = QPoint();
            _tripleSelBegin = QPoint();
        }
```

#### AUTO 


```{c}
auto *terminaldisplay
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &i : profilelist) {
            if (i->name() == profile) {
                profileptr = i;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& jsonSplitter : jsonTabs) {
        auto topLevelSplitter = restoreSessionsSplitterRecurse(jsonSplitter.toObject(), this);
        _viewContainer->addSplitter(topLevelSplitter, _viewContainer->count());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QPainter &paint, const QRect &rect, bool friendly) {
        emit drawContents(_image, paint, rect, friendly, _imageSize, _bidiEnabled, _fixedFont, _lineProperties);
    }
```

#### IF STATEMENT WITH INITIALIZER 


```{c}
if (auto it = findProfile(profile); it != _profiles.end()) {
            _profiles.erase(it);
        }
```

#### AUTO 


```{c}
auto proxyStyle = qobject_cast<const QProxyStyle *>(style());
```

#### AUTO 


```{c}
auto layout = new QVBoxLayout(_containerWidget);
```

#### LAMBDA EXPRESSION 


```{c}
[boldWeight](const QFont &font) { return font.weight() >= boldWeight; }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QMimeType &mimeType : allMimeTypes) {
        patterns.append(mimeType.globPatterns());
    }
```

#### AUTO 


```{c}
const auto y = headerHeight;
```

#### AUTO 


```{c}
auto terminal = activeSplitter->activeTerminalDisplay();
```

#### AUTO 


```{c}
auto currentProfile = SessionManager::instance()->sessionProfile(_currentTerminalDisplay->session());
```

#### AUTO 


```{c}
const auto options = QVector<QCommandLineOption>{
        {{QStringLiteral("profile")}, i18nc("@info:shell", "Name of profile to use for new Konsole instance"), QStringLiteral("name")},
        {{QStringLiteral("layout")}, i18nc("@info:shell", "json layoutfile to be loaded to use for new Konsole instance"), QStringLiteral("file")},
        {{QStringLiteral("builtin-profile")}, i18nc("@info:shell", "Use the built-in profile instead of the default profile")},
        {{QStringLiteral("workdir")}, i18nc("@info:shell", "Set the initial working directory of the new tab or window to 'dir'"), QStringLiteral("dir")},
        {{QStringLiteral("hold"), QStringLiteral("noclose")}, i18nc("@info:shell", "Do not close the initial session automatically when it ends.")},
        // BR: 373440
        {{QStringLiteral("new-tab")}, i18nc("@info:shell", "Create a new tab in an existing window rather than creating a new window ('Run all Konsole windows in a single process' must be enabled)")},
        {{QStringLiteral("tabs-from-file")}, i18nc("@info:shell", "Create tabs as specified in given tabs configuration file"), QStringLiteral("file")},
        {{QStringLiteral("background-mode")},
         i18nc("@info:shell", "Start Konsole in the background and bring to the front when Ctrl+Shift+F12 (by default) is pressed")},
        {{QStringLiteral("separate"), QStringLiteral("nofork")}, i18nc("@info:shell", "Run in a separate process")},
        {{QStringLiteral("show-menubar")}, i18nc("@info:shell", "Show the menubar, overriding the default setting")},
        {{QStringLiteral("hide-menubar")}, i18nc("@info:shell", "Hide the menubar, overriding the default setting")},
        {{QStringLiteral("show-tabbar")}, i18nc("@info:shell", "Show the tabbar, overriding the default setting")},
        {{QStringLiteral("hide-tabbar")}, i18nc("@info:shell", "Hide the tabbar, overriding the default setting")},
        {{QStringLiteral("fullscreen")}, i18nc("@info:shell", "Start Konsole in fullscreen mode")},
        {{QStringLiteral("notransparency")}, i18nc("@info:shell", "Disable transparent backgrounds, even if the system supports them.")},
        {{QStringLiteral("list-profiles")}, i18nc("@info:shell", "List the available profiles")},
        {{QStringLiteral("list-profile-properties")}, i18nc("@info:shell", "List all the profile properties names and their type (for use with -p)")},
        {{QStringLiteral("p")}, i18nc("@info:shell", "Change the value of a profile property."), QStringLiteral("property=value")},
        {{QStringLiteral("e")},
         i18nc("@info:shell", "Command to execute. This option will catch all following arguments, so use it as the last option."),
         QStringLiteral("cmd")},
        {{QStringLiteral("force-reuse")}, i18nc("@info:shell", "Force re-using the existing instance even if it breaks functionality, e. g. --new-tab. Mostly for debugging.")},
    };
```

#### AUTO 


```{c}
const auto mode = profile->property<int>(Profile::HistoryMode);
```

#### AUTO 


```{c}
auto targetSplitter = qobject_cast<QSplitter *>(child->parent());
```

#### RANGE FOR STATEMENT 


```{c}
for (const Profile::Ptr &profile : profiles) {
    if (profile->name() == profileName) {
      SessionManager::instance()->setSessionProfile(this, profile);
    }
  }
```

#### AUTO 


```{c}
const auto *translator = model->data(selected.first(), Qt::UserRole + 1)
                                               .value<const KeyboardTranslator *>();
```

#### LAMBDA EXPRESSION 


```{c}
[](const QChar &c) {
        if (c.unicode() <= 0x1F) {
            return QStringLiteral("^%1").arg(QChar(u'@' + c.unicode()));
        } else if (c.unicode() == 0x7F) {
            return QStringLiteral("^?");
        } else if (c.unicode() >= 0x80 && c.unicode() <= 0x9F){
            return QStringLiteral("^[%1").arg(QChar(u'@' + c.unicode() - 0x80));
        }
        return QString();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &metaData : pluginMetaData) {
        const KPluginFactory::Result result = KPluginFactory::instantiatePlugin<IKonsolePlugin>(metaData);
        if (!result) {
            continue;
        }

        d->plugins.push_back(result.plugin);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&filename](const QString &s) {
            return filename == s // It's a direct child file or dir
                || filename.startsWith(s + QLatin1Char{':'}) // filename:lineNumber (output of grep -n)
                || filename.startsWith(s + QLatin1Char{'/'}); // It's inside a child dir
        }
```

#### AUTO 


```{c}
auto closeAction = _contextPopupMenu->addAction(
        QIcon::fromTheme(QStringLiteral("tab-close")),
        i18nc("@action:inmenu", "Close Tab"), this,
        [this] { closeTerminalTab(_contextMenuTabIndex); }
    );
```

#### AUTO 


```{c}
auto *favoriteColumnHeaderItem = new QStandardItem();
```

#### AUTO 


```{c}
auto match = std::find_if(_currentDirContents.cbegin(), _currentDirContents.cend(),
                                  [&filename](const QString &s) {
                                      return filename == s || // It's a direct child file or dir
                                             filename.startsWith(s + QLatin1Char{'/'}); // It's inside a child dir
                                });
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto & i : list) {
        // dis-regard the fallback profile
        if (i->path() == _fallbackProfile->path())
            continue;

        if (i->menuIndexAsInt() == 0)
            lackingIndices.append(i);
        else
            havingIndices.append(i);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&packedLineTypes](quint8 lineId) -> void {
        lineId = LinesNum - 1 - lineId % LinesNum;
        packedLineTypes &= ~(3 << (2 * lineId));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](CharacterProperties &prop, const EastAsianWidthEntry &entry) { prop.eastAsianWidth = entry.eastAsianWidth(); }
```

#### AUTO 


```{c}
auto colorItemIntense = new QTableWidgetItem();
```

#### RANGE FOR STATEMENT 


```{c}
for(auto &button: group->buttons()) {
            if(button->objectName() == valueName) {
                currentButton = button;
                break;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&](int column) {
                    return image[display->loc(column, y)].character <= 0x7e
                            || (image[display->loc(column, y)].rendition & RE_EXTENDED_CHAR)
                            || (bidiEnabled && !doubleWidth);
                }
```

#### AUTO 


```{c}
auto detachAction = _contextPopupMenu->addAction(
        QIcon::fromTheme(QStringLiteral("tab-detach")),
        i18nc("@action:inmenu", "&Detach Tab"), this,
        [this] { Q_EMIT detachTab(_contextMenuTabIndex); }
    );
```

#### AUTO 


```{c}
const auto hasSameRendition = [&](int column) {
                return (_image[loc(column, y)].rendition & ~RE_EXTENDED_CHAR)
                    == (currentRendition & ~RE_EXTENDED_CHAR);
            };
```

#### AUTO 


```{c}
auto linkHandler = [this](const QString &url) {
            if (url == QLatin1String("#close")) {
                _outputSuspendedMessageWidget->hide();
            } else {
                QDesktopServices::openUrl(QUrl(url));
            }
        };
```

#### AUTO 


```{c}
auto *favoriteItem = _sessionModel->item(i, FavoriteStatusColumn);
```

#### LAMBDA EXPRESSION 


```{c}
[this](){
            this->loadLayout(QStandardPaths::locate(QStandardPaths::GenericDataLocation, QStringLiteral("konsole/2x1-terminals.json"))); }
```

#### AUTO 


```{c}
auto *sm = Konsole::SessionManager::instance();
```

#### AUTO 


```{c}
auto extChars = [this]() {
                    return usedExtendedChars();
                };
```

#### RANGE FOR STATEMENT 


```{c}
for (auto item : items) {
        res.append(std::visit(ItemToString{}, item));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Session *session : sessions) {
        connect(session, &Konsole::Session::finished, this,
                &Konsole::SessionListModel::sessionFinished);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : fileNames) {
            profiles.append(dir + QLatin1Char('/') + file);
        }
```

#### AUTO 


```{c}
auto *newBuffer = dynamic_cast<CompactHistoryScroll *>(old);
```

#### AUTO 


```{c}
const auto* hostnameValidator = new QRegularExpressionValidator(hostnameRegex);
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
            startImportFromSshConfig();
        }
```

#### AUTO 


```{c}
const auto sessionIterator = widgetJsonObject.constFind(QStringLiteral("SessionRestoreId"));
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QPoint &pos) {
        QModelIndex idx = ui->commandsTreeView->indexAt(pos);
        if (!idx.isValid())
            return;
        auto sourceIdx = priv->filterModel->mapToSource(idx);
        const bool isParent = sourceIdx.parent() == priv->model->invisibleRootItem()->index();
        QMenu *menu = new QMenu(this);

        if (!isParent) {
            auto actionEdit = new QAction(QStringLiteral("Edit"), ui->commandsTreeView);
            menu->addAction(actionEdit);
            connect(actionEdit, &QAction::triggered, this, &QuickCommandsWidget::triggerEdit);
        } else {
            auto actionRename = new QAction(QStringLiteral("Rename"), ui->commandsTreeView);
            menu->addAction(actionRename);
            connect(actionRename, &QAction::triggered, this, &QuickCommandsWidget::triggerRename);
        }
        auto actionDelete = new QAction(QStringLiteral("Delete"), ui->commandsTreeView);
        menu->addAction(actionDelete);
        connect(actionDelete, &QAction::triggered, this, &QuickCommandsWidget::triggerDelete);
        menu->popup(ui->commandsTreeView->viewport()->mapToGlobal(pos));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto terminal : viewSplitterAt(idx)->findChildren<TerminalDisplay*>()) {
        terminal->sessionController()->closeSession();
    }
```

#### AUTO 


```{c}
auto sequence = QKeySequence::fromString(value.toString());
```

#### LAMBDA EXPRESSION 


```{c}
[&](int column) {
                    const int characterLoc = qMin(_display->loc(column, y) + 1, _display->_imageSize - 1);
                    return (_display->_image[characterLoc].character == 0) == doubleWidth;
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &option : optionNames) {
        for (const QString &value : parser->values(option)) {
            m_commandLineArguments.insert(option, value);
        }
    }
```

#### AUTO 


```{c}
auto line = _lines.at(position).get();
```

#### AUTO 


```{c}
const auto regExp = QRegularExpression(QStringLiteral(R"(([a-z]*:\/\/;)*([A-Za-z*]:\/\/))"));
```

#### RANGE FOR STATEMENT 


```{c}
for(const QButtonGroup *group: qAsConst(_groups)) {
            int value = buttonToEnumValue(group->checkedButton());
            const auto enumItem = groupToConfigItemEnum(group);

            if(!enumItem->isEqual(value)) {
                return true;
            }
        }
```

#### AUTO 


```{c}
auto view = _viewSplitter->activeContainer()->widget(i);
```

#### AUTO 


```{c}
auto splitter = qobject_cast<ViewSplitter *>(terminalDisplay->parentWidget());
```

#### AUTO 


```{c}
const auto &child
```

#### AUTO 


```{c}
const auto getLineType = [&packedLineTypes](quint8 lineId)->LineType {
        lineId = LinesNum - 1 - lineId % LinesNum;
        return LineType(packedLineTypes >> 2 * lineId & 3);
    };
```

#### AUTO 


```{c}
auto *sshDockWidget = new QDockWidget(mainWindow);
```

#### AUTO 


```{c}
auto source = qobject_cast<TerminalDisplay*>(ev->source());
```

#### LAMBDA EXPRESSION 


```{c}
[]() {
            QGuiApplication::inputMethod()->update(Qt::ImCursorRectangle);
        }
```

#### AUTO 


```{c}
auto swappedContext = swappedWidget->sessionController();
```

#### LAMBDA EXPRESSION 


```{c}
[this](QPainter &painter,
            const QRect &rect, const QColor &backgroundColor, bool useOpacitySetting) {
        emit drawBackground(painter, rect, backgroundColor, useOpacitySetting);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto & i : profilelist) {
        if (i->name() == profile) {
            profileptr = i;
            break;
        }
    }
```

#### AUTO 


```{c}
auto *session = SessionManager::instance()->idToSession(sessionId);
```

#### LAMBDA EXPRESSION 


```{c}
[this] { emit detachTab(this, widget(_contextMenuTabIndex)); }
```

#### AUTO 


```{c}
auto lfontset = [this](const QFont &f) { _terminalFont->setVTFont(f); };
```

#### AUTO 


```{c}
const auto initialDir = profile->startInCurrentSessionDir() ? directory : QString();
```

#### LAMBDA EXPRESSION 


```{c}
[&](const char *key, double value) {
        const bool valueIsNull = qFuzzyCompare(value, 0.0);
        const bool keyExists = configGroup.hasKey(key);
        const bool keyExistsAndHasDifferentValue = !qFuzzyCompare(configGroup.readEntry(key, value), value);
        if ((!valueIsNull && !keyExists) || keyExistsAndHasDifferentValue) {
            configGroup.writeEntry(key, value);
        }
    }
```

#### AUTO 


```{c}
auto ldrawBackground = [this](QPainter &painter,
            const QRect &rect, const QColor &backgroundColor, bool useOpacitySetting) {
        _terminalPainter->drawBackground(painter, rect, backgroundColor, useOpacitySetting);
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        requestMoveToNewTab(this);
    }
```

#### AUTO 


```{c}
auto *appearancePageWidget = new QWidget(this);
```

#### LAMBDA EXPRESSION 


```{c}
[&] {
        tooltipRequested();
    }
```

#### AUTO 


```{c}
auto *controller = qobject_cast<SessionController *>(ViewProperties::propertiesById(id));
```

#### AUTO 


```{c}
const auto c
```

#### AUTO 


```{c}
auto fileLocationSettings = new FileLocationSettings(settingsDialog);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto *buttonGroup : allButtonGroups) {
        if (buttonGroup->objectName().startsWith(ManagedNamePrefix)) {
            add(buttonGroup);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto **statusIcon : statusIcons) {
        *statusIcon = new QLabel(this);
        (*statusIcon)->setAlignment(Qt::AlignCenter);
        (*statusIcon)->setFixedSize(20, 20);
        (*statusIcon)->setVisible(false);

        m_boxLayout->addWidget(*statusIcon);
    }
```

#### AUTO 


```{c}
auto [charLine, charColumn] = getCharacterPosition(ev->pos(), !usesMouseTracking());
```

#### AUTO 


```{c}
auto *activeview = qobject_cast<TerminalDisplay *>(container->currentWidget());
```

#### AUTO 


```{c}
auto currWidget = widget(idx);
```

#### AUTO 


```{c}
const auto sizes = parent_splitter->sizes();
```

#### AUTO 


```{c}
auto* terminalPart = factory->create<KParts::ReadOnlyPart>(this);
```

#### AUTO 


```{c}
const auto widgetJsonObject = widgetJsonValue.toObject();
```

#### AUTO 


```{c}
auto widget = static_cast<ViewSplitter*>(view);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto widgetJsonValue : splitterWidgets) {
        const auto widgetJsonObject = widgetJsonValue.toObject();
        const auto sessionIterator = widgetJsonObject.constFind(QStringLiteral("SessionRestoreId"));

        if (sessionIterator != widgetJsonObject.constEnd()) {
            Session *session = useSessionId
                ? SessionManager::instance()->idToSession(sessionIterator->toInt())
                : SessionManager::instance()->createSession();

            auto newView = manager->createView(session);
            currentSplitter->addWidget(newView);
        } else {
            auto nextSplitter = restoreSessionsSplitterRecurse(widgetJsonObject, manager, useSessionId);
            currentSplitter->addWidget(nextSplitter);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        closeTerminalTab(_contextMenuTabIndex);
    }
```

#### AUTO 


```{c}
auto *action = new QAction(array[i].description.toString(), this);
```

#### AUTO 


```{c}
const auto width = geometry().width();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Profile::Ptr &existingProfile : profiles) {
            existingProfileNames.append(existingProfile->name());
        }
```

#### AUTO 


```{c}
auto app = new QApplication(argc, argv);
```

#### LAMBDA EXPRESSION 


```{c}
[&](const char *key, double min, double max) -> double {
        const double value = configGroup.readEntry(key, min);
        if (min > value || value > max) {
            qCDebug(KonsoleDebug) << QStringLiteral(
                    "Color scheme \"%1\": color index 2 has an invalid value: %3 = %4. "
                    "Allowed value range: %5 - %6. Using %7.")
                    .arg(name()).arg(index).arg(QLatin1String(key)).arg(value, 0, 'g', 1)
                    .arg(min, 0, 'g', 1).arg(max, 0, 'g', 1).arg(min, 0, 'g', 1);
            return min;
        }
        return value;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &colorScheme : nativeColorSchemes) {
        if (loadColorScheme(colorScheme)) {
            success++;
        } else {
            failed++;
        }
    }
```

#### AUTO 


```{c}
auto profile = profileName.isEmpty() ?
                ProfileManager::instance()->defaultProfile() :
                ProfileManager::instance()->loadProfile(profileName);
```

#### AUTO 


```{c}
const auto y = parentSize.height();
```

#### AUTO 


```{c}
const auto checkAndMaybeSaveValue = [&](const char *key, double value) {
        const bool valueIsNull = qFuzzyCompare(value, 0.0);
        const bool keyExists = configGroup.hasKey(key);
        const bool keyExistsAndHasDifferentValue = !qFuzzyCompare(configGroup.readEntry(key, value), value);
        if ((!valueIsNull && !keyExists) || keyExistsAndHasDifferentValue) {
            configGroup.writeEntry(key, value);
        }
    };
```

#### AUTO 


```{c}
auto mainWindow = new KMainWindow();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QRect &rect : region) {
        dirtyImageRegion += widgetToImage(rect);
        _terminalPainter->drawBackground(paint, rect, getBackgroundColor(), true /* use opacity setting */);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, window](ViewSplitter *splitter, const QHash<TerminalDisplay *, Session *> &sessionsMap) {
                detachTerminals(window, splitter, sessionsMap);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto action : _contextPopupMenu->actions()) {
        if (action->objectName() == QLatin1String("tab-detach")) {
            action->setEnabled(count() > 1);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, readonly]() {
        _sessionDisplayConnection->view()->updateReadOnlyState(readonly);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &range: currentMergedRangesIt.value()) {
            if(range.first != range.second)
                out << QString::asprintf("%06X..%06X ; %2d\n", range.first, range.second, int(width));
            else
                out << QString::asprintf("%06X         ; %2d\n", range.first, int(width));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto *filter : _filters) {
        QSharedPointer<HotSpot> spot = filter->hotSpotAt(line, column);
        if (spot != nullptr) {
           return spot;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto splitter : splitters) {
        if (splitter->orientation() != orientation()) {
            continue;
        }

        int delta = 0;
        for (auto point : splitter->sizes()) {
            delta += point;
            QPoint thisPoint = orientation() == Qt::Horizontal ? QPoint(delta, 0) : QPoint(0, delta);

            QPoint splitterPos = splitter->mapToTopLevel(thisPoint);

            const int ourPos = orientation() == Qt::Horizontal ? splitterPos.x() : splitterPos.y();

            allSplitterSizes.push_back(ourPos);
        }
    }
```

#### AUTO 


```{c}
const auto items = QList<QStandardItem*> {
        new QStandardItem(),
        new QStandardItem(),
        new QStandardItem()
    };
```

#### AUTO 


```{c}
const auto* v3option = qstyleoption_cast<const QStyleOptionViewItemV3*>(&option);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto sdsp : _sessionMap) {
        sessionList.append(sdsp->session());
    }
```

#### AUTO 


```{c}
auto buildPath = libraryPaths.last();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto action : _contextPopupMenu->actions()) {
        if (action->objectName() == QStringLiteral("tab-detach")) {
            action->setEnabled(count() > 1);
        }
    }
```

#### AUTO 


```{c}
const auto generatorParam = sepPos >= 0 ? generator.mid(sepPos + 1) : QString();
```

#### AUTO 


```{c}
auto *model = qobject_cast<QStandardItemModel *>(_appearanceUi->colorSchemeList->model());
```

#### AUTO 


```{c}
auto *bookmarkMenu = new BookmarkMenu(manager, this, _menu, collection);
```

#### RANGE FOR STATEMENT 


```{c}
for (TerminalDisplay *display : qAsConst(_views)) {
            display->outputSuspended(false);
        }
```

#### AUTO 


```{c}
auto optionsButton = new QToolButton(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this](QPainter &paint, const QRect &rect, bool friendly) {
        Q_EMIT drawContents(_image, paint, rect, friendly, _imageSize, _bidiEnabled, _lineProperties);
    }
```

#### AUTO 


```{c}
const auto highlightScrolledLines = profile->property<bool>(Profile::HighlightScrolledLines);
```

#### AUTO 


```{c}
auto *filterChain = view()->filterChain();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QButtonGroup *group : qAsConst(_groups)) {
        auto *enumItem = groupToConfigItemEnum(group);
        if (enumItem == nullptr) {
            continue;
        }

        int value = enumItem->value();
        const QString &valueName = enumItem->choices().at(value).name;
        QAbstractButton *currentButton = nullptr;
        for (auto &button : group->buttons()) {
            if (button->objectName() == valueName) {
                currentButton = button;
                break;
            }
        }
        if (currentButton == nullptr) {
            return;
        }
        currentButton->setChecked(true);
        changed = true;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]{
        setHandleWidth(calculateHandleWidth(KonsoleSettings::self()->splitDragHandleSize()));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &range : currentMergedRangesIt.value()) {
            if (range.first != range.second)
                out << QString::asprintf("%06X..%06X ; %2d\n", range.first, range.second, int(width));
            else
                out << QString::asprintf("%06X         ; %2d\n", range.first, int(width));
        }
```

#### AUTO 


```{c}
auto terminal = sessionController->session()->foregroundProcessName();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &[group, oldName, newName] : keys) {
            KConfigGroup cg = konsoleConfig->group(group);
            if (cg.exists() && cg.hasKey(oldName)) {
                const bool value = cg.readEntry(oldName, false);
                cg.deleteEntry(oldName);
                cg.writeEntry(newName, value);
            }
        }
```

#### AUTO 


```{c}
auto *filterChain = view->filterChain();
```

#### LAMBDA EXPRESSION 


```{c}
[this, properties]{
        m_terminalTitle->setText(properties->title());
    }
```

#### AUTO 


```{c}
const auto rightSize = rightWidget != nullptr ? rightWidget->sizeHint() : QSize(0, 0);
```

#### AUTO 


```{c}
const auto options = QVector<QCommandLineOption> {
        { { QStringLiteral("profile") },
            i18nc("@info:shell", "Name of profile to use for new Konsole instance"),
            QStringLiteral("name")
        },
        { { QStringLiteral("layout") },
            i18nc("@info:shell", "json layoutfile to be loaded to use for new Konsole instance"),
            QStringLiteral("file")
        },
         { { QStringLiteral("fallback-profile") },
            i18nc("@info:shell", "Use the internal FALLBACK profile")
        },
        { { QStringLiteral("workdir") },
            i18nc("@info:shell", "Set the initial working directory of the new tab or window to 'dir'"),
            QStringLiteral("dir")
        },
        { { QStringLiteral("hold"), QStringLiteral("noclose") },
           i18nc("@info:shell", "Do not close the initial session automatically when it ends.")
        },
        {  {QStringLiteral("new-tab") },
            i18nc("@info:shell", "Create a new tab in an existing window rather than creating a new window")
        },
        { { QStringLiteral("tabs-from-file") },
            i18nc("@info:shell","Create tabs as specified in given tabs configuration"" file"),
            QStringLiteral("file")
        },
        { { QStringLiteral("background-mode") },
            i18nc("@info:shell", "Start Konsole in the background and bring to the front when Ctrl+Shift+F12 (by default) is pressed")
        },
        { { QStringLiteral("separate"), QStringLiteral("nofork") },
            i18nc("@info:shell", "Run in a separate process")
        },
        { { QStringLiteral("show-menubar") },
            i18nc("@info:shell", "Show the menubar, overriding the default setting")
        },
        { { QStringLiteral("hide-menubar") },
            i18nc("@info:shell", "Hide the menubar, overriding the default setting")
        },
        { { QStringLiteral("show-tabbar") },
            i18nc("@info:shell", "Show the tabbar, overriding the default setting")
        },
        { { QStringLiteral("hide-tabbar") },
            i18nc("@info:shell", "Hide the tabbar, overriding the default setting")
        },
        { { QStringLiteral("fullscreen") },
            i18nc("@info:shell", "Start Konsole in fullscreen mode")
        },
        { { QStringLiteral("notransparency") },
            i18nc("@info:shell", "Disable transparent backgrounds, even if the system supports them.")
        },
        { { QStringLiteral("list-profiles") },
            i18nc("@info:shell", "List the available profiles")
        },
        { { QStringLiteral("list-profile-properties") },
            i18nc("@info:shell", "List all the profile properties names and their type (for use with -p)")
        },
        { { QStringLiteral("p") },
            i18nc("@info:shell", "Change the value of a profile property."),
            QStringLiteral("property=value")
        },
        { { QStringLiteral("e") },
            i18nc("@info:shell", "Command to execute. This option will catch all following arguments, so use it as the last option."),
            QStringLiteral("cmd")
        }
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &value : profileProperties) {
        ProfileCommandParser parser;

        QHashIterator<Profile::Property, QVariant> iter(parser.parse(value));
        while (iter.hasNext()) {
            iter.next();
            newProfile->setProperty(iter.key(), iter.value());
        }

        shouldUseNewProfile = true;
    }
```

#### AUTO 


```{c}
const auto isSameScript = [&](int column) {
                const QChar::Script script = QChar::script(baseCodePoint(image[display->loc(column, y)]));
                if (currentScript == QChar::Script_Common || script == QChar::Script_Common || currentScript == QChar::Script_Inherited
                    || script == QChar::Script_Inherited) {
                    return true;
                }
                return currentScript == script;
            };
```

#### CONST EXPRESSION 


```{c}
static constexpr unsigned int LAST_CODE_POINT = CODE_POINTS_NUM - 1;
```

#### AUTO 


```{c}
auto editor = new FilteredKeySequenceEdit(aParent);
```

#### AUTO 


```{c}
auto topLevelSplitter = restoreSessionsSplitterRecurse(jsonSplitter.toObject(), this);
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        d->filterModel->setFilterRegularExpression(ui->filterText->text());
        d->filterModel->invalidate();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (unsigned int & glyphState : glyphStates) {
        glyphState = 0; //nothing..
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, profile]() {
            setEditProfileActionText(profile);
        }
```

#### AUTO 


```{c}
auto r = region(td->fontWidth(), td->fontHeight(), td->columns(), td->contentRect()).first;
```

#### RANGE FOR STATEMENT 


```{c}
for (auto option : options.buttons) {
        options.group->setId(option.button, option.value);
    }
```

#### AUTO 


```{c}
const auto leftSize = leftWidget ? leftWidget->sizeHint() : QSize(0, 0);
```

#### LAMBDA EXPRESSION 


```{c}
[&packedLineTypes](quint8 lineId)->LineType {
        lineId = LinesNum - 1 - lineId % LinesNum;
        return LineType(packedLineTypes >> 2 * lineId & 3);
    }
```

#### AUTO 


```{c}
auto *mouseEvent = static_cast<QMouseEvent *>(event);
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto& possibility : possibilities) {
        possibility.button->setChecked(possibility.value == actual);
        connect(possibility.button, SIGNAL(clicked()), this, possibility.slot);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&profileToLoad](const Konsole::Profile::Ptr &pr) {
        return pr->name() == profileToLoad;
    }
```

#### AUTO 


```{c}
auto enableAction = [&enable, &collection](const QString& actionName) {
        auto *action = collection->action(actionName);
        if (action != nullptr) {
            action->setEnabled(enable);
        }
    };
```

#### AUTO 


```{c}
auto sessionController = qobject_cast<SessionController*>(controller);
```

#### AUTO 


```{c}
auto orientation = (jsonSplitter[QStringLiteral("Orientation")].toString() == QStringLiteral("Horizontal")) ? Qt::Horizontal : Qt::Vertical;
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &&size : sizes) {
                size = sharedSize.width();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *filter : _filters) {
        QSharedPointer<HotSpot> spot = filter->hotSpotAt(line, column);
        if (spot != nullptr) {
            return spot;
        }
    }
```

#### AUTO 


```{c}
const auto items = QList<QStandardItem*> {
        _sessionModel->item(row, FavoriteStatusColumn),
        _sessionModel->item(row, ProfileNameColumn),
        _sessionModel->item(row, ShortcutColumn),
        _sessionModel->item(row, ProfileColumn),
    };
```

#### AUTO 


```{c}
const auto &file
```

#### AUTO 


```{c}
auto [charLine, charColumn] = getCharacterPosition(ev->position().toPoint(), !usesMouseTracking());
```

#### AUTO 


```{c}
auto tabTterminalDisplays = toplevelSplitter->findChildren<TerminalDisplay*>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &p : params) {
            int eq = p.indexOf(QLatin1Char('='));
            if (eq > 0) {
                QString var = p.mid(0, eq);
                QString val = p.mid(eq + 1);
                if (var == QLatin1String("inline")) {
                    if (val != QLatin1String("1")) {
                        return;
                    }
                }
                if (var == QLatin1String("preserveAspectRatio")) {
                    if (val == QLatin1String("0")) {
                        keepAspect = 0;
                    }
                }
                if (var == QLatin1String("doNotMoveCursor")) {
                    if (val == QLatin1String("1")) {
                        moveCursor = false;
                    }
                }
                if (var == QLatin1String("width")) {
                    int unitPos = val.toStdString().find_first_not_of("0123456789");
                    scaledWidth = val.midRef(0, unitPos).toInt();
                    if (unitPos == -1) {
                        scaledWidth *= _currentScreen->currentTerminalDisplay()->terminalFont()->fontWidth();
                    } else {
                        if (val.mid(unitPos) == QLatin1String("%")) {
                            scaledWidth *= _currentScreen->currentTerminalDisplay()->terminalFont()->fontWidth() * _currentScreen->getColumns() / 100;
                        }
                    }
                }
                if (var == QLatin1String("height")) {
                    int unitPos = val.toStdString().find_first_not_of("0123456789");
                    scaledHeight = val.midRef(0, unitPos).toInt();
                    if (unitPos == -1) {
                        scaledHeight *= _currentScreen->currentTerminalDisplay()->terminalFont()->fontHeight();
                    } else {
                        if (val.mid(unitPos) == QLatin1String("%")) {
                            scaledHeight *= _currentScreen->currentTerminalDisplay()->terminalFont()->fontHeight() * _currentScreen->getLines() / 100;
                        }
                    }
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *l : qAsConst(_layouts)) {
        int left = getLeftMargin(l);
        l->setColumnMinimumWidth(LABELS_COLUMN, maxRight - left);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (TerminalDisplay *terminalDisplay : viewsList) {
        if (terminalDisplay != _sessionDisplayConnection->view()) {
            terminalDisplay->updateReadOnlyState(isReadOnly());
        }
        emit readOnlyChanged(this);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QFont &f) {
            _terminalFont->setVTFont(f);
        }
```

#### AUTO 


```{c}
auto from = std::make_move_iterator(_screenLines.begin() + destY);
```

#### CONST EXPRESSION 


```{c}
static constexpr int LABELS_COLUMN = 0;
```

#### AUTO 


```{c}
auto* copyInputToAllTabsAction = collection->add<KToggleAction>(QStringLiteral("copy-input-to-all-tabs"));
```

#### AUTO 


```{c}
auto *terminalPart = factory->create<KParts::ReadOnlyPart>(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &file : entry.uninstalledFiles()) {
                if (ColorSchemeManager::instance()->unloadColorScheme(file)) {
                    continue;
                }
                qWarning() << "Failed to unload file" << file;
                // If unloading fails we do not care. Iff the scheme failed here
                // it either wasn't loaded or was invalid to begin with.
            }
```

#### AUTO 


```{c}
auto focusedTerminalDisplay = qobject_cast<TerminalDisplay *>(focusedWidget);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &spot : spots) {
        QRegion region;
        if (spot->type() == HotSpot::Link || spot->type() == HotSpot::EMailAddress || spot->type() == HotSpot::EscapedUrl) {
            QPair<QRegion, QRect> spotRegion = spot->region(td->fontWidth(), td->fontHeight(), td->columns(), td->contentRect());
            region = spotRegion.first;
            QRect r = spotRegion.second;

            if (_showUrlHint && spot->type() == HotSpot::Link) {
                // if we are in reverse  url hints mode, we need to get the proper number,
                // before trying to display the hint. if we don't do that we miss mint nr. '0'.
                if (_reverseUrlHints) {
                    urlNumber -= 1;
                }
                if (urlNumber >= 0 && urlNumber < 10) {
                    // Position at the beginning of the URL
                    QRect hintRect(*region.begin());
                    hintRect.setWidth(r.height());
                    painter.fillRect(hintRect, QColor(0, 0, 0, 128));
                    painter.setPen(Qt::white);
                    painter.drawRect(hintRect.adjusted(0, 0, -1, -1));
                    painter.drawText(hintRect, Qt::AlignCenter, QString::number(urlNumber));
                }
                // But if we are not in reverse mode, we need to increase it later.
                if (!_reverseUrlHints) {
                    urlNumber += 1;
                }
            }
        }

        if (spot->startLine() < 0 || spot->endLine() < 0) {
            qDebug() << "ERROR, invalid hotspot:";
            spot->debug();
        }

        for (int line = spot->startLine() ; line <= spot->endLine() ; line++) {
            int startColumn = 0;
            int endColumn = td->columns() - 1; // TODO use number of _columns which are actually
            // occupied on this line rather than the width of the
            // display in _columns

            // Check image size so _image[] is valid (see makeImage)
            if (endColumn >= td->columns() || line >= td->lines()) {
                break;
            }

            // ignore whitespace at the end of the lines
            while (td->getCursorCharacter(endColumn, line).isSpace() && endColumn > 0) {
                endColumn--;
            }

            // increment here because the column which we want to set 'endColumn' to
            // is the first whitespace character at the end of the line
            endColumn++;

            if (line == spot->startLine()) {
                startColumn = spot->startColumn();
            }
            if (line == spot->endLine()) {
                endColumn = spot->endColumn();
            }

            // TODO: resolve this comment with the new margin/center code
            // subtract one pixel from
            // the right and bottom so that
            // we do not overdraw adjacent
            // hotspots
            //
            // subtracting one pixel from all sides also prevents an edge case where
            // moving the mouse outside a link could still leave it underlined
            // because the check below for the position of the cursor
            // finds it on the border of the target area
            QRect r;
            r.setCoords(startColumn * td->fontWidth() + td->contentRect().left(),
                        line * td->fontHeight() + td->contentRect().top(),
                        endColumn * td->fontWidth() + td->contentRect().left() - 1,
                        (line + 1)* td->fontHeight() + td->contentRect().top() - 1);

            // Underline link hotspots
            // TODO: Fix accessing the urlHint here.
            // TODO: Move this code to UrlFilterHotSpot.
            const bool hasMouse = region.contains(td->mapFromGlobal(QCursor::pos()));
            if ((spot->type() == HotSpot::Link && _showUrlHint) || hasMouse) {
                QFontMetrics metrics(td->font());

                // find the baseline (which is the invisible line that the characters in the font sit on,
                // with some having tails dangling below)
                const int baseline = r.bottom() - metrics.descent();
                // find the position of the underline below that
                const int underlinePos = baseline + metrics.underlinePos();
                painter.drawLine(r.left() , underlinePos, r.right() , underlinePos);

                // Marker hotspots simply have a transparent rectangular shape
                // drawn on top of them
            } else if (spot->type() == HotSpot::Marker) {
                //TODO - Do not use a hardcoded color for this
                const bool isCurrentResultLine = (td->screenWindow()->currentResultLine() == (spot->startLine() + td->screenWindow()->currentLine()));
                QColor color = isCurrentResultLine ? QColor(255, 255, 0, 120) : QColor(255, 0, 0, 120);
                painter.fillRect(r, color);
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            _filterUpdateRequired = true;
        }
```

#### AUTO 


```{c}
const auto parent = parentWidget();
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Profile::Ptr &profile) { emit newViewWithProfileRequest(this, profile); }
```

#### AUTO 


```{c}
const auto* opt = qstyleoption_cast<const QStyleOptionViewItem*>(&option);
```

#### RANGE FOR STATEMENT 


```{c}
for (TerminalDisplay *display : qAsConst(_views)) {
                if (display->flowControlWarningEnabled()) {
                    display->outputSuspended(true);
                }
            }
```

