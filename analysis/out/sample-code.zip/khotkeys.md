#### AUTO 


```{c}
auto *job = new KIO::CommandLauncherJob("qdbusviewer");
```

#### AUTO 


```{c}
auto emitModelChange = [this](KHotKeys::ActionDataBase *hotkey) {
        d->model->emitChanged(hotkey);
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this](KHotKeys::ActionDataBase *hotkey) {
        d->model->emitChanged(hotkey);
    }
```

#### AUTO 


```{c}
auto it = shortcuts.constBegin();
```

#### LAMBDA EXPRESSION 


```{c}
[&dir] (const QString &file) {
            return QStringLiteral("%1/%2").arg(dir, file);
        }
```

#### AUTO 


```{c}
auto shortcuts = KGlobalAccel::self()->shortcut(action);
```

#### AUTO 


```{c}
const auto &dir
```

#### AUTO 


```{c}
auto qObject = dynamic_cast<QObject *>(trigger);
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
            _trigger = nullptr;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&dir](const QString &file) {
            return QStringLiteral("%1/%2").arg(dir, file);
        }
```

#### AUTO 


```{c}
auto *job = new KIO::CommandLauncherJob(exec);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &dir : khotkeysDirs) {
        const QStringList fileNames = QDir(dir).entryList(QStringList{QStringLiteral("*.khotkeys")});
        std::transform(fileNames.begin(), fileNames.end(), std::back_inserter(updates), [&dir](const QString &file) {
            return QStringLiteral("%1/%2").arg(dir, file);
        });
    }
```

#### AUTO 


```{c}
const auto shortcuts = shortcut();
```

#### AUTO 


```{c}
auto *job = new KIO::ApplicationLauncherJob(service);
```

#### AUTO 


```{c}
auto it = windows.begin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &dir : khotkeysDirs) {
        const QStringList fileNames = QDir(dir).entryList(QStringList{QStringLiteral("*.khotkeys")});
        std::transform(fileNames.begin(), fileNames.end(), std::back_inserter(updates), [&dir] (const QString &file) {
            return QStringLiteral("%1/%2").arg(dir, file);
        });
    }
```

