#### RANGE FOR STATEMENT 


```{c}
for (const QString& languageCode : std::as_const(languageCodes))
    {
        QLocale locale(languageCode);
        QString languageName = locale.nativeLanguageName();

        languageNames.append(languageName);
    }
```

#### AUTO 


```{c}
const auto &file
```

#### AUTO 


```{c}
auto context = new KLocalizedContext(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QChar &key : search) {
        int pos = m_originalWord.indexOf( key );
        while (pos > 0) {
            m_currentWord.replace(pos, 1, key);
            pos = m_originalWord.indexOf( key );
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &file : xmlFilesList) {
            addTheme(file.absoluteFilePath());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &theme : themesList) {
        list.append(theme.name());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &theme : themesList) {
        list.append(theme.uiName());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QChar &c : m_originalWord) {
        if (search.contains(c)) {
            m_currentWord.append(c);
        } else {
            m_currentWord.append(QLatin1Char('_'));
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, dialog] {
        const QList<KNSCore::EntryInternal> entries = dialog->changedEntries();
        if ( !entries.isEmpty() ){
            SharedKvtmlFiles::sortDownloadedFiles();
            //look for languages dirs installed
            scanLanguages();
            //refresh Languages menu
            setCurrentLanguage(m_languages.indexOf(Prefs::selectedLanguage()));
        }

        dialog->deleteLater();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KEduVocExpression* entry : words) {
        QString hint = entry->translation(0)->comment();
        if (hint.isEmpty() && doc.identifierCount() > 0) {
            // if there is no comment or it's empty, use the first translation if there is one
            hint = entry->translation(1)->text();
        }
        QString text = entry->translation(0)->text();
        if (!text.isEmpty()) {
            m_randomList.append(qMakePair(text, hint));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QChar& currentWordLetter : std::as_const(m_currentWord))
    {
        currentWordLetters.append(currentWordLetter);
    }
```

#### AUTO 


```{c}
const auto &theme
```

