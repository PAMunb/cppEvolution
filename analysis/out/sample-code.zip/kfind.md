#### LAMBDA EXPRESSION 


```{c}
[] {
        MimeTypes mimeTypes;

        const auto types = QMimeDatabase().allMimeTypes();
        for (const QMimeType &type : types) {
            if ((!type.comment().isEmpty())
                && (!type.name().startsWith(QLatin1String("kdedevice/")))
                && (!type.name().startsWith(QLatin1String("all/")))) {
                mimeTypes.all.append(type);

                if (type.name().startsWith(QLatin1String("image/"))) {
                    mimeTypes.image.append(type.name());
                } else if (type.name().startsWith(QLatin1String("video/"))) {
                    mimeTypes.video.append(type.name());
                } else if (type.name().startsWith(QLatin1String("audio/"))) {
                    mimeTypes.audio.append(type.name());
                }
            }
        }

        std::sort(mimeTypes.all.begin(), mimeTypes.all.end(), [](const QMimeType &lhs, const QMimeType &rhs) {
            return lhs.comment() < rhs.comment();
        });

        return mimeTypes;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, watcher] {
        const MimeTypes &mimeTypes = watcher->result();

        for (const auto &mime : qAsConst(mimeTypes.all)) {
            typeBox->addItem(mime.comment());
        }

        m_types = mimeTypes.all;

        m_ImageTypes = mimeTypes.image;
        m_VideoTypes = mimeTypes.video;
        m_AudioTypes = mimeTypes.audio;

        watcher->deleteLater();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(QWidget *page : pages) {
        page->setEnabled(false);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFindItem &item : itemList) {
                stream << item.getFileItem().url().url() << endl;
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this, watcher] {
        const MimeTypes &mimeTypes = watcher->result();

        for (const auto &mime : std::as_const(mimeTypes.all)) {
            typeBox->addItem(mime.comment());
        }

        m_types = mimeTypes.all;

        m_ImageTypes = mimeTypes.image;
        m_VideoTypes = mimeTypes.video;
        m_AudioTypes = mimeTypes.audio;

        watcher->deleteLater();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KFileMetaData::Extractor* ex : exList) {
            KFileMetaData::SimpleExtractionResult result(filename, mimetype,
                                                         KFileMetaData::ExtractionResult::ExtractMetaData);
            ex->extract(&result);

            KFileMetaData::PropertyMap properties = result.properties();
            KFileMetaData::PropertyMap::const_iterator it = properties.constBegin();
            for (; it != properties.constEnd(); it++) {
                if (!metaKeyRx.exactMatch(KFileMetaData::PropertyInfo(it.key()).displayName())) {
                    continue;
                }
                strmetakeycontent = it.value().toString();
                if (strmetakeycontent.indexOf(m_metainfo) != -1) {
                    foundmeta = true;
                    break;
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &mime : qAsConst(mimeTypes.all)) {
            typeBox->addItem(mime.comment());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (KFileMetaData::Extractor* ex : exList) {
            KFileMetaData::SimpleExtractionResult result(filename, mimetype,
                                                         KFileMetaData::ExtractionResult::ExtractMetaData);
            ex->extract(&result);

            const KFileMetaData::PropertyMultiMap properties = result.properties();
            for (auto it = properties.cbegin(); it != properties.cend(); ++it) {
                if (!metaKeyRx.exactMatch(KFileMetaData::PropertyInfo(it.key()).displayName())) {
                    continue;
                }
                strmetakeycontent = it.value().toString();
                if (strmetakeycontent.indexOf(m_metainfo) != -1) {
                    foundmeta = true;
                    break;
                }
            }
        }
```

#### AUTO 


```{c}
auto mimeTypeFuture = QtConcurrent::run([this] {
        MimeTypes mimeTypes;

        foreach (const KMimeType::Ptr &type, KMimeType::allMimeTypes()) {
            if ((!type->comment().isEmpty())
                && (!type->name().startsWith(QLatin1String("kdedevice/")))
                && (!type->name().startsWith(QLatin1String("all/")))) {
                mimeTypes.all.append(type);

                if (type->name().startsWith(QLatin1String("image/"))) {
                    mimeTypes.image.append(type->name());
                } else if (type->name().startsWith(QLatin1String("video/"))) {
                    mimeTypes.video.append(type->name());
                } else if (type->name().startsWith(QLatin1String("audio/"))) {
                    mimeTypes.audio.append(type->name());
                }
            }
        }

        std::sort(mimeTypes.all.begin(), mimeTypes.all.end(), [](const KMimeType::Ptr &lhs, const KMimeType::Ptr &rhs) {
            return lhs->comment() < rhs->comment();
        });

        return mimeTypes;
    });
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : selected) {
        if (index.column() == 0) {
            KFindItem item = m_model->itemAtIndex(index);
            if (item.isValid()) {
                auto *job = new KIO::OpenUrlJob(item.getFileItem().targetUrl());
                job->setUiDelegate(new KIO::JobUiDelegate(KJobUiDelegate::AutoHandlingEnabled, this));
                job->start();
            }
        }
    }
```

#### AUTO 


```{c}
const auto types = QMimeDatabase().allMimeTypes();
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFindItem &item : itemList) {
                stream << item.getFileItem().url().url() << Qt::endl;
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &mime : qAsConst(mimeTypes.all)) {
            typeBox->addItem(mime->comment());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : selected) {
        if (index.column() == 0) {
            const KFindItem item = m_model->itemAtIndex(index);
            if (item.isValid()) {
                fileList.append(item.getFileItem());
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        MimeTypes mimeTypes;

        foreach (const KMimeType::Ptr &type, KMimeType::allMimeTypes()) {
            if ((!type->comment().isEmpty())
                && (!type->name().startsWith(QLatin1String("kdedevice/")))
                && (!type->name().startsWith(QLatin1String("all/")))) {
                mimeTypes.all.append(type);

                if (type->name().startsWith(QLatin1String("image/"))) {
                    mimeTypes.image.append(type->name());
                } else if (type->name().startsWith(QLatin1String("video/"))) {
                    mimeTypes.video.append(type->name());
                } else if (type->name().startsWith(QLatin1String("audio/"))) {
                    mimeTypes.audio.append(type->name());
                }
            }
        }

        std::sort(mimeTypes.all.begin(), mimeTypes.all.end(), [](const KMimeType::Ptr &lhs, const KMimeType::Ptr &rhs) {
            return lhs->comment() < rhs->comment();
        });

        return mimeTypes;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : indexes) {
        if (index.isValid()) {
            if (index.column() == 0) { //Only use the first column item
                uris.append(m_itemList.at(index.row()).getFileItem().url());
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        MimeTypes mimeTypes;

        const auto types = QMimeDatabase().allMimeTypes();
        foreach (const QMimeType &type, types) {
            if ((!type.comment().isEmpty())
                && (!type.name().startsWith(QLatin1String("kdedevice/")))
                && (!type.name().startsWith(QLatin1String("all/")))) {
                mimeTypes.all.append(type);

                if (type.name().startsWith(QLatin1String("image/"))) {
                    mimeTypes.image.append(type.name());
                } else if (type.name().startsWith(QLatin1String("video/"))) {
                    mimeTypes.video.append(type.name());
                } else if (type.name().startsWith(QLatin1String("audio/"))) {
                    mimeTypes.audio.append(type.name());
                }
            }
        }

        std::sort(mimeTypes.all.begin(), mimeTypes.all.end(), [](const QMimeType &lhs, const QMimeType &rhs) {
            return lhs.comment() < rhs.comment();
        });

        return mimeTypes;
    }
```

#### AUTO 


```{c}
auto *job = new KIO::OpenUrlJob(item.getFileItem().targetUrl());
```

#### LAMBDA EXPRESSION 


```{c}
[this, fileList]() {
                KPropertiesDialog::showDialog(fileList, this, false /*non modal*/);
        }
```

#### AUTO 


```{c}
const auto &mime
```

#### AUTO 


```{c}
auto mimeTypeFuture = QtConcurrent::run([this] {
        MimeTypes mimeTypes;

        const auto types = QMimeDatabase().allMimeTypes();
        foreach (const QMimeType &type, types) {
            if ((!type.comment().isEmpty())
                && (!type.name().startsWith(QLatin1String("kdedevice/")))
                && (!type.name().startsWith(QLatin1String("all/")))) {
                mimeTypes.all.append(type);

                if (type.name().startsWith(QLatin1String("image/"))) {
                    mimeTypes.image.append(type.name());
                } else if (type.name().startsWith(QLatin1String("video/"))) {
                    mimeTypes.video.append(type.name());
                } else if (type.name().startsWith(QLatin1String("audio/"))) {
                    mimeTypes.audio.append(type.name());
                }
            }
        }

        std::sort(mimeTypes.all.begin(), mimeTypes.all.end(), [](const QMimeType &lhs, const QMimeType &rhs) {
            return lhs.comment() < rhs.comment();
        });

        return mimeTypes;
    });
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &mime : std::as_const(mimeTypes.all)) {
            typeBox->addItem(mime.comment());
        }
```

#### LAMBDA EXPRESSION 


```{c}
[] {
        MimeTypes mimeTypes;

        const auto types = QMimeDatabase().allMimeTypes();
        foreach (const QMimeType &type, types) {
            if ((!type.comment().isEmpty())
                && (!type.name().startsWith(QLatin1String("kdedevice/")))
                && (!type.name().startsWith(QLatin1String("all/")))) {
                mimeTypes.all.append(type);

                if (type.name().startsWith(QLatin1String("image/"))) {
                    mimeTypes.image.append(type.name());
                } else if (type.name().startsWith(QLatin1String("video/"))) {
                    mimeTypes.video.append(type.name());
                } else if (type.name().startsWith(QLatin1String("audio/"))) {
                    mimeTypes.audio.append(type.name());
                }
            }
        }

        std::sort(mimeTypes.all.begin(), mimeTypes.all.end(), [](const QMimeType &lhs, const QMimeType &rhs) {
            return lhs.comment() < rhs.comment();
        });

        return mimeTypes;
    }
```

#### AUTO 


```{c}
auto *watcher = new QFutureWatcher<MimeTypes>(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QMimeType &type : types) {
            if ((!type.comment().isEmpty())
                && (!type.name().startsWith(QLatin1String("kdedevice/")))
                && (!type.name().startsWith(QLatin1String("all/")))) {
                mimeTypes.all.append(type);

                if (type.name().startsWith(QLatin1String("image/"))) {
                    mimeTypes.image.append(type.name());
                } else if (type.name().startsWith(QLatin1String("video/"))) {
                    mimeTypes.video.append(type.name());
                } else if (type.name().startsWith(QLatin1String("audio/"))) {
                    mimeTypes.audio.append(type.name());
                }
            }
        }
```

#### AUTO 


```{c}
auto mimeTypeFuture = QtConcurrent::run([] {
        MimeTypes mimeTypes;

        const auto types = QMimeDatabase().allMimeTypes();
        for (const QMimeType &type : types) {
            if ((!type.comment().isEmpty())
                && (!type.name().startsWith(QLatin1String("kdedevice/")))
                && (!type.name().startsWith(QLatin1String("all/")))) {
                mimeTypes.all.append(type);

                if (type.name().startsWith(QLatin1String("image/"))) {
                    mimeTypes.image.append(type.name());
                } else if (type.name().startsWith(QLatin1String("video/"))) {
                    mimeTypes.video.append(type.name());
                } else if (type.name().startsWith(QLatin1String("audio/"))) {
                    mimeTypes.audio.append(type.name());
                }
            }
        }

        std::sort(mimeTypes.all.begin(), mimeTypes.all.end(), [](const QMimeType &lhs, const QMimeType &rhs) {
            return lhs.comment() < rhs.comment();
        });

        return mimeTypes;
    });
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFindItem &item : itemList) {
                stream << item.getFileItem().url().url()
          #if (QT_VERSION < QT_VERSION_CHECK(5, 15, 0))
                       << endl
          #else
                       << Qt::endl
          #endif
                          ;
            }
```

#### AUTO 


```{c}
auto hScroll = horizontalScrollBar()->value();
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFindItem &item : itemList) {
                const KFileItem fileItem = item.getFileItem();
                stream << QStringLiteral("<dt><a href=\"%1\">%2</a></dt>\n").arg(
                    fileItem.url().url(), fileItem.url().toDisplayString());
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this, watcher] {
        const MimeTypes &mimeTypes = watcher->result();

        for (const auto &mime : qAsConst(mimeTypes.all)) {
            typeBox->addItem(mime->comment());
        }

        m_types = mimeTypes.all;

        m_ImageTypes = mimeTypes.image;
        m_VideoTypes = mimeTypes.video;
        m_AudioTypes = mimeTypes.audio;

        watcher->deleteLater();
    }
```

#### AUTO 


```{c}
auto mimeTypeFuture = QtConcurrent::run([] {
        MimeTypes mimeTypes;

        const auto types = QMimeDatabase().allMimeTypes();
        foreach (const QMimeType &type, types) {
            if ((!type.comment().isEmpty())
                && (!type.name().startsWith(QLatin1String("kdedevice/")))
                && (!type.name().startsWith(QLatin1String("all/")))) {
                mimeTypes.all.append(type);

                if (type.name().startsWith(QLatin1String("image/"))) {
                    mimeTypes.image.append(type.name());
                } else if (type.name().startsWith(QLatin1String("video/"))) {
                    mimeTypes.video.append(type.name());
                } else if (type.name().startsWith(QLatin1String("audio/"))) {
                    mimeTypes.audio.append(type.name());
                }
            }
        }

        std::sort(mimeTypes.all.begin(), mimeTypes.all.end(), [](const QMimeType &lhs, const QMimeType &rhs) {
            return lhs.comment() < rhs.comment();
        });

        return mimeTypes;
    });
```

#### RANGE FOR STATEMENT 


```{c}
for(QWidget *page : pages) {
        page->setEnabled(true);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : indexes) {
        if (index.column() == 0 && index.isValid()) {
            KFindItem item = m_model->itemAtIndex(index);
            if (item.isValid()) {
                uris.append(item.getFileItem().url());
            }
        }
    }
```

#### AUTO 


```{c}
auto it = properties.cbegin();
```

#### LAMBDA EXPRESSION 


```{c}
[](const KMimeType::Ptr &lhs, const KMimeType::Ptr &rhs) {
            return lhs->comment() < rhs->comment();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, fileList]() {
            KPropertiesDialog::showDialog(fileList, this, false /*non modal*/);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QMimeType &lhs, const QMimeType &rhs) {
            return lhs.comment() < rhs.comment();
        }
```

