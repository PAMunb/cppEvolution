#### RANGE FOR STATEMENT 


```{c}
for (const auto &jt : qAsConst(result)) {
            cout << "result[" << j << "].displayName:\n"
                 << (jt).displayName
                 << endl;
            int i = 0;
            const auto mailboxList = (jt).mailboxList;
            for (const auto &it : mailboxList) {
                cout << "result[" << j << "].mailboxList[" << i << "].displayName:\n"
                     << (it).name() << endl
                     << "result[" << j << "].mailboxList[" << i << "].addrSpec.localPart:\n"
                     << (it).addrSpec().localPart << endl
                     << "result[" << j << "].mailboxList[" << i << "].addrSpec.domain:\n"
                     << (it).addrSpec().domain
                     << endl;
                ++i;
            }
            ++j;
        }
```

#### AUTO 


```{c}
auto cd = content->contentDisposition(false);
```

#### AUTO 


```{c}
auto *h10 = new MessageID();
```

#### AUTO 


```{c}
const auto mailboxList = addr.mailboxList;
```

#### RANGE FOR STATEMENT 


```{c}
for (const Types::Mailbox &mbox : mailboxList) {
            rv.append(mbox);
        }
```

#### AUTO 


```{c}
const auto mailBoxList = addr.mailboxList;
```

#### AUTO 


```{c}
const auto unfoldedBody = unfoldHeader(head.constData() + startOfFieldBody, endOfFieldBody - startOfFieldBody);
```

#### AUTO 


```{c}
auto header = new Headers::MIMEVersion(msg);
```

#### RANGE FOR STATEMENT 


```{c}
for (Headers::Base *h : qAsConst(d_ptr->headers)) {
        if (h->is(type)) {
            result << h;
        }
    }
```

#### AUTO 


```{c}
const auto contents = d_ptr->contents();
```

#### AUTO 


```{c}
const auto match = subjectRegex.match(QLatin1String(m_subject));
```

#### RANGE FOR STATEMENT 


```{c}
for (const Types::Mailbox &mbox : mailboxList) {
            if (mbox.hasName()) {
                rv.append(mbox.name());
            } else {
                rv.append(QString::fromLatin1(mbox.address()));
            }
        }
```

#### AUTO 


```{c}
const auto headers = main->d_ptr->headers;
```

#### RANGE FOR STATEMENT 


```{c}
for (const Types::Address &addr : qAsConst(d->addressList)) {
        const auto mailboxList = addr.mailboxList;
        for (const Types::Mailbox &mbox : mailboxList) {
            if (mbox.hasName())
                rv.append(mbox.name());
            else
                rv.append(QString::fromLatin1(mbox.address()));
        }
    }
```

#### AUTO 


```{c}
auto *h15 = new Generic();
```

#### AUTO 


```{c}
auto msg = readAndParseMail(QLatin1String("empty-subject.mbox"));
```

#### AUTO 


```{c}
auto *h14 = new References();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &it : qAsConst(maybeAddressList)) {
        if (!(it).displayName.isEmpty()) {
            KMIME_WARN << "mailbox groups in header disallowing them! Name: \""
                       << (it).displayName << "\""
                       << Qt::endl
                          ;
        }
        d->mailboxList += (it).mailboxList;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &it : std::as_const(maybeAddressList)) {
        res += (it).mailboxList;
    }
```

#### AUTO 


```{c}
auto c1 = new KMime::Content;
```

#### AUTO 


```{c}
auto addrs = h->addresses();
```

#### AUTO 


```{c}
const auto parts = mpp.parts();
```

#### AUTO 


```{c}
const auto contentDisposition = content->contentDisposition(false);
```

#### AUTO 


```{c}
auto *h2 = new Headers::Generic("Resent-From");
```

#### AUTO 


```{c}
auto *h = new Headers::Generics::Ident();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Types::AddrSpec &addr : msgIdList) {
        if (!addr.isEmpty()) {
            const QString asString = addr.asString();
            if (!asString.isEmpty()) {
                rv.append(asString.toLatin1());   // FIXME: change parsing to use QByteArrays
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &part : parts) {
        Content *c = new Content(q);
        c->setContent(part);
        c->setFrozen(frozen);
        c->parse();
        c->contentType()->setCategory(cat);
        multipartContents.append(c);
    }
```

#### AUTO 


```{c}
auto *c121 = new Content();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Types::Address &addr : std::as_const(d->addressList)) {
        const auto mailboxList = addr.mailboxList;
        for (const Types::Mailbox &mbox : mailboxList) {
            if (mbox.hasName()) {
                rv.append(mbox.name());
            } else {
                rv.append(QString::fromLatin1(mbox.address()));
            }
        }
    }
```

#### AUTO 


```{c}
auto locale = QLocale::system();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Types::Mailbox &mbox : mailboxList) {
        rv.append(mbox.address());
    }
```

#### AUTO 


```{c}
const auto prevBody = body;
```

#### RANGE FOR STATEMENT 


```{c}
for (Content *child : contents) {
            if (hasInvitation(child)) {
                return true;
            }
        }
```

#### AUTO 


```{c}
const auto top = content->topLevel();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &it : qAsConst(result.mailboxList)) {
            cout << "result.mailboxList[" << i << "].displayName:\n"
                 << (it).name() << endl
                 << "result.mailboxList[" << i << "].addrSpec.localPart:\n"
                 << (it).addrSpec().localPart << endl
                 << "result.mailboxList[" << i << "].addrSpec.domain:\n"
                 << (it).addrSpec().domain << endl;
            ++i;
        }
```

#### AUTO 


```{c}
const auto addressList = d_func()->addressList;
```

#### RANGE FOR STATEMENT 


```{c}
for (Headers::Base *h : qAsConst(d_ptr->headers)) {
        if (h->is(type)) {
            return h; // Found.
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (unsigned int i : std::as_const(d->index)) {
        l.append(QString::number(i));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Types::Mailbox &mbox : qAsConst(d->mailboxList)) {
        rv += mbox.as7BitString(d->encCS);
        rv += ", ";
    }
```

#### AUTO 


```{c}
auto *h3 = new Headers::Generic("Resent-From");
```

#### RANGE FOR STATEMENT 


```{c}
for (const Types::AddrSpec &addr : std::as_const(d->msgIdList)) {
        if (!addr.isEmpty()) {
            const QString asString = addr.asString();
            rv += '<';
            if (!asString.isEmpty()) {
                rv += asString.toLatin1(); // FIXME: change parsing to use QByteArrays
            }
            rv += "> ";
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Types::Mailbox &mbox : std::as_const(d->mailboxList)) {
        if (mbox.hasName()) {
            rv.append(mbox.name());
        } else {
            rv.append(QString::fromLatin1(mbox.address()));
        }
    }
```

#### AUTO 


```{c}
const auto contents = d->contents();
```

#### RANGE FOR STATEMENT 


```{c}
for (Content *child : contentsList) {
            if (isAttachment(child))
                result.push_back(child);
            else
                result += child->attachments();
        }
```

#### AUTO 


```{c}
auto *msg3 = new Message();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &part : parts) {
        auto *c = new Content(q);
        c->setContent(part);
        c->setFrozen(frozen);
        c->parse();
        c->contentType()->setCategory(cat);
        multipartContents.append(c);
    }
```

#### AUTO 


```{c}
auto msg = readAndParseMail(QStringLiteral("empty-subject.mbox"));
```

#### AUTO 


```{c}
auto *main = new Content(this);
```

#### AUTO 


```{c}
auto header = new Headers::MIMEVersion;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &it : qAsConst(maybeAddressList)) {
        res += (it).mailboxList;
    }
```

#### AUTO 


```{c}
auto *h3 = new Sender();
```

#### AUTO 


```{c}
auto *c = new Message();
```

#### AUTO 


```{c}
const auto mailboxList = d_func()->mailboxList;
```

#### RANGE FOR STATEMENT 


```{c}
for (Headers::Base *h : headers) {
            setHeader(h);   // Will remove the old one if present.
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Headers::Base *h : std::as_const(d_ptr->headers)) {
        if (h->is(type)) {
            result << h;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Headers::Base *h : std::as_const(d_ptr->headers)) {
        if (h->is(type)) {
            return h; // Found.
        }
    }
```

#### AUTO 


```{c}
auto *h13 = new InReplyTo();
```

#### AUTO 


```{c}
auto *c5 = new Content();
```

#### AUTO 


```{c}
auto msg = readAndParseMail(QStringLiteral("bug392239.mbox"));
```

#### AUTO 


```{c}
auto *msg2 = new Message();
```

#### AUTO 


```{c}
auto att = new KMime::Content;
```

#### AUTO 


```{c}
auto *h11 = new ContentID();
```

#### AUTO 


```{c}
auto *myfrom = new Headers::From();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Types::Address &addr : qAsConst(d->addressList)) {
        rv.reserve(rv.size() + addr.mailboxList.size());
        const auto mailboxList = addr.mailboxList;
        for (const Types::Mailbox &mbox : mailboxList) {
            rv.append(mbox.prettyAddress());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Content *c : std::as_const(d->multipartContents)) {
            e += boundary + '\n';
            e += c->encodedContent(false);    // don't convert LFs here, we do that later!!!!!
        }
```

#### AUTO 


```{c}
auto *c = new Content;
```

#### AUTO 


```{c}
const auto &it
```

#### RANGE FOR STATEMENT 


```{c}
for (const Types::Address &addr : qAsConst(d->addressList)) {
        const auto mailBoxList = addr.mailboxList;
        for (const Types::Mailbox &mbox : mailBoxList) {
            rv += mbox.as7BitString(d->encCS);
            rv += ", ";
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Headers::Base *h : qAsConst(d->headers)) {
        if (!h->isEmpty()) {
            newHead += h->as7BitString() + '\n';
        }
    }
```

#### AUTO 


```{c}
auto *attach = new Content();
```

#### AUTO 


```{c}
const auto srcStr = QString::fromLatin1(m_src);
```

#### AUTO 


```{c}
const auto fileName = cd->filename().toLower();
```

#### AUTO 


```{c}
auto ct = contentType(false);
```

#### AUTO 


```{c}
auto cte = q->contentTransferEncoding();
```

#### AUTO 


```{c}
auto c2 = new KMime::Content;
```

#### RANGE FOR STATEMENT 


```{c}
for (const Types::AddrSpec &addr : qAsConst(d->msgIdList)) {
        if (!addr.isEmpty()) {
            const QString asString = addr.asString();
            rv += '<';
            if (!asString.isEmpty()) {
                rv += asString.toLatin1(); // FIXME: change parsing to use QByteArrays
            }
            rv += "> ";
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &jt : qAsConst(result)) {
            cout << "result[" << j << "].displayName:\n"
                 << (jt).displayName
                 << endl;
            int i = 0;
            foreach (const auto &it, (jt).mailboxList) {
                cout << "result[" << j << "].mailboxList[" << i << "].displayName:\n"
                     << (it).name() << endl
                     << "result[" << j << "].mailboxList[" << i << "].addrSpec.localPart:\n"
                     << (it).addrSpec().localPart << endl
                     << "result[" << j << "].mailboxList[" << i << "].addrSpec.domain:\n"
                     << (it).addrSpec().domain
                     << endl;
                ++i;
            }
            ++j;
        }
```

#### AUTO 


```{c}
auto *html = new Content();
```

#### AUTO 


```{c}
auto *msg = new KMime::Message;
```

#### AUTO 


```{c}
auto *c11 = new Content();
```

#### AUTO 


```{c}
auto *h12 = new Supersedes();
```

#### AUTO 


```{c}
auto it = d->headers.begin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &it : qAsConst(maybeAddressList)) {
        if (!(it).displayName.isEmpty()) {
            KMIME_WARN << "mailbox groups in header disallowing them! Name: \""
                       << (it).displayName << "\""
              #if (QT_VERSION < QT_VERSION_CHECK(5, 15, 0))
                       << endl
              #else
                       << Qt::endl
              #endif
                          ;
        }
        d->mailboxList += (it).mailboxList;
    }
```

#### AUTO 


```{c}
auto *c2 = new Content();
```

#### AUTO 


```{c}
auto *h16 = new Subject();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &charset : std::as_const(c_harsetCache)) {
        if (qstricmp(name.data(), charset.data()) == 0) {
            return charset;
        }
    }
```

#### AUTO 


```{c}
const auto& mbox = d->mailboxList.at(0);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &it : mailboxList) {
            cout << "result.mailboxList[" << i << "].displayName:\n"
                 << (it).name() << endl
                 << "result.mailboxList[" << i << "].addrSpec.localPart:\n"
                 << (it).addrSpec().localPart << endl
                 << "result.mailboxList[" << i << "].addrSpec.domain:\n"
                 << (it).addrSpec().domain
                 << endl;
            ++i;
        }
```

#### AUTO 


```{c}
auto contents = msg->contents();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Types::Address &addr : std::as_const(d->addressList)) {
        const auto mailBoxList = addr.mailboxList;
        for (const Types::Mailbox &mbox : mailBoxList) {
            rv += mbox.as7BitString(d->encCS);
            rv += ", ";
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &it : std::as_const(maybeAddressList)) {
        if (!(it).displayName.isEmpty()) {
            KMIME_WARN << "mailbox groups in header disallowing them! Name: \""
                       << (it).displayName << "\""
                       << Qt::endl
                          ;
        }
        d->mailboxList += (it).mailboxList;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &s : l) {
        bool ok;
        unsigned int i = s.toUInt(&ok);
        if (!ok) {
            d->index.clear();
            break;
        }
        d->index.append(i);
    }
```

#### AUTO 


```{c}
const auto &jt
```

#### RANGE FOR STATEMENT 


```{c}
for (const Types::Address &addr : std::as_const(d->addressList)) {
        rv.reserve(rv.size() + addr.mailboxList.size());
        const auto mailboxList = addr.mailboxList;
        for (const Types::Mailbox &mbox : mailboxList) {
            rv.append(mbox.prettyAddress());
        }
    }
```

#### AUTO 


```{c}
auto result = msg->headersByType("Received");
```

#### AUTO 


```{c}
auto *h18 = new ContentDescription();
```

#### AUTO 


```{c}
const auto endIt = d->headers.end();
```

#### AUTO 


```{c}
auto *h = new Headers::Generics::MailboxList();
```

#### AUTO 


```{c}
auto *h9 = new MIMEVersion();
```

#### RANGE FOR STATEMENT 


```{c}
for (Content *c1 : contents) {
                if (c1->contentType()->mimeType() == type) {
                    return c1;
                }
            }
```

#### AUTO 


```{c}
auto *to = new KMime::Headers::To;
```

#### AUTO 


```{c}
auto *c = new Content();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &it : std::as_const(result.mailboxList)) {
            cout << "result.mailboxList[" << i << "].displayName:\n"
                 << (it).name() << endl
                 << "result.mailboxList[" << i << "].addrSpec.localPart:\n"
                 << (it).addrSpec().localPart << endl
                 << "result.mailboxList[" << i << "].addrSpec.domain:\n"
                 << (it).addrSpec().domain << endl;
            ++i;
        }
```

#### AUTO 


```{c}
auto *h7 = new ReplyTo();
```

#### AUTO 


```{c}
const auto msgIdList = d_func()->msgIdList;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &charset : qAsConst(c_harsetCache)) {
        if (qstricmp(name.data(), charset.data()) == 0) {
            return charset;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Types::Mailbox &mbox : mailboxList) {
            rv.append(mbox.address());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Content *c : contents) {
        ret += c->lineCount();
    }
```

#### AUTO 


```{c}
auto *h24 = new UserAgent();
```

#### AUTO 


```{c}
auto root = new KMime::Message;
```

#### RANGE FOR STATEMENT 


```{c}
for (const Types::Mailbox &mbox : qAsConst(d->mailboxList)) {
        if (mbox.hasName())
            rv.append(mbox.name());
        else
            rv.append(QString::fromLatin1(mbox.address()));
    }
```

#### AUTO 


```{c}
auto msg = readAndParseMail(QStringLiteral("reply-header.mbox"));
```

#### AUTO 


```{c}
auto sig = new KMime::Content;
```

#### RANGE FOR STATEMENT 


```{c}
for (const Types::Address &addr : qAsConst(d->addressList)) {
        rv.reserve(rv.size() + addr.mailboxList.size());
        foreach (const Types::Mailbox &mbox, addr.mailboxList) {
            rv.append(mbox.prettyAddress());
        }
    }
```

#### AUTO 


```{c}
auto *h17 = new Organization();
```

#### AUTO 


```{c}
auto header = extractHeader(head, headerStart, endOfFieldBody)
```

#### RANGE FOR STATEMENT 


```{c}
for (Content *c : contents) {
            if ((ret = c->textContent()) != nullptr) {
                break;
            }
        }
```

#### AUTO 


```{c}
auto *h1 = new Headers::Generic("Resent-From");
```

#### AUTO 


```{c}
auto parts = mpp.parts();
```

#### AUTO 


```{c}
auto *c1 = new Content();
```

#### AUTO 


```{c}
auto *h = new Headers::Generics::SingleMailbox();
```

#### AUTO 


```{c}
auto *msg = new Message();
```

#### AUTO 


```{c}
auto *h2 = new Headers::Generics::MailboxList();
```

#### AUTO 


```{c}
auto *top = const_cast<Content *>(this);
```

#### AUTO 


```{c}
auto *c12 = new Content();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Types::Mailbox &mbox : mailboxList) {
            rv.append(mbox.prettyAddress());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Types::Mailbox &mbox : std::as_const(d->mailboxList)) {
        rv += mbox.as7BitString(d->encCS);
        rv += ", ";
    }
```

#### AUTO 


```{c}
const auto mailboxList = (jt).mailboxList;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &it : mailboxList) {
                cout << "result[" << j << "].mailboxList[" << i << "].displayName:\n"
                     << (it).name() << endl
                     << "result[" << j << "].mailboxList[" << i << "].addrSpec.localPart:\n"
                     << (it).addrSpec().localPart << endl
                     << "result[" << j << "].mailboxList[" << i << "].addrSpec.domain:\n"
                     << (it).addrSpec().domain
                     << endl;
                ++i;
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Types::Mailbox &mbox : mailboxes) {
        rv.append(mbox.prettyAddress());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Types::Mailbox &mbox : std::as_const(d->mailboxList)) {
        if (mbox.hasName())
            rv.append(mbox.name());
        else
            rv.append(QString::fromLatin1(mbox.address()));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Types::Mailbox &mbox : mailboxList) {
            if (mbox.hasName())
                rv.append(mbox.name());
            else
                rv.append(QString::fromLatin1(mbox.address()));
        }
```

#### AUTO 


```{c}
const auto contents = c->contents();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &jt : std::as_const(result)) {
            cout << "result[" << j << "].displayName:\n"
                 << (jt).displayName
                 << endl;
            int i = 0;
            const auto mailboxList = (jt).mailboxList;
            for (const auto &it : mailboxList) {
                cout << "result[" << j << "].mailboxList[" << i << "].displayName:\n"
                     << (it).name() << endl
                     << "result[" << j << "].mailboxList[" << i << "].addrSpec.localPart:\n"
                     << (it).addrSpec().localPart << endl
                     << "result[" << j << "].mailboxList[" << i << "].addrSpec.domain:\n"
                     << (it).addrSpec().domain
                     << endl;
                ++i;
            }
            ++j;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (unsigned int i : qAsConst(d->index)) {
        l.append(QString::number(i));
    }
```

#### AUTO 


```{c}
auto *c3 = new Content();
```

#### AUTO 


```{c}
auto dt = QDateTime(QDate(2015, 5, 26), QTime(12, 34, 56));
```

#### AUTO 


```{c}
auto *msg = new Message;
```

#### RANGE FOR STATEMENT 


```{c}
for (Content *c : contents) {
            s += c->storageSize();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Types::Address &addr : addressList) {
        const auto mailboxList = addr.mailboxList;
        for (const Types::Mailbox &mbox : mailboxList) {
            rv.append(mbox.address());
        }
    }
```

#### AUTO 


```{c}
auto *h8 = new Keywords();
```

#### AUTO 


```{c}
auto *h22 = new FollowUpTo();
```

#### RANGE FOR STATEMENT 


```{c}
for (Content *child : contentsList) {
            if (isAttachment(child)) {
                result.push_back(child);
            } else {
                result += child->attachments();
            }
        }
```

#### AUTO 


```{c}
auto *c4 = new Content();
```

#### AUTO 


```{c}
auto ids = h->identifiers();
```

#### AUTO 


```{c}
const auto contentsList = contents();
```

#### AUTO 


```{c}
auto *mimeVersion = header<Headers::MIMEVersion>(true);
```

#### AUTO 


```{c}
const auto mailboxList = result.mailboxList;
```

#### AUTO 


```{c}
auto *text = new Content();
```

#### RANGE FOR STATEMENT 


```{c}
for (Content *c : contentsList) {
        c->assemble();
    }
```

#### AUTO 


```{c}
auto mixed = root->contents().at(0);
```

#### AUTO 


```{c}
auto list = msg->contents();
```

#### AUTO 


```{c}
auto c = new KMime::Content;
```

#### AUTO 


```{c}
auto *c = new Content(q);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Types::Address &addr : std::as_const(d->addressList)) {
        const auto mailboxList = addr.mailboxList;
        for (const Types::Mailbox &mbox : mailboxList) {
            if (mbox.hasName())
                rv.append(mbox.name());
            else
                rv.append(QString::fromLatin1(mbox.address()));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Types::Address &addr : addressList) {
        const auto mailboxList = addr.mailboxList;
        for (const Types::Mailbox &mbox : mailboxList) {
            rv.append(mbox);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &line : lines) {
        QEXPECT_FAIL("", "KMime does not fold lines longer than 998 characters", Continue);
        QVERIFY(line.length() < 998 && !line.isEmpty() && line != QLatin1String("body"));
        // The test should be (after the expected failure disappears):
        //QVERIFY( line.length() < 998 );
    }
```

#### AUTO 


```{c}
auto header = extractHeader(head, 0, endOfFieldBody);
```

#### AUTO 


```{c}
auto msg = readAndParseMail(QStringLiteral("kmail-attachmentstatus.mbox"));
```

#### AUTO 


```{c}
const auto contentType = content->contentType(false);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Types::Mailbox &mbox : mailBoxList) {
            rv += mbox.as7BitString(d->encCS);
            rv += ", ";
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Headers::Base *h : std::as_const(d->headers)) {
        if (!h->isEmpty()) {
            newHead += h->as7BitString() + '\n';
        }
    }
```

#### AUTO 


```{c}
const auto contents = content->contents();
```

#### AUTO 


```{c}
auto cte = contentTransferEncoding();
```

#### RANGE FOR STATEMENT 


```{c}
for (Content *c : qAsConst(d->multipartContents)) {
            e += boundary + '\n';
            e += c->encodedContent(false);    // don't convert LFs here, we do that later!!!!!
        }
```

#### AUTO 


```{c}
auto *h = new Headers::Generics::AddressList();
```

#### RANGE FOR STATEMENT 


```{c}
for (Content *child : contents) {
            if (hasAttachment(child)) {
                return true;
            }
        }
```

#### AUTO 


```{c}
auto ct = content->contentType(false);
```

