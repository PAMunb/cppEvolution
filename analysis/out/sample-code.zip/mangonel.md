#### RANGE FOR STATEMENT 


```{c}
for (const QString &child : settings.childGroups()) {
            settings.beginGroup(child);
            const QString childPath = (path.isEmpty() ? "/" : "") + path + key + "/" + child + "/";
            QHash<QString, Popularity> children = getRecursivePopularity(settings, childPath);
            QHash<QString, Popularity>::const_iterator i = children.constBegin();
            while (i != children.constEnd()) {
                ret.insert(i.key(), i.value());
                ++i;
            }
            settings.endGroup();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Provider* provider : m_providers) {
        QList<ProviderResult*> list = provider->getResults(query);
        for (ProviderResult *app : list) {
            if (!app) {
                qWarning() << "got null app from" << provider;
                continue;
            }
            if (app->name.isEmpty()) {
                qWarning() << "empty name!" << app->name << app->program << app->completion;
                continue;
            }
            QQmlEngine::setObjectOwnership(app, QQmlEngine::JavaScriptOwnership);
            app->setParent(this);

            if (!app->isCalculation) {
                if (m_popularities.contains(app->program)) {
                    const Popularity &popularity = m_popularities[app->program];
                    app->priority = QDateTime::currentSecsSinceEpoch() - popularity.lastUse;
                    app->priority -= (3600 * 360) * popularity.count;
                }
            }

            newResults.append(app);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QFileInfo &file : QDir(path).entryInfoList(QStringList("*.desktop"))) {
        Application app = loadDesktopFile(file);
        if (!app.isValid()) {
            continue;
        }
        m_applications[file.absoluteFilePath()] = app;
    }
```

#### AUTO 


```{c}
auto i = dimension.constBegin();
```

#### LAMBDA EXPRESSION 


```{c}
[this](ProviderResult *a, ProviderResult *b) {
            Q_ASSERT(a);
            Q_ASSERT(b);

            if (a->isCalculation != b->isCalculation) {
                if (a->isCalculation) {
                    return true;
                }
                if (b->isCalculation) {
                    return false;
                }
            }

            const bool aStartMatch = a->name.startsWith(m_currentQuery, Qt::CaseInsensitive);
            const bool bStartMatch = b->name.startsWith(m_currentQuery, Qt::CaseInsensitive);
            if (aStartMatch != bStartMatch) {
                return aStartMatch && !bStartMatch;
            }

            const bool aContains = a->name.contains(m_currentQuery, Qt::CaseInsensitive);
            const bool bContains = b->name.contains(m_currentQuery, Qt::CaseInsensitive);
            if (aContains != bContains) {
                return aContains && !bContains;
            }
            if (m_popularities.contains(a->program)) {
                if (!m_popularities.contains(b->program)) {
                    return true;
                }

                const Popularity &aPopularity = m_popularities[a->program];
                const Popularity &bPopularity = m_popularities[b->program];
                if (aPopularity.count != bPopularity.count) {
                    return aPopularity.count > bPopularity.count;
                }

                return aPopularity.lastUse > bPopularity.lastUse;
            }

            if (a->priority != b->priority) {
                return a->priority < b->priority;
            }

            return a->name > b->name;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Unit& u : unitList) {
        m_variables[u.name] = u.value;
    }
```

#### AUTO 


```{c}
auto i = n1.m_dimension.constBegin();
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString& s) { return s.toLower(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](ProviderResult *a, ProviderResult *b) {
            Q_ASSERT(a);
            Q_ASSERT(b);

            if (a->isCalculation != b->isCalculation) {
                return a->isCalculation;
            }

            bool aStartMatch = a->name.startsWith(m_currentQuery, Qt::CaseInsensitive);
            bool bStartMatch = b->name.startsWith(m_currentQuery, Qt::CaseInsensitive);
            if (aStartMatch != bStartMatch) {
                return aStartMatch;
            }

            aStartMatch = a->program.startsWith(m_currentQuery, Qt::CaseInsensitive);
            bStartMatch = b->program.startsWith(m_currentQuery, Qt::CaseInsensitive);
            if (aStartMatch != bStartMatch) {
                return aStartMatch;
            }

            const bool aContains = a->name.contains(m_currentQuery, Qt::CaseInsensitive) ||
                                    a->program.contains(m_currentQuery, Qt::CaseInsensitive);
            const bool bContains = b->name.contains(m_currentQuery, Qt::CaseInsensitive) ||
                                    b->program.contains(m_currentQuery, Qt::CaseInsensitive);
            if (aContains != bContains) {
                return aContains;
            }

            if (m_popularities.contains(a->program)) {
                if (!m_popularities.contains(b->program)) {
                    return true;
                }

                const Popularity &aPopularity = m_popularities[a->program];
                const Popularity &bPopularity = m_popularities[b->program];

                const bool aHasMatchStrings = aPopularity.matchStrings.contains(m_currentQuery);
                const bool bHasMatchStrings = bPopularity.matchStrings.contains(m_currentQuery);
                if (aHasMatchStrings != bHasMatchStrings) {
                    return aHasMatchStrings;
                }

                if (aPopularity.count != bPopularity.count) {
                    return aPopularity.count > bPopularity.count;
                }

                if (aPopularity.lastUse != bPopularity.lastUse) {
                    return aPopularity.lastUse > bPopularity.lastUse;
                }
            }

            if (a->priority != b->priority) {
                return a->priority < b->priority;
            }

            if (a->name != b->name) {
                return a->name > b->name;
            }

            // They are 100% equal
            return false;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KUnitConversion::UnitCategory &candidateCategory : m_converter.categories()) {
            units.append(findCompatibleUnits(name, candidateCategory, OnlyCommonUnits));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &candidateName : category.allUnits()) {
        if (name.compare(candidateName, Qt::CaseInsensitive)) {
            continue;
        }

        KUnitConversion::Unit candidate = category.unit(candidateName);
        if (level == OnlyCommonUnits && !commonIds.contains(candidate.id())) {
            continue;
        }

        if (candidate.isValid()) {
            return candidate;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &program : toRemove) {
        m_index.remove(program);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QFileInfo &path : paths) {
        ProviderResult *result = new ProviderResult();

        result->program = path.absoluteFilePath();

        static const QString homePath = QDir::homePath();
        if (result->program.startsWith(homePath)) {
            result->name = path.absoluteFilePath().mid(homePath.length());
            result->completion = "~" + result->name.left(result->name.lastIndexOf("/")) + "/" + path.fileName();
        } else {
            result->name = path.absoluteFilePath();
            result->completion = result->name.left(result->name.lastIndexOf("/")) + "/" + path.fileName();
        }
        result->priority = QDateTime::currentSecsSinceEpoch() - path.lastModified().toSecsSinceEpoch();
        if (path.isDir()) {
            result->completion += "/";
            result->icon = "system-file-manager";
        } else {
            result->icon = m_mimeDb.mimeTypeForFile(path.absoluteFilePath()).iconName();
        }

        result->object = this;
        result->type = i18n("Open path");
        list.append(result);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &fullProgramPath : m_index.values()) {
        if (!fullProgramPath.startsWith(path)) {
            continue;
        }

        QFileInfo programInfo(fullProgramPath);
        if (programInfo.dir().path() == path) {
            toRemove.append(programInfo.fileName());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QFileInfo &file : list) {
        const QString canonicalPath = file.canonicalFilePath();

        if (file.isFile() && file.isExecutable()) {
            m_index[file.fileName()] = canonicalPath;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](ProviderResult *a, ProviderResult *b) {
            Q_ASSERT(a);
            Q_ASSERT(b);

            if (a->isCalculation != b->isCalculation) {
                if (a->isCalculation) {
                    return true;
                }
                if (b->isCalculation) {
                    return false;
                }
            }

            const bool aStartMatch = a->name.startsWith(m_currentQuery, Qt::CaseInsensitive) ||
                                        a->program.startsWith(m_currentQuery, Qt::CaseInsensitive);
            const bool bStartMatch = b->name.startsWith(m_currentQuery, Qt::CaseInsensitive) ||
                                        b->program.startsWith(m_currentQuery, Qt::CaseInsensitive);
            if (aStartMatch != bStartMatch) {
                return aStartMatch && !bStartMatch;
            }

            const bool aContains = a->name.contains(m_currentQuery, Qt::CaseInsensitive) ||
                                    a->program.contains(m_currentQuery, Qt::CaseInsensitive);
            const bool bContains = b->name.contains(m_currentQuery, Qt::CaseInsensitive) ||
                                    b->program.contains(m_currentQuery, Qt::CaseInsensitive);
            if (aContains != bContains) {
                return aContains && !bContains;
            }
            if (m_popularities.contains(a->program)) {
                if (!m_popularities.contains(b->program)) {
                    return true;
                }

                const Popularity &aPopularity = m_popularities[a->program];
                const Popularity &bPopularity = m_popularities[b->program];
                if (aPopularity.count != bPopularity.count) {
                    return aPopularity.count > bPopularity.count;
                }

                if (aPopularity.lastUse != bPopularity.lastUse) {
                    return aPopularity.lastUse > bPopularity.lastUse;
                }
            }

            if (a->priority != b->priority) {
                return a->priority < b->priority;
            }

            if (a->name != b->name) {
                return a->name > b->name;
            }

            // They are 100% equal
            return false;
    }
```

#### AUTO 


```{c}
auto& token
```

#### RANGE FOR STATEMENT 


```{c}
for (ProviderResult *app : list) {
                app->setParent(this);

                if (app->isCalculation) {
                    m_apps.append(app);
                    continue;
                }
                if (m_popularities.contains(app->program)) {
                    const Popularity &popularity = m_popularities[app->program];
                    app->priority = QDateTime::currentSecsSinceEpoch() - popularity.lastUse;
                    app->priority -= (3600 * 360) * popularity.count;

                    if (popularity.matchStrings.contains(query)) {
                        app->priority /= 2;
                    }
                }

                m_apps.append(app);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[](float val1, float val2) { return val1 + val2; }
```

#### LAMBDA EXPRESSION 


```{c}
[](float val1, float val2) { return fmod(val1, val2); }
```

#### LAMBDA EXPRESSION 


```{c}
[](double val1, double val2) { return val1 - val2; }
```

#### AUTO 


```{c}
auto i = other.m_dimension.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (QPointer<ProviderResult> app : m_apps) {
        ret.append(app.data());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &dir : getPathEnv()) {
        index.unite(walkDir(dir));
    }
```

#### AUTO 


```{c}
const auto& _tokens = tokens;
```

#### AUTO 


```{c}
auto exponent = i.value().toString();
```

#### RANGE FOR STATEMENT 


```{c}
for (QChar& ch : result) {
        if (ch.isSpace()) {
            ++emptySpaces;
            if (emptySpaces > 1) {
                ch = u'⋅';
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &dir : parsePathEnv()) {
        m_fsWatcher->addPath(dir);
        walkDir(dir);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](QQmlEngine *, QJSEngine*) -> QObject* {
        QQmlEngine::setObjectOwnership(Mangonel::instance(), QQmlEngine::CppOwnership);
        return Mangonel::instance();
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr int INVALID_PRECEDENCE = INT_MIN;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &dirPath : QStandardPaths::standardLocations(QStandardPaths::ApplicationsLocation)) {
        m_fsWatcher->addPath(dirPath);
        loadDir(dirPath);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &candidateName : category.allUnits()) {
        QString simpleCandidateName = candidateName.toLower();
        simpleCandidateName.remove(nonAlphaRegex);
        if (simpleCandidateName.startsWith(simpleName)) {
            units.append(category.unit(candidateName));
        }

        if (name.compare(candidateName, Qt::CaseInsensitive)) {
            continue;
        }

        KUnitConversion::Unit candidate = category.unit(candidateName);
        if (level == OnlyCommonUnits && !commonIds.contains(candidate.id())) {
            continue;
        }

        if (candidate.isValid()) {
            return {candidate};
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &key : m_popularities.keys()) {
        settings.beginGroup(key);
        settings.setValue("launches", m_popularities[key].count);
        settings.setValue("lastUse", m_popularities[key].lastUse);
        settings.endGroup();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Provider* provider : m_providers) {
        timer.restart();
        QList<ProviderResult*> list = provider->getResults(query);
        if (timer.elapsed() > 30) {
            qWarning() << provider << "spent" << timer.elapsed() << "ms on" << query;
        }
        for (ProviderResult *app : list) {
            if (!app) {
                qWarning() << "got null app from" << provider;
                continue;
            }
            if (app->name.isEmpty()) {
                qWarning() << "empty name!" << app->name << app->program << app->completion;
                continue;
            }
            QQmlEngine::setObjectOwnership(app, QQmlEngine::JavaScriptOwnership);
            app->setParent(this);

            if (!app->isCalculation) {
                if (m_popularities.contains(app->program)) {
                    const Popularity &popularity = m_popularities[app->program];
                    app->priority = currentSecsSinceEpoch - popularity.lastUse;
                    app->priority -= (3600 * 360) * popularity.count;
                }
            }

            newResults.append(app);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Unit& u : unitList) {
        m_variables[u.name] = u.value;
        m_allUnits.insert(u.name);
        const QString fixed = u.name.toLower().replace('_', ' ');
        if (fixed != u.name) {
            m_unitFixups[fixed] = u.name;
        }
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr int MAX_PRECEDENCE = INT_MAX;
```

#### RANGE FOR STATEMENT 


```{c}
for (ProviderResult *result : newResults) {
        ret.append(result);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &candidateName : category.allUnits()) {
        QString simpleCandidateName = candidateName.toLower();
        simpleCandidateName.remove(nonAlphaRegex);
        if (simpleCandidateName.startsWith(simpleName)) { // TODO: return multiple matches
            fallback = category.unit(candidateName);
        }

        if (name.compare(candidateName, Qt::CaseInsensitive)) {
            continue;
        }

        KUnitConversion::Unit candidate = category.unit(candidateName);
        if (level == OnlyCommonUnits && !commonIds.contains(candidate.id())) {
            continue;
        }

        if (candidate.isValid()) {
            return candidate;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (ProviderResult *app : list) {
            if (!app) {
                qWarning() << "got null app from" << provider;
                continue;
            }
            app->setParent(this);

            if (app->isCalculation) {
                m_apps.append(app);
                continue;
            }

            if (m_popularities.contains(app->program)) {
                const Popularity &popularity = m_popularities[app->program];
                app->priority = QDateTime::currentSecsSinceEpoch() - popularity.lastUse;
                app->priority -= (3600 * 360) * popularity.count;

                if (popularity.matchStrings.contains(query)) {
                    app->priority /= 2;
                }
            }

            m_apps.append(app);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QPointer<Application> app : m_apps) {
        if (!app) {
            continue;
        }

        app->deleteLater();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& token : _tokens) {
        if (computeMinPrec) {
            Token::Operator op = token.asOperator();
            if (op != Token::Invalid) {
                int prec = opPrecedence(op);
                if (prec < min_prec)
                    min_prec = prec;
            }
        }

        if (token.pos() == -1 && token.size() == -1)
            continue;

        if (token.pos() == -1 || token.size() == -1) {

#ifdef EVALUATOR_DEBUG
            qDebug() << "BUG: found token with either pos or size not set, "
                        "but not both.";
#endif  // EVALUATOR_DEBUG
            continue;
        }

        if (start == -1) {
            start = token.pos();
        } else {

#ifdef EVALUATOR_DEBUG
            if (token.pos() != end)
                qDebug() << "BUG: tokens expressions are not successive.";
#endif  // EVALUATOR_DEBUG

        }

        end = token.pos() + token.size();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QFileInfo &path : paths) {
        ProviderResult *result = new ProviderResult();
        result->name = subUser(path.absoluteFilePath());
        result->completion = result->name.left(result->name.lastIndexOf("/")) + "/" + path.fileName();
        QFileInfo info(path.absoluteFilePath());
        result->priority = QDateTime::currentSecsSinceEpoch() - info.lastModified().toSecsSinceEpoch();
        if (path.isDir()) {
            result->completion += "/";
            result->icon = "system-file-manager";
        } else {
            result->icon = m_mimeDb.mimeTypeForFile(path.absoluteFilePath()).iconName();
        }

        result->object = this;
        result->program = path.absoluteFilePath();
        result->type = i18n("Open path");
        list.append(result);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](ProviderResult *a, ProviderResult *b) {
            Q_ASSERT(a);
            Q_ASSERT(b);

            if (a->isCalculation != b->isCalculation) {
                return a->isCalculation;
            }

            const bool aContains = a->name.contains(m_currentQuery, Qt::CaseInsensitive) ||
                                    a->program.contains(m_currentQuery, Qt::CaseInsensitive);
            const bool bContains = b->name.contains(m_currentQuery, Qt::CaseInsensitive) ||
                                    b->program.contains(m_currentQuery, Qt::CaseInsensitive);
            if (aContains != bContains) {
                return aContains;
            }

            const bool aHasPopularity = m_popularities.contains(a->program);
            const bool bHasPopularity = m_popularities.contains(b->program);
            if (aHasPopularity != bHasPopularity) {
                return aHasPopularity;
            }

            if (aHasPopularity && bHasPopularity) {
                const Popularity &aPopularity = m_popularities[a->program];
                const Popularity &bPopularity = m_popularities[b->program];

                const bool aHasMatchStrings = aPopularity.matchStrings.contains(m_currentQuery);
                const bool bHasMatchStrings = bPopularity.matchStrings.contains(m_currentQuery);
                if (aHasMatchStrings != bHasMatchStrings) {
                    return aHasMatchStrings;
                }

                if (aPopularity.count != bPopularity.count) {
                    return aPopularity.count > bPopularity.count;
                }

                if (aPopularity.lastUse != bPopularity.lastUse) {
                    return aPopularity.lastUse > bPopularity.lastUse;
                }
            }

            bool aStartMatch = a->name.startsWith(m_currentQuery, Qt::CaseInsensitive);
            bool bStartMatch = b->name.startsWith(m_currentQuery, Qt::CaseInsensitive);
            if (aStartMatch != bStartMatch) {
                return aStartMatch;
            }

            aStartMatch = a->program.startsWith(m_currentQuery, Qt::CaseInsensitive);
            bStartMatch = b->program.startsWith(m_currentQuery, Qt::CaseInsensitive);
            if (aStartMatch != bStartMatch) {
                return aStartMatch;
            }

            if (a->priority != b->priority) {
                return a->priority < b->priority;
            }

            if (a->name != b->name) {
                return a->name > b->name;
            }

            // They are 100% equal
            return false;
    }
```

#### AUTO 


```{c}
auto imag = HMath::arccos(x.real / abs);
```

#### RANGE FOR STATEMENT 


```{c}
for (ProviderResult *app : list) {
            if (!app) {
                qWarning() << "got null app from" << provider;
                continue;
            }
            if (app->name.isEmpty()) {
                qWarning() << "empty name!" << app->name << app->program << app->completion;
                continue;
            }
            QQmlEngine::setObjectOwnership(app, QQmlEngine::JavaScriptOwnership);
            app->setParent(this);

            if (!app->isCalculation) {
                if (m_popularities.contains(app->program)) {
                    const Popularity &popularity = m_popularities[app->program];
                    app->priority = QDateTime::currentSecsSinceEpoch() - popularity.lastUse;
                    app->priority -= (3600 * 360) * popularity.count;
                }
            }

            newResults.append(app);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QFileInfo &file : list) {
        if (file.isDir()) {
            if (file.isSymLink() && file.canonicalFilePath() != path) {
                binList.unite(walkDir(file.absoluteFilePath()));
            }
        } else {
            if (file.isExecutable()) {
                binList.insert(file.fileName(), file.absoluteFilePath());
            }
        }
    }
```

#### AUTO 


```{c}
auto i = list.begin();
```

#### RANGE FOR STATEMENT 


```{c}
for (Provider* provider : m_providers) {
            QList<ProviderResult*> list = provider->getResults(query);
            for (ProviderResult *app : list) {
                app->setParent(this);

                if (app->isCalculation) {
                    m_apps.append(app);
                    continue;
                }
                if (m_popularities.contains(app->program)) {
                    const Popularity &popularity = m_popularities[app->program];
                    app->priority = QDateTime::currentSecsSinceEpoch() - popularity.lastUse;
                    app->priority -= (3600 * 360) * popularity.count;

                    if (popularity.matchStrings.contains(query)) {
                        app->priority /= 2;
                    }
                }

                m_apps.append(app);
            }
        }
```

#### AUTO 


```{c}
auto& name = i.key();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& key : legacy->allKeys())
            settings->setValue(key, legacy->value(key));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QFileInfo &file : list) {
        const QString canonicalPath = file.canonicalFilePath();

        if (file.isFile() && file.isExecutable()) {
            m_index[file.fileName()] = canonicalPath;
            m_modified[file.fileName()] = file.lastModified().toSecsSinceEpoch();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](float val1, float val2) { return val1 / val2; }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& ch : result) {
            if (ch.isSpace()) {
                ++emptySpaces;
                if (emptySpaces > 1)
                    ch = u'⋅';
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& ch : result) {
        if (ch.isSpace()) {
            ++emptySpaces;
            if (emptySpaces > 1)
                ch = u'⋅';
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Application &application : m_applications) {
        if (!application.keywords.contains(term)) {
            continue;
        }
        ProviderResult *app = createApp(application);
        if (app->name.isEmpty()) {
            delete app;
            continue;
        }
        app->priority = currentSecsSinceEpoch - app->priority;
        //if (service->isApplication()) app->priority *= 1.1;

        list.append(app);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KUnitConversion::UnitCategory &candidateCategory : m_converter.categories()) {
            unit = matchUnitCaseInsensitive(name, candidateCategory, AllUnits);
            if (unit.isValid()) {
                return unit;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QPointer<ProviderResult> app : m_apps) {
        if (!app) {
            continue;
        }

        app->deleteLater();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KUnitConversion::Unit &outputUnit : resolveUnitName(match.captured(3), inputUnit.category())) {
            if (usedOutputs.contains(outputUnit.id())) {
                continue;
            }
            usedOutputs.insert(outputUnit.id());

            const KUnitConversion::Value inputValue(inputNumber, inputUnit);

            ProviderResult *result = createResult(inputUnit, inputValue, outputUnit);
            result->priority = priority++;
            list.append(result);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](double val1, double val2) { return val1 * val2; }
```

#### LAMBDA EXPRESSION 


```{c}
[](Application *a, Application *b) {
            if (a->priority != b->priority) {
                return a->priority < b->priority;
            } else {
                return a->name > b->name;
            }
        }
```

#### AUTO 


```{c}
auto val = m_constants.at(c);
```

#### RANGE FOR STATEMENT 


```{c}
for(const QFileInfo &path : paths) {
        ProviderResult *result = new ProviderResult();
        result->name = subUser(path.absoluteFilePath());
        result->completion = result->name.left(result->name.lastIndexOf("/")) + "/" + path.fileName();
        QFileInfo info(path.absoluteFilePath());
        result->priority = info.lastModified().toSecsSinceEpoch();
        if (path.isDir()) {
            result->completion += "/";
            result->icon = "system-file-manager";
        } else {
            result->icon = m_mimeDb.mimeTypeForFile(path.absoluteFilePath()).iconName();
        }

        result->object = this;
        result->program = path.absoluteFilePath();
        result->type = i18n("Open path");
        list.append(result);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QGlobalShortcut* s : shortcuts_.values(id)) {
            emit s->activated();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString &name : paths) {
        const QFileInfo path(dir.filePath(name));
        ProviderResult *result = new ProviderResult();

        result->program = path.absoluteFilePath();

        if (result->program.startsWith(homePath)) {
            result->name = result->program.mid(homePath.length());
            result->completion = "~" + result->name.left(result->name.lastIndexOf("/")) + "/" + path.fileName();
        } else {
            result->name = result->program;
            result->completion = result->name.left(result->name.lastIndexOf("/")) + "/" + path.fileName();
        }
        result->priority = currentSecsSinceEpoch - path.lastModified().toSecsSinceEpoch();
        if (path.isDir()) {
            result->completion += "/";
            result->icon = "system-file-manager";
        } else {
            result->icon = m_mimeDb.mimeTypeForFile(path).iconName();
        }

        result->object = this;
        result->type = i18n("Open path");
        list.append(result);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](double val1, double val2) { return val1 / val2; }
```

#### RANGE FOR STATEMENT 


```{c}
for (Provider* provider : m_providers) {
        QList<ProviderResult*> list = provider->getResults(query);
        for (ProviderResult *app : list) {
            app->setParent(this);

            if (app->isCalculation) {
                m_apps.append(app);
                continue;
            }

            if (m_popularities.contains(app->program)) {
                const Popularity &popularity = m_popularities[app->program];
                app->priority = QDateTime::currentSecsSinceEpoch() - popularity.lastUse;
                app->priority -= (3600 * 360) * popularity.count;

                if (popularity.matchStrings.contains(query)) {
                    app->priority /= 2;
                }
            }

            m_apps.append(app);
        }
    }
```

#### AUTO 


```{c}
auto& key
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &path : pathList) {
        const QString canonicalPath = QFileInfo(path).canonicalFilePath();
        if (canonicalPath.isEmpty()) {
            continue;
        }
        absPathList.append(canonicalPath);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Application *app : list) {
                app->setParent(this);
                m_apps.append(app);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (ProviderResult *app : list) {
            if (!app) {
                qWarning() << "got null app from" << provider;
                continue;
            }
            if (app->name.isEmpty()) {
                qWarning() << "empty name!" << app->name << app->program << app->completion;
                continue;
            }
            QQmlEngine::setObjectOwnership(app, QQmlEngine::JavaScriptOwnership);
            app->setParent(this);

            if (!app->isCalculation) {
                if (m_popularities.contains(app->program)) {
                    const Popularity &popularity = m_popularities[app->program];
                    app->priority = currentSecsSinceEpoch - popularity.lastUse;
                    app->priority -= (3600 * 360) * popularity.count;
                }
            }

            newResults.append(app);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Provider* provider : m_providers) {
        QList<ProviderResult*> list = provider->getResults(query);
        for (ProviderResult *app : list) {
            if (!app) {
                qWarning() << "got null app from" << provider;
                continue;
            }
            app->setParent(this);

            if (app->isCalculation) {
                m_apps.append(app);
                continue;
            }

            if (m_popularities.contains(app->program)) {
                const Popularity &popularity = m_popularities[app->program];
                app->priority = QDateTime::currentSecsSinceEpoch() - popularity.lastUse;
                app->priority -= (3600 * 360) * popularity.count;

                if (popularity.matchStrings.contains(query)) {
                    app->priority /= 2;
                }
            }

            m_apps.append(app);
        }
    }
```

#### AUTO 


```{c}
const auto& exp = i.value();
```

#### RANGE FOR STATEMENT 


```{c}
for (const KUnitConversion::Unit &inputUnit : resolveUnitName(match.captured(2))) {
        if (usedInputs.contains(inputUnit.id())) {
            continue;
        }
        usedInputs.insert(inputUnit.id());
        for (const KUnitConversion::Unit &outputUnit : resolveUnitName(match.captured(3), inputUnit.category())) {
            if (usedOutputs.contains(outputUnit.id())) {
                continue;
            }
            usedOutputs.insert(outputUnit.id());

            const KUnitConversion::Value inputValue(inputNumber, inputUnit);

            ProviderResult *result = createResult(inputUnit, inputValue, outputUnit);
            result->priority = priority++;
            list.append(result);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &key : settings.childGroups()) {
        settings.beginGroup(key);
        Popularity pop;
        const QString program = settings.value("program").toString();
        pop.count = settings.value("launches").toLongLong();
        pop.lastUse = settings.value("lastUse").toLongLong();
        pop.matchStrings = settings.value("matchStrings").toStringList();
        m_popularities.insert(program, pop);
        settings.endGroup();
    }
```

#### AUTO 


```{c}
auto key = dim_json.keys().at(i);
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QPointer<ProviderResult> &a, const QPointer<ProviderResult> &b) {
            Q_ASSERT(a);
            Q_ASSERT(b);

            if (a->isCalculation != b->isCalculation) {
                if (a->isCalculation) {
                    return true;
                }
                if (b->isCalculation) {
                    return false;
                }
            }

            const bool aStartMatch = a->name.startsWith(query, Qt::CaseInsensitive);
            const bool bStartMatch = b->name.startsWith(query, Qt::CaseInsensitive);
            if (aStartMatch != bStartMatch) {
                return aStartMatch && !bStartMatch;
            }

            const bool aContains = a->name.contains(query, Qt::CaseInsensitive);
            const bool bContains = b->name.contains(query, Qt::CaseInsensitive);
            if (aContains != bContains) {
                return aContains && !bContains;
            }
            if (m_popularities.contains(a->program)) {
                if (!m_popularities.contains(b->program)) {
                    return true;
                }

                const Popularity &aPopularity = m_popularities[a->program];
                const Popularity &bPopularity = m_popularities[b->program];
                if (aPopularity.count >= bPopularity.count) {
                    return aPopularity.count >= bPopularity.count;
                }

                return aPopularity.lastUse > bPopularity.lastUse;
            }

            if (a->priority != b->priority) {
                return a->priority < b->priority;
            }

            return a->name > b->name;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](double val1, double val2) { return fmod(val1, val2); }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QChar op : operators) {
        int index = query.indexOf(op);

        if (index == 0) {
            index = query.indexOf(op, 1);
        }

        if (index < 0) {
            continue;
        }

        if (!s_functions.contains(query.at(index-1))) {
            oper = op;
            values = query.split(op);
            break;
        }
    }
```

#### AUTO 


```{c}
const auto& name = i.key();
```

#### RANGE FOR STATEMENT 


```{c}
for(const QFileInfo &path : paths) {
        Application *result = new Application();
        result->name = subUser(path.absoluteFilePath());
        result->completion = result->name.left(result->name.lastIndexOf("/")) + "/" + path.fileName();
        QFileInfo info(path.absoluteFilePath());
        result->priority = info.lastModified().toSecsSinceEpoch();
        if (path.isDir()) {
            result->completion += "/";
            result->icon = "system-file-manager";
        } else {
            result->icon = m_mimeDb.mimeTypeForFile(path.absoluteFilePath()).iconName();
        }

        result->object = this;
        result->program = path.absoluteFilePath();
        result->type = i18n("Open path");
        list.append(result);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &key : settings.childGroups()) {
        settings.beginGroup(key);
        const QString program = path + key;
        Popularity pop;
        pop.count = settings.value("launches").toLongLong();
        pop.lastUse = settings.value("lastUse").toLongLong();
        pop.matchStrings = settings.value("matchStrings").toStringList();

        if (pop.count || pop.lastUse || !pop.matchStrings.isEmpty()) {
            ret.insert(program, pop);
        }

        for (const QString &child : settings.childGroups()) {
            settings.beginGroup(child);
            const QString childPath = (path.isEmpty() ? "/" : "") + path + key + "/" + child + "/";
            QHash<QString, Popularity> children = getRecursivePopularity(settings, childPath);
            QHash<QString, Popularity>::const_iterator i = children.constBegin();
            while (i != children.constEnd()) {
                ret.insert(i.key(), i.value());
                ++i;
            }
            settings.endGroup();
        }

        settings.endGroup();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](double val1, double val2) { return val1 + val2; }
```

#### AUTO 


```{c}
auto tokenType = token.type();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &key : m_popularities.keys()) {
        // QSettings is dumb and annoying
        const QByteArray hashedProgram = QCryptographicHash::hash(key.toUtf8(), QCryptographicHash::Md5).toHex();
        settings.beginGroup(QString::fromLatin1(hashedProgram));
        settings.setValue("program", key);
        settings.setValue("launches", m_popularities[key].count);
        settings.setValue("lastUse", m_popularities[key].lastUse);
        settings.setValue("matchStrings", m_popularities[key].matchStrings);
        settings.endGroup();
    }
```

#### CONST EXPRESSION 


```{c}
constexpr unsigned DIGIT_MAP_COUNT = 128;
```

#### RANGE FOR STATEMENT 


```{c}
for (const KUnitConversion::UnitCategory &candidateCategory : m_converter.categories()) {
            units.append(findCompatibleUnits(name, candidateCategory, AllUnits));
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](float val1, float val2) { return pow(val1, val2); }
```

#### AUTO 


```{c}
auto strNotation = json["form"].toString();
```

#### RANGE FOR STATEMENT 


```{c}
for (const KService::Ptr &service : services) {
        if (service->noDisplay()) {
            continue;
        }
        
        ProviderResult *app = createApp(service);
        if (app->name.isEmpty()) {
            delete app;
            continue;
        }
        if (service->isApplication()) app->priority *= 1.1;

        list.append(app);
    }
```

#### AUTO 


```{c}
auto dimension = q.getDimension();
```

#### AUTO 


```{c}
auto i = m_dimension.constBegin();
```

#### LAMBDA EXPRESSION 


```{c}
[](double val1, double val2) { return pow(val1, val2); }
```

#### AUTO 


```{c}
auto i = n.m_dimension.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &key : m_popularities.keys()) {
        settings.beginGroup(key);
        settings.setValue("launches", m_popularities[key].count);
        settings.setValue("lastUse", m_popularities[key].lastUse);
        settings.setValue("matchString", m_popularities[key].matchStrings);
        settings.endGroup();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &program : toRemove) {
        m_index.remove(program);
        m_modified.remove(program);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&](ProviderResult *a, ProviderResult *b) {
            if (a->isCalculation != b->isCalculation) {
                if (a->isCalculation) {
                    return true;
                }
                if (b->isCalculation) {
                    return false;
                }
            }

            const bool aStartMatch = a->name.startsWith(query, Qt::CaseInsensitive);
            const bool bStartMatch = b->name.startsWith(query, Qt::CaseInsensitive);
            if (aStartMatch != bStartMatch) {
                return aStartMatch && !bStartMatch;
            }

            const bool aContains = a->name.contains(query, Qt::CaseInsensitive);
            const bool bContains = b->name.contains(query, Qt::CaseInsensitive);
            if (aContains != bContains) {
                return aContains && !bContains;
            }
            if (m_popularities.contains(a->program)) {
                if (!m_popularities.contains(b->program)) {
                    return true;
                }

                const Popularity &aPopularity = m_popularities[a->program];
                const Popularity &bPopularity = m_popularities[b->program];
                if (aPopularity.count >= bPopularity.count) {
                    return aPopularity.count >= bPopularity.count;
                }

                return aPopularity.lastUse > bPopularity.lastUse;
            }

            if (a->priority != b->priority) {
                return a->priority < b->priority;
            } else {
                return a->name > b->name;
            }
        }
```

#### AUTO 


```{c}
auto strMode = json["mode"].toString();
```

#### LAMBDA EXPRESSION 


```{c}
[this](ProviderResult *a, ProviderResult *b) {
            Q_ASSERT(a);
            Q_ASSERT(b);

            if (a->isCalculation != b->isCalculation) {
                return a->isCalculation;
            }

            bool aStartMatch = a->name.startsWith(m_currentQuery, Qt::CaseInsensitive);
            bool bStartMatch = b->name.startsWith(m_currentQuery, Qt::CaseInsensitive);
            if (aStartMatch != bStartMatch) {
                return aStartMatch;
            }

            aStartMatch = a->program.startsWith(m_currentQuery, Qt::CaseInsensitive);
            bStartMatch = b->program.startsWith(m_currentQuery, Qt::CaseInsensitive);
            if (aStartMatch != bStartMatch) {
                return aStartMatch;
            }

            const bool aContains = a->name.contains(m_currentQuery, Qt::CaseInsensitive) ||
                                    a->program.contains(m_currentQuery, Qt::CaseInsensitive);
            const bool bContains = b->name.contains(m_currentQuery, Qt::CaseInsensitive) ||
                                    b->program.contains(m_currentQuery, Qt::CaseInsensitive);
            if (aContains != bContains) {
                return aContains;
            }

            const bool aHasPopularity = m_popularities.contains(a->program);
            const bool bHasPopularity = m_popularities.contains(b->program);
            if (aHasPopularity != bHasPopularity) {
                return aHasPopularity;
            }

            if (aHasPopularity && bHasPopularity) {
                const Popularity &aPopularity = m_popularities[a->program];
                const Popularity &bPopularity = m_popularities[b->program];

                const bool aHasMatchStrings = aPopularity.matchStrings.contains(m_currentQuery);
                const bool bHasMatchStrings = bPopularity.matchStrings.contains(m_currentQuery);
                if (aHasMatchStrings != bHasMatchStrings) {
                    return aHasMatchStrings;
                }

                if (aPopularity.count != bPopularity.count) {
                    return aPopularity.count > bPopularity.count;
                }

                if (aPopularity.lastUse != bPopularity.lastUse) {
                    return aPopularity.lastUse > bPopularity.lastUse;
                }
            }

            if (a->priority != b->priority) {
                return a->priority < b->priority;
            }

            if (a->name != b->name) {
                return a->name > b->name;
            }

            // They are 100% equal
            return false;
    }
```

#### AUTO 


```{c}
auto strBase = json["base"].toString();
```

#### RANGE FOR STATEMENT 


```{c}
for (const KUnitConversion::Unit &unit : category.mostCommonUnits()) {
            commonIds.insert(unit.id());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &key : settings.childGroups()) {
        settings.beginGroup(key);
        Popularity pop;
        pop.count = settings.value("launches").toLongLong();
        pop.lastUse = settings.value("lastUse").toLongLong();
        pop.matchStrings = settings.value("matchStrings").toStringList();
        m_popularities.insert(key, pop);
        settings.endGroup();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KUnitConversion::UnitCategory &candidateCategory : m_converter.categories()) {
            unit = matchUnitCaseInsensitive(name, candidateCategory, OnlyCommonUnits);
            if (unit.isValid()) {
                return unit;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](ProviderResult *a, ProviderResult *b) {
            Q_ASSERT(a);
            Q_ASSERT(b);

            const bool aContains = a->name.contains(m_currentQuery, Qt::CaseInsensitive) ||
                                    a->program.contains(m_currentQuery, Qt::CaseInsensitive);
            const bool bContains = b->name.contains(m_currentQuery, Qt::CaseInsensitive) ||
                                    b->program.contains(m_currentQuery, Qt::CaseInsensitive);
            if (aContains != bContains) {
                return aContains;
            }

            const bool aHasPopularity = m_popularities.contains(a->program);
            const bool bHasPopularity = m_popularities.contains(b->program);
            if (aHasPopularity != bHasPopularity) {
                return aHasPopularity;
            }

            if (aHasPopularity && bHasPopularity) {
                const Popularity &aPopularity = m_popularities[a->program];
                const Popularity &bPopularity = m_popularities[b->program];

                const bool aHasMatchStrings = aPopularity.matchStrings.contains(m_currentQuery);
                const bool bHasMatchStrings = bPopularity.matchStrings.contains(m_currentQuery);
                if (aHasMatchStrings != bHasMatchStrings) {
                    return aHasMatchStrings;
                }

                if (aPopularity.count != bPopularity.count) {
                    return aPopularity.count > bPopularity.count;
                }

                if (aPopularity.lastUse != bPopularity.lastUse) {
                    return aPopularity.lastUse > bPopularity.lastUse;
                }
            }

            bool aStartMatch = a->name.startsWith(m_currentQuery, Qt::CaseInsensitive);
            bool bStartMatch = b->name.startsWith(m_currentQuery, Qt::CaseInsensitive);
            if (aStartMatch != bStartMatch) {
                return aStartMatch;
            }

            aStartMatch = a->program.startsWith(m_currentQuery, Qt::CaseInsensitive);
            bStartMatch = b->program.startsWith(m_currentQuery, Qt::CaseInsensitive);
            if (aStartMatch != bStartMatch) {
                return aStartMatch;
            }

            if (a->isCalculation != b->isCalculation) {
                return a->isCalculation;
            }

            if (a->priority != b->priority) {
                return a->priority < b->priority;
            }

            if (a->name != b->name) {
                return a->name > b->name;
            }

            // They are 100% equal
            return false;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Provider* provider : m_providers) {
            QList<Application*> list = provider->getResults(query);
            for (Application *app : list) {
                app->setParent(this);
                m_apps.append(app);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Provider* provider : m_providers) {
        QList<ProviderResult*> list = provider->getResults(query);
        for (ProviderResult *app : list) {
            if (!app) {
                qWarning() << "got null app from" << provider;
                continue;
            }
            QQmlEngine::setObjectOwnership(app, QQmlEngine::JavaScriptOwnership);
            app->setParent(this);

            if (!app->isCalculation) {
                if (m_popularities.contains(app->program)) {
                    const Popularity &popularity = m_popularities[app->program];
                    app->priority = QDateTime::currentSecsSinceEpoch() - popularity.lastUse;
                    app->priority -= (3600 * 360) * popularity.count;

                    if (popularity.matchStrings.contains(query)) {
                        app->priority /= 2;
                    }
                }
            }

            newResults.append(app);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](float val1, float val2) { return val1 - val2; }
```

#### LAMBDA EXPRESSION 


```{c}
[this](ProviderResult *a, ProviderResult *b) {
            Q_ASSERT(a);
            Q_ASSERT(b);

            if (a->isCalculation != b->isCalculation) {
                if (a->isCalculation) {
                    return true;
                }
                if (b->isCalculation) {
                    return false;
                }
            }

            const bool aStartMatch = a->name.startsWith(m_currentQuery, Qt::CaseInsensitive) ||
                                        a->program.startsWith(m_currentQuery, Qt::CaseInsensitive);
            const bool bStartMatch = b->name.startsWith(m_currentQuery, Qt::CaseInsensitive) ||
                                        b->program.startsWith(m_currentQuery, Qt::CaseInsensitive);
            if (aStartMatch != bStartMatch) {
                return aStartMatch && !bStartMatch;
            }

            const bool aContains = a->name.contains(m_currentQuery, Qt::CaseInsensitive) ||
                                    a->program.contains(m_currentQuery, Qt::CaseInsensitive);
            const bool bContains = b->name.contains(m_currentQuery, Qt::CaseInsensitive) ||
                                    b->program.contains(m_currentQuery, Qt::CaseInsensitive);
            if (aContains != bContains) {
                return aContains && !bContains;
            }
            if (m_popularities.contains(a->program)) {
                if (!m_popularities.contains(b->program)) {
                    return true;
                }

                const Popularity &aPopularity = m_popularities[a->program];
                const Popularity &bPopularity = m_popularities[b->program];
                if (aPopularity.count != bPopularity.count) {
                    return aPopularity.count > bPopularity.count;
                }

                return aPopularity.lastUse > bPopularity.lastUse;
            }

            if (a->priority != b->priority) {
                return a->priority < b->priority;
            }

            return a->name > b->name;
    }
```

#### AUTO 


```{c}
auto i = m_dimension.begin();
```

#### AUTO 


```{c}
auto& exp = i.value();
```

#### AUTO 


```{c}
auto token = (i < tokens.count()) ? tokens.at(i)
                                          : Token(Token::stxOperator);
```

#### LAMBDA EXPRESSION 


```{c}
[](float val1, float val2) { return val1 * val2; }
```

#### AUTO 


```{c}
auto& ch
```

#### RANGE FOR STATEMENT 


```{c}
for (ProviderResult *app : list) {
            if (!app) {
                qWarning() << "got null app from" << provider;
                continue;
            }
            QQmlEngine::setObjectOwnership(app, QQmlEngine::JavaScriptOwnership);
            app->setParent(this);

            if (!app->isCalculation) {
                if (m_popularities.contains(app->program)) {
                    const Popularity &popularity = m_popularities[app->program];
                    app->priority = QDateTime::currentSecsSinceEpoch() - popularity.lastUse;
                    app->priority -= (3600 * 360) * popularity.count;

                    if (popularity.matchStrings.contains(query)) {
                        app->priority /= 2;
                    }
                }
            }

            newResults.append(app);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &dirPath : QStandardPaths::standardLocations(QStandardPaths::GenericDataLocation)) {
        m_fsWatcher->addPath(dirPath + QStringLiteral("/kservices5/"));
        loadDir(dirPath + QStringLiteral("/kservices5/")); // kcm files
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QPointer<Application> app : m_apps) {
        ret.append(app.data());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &key : m_popularities.keys()) {
        settings.beginGroup(key);
        settings.setValue("launches", m_popularities[key].count);
        settings.setValue("lastUse", m_popularities[key].lastUse);
        settings.setValue("matchStrings", m_popularities[key].matchStrings);
        settings.endGroup();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&](ProviderResult *a, ProviderResult *b) {
            if (a->isCalculation != b->isCalculation) {
            if (a->isCalculation) {
            return true;
            }
            if (b->isCalculation) {
            return false;
            }
            }

            const bool aStartMatch = a->name.startsWith(query, Qt::CaseInsensitive);
            const bool bStartMatch = b->name.startsWith(query, Qt::CaseInsensitive);
            if (aStartMatch != bStartMatch) {
            return aStartMatch && !bStartMatch;
            }

            const bool aContains = a->name.contains(query, Qt::CaseInsensitive);
            const bool bContains = b->name.contains(query, Qt::CaseInsensitive);
            if (aContains != bContains) {
            return aContains && !bContains;
            }
            if (m_popularities.contains(a->program)) {
                if (!m_popularities.contains(b->program)) {
                    return true;
                }

                const Popularity &aPopularity = m_popularities[a->program];
                const Popularity &bPopularity = m_popularities[b->program];
                if (aPopularity.count >= bPopularity.count) {
                    return aPopularity.count >= bPopularity.count;
                }

                return aPopularity.lastUse > bPopularity.lastUse;
            }

            if (a->priority != b->priority) {
                return a->priority < b->priority;
            } else {
                return a->name > b->name;
            }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &key : settings.childGroups()) {
        settings.beginGroup(key);
        popularity pop;
        pop.count = settings.value("launches").toLongLong();
        pop.lastUse = settings.value("lastUse").toLongLong();
        m_popularities.insert(key, pop);
        settings.endGroup();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (ProviderResult *app : list) {
            app->setParent(this);

            if (app->isCalculation) {
                m_apps.append(app);
                continue;
            }

            if (m_popularities.contains(app->program)) {
                const Popularity &popularity = m_popularities[app->program];
                app->priority = QDateTime::currentSecsSinceEpoch() - popularity.lastUse;
                app->priority -= (3600 * 360) * popularity.count;

                if (popularity.matchStrings.contains(query)) {
                    app->priority /= 2;
                }
            }

            m_apps.append(app);
        }
```

