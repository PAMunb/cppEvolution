#### AUTO 


```{c}
auto *file = new QFile(filename);
```

#### AUTO 


```{c}
auto *p = new KTNEFProperty(key, type, value, name);
```

#### AUTO 


```{c}
auto *p = new KTNEFProperty(key, type, value, QVariant());
```

#### AUTO 


```{c}
auto p = new KTNEFProperty(key, type, value, name);
```

#### AUTO 


```{c}
auto it = MAPI_NamedTagMap()->constFind(key);
```

#### AUTO 


```{c}
auto file = new QFile(filename);
```

#### AUTO 


```{c}
auto it = attendees.cbegin(), end = attendees.cend();
```

